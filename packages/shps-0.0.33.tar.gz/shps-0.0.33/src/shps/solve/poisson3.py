"""
Drop-in replacement for poisson_neumann with JIT-accelerated assembly.

Layers of speedup:
  1. No multiprocessing (eliminates IPC overhead).
  2. Numba @njit kernels with parallel=True for element computation,
     COO construction, and force-vector scatter — no temporary arrays,
     fused loops, multi-threaded where safe.
  3. Falls back gracefully to plain NumPy if Numba is unavailable.

API is unchanged: poisson_neumann(...) has the same signature and returns
the same result.
"""

import numpy as np
import scipy.sparse as sp
from time import perf_counter
from functools import partial


# Try Numba or fallback
try:
    from numba import njit, prange
    njit(lambda x: x + 1)(1.0)
    _HAS_NUMBA = True
except Exception:
    _HAS_NUMBA = False
    prange = range
    def njit(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator

#
# Solver
#
try:
    from pypardiso import spsolve as _spsolve
    _PARDISO = True
except ModuleNotFoundError:
    from scipy.sparse.linalg import spsolve as _spsolve
    _PARDISO = False

from .element import T3, T6, M0_T3, M0_T6, IJ0_T6, IK0_T6

# Pre-flatten IK0 once at import time for the T6 contraction
_IK0_FLAT = IK0_T6.reshape(36, 9).copy()   # contiguous (36, 9)

# ===================================================================
# JIT kernels — element stiffness
# ===================================================================

@njit#(cache=True, parallel=True)
def _batch_T3_jit(node_coords, conn, weights, ke_out, by_out, bz_out, areas_out):
    """
    Compute all T3 element stiffness matrices in parallel.
    Writes into pre-allocated output arrays — zero temporary allocations.
    """
    ne = conn.shape[0]
    for e in prange(ne):
        i0, i1, i2 = conn[e, 0], conn[e, 1], conn[e, 2]

        y1 = node_coords[i0, 0]; z1 = node_coords[i0, 1]
        y2 = node_coords[i1, 0]; z2 = node_coords[i1, 1]
        y3 = node_coords[i2, 0]; z3 = node_coords[i2, 1]

        z23 = z2 - z3;  z31 = z3 - z1;  z12 = z1 - z2
        y32 = y3 - y2;  y13 = y1 - y3;  y21 = y2 - y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

        by_out[e, 0] = z23;  by_out[e, 1] = z31;  by_out[e, 2] = z12
        bz_out[e, 0] = y32;  bz_out[e, 1] = y13;  bz_out[e, 2] = y21
        areas_out[e] = area

        w = weights[e] / (4.0 * area)
        ke_out[e, 0, 0] = (y32*y32 + z23*z23) * w
        ke_out[e, 0, 1] = (y13*y32 + z23*z31) * w
        ke_out[e, 0, 2] = (y21*y32 + z12*z23) * w
        ke_out[e, 1, 0] = ke_out[e, 0, 1]
        ke_out[e, 1, 1] = (y13*y13 + z31*z31) * w
        ke_out[e, 1, 2] = (y13*y21 + z12*z31) * w
        ke_out[e, 2, 0] = ke_out[e, 0, 2]
        ke_out[e, 2, 1] = ke_out[e, 1, 2]
        ke_out[e, 2, 2] = (y21*y21 + z12*z12) * w


@njit#(cache=True, parallel=True)
def _batch_T6_jit(node_coords, conn, weights, IK_flat, ke_out, by_out, bz_out, areas_out):
    """
    Compute all T6 element stiffness matrices in parallel.
    IK_flat: (36, 9) pre-flattened IK0_T6.
    """
    ne = conn.shape[0]
    for e in prange(ne):
        i0, i1, i2 = conn[e, 0], conn[e, 1], conn[e, 2]

        y1 = node_coords[i0, 0]; z1 = node_coords[i0, 1]
        y2 = node_coords[i1, 0]; z2 = node_coords[i1, 1]
        y3 = node_coords[i2, 0]; z3 = node_coords[i2, 1]

        z23 = z2 - z3;  z31 = z3 - z1;  z12 = z1 - z2
        y32 = y3 - y2;  y13 = y1 - y3;  y21 = y2 - y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

        by_out[e, 0] = z23;  by_out[e, 1] = z31;  by_out[e, 2] = z12
        bz_out[e, 0] = y32;  bz_out[e, 1] = y13;  bz_out[e, 2] = y21
        areas_out[e] = area

        # W[k,l] = by[k]*by[l] + bz[k]*bz[l],  flattened to length 9
        by0 = z23; by1 = z31; by2 = z12
        bz0 = y32; bz1 = y13; bz2 = y21

        W0 = by0*by0 + bz0*bz0
        W1 = by0*by1 + bz0*bz1
        W2 = by0*by2 + bz0*bz2
        W3 = by1*by0 + bz1*bz0
        W4 = by1*by1 + bz1*bz1
        W5 = by1*by2 + bz1*bz2
        W6 = by2*by0 + bz2*bz0
        W7 = by2*by1 + bz2*bz1
        W8 = by2*by2 + bz2*bz2

        coeff = weights[e] / (4.0 * area)

        # ke_flat[i] = sum_j W_flat[j] * IK_flat[i, j]   for i in 0..35
        for i in range(36):
            val = (W0 * IK_flat[i, 0] + W1 * IK_flat[i, 1] + W2 * IK_flat[i, 2]
                 + W3 * IK_flat[i, 3] + W4 * IK_flat[i, 4] + W5 * IK_flat[i, 5]
                 + W6 * IK_flat[i, 6] + W7 * IK_flat[i, 7] + W8 * IK_flat[i, 8])
            ke_out[e, i // 6, i % 6] = val * coeff


# ===================================================================
# JIT kernels — COO fill
# ===================================================================

@njit#(cache=True, parallel=True)
def _fill_coo(conn, ke_all, rows, cols, data):
    """
    Fill pre-allocated COO arrays from batched element matrices.
    No Python-level memory allocation inside the loop.
    """
    ne  = conn.shape[0]
    nne = conn.shape[1]
    stride = nne * nne          # entries per element
    for e in prange(ne):
        base = e * stride
        for a in range(nne):
            ra = conn[e, a]
            for b in range(nne):
                idx = base + a * nne + b
                rows[idx] = ra
                cols[idx] = conn[e, b]
                data[idx] = ke_all[e, a, b]


# ===================================================================
# JIT kernels — force-vector scatter  (replaces slow np.add.at)
# ===================================================================

@njit(cache=True)
def _scatter_force(conn, fe_all, Fa):
    """
    Scatter-add element force vectors into global vector.
    Sequential (race-safe) but much faster than np.add.at.
    """
    ne  = conn.shape[0]
    nne = conn.shape[1]
    for e in range(ne):             # NOT prange — avoid race on Fa
        for a in range(nne):
            Fa[conn[e, a]] += fe_all[e, a]


# ===================================================================
# JIT kernels — Hilbert load
# ===================================================================

@njit#(cache=True, parallel=True)
def _hilbert_T3_jit(conn, weights_area, f, M0, fe_out):
    """fe[e] = weights_area[e] * M0 @ f[conn[e]]"""
    ne = conn.shape[0]
    for e in prange(ne):
        w = weights_area[e]
        f0 = f[conn[e, 0]]
        f1 = f[conn[e, 1]]
        f2 = f[conn[e, 2]]
        for i in range(3):
            fe_out[e, i] = w * (M0[i, 0]*f0 + M0[i, 1]*f1 + M0[i, 2]*f2)


@njit#(cache=True, parallel=True)
def _hilbert_T6_jit(conn, weights_area, f, M0, fe_out):
    ne = conn.shape[0]
    for e in prange(ne):
        w = weights_area[e]
        # gather
        fv = np.empty(6)
        for a in range(6):
            fv[a] = f[conn[e, a]]
        for i in range(6):
            s = 0.0
            for j in range(6):
                s += M0[i, j] * fv[j]
            fe_out[e, i] = w * s


# ===================================================================
# JIT kernels — Poisson load
# ===================================================================

@njit#(cache=True, parallel=True)
def _poisson_T3_jit(conn, by, bz, weights, fy, fz, fe_out):
    """fe[e,i] = (1/6) * (by[e,i]*sum(fy[conn[e]]) + bz[e,i]*sum(fz[conn[e]])) * w[e]"""
    ne = conn.shape[0]
    for e in prange(ne):
        fy_sum = fy[conn[e, 0]] + fy[conn[e, 1]] + fy[conn[e, 2]]
        fz_sum = fz[conn[e, 0]] + fz[conn[e, 1]] + fz[conn[e, 2]]
        w = weights[e] / 6.0
        for i in range(3):
            fe_out[e, i] = (by[e, i] * fy_sum + bz[e, i] * fz_sum) * w


@njit#(cache=True, parallel=True)
def _poisson_T6_jit(conn, by, bz, weights, fy, fz, IJ_flat, fe_out):
    """
    Vectorised T6 Poisson load with JIT.
    IJ_flat: IJ0_T6.reshape(36, 3), shape (36, 3).
    """
    ne = conn.shape[0]
    for e in prange(ne):
        # Py_flat[i] = 0.5 * sum_k by[e,k] * IJ_flat[i, k]   for i in 0..35
        # Pz_flat[i] = 0.5 * sum_k bz[e,k] * IJ_flat[i, k]
        # Py is (6,6) row-major; fe[e,i] = sum_j Py[i,j]*fy[conn[e,j]] + Pz[i,j]*fz[conn[e,j]]

        # gather field values
        fy_e = np.empty(6)
        fz_e = np.empty(6)
        for a in range(6):
            fy_e[a] = fy[conn[e, a]]
            fz_e[a] = fz[conn[e, a]]

        b0 = by[e, 0]; b1 = by[e, 1]; b2 = by[e, 2]
        c0 = bz[e, 0]; c1 = bz[e, 1]; c2 = bz[e, 2]
        w = weights[e]

        for i in range(6):
            val = 0.0
            for j in range(6):
                idx = i * 6 + j
                Pij_y = 0.5 * (b0 * IJ_flat[idx, 0] + b1 * IJ_flat[idx, 1] + b2 * IJ_flat[idx, 2])
                Pij_z = 0.5 * (c0 * IJ_flat[idx, 0] + c1 * IJ_flat[idx, 1] + c2 * IJ_flat[idx, 2])
                val += Pij_y * fy_e[j] + Pij_z * fz_e[j]
            fe_out[e, i] = val * w


# ===================================================================
# Pre-flatten IJ0 for the T6 Poisson JIT kernel
# ===================================================================
_IJ0_FLAT = IJ0_T6.reshape(36, 3).copy()


# ===================================================================
# Wrapper helpers
# ===================================================================

def _batch_T3(nodes, conn, weights):
    ne = conn.shape[0]
    ke  = np.empty((ne, 3, 3))
    by  = np.empty((ne, 3))
    bz  = np.empty((ne, 3))
    areas = np.empty(ne)
    _batch_T3_jit(nodes, conn, weights, ke, by, bz, areas)
    return ke, by, bz, areas


def _batch_T6(nodes, conn, weights):
    ne = conn.shape[0]
    ke  = np.empty((ne, 6, 6))
    by  = np.empty((ne, 3))
    bz  = np.empty((ne, 3))
    areas = np.empty(ne)
    _batch_T6_jit(nodes, conn, weights, _IK0_FLAT, ke, by, bz, areas)
    return ke, by, bz, areas


def _build_coo(conn, ke_all, ndof):
    ne  = conn.shape[0]
    nne = conn.shape[1]
    total = ne * nne * nne
    rows = np.empty(total, dtype=np.intp)
    cols = np.empty(total, dtype=np.intp)
    data = np.empty(total)
    _fill_coo(conn, ke_all, rows, cols, data)
    return sp.coo_matrix((data, (rows, cols)), shape=(ndof, ndof))


# ===================================================================
# Load dispatch helpers
# ===================================================================

def _is_hilbert_load(load):
    return isinstance(load, partial) and load.func.__name__ == '_hilbert_kernel'

def _is_poisson_load(load):
    return isinstance(load, partial) and load.func.__name__ == '_poisson_source'


def _apply_hilbert(shape, conn, areas, weights_area, load, Fa):
    f = load.keywords['f']
    nne = conn.shape[1]
    ne  = conn.shape[0]
    fe  = np.empty((ne, nne))
    if shape == "T3":
        _hilbert_T3_jit(conn, weights_area, f, M0_T3, fe)
    else:
        _hilbert_T6_jit(conn, weights_area, f, M0_T6, fe)
    _scatter_force(conn, fe, Fa)


def _apply_poisson(shape, conn, by, bz, weights, load, Fa):
    fy = load.keywords['fy']
    fz = load.keywords['fz']
    ne  = conn.shape[0]
    nne = conn.shape[1]
    fe  = np.empty((ne, nne))
    if shape == "T3":
        _poisson_T3_jit(conn, by, bz, weights, fy, fz, fe)
    else:
        _poisson_T6_jit(conn, by, bz, weights, fy, fz, _IJ0_FLAT, fe)
    _scatter_force(conn, fe, Fa)


# ===================================================================
# Main solver (same API as original)
# ===================================================================

def poisson_neumann(
        nodes=None,
        elements=None,
        model=None,
        materials=None,
        force=None,
        loads=None,
        measure=None,
        threads=6,
        chunk=200,
        fix_node=None,
        fix_value=1.0,
        verbose=False
):
    # resolve model shorthand
    if model is not None:
        assert nodes is None and elements is None
        nodes = model.nodes
        elements = model.elems

    if measure is not None:
        assert model is not None
        assert materials is None
        materials = {
            cell.group: model.cell_weight(cell, measure)
            for cell in elements
        }

    if loads is None:
        loads = []

    ndf        = 1
    ndof_total = ndf * len(nodes)
    Fa         = np.zeros(ndof_total)
    if force is not None:
        Fa += force

    tic = perf_counter()

    # bucket elements by shape
    buckets = {}
    for cell in elements:
        buckets.setdefault(cell.shape, []).append(cell)

    coo_parts = []

    for shape, cells in buckets.items():
        nne = {"T3": 3, "T6": 6}[shape]
        ne  = len(cells)

        conn    = np.empty((ne, nne), dtype=np.intp)
        weights = np.ones(ne)
        for e, cell in enumerate(cells):
            conn[e] = cell.nodes
            if cell.group is not None and materials is not None:
                weights[e] = materials[cell.group]

        # Element computation (JIT parallel)
        if shape == "T3":
            ke_all, by, bz, areas = _batch_T3(nodes, conn, weights)
        elif shape == "T6":
            ke_all, by, bz, areas = _batch_T6(nodes, conn, weights)
        else:
            raise ValueError(f"Unknown element shape: {shape}")

        # Global stiffness (JIT COO fill)
        coo_parts.append(_build_coo(conn, ke_all, ndof_total))

        # Loads
        weights_area = areas * weights

        for load in loads:
            if _is_hilbert_load(load):
                _apply_hilbert(shape, conn, areas, weights_area, load, Fa)
            elif _is_poisson_load(load):
                _apply_poisson(shape, conn, by, bz, weights, load, Fa)
            else:
                # Fallback: per-element (custom / Burgers loads)
                for e, cell in enumerate(cells):
                    fe = load(cell, by[e], bz[e], areas[e])
                    np.add.at(Fa, cell.nodes, fe)

    if verbose:
        print(f"Assembly   : {perf_counter() - tic:6.3f} s")

    # ---- Merge COO into CSR --------------------------------------------------
    K = sum(coo_parts).tocsr()

    # ---- Dirichlet fix -----------------------------------------------------
    if fix_node is None:
        fix_node = 0

    tic = perf_counter()
    fixed = np.array([fix_node * ndf])
    free  = np.setdiff1d(np.arange(ndof_total), fixed)

    Pf = Fa[free] - K[free][:, fixed].toarray().ravel() * fix_value
    if verbose:
        print(f"Compatibility: {abs(Fa.sum())/(100*Fa.max()):.6e} (should be 0.0)")

    Kf = K[free][:, free]

    # ---- Solve -------------------------------------------------------------
    Uf = _spsolve(Kf, Pf)

    if verbose:
        print(f"Solve      : {perf_counter() - tic:6.3f} s "
              f"({'PARDISO' if _PARDISO else 'SuperLU'})")

    u = np.empty(ndof_total)
    u[free]  = Uf
    u[fixed] = fix_value
    return u