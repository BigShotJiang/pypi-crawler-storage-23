
import numpy as np
import math

from dataclasses import dataclass

try:
    from numba import njit as jit 
    from numba import prange
    jit(lambda x: x**2)(1.0)  # test if numba is available

except:
    prange = range
    def jit(*_, **__):
        def _decorator(func):
            return func
        return _decorator


@dataclass
class _Element:
    nodes: tuple # of int
  # gauss: tuple # of Gauss
    shape: str
    model: dict = None
    group: int = 0
    tag: int = 0

import numpy as np


# T6 shape terms in barycentric form: list of (a,b,c,coef)
Ni_terms = [
    [(2,0,0, 2.0), (1,0,0,-1.0)],        # N1
    [(0,2,0, 2.0), (0,1,0,-1.0)],        # N2
    [(0,0,2, 2.0), (0,0,1,-1.0)],        # N3
    [(1,1,0, 4.0)],                      # N4
    [(0,1,1, 4.0)],                      # N5
    [(1,0,1, 4.0)],                      # N6
]

# dN/dL1, dN/dL2, dN/dL3 for each Ni 
dN_dL = [
    ([(1,0,0, 4.0), (0,0,0,-1.0)], [], []),      # N1
    ([], [(0,1,0, 4.0), (0,0,0,-1.0)], []),      # N2
    ([], [], [(0,0,1, 4.0), (0,0,0,-1.0)]),      # N3
    ([(0,1,0, 4.0)], [(1,0,0, 4.0)], []),        # N4
    ([], [(0,0,1, 4.0)], [(0,1,0, 4.0)]),        # N5
    ([(0,0,1, 4.0)], [], [(1,0,0, 4.0)]),        # N6
]

#
# Exact barycentric monomial integral:
# ∫_Ω L1^a L2^b L3^c dΩ = 2A * (a! b! c!) / (a+b+c+2)!

def _I(A, a, b, c):
    return 2.0*A * math.factorial(a)*math.factorial(b)*math.factorial(c) / math.factorial(a+b+c+2)

# Exact barycentric monomial integral without area factor:
# I0(a,b,c) = ∫ L1^a L2^b L3^c dΩ / A 
#           = 2 * (a! b! c!) / (a+b+c+2)!   (since ∫ = A * I0)
def _I0(a, b, c):
    return 2.0 * math.factorial(a)*math.factorial(b)*math.factorial(c) / math.factorial(a+b+c+2)


def _init_hilbert():
    # 
    # M0: 6x6 matrix with ∫ Ni Nj dΩ = A * M0[i,j]
    M0 = np.zeros((6,6))
    for i in range(6):
        for j in range(6):
            s = 0.0
            for (a1,b1,c1,ci) in Ni_terms[i]:
                for (a2,b2,c2,cj) in Ni_terms[j]:
                    s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
            M0[i,j] = s

    return M0


def _init_poisson():
    # Convection terms ,like ∫ N (c . ∇u) dΩ

    # IJ0: 6x6x3 with ∫ (dNi/dLk) Nj dΩ = A * IJ0[i,j,k], k=0..2 for L1,L2,L3
    IJ0 = np.zeros((6,6,3))
    for i in range(6):
        for j in range(6):
            for k in range(3):
                s = 0.0
                for (a1,b1,c1,ci) in dN_dL[i][k]:
                    for (a2,b2,c2,cj) in Ni_terms[j]:
                        s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
                IJ0[i,j,k] = s

    return IJ0

def _init_sobolev():
    # Stiffness, or diffusion terms

    # IK0: 6x6x3x3 with ∫ (dNi/dLk)(dNj/dLl) dΩ = A * IK0[i,j,k,l]
    IK0 = np.zeros((6,6,3,3))
    for i in range(6):
        for j in range(6):
            for k in range(3):
                for l in range(3):
                    s = 0.0
                    for (a1,b1,c1,ci) in dN_dL[i][k]:
                        for (a2,b2,c2,cj) in dN_dL[j][l]:
                            s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
                    IK0[i,j,k,l] = s
    return IK0


def _init_burgers():
    # Barycentric moments
    # J0[i,j,k,m] = ∫ (dNi/dLm) Nj Nk dΩ / A   (i,j,k=0..5, m=0..2 for L1..L3)
    J0 = np.zeros((6,6,6,3))
    for i in range(6):
        for j in range(6):
            for k in range(6):

                # multiply dNi/dLm term-by-term with Nj and Nk
                for m in range(3):
                    s = 0.0
                    for (a1,b1,c1,ci) in dN_dL[i][m]:
                        for (a2,b2,c2,cj) in Ni_terms[j]:
                            for (a3,b3,c3,ck) in Ni_terms[k]:
                                s += ci*cj*ck * _I0(a1+a2+a3, b1+b2+b3, c1+c2+c3)
                    J0[i,j,k,m] = s

    return J0


M0_T6  = _init_hilbert()  # 6x6 matrix for Hilbert integral
IJ0_T6 = _init_poisson()
IK0_T6 = _init_sobolev()
IK0_flat = IK0_T6.reshape(9, 36)
J0_T6  = _init_burgers()

# P = np.array([0, 1, 2, 4, 5, 3], dtype=np.int64)

# M0_T6  = M0_T6[np.ix_(P, P)]
# IJ0_T6 = IJ0_T6[P][:, P, :]
# IK0_T6 = IK0_T6[P][:, P, :, :]
# J0_T6  = J0_T6[P][:, P][:, :, P, :]


M0_T3 = np.array([[2,1,1],
                  [1,2,1],
                  [1,1,2]],dtype=float)/12


def _barycentric_T3(r, p1, p2, p3):
    """
    r  : (y,z) point
    p1,p2,p3 : corner points (y,z)
    returns (L1,L2,L3)
    """
    
    y, z = r
    y1, z1 = p1
    y2, z2 = p2
    y3, z3 = p3
    T = np.array([[y1 - y3, y2 - y3],
                  [z1 - z3, z2 - z3]])
    L1, L2 = np.linalg.solve(T, np.array([y - y3, z - z3]))
    L3 = 1.0 - L1 - L2
    return L1, L2, L3

    # signed area * 2
    den = (y2 - y1)*(z3 - z1) - (y3 - y1)*(z2 - z1)
    if abs(den) < 1e-30:
        raise ValueError("Degenerate triangle (zero area).")
    

    L1 = ((y2 - y)*(z3 - z) - (y3 - y)*(z2 - z)) / den
    L2 = ((y3 - y)*(z1 - z) - (y1 - y)*(z3 - z)) / den
    L3 = 1.0 - L1 - L2
    return L1, L2, L3



def barycentric_T3_and_grads(r, p1, p2, p3):
    y, z = r
    y1, z1 = p1
    y2, z2 = p2
    y3, z3 = p3

    den = (y2 - y1)*(z3 - z1) - (y3 - y1)*(z2 - z1)  # = 2A (signed)
    if abs(den) < 1e-30:
        raise ValueError("Degenerate triangle (zero area).")

    L1 = ((y2 - y)*(z3 - z) - (y3 - y)*(z2 - z)) / den
    L2 = ((y3 - y)*(z1 - z) - (y1 - y)*(z3 - z)) / den
    L3 = 1.0 - L1 - L2

    # ∇Li = [dLi/dy, dLi/dz] (constant over the element)
    dL1 = np.array([(z2 - z3)/den, (y3 - y2)/den])
    dL2 = np.array([(z3 - z1)/den, (y1 - y3)/den])
    dL3 = -dL1 - dL2

    return (L1, L2, L3), (dL1, dL2, dL3)


class T6(_Element):
    _triangles = [
        (0, 1, 3),
        (1, 2, 4),
        (2, 0, 5),
        (3, 4, 5)
    ]
    _quadrature = [
        ((1/6, 1/6, 2/3), 1/3),
        ((1/6, 2/3, 1/6), 1/3),
        ((2/3, 1/6, 1/6), 1/3)
    ]

    @property 
    def fibers(self):
        for point, weight in self._quadrature:
            L1, L2, L3 = point
            r = L1*self.model.nodes[self.nodes[0]] + \
                L2*self.model.nodes[self.nodes[1]] + \
                L3*self.model.nodes[self.nodes[2]]
            yield r, self.area * weight

    @property
    def area(self):
        y, z = self.model.nodes[self.nodes[:3]].T
        z1, z2, z3 = z
        y1, y2, y3 = y
        a = float(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))
        return a


    def interp(self, field, r):
        # compute L1,L2,L3 from corners 1..3
        P = self.model.nodes[self.nodes]
        p1, p2, p3 = P[0], P[1], P[2]
        L1, L2, L3 = _barycentric_T3(r, p1, p2, p3)

        N = np.array([
             L1*(2*L1 - 1),
             L2*(2*L2 - 1),
             L3*(2*L3 - 1),
             4*L1*L2,   # edge (1,2)
             4*L2*L3,   # edge (2,3)
             4*L3*L1,   # edge (3,1)
        ])
        return np.dot(N, field[self.nodes])

        u1, u2, u3, u4, u5, u6 = field[self.nodes]

        # Triangle: u4 on (2,3), u5 on (3,1), u6 on (1,2)
        return (
            N1*u1 + N2*u2 + N3*u3
            + N5*u4   # (2,3)
            + N6*u5   # (3,1)
            + N4*u6   # (1,2)
        )

    def gradient(self, field, r):
        # Corners are nodes 1..3 from Triangle -o2
        P = self.model.nodes[self.nodes]   # (6,2) -> (y,z)
        p1, p2, p3 = P[0], P[1], P[2]

        (L1, L2, L3), (dL1, dL2, dL3) = barycentric_T3_and_grads(r, p1, p2, p3)

        # Shape function gradients
        dN = np.array([
           (4*L1 - 1) * dL1,
           (4*L2 - 1) * dL2,
           (4*L3 - 1) * dL3,
           4*(L2*dL1 + L1*dL2),  # edge (1,2)
           4*(L3*dL2 + L2*dL3),  # edge (2,3)
           4*(L1*dL3 + L3*dL1)   # edge (3,1)
        ])
        return np.dot(dN.T, field[self.nodes])  # [du/dy, du/dz]

    def inertia(self, u, v, *, weight='e'):
        w = self.model._measures[self.group][weight]*self.area 
        return u.dot(M0_T6 @ v) * w

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, x, y):
        # gy = (1/(2A)) * (b_k * A * IJ0[:,:,k]) = 0.5 * Σ_k b_k IJ0[:,:,k]
        Py = 0.5 * (by[0]*IJ0_T6[:,:,0] + by[1]*IJ0_T6[:,:,1] + by[2]*IJ0_T6[:,:,2])

        # gz = 0.5 * Σ_k c_k IJ0[:,:,k]
        Pz = 0.5 * (bz[0]*IJ0_T6[:,:,0] + bz[1]*IJ0_T6[:,:,1] + bz[2]*IJ0_T6[:,:,2])
        return Py@x + Pz@y

    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, area, f):
        return area*M0_T6 @ f

    @staticmethod
    def state(xyz):
        ((y1, y2, y3), (z1, z2, z3)) = xyz[:, :3]

        z12, z23, z31 = z1 - z2, z2 - z3, z3 - z1
        y32, y13, y21 = y3 - y2, y1 - y3, y2 - y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

        #  ∫ N^T N dΩ
        me = area*M0_T6

        # ∫ (∇N)^T (∇N) dΩ
        by = np.array([ z23,  z31,  z12])
        bz = np.array([ y32,  y13,  y21])

        me = area * M0_T6

        # ke = (1/(4A)) * Σ_{k,l} (b_k b_l + c_k c_l) * IK0[:,:,k,l]
        W  = np.outer(bz,bz) + np.outer(by,by)       # 3x3
        # ke = (1.0/(4.0*A)) * np.einsum('kl,ijkl->ij', W, IK0)
        ke = (1.0/(4.0*area)) * np.tensordot(W, IK0_T6, axes=([0,1],[2,3]))  # (6,6)

        return me, ke, by, bz, area


class T3(_Element):
    _triangles = [(0,1,2)]

    @property
    def fibers(self):
        yield sum(self.model.nodes[self.nodes])/3.0, self.area

    @property
    def area(self):
        y, z = self.model.nodes[self.nodes].T
        z1, z2, z3 = z
        y1, y2, y3 = y
        a = float(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))
        return abs(a)
    
    def interp(self, field, r):
        # compute L1,L2,L3 from corners 1..3
        P = self.model.nodes[self.nodes]
        p1, p2, p3 = P[0], P[1], P[2]
        L1, L2, L3 = _barycentric_T3(r, p1, p2, p3)

        N = np.array([
             L1,
             L2,
             L3,
        ])
        return np.dot(N, field[self.nodes])
    # def interp(self, field, r):
    #     return sum(field[self.nodes]) / 3.0

    # def interp(self, field, r):
    #     u1, u2, u3 = field[self.nodes]
    #     ((y1, y2, y3), (z1, z2, z3)) = self.model.nodes[self.nodes].T
    #     z12 = z1 - z2
    #     z23 = z2 - z3
    #     z31 = z3 - z1
    #     y32 = y3 - y2
    #     y13 = y1 - y3
    #     y21 = y2 - y1
    #     A = self.area
    #     N1 = 1/(2*A)*(z23*(r[0]-y3) + y32*(r[1]-z3))
    #     N2 = 1/(2*A)*(z31*(r[0]-y3) + y13*(r[1]-z3))
    #     N3 = 1/(2*A)*(z12*(r[0]-y3) + y21*(r[1]-z3))
    #     return N1*u1 + N2*u2 + N3*u3

    def inertia(self, u, v, *, weight='e'):
        w = self.model._measures[self.group][weight]*self.area 
        return u.dot(M0_T3 @ v) * w

    def gradient(self, field, r):
        # May also try Cook equation 3.4-6
        u1, u2, u3 = field[self.nodes]
        ((y1, y2, y3), (z1, z2, z3)) = self.model.nodes[self.nodes].T
        z12 = z1 - z2
        z23 = z2 - z3
        z31 = z3 - z1
        y32 = y3 - y2
        y13 = y1 - y3
        y21 = y2 - y1
        A = self.area
        return 1/(2*A)*np.array([
            z23*u1 + z31*u2 + z12*u3,
            y32*u1 + y13*u2 + y21*u3
        ])


    @staticmethod
    # @jit(cache=True, fastmath=True)
    def state(xyz):
        ((y1, y2, y3), (z1, z2, z3)) = xyz

        z12, z23, z31 = z1-z2, z2-z3, z3-z1
        y32, y13, y21 = y3-y2, y1-y3, y2-y1

        by, bz, area = T3.tangent(xyz)

        #  ∫ N^T N dΩ
        me = area*M0_T3

        # ∫ (∇N)^T (∇N) dΩ

        k11 =  y32**2  + z23**2
        k12 =  y13*y32 + z23*z31
        k13 =  y21*y32 + z12*z23
        k22 =  y13**2  + z31**2
        k23 =  y13*y21 + z12*z31
        k33 =  y21**2  + z12**2
        ke  = 1/(4.0*area) * np.array([[k11, k12, k13],
                                       [k12, k22, k23],
                                       [k13, k23, k33]])

        return me, ke, by, bz, area


    @staticmethod
    @jit(cache=True, fastmath=True)
    def tangent(xyz): # _map_triangle

        ((y1, y2, y3), (z1, z2, z3)) = xyz

        z12, z23, z31 = z1-z2, z2-z3, z3-z1
        y32, y13, y21 = y3-y2, y1-y3, y2-y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))


        # ∇N
        by = np.array([ z23,  z31,  z12])
        bz = np.array([ y32,  y13,  y21])

        return by, bz, area
    

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, fy, fz):
        #  ∫ (∂N/∂y)^T N dΩ
        Py = (1.0/6.0) * np.outer( by, [1.0, 1.0, 1.0])
        #  ∫ (∂N/∂z)^T N dΩ
        Pz = (1.0/6.0) * np.outer( bz, [1.0, 1.0, 1.0])
        return Py@fy + Pz@fz
    
    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, dA, f):
        return dA*M0_T3 @ f
    
# -----------------------------------------------------------------------------
# Reference (xi,eta) = [-1,1]x[-1,1] Q1 (R4) and Q2 (R9) Lagrange shape functions
# Assumed node orderings:
#
# R4 (4-node bilinear quad):
#   0: (-1,-1)  bottom-left
#   1: ( 1,-1)  bottom-right
#   2: ( 1, 1)  top-right
#   3: (-1, 1)  top-left
#
# R9 (9-node biquadratic quad):
#   0: (-1,-1)  bottom-left
#   1: ( 1,-1)  bottom-right
#   2: ( 1, 1)  top-right
#   3: (-1, 1)  top-left
#   4: ( 0,-1)  mid bottom (0-1)
#   5: ( 1, 0)  mid right  (1-2)
#   6: ( 0, 1)  mid top    (2-3)
#   7: (-1, 0)  mid left   (3-0)
#   8: ( 0, 0)  center
# -----------------------------------------------------------------------------

# ---- R4 (Q1) ---------------------------------------------------------------

def _N_R4(xi, eta):
    return np.array([
        0.25*(1.0-xi)*(1.0-eta),
        0.25*(1.0+xi)*(1.0-eta),
        0.25*(1.0+xi)*(1.0+eta),
        0.25*(1.0-xi)*(1.0+eta),
    ])

def _dN_dxi_R4(xi, eta):
    return np.array([
        -0.25*(1.0-eta),
         0.25*(1.0-eta),
         0.25*(1.0+eta),
        -0.25*(1.0+eta),
    ])

def _dN_deta_R4(xi, eta):
    return np.array([
        -0.25*(1.0-xi),
        -0.25*(1.0+xi),
         0.25*(1.0+xi),
         0.25*(1.0-xi),
    ])

# ---- R9 (Q2) ---------------------------------------------------------------

def _phi(x):
    # 1D Lagrange on [-1,0,1]
    return np.array([0.5*x*(x-1.0), 1.0-x*x, 0.5*x*(x+1.0)])

def _dphi(x):
    return np.array([x-0.5, -2.0*x, x+0.5])

# map the 9 nodes (see ordering above) to tensor indices (i,j) in {0,1,2}^2
_R9_IJ = [
    (0, 0),  # 0: (-1,-1)
    (2, 0),  # 1: ( 1,-1)
    (2, 2),  # 2: ( 1, 1)
    (0, 2),  # 3: (-1, 1)
    (1, 0),  # 4: ( 0,-1)
    (2, 1),  # 5: ( 1, 0)
    (1, 2),  # 6: ( 0, 1)
    (0, 1),  # 7: (-1, 0)
    (1, 1),  # 8: ( 0, 0)
]

def _N_R9(xi, eta):
    px = _phi(xi); py = _phi(eta)
    N = np.empty(9, dtype=float)
    for a, (i, j) in enumerate(_R9_IJ):
        N[a] = px[i] * py[j]
    return N

def _dN_dxi_R9(xi, eta):
    dpx = _dphi(xi); py = _phi(eta)
    dN = np.empty(9, dtype=float)
    for a, (i, j) in enumerate(_R9_IJ):
        dN[a] = dpx[i] * py[j]
    return dN

def _dN_deta_R9(xi, eta):
    px = _phi(xi); dpy = _dphi(eta)
    dN = np.empty(9, dtype=float)
    for a, (i, j) in enumerate(_R9_IJ):
        dN[a] = px[i] * dpy[j]
    return dN


# -----------------------------------------------------------------------------
# Gauss rules & reference integrals (computed once)
#
# We build:
#   M0     : mass reference integral normalized so physical me = area * M0
#   Kxi    : ∫ (dN/dxi)^T (dN/dxi) dxi deta
#   Keta   : ∫ (dN/deta)^T(dN/deta) dxi deta
#   Kxieta : ∫ (dN/dxi)^T(dN/deta) dxi deta
#   Sxi    : ∫ (dN/dxi)^T N dxi deta     (i.e. outer(dNxi, N))
#   Seta   : ∫ (dN/deta)^T N dxi deta
#
# For an affine map from reference square to a perfect rectangle/parallelogram:
#   detJ = area/4  (since reference area = 4)
# so: me = detJ * Mref = area*(Mref/4) = area*M0
# -----------------------------------------------------------------------------

_G2_PTS = np.array([-1.0/np.sqrt(3.0),  1.0/np.sqrt(3.0)])
_G2_WTS = np.array([1.0, 1.0])

_G3_PTS = np.array([-np.sqrt(3.0/5.0), 0.0, np.sqrt(3.0/5.0)])
_G3_WTS = np.array([5.0/9.0, 8.0/9.0, 5.0/9.0])

def _build_ref_mats(n, Nfun, dNxi_fun, dNeta_fun, pts, wts):
    M = np.zeros((n, n))
    Kxi = np.zeros((n, n))
    Keta = np.zeros((n, n))
    Kxieta = np.zeros((n, n))
    Sxi = np.zeros((n, n))
    Seta = np.zeros((n, n))
    for xi, wxi in zip(pts, wts):
        for eta, weta in zip(pts, wts):
            w = wxi * weta
            N = Nfun(xi, eta)
            dNxi = dNxi_fun(xi, eta)
            dNeta = dNeta_fun(xi, eta)

            M += w * np.outer(N, N)
            Kxi += w * np.outer(dNxi, dNxi)
            Keta += w * np.outer(dNeta, dNeta)
            Kxieta += w * np.outer(dNxi, dNeta)

            Sxi += w * np.outer(dNxi, N)
            Seta += w * np.outer(dNeta, N)

    M0 = M / 4.0  # because detJ = area/4
    return M0, Kxi, Keta, Kxieta, Sxi, Seta

# R4 reference matrices (2x2 Gauss is exact for Q1 integrands here)
M0_R4, KXI_R4, KETA_R4, KXIETA_R4, SXI_R4, SETA_R4 = _build_ref_mats(
    4, _N_R4, _dN_dxi_R4, _dN_deta_R4, _G2_PTS, _G2_WTS
)

# R9 reference matrices (3x3 Gauss is exact up to degree 5; enough for Q2 mass/stiffness)
M0_R9, KXI_R9, KETA_R9, KXIETA_R9, SXI_R9, SETA_R9 = _build_ref_mats(
    9, _N_R9, _dN_dxi_R9, _dN_deta_R9, _G3_PTS, _G3_WTS
)

# -----------------------------------------------------------------------------
# Geometry helpers (perfect rectangle / affine quad)
# Uses only corner nodes 0,1,3 (consistent with your "no iso mapping" assumption)
# r(xi,eta) = p0 + 0.5*(1+xi)*(p1-p0) + 0.5*(1+eta)*(p3-p0)
# -----------------------------------------------------------------------------

def _rect_map(p0, p1, p3, xi, eta):
    e1 = p1 - p0
    e2 = p3 - p0
    return p0 + 0.5*(1.0 + xi)*e1 + 0.5*(1.0 + eta)*e2

def _rect_xieta(p0, p1, p3, r):
    e1 = p1 - p0
    e2 = p3 - p0
    A = np.column_stack((e1, e2))  # 2x2
    s, t = np.linalg.solve(A, (r - p0))
    return 2.0*s - 1.0, 2.0*t - 1.0

def _rect_tangent_from_xyz(xyz):
    """
    xyz: shape (2, nnodes) where row0=y, row1=z (matches your T3/T6.state style)
    Returns:
      by, bz: rows of J^{-T}, each shape (2,) giving coefficients for [d/dxi, d/deta]
              so that: d/dy = by[0] d/dxi + by[1] d/deta
                      d/dz = bz[0] d/dxi + bz[1] d/deta
      area: positive area
    """
    y = xyz[0]; z = xyz[1]
    y0, y1, y3 = y[0], y[1], y[3]
    z0, z1, z3 = z[0], z[1], z[3]

    e1y, e1z = y1 - y0, z1 - z0
    e2y, e2z = y3 - y0, z3 - z0

    detA = e1y*e2z - e1z*e2y         # signed
    area = abs(detA)

    inv_det = 1.0 / detA            # keep sign for the map orientation
    # J = [e1/2, e2/2] => J^{-T} = 2*A^{-T}
    by = 2.0*inv_det*np.array([ e2z, -e1z])   # [d xi/dy, d eta/dy]
    bz = 2.0*inv_det*np.array([-e2y,  e1y])   # [d xi/dz, d eta/dz]
    return by, bz, area


# -----------------------------------------------------------------------------
# Elements
# -----------------------------------------------------------------------------

class R4(_Element):
    _triangles = [(0, 1, 2), (0, 2, 3)]

    # 2x2 Gauss, weights normalized so sum(weights)=1 and fiber weights = area*weight
    _quadrature = [
        ((-1.0/np.sqrt(3.0), -1.0/np.sqrt(3.0)), 0.25),
        (( 1.0/np.sqrt(3.0), -1.0/np.sqrt(3.0)), 0.25),
        (( 1.0/np.sqrt(3.0),  1.0/np.sqrt(3.0)), 0.25),
        ((-1.0/np.sqrt(3.0),  1.0/np.sqrt(3.0)), 0.25),
    ]

    @property
    def area(self):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        e1 = p1 - p0
        e2 = p3 - p0
        return float(abs(e1[0]*e2[1] - e1[1]*e2[0]))

    @property
    def fibers(self):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        A = self.area
        for (xi, eta), w in self._quadrature:
            r = _rect_map(p0, p1, p3, xi, eta)
            yield r, A*w

    def interp(self, field, r):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        xi, eta = _rect_xieta(p0, p1, p3, r)
        N = _N_R4(xi, eta)
        return float(N @ field[self.nodes])

    def gradient(self, field, r):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        xi, eta = _rect_xieta(p0, p1, p3, r)

        # geometry coefficients (rows of J^{-T})
        xyz = self.model.nodes[self.nodes[:4]].T
        by, bz, _ = _rect_tangent_from_xyz(xyz)

        dNxi  = _dN_dxi_R4(xi, eta)
        dNeta = _dN_deta_R4(xi, eta)

        dNy = by[0]*dNxi + by[1]*dNeta
        dNz = bz[0]*dNxi + bz[1]*dNeta

        u = field[self.nodes]
        return np.array([dNy @ u, dNz @ u], dtype=float)

    def inertia(self, u, v, *, weight='e'):
        w = self.model._measures[self.group][weight] * self.area
        return u.dot(M0_R4 @ v) * w

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, fy, fz):
        detJ = 0.25 * area
        Py = detJ * (by[0]*SXI_R4 + by[1]*SETA_R4)
        Pz = detJ * (bz[0]*SXI_R4 + bz[1]*SETA_R4)
        return Py @ fy + Pz @ fz

    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, area, f):
        return area * (M0_R4 @ f)

    @staticmethod
    @jit(cache=True, fastmath=True)
    def state(xyz):
        by, bz, area = _rect_tangent_from_xyz(xyz)

        # mass
        me = area * M0_R4

        # stiffness
        detJ = 0.25 * area
        c_xi  = by[0]*by[0] + bz[0]*bz[0]
        c_eta = by[1]*by[1] + bz[1]*bz[1]
        c_mix = by[0]*by[1] + bz[0]*bz[1]

        ke = detJ * (
            c_xi  * KXI_R4
            + c_eta * KETA_R4
            + c_mix * (KXIETA_R4 + KXIETA_R4.T)
        )

        return me, ke, by, bz, area


class R9(_Element):
    _triangles = [
        (0, 4, 8), (4, 1, 8),
        (1, 5, 8), (5, 2, 8),
        (2, 6, 8), (6, 3, 8),
        (3, 7, 8), (7, 0, 8),
    ]

    # 3x3 Gauss, weights normalized so sum(weights)=1 and fiber weights = area*weight
    _quadrature = [
        ((xi, eta), (wx*wy)/4.0)
        for xi, wx in zip(_G3_PTS, _G3_WTS)
        for eta, wy in zip(_G3_PTS, _G3_WTS)
    ]

    @property
    def area(self):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        e1 = p1 - p0
        e2 = p3 - p0
        return float(abs(e1[0]*e2[1] - e1[1]*e2[0]))

    @property
    def fibers(self):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        A = self.area
        for (xi, eta), w in self._quadrature:
            r = _rect_map(p0, p1, p3, xi, eta)
            yield r, A*w

    def interp(self, field, r):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        xi, eta = _rect_xieta(p0, p1, p3, r)
        N = _N_R9(xi, eta)
        return float(N @ field[self.nodes])

    def gradient(self, field, r):
        P = self.model.nodes[self.nodes[:4]]
        p0, p1, p3 = P[0], P[1], P[3]
        xi, eta = _rect_xieta(p0, p1, p3, r)

        xyz = self.model.nodes[self.nodes[:4]].T
        by, bz, _ = _rect_tangent_from_xyz(xyz)

        dNxi  = _dN_dxi_R9(xi, eta)
        dNeta = _dN_deta_R9(xi, eta)

        dNy = by[0]*dNxi + by[1]*dNeta
        dNz = bz[0]*dNxi + bz[1]*dNeta

        u = field[self.nodes]
        return np.array([dNy @ u, dNz @ u], dtype=float)

    def inertia(self, u, v, *, weight='e'):
        w = self.model._measures[self.group][weight] * self.area
        return u.dot(M0_R9 @ v) * w

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, fy, fz):
        detJ = 0.25 * area
        Py = detJ * (by[0]*SXI_R9 + by[1]*SETA_R9)
        Pz = detJ * (bz[0]*SXI_R9 + bz[1]*SETA_R9)
        return Py @ fy + Pz @ fz

    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, area, f):
        return area * (M0_R9 @ f)

    @staticmethod
    @jit(cache=True, fastmath=True)
    def state(xyz):
        by, bz, area = _rect_tangent_from_xyz(xyz)

        me = area * M0_R9

        detJ = 0.25 * area
        c_xi  = by[0]*by[0] + bz[0]*bz[0]
        c_eta = by[1]*by[1] + bz[1]*bz[1]
        c_mix = by[0]*by[1] + bz[0]*bz[1]

        ke = detJ * (
            c_xi  * KXI_R9
            + c_eta * KETA_R9
            + c_mix * (KXIETA_R9 + KXIETA_R9.T)
        )

        return me, ke, by, bz, area