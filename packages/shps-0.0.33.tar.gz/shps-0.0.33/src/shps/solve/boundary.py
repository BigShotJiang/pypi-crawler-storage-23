
#
#
#
import numpy as np
from math import comb

from collections import defaultdict


def _cell_edges(elem):
    if len(elem) == 3:
        # T3 element
        return [(elem[0], elem[1]), (elem[1], elem[2]), (elem[2], elem[0])]
    elif len(elem) == 6:
        # T6 element
        return [(elem[0], elem[3], elem[1]),
                (elem[1], elem[4], elem[2]),
                (elem[2], elem[5], elem[0])]
    else:
        raise ValueError("Unsupported element type for boundary edges.")


def find_boundaries(conn):
    """
    Yield ordered boundary loops (outer and holes) as lists of node indices.

    Parameters
    ----------
    conn : iterable of iterables
        Element connectivity; each entry is a sequence of node indices (e.g. len=3 for T3, 4 for Q4).

    Yields
    ------
    loop : list[int]
        Ordered node indices around one boundary loop (start not repeated at end).
    """
    # 1) Count undirected edge occurrences
    edge_count = {}
    for elem in conn:

        # e = _perimeter_cycle(elem) #list(elem)
        # if len(e) < 2: 
        #     continue
        # for a, b in zip(e, e[1:] + e[:1]):
        # for a, *_, b in _cell_edges(elem):
        #     if a == b: 
        #         continue
        #     k = (a, b) if a < b else (b, a)
        #     edge_count[k] = edge_count.get(k, 0) + 1
        for edge in _cell_edges(elem):
            k = tuple(sorted(edge))
            edge_count[k] = edge_count.get(k, 0) + 1


    # 2) Build adjacency graph using only edges that occur once (boundary edges)
    adj = defaultdict(list)
    for elem in conn:
        for edge in _cell_edges(elem):
            k = tuple(sorted(edge))
            if edge_count.get(k, 0) == 1:
                for i in range(len(edge)-1):
                    a, b = edge[i], edge[i+1]
                    adj[a].append(b)
                    adj[b].append(a)

    # 3) Walk boundary loops; mark undirected edges visited
    visited = set()  # stores undirected edge keys (min, max)

    for u in list(adj.keys()):
        for v in adj[u]:
            k0 = (u, v) if u < v else (v, u)
            if k0 in visited:
                continue

            loop = [u]
            curr, nxt = u, v

            while True:
                visited.add((curr, nxt) if curr < nxt else (nxt, curr))
                loop.append(nxt)

                # choose the next neighbor from 'nxt' that isn't the edge we just came from
                nxt_neighbors = adj[nxt]
                w = None
                for cand in nxt_neighbors:
                    if cand == curr:
                        continue
                    k = (nxt, cand) if nxt < cand else (cand, nxt)
                    if k not in visited:
                        w = cand
                        break

                if w is None:
                    # either we've closed the loop or hit an open chain end
                    if loop[0] == loop[-1]:
                        loop.pop()  # remove duplicated start if present
                    yield loop
                    break

                curr, nxt = nxt, w


# ----- c * y^ey * z^ez -----
class Monomial2D:
    __slots__=("ey","ez","c")
    def __init__(self, ey, ez, c):
        self.ey=int(ey)
        self.ez=int(ez)
        self.c=float(c)
    def edge_coeffs(self, yi,zi,yj,zj):
        dy, dz = (yj-yi), (zj-zi)
        deg = self.ey + self.ez
        a = np.zeros(deg+1, float)
        # (yi+dy s)^ey (zi+dz s)^ez = sum_p sum_q binom * yi^(ey-p) dy^p * zi^(ez-q) dz^q * s^(p+q)
        for p in range(self.ey+1):
            by = comb(self.ey,p) * (yi**(self.ey-p)) * (dy**p)
            for q in range(self.ez+1):
                bz = comb(self.ez,q) * (zi**(self.ez-q)) * (dz**q)
                a[p+q] += self.c * by * bz
        return a

class ScalarPoly:
    def __init__(self, terms=None):
        self.terms=[t for t in (terms or []) if t is not None and t.c!=0.0]
    def edge_coeffs(self, yi,zi,yj,zj):
        acc = np.zeros(1, float)
        for t in self.terms:
            a = t.edge_coeffs(yi,zi,yj,zj)
            if a.size>acc.size: acc = np.pad(acc,(0,a.size-acc.size))
            if a.size<acc.size: a = np.pad(a,(0,acc.size-a.size))
            acc += a
        return acc

class VectorPoly:
    def __init__(self, gy_terms=None, gz_terms=None):
        self.qy = ScalarPoly(gy_terms or [])
        self.qz = ScalarPoly(gz_terms or [])
    def edge_projection_coeffs(self, yi,zi,yj,zj, ny,nz):
        ay = self.qy.edge_coeffs(yi,zi,yj,zj)
        az = self.qz.edge_coeffs(yi,zi,yj,zj)
        m = max(len(ay), len(az))
        if len(ay)<m: ay = np.pad(ay,(0,m-len(ay)))
        if len(az)<m: az = np.pad(az,(0,m-len(az)))
        return ny*ay + nz*az


def _loop_orientation_sign(coords, idx):
    # +1 for CCW, -1 for CW, using (y,z) as (x,y)
    ys = coords[idx,0]; zs = coords[idx,1]
    ys = np.r_[ys, ys[0]]; zs = np.r_[zs, zs[0]]
    area2 = np.sum(ys[:-1]*zs[1:] - ys[1:]*zs[:-1])
    return 1.0 if area2>0 else -1.0


class BoundaryTerm:
    """Return coefficients a[0..d] for g(s) = sum_k a[k] s^k along an edge."""
    def poly_coeffs_along_edge(self, yi, zi, yj, zj):
        raise NotImplementedError

# General monomial: c * y^ey * z^ez
class MonomialBoundary(BoundaryTerm):
    def __init__(self, ey, ez, c):
        self.ey = int(ey); self.ez = int(ez); self.c = float(c)

    def poly_coeffs_along_edge(self, yi, zi, yj, zj):
        dy, dz = (yj - yi), (zj - zi)
        deg = self.ey + self.ez
        a = np.zeros(deg + 1, dtype=float)
        # (yi + dy s)^ey (zi + dz s)^ez = sum_{p=0..ey} sum_{q=0..ez} binom * ... * s^{p+q}
        for p in range(self.ey + 1):
            by = comb(self.ey, p) * (yi ** (self.ey - p)) * (dy ** p)
            for q in range(self.ez + 1):
                bz = comb(self.ez, q) * (zi ** (self.ez - q)) * (dz ** q)
                a[p + q] += self.c * by * bz
        return a


def _edge_nodal_from_coeffs(a, L):
    """
    Given coefficients a[k] for g(s)=sum a[k] s^k on s in [0,1], return (Fi,Fj)
    with N_i=1-s, N_j=s and ds_edge = L ds.
    """
    k = np.arange(len(a), dtype=float)
    Fi = L * np.sum(a * (1.0/(k+1.0) - 1.0/(k+2.0)))
    Fj = L * np.sum(a * (1.0/(k+2.0)))
    return Fi, Fj

# def _edge_nodal_from_coeffs_T6(a, L):
#     """
#     Given coefficients a[k] for g(s)=sum a[k] s^k on s in [0,1],
#     return consistent nodal loads (Fi, Fm, Fj) for quadratic edge
#     nodes at s = 0, 1/2, 1, with ds_edge = L ds.
#     """
#     r = np.arange(len(a), dtype=float)
#     I0 = 1.0/(r+1.0)  # ∫ s^r
#     I1 = 1.0/(r+2.0)  # ∫ s^(r+1)
#     I2 = 1.0/(r+3.0)  # ∫ s^(r+2)

#     # ∫ N0 s^r = I0 - 3 I1 + 2 I2
#     Fi = L * np.sum(a * (I0 - 3.0*I1 + 2.0*I2))
#     # ∫ Nm s^r = 4 I1 - 4 I2
#     Fm = L * np.sum(a * (4.0*I1 - 4.0*I2))
#     # ∫ N1 s^r = - I1 + 2 I2
#     Fj = L * np.sum(a * (-I1 + 2.0*I2))
#     return Fi, Fm, Fj

def _edge_nodal_from_coeffs_T6(a, L):
    """
    g(s)=sum_k a[k] s^k, s in [0,1], ds_edge = L ds
    Quadratic edge nodes at s=0, 1/2, 1 with:
      N0 = 2s^2 - 3s + 1
      Nm = 4s - 4s^2
      N1 = 2s^2 - s
    Returns (F0, Fm, F1).
    """
    r = np.arange(len(a), dtype=float)
    I0 = 1.0/(r + 1.0)  # ∫ s^r
    I1 = 1.0/(r + 2.0)  # ∫ s^(r+1)
    I2 = 1.0/(r + 3.0)  # ∫ s^(r+2)

    F0 = L * np.sum(a * (I0 - 3.0*I1 + 2.0*I2))
    Fm = L * np.sum(a * (4.0*I1 - 4.0*I2))
    F1 = L * np.sum(a * (-I1 + 2.0*I2))
    return F0, Fm, F1


def integrate_boundary(node_coords,
                       boun_indices, 
                       gy_terms, 
                       gz_terms,
                       edge_order=1,
                       normal_sign_override=None):
    """
    Exact, consistent Neumann load assembly for one boundary loop (outer or hole).

    Parameters
    ----------
      node_coords: (N,2) [y,z]
      boun_indices: ordered node indices around the loop
      gy_terms, gz_terms: lists of Monomial2D terms for q=(qy,qz)
      normal_sign_override: None or +/-1 to flip outward if the orientation differs
    """

    coords = np.asarray(node_coords, float)
    F = np.zeros(len(coords), float)

    if len(boun_indices)<2:
        return F

    orient = _loop_orientation_sign(coords, np.array(boun_indices, int))
    if normal_sign_override is not None:
        orient *= float(normal_sign_override)

    pairs = [(boun_indices[k], boun_indices[k+1]) for k in range(len(boun_indices)-1)]

    if boun_indices[0] != boun_indices[-1] and len(boun_indices)>=3:
        pairs.append((boun_indices[-1], boun_indices[0]))

    q = VectorPoly(gy_terms, gz_terms)

    if edge_order == 1:
        for i,j in pairs:
            yi,zi = coords[i]
            yj,zj = coords[j]
            dy, dz = (yj-yi), (zj-zi)
            L = float(np.hypot(dy,dz))
            if L==0.0:
                continue

            # outward unit normal (right normal for CCW)
            ny, nz = np.array([dz/L, -dy/L])

            # polynomial coefficients for g(s)=q·n
            a = q.edge_projection_coeffs(yi,zi,yj,zj, ny,nz)

            Fi, Fj = _edge_nodal_from_coeffs(a, L)
            F[i] += Fi
            F[j] += Fj
        return F

    # ---------------------------
    # T6 path: quadratic edges
    # ---------------------------
    idx = list(boun_indices)

    # remove duplicate closing node if present
    if len(idx) >= 2 and idx[0] == idx[-1]:
        idx = idx[:-1]

    n = len(idx)
    if n < 3:
        return F

    if n % 2 != 0:
        # Not an alternating v,m,v,m,... loop; safest fallback:
        # (you can also raise, but fallback avoids breaking anything)
        return integrate_boundary(node_coords, boun_indices, gy_terms, gz_terms,
                                    normal_sign_override=normal_sign_override,
                                    edge_order=1)

    # Choose rotation so triples look like (vertex, mid, vertex).
    # We use midpoint test ONLY in T6 mode, so T3 cannot be affected.
    def midpoint_error(start):
        err = 0.0
        for k in range(start, start + n, 2):
            i = idx[k % n]
            m = idx[(k + 1) % n]
            j = idx[(k + 2) % n]
            mid = 0.5 * (coords[i] + coords[j])
            err += np.linalg.norm(coords[m] - mid)
        return err

    if midpoint_error(1) < midpoint_error(0):
        idx = idx[1:] + idx[:1]  # rotate by 1

    # Build physical edges (i, m, j), stepping by 2
    edges = [(idx[k], idx[k+1], idx[(k+2) % n]) for k in range(0, n, 2)]


    for e in edges:
        if len(e) == 2:
            # linear fallback segment (only possible for open chains)
            i, j = e
            yi, zi = coords[i]
            yj, zj = coords[j]
            dy, dz = (yj - yi), (zj - zi)
            L = float(np.hypot(dy, dz))
            if L == 0.0:
                continue
            ny, nz = np.array([dz/L, -dy/L])
            a = q.edge_projection_coeffs(yi, zi, yj, zj, ny, nz)
            Fi, Fj = _edge_nodal_from_coeffs(a, L)
            F[i] += Fi
            F[j] += Fj
            continue

        i, m, j = e

        # Optional: verify affine T6 midpoint assumption (comment out for speed)
        # mid = 0.5 * (coords[i] + coords[j])
        # if np.linalg.norm(coords[m] - mid) > (midpoint_atol + midpoint_rtol*np.linalg.norm(coords[j] - coords[i])):
        #     # Not straight-edged/affine midpoint placement; quadratic closed-form is not valid.
        #     # Safest fallback: integrate as two linear segments (still won’t break T3).
        #     yi, zi = coords[i]; ym, zm = coords[m]; yj, zj = coords[j]

        #     # (i -> m)
        #     dy, dz = (ym - yi), (zm - zi)
        #     L1 = float(np.hypot(dy, dz))
        #     if L1 > 0:
        #         ny, nz = np.array([dz/L1, -dy/L1])
        #         a = q.edge_projection_coeffs(yi, zi, ym, zm, ny, nz)
        #         Fi, Fm1 = _edge_nodal_from_coeffs(a, L1)
        #         F[i] += Fi; F[m] += Fm1

        #     # (m -> j)
        #     dy, dz = (yj - ym), (zj - zm)
        #     L2 = float(np.hypot(dy, dz))
        #     if L2 > 0:
        #         ny, nz = np.array([dz/L2, -dy/L2])
        #         a = q.edge_projection_coeffs(ym, zm, yj, zj, ny, nz)
        #         Fm2, Fj = _edge_nodal_from_coeffs(a, L2)
        #         F[m] += Fm2; F[j] += Fj

        #     continue

        # Physical edge endpoints define straight geometry + normal
        yi, zi = coords[i]
        yj, zj = coords[j]
        dy, dz = (yj - yi), (zj - zi)
        L = float(np.hypot(dy, dz))
        if L == 0.0:
            continue

        ny, nz = np.array([dz/L, -dy/L])

        a = q.edge_projection_coeffs(yi, zi, yj, zj, ny, nz)

        Fi, Fm, Fj = _edge_nodal_from_coeffs_T6(a, L)
        F[i] += Fi
        F[m] += Fm
        F[j] += Fj

    return F