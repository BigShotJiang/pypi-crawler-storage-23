"""
Drop-in replacement for poisson_neumann with vectorized assembly.

Key speedups vs. the original:
  1. No multiprocessing — eliminates pickle/IPC overhead that dominates
     for cheap per-element work (T3/T6 stiffness is ~μs each).
  2. Vectorized element stiffness/mass — one NumPy call per element *type*
     instead of one Python call per element.
  3. Vectorized COO construction — np.repeat/np.tile on connectivity
     instead of Python append loops.
  4. Vectorized load assembly for the common HilbertLoad / PoissonLoad
     cases; falls back to per-element calls for custom loads only.

API is unchanged: poisson_neumann(...) has the same signature and returns
the same result.
"""

import numpy as np
import scipy.sparse as sp
from time import perf_counter
from functools import partial

try:
    from pypardiso import spsolve as _spsolve
    _PARDISO = True
except ModuleNotFoundError:
    from scipy.sparse.linalg import spsolve as _spsolve
    _PARDISO = False

from .element import T3, T6, M0_T3, M0_T6, IJ0_T6, IK0_T6

# ---------------------------------------------------------------------------
# Vectorised element-level computation
# ---------------------------------------------------------------------------

def _batch_T3(nodes, conn, weights):
    """
    Vectorized T3 stiffness, mass, and geometry for all T3 elements at once.

    Parameters
    ----------
    nodes   : (n_node, 2) float array
    conn    : (n_elem, 3) int   array of node indices
    weights : (n_elem,)   float array of material / measure multipliers

    Returns
    -------
    ke_all  : (n_elem, 3, 3)
    me_all  : (n_elem, 3, 3)  — not currently needed by the solver, but cheap
    by_all  : (n_elem, 3)
    bz_all  : (n_elem, 3)
    areas   : (n_elem,)
    """
    ne = conn.shape[0]
    xyz = nodes[conn]          # (ne, 3, 2)
    y = xyz[:, :, 0]           # (ne, 3)
    z = xyz[:, :, 1]

    y1, y2, y3 = y[:, 0], y[:, 1], y[:, 2]
    z1, z2, z3 = z[:, 0], z[:, 1], z[:, 2]

    z23 = z2 - z3;  z31 = z3 - z1;  z12 = z1 - z2
    y32 = y3 - y2;  y13 = y1 - y3;  y21 = y2 - y1

    areas = np.abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

    by = np.column_stack([z23, z31, z12])   # (ne, 3)
    bz = np.column_stack([y32, y13, y21])

    # Element stiffness: ke = (1/4A) * [[k11 k12 k13],[...],...]
    k11 = y32**2 + z23**2
    k12 = y13*y32 + z23*z31
    k13 = y21*y32 + z12*z23
    k22 = y13**2 + z31**2
    k23 = y13*y21 + z12*z31
    k33 = y21**2 + z12**2

    inv4A = weights / (4.0 * areas)          # includes material weight

    ke = np.empty((ne, 3, 3))
    ke[:, 0, 0] = k11 * inv4A
    ke[:, 0, 1] = k12 * inv4A
    ke[:, 0, 2] = k13 * inv4A
    ke[:, 1, 0] = k12 * inv4A
    ke[:, 1, 1] = k22 * inv4A
    ke[:, 1, 2] = k23 * inv4A
    ke[:, 2, 0] = k13 * inv4A
    ke[:, 2, 1] = k23 * inv4A
    ke[:, 2, 2] = k33 * inv4A

    return ke, by, bz, areas


def _batch_T6(nodes, conn, weights):
    """
    Vectorized T6 stiffness and geometry for all T6 elements at once.
    Uses only the 3 corner nodes for geometry (same as the scalar version).
    """
    ne = conn.shape[0]
    xyz = nodes[conn[:, :3]]   # (ne, 3, 2) — corners only
    y = xyz[:, :, 0]
    z = xyz[:, :, 1]

    y1, y2, y3 = y[:, 0], y[:, 1], y[:, 2]
    z1, z2, z3 = z[:, 0], z[:, 1], z[:, 2]

    z23 = z2 - z3;  z31 = z3 - z1;  z12 = z1 - z2
    y32 = y3 - y2;  y13 = y1 - y3;  y21 = y2 - y1

    areas = np.abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

    by = np.column_stack([z23, z31, z12])
    bz = np.column_stack([y32, y13, y21])

    # W[e] = outer(bz[e], bz[e]) + outer(by[e], by[e])   — shape (ne,3,3)
    W = (bz[:, :, None] * bz[:, None, :]
       + by[:, :, None] * by[:, None, :])      # (ne, 3, 3)

    # ke[e] = (1/(4A)) * tensordot(W[e], IK0_T6, axes=([0,1],[2,3]))
    # IK0_T6 is (6,6,3,3); reshape to (36,9) so a single matmul works:
    IK_flat = IK0_T6.reshape(36, 9)            # (36, 9)  — precomputable
    W_flat  = W.reshape(ne, 9)                  # (ne, 9)
    ke_flat = W_flat @ IK_flat.T                # (ne, 36)

    coeff = (weights / (4.0 * areas))[:, None]
    ke = (ke_flat * coeff).reshape(ne, 6, 6)

    return ke, by, bz, areas


def _build_coo(conn, ke_all, ndof):
    """
    Build COO sparse matrix from batched element matrices.

    conn   : (ne, nne) int
    ke_all : (ne, nne, nne) float
    """
    nne = conn.shape[1]
    # rows[e, a, b] = conn[e, a],  cols[e, a, b] = conn[e, b]
    rows = np.repeat(conn, nne, axis=1).ravel()
    cols = np.tile(conn, (1, nne)).ravel()
    data = ke_all.ravel()
    return sp.coo_matrix((data, (rows, cols)), shape=(ndof, ndof))


def _assemble_force_vector(conn, fe_all, Fa):
    """
    Vectorized scatter-add of element force vectors into global vector.

    conn   : (ne, nne) int
    fe_all : (ne, nne) float
    """
    np.add.at(Fa, conn.ravel(), fe_all.ravel())


# ---------------------------------------------------------------------------
# Vectorised load helpers
# ---------------------------------------------------------------------------

def _is_hilbert_load(load):
    """Check if a load was created by HilbertLoad()."""
    return (isinstance(load, partial)
            and load.func.__name__ == '_hilbert_kernel')


def _is_poisson_load(load):
    return (isinstance(load, partial)
            and load.func.__name__ == '_poisson_source')


def _batch_hilbert_T3(conn, areas, weights_area, load):
    """Vectorized HilbertLoad for T3 elements."""
    f = load.keywords['f']
    measure = load.keywords.get('measure')
    # dA per element — for now use areas * cell_weights
    # (cell_weight handled via weights_area passed in)
    f_elem = f[conn]                           # (ne, 3)
    # M0_T3 @ f  for each element: (ne,3) via broadcast
    Mf = f_elem @ M0_T3.T                      # (ne, 3) since M0 is symmetric
    fe = Mf * weights_area[:, None]
    return fe


def _batch_hilbert_T6(conn, areas, weights_area, load):
    f = load.keywords['f']
    f_elem = f[conn]
    Mf = f_elem @ M0_T6.T
    fe = Mf * weights_area[:, None]
    return fe


def _batch_poisson_T3(conn, by, bz, areas, weights, load):
    """Vectorized PoissonLoad for T3 elements."""
    fy = load.keywords['fy']
    fz = load.keywords['fz']
    # Scalar version: Py = (1/6) outer(by, [1,1,1]);  fe = Py@fy + Pz@fz
    # Vectorized: for each element e,
    #   fe[e, i] = (1/6) * (by[e,i] * sum(fy[conn[e]]) + bz[e,i] * sum(fz[conn[e]]))
    fy_sum = fy[conn].sum(axis=1)              # (ne,)
    fz_sum = fz[conn].sum(axis=1)
    w = weights[:, None]
    fe = (1.0 / 6.0) * (by * fy_sum[:, None] + bz * fz_sum[:, None]) * w
    return fe


def _batch_poisson_T6(conn, by, bz, areas, weights, load):
    """Vectorized PoissonLoad for T6 elements."""
    fy = load.keywords['fy']
    fz = load.keywords['fz']
    ne = conn.shape[0]

    fy_elem = fy[conn]   # (ne, 6)
    fz_elem = fz[conn]   # (ne, 6)

    # Py[e] = 0.5 * sum_k by[e,k] * IJ0[:,:,k]   — shape (6,6) per element
    # fe_y[e] = Py[e] @ fy_elem[e]
    # Vectorized: IJ0_T6 is (6,6,3). 
    # Py_all[e] = 0.5 * einsum('k, ijk -> ij', by[e], IJ0_T6)
    #           = 0.5 * (IJ0_T6 @ by[e])  with IJ0 reshaped to (36,3)
    IJ_flat = IJ0_T6.reshape(36, 3)           # (36, 3)
    Py_flat = 0.5 * (by @ IJ_flat.T)          # (ne, 36)  — each row is Py[e].ravel()
    Pz_flat = 0.5 * (bz @ IJ_flat.T)

    # For each element: fe[e] = Py[e] @ fy_elem[e] + Pz[e] @ fz_elem[e]
    # Py[e] is (6,6), fy_elem[e] is (6,)
    # Py_flat[e] is (36,) = Py[e].ravel() in row-major
    Py_mat = Py_flat.reshape(ne, 6, 6)
    Pz_mat = Pz_flat.reshape(ne, 6, 6)

    fe = (np.einsum('eij,ej->ei', Py_mat, fy_elem)
        + np.einsum('eij,ej->ei', Pz_mat, fz_elem))
    fe *= weights[:, None]
    return fe


# ---------------------------------------------------------------------------
# Main solver (same API as original)
# ---------------------------------------------------------------------------

def poisson_neumann(
        nodes=None,
        elements=None,
        model=None,
        materials=None,
        force=None,
        loads=None,
        measure=None,
        threads=6,          # kept for API compat; ignored
        chunk=200,           # kept for API compat; ignored
        fix_node=None,
        fix_value=1.0,
        verbose=False
):
    # resolve model shorthand
    if model is not None:
        assert nodes is None and elements is None
        nodes = model.nodes
        elements = model.elems

    if measure is not None:
        assert model is not None
        assert materials is None
        materials = {
            cell.group: model.cell_weight(cell, measure)
            for cell in elements
        }

    if loads is None:
        loads = []

    ndf        = 1
    ndof_total = ndf * len(nodes)
    Fa         = np.zeros(ndof_total)
    if force is not None:
        Fa += force

    tic = perf_counter()

    # bucket elements by shape
    buckets = {}   # shape_str -> list of elements
    for cell in elements:
        buckets.setdefault(cell.shape, []).append(cell)

    coo_parts = []  # list of COO matrices to sum at the end

    for shape, cells in buckets.items():
        nne = {"T3": 3, "T6": 6}[shape]
        ne  = len(cells)

        # Build connectivity array and per-element weight
        conn    = np.empty((ne, nne), dtype=np.intp)
        weights = np.ones(ne)
        groups  = []
        for e, cell in enumerate(cells):
            conn[e] = cell.nodes
            groups.append(cell.group)
            if cell.group is not None and materials is not None:
                weights[e] = materials[cell.group]

        # Vectorised element computation
        if shape == "T3":
            ke_all, by, bz, areas = _batch_T3(nodes, conn, weights)
        elif shape == "T6":
            ke_all, by, bz, areas = _batch_T6(nodes, conn, weights)
        else:
            raise ValueError(f"Unknown element shape: {shape}")

        # Global stiffness
        coo_parts.append(_build_coo(conn, ke_all, ndof_total))

        # Loads
        # Compute weights_area for Hilbert loads (area * cell_weight)
        weights_area = areas * weights

        for load in loads:
            # Try vectorized path for known load types
            if _is_hilbert_load(load):
                if shape == "T3":
                    fe = _batch_hilbert_T3(conn, areas, weights_area, load)
                else:
                    fe = _batch_hilbert_T6(conn, areas, weights_area, load)
                _assemble_force_vector(conn, fe, Fa)

            elif _is_poisson_load(load):
                if shape == "T3":
                    fe = _batch_poisson_T3(conn, by, bz, areas, weights, load)
                else:
                    fe = _batch_poisson_T6(conn, by, bz, areas, weights, load)
                _assemble_force_vector(conn, fe, Fa)

            else:
                # Fallback: per-element call (for custom / Burgers loads)
                for e, cell in enumerate(cells):
                    fe = load(cell, by[e], bz[e], areas[e])
                    np.add.at(Fa, cell.nodes, fe)

    if verbose:
        print(f"Assembly   : {perf_counter() - tic:6.3f} s")

    # ---- Merge COO parts into CSR -----------------------------------------
    K = sum(coo_parts).tocsr()

    # ---- Dirichlet fix -----------------------------------------------------
    if fix_node is None:
        fix_node = 0

    tic = perf_counter()
    fixed = np.array([fix_node * ndf])
    free  = np.setdiff1d(np.arange(ndof_total), fixed)

    Pf = Fa[free] - K[free][:, fixed].toarray().ravel() * fix_value
    if verbose:
        print(f"Compatibility: {abs(Fa.sum())/(100*Fa.max()):.6e} (should be 0.0)")

    Kf = K[free][:, free]

    # ---- Solve -------------------------------------------------------------
    Uf = _spsolve(Kf, Pf)

    if verbose:
        print(f"Solve      : {perf_counter() - tic:6.3f} s "
              f"({'PARDISO' if _PARDISO else 'SuperLU'})")

    u = np.empty(ndof_total)
    u[free]  = Uf
    u[fixed] = fix_value
    return u