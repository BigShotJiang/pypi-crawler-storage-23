# Chain
from thirdmagic.consts import MAGEFLOW_TASK_INITIALS

ON_CHAIN_ERROR = f"{MAGEFLOW_TASK_INITIALS}on_chain_error"
ON_CHAIN_END = f"{MAGEFLOW_TASK_INITIALS}on_chain_done"


# Swarm
ON_SWARM_ITEM_ERROR = f"{MAGEFLOW_TASK_INITIALS}on_swarm_item_error"
ON_SWARM_ITEM_DONE = f"{MAGEFLOW_TASK_INITIALS}on_swarm_item_done"
SWARM_FILL_TASK = f"{MAGEFLOW_TASK_INITIALS}swarm_fill_tasks"
