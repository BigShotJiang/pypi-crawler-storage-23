from .model import TotoModel

__all__ = ["TotoModel"]
