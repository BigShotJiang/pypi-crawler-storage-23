CONSOLE_WIDTH: int = 200
MAX_LEN_MIGRATION_ID: int = 125
MIGRATION_FOLDER: str = "migrations"
MIGRATION_STATE_FILE: str = ".migrations-state.json"
