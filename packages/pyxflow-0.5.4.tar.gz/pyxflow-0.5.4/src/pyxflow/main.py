"""FlowApp -- single entry point to configure and run a PyXFlow application."""

import inspect
import json
import os
import sys


class FlowApp:
    """Configure and run a PyXFlow application.

    Usage::

        # demo/__main__.py
        from pyxflow import FlowApp

        FlowApp(port=8088).run()

    CLI flags:
        --dev     Auto-reload on source changes (requires watchfiles)
        --debug   Verbose UIDL protocol logging
    """

    def __init__(self, *, port: int = 8080, host: str = "localhost"):
        # Auto-detect caller's package -> views module
        frame = inspect.stack()[1]
        module_name = frame.frame.f_globals.get("__name__", "")
        if module_name == "__main__":
            # python -m <package> -> resolve from __spec__ or file path
            spec = frame.frame.f_globals.get("__spec__")
            if spec and spec.parent:
                package = spec.parent
            else:
                # Fallback: derive from file path (e.g. demo/__main__.py -> demo)
                from pathlib import Path
                caller_path = Path(frame.filename).resolve()
                package = caller_path.parent.name
        elif "." in module_name:
            package = module_name.rsplit(".", 1)[0]
        else:
            package = module_name
        self._views = f"{package}.views"
        self._port = port
        self._host = host

    def run(self):
        """Parse CLI flags and start the server."""
        args = set(sys.argv[1:])
        dev = "--dev" in args
        debug = "--debug" in args

        if dev:
            self._run_dev(debug)
        else:
            _serve(self._views, self._host, self._port, debug, dev=False)

    def _run_dev(self, debug: bool):
        """Dev mode: parent owns the socket, children are restarted on changes.

        The listening socket is created once in this parent process and
        inherited by each child via pass_fds.  When a child is killed for
        reload, the socket stays open -- no EADDRINUSE race.
        """
        import socket
        import subprocess
        import watchfiles
        from pathlib import Path

        watch_dir = Path(".").resolve()
        print(f"  Dev mode: watching {watch_dir} for Python file changes", flush=True)

        # Check if something is already listening on the port
        probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            probe.connect((self._host, self._port))
            probe.close()
            print(f"\n  ERROR: Port {self._port} is already in use.")
            print(f"  Kill the other process:  lsof -ti :{self._port} | xargs kill -9\n")
            return
        except ConnectionRefusedError:
            pass  # Nothing listening -- good
        finally:
            probe.close()

        # Create listening socket in the parent -- survives child restarts
        srv_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv_sock.bind((self._host, self._port))
        srv_sock.listen(128)
        srv_sock.set_inheritable(True)
        fd = srv_sock.fileno()
        print(f"  Listening on http://{self._host}:{self._port}", flush=True)

        env = os.environ.copy()
        env["_PYFLOW_APP"] = json.dumps({
            "views": self._views,
            "host": self._host,
            "port": self._port,
            "debug": debug,
            "socket_fd": fd,
        })

        def start_child():
            return subprocess.Popen(
                [sys.executable, "-c",
                 "from pyxflow.server.app_runner import _dev_serve; _dev_serve()"],
                pass_fds=(fd,),
                env=env,
            )

        def stop_child(proc):
            if proc.poll() is None:
                proc.kill()
                proc.wait(timeout=2)

        # Track mtimes to ignore metadata-only events (macOS FSEvents
        # fires for extended attribute changes like "last opened date")
        file_mtimes: dict[str, float] = {}

        proc = start_child()
        try:
            for changes in watchfiles.watch(
                ".",
                watch_filter=watchfiles.PythonFilter(),
                debounce=800,
            ):
                actually_changed = []
                for _, p in changes:
                    try:
                        mtime = os.path.getmtime(p)
                    except OSError:
                        mtime = 0
                    if file_mtimes.get(p) != mtime:
                        file_mtimes[p] = mtime
                        actually_changed.append(os.path.relpath(p, watch_dir))
                if not actually_changed:
                    continue
                paths = sorted(actually_changed)
                print(f"  Reloading because files modified: {', '.join(paths)}", flush=True)
                stop_child(proc)
                proc = start_child()
        except KeyboardInterrupt:
            pass
        finally:
            stop_child(proc)
            srv_sock.close()


def _auto_detect_app() -> str | None:
    """Try to find an app module in cwd by looking for <pkg>/views/ or ./views/."""
    from pathlib import Path
    # Check subdirectories first (e.g. myapp/views/)
    for entry in sorted(Path.cwd().iterdir()):
        if entry.is_dir() and (entry / "views").is_dir():
            return entry.name
    # Check cwd itself (e.g. views/ at root, from --setup without name)
    if (Path.cwd() / "views").is_dir():
        return Path.cwd().name.replace("-", "_")
    return None


def _usage() -> None:
    print("Usage: pyxflow [app_module] [--dev] [--debug] [--port PORT] [--host HOST]")
    print("       pyxflow [app_module] bundle [--copy|--build] [--vaadin-version VERSION]")
    print("       pyxflow --vscode")
    print("       pyxflow --setup [app_name]")
    print()
    print("  app_module  Python module with views (auto-detected if omitted)")
    print("  --dev       Auto-reload on source changes")
    print("  --debug     Verbose UIDL protocol logging")
    print("  --port N    Server port (default: 8080)")
    print("  --host H    Server host (default: localhost)")
    print("  bundle      Generate frontend bundle")
    print("  --copy      Copy bundle from Maven JARs in ~/.m2 (default, fast)")
    print("  --build     Full Maven build (slower, generates custom bundle)")
    print("  --keep      Keep bundle-project/ after build (only with --build)")
    print("  --optimized Use optimized bundle (code-split chunks, larger on disk)")
    print("  --vscode    Generate .vscode/ config and install recommended extensions")
    print("  --setup     Scaffold a new Vaadin PyXFlow project (views, static, __main__.py)")
    sys.exit(0)


from pyxflow.server.app_runner import _ensure_importable, _dev_serve, _serve  # noqa: F401


def main_deprecated():
    """Deprecated CLI entry point (``vaadin`` command)."""
    print("WARNING: 'vaadin' command is deprecated. Use 'pyxflow' instead.", file=sys.stderr)
    main()


def main():
    """CLI entry point: ``pyxflow [app_module] [--dev] [--debug]``."""
    if len(sys.argv) >= 2 and sys.argv[1] in ("-h", "--help"):
        _usage()

    # Parse all arguments: find module name (first non-flag) and flags.
    # "bundle" is a subcommand alias for "--bundle"
    _SUBCOMMANDS = {"bundle": "--bundle"}
    # Flags that consume the next token as their value:
    _VALUE_FLAGS = {"--vaadin-version", "--port", "--host"}
    args = sys.argv[1:]
    views = None
    rest: list[str] = []
    skip_next = False
    for arg in args:
        if skip_next:
            rest.append(arg)
            skip_next = False
        elif arg in _VALUE_FLAGS:
            rest.append(arg)
            skip_next = True
        elif arg in _SUBCOMMANDS:
            rest.append(_SUBCOMMANDS[arg])
        elif views is None and not arg.startswith("-"):
            views = arg
        else:
            rest.append(arg)

    if "--setup" in rest:
        from pyxflow.resources.setup_app import _setup_project, _setup_vscode
        _setup_project(views)
        _setup_vscode()
        sys.exit(0)

    if "--vscode" in rest:
        from pyxflow.resources.setup_app import _setup_vscode
        _setup_vscode()
        sys.exit(0)

    if "--bundle" in rest:
        from pathlib import Path
        from pyxflow.resources.generate_bundle import (
            generate_and_build, copy_from_jars, _DEFAULT_VAADIN_VERSION,
        )

        keep = "--keep" in rest
        use_build = "--build" in rest
        optimized = "--optimized" in rest
        vaadin_version = _DEFAULT_VAADIN_VERSION
        if "--vaadin-version" in rest:
            idx = rest.index("--vaadin-version")
            vaadin_version = rest[idx + 1]

        # Resolve app_dir from module name if given
        app_dir = None
        if views:
            # "demo" -> "demo/", "my_app" -> "my_app/"
            app_dir = Path.cwd() / views.replace(".", os.sep).replace("-", "_")

        cwd = os.getcwd()
        if cwd not in sys.path:
            sys.path.insert(0, cwd)

        if use_build:
            generate_and_build(app_dir=app_dir, keep=keep, vaadin_version=vaadin_version, optimized=optimized)
        else:
            # Default: copy from Maven JARs (fast, no build needed)
            is_pyxflow_dev = (Path.cwd() / "src" / "pyxflow").is_dir()
            if is_pyxflow_dev:
                bundle_dir = Path.cwd() / "src" / "pyxflow" / "bundle"
            elif app_dir:
                bundle_dir = app_dir / "bundle"
            else:
                print("ERROR: Cannot determine bundle output directory.")
                print("  Run from a pyxflow source tree (src/pyxflow/ exists)")
                print("  or specify an app module: pyxflow <app_module> bundle")
                sys.exit(1)

            print("===================================================")
            print("  Vaadin PyXFlow Bundle Generator (copy mode)")
            print("===================================================")
            print(f"  Vaadin version: {vaadin_version}")
            print(f"  Bundle output:  {bundle_dir}")
            print()

            copy_from_jars(bundle_dir, vaadin_version, optimized=optimized)

            print()
            print("===================================================")
            print("  Bundle copied successfully!")
            print("===================================================")
        sys.exit(0)

    if views is None or views == ".":
        views = _auto_detect_app()
        if views is None:
            print("  No views/ directory found in the current directory.")
            print()
            print("  To scaffold a new project:  vaadin --setup")
            print("  Or create views/ manually:  mkdir -p views && touch views/__init__.py")
            print()
            _usage()

    if "." not in views:
        views = f"{views}.views"

    _ensure_importable(views)

    port = 8080
    host = "localhost"
    if "--port" in rest:
        idx = rest.index("--port")
        port = int(rest[idx + 1])
        rest = rest[:idx] + rest[idx + 2:]
    if "--host" in rest:
        idx = rest.index("--host")
        host = rest[idx + 1]
        rest = rest[:idx] + rest[idx + 2:]

    debug = "--debug" in rest
    dev = "--dev" in rest

    if dev:
        # Reuse FlowApp dev mode
        app = FlowApp.__new__(FlowApp)
        app._views = views
        app._port = port
        app._host = host
        app._run_dev(debug)
    else:
        _serve(views, host, port, debug, dev=dev)
