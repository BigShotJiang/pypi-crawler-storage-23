
from src.utils.utils import launch, log

def init_config(config):
    launch()