import subprocess
import sys
from pathlib import Path


def main() -> int:
    binary = Path(__file__).resolve().parent / "bin" / "semverctl"
    if not binary.exists():
        print(f"Binary not found: {binary}", file=sys.stderr)
        return 1
    return subprocess.call([str(binary), *sys.argv[1:]])
