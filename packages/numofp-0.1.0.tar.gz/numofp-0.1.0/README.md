# numofp — Number of Prompts

Like `loc` counts lines of code, `numofp` counts how many AI prompts built your codebase.

## Install

```
pip install numofp
```

## Usage

```bash
numofp                    # current directory
numofp /path/to/project   # specific project
numofp --all              # all projects ranked by prompt count
numofp --deep             # show all chat sessions, not just top 10
numofp --json             # machine-readable output
```

## Example output

```
   numofp — Number of Prompts
  /Users/you/my-project

  ├───────────────────────────────────────────────────┤
  │ Tool             │   Prompts│  Sessions│ Details  │
  ├───────────────────────────────────────────────────┤
  │ Claude Code      │      2929│      1252│ history  │
  │ Codex CLI        │        88│        56│          │
  ├───────────────────────────────────────────────────┤
  │ TOTAL            │      3017│          │          │
  ├───────────────────────────────────────────────────┤

  Recent chats

    1. Codex CLI   Feb 10    11p  Hey, can you use exaMCP ?
    2. Claude Code Jan 22    14p  build the auth flow
    3. Claude Code Jan 21     8p  add dark mode
   ...
```

## Supported tools

| Tool | Data source |
|------|------------|
| **Claude Code** | `~/.claude/history.jsonl` + session files |
| **Codex CLI** | `~/.codex/sessions/` JSONL files |
| **Cursor** | `~/Library/.../Cursor/User/workspaceStorage/` SQLite |

Zero external dependencies — uses only Python stdlib.
