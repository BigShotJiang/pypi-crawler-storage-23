from poc.cli import main

main()
