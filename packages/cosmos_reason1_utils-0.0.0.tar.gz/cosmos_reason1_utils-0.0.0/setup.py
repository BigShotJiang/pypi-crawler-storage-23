"""
Empty setup.py for cosmos-reason1-utils
Target: HackerOne Bug Bounty - nvidia-cosmos
"""
from setuptools import setup

setup(
    name="cosmos-reason1-utils",
    version="0.0.0",
    description="Empty placeholder package - reserved for nvidia-cosmos",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
