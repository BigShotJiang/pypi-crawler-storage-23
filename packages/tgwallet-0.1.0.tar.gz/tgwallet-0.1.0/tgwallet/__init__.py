from tgwallet.client import WalletP2PClient

__all__ = ['WalletP2PClient']