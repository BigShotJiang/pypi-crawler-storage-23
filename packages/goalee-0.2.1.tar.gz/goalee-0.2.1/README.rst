# goalee
---

Library for building validation rules (Goals) for asynchronous distributed applications in the context of Internet of Things and Cyber-Physical Systems.


* Free software: MIT license
* Documentation: https://goalee.readthedocs.io.


## Install

Clone this repo and install like a normal python package.

```
pip install .
```


Features
--------

* TODO

