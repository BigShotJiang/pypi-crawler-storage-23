"""CI/CD deployment gate features for bicep-whatif-advisor."""
