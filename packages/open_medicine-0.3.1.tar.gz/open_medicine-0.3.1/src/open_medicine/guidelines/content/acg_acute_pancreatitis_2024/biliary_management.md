# Biliary Pancreatitis Management — ACG 2024

## ERCP Indications

### With Cholangitis — Urgent ERCP

The ACG **recommends** early ERCP **within the first 24 hours** in patients with AP complicated by **cholangitis** (Strong, Moderate).

- Early ERCP in this setting decreases morbidity and mortality.
- Cholangitis is defined by the Charcot triad (fever, jaundice, right upper quadrant pain) or the Reynolds pentad (adding altered mental status and hypotension).

### Without Cholangitis — Conservative Approach

The ACG **suggests** medical therapy over early ERCP (within the first 72 hours) in acute biliary pancreatitis **without cholangitis** (Conditional, Very Low).

- In the absence of cholangitis and/or jaundice, if a **common bile duct (CBD) stone** is suspected:
  - **MRCP or EUS** should be used to screen for CBD stones **before** ERCP.
  - Diagnostic ERCP should be avoided due to procedural risks.

### ERCP Decision Algorithm

```
Acute biliary pancreatitis confirmed
  → Cholangitis present (fever, jaundice, RUQ pain)?
      → YES → Urgent ERCP within 24 hours (Strong, Moderate)
      → NO → Is CBD stone suspected (dilated duct, elevated bilirubin)?
          → YES → MRCP or EUS to confirm CBD stone
              → Stone confirmed → ERCP
              → No stone → Medical management
          → NO → Medical management, no ERCP needed
```

## Post-ERCP Pancreatitis (PEP) Prevention

### Rectal Indomethacin

The ACG **recommends** rectal indomethacin (**100 mg**) before or immediately after ERCP to prevent PEP in all patients without a contraindication (Strong, Moderate).

### Pancreatic Duct Stent

The ACG **suggests** placement of a **pancreatic duct stent** in patients at high risk for PEP who are receiving rectal indomethacin (Conditional, Low).

> **Key Rule:** High-risk patients will likely benefit from **both** rectal indomethacin AND a pancreatic duct stent for PEP prevention.

### PEP Risk Factors

| Risk Factor | Category |
|---|---|
| Suspected sphincter of Oddi dysfunction | Patient-related |
| History of post-ERCP pancreatitis | Patient-related |
| Young age | Patient-related |
| Female sex | Patient-related |
| Non-dilated bile duct | Patient-related |
| Difficult cannulation | Procedure-related |
| Pancreatic duct injection | Procedure-related |
| Pancreatic sphincterotomy | Procedure-related |

## Cholecystectomy Timing

### Mild Biliary Pancreatitis — Same-Admission Cholecystectomy

The ACG **recommends** that patients with mild acute biliary pancreatitis undergo cholecystectomy **early, preferably before discharge** (Strong, Moderate).

- Same-admission cholecystectomy should be **standard of care** for appropriate patients.
- Delaying cholecystectomy after mild biliary AP is associated with increased risk of recurrent biliary events including recurrent pancreatitis and biliary sepsis.

### Necrotizing Biliary Pancreatitis

Cholecystectomy in patients with **pancreatic necrosis** complicating biliary pancreatitis should be **delayed** to a later course during the prolonged hospitalization or after recovery.

### Recurrent Idiopathic AP

Following a **second episode** of AP with no identifiable cause, in patients fit for surgery, the ACG **suggests** performing a cholecystectomy to reduce the risk of recurrent episodes (Conditional, Very Low).

## Cholecystectomy Decision Algorithm

```
Biliary pancreatitis confirmed
  → Mild AP?
      → YES → Cholecystectomy before discharge (same admission)
      → NO → Necrotizing pancreatitis?
          → YES → Delay cholecystectomy until recovery
          → NO (moderately severe) → Individualize timing based on
             clinical status and local complications

Idiopathic AP — second episode, no cause found
  → Patient fit for surgery? → Suggest cholecystectomy
```

## Limitations

- The optimal timing window for cholecystectomy in moderately severe biliary AP is not well defined.
- Routine diagnostic ERCP carries inherent risk of PEP; the decision to proceed should weigh the pre-test probability of CBD stones.
- PEP prevention data are strongest for high-risk patients; the magnitude of benefit for average-risk patients receiving universal rectal indomethacin is less clear.
