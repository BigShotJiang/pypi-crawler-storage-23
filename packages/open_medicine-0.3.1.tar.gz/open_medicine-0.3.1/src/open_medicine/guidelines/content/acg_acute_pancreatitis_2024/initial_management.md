# Initial Management of Acute Pancreatitis — ACG 2024

## Fluid Resuscitation

### Type of Fluid

The ACG **suggests** using **lactated Ringer's (LR) solution over normal saline** for IV resuscitation (Conditional, Low).

- LR is associated with improved electrolyte balance and reduced pancreatic injury.

### Rate of Fluid Administration

The ACG **suggests** moderately aggressive IV hydration with isotonic crystalloid, with caution if cardiovascular and/or renal comorbidities exist (Conditional, Low).

Based on the WATERFALL trial (de-Madaria et al., NEJM 2022), the guideline **no longer recommends early aggressive IV hydration** as it was associated with increased volume overload without clinical benefit.

| Strategy | Bolus | Maintenance Rate |
|---|---|---|
| **Moderate resuscitation (recommended)** | 10 mL/kg if hypovolemic; no bolus if normovolemic | 1.5 mL/kg/hr |
| **Aggressive resuscitation (no longer routine)** | 20 mL/kg | 3 mL/kg/hr |

### Monitoring and Reassessment

```
Patient admitted with acute pancreatitis
  → Begin lactated Ringer's at 1.5 mL/kg/hr
      → Hypovolemic? → Bolus 10 mL/kg LR
      → Normovolemic? → No bolus, continue maintenance
  → Reassess at 3 hours → Evaluate for fluid overload
  → Reassess at 12, 24, 48, 72 hours
      → Goals: Decreasing BUN, stable/decreasing hematocrit
      → Signs of fluid overload? → Reduce rate
      → Persistent hypovolemia? → Increase rate or re-bolus
```

> **Key Rule:** Fluid resuscitation is most important in the first 24 hours. After this window, the benefit of aggressive hydration diminishes significantly.

### Volume Overload Caution

Patients with cardiovascular and/or renal comorbidities require careful monitoring for volume overload throughout resuscitation. There is insufficient evidence that goal-directed therapy using specific parameters definitively reduces persistent organ failure, infected necrosis, or mortality.

## Pain Management

Pain management should follow a **multimodal, step-up approach** consistent with the WHO analgesic ladder:

| Step | Agents | Notes |
|---|---|---|
| **Step 1** | Acetaminophen, NSAIDs | First-line for mild pain |
| **Step 2** | Weak opioids (tramadol, codeine) | Add if Step 1 insufficient |
| **Step 3** | Strong opioids (hydromorphone, fentanyl) | Titrate for severe pain |

### Key Principles

- NSAIDs and opioids are **equally effective** in decreasing the need for rescue analgesia in mild AP.
- **Hydromorphone and fentanyl** are preferred opioids.
- **Meperidine should be avoided** due to neurotoxicity risk from normeperidine metabolite accumulation.
- Patient-controlled analgesia (PCA) has been associated with prolonged hospitalization in retrospective data — further RCTs are needed.

## Nutrition and Feeding

### Mild Acute Pancreatitis — Early Oral Feeding

The ACG **suggests** early oral feeding **(within 24–48 hours)** as tolerated (Conditional, Low).

- **Low-fat solid diet** is recommended as initial oral feeding, rather than a stepwise liquid-to-solid approach.
- This represents a major shift from the historical NPO approach.

### Severe Acute Pancreatitis — Enteral Nutrition

- **Enteral nutrition** should be initiated in patients with severe AP, particularly those with pancreatic necrosis.
- **Parenteral nutrition (TPN) should be avoided** unless the enteral route is not possible, not tolerated, or not meeting caloric requirements (Conditional, Moderate).
- A meta-analysis of 8 RCTs demonstrated that enteral nutrition (vs TPN) in severe AP results in:
  - Decreased infectious complications
  - Decreased organ failure
  - Decreased mortality

### Route of Enteral Feeding

The ACG **suggests** **nasogastric (NG) over nasojejunal (NJ)** delivery of enteral feeding (Conditional, Low).

- NG and NJ routes have **comparable safety and efficacy**.
- NG tubes are easier to place, simplifying clinical practice.

## Feeding Decision Algorithm

```
Mild acute pancreatitis
  → Attempt oral feeding within 24–48 hours
      → Tolerated? → Continue low-fat solid diet
      → Not tolerated? → Reassess in 12–24 hours, consider NG enteral nutrition

Moderately severe / Severe acute pancreatitis
  → Oral diet as tolerated
      → Not tolerating oral intake after 72 hours?
          → Start enteral nutrition via NG tube
              → Not tolerated via NG?
                  → Consider NJ tube placement
                  → TPN only as last resort
```

## Limitations

- The WATERFALL trial, while pivotal, was a single RCT; fluid resuscitation strategies may require further validation in specific subpopulations.
- Pain management recommendations are largely based on expert consensus and extrapolation from other acute pain settings due to limited pancreatitis-specific RCT data.
- Optimal caloric targets and feeding formulations for enteral nutrition in severe AP remain areas of active investigation.
