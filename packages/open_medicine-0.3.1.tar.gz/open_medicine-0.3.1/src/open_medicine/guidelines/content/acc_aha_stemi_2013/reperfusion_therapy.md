# Reperfusion Therapy in STEMI — ACCF/AHA 2013

## Reperfusion Strategy Selection

All patients with STEMI with symptom onset within the prior **12 hours** should receive reperfusion therapy. The choice between primary PCI and fibrinolytic therapy depends on timing and availability.

### Decision Algorithm

- **If patient presents to a PCI-capable hospital:**
  - Perform primary PCI with a **first-medical-contact (FMC)-to-device time goal of 90 minutes or less** (Class I, LOE: A)
- **If patient presents to a non-PCI-capable hospital:**
  - If transfer for primary PCI can achieve **FMC-to-device time of 120 minutes or less:** transfer immediately for primary PCI (Class I, LOE: B)
  - If FMC-to-device time will **exceed 120 minutes:** administer fibrinolytic therapy with a **door-to-needle time goal of 30 minutes or less** (Class I, LOE: B)
- **If patient presents with cardiogenic shock or severe heart failure:**
  - Transfer immediately for catheterization and revascularization, irrespective of time delay from MI onset (Class I, LOE: B)

### Late-Presenting Patients

- Primary PCI is reasonable for patients with symptom onset within the prior **12 to 24 hours** who have clinical and/or ECG evidence of ongoing ischemia (Class IIa, LOE: B)
- PCI should **not** be performed in a totally occluded infarct artery **> 24 hours after symptom onset** in asymptomatic, hemodynamically stable patients without evidence of ischemia (Class III: No Benefit, LOE: B)

---

## Primary Percutaneous Coronary Intervention (PCI)

### Key Recommendations

- Primary PCI should be performed in patients with STEMI and ischemic symptoms of **less than 12 hours' duration** (Class I, LOE: A)
- Primary PCI should be performed in patients with STEMI and ischemic symptoms of less than 12 hours' duration who have **contraindications to fibrinolytic therapy**, irrespective of the time delay from FMC (Class I, LOE: B)
- Primary PCI should be performed in patients with STEMI who present with **cardiogenic shock or acute severe heart failure**, irrespective of time delay from MI onset (Class I, LOE: B)

### PCI Technique

- **Stent placement** (bare-metal stent [BMS] or drug-eluting stent [DES]) is recommended over balloon angioplasty alone for primary PCI (Class I, LOE: A)
- **Aspiration thrombectomy** is reasonable for patients undergoing primary PCI (Class IIa, LOE: B)
- **Radial artery access** is reasonable when performed by experienced operators (reduces access-site bleeding complications)

---

## Fibrinolytic Therapy

### Indications

- In the absence of contraindications, fibrinolytic therapy should be given to patients with STEMI at non-PCI-capable hospitals when the anticipated FMC-to-device time at a PCI-capable hospital **exceeds 120 minutes** because of unavoidable delays (Class I, LOE: B)
- When fibrinolytic therapy is indicated, it should be administered within **30 minutes of hospital arrival** (door-to-needle time) (Class I, LOE: B)

### Fibrinolytic Agents and Dosing

| Agent | Dose | Route | Administration |
|---|---|---|---|
| **Tenecteplase** (preferred — single bolus) | Weight-based: <60 kg = 30 mg; 60-69 kg = 35 mg; 70-79 kg = 40 mg; 80-89 kg = 45 mg; >=90 kg = 50 mg | IV bolus over 5 seconds | Single dose |
| **Reteplase** | 10 units + 10 units | IV bolus | Two 10-unit boluses given 30 minutes apart |
| **Alteplase** (accelerated regimen) | 15 mg bolus, then 0.75 mg/kg over 30 min (max 50 mg), then 0.50 mg/kg over 60 min (max 35 mg); total max 100 mg | IV bolus + infusion | Over 90 minutes |

### Absolute Contraindications to Fibrinolytic Therapy

- Prior intracranial hemorrhage (any time)
- Known structural cerebrovascular lesion (e.g., AVM)
- Known intracranial neoplasm (primary or metastatic)
- Ischemic stroke within 3 months (except acute ischemic stroke within 4.5 hours)
- Suspected aortic dissection
- Active bleeding or bleeding diathesis (excluding menses)
- Significant closed-head or facial trauma within 3 months
- Intracranial or spinal surgery within 2 months
- Severe uncontrolled hypertension (unresponsive to emergency therapy)

### Relative Contraindications to Fibrinolytic Therapy

- History of chronic, severe, poorly controlled hypertension
- Severe uncontrolled hypertension on presentation (SBP > 180 mmHg or DBP > 110 mmHg)
- Ischemic stroke > 3 months prior
- Dementia or known intracranial pathology not otherwise listed
- Traumatic or prolonged (> 10 minutes) CPR
- Major surgery within 3 weeks
- Recent (within 2-4 weeks) internal bleeding
- Noncompressible vascular punctures
- Prior exposure to streptokinase (if streptokinase is being considered)
- Pregnancy
- Active peptic ulcer
- Current use of anticoagulants (higher INR = higher bleeding risk)

---

## Pharmacoinvasive Strategy and Rescue PCI

### Transfer After Fibrinolysis (Class I, LOE: B)

- Patients who receive fibrinolytic therapy at a non-PCI-capable hospital should be **transferred to a PCI-capable hospital** as soon as possible for routine angiography
- Angiography should be performed within **3 to 24 hours** after fibrinolytic therapy (Class IIa, LOE: B)

### Rescue PCI

- **Rescue PCI** is reasonable for patients with evidence of **failed reperfusion** or **reocclusion** after fibrinolytic therapy (Class IIa, LOE: B)
- Signs of failed reperfusion include: failure of > 50% ST-segment resolution at 60-90 minutes after fibrinolytic therapy, ongoing or recurrent ischemic symptoms, hemodynamic or electrical instability
- Angiography and revascularization should **not be performed within the first 2 to 3 hours** after fibrinolytic administration (to reduce bleeding risk)

### Urgent PCI Indications After Fibrinolysis

Transfer for urgent PCI is indicated for:
- Evidence of failed reperfusion
- Reocclusion after initially successful reperfusion
- Recurrent ischemia
- Cardiogenic shock or acute severe heart failure developing after initial presentation

## Limitations

- Time-based goals (90-minute FMC-to-device, 120-minute transfer-for-PCI) are system performance metrics; individual patient outcomes depend on multiple additional factors.
- Fibrinolytic therapy achieves TIMI 3 flow in approximately 50-60% of patients, compared with > 90% for primary PCI.
- The guideline does not provide specific guidance on reperfusion decisions in patients presenting between 12 and 24 hours with resolved symptoms but persistent ST elevation.

> **OpenMedicine Calculator:** `calculate_timi_stemi` -- available via MCP for automated TIMI STEMI risk scoring to guide intensity of management.
