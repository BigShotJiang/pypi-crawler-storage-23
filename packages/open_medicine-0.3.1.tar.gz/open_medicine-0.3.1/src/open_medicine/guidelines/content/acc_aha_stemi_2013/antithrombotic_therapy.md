# Antithrombotic Therapy in STEMI — ACCF/AHA 2013

## Antiplatelet Therapy

### Aspirin

- **Loading dose:** 162 to 325 mg, chewed (not enteric-coated) for rapid buccal absorption, given as early as possible (Class I, LOE: B)
- **Maintenance dose:** 81 mg per day, continued indefinitely (Class I, LOE: A)
- Aspirin 81 mg per day is preferred over higher maintenance doses (Class IIa, LOE: B)

### P2Y12 Receptor Inhibitors — Primary PCI

A loading dose of a P2Y12 receptor inhibitor should be given as early as possible or at time of primary PCI (Class I, LOE: B):

| Agent | Loading Dose | Maintenance Dose | Duration |
|---|---|---|---|
| **Clopidogrel** | 600 mg orally | 75 mg once daily | At least 12 months |
| **Prasugrel** | 60 mg orally | 10 mg once daily | At least 12 months |
| **Ticagrelor** | 180 mg orally | 90 mg twice daily | At least 12 months |

- P2Y12 inhibitor therapy should be given for **at least 12 months** to patients with STEMI who receive a stent (BMS or DES) during primary PCI (Class I, LOE: B)
- It is reasonable to choose ticagrelor over clopidogrel for P2Y12 treatment in patients with STEMI undergoing primary PCI (Class IIa, LOE: B)
- **Prasugrel contraindication:** Prior stroke or TIA (Class III: Harm, LOE: B)
- **Prasugrel caution:** Generally not recommended in patients >= 75 years or body weight < 60 kg (increased bleeding risk, reduced net benefit)

### P2Y12 Receptor Inhibitors — Fibrinolytic Therapy

- **Clopidogrel** should be given in addition to aspirin in patients receiving fibrinolytic therapy (Class I, LOE: A):
  - Age <= 75 years: 300 mg loading dose, then 75 mg daily
  - Age > 75 years: 75 mg (no loading dose), then 75 mg daily
- Continue clopidogrel for at least **14 days** and ideally **up to 12 months** (Class I, LOE: C)
- Prasugrel and ticagrelor have **not been studied** in fibrinolytic-treated patients and should not be used in this setting

### GP IIb/IIIa Receptor Antagonists

- It is reasonable to administer GP IIb/IIIa receptor antagonists (abciximab, high-dose tirofiban, or double-bolus eptifibatide) at the time of primary PCI in selected patients with a large thrombus burden (Class IIa, LOE: A)
- **Routine use** before primary PCI (upstream use) is **not recommended** (Class III: No Benefit, LOE: B)

---

## Anticoagulation Therapy

### Anticoagulation for Primary PCI

**Unfractionated Heparin (UFH)** (Class I, LOE: C):
- **Bolus:** 70-100 U/kg IV when **no** GP IIb/IIIa inhibitor is planned
- **Bolus:** 50-70 U/kg IV when GP IIb/IIIa inhibitor **is** planned
- Target **activated clotting time (ACT):** 200-250 seconds (with GP IIb/IIIa inhibitor) or 250-300 seconds (without GP IIb/IIIa inhibitor)
- Additional boluses as needed to maintain therapeutic ACT levels during the procedure

**Bivalirudin** (Class I, LOE: B):
- **Bolus:** 0.75 mg/kg IV, followed by **infusion** of 1.75 mg/kg/h
- Continue infusion for the duration of the PCI procedure
- Reasonable in patients at **high risk of bleeding** as an alternative to UFH plus GP IIb/IIIa inhibitor (Class IIa, LOE: B)
- Reduce infusion to 1.0 mg/kg/h if CrCl < 30 mL/min

**Fondaparinux:**
- Should **not** be used as the sole anticoagulant for primary PCI because of the risk of catheter thrombosis (Class III: Harm, LOE: B)

### Anticoagulation for Fibrinolytic Therapy

Patients receiving fibrinolytic therapy should receive anticoagulant therapy for a **minimum of 48 hours**, preferably for the duration of hospitalization **up to 8 days** or until revascularization (Class I, LOE: A):

**UFH** (Class I, LOE: C):
- **Bolus:** 60 U/kg IV (maximum 4,000 U)
- **Infusion:** 12 U/kg/h IV (maximum 1,000 U/h)
- Target aPTT: **1.5 to 2.0 times control** (approximately 50-70 seconds)
- Duration: 48 hours or until revascularization

**Enoxaparin** (Class I, LOE: A):
- **Age < 75 years:** 30 mg IV bolus, then 1 mg/kg subcutaneously every 12 hours (maximum 100 mg for the first 2 doses)
- **Age >= 75 years:** No IV bolus; 0.75 mg/kg subcutaneously every 12 hours (maximum 75 mg for the first 2 doses)
- **CrCl < 30 mL/min (any age):** 1 mg/kg subcutaneously once daily (regardless of age)
- Duration: for the index hospitalization, up to 8 days or until revascularization

**Fondaparinux** (Class I, LOE: B):
- **Dose:** 2.5 mg IV on day 1, then 2.5 mg subcutaneously once daily
- Duration: for the index hospitalization, up to 8 days or until revascularization
- If the patient proceeds to PCI, an additional anticoagulant with anti-IIa activity (UFH) should be administered due to the risk of catheter thrombosis

### Anticoagulation After PCI Following Fibrinolytic Therapy

- If patient received **UFH** as adjunct to fibrinolytic therapy: administer additional UFH boluses as needed during PCI to maintain therapeutic ACT
- If patient received **enoxaparin** and last SC dose was **< 8 hours ago:** no additional enoxaparin needed
- If patient received **enoxaparin** and last SC dose was **8 to 12 hours ago:** give 0.3 mg/kg IV bolus at PCI
- If patient received **enoxaparin** and last SC dose was **> 12 hours ago:** use standard anticoagulation for PCI
- **Do not switch between UFH and enoxaparin** (increased bleeding risk)

---

## Special Populations

### Patients Requiring Oral Anticoagulation

- In patients with STEMI who require long-term anticoagulation (e.g., atrial fibrillation, mechanical heart valve, LV thrombus), triple antithrombotic therapy (OAC + aspirin + clopidogrel) should be **limited in duration** to minimize bleeding (Class IIb, LOE: C)
- Use clopidogrel (not prasugrel or ticagrelor) when combined with OAC

### Elderly (>= 75 years)

- Clopidogrel with fibrinolytic therapy: 75 mg (no loading dose)
- Enoxaparin: reduced dose regimen (0.75 mg/kg SC every 12 hours, no IV bolus)
- Prasugrel: generally not recommended due to increased bleeding risk

### Renal Impairment (CrCl < 30 mL/min)

- UFH is preferred (no renal accumulation)
- Enoxaparin: 1 mg/kg SC once daily
- Bivalirudin: reduce infusion to 1.0 mg/kg/h
- Fondaparinux: contraindicated if CrCl < 20 mL/min
