# Spirometric Grading — GOLD 2024

## Diagnosis Confirmation

The diagnosis of COPD is confirmed when the post-bronchodilator ratio of Forced Expiratory Volume in 1 second (FEV1) to Forced Vital Capacity (FVC) is < 0.70.

## Grading of Airflow Limitation

In patients with FEV1/FVC < 0.70, the severity of airflow limitation is classified based on the post-bronchodilator FEV1 % predicted:

| GOLD Grade | Severity | FEV1 % predicted |
| :--- | :--- | :--- |
| **GOLD 1** | Mild | ≥ 80% |
| **GOLD 2** | Moderate | 50% ≤ FEV1 < 80% |
| **GOLD 3** | Severe | 30% ≤ FEV1 < 50% |
| **GOLD 4** | Very Severe | < 30% |

> **OpenMedicine Calculator:** `calculate_gold_copd` — available via MCP to calculate the combined GOLD COPD assessment.
