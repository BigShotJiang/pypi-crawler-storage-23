# Pharmacotherapy for Hypertension -- ACC/AHA 2017

## First-Line Antihypertensive Drug Classes

Four drug classes are recommended as first-line therapy for hypertension (Class I, Level of Evidence A):

1. **Thiazide or thiazide-type diuretics**
2. **ACE inhibitors (ACEi)**
3. **Angiotensin II receptor blockers (ARBs)**
4. **Calcium channel blockers (CCBs) -- dihydropyridine**

### Preferred Agents and Dosing

| Drug Class | Preferred Agent | Starting Dose | Target Dose | Route | Frequency |
|---|---|---|---|---|---|
| **Thiazide-type diuretic** | Chlorthalidone (preferred over HCTZ) | 12.5 mg | 25 mg | Oral | Once daily |
| **Thiazide-type diuretic** | Indapamide | 1.25 mg | 2.5 mg | Oral | Once daily |
| **Thiazide diuretic** | Hydrochlorothiazide | 25 mg | 50 mg | Oral | Once daily |
| **ACE inhibitor** | Lisinopril | 10 mg | 40 mg | Oral | Once daily |
| **ACE inhibitor** | Enalapril | 5 mg | 40 mg | Oral | Once or twice daily |
| **ACE inhibitor** | Ramipril | 2.5 mg | 20 mg | Oral | Once or twice daily |
| **ARB** | Losartan | 50 mg | 100 mg | Oral | Once daily |
| **ARB** | Valsartan | 80 mg | 320 mg | Oral | Once daily |
| **ARB** | Olmesartan | 20 mg | 40 mg | Oral | Once daily |
| **DHP CCB** | Amlodipine | 2.5--5 mg | 10 mg | Oral | Once daily |

- **Chlorthalidone** is the preferred diuretic because of its long half-life (40--60 hours) and proven reduction of cardiovascular events (Class I, Level of Evidence B-NR).
- Do not combine ACE inhibitor + ARB or ACE inhibitor/ARB + direct renin inhibitor (Class III: Harm, Level of Evidence A).

## Treatment Initiation Decision Tree

### Stage 1 Hypertension (130--139/80--89 mm Hg)

- **If clinical CVD or 10-year ASCVD risk >= 10%:**
  - Initiate 1 first-line agent at low dose (Class I, Level of Evidence A for SBP target < 130)
  - Reassess in 1 month; titrate to target < 130/80 mm Hg
- **If no CVD and 10-year ASCVD risk < 10%:**
  - Nonpharmacologic therapy for 3--6 months
  - If BP remains >= 140/90 mm Hg, initiate 1 first-line agent (Class I, Level of Evidence C-LD)

### Stage 2 Hypertension (>= 140/>= 90 mm Hg)

- Initiate 2 first-line agents of different classes (Class I, Level of Evidence C-EO).
- When BP is >= 20/10 mm Hg above goal, initiating with 2 drugs is particularly warranted.
- Evaluate or refer within 1 month.
- Consider a single-pill combination to improve adherence (Class IIb, Level of Evidence C-EO).

## Titration and Follow-Up

- Assess BP monthly until controlled at target (Class I, Level of Evidence A).
- If target not reached on single agent at optimal dose, add a second agent from a different first-line class rather than maximizing monotherapy dose alone.
- Once BP is at goal and stable, follow-up every 3--6 months.

## Special Populations

### Black Adults

- Initial antihypertensive treatment should include a thiazide-type diuretic or CCB (Class I, Level of Evidence B-R).
- ACE inhibitors and ARBs are less effective as monotherapy in Black adults without CKD or heart failure.
- When >= 2 agents are needed, a RAS blocker (ACEi or ARB) may be added to thiazide or CCB.

### Chronic Kidney Disease (CKD)

- BP target: < 130/80 mm Hg (Class I, Level of Evidence B-R).
- ACE inhibitor or ARB is reasonable to slow CKD progression in patients with Stage >= 3 CKD or Stage 1--2 CKD with albuminuria >= 300 mg/day (Class IIa, Level of Evidence B-R).
- If ACE inhibitor not tolerated, substitute ARB.
- Use loop diuretics (e.g., furosemide) instead of thiazides when eGFR < 30 mL/min.

### Diabetes Mellitus

- BP target: < 130/80 mm Hg (Class I, Level of Evidence B-R for SBP).
- All first-line drug classes are effective (Class I, Level of Evidence A).
- ACEi or ARB recommended as first-line when albuminuria is present (Class IIa, Level of Evidence B-NR).

### Stable Ischemic Heart Disease

- BP target: < 130/80 mm Hg (Class I, Level of Evidence B-R for SBP).
- First-line: ACEi or ARB (especially with prior MI, diabetes, or LV dysfunction) (Class I, Level of Evidence A).
- Beta-blockers are indicated for post-MI patients (Class I, Level of Evidence A) but are not first-line for hypertension alone.

### Heart Failure

- BP target: < 130/80 mm Hg (Class I, Level of Evidence C-EO).
- **HFrEF:** Guideline-directed medical therapy (GDMT) drugs with BP-lowering effects are preferred: ACEi/ARB/ARNi, beta-blocker (carvedilol, metoprolol succinate, bisoprolol), MRA (spironolactone, eplerenone), and diuretics (Class I, Level of Evidence A).
- **HFpEF:** Diuretics for volume overload; treat comorbid HTN per standard algorithm (Class IIa, Level of Evidence C-EO).
- Avoid non-dihydropyridine CCBs (diltiazem, verapamil) in HFrEF (Class III: Harm).

### Older Adults (>= 65 Years)

- For community-dwelling ambulatory older adults, antihypertensive treatment is recommended at SBP >= 130 mm Hg with a target SBP < 130 mm Hg (Class I, Level of Evidence A).
- For older adults with high burden of comorbidity, limited life expectancy, or clinical judgment concerns, clinical decision-making should be individualized (Class IIa, Level of Evidence C-EO).
- Use caution with aggressive BP lowering: monitor for orthostatic hypotension, falls, electrolyte abnormalities, and acute kidney injury.

### Pregnancy

- Use methyldopa, nifedipine, or labetalol for BP management in pregnancy.
- **Contraindicated in pregnancy:** ACE inhibitors, ARBs, and direct renin inhibitors (Class III: Harm, Level of Evidence C-EO).

### Cerebrovascular Disease

- **Acute ischemic stroke (pre-thrombolysis):** Lower BP to < 185/110 mm Hg before IV alteplase (Class I, Level of Evidence B-NR).
- **Acute ischemic stroke (post-thrombolysis):** Maintain BP < 180/105 mm Hg for the first 24 hours.
- **Acute ischemic stroke (no thrombolysis, SBP 150--220 mm Hg):** Immediate lowering of SBP to < 140 mm Hg is NOT of benefit and may cause harm (Class III: No Benefit, Level of Evidence A).
- **Secondary stroke prevention:** BP target < 130/80 mm Hg once stable (Class I, Level of Evidence B-R). A thiazide diuretic, ACEi, or combination is recommended.
- **Acute intracranial hemorrhage (SBP > 220 mm Hg):** Continuous IV infusion with close monitoring is reasonable (Class IIa, Level of Evidence C-EO).

### Aortic Disease

- Beta-blockers are the preferred antihypertensive drug class (Class I, Level of Evidence C-EO).

### Valvular Heart Disease

- **Asymptomatic aortic stenosis:** Initiate antihypertensive pharmacotherapy at low dose and titrate gradually; avoid hypotension.
- **Chronic aortic insufficiency:** Agents that do not slow heart rate are preferred (avoid beta-blockers unless needed for other indications) (Class IIa, Level of Evidence C-EO).

## Contraindicated or Harmful Combinations

- ACE inhibitor + ARB: Class III (Harm)
- ACE inhibitor or ARB + direct renin inhibitor (e.g., aliskiren): Class III (Harm)
- ACE inhibitors, ARBs, or direct renin inhibitors in pregnancy: Class III (Harm)
- Non-DHP CCBs (verapamil, diltiazem) in HFrEF: Class III (Harm)

## Drugs That Can Elevate Blood Pressure

Be aware of and minimize use of: NSAIDs, oral contraceptives, sympathomimetics (decongestants), stimulants, cyclosporine, tacrolimus, erythropoietin, corticosteroids, and licorice.
