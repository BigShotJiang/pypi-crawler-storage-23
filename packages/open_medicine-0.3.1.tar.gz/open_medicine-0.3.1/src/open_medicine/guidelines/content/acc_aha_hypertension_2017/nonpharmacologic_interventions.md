# Nonpharmacologic Interventions for Hypertension -- ACC/AHA 2017

## General Principle

Nonpharmacologic therapy is recommended for ALL adults with elevated BP or hypertension (Class I, Level of Evidence A). These interventions are the foundation of treatment and should continue even when pharmacotherapy is added. The effects of individual interventions are dose-dependent and approximately additive.

## Best Proven Nonpharmacologic Interventions (Guideline Table 15)

| Intervention | Dose/Target | Approximate SBP Reduction (Hypertensive) |
|---|---|---|
| **Weight loss** | Ideal body weight; best goal >= 1 kg reduction | ~1 mm Hg per 1 kg weight lost |
| **DASH diet** | Fruits, vegetables, whole grains, low-fat dairy; reduced saturated and total fat | ~11 mm Hg |
| **Sodium reduction** | Optimal: < 1,500 mg/day; at minimum aim for >= 1,000 mg/day reduction | ~5--6 mm Hg |
| **Potassium supplementation** | 3,500--5,000 mg/day, preferably through dietary sources | ~4--5 mm Hg |
| **Physical activity** | 90--150 min/week aerobic exercise; 65--75% heart rate reserve | ~5--8 mm Hg |
| **Alcohol moderation** | Men: <= 2 standard drinks/day; Women: <= 1 standard drink/day | ~4 mm Hg |

## Detailed Intervention Guidance

### Weight Loss

- Recommended for all overweight or obese adults with elevated BP or hypertension (Class I, Level of Evidence A).
- Goal: achieve and maintain ideal body weight.
- Expect approximately 1 mm Hg SBP reduction for every 1 kg of body weight lost.
- Weight loss enhances the BP-lowering effect of antihypertensive medications.

### DASH Dietary Pattern

- Adopt a diet rich in fruits, vegetables, whole grains, and low-fat dairy products with reduced content of saturated and total fat (Class I, Level of Evidence A).
- The DASH diet can reduce SBP by approximately 11 mm Hg in hypertensive patients.
- Most effective when combined with sodium restriction (DASH-Sodium trial).

### Dietary Sodium Reduction

- Reduce dietary sodium intake (Class I, Level of Evidence A).
- Optimal goal: < 1,500 mg/day sodium.
- At minimum, aim for a reduction of >= 1,000 mg/day from current intake.
- Expected SBP reduction: approximately 5--6 mm Hg.
- Sodium reduction is additive to other dietary interventions and antihypertensive drugs.

### Dietary Potassium Enhancement

- Increase dietary potassium intake to 3,500--5,000 mg/day, preferably from dietary sources (Class I, Level of Evidence A).
- Expected SBP reduction: approximately 4--5 mm Hg.
- **Caution:** Potassium supplementation may be harmful in patients with CKD or those taking drugs that reduce potassium excretion (ACE inhibitors, ARBs, potassium-sparing diuretics). Monitor serum potassium in these patients.

### Physical Activity

- Engage in regular aerobic physical activity: 90--150 minutes per week at 65--75% of heart rate reserve (Class I, Level of Evidence A).
- Expected SBP reduction: approximately 5--8 mm Hg.
- Dynamic resistance training and isometric resistance training are also effective adjuncts.
- Both structured exercise programs and increased routine physical activity provide benefit.

### Alcohol Moderation

- Limit alcohol consumption to <= 2 drinks per day for men and <= 1 drink per day for women (Class I, Level of Evidence A).
- One standard drink = 12 oz regular beer, 5 oz wine, or 1.5 oz distilled spirits.
- Expected SBP reduction: approximately 4 mm Hg.
- Counsel patients who drink more than moderate amounts to reduce alcohol intake.

## Actionable Implementation Strategy

1. **All patients with BP >= 120/80 mm Hg:** Begin nonpharmacologic interventions.
2. **Elevated BP (120--129/< 80 mm Hg):** Nonpharmacologic therapy alone. Reassess in 3--6 months.
3. **Stage 1 HTN with < 10% ASCVD risk:** Nonpharmacologic therapy alone for initial 3--6 months. If goal not achieved, add pharmacotherapy.
4. **Stage 1 HTN with >= 10% ASCVD risk or known CVD:** Start nonpharmacologic interventions simultaneously with pharmacotherapy.
5. **Stage 2 HTN:** Start nonpharmacologic interventions simultaneously with dual-drug pharmacotherapy.

## Limitations

- The SBP reductions listed are approximate population-level estimates; individual responses vary.
- Combining multiple lifestyle modifications may produce greater reductions than any single intervention alone, but the effects are not strictly additive in all patients.
- Sustained adherence to lifestyle changes is challenging; ongoing counseling and support are recommended.
