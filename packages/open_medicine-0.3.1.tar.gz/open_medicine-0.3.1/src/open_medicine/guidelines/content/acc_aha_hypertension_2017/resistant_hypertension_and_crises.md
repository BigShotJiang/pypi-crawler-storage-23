# Resistant Hypertension and Hypertensive Crises -- ACC/AHA 2017

## Resistant Hypertension

### Definition

Resistant hypertension is defined as BP that remains above goal (>= 130/80 mm Hg) despite concurrent use of 3 antihypertensive agents of different classes at optimal doses, one of which is a diuretic. Controlled BP requiring >= 4 medications is also classified as resistant hypertension.

### Evaluation Algorithm for Resistant Hypertension

1. **Confirm true resistance (rule out pseudo-resistance):**
   - Verify proper BP measurement technique (correct cuff size, positioning, rest period)
   - Obtain out-of-office BP (ABPM or HBPM) to exclude white coat effect (Class I, Level of Evidence B-R)
   - Assess medication adherence: direct questioning, pill counts, pharmacy refill records, or drug levels when available

2. **Identify and address contributing lifestyle factors:**
   - Excess dietary sodium intake
   - Excessive alcohol consumption
   - Obesity / physical inactivity
   - Obstructive sleep apnea (screen and treat if present)

3. **Discontinue or minimize interfering substances:**
   - NSAIDs
   - Oral contraceptives
   - Sympathomimetic agents (decongestants, stimulants)
   - Herbal supplements (e.g., licorice, ephedra)
   - Corticosteroids

4. **Screen for secondary causes of hypertension:**
   - **Primary aldosteronism:** Screen with aldosterone-to-renin ratio (Class I, Level of Evidence C-LD). Screening is recommended in: resistant HTN, spontaneous or diuretic-induced hypokalemia, adrenal incidentaloma, family history of early-onset HTN, or stroke at a young age (Class I, Level of Evidence C-EO).
   - **Renal artery stenosis:** Consider renal artery duplex ultrasonography or CT/MR angiography in patients with abrupt onset, worsening renal function on ACEi/ARB, asymmetric kidneys, or flash pulmonary edema.
   - **Pheochromocytoma:** Screen with plasma or 24-hour urine metanephrines if paroxysmal hypertension, adrenal mass, or clinical suspicion.
   - **Cushing syndrome:** 24-hour urinary free cortisol, late-night salivary cortisol, or overnight dexamethasone suppression test.
   - **Thyroid disease:** TSH and free T4.
   - **Primary hyperparathyroidism:** Serum calcium and intact PTH.
   - **Coarctation of the aorta:** BP differential between upper and lower extremities, echocardiography, or CT/MR angiography.

### Pharmacologic Management of Resistant Hypertension

- **Step 1 -- Optimize diuretic therapy:**
  - Switch hydrochlorothiazide to chlorthalidone 12.5--25 mg daily or indapamide 1.25--2.5 mg daily (longer half-life, superior evidence) (Class I, Level of Evidence B-NR).
  - If eGFR < 30 mL/min: use a loop diuretic (furosemide 20--80 mg twice daily or torsemide 10--20 mg daily) instead of a thiazide-type diuretic.

- **Step 2 -- Add mineralocorticoid receptor antagonist (MRA):**
  - Spironolactone 25--50 mg daily is the preferred add-on agent for resistant hypertension (Class I, Level of Evidence B-R).
  - Alternative: Eplerenone 50--100 mg daily (if gynecomastia or breast tenderness with spironolactone).
  - Monitor serum potassium and creatinine within 2--4 weeks of initiation. Avoid if baseline K+ > 5.0 mEq/L or eGFR < 30 mL/min.

- **Step 3 -- Add agents with different mechanisms:**
  - Consider: beta-blocker, alpha-1 blocker, central alpha-2 agonist (clonidine), or direct vasodilator (hydralazine, minoxidil).
  - **Beta-blockers:** Metoprolol succinate 25--200 mg daily, bisoprolol 2.5--10 mg daily, or carvedilol 6.25--25 mg twice daily.
  - **Alpha-1 blockers:** Doxazosin 1--16 mg daily, prazosin 1--20 mg in divided doses (associated with orthostatic hypotension; may benefit men with BPH).
  - **Central alpha-2 agonists:** Clonidine 0.1--0.3 mg twice daily orally or clonidine patch 0.1--0.3 mg/day weekly. Avoid abrupt discontinuation (rebound hypertension). Reserved as last-line.
  - **Direct vasodilators:** Hydralazine 25--100 mg twice daily or minoxidil 2.5--80 mg daily (causes fluid retention; must co-administer with diuretic and beta-blocker).

- **Step 4 -- Referral:**
  - If BP remains uncontrolled despite optimized regimen with >= 4 agents, refer to a hypertension specialist.

## Hypertensive Crises

### Definitions

- **Hypertensive emergency:** Severe BP elevation (> 180/120 mm Hg) WITH acute target organ damage. Requires immediate IV therapy in a monitored setting (ICU).
- **Markedly elevated BP (hypertensive urgency):** Severe BP elevation (> 180/120 mm Hg) WITHOUT acute target organ damage. Managed with oral antihypertensives and close follow-up.

### Target Organ Damage in Hypertensive Emergency

- Hypertensive encephalopathy
- Acute intracranial hemorrhage
- Acute ischemic stroke
- Acute myocardial infarction / unstable angina
- Acute left ventricular failure with pulmonary edema
- Acute aortic dissection
- Acute renal failure
- Eclampsia

### BP Reduction Targets in Hypertensive Emergency

| Timeframe | SBP Goal |
|---|---|
| **First 1 hour** | Reduce by no more than 25% from presenting value |
| **Next 2--6 hours** | Target 160/100 mm Hg (if stable) |
| **Next 24--48 hours** | Cautiously approach normal BP |

### Exceptions to Standard BP Reduction Timeline

| Condition | Target |
|---|---|
| **Aortic dissection** | SBP < 120 mm Hg within first hour; heart rate < 60 bpm |
| **Severe preeclampsia / eclampsia** | SBP < 140 mm Hg within first hour |
| **Pheochromocytoma crisis** | Rapid SBP control with IV phentolamine or nitroprusside |

### IV Agents for Hypertensive Emergency

| Agent | Mechanism | Typical Starting Dose | Onset | Notes |
|---|---|---|---|---|
| **Nicardipine** | DHP CCB | 5 mg/hr IV, titrate by 2.5 mg/hr q5--15 min; max 15 mg/hr | 5--10 min | Preferred in most emergencies; avoid in acute HF |
| **Labetalol** | Alpha/beta-blocker | 20 mg IV bolus, then 20--80 mg q10 min or 0.5--2 mg/min infusion | 5--10 min | Avoid in severe bradycardia, HFrEF, bronchospasm |
| **Clevidipine** | DHP CCB | 1--2 mg/hr IV; double dose q90 sec; max 32 mg/hr | 2--4 min | Ultra-short acting; avoid in soy/egg allergy |
| **Nitroprusside** | Direct vasodilator | 0.25--10 mcg/kg/min IV | Seconds | Cyanide toxicity risk with prolonged use (> 48 hr); requires arterial line |
| **Esmolol** | Beta-1 blocker | 250--500 mcg/kg IV bolus, then 25--300 mcg/kg/min | 60 sec | Ultra-short acting; useful when beta-blockade uncertain |
| **Fenoldopam** | Dopamine-1 agonist | 0.1--0.3 mcg/kg/min IV; titrate q15 min | 5--10 min | May benefit renal perfusion; avoid with glaucoma |
| **Nitroglycerin** | Venodilator | 5--200 mcg/min IV | 2--5 min | Preferred in acute coronary syndrome and pulmonary edema |
| **Hydralazine** | Direct vasodilator | 10--20 mg IV q4--6 hr | 10--20 min | Preferred in eclampsia; unpredictable response |
| **Phentolamine** | Alpha blocker | 5--15 mg IV bolus | 1--2 min | Specific for pheochromocytoma crisis |

### Hypertensive Urgency (Markedly Elevated BP Without Target Organ Damage)

- No need for ICU admission or IV therapy.
- Reinstitute or intensify oral antihypertensive therapy.
- Assess for medication nonadherence, dietary indiscretion, or discontinuation of medications.
- Reduce BP gradually over 24--48 hours with oral agents.
- Close outpatient follow-up within 1--7 days.
- Overly aggressive acute lowering in the absence of target organ damage is not recommended and may be harmful.

## Limitations

- The optimal rate of BP reduction in hypertensive emergencies is extrapolated from observational data and expert consensus; randomized trial evidence is limited.
- The definition of resistant hypertension requires confirmation that doses are optimal and adherence is confirmed, which is often difficult to verify in clinical practice.
- Spironolactone for resistant hypertension has the strongest evidence (PATHWAY-2 trial), but data on other add-on agents in this context are less robust.
