# Blood Pressure Classification and Measurement -- ACC/AHA 2017

## BP Classification Categories

| Category | Systolic (mm Hg) | | Diastolic (mm Hg) |
|----------|-------------------|----|---------------------|
| **Normal** | < 120 | and | < 80 |
| **Elevated** | 120--129 | and | < 80 |
| **Stage 1 Hypertension** | 130--139 | or | 80--89 |
| **Stage 2 Hypertension** | >= 140 | or | >= 90 |

- Individuals with SBP and DBP in two different categories should be designated to the higher BP category.
- The term "prehypertension" is eliminated; replaced by "Elevated BP" and "Stage 1 Hypertension."

## Proper BP Measurement (Class I, Level of Evidence A)

- Use an average based on >= 2 readings obtained on >= 2 occasions to estimate the individual's level of BP.
- Patient should be seated quietly for at least 5 minutes before measurement, feet flat on the floor, back supported, arm supported at heart level.
- Use an appropriately sized cuff (bladder encircling >= 80% of the arm circumference).
- Neither the patient nor the observer should talk during the rest period or during measurement.
- At the first visit, record BP in both arms and use the arm with the higher reading for subsequent measurements.

## Out-of-Office BP Measurement

- Out-of-office BP measurements are recommended to confirm the diagnosis of hypertension and for titration of BP-lowering medication (Class I, Level of Evidence A).
- Ambulatory blood pressure monitoring (ABPM) is the preferred method; home BP monitoring (HBPM) is acceptable when ABPM is not available or tolerated.

### Out-of-Office BP Thresholds Corresponding to Office 130/80 mm Hg

| Method | Systolic (mm Hg) | Diastolic (mm Hg) |
|--------|-------------------|--------------------|
| **Home BP (HBPM)** | >= 130 | >= 80 |
| **Daytime ABPM** | >= 130 | >= 80 |
| **Nighttime ABPM** | >= 110 | >= 65 |
| **24-hour ABPM** | >= 125 | >= 75 |

### Out-of-Office BP Thresholds Corresponding to Office 140/90 mm Hg

| Method | Systolic (mm Hg) | Diastolic (mm Hg) |
|--------|-------------------|--------------------|
| **Home BP (HBPM)** | >= 135 | >= 85 |
| **Daytime ABPM** | >= 135 | >= 85 |
| **Nighttime ABPM** | >= 120 | >= 70 |
| **24-hour ABPM** | >= 130 | >= 80 |

## White Coat and Masked Hypertension

- **White coat hypertension:** Office BP >= 130/80 mm Hg but out-of-office BP < 130/80 mm Hg. Screen with ABPM or HBPM before starting pharmacotherapy (Class IIa, Level of Evidence C-LD).
- **Masked hypertension:** Office BP < 130/80 mm Hg but out-of-office BP >= 130/80 mm Hg. Associated with increased CVD risk. Consider out-of-office monitoring in patients with borderline office BP.

## Treatment Initiation Thresholds

### Decision Algorithm Based on ASCVD Risk

- **Elevated BP (120--129/< 80 mm Hg):**
  - Nonpharmacologic therapy only (Class I, Level of Evidence A)
  - Reassess in 3--6 months

- **Stage 1 Hypertension (130--139/80--89 mm Hg):**
  - If known clinical CVD OR 10-year ASCVD risk >= 10%: initiate nonpharmacologic therapy PLUS antihypertensive drug therapy; target < 130/80 mm Hg (Class I, Level of Evidence A for SBP; Class I, Level of Evidence C-EO for DBP)
  - If no clinical CVD AND 10-year ASCVD risk < 10%: nonpharmacologic therapy alone; reassess in 3--6 months. If BP remains above goal, initiate pharmacotherapy at >= 140/90 mm Hg (Class I, Level of Evidence C-LD)

- **Stage 2 Hypertension (>= 140/>= 90 mm Hg):**
  - Nonpharmacologic therapy PLUS antihypertensive drug therapy with 2 agents of different classes (Class I, Level of Evidence C-EO)
  - Evaluate or refer within 1 month
  - Target < 130/80 mm Hg

## BP Targets by Comorbidity

| Condition | SBP Target (mm Hg) | DBP Target (mm Hg) | COR/LOE |
|-----------|---------------------|---------------------|---------|
| **General (with CVD or >= 10% ASCVD risk)** | < 130 | < 80 | I/A (SBP), I/C-EO (DBP) |
| **Stable ischemic heart disease** | < 130 | < 80 | I/B-R (SBP) |
| **Heart failure** | < 130 | < 80 | I/C-EO |
| **Chronic kidney disease** | < 130 | < 80 | I/B-R |
| **Diabetes mellitus** | < 130 | < 80 | I/B-R |
| **Peripheral arterial disease** | < 130 | < 80 | I/B-NR |
| **Secondary stroke prevention** | < 130 | < 80 | I/B-R |
| **Age >= 65 years (community-dwelling ambulatory)** | < 130 | -- | I/A |

## Screening for Secondary Hypertension

Consider secondary hypertension workup in the following scenarios:
- Resistant hypertension (uncontrolled on >= 3 drugs including a diuretic)
- Abrupt onset of hypertension
- Onset before age 30 (without other risk factors such as obesity)
- Exacerbation of previously controlled hypertension
- Disproportionate target organ damage for the degree or duration of hypertension
- Onset of diastolic hypertension in adults >= 65 years

### Primary Aldosteronism Screening

- Screen for primary aldosteronism in adults with resistant hypertension, spontaneous or diuretic-induced hypokalemia, incidentally discovered adrenal mass, family history of early-onset hypertension, or stroke at a young age (Class I, Level of Evidence C-EO).
- Use the plasma aldosterone-to-renin ratio for screening (Class I, Level of Evidence C-LD).

## Limitations

- The 10-year ASCVD risk calculator (Pooled Cohort Equations) is validated for adults aged 40--79 years; use clinical judgment outside this range.
- Office BP measurement may not accurately reflect ambulatory BP in all patients; out-of-office confirmation is recommended.
- The new lower threshold for Stage 1 hypertension (130/80 mm Hg) significantly increases the prevalence of hypertension to approximately 46% of US adults from 32% under JNC 7 criteria.
