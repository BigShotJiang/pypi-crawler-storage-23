# Initial Assessment of Acute Ischemic Stroke — AHA/ASA 2019

## NIHSS Severity Classification

The NIH Stroke Scale (NIHSS) quantifies neurological deficit severity (0–42 points) and drives treatment decisions.

| NIHSS Score | Severity | Clinical Implication |
|---|---|---|
| 0 | No symptoms | Reassess diagnosis; consider stroke mimics |
| 1–4 | Minor stroke | Consider IV alteplase if disabling symptoms; observe if non-disabling |
| 5–15 | Moderate stroke | IV alteplase indicated if within time window. Assess for LVO. |
| 16–20 | Moderate-to-severe stroke | IV alteplase + evaluate for mechanical thrombectomy |
| 21–42 | Severe stroke | IV alteplase + emergent thrombectomy evaluation. High mortality risk. |

> **OpenMedicine Calculator:** `calculate_nihss` — available via MCP for automated scoring.

## Emergency Department Evaluation (Door-to-Needle < 60 Minutes)

The AHA/ASA recommends a target door-to-needle time of ≤ 60 minutes for IV alteplase (Class I). The following must be completed urgently:

1. **Non-contrast CT Head:** Obtain immediately to rule out hemorrhagic stroke (Class I). Must be interpreted within 45 minutes of ED arrival.
2. **Blood glucose:** Only laboratory test REQUIRED before alteplase administration. Treat hypoglycemia (< 60 mg/dL) before thrombolysis.
3. **NIHSS scoring:** Complete a standardized NIHSS assessment.
4. **Time of symptom onset (Last Known Well):** Critical for determining treatment eligibility. If unknown (e.g., wake-up stroke), advanced imaging (MRI DWI-FLAIR mismatch) is required to establish eligibility.
5. **CT Angiography (CTA):** Perform if Large Vessel Occlusion (LVO) is suspected (NIHSS ≥ 6, cortical signs). CTA should NOT delay IV alteplase administration.

### Key Blood Pressure Thresholds Before Thrombolysis
- BP must be **< 185/110 mmHg** before alteplase is administered (Class I).
- **If BP exceeds this:** Treat with IV Labetalol 10–20 mg over 1–2 min (may repeat once) OR Nicardipine infusion 5 mg/hr, titrate by 2.5 mg/hr every 5–15 min (max 15 mg/hr).
- **If BP cannot be reduced below 185/110:** Alteplase is CONTRAINDICATED.

### Post-Thrombolysis BP Management
- Maintain BP **< 180/105 mmHg** for the first 24 hours after alteplase (Class I).
