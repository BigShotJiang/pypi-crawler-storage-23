# Risk Assessment — ACC/AHA 2013

## Pooled Cohort Equations

The 2013 ACC/AHA Guideline on the Assessment of Cardiovascular Risk introduces the Pooled Cohort Equations to estimate the 10-year risk of developing a first hard atherosclerotic cardiovascular disease (ASCVD) event.

- **Recommendation:** "The race- and sex-specific Pooled Cohort Equations to predict 10-year risk of a first hard ASCVD event should be used in non-Hispanic African Americans and non-Hispanic whites, 40–79 years of age." (Class I, Level B)

A "hard ASCVD event" is defined as:
- Nonfatal myocardial infarction (MI)
- Coronary heart disease (CHD)-related death
- Fatal or nonfatal stroke

## Parameters Used

The risk estimation incorporates the following individual patient characteristics:
- Age (validated for 40 to 79 years)
- Sex
- Race (specifically configured for non-Hispanic African Americans and non-Hispanic Whites)
- Total Cholesterol (mg/dL)
- High-Density Lipoprotein Cholesterol (HDL-C) (mg/dL)
- Systolic Blood Pressure (mmHg)
- Use of antihypertensive treatment (treated vs. untreated)
- Diabetes status (presence or absence)
- Current smoking status

## Limitations and Applicability

- The equations are primarily validated for individuals aged 40 through 79 years.
- For patients outside this age range (e.g., 20 to 59 years), the guideline suggests considering lifetime risk estimation to motivate lifestyle optimization.
- The equations may under- or overestimate risk in other racial/ethnic groups (such as Hispanic or Asian Americans) and must be applied with clinical judgment.

> **OpenMedicine Calculator:** `calculate_ascvd` — available via MCP for automated scoring.
