# Interpretation of 10-Year Risk — ACC/AHA 2013 & 2018

## Risk Categories and Actionable Pharmacotherapy

The 10-year ASCVD risk score is utilized in shared decision-making to guide primary prevention strategies in patients 40-75 years old without diabetes or clinical ASCVD.

- **< 5.0% (Low Risk):** 
  - **Action:** Emphasize lifestyle optimization. Statin therapy is generally NOT indicated.
- **5.0% to < 7.5% (Borderline Risk):** 
  - **Action:** Consider moderate-intensity statin IF risk-enhancing factors are present (e.g., family history of premature ASCVD, chronic kidney disease, metabolic syndrome, LDL-C ≥ 160).
- **7.5% to < 20.0% (Intermediate Risk):** 
  - **Action:** Initiate **Moderate-Intensity Statin** therapy (Goal: reduce LDL-C by 30% to 49%).
  - **Drug Examples:** Atorvastatin 10–20 mg, Rosuvastatin 5–10 mg, Simvastatin 20–40 mg.
- **≥ 20.0% (High Risk):** 
  - **Action:** Initiate **High-Intensity Statin** therapy (Goal: reduce LDL-C by ≥ 50%).
  - **Drug Examples:** Atorvastatin 40–80 mg, Rosuvastatin 20–40 mg.

## Special Benefit Groups (No Calculation Required)
Regardless of the 10-year risk score, the following groups have automated prescribing indications:
1. **Clinical ASCVD:** Secondary prevention requires **High-Intensity Statin**.
2. **Primary LDL-C ≥ 190 mg/dL:** Requires **High-Intensity Statin**.
3. **Diabetes Mellitus (Age 40-75):** Requires at least **Moderate-Intensity Statin**. Consider High-Intensity if multiple ASCVD risk factors are present or age 50-75.

## Follow-up & Monitoring
- Check fasting lipid panel 4 to 12 weeks after statin initiation or dose adjustment.
- Reassess response every 3 to 12 months thereafter.

> **OpenMedicine Calculator:** `calculate_ascvd` — available via MCP for automated scoring.
