# Endoscopic Management of Upper GI Bleeding — NICE CG141 (2012)

## Timing of Endoscopy

### Unstable Patients (Recommendation 1.3.1)
- **Offer endoscopy immediately after resuscitation** to unstable patients with severe acute upper GI bleeding.

### Stable Patients (Recommendation 1.3.2)
- **Offer endoscopy within 24 hours of admission** to all other patients with upper GI bleeding.

### Decision Tree

```
Patient with acute upper GI bleeding
  → Haemodynamically unstable despite resuscitation?
      → YES → Endoscopy immediately after resuscitation
      → NO → Endoscopy within 24 hours of admission
```

---

## Management of Non-Variceal Bleeding

### Endoscopic Treatment (Recommendations 1.4.1–1.4.2)

**Do NOT use adrenaline (epinephrine) as monotherapy.** Use one of the following combination approaches:

| Endoscopic Method | Details |
|---|---|
| **Mechanical clips ± adrenaline** | Primary haemostasis. Clips applied to visible vessel or actively bleeding point. |
| **Thermal coagulation + adrenaline** | Bipolar electrocoagulation or heater probe. Inject adrenaline first, then apply thermal energy. |
| **Fibrin or thrombin + adrenaline** | Inject adrenaline, then apply fibrin/thrombin sealant. |

> **Key Rule:** Adrenaline monotherapy is NOT sufficient — always combine with a second modality (Class I recommendation).

### Proton Pump Inhibitors (PPIs)

- **Before endoscopy:** Do NOT offer acid-suppression drugs (PPIs or H2-receptor antagonists) before endoscopy for suspected non-variceal UGIB (Recommendation 1.4.3).
- **After endoscopy:** Offer PPIs to patients with non-variceal UGIB and **stigmata of recent haemorrhage** shown at endoscopy (Recommendation 1.4.4).
  - **Recommended regimen:** High-dose IV PPI — Omeprazole 80 mg IV bolus, then 8 mg/hour infusion for 72 hours. Transition to oral PPI (Omeprazole 40 mg daily) thereafter.

### Re-Bleeding After Initial Endoscopy

```
Initial endoscopic treatment performed
  → High risk of re-bleeding?
      → YES → Consider repeat endoscopy with treatment
              (especially if doubt about adequate haemostasis)
              (Recommendation 1.4.5)
  → Patient re-bleeds?
      → YES → Repeat endoscopy with further endoscopic treatment
              (Recommendation 1.4.6)
              → Second endoscopy fails to achieve haemostasis?
                  → Unstable patient → Interventional radiology
                    (angiographic embolization) (Recommendation 1.4.7)
                  → Interventional radiology not promptly available?
                      → Refer urgently for emergency surgery
```

---

## Management of Variceal Bleeding

### Oesophageal Varices

1. **Band ligation (EVL)** is the recommended endoscopic therapy for bleeding oesophageal varices (Recommendation 1.5.3).
2. **If bleeding is not controlled by band ligation:** Consider transjugular intrahepatic portosystemic shunt (TIPS) (Recommendation 1.5.4).

### Gastric Varices

1. **Endoscopic injection of N-butyl-2-cyanoacrylate (tissue adhesive):** Recommended for bleeding gastric varices (Recommendation 1.5.5).
2. **If not controlled by cyanoacrylate injection:** Offer TIPS (Recommendation 1.5.6).

### Variceal Bleeding Management Algorithm

```
Variceal bleeding confirmed at endoscopy
  → Oesophageal varices?
      → YES → Endoscopic band ligation (EVL)
              → Bleeding controlled?
                  → YES → Continue terlipressin (up to 5 days),
                          prophylactic antibiotics (7 days).
                          Plan secondary prophylaxis (NSBB + EVL until obliteration)
                  → NO → Consider TIPS
      → Gastric varices?
          → YES → Endoscopic injection of N-butyl-2-cyanoacrylate
                  → Bleeding controlled?
                      → YES → Continue vasoactive therapy, antibiotics
                      → NO → TIPS
```

---

## Critical Care Primary Prophylaxis (Recommendation 1.7.1)

For acutely ill patients admitted to critical care:
- **Offer acid-suppression therapy** for primary prevention of UGIB.
- **Agents:** H2-receptor antagonists or PPIs.
- **Route:** Use oral form if possible.
- **Review:** Ongoing need should be reviewed when the patient recovers or is discharged from critical care (Recommendation 1.7.2).

## Limitations

- The guideline does not provide specific volume targets for crystalloid resuscitation.
- The GBS = 0 threshold for early discharge is highly specific but applies to only a small proportion (< 5%) of all UGIB presentations.
- Managing patients on novel oral anticoagulants (DOACs) at the time of this guideline's initial publication (2012) was limited; the DOAC reversal section reflects subsequent NICE technology appraisals.
