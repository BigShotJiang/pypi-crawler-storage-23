# Glycemic Goals and Hypoglycemia — ADA 2024

## A1C Targets

### Primary Goal (Recommendation 6.5a, Grade A)

An A1C goal of **< 7% (< 53 mmol/mol)** without significant hypoglycemia is appropriate for many nonpregnant adults with diabetes.

### More Stringent Goal (Recommendation 6.6, Grade B)

A lower A1C target (e.g., < 6.5%) may be acceptable and even beneficial if it can be achieved safely without significant hypoglycemia or other adverse effects of treatment.

**Factors favoring a more stringent goal:**
- Recently diagnosed diabetes
- Long life expectancy
- No significant cardiovascular disease
- No advanced microvascular complications
- Intact hypoglycemia awareness
- Motivated, engaged patient with adequate support

### Less Stringent Goal (Recommendation 6.7, Grade B)

A less stringent A1C goal (e.g., < 8%) may be appropriate for individuals with limited life expectancy or where the harms of treatment outweigh the benefits.

**Factors favoring a less stringent goal:**
- Limited life expectancy
- Extensive comorbidities or established cardiovascular disease
- Advanced microvascular complications
- Cognitive or functional impairment
- Impaired hypoglycemia awareness
- Recurrent severe hypoglycemia
- High treatment burden

### Individualization Decision Logic

```
Nonpregnant adult with diabetes
  → Assess patient-specific factors (comorbidities, life expectancy, hypoglycemia risk, duration)
      → Low risk, recently diagnosed, long life expectancy, motivated?
          → YES → Target A1C < 6.5% if safely achievable (Grade B)
      → Average risk, no major complications?
          → YES → Target A1C < 7% (Grade A)
      → High risk, limited life expectancy, extensive comorbidities, cognitive impairment?
          → YES → Target A1C < 8% (Grade B)
      → Very frail, end of life, focus on comfort?
          → YES → Avoid hypoglycemia and symptomatic hyperglycemia; A1C target may not apply
```

---

## Continuous Glucose Monitoring (CGM) Targets

### Time-in-Range Goals (Recommendation 6.5b, Grade B)

| Metric | Most Adults | Older/High-Risk Adults |
|---|---|---|
| Time in Range (TIR) 70–180 mg/dL | > 70% | > 50% |
| Time Below Range (TBR) < 70 mg/dL | < 4% | < 1% |
| Time Below Range (TBR) < 54 mg/dL | < 1% | < 1% |
| Time Above Range (TAR) > 180 mg/dL | < 25% | < 50% |
| Time Above Range (TAR) > 250 mg/dL | < 5% | < 10% |

- A TIR > 70% correlates approximately with an A1C of ~7% (53 mmol/mol).
- A 10- to 14-day CGM assessment with wear time of ≥ 70% is recommended for meaningful data (Grade B).
- TIR is associated with the risk of microvascular complications and can be used for assessment of glycemic status (Grade C).

---

## Glycemic Assessment Frequency

- **Recommendation 6.1 (Grade E):** Assess glycemic status by A1C and/or CGM metrics at minimum **biannually** in patients meeting goals with stable therapy.
- **Recommendation 6.2 (Grade E):** Assess **quarterly** when therapy has recently changed, glycemic goals are not being met, or health status has changed.

---

## Hypoglycemia Classification

| Level | Blood Glucose | Clinical Significance |
|---|---|---|
| **Level 1** | < 70 mg/dL (< 3.9 mmol/L) AND ≥ 54 mg/dL (≥ 3.0 mmol/L) | Clinically significant; alert value requiring treatment |
| **Level 2** | < 54 mg/dL (< 3.0 mmol/L) | Serious; requires immediate action |
| **Level 3** | Severe event | Altered mental and/or physical status requiring assistance for treatment, regardless of glucose level |

### Hypoglycemia Prevention and Management

- **CGM for high-risk patients (Recommendation 6.11d, Grade A):** CGM is beneficial and recommended for individuals at high risk for hypoglycemia.
- **Treatment (Recommendation 6.12, Grade B):** Glucose (15–20 g) is the preferred treatment for the conscious individual with glucose < 70 mg/dL. Any form of carbohydrate containing glucose may be used. Recheck in 15 minutes and repeat if still < 70 mg/dL.
- **Glucagon (Recommendation 6.13, Grade E):** Prescribe glucagon for all insulin-treated individuals or those at high hypoglycemia risk. Non-reconstituted glucagon preparations (nasal, auto-injector) are preferred.
- **Response to Level 2/3 events (Recommendation 6.15, Grade E):** Prompt reevaluation and potential deintensification of the treatment plan.

### Medication Deintensification

- **Recommendation 6.8a (Grade B):** Deintensify or switch hypoglycemia-causing medications (insulin, sulfonylureas, meglitinides) when hypoglycemia risk is high, within individualized glycemic goals.
- **Recommendation 6.8b (Grade B):** Deintensify when medication harms or burdens exceed benefits.

---

## Older Adult Considerations

- **Recommendation 6.17 (Grade B):** Ongoing assessment of cognitive function is suggested with increased vigilance for hypoglycemia if impaired or declining cognition is found.
- Relaxed CGM targets apply (TIR > 50%, TBR < 1%).
- Avoid complex regimens that increase hypoglycemia risk in frail older adults.

## Limitations

- A1C can be inaccurate in conditions affecting red blood cell turnover (hemolytic anemia, hemoglobinopathies, iron deficiency, recent transfusion, erythropoietin therapy).
- CGM metrics require adequate wear time (≥ 70% over 10–14 days) to be reliable.
- The correlation between TIR and A1C is approximate; individual variation exists.
- Glycemic targets must be individualized; rigid application of a single target to all patients is inappropriate.
