# Treatment Duration and Secondary Prevention for VTE — ASH 2020

## Primary Treatment Duration

### Key Principle

For all VTE (whether provoked by transient or chronic risk factors, or unprovoked), the ASH guideline panel suggests using a **shorter course of anticoagulation (3–6 months)** over a longer course (6–12 months) for primary treatment (conditional recommendation, moderate certainty of evidence ⨁⨁⨁○).

### Duration by VTE Category

| VTE Category | Primary Treatment Duration | Secondary Prevention | Strength |
|---|---|---|---|
| **Provoked by major transient risk factor** (surgery, immobilization, trauma) | 3–6 months | Stop anticoagulation after primary treatment | Conditional, Moderate ⨁⨁⨁○ |
| **Provoked by chronic risk factor** (autoimmune disease, inflammatory condition) | 3–6 months | Indefinite therapy suggested (Rec 18) | Conditional, Moderate ⨁⨁⨁○ |
| **Unprovoked (no identifiable risk factor)** | 3–6 months | Indefinite therapy suggested (Rec 19) | Conditional, Moderate ⨁⨁⨁○ |
| **Recurrent unprovoked VTE** | 3–6 months | Indefinite therapy **recommended** (Rec 25) | **Strong**, Moderate ⨁⨁⨁○ |

---

## Secondary Prevention Decisions

### Decision Algorithm

```
Patient completing 3–6 months of primary anticoagulation for VTE
  → Was the VTE provoked by a major transient risk factor?
      → YES → Was the risk factor resolved?
          → YES → Stop anticoagulation (Rec 12)
          → NO → Continue anticoagulation while risk factor persists
  → Was the VTE provoked by a chronic/persistent risk factor?
      → YES → Suggest indefinite anticoagulation (Rec 18, Conditional)
              unless high bleeding risk → individualize
  → Was the VTE unprovoked?
      → YES → First unprovoked event?
          → YES → Suggest indefinite anticoagulation (Rec 19, Conditional)
                   unless high bleeding risk → individualize
      → Recurrent unprovoked VTE?
          → YES → Recommend indefinite anticoagulation (Rec 25, Strong)
  → Is the patient on indefinite therapy?
      → YES → Choose agent and dose for secondary prevention (see below)
      → Reassess periodically (at least annually) for benefit-risk balance
```

### Indefinite Anticoagulation for Chronic Risk Factor VTE (Recommendation 18)

The panel suggests **indefinite antithrombotic therapy over stopping anticoagulation** for patients with VTE provoked by a chronic risk factor, excluding those at high bleeding risk (conditional recommendation, moderate certainty ⨁⨁⨁○).

### Indefinite Anticoagulation for Unprovoked VTE (Recommendation 19)

The panel suggests **indefinite antithrombotic therapy over stopping anticoagulation** for patients with unprovoked DVT and/or PE, excluding those at high bleeding risk (conditional recommendation, moderate certainty ⨁⨁⨁○).

### Indefinite Anticoagulation for Recurrent Unprovoked VTE (Recommendation 25)

The panel **recommends indefinite antithrombotic therapy** over stopping anticoagulation for patients with recurrent unprovoked VTE (**strong recommendation**, moderate certainty ⨁⨁⨁○).

---

## Anticoagulation vs Aspirin for Secondary Prevention (Recommendation 20)

The panel suggests using **anticoagulation over aspirin** for secondary prevention of VTE (conditional recommendation, moderate certainty ⨁⨁⨁○).

- Aspirin does reduce VTE recurrence risk compared to placebo but is inferior to anticoagulation.
- Aspirin may be considered only if anticoagulation is contraindicated or declined.

---

## DOAC Dosing for Extended/Secondary Prevention (Recommendation 22)

For patients who will receive indefinite anticoagulation with a DOAC, the panel suggests either a **standard-dose DOAC or a lower-dose DOAC** (conditional recommendation, moderate certainty ⨁⨁⨁○).

### Standard-Dose vs Reduced-Dose Options

| Drug | Standard Dose | Reduced Dose for Extended Therapy |
|---|---|---|
| Apixaban | 5 mg twice daily | 2.5 mg twice daily |
| Rivaroxaban | 20 mg once daily | 10 mg once daily |

- **Reduced-dose** apixaban 2.5 mg BID and rivaroxaban 10 mg daily have demonstrated efficacy in preventing VTE recurrence with lower bleeding rates compared to standard doses.
- The choice between standard and reduced dose should consider individual bleeding risk, patient preference, and recurrence risk.
- **Dabigatran and edoxaban:** No reduced-dose extended-therapy data; continue at standard dose if used for secondary prevention (dabigatran 150 mg BID, edoxaban 60 mg daily).

---

## Prognostic Tools for Duration Decisions

### Against Routine Use of Prognostic Scores (Recommendation 15, Conditional, Very Low ⨁○○○)

The panel suggests **against routine use of prognostic scores** (e.g., HERDOO2, Vienna prediction model, DASH score) to guide duration of anticoagulation. These scores may be used for patients in whom the benefit-risk balance of indefinite therapy is particularly uncertain.

### Against Routine D-Dimer Testing (Recommendation 16, Conditional, Very Low ⨁○○○)

The panel suggests **against routine use of D-dimer testing** to guide the duration of anticoagulation.

### Against Routine Residual Vein Thrombosis Ultrasound (Recommendation 17, Conditional, Very Low ⨁○○○)

The panel suggests **against routine ultrasound to detect residual vein thrombosis** to guide the duration of anticoagulation.

---

## Recurrent VTE Management

### Breakthrough VTE During VKA Therapy (Recommendation 23, Conditional, Very Low ⨁○○○)

For patients who develop recurrent VTE while receiving VKA, the panel suggests switching to **LMWH over DOAC therapy**.

- **Exception:** If breakthrough VTE is attributable to poor INR control or non-adherence, a DOAC is a reasonable alternative.
- Assess and ensure therapeutic anticoagulation compliance before concluding treatment failure.

### Recurrent VTE After Prior Unprovoked or Chronic-Risk VTE (Recommendation 24a, Conditional, Moderate ⨁⨁⨁○)

Indefinite antithrombotic therapy is suggested even if the recurrent event was provoked by a transient risk factor, if the prior event was unprovoked or provoked by a chronic risk factor.

### Two Transient-Factor–Provoked VTE Events (Recommendation 24b, Conditional, Moderate ⨁⨁⨁○)

The panel suggests stopping anticoagulation after completion of primary treatment if both VTE events were provoked by transient risk factors.

---

## Aspirin and Concurrent Anticoagulation (Recommendation 26, Conditional, Very Low ⨁○○○)

For patients with stable cardiovascular disease who are starting anticoagulation for VTE, the panel suggests **suspending aspirin** for the duration of anticoagulation.

- **Exceptions:** Continue aspirin in patients with recent acute coronary syndrome (< 12 months), recent coronary stent placement, or other high-risk coronary situations.

## Limitations

- Optimal duration of anticoagulation for unprovoked VTE remains uncertain; the distinction between "conditional" recommendation for first unprovoked VTE and "strong" for recurrent unprovoked reflects the cumulative recurrence risk.
- Reduced-dose extended DOAC therapy data come from specific trials (AMPLIFY-EXT for apixaban, EINSTEIN-CHOICE for rivaroxaban); applicability to all patient populations requires clinical judgment.
- The decision to continue indefinite anticoagulation should be reassessed at least annually, weighing ongoing bleeding risk against recurrence risk.
- The guideline does not address cancer-associated VTE, which is covered in the separate ASH 2021 guideline (DOI: 10.1182/bloodadvances.2021004734).
