# Diagnostic Evaluation of Transient Ischemic Attack — AHA/ASA 2009

## Neuroimaging

- **MRI with diffusion-weighted imaging (DWI)** is the preferred neuroimaging modality and should be performed **within 24 hours** of symptom onset (Class I, LOE B).
- DWI identifies acute ischemic lesions in approximately **30–50%** of clinically diagnosed TIA patients, which reclassifies the event as ischemic stroke.
- If MRI is unavailable or contraindicated, **non-contrast CT head** should be performed to exclude hemorrhage and other structural pathology (Class I, LOE B).

### MRI Protocol for TIA

| Sequence | Purpose |
|---|---|
| **DWI** | Detect acute ischemic lesions |
| **FLAIR** | Detect subacute ischemia and white matter disease |
| **T2*/SWI** | Detect hemorrhage and microbleeds |
| **MRA (intracranial)** | Evaluate intracranial vasculature |

## Vascular Imaging

### Extracranial (Cervical) Vessels

- **Noninvasive imaging of the cervical vessels** should be performed routinely in all TIA patients (Class I, LOE A).
- Modalities: carotid ultrasound (duplex), CTA of the neck, or MRA of the neck.
- The primary goal is to identify **carotid stenosis ≥ 50%**, which may warrant urgent carotid endarterectomy or stenting.

### Intracranial Vessels

- **Noninvasive imaging of the intracranial vasculature** is reasonable to identify intracranial stenosis or occlusion (Class IIa, LOE B).
- Modalities: MRA, CTA, or transcranial Doppler (TCD).

## Cardiac Evaluation

### Electrocardiography

- **12-lead ECG** should be performed as soon as possible after TIA to detect atrial fibrillation, atrial flutter, or other arrhythmias (Class I, LOE B).
- Atrial fibrillation is found in approximately **5–10%** of TIA patients on initial ECG.

### Prolonged Cardiac Monitoring

- **Prolonged cardiac monitoring** (Holter monitor or inpatient telemetry for ≥ 24 hours) is reasonable when the vascular etiology is not yet identified (Class IIa, LOE B).
- Paroxysmal atrial fibrillation is detected in an additional **5–10%** of patients with prolonged monitoring.

### Echocardiography

- **Echocardiography** is reasonable when a cardioembolic source is suspected (Class IIa, LOE B).
- Transthoracic echocardiography (TTE) is first-line; transesophageal echocardiography (TEE) may be considered for suspected PFO, valvular disease, or left atrial thrombus.

## Laboratory Tests

- **Routine blood tests** are reasonable at initial evaluation (Class IIa, LOE B):

| Test | Purpose |
|---|---|
| **CBC** | Detect anemia, polycythemia, thrombocytopenia |
| **Basic metabolic panel** | Detect electrolyte abnormalities, renal function |
| **Fasting glucose / HbA1c** | Screen for diabetes mellitus |
| **Lipid panel** | Cardiovascular risk stratification |
| **Coagulation studies (PT/INR)** | Baseline if anticoagulation is being considered |
| **ESR / CRP** | If vasculitis or temporal arteritis is suspected |

## Urgent vs. Emergent Evaluation

The pace of evaluation depends on the ABCD2 score and clinical context:

| ABCD2 Score | Timing of Evaluation | Setting |
|-------------|---------------------|---------|
| **0–2 (low risk)** | Within 48 hours if outpatient workup can be completed rapidly | Outpatient or observation |
| **3–5 (moderate risk)** | Within 24 hours | Hospital admission or urgent outpatient TIA clinic |
| **6–7 (high risk)** | Immediately | Hospital admission |

- Patients presenting **within 72 hours** of TIA with **ABCD2 ≥ 3** should be hospitalized (Class IIa, LOE C).
- Patients with **ABCD2 0–2** may be managed as outpatients only if a comprehensive evaluation can be completed rapidly and reliably.

## Limitations

- MRI availability varies significantly across emergency departments; CT is often the only immediately available modality.
- TCD is operator-dependent and may not be available at all centers.
- Optimal duration of cardiac monitoring is debated; extended monitoring (14–30 days) may detect additional paroxysmal AF but was not part of this 2009 guidance.
- The ABCD2 score has limited sensitivity for identifying high-risk patients; disposition decisions should incorporate imaging and etiology findings.
