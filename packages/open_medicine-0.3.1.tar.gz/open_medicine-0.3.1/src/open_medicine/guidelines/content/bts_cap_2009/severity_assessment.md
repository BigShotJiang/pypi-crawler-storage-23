# Severity Assessment of Community Acquired Pneumonia — BTS 2009

## CURB-65 Score

The CURB-65 score is the recommended tool for assessing the severity of community acquired pneumonia (CAP) at presentation.

### Criteria (1 point each)

| Criterion | Definition |
|-----------|------------|
| **C**onfusion | Abbreviated Mental Test Score ≤ 8 or new disorientation |
| **U**rea | Blood urea nitrogen > 20 mg/dL (> 7 mmol/L) |
| **R**espiratory rate | ≥ 30 breaths per minute |
| **B**lood pressure | Systolic < 90 mmHg or diastolic ≤ 60 mmHg |
| Age ≥ **65** | Patient age 65 or older |

### Risk Stratification and Management

- **Score 0–1 (Low risk, 30-day mortality ~1.5%):**
  - Suitable for home treatment.
  - Oral antibiotics.
  - Safety-net advice and review within 48 hours.

- **Score 2 (Moderate risk, 30-day mortality ~9.2%):**
  - Consider short inpatient stay or hospital-supervised outpatient treatment.
  - May benefit from IV antibiotics initially, then oral switch.
  - Clinical judgment is critical — consider social circumstances and comorbidities.

- **Score 3–5 (High risk, 30-day mortality ~22%):**
  - Manage as severe pneumonia with urgent hospital admission.
  - IV antibiotics.
  - Score 4–5: Assess for ICU admission and consider need for mechanical ventilation or vasopressor support.

## Limitations

- CURB-65 does not account for radiographic severity, comorbidities, or oxygen saturation.
- Clinical judgment should be applied alongside the score.
- Young patients may be under-triaged (score 0 purely due to age) despite severe disease — always assess oxygen saturation and clinical appearance.
