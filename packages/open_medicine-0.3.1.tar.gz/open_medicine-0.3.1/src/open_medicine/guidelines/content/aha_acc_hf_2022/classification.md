# Heart Failure Classification and Staging — AHA/ACC/HFSA 2022

## Universal Definition of Heart Failure

Heart failure is a clinical syndrome with symptoms and/or signs caused by a structural and/or functional cardiac abnormality and corroborated by elevated natriuretic peptide levels and/or objective evidence of pulmonary or systemic congestion.

## LVEF-Based Classification

| Classification | LVEF | Description |
|---|---|---|
| **HFrEF** (HF with reduced EF) | ≤ 40% | Systolic dysfunction predominates |
| **HFmrEF** (HF with mildly reduced EF) | 41–49% | Intermediate phenotype; may be improving from HFrEF or deteriorating toward HFrEF |
| **HFpEF** (HF with preserved EF) | ≥ 50% | Diastolic dysfunction; evidence of spontaneous or provokable increased LV filling pressures |
| **HFimpEF** (HF with improved EF) | Previous LVEF ≤ 40% with follow-up LVEF > 40% | GDMT should be continued even if asymptomatic to prevent relapse |

### Key Decision Logic

- **LVEF ≤ 40%** → Classify as **HFrEF** → Initiate full four-pillar GDMT (see pharmacotherapy section)
- **LVEF 41–49%** → Classify as **HFmrEF** → SGLT2i recommended; consider HFrEF therapies (ARNi, beta-blocker, MRA)
- **LVEF ≥ 50% with HF symptoms/signs and evidence of increased filling pressures** → Classify as **HFpEF** → SGLT2i recommended; manage comorbidities
- **Previous LVEF ≤ 40%, now > 40%** → Classify as **HFimpEF** → Continue all GDMT indefinitely; do NOT withdraw therapy

## Stages of Heart Failure (A–D)

### Stage A — At Risk for Heart Failure

**Definition:** Patients at risk for HF but without structural heart disease, symptoms, signs, or biomarker evidence of HF.

**Risk factors:** Hypertension, atherosclerotic cardiovascular disease, diabetes mellitus, metabolic syndrome, obesity, exposure to cardiotoxic agents, genetic variant for cardiomyopathy, family history of cardiomyopathy.

**Management recommendations:**
- Optimize blood pressure control (Class I, LOE A)
- Optimize glycemic control in patients with diabetes (Class I, LOE A)
- Encourage physical activity and healthy lifestyle (Class I, LOE B-NR)
- SGLT2i for patients with type 2 diabetes and either established CVD or high cardiovascular risk to prevent HF hospitalization (Class I, LOE A)
- BNP/NT-proBNP biomarker-based screening to identify pre-HF and guide prevention (Class IIa, LOE B-R)
- Avoid known cardiotoxic agents when possible (Class I, LOE B-NR)

### Stage B — Pre–Heart Failure

**Definition:** Patients without current or prior symptoms/signs of HF but with one of the following: structural heart disease (e.g., reduced LVEF, LVH, chamber enlargement, wall motion abnormality, valvular heart disease), evidence of increased filling pressures, or persistently elevated natriuretic peptide levels or cardiac troponin in the absence of competing diagnoses.

**Management recommendations:**
- ACEi (or ARB) for patients with LVEF ≤ 40% to prevent symptomatic HF (Class I, LOE A)
- Evidence-based beta-blocker for patients with LVEF ≤ 40% to prevent symptomatic HF (Class I, LOE C-EO)
- Statin therapy for patients with history of MI or ACS to reduce cardiovascular events (Class I, LOE A)
- ICD for primary prevention in selected patients with LVEF ≤ 30% at ≥ 40 days post-MI (see device therapy section) (Class I, LOE B-R)
- Avoid cardiotoxic agents and excessive alcohol use (Class I, LOE B-NR)

### Stage C — Symptomatic Heart Failure

**Definition:** Patients with current or prior symptoms and/or signs of HF caused by structural and/or functional cardiac abnormality.

**Management:** Depends on LVEF classification:

- **HFrEF (LVEF ≤ 40%):**
  - Four-pillar GDMT: ARNi (or ACEi/ARB) + beta-blocker + MRA + SGLT2i — all Class I, LOE A
  - Diuretics for volume overload (Class I, LOE B)
  - Additional agents (ivabradine, vericiguat, hydralazine/ISDN) based on individual criteria
  - See **pharmacotherapy** section for complete drug-by-drug recommendations

- **HFmrEF (LVEF 41–49%):**
  - SGLT2i to reduce HF hospitalization and cardiovascular mortality (Class IIa, LOE B-R)
  - Diuretics for congestion (Class I, LOE B)
  - ARNi, ACEi, ARB, MRA, and beta-blockers may be considered based on extrapolation from HFrEF data (Class IIb, LOE B-NR)

- **HFpEF (LVEF ≥ 50%):**
  - SGLT2i to reduce HF hospitalization and cardiovascular mortality (Class IIa, LOE B-R)
  - Diuretics for congestion (Class I, LOE B)
  - Management of underlying causes and comorbidities (hypertension, obesity, CAD, AF, etc.) (Class I, LOE C-LD)

### Stage D — Advanced Heart Failure

**Definition:** Patients with marked HF symptoms that interfere with daily life and with recurrent hospitalizations despite optimization of GDMT.

**Criteria for advanced HF:**
- Need for intravenous inotropes or mechanical circulatory support
- Recurrent hospitalizations (≥ 2 in 12 months) despite optimized GDMT
- Persistent NYHA class III–IV symptoms despite optimized GDMT
- Progressive end-organ dysfunction (worsening renal or hepatic function)
- Cardiac cachexia
- Inability to tolerate uptitration of neurohormonal antagonists

**Management recommendations:**
- Referral to advanced HF specialist/center (Class I, LOE C-EO)
- Durable mechanical circulatory support (LVAD) for selected patients with HFrEF to improve functional status and survival (Class IIa, LOE A)
- Cardiac transplantation for selected patients to improve survival and quality of life (Class I, LOE C-LD)
- Palliative care consultation integrated early and throughout all stages (Class I, LOE B-NR)
- Continuous intravenous inotropic support as bridge to transplant or MCS, or as palliation (Class IIb, LOE B-NR)

## NYHA Functional Classification

| Class | Description |
|---|---|
| I | No limitation of physical activity |
| II | Slight limitation; ordinary activity causes symptoms |
| III | Marked limitation; less than ordinary activity causes symptoms |
| IV | Unable to carry out any physical activity without symptoms; symptoms at rest |

## Limitations

- LVEF is a continuous variable; the cutoffs of 40% and 50% are somewhat arbitrary and based on trial enrollment criteria rather than pathophysiology.
- HFmrEF is a heterogeneous group that may include patients improving from HFrEF or deteriorating from HFpEF; specific evidence for this subgroup is limited.
- HFpEF diagnosis requires evidence of increased filling pressures (elevated natriuretic peptides, echocardiographic diastolic parameters, or invasive hemodynamic assessment); LVEF ≥ 50% alone is insufficient.
- Staging is unidirectional in concept (A → B → C → D); patients do not "regress" to earlier stages even if symptoms resolve with treatment.
