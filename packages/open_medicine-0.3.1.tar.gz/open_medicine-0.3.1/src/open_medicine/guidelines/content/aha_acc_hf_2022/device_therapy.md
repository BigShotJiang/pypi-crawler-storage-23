# Device Therapy and Advanced Heart Failure — AHA/ACC/HFSA 2022

## Implantable Cardioverter-Defibrillator (ICD)

### Primary Prevention ICD

ICD is recommended for primary prevention of sudden cardiac death (SCD) in patients with symptomatic HFrEF despite ≥ 3 months of optimized GDMT, with reasonable expectation of meaningful survival for > 1 year.

#### Ischemic Cardiomyopathy

| Criteria | Recommendation | LOE |
|---|---|---|
| LVEF ≤ 30%, ≥ 40 days post-MI, NYHA class I on GDMT | Class I | B-R |
| LVEF ≤ 35%, ≥ 40 days post-MI, NYHA class II–III on GDMT | Class I | A |

#### Non-Ischemic Dilated Cardiomyopathy

| Criteria | Recommendation | LOE |
|---|---|---|
| LVEF ≤ 35%, NYHA class II–III on GDMT | Class I | A |

### Key Decision Logic for ICD

```
Patient with HFrEF on ≥ 3 months of optimized GDMT
  → LVEF still ≤ 35%?
      → YES → Life expectancy > 1 year with reasonable functional status?
          → YES → Ischemic etiology?
              → YES (≥ 40 days post-MI):
                  → NYHA I and LVEF ≤ 30% → ICD (Class I, LOE B-R)
                  → NYHA II–III and LVEF ≤ 35% → ICD (Class I, LOE A)
              → NO (non-ischemic):
                  → NYHA II–III and LVEF ≤ 35% → ICD (Class I, LOE A)
          → NO (limited prognosis) → ICD not recommended
      → NO (LVEF > 35%) → ICD not indicated for primary prevention
```

### ICD Considerations

- **Do NOT implant** during the first 40 days after acute MI (Class III — Harm, LOE B-R).
- **Do NOT implant** within 90 days of coronary revascularization (reassess LVEF after recovery).
- **Do NOT implant** in patients with NYHA class IV refractory symptoms who are not candidates for transplant, LVAD, or CRT (Class III — No Benefit, LOE B-NR).
- **ICD generator replacement:** Reassess ongoing indication at each generator change; if LVEF has improved to > 35%, benefit of continued ICD therapy is uncertain (Class IIb, LOE C-LD).
- **Wearable cardioverter-defibrillator (WCD):** May be considered as bridge therapy in patients at high SCD risk with a transient or potentially reversible indication (e.g., early post-MI, peripartum cardiomyopathy, newly diagnosed non-ischemic DCM awaiting LVEF reassessment) (Class IIb, LOE B-NR).

---

## Cardiac Resynchronization Therapy (CRT)

CRT is recommended to improve symptoms, reduce hospitalizations, and reduce mortality in selected patients with HFrEF and conduction delay.

### CRT Indications by QRS Morphology and Duration

| QRS Morphology | QRS Duration | NYHA Class | LVEF | Recommendation | LOE |
|---|---|---|---|---|---|
| **LBBB** | **≥ 150 ms** | II, III, ambulatory IV | ≤ 35% | **Class I** | B-R |
| LBBB | 120–149 ms | II, III, ambulatory IV | ≤ 35% | Class IIa | B-NR |
| Non-LBBB | ≥ 150 ms | II, III, ambulatory IV | ≤ 35% | Class IIa | B-NR |
| Non-LBBB | 120–149 ms | II, III, ambulatory IV | ≤ 35% | Class IIb | B-NR |

### Additional CRT Scenarios

- **Patients with AF and LVEF ≤ 35%** who require ventricular pacing or otherwise meet CRT criteria: CRT may be considered, provided a strategy to ensure effective biventricular pacing (> 70% of all beats) is implemented (Class IIa, LOE B-NR).
- **Patients with HFrEF who have an indication for permanent ventricular pacing** (e.g., high-grade AV block): CRT is recommended over right ventricular pacing to reduce morbidity (Class I, LOE B-R).
- **Patients with existing conventional pacemaker or ICD** who develop worsening HF and LVEF ≤ 35% with significant RV pacing burden: Upgrade to CRT should be considered (Class IIa, LOE B-NR).

### CRT Decision Algorithm

```
Patient with HFrEF (LVEF ≤ 35%) on optimized GDMT with NYHA II–IV
  → QRS duration ≥ 120 ms?
      → YES → Sinus rhythm?
          → YES → LBBB morphology?
              → YES → QRS ≥ 150 ms?
                  → YES → CRT strongly recommended (Class I)
                  → NO (120–149 ms) → CRT reasonable (Class IIa)
              → NO (non-LBBB) → QRS ≥ 150 ms?
                  → YES → CRT reasonable (Class IIa)
                  → NO (120–149 ms) → CRT may be considered (Class IIb)
          → NO (AF) → CRT may be considered if biventricular pacing > 70% can be ensured (Class IIa)
      → NO (QRS < 120 ms) → CRT is NOT recommended (Class III — No Benefit, LOE B-R)
  → Need for permanent ventricular pacing (any QRS)?
      → YES → CRT preferred over RV pacing (Class I)
```

---

## Stage D — Advanced Heart Failure Therapies

### Durable Mechanical Circulatory Support (MCS)

Left ventricular assist device (LVAD) implantation should be considered for selected patients with Stage D HFrEF.

| Indication | Recommendation | LOE |
|---|---|---|
| Bridge to transplant (BTT) in transplant-eligible patients | Class IIa | B-NR |
| Destination therapy (DT) in transplant-ineligible patients to improve functional status and survival | Class IIa | A |

**Patient selection criteria for durable MCS:**
- NYHA class III–IV symptoms despite optimal GDMT for ≥ 3 months (or inotrope-dependent)
- LVEF ≤ 25%
- Peak VO₂ < 12 mL/kg/min (if exercise testing feasible)
- Adequate right ventricular function and absence of severe contraindications (uncontrolled infection, severe coagulopathy, irreversible organ failure other than cardiac)
- Psychosocial support and demonstrated ability to manage device

### Cardiac Transplantation (Class I, LOE C-LD)

Recommended for selected patients with Stage D HF to improve survival and quality of life when no further medical or surgical options exist.

**Referral criteria:**
- Persistent NYHA class III–IV despite optimized GDMT
- Recurrent HF hospitalizations (≥ 2 in 12 months)
- Need for continuous inotropic support
- Progressive end-organ dysfunction attributable to HF
- Peak VO₂ < 12–14 mL/kg/min (or < 50% predicted)

### Inotropic Support

- **Continuous IV inotropes (milrinone, dobutamine):** May be considered as bridge to transplant, bridge to MCS, or for palliation in patients with Stage D HF refractory to GDMT (Class IIb, LOE B-NR).
- Routine intermittent inotropes for ambulatory HF are NOT recommended (Class III — Harm, LOE B-R).

### Palliative Care (Class I, LOE B-NR)

Palliative and supportive care consultation should be integrated at all stages of HF, not limited to end-of-life care. Advance care planning, symptom management, and goals-of-care discussions should be ongoing.

---

## Iron Deficiency in Heart Failure

- **IV iron replacement** (ferric carboxymaltose or iron sucrose) is reasonable to improve functional status and quality of life in patients with HFrEF or HFmrEF and iron deficiency (ferritin < 100 ng/mL, or ferritin 100–299 ng/mL with transferrin saturation < 20%) (Class IIa, LOE B-R).
- Oral iron supplementation has not shown consistent benefit and is not recommended as a substitute for IV iron.

## Cardiac Rehabilitation (Class IIa, LOE A)

Exercise training or cardiac rehabilitation is recommended for patients with HF who are able to participate, to improve functional capacity, exercise tolerance, and quality of life.

## Limitations

- ICD primary prevention trials enrolled patients before widespread use of modern GDMT (ARNi, SGLT2i, MRA); the absolute benefit of ICD may be lower in patients on contemporary optimized therapy.
- CRT benefit is greatest in LBBB with QRS ≥ 150 ms; evidence is weaker for narrow LBBB (120–149 ms) and non-LBBB patterns.
- LVAD technology continues to evolve; outcomes data reflect specific device generations and may improve with future devices.
- Stage D criteria are subjective; early referral to advanced HF specialists is preferable to late referral.
