API Reference
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   accelforge.frontend
   accelforge.mapper
   accelforge.model
   accelforge.plotting
   accelforge.util

Module contents
---------------

.. automodule:: accelforge
   :members:
   :show-inheritance:
   :undoc-members:
