class PhiSaveCodecError(Exception):
    pass
