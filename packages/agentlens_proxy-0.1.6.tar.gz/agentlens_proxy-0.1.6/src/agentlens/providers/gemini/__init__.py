"""Gemini provider plugin."""

from .plugin import GeminiPlugin

__all__ = ["GeminiPlugin"]
