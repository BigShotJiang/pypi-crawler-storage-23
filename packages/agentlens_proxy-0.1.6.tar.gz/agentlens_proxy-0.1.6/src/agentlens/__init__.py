"""AgentLens — Profile AI agents by intercepting LLM API traffic."""

from importlib.metadata import version

__version__ = version("agentlens-proxy")
