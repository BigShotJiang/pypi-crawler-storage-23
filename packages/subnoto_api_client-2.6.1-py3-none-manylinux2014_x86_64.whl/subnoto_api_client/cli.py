"""Subnoto CLI - auto-generated from OpenAPI spec. Do not edit."""

import json
import os
import sys
from pathlib import Path
from typing import List, Optional

import typer

from subnoto_api_client import SubnotoSyncClient, SubnotoConfig


app = typer.Typer(name="subnoto", help="Subnoto API CLI", no_args_is_help=True)


def _client() -> SubnotoSyncClient:
    config = SubnotoConfig(
        api_base_url=os.getenv("SUBNOTO_API_URL", "https://enclave.subnoto.com"),
        access_key=os.getenv("SUBNOTO_ACCESS_KEY", ""),
        secret_key=os.getenv("SUBNOTO_SECRET_KEY", ""),
        unattested=os.getenv("SUBNOTO_UNATTESTED", "").lower() == "true",
    )
    if not config.access_key or not config.secret_key:
        typer.echo("Error: SUBNOTO_ACCESS_KEY and SUBNOTO_SECRET_KEY required", err=True)
        raise typer.Exit(1)
    return SubnotoSyncClient(config)


def _out(resp):
    try:
        typer.echo(json.dumps(resp.json(), indent=2))
    except Exception:
        typer.echo(resp.text)
    if resp.status_code >= 400:
        raise typer.Exit(1)


authentication_app = typer.Typer(help="Authentication operations", no_args_is_help=True)
app.add_typer(authentication_app, name="authentication")

contact_app = typer.Typer(help="Contact operations", no_args_is_help=True)
app.add_typer(contact_app, name="contact")

envelope_app = typer.Typer(help="Envelope operations", no_args_is_help=True)
app.add_typer(envelope_app, name="envelope")

template_app = typer.Typer(help="Template operations", no_args_is_help=True)
app.add_typer(template_app, name="template")

utils_app = typer.Typer(help="Utils operations", no_args_is_help=True)
app.add_typer(utils_app, name="utils")

workspace_app = typer.Typer(help="Workspace operations", no_args_is_help=True)
app.add_typer(workspace_app, name="workspace")


@authentication_app.command("create-iframe-token")
def authentication_create_iframe_token(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope."),
    signer_email: str = typer.Option(..., "--signer-email", help="The signer email address."),
):
    """create-iframe-token"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["signerEmail"] = signer_email
        _out(c.post("/public/authentication/create-iframe-token", json=body))

@contact_app.command("create")
def contact_create(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    contacts: str = typer.Option(..., "--contacts", help="The contacts to create. (JSON)"),
):
    """create"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["contacts"] = json.loads(contacts)
        _out(c.post("/public/contact/create", json=body))

@contact_app.command("delete")
def contact_delete(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    emails: List[str] = typer.Option(..., "--emails", help="The emails of the contacts to delete."),
):
    """delete"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        if emails:
            body["emails"] = list(emails)
        _out(c.post("/public/contact/delete", json=body))

@contact_app.command("get")
def contact_get(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    email: str = typer.Option(..., "--email", help="The email of the contact."),
):
    """get"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["email"] = email
        _out(c.post("/public/contact/get", json=body))

@contact_app.command("list")
def contact_list(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
):
    """list"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        _out(c.post("/public/contact/list", json=body))

@contact_app.command("update")
def contact_update(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    contact: str = typer.Option(..., "--contact", help=" (JSON)"),
):
    """update"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["contact"] = json.loads(contact)
        _out(c.post("/public/contact/update", json=body))

@envelope_app.command("add-attachment")
def envelope_add_attachment(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace containing the envelope."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to attach the document to."),
    document_title: str = typer.Option(..., "--document-title", help="The title of the document attachment."),
    file: Path = typer.Option(..., "--file", help="The file to attach (PDF, Word, ODT, or RTF document, max 11MB)."),
):
    """add-attachment"""
    with _client() as c:
        data, files = {}, {}
        data["workspaceUuid"] = str(workspace_uuid)
        data["envelopeUuid"] = str(envelope_uuid)
        data["documentTitle"] = str(document_title)
        _p = Path(file)
        files["file"] = (_p.name, open(_p, "rb"))
        _out(c._client.post("/public/envelope/add-attachment", data=data, files=files))

@envelope_app.command("add-blocks")
def envelope_add_blocks(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope."),
    document_uuid: str = typer.Option(..., "--document-uuid", help="The UUID of the document."),
    blocks: str = typer.Option(..., "--blocks", help="Array of blocks to add to the document. (JSON)"),
):
    """add-blocks"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["documentUuid"] = document_uuid
        body["blocks"] = json.loads(blocks)
        _out(c.post("/public/envelope/add-blocks", json=body))

@envelope_app.command("add-recipients")
def envelope_add_recipients(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope."),
    recipients: str = typer.Option(..., "--recipients", help="List of recipients to add (max 50). (JSON)"),
):
    """add-recipients"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["recipients"] = json.loads(recipients)
        _out(c.post("/public/envelope/add-recipients", json=body))

@envelope_app.command("create-from-file")
def envelope_create_from_file(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    envelope_title: str = typer.Option(..., "--envelope-title", help="The title of the envelope being created."),
    file: Path = typer.Option(..., "--file", help="The file to upload (PDF, Word, ODT, or RTF document, max 50MB)."),
    detect_smart_anchors: Optional[str] = typer.Option(None, "--detect-smart-anchors", help="Enable Smart Anchor detection. Set to 'true' to detect and process Smart Anchors in the PDF. Defaults to false."),
):
    """create-from-file"""
    with _client() as c:
        data, files = {}, {}
        data["workspaceUuid"] = str(workspace_uuid)
        data["envelopeTitle"] = str(envelope_title)
        _p = Path(file)
        files["file"] = (_p.name, open(_p, "rb"))
        if detect_smart_anchors is not None:
            data["detectSmartAnchors"] = str(detect_smart_anchors)
        _out(c._client.post("/public/envelope/create-from-file", data=data, files=files))

@envelope_app.command("create-from-template")
def envelope_create_from_template(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to create the envelope in."),
    template_uuid: str = typer.Option(..., "--template-uuid", help="The UUID of the template to copy from."),
    recipients: str = typer.Option(..., "--recipients", help="Array of recipients with labels to map to template recipient labels. (JSON)"),
):
    """create-from-template"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["templateUuid"] = template_uuid
        body["recipients"] = json.loads(recipients)
        _out(c.post("/public/envelope/create-from-template", json=body))

@envelope_app.command("delete")
def envelope_delete(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace containing the envelope."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to delete."),
):
    """delete"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        _out(c.post("/public/envelope/delete", json=body))

@envelope_app.command("delete-attachment")
def envelope_delete_attachment(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help=""),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help=""),
    document_uuid: str = typer.Option(..., "--document-uuid", help=""),
):
    """delete-attachment"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["documentUuid"] = document_uuid
        _out(c.post("/public/envelope/delete-attachment", json=body))

@envelope_app.command("delete-blocks")
def envelope_delete_blocks(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope."),
    document_uuid: str = typer.Option(..., "--document-uuid", help="The UUID of the document."),
    block_uuids: List[str] = typer.Option(..., "--block-uuids", help="Array of block UUIDs to delete from the document."),
):
    """delete-blocks"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["documentUuid"] = document_uuid
        if block_uuids:
            body["blockUuids"] = list(block_uuids)
        _out(c.post("/public/envelope/delete-blocks", json=body))

@envelope_app.command("delete-recipients")
def envelope_delete_recipients(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope."),
    recipients: str = typer.Option(..., "--recipients", help="List of recipients to delete (max 50). (JSON)"),
):
    """delete-recipients"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["recipients"] = json.loads(recipients)
        _out(c.post("/public/envelope/delete-recipients", json=body))

@envelope_app.command("get")
def envelope_get(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to get the envelope from."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to get."),
):
    """get"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        _out(c.post("/public/envelope/get", json=body))

@envelope_app.command("get-document")
def envelope_get_document(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to get the envelope from."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to get the document from."),
    document_uuid: str = typer.Option(..., "--document-uuid", help="The UUID of the document to download."),
):
    """get-document"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["documentUuid"] = document_uuid
        _out(c.post("/public/envelope/get-document", json=body))

@envelope_app.command("get-proof")
def envelope_get_proof(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to get the envelope from."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to get the proof document from."),
):
    """get-proof"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        _out(c.post("/public/envelope/get-proof", json=body))

@envelope_app.command("list")
def envelope_list(
    workspace_uuid: Optional[str] = typer.Option(None, "--workspace-uuid", help="The UUID of the workspace to list the envelopes in."),
    tags: Optional[List[str]] = typer.Option(None, "--tags", help="Optional array of tag names to filter envelopes by"),
    page: int = typer.Option(1, "--page", help="The page number to retrieve (1-indexed). Defaults to 1. Each page contains up to 50 results."),
):
    """list"""
    with _client() as c:
        body = {}
        if workspace_uuid is not None:
            body["workspaceUuid"] = workspace_uuid
        if tags:
            body["tags"] = list(tags)
        if page is not None:
            body["page"] = page
        _out(c.post("/public/envelope/list", json=body))

@envelope_app.command("send")
def envelope_send(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to send the envelope from."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to send."),
    distribution_method: Optional[str] = typer.Option(None, "--distribution-method", help="When \"email\" (default), invitation emails are sent; when \"none\", no emails are sent and link medium is set to \"none\". [email|none]"),
    use_user_as_sender_name: bool = typer.Option(False, "--use-user-as-sender-name/--no-use-user-as-sender-name", help="Deprecated. Use the update envelope endpoint to set this; value is ignored when sending. Whether to use the user's name or by default the company name as the sender name."),
    custom_invitation_message: Optional[str] = typer.Option(None, "--custom-invitation-message", help="Deprecated. Use the update envelope endpoint to set this; value is ignored when sending. Custom message to include in the invitation email."),
):
    """send"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        if distribution_method is not None:
            body["distributionMethod"] = distribution_method
        body["useUserAsSenderName"] = use_user_as_sender_name
        if custom_invitation_message is not None:
            body["customInvitationMessage"] = custom_invitation_message
        _out(c.post("/public/envelope/send", json=body))

@envelope_app.command("sign")
def envelope_sign(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace containing the envelope."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope containing the document to sign."),
    recipient_email: str = typer.Option(..., "--recipient-email", help="The email of the recipient who is signing. Must match the API key owner's email."),
    signature_image: Optional[str] = typer.Option(None, "--signature-image", help="Base64 encoded signature image to be merged with the watermark."),
):
    """sign"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["recipientEmail"] = recipient_email
        if signature_image is not None:
            body["signatureImage"] = signature_image
        _out(c.post("/public/envelope/sign", json=body))

@envelope_app.command("update")
def envelope_update(
    workspace_uuid: str = typer.Option(..., "--workspace-uuid", help="The UUID of the workspace to get the envelope from."),
    envelope_uuid: str = typer.Option(..., "--envelope-uuid", help="The UUID of the envelope to get."),
    update: str = typer.Option(..., "--update", help=" (JSON)"),
):
    """update"""
    with _client() as c:
        body = {}
        body["workspaceUuid"] = workspace_uuid
        body["envelopeUuid"] = envelope_uuid
        body["update"] = json.loads(update)
        _out(c.post("/public/envelope/update", json=body))

@template_app.command("list")
def template_list(
    workspace_uuid: Optional[str] = typer.Option(None, "--workspace-uuid", help="The UUID of the workspace to list the templates in."),
    page: int = typer.Option(1, "--page", help="The page number to retrieve (1-indexed). Defaults to 1. Each page contains up to 50 results."),
):
    """list"""
    with _client() as c:
        body = {}
        if workspace_uuid is not None:
            body["workspaceUuid"] = workspace_uuid
        if page is not None:
            body["page"] = page
        _out(c.post("/public/template/list", json=body))

@utils_app.command("whoami")
def utils_whoami(
):
    """whoami"""
    with _client() as c:
        _out(c.post("/public/utils/whoami", json={}))

@workspace_app.command("create")
def workspace_create(
    name: str = typer.Option(..., "--name", help="The name of the workspace to create."),
    color_hex: Optional[str] = typer.Option(None, "--color-hex", help="The color of the workspace in hexadecimal format."),
):
    """create"""
    with _client() as c:
        body = {}
        body["name"] = name
        if color_hex is not None:
            body["colorHex"] = color_hex
        _out(c.post("/public/workspace/create", json=body))

@workspace_app.command("get")
def workspace_get(
):
    """get"""
    with _client() as c:
        _out(c.post("/public/workspace/get", json={}))

@workspace_app.command("list")
def workspace_list(
):
    """list"""
    with _client() as c:
        _out(c.post("/public/workspace/list", json={}))


def main():
    app()


if __name__ == "__main__":
    main()
