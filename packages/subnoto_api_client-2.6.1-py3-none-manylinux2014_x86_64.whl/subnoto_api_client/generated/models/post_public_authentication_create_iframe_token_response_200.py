from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostPublicAuthenticationCreateIframeTokenResponse200")



@_attrs_define
class PostPublicAuthenticationCreateIframeTokenResponse200:
    """ 
        Attributes:
            iframe_token (str): The iframe token (prefix sit.) to use in the embed sign URL hash.
     """

    iframe_token: str





    def to_dict(self) -> dict[str, Any]:
        iframe_token = self.iframe_token


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "iframeToken": iframe_token,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        iframe_token = d.pop("iframeToken")

        post_public_authentication_create_iframe_token_response_200 = cls(
            iframe_token=iframe_token,
        )

        return post_public_authentication_create_iframe_token_response_200

