"""Agent-SRE CLI."""
from agent_sre.cli.main import cli

__all__ = ["cli"]
