"""Agent OS integration — policy signals and preview mode."""
