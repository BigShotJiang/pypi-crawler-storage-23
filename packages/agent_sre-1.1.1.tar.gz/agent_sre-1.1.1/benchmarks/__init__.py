"""Agent SRE performance benchmarks."""
