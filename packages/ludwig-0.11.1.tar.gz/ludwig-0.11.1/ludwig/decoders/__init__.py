# register all decoders
import ludwig.decoders.generic_decoders  # noqa
import ludwig.decoders.image_decoders  # noqa
import ludwig.decoders.llm_decoders  # noqa
import ludwig.decoders.sequence_decoders  # noqa
import ludwig.decoders.sequence_tagger  # noqa
