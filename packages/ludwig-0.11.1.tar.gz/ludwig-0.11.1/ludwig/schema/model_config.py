# TODO(travis) consider removing this in the future after deprecation period
from ludwig.schema.model_types.base import ModelConfig  # noqa
