"""OpenFDA API client and utilities."""
