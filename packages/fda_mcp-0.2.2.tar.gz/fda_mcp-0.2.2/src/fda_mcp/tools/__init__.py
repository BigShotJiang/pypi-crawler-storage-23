"""MCP tool handlers for the FDA MCP server."""
