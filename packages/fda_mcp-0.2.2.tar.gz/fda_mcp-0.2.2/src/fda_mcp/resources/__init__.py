"""MCP resource handlers for the FDA MCP server."""
