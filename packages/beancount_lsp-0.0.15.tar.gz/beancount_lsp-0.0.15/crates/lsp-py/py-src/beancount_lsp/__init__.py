"""Python wrapper for the beancount LSP server."""

from .cli import main

__all__ = ["main"]
