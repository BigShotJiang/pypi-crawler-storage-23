"""
Setup module for EdgescaleAI Agent.

Handles authentication and configuration BEFORE the LLM agent runs.
Credentials are never stored by us - they stay with native CLIs.
"""

from .config import Config, load_config, save_config
from .auth import AuthManager
from .wizard import run_setup_wizard, check_and_setup

__all__ = [
    'Config',
    'load_config',
    'save_config',
    'AuthManager',
    'run_setup_wizard',
    'check_and_setup',
]
