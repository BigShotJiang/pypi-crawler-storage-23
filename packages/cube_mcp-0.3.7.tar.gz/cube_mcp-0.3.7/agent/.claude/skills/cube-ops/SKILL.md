---
name: cube-ops
description: EdgescaleAI Cube operations and Helm deployments
---

# Cube Operations Skill

You are an expert at managing EdgescaleAI Cube edge devices and deploying applications to them.

## Available Cubes

Common Cube clusters accessible via Teleport:

| Cluster | Description |
|---------|-------------|
| staging-int | EdgescaleAI staging environment |
| staging-pre-prod | EdgescaleAI pre-production |
| staging-test-v2 | EdgescaleAI test environment |
| ironmountain-v4 | Production Cube |
| pep-onlogicmc610-* | Development Cubes |

## Workflow: Connecting to a Cube

1. **Login to Teleport** (opens browser for SSO):
   ```
   cube_login(cluster="staging-int")
   ```

2. **Verify connection**:
   ```
   cube_status()
   ```

## Workflow: Deploying a Helm Chart

### Prerequisites
- APOLLO_CLIENT and APOLLO_SECRET environment variables set
- Chart.yaml in the project (or ./charts/*/)
- Optional: Dockerfile for container image

### Simple Deploy (Auto-detection)
```
helm_deploy()
```
This will:
- Find Chart.yaml automatically
- Bump patch version
- Build Docker image if Dockerfile exists
- Package and push Helm chart
- Publish to Apollo

### Versioned Deploy
```
helm_deploy(version="2.0.0")
```

### Minor/Major Version Bump
```
helm_deploy(bump="minor")  # 1.0.0 -> 1.1.0
helm_deploy(bump="major")  # 1.0.0 -> 2.0.0
```

### Dry Run (Preview)
```
helm_deploy(dry_run=True)
```

### Skip Docker Build
```
helm_deploy(skip_docker=True)
```

## Apollo Container Registry

- **Registry URL**: edgescaleai.palantirapollo.com
- **Docker prefix**: edgescaleai.palantirapollo.com/com.edgescaleai-cube
- **Helm prefix**: oci://edgescaleai.palantirapollo.com/charts/com.edgescaleai-cube

## Setup Guidance

### Missing Apollo Credentials

Add to `~/.bashrc` or `~/.zshrc`:
```bash
export APOLLO_CLIENT="<your-client-id>"
export APOLLO_SECRET="<your-client-secret>"
```

Then run:
```bash
source ~/.bashrc
```

### Missing Tools

| Tool | Install Command |
|------|-----------------|
| tsh (Teleport) | https://goteleport.com/download/ |
| kubectl | brew install kubectl |
| helm | brew install helm |
| docker | https://docs.docker.com/get-docker/ |
| apollo-cli | pip install apollo-cli |

### Docker Buildx

For multi-arch builds (amd64/arm64):
```bash
docker buildx install
docker buildx create --use
```

## Troubleshooting

### Teleport Login Timeout
The SSO flow requires completing authentication in the browser. If it times out, try again and complete the browser flow quickly.

### kubectl Connection Refused
Make sure you're connected to a Cube first with `cube_login`.

### Helm Push Failed
1. Check Apollo credentials are set
2. Run `acr_login()` first
3. Verify chart version doesn't already exist

### Docker Build Failed
1. Check Dockerfile exists and is valid
2. Verify Docker daemon is running
3. For buildx issues, try: `docker buildx create --use`
