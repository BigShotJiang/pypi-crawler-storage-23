"""Tests that verify logging levels in relay.py are correct.

After the cleanup, verbose tbot/TLS details should be at DEBUG level,
while important connection events stay at INFO/WARNING/ERROR.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

RELAY_PATH = Path(__file__).resolve().parents[1] / "src" / "cube_cloud" / "tunnel" / "relay.py"


@pytest.fixture
def relay_source():
    """Read the relay.py source code."""
    return RELAY_PATH.read_text()


# ---------------------------------------------------------------------------
# Verify that verbose tbot/TLS logs are at DEBUG level
# ---------------------------------------------------------------------------


class TestDebugLevelLogs:
    """These log messages should be at DEBUG level (not INFO)."""

    def test_tbot_oneshot_exit_is_debug(self, relay_source):
        """'tbot oneshot exit=' should use logger.debug."""
        assert 'logger.debug("tbot oneshot exit=' in relay_source

    def test_tbot_generated_files_is_debug(self, relay_source):
        """'tbot generated files' should use logger.debug."""
        assert 'logger.debug("tbot generated files' in relay_source

    def test_connecting_tls_is_debug(self, relay_source):
        """'Connecting TLS to' should use logger.debug."""
        assert 'logger.debug("Connecting TLS to' in relay_source

    def test_tls_connection_established_is_debug(self, relay_source):
        """'TLS connection established' should use logger.debug."""
        assert 'logger.debug("TLS connection established' in relay_source

    def test_using_cached_cert_is_debug(self, relay_source):
        """'Using cached cert' should use logger.debug."""
        assert 'logger.debug("Using cached cert' in relay_source


# ---------------------------------------------------------------------------
# Verify that important events stay at INFO level
# ---------------------------------------------------------------------------


class TestInfoLevelLogs:
    """These log messages should remain at INFO level."""

    def test_generating_app_cert_is_info(self, relay_source):
        """'Generating app cert' should use logger.info."""
        assert 'logger.info("Generating app cert' in relay_source

    def test_tunnel_connect_is_info(self, relay_source):
        """'Tunnel CONNECT' should use logger.info."""
        assert 'logger.info("Tunnel CONNECT' in relay_source

    def test_stream_connected_is_info(self, relay_source):
        """'Stream %d connected' should use logger.info."""
        assert 'logger.info("Stream %d connected' in relay_source

    def test_tunnel_relay_run_started_is_info(self, relay_source):
        """'Tunnel relay run() started' should use logger.info."""
        assert 'logger.info("Tunnel relay run() started' in relay_source

    def test_cert_cache_expired_is_info(self, relay_source):
        """'Cert cache expired' should use logger.info."""
        assert 'logger.info("Cert cache expired' in relay_source


# ---------------------------------------------------------------------------
# Verify error/warning logs are present
# ---------------------------------------------------------------------------


class TestErrorLogs:
    """Error and warning messages should be present."""

    def test_connect_failed_is_error(self, relay_source):
        """'CONNECT failed' should use logger.error."""
        assert 'logger.error("CONNECT failed' in relay_source

    def test_no_teleport_ca_is_warning(self, relay_source):
        """'No Teleport CA found' should use logger.warning."""
        assert 'logger.warning("No Teleport CA found' in relay_source

    def test_tunnel_relay_error_is_error(self, relay_source):
        """'Tunnel relay error' should use logger.error."""
        assert 'logger.error("Tunnel relay error' in relay_source
