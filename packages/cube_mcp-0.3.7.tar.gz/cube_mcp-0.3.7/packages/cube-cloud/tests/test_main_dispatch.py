"""Tests for cube-cloud main.py: tool registration and dispatch."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from cube_cloud.main import _dispatch_teleport, list_tools


# ---------------------------------------------------------------------------
# Tool registration — cube_cluster_login should be in the tool list
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cube_cluster_login_registered():
    """cube_cluster_login should appear in the list of tools."""
    tools = await list_tools()
    names = {t.name for t in tools}
    assert "cube_cluster_login" in names


@pytest.mark.asyncio
async def test_cube_cluster_login_schema():
    """cube_cluster_login tool should require 'cluster' parameter."""
    tools = await list_tools()
    tool = next(t for t in tools if t.name == "cube_cluster_login")
    schema = tool.inputSchema
    assert "cluster" in schema["properties"]
    assert "cluster" in schema.get("required", [])


# ---------------------------------------------------------------------------
# Dispatch — cube_cluster_login routes to clusters.cube_cluster_login
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_teleport_routes_kube_login():
    """_dispatch_teleport should route cube_cluster_login to clusters module."""
    with patch("cube_cloud.main.clusters.cube_cluster_login", new=AsyncMock(return_value="ok")) as mock:
        result = await _dispatch_teleport("cube_cluster_login", {"cluster": "staging-int"})

    assert result == "ok"
    mock.assert_called_once_with("staging-int")


@pytest.mark.asyncio
async def test_dispatch_teleport_unknown_tool():
    """Unknown teleport tool should return error message."""
    result = await _dispatch_teleport("nonexistent_tool", {})
    assert "Unknown teleport tool" in result
