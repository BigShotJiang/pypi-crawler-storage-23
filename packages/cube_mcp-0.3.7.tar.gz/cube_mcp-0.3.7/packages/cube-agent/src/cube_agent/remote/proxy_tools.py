"""MCP tools that proxy to cube-cloud.

These tools are forwarded verbatim — the agent just passes arguments through
and returns the remote response. All the logic lives server-side.
"""

from __future__ import annotations

from mcp.types import Tool

# Tools that are proxied to cube-cloud (no local execution needed)
REMOTE_TOOLS: list[Tool] = [
    Tool(
        name="list_environments",
        description=(
            "List Apollo environments with their IDs and RIDs. "
            "Optionally filter by name substring."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "search": {
                    "type": "string",
                    "description": 'Optional name substring to filter by (case-insensitive). Example: "pep".',
                },
            },
        },
    ),
    Tool(
        name="create_environment",
        description="Create a new Apollo environment and install the Apollo Control Plane module.",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": 'Environment name (e.g. "my-cube-test"). Must be unique.',
                },
                "accreditation": {
                    "type": "string",
                    "description": "Accreditation level. Defaults to DEV.",
                    "default": "DEV",
                },
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="replicate_environment",
        description=(
            "Replicate an Apollo environment into a new or existing environment. "
            "Copies modules, entities, config overrides, and reports secrets."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Source environment name or RID.",
                },
                "target": {
                    "type": "string",
                    "description": "Target environment name. Created if it doesn't exist.",
                },
                "accreditation": {
                    "type": "string",
                    "description": "Accreditation for new environments. Defaults to DEV.",
                    "default": "DEV",
                },
            },
            "required": ["source", "target"],
        },
    ),
    Tool(
        name="install_entity",
        description="Install a Helm chart entity on an Apollo environment.",
        inputSchema={
            "type": "object",
            "properties": {
                "environment": {
                    "type": "string",
                    "description": "Target environment name or RID.",
                },
                "entity_name": {
                    "type": "string",
                    "description": "Helm chart name (e.g. mosquitto).",
                },
                "product_id": {
                    "type": "string",
                    "description": 'Product maven coordinate "groupId:artifactId".',
                },
                "k8s_namespace": {
                    "type": "string",
                    "description": "Kubernetes namespace. Defaults to default.",
                    "default": "default",
                },
                "config_overrides": {
                    "type": "string",
                    "description": "Optional JSON config overrides.",
                },
            },
            "required": ["environment", "entity_name", "product_id"],
        },
    ),
    Tool(
        name="entity_health",
        description="Get health and activity status of entities in an Apollo environment.",
        inputSchema={
            "type": "object",
            "properties": {
                "environment": {
                    "type": "string",
                    "description": "Environment name or RID.",
                },
                "entity_id": {
                    "type": "string",
                    "description": "Optional entity display name to filter by.",
                },
            },
            "required": ["environment"],
        },
    ),
    Tool(
        name="plan_details",
        description="Get detailed plan information for an entity, including tasks, events, and error logs.",
        inputSchema={
            "type": "object",
            "properties": {
                "environment": {
                    "type": "string",
                    "description": "Environment name or RID.",
                },
                "entity_name": {
                    "type": "string",
                    "description": "Entity display name (substring match).",
                },
                "plan_index": {
                    "type": "integer",
                    "description": "Which plan to show (0 = most recent). Defaults to 0.",
                    "default": 0,
                },
            },
            "required": ["environment", "entity_name"],
        },
    ),
    Tool(
        name="acr_get_token",
        description="Get an OAuth2 access token from Apollo Container Registry.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="apollo_publish_manifest",
        description="Publish an Apollo manifest YAML to make a Helm chart available for deployment.",
        inputSchema={
            "type": "object",
            "properties": {
                "manifest_yaml": {
                    "type": "string",
                    "description": "The manifest YAML content to publish.",
                },
            },
            "required": ["manifest_yaml"],
        },
    ),
    # Phase 2: Server-side Teleport + kubectl tools
    Tool(
        name="cube_status",
        description="Get the status of a Cube node (server-side kubectl via tbot).",
        inputSchema={
            "type": "object",
            "properties": {
                "cluster": {
                    "type": "string",
                    "description": "Cube cluster name (from cube_list).",
                },
            },
            "required": ["cluster"],
        },
    ),
    Tool(
        name="cube_list",
        description="List available Cube clusters accessible via server-side tbot.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="kubectl_exec",
        description=(
            "Execute a kubectl command server-side. "
            "Destructive commands (delete, apply, create, etc.) are blocked."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "cluster": {
                    "type": "string",
                    "description": "Target Cube cluster name (from cube_list).",
                },
                "command": {
                    "type": "string",
                    "description": 'kubectl command without the "kubectl" prefix. Example: "get pods -n default".',
                },
            },
            "required": ["cluster", "command"],
        },
    ),
    Tool(
        name="app_list",
        description="List available Teleport apps (server-side via tbot).",
        inputSchema={
            "type": "object",
            "properties": {
                "company": {
                    "type": "string",
                    "description": 'Optional filter by company label (e.g. "edgescaleai", "lear").',
                },
            },
        },
    ),
]

REMOTE_TOOL_NAMES = {t.name for t in REMOTE_TOOLS}
