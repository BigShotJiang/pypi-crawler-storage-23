# Cube Authentication via Teleport

## Overview

EdgescaleAI Cubes use Teleport for secure authentication. When you use `cube_login`, it:

1. Opens your browser for SSO authentication via Google/SSO
2. Generates short-lived certificates (12 hours)
3. Configures kubectl to connect to the Cube

## EdgescaleAI Teleport Setup

**Proxy URL:** `edgescaleai.teleport.sh`

### Quick Start

```bash
# Step 1: Login to Teleport (opens browser for SSO)
tsh login --proxy=edgescaleai.teleport.sh

# Step 2: List available Cubes
tsh kube ls

# Step 3: Connect to a Cube
tsh kube login <cube-name>

# Step 4: Verify connection
kubectl get nodes
```

### Available Cubes

After logging in, you can see available Cubes with `tsh kube ls`. Common Cubes include:

| Cube Name | Company/Owner |
|-----------|---------------|
| staging-int | EdgescaleAI (staging) |
| staging-pre-prod | EdgescaleAI (pre-production) |
| staging-test-v2 | EdgescaleAI (test) |
| ironmountain-v4 | EdgescaleAI |
| pep-onlogicmc610-* | EdgescaleAI (development) |

### Example Workflow

```bash
# Login to Teleport
tsh login --proxy=edgescaleai.teleport.sh

# See all available Cubes
tsh kube ls

# Connect to staging-int
tsh kube login staging-int

# Check node status
kubectl describe node
```

## Troubleshooting

- **"certificate has expired"**: Re-run `tsh login --proxy=edgescaleai.teleport.sh`
- **"cluster not found"**: Check available clusters with `tsh kube ls`
- **"permission denied"**: Contact EdgescaleAI admin for Cube access
- **Session expired mid-work**: Teleport sessions last 12 hours, re-authenticate as needed

## Checking Status

```bash
# Check current Teleport session
tsh status

# Check which Cube is currently selected
tsh kube ls | grep "\\*"
```
