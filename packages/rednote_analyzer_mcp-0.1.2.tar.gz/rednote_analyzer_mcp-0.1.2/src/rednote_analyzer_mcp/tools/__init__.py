"""RedNote MCP tools."""
