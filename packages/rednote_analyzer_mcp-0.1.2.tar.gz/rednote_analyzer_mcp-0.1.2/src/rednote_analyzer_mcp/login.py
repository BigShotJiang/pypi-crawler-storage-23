"""Login script for RedNote Analyzer MCP.

This script opens a browser window for the user to log in to xiaohongshu.com.
Cookies are saved for subsequent headless use by the MCP server.
"""

from __future__ import annotations

import asyncio
import sys


async def login() -> None:
    """Open browser for interactive login to xiaohongshu.com."""
    try:
        from rednote_analyzer_mcp.adapters.playwright import PlaywrightAdapter
    except ImportError:
        print("Error: Browser support not installed.")
        print("Run: pipx install 'rednote-analyzer-mcp[browser]'")
        print("Then: playwright install chromium")
        sys.exit(1)

    print("Opening browser for login...")
    print("Please log in to xiaohongshu.com (scan QR code or use phone number)")
    print()

    adapter = PlaywrightAdapter(headless=False)

    # Trigger browser launch and navigate to XHS
    await adapter._ensure_browser()
    assert adapter._context is not None

    page = await adapter._context.new_page()
    await page.goto("https://www.xiaohongshu.com", wait_until="domcontentloaded")

    print("Waiting for login...")
    print("After logging in, press Ctrl+C to save cookies and exit.")
    print()

    try:
        # Wait indefinitely for user to log in
        while True:
            await asyncio.sleep(2)
            cookies = await adapter._context.cookies()
            has_session = any(c["name"] == "web_session" for c in cookies)
            if has_session:
                print("Login detected! Saving cookies...")
                await adapter._save_cookies()
                print(f"Cookies saved to ~/.rednote-mcp/cookies.json")
                print()
                print("You can now close this window and use the MCP server.")
                # Keep browser open for a bit so user can see the message
                await asyncio.sleep(3)
                break
    except KeyboardInterrupt:
        print()
        print("Saving cookies...")
        await adapter._save_cookies()
        print("Done!")
    finally:
        await adapter.close()


def main() -> None:
    """Entry point for login command."""
    asyncio.run(login())


if __name__ == "__main__":
    main()
