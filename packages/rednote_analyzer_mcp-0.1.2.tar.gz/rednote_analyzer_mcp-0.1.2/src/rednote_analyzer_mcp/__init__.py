def hello() -> str:
    return "Hello from rednote-analyzer-mcp!"
