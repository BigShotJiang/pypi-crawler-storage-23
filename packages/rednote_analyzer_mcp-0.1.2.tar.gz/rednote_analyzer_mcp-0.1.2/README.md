# RedNote Analyzer MCP

[![PyPI version](https://img.shields.io/pypi/v/rednote-analyzer-mcp.svg)](https://pypi.org/project/rednote-analyzer-mcp/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

让 AI 助手能够**搜索、分析、生成**小红书内容的 MCP 服务器。

[English](#english) | [中文](#安装)

---

## 先决条件

- Python 3.11+
- [pipx](https://pipx.pypa.io/) 或 [uv](https://github.com/astral-sh/uv)
- Chromium 浏览器（安装后会自动下载）

## 安装

### 第一步：安装

```bash
pipx install "rednote-analyzer-mcp[browser]"
playwright install chromium
```

### 第二步：登录小红书（必须）

```bash
rednote-login
```

浏览器会打开小红书，扫码或手机号登录，登录成功后自动保存 Cookie。

> ⚠️ 不登录直接用会返回空结果！

### 第三步：配置 AI 工具

选择你用的工具：

#### Claude Code

在项目根目录创建 `.mcp.json` 文件：

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

或者用命令添加：

```bash
# 添加到当前项目
claude mcp add rednote-analyzer-mcp -s local \
  -e REDNOTE_ADAPTER=playwright \
  -e REDNOTE_HEADLESS=true \
  -- uvx "rednote-analyzer-mcp[browser]"

# 添加到全局（所有项目可用）
claude mcp add rednote-analyzer-mcp -s user \
  -e REDNOTE_ADAPTER=playwright \
  -e REDNOTE_HEADLESS=true \
  -- uvx "rednote-analyzer-mcp[browser]"
```

#### Claude Desktop

编辑 `claude_desktop_config.json`：

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### Cursor

创建 `.cursor/mcp.json`（项目级）或 `~/.cursor/mcp.json`（全局）：

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### VS Code (GitHub Copilot)

创建 `.vscode/mcp.json`：

```json
{
  "servers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### Windsurf

编辑 `~/.codeium/mcp_config.json`：

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### 其他工具

通用配置模式：

| 配置项 | 值 |
|-------|---|
| command | `uvx` |
| args | `["rednote-analyzer-mcp[browser]"]` |
| env | `{"REDNOTE_ADAPTER": "playwright", "REDNOTE_HEADLESS": "true"}` |

---

## 使用

配置完成后，直接跟 AI 对话：

> "搜索小红书上关于美股的热门笔记"
>
> "分析这些笔记的爆款规律"
>
> "帮我写一篇关于基金定投的小红书文案"
>
> "把这段文字改写成小红书风格"

---

## 工具列表

| 工具 | 功能 |
|------|------|
| `rednote_search_notes` | 搜索笔记 |
| `rednote_get_note_detail` | 获取笔记详情和评论 |
| `rednote_analyze_note` | 分析笔记结构和爆款元素 |
| `rednote_extract_patterns` | 批量分析，提取规律 |
| `rednote_generate_post` | 生成帖子大纲 |
| `rednote_rewrite_in_style` | 改写为小红书风格 |

---

## 常见问题

**Q: 怎么更新？**

```bash
pipx upgrade rednote-analyzer-mcp
```

**Q: 搜索返回空结果？**

A: 没有登录。运行 `rednote-login` 登录一次。

**Q: Cookie 过期了？**

A: 重新运行 `rednote-login`。

**Q: 怎么查看 MCP 是否连接成功？**

A: Claude Code 运行 `claude mcp list`，其他工具看各自的 MCP 状态面板。

---

## License

MIT | [开发指南](CONTRIBUTING.md)

---

# English

## Prerequisites

- Python 3.11+
- [pipx](https://pipx.pypa.io/) or [uv](https://github.com/astral-sh/uv)
- Chromium browser (auto-downloaded during install)

## Installation

### Step 1: Install

```bash
pipx install "rednote-analyzer-mcp[browser]"
playwright install chromium
```

### Step 2: Log in to Xiaohongshu (required)

```bash
rednote-login
```

A browser will open. Log in with your phone number or scan QR code. Cookies are saved automatically after login.

> ⚠️ Skipping login will result in empty search results!

### Step 3: Configure your AI tool

Choose your tool:

#### Claude Code

Create `.mcp.json` in your project root:

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

Or use CLI:

```bash
# Add to current project
claude mcp add rednote-analyzer-mcp -s local \
  -e REDNOTE_ADAPTER=playwright \
  -e REDNOTE_HEADLESS=true \
  -- uvx "rednote-analyzer-mcp[browser]"

# Add globally (all projects)
claude mcp add rednote-analyzer-mcp -s user \
  -e REDNOTE_ADAPTER=playwright \
  -e REDNOTE_HEADLESS=true \
  -- uvx "rednote-analyzer-mcp[browser]"
```

#### Claude Desktop

Edit `claude_desktop_config.json`:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### Cursor

Create `.cursor/mcp.json` (project) or `~/.cursor/mcp.json` (global):

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### VS Code (GitHub Copilot)

Create `.vscode/mcp.json`:

```json
{
  "servers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### Windsurf

Edit `~/.codeium/mcp_config.json`:

```json
{
  "mcpServers": {
    "rednote-analyzer-mcp": {
      "command": "uvx",
      "args": ["rednote-analyzer-mcp[browser]"],
      "env": {
        "REDNOTE_ADAPTER": "playwright",
        "REDNOTE_HEADLESS": "true"
      }
    }
  }
}
```

#### Other Tools

General config pattern:

| Key | Value |
|-----|-------|
| command | `uvx` |
| args | `["rednote-analyzer-mcp[browser]"]` |
| env | `{"REDNOTE_ADAPTER": "playwright", "REDNOTE_HEADLESS": "true"}` |

---

## Usage

After setup, talk to your AI:

> "Search for trending posts about US stocks (美股) on RedNote"
>
> "Analyze the viral patterns of these notes"
>
> "Help me write a RedNote post about ETF investing"
>
> "Rewrite this text in RedNote style"

---

## Tools

| Tool | Function |
|------|----------|
| `rednote_search_notes` | Search notes |
| `rednote_get_note_detail` | Get note details and comments |
| `rednote_analyze_note` | Analyze note structure and viral elements |
| `rednote_extract_patterns` | Batch analyze, extract patterns |
| `rednote_generate_post` | Generate post outline |
| `rednote_rewrite_in_style` | Rewrite in RedNote style |

---

## FAQ

**Q: How to update?**

```bash
pipx upgrade rednote-analyzer-mcp
```

**Q: Search returns empty results?**

A: You haven't logged in. Run `rednote-login` to log in.

**Q: Cookie expired?**

A: Run `rednote-login` again.

**Q: How to check if MCP is connected?**

A: Claude Code: run `claude mcp list`. Other tools: check their MCP status panel.

---

## License

MIT | [Contributing](CONTRIBUTING.md)
