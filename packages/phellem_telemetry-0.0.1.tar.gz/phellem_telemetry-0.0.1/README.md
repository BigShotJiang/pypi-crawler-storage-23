# phellem-telemetry

Telemetry module for the Phellem security framework

Under active development by [Casparian Systems Inc](https://casparian.systems).

## License

Proprietary — Copyright (c) 2026 Casparian Systems Inc. All rights reserved.
See [LICENSE](LICENSE) for details.
