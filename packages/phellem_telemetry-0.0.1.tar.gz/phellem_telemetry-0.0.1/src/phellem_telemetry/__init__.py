# Copyright 2026 Casparian Systems Inc - All rights reserved.
# This package is under active development.
__version__ = "0.0.1"
