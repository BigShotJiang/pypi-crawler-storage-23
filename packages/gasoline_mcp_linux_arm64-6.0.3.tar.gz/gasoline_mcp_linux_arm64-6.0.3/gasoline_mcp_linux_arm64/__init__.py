"""Platform-specific Gasoline binary for linux-arm64."""

__version__ = "6.0.3"
