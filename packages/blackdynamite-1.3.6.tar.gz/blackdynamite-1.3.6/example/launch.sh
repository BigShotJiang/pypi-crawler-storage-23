#!/bin/bash

echo 'here is the job'
echo __BLACKDYNAMITE__id__
echo __BLACKDYNAMITE__param1__
echo __BLACKDYNAMITE__param2__
echo __BLACKDYNAMITE__param3__
echo __BLACKDYNAMITE__compiler__

python3 ./doIt.py

canYouDigIt runs quantity --quantity_id test_quantity --value 1 --step 1 --t
canYouDigIt runs quantity --quantity_id test_quantity_str --value toto --step 1 --t
