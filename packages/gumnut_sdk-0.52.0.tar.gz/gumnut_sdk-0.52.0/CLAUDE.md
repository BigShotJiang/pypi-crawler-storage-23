Refer to @AGENTS.md for instructions.
