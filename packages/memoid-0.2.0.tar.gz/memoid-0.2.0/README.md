# Memoid Python SDK

Python SDK for [Memoid](https://memoid.dev) - AI Memory Layer for intelligent applications.

## Installation

```bash
pip install memoid
```

## Quick Start

```python
from memoid import MemoryClient

client = MemoryClient("your-api-key")

# Add memory from conversation
memories = client.add(
    messages=[
        {"role": "user", "content": "I'm vegetarian and love Italian food"},
        {"role": "assistant", "content": "Great! I'll remember that."}
    ],
    user_id="user_123"
)

# Search memories
results = client.search(
    query="What dietary restrictions does the user have?",
    user_id="user_123"
)

for result in results:
    print(f"{result.memory} (score: {result.score})")
```

## Async Support

```python
from memoid import AsyncMemoryClient

async with AsyncMemoryClient("your-api-key") as client:
    memories = await client.add(
        messages=[{"role": "user", "content": "My favorite color is blue"}],
        user_id="user_123"
    )

    results = await client.search(query="favorite color", user_id="user_123")
```

## API Reference

### MemoryClient

#### `add(messages, user_id=None, agent_id=None, metadata=None)`
Add memories from a conversation.

#### `get(memory_id)`
Get a specific memory by ID.

#### `get_all(user_id=None, agent_id=None, limit=100, offset=0)`
Get all memories with optional filtering.

#### `search(query, user_id=None, agent_id=None, limit=10)`
Search memories using natural language.

#### `update(memory_id, memory, metadata=None)`
Update a memory.

#### `delete(memory_id)`
Delete a memory.

#### `delete_all(user_id=None, agent_id=None)`
Delete all memories with optional filtering.

#### `get_graph(user_id=None, agent_id=None)`
Get the knowledge graph.

## License

MIT
