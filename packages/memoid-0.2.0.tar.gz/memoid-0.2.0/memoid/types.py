from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class Memory:
    id: str
    memory: str
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    run_id: Optional[str] = None
    project_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Memory":
        return cls(
            id=data.get("id", ""),
            memory=data.get("memory", ""),
            user_id=data.get("user_id"),
            agent_id=data.get("agent_id"),
            run_id=data.get("run_id"),
            project_id=data.get("project_id"),
            metadata=data.get("metadata"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
        )


@dataclass
class SearchResult:
    id: str
    memory: str
    score: float
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    run_id: Optional[str] = None
    project_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SearchResult":
        return cls(
            id=data.get("id", ""),
            memory=data.get("memory", ""),
            score=data.get("score", 0.0),
            user_id=data.get("user_id"),
            agent_id=data.get("agent_id"),
            run_id=data.get("run_id"),
            project_id=data.get("project_id"),
            metadata=data.get("metadata"),
        )


@dataclass
class MemoryHistory:
    id: str
    memory_id: str
    event: str
    prev_memory: Optional[str] = None
    new_memory: Optional[str] = None
    created_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryHistory":
        return cls(
            id=data.get("id", ""),
            memory_id=data.get("memory_id", ""),
            event=data.get("event", ""),
            prev_memory=data.get("prev_memory"),
            new_memory=data.get("new_memory"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
        )


@dataclass
class Project:
    id: str
    name: str
    custom_instructions: Optional[str] = None
    custom_categories: Optional[List[str]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Project":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            custom_instructions=data.get("custom_instructions"),
            custom_categories=data.get("custom_categories"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
        )


@dataclass
class UsageStats:
    total_memories: int = 0
    total_searches: int = 0
    total_api_calls: int = 0
    avg_latency_ms: float = 0.0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UsageStats":
        return cls(
            total_memories=data.get("total_memories", 0),
            total_searches=data.get("total_searches", 0),
            total_api_calls=data.get("total_api_calls", 0),
            avg_latency_ms=data.get("avg_latency_ms", 0.0),
        )


@dataclass
class DailyUsage:
    date: str
    api_calls: int = 0
    memories_added: int = 0
    searches: int = 0
    avg_latency_ms: float = 0.0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DailyUsage":
        return cls(
            date=data.get("date", ""),
            api_calls=data.get("api_calls", 0),
            memories_added=data.get("memories_added", 0),
            searches=data.get("searches", 0),
            avg_latency_ms=data.get("avg_latency_ms", 0.0),
        )


@dataclass
class GraphEntity:
    id: str
    name: str
    type: str
    metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GraphEntity":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            type=data.get("type", ""),
            metadata=data.get("metadata"),
        )


@dataclass
class GraphRelation:
    source: str
    target: str
    relation: str
    metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GraphRelation":
        return cls(
            source=data.get("source", ""),
            target=data.get("target", ""),
            relation=data.get("relation", ""),
            metadata=data.get("metadata"),
        )
