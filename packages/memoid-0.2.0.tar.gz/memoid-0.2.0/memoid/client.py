import httpx
from typing import List, Optional, Dict, Any
from .types import (
    Memory, SearchResult, MemoryHistory,
    Project, UsageStats, DailyUsage,
    GraphEntity, GraphRelation,
)


class MemoryClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.memoid.dev",
        timeout: float = 30.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    # ── Memories ──────────────────────────────────────────────────────────────

    def add(
        self,
        messages: List[Dict[str, str]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        infer: bool = True,
        extract_graph: bool = False,
    ) -> List[Memory]:
        payload: Dict[str, Any] = {"messages": messages, "infer": infer, "extract_graph": extract_graph}
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id
        if run_id:
            payload["run_id"] = run_id
        if project_id:
            payload["project_id"] = project_id
        if metadata:
            payload["metadata"] = metadata

        response = self._client.post("/v1/memories", json=payload)
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    def get(self, memory_id: str) -> Memory:
        response = self._client.get(f"/v1/memories/{memory_id}")
        response.raise_for_status()
        return Memory.from_dict(response.json())

    def get_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id
        if run_id:
            params["run_id"] = run_id
        if project_id:
            params["project_id"] = project_id

        response = self._client.get("/v1/memories", params=params)
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    def search(
        self,
        query: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        limit: int = 10,
        threshold: Optional[float] = None,
    ) -> List[SearchResult]:
        payload: Dict[str, Any] = {"query": query, "limit": limit}
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id
        if run_id:
            payload["run_id"] = run_id
        if project_id:
            payload["project_id"] = project_id
        if threshold is not None:
            payload["threshold"] = threshold

        response = self._client.post("/v1/search", json=payload)
        response.raise_for_status()
        data = response.json()
        return [SearchResult.from_dict(r) for r in data.get("results", [])]

    def update(
        self,
        memory_id: str,
        memory: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        payload: Dict[str, Any] = {"memory": memory}
        if metadata:
            payload["metadata"] = metadata

        response = self._client.put(f"/v1/memories/{memory_id}", json=payload)
        response.raise_for_status()
        return Memory.from_dict(response.json())

    def delete(self, memory_id: str) -> bool:
        response = self._client.delete(f"/v1/memories/{memory_id}")
        response.raise_for_status()
        return True

    def delete_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> bool:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id
        if run_id:
            params["run_id"] = run_id
        if project_id:
            params["project_id"] = project_id

        response = self._client.delete("/v1/memories", params=params)
        response.raise_for_status()
        return True

    def history(self, memory_id: str) -> List[MemoryHistory]:
        response = self._client.get(f"/v1/memories/{memory_id}/history")
        response.raise_for_status()
        data = response.json()
        return [MemoryHistory.from_dict(h) for h in data.get("history", [])]

    def batch_update(self, memories: List[Dict[str, Any]]) -> List[Memory]:
        """Update multiple memories. Each dict: {id, memory, metadata?}"""
        response = self._client.put("/v1/batch", json={"memories": memories})
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    def batch_delete(
        self,
        memory_ids: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> bool:
        payload: Dict[str, Any] = {}
        if memory_ids:
            payload["memory_ids"] = memory_ids
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id

        response = self._client.request("DELETE", "/v1/batch", json=payload)
        response.raise_for_status()
        return True

    # ── Projects ──────────────────────────────────────────────────────────────

    def get_projects(self) -> List[Project]:
        response = self._client.get("/v1/projects")
        response.raise_for_status()
        data = response.json()
        return [Project.from_dict(p) for p in data.get("projects", [])]

    def create_project(
        self,
        name: str,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
    ) -> Project:
        payload: Dict[str, Any] = {"name": name}
        if custom_instructions:
            payload["custom_instructions"] = custom_instructions
        if custom_categories:
            payload["custom_categories"] = custom_categories

        response = self._client.post("/v1/projects", json=payload)
        response.raise_for_status()
        return Project.from_dict(response.json())

    def update_project(
        self,
        project_id: str,
        name: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
    ) -> Project:
        payload: Dict[str, Any] = {}
        if name:
            payload["name"] = name
        if custom_instructions is not None:
            payload["custom_instructions"] = custom_instructions
        if custom_categories is not None:
            payload["custom_categories"] = custom_categories

        response = self._client.patch(f"/v1/projects/{project_id}", json=payload)
        response.raise_for_status()
        return Project.from_dict(response.json())

    def delete_project(self, project_id: str) -> bool:
        response = self._client.delete(f"/v1/projects/{project_id}")
        response.raise_for_status()
        return True

    # ── Graph ─────────────────────────────────────────────────────────────────

    def get_graph(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id

        response = self._client.get("/v1/graph", params=params)
        response.raise_for_status()
        data = response.json()
        return {
            "entities": [GraphEntity.from_dict(e) for e in data.get("entities", [])],
            "relations": [GraphRelation.from_dict(r) for r in data.get("relations", [])],
        }

    def get_entities(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> List[GraphEntity]:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id

        response = self._client.get("/v1/entities", params=params)
        response.raise_for_status()
        data = response.json()
        return [GraphEntity.from_dict(e) for e in data.get("entities", [])]

    # ── Usage ─────────────────────────────────────────────────────────────────

    def get_usage_stats(self) -> UsageStats:
        response = self._client.get("/v1/usage/stats")
        response.raise_for_status()
        return UsageStats.from_dict(response.json())

    def get_usage_daily(self, days: int = 30) -> List[DailyUsage]:
        response = self._client.get("/v1/usage/daily", params={"days": days})
        response.raise_for_status()
        data = response.json()
        return [DailyUsage.from_dict(d) for d in data.get("daily", [])]


class AsyncMemoryClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.memoid.dev",
        timeout: float = 30.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    # ── Memories ──────────────────────────────────────────────────────────────

    async def add(
        self,
        messages: List[Dict[str, str]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        infer: bool = True,
        extract_graph: bool = False,
    ) -> List[Memory]:
        payload: Dict[str, Any] = {"messages": messages, "infer": infer, "extract_graph": extract_graph}
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id
        if run_id:
            payload["run_id"] = run_id
        if project_id:
            payload["project_id"] = project_id
        if metadata:
            payload["metadata"] = metadata

        response = await self._client.post("/v1/memories", json=payload)
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    async def get(self, memory_id: str) -> Memory:
        response = await self._client.get(f"/v1/memories/{memory_id}")
        response.raise_for_status()
        return Memory.from_dict(response.json())

    async def get_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Memory]:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id
        if run_id:
            params["run_id"] = run_id
        if project_id:
            params["project_id"] = project_id

        response = await self._client.get("/v1/memories", params=params)
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    async def search(
        self,
        query: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
        limit: int = 10,
        threshold: Optional[float] = None,
    ) -> List[SearchResult]:
        payload: Dict[str, Any] = {"query": query, "limit": limit}
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id
        if run_id:
            payload["run_id"] = run_id
        if project_id:
            payload["project_id"] = project_id
        if threshold is not None:
            payload["threshold"] = threshold

        response = await self._client.post("/v1/search", json=payload)
        response.raise_for_status()
        data = response.json()
        return [SearchResult.from_dict(r) for r in data.get("results", [])]

    async def update(
        self,
        memory_id: str,
        memory: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        payload: Dict[str, Any] = {"memory": memory}
        if metadata:
            payload["metadata"] = metadata

        response = await self._client.put(f"/v1/memories/{memory_id}", json=payload)
        response.raise_for_status()
        return Memory.from_dict(response.json())

    async def delete(self, memory_id: str) -> bool:
        response = await self._client.delete(f"/v1/memories/{memory_id}")
        response.raise_for_status()
        return True

    async def delete_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> bool:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id
        if run_id:
            params["run_id"] = run_id
        if project_id:
            params["project_id"] = project_id

        response = await self._client.delete("/v1/memories", params=params)
        response.raise_for_status()
        return True

    async def history(self, memory_id: str) -> List[MemoryHistory]:
        response = await self._client.get(f"/v1/memories/{memory_id}/history")
        response.raise_for_status()
        data = response.json()
        return [MemoryHistory.from_dict(h) for h in data.get("history", [])]

    async def batch_update(self, memories: List[Dict[str, Any]]) -> List[Memory]:
        """Update multiple memories. Each dict: {id, memory, metadata?}"""
        response = await self._client.put("/v1/batch", json={"memories": memories})
        response.raise_for_status()
        data = response.json()
        return [Memory.from_dict(m) for m in data.get("memories", [])]

    async def batch_delete(
        self,
        memory_ids: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> bool:
        payload: Dict[str, Any] = {}
        if memory_ids:
            payload["memory_ids"] = memory_ids
        if user_id:
            payload["user_id"] = user_id
        if agent_id:
            payload["agent_id"] = agent_id

        response = await self._client.request("DELETE", "/v1/batch", json=payload)
        response.raise_for_status()
        return True

    # ── Projects ──────────────────────────────────────────────────────────────

    async def get_projects(self) -> List[Project]:
        response = await self._client.get("/v1/projects")
        response.raise_for_status()
        data = response.json()
        return [Project.from_dict(p) for p in data.get("projects", [])]

    async def create_project(
        self,
        name: str,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
    ) -> Project:
        payload: Dict[str, Any] = {"name": name}
        if custom_instructions:
            payload["custom_instructions"] = custom_instructions
        if custom_categories:
            payload["custom_categories"] = custom_categories

        response = await self._client.post("/v1/projects", json=payload)
        response.raise_for_status()
        return Project.from_dict(response.json())

    async def update_project(
        self,
        project_id: str,
        name: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
    ) -> Project:
        payload: Dict[str, Any] = {}
        if name:
            payload["name"] = name
        if custom_instructions is not None:
            payload["custom_instructions"] = custom_instructions
        if custom_categories is not None:
            payload["custom_categories"] = custom_categories

        response = await self._client.patch(f"/v1/projects/{project_id}", json=payload)
        response.raise_for_status()
        return Project.from_dict(response.json())

    async def delete_project(self, project_id: str) -> bool:
        response = await self._client.delete(f"/v1/projects/{project_id}")
        response.raise_for_status()
        return True

    # ── Graph ─────────────────────────────────────────────────────────────────

    async def get_graph(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id

        response = await self._client.get("/v1/graph", params=params)
        response.raise_for_status()
        data = response.json()
        return {
            "entities": [GraphEntity.from_dict(e) for e in data.get("entities", [])],
            "relations": [GraphRelation.from_dict(r) for r in data.get("relations", [])],
        }

    async def get_entities(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> List[GraphEntity]:
        params: Dict[str, Any] = {}
        if user_id:
            params["user_id"] = user_id
        if agent_id:
            params["agent_id"] = agent_id

        response = await self._client.get("/v1/entities", params=params)
        response.raise_for_status()
        data = response.json()
        return [GraphEntity.from_dict(e) for e in data.get("entities", [])]

    # ── Usage ─────────────────────────────────────────────────────────────────

    async def get_usage_stats(self) -> UsageStats:
        response = await self._client.get("/v1/usage/stats")
        response.raise_for_status()
        return UsageStats.from_dict(response.json())

    async def get_usage_daily(self, days: int = 30) -> List[DailyUsage]:
        response = await self._client.get("/v1/usage/daily", params={"days": days})
        response.raise_for_status()
        data = response.json()
        return [DailyUsage.from_dict(d) for d in data.get("daily", [])]
