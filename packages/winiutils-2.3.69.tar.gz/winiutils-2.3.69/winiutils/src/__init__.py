"""src package.

This package contains the source code for the winiutils library.
"""
