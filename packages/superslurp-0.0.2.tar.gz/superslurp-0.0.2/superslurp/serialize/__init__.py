from __future__ import annotations

__all__ = ["make_json_serializable"]

from superslurp.serialize.json_dump import make_json_serializable
