from __future__ import annotations

__all__ = ["generate_report", "main", "parse_superu_receipt"]

from superslurp.__main__ import generate_report, main, parse_superu_receipt
