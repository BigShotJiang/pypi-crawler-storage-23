from __future__ import annotations

__all__ = ["parse_text_v1"]

from superslurp.parse.v1.parse_text import parse_text_v1
