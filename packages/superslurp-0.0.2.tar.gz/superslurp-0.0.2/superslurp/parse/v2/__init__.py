from __future__ import annotations

__all__ = ["parse_text_v2"]

from superslurp.parse.v2.parse_text import parse_text_v2
