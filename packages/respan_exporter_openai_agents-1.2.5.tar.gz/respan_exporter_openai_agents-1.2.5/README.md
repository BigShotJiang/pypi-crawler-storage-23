# Respan Exporter for OpenAI Agents SDK

**[respan.ai](https://respan.ai)** | **[Documentation](https://docs.respan.ai)** | **[PyPI](https://pypi.org/project/respan-exporter-openai-agents/)**

Exporter for OpenAI Agents telemetry to Respan.