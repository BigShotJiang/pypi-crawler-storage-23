"""
HYDRA-32: 32-bit Provenance Encoding with Gradient Taint Model.

============================================================================
32-bit layout
============================================================================

    Universal header (bits 31-26) — identical in ALL modes:
    ┌─────────┬───────┬──────────┐
    │ mode:2  │ T:1   │ depth:3  │  6 bits
    └─────────┴───────┴──────────┘

    T (taint):  1 = derives from protected attribute. OR propagation.
    depth:      Derivation distance from source (0-7, saturates).
                max(a, b) + 1 for binary ops.

    risk(p) = taint(p) * 1/(1 + depth(p))

    Payload (bits 25-0) — mode-specific:

    Mode 00 (0-1 pairs): [pair_data:10 | entity:8 | chain:8]
    Mode 01 (2 pairs):   [pair_index:17 | entity:5 | chain:4]
    Mode 10 (3 pairs):   [pair_combo:25 | reserved:1]
    Mode 11 (4+ pairs):  [signature:26]

============================================================================
Provenance algebra
============================================================================

    Pairs:   union        Entity: XOR       Chain: hash combine
    Taint:   OR           Depth:  max+1 (saturating)

    Taint propagation: taint(f(a, b)) = taint(a) ∨ taint(b)
"""

from dataclasses import dataclass, field
from typing import Dict, Set, List, Tuple, Optional, FrozenSet, Any, NamedTuple
import math
import numpy as np
import pandas as pd


# =============================================================================
# Constants
# =============================================================================

MAX_PAIRS = 512  # 9-bit pair IDs (0-511)

# Mode constants (bits 31-30)
MODE_01    = 0b00  # 0-1 pairs: max precision
MODE_2     = 0b01  # 2 pairs:   combinatorial
MODE_3     = 0b10  # 3 pairs:   combinatorial (NEW in HYDRA-32)
MODE_DENSE = 0b11  # 4+ pairs:  registry signature

# Header bit positions
HEADER_BITS     = 6   # mode(2) + taint(1) + depth(3)
PAYLOAD_BITS    = 26  # 32 - 6
MODE_SHIFT      = 30  # bits 31-30
TAINT_SHIFT     = 29  # bit 29
DEPTH_SHIFT     = 26  # bits 28-26
PAYLOAD_MASK    = (1 << PAYLOAD_BITS) - 1  # 0x3FFFFFF

# Mode 00 payload: [pair_data:10 | entity:8 | chain:8]
MODE_01_PAIR_BITS   = 10
MODE_01_ENTITY_BITS = 8   # 256 buckets (was 6/64 in HYDRA-24)
MODE_01_CHAIN_BITS  = 8   # 256 buckets (was 6/64 in HYDRA-24)

# Mode 01 payload: [pair_index:17 | entity:5 | chain:4]
MODE_2_PAIR_BITS    = 17
MODE_2_ENTITY_BITS  = 5   # 32 buckets (was 3/8 in HYDRA-24)
MODE_2_CHAIN_BITS   = 4   # 16 buckets (was 2/4 in HYDRA-24)

# Mode 10 payload: [pair_combo:25 | reserved:1]  (NEW)
MODE_3_PAIR_BITS    = 25  # C(512,3) = 22,238,720 < 2^25 = 33,554,432

# Mode 11 payload: [signature:26]
MODE_DENSE_SIG_BITS = 26  # ~67M hash space (was 22/~4M in HYDRA-24)

# Taint/depth constants
MAX_DEPTH = 7  # 3 bits, saturates


# =============================================================================
# Operation Codes for Chain Hash
# =============================================================================

class OpCode:
    """Operation codes for chain hash computation."""
    RAW     = 0
    ADD     = 1
    SUB     = 2
    MUL     = 3
    DIV     = 4
    NEG     = 5
    CLIP    = 6
    FILL    = 7
    MAP     = 8
    CMP     = 9
    MERGE   = 10
    AGG     = 11
    CUSTOM  = 15


# =============================================================================
# Provenance Info (decoded result)
# =============================================================================

class ProvenanceInfo(NamedTuple):
    """Full decoded provenance — includes taint and depth from header."""
    pairs: Set[int]
    entity: int
    chain: int
    taint: bool
    depth: int
    mode: str


# =============================================================================
# Core Encoding Functions
# =============================================================================

def _binomial(n: int, k: int) -> int:
    """Compute C(n, k) using iterative method. O(k) time, no overflow risk."""
    if k < 0 or k > n:
        return 0
    if k == 0 or k == n:
        return 1
    k = min(k, n - k)
    result = 1
    for i in range(k):
        result = result * (n - i) // (i + 1)
    return result


# -- Mode 00: 0-1 pairs -------------------------------------------------------

def _encode_pair_01(pairs: Set[int]) -> int:
    """Encode 0-1 pairs to 10 bits. 0=empty, 1+pair_id=single."""
    if len(pairs) == 0:
        return 0
    if len(pairs) == 1:
        return 1 + next(iter(pairs))
    raise ValueError("_encode_pair_01 only handles 0-1 pairs")


def _decode_pair_01(data: int) -> Set[int]:
    """Decode 10-bit pair data to 0-1 pairs."""
    if data == 0:
        return set()
    return {data - 1}


# -- Mode 01: exactly 2 pairs -------------------------------------------------

def _encode_pair_2(pairs: Set[int]) -> int:
    """Encode 2 pairs via combinatorial number system. Bijective, exact."""
    if len(pairs) != 2:
        raise ValueError("_encode_pair_2 requires exactly 2 pairs")
    p0, p1 = sorted(pairs)
    return _binomial(p0, 1) + _binomial(p1, 2)


def _decode_pair_2(index: int) -> Set[int]:
    """Decode combinatorial index to exactly 2 pairs."""
    p1 = 1
    while _binomial(p1 + 1, 2) <= index:
        p1 += 1
    p0 = index - _binomial(p1, 2)
    return {p0, p1}


# -- Mode 10: exactly 3 pairs -------------------------------------------------

def _encode_pair_3(pairs: Set[int]) -> int:
    """Encode exactly 3 pairs via combinatorial number system."""
    if len(pairs) != 3:
        raise ValueError("_encode_pair_3 requires exactly 3 pairs")
    c0, c1, c2 = sorted(pairs)
    return _binomial(c0, 1) + _binomial(c1, 2) + _binomial(c2, 3)


def _decode_pair_3(index: int) -> Set[int]:
    """Decode combinatorial index to exactly 3 pairs."""
    # Find c2
    c2 = 2
    while _binomial(c2 + 1, 3) <= index:
        c2 += 1
    index -= _binomial(c2, 3)

    # Find c1
    c1 = 1
    while _binomial(c1 + 1, 2) <= index:
        c1 += 1
    c0 = index - _binomial(c1, 2)

    return {c0, c1, c2}


# -- Mode 11: signature for 4+ pairs ------------------------------------------

def _compute_signature(pairs: FrozenSet[int], entity: int = 0, chain: int = 0) -> int:
    """Compute 26-bit signature with avalanche mixing for registry lookup."""
    h = 0
    for p in sorted(pairs):
        h = ((h * 31) + p) & 0xFFFFFFFF

    h = ((h * 31) + entity) & 0xFFFFFFFF
    h = ((h * 31) + chain) & 0xFFFFFFFF

    # Avalanche finalization (MurmurHash3-style)
    h ^= h >> 16
    h = (h * 0x85EBCA6B) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * 0xC2B2AE35) & 0xFFFFFFFF
    h ^= h >> 16

    return h & ((1 << MODE_DENSE_SIG_BITS) - 1)


# -- Entity hashing ------------------------------------------------------------

def _hash_entity(row_id: Any) -> int:
    """Hash a row identifier to entity bits."""
    if row_id is None:
        return 0
    return hash(row_id) & 0xFFFFFFFF


# -- Chain combination ---------------------------------------------------------

def _combine_chains(chain_a: int, chain_b: int, op: int, bits: int) -> int:
    """Combine two chain hashes with an operation code."""
    combined = chain_a ^ chain_b
    result = ((combined * 31) + op) & 0xFFFFFFFF
    return result % (1 << bits) if bits > 0 else 0


def _update_chain(chain: int, op: int, bits: int) -> int:
    """Update chain hash with a unary operation."""
    result = ((chain * 31) + op) & 0xFFFFFFFF
    return result % (1 << bits) if bits > 0 else 0


# =============================================================================
# Dense Registry Entry
# =============================================================================

@dataclass
class DenseEntry:
    """Registry entry for 4+ pair provenances (entity + chain stored here)."""
    pairs: FrozenSet[int]
    entity: int
    chain: int


# =============================================================================
# Provenance Tracker
# =============================================================================

class ProvenanceTracker:
    """HYDRA-32 provenance tracker with gradient taint model."""

    def __init__(self):
        # Pair ID registry (bidirectional)
        self._id_to_name: Dict[int, Tuple[str, str]] = {}
        self._name_to_id: Dict[Tuple[str, str], int] = {}
        self._next_id = 0

        # Dense registry (for 4+ pairs only)
        self._dense: Dict[int, DenseEntry] = {}

        # Protected source tracking
        self._protected_tables: Set[str] = set()
        self._protected_columns: Set[Tuple[str, str]] = set()

    # -------------------------------------------------------------------------
    # Registration
    # -------------------------------------------------------------------------

    def register(self, table: str, column: str, protected: bool = False) -> int:
        """Register a (table, column) pair and return its ID (0-511).

        Args:
            table: Source table/file name
            column: Column name
            protected: If True, marks the source as a protected attribute.
                       Values derived from this source will carry taint=1.
        """
        key = (table, column)
        if key in self._name_to_id:
            if protected:
                self._protected_columns.add(key)
            return self._name_to_id[key]

        if self._next_id >= MAX_PAIRS:
            raise ValueError(f"Maximum {MAX_PAIRS} pairs supported")

        pair_id = self._next_id
        self._id_to_name[pair_id] = key
        self._name_to_id[key] = pair_id
        self._next_id += 1

        if protected:
            self._protected_columns.add(key)

        return pair_id

    def register_table(self, table: str, columns: List[str],
                       protected: bool = False) -> List[int]:
        """Register all columns for a table. Returns list of pair IDs."""
        return [self.register(table, col, protected) for col in columns]

    def get_name(self, pair_id: int) -> Optional[Tuple[str, str]]:
        """Get (table, column) for a pair ID."""
        return self._id_to_name.get(pair_id)

    def get_id(self, table: str, column: str) -> Optional[int]:
        """Get pair ID for a (table, column)."""
        return self._name_to_id.get((table, column))

    def is_protected(self, table: str, column: str = None) -> bool:
        """Check if a table or specific column is a protected attribute."""
        if table in self._protected_tables:
            return True
        if column and (table, column) in self._protected_columns:
            return True
        return False

    # -------------------------------------------------------------------------
    # Encoding
    # -------------------------------------------------------------------------

    def encode(self, pairs: Set[int], entity: int = 0, chain: int = 0,
               taint: bool = False, depth: int = 0) -> int:
        """
        Encode provenance to 32-bit value.

        Args:
            pairs: Set of source pair IDs (0-511)
            entity: Row identifier hash (truncated to fit mode)
            chain: Computation path hash (truncated to fit mode)
            taint: True if value derives from protected data
            depth: Derivation distance from source (0-7, saturates)

        Returns:
            32-bit provenance value
        """
        n = len(pairs)
        depth_3 = min(depth, MAX_DEPTH)
        taint_1 = 1 if taint else 0

        if n <= 1:
            pair_data = _encode_pair_01(pairs)
            entity_v = entity % (1 << MODE_01_ENTITY_BITS)
            chain_v = chain % (1 << MODE_01_CHAIN_BITS)
            return ((MODE_01 << MODE_SHIFT) |
                    (taint_1 << TAINT_SHIFT) |
                    (depth_3 << DEPTH_SHIFT) |
                    (pair_data << 16) |
                    (entity_v << 8) |
                    chain_v)

        elif n == 2:
            pair_data = _encode_pair_2(pairs)
            entity_v = entity % (1 << MODE_2_ENTITY_BITS)
            chain_v = chain % (1 << MODE_2_CHAIN_BITS)
            return ((MODE_2 << MODE_SHIFT) |
                    (taint_1 << TAINT_SHIFT) |
                    (depth_3 << DEPTH_SHIFT) |
                    (pair_data << 9) |
                    (entity_v << 4) |
                    chain_v)

        elif n == 3:
            pair_data = _encode_pair_3(pairs)
            return ((MODE_3 << MODE_SHIFT) |
                    (taint_1 << TAINT_SHIFT) |
                    (depth_3 << DEPTH_SHIFT) |
                    (pair_data << 1) |
                    0)  # reserved bit

        else:
            # 4+ pairs: registry-backed
            frozen = frozenset(pairs)
            sig = _compute_signature(frozen, entity, chain)
            self._dense[sig] = DenseEntry(pairs=frozen, entity=entity, chain=chain)
            return ((MODE_DENSE << MODE_SHIFT) |
                    (taint_1 << TAINT_SHIFT) |
                    (depth_3 << DEPTH_SHIFT) |
                    sig)

    # -------------------------------------------------------------------------
    # Decoding
    # -------------------------------------------------------------------------

    def decode(self, provenance: int) -> Set[int]:
        """Decode to pair IDs only (legacy API)."""
        return self.decode_full(provenance).pairs

    def decode_full(self, provenance: int) -> ProvenanceInfo:
        """Decode 32-bit provenance to full ProvenanceInfo."""
        mode = (provenance >> MODE_SHIFT) & 0x3
        taint = bool((provenance >> TAINT_SHIFT) & 1)
        depth = (provenance >> DEPTH_SHIFT) & 0x7
        payload = provenance & PAYLOAD_MASK

        if mode == MODE_01:
            pair_data = (payload >> 16) & 0x3FF
            entity = (payload >> 8) & 0xFF
            chain = payload & 0xFF
            pairs = _decode_pair_01(pair_data)
            mode_name = "EXACT-0" if len(pairs) == 0 else "EXACT-1"
            return ProvenanceInfo(pairs, entity, chain, taint, depth, mode_name)

        elif mode == MODE_2:
            pair_data = (payload >> 9) & 0x1FFFF
            entity = (payload >> 4) & 0x1F
            chain = payload & 0xF
            pairs = _decode_pair_2(pair_data)
            return ProvenanceInfo(pairs, entity, chain, taint, depth, "EXACT-2")

        elif mode == MODE_3:
            pair_data = (payload >> 1) & 0x1FFFFFF
            pairs = _decode_pair_3(pair_data)
            # No inline entity/chain in mode 10 — all bits used for pairs
            return ProvenanceInfo(pairs, 0, 0, taint, depth, "EXACT-3")

        elif mode == MODE_DENSE:
            sig = payload & ((1 << MODE_DENSE_SIG_BITS) - 1)
            entry = self._dense.get(sig)
            if entry:
                return ProvenanceInfo(set(entry.pairs), entry.entity,
                                      entry.chain, taint, depth, "DENSE")
            return ProvenanceInfo(set(), 0, 0, taint, depth, "DENSE")

        return ProvenanceInfo(set(), 0, 0, False, 0, "UNKNOWN")

    # -------------------------------------------------------------------------
    # Header-only fast path (no mode decode needed)
    # -------------------------------------------------------------------------

    @staticmethod
    def read_header(provenance: int) -> Tuple[int, bool, int]:
        """Extract (mode, taint, depth) from header bits."""
        mode = (provenance >> MODE_SHIFT) & 0x3
        taint = bool((provenance >> TAINT_SHIFT) & 1)
        depth = (provenance >> DEPTH_SHIFT) & 0x7
        return mode, taint, depth

    @staticmethod
    def is_tainted(provenance: int) -> bool:
        """O(1) taint check — no decoding needed."""
        return bool((provenance >> TAINT_SHIFT) & 1)

    @staticmethod
    def get_depth(provenance: int) -> int:
        """O(1) depth read — no decoding needed."""
        return (provenance >> DEPTH_SHIFT) & 0x7

    # -------------------------------------------------------------------------
    # Risk Scoring
    # -------------------------------------------------------------------------

    @staticmethod
    def risk_score(provenance: int) -> float:
        """risk = taint * 1/(1 + depth).  Returns float in [0.0, 1.0]."""
        taint = bool((provenance >> TAINT_SHIFT) & 1)
        if not taint:
            return 0.0
        depth = (provenance >> DEPTH_SHIFT) & 0x7
        return 1.0 / (1.0 + depth)

    # -------------------------------------------------------------------------
    # Mode / explain helpers
    # -------------------------------------------------------------------------

    def get_mode(self, provenance: int) -> str:
        """Human-readable mode name."""
        mode = (provenance >> MODE_SHIFT) & 0x3
        if mode == MODE_01:
            pairs = _decode_pair_01((provenance & PAYLOAD_MASK) >> 16 & 0x3FF)
            return "EXACT-0" if len(pairs) == 0 else "EXACT-1"
        elif mode == MODE_2:
            return "EXACT-2"
        elif mode == MODE_3:
            return "EXACT-3"
        elif mode == MODE_DENSE:
            return "DENSE"
        return "UNKNOWN"

    def explain(self, provenance: int) -> List[Tuple[str, str]]:
        """Decode to human-readable (table, column) names."""
        pairs = self.decode(provenance)
        result = []
        for pid in sorted(pairs):
            name = self.get_name(pid)
            if name:
                result.append(name)
        return result

    def explain_full(self, provenance: int) -> Dict[str, Any]:
        """Full provenance explanation including taint, depth, risk."""
        info = self.decode_full(provenance)
        names = [self.get_name(pid) for pid in sorted(info.pairs)]
        names = [n for n in names if n is not None]

        return {
            'pairs': names,
            'pair_ids': sorted(info.pairs),
            'entity': info.entity,
            'chain': info.chain,
            'taint': info.taint,
            'depth': info.depth,
            'risk': self.risk_score(provenance),
            'mode': info.mode,
            'provenance_hex': f"0x{provenance:08X}",
        }

    def explain_tables(self, provenance: int) -> List[str]:
        """Unique table names from provenance."""
        names = self.explain(provenance)
        seen: Dict[str, None] = {}
        for table, _ in names:
            seen.setdefault(table, None)
        return list(seen)

    def has_protected(self, provenance: int) -> bool:
        """Check if provenance uses any protected tables/columns."""
        for table, col in self.explain(provenance):
            if self.is_protected(table, col):
                return True
        return False

    # -------------------------------------------------------------------------
    # Provenance Operations (taint + depth propagation)
    # -------------------------------------------------------------------------

    def combine(self, prov_a: int, prov_b: int, op: int = OpCode.ADD) -> int:
        """Combine two provenances.  pairs=union, entity=XOR, taint=OR, depth=max+1."""
        if prov_a == 0:
            return prov_b
        if prov_b == 0:
            return prov_a

        info_a = self.decode_full(prov_a)
        info_b = self.decode_full(prov_b)

        combined_pairs = info_a.pairs | info_b.pairs
        combined_entity = info_a.entity ^ info_b.entity
        combined_taint = info_a.taint or info_b.taint
        combined_depth = min(max(info_a.depth, info_b.depth) + 1, MAX_DEPTH)

        # Chain bits depend on result mode
        n = len(combined_pairs)
        if n <= 1:
            chain_bits = MODE_01_CHAIN_BITS
        elif n == 2:
            chain_bits = MODE_2_CHAIN_BITS
        elif n == 3:
            chain_bits = 0  # no inline chain in mode 10
        else:
            chain_bits = 16  # stored in registry

        combined_chain = _combine_chains(
            info_a.chain, info_b.chain, op, chain_bits)

        return self.encode(combined_pairs, combined_entity, combined_chain,
                           combined_taint, combined_depth)

    def update_chain(self, provenance: int, op: int) -> int:
        """Update provenance with a unary operation. Depth += 1, taint preserved."""
        info = self.decode_full(provenance)

        n = len(info.pairs)
        if n <= 1:
            chain_bits = MODE_01_CHAIN_BITS
        elif n == 2:
            chain_bits = MODE_2_CHAIN_BITS
        elif n == 3:
            chain_bits = 0
        else:
            chain_bits = 16

        new_chain = _update_chain(info.chain, op, chain_bits)
        new_depth = min(info.depth + 1, MAX_DEPTH)

        return self.encode(info.pairs, info.entity, new_chain,
                           info.taint, new_depth)

    def contains(self, provenance: int, pair_id: int) -> bool:
        """Check if a pair is in the provenance."""
        return pair_id in self.decode(provenance)

    def contains_table(self, provenance: int, table: str) -> bool:
        """Check if a table is in the provenance."""
        return table in self.explain_tables(provenance)

    # -------------------------------------------------------------------------
    # Entity helpers
    # -------------------------------------------------------------------------

    def entity_from_row(self, row_id: Any) -> int:
        """Create entity hash from a row identifier."""
        return _hash_entity(row_id)

    # -------------------------------------------------------------------------
    # Stats
    # -------------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """Tracker statistics."""
        return {
            'registered_pairs': self._next_id,
            'dense_entries': len(self._dense),
            'protected_tables': list(self._protected_tables),
            'protected_columns': [f"{t}.{c}" for t, c in self._protected_columns],
            'encoding': 'HYDRA-32',
        }


# =============================================================================
# Pandas Integration
# =============================================================================

class TrackedSeries(pd.Series):
    """Pandas Series with HYDRA-32 provenance (taint + depth aware)."""

    _metadata = ['_prov', '_tracker']

    def __init__(self, *args, **kwargs):
        prov = kwargs.pop('_prov', None)
        tracker = kwargs.pop('_tracker', None)
        super().__init__(*args, **kwargs)
        self._prov = prov if prov is not None else np.zeros(len(self), dtype=np.uint32)
        self._tracker = tracker

    @property
    def _constructor(self):
        return TrackedSeries

    def _binop(self, other, op, op_code: int = OpCode.ADD):
        """Binary operation with taint/depth propagation."""
        result_values = op(
            self.values,
            other.values if hasattr(other, 'values') else other)

        if isinstance(other, TrackedSeries) and self._tracker:
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                pa = int(self._prov[i]) if i < len(self._prov) else 0
                pb = int(other._prov[i]) if i < len(other._prov) else 0
                new_prov[i] = self._tracker.combine(pa, pb, op_code)
            return TrackedSeries(result_values, index=self.index,
                                 _prov=new_prov, _tracker=self._tracker)
        else:
            return TrackedSeries(result_values, index=self.index,
                                 _prov=self._prov.copy(), _tracker=self._tracker)

    def _unop(self, op, op_code: int):
        """Unary operation with depth increment."""
        result_values = op(self.values)

        if self._tracker:
            n = len(result_values)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, op_code)
            return TrackedSeries(result_values, index=self.index,
                                 _prov=new_prov, _tracker=self._tracker)
        else:
            return TrackedSeries(result_values, index=self.index,
                                 _prov=self._prov.copy(), _tracker=self._tracker)

    # Arithmetic
    def __add__(self, other):
        return self._binop(other, np.add, OpCode.ADD)
    def __sub__(self, other):
        return self._binop(other, np.subtract, OpCode.SUB)
    def __mul__(self, other):
        return self._binop(other, np.multiply, OpCode.MUL)
    def __truediv__(self, other):
        return self._binop(other, np.true_divide, OpCode.DIV)
    def __floordiv__(self, other):
        return self._binop(other, np.floor_divide, OpCode.DIV)
    def __pow__(self, other):
        return self._binop(other, np.power, OpCode.MUL)

    # Reverse arithmetic
    def __radd__(self, other):
        return self._binop(other, lambda a, b: np.add(b, a), OpCode.ADD)
    def __rsub__(self, other):
        return self._binop(other, lambda a, b: np.subtract(b, a), OpCode.SUB)
    def __rmul__(self, other):
        return self._binop(other, lambda a, b: np.multiply(b, a), OpCode.MUL)
    def __rtruediv__(self, other):
        return self._binop(other, lambda a, b: np.true_divide(b, a), OpCode.DIV)

    # Unary
    def __neg__(self):
        return self._unop(lambda x: -x, OpCode.NEG)

    # Comparisons
    def __gt__(self, other):
        return self._binop(other, lambda a, b: a > b, OpCode.CMP)
    def __lt__(self, other):
        return self._binop(other, lambda a, b: a < b, OpCode.CMP)
    def __ge__(self, other):
        return self._binop(other, lambda a, b: a >= b, OpCode.CMP)
    def __le__(self, other):
        return self._binop(other, lambda a, b: a <= b, OpCode.CMP)

    def clip(self, lower=None, upper=None, **kwargs):
        return self._unop(lambda x: np.clip(x, lower, upper), OpCode.CLIP)

    def fillna(self, value=0, **kwargs):
        result = super().fillna(value, **kwargs)
        if self._tracker:
            n = len(result)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, OpCode.FILL)
            return TrackedSeries(result.values, index=self.index,
                                 _prov=new_prov, _tracker=self._tracker)
        return TrackedSeries(result.values, index=self.index,
                             _prov=self._prov.copy(), _tracker=self._tracker)

    def map(self, arg, **kwargs):
        result = super().map(arg, **kwargs)
        if self._tracker:
            n = len(result)
            new_prov = np.zeros(n, dtype=np.uint32)
            for i in range(n):
                p = int(self._prov[i]) if i < len(self._prov) else 0
                new_prov[i] = self._tracker.update_chain(p, OpCode.MAP)
            return TrackedSeries(result.values, index=self.index,
                                 _prov=new_prov, _tracker=self._tracker)
        return TrackedSeries(result.values, index=self.index,
                             _prov=self._prov.copy(), _tracker=self._tracker)

    def replace(self, *args, **kwargs):
        result = super().replace(*args, **kwargs)
        if isinstance(result, pd.Series):
            if self._tracker:
                n = len(result)
                new_prov = np.zeros(n, dtype=np.uint32)
                for i in range(n):
                    p = int(self._prov[i]) if i < len(self._prov) else 0
                    new_prov[i] = self._tracker.update_chain(p, OpCode.MAP)
                return TrackedSeries(result.values, index=result.index,
                                     _prov=new_prov, _tracker=self._tracker)
            return TrackedSeries(result.values, index=result.index,
                                 _prov=self._prov.copy(), _tracker=self._tracker)
        return result


class TrackedDataFrame(pd.DataFrame):
    """Pandas DataFrame with HYDRA-32 provenance."""

    _metadata = ['_tracker', '_col_prov']

    def __init__(self, *args, **kwargs):
        tracker = kwargs.pop('_tracker', None)
        col_prov = kwargs.pop('_col_prov', None)
        super().__init__(*args, **kwargs)
        self._tracker = tracker
        self._col_prov = col_prov if col_prov is not None else {}

    @property
    def _constructor(self):
        return TrackedDataFrame

    @property
    def _constructor_sliced(self):
        return TrackedSeries

    def __getitem__(self, key):
        result = super().__getitem__(key)
        if isinstance(result, pd.Series) and key in self._col_prov:
            prov = self._col_prov[key]
            n = len(result)
            if len(prov) != n:
                prov = np.broadcast_to(
                    prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n
                ).copy()
            return TrackedSeries(result.values, index=result.index,
                                 _prov=prov.copy(), _tracker=self._tracker)
        elif isinstance(result, pd.Series):
            return TrackedSeries(result.values, index=result.index,
                                 _prov=np.zeros(len(result), dtype=np.uint32),
                                 _tracker=self._tracker)
        return result

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        if isinstance(value, TrackedSeries):
            self._col_prov[key] = value._prov.copy()

    def merge(self, right, *args, **kwargs):
        result = super().merge(right, *args, **kwargs)
        new_prov = {}
        n = len(result)

        for col, prov in self._col_prov.items():
            if col in result.columns:
                if self._tracker and len(prov) > 0:
                    base_prov = int(prov[0])
                    merged_prov = self._tracker.update_chain(base_prov, OpCode.MERGE)
                    new_prov[col] = np.full(n, merged_prov, dtype=np.uint32)
                else:
                    new_prov[col] = np.broadcast_to(
                        prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n
                    ).copy()

        if isinstance(right, TrackedDataFrame):
            for col, prov in right._col_prov.items():
                if col in result.columns and col not in new_prov:
                    if self._tracker and len(prov) > 0:
                        base_prov = int(prov[0])
                        merged_prov = self._tracker.update_chain(base_prov, OpCode.MERGE)
                        new_prov[col] = np.full(n, merged_prov, dtype=np.uint32)
                    else:
                        new_prov[col] = np.broadcast_to(
                            prov[:1] if len(prov) > 0 else np.array([0], dtype=np.uint32), n
                        ).copy()

        return TrackedDataFrame(result, _tracker=self._tracker, _col_prov=new_prov)


# =============================================================================
# Helper Functions
# =============================================================================

def wrap_dataframe(df: pd.DataFrame, tracker: ProvenanceTracker, table: str,
                   protected=False, include_entity: bool = True) -> TrackedDataFrame:
    """Wrap a DataFrame with HYDRA-32 provenance. Sets taint for protected columns."""
    result = TrackedDataFrame(df, _tracker=tracker)
    n = len(df)

    if isinstance(protected, (list, tuple, set)):
        protected_cols = set(str(c) for c in protected)
    else:
        protected_cols = None

    # Table-level protection: mark the table itself so is_protected(table)
    # returns True without needing a column argument
    if protected_cols is None and protected:
        tracker._protected_tables.add(table)

    for col in df.columns:
        col_protected = protected if protected_cols is None else (str(col) in protected_cols)
        pair_id = tracker.register(table, str(col), col_protected)

        is_tainted = tracker.is_protected(table, str(col))

        prov_array = np.zeros(n, dtype=np.uint32)
        for i in range(n):
            entity = tracker.entity_from_row(df.index[i]) if include_entity else 0
            entity_v = entity % (1 << MODE_01_ENTITY_BITS)
            prov_array[i] = tracker.encode(
                {pair_id}, entity=entity_v, chain=0,
                taint=is_tainted, depth=0)

        result._col_prov[col] = prov_array

    return result


def audit(series: TrackedSeries) -> Dict[str, Any]:
    """Audit a series for provenance, taint, and risk information."""
    if not series._tracker or len(series) == 0:
        return {'error': 'No tracker or empty series'}

    prov = int(series._prov[0])
    tracker = series._tracker

    info = tracker.decode_full(prov)

    return {
        'provenance': f"0x{prov:08X}",
        'mode': info.mode,
        'pair_count': len(info.pairs),
        'pair_ids': sorted(info.pairs),
        'columns': tracker.explain(prov),
        'tables': tracker.explain_tables(prov),
        'entity': info.entity,
        'chain': info.chain,
        'taint': info.taint,
        'depth': info.depth,
        'risk': tracker.risk_score(prov),
        'has_protected': tracker.has_protected(prov),
    }


def audit_series_diversity(series: TrackedSeries) -> Dict[str, Any]:
    """Analyze provenance diversity across a series."""
    if not series._tracker or len(series) == 0:
        return {'error': 'No tracker or empty series'}

    tracker = series._tracker
    unique_provs = set(int(p) for p in series._prov)
    unique_pairs = set()
    unique_entities = set()
    unique_chains = set()
    taint_count = 0
    max_depth = 0

    for prov in unique_provs:
        info = tracker.decode_full(prov)
        unique_pairs.update(info.pairs)
        unique_entities.add(info.entity)
        unique_chains.add(info.chain)
        if info.taint:
            taint_count += 1
        max_depth = max(max_depth, info.depth)

    return {
        'total_rows': len(series),
        'unique_provenances': len(unique_provs),
        'unique_pair_sets': len(unique_pairs),
        'unique_entities': len(unique_entities),
        'unique_chains': len(unique_chains),
        'entity_diversity': len(unique_entities) / len(series) if len(series) > 0 else 0,
        'tainted_provenances': taint_count,
        'taint_ratio': taint_count / len(unique_provs) if unique_provs else 0,
        'max_depth': max_depth,
    }


def provenance_entropy(series: TrackedSeries) -> float:
    """Shannon entropy of provenance distribution across a series."""
    if len(series) == 0:
        return 0.0

    prov_counts: Dict[int, int] = {}
    for p in series._prov:
        p_int = int(p)
        prov_counts[p_int] = prov_counts.get(p_int, 0) + 1

    n = len(series)
    h = 0.0
    for count in prov_counts.values():
        p = count / n
        if p > 0:
            h -= p * math.log2(p)
    return h


def column_risk_report(df: TrackedDataFrame,
                       tracker: ProvenanceTracker = None) -> List[Dict[str, Any]]:
    """Per-column taint risk report. Returns list of dicts sorted by risk (highest first)."""
    if tracker is None:
        tracker = df._tracker
    if tracker is None:
        return []

    report = []
    for col in df.columns:
        if col not in df._col_prov:
            report.append({
                'column': col, 'tainted': False, 'max_risk': 0.0,
                'min_depth': None, 'risk_level': 'CLEAN',
            })
            continue

        prov_array = df._col_prov[col]
        max_risk = 0.0
        any_taint = False
        min_depth = MAX_DEPTH

        for p in prov_array:
            p_int = int(p)
            if ProvenanceTracker.is_tainted(p_int):
                any_taint = True
                d = ProvenanceTracker.get_depth(p_int)
                min_depth = min(min_depth, d)
                risk = ProvenanceTracker.risk_score(p_int)
                max_risk = max(max_risk, risk)

        if max_risk > 0.5:
            level = 'HIGH'
        elif max_risk > 0.2:
            level = 'MEDIUM'
        elif max_risk > 0:
            level = 'LOW'
        else:
            level = 'CLEAN'

        report.append({
            'column': col,
            'tainted': any_taint,
            'max_risk': round(max_risk, 4),
            'min_depth': min_depth if any_taint else None,
            'risk_level': level,
        })

    report.sort(key=lambda x: x['max_risk'], reverse=True)
    return report
