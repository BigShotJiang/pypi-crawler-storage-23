"""agentic-memory — Persistent memory system for AI agents."""

__version__ = "0.1.0"
