"""Workflow templates bundled with dotpromptz."""

