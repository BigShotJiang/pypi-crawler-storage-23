"""Core registry for bidirectional data transformations.

Provides a registry pattern for data transformations with automatic
path finding and DAG visualization capabilities.
"""

import os
import tempfile
from pathlib import Path
from typing import TypeVar, Callable, Dict, Any, Type, Optional, List
import pandas as pd
from dataclasses import dataclass
from collections import deque
from guts_base.data.utils import datalad_locked_file_warning

T = TypeVar("T")


@dataclass(frozen=True)
class Transform:
    """Represents a bidirectional transformation."""

    source: Type
    target: Type
    forward: Callable

    @staticmethod
    def assert_target_empty(source, target):
        if hasattr(target, "path"):
            path = Path(target.path)

            if path.exists():
                print(path, "exists, removing before applying transform.")
                os.remove(path)

    @staticmethod
    def assert_target_dir_exists(source, target):
        if hasattr(target, "path"):
            path = Path(target.path)

            if not path.parent.exists():
                path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def describe_transformed_object(source, target):
        if hasattr(target, "ext") and hasattr(target, "path"):
            if target.ext == ".xlsx":
                f = pd.ExcelFile(target.path)
                print(f"Created Excel file '{target.path}' with sheets: {f.sheet_names}")

    @staticmethod
    def assert_file_not_locked_with_datalad(source, target):
        """TODO: SHould this be used?"""
        if hasattr(target, "path"):
            if os.access(target.path, os.EX_OK):
                if not os.access(target.path, os.W_OK):
                    datalad_locked_file_warning(target.path)
                
    def apply_transform(self, source, target):
        self.assert_target_empty(source, target)
        self.assert_target_dir_exists(source, target)
        out = self.forward(source, target)
        self.describe_transformed_object(source, target)
        return out

class TransformRegistry:
    """Registry for bidirectional transformations with auto-path finding."""

    def __init__(self):
        self._transforms: Dict[tuple[Type, Type], Transform] = {}

    def register(self, source: Type, target: Type):
        """Decorator to register a transformation."""

        def decorator(forward: Callable):
            transform = Transform(source, target, forward)
            self._transforms[(source, target)] = transform
            return forward

        return decorator

    def can_transform(self, source: Type, target: Type) -> bool:
        """Check if direct transformation is possible."""
        return (source, target) in self._transforms

    def find_path(self, source: Type, target: Type) -> Optional[List[Type]]:
        """Find shortest transformation path from source to target using BFS."""
        queue = deque([(source, [])])
        visited = {source}

        while queue:
            current_type, path = queue.popleft()

            if current_type == target:
                return path

            # Find all types we can transform to from current_type
            for (src, tgt), _ in self._transforms.items():
                if src == current_type and tgt not in visited:
                    visited.add(tgt)
                    queue.append((tgt, path + [tgt]))

        return None

    def transform(self, data: Any, target: Any) -> Any:
        """Transform data to target type, automatically finding path if needed.

        Args:
            data: The data to transform.
            target: The target type (e.g., xr.Dataset) or target object (e.g., ExcelWide instance).

        Returns:
            The transformed data.
        """
        source_type = type(data)
        
        # Check if target is a type or an instance
        if isinstance(target, type):
            target_type = target
            target_instance = None
        else:
            target_type = type(target)
            target_instance = target

        # Direct transformation exists
        if self.can_transform(source_type, target_type):
            key = (source_type, target_type)
            # Pass the target instance if available, otherwise pass the type
            if target_instance is not None:
                return self._transforms[key].apply_transform(data, target_instance)
            else:
                return self._transforms[key].apply_transform(data, target_type)

        # Find path
        path = self.find_path(source_type, target_type)
        if path is None:
            raise ValueError(f"No path from {source_type} to {target_type}")

        # Apply transformations along the path
        with tempfile.TemporaryDirectory(prefix="data_transform_intermediates_") as tmp_dir:
            tmp_dir = Path(tmp_dir)

            current = data
            for i, next_type in enumerate(path):
                # Check if this is the last step and we have a target instance
                is_last_step = (i == len(path) - 1)
                
                if is_last_step and target_instance is not None:
                    # Use the actual target instance for the final step
                    intermediate_target = target_instance
                elif hasattr(next_type, '__dataclass_fields__') and 'path' in next_type.__dataclass_fields__:
                    assert "ext" in next_type.__dataclass_fields__, (
                        "If the target has a path, it must also define an extension (e.g. .xlsx)"
                    )
                    # For intermediate types, create a temporary file path if needed
                    # Don't create the file yet - let the transformation function create it
                    path_intermediate = tmp_dir / f"{next_type.__name__}.{next_type.ext}"
                    intermediate_target = next_type(str(path_intermediate))
                else:
                    intermediate_target = next_type()
                
                result = self._transforms[(type(current), next_type)].apply_transform(current, intermediate_target)
                
                # If the result is a string (path), create the appropriate instance
                if isinstance(result, str) and hasattr(next_type, '__dataclass_fields__') and 'path' in next_type.__dataclass_fields__:
                    current = next_type(result)
                else:
                    current = result

        return current

    def get_all_types(self) -> List[Type]:
        """Get all registered types."""
        types = set()
        for src, tgt in self._transforms.keys():
            types.add(src)
            types.add(tgt)
        return list(types)

    def get_edges(self) -> List[tuple[Type, Type]]:
        """Get all transformation edges."""
        return list(self._transforms.keys())

    def visualize_dag(self, output_path: str = "transform_dag.png", ortho: bool = True):
        """Visualize the transformation DAG using graphviz.
        
        Args:
            output_path: Path to save the visualization (without extension).
            ortho: If True, use orthogonal (rectangular) edges.
        """
        try:
            from graphviz import Digraph
        except ImportError as e:
            raise ImportError(
                "graphviz is required for DAG visualization. "
                "Install with: pip install graphviz"
            ) from e

        dot = Digraph(comment="Data Transformations", format="png")
        
        # Use orthogonal edges if requested
        if ortho:
            dot.attr(splines='ortho')
        
        # Use rectangular boxes for nodes
        dot.attr('node', shape='box')

        # Add nodes
        for t in self.get_all_types():
            label = t.__name__ if hasattr(t, "__name__") else str(t)
            dot.node(str(id(t)), label)

        # Add edges
        for src, tgt in self.get_edges():
            src_label = src.__name__ if hasattr(src, "__name__") else str(src)
            tgt_label = tgt.__name__ if hasattr(tgt, "__name__") else str(tgt)
            
            # Check if this is a bidirectional edge
            is_bidirectional = (tgt, src) in self._transforms
            
            if is_bidirectional:
                # Color light gray for bidirectional edges
                edge_color = 'black'
            else:
                edge_color = 'grey'
            
            if ortho:
                # Use xlabel for orthogonal edges (external label)
                dot.edge(str(id(src)), str(id(tgt)), xlabel=f"{src_label} → {tgt_label}", color=edge_color)
            else:
                # Use regular label for curved edges
                dot.edge(str(id(src)), str(id(tgt)), label=f"{src_label} → {tgt_label}", color=edge_color)

        # Render
        dot.render(output_path, cleanup=True)
        print(f"DAG visualization saved to {output_path}.png")
        return dot


# Global registry instance
registry = TransformRegistry()


def transform(data: Any, target: Any) -> Any:
    """Convenience function to transform data.

    Args:
        data: The data to transform.
        target: The target type or target object.

    Returns:
        The transformed data.
    """
    return registry.transform(data, target)