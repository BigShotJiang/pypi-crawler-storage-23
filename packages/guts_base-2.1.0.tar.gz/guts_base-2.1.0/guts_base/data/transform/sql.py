"""SQL transformations.

Provides transformations between SQL databases and xarray Datasets.
"""

import xarray as xr

from .registry import registry
from .types import SQLConnection, GutsDataset
from ..expydb import from_expydb, to_dataset, reduce_multiindex_to_flat_index
from expyDB.intervention_model import Experiment


@registry.register(SQLConnection, xr.Dataset)
def sql_to_xarray(data: SQLConnection, target: xr.Dataset) -> xr.Dataset:
    """SQL → XARRAY using expyDB.
    
    Reads data from an expyDB database and converts it to an xarray Dataset.
    """
    observations_idata, interventions_idata = from_expydb(
        database=f"sqlite:///{data.conn_str}",
        statement=data.query
    )
    
    dataset = to_dataset(
        observations_idata,
        interventions_idata,
        unit_time=data.unit_time
    )
    dataset = reduce_multiindex_to_flat_index(dataset)
    
    return dataset

@registry.register(xr.Dataset, GutsDataset)
def xarray_to_guts_dataset(data: xr.Dataset, target: GutsDataset) -> xr.Dataset:
    return target.to_gutsbase_dataset(dataset=data)


@registry.register(Experiment, SQLConnection)
def experiment_to_sql(data: Experiment, target: SQLConnection) -> None:
    data.to_database(target.conn_str)

# @registry.register(xr.Dataset, SQLConnection)
# def xarray_to_sql(data: xr.Dataset, target: SQLConnection) -> None:
#     """XARRAY → SQL (not implemented for expyDB)"""
#     raise NotImplementedError(
#         "Writing xarray Dataset to expyDB is not currently supported. "
#         "expyDB is designed for reading data from databases, not writing."
#     )

