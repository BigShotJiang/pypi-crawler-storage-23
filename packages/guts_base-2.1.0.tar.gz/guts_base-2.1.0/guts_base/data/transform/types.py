"""Type tags for format variants.

Since Python types don't distinguish between format variants
(e.g., EXCEL wide vs LONG), we use frozen dataclasses as type tags.
"""

import operator
from dataclasses import dataclass, field
from typing import Optional, Literal, List, Tuple, Callable, Dict, Any, Hashable
import pandas as pd
import numpy as np
import xarray as xr
from pymob import SimulationBase
from frozendict import frozendict

@dataclass(frozen=True)
class SQLConnection:
    """SQL database connection descriptor."""
    conn_str: str
    ext: str = ".sqlite"
    query: Optional[str] = None
    unit_time: Literal["day", "hour", "minute", "second"] = "day"


@dataclass(frozen=True)
class ExpyDBExperiment:
    """ExpyDB Intervention Model experiment class."""


@dataclass(frozen=True)
class ExcelWide:
    """Excel file in wide format descriptor."""
    path: str
    ext: str = ".xlsx"
    exposure_dim: str = "substance"
    metadata_sheet: str = "meta"
    intervention_sheets: Optional[List[str]] = None
    observation_sheets: Optional[List[str]] = None

@dataclass(frozen=True)
class ExcelTimeofDeath:
    """Excel file in wide format descriptor."""
    path: str
    observation_sheets: List[str]
    intervention_sheets: List[str]
    observation_schedule: str = "d"
    rect_interpolation: bool = False
    ext: str = ".xlsx"

@dataclass(frozen=True)
class ExcelWideUnprocessedMeta:
    """Excel file in wide format descriptor. Has not had metadata"""
    path: str
    ext: str = ".xlsx"

    preprocessing_func: Callable = lambda data, target, **kwargs: data.path
    preprocessing_kwargs: Dict = field(default_factory=dict)
    update_metadata_kwargs: Optional[Dict] = None

@dataclass(frozen=True)
class ExcelLong:
    """Excel file in long format descriptor."""
    path: str
    ext: str = ".xlsx"



@dataclass(frozen=True)
class GutsDataset:
    """Create a GutsDataset from an xarray
    
    Parameters
    ----------

    data_filters_max_time: Tuple[Tuple[str,str,float]]
        A collection of tuples that indicate how a data variable in the raw dataset 
        should be filtered. Currently it is only possible to compare against the maximum
        over time.
        E.g. ("sulfoxaflor", ">=", 0.0) results in the command
        dataset.where(dataset['sulfoxaflor'].max("time") >= 0.0, drop=True)

    time_filter: Tuple[float, float]
        Denote the maximum and minimum time window to be included in the final dataset
        
    exposure: Tuple[str, List[str]]
        which data variables should be combined into the exposure array, and which
        dimension name should the new array receive for the combined arrays. 
        E.g. ("substance", ["lambda_cyhalothrin", "sulfoxaflor"]). The names in
        the list must exist in the data array, the dimension name is arbitrary.

    drop_original_exposure_vars: bool
        Should variables that are combined in exposure data variable be dropped from the
        dataset? Default: True

    model_type: str
        Select one of IT or SD. If IT is selected the x-coordinate (default: time) 
        is reindexed, to increase the temporal resolution, to ensure that models are fitted
        correctly.
        TODO: Can reindexing of observations or exposures happen independent of the dataset?

    indices: Tuple[Tuple[str, List[str]], ...]
        index coordinates to create. Index coordinates are arrays that follow the batch
        dimension (default: id). They repeat certain metadata information to allow for
        clustering of parameters during inference. Additionally, they can be used to 
        expand existing variables.

    coordinate_to_dim: Tuple[Tuple[str, List[str]], ...]
        Transform a list of variables from batch like coordinate notation to a dimension. 
        The variable retains the batch dimension, but additionally receives a new dimension
        that has the same name as the coordinate and the unique coordinates of the old
        coordinate. ⚠️ IDs that did not have the old coordinate are filled with zeros

        Example before transformation

        dims:   (id)
        
        coordinates
        id:      1,2,3,4
        coord_a: a,a,b,b
        
        data variables
        var_1 (id):  2,5,9,1

        Example after transformation

        dims:   (id, coord_a)
        
        coordinates
        id:      1,2,3,4
        coord_a: a,b
        
        data variables
        var_1 (coord_a,id):  [[2,5,0,0],
                               0,0,9,1]]

    n_reindexed_x: int
        number of extra x coordinates to expand the x dimension with if model_type=="IT"

    batch_dim: str
        The name of the batch dimension in the dataset (default: id)
                               
    x_dim: str
        The name of the x dimension in the dataset (default: time)
    
    squeeze_dims: Tuple[str, ...]
        Try squeezing dims of length 1

    extra_processing: Callable (optional)
        A callable that takes an xr.Dataset as input and an arbitrary number of keyword
        arguments that returns an xr.Dataset, default: None.

    extra_processing_kwargs: Dict
        Arguments to the extra_processing callable.

    """
    exposure: Tuple[str,List[str]]
    model_type: Literal["IT", "SD"]
    drop_original_exposure_vars: bool = True
    indices: Tuple[Tuple[str,List[str]], ...] = ()
    coordinate_to_dim: Tuple[Tuple[str,List[str]], ...] = ()
    data_filters_max_time: Tuple[Tuple[str,str,float], ...] = ()
    time_filter: Optional[Tuple[float,float]] = None

    n_reindexed_x: int = 100
    batch_dim: str = "id"
    x_dim: str = "time"
    squeeze_dims: Tuple[str, ...] = ()
    drop_vars: Tuple[str, ...] = ()
    extra_processing: Optional[Callable] = None
    extra_processing_kwargs: frozendict = frozendict()

    def to_gutsbase_dataset(self, dataset: xr.Dataset, ) -> xr.Dataset:
        _dataset = dataset.copy()

        _dataset = self.filter_dataset(
            _dataset, 
            data_filters=self.data_filters_max_time,
            time_range=self.time_filter
        )

        # reindexing happens before everything else, because in later functions
        # nans of survival data are filled
        _dataset = self._reindex_based_on_model_type(
            _dataset, 
            model_type=self.model_type, 
            n_reindexed_x=self.n_reindexed_x
        )

        _dataset = self._prepare_exposure_data(
            _dataset,
            exposure_dim=self.exposure[0],
            exposure_datavars=self.exposure[1],
            drop_original_exposure_datavars=self.drop_original_exposure_vars
        )

        # survival data prep
        _dataset = self._prepare_survival_data(_dataset)

        _dataset = self._create_index_coordinates(_dataset, self.indices)

        _dataset = self._expand_coords_to_dim(
            _dataset, 
            coordinate_to_dim=self.coordinate_to_dim,
            batch_dim=self.batch_dim
        )

        _dataset = self._try_squeeze_dims(_dataset, squeeze=self.squeeze_dims)
        _dataset = _dataset.drop_vars(self.drop_vars, errors="ignore")

        # transpose
        _dataset = _dataset.transpose(self.batch_dim, self.x_dim, ...)

        # make sure that the dataset can be saved to disk
        _dataset = SimulationBase._serialize_attrs(_dataset)

        if self.extra_processing is not None:
            _dataset = self.extra_processing(_dataset, **self.extra_processing_kwargs)

        return _dataset

    @classmethod
    def _expand_coords_to_dim(
        cls, 
        dataset: xr.Dataset, 
        coordinate_to_dim: Tuple[Tuple[str, List[str]], ...],
        batch_dim: str
    ):
        _dataset = dataset.copy()
        for index_coord, variables in coordinate_to_dim:
            if all(v in _dataset.data_vars for v in variables):
                _dataset = cls._expand_batch_like_coordinate_to_new_dimension(
                    _dataset, 
                    coordinate=index_coord, 
                    variables=variables,
                    batch_dim=batch_dim
                )
            elif all(v in _dataset.coords for v in variables):
                _dataset = cls._map_batch_coordinates_to_extra_dim_coordinates(
                    _dataset, 
                    coordinates=variables,
                    target_dimension=index_coord, 
                    batch_dim=batch_dim
                )
            else:
                from guts_base.sim import GutsBaseError
                raise GutsBaseError(
                    "variables in coordinate_to_dim must be either all data variables"+
                    "or coordinates."
                )

        return _dataset

    @classmethod
    def _reindex_based_on_model_type(
        cls, 
        dataset, 
        model_type: Literal["IT", "SD"], 
        n_reindexed_x: int
    ):
        _dataset = dataset.copy()

        # IT based model reindexing
        if model_type == "IT":
            print(
                "Redindexing time vector to increase resolution, because model has "+
                f"'_it' (individual tolerance) in it's name. (N={n_reindexed_x} " +
                "additional time points)"
            )

            # TODO: Skip conditional on frequency of time vector. E.g. IT should
            # be at least hourly or something like that

            _dataset = cls._reindex_x_dim(
                _dataset, 
                n_reindexed_x=n_reindexed_x, 
                x_dim="time"
            )
        else:
            print(
                "No redindexing of time vector to, because model name did not contain "+
                "'_it' (individual tolerance), or model was not given by name. If an IT model " +
                "is calculated without a dense time resolution, the estimates can be biased!"
            )
        return _dataset

    @classmethod        
    def _create_index_coordinates(cls, dataset, indices: Tuple[Tuple[str,List[str]], ...]):
        _dataset = dataset.copy()
        for index in indices:
            index_name, index_coords = index
            _dataset = cls._create_index_coordinate(
                dataset=_dataset,
                index_name=index_name,
                coordinates=index_coords
            )

        return _dataset

    @staticmethod
    def _try_squeeze_dims(dataset: xr.Dataset, squeeze: Tuple[str, ...]):
        _dataset = dataset.copy()

        if isinstance(squeeze, str):
            squeeze = tuple([squeeze])

        for dim in squeeze:
            try:
                _dataset = _dataset.squeeze(dim=dim, drop=False)
            except ValueError:
                # pass over dims that can't be squeezed, because they are larger than
                # length one
                pass
            except KeyError:
                # do nothing if dim can't be found
                pass

        return _dataset

    @staticmethod
    def _prepare_exposure_data(
        dataset: xr.Dataset, 
        exposure_dim: str, 
        exposure_datavars: List[str],
        drop_original_exposure_datavars: bool = True
    ):
        _dataset = dataset.copy()

        if "exposure" not in dataset:
            exposure_array = _dataset[exposure_datavars].to_dataarray(dim=exposure_dim)

            all_keys = set.union(*[set(_dataset[datavar].attrs) for datavar in exposure_datavars])
            new_coords = {
                key: (exposure_dim, [_dataset[dv].attrs.get(key) for dv in exposure_datavars])
                for key in all_keys
            }
            
            exposure_array = exposure_array.assign_coords(new_coords)

            _dataset["exposure"] = exposure_array

        if drop_original_exposure_datavars:
            _dataset = _dataset.drop_vars(exposure_datavars)

        return _dataset

    @staticmethod
    def _reindex_x_dim(dataset, n_reindexed_x: Optional[int], x_dim: str = "time"):
        _dataset = dataset.copy()

        if n_reindexed_x is not None:
            new_time_index = np.unique(np.concatenate([
                _dataset[x_dim],
                np.linspace(
                    0, np.max(_dataset[x_dim]), 
                    n_reindexed_x
                )
            ]))
            return _dataset.reindex(time = new_time_index)

        else:
            return _dataset
        
    
    @staticmethod
    def _prepare_survival_data(dataset: xr.Dataset):
        _dataset = dataset.copy()
        
        # coerce lower case 
        if "Survival" in _dataset:
            _dataset = _dataset.rename({"Survival": "survival"})

        if "SURVIVAL" in _dataset:
            _dataset = _dataset.rename({"SURVIVAL": "survival"})

        if "subject_count" not in _dataset.coords:
            _dataset = _dataset.assign_coords(
                subject_count=("id", _dataset["survival"].isel(time=0).values, )
            )

        from guts_base.data import is_survival_only_nan_except_start
        from guts_base.data import prepare_survival_data_for_conditional_binomial

        if is_survival_only_nan_except_start(_dataset.survival):
            _dataset = _dataset.assign_coords({
                "survivors_at_start": (("id", "time"), np.broadcast_to(
                    _dataset.survival.isel(time=0).values.reshape(-1,1), 
                    shape=_dataset.survival.shape
            ).astype(int))})
        else:
            _dataset = prepare_survival_data_for_conditional_binomial(
                observations=_dataset
            )

        return _dataset

    @staticmethod
    def _create_index_coordinate(
        dataset,
        index_name: str,
        coordinates: List[str],

    ):
        """creates a new coordinate of existing coordinates in a dataset
        """
        from guts_base.data import combine_coords_to_multiindex
        from guts_base.sim import GutsBaseError

        _dataset = dataset.copy()

        _coordinates = []
        for coord in coordinates:
            if coord in _dataset.coords:
                if len(_dataset.coords[coord]) == 1:
                    raise GutsBaseError(
                        f"Requested an index for a coordinate '{coord}' with length 1. " +
                        "Index could be broadcasted to the batch dimension, but the " +
                        f"effect would be none. Instead drop coordinate '{coord}' from " +
                        f"the index:\n>>> GutsDataset(..., indices = ('{index_name}', " +
                        f"{[c for c in coordinates if c != coord]}))\n"+
                        "If the index has no coordinates any longer, you can drop it entirely."
                    )
                else:
                    _coordinates.append(coord)
            else:
                raise GutsBaseError(
                    f"{coord} not in dataset coordinates. Make sure all coordinates exist "+
                    "that should be used for the index."
                )

        _dataset = combine_coords_to_multiindex(
            _dataset, 
            coordinates=_coordinates,
            index_name=index_name
        ).sortby(index_name)

        return _dataset


    @staticmethod
    def _expand_batch_like_coordinate_to_new_dimension(
        dataset: xr.Dataset, 
        coordinate: str, 
        variables: List[str] = [],
        batch_dim: str = "id"
    ):
        """This method will take an existing coordinate of a dataset that has the same
        coordinate has the batch dimension. It will then re-express the coordinate as a
        separate dimension for the given variables, by duplicating the N-Dimensional array
        times the amount of unique names in the specified coordinate to create an 
        N+1-dimensional array. This array will be filled with zeros along the batch dimension
        where the specified coordinate along the ID dimension coincides with the new (unique)
        coordinate of the new dimension. 

        This process is entirely reversible
        """
        _dataset = dataset.copy()
        old_coords = _dataset[coordinate]

        # old coordinate before turning it into a dimension
        obs = _dataset.drop(coordinate)

        # create unique coordinates of the new dimension, preserving the order of the
        # old coordinate
        _, index = np.unique(old_coords, return_index=True)
        coords_new_dim = tuple(np.array(old_coords)[sorted(index)])

        for v in variables:
            # take data variable and extract dimension order
            data_var = obs[v]
            dim_order = data_var.dims

            # expand the dimensionality, then transpose for new dim to be last
            data_var = data_var.expand_dims(coordinate).transpose(..., batch_dim, coordinate)

            # create a dummy dimension to broadcast the new array 
            # preserve the order of the dummy variable columns by indexing along the 
            # unique coordinates with preserved order.
            dummy_categorical = pd.get_dummies(old_coords)[list(coords_new_dim)].astype(int).values # type: ignore

            # apply automatic broadcasting to increase the size of the new dimension
            data_var_np1_d = data_var * dummy_categorical
            data_var_np1_d.attrs = data_var.attrs

            # annotate coordinates of the new dimension
            data_var_np1_d = data_var_np1_d.assign_coords({
                coordinate: list(coords_new_dim)
            })

            # transpose back to original dimension order with new dim as last dim
            data_var_np1_d = data_var_np1_d.transpose(*dim_order, coordinate)
            obs[v] = data_var_np1_d

        return obs
    
    @staticmethod
    def _unique_unsorted(values):
        _, index = np.unique(values, return_index=True)
        return tuple(np.array(values)[sorted(index)])

    @classmethod
    def _map_batch_coordinates_to_extra_dim_coordinates(
        cls,
        dataset: xr.Dataset, 
        target_dimension: str,
        coordinates: Optional[List[Hashable]] = None,
        batch_dim: str = "id",
    ) -> xr.Dataset:
        """Iterates over coordinates and reduces those coordinates to the new dimension
        which have the same number of unique coordinates as the new dimension has coordinates
        """
        _dataset = dataset.copy()
        if coordinates is None:
            coordinates = list(_dataset.coords.keys())

        for key, coord in _dataset.coords.items():
            # skips coords, if not specified in coordinates
            if key not in coordinates:
                continue

            if batch_dim in coord.dims and key not in _dataset.dims:
                if len(coord.dims) == 1:
                    dim_coords = cls._unique_unsorted(coord.values)
                    if len(dim_coords) == len(_dataset[target_dimension]):
                        _dataset[key] = (target_dimension, list(dim_coords))
                    else:
                        pass
                else:
                    print(
                        f"Coordinate '{key}' is has dimensions {coord.dims}. " +
                        "Mapping coordinates with more than 1 dimension to the extra " +
                        f"dimension '{target_dimension}' is not supported yet."
                    )
                    pass

        return _dataset
                

    @staticmethod
    def reduce_dimension_to_batch_like_coordinate(dimension, variables):
        """This method takes an existing dimension from a N-D array and reduces it to an
        (N-1)-D array, by writing a new coordinate from the reducible dimension in the way
        that the new batch-like coordinate takes the coordinate of the dimension, where
        the data of the N-D array was not zero. After it has been asserted that there is
        only a unique candidate for the each coordinate along the batch dimension 
        (i.e. only one value is non-zero for a given batch-coordinate), the dimension will
        be reduced by summing over the given dimension.

        The method is contingent on having no overlap in batch dimension in the dataset
        """
        pass

    @staticmethod
    def filter_dataset(
        dataset: xr.Dataset, 
        data_filters: Tuple[Tuple[str, str, float], ...] = (),
        time_range: Optional[Tuple[float, float]] = None,
        ) -> xr.Dataset:
        """Filters """
        _dataset = dataset.copy()

        ops = {
            "==": operator.eq, "<": operator.lt, ">": operator.gt, 
            ">=": operator.ge, "<=": operator.le, "!=": operator.ne
        }

        if time_range is not None:
            tmin, tmax = time_range     
            _dataset = _dataset.sel(time=[
                t for t in _dataset.time.values if t >= tmin and t <= tmax
            ])

        for fltr in data_filters:
            data_var, op, condition = fltr
            _dataset = _dataset.where(
                ops[op](_dataset[data_var].max("time"), float(condition)), 
                drop=True
            )
        return _dataset

