"""PYMOB transformations (one-way).

Provides one-way transformation from xarray to PYMOB Modelparameters.
"""

import xarray as xr

from .registry import registry


@registry.register(xr.Dataset, object)
def xarray_to_pymob(data: xr.Dataset, target: object):
    """XARRAY → PYMOB (one-way)"""
    from pymob.sim.config import Modelparameters

    return Modelparameters.model_validate(data.to_dict())