"""Excel transformations.

Provides transformations between Excel files (wide and long formats) and xarray Datasets.
"""

import pandas as pd
import xarray as xr
from expyDB.intervention_model import Experiment

from .registry import registry
from .types import ExcelWide, ExcelLong, ExcelTimeofDeath, ExcelWideUnprocessedMeta
from ..openguts import OpenGutsIO
from guts_base.data import time_of_death
from guts_base.data.preprocessing import  update_metadata

# EXCEL_RINGTEST -> EXCEL_WIDE

@registry.register(ExcelWideUnprocessedMeta, ExcelWide)
def excel_wide_unprocessed_meta_to_excel_wide(data: ExcelWideUnprocessedMeta, target: ExcelWide):
    if data.update_metadata_kwargs is not None:
        _ = update_metadata(data.path, **data.update_metadata_kwargs)
    data.preprocessing_func(data.path, new_path=target.path, **data.preprocessing_kwargs)
    return target.path


# time of death
@registry.register(ExcelTimeofDeath, ExcelWideUnprocessedMeta)
def excel_timeofdeath_to_excel_wide(data: ExcelTimeofDeath, target: ExcelWide):
    return time_of_death.main(
        file=data.path,
        out=target.path,
        sheet=data.observation_sheets[0],
        intervention_columns=data.intervention_sheets,
        observation_schedule=data.observation_schedule,
        extra_observation_columns=data.observation_sheets[slice(1,None)],
        rect_interpolate=False
    )

# EXCEL_WIDE <-> EXCEL_LONG transformations



@registry.register(ExcelWide, ExcelLong)
def excel_wide_to_long(data: ExcelWide, target: ExcelLong) -> str:
    """Excel [wide] → Excel [long]"""
    io = OpenGutsIO()

    # TODO: This should be coordinated with the implementation in mempy
    io.from_excel_wide(
        data.path,
        metadata_sheetname=data.metadata_sheet,
        observations=data.observation_sheets,
        interventions=data.intervention_sheets,
    )
    io.to_excel_long(target.path)
    return target.path


@registry.register(ExcelLong, ExcelWide)
def excel_long_to_wide(data: ExcelLong, target: ExcelWide) -> str:
    """Excel [long] → Excel [wide]"""
    io = OpenGutsIO()
    io.from_excel_long(data.path)
    io._file = target.path
    io.to_excel_wide()
    return target.path

# XARRAY <-> EXCEL_WIDE transformations
@registry.register(xr.Dataset, ExcelWide)
def xarray_to_excel_wide(data: xr.Dataset, target: ExcelWide) -> str:
    """Xarray → Excel [wide]"""
    OpenGutsIO._write_openguts(
        observations=data, 
        exposure_dim=target.exposure_dim,
        path=target.path,
    )
    return target.path


@registry.register(ExcelLong, Experiment)
def excel_long_to_experiment(data: ExcelLong, target: Experiment) -> Experiment:
    """Excel [long] → Experiment using OpenGuts format.
    
    Reads an Excel file in OpenGuts format (which produces long dataframes),
    converts it to an Experiment model.
    """
    io = OpenGutsIO()
    io.from_excel_long(file=data.path)
    return io.to_experiment()
