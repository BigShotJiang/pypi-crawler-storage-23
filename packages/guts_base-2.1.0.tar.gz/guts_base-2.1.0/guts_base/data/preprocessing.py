import os

import pandas as pd

from expyDB.intervention_model import (
    Experiment, Treatment, Timeseries, 
    PandasConverter,
)
import shutil
from textwrap import dedent



def read_timeseries_sheet(path, sheet, sep=None):
    ts = pd.read_excel(path, sheet_name=sheet, index_col=0)  # type: ignore
    multi_index = pd.MultiIndex.from_tuples(
        [tuple(c.split(sep)) for c in ts.columns], names=["treatment_id", "timeseries_id"]
    )
    ts.columns = multi_index
    return ts

def ringtest(path, new_path):
    exposure = read_timeseries_sheet(path, sheet="Exposure", sep=" ")
    exposure.index.name = "time"
    survival = read_timeseries_sheet(path, sheet="Survival", sep=" ")
    survival.index.name = "time"

    # TODO: possibly using a normal index would also be acceptable
    template = PandasConverter(Experiment())
    # template.meta.index = template.meta_multiindex

    # extract information from the meta that is needed elsewhere
    data = {}
    data.update({"exposure": exposure})
    data.update({"survival": survival})


    map = [
        # new keys
        (None, ("experiment", "name"), lambda x: "Ring test"),
        (None, ("experiment", "interventions"), lambda x: ["exposure"]),
        (None, ("experiment", "observations"), lambda x: ["survival"]),
        (None, ("experiment", "public"), lambda x: True),

        (None, ("treatment", "medium"), lambda x: "water"),

        (None, ("observation", "unit"), lambda x: "-"),
        (None, ("observation", "time_unit"), lambda x: "day"),

        (None, ("intervention", "unit"), lambda x: "-"),
        (None, ("intervention", "time_unit"), lambda x: "day"),
    ]

    template.map_to_meta(map=map)
    template.data = data
    template.to_excel(new_path)

    return new_path

def update_metadata(source, meta_sheet, meta_index, meta_column, meta_dict={}):
    """A simple method to update the metadata of an unmodified data workbook
    """
    
    # read the relevant sheets of the pollinera data workbook
    with pd.ExcelFile(source) as reader:
        # info is simply passed forward and renamed, because it must not be named Info
        meta = pd.read_excel(reader, sheet_name=meta_sheet).set_index(meta_index)
        
    if meta_column not in meta.columns:
        raise ValueError(dedent(
            f"""{meta_column=} not in {meta.columns=}
            """
        ))

    for new_key, new_value in meta_dict.items():
        meta.loc[new_key, meta_column] = new_value 

    # this should also be equal for anything else
    with pd.ExcelWriter(source, mode="a", if_sheet_exists="replace") as writer:
        meta.to_excel(writer, sheet_name=meta_sheet)

    return source