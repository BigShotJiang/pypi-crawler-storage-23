from typing import List, Optional, Callable, Dict, Any, Tuple
from importlib import import_module
import warnings

import numpy as np
import xarray as xr
import pandas as pd
from expyDB.database_operations import create_database, experiment_to_db
from pymob.sim.config import dict_to_string

import glob
import os

import click
import pandas as pd

from expyDB.intervention_model import to_expydb, Experiment, PandasConverter
from guts_base.data.utils import datalad_locked_file_warning

def test_equality_of_exposure_patterns_in_treatment(df):
    for _, group in df.groupby("treatment_id"):
        exposures = group.pivot_table(
            # values="value", 
            index=["time", "treatment_id"], 
            columns="replicate_id"
        )

        equal_expo = exposures.values == exposures.values[:, ].reshape((-1, 1))
        if not np.all(equal_expo):
            raise RuntimeError(
                "Replicates in the same treatment ID have different exposure patterns."
            )
        
def create_new_columns_and_test_integrity_of_replicates(
    exposure, survival, n_reps, path
):
    assert np.all(exposure.columns == survival.columns)
    
    columns_new, treatment_reps = identify_replicates(frame=exposure)

    if not np.all(np.array(list(treatment_reps.values())) == n_reps):
        warnings.warn(
            f"Actual treatment replicates are different from "
            f"replicates ({n_reps}), given in Info sheet in file: "
            f"{path}"
        )

    return columns_new

def identify_replicates(frame):
    df = frame.drop(columns="time")

    # Find identical columns and assign group labels
    group_labels = {}
    used_cols = set()
    treatment_map = {}

    for col in df.columns:
        if col not in used_cols:
            # compare the column to each column of the dataframe with 
            # df.apply(func, axis=0) and get the column names
            identical_cols = df.columns[df.apply(lambda x: x.equals(df[col]), axis=0)].tolist()
            group_label = f'{len(group_labels) + 1}'
            group_labels[group_label] = identical_cols
            used_cols.update(identical_cols)

            for icol in identical_cols:
                treatment_map.update({icol: group_label})

    columns_new = [f"{treatment_map[col]}__{col}" for col in df.columns]
    treatment_reps = {key: len(cols) for key, cols in group_labels.items()}

    return columns_new, treatment_reps



def read_timeseries_sheet(path, sheet, sep=None):
    ts = pd.read_excel(path, sheet_name=sheet, index_col=0)  # type: ignore
    multi_index = pd.MultiIndex.from_tuples(
        [tuple(c.split(sep)) for c in ts.columns], names=["treatment_id", "timeseries_id"]
    )
    ts.columns = multi_index
    return ts

def init_minimal_meta():
    return pd.DataFrame([
        ("experiment__interventions", None),
        ("experiment__observations", None),
        ("observation__unit", "-"),
        ("intervention__unit", "-"),
    ], columns=["Metadata", "Value"], dtype=object).set_index("Metadata")


class OpenGutsIO:
    # TODO: Use preprocessing here and use map as a class attribute
    def __init__(self, file: Optional[str] = None, preprocessing: Optional[Callable] = None):
        self._file = file
        self.preprocessing = preprocessing

        if file is not None:
            self.data = self.from_file(file)

    def _wide_to_long(self, frame, columns_new):
        frame_wide = frame.copy()

        frame_wide.columns = ["time"] + columns_new
        frame_long = pd.melt(
            frame=frame_wide, 
            id_vars=["time"], 
            value_vars=columns_new,
            var_name="group_id"
        )
        # create new index columns from new column names
        
        separated_ids = frame_long.group_id.str.split("__", n=1, expand=True)
        
        if len(separated_ids.columns) == 1:
            separated_ids[1] = 1

        frame_long[["treatment_id", "replicate_id"]] = separated_ids
        frame_long = frame_long.drop(columns="group_id")
        
        return frame_long


    def _merge_tables(self, tables: List):
        data = tables.pop(0).set_index(["time", "treatment_id", "replicate_id"])

        for expo in tables:
            rdata =expo.set_index(["time", "treatment_id", "replicate_id"])
            data = pd.merge(
                left=data, 
                right=rdata, 
                how="left", 
                left_index=True, 
                right_index=True
            )

        return data

    def _read_timeseries(self, path, sheets):
        # design new columns based on the information about replicates and treatments
        timeseries_long_list = []
        timeseries_column_list = []
        time_units = {}
        for iv in sheets:
            timeseries_df = pd.read_excel(path, sheet_name=f"{iv}") 

            time_column = timeseries_df.columns[0]
            time_unit = time_column.lower().replace("time", "").strip(" []").strip("()")

            # define replicates based on equality of columns
            timeseries_columns = [c for c in timeseries_df.columns[1:]]
            timeseries_long = self._wide_to_long(
                frame=timeseries_df, columns_new=timeseries_columns
            )
            intervention_long = timeseries_long.rename(columns={"value": iv})
            timeseries_long_list.append(intervention_long)
            timeseries_column_list.append(timeseries_columns)
            time_units.update({iv: time_unit})

        return self._merge_tables(timeseries_long_list).reset_index(), time_units


    def _read_openguts(
        self, 
        path: str, 
        metadata_sheetname: str = "meta", 
        interventions: Optional[List[str]] = None, 
        observations: Optional[List[str]] = None
    ):
        
        file = pd.ExcelFile(path)

        if metadata_sheetname in file.sheet_names:
            meta = file.parse(sheet_name=metadata_sheetname, index_col=0)
            meta = meta.dropna(how="all")
        else:
            meta = init_minimal_meta()

        
        ivs = meta.loc["experiment__interventions","Value"] 
        obs = meta.loc["experiment__observations","Value"] 
        
        if ivs is None:
            assert interventions is not None, (
                "'experiment__interventions' must be defined in metadata or passed "
                "as an argument"
            )
            ivs = f"[{','.join(interventions)}]"
            meta.loc["experiment__interventions", "Value"] = ivs


        if obs is None:
            assert observations is not None, (
                "'experiment__observations' must be defined in metadata or passed "
                "as an argument"
            )
            obs = f"[{','.join(observations)}]"
            meta.loc["experiment__observations" , "Value"] = obs
    
        # interventions specified in the sheet are ALWAYS preferred.
        intervention_sheets = [i.strip("[]' ") for i in ivs.split(",")]  # type: ignore

        # observations specified in the sheet are ALWAYS preferred.
        observation_sheets = [i.strip("[]' ") for i in obs.split(",")]  # type: ignore

        # survival_df = pd.read_excel(path, sheet_name="survival") 
        # survival_df = survival_df.rename(columns={"time [d]": "time"})

        # design new columns based on the information about replicates and treatments
        interventions_long, interventions_time_units = self._read_timeseries(path, intervention_sheets)
        observations_long, observations_time_units = self._read_timeseries(path, observation_sheets)
        time_unit = {
            "interventions": interventions_time_units,
            "observations": observations_time_units
        }

        # TODO test if all exposures within a treatment (replicates) were nominally the same 
        # test_equality_of_exposure_patterns_in_treatment(df=exposures_long)

        return interventions_long, observations_long, meta, time_unit

    @staticmethod
    def _write_openguts(observations: xr.Dataset, exposure_dim: str, path: str):

        """
        Export observations to OpenGUTS Excel format.

        Parameters
        ----------
        observations : xr.Dataset
            Dataset containing exposure and survival data.
        exposure_dim : str
            The name of the exposure dimension (typically 'substance' or 'exposure_path').
        path : str
            File path (including filename) where the Excel file will be written.
        time_unit : str
            Unit string for the time coordinate, used to label the exported time axis.

        Returns
        -------
        None
            The function writes an Excel workbook to ``path`` and does not return a value.

        Notes
        -----
        The method creates a sheet for each exposure dimension and a ``survival`` sheet.
        It ensures the output directory exists before writing.
        """
        os.makedirs(os.path.dirname(path), exist_ok=True)

        intervention_sheets = []
        observation_sheets = []

        intervention_units = {}
        observation_units = {}



        with pd.ExcelWriter(path) as writer:
            for i, (key, data) in enumerate(observations.data_vars.items()):
                data.to_pandas().T.to_excel(writer, sheet_name=key)

                if data.attrs["type"] == "intervention":
                    intervention_sheets.append(key)
                    intervention_units.update({key: data.attrs["unit"]})
                elif data.attrs["type"] == "observation":
                    observation_sheets.append(key)
                    observation_units.update({key: data.attrs["unit"]})


            meta = init_minimal_meta()

            meta.loc["experiment__interventions", "Value"] = f'[{",".join(intervention_sheets)}]'
            meta.loc["experiment__observations", "Value"] = f'[{",".join(observation_sheets)}]'
            meta.loc["observation__unit", "Value"] = ",".join([f"{key}:{value}" for key, value in observation_units.items()])
            meta.loc["intervention__unit", "Value"] = ",".join([f"{key}:{value}" for key, value in intervention_units.items()])
            
            # TODO: time unit is still open

            meta.to_excel(writer, sheet_name="meta")


    def from_file(self, file) -> None:
        warnings.warn("from_file is ambiguous, use from_excel_wide", category=DeprecationWarning)
        self.from_excel_wide(file)

    def from_excel_wide(
        self, 
        file,
        metadata_sheetname: str = "meta", 
        interventions: Optional[List[str]] = None, 
        observations: Optional[List[str]] = None
    ) -> None:
        (
            interventions_long, 
            observations_long, 
            meta, 
            time_unit
        ) = self._read_openguts(
            path=file, 
            metadata_sheetname=metadata_sheetname,
            interventions=interventions,
            observations=observations
        )

        self.interventions = interventions_long
        self.observations = observations_long
        self.time_unit = time_unit
        self.meta = meta

    def to_excel_wide(self):
        raise NotImplementedError(
            "This method should implement writing an excel file that corresponds"
            "to the original input file."
        )
    
    def to_experiment(self) -> Experiment:
        return Experiment.from_dict(data=dict(
            interventions=self.interventions, 
            observations=self.observations,
            meta=self.meta,
            time_units=self.time_unit
        ))

    def from_experiment(self, experiment: Experiment) -> None:
        data = experiment.to_dict()
        self.interventions=data["interventions"],
        self.observations=data["observations"],
        self.meta=data["meta"],
        self.time_units=data["time_units"],

    def to_xarray(self):
        return self.to_experiment().to_xarray()

    def from_xarray(self):
        raise NotImplementedError

    def to_excel_long(self, file, metadata_sheetname="meta"):
        """Write data to Excel file in long format.
        
        Creates an Excel file with:
        - meta sheet: Metadata from self.meta (including time units)
        - interventions sheet: All intervention data in long format
        - observations sheet: All observation data in long format
        
        Args:
            file: Path to output Excel file
            metadata_sheetname: Name of metadata sheet (default: "meta")
        """
        # Create a copy of meta to add time unit information
        meta_with_time_units = self.meta.copy()
        
        # Add time unit information to metadata
        # Format: time_unit__interventions__sheet_name = unit
        #         time_unit__observations__sheet_name = unit
        for data_type in ["interventions", "observations"]:
            for sheet_name, unit in self.time_unit[data_type].items():
                meta_key = f"time_unit__{data_type}__{sheet_name}"
                meta_with_time_units.loc[meta_key, "Value"] = unit
        
        with pd.ExcelWriter(file, engine="openpyxl") as writer:
            # Write metadata sheet with time units
            meta_with_time_units.to_excel(writer, sheet_name=metadata_sheetname)
            
            # Write interventions sheet (long format)
            self.interventions.to_excel(writer, sheet_name="interventions", index=False)
            
            # Write observations sheet (long format)
            self.observations.to_excel(writer, sheet_name="observations", index=False)

    def from_excel_long(self, file, metadata_sheetname="meta"):
        """Read data from Excel file in long format.
        
        Reads an Excel file with:
        - meta sheet: Metadata including time units
        - interventions sheet: All intervention data in long format
        - observations sheet: All observation data in long format
        
        Args:
            file: Path to input Excel file
            metadata_sheetname: Name of metadata sheet (default: "meta")
        """
        # Read metadata
        meta = pd.read_excel(file, sheet_name=metadata_sheetname, index_col=0)
        
        # Read interventions and observations
        interventions = pd.read_excel(file, sheet_name="interventions")
        observations = pd.read_excel(file, sheet_name="observations")
        
        # Extract time units from metadata
        time_unit = {"interventions": {}, "observations": {}}
        for idx in meta.index:
            if idx.startswith("time_unit__"):
                parts = idx.split("__")
                if len(parts) == 3:
                    data_type, sheet_name = parts[1], parts[2]
                    unit = meta.loc[idx, "Value"]
                    time_unit[data_type][sheet_name] = unit if isinstance(unit, str) else ""
        
        # Set instance attributes
        self.meta = meta
        self.interventions = interventions
        self.observations = observations
        self.time_unit = time_unit

def preprocess(path, func=None, out=None):
    if func is not None:
        if out is None:
            filename = os.path.dirname(path)
            directory = os.path.basename(filename)
            new_path = path.replace(directory, f"processed_{directory}")
        else:
            filename = os.path.basename(path)
            new_path = out.format(filename=filename)

        os.makedirs(os.path.dirname(new_path), exist_ok=True)
    
        processed_path = func(path, new_path)
    else:
        processed_path = path

    return processed_path

def import_data_to_database(path, database, preprocessing: Optional[Callable] = None, preprocessing_out: Optional[str] = None):
    """This script takes raw data, preprocesses it to contain all 
    necessary metadata for expyDB. Then it creates an experiment Model and 
    processes adds it to the database
    """
    # preprocess path
    processed_path = preprocess(path, preprocessing, preprocessing_out)

    # Preprocess excel to interventions and observations in Long form and a 
    # metadata Series as well as a default time unit
    openguts = OpenGutsIO(processed_path)
    
    # From excel to an Experiment Model instance
    experiment = openguts.to_experiment()

    # from the Model to the Database
    if not os.access(database, os.W_OK):
        warnings.warn(
            f"Did not write to database. The file '{database}' does "
            "not have write access."
        )
        return
    
    experiment.to_database(database=database)

    print("Import to database successful.")


def create_database_and_import_data_main(datasets_path, database_path, preprocessing=None, preprocessing_out=None):
    print("\n")
    print(f"Creating a database and importing data")
    print(f"======================================")

    if preprocessing is not None:
        module, func = preprocessing.rsplit(".", 1)
        mod = import_module(module)
        preprocessing_func = getattr(mod, func)
    else:
        preprocessing_func = None

    paths = []
    for p in datasets_path:
        if os.path.isfile(p):
            paths.append(p)
        else:
            paths.extend(glob.glob(os.path.join(p, "*.xlsx")))

    create_database(database=database_path, force=True)
    for p in paths:
        print(f"\nPreprocessing and importing file: {p}")
        import_data_to_database(
            path=p, database=database_path, 
            preprocessing=preprocessing_func,
            preprocessing_out=preprocessing_out
        )

@click.command()
@click.option("--datasets_path", type=str, multiple=True, help="The path to the directory where the excel files are located. Alternatively, use multiple times with paths to files")
@click.option("--database_path", type=str, help="The path to the database (should end with .db)")
@click.option("--preprocessing", type=str, help="Function used to preprocess the data", default=None)
@click.option("--preprocessing-out", type=str, help="A pattern that uses {filename} as a placeholder e.g. 'data/processed_data/{filename}. If unset, preprends 'processes_' to the dirname", default=None)
def create_database_and_import_data(datasets_path, database_path, preprocessing, preprocessing_out):
    create_database_and_import_data_main(
        datasets_path=datasets_path,
        database_path=database_path,
        preprocessing=preprocessing,
        preprocessing_out=preprocessing_out
    )