import xarray as xr
from typing import Literal, Dict, Optional, Callable, Tuple
from pymob.sim.config import Config
from guts_base.data.transform import GutsDataset
import pathlib

class Migration:
    cfg: Config
    dataset: xr.Dataset
    data_path: pathlib.Path
    new_version = "2.1.0"

    def __init__(
        self, 
        path: str ,
        model_type_if_not_specified_in_config = None, 
        overwrite_old_dataset: bool = False
    ) -> None:
        self.model_type_if_not_specified_in_config = model_type_if_not_specified_in_config
        self.overwrite_old_dataset = overwrite_old_dataset

        self.cfg = Config(path)

    def load_scenario(self):
        data_path = pathlib.Path(str(self.cfg.case_study.observations))
        if data_path.exists():
            self.data_path = data_path
        else:
            self.data_path = pathlib.Path(str(self.cfg.case_study.data_path)) / data_path
        self.cfg.case_study.observations = str(self.data_path)
        self.dataset = xr.load_dataset(self.cfg.case_study.observations)


    def migrate_config(self, ) -> None:
        cfg = self.cfg
        simulation_extra: Dict = cfg.simulation.model_extra  # type: ignore

        if "n_reindexed" in simulation_extra:
            cfg.guts_base.n_reindexed_x = simulation_extra.pop("n_reindexed_x")

        if "unit_time" in simulation_extra:
            unit_time = simulation_extra.pop("unit_time")
            cfg.guts_base.unit_time = unit_time

        if "forward_interpolate_exposure_data" in simulation_extra:
            fied = simulation_extra.pop("forward_interpolate_exposure_data")
            cfg.guts_base.forward_interpolate_exposure_data = fied


    def migrate_dataset(self) -> None:
        cfg = self.cfg
        if cfg.simulation.model is None:
            if self.model_type_if_not_specified_in_config is None:
                raise RuntimeError(
                    "if config.simulation.model = None, fallback must be specified manually "+
                    "with model_type_if_not_specified_in_config"
                )
            else:
                model_type = self.model_type_if_not_specified_in_config
        else:
            model_type = "SD" if "_sd" in cfg.simulation.model else "IT"

        dataset_migrated = GutsDataset(
            exposure=("exposure", ["exposure"]),
            drop_original_exposure_vars=False,
            model_type=model_type,
            n_reindexed_x=self.cfg.guts_base.n_reindexed_x
        ).to_gutsbase_dataset(dataset=self.dataset) # type: ignore

        dataset_migrated = dataset_migrated.assign_coords(eps=cfg.jaxsolver.atol * 10)

        self.dataset = dataset_migrated
 

    def apply_migration(self):
        if self.cfg.case_study.version == self.new_version:
            print(f"Skipping migration. Scenario is already at version {self.new_version}")
            return
        else: 
            self.cfg.case_study.version = self.new_version
        self.load_scenario()
        self.migrate_config()
        self.migrate_dataset()
        self.write_data()

    def write_data(self):
        if self.overwrite_old_dataset:
            stem_mod = self.data_path.stem
        else:
            stem_mod = self.data_path.stem + "_v" + self.new_version.replace(".", "_")
        
        assert self.cfg.simulation.model_extra is not None
        if len(self.cfg.simulation.model_extra) == 0:
            new_path = self.data_path.with_stem(stem_mod)

            self.cfg.case_study.observations = str(new_path)
            self.dataset.to_netcdf(path=self.cfg.case_study.observations)
            self.cfg.save(force=True)
            
        else:
            raise RuntimeError(
                f"Not all config sections were successfully migrated: {self.cfg.simulation.__pydantic_extra__}"
            )



if __name__ == "__main__":
    Migration("scenarios/red_sd/settings.cfg").apply_migration()
    Migration("scenarios/red_sd_da/settings.cfg").apply_migration()
