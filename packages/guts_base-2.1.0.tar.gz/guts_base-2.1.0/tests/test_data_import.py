# TODO: Set up data import pipelines and templates for importing data into expyDB
# TODO: Test plotting
# TODO: Run a simple test case with the ring test data
import pandas as pd
from datetime import datetime, timedelta
import tempfile
from click.testing import CliRunner
from guts_base.data import create_database_and_import_data, OpenGutsIO, time_of_death_to_openguts

def test_data_import_openguts():
    tempdir = tempfile.TemporaryDirectory()

    runner = CliRunner(echo_stdin=True)
    result = runner.invoke(
        create_database_and_import_data, 
        catch_exceptions=False,
        args=[
            "--datasets_path", "data/templates/ringtest_A_SD_openguts_notation.xlsx", 
            "--database_path", f"{tempdir.name}/ringtest.db", 
            "--preprocessing", "guts_base.data.preprocessing.ringtest",
            "--preprocessing-out", f"{tempdir.name}/processed_{{filename}}"
        ]
    )

    if isinstance(result.exception, SystemExit):
        raise KeyError(
            "Invokation of the click command did not execute correctly. " +
            f"Recorded output: {' '.join(result.output.splitlines())}"
        )
    
    else:
        print(result.output)

def test_data_import_time_of_death():
    tempdir = tempfile.TemporaryDirectory()
    runner = CliRunner(echo_stdin=True)
    result = runner.invoke(
        time_of_death_to_openguts, 
        catch_exceptions=False,
        args=[
            "--file", "data/templates/ringtest_A_SD_time_of_death_notation.xlsx", 
            "--sheet", "time-of-death", 
            "--out", tempdir.name + "/openguts_ringtest_A_SD_time_of_death_notation.xlsx",
            "-c", "exposure"
        ]
    )

    if isinstance(result.exception, SystemExit):
        raise KeyError(
            "Invokation of the click command did not execute correctly. " +
            f"Recorded output: {' '.join(result.output.splitlines())}"
        )
    
    else:
        print(result.output)
    
    # this will raise an assertion error if the data cannot be converted to
    # an experiment
    io = OpenGutsIO(f"{tempdir.name}/openguts_ringtest_A_SD_time_of_death_notation.xlsx")
    
    io.to_excel_long(f"{tempdir.name}/long_ringtest_A_SD_time_of_death_notation.xlsx")
    io.from_excel_long(f"{tempdir.name}/long_ringtest_A_SD_time_of_death_notation.xlsx")
    
    io.to_experiment()


def test_tod_to_openguts():
    """Tests only the conversion, there is no pre-processing template in place.
    This would have to be built.
    """
    tempdir = tempfile.TemporaryDirectory()
    runner = CliRunner(echo_stdin=True)
    result = runner.invoke(
        time_of_death_to_openguts, 
        catch_exceptions=False,
        args=[
            "--file", "data/templates/tktd_data_template_time_of_death_notation.xlsx", 
            "--sheet", "time-of-death",
            "--out", tempdir.name + "/openguts_tktd_data_template_time_of_death_notation.xlsx",
            "-c", "concentration_pesticide__mg/g",
            "-c", "concentration_pesticide_B__mg/g"
        ],
    )

    if isinstance(result.exception, SystemExit):
        raise KeyError(
            "Invokation of the click command did not execute correctly. " +
            f"Recorded output: {' '.join(result.output.splitlines())}"
        )
    
    else:
        print(result.output)
        
    
    processed_data = pd.read_excel(
        f"{tempdir.name}/openguts_tktd_data_template_time_of_death_notation.xlsx",
        sheet_name=None
    )

    pd.testing.assert_frame_equal(
        processed_data["concentration_pesticide__mg_g"],
        pd.DataFrame({
            "time [d]": [0, 1/24, 64],
            "01__1": [0,0,0],
            "02__2": [0,0,0],
        })
    )

    pd.testing.assert_frame_equal(
        processed_data["concentration_pesticide_b__mg_g"],
        pd.DataFrame({
            "time [d]": [0, 1/24, 64],
            "01__1": [0,0,0],
            "02__2": [0.5,0,0],
        })
    )


    pd.testing.assert_frame_equal(
        processed_data["survival"],
        pd.DataFrame({
            "time [d]":  list(range(65)),
            "01__1": [
                30,28,26,26,26,26,26,26,25,24,24,24,24,24,24,24,24,24,24,24,24,
                24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,
                24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,
                24,24],
            "02__2": [
                30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,27,27,27,26,26,25,
                25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,
                25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,
                25,24],
        })
    )


def test_import_then_run(tmp_path):
    from guts_base.data.transform import ExcelWide, GutsDataset, SQLConnection, registry
    from expyDB.intervention_model import Experiment, Timeseries, Treatment, select
    from expyDB import create_database
    from guts_base import GutsBase

    excel_wide = ExcelWide(
        "data/testing/Fit_Data_Cloeon_final.xlsx", 
        intervention_sheets=["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"],
        observation_sheets=["Survival"]
    )

    

    sql = SQLConnection(conn_str=str(tmp_path / "db.sqlite"))
    create_database(database=sql.conn_str, force=True)
    registry.transform(excel_wide, sql)


    query = (
        select(Timeseries, Treatment)
        .join(Timeseries,)
    ).where(
        Timeseries.variable.in_(["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"]),
        # data.Timeseries.method.in_(exposure_path),  # type: ignore
    )
    sql = SQLConnection(conn_str=sql.conn_str, query=query)
    
    
    guts_dataset = GutsDataset(
        model_type="IT",
        exposure=("substance", ["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"]),
        indices=(),
        n_reindexed_x=100,
    )
    dataset = registry.transform(sql, guts_dataset)
    fp = str(tmp_path / "data_cloeon_final_from_dataflow.nc")

    dataset.to_netcdf(fp)

    sim = GutsBase()
    sim.config.case_study.observations = fp
    sim.config.simulation.model_class = "guts_base.mod.RED_SD_DA"
    sim.setup()


if __name__ == "__main__":

    test_data_import_openguts()
    test_data_import_time_of_death()
    test_tod_to_openguts()