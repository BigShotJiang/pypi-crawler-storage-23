"""Test file for exploring the data transformation framework.

This is a minimal test file to explore the implementation of the
data transformation framework.
"""

import pytest
import xarray as xr
import pandas as pd
from expyDB.intervention_model import Experiment, Timeseries, Treatment, select
from expyDB import create_database

from guts_base.data.transform import registry, ExcelWide, ExcelLong, ExcelWideUnprocessedMeta, SQLConnection
from guts_base.data.preprocessing import ringtest


def test_xarray_to_sql(tmp_path):
    pytest.skip()
    """Test bidirectional XARRAY ↔ EXCEL [wide]"""
    # Create test xarray with simple structure
    ds = xr.load_dataset("data/testing/red_sd_it_observations.nc")

    # Transform to Excel
    excel_wide = ExcelWide(str(tmp_path / "wide.xlsx"))

    registry.transform(ds, excel_wide)

    # Transform back
    ds_back = registry.transform(excel_wide, xr.Dataset)

    # Verify - check that data values are preserved
    import numpy as np
    np.testing.assert_array_equal(ds_back["exposure"].values, ds["exposure"].values)
    np.testing.assert_array_equal(ds_back["survival"].values, ds["survival"].values)

def test_excel_wide_to_sql(tmp_path):
    excel_wide_ringtest = ExcelWideUnprocessedMeta(
        "data/templates/ringtest_A_SD_openguts_notation.xlsx",
        preprocessing_func=ringtest
    )
    excel_wide = ExcelWide(str(tmp_path / "wide.xlsx"))
    excel_long = ExcelLong(str(tmp_path / "long.xlsx"))
    sql = SQLConnection(conn_str=str(tmp_path / "db.sqlite"))
    create_database(database=sql.conn_str, force=True)
    

    registry.transform(excel_wide_ringtest, excel_wide)
    registry.transform(excel_wide, excel_long)
    experiment = registry.transform(excel_long, Experiment)

    from expyDB.intervention_model import PandasConverter

    conv = PandasConverter(experiment)
    conv.data["survival"]
    registry.transform(experiment, sql)  

    registry

def test_excel_wide_to_sql_roundtrip(tmp_path):
    excel_wide_ringtest = ExcelWideUnprocessedMeta(
        "data/templates/ringtest_A_SD_openguts_notation.xlsx",
        preprocessing_func=ringtest
    )
    sql = SQLConnection(conn_str=str(tmp_path / "db.sqlite"))
    create_database(database=sql.conn_str, force=True)
    registry.transform(excel_wide_ringtest, sql)


    query = (
        select(Timeseries, Treatment)
        .join(Timeseries,)
    ).where(
        Timeseries.variable.in_(["exposure"]),
        # data.Timeseries.method.in_(exposure_path),  # type: ignore
    )
    sql = SQLConnection(conn_str=sql.conn_str, query=query)
    

    
    excel_wide = ExcelWide(str(tmp_path / "wide.xlsx"), exposure_dim="substances")
    registry.transform(sql, excel_wide)

    excel_wide

def test_excel_multisubstance_wide_to_sql_roundtrip(tmp_path):
    excel_wide = ExcelWide(
        "data/testing/Fit_Data_Cloeon_final.xlsx", 
        intervention_sheets=["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"],
        observation_sheets=["Survival"]
    )

    

    sql = SQLConnection(conn_str=str(tmp_path / "db.sqlite"))
    create_database(database=sql.conn_str, force=True)
    registry.transform(excel_wide, sql)


    query = (
        select(Timeseries, Treatment)
        .join(Timeseries,)
    ).where(
        Timeseries.variable.in_(["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"]),
        # data.Timeseries.method.in_(exposure_path),  # type: ignore
    )
    sql = SQLConnection(conn_str=sql.conn_str, query=query)
    
    
    excel_wide_result = ExcelWide(
        str(tmp_path / "wide_roundtrip.xlsx"), 
        intervention_sheets=["Exposure_FLUA_ug_dl", "Exposure_CYP_ng_l"],
        observation_sheets=["Survival"]
    )
    registry.transform(sql, excel_wide_result)

    excel_wide_result

    # TODO: 
    pd.read_excel(excel_wide_result.path, sheet_name="Survival")
    pd.read_excel(excel_wide.path, sheet_name="Survival")




def test_excel_wide_to_long(tmp_path):
    pytest.skip()
    """Test EXCEL [wide] → EXCEL [LONG]"""
    # Create test Excel wide


    excel_wide = ExcelWide("data/templates/ringtest_A_SD_openguts_notation.xlsx")

    excel_long = ExcelLong(str(tmp_path / "long.xlsx"))

    # Transform to long
    registry.transform(excel_wide, excel_long)

    # Verify
    df_long = pd.read_excel(excel_long.path)
    assert "variable" in df_long.columns
    assert "value" in df_long.columns


def test_auto_path_finding(tmp_path):
    pytest.skip()
    """Test automatic path finding for multi-step transformations"""
    # Create test Excel wide
    df = pd.DataFrame(
        {
            "time": [0, 1],
            "treatment_id": ["t1", "t1"],
            "replicate_id": ["r1", "r1"],
            "exposure": [1.0, 3.0],
            "survival": [10, 8],
        }
    )
    wide_path = tmp_path / "wide.xlsx"
    long_path = tmp_path / "long.xlsx"
    df.to_excel(wide_path, index=False)

    # Manual multi-step transformation: ExcelWide → ExcelLong → Xarray
    excel_wide = ExcelWide(str(wide_path))
    excel_long = ExcelLong(str(long_path))
    registry.transform(excel_wide, excel_long)
    ds = registry.transform(excel_long, xr.Dataset)

    registry.visualize_dag()

    # Verify
    assert isinstance(ds, xr.Dataset)
    assert "exposure" in ds.data_vars


if __name__ == "__main__":
    # Run tests manually for exploration
    from pathlib import Path

    tmp_path = Path("results/testing/data_transforms")
    tmp_path.mkdir(parents=True, exist_ok=True)

    print("Testing XARRAY ↔ EXCEL [wide]...")
    test_xarray_to_sql(tmp_path)
    print("✓ Passed")

    print("Testing XARRAY ↔ EXCEL [wide]...")
    test_excel_wide_to_sql(tmp_path)
    test_excel_wide_to_sql_roundtrip(tmp_path)
    test_excel_multisubstance_wide_to_sql_roundtrip(tmp_path)
    print("✓ Passed")


    print("Testing EXCEL [wide] → EXCEL [LONG]...")
    test_excel_wide_to_long(tmp_path)
    print("✓ Passed")

    print("Testing auto-path finding...")
    test_auto_path_finding(tmp_path)
    print("✓ Passed")

    print("\nAll tests passed!")