---
description: To get documentation for Django settings
---

To get information about Django settings look at:
- scripts/global_settings.py which are the current values for all defaults settings (as of Django 6.0)
- scripts/settings.txt which is the current RST documentation for all settings (as of Django 6.0)