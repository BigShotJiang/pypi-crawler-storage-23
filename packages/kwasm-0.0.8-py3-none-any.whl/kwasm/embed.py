"""Embed kwasm GDS viewer in Jupyter notebooks."""

import base64
import html
import tempfile
import warnings
from pathlib import Path
from typing import Any, cast

# Installed package: WASM artifacts bundled next to this file
_PKG_DIST = Path(__file__).parent / "dist"
# Dev mode: artifacts at repo root
_REPO_DIST = Path(__file__).parents[2] / "dist"

DIST = _PKG_DIST if _PKG_DIST.exists() else _REPO_DIST


def _netlist_to_bytes(netlist):
    """Convert a netlist argument to bytes.

    Accepts a file path (str or Path) or a dict (serialized to JSON,
    which is valid YAML and parsed by the Rust backend).
    """
    if isinstance(netlist, dict):
        import json

        return json.dumps(netlist).encode()
    elif netlist is not None:
        return Path(netlist).read_bytes()
    return None


def _read_artifacts():
    """Read pre-built WASM artifacts from dist/."""
    html_path = DIST / "index.html"
    js_path = DIST / "kwasm.js"
    wasm_path = DIST / "kwasm.wasm"

    for p in [html_path, js_path, wasm_path]:
        if not p.exists():
            raise FileNotFoundError(f"{p} not found. Run 'just build-wasm' first.")

    return (
        html_path.read_text(),
        js_path.read_text(),
        base64.b64encode(wasm_path.read_bytes()).decode("ascii"),
    )


def _build_html(
    gds_bytes,
    tools=(),
    drop=False,
    layers=True,
    lyp_bytes=None,
    lyrdb_bytes=None,
    netlist_bytes=None,
):
    """Build a self-contained HTML string with embedded WASM and GDS."""
    html_template, js_glue, wasm_b64 = _read_artifacts()
    gds_b64 = base64.b64encode(gds_bytes).decode("ascii")

    lyp_snippet = ""
    if lyp_bytes is not None:
        lyp_b64 = base64.b64encode(lyp_bytes).decode("ascii")
        lyp_snippet = (
            "\n"
            "    // --- Embedded LYP layer properties (base64 -> Blob URL) ---\n"
            "    (function() {\n"
            f'        var lypB64 = "{lyp_b64}";\n'
            "        var lypBin = Uint8Array.from(atob(lypB64), function(c) { return c.charCodeAt(0); });\n"
            "        window._kwasmLypUrl = URL.createObjectURL(new Blob([lypBin]));\n"
            "    })();\n"
        )

    lyrdb_snippet = ""
    if lyrdb_bytes is not None:
        lyrdb_b64 = base64.b64encode(lyrdb_bytes).decode("ascii")
        lyrdb_snippet = (
            "\n"
            "    // --- Embedded LYRDB report database (base64 -> Blob URL) ---\n"
            "    (function() {\n"
            f'        var lyrdbB64 = "{lyrdb_b64}";\n'
            "        var lyrdbBin = Uint8Array.from(atob(lyrdbB64), function(c) { return c.charCodeAt(0); });\n"
            "        window._kwasmLyrdbUrl = URL.createObjectURL(new Blob([lyrdbBin]));\n"
            "    })();\n"
        )

    netlist_snippet = ""
    if netlist_bytes is not None:
        netlist_b64 = base64.b64encode(netlist_bytes).decode("ascii")
        netlist_snippet = (
            "\n"
            "    // --- Embedded netlist YAML (base64 -> Blob URL) ---\n"
            "    (function() {\n"
            f'        var netlistB64 = "{netlist_b64}";\n'
            "        var netlistBin = Uint8Array.from(atob(netlistB64), function(c) { return c.charCodeAt(0); });\n"
            "        window._kwasmNetlistUrl = URL.createObjectURL(new Blob([netlistBin]));\n"
            "    })();\n"
        )

    embedded_script = (
        "<script>\n"
        "    // --- Embedded WASM binary (base64) ---\n"
        "    (function() {\n"
        f'        var wasmB64 = "{wasm_b64}";\n'
        "        var wasmBin = Uint8Array.from(atob(wasmB64), function(c) { return c.charCodeAt(0); });\n"
        "        Module.wasmBinary = wasmBin.buffer;\n"
        "    })();\n"
        "\n"
        "    // --- Embedded GDS layout (base64 -> Blob URL) ---\n"
        "    (function() {\n"
        f'        var gdsB64 = "{gds_b64}";\n'
        "        var gdsBin = Uint8Array.from(atob(gdsB64), function(c) { return c.charCodeAt(0); });\n"
        "        window._embeddedLayoutUrl = URL.createObjectURL(new Blob([gdsBin]));\n"
        "    })();\n"
        f"{lyp_snippet}"
        f"{lyrdb_snippet}"
        f"{netlist_snippet}"
        "</script>\n"
        "<script>\n"
        f"{js_glue}\n"
        "</script>"
    )

    result = html_template.replace(
        '<script async src="kwasm.js"></script>', embedded_script
    )
    result = result.replace("|| 'layout.gds'", "|| ''")

    # Inject overrides for the in-page JS to pick up
    drop_js = "window._kwasmDropDisabled = true;" if not drop else ""
    layers_js = "window._kwasmLayersDisabled = true;" if not layers else ""
    tools_value = ",".join(tools)
    override_script = (
        "<script>"
        f"Object.defineProperty(window, '_kwasmToolsOverride', {{value: '{tools_value}'}});"
        f"{drop_js}"
        f"{layers_js}"
        "</script>"
    )
    result = result.replace("<script>", override_script + "\n<script>", 1)

    return result


def bundle(gds, output=None, lyp=None, lyrdb=None, netlist=None):
    """Bundle a GDS layout into a single self-contained HTML file."""
    gds_path = Path(gds)
    if output is None:
        output = f"{gds_path.stem}.html"
    gds_bytes = gds_path.read_bytes()
    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)
    html_str = _build_html(
        gds_bytes,
        tools=(
            "select",
            "move",
            "ruler",
            "clear-rulers",
            "fit-all",
            "reload",
            "top-ports",
            "instance-ports",
            "text",
            "theme",
        ),
        drop=True,
        layers=True,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    # Update title with the GDS filename
    html_str = html_str.replace(
        "<title>kwasm - Layout Viewer</title>",
        f"<title>kwasm - {gds_path.stem}</title>",
    )
    out = Path(output)
    out.write_text(html_str)
    return out


def show(
    component_or_path,
    height=500,
    tools=(),
    drop=False,
    layers=True,
    lyp=None,
    lyrdb=None,
    netlist=None,
):
    """Display a GDS layout in a Jupyter notebook using kwasm.

    Args:
        component_or_path: A file path (str or Path) to a .gds file,
            or a gdsfactory Component (anything with a .write_gds() method).
        height: Height of the viewer in pixels.
        tools: Tuple/list of toolbar tool names to show. Empty (default)
            hides the toolbar. Available names: select, move, ruler,
            clear-rulers, fit-all, reload, top-ports, instance-ports,
            text, theme.
        drop: Whether to enable drag & drop of GDS files. Defaults to False.
        layers: Whether to show the layer panel. Defaults to True.
        lyp: Optional path (str or Path) to a .lyp layer properties file.
        lyrdb: Optional path (str or Path) to a .lyrdb report database file.
        netlist: Optional path (str or Path) to a .pic.yml netlist file,
            or a dict (serialized to JSON for the WASM backend).

    Returns:
        IPython.display.HTML object for notebook rendering.
    """
    from IPython.display import HTML

    path = (
        Path(component_or_path) if isinstance(component_or_path, (str, Path)) else None
    )

    if path is not None:
        gds_bytes = path.read_bytes()
    else:
        # Duck-type: assume it has .write_gds()
        with tempfile.NamedTemporaryFile(suffix=".gds", delete=False) as f:
            tmp = Path(f.name)
        try:
            cast(Any, component_or_path).write_gds(tmp)
            gds_bytes = tmp.read_bytes()
        finally:
            tmp.unlink(missing_ok=True)

    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)

    full_html = _build_html(
        gds_bytes,
        tools=tools,
        drop=drop,
        layers=layers,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    escaped = html.escape(full_html, quote=True)

    iframe = (
        f'<iframe srcdoc="{escaped}" '
        f'width="100%" height="{height}" '
        f'style="border:none"></iframe>'
    )

    # IPython suggests IFrame, but IFrame only supports src (URLs),
    # not srcdoc (inline HTML). Suppress the warning.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return HTML(iframe)
