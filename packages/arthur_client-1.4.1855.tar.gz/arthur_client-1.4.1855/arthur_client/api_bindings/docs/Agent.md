# Agent

Request model for agent upsert - nested entities without IDs.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the agent. | 
**data_plane_id** | **str** | UUID of the data plane where this agent was detected. | 
**task_id** | **str** | UUID of the associated task. | 
**creation_source** | [**AgentCreationSource**](AgentCreationSource.md) | Information about how this agent was created. | 
**model_id** | **str** |  | [optional] 
**num_spans** | **int** | Number of spans associated with this agent. | [optional] [default to 0]
**is_autocreated** | **bool** | Whether this agent was auto-created from traces. | [optional] [default to True]
**rules** | [**List[RuleResponse]**](RuleResponse.md) | Rules associated with this agent&#39;s task. | [optional] 
**last_fetched** | **datetime** |  | [optional] 
**tools** | [**List[Tool]**](Tool.md) | Tools used by this agent. | [optional] 
**sub_agents** | [**List[SubAgent]**](SubAgent.md) | Sub-agents used by this agent. | [optional] 
**llm_models** | [**List[LLMModel]**](LLMModel.md) | LLM models used by this agent. | [optional] 
**data_sources** | [**List[DataSource]**](DataSource.md) | Data sources used by this agent. | [optional] 

## Example

```python
from arthur_client.api_bindings.models.agent import Agent

# TODO update the JSON string below
json = "{}"
# create an instance of Agent from a JSON string
agent_instance = Agent.from_json(json)
# print the JSON string representation of the object
print(Agent.to_json())

# convert the object into a dict
agent_dict = agent_instance.to_dict()
# create an instance of Agent from a dict
agent_from_dict = Agent.from_dict(agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


