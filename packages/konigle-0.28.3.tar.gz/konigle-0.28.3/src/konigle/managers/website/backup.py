"""
Backup managers for the Konigle SDK.

This module provides managers for backup resources, enabling backup
creation, listing, deletion, and restoration operations.
"""

from typing import Dict, cast

from konigle.filters.website import BackupFilters
from konigle.managers.base import BaseAsyncManager, BaseSyncManager
from konigle.models.website.backup import Backup, BackupCreate


class BaseBackupManager:
    resource_class = Backup
    """The resource model class this manager handles."""

    base_path = "/backup/api/v1/backups"
    """The API base path for this resource type."""

    filter_class = BackupFilters
    """The filter class used for listing resources."""


class BackupManager(BaseBackupManager, BaseSyncManager):
    """Manager for backup resources."""

    def create(self, data: BackupCreate) -> Backup:
        """Create a new backup.

        Args:
            data: Backup creation data including kind, backup_type,
                  target_id, description, and trigger.

        Returns:
            Created backup resource.
        """
        return cast(Backup, super().create(data))

    def restore(self, id_: str) -> Dict[str, str]:
        """Restore a backup.

        Args:
            id_: ID of the backup to restore.

        Returns:
            Dictionary with restoration status.
        """
        path = f"{self.base_path}/{id_}/restore"
        response = self._session.post(path)
        return response.json()


class AsyncBackupManager(BaseBackupManager, BaseAsyncManager):
    """Async manager for backup resources."""

    async def create(self, data: BackupCreate) -> Backup:
        """Create a new backup.

        Args:
            data: Backup creation data including kind, backup_type,
                  target_id, description, and trigger.

        Returns:
            Created backup resource.
        """
        return cast(Backup, await super().create(data))

    async def restore(self, id_: str) -> Dict[str, str]:
        """Restore a backup.

        Args:
            id_: ID of the backup to restore.

        Returns:
            Dictionary with restoration status.
        """
        path = f"{self.base_path}/{id_}/restore"
        response = await self._session.post(path)
        return response.json()
