"""
Calculator package.

Provides standard and scientific calculators and unit converters.
"""

from calculator.main import main

__all__ = ["main"]
