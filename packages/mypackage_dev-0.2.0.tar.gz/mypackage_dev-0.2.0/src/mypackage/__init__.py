"""
MyPackage - A sample Python package with semantic versioning.

This package demonstrates best practices for creating and publishing
Python packages to PyPI with support for multiple environments.
"""

__version__ = "0.2.0"

from .calculator import add, divide, modulo, multiply, power, subtract
from .data_processor import (
    filter_even,
    find_median,
    get_statistics,
    remove_duplicates,
    sum_list,
)
from .text_utils import (
    capitalize_words,
    count_words,
    is_palindrome,
    remove_whitespace,
    reverse_string,
)

__all__ = [
    "add",
    "subtract",
    "multiply",
    "divide",
    "power",
    "modulo",
    "capitalize_words",
    "reverse_string",
    "count_words",
    "is_palindrome",
    "remove_whitespace",
    "filter_even",
    "sum_list",
    "get_statistics",
    "find_median",
    "remove_duplicates",
]
