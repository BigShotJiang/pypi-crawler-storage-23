"""
Calculator module providing basic arithmetic operations.
"""

from typing import Union

Number = Union[int, float]


def add(a: Number, b: Number) -> Number:
    """
    Add two numbers.

    Args:
        a: First number
        b: Second number

    Returns:
        Sum of a and b

    Example:
        >>> add(2, 3)
        5
        >>> add(2.5, 3.5)
        6.0
    """
    return a + b


def subtract(a: Number, b: Number) -> Number:
    """
    Subtract second number from first number.

    Args:
        a: First number
        b: Second number

    Returns:
        Difference of a and b

    Example:
        >>> subtract(5, 3)
        2
        >>> subtract(10.5, 3.5)
        7.0
    """
    return a - b


def multiply(a: Number, b: Number) -> Number:
    """
    Multiply two numbers.

    Args:
        a: First number
        b: Second number

    Returns:
        Product of a and b

    Example:
        >>> multiply(2, 3)
        6
        >>> multiply(2.5, 4)
        10.0
    """
    return a * b


def divide(a: Number, b: Number) -> float:
    """
    Divide first number by second number.

    Args:
        a: Numerator
        b: Denominator

    Returns:
        Quotient of a and b

    Raises:
        ValueError: If b is zero

    Example:
        >>> divide(6, 3)
        2.0
        >>> divide(10, 4)
        2.5
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def power(base: Number, exponent: Number) -> Number:
    """
    Raise base to the power of exponent.

    Args:
        base: Base number
        exponent: Exponent

    Returns:
        Result of base raised to exponent

    Example:
        >>> power(2, 3)
        8
        >>> power(5, 2)
        25
        >>> power(2.5, 2)
        6.25
    """
    return base**exponent


def modulo(a: int, b: int) -> int:
    """
    Calculate the modulo (remainder) of a divided by b.

    Args:
        a: Dividend
        b: Divisor

    Returns:
        Remainder of a divided by b

    Raises:
        ValueError: If b is zero

    Example:
        >>> modulo(10, 3)
        1
        >>> modulo(15, 4)
        3
        >>> modulo(8, 2)
        0
    """
    if b == 0:
        raise ValueError("Cannot perform modulo with zero")
    return a % b
