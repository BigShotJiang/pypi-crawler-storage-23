"""
Text utility functions for string manipulation.
"""


def capitalize_words(text: str) -> str:
    """
    Capitalize the first letter of each word in a string.

    Args:
        text: Input string

    Returns:
        String with each word capitalized

    Example:
        >>> capitalize_words("hello world")
        'Hello World'
        >>> capitalize_words("python programming")
        'Python Programming'
    """
    return text.title()


def reverse_string(text: str) -> str:
    """
    Reverse a string.

    Args:
        text: Input string

    Returns:
        Reversed string

    Example:
        >>> reverse_string("hello")
        'olleh'
        >>> reverse_string("Python")
        'nohtyP'
    """
    return text[::-1]


def count_words(text: str) -> int:
    """
    Count the number of words in a string.

    Args:
        text: Input string

    Returns:
        Number of words in the string

    Example:
        >>> count_words("hello world")
        2
        >>> count_words("Python is awesome")
        3
    """
    if not text or text.isspace():
        return 0
    return len(text.split())


def is_palindrome(text: str) -> bool:
    """
    Check if a string is a palindrome (reads the same forwards and backwards).

    Args:
        text: Input string

    Returns:
        True if the string is a palindrome, False otherwise

    Example:
        >>> is_palindrome("racecar")
        True
        >>> is_palindrome("hello")
        False
        >>> is_palindrome("A man a plan a canal Panama")
        True
    """
    # Remove spaces and convert to lowercase for comparison
    cleaned = "".join(text.split()).lower()
    return cleaned == cleaned[::-1]


def remove_whitespace(text: str) -> str:
    """
    Remove all whitespace characters from a string.

    Args:
        text: Input string

    Returns:
        String with all whitespace removed

    Example:
        >>> remove_whitespace("hello world")
        'helloworld'
        >>> remove_whitespace("  Python   Programming  ")
        'PythonProgramming'
    """
    return "".join(text.split())
