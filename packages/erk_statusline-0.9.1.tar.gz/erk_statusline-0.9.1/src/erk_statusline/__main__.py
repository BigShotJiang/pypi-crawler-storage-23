"""Entry point for running erk-statusline as a module."""

from erk_statusline.statusline import main

if __name__ == "__main__":
    main()
