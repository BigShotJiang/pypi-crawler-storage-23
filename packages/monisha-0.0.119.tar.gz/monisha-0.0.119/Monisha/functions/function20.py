from .function10 import Fonts
#====================================================================

def Fonted(icomings, o):

    if icomings == "F01":
         outgoing = o
    elif icomings == "F02":
         outgoing = Fonts.FS02(o)
    elif icomings == "F03":
         outgoing = Fonts.FS03(o)
    elif icomings == "F04":
         outgoing = Fonts.FS04(o)
    elif icomings == "F05":
         outgoing = Fonts.FS05(o)
    elif icomings == "F06":
         outgoing = Fonts.FS06(o)
    elif icomings == "F07":
         outgoing = Fonts.FS07(o)
    elif icomings == "F08":
         outgoing = Fonts.FS08(o)
    elif icomings == "F09":
         outgoing = Fonts.FS09(o)
    elif icomings == "F10":
         outgoing = Fonts.FS10(o)
    elif icomings == "F11":
         outgoing = Fonts.FS11(o)
    elif icomings == "F12":
         outgoing = Fonts.FS12(o)
    elif icomings == "F13":
         outgoing = Fonts.FS13(o)
    elif icomings == "F14":
         outgoing = Fonts.FS14(o)
    elif icomings == "F15":
         outgoing = Fonts.FS15(o)
    elif icomings == "F16":
         outgoing = Fonts.FS16(o)
    elif icomings == "F17":
         outgoing = Fonts.FS17(o)
    elif icomings == "F18":
         outgoing = Fonts.FS18(o)
    elif icomings == "F19":
         outgoing = Fonts.FS19(o)
    elif icomings == "F20":
         outgoing = Fonts.FS20(o)
    elif icomings == "F21":
         outgoing = Fonts.FS21(o)
    elif icomings == "F22":
         outgoing = Fonts.FS22(o)
    elif icomings == "F23":
         outgoing = Fonts.FS23(o)
    elif icomings == "F24":
         outgoing = Fonts.FS24(o)
    elif icomings == "F25":
         outgoing = Fonts.FS25(o)
    elif icomings == "F26":
         outgoing = Fonts.FS26(o)
    elif icomings == "F27":
         outgoing = Fonts.FS27(o)
    elif icomings == "F28":
         outgoing = Fonts.FS28(o)
    elif icomings == "F29":
         outgoing = Fonts.FS29(o)
    elif icomings == "F30":
         outgoing = Fonts.FS30(o)
    elif icomings == "F31":
         outgoing = Fonts.FS31(o)
    elif icomings == "F32":
         outgoing = Fonts.FS32(o)
    elif icomings == "F33":
         outgoing = Fonts.FS33(o)
    elif icomings == "F34":
         outgoing = Fonts.FS34(o)
    elif icomings == "F35":
         outgoing = Fonts.FS35(o)
    elif icomings == "F36":
         outgoing = Fonts.FS36(o)
    elif icomings == "F37":
         outgoing = Fonts.FS37(o)
    elif icomings == "F38":
         outgoing = Fonts.FS38(o)
    elif icomings == "F39":
         outgoing = Fonts.FS39(o)
    elif icomings == "F40":
         outgoing = Fonts.FS40(o)
    else:
         outgoing = Fonts.FONTER

    return outgoing

#====================================================================

def FontNow(coming):

    if coming == "F01":
         cooxoo = Fonts.FONT01
    elif coming == "F02":
         cooxoo = Fonts.FONT02
    elif coming == "F03":
         cooxoo = Fonts.FONT03
    elif coming == "F04":
         cooxoo = Fonts.FONT04
    elif coming == "F05":
         cooxoo = Fonts.FONT05
    elif coming == "F06":
         cooxoo = Fonts.FONT06
    elif coming == "F07":
         cooxoo = Fonts.FONT07
    elif coming == "F08":
         cooxoo = Fonts.FONT08
    elif coming == "F09":
         cooxoo = Fonts.FONT09
    elif coming == "F10":
         cooxoo = Fonts.FONT10
    elif coming == "F11":
         cooxoo = Fonts.FONT11
    elif coming == "F12":
         cooxoo = Fonts.FONT12
    elif coming == "F13":
         cooxoo = Fonts.FONT13
    elif coming == "F14":
         cooxoo = Fonts.FONT14
    elif coming == "F15":
         cooxoo = Fonts.FONT15
    elif coming == "F16":
         cooxoo = Fonts.FONT16
    elif coming == "F17":
         cooxoo = Fonts.FONT17
    elif coming == "F18":
         cooxoo = Fonts.FONT18
    elif coming == "F19":
         cooxoo = Fonts.FONT19
    elif coming == "F20":
         cooxoo = Fonts.FONT20
    elif coming == "F21":
         cooxoo = Fonts.FONT21
    elif coming == "F22":
         cooxoo = Fonts.FONT22
    elif coming == "F23":
         cooxoo = Fonts.FONT23
    elif coming == "F24":
         cooxoo = Fonts.FONT24
    elif coming == "F25":
         cooxoo = Fonts.FONT25
    elif coming == "F26":
         cooxoo = Fonts.FONT26
    elif coming == "F27":
         cooxoo = Fonts.FONT27
    elif coming == "F28":
         cooxoo = Fonts.FONT28
    elif coming == "F29":
         cooxoo = Fonts.FONT29
    elif coming == "F30":
         cooxoo = Fonts.FONT30
    elif coming == "F31":
         cooxoo = Fonts.FONT31
    elif coming == "F32":
         cooxoo = Fonts.FONT32
    elif coming == "F33":
         cooxoo = Fonts.FONT33
    elif coming == "F34":
         cooxoo = Fonts.FONT34
    elif coming == "F35":
         cooxoo = Fonts.FONT35
    elif coming == "F36":
         cooxoo = Fonts.FONT36
    elif coming == "F37":
         cooxoo = Fonts.FONT37
    elif coming == "F38":
         cooxoo = Fonts.FONT38
    elif coming == "F39":
         cooxoo = Fonts.FONT39
    elif coming == "F40":
         cooxoo = Fonts.FONT40
    else:
         cooxoo = Fonts.FONTER

    return cooxoo

#====================================================================
