from ..scripts import Humon, Scripted
#=============================================================================

def Dbytes(sizes, second=Scripted.DATA01):
    if not isinstance(sizes, int):
        return Scripted.DATA09 + second
    nomos = 0
    POWEO = 1024
    POWER = Humon.DATA01
    while sizes > POWEO:
        sizes /= POWEO
        nomos += 1
    return str(round(sizes, 2)) + Scripted.DATA02 + POWER[nomos] + second

#=============================================================================

def Hbytes(sizes, second=Scripted.DATA01):
    if not isinstance(sizes, int):
        return Scripted.DATA08 + second
    nomos = 0
    POWEO = 1024
    POWER = Humon.DATA02
    while sizes > POWEO:
        sizes /= POWEO
        nomos += 1
    return str(round(sizes, 2)) + Scripted.DATA02 + POWER[nomos] + second

#=============================================================================

def Gbytes(sizes, second=Scripted.DATA01):
    if not isinstance(sizes, int):
        return Scripted.DATA01 + second
    nomos = 0
    POWEO = 1024
    POWER = Humon.DATA01
    while sizes > POWEO:
        sizes /= POWEO
        nomos += 1
    return str(round(sizes, 2)) + Scripted.DATA02 + POWER[nomos] + second

#=============================================================================
