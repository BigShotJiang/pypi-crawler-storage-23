
class Num(object):

    NUM000 = 0
    NUM001 = 1
    NUM002 = 2
    NUM003 = 3
    NUM004 = 4
    NUM005 = 5
    NUM006 = 6
    NUM007 = 7
    NUM008 = 8
    NUM009 = 9
    NUM010 = 10
    NUM011 = 11
    NUM012 = 12
    NUM013 = 13
    NUM014 = 14
    NUM015 = 15
    NUM016 = 16
    NUM017 = 17
    NUM018 = 18
    NUM019 = 19
    NUM020 = 20
    NUM100 = 100
