#DATA17

class Script01(object):

    DATA01 = ""
    DATA04 = "-"
    DATA15 = "∞"
    DATA02 = " "
    DATA03 = "ㅤ"
    DATA16 = ", "
    DATA05 = "NA"
    DATA08 = "0 𝙱"
    DATA09 = "0 B"
    DATA12 = "{}{}"
    DATA06 = ".tmp"
    DATA17 = ".jpg"
    DATA18 = "{}.jpg"
    DATA13 = "Unknown"
    DATA14 = "Unknown.tmp"

    HTAG01 = "<{}>"
    HTAG02 = "</{}>"
    HTAG03 = "<{} {}>"
    HTAG04 = "{}='{}'" 
