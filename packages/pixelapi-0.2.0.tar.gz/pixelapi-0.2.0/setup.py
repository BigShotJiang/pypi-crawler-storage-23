from setuptools import setup, find_packages

setup(
    name="pixelapi",
    version="0.1.0",
    description="Python SDK for PixelAPI — AI Image & Video Generation",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="PixelAPI",
    author_email="hello@pixelapi.dev",
    url="https://pixelapi.dev",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["requests>=2.28.0"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
