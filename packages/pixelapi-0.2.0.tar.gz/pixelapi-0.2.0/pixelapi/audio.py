"""Audio generation methods."""

import time
from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from pixelapi import PixelAPI


@dataclass
class AudioResult:
    """Result of an audio generation."""
    id: str
    status: str
    url: Optional[str] = None
    credits_used: float = 0


class AudioClient:
    """Audio generation API client (MusicGen)."""

    def __init__(self, client: "PixelAPI") -> None:
        self._client = client

    def generate(
        self,
        prompt: str,
        duration: int = 15,
        wait: bool = True,
        poll_interval: float = 2.0,
    ) -> AudioResult:
        """Generate music/audio from a text prompt.

        Args:
            prompt: Description of the music to generate.
            duration: Duration in seconds (default 15, max 30).
            wait: If True, poll until the audio is ready.
            poll_interval: Seconds between poll requests.

        Returns:
            AudioResult with url when complete.
        """
        body = {"prompt": prompt, "duration": duration}
        data = self._client._request("POST", "/v1/audio/generate", json=body)
        result = AudioResult(
            id=data["generation_id"],
            status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def get(self, generation_id: str) -> AudioResult:
        """Get the status/result of an audio generation."""
        data = self._client._request("GET", f"/v1/image/{generation_id}")
        return AudioResult(
            id=data["generation_id"],
            status=data["status"],
            url=data.get("output_url"),
            credits_used=data.get("credits_used", 0),
        )

    def _poll(self, gen_id: str, interval: float) -> AudioResult:
        """Poll until audio generation completes or fails."""
        while True:
            result = self.get(gen_id)
            if result.status in ("completed", "failed"):
                return result
            time.sleep(interval)
