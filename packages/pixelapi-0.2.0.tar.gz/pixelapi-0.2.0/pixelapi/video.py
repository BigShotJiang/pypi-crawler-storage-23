"""Video generation methods."""

import time
from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from pixelapi import PixelAPI


@dataclass
class VideoResult:
    id: str
    status: str
    url: Optional[str] = None
    model: str = ""
    credits_used: float = 0


class VideoClient:
    def __init__(self, client: "PixelAPI") -> None:
        self._client = client

    def generate(
        self,
        prompt: str,
        model: str = "cogvideo-2b",
        num_frames: int = 49,
        num_inference_steps: Optional[int] = None,
        guidance_scale: Optional[float] = None,
        seed: Optional[int] = None,
        wait: bool = True,
        poll_interval: float = 3.0,
    ) -> VideoResult:
        """Generate a video from a text prompt."""
        body = {"prompt": prompt, "model": model, "num_frames": num_frames}
        if num_inference_steps is not None:
            body["steps"] = num_inference_steps
        if guidance_scale is not None:
            body["guidance_scale"] = guidance_scale
        if seed is not None:
            body["seed"] = seed

        data = self._client._request("POST", "/v1/video/generate", json=body)
        result = VideoResult(
            id=data["generation_id"], status=data["status"],
            model=data.get("model", model),
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def get(self, generation_id: str) -> VideoResult:
        data = self._client._request("GET", f"/v1/video/{generation_id}")
        return VideoResult(
            id=data["generation_id"], status=data["status"],
            url=data.get("output_url"), model=data.get("model", ""),
            credits_used=data.get("credits_used", 0),
        )

    def _poll(self, gen_id: str, interval: float) -> VideoResult:
        while True:
            result = self.get(gen_id)
            if result.status in ("completed", "failed"):
                return result
            time.sleep(interval)
