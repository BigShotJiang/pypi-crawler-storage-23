"""PixelAPI - AI Image Generation, Background Removal & Audio API"""

from .client import PixelAPI, AsyncPixelAPI
from .exceptions import (
    PixelAPIError,
    AuthenticationError,
    RateLimitError,
    InsufficientCreditsError,
    NotFoundError,
    ValidationError,
    ServerError,
)
from .models import Generation, GenerationStatus

__version__ = "0.2.0"
__all__ = [
    "PixelAPI",
    "AsyncPixelAPI",
    "PixelAPIError",
    "AuthenticationError",
    "RateLimitError",
    "InsufficientCreditsError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "Generation",
    "GenerationStatus",
]
