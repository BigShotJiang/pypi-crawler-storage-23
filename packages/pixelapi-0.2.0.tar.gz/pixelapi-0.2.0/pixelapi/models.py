"""Response models for the PixelAPI SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class GenerationStatus(str, Enum):
    """Status of a generation job."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Generation:
    """Represents an AI generation result."""

    id: str
    status: GenerationStatus
    output_url: Optional[str] = None
    model: Optional[str] = None
    credits_used: Optional[int] = None
    error: Optional[str] = None
    created_at: Optional[str] = None
    completed_at: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Generation:
        """Create a Generation from an API response dict."""
        return cls(
            id=data.get("id") or data.get("generation_id", ""),
            status=GenerationStatus(data.get("status", "pending")),
            output_url=data.get("output_url"),
            model=data.get("model"),
            credits_used=data.get("credits_used"),
            error=data.get("error"),
            created_at=data.get("created_at"),
            completed_at=data.get("completed_at"),
            metadata={
                k: v
                for k, v in data.items()
                if k
                not in {
                    "id",
                    "generation_id",
                    "status",
                    "output_url",
                    "model",
                    "credits_used",
                    "error",
                    "created_at",
                    "completed_at",
                }
            },
        )

    @property
    def is_complete(self) -> bool:
        return self.status == GenerationStatus.COMPLETED

    @property
    def is_failed(self) -> bool:
        return self.status == GenerationStatus.FAILED

    @property
    def is_pending(self) -> bool:
        return self.status in (GenerationStatus.PENDING, GenerationStatus.PROCESSING)
