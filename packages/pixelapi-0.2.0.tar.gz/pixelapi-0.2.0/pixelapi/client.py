"""PixelAPI client — sync and async."""

from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from . import __version__
from .exceptions import (
    AuthenticationError,
    InsufficientCreditsError,
    NotFoundError,
    PixelAPIError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .models import Generation

_BASE_URL = "https://api.pixelapi.dev"
_USER_AGENT = f"pixelapi-python/{__version__}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _raise_for_status(response: httpx.Response) -> None:
    """Raise a typed exception based on HTTP status code."""
    if response.is_success:
        return

    try:
        body = response.json()
    except Exception:
        body = {"detail": response.text}

    message = body.get("detail") or body.get("error") or body.get("message") or response.text
    code = response.status_code

    if code == 401:
        raise AuthenticationError(message, code, body)
    if code == 402:
        raise InsufficientCreditsError(message, code, body)
    if code == 404:
        raise NotFoundError(message, code, body)
    if code == 422:
        raise ValidationError(message, code, body)
    if code == 429:
        retry_after = response.headers.get("retry-after")
        raise RateLimitError(
            message, code, body, retry_after=float(retry_after) if retry_after else None
        )
    if code >= 500:
        raise ServerError(message, code, body)

    raise PixelAPIError(message, code, body)


# ---------------------------------------------------------------------------
# Resource classes (sync)
# ---------------------------------------------------------------------------

class _ImageResource:
    """Handles all image endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def generate(self, *, prompt: str, model: str = "flux-schnell", **kwargs: Any) -> Generation:
        """Generate an image from text.

        Args:
            prompt: Text description of the image to generate.
            model: Model to use (flux-schnell, sdxl, etc.).
            **kwargs: Additional parameters (width, height, negative_prompt, etc.).
        """
        payload = {"prompt": prompt, "model": model, **kwargs}
        resp = self._client.post("/v1/image/generate", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def remove_background(self, *, image_url: str, **kwargs: Any) -> Generation:
        """Remove background from an image.

        Args:
            image_url: URL of the image to process.
        """
        payload = {"image_url": image_url, **kwargs}
        resp = self._client.post("/v1/image/remove-background", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def upscale(self, *, image_url: str, **kwargs: Any) -> Generation:
        """Upscale an image to 4x resolution.

        Args:
            image_url: URL of the image to upscale.
        """
        payload = {"image_url": image_url, **kwargs}
        resp = self._client.post("/v1/image/upscale", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def restore_face(self, *, image_url: str, **kwargs: Any) -> Generation:
        """Restore and enhance faces in an image.

        Args:
            image_url: URL of the image with faces to restore.
        """
        payload = {"image_url": image_url, **kwargs}
        resp = self._client.post("/v1/image/restore-face", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def remove_object(self, *, image_url: str, mask_url: str, **kwargs: Any) -> Generation:
        """Remove an object from an image using a mask.

        Args:
            image_url: URL of the source image.
            mask_url: URL of the mask (white = area to remove).
        """
        payload = {"image_url": image_url, "mask_url": mask_url, **kwargs}
        resp = self._client.post("/v1/image/remove-object", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def replace_background(self, *, image_url: str, prompt: str, **kwargs: Any) -> Generation:
        """Replace background with an AI-generated scene.

        Args:
            image_url: URL of the product image.
            prompt: Description of the desired background scene.
        """
        payload = {"image_url": image_url, "prompt": prompt, **kwargs}
        resp = self._client.post("/v1/image/replace-background", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())


class _AudioResource:
    """Handles audio generation endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def generate(self, *, prompt: str, duration: int = 15, **kwargs: Any) -> Generation:
        """Generate music/audio from a text prompt.

        Args:
            prompt: Description of the music to generate.
            duration: Duration in seconds (default 15).
        """
        payload = {"prompt": prompt, "duration": duration, **kwargs}
        resp = self._client.post("/v1/audio/generate", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())


class _GenerationResource:
    """Handles generation status polling."""

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    def get(self, generation_id: str) -> Generation:
        """Get the current status of a generation.

        Args:
            generation_id: The ID returned when creating a generation.
        """
        resp = self._client.get(f"/v1/image/{generation_id}")
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    def wait(
        self,
        generation_id: str,
        *,
        timeout: float = 120,
        poll_interval: float = 1.0,
    ) -> Generation:
        """Poll until a generation completes or fails.

        Args:
            generation_id: The ID to poll.
            timeout: Maximum seconds to wait (default 120).
            poll_interval: Seconds between polls (default 1).

        Raises:
            TimeoutError: If the generation doesn't complete within timeout.
            PixelAPIError: If the generation fails.
        """
        deadline = time.monotonic() + timeout
        while True:
            gen = self.get(generation_id)
            if gen.is_complete:
                return gen
            if gen.is_failed:
                raise PixelAPIError(
                    gen.error or "Generation failed",
                    body={"generation_id": generation_id, "status": gen.status.value},
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Generation {generation_id} did not complete within {timeout}s"
                )
            time.sleep(poll_interval)


# ---------------------------------------------------------------------------
# Main client (sync)
# ---------------------------------------------------------------------------

class PixelAPI:
    """Synchronous PixelAPI client.

    Usage::

        from pixelapi import PixelAPI

        client = PixelAPI("pk_live_xxx")
        result = client.image.generate(prompt="a cat in space", model="sdxl")
        completed = client.generation.wait(result.id)
        print(completed.output_url)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _BASE_URL,
        timeout: float = 60.0,
    ) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": _USER_AGENT,
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.image = _ImageResource(self._client)
        self.audio = _AudioResource(self._client)
        self.generation = _GenerationResource(self._client)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> PixelAPI:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async resource classes
# ---------------------------------------------------------------------------

class _AsyncImageResource:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def generate(self, *, prompt: str, model: str = "flux-schnell", **kwargs: Any) -> Generation:
        payload = {"prompt": prompt, "model": model, **kwargs}
        resp = await self._client.post("/v1/image/generate", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def remove_background(self, *, image_url: str, **kwargs: Any) -> Generation:
        payload = {"image_url": image_url, **kwargs}
        resp = await self._client.post("/v1/image/remove-background", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def upscale(self, *, image_url: str, **kwargs: Any) -> Generation:
        payload = {"image_url": image_url, **kwargs}
        resp = await self._client.post("/v1/image/upscale", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def restore_face(self, *, image_url: str, **kwargs: Any) -> Generation:
        payload = {"image_url": image_url, **kwargs}
        resp = await self._client.post("/v1/image/restore-face", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def remove_object(self, *, image_url: str, mask_url: str, **kwargs: Any) -> Generation:
        payload = {"image_url": image_url, "mask_url": mask_url, **kwargs}
        resp = await self._client.post("/v1/image/remove-object", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def replace_background(self, *, image_url: str, prompt: str, **kwargs: Any) -> Generation:
        payload = {"image_url": image_url, "prompt": prompt, **kwargs}
        resp = await self._client.post("/v1/image/replace-background", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())


class _AsyncAudioResource:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def generate(self, *, prompt: str, duration: int = 15, **kwargs: Any) -> Generation:
        payload = {"prompt": prompt, "duration": duration, **kwargs}
        resp = await self._client.post("/v1/audio/generate", json=payload)
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())


class _AsyncGenerationResource:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def get(self, generation_id: str) -> Generation:
        resp = await self._client.get(f"/v1/image/{generation_id}")
        _raise_for_status(resp)
        return Generation.from_dict(resp.json())

    async def wait(
        self,
        generation_id: str,
        *,
        timeout: float = 120,
        poll_interval: float = 1.0,
    ) -> Generation:
        import asyncio

        deadline = time.monotonic() + timeout
        while True:
            gen = await self.get(generation_id)
            if gen.is_complete:
                return gen
            if gen.is_failed:
                raise PixelAPIError(
                    gen.error or "Generation failed",
                    body={"generation_id": generation_id, "status": gen.status.value},
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Generation {generation_id} did not complete within {timeout}s"
                )
            await asyncio.sleep(poll_interval)


# ---------------------------------------------------------------------------
# Main client (async)
# ---------------------------------------------------------------------------

class AsyncPixelAPI:
    """Asynchronous PixelAPI client.

    Usage::

        from pixelapi import AsyncPixelAPI

        async with AsyncPixelAPI("pk_live_xxx") as client:
            result = await client.image.generate(prompt="a cat in space")
            completed = await client.generation.wait(result.id)
            print(completed.output_url)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _BASE_URL,
        timeout: float = 60.0,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": _USER_AGENT,
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.image = _AsyncImageResource(self._client)
        self.audio = _AsyncAudioResource(self._client)
        self.generation = _AsyncGenerationResource(self._client)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncPixelAPI:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
