"""Image generation methods."""

import time
from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from pixelapi import PixelAPI


@dataclass
class ImageResult:
    """Result of an image generation."""
    id: str
    status: str
    url: Optional[str] = None
    model: str = ""
    credits_used: float = 0


class ImageClient:
    """Image generation API client."""

    def __init__(self, client: "PixelAPI") -> None:
        self._client = client

    def generate(
        self,
        prompt: str,
        model: str = "flux-schnell",
        width: int = 1024,
        height: int = 1024,
        num_inference_steps: Optional[int] = None,
        guidance_scale: Optional[float] = None,
        negative_prompt: Optional[str] = None,
        seed: Optional[int] = None,
        wait: bool = True,
        poll_interval: float = 1.0,
    ) -> ImageResult:
        """Generate an image from a text prompt.

        Args:
            prompt: Text description of the image to generate.
            model: Model to use ('flux-schnell' or 'sdxl').
            width: Image width (256-2048).
            height: Image height (256-2048).
            wait: If True, poll until the image is ready.
            poll_interval: Seconds between poll requests.

        Returns:
            ImageResult with url when complete.
        """
        body = {"prompt": prompt, "model": model, "width": width, "height": height}
        if num_inference_steps is not None:
            body["steps"] = num_inference_steps
        if guidance_scale is not None:
            body["guidance_scale"] = guidance_scale
        if negative_prompt:
            body["negative_prompt"] = negative_prompt
        if seed is not None:
            body["seed"] = seed

        data = self._client._request("POST", "/v1/image/generate", json=body)
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            model=data.get("model", model),
            credits_used=data.get("credits_used", 0),
        )

        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def get(self, generation_id: str) -> ImageResult:
        """Get the status/result of a generation."""
        data = self._client._request("GET", f"/v1/image/{generation_id}")
        return ImageResult(
            id=data["generation_id"], status=data["status"],
            url=data.get("output_url"), model=data.get("model", ""),
            credits_used=data.get("credits_used", 0),
        )

    def upscale(
        self, image_url: str, scale: int = 4,
        wait: bool = True, poll_interval: float = 1.0,
    ) -> ImageResult:
        """Upscale an image using Real-ESRGAN."""
        data = self._client._request(
            "POST", "/v1/image/upscale",
            json={"image_url": image_url, "scale": scale},
        )
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll_upscale(result.id, poll_interval)
        return result

    def get_upscale(self, generation_id: str) -> ImageResult:
        """Get the status/result of an upscale generation."""
        data = self._client._request("GET", f"/v1/image/upscale/{generation_id}")
        return ImageResult(
            id=data["generation_id"], status=data["status"],
            url=data.get("output_url"),
            credits_used=data.get("credits_used", 0),
        )

    def _poll_upscale(self, gen_id: str, interval: float) -> ImageResult:
        """Poll until upscale completes or fails."""
        while True:
            result = self.get_upscale(gen_id)
            if result.status in ("completed", "failed"):
                return result
            time.sleep(interval)

    def remove_background(
        self, image_url: str,
        wait: bool = True, poll_interval: float = 1.0,
    ) -> ImageResult:
        """Remove background from an image (BiRefNet). Returns transparent PNG.

        Args:
            image_url: URL of the image to process.
        """
        data = self._client._request(
            "POST", "/v1/image/remove-background",
            json={"image_url": image_url},
        )
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def restore_face(
        self, image_url: str,
        wait: bool = True, poll_interval: float = 1.0,
    ) -> ImageResult:
        """Restore and enhance faces in an image (CodeFormer/GFPGAN).

        Args:
            image_url: URL of the image with faces to restore.
        """
        data = self._client._request(
            "POST", "/v1/image/restore-face",
            json={"image_url": image_url},
        )
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def remove_object(
        self, image_url: str, mask_url: str,
        wait: bool = True, poll_interval: float = 1.0,
    ) -> ImageResult:
        """Remove an object from an image using a mask (LaMa inpainting).

        Args:
            image_url: URL of the source image.
            mask_url: URL of the mask image (white = area to remove).
        """
        data = self._client._request(
            "POST", "/v1/image/remove-object",
            json={"image_url": image_url, "mask_url": mask_url},
        )
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def replace_background(
        self, image_url: str, prompt: str,
        wait: bool = True, poll_interval: float = 1.0,
    ) -> ImageResult:
        """Replace background with an AI-generated scene.

        Args:
            image_url: URL of the product image.
            prompt: Description of the desired background scene.
        """
        data = self._client._request(
            "POST", "/v1/image/replace-background",
            json={"image_url": image_url, "prompt": prompt},
        )
        result = ImageResult(
            id=data["generation_id"], status=data["status"],
            credits_used=data.get("credits_used", 0),
        )
        if wait:
            result = self._poll(result.id, poll_interval)
        return result

    def _poll(self, gen_id: str, interval: float) -> ImageResult:
        """Poll until generation completes or fails."""
        while True:
            result = self.get(gen_id)
            if result.status in ("completed", "failed"):
                return result
            time.sleep(interval)
