"""Custom exceptions for the PixelAPI SDK."""

from __future__ import annotations

from typing import Any, Optional


class PixelAPIError(Exception):
    """Base exception for all PixelAPI errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        body: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.body = body or {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(PixelAPIError):
    """Raised when the API key is invalid or missing."""


class RateLimitError(PixelAPIError):
    """Raised when the rate limit is exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        status_code: int = 429,
        body: Optional[dict[str, Any]] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(message, status_code, body)
        self.retry_after = retry_after


class InsufficientCreditsError(PixelAPIError):
    """Raised when the account doesn't have enough credits."""


class NotFoundError(PixelAPIError):
    """Raised when a resource is not found."""


class ValidationError(PixelAPIError):
    """Raised when request validation fails."""


class ServerError(PixelAPIError):
    """Raised when the server returns a 5xx error."""


class TimeoutError(PixelAPIError):
    """Raised when polling for a generation result times out."""
