"""Account balance and usage."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pixelapi import PixelAPI


class AccountClient:
    def __init__(self, client: "PixelAPI") -> None:
        self._client = client

    def balance(self) -> dict:
        """Get current credit balance and plan info."""
        return self._client._request("GET", "/v1/account/balance")

    def usage(self, days: int = 30, limit: int = 50) -> dict:
        """Get usage history."""
        return self._client._request(
            "GET", f"/v1/account/usage?days={days}&limit={limit}"
        )
