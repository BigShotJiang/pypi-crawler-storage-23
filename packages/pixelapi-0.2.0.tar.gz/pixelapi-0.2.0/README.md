# PixelAPI Python SDK

Official Python client for [PixelAPI](https://pixelapi.dev) — the cheapest AI image generation, background removal, upscaling, and audio API.

**10 AI models, one API key, from $0.002/image.**

[![PyPI](https://img.shields.io/pypi/v/pixelapi)](https://pypi.org/project/pixelapi/)
[![Python 3.8+](https://img.shields.io/pypi/pyversions/pixelapi)](https://pypi.org/project/pixelapi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
pip install pixelapi
```

## Quick Start

```python
from pixelapi import PixelAPI

api = PixelAPI("your_api_key")

# Generate an image ($0.003)
result = api.image.generate("a cat astronaut, digital art", model="flux-schnell")
print(result.url)
```

## Image Generation

```python
# FLUX Schnell — fast, photorealistic (~3s, 3 credits)
result = api.image.generate("product on marble table", model="flux-schnell")

# SDXL — versatile, great for illustrations (~13s, 3 credits)
result = api.image.generate("watercolor mountains", model="sdxl")

print(result.url)
```

## Background Removal — $0.002/image

```python
result = api.image.remove_background("https://example.com/product.jpg")
print(result.url)  # Transparent PNG
```

## Background Replacement — $0.005/image

```python
result = api.image.replace_background(
    "https://example.com/product.jpg",
    prompt="product on marble countertop, soft studio lighting"
)
```

## 4x Upscaling — $0.02/image

```python
result = api.image.upscale("https://example.com/low-res.jpg")
print(result.url)
```

## Face Restoration — $0.003/image

```python
result = api.image.restore_face("https://example.com/blurry-portrait.jpg")
```

## Object Removal — $0.005/image

```python
result = api.image.remove_object(
    "https://example.com/photo.jpg",
    mask_url="https://example.com/mask.png"
)
```

## 🎵 AI Music Generation — $0.005/track (NEW in v0.2.0)

```python
result = api.audio.generate("upbeat electronic music for a product video", duration=15)
print(result.url)  # Audio URL
```

## Non-blocking Usage

```python
# Don't wait for completion
result = api.image.generate("hello world", wait=False)
print(result.id, result.status)  # generation_id, "pending"

# Check later
status = api.image.get(result.id)
if status.status == "completed":
    print(status.url)
```

## Error Handling

```python
from pixelapi import PixelAPI, AuthError, InsufficientCredits, RateLimitError

api = PixelAPI("your_api_key")

try:
    result = api.image.generate("hello world")
except AuthError:
    print("Invalid API key")
except RateLimitError:
    print("Too many requests — slow down")
except InsufficientCredits:
    print("Top up at pixelapi.dev/app")
```

## API Reference

| Method | Endpoint | Credits |
|--------|----------|---------|
| `api.image.generate()` | POST /v1/image/generate | 3 |
| `api.image.remove_background()` | POST /v1/image/remove-background | 2 |
| `api.image.upscale()` | POST /v1/image/upscale | 20 |
| `api.image.restore_face()` | POST /v1/image/restore-face | 3 |
| `api.image.remove_object()` | POST /v1/image/remove-object | 5 |
| `api.image.replace_background()` | POST /v1/image/replace-background | 5 |
| `api.audio.generate()` | POST /v1/audio/generate | 5 |
| `api.image.get()` | GET /v1/image/{id} | 0 |
| `api.account.balance()` | GET /v1/account/balance | 0 |
| `api.models.list()` | GET /v1/models | 0 |

## What's New in v0.2.0

- 🎵 **Audio generation** via `api.audio.generate()`
- ✂️ **Background removal** via `api.image.remove_background()`
- 🎨 **Background replacement** via `api.image.replace_background()`
- 👤 **Face restoration** via `api.image.restore_face()`
- 🧹 **Object removal** via `api.image.remove_object()`
- Resource-based API (`api.image.*`, `api.audio.*`, `api.account.*`)
- Full backward compatibility with v0.1.0 flat API

## Links

- **Docs:** [pixelapi.dev/docs](https://pixelapi.dev/docs)
- **Dashboard:** [pixelapi.dev/app](https://pixelapi.dev/app)
- **Swagger:** [api.pixelapi.dev/docs](https://api.pixelapi.dev/docs)
- **Support:** support@pixelapi.dev

## License

MIT
