# ResourceListAgentResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[AgentResponse]**](AgentResponse.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_agent_response import ResourceListAgentResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListAgentResponse from a JSON string
resource_list_agent_response_instance = ResourceListAgentResponse.from_json(json)
# print the JSON string representation of the object
print(ResourceListAgentResponse.to_json())

# convert the object into a dict
resource_list_agent_response_dict = resource_list_agent_response_instance.to_dict()
# create an instance of ResourceListAgentResponse from a dict
resource_list_agent_response_from_dict = ResourceListAgentResponse.from_dict(resource_list_agent_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


