# ResourceListDataSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[DataSource]**](DataSource.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_data_source import ResourceListDataSource

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListDataSource from a JSON string
resource_list_data_source_instance = ResourceListDataSource.from_json(json)
# print the JSON string representation of the object
print(ResourceListDataSource.to_json())

# convert the object into a dict
resource_list_data_source_dict = resource_list_data_source_instance.to_dict()
# create an instance of ResourceListDataSource from a dict
resource_list_data_source_from_dict = ResourceListDataSource.from_dict(resource_list_data_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


