from unittest import TestCase


class TestStartup(TestCase):
    def test_startup(self):
        assert True
