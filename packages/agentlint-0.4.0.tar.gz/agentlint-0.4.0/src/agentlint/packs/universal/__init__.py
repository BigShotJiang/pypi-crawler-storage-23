"""Universal rule pack — PreToolUse, PostToolUse, and Stop rules."""
from agentlint.packs.universal.dependency_hygiene import DependencyHygiene
from agentlint.packs.universal.drift_detector import DriftDetector
from agentlint.packs.universal.max_file_size import MaxFileSize
from agentlint.packs.universal.no_debug_artifacts import NoDebugArtifacts
from agentlint.packs.universal.no_destructive_commands import NoDestructiveCommands
from agentlint.packs.universal.no_env_commit import NoEnvCommit
from agentlint.packs.universal.no_force_push import NoForcePush
from agentlint.packs.universal.no_push_to_main import NoPushToMain
from agentlint.packs.universal.no_secrets import NoSecrets
from agentlint.packs.universal.no_skip_hooks import NoSkipHooks
from agentlint.packs.universal.no_test_weakening import NoTestWeakening
from agentlint.packs.universal.no_todo_left import NoTodoLeft
from agentlint.packs.universal.test_with_changes import TestWithChanges
from agentlint.packs.universal.token_budget import TokenBudget

RULES = [
    # PreToolUse
    NoSecrets(),
    NoEnvCommit(),
    NoForcePush(),
    NoPushToMain(),
    NoSkipHooks(),
    NoDestructiveCommands(),
    DependencyHygiene(),
    NoTestWeakening(),
    # PostToolUse
    MaxFileSize(),
    DriftDetector(),
    TokenBudget(),
    # Stop (TokenBudget also fires on Stop)
    NoDebugArtifacts(),
    NoTodoLeft(),
    TestWithChanges(),
]
