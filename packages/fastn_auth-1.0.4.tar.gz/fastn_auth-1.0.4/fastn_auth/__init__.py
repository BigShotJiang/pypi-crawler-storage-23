"""Fastn Auth SDK - Python SDK for Fastn connector authentication."""

from .client import FastnAuth
from .errors import (
    AuthenticationError,
    FastnAuthError,
    InvalidResponseError,
    NetworkError,
    TimeoutError,
)
from .session import AuthSession
from .types import (
    AuthResult,
    AuthStatus,
    Credentials,
    FastnAuthConfig,
    GetCredentialsOptions,
    InitOptions,
    InitResponse,
    PollOptions,
    StatusResponse,
)

__version__ = "1.0.4"

__all__ = [
    # Main client
    "FastnAuth",
    # Session
    "AuthSession",
    # Types
    "FastnAuthConfig",
    "InitOptions",
    "GetCredentialsOptions",
    "AuthStatus",
    "InitResponse",
    "StatusResponse",
    "Credentials",
    "AuthResult",
    "PollOptions",
    # Errors
    "FastnAuthError",
    "TimeoutError",
    "AuthenticationError",
    "NetworkError",
    "InvalidResponseError",
]
