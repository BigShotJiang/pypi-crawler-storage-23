"""Custom exception classes for the Fastn Auth SDK."""

from typing import Optional


class FastnAuthError(Exception):
    """Base error class for Fastn Auth SDK errors.

    Attributes:
        message: Error message.
        code: Error code.
        status_code: HTTP status code if applicable.
    """

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code


class TimeoutError(FastnAuthError):
    """Error thrown when the authentication flow times out."""

    def __init__(self, message: str = "Authentication timed out") -> None:
        super().__init__(message, code="TIMEOUT")


class AuthenticationError(FastnAuthError):
    """Error thrown when the authentication flow fails."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message, code="AUTH_FAILED")


class NetworkError(FastnAuthError):
    """Error thrown when a network request fails."""

    def __init__(
        self,
        message: str = "Network request failed",
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message, code="NETWORK_ERROR", status_code=status_code)


class InvalidResponseError(FastnAuthError):
    """Error thrown when the API returns an invalid response."""

    def __init__(self, message: str = "Invalid API response") -> None:
        super().__init__(message, code="INVALID_RESPONSE")
