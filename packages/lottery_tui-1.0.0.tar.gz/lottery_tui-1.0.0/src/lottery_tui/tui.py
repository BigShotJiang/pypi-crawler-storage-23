from typing import NoReturn

from rich.text import Text
from textual.app import App, ComposeResult
from textual.containers import Container
from textual.events import Key
from textual.types import SelectType
from textual.widgets import Button, Label, Select, Static

from .lottery import request_lottery_obj


class LotteryTUI(App):
    """A Textual TUI for the Lottery application."""

    CSS_PATH = 'tui.tcss'

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Container(
            Static('Welcome to the Lottery TUI!', id='welcome'),
            Static('Pick a lottery to play:', id='instructions'),
            Select(
                options=[
                    ('Lotto', 'lotto'),
                    ('EuroMillions', 'euromillions'),
                    ('Set For Life', 'setforlife'),
                    ('Thunderball', 'thunderball'),
                ],
                id='lottery-select',
            ),
            Button('Draw', id='draw-button'),
            Label('', id='result-label'),
            id='main-container',
        )

    def on_key(self, event: Key) -> NoReturn:
        """Handle key events."""
        if event.key == 'q':
            self.exit()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == 'draw-button':
            self._draw_button_handler()

    def _draw_button_handler(self) -> None:
        """Handle the draw button press."""
        if self._read_lottery_selection() is None:
            self._update_result_label(
                Text('Please select a lottery before drawing.', style='bold #ff8c42')
            )
            return

        lottery_obj = request_lottery_obj(self._read_lottery_selection())
        result = lottery_obj.draw()
        self._update_result_label(str(result))

    def _read_lottery_selection(self) -> SelectType | None:
        """Read the selected lottery from the dropdown."""
        select_widget = self.query_one('#lottery-select')
        if select_widget.is_blank():
            return None
        return select_widget.value

    def _update_result_label(self, message: str) -> None:
        """Update the result label with a new message."""
        self.query_one('#result-label').update(message)


def main():
    """Entry point for the Lottery TUI."""
    app = LotteryTUI()
    app.run()
