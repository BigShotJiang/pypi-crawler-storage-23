"""Validation utilities for LLM tracing spans data."""
