"""Metadata validation for LLM tracing spans."""
