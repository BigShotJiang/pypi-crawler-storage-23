"""Span data validation for LLM tracing."""
