"""Evaluation data validation for LLM tracing spans."""
