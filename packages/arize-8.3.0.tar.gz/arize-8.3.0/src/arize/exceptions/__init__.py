"""Custom exceptions and error types for the Arize SDK."""
