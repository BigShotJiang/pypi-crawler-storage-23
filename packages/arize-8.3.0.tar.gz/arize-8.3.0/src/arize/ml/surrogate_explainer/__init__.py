"""Surrogate explainer implementations for model interpretability."""
