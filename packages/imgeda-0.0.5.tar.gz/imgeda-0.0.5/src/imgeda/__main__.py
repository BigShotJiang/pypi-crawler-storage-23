from imgeda.cli.app import app

app()
