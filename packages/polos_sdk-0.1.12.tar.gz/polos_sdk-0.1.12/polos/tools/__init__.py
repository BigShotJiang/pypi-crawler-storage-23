"""Tools for AI agents."""
