"""Unit tests for middleware module."""
