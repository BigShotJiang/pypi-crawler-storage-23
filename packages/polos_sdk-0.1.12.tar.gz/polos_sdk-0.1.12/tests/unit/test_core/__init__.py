"""Unit tests for core module."""
