"""Integration tests for Polos Worker."""
