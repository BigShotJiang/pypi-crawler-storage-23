"""
Valiqor Client - Unified Facade for All Valiqor Modules

Provides lazy-loaded access to:
    - client.eval: Quality evaluation
    - client.security: Security testing
    - client.trace: LLM tracing
    - client.scanner: Code scanning

Example:
    client = ValiqorClient(api_key="vq_xxx", project_name="my-app")

    # Evaluation
    result = client.eval.evaluate(dataset=[...])

    # Security
    audit = client.security.audit(prompts=[...])

    # Tracing
    with client.trace.start_span("query") as span:
        # ... LLM call
        span.set_output(response)

    # Scanning
    client.scanner.scan("./src")
"""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from valiqor.common import get_config

if TYPE_CHECKING:
    from valiqor.eval import ValiqorEvalClient
    from valiqor.failure_analysis import ValiqorFAClient
    from valiqor.scanner import ValiqorScanner
    from valiqor.security import ValiqorSecurityClient
    from valiqor.trace import TracerV2
    from valiqor.trace.query import TraceQueryClient


class ValiqorClient:
    """
    Unified client facade for all Valiqor modules.

    Provides lazy-loaded access to eval, security, trace, and scanner
    modules through a single authenticated client.

    Args:
        api_key: API key for authentication (or VALIQOR_API_KEY env var)
        project_name: Project name for grouping (or VALIQOR_PROJECT_NAME env var)
        environment: Environment name (default: from config or "development")
        config_file: Optional path to .valiqorrc file
        base_url: Override backend URL (for self-hosted/local)
        timeout: Request timeout in seconds (default: 300)

    Example:
        # Basic usage
        client = ValiqorClient(api_key="vq_xxx")

        # With project
        client = ValiqorClient(
            api_key="vq_xxx",
            project_name="my-app",
            environment="production"
        )

        # Access modules
        client.eval.evaluate(...)
        client.security.audit(...)
        client.trace.start_span(...)
        client.scanner.scan(...)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        project_name: Optional[str] = None,
        environment: Optional[str] = None,
        config_file: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 300,
    ):
        # Build config from all sources
        overrides = {}
        if api_key:
            overrides["api_key"] = api_key
        if project_name:
            overrides["project_name"] = project_name
        if environment:
            overrides["environment"] = environment
        if base_url:
            overrides["backend_url"] = base_url
        if timeout:
            overrides["timeout"] = timeout

        self._config = get_config(config_file=config_file, **overrides)

        # Store commonly used values
        self._api_key = self._config.get("api_key", "")
        self._project_name = self._config.get("project_name", "")
        self._environment = self._config.get("environment", "development")
        self._base_url = self._config.get("backend_url")  # Already has default from get_config()
        self._timeout = self._config.get("timeout", 300)

        # Validate API key is not empty
        if not self._api_key or not self._api_key.strip():
            from valiqor.common.exceptions import ValidationError
            raise ValidationError(
                "API key is required. Provide via api_key parameter, "
                "VALIQOR_API_KEY env var, or .valiqorrc config file. "
                "Get a free key at https://app.valiqor.com/api-keys"
            )

        # Lazy-loaded module instances
        self._eval: Optional["ValiqorEvalClient"] = None
        self._security: Optional["ValiqorSecurityClient"] = None
        self._trace: Optional["TracerV2"] = None
        self._scanner: Optional["ValiqorScanner"] = None
        self._failure_analysis: Optional["ValiqorFAClient"] = None
        self._traces: Optional["TraceQueryClient"] = None

        # HTTP client for direct methods (projects, usage, auth)
        from valiqor.common import HTTPClient
        self._http = HTTPClient(
            base_url=self._base_url,
            api_key=self._api_key,
            timeout=self._timeout,
            user_agent="valiqor-sdk/1.0.0",
        )

        # Cache for project name → ID resolution
        self._project_cache: Dict[str, str] = {}

    @property
    def config(self) -> Dict[str, Any]:
        """Get the current configuration."""
        return self._config

    @property
    def api_key(self) -> str:
        """Get the API key."""
        return self._api_key

    @property
    def project_name(self) -> str:
        """Get the project name."""
        return self._project_name

    @property
    def environment(self) -> str:
        """Get the environment name."""
        return self._environment

    @property
    def eval(self) -> "ValiqorEvalClient":
        """
        Access evaluation module.

        Returns:
            ValiqorEvalClient instance

        Raises:
            ImportError: If eval module dependencies not installed
        """
        if self._eval is None:
            try:
                from valiqor.eval import ValiqorEvalClient
            except ImportError as e:
                raise ImportError(
                    "Eval module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._eval = ValiqorEvalClient(
                api_key=self._api_key,
                project_name=self._project_name,
                base_url=self._base_url,
                timeout=self._timeout,
                _config=self._config,
            )
        return self._eval

    @property
    def security(self) -> "ValiqorSecurityClient":
        """
        Access security testing module.

        Returns:
            ValiqorSecurityClient instance

        Raises:
            ImportError: If security module dependencies not installed
        """
        if self._security is None:
            try:
                from valiqor.security import ValiqorSecurityClient
            except ImportError as e:
                raise ImportError(
                    "Security module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._security = ValiqorSecurityClient(
                api_key=self._api_key,
                project_name=self._project_name,
                base_url=self._base_url,
                timeout=self._timeout,
                _config=self._config,
            )
        return self._security

    @property
    def trace(self) -> "TracerV2":
        """
        Access tracing module.

        Returns:
            TracerV2 instance

        Raises:
            ImportError: If trace module dependencies not installed
        """
        if self._trace is None:
            try:
                from valiqor.trace import TracerV2
            except ImportError as e:
                raise ImportError(
                    "Trace module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._trace = TracerV2(
                project_name=self._project_name,
                environment=self._environment,
                _config=self._config,
            )
        return self._trace

    @property
    def scanner(self) -> "ValiqorScanner":
        """
        Access code scanner module.

        Returns:
            ValiqorScanner instance

        Raises:
            ImportError: If scanner module dependencies not installed
        """
        if self._scanner is None:
            try:
                from valiqor.scanner import ValiqorScanner
            except ImportError as e:
                raise ImportError(
                    "Scanner module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._scanner = ValiqorScanner(
                project_name=self._project_name,
                _config=self._config,
            )
        return self._scanner

    @property
    def failure_analysis(self) -> "ValiqorFAClient":
        """
        Access failure analysis (failure forensics) module.

        Returns:
            ValiqorFAClient instance
        """
        if self._failure_analysis is None:
            try:
                from valiqor.failure_analysis import ValiqorFAClient
            except ImportError as e:
                raise ImportError(
                    "Failure analysis module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._failure_analysis = ValiqorFAClient(
                api_key=self._api_key,
                project_name=self._project_name,
                base_url=self._base_url,
                timeout=self._timeout,
                _config=self._config,
            )
        return self._failure_analysis

    @property
    def traces(self) -> "TraceQueryClient":
        """
        Access trace query module (read traces from backend).

        This is separate from ``client.trace`` which is for local
        tracing instrumentation and recording.

        Returns:
            TraceQueryClient instance
        """
        if self._traces is None:
            try:
                from valiqor.trace.query import TraceQueryClient
            except ImportError as e:
                raise ImportError(
                    "Trace query module not available. "
                    "Install with: pip install valiqor\n"
                    f"Original error: {e}"
                )

            self._traces = TraceQueryClient(
                api_key=self._api_key,
                base_url=self._base_url,
                timeout=self._timeout,
                _config=self._config,
            )
        return self._traces

    # =========================================================================
    # Project CRUD (user-facing /v2/projects routes)
    # =========================================================================

    def list_projects(self) -> List[Dict[str, Any]]:
        """
        List all projects in your organization.

        Returns:
            List of project dicts with id, name, key, model_name, created_at
        """
        data = self._http.get("/v2/projects")
        if isinstance(data, list):
            return data
        return data.get("projects", data.get("items", []))

    def create_project(
        self,
        name: str,
        key: Optional[str] = None,
        model_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new project.

        Args:
            name: Project name
            key: Optional project key/slug
            model_name: Optional model name

        Returns:
            Dict with project details (id, name, key, model_name, created_at)
        """
        payload: Dict[str, Any] = {"name": name}
        if key:
            payload["key"] = key
        if model_name:
            payload["model_name"] = model_name
        return self._http.post("/v2/projects", json=payload)

    def get_project(self, project_id: str = None) -> Dict[str, Any]:
        """
        Get project details by ID.

        If project_id is not provided, resolves the current project
        from self.project_name.

        Args:
            project_id: Project UUID (optional; auto-resolved from project_name)

        Returns:
            Dict with project details
        """
        if not project_id:
            if not self._project_name:
                from valiqor.common.exceptions import ValidationError
                raise ValidationError(
                    "project_id or project_name is required. "
                    "Set project_name in ValiqorClient or .valiqorrc."
                )
            project_id = self._resolve_project_id(self._project_name)
        return self._http.get(f"/v2/projects/{project_id}")

    def _resolve_project_id(self, project_name: str) -> str:
        """Resolve project name to ID (cached)."""
        if project_name in self._project_cache:
            return self._project_cache[project_name]

        projects = self.list_projects()
        self._project_cache = {p["name"]: p["id"] for p in projects}

        if project_name not in self._project_cache:
            from valiqor.common.exceptions import ValidationError
            raise ValidationError(
                f"Project '{project_name}' not found. "
                f"Available: {list(self._project_cache.keys())}"
            )
        return self._project_cache[project_name]

    # =========================================================================
    # Usage & Auth
    # =========================================================================

    def get_usage(self) -> Dict[str, Any]:
        """
        Get current usage and quota information.

        Returns detailed per-service breakdown including token usage.

        Returns:
            Dict with keys: total_api_usage, api_quota_limit,
            api_quota_remaining, plan, reset_date, services (per-service breakdown),
            token_usage, token_quota_limit, etc.
        """
        return self._http.get("/v2/auth/usage")

    def validate_auth(self) -> Dict[str, Any]:
        """
        Validate API key with backend.

        Returns:
            Dict with organization and user info

        Raises:
            AuthenticationError: If API key is invalid
            ValidationError: If API key is empty
        """
        if not self._api_key or not self._api_key.strip():
            from valiqor.common.exceptions import AuthenticationError
            raise AuthenticationError(
                "API key is empty. Cannot validate authentication."
            )
        return self._http.post("/v2/auth/validate")

    def __repr__(self) -> str:
        masked_key = (
            f"{self._api_key[:6]}...{self._api_key[-4:]}" if len(self._api_key) > 10 else "***"
        )
        return (
            f"ValiqorClient("
            f"project={self._project_name!r}, "
            f"env={self._environment!r}, "
            f"api_key={masked_key})"
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Clean up HTTP sessions
        self._http.close()
        if self._eval is not None:
            self._eval.close()
        if self._security is not None:
            self._security.close()
        if self._failure_analysis is not None:
            self._failure_analysis.close()
        if self._traces is not None:
            self._traces.close()
