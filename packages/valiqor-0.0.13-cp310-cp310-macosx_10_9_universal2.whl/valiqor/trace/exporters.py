# exporters.py - Trace exporters for valiqor SDK
import json
import os
import time
from typing import Any, Dict, Optional

import requests


def _get_debug_mode() -> bool:
    """Check if debug mode is enabled via global config or environment."""
    try:
        from valiqor.trace.autolog import _global_config

        return _global_config.get("debug", False)
    except ImportError:
        pass
    return os.environ.get("VALIQOR_DEBUG", "").lower() in ("1", "true", "yes")


def _debug_print(message: str) -> None:
    """Print message only if debug mode is enabled."""
    if _get_debug_mode():
        print(message)


class TraceEvent:
    """Trace event wrapper"""

    def __init__(self, level: str = "primary", **fields: Any):
        self.ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        self.level = level
        self.fields = fields
        self.type = fields.get("type", "unknown")
        self.payload = fields.get("payload", {})
        self.tags = fields.get("tags", {})
        self.diag = fields.get("diag", {})

    def to_dict(self) -> Dict[str, Any]:
        d = {"ts": self.ts, "level": self.level}
        # Add all fields
        for key, value in self.fields.items():
            d[key] = value
        d["_record_type"] = "session" if self.level == "session" else "event"
        return d


class ConsoleExporter:
    """Export traces to console for debugging"""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def export(self, event: TraceEvent):
        """Export event to console"""
        if self.verbose:
            print(f"\n{'='*60}")
            print(f"TRACE EVENT: {event.level}")
            print(f"{'='*60}")
            print(json.dumps(event.to_dict(), indent=2, default=str))
        else:
            ev_type = event.fields.get("type", event.level)
            _debug_print(f"[TRACE] {ev_type}")


class FileExporter:
    """Export traces to JSON files"""

    def __init__(self, trace_dir: str = "valiqor_output/traces"):
        self.trace_dir = trace_dir
        os.makedirs(trace_dir, exist_ok=True)

    def export(self, event: TraceEvent):
        """Export event to file"""
        if event.level == "session":
            # This is a complete trace
            trace_id = event.fields.get("metadata", {}).get("trace_id", f"trace_{int(time.time())}")
            filename = f"session_trace_{trace_id}.json"
        else:
            # Individual event
            filename = f"event_{int(time.time() * 1000)}.json"

        filepath = os.path.join(self.trace_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(event.to_dict(), f, ensure_ascii=False, indent=2, default=str)


class APIExporter:
    """Export traces to Valiqor backend API"""

    def __init__(
        self,
        api_url: str,
        api_key: Optional[str] = None,
        organization_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key or os.environ.get("VALIQOR_API_KEY")
        self.organization_id = organization_id or os.environ.get("VALIQOR_ORG_ID")
        self.project_id = project_id or os.environ.get("VALIQOR_PROJECT_ID")

    def export(self, event: TraceEvent):
        """Export event to API"""
        if event.level != "session":
            # Only export complete session traces
            return

        headers = {
            "Content-Type": "application/json",
        }

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "trace": event.to_dict(),
            "organization_id": self.organization_id,
            "project_id": self.project_id,
        }

        try:
            response = requests.post(
                f"{self.api_url}/api/v1/traces", headers=headers, json=payload, timeout=30
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            # Log but don't fail
            _debug_print(f"[WARN] Failed to export trace to API: {e}")
