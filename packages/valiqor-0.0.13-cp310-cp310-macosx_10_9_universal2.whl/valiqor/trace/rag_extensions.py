# rag_extensions.py - RAG-specific extensions for valiqor tracing
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Union


@dataclass
class DocumentHit:
    """Represents a single retrieved document with metadata"""

    doc_id: str
    rank: int
    score: float
    span: Optional[List[int]] = None  # [start, end] character positions
    snippet_preview: Optional[str] = None  # First 200 chars of content
    metadata: Optional[Dict[str, Any]] = None  # Additional document metadata

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "rank": self.rank,
            "score": self.score,
            "span": self.span,
            "snippet_preview": self.snippet_preview,
            "metadata": self.metadata or {},
        }


@dataclass
class RetrievalInfo:
    """Complete retrieval operation information"""

    retriever: str  # "vectordb", "bm25", "api", "hybrid", etc.
    embedding_model: Optional[str] = None
    chunk_size: Optional[int] = None
    chunk_overlap: Optional[int] = None
    top_k: Optional[int] = None
    similarity_threshold: Optional[float] = None
    filters: Optional[Dict[str, Any]] = None
    query: Optional[str] = None
    hits: Optional[List[DocumentHit]] = None
    latency_ms: Optional[float] = None
    total_documents: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "retriever": self.retriever,
            "embedding_model": self.embedding_model,
            "chunk_size": self.chunk_size,
            "chunk_overlap": self.chunk_overlap,
            "top_k": self.top_k,
            "similarity_threshold": self.similarity_threshold,
            "filters": self.filters or {},
            "query": self.query,
            "hits": [hit.to_dict() for hit in (self.hits or [])],
            "latency_ms": self.latency_ms,
            "total_documents": self.total_documents,
        }


@dataclass
class Citation:
    """Document citation with specific reference span"""

    doc_id: str
    span: Optional[List[int]] = None  # [start, end] in source document
    confidence: Optional[float] = None
    relevance_score: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "span": self.span,
            "confidence": self.confidence,
            "relevance_score": self.relevance_score,
        }


@dataclass
class FormatCheck:
    """Format validation for generated content"""

    is_complete: bool = True
    length_tokens: Optional[int] = None
    length_chars: Optional[int] = None
    refusal: bool = False
    contains_citations: bool = False
    citation_count: Optional[int] = None
    language: Optional[str] = None
    format_type: Optional[str] = None  # "markdown", "json", "plain_text", etc.

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_complete": self.is_complete,
            "length_tokens": self.length_tokens,
            "length_chars": self.length_chars,
            "refusal": self.refusal,
            "contains_citations": self.contains_citations,
            "citation_count": self.citation_count,
            "language": self.language,
            "format_type": self.format_type,
        }


@dataclass
class GenerationInfo:
    """Complete generation operation information"""

    answer: str
    citations: Optional[List[Citation]] = None
    format_check: Optional[FormatCheck] = None
    model_used: Optional[str] = None
    prompt_template: Optional[str] = None
    context_length: Optional[int] = None
    generation_latency_ms: Optional[float] = None
    reasoning_trace: Optional[List[str]] = None  # For chain-of-thought tracking

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "citations": [citation.to_dict() for citation in (self.citations or [])],
            "format_check": self.format_check.to_dict() if self.format_check else None,
            "model_used": self.model_used,
            "prompt_template": self.prompt_template,
            "context_length": self.context_length,
            "generation_latency_ms": self.generation_latency_ms,
            "reasoning_trace": self.reasoning_trace or [],
        }


class RAGSpan:
    """Enhanced span for RAG operations with retrieval and generation context"""

    def __init__(
        self,
        span_id: str,
        name: str,
        parent_span_id: Optional[str] = None,
        trace_id: Optional[str] = None,
    ):
        self.span_id = span_id
        self.trace_id = trace_id or f"trace_{str(uuid.uuid4())[:8]}"
        self.parent_span_id = parent_span_id
        self.name = name
        self.start_time = datetime.utcnow().isoformat() + "Z"
        self.end_time = None
        self.duration_ms = None
        self.status = "in_progress"
        self.children = []
        self.attributes = {}
        self.events = []
        self._start_timestamp = time.time()

        # RAG-specific attributes
        self.retrieval_info: Optional[RetrievalInfo] = None
        self.generation_info: Optional[GenerationInfo] = None
        self.rag_pipeline_stage: Optional[str] = None  # "retrieval", "generation", "full_pipeline"

    def set_retrieval_info(self, retrieval_info: RetrievalInfo):
        """Set retrieval information for this span"""
        self.retrieval_info = retrieval_info
        self.rag_pipeline_stage = "retrieval"

        # Add key retrieval attributes to span
        self.attributes.update(
            {
                "rag.retriever_type": retrieval_info.retriever,
                "rag.embedding_model": retrieval_info.embedding_model,
                "rag.top_k": retrieval_info.top_k,
                "rag.hit_count": len(retrieval_info.hits) if retrieval_info.hits else 0,
                "rag.retrieval_latency_ms": retrieval_info.latency_ms,
            }
        )

    def set_generation_info(self, generation_info: GenerationInfo):
        """Set generation information for this span"""
        self.generation_info = generation_info
        if self.rag_pipeline_stage == "retrieval":
            self.rag_pipeline_stage = "full_pipeline"
        else:
            self.rag_pipeline_stage = "generation"

        # Add key generation attributes to span
        self.attributes.update(
            {
                "rag.generation_model": generation_info.model_used,
                "rag.answer_length": len(generation_info.answer) if generation_info.answer else 0,
                "rag.citation_count": (
                    len(generation_info.citations) if generation_info.citations else 0
                ),
                "rag.generation_latency_ms": generation_info.generation_latency_ms,
            }
        )

    def add_child(self, child_span_id: str):
        """Add a child span ID to this span"""
        if child_span_id not in self.children:
            self.children.append(child_span_id)

    def set_attribute(self, key: str, value: Any):
        """Set a span attribute"""
        from .tracer import _safe_serialize

        self.attributes[key] = _safe_serialize(value)

    def add_event(self, name: str, data: Dict[str, Any] = None):
        """Add an event to this span"""
        event = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": name,
            "data": data or {},
        }
        self.events.append(event)

    def finish(self, status: str = "success"):
        """Finish the span"""
        self.end_time = datetime.utcnow().isoformat() + "Z"
        self.duration_ms = round((time.time() - self._start_timestamp) * 1000, 2)
        self.status = status

    def end(self, status: str = "success"):
        """End the span (alias for finish)"""
        self.finish(status)

    def to_dict(self) -> Dict[str, Any]:
        """Convert span to dictionary with RAG extensions"""
        base_dict = {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "children": self.children,
            "attributes": self.attributes,
            "events": self.events,
        }

        # Add RAG-specific information
        # Check retrieval_info (RetrievalInfo object) first, then retrieval (dict) as backup
        if self.retrieval_info:
            base_dict["retrieval"] = self.retrieval_info.to_dict()
        elif hasattr(self, "retrieval") and self.retrieval:
            # Backup: retrieval dict set directly (from autolog)
            base_dict["retrieval"] = self.retrieval

        # Check generation_info (GenerationInfo object) first, then generation (dict) as backup
        if self.generation_info:
            base_dict["generation"] = self.generation_info.to_dict()
        elif hasattr(self, "generation") and self.generation:
            # Backup: generation dict set directly
            base_dict["generation"] = self.generation

        if self.rag_pipeline_stage:
            base_dict["rag_pipeline_stage"] = self.rag_pipeline_stage

        return base_dict


class RAGTraceEvent:
    """Enhanced trace event with RAG context"""

    def __init__(self, level: str = "primary", **fields: Any):
        self.ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        self.level = level
        self.fields = fields

        # RAG-specific fields
        self.retrieval_context: Optional[RetrievalInfo] = None
        self.generation_context: Optional[GenerationInfo] = None

    def set_retrieval_context(self, retrieval_info: RetrievalInfo):
        """Add retrieval context to the event"""
        self.retrieval_context = retrieval_info
        self.fields["retrieval"] = retrieval_info.to_dict()

    def set_generation_context(self, generation_info: GenerationInfo):
        """Add generation context to the event"""
        self.generation_context = generation_info
        self.fields["generation"] = generation_info.to_dict()

    def to_dict(self) -> Dict[str, Any]:
        from .tracer import _safe_serialize

        d = {"ts": self.ts, "level": self.level, **_safe_serialize(self.fields)}
        d["_record_type"] = "session" if self.level == "session" else "event"
        return d


# Helper functions for creating RAG objects
def create_document_hit(
    doc_id: str,
    rank: int,
    score: float,
    snippet: str = None,
    span: List[int] = None,
    metadata: Dict[str, Any] = None,
) -> DocumentHit:
    """Create a DocumentHit with optional snippet truncation"""
    if snippet and len(snippet) > 200:
        snippet = snippet[:200] + "..."

    return DocumentHit(
        doc_id=doc_id, rank=rank, score=score, span=span, snippet_preview=snippet, metadata=metadata
    )


def create_citation(
    doc_id: str, span: List[int] = None, confidence: float = None, relevance_score: float = None
) -> Citation:
    """Create a Citation object"""
    return Citation(
        doc_id=doc_id, span=span, confidence=confidence, relevance_score=relevance_score
    )


def create_format_check(answer: str, **kwargs) -> FormatCheck:
    """Create a FormatCheck with automatic validation"""
    return FormatCheck(
        is_complete=bool(answer and answer.strip()),
        length_tokens=kwargs.get("length_tokens"),
        length_chars=len(answer) if answer else 0,
        refusal=(
            any(
                phrase in answer.lower()
                for phrase in ["i can't", "i cannot", "sorry, i can't"]
                if answer
            )
            if answer
            else False
        ),
        contains_citations=bool(kwargs.get("citations")),
        citation_count=len(kwargs.get("citations", [])),
        language=kwargs.get("language", "en"),
        format_type=kwargs.get("format_type", "plain_text"),
    )
