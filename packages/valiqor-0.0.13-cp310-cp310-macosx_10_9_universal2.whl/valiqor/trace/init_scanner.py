"""
Lightweight AST Scanner for valiqor init.

This module provides a quick codebase scan to detect LLM usage patterns
without running the full scan pipeline (no LLM expansion, no backend upload).

Used by: valiqor init, valiqor refresh
"""

import ast
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# Directories to skip during scanning
SKIP_DIRS: Set[str] = {
    "__pycache__",
    ".venv",
    "venv",
    "env",
    ".env",
    ".git",
    ".svn",
    "node_modules",
    ".tox",
    ".pytest_cache",
    ".mypy_cache",
    "dist",
    "build",
    "site-packages",
    ".eggs",
    "*.egg-info",
    "valiqor_output",
    "traces",
}

# Files to skip during scanning (valiqor config/output files)
SKIP_FILES: Set[str] = {
    ".valiqorrc",
    "valiqor_init.py",
}


def _should_skip_path(path: Path) -> bool:
    """Check if a path should be skipped based on SKIP_DIRS and SKIP_FILES patterns."""
    # Check if filename is in skip list
    if path.name in SKIP_FILES:
        return True

    # Check if any directory component is in skip list
    for part in path.parts:
        if part in SKIP_DIRS:
            return True
        # Handle wildcard patterns like *.egg-info
        for skip_pattern in SKIP_DIRS:
            if "*" in skip_pattern:
                import fnmatch

                if fnmatch.fnmatch(part, skip_pattern):
                    return True
    return False


def _load_gitignore_patterns(repo_path: Path) -> List[str]:
    """Load patterns from .gitignore if it exists."""
    gitignore = repo_path / ".gitignore"
    patterns = []
    if gitignore.exists():
        try:
            with open(gitignore, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        patterns.append(line)
        except Exception:
            pass
    return patterns


def quick_detect(repo_path: str = ".", verbose: bool = False) -> List[Dict[str, Any]]:
    """
    Quick AST scan for LLM detection only.

    This is a lightweight scan that reuses ASTScanner from the scanner module
    but skips the full pipeline (no LLM expansion, no upload).

    Args:
        repo_path: Path to the repository to scan (default: current directory)
        verbose: Print progress messages

    Returns:
        List of detection dictionaries with keys:
        - file: Path to the file
        - function: Enclosing function/class name
        - call_type: Type of detection (llm.call, tool.definition, etc.)
        - library: Detected library (openai, anthropic, langchain, etc.)
        - line: Line number
        - callee: The called function/method name
        - confidence: Detection confidence (0.0-1.0)
    """
    try:
        from ..scanner.core.ast_scanner import ASTScanner
    except ImportError as e:
        logger.warning(f"Scanner module not available: {e}")
        return []

    detections: List[Dict[str, Any]] = []
    repo = Path(repo_path).resolve()

    if verbose:
        print(f"  Scanning: {repo}")

    # Find all Python files
    py_files = []
    for py_file in repo.rglob("*.py"):
        if not _should_skip_path(py_file.relative_to(repo)):
            py_files.append(py_file)

    if verbose:
        print(f"  Found {len(py_files)} Python files")

    # Scan each file
    for py_file in py_files:
        try:
            source = py_file.read_text(encoding="utf-8")

            # Use relative path for cleaner output
            rel_path = str(py_file.relative_to(repo))

            scanner = ASTScanner(rel_path, source)
            file_detections = scanner.scan_source()

            # Add source lines for context
            source_lines = source.splitlines()
            for detection in file_detections:
                line_num = detection.get("line", 0)
                if 0 < line_num <= len(source_lines):
                    detection["source_line"] = source_lines[line_num - 1].strip()
                detections.append(detection)

            if verbose and file_detections:
                print(f"    {rel_path}: {len(file_detections)} detections")

        except SyntaxError as e:
            if verbose:
                print(f"    ⚠️  Syntax error in {py_file.name}: {e}")
        except UnicodeDecodeError:
            if verbose:
                print(f"    ⚠️  Encoding error in {py_file.name}")
        except Exception as e:
            if verbose:
                print(f"    ⚠️  Error scanning {py_file.name}: {e}")

    return detections


def detect_entry_points(repo_path: str = ".") -> List[Dict[str, Any]]:
    """
    Detect main entry points in the codebase.

    Looks for:
    - if __name__ == "__main__" blocks
    - Streamlit apps (st.button handlers)
    - FastAPI/Flask route handlers
    - CLI entry points

    Args:
        repo_path: Path to the repository

    Returns:
        List of entry point dictionaries with keys:
        - file: Path to the file
        - type: Entry point type (main, streamlit, fastapi, flask, cli)
        - line: Line number
        - name: Entry point name/description
    """
    entry_points: List[Dict[str, Any]] = []
    repo = Path(repo_path).resolve()

    for py_file in repo.rglob("*.py"):
        if _should_skip_path(py_file.relative_to(repo)):
            continue

        try:
            source = py_file.read_text(encoding="utf-8")
            rel_path = str(py_file.relative_to(repo))
            tree = ast.parse(source, filename=rel_path)

            for node in ast.walk(tree):
                # Detect if __name__ == "__main__"
                if isinstance(node, ast.If):
                    if _is_main_check(node):
                        entry_points.append(
                            {
                                "file": rel_path,
                                "type": "main",
                                "line": node.lineno,
                                "name": "__main__",
                            }
                        )

                # Detect Streamlit button handlers
                if isinstance(node, ast.Call):
                    call_name = _get_call_name(node)
                    if call_name in ("st.button", "streamlit.button"):
                        entry_points.append(
                            {
                                "file": rel_path,
                                "type": "streamlit",
                                "line": node.lineno,
                                "name": _get_button_label(node),
                            }
                        )

                # Detect FastAPI/Flask route decorators
                if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                    for decorator in node.decorator_list:
                        dec_name = _get_decorator_name(decorator)
                        if dec_name and any(
                            x in dec_name for x in ["route", "get", "post", "put", "delete"]
                        ):
                            framework = "fastapi" if "app" in dec_name.lower() else "flask"
                            entry_points.append(
                                {
                                    "file": rel_path,
                                    "type": framework,
                                    "line": node.lineno,
                                    "name": node.name,
                                }
                            )

        except (SyntaxError, UnicodeDecodeError):
            continue
        except Exception:
            continue

    return entry_points


def _is_main_check(node: ast.If) -> bool:
    """Check if an If node is 'if __name__ == "__main__"'."""
    test = node.test
    if isinstance(test, ast.Compare):
        if len(test.ops) == 1 and isinstance(test.ops[0], ast.Eq):
            left = test.left
            right = test.comparators[0] if test.comparators else None

            # Check for __name__ == "__main__"
            if isinstance(left, ast.Name) and left.id == "__name__":
                if isinstance(right, ast.Constant) and right.value == "__main__":
                    return True
                # Python 3.7 compatibility
                if isinstance(right, ast.Str) and right.s == "__main__":
                    return True
    return False


def _get_call_name(node: ast.Call) -> str:
    """Extract the full call name from a Call node."""
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    elif isinstance(func, ast.Attribute):
        parts = []
        current = func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return ".".join(reversed(parts))
    return ""


def _get_button_label(node: ast.Call) -> str:
    """Extract button label from st.button() call."""
    if node.args:
        first_arg = node.args[0]
        if isinstance(first_arg, ast.Constant):
            return str(first_arg.value)[:50]
        if isinstance(first_arg, ast.Str):  # Python 3.7
            return first_arg.s[:50]
    return "button"


def _get_decorator_name(node) -> Optional[str]:
    """Extract decorator name from a decorator node."""
    if isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Attribute):
        return _get_call_name(ast.Call(func=node, args=[], keywords=[]))
    elif isinstance(node, ast.Call):
        return _get_call_name(node)
    return None
