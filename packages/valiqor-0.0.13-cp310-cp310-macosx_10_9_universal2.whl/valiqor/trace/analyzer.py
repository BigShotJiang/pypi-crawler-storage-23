"""
Detection Analyzer for valiqor init.

Processes AST detections to generate:
- Provider detection (openai, anthropic, langchain, etc.)
- Workflow suggestions (where to add trace_workflow)
- Entry point analysis
- Call hierarchy analysis (to avoid suggesting @trace_workflow on nested functions)

Used by: valiqor init, valiqor refresh
"""

import ast
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


@dataclass
class WorkflowSuggestion:
    """A suggested location to add trace_workflow."""

    file: str
    line: int
    function_name: str
    workflow_name: str
    suggestion_type: str  # 'decorator' or 'context_manager'
    llm_calls: List[Dict[str, Any]]
    reason: str
    code_snippet: Optional[str] = None
    input_variable: Optional[str] = None  # Detected user input variable
    # Call hierarchy fields
    is_entry_point: bool = True  # True = suggest @trace_workflow, False = nested/auto-traced
    is_recommended: bool = False  # True = PRIMARY entry point (applied by default)
    called_by: List[str] = field(default_factory=list)  # Functions that call this one
    calls: List[str] = field(default_factory=list)  # Functions this one calls

    def to_dict(self) -> Dict[str, Any]:
        return {
            "file": self.file,
            "line": self.line,
            "function_name": self.function_name,
            "workflow_name": self.workflow_name,
            "suggestion_type": self.suggestion_type,
            "llm_calls_count": len(self.llm_calls),
            "reason": self.reason,
            "code_snippet": self.code_snippet,
            "input_variable": self.input_variable,
            "is_entry_point": self.is_entry_point,
            "is_recommended": self.is_recommended,
            "called_by": self.called_by,
            "calls": self.calls,
        }


@dataclass
class AnalysisResult:
    """Result of analyzing AST detections."""

    providers: List[str] = field(default_factory=list)
    workflow_suggestions: List[WorkflowSuggestion] = field(default_factory=list)
    detections_by_file: Dict[str, List[Dict]] = field(default_factory=dict)
    entry_points: List[Dict[str, Any]] = field(default_factory=list)
    total_llm_calls: int = 0
    total_tool_definitions: int = 0
    total_files_with_llm: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "providers": self.providers,
            "workflow_suggestions": [s.to_dict() for s in self.workflow_suggestions],
            "total_llm_calls": self.total_llm_calls,
            "total_tool_definitions": self.total_tool_definitions,
            "total_files_with_llm": self.total_files_with_llm,
            "files_analyzed": list(self.detections_by_file.keys()),
        }


# Mapping from detection library names to provider names
LIBRARY_TO_PROVIDER: Dict[str, str] = {
    "openai": "openai",
    "anthropic": "anthropic",
    "langchain": "langchain",
    "langchain_openai": "langchain",
    "langchain_anthropic": "langchain",
    "langchain_community": "langchain",
    "langgraph": "langchain",
    "ollama": "ollama",
    "vertexai": "vertexai",
    "google": "google",
    "llama_index": "llama_index",
    "agno": "agno",
    "crewai": "crewai",
    "autogen": "autogen",
}


def analyze_detections(
    detections: List[Dict[str, Any]],
    entry_points: Optional[List[Dict[str, Any]]] = None,
    repo_path: str = ".",
) -> AnalysisResult:
    """
    Analyze AST detections to extract providers and workflow suggestions.

    Args:
        detections: List of detection dictionaries from quick_detect()
        entry_points: Optional list of entry points from detect_entry_points()
        repo_path: Path to the repository root (for call hierarchy analysis)

    Returns:
        AnalysisResult with providers, suggestions, and statistics
    """
    result = AnalysisResult()
    result.entry_points = entry_points or []

    # Group detections by file
    by_file: Dict[str, List[Dict]] = defaultdict(list)
    for detection in detections:
        file_path = detection.get("file", "")
        by_file[file_path].append(detection)

    result.detections_by_file = dict(by_file)

    # Extract unique providers
    providers_set: Set[str] = set()
    for detection in detections:
        library = detection.get("library", "")
        if library:
            provider = LIBRARY_TO_PROVIDER.get(library.lower(), library.lower())
            providers_set.add(provider)

        # Also check for HTTP endpoints to LLM services
        endpoint = detection.get("endpoint", "")
        if "ollama" in endpoint.lower() or "11434" in endpoint:
            providers_set.add("ollama")
        elif "openai" in endpoint.lower():
            providers_set.add("openai")
        elif "anthropic" in endpoint.lower():
            providers_set.add("anthropic")

    result.providers = sorted(list(providers_set))

    # Count statistics (exclude llm.config from LLM call counts)
    for detection in detections:
        call_type = detection.get("call_type", "")
        # Only count actual LLM inference calls, not configuration
        if call_type == "llm.call":
            result.total_llm_calls += 1
        elif call_type in ("tool.definition", "tool.call"):
            result.total_tool_definitions += 1

    result.total_files_with_llm = len(
        [
            f
            for f, dets in by_file.items()
            if any(d.get("call_type") == "llm.call" for d in dets)  # Excludes llm.config
        ]
    )

    # Generate workflow suggestions
    result.workflow_suggestions = _generate_workflow_suggestions(by_file, entry_points, repo_path)

    return result


def _generate_workflow_suggestions(
    detections_by_file: Dict[str, List[Dict]],
    entry_points: Optional[List[Dict[str, Any]]] = None,
    repo_path: str = ".",
) -> List[WorkflowSuggestion]:
    """
    Generate trace_workflow placement suggestions.

    Strategy:
    1. Find functions that contain LLM calls OR graph invocations
    2. Prioritize: graph.invocation > llm.call > llm instantiation
    3. Prioritize entry points (main, streamlit handlers, API routes)
    4. Suggest decorator for functions, context manager for code blocks
    5. Detect input variables for each suggestion
    6. Build call hierarchy to identify TRUE entry points
    7. Mark nested functions as auto-traced (don't suggest @trace_workflow)
    """
    # Import input detector
    try:
        from .input_detector import detect_input_variable
    except ImportError:
        detect_input_variable = None

    suggestions: List[WorkflowSuggestion] = []
    entry_point_files = {ep["file"] for ep in (entry_points or [])}

    # Call types that indicate workflow-worthy functions (in priority order)
    # These are ACTUAL inference calls that should trigger workflow tracing
    WORKFLOW_CALL_TYPES = {
        "graph.invocation": "graph invocation",  # Highest priority - orchestrates LLM calls
        "agent.invocation": "agent invocation",  # Agent.run(), agent.invoke()
        "crew.invocation": "crew invocation",  # CrewAI kickoff, agent.run()
        "llm.call": "LLM call",  # Actual LLM inference
        "llm.invocation": "LLM invocation",  # Method calls like llm.complete(), llm.invoke()
        "chain.invocation": "chain invocation",
    }

    # Call types that are just setup/configuration (DO NOT suggest trace_workflow for these)
    SETUP_CALL_TYPES = {
        "llm.instantiation",  # Creating LLM client objects
        "llm.config",  # genai.configure(), openai.api_key=, etc.
    }

    for file_path, detections in detections_by_file.items():
        # Group detections by enclosing function
        by_function = _group_by_function(detections)

        for func_name, func_detections in by_function.items():
            # Filter out setup/config calls - they don't indicate workflow entry points
            non_setup_detections = [
                d for d in func_detections if d.get("call_type") not in SETUP_CALL_TYPES
            ]

            # Find workflow-relevant calls (graph invocations, agent invocations, LLM calls, etc.)
            workflow_calls = [
                d for d in non_setup_detections if d.get("call_type") in WORKFLOW_CALL_TYPES
            ]

            # Also check for llm.call that might be instantiation vs invocation
            # ChatOpenAI() is instantiation, llm.invoke() is invocation
            llm_calls = [d for d in non_setup_detections if d.get("call_type") == "llm.call"]

            # Prioritize functions with graph/chain/agent invocations over mere LLM calls
            has_invocation = any(
                d.get("call_type")
                in ("graph.invocation", "chain.invocation", "agent.invocation", "crew.invocation")
                for d in non_setup_detections
            )

            # Skip if no workflow-relevant calls (only setup/config calls)
            if not workflow_calls and not llm_calls:
                continue

            # Build the reason based on what was detected
            call_counts = []
            if has_invocation:
                graph_count = sum(
                    1 for d in non_setup_detections if d.get("call_type") == "graph.invocation"
                )
                agent_count = sum(
                    1
                    for d in non_setup_detections
                    if d.get("call_type") in ("agent.invocation", "crew.invocation")
                )
                if graph_count:
                    call_counts.append(f"{graph_count} graph invocation(s)")
                if agent_count:
                    call_counts.append(f"{agent_count} agent invocation(s)")
            if llm_calls:
                call_counts.append(f"{len(llm_calls)} LLM call(s)")

            # Use all detected calls for this function
            all_relevant_calls = workflow_calls if workflow_calls else llm_calls

            # Detect input variable from LLM calls
            input_variable = None
            if detect_input_variable:
                # Try each call until we find an input variable
                for call in all_relevant_calls:
                    detected = detect_input_variable(call)
                    if detected:
                        input_variable = detected
                        break

            # Determine suggestion type
            if func_name == "<module>":
                # Module-level code - suggest context manager
                suggestion_type = "context_manager"
                workflow_name = _generate_workflow_name(file_path)
                reason = (
                    f"Module level: {', '.join(call_counts) if call_counts else 'LLM activity'}"
                )
                line = min(d.get("line", 1) for d in all_relevant_calls)
            elif func_name.startswith("<handler:"):
                # Streamlit/UI handler block - suggest context manager inside the handler
                suggestion_type = "context_manager"
                workflow_name = _sanitize_workflow_name(func_name)
                # Extract handler info for display
                handler_display = func_name.replace("<handler:", "").rstrip(">")
                reason = f"Streamlit handler ({handler_display}): {', '.join(call_counts) if call_counts else 'LLM activity'}"
                # Use the first detection's line (inside the handler)
                line = min(d.get("line", 1) for d in all_relevant_calls) - 1
                if line < 1:
                    line = 1
            else:
                # Function - suggest decorator
                suggestion_type = "decorator"
                workflow_name = _sanitize_workflow_name(func_name)
                reason = (
                    f"Function contains {', '.join(call_counts) if call_counts else 'LLM activity'}"
                )
                # Use the first detection's line as function start approximation
                line = min(d.get("line", 1) for d in func_detections) - 1
                if line < 1:
                    line = 1

            # Prioritize entry point files
            if file_path in entry_point_files:
                reason = f"[ENTRY POINT] {reason}"

            # Mark functions with graph invocations as higher priority
            if has_invocation:
                reason = f"[ORCHESTRATOR] {reason}"

            # Get code snippet if available
            code_snippet = None
            if all_relevant_calls and "source_line" in all_relevant_calls[0]:
                code_snippet = all_relevant_calls[0]["source_line"]

            suggestion = WorkflowSuggestion(
                file=file_path,
                line=line,
                function_name=func_name,
                workflow_name=workflow_name,
                suggestion_type=suggestion_type,
                llm_calls=llm_calls,
                reason=reason,
                code_snippet=code_snippet,
                input_variable=input_variable,
            )
            suggestions.append(suggestion)

    # Sort by priority:
    # 1. Public orchestrators (graph invocations without _ prefix) - best for tracing
    # 2. Entry points
    # 3. Private orchestrators (internal methods called by graph)
    # 4. Other functions by file/line
    def sort_key(s: WorkflowSuggestion):
        is_orchestrator = "[ORCHESTRATOR]" in s.reason
        is_entry = "[ENTRY POINT]" in s.reason

        # Check if it's a private method (starts with _)
        func_name = s.function_name.split(".")[-1] if "." in s.function_name else s.function_name
        is_private = func_name.startswith("_")

        # Priority order (lower = higher priority):
        # 0: Public orchestrator at entry point
        # 1: Public orchestrator
        # 2: Entry point
        # 3: Private orchestrator (internal graph nodes - less useful to manually trace)
        # 4: Everything else
        if is_orchestrator and not is_private:
            if is_entry:
                priority = 0
            else:
                priority = 1
        elif is_entry:
            priority = 2
        elif is_orchestrator and is_private:
            priority = 3
        else:
            priority = 4

        return (priority, s.file, s.line)

    suggestions.sort(key=sort_key)

    # Build call hierarchy to identify TRUE entry points
    # Functions called by other suggested functions should NOT get @trace_workflow
    suggestions = _apply_call_hierarchy(suggestions, detections_by_file, repo_path)

    return suggestions


def _apply_call_hierarchy(
    suggestions: List[WorkflowSuggestion],
    detections_by_file: Dict[str, List[Dict]],
    repo_path: str = ".",
) -> List[WorkflowSuggestion]:
    """
    Analyze call hierarchy and mark nested functions as auto-traced.

    A function is a TRUE entry point if no other suggested function calls it.
    Nested functions get is_entry_point=False and modified reason.

    Strategy:
    1. Try to load hierarchy from scan output (feature.json, context.json)
       - This is framework-agnostic and works for LangGraph, CrewAI, etc.
    2. Merge with AST-based detection for LangGraph add_node() patterns
    3. Fall back to pure AST if no scan data available
    """
    if not suggestions:
        return suggestions

    # Get all suggested function names (including qualified names like Class.method)
    suggested_funcs = {s.function_name for s in suggestions}

    # Try to load call hierarchy from scan output (feature.json)
    # This uses feature groupings which work for any framework
    scan_calls_map = _load_call_hierarchy_from_scan(repo_path, suggested_funcs)

    # Also run AST-based detection for framework-specific patterns
    # (e.g., LangGraph add_node(), direct self.method() calls)
    ast_calls_map = _build_call_hierarchy(detections_by_file, suggested_funcs, repo_path)

    # Merge both: union of detected call relationships
    calls_map: Dict[str, Set[str]] = defaultdict(set)
    for caller, callees in scan_calls_map.items():
        calls_map[caller].update(callees)
    for caller, callees in ast_calls_map.items():
        calls_map[caller].update(callees)

    # Build reverse map: function -> set of functions that call it
    called_by_map: Dict[str, Set[str]] = defaultdict(set)
    for caller, callees in calls_map.items():
        for callee in callees:
            called_by_map[callee].add(caller)

    # Mark each suggestion
    for suggestion in suggestions:
        func_name = suggestion.function_name

        # Check if any OTHER suggested function calls this one
        callers = called_by_map.get(func_name, set())
        # Filter to only callers that are also in suggested_funcs
        callers_that_are_suggested = callers & suggested_funcs

        if callers_that_are_suggested:
            # This function is called by another suggested function
            suggestion.is_entry_point = False
            suggestion.called_by = sorted(list(callers_that_are_suggested))

            # Update reason to indicate it's auto-traced
            original_reason = suggestion.reason
            # Remove existing prefixes to keep it clean
            for prefix in ["[ORCHESTRATOR] ", "[ENTRY POINT] "]:
                original_reason = original_reason.replace(prefix, "")

            caller_names = ", ".join(suggestion.called_by)
            suggestion.reason = f"[AUTO-TRACED] Called by {caller_names} - {original_reason}"
        else:
            suggestion.is_entry_point = True

        # Store what this function calls
        if func_name in calls_map:
            suggestion.calls = sorted(list(calls_map[func_name]))

    # Re-sort: True entry points first, then auto-traced
    def final_sort_key(s: WorkflowSuggestion):
        # Entry points first (0), then auto-traced (1)
        entry_priority = 0 if s.is_entry_point else 1
        # Then by original priority
        is_orchestrator = "[ORCHESTRATOR]" in s.reason or "graph invocation" in s.reason
        is_private = s.function_name.split(".")[-1].startswith("_")

        if is_orchestrator and not is_private:
            sub_priority = 0
        elif not is_private:
            sub_priority = 1
        else:
            sub_priority = 2

        return (entry_priority, sub_priority, s.file, s.line)

    suggestions.sort(key=final_sort_key)

    # Mark the first entry point as RECOMMENDED (primary entry point)
    # Only one should be marked as recommended - typically the orchestrator
    for suggestion in suggestions:
        if suggestion.is_entry_point:
            suggestion.is_recommended = True
            break  # Only mark the first one

    return suggestions


def _find_latest_scan_output(repo_path: str) -> Optional[Path]:
    """
    Find the most recent scan output directory.

    Searches in order:
    1. valiqor_output/scans/ (new format)
    2. scans/ (old format)

    Returns the most recent scan folder, or None if not found.
    """
    repo = Path(repo_path)

    # Possible scan directories (in order of preference)
    scan_dirs = [
        repo / "valiqor_output" / "scans",  # New format
        repo / "scans",  # Old format
    ]

    all_scan_folders = []

    for scans_dir in scan_dirs:
        if not scans_dir.exists():
            continue

        # Find scan folders - handle both naming conventions
        for d in scans_dir.iterdir():
            if not d.is_dir():
                continue
            # Match both "AST_and_Tracing_*" and "<project>_*" formats
            # All valid scan folders have a timestamp pattern
            import re

            if re.match(r".+_\d{8}_\d{6}$", d.name):
                all_scan_folders.append(d)

    if not all_scan_folders:
        return None

    # Sort by modification time (most recent first)
    all_scan_folders.sort(key=lambda d: d.stat().st_mtime, reverse=True)
    return all_scan_folders[0]


def _load_call_hierarchy_from_scan(
    repo_path: str, target_functions: Set[str]
) -> Dict[str, Set[str]]:
    """
    Load call hierarchy from existing scan output (feature.json, context.json).

    Strategy (generic, not LangGraph-specific):
    1. Load feature.json to find feature groupings (agentic_rag, tool_agent, etc.)
    2. Within each feature, identify entry points (public methods) vs helpers (private methods)
    3. Entry points "call" all private methods in the same feature/class

    This works for any orchestration pattern (LangGraph, CrewAI, AutoGen, etc.)
    because the scanner has already identified feature boundaries.

    Args:
        repo_path: Path to the repository root
        target_functions: Set of function names we care about (e.g., "AgenticRAGChat.process_message")

    Returns:
        Dict mapping function_name -> set of functions it calls (that are in target_functions)
        Empty dict if scan output not found.
    """
    import json

    calls_map: Dict[str, Set[str]] = defaultdict(set)

    # Find latest scan output
    latest_scan = _find_latest_scan_output(repo_path)
    if not latest_scan:
        return {}

    feature_file = latest_scan / "feature.json"
    context_file = latest_scan / "context.json"

    if not feature_file.exists():
        return {}

    try:
        # Load feature.json - groups related functions into features
        with open(feature_file, "r", encoding="utf-8") as f:
            features = json.load(f)

        # Load context.json for node details (optional, for richer info)
        node_details: Dict[str, Dict] = {}
        if context_file.exists():
            with open(context_file, "r", encoding="utf-8") as f:
                context = json.load(f)
                for node in context.get("ast_nodes", []):
                    node_id = node.get("node_id")
                    if node_id:
                        node_details[node_id] = node

        # Build map of class_context -> list of target functions in that class
        class_to_funcs: Dict[str, Set[str]] = defaultdict(set)
        for func in target_functions:
            if "." in func:
                class_name = func.split(".")[0]
                class_to_funcs[class_name].add(func)
            else:
                class_to_funcs["GLOBAL"].add(func)

        # Process each feature to identify entry points vs helpers
        for feature in features:
            class_context = feature.get("class_context", "GLOBAL")
            feature_kind = feature.get("feature_kind", "")
            has_loop = feature.get("has_loop", False)
            source_nodes = feature.get("source_nodes", [])

            # Skip features that don't have our target functions
            if class_context not in class_to_funcs:
                continue

            funcs_in_class = class_to_funcs[class_context]

            # Features with loops or agentic patterns have orchestration
            is_orchestration = has_loop or feature_kind in (
                "agentic_rag",
                "tool_agent",
                "multi_agent",
                "chain_workflow",
                "rag_pipeline",
                "agent_workflow",
            )

            if not is_orchestration:
                continue

            # Find entry points (public methods) and helpers (private methods)
            # within this feature's class
            entry_points = set()
            helper_methods = set()

            for func in funcs_in_class:
                method_name = func.split(".")[-1] if "." in func else func

                # Private methods (start with _) are helpers
                # Public methods are potential entry points
                if method_name.startswith("_") and not method_name.startswith("__"):
                    helper_methods.add(func)
                elif method_name not in ("__init__", "__call__"):
                    entry_points.add(func)

            # Entry points "call" all helper methods in the same feature
            # This is the key insight: in any orchestration pattern,
            # the public method orchestrates the private helpers
            for entry in entry_points:
                for helper in helper_methods:
                    if entry != helper:
                        calls_map[entry].add(helper)

        return dict(calls_map)

    except (OSError, json.JSONDecodeError) as e:
        return {}


def _normalize_func_name(
    func_name: str, target_functions: Set[str], short_to_qualified: Dict[str, Set[str]]
) -> Optional[str]:
    """
    Normalize a function name to match our target_functions format.

    Returns the matching target function name, or None if no match.
    """
    # Direct match
    if func_name in target_functions:
        return func_name

    # Try short name match (for "process_message" matching "AgenticRAGChat.process_message")
    short_name = func_name.split(".")[-1] if "." in func_name else func_name
    matches = short_to_qualified.get(short_name, set())

    if len(matches) == 1:
        return matches.pop()
    elif len(matches) > 1:
        # Multiple matches - try to find exact class match
        for match in matches:
            if func_name.endswith(match) or match.endswith(func_name):
                return match

    return None


def _build_call_hierarchy(
    detections_by_file: Dict[str, List[Dict]], target_functions: Set[str], repo_path: str = "."
) -> Dict[str, Set[str]]:
    """
    Build a map of which functions call which other functions.

    Uses AST analysis to find function calls within each file.
    Also detects LangGraph patterns where methods are graph nodes.

    Args:
        detections_by_file: Detections grouped by file path
        target_functions: Set of function names we care about
        repo_path: Root path of the repository

    Returns:
        Dict mapping function_name -> set of functions it calls (that are in target_functions)
    """
    calls_map: Dict[str, Set[str]] = defaultdict(set)

    # Track method names without class prefix for matching
    # e.g., "AgenticRAGChat.process_message" should match calls to "self.process_message"
    method_names = set()
    class_methods: Dict[str, str] = {}  # method_name -> qualified_name

    for func in target_functions:
        if "." in func:
            class_name, method_name = func.rsplit(".", 1)
            method_names.add(method_name)
            class_methods[method_name] = func

    for file_path in detections_by_file.keys():
        try:
            full_path = Path(repo_path) / file_path
            if not full_path.exists():
                continue

            source = full_path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source, filename=str(full_path))

            # First pass: find LangGraph node registrations in each class
            # This maps class_name -> {method_names registered as graph nodes}
            graph_nodes_by_class: Dict[str, Set[str]] = defaultdict(set)

            # Also find which methods invoke the graph
            graph_invokers_by_class: Dict[str, Set[str]] = defaultdict(set)

            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    class_name = node.name

                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            # Check for add_node calls (LangGraph pattern)
                            for child in ast.walk(item):
                                if isinstance(child, ast.Call) and isinstance(
                                    child.func, ast.Attribute
                                ):
                                    # Look for .add_node() calls
                                    if child.func.attr == "add_node" and len(child.args) >= 2:
                                        second_arg = child.args[1]
                                        # add_node("name", self.method)
                                        if isinstance(second_arg, ast.Attribute) and isinstance(
                                            second_arg.value, ast.Name
                                        ):
                                            if second_arg.value.id == "self":
                                                graph_nodes_by_class[class_name].add(
                                                    second_arg.attr
                                                )

                                    # Look for .invoke() or .stream() calls on graph
                                    if child.func.attr in (
                                        "invoke",
                                        "stream",
                                        "ainvoke",
                                        "astream",
                                    ):
                                        # Check if this is self.graph.invoke() or similar
                                        if isinstance(child.func.value, ast.Attribute):
                                            if isinstance(child.func.value.value, ast.Name):
                                                if child.func.value.value.id == "self":
                                                    graph_invokers_by_class[class_name].add(
                                                        item.name
                                                    )

            # Second pass: build call map using both direct calls and graph relationships
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    class_name = node.name
                    graph_nodes = graph_nodes_by_class.get(class_name, set())
                    graph_invokers = graph_invokers_by_class.get(class_name, set())

                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            qualified_name = f"{class_name}.{item.name}"
                            if qualified_name in target_functions:
                                # Find direct calls
                                calls = _extract_calls_from_node(
                                    item, target_functions, method_names, class_methods
                                )

                                # If this method invokes the graph, it "calls" all graph nodes
                                if item.name in graph_invokers:
                                    for node_method in graph_nodes:
                                        node_qualified = f"{class_name}.{node_method}"
                                        if node_qualified in target_functions:
                                            calls.add(node_qualified)

                                if calls:
                                    calls_map[qualified_name] = calls

                elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    # Top-level function
                    if node.name in target_functions:
                        calls = _extract_calls_from_node(
                            node, target_functions, method_names, class_methods
                        )
                        if calls:
                            calls_map[node.name] = calls

        except (SyntaxError, UnicodeDecodeError, OSError) as e:
            # Skip files that can't be parsed
            continue

    return dict(calls_map)


def _extract_calls_from_node(
    node: ast.AST, target_functions: Set[str], method_names: Set[str], class_methods: Dict[str, str]
) -> Set[str]:
    """
    Extract function/method calls from an AST node.

    Handles:
    - Direct function calls: some_function()
    - Method calls on self: self.some_method()
    - Method calls on instances: obj.some_method()
    """
    calls = set()

    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            call_name = None

            # Handle different call types
            if isinstance(child.func, ast.Name):
                # Direct function call: some_function()
                call_name = child.func.id
                if call_name in target_functions:
                    calls.add(call_name)

            elif isinstance(child.func, ast.Attribute):
                # Method call: self.method() or obj.method()
                method_name = child.func.attr

                # Check if it's a call to self.method()
                if isinstance(child.func.value, ast.Name):
                    if child.func.value.id == "self":
                        # self.method() - look up the qualified name
                        if method_name in class_methods:
                            calls.add(class_methods[method_name])
                        elif method_name in method_names:
                            # Try to find the qualified name
                            for func in target_functions:
                                if func.endswith(f".{method_name}"):
                                    calls.add(func)
                                    break
                    else:
                        # obj.method() - could be an instance call
                        if method_name in method_names:
                            for func in target_functions:
                                if func.endswith(f".{method_name}"):
                                    calls.add(func)
                                    break

    return calls


def _group_by_function(detections: List[Dict]) -> Dict[str, List[Dict]]:
    """Group detections by their enclosing function."""
    by_function: Dict[str, List[Dict]] = defaultdict(list)

    for detection in detections:
        func = detection.get("function", "<module>")
        # Handle nested class.method format
        if "." in func:
            # Keep the full path for clarity
            pass
        by_function[func].append(detection)

    return dict(by_function)


def _generate_workflow_name(file_path: str) -> str:
    """Generate a workflow name from a file path."""
    stem = Path(file_path).stem
    # Convert to snake_case and clean up
    name = stem.replace("-", "_").replace(" ", "_").lower()
    return f"{name}_workflow"


def _sanitize_workflow_name(func_name: str) -> str:
    """Sanitize a function name for use as workflow name."""
    # Handle handler context format: <handler:button:Label>
    if func_name.startswith("<handler:"):
        # Extract the handler type and label
        # Format: <handler:type:label> or <handler:type:label text>
        inner = func_name[len("<handler:") :].rstrip(">")
        parts = inner.split(":", 1)
        if len(parts) >= 2:
            handler_type = parts[0]  # 'button'
            label = parts[1]  # 'Match Resume with Job Description'
            # Convert label to snake_case workflow name
            label_clean = label.lower()
            # Replace spaces, punctuation with underscores
            import re

            label_clean = re.sub(r"[^a-z0-9]+", "_", label_clean)
            label_clean = label_clean.strip("_")
            # Truncate if too long
            if len(label_clean) > 40:
                label_clean = label_clean[:40].rstrip("_")
            return f"{handler_type}_{label_clean}" if label_clean else handler_type
        return "handler"

    # Remove class prefix if present
    if "." in func_name:
        parts = func_name.split(".")
        class_name = parts[0] if len(parts) > 1 else ""
        method_name = parts[-1]  # Take the method name
    else:
        class_name = ""
        method_name = func_name

    # Handle dunder methods specially
    if method_name.startswith("__") and method_name.endswith("__"):
        # __init__ -> init, __call__ -> call
        core_name = method_name.strip("_")
        if class_name:
            # GeminiEmbedder.__init__ -> gemini_embedder_init
            return f"{_to_snake_case(class_name)}_{core_name}"
        return core_name

    # Clean up common prefixes/suffixes for regular methods
    name = method_name.lower()

    # Only strip single leading underscore for private methods, not double
    if name.startswith("_") and not name.startswith("__"):
        name = name[1:]

    # Strip common prefixes
    for prefix in ("async_", "do_", "run_", "handle_"):
        if name.startswith(prefix) and len(name) > len(prefix):
            name = name[len(prefix) :]
            break

    return name


def _to_snake_case(name: str) -> str:
    """Convert CamelCase to snake_case."""
    import re

    # Insert underscore before uppercase letters and lowercase
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def get_suggested_imports(analysis: AnalysisResult) -> List[str]:
    """
    Get list of import statements needed for the detected providers.

    Args:
        analysis: AnalysisResult from analyze_detections()

    Returns:
        List of import statement strings
    """
    imports = ["import valiqor"]

    # Provider-specific imports if needed
    # (Currently valiqor handles all providers through autolog)

    return imports


def format_suggestion_for_cli(suggestion: WorkflowSuggestion) -> str:
    """
    Format a workflow suggestion for CLI output.

    Args:
        suggestion: WorkflowSuggestion to format

    Returns:
        Formatted string for CLI display
    """
    lines = []
    lines.append(f"  📍 {suggestion.file}:{suggestion.line} - {suggestion.function_name}")

    if suggestion.suggestion_type == "decorator":
        lines.append(f'     Add: @valiqor.trace_workflow("{suggestion.workflow_name}")')
    else:
        lines.append(f'     Add: with valiqor.trace_workflow("{suggestion.workflow_name}"):')

    if suggestion.code_snippet:
        lines.append(f"     Code: {suggestion.code_snippet[:60]}...")

    lines.append(f"     Reason: {suggestion.reason}")

    return "\n".join(lines)
