"""EasyClaw TUI — Interactive OpenClaw installer."""

__version__ = "0.1.1"
