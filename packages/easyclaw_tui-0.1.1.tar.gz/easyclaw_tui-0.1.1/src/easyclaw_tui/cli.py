"""CLI entry point: easyclaw install / easyclaw help."""

from __future__ import annotations

import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="easyclaw",
        description="EasyClaw — Interactive OpenClaw Installer",
    )
    sub = parser.add_subparsers(dest="command")

    # easyclaw install
    install_p = sub.add_parser("install", help="Run the interactive installer")
    install_p.add_argument("--api-key", default="", help="EasyClaw API key (ec_live_...)")
    install_p.add_argument("--openrouter-key", default="", help="OpenRouter API key (sk-or-...)")
    install_p.add_argument("--openai-key", default="", help="OpenAI API key (optional, for memory)")
    install_p.add_argument("--model", default="minimax-m2.5", help="Primary model (default: minimax-m2.5)")
    install_p.add_argument("--channel", default="none", help="Channel: none, whatsapp, telegram, discord")
    install_p.add_argument("--bind", default="lan", help="Bind mode: lan, loopback, auto, tailnet")
    install_p.add_argument("--no-tui", action="store_true", help="Fall back to bash script")

    # easyclaw help
    sub.add_parser("help", help="Post-install troubleshooting and diagnostics")

    args = parser.parse_args()

    if args.command is None:
        # Default to install
        args.command = "install"
        args.api_key = ""
        args.openrouter_key = ""
        args.openai_key = ""
        args.model = "minimax-m2.5"
        args.channel = "none"
        args.bind = "lan"
        args.no_tui = False

    if args.command == "install":
        if getattr(args, "no_tui", False):
            print("Falling back to bash installer...")
            print("Run: curl -fsSL https://easyclaw.help/install.sh | bash")
            sys.exit(0)
        _run_install(
            api_key=getattr(args, "api_key", ""),
            openrouter_key=getattr(args, "openrouter_key", ""),
            openai_key=getattr(args, "openai_key", ""),
            model=getattr(args, "model", "minimax-m2.5"),
            channel=getattr(args, "channel", "none"),
            bind=getattr(args, "bind", "lan"),
        )

    elif args.command == "help":
        _run_help()

    else:
        parser.print_help()


def _run_install(
    api_key: str = "",
    openrouter_key: str = "",
    openai_key: str = "",
    model: str = "minimax-m2.5",
    channel: str = "none",
    bind: str = "lan",
) -> None:
    from easyclaw_tui.app import EasyClawApp

    app = EasyClawApp(
        mode="install",
        api_key=api_key,
        openrouter_key=openrouter_key,
        openai_key=openai_key,
        model=model,
        channel=channel,
        bind=bind,
    )
    app.run()


def _run_help() -> None:
    from easyclaw_tui.app import EasyClawApp

    app = EasyClawApp(mode="help")
    app.run()


if __name__ == "__main__":
    main()
