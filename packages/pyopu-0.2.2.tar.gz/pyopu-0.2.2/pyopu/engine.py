import numpy as np
from pyopu.tensors.base_tensor import Rank1Tensor, Rank2Tensor, Rank3Tensor
from pyopu.telemetry.base_telemetry import Observable

class OPUResult:
    def __init__(self, final_probabilities):
        self.final_probabilities = final_probabilities

    def get_binary_state(self, threshold=0.5):
        return [1 if p > threshold else 0 for p in self.final_probabilities]

class TensorEngine(Observable):
    def __init__(self):
        super().__init__()
        self.T1 = None; self.T2 = None; self.T3 = None

    def set_tensors(self, t1: Rank1Tensor, t2: Rank2Tensor = None, t3: Rank3Tensor = None):
        nv = t1.num_vars
        if t2 is not None and t2.num_vars != nv: raise ValueError("Rank-2 var mismatch.")
        if t3 is not None and t3.num_vars != nv: raise ValueError("Rank-3 var mismatch.")
        self.T1 = t1.data
        self.T2 = t2.data if t2 is not None else None
        self.T3 = t3.data if t3 is not None else None

    def _calculate_force(self, x_state):
        Force = np.copy(self.T1)
        if self.T2 is not None:
            Force += np.dot(self.T2, x_state) + np.dot(self.T2.T, x_state)
        if self.T3 is not None:
            F3 = np.einsum('ijk,j,k->i', self.T3, x_state, x_state)
            F3 += np.einsum('jik,j,k->i', self.T3, x_state, x_state)
            F3 += np.einsum('jki,j,k->i', self.T3, x_state, x_state)
            Force += F3
        return Force

    def run_loop(self, interface, organoid, duration_ms=1000.0, dt_kernel_ms=10.0):
        if self.T1 is None: raise ValueError("Tensors not set.")
        steps = int(duration_ms / dt_kernel_ms)
        import sys
        import time
        
        # Reset telemetry accumulation and interface states
        self.reset_telemetries()
        organoid.reset_telemetries()
        interface.reset()
        
        print(f"Starting OPU Simulation ({organoid.num_neobits} Neobits)...")
        start_time = time.time()

        for step in range(steps):
            x_inst = interface.read_from_organoid(organoid._control_spike_mon, organoid.neurons_per_neobit, organoid.num_neobits)
            organoid.x_state = 0.8 * organoid.x_state + 0.2 * x_inst
            force = self._calculate_force(organoid.x_state)
            interface.write_to_organoid(organoid.neuron_group, force, organoid.neurons_per_neobit)
            
            # Notify observers (like EnergyTelemetry)
            self.notify_telemetries(x_state=organoid.x_state, force=force)
            
            organoid.run_step(dt_kernel_ms)
            
            # Progress bar
            progress = (step + 1) / steps
            bar_len = 30
            filled = int(bar_len * progress)
            bar = '█' * filled + ' ' * (bar_len - filled)
            percent = progress * 100
            elapsed = time.time() - start_time
            mins, secs = divmod(int(elapsed), 60)
            sys.stdout.write(f"\r[Elapsed Time: {mins}:{secs:02d}] |{bar}| {percent:.1f}%")
            sys.stdout.flush()
            
        print("\nExecution Complete.")
        return OPUResult(organoid.x_state)
