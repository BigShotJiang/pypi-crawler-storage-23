import{I as i}from"./index.fgUe_wBo.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
