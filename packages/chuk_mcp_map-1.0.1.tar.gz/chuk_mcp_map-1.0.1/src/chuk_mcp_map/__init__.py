"""chuk-mcp-map — interactive geospatial visualisation MCP server."""

__version__ = "1.0.0"
