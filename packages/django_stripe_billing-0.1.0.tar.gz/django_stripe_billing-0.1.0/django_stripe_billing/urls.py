"""
URL patterns for django_stripe_billing.

Include in your project's urls.py::

    from django.urls import path, include

    urlpatterns = [
        path('webhooks/', include('django_stripe_billing.urls')),
    ]

This exposes: POST /webhooks/stripe/
"""
from django.urls import path

from .views import stripe_webhook

app_name = 'django_stripe_billing'

urlpatterns = [
    path('stripe/', stripe_webhook, name='stripe-webhook'),
]
