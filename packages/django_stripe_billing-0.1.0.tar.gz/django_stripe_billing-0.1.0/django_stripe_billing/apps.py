"""
AppConfig for django_stripe_billing.
"""
from django.apps import AppConfig


class DjangoStripeBillingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_stripe_billing'
    verbose_name = "Django Stripe Billing"

    def ready(self) -> None:
        # Ensure built-in webhook handlers are registered when the app loads.
        import django_stripe_billing.webhooks  # noqa: F401
