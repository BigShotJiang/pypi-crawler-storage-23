"""
Admin registration for django_stripe_billing.
"""
from django.contrib import admin
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

from .models import StripeWebhookEvent


@admin.register(StripeWebhookEvent)
class StripeWebhookEventAdmin(admin.ModelAdmin):
    list_display = (
        "stripe_event_id",
        "event_type",
        "status_badge",
        "attempts",
        "livemode",
        "created_at",
        "processed_at",
    )
    list_filter = ("status", "event_type", "livemode")
    search_fields = ("stripe_event_id", "event_type", "error_message")
    readonly_fields = (
        "stripe_event_id",
        "event_type",
        "api_version",
        "livemode",
        "payload",
        "status",
        "attempts",
        "error_message",
        "created_at",
        "processed_at",
    )
    ordering = ("-created_at",)
    date_hierarchy = "created_at"

    _STATUS_COLOURS = {
        "pending": "#6b7280",  # grey
        "processing": "#2563eb",  # blue
        "success": "#16a34a",  # green
        "error": "#dc2626",  # red
        "skipped": "#d97706",  # amber
    }

    @admin.display(description=_("Status"))
    def status_badge(self, obj: StripeWebhookEvent) -> str:
        colour = self._STATUS_COLOURS.get(obj.status, "#6b7280")
        return format_html(
            '<span style="background:{};color:#fff;padding:2px 8px;'
            'border-radius:4px;font-size:11px">{}</span>',
            colour,
            obj.get_status_display(),
        )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
