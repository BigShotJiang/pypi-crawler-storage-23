from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='StripeWebhookEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('stripe_event_id', models.CharField(
                    db_index=True,
                    help_text='Stripe event ID (evt_...). Unique constraint enforces idempotency.',
                    max_length=255,
                    unique=True,
                )),
                ('event_type', models.CharField(
                    help_text='Stripe event type, e.g. invoice.payment_succeeded',
                    max_length=100,
                )),
                ('api_version', models.CharField(
                    blank=True,
                    default='',
                    help_text='Stripe API version from the event.',
                    max_length=20,
                )),
                ('livemode', models.BooleanField(
                    default=True,
                    help_text='Whether the event was produced in live mode.',
                )),
                ('payload', models.TextField(
                    help_text='Raw JSON payload (truncated to 10 000 chars).',
                )),
                ('status', models.CharField(
                    choices=[
                        ('pending', 'Pending'),
                        ('processing', 'Processing'),
                        ('success', 'Success'),
                        ('error', 'Error'),
                        ('skipped', 'Skipped'),
                    ],
                    db_index=True,
                    default='pending',
                    max_length=20,
                )),
                ('attempts', models.PositiveSmallIntegerField(
                    default=0,
                    help_text='Number of processing attempts.',
                )),
                ('error_message', models.TextField(
                    blank=True,
                    default='',
                    help_text='Error details if status is error.',
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('processed_at', models.DateTimeField(blank=True, null=True)),
            ],
            options={
                'verbose_name': 'Stripe Webhook Event',
                'verbose_name_plural': 'Stripe Webhook Events',
                'ordering': ['-created_at'],
                'indexes': [
                    models.Index(fields=['event_type', 'status'], name='dsb_webhook_event_type_status_idx'),
                    models.Index(fields=['created_at'], name='dsb_webhook_created_at_idx'),
                ],
            },
        ),
    ]
