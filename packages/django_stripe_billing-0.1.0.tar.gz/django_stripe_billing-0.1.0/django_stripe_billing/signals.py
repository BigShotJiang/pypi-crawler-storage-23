"""
Django signals emitted by django_stripe_billing.

Connect to these signals in your app to implement custom business logic
(e.g. updating UserProfile, granting plan access) without modifying the
package itself.

Usage example::

    from django.dispatch import receiver
    from django_stripe_billing.signals import payment_succeeded

    @receiver(payment_succeeded)
    def handle_payment(sender, invoice, user, user_payment, **kwargs):
        user.userprofile.plan = 'pro_monthly'
        user.userprofile.save()
"""
from django.dispatch import Signal

# Fired after invoice.payment_succeeded is handled.
# kwargs: invoice (dict), user (User|None), user_payment (UserPayment|None)
payment_succeeded = Signal()

# Fired after invoice.payment_failed is handled.
# kwargs: invoice (dict), user (User|None), attempt_count (int)
payment_failed = Signal()

# Fired after checkout.session.completed is handled.
# kwargs: session (dict), user_payment (UserPayment|None)
checkout_completed = Signal()

# Fired after customer.subscription.updated is handled.
# kwargs: subscription (dict), user (User|None)
subscription_updated = Signal()

# Fired after customer.subscription.deleted is handled.
# kwargs: subscription (dict), user (User|None), old_plan (str)
subscription_deleted = Signal()

# Fired after charge.refunded is handled.
# kwargs: charge (dict), user (User|None), amount_display (str)
charge_refunded = Signal()

# Fired after customer.subscription.trial_will_end is handled.
# kwargs: subscription (dict), user (User|None), trial_end_date (str)
trial_will_end = Signal()

# Fired after customer.subscription.paused is handled.
# kwargs: subscription (dict), user (User|None)
subscription_paused = Signal()

# Fired after payment_method.attached is handled.
# kwargs: payment_method (dict), user (User|None)
payment_method_attached = Signal()
