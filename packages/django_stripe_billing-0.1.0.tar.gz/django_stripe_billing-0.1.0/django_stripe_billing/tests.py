"""
Tests for django_stripe_billing live in the top-level tests/ package.

Run from project root: pytest

See TESTING.md for how to run and extend the suite.
"""
