"""
Tests for django_stripe_billing.conf.

Covers require_stripe_secret_key, require_webhook_secret, and settings fallback.
"""
import pytest
from django.core.exceptions import ImproperlyConfigured
from django.test import override_settings

from django_stripe_billing.conf import (
    DEFAULTS,
    require_stripe_secret_key,
    require_webhook_secret,
    stripe_billing_settings,
)


class TestRequireStripeSecretKey:
    """require_stripe_secret_key returns key or raises ImproperlyConfigured."""

    def test_raises_when_empty(self):
        with override_settings(STRIPE_BILLING={"STRIPE_SECRET_KEY": ""}):
            with pytest.raises(ImproperlyConfigured) as exc_info:
                require_stripe_secret_key()
            assert "STRIPE_SECRET_KEY" in str(exc_info.value)

    def test_raises_when_whitespace_only(self):
        with override_settings(STRIPE_BILLING={"STRIPE_SECRET_KEY": "   "}):
            with pytest.raises(ImproperlyConfigured):
                require_stripe_secret_key()

    def test_returns_stripped_key_when_set(self):
        with override_settings(STRIPE_BILLING={"STRIPE_SECRET_KEY": " sk_test_abc  "}):
            assert require_stripe_secret_key() == "sk_test_abc"


class TestRequireWebhookSecret:
    """require_webhook_secret returns secret or raises ImproperlyConfigured."""

    def test_raises_when_empty(self):
        with override_settings(STRIPE_BILLING={"STRIPE_WEBHOOK_SECRET": ""}):
            with pytest.raises(ImproperlyConfigured) as exc_info:
                require_webhook_secret()
            assert "STRIPE_WEBHOOK_SECRET" in str(exc_info.value)

    def test_raises_when_whitespace_only(self):
        with override_settings(STRIPE_BILLING={"STRIPE_WEBHOOK_SECRET": "  "}):
            with pytest.raises(ImproperlyConfigured):
                require_webhook_secret()

    def test_returns_stripped_secret_when_set(self):
        with override_settings(
            STRIPE_BILLING={"STRIPE_WEBHOOK_SECRET": " whsec_xyz  "}
        ):
            assert require_webhook_secret() == "whsec_xyz"


class TestStripeBillingSettings:
    """stripe_billing_settings reads from STRIPE_BILLING and DEFAULTS."""

    def test_returns_value_from_stripe_billing_dict(self):
        with override_settings(
            STRIPE_BILLING={"APP_TITLE": "My SaaS", "STRIPE_MODE": "test"}
        ):
            assert stripe_billing_settings.APP_TITLE == "My SaaS"
            assert stripe_billing_settings.STRIPE_MODE == "test"

    def test_unknown_setting_raises_attribute_error(self):
        with pytest.raises(AttributeError) as exc_info:
            _ = stripe_billing_settings.UNKNOWN_KEY
        assert "UNKNOWN_KEY" in str(exc_info.value)

    def test_defaults_used_when_key_not_in_dict(self):
        # Rely on tests/settings.py or default STRIPE_BILLING
        assert stripe_billing_settings.APP_TITLE in ("My App", "My SaaS", "")
        assert stripe_billing_settings.OUTGOING_WEBHOOK_URLS == {} or isinstance(
            stripe_billing_settings.OUTGOING_WEBHOOK_URLS, dict
        )

    def test_defaults_constants(self):
        assert DEFAULTS["STRIPE_SECRET_KEY"] == ""
        assert DEFAULTS["STRIPE_WEBHOOK_SECRET"] == ""
        assert "STRIPE_MODE" in DEFAULTS
        assert "OUTGOING_WEBHOOK_URLS" in DEFAULTS
