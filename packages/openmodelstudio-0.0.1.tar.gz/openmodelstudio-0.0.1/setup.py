from setuptools import setup, find_packages

setup(
    name="openmodelstudio",
    version="0.1.0",
    description="OpenModelStudio SDK — register models, log metrics, and manage artifacts from JupyterLab workspaces",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28",
    ],
)
