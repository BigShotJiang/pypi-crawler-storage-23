"""Tests for the `modelmux dispatch` and `modelmux broadcast` CLI subcommands."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from modelmux.adapters.base import AdapterResult, BaseAdapter


def _make_adapter(available=True, result=None):
    """Create a mock adapter that passes isinstance(x, BaseAdapter)."""
    mock = MagicMock(spec=BaseAdapter)
    mock.check_available.return_value = available
    if result is not None:
        mock.run = AsyncMock(return_value=result)
    return mock


def _dispatch_ns(**overrides):
    """Build a namespace for dispatch with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "provider": "codex",
        "model": "",
        "sandbox": "read-only",
        "timeout": 300,
        "workdir": ".",
        "task": ["test"],
        "max_retries": 1,
        "failover": False,
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


def _broadcast_ns(**overrides):
    """Build a namespace for broadcast with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "providers": None,
        "model": "",
        "sandbox": "read-only",
        "timeout": 300,
        "workdir": ".",
        "task": ["test"],
        "compare": False,
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


# ── dispatch tests ──


def test_dispatch_no_task_exits(monkeypatch):
    """dispatch with no task and empty stdin should exit 1."""
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=[])
    monkeypatch.setattr("sys.stdin", MagicMock(read=MagicMock(return_value="")))

    with pytest.raises(SystemExit) as exc_info:
        _cmd_dispatch(ns)
    assert exc_info.value.code == 1


def test_dispatch_no_providers_exits():
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=["hello world"])
    mock_adapter = _make_adapter(available=False)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)
    assert exc_info.value.code == 1


def test_dispatch_success(capsys):
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["review", "this", "code"])
    fake_result = AdapterResult(
        run_id="abc123",
        provider="codex",
        status="success",
        output="Looks good!",
        summary="Looks good!",
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"
    assert result["provider"] == "codex"
    assert result["output"] == "Looks good!"


def test_dispatch_auto_routes(capsys):
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=["analyze architecture"])
    mock_codex = _make_adapter(available=True)
    fake_result = AdapterResult(
        run_id="r1",
        provider="gemini",
        status="success",
        output="Analysis done",
        summary="Analysis done",
    )
    mock_gemini = _make_adapter(available=True, result=fake_result)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_codex, "gemini": mock_gemini},
        ),
        patch(
            "modelmux.routing.smart_route",
            return_value=("gemini", {}),
        ),
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["provider"] == "gemini"


def test_dispatch_passes_model(capsys):
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(
        model="gpt-5.4", timeout=120, workdir="/tmp", task=["test"]
    )
    fake_result = AdapterResult(
        run_id="r2", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_dispatch(ns)

    call_kwargs = mock_adapter.run.call_args[1]
    assert call_kwargs["extra_args"] == {"model": "gpt-5.4"}
    assert call_kwargs["timeout"] == 120
    assert call_kwargs["workdir"] == "/tmp"


def test_dispatch_error_exits_1(capsys):
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail"])
    fake_result = AdapterResult(
        run_id="r3", provider="codex", status="error", error="broke"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)

    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "error"


def test_dispatch_retry_succeeds_on_second_attempt(capsys):
    """dispatch --max-retries=2 should retry on error."""
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(max_retries=2, task=["retry me"])

    call_count = [0]
    error_result = AdapterResult(
        run_id="r4", provider="codex", status="error", error="transient"
    )
    ok_result = AdapterResult(
        run_id="r4", provider="codex", status="success", output="ok"
    )

    async def side_effect(**kwargs):
        call_count[0] += 1
        return error_result if call_count[0] == 1 else ok_result

    mock_adapter = _make_adapter(available=True)
    mock_adapter.run = AsyncMock(side_effect=side_effect)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("time.sleep"),
    ):
        _cmd_dispatch(ns)

    assert call_count[0] == 2
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"


# ── broadcast tests ──


def test_broadcast_success(capsys):
    """broadcast should return results from all providers."""
    from modelmux.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["review code"])

    codex_result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="LGTM"
    )
    gemini_result = AdapterResult(
        run_id="g1", provider="gemini", status="success", output="Fine"
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True, result=gemini_result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert len(data["results"]) == 2
    assert data["providers"] == ["codex", "gemini"]
    assert data["results"][0]["status"] == "success"
    assert data["results"][1]["status"] == "success"


def test_broadcast_specific_providers(capsys):
    """broadcast --providers codex should only use codex."""
    from modelmux.cli import _cmd_broadcast

    ns = _broadcast_ns(providers=["codex"], task=["test"])
    codex_result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="ok"
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["providers"] == ["codex"]
    assert len(data["results"]) == 1


def test_dispatch_failover_success(capsys):
    """dispatch --failover should try another provider on error."""
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail then recover"], failover=True)
    err_result = AdapterResult(
        run_id="r5", provider="codex", status="error", error="crashed"
    )
    ok_result = AdapterResult(
        run_id="r6", provider="gemini", status="success", output="recovered"
    )
    mock_codex = _make_adapter(available=True, result=err_result)
    mock_gemini = _make_adapter(available=True, result=ok_result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"
    assert result["provider"] == "gemini"
    assert result["failover_from"] == "codex"


def test_dispatch_no_failover_by_default(capsys):
    """dispatch without --failover should not try other providers."""
    from modelmux.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail"])
    err_result = AdapterResult(
        run_id="r7", provider="codex", status="error", error="crashed"
    )
    mock_codex = _make_adapter(available=True, result=err_result)
    mock_gemini = _make_adapter(available=True)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_codex, "gemini": mock_gemini},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)

    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "error"
    assert "failover_from" not in result


def test_broadcast_compare(capsys):
    """broadcast --compare should add comparison analysis."""
    from modelmux.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["compare test"], compare=True)
    codex_result = AdapterResult(
        run_id="c1",
        provider="codex",
        status="success",
        output="The code looks good and well structured",
        duration_seconds=5.0,
    )
    gemini_result = AdapterResult(
        run_id="g1",
        provider="gemini",
        status="success",
        output="The code is well structured and readable",
        duration_seconds=3.0,
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True, result=gemini_result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "comparison" in data
    assert data["comparison"]["comparable"] is True
    assert "agreement_score" in data["comparison"]
    assert "speed_ranking" in data["comparison"]


def test_broadcast_no_compare_by_default(capsys):
    """broadcast without --compare should not include comparison."""
    from modelmux.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["no compare"])
    result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=result)

    with patch(
        "modelmux.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "comparison" not in data


def test_broadcast_all_fail_exits_1(capsys):
    """broadcast should exit 1 if all providers fail."""
    from modelmux.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["fail"])
    err_result = AdapterResult(
        run_id="e1", provider="codex", status="error", error="nope"
    )
    mock_adapter = _make_adapter(available=True, result=err_result)

    with (
        patch(
            "modelmux.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_broadcast(ns)

    assert exc_info.value.code == 1


# ── feedback tests ──


def _feedback_ns(**overrides):
    """Build a namespace for feedback with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "run_id": "",
        "provider": "",
        "rating": 0,
        "comment": "",
        "category": "",
        "list": False,
        "hours": 0,
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


def test_feedback_submit(capsys, tmp_path):
    """feedback --run-id --provider --rating should log feedback."""
    from modelmux.cli import _cmd_feedback

    ns = _feedback_ns(run_id="abc123", provider="codex", rating=4, comment="great")

    with patch("modelmux.feedback._feedback_file", return_value=tmp_path / "fb.jsonl"):
        _cmd_feedback(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "ok"
    assert result["run_id"] == "abc123"
    assert result["rating"] == 4


def test_feedback_missing_args_exits():
    """feedback without required args should exit 1."""
    from modelmux.cli import _cmd_feedback

    ns = _feedback_ns()  # all empty

    with pytest.raises(SystemExit) as exc_info:
        _cmd_feedback(ns)
    assert exc_info.value.code == 1


def test_feedback_invalid_rating_exits(tmp_path):
    """feedback with rating outside 1-5 should exit 1."""
    from modelmux.cli import _cmd_feedback

    ns = _feedback_ns(run_id="x", provider="codex", rating=7)

    with (
        patch("modelmux.feedback._feedback_file", return_value=tmp_path / "fb.jsonl"),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_feedback(ns)
    assert exc_info.value.code == 1


def test_feedback_list_empty(capsys):
    """feedback --list with no data should show message."""
    from modelmux.cli import _cmd_feedback

    ns = _feedback_ns(**{"list": True})

    with patch("modelmux.feedback.read_feedback", return_value=[]):
        _cmd_feedback(ns)

    captured = capsys.readouterr()
    assert "No feedback" in captured.out
