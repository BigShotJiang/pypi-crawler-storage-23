"""CortexCode - Lightweight code indexing for AI assistants."""

__version__ = "0.1.0"
