"""
GraphBus CLI - Command-line interface for GraphBus framework
"""

__version__ = "0.1.0"
