"""
GraphBus CLI utilities
"""
