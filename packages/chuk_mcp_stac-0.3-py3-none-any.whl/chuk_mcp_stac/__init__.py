"""
chuk-mcp-stac: Satellite Imagery Discovery & Retrieval MCP Server

Searches STAC catalogs (Earth Search, Planetary Computer, etc.),
downloads bands as Cloud-Optimised GeoTIFFs, and stores them in
chuk-artifacts for downstream analysis by chuk-mcp-geo.
"""
