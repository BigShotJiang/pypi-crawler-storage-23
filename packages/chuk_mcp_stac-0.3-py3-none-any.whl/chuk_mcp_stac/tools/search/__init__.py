"""
STAC search tools — catalog browsing, scene search, scene detail.
"""

from .api import register_search_tools

__all__ = ["register_search_tools"]
