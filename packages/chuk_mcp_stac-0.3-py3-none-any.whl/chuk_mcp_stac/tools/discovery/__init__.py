"""
Discovery tools — server status and capability listing.
"""

from .api import register_discovery_tools

__all__ = ["register_discovery_tools"]
