"""Line-by-line G-code tokenizer."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class TokenType(Enum):
    COMMAND = "command"
    COMMENT = "comment"


@dataclass
class Token:
    type: TokenType
    line_number: int
    command: str = ""
    params: dict[str, float] = field(default_factory=dict)
    value: str = ""


_PARAM_RE = re.compile(r"([A-Z])(-?\d+\.?\d*)")


def _parse_params(param_str: str) -> dict[str, float]:
    return {m.group(1): float(m.group(2)) for m in _PARAM_RE.finditer(param_str)}


def tokenize(gcode: str) -> list[Token]:
    """Tokenize raw G-code string into a list of Tokens."""
    tokens: list[Token] = []

    for line_num, raw_line in enumerate(gcode.splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue

        if ";" in line:
            code_part, comment_part = line.split(";", 1)
            code_part = code_part.strip()
            comment_part = comment_part.strip()
        else:
            code_part = line
            comment_part = None

        if code_part:
            parts = code_part.split(None, 1)
            cmd = parts[0].upper()
            param_str = parts[1] if len(parts) > 1 else ""
            tokens.append(Token(
                type=TokenType.COMMAND,
                line_number=line_num,
                command=cmd,
                params=_parse_params(param_str),
            ))

        if comment_part is not None:
            tokens.append(Token(
                type=TokenType.COMMENT,
                line_number=line_num,
                value=comment_part,
            ))

    return tokens
