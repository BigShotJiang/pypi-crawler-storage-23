"""G-code parsing subsystem."""
