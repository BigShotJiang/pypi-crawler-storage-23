"""G-code command parser and state tracker."""
from __future__ import annotations

from dataclasses import dataclass, field

from warp_engine.models import (
    Vec3, MoveSegment, MoveType, PrintSettings, AdhesionType,
)
from warp_engine.parser.tokenizer import Token, TokenType


@dataclass
class CommandParser:
    position: Vec3 = field(default_factory=lambda: Vec3(0.0, 0.0, 0.0))
    segments: list[MoveSegment] = field(default_factory=list)
    settings: PrintSettings = field(default_factory=lambda: PrintSettings(
        bed_temp=0.0, nozzle_temp=0.0, material="",
        layer_height=0.0, first_layer_height=0.0,
        adhesion_type=AdhesionType.NONE,
        infill_density=0.0, infill_pattern="",
    ))
    fan_speed: float = 0.0
    feedrate: float = 0.0
    _relative_extrusion: bool = False
    _last_e: float = 0.0

    def process(self, tokens: list[Token]) -> None:
        for token in tokens:
            if token.type == TokenType.COMMENT:
                self._process_comment(token)
            elif token.type == TokenType.COMMAND:
                self._process_command(token)

    def _process_comment(self, token: Token) -> None:
        val = token.value.lower()
        if "layer_height" in val or "layer height" in val:
            parts = val.split("=") if "=" in val else val.split(":")
            if len(parts) == 2:
                try:
                    self.settings.layer_height = float(parts[1].strip().split()[0])
                except (ValueError, IndexError):
                    pass

    def _process_command(self, token: Token) -> None:
        cmd = token.command
        params = token.params

        if cmd in ("G0", "G1"):
            self._handle_move(params)
        elif cmd == "G28":
            self.position = Vec3(0.0, 0.0, 0.0)
            self._last_e = 0.0
        elif cmd == "M82":
            self._relative_extrusion = False
        elif cmd == "M83":
            self._relative_extrusion = True
        elif cmd in ("M104", "M109"):
            if "S" in params:
                self.settings.nozzle_temp = params["S"]
        elif cmd in ("M140", "M190"):
            if "S" in params:
                self.settings.bed_temp = params["S"]
        elif cmd == "M106":
            self.fan_speed = params.get("S", 255.0)
        elif cmd == "M107":
            self.fan_speed = 0.0
        elif cmd == "G92":
            if "E" in params:
                self._last_e = params["E"]

    def _handle_move(self, params: dict[str, float]) -> None:
        new_x = params.get("X", self.position.x)
        new_y = params.get("Y", self.position.y)
        new_z = params.get("Z", self.position.z)

        if "F" in params:
            self.feedrate = params["F"]

        new_pos = Vec3(new_x, new_y, new_z)

        raw_e = params.get("E")
        if raw_e is not None:
            if self._relative_extrusion:
                extrusion = raw_e
            else:
                extrusion = raw_e - self._last_e
                self._last_e = raw_e
        else:
            extrusion = 0.0

        move_type = MoveType.TRAVEL if extrusion <= 0 else MoveType.PERIMETER

        seg = MoveSegment(
            start=self.position,
            end=new_pos,
            extrusion=max(0.0, extrusion),
            speed=self.feedrate,
            move_type=move_type,
        )
        self.segments.append(seg)
        self.position = new_pos
