"""Assemble parsed G-code data into a PrintIR structure."""
from __future__ import annotations

from warp_engine.models import (
    PrintIR, Layer, BedShape, MoveSegment,
)
from warp_engine.parser.tokenizer import tokenize
from warp_engine.parser.flavor_detector import detect_flavor
from warp_engine.parser.command_parser import CommandParser


def build_ir(gcode: str) -> PrintIR:
    """Parse raw G-code string into a PrintIR intermediate representation."""
    if not gcode.strip():
        from warp_engine.models import PrintSettings, AdhesionType, GcodeFlavor
        return PrintIR(
            layers=[],
            settings=PrintSettings(
                bed_temp=0, nozzle_temp=0, material="",
                layer_height=0, first_layer_height=0,
                adhesion_type=AdhesionType.NONE,
                infill_density=0, infill_pattern="",
            ),
            bed_shape=BedShape.RECTANGULAR,
            flavor=GcodeFlavor.UNKNOWN,
        )

    flavor = detect_flavor(gcode)
    tokens = tokenize(gcode)
    parser = CommandParser()
    parser.process(tokens)

    layers = _split_into_layers(parser.segments)

    if layers and parser.settings.first_layer_height == 0.0:
        parser.settings.first_layer_height = layers[0].z_height

    if parser.settings.layer_height == 0.0 and len(layers) >= 2:
        parser.settings.layer_height = round(
            layers[1].z_height - layers[0].z_height, 4
        )

    return PrintIR(
        layers=layers,
        settings=parser.settings,
        bed_shape=BedShape.RECTANGULAR,
        flavor=flavor,
    )


def _split_into_layers(segments: list[MoveSegment]) -> list[Layer]:
    """Group segments into layers by Z height changes."""
    if not segments:
        return []

    layers: list[Layer] = []
    current_z = segments[0].start.z
    current_segments: list[MoveSegment] = []

    for seg in segments:
        seg_z = seg.end.z
        if seg_z != current_z and current_segments:
            layers.append(_make_layer(current_z, current_segments))
            current_segments = []
            current_z = seg_z
        current_segments.append(seg)

    if current_segments:
        layers.append(_make_layer(current_z, current_segments))

    return layers


def _make_layer(z_height: float, segments: list[MoveSegment]) -> Layer:
    """Create a Layer with estimated print time."""
    layer_time = 0.0
    for seg in segments:
        if seg.speed > 0:
            dist = seg.length
            layer_time += (dist / seg.speed) * 60.0  # F is mm/min

    return Layer(
        z_height=z_height,
        segments=segments,
        layer_time=layer_time,
        fan_speed=0.0,
    )
