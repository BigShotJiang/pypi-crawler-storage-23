"""Auto-detect G-code flavor from file header comments."""
from __future__ import annotations

import re

from warp_engine.models import GcodeFlavor

_FLAVOR_MAP: dict[str, GcodeFlavor] = {
    "marlin": GcodeFlavor.MARLIN,
    "klipper": GcodeFlavor.KLIPPER,
    "reprap": GcodeFlavor.REPRAP,
    "smoothie": GcodeFlavor.SMOOTHIEWARE,
    "smoothieware": GcodeFlavor.SMOOTHIEWARE,
    "sailfish": GcodeFlavor.SAILFISH,
}

_FLAVOR_RE = re.compile(
    r";\s*(?:flavor|g-code flavor)\s*:\s*(\w+)", re.IGNORECASE
)


def detect_flavor(gcode_header: str) -> GcodeFlavor:
    """Detect G-code flavor from the first ~50 lines of a file."""
    for line in gcode_header.splitlines()[:50]:
        match = _FLAVOR_RE.search(line)
        if match:
            key = match.group(1).lower()
            if key in _FLAVOR_MAP:
                return _FLAVOR_MAP[key]

    return GcodeFlavor.UNKNOWN
