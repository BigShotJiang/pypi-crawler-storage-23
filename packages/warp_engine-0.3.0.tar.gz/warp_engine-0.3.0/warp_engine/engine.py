"""Main entry point for warp analysis."""
from __future__ import annotations

from warp_engine.models import (
    WarpReport, ThermalEnvironment, AnalysisTier, RiskLevel,
    ThermalField, AnalysisMetadata,
)
from warp_engine.parser.ir_builder import build_ir
from warp_engine.analysis.geometry import analyze_geometry
from warp_engine.analysis.thermal import analyze_thermal
from warp_engine.analysis.adhesion import analyze_adhesion
from warp_engine.analysis.settings_analyzer import analyze_settings
from warp_engine.analysis.combiner import combine_risks
from warp_engine.printers.profiles import get_printer
from warp_engine import __version__


class Engine:
    """Orchestrates the full warp-risk analysis pipeline.

    Usage::

        engine = Engine()
        report = engine.analyze(gcode=my_gcode, material="PLA")
    """

    def analyze(
        self,
        gcode: str,
        material: str = "PLA",
        tier: AnalysisTier = AnalysisTier.QUICK,
        printer_profile: str | None = None,
        chamber_temp: float | None = None,
        ambient_temp: float = 25.0,
        stl_bytes: bytes | None = None,
    ) -> WarpReport:
        """Run the warp analysis pipeline on the supplied G-code.

        Args:
            gcode: Raw G-code string.
            material: Filament material name (e.g. "PLA", "ABS").
            tier: Analysis fidelity tier.
            printer_profile: Optional printer profile ID for airflow modelling.
            chamber_temp: Override chamber temperature (degrees C).
            ambient_temp: Ambient room temperature (degrees C).
            stl_bytes: Reserved for future STL-based geometry analysis.

        Returns:
            A fully populated :class:`WarpReport`.
        """
        ir = build_ir(gcode)

        if not ir.layers:
            return WarpReport(
                overall_score=0.0,
                risk_level=RiskLevel.LOW,
                regions=[],
                recommendations=[],
                thermal_field=ThermalField(layer_temps=[], hotspots=[], stress_map={}),
                metadata=AnalysisMetadata(tier=tier, time_ms=0, version=__version__),
            )

        # Use material extracted from G-code comments if available,
        # otherwise fall back to the caller-supplied value.
        if ir.settings.material:
            material = ir.settings.material or material
        ir.settings.material = material

        printer = get_printer(printer_profile) if printer_profile else None
        env = ThermalEnvironment(
            bed_temp=ir.settings.bed_temp,
            chamber_temp=chamber_temp or (printer.default_chamber_temp if printer else ambient_temp),
            ambient_temp=ambient_temp,
            airflow_sources=list(printer.airflow_sources) if printer else [],
        )

        geometry_risk = analyze_geometry(ir)
        thermal_field = analyze_thermal(ir, env, tier)
        adhesion_risk = analyze_adhesion(ir)
        settings_risk = analyze_settings(ir.settings)

        return combine_risks(
            geometry=geometry_risk,
            adhesion=adhesion_risk,
            settings=settings_risk,
            thermal=thermal_field,
            material_name=material,
            tier=tier,
        )
