"""Weighted risk combiner and recommendation engine."""
from __future__ import annotations

import time

from warp_engine import __version__
from warp_engine.models import (
    GeometryRisk, AdhesionRisk, SettingsRisk, ThermalField,
    RiskLevel, RiskRegion, Recommendation, AnalysisMetadata,
    WarpReport, AnalysisTier,
)
from warp_engine.materials.profiles import get_material


def combine_risks(
    geometry: GeometryRisk,
    adhesion: AdhesionRisk,
    settings: SettingsRisk,
    thermal: ThermalField,
    material_name: str,
    tier: AnalysisTier,
) -> WarpReport:
    """Combine individual risk analyses into a unified warp report.

    Weights are sourced from the material profile.  Each sub-score is
    normalised to [0, 1] where 0 = no risk and 1 = extreme risk.  The
    weighted average is then mapped to a :class:`RiskLevel`.

    Args:
        geometry: Output of the geometry risk analyzer.
        adhesion: Output of the adhesion risk analyzer.
        settings: Output of the settings risk analyzer.
        thermal: Output of the thermal model.
        material_name: Material name used to look up weighting factors.
        tier: Analysis tier that was used.

    Returns:
        A fully-populated :class:`WarpReport`.
    """
    start = time.monotonic()

    material = get_material(material_name)
    tw = material.thermal_weight if material else 0.3
    aw = material.adhesion_weight if material else 0.3
    cw = material.cooling_weight if material else 0.2
    gw = material.geometry_weight if material else 0.3

    # Normalise weights so they sum to 1.0
    total_w = tw + aw + cw + gw
    tw, aw, cw, gw = tw / total_w, aw / total_w, cw / total_w, gw / total_w

    # Compute individual sub-scores (each in [0, 1])
    thermal_score = _avg_stress(thermal)
    geometry_score = _geometry_score(geometry)
    adhesion_score = 1.0 - adhesion.adhesion_type_score
    settings_score = _settings_score(settings)

    overall = (
        tw * thermal_score
        + gw * geometry_score
        + aw * adhesion_score
        + cw * settings_score
    )
    overall = min(1.0, max(0.0, overall))

    risk_level = _score_to_level(overall)
    regions = _build_regions(geometry, thermal)
    recommendations = _build_recommendations(
        geometry, adhesion, settings, thermal, material_name,
    )

    elapsed_ms = int((time.monotonic() - start) * 1000)

    return WarpReport(
        overall_score=round(overall, 3),
        risk_level=risk_level,
        regions=regions,
        recommendations=recommendations,
        thermal_field=thermal,
        metadata=AnalysisMetadata(
            tier=tier, time_ms=elapsed_ms, version=__version__,
        ),
    )


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _avg_stress(thermal: ThermalField) -> float:
    """Return the mean thermal stress across all layers, or 0 if empty."""
    if not thermal.stress_map:
        return 0.0
    values = thermal.stress_map.values()
    return sum(values) / len(values)


def _geometry_score(geometry: GeometryRisk) -> float:
    """Derive a 0-1 risk score from geometry flags.

    Each category of geometry risk contributes proportionally.  The score
    is capped at 1.0.
    """
    count = (
        len(geometry.large_flat_regions)
        + len(geometry.thin_walls)
        + len(geometry.sharp_corners)
        + len(geometry.overhangs)
        + len(geometry.aspect_ratio_flags)
        + len(geometry.cross_section_changes)
    )
    # Each flagged region adds 0.15; saturates at 1.0
    return min(1.0, count * 0.15)


def _settings_score(settings: SettingsRisk) -> float:
    """Derive a 0-1 risk score from print settings flags."""
    score = 0.0
    if settings.cooling_too_aggressive:
        score += 0.25
    if settings.bed_temp_mismatch:
        score += 0.25
    score += settings.speed_risk * 0.2
    score += settings.layer_height_risk * 0.15
    score += settings.infill_risk * 0.15
    return min(1.0, score)


def _score_to_level(score: float) -> RiskLevel:
    """Map a numeric 0-1 score to a discrete :class:`RiskLevel`."""
    if score < 0.25:
        return RiskLevel.LOW
    if score < 0.5:
        return RiskLevel.MODERATE
    if score < 0.75:
        return RiskLevel.HIGH
    return RiskLevel.CRITICAL


def _build_regions(
    geometry: GeometryRisk,
    thermal: ThermalField,
) -> list[RiskRegion]:
    """Translate geometry and thermal regions into unified risk regions."""
    regions: list[RiskRegion] = []

    for region in geometry.large_flat_regions:
        regions.append(RiskRegion(
            bounding_box=region.bounding_box,
            affected_layers=region.affected_layers,
            score=0.7,
            primary_cause="large_flat_surface",
            contributing_factors=["differential_cooling", "bed_adhesion_stress"],
        ))

    for region in geometry.thin_walls:
        regions.append(RiskRegion(
            bounding_box=region.bounding_box,
            affected_layers=region.affected_layers,
            score=0.5,
            primary_cause="thin_wall",
            contributing_factors=["insufficient_structure"],
        ))

    for region in geometry.sharp_corners:
        regions.append(RiskRegion(
            bounding_box=region.bounding_box,
            affected_layers=region.affected_layers,
            score=0.6,
            primary_cause="sharp_corner",
            contributing_factors=["stress_concentration"],
        ))

    for region in geometry.overhangs:
        regions.append(RiskRegion(
            bounding_box=region.bounding_box,
            affected_layers=region.affected_layers,
            score=0.55,
            primary_cause="overhang",
            contributing_factors=["unsupported_material", "cooling_imbalance"],
        ))

    for hotspot in thermal.hotspots:
        regions.append(RiskRegion(
            bounding_box=hotspot.bounding_box,
            affected_layers=hotspot.affected_layers,
            score=0.65,
            primary_cause="thermal_hotspot",
            contributing_factors=["uneven_cooling"],
        ))

    return regions


def _build_recommendations(
    geometry: GeometryRisk,
    adhesion: AdhesionRisk,
    settings: SettingsRisk,
    thermal: ThermalField,
    material_name: str,
) -> list[Recommendation]:
    """Generate actionable recommendations based on identified risk factors."""
    recs: list[Recommendation] = []
    priority = 1

    # --- Adhesion recommendations ---
    if adhesion.adhesion_type_score < 0.3:
        recs.append(Recommendation(
            priority=priority,
            category="adhesion",
            message=(
                "Adhesion method provides little warp resistance. "
                "Consider using a brim or raft for better bed adhesion."
            ),
            expected_improvement=0.25,
            setting_change={"adhesion_type": "brim"},
        ))
        priority += 1

    if adhesion.bed_contact_area > 0 and adhesion.bed_contact_area < 50:
        recs.append(Recommendation(
            priority=priority,
            category="adhesion",
            message=(
                "Small bed contact area increases warp risk. "
                "Adding a brim can significantly improve first-layer grip."
            ),
            expected_improvement=0.2,
            setting_change={"brim_width": 8},
        ))
        priority += 1

    # --- Temperature recommendations ---
    if settings.bed_temp_mismatch:
        material = get_material(material_name)
        temp_hint = ""
        if material:
            lo, hi = material.bed_temp_range
            temp_hint = f" Recommended range for {material_name}: {lo}-{hi} C."
        recs.append(Recommendation(
            priority=priority,
            category="temperature",
            message=(
                "Bed temperature does not match the recommended range "
                f"for {material_name}.{temp_hint}"
            ),
            expected_improvement=0.2,
            setting_change={"bed_temp": "use_material_default"},
        ))
        priority += 1

    if settings.cooling_too_aggressive:
        recs.append(Recommendation(
            priority=priority,
            category="temperature",
            message=(
                "Part cooling fan speed may be too high for the first "
                "layers, increasing thermal contraction. Consider "
                "reducing fan speed for the first 3-5 layers."
            ),
            expected_improvement=0.15,
            setting_change={"fan_speed_first_layers": 0},
        ))
        priority += 1

    # --- Structure / infill recommendations ---
    if settings.infill_risk > 0.5:
        recs.append(Recommendation(
            priority=priority,
            category="structure",
            message=(
                "Low infill density may not provide enough internal "
                "structure to resist warping forces. Consider increasing "
                "infill to at least 20%."
            ),
            expected_improvement=0.15,
            setting_change={"infill_density": 0.2},
        ))
        priority += 1

    # --- Geometry recommendations ---
    if geometry.large_flat_regions:
        recs.append(Recommendation(
            priority=priority,
            category="geometry",
            message=(
                f"Detected {len(geometry.large_flat_regions)} large flat "
                "region(s) prone to differential shrinkage. Consider "
                "rotating the model or adding mouse-ears at corners."
            ),
            expected_improvement=0.2,
        ))
        priority += 1

    if geometry.sharp_corners:
        recs.append(Recommendation(
            priority=priority,
            category="geometry",
            message=(
                f"Detected {len(geometry.sharp_corners)} sharp corner(s) "
                "that concentrate stress. Filleting corners in the model "
                "can reduce lifting."
            ),
            expected_improvement=0.1,
        ))
        priority += 1

    if geometry.overhangs:
        recs.append(Recommendation(
            priority=priority,
            category="geometry",
            message=(
                f"Detected {len(geometry.overhangs)} overhang region(s). "
                "Adding support or reorienting the part may help."
            ),
            expected_improvement=0.1,
        ))
        priority += 1

    # --- Thermal stress recommendations ---
    avg_stress = _avg_stress(thermal)
    if avg_stress > 0.5:
        recs.append(Recommendation(
            priority=priority,
            category="temperature",
            message=(
                "High average thermal stress detected across layers. "
                "Printing in an enclosure or raising the ambient "
                "temperature can reduce thermal gradients."
            ),
            expected_improvement=0.2,
        ))
        priority += 1

    return recs
