"""Adhesion risk analyzer.

Evaluates bed adhesion risk by examining first-layer contact area,
adhesion type, perimeter length, and estimated lift forces.
"""
from __future__ import annotations

from warp_engine.models import AdhesionRisk, AdhesionType, MoveType, PrintIR

# Assumed nozzle width for contact area estimation (mm).
_NOZZLE_WIDTH = 0.4

# Adhesion type scores: higher means better adhesion assistance.
_ADHESION_SCORES: dict[AdhesionType, float] = {
    AdhesionType.NONE: 0.0,
    AdhesionType.SKIRT: 0.2,
    AdhesionType.BRIM: 0.6,
    AdhesionType.RAFT: 0.9,
}


def analyze_adhesion(ir: PrintIR) -> AdhesionRisk:
    """Analyze adhesion risk for a print.

    Examines the first layer to estimate bed contact area, perimeter length,
    and coverage.  Scores the chosen adhesion type and estimates a rough
    lift-force metric.

    Parameters
    ----------
    ir:
        The intermediate representation of the parsed G-code.

    Returns
    -------
    AdhesionRisk
        Populated adhesion risk dataclass.
    """
    if not ir.layers:
        return AdhesionRisk(
            bed_contact_area=0.0,
            contact_ratio=0.0,
            first_layer_coverage=0.0,
            adhesion_type_score=_ADHESION_SCORES.get(
                ir.settings.adhesion_type, 0.0
            ),
            perimeter_length=0.0,
            lift_force_estimate=0.0,
        )

    first_layer = ir.layers[0]

    # Sum path lengths for extrusion moves (non-travel) on the first layer.
    total_path_length = 0.0
    perimeter_length = 0.0

    for seg in first_layer.segments:
        if seg.move_type == MoveType.TRAVEL:
            continue
        seg_len = seg.length
        total_path_length += seg_len
        if seg.move_type == MoveType.PERIMETER:
            perimeter_length += seg_len

    # Contact area: path length * nozzle width (mm^2).
    bed_contact_area = total_path_length * _NOZZLE_WIDTH

    # Bounding-box area of the first layer for coverage ratio.
    xs = []
    ys = []
    for seg in first_layer.segments:
        if seg.move_type == MoveType.TRAVEL:
            continue
        xs.extend([seg.start.x, seg.end.x])
        ys.extend([seg.start.y, seg.end.y])

    if xs and ys:
        bbox_area = (max(xs) - min(xs)) * (max(ys) - min(ys))
    else:
        bbox_area = 0.0

    # Contact ratio: fraction of bounding box covered by extrusion paths.
    contact_ratio = bed_contact_area / bbox_area if bbox_area > 0 else 0.0

    # First layer coverage is the same as contact ratio (0-1 range, clamped).
    first_layer_coverage = min(contact_ratio, 1.0)

    # Adhesion type score.
    adhesion_type_score = _ADHESION_SCORES.get(
        ir.settings.adhesion_type, 0.0
    )

    # Lift-force estimate: a heuristic proportional to perimeter length
    # divided by contact area.  Longer perimeters relative to contact area
    # mean higher edge-peel risk.
    if bed_contact_area > 0:
        lift_force_estimate = perimeter_length / bed_contact_area
    else:
        lift_force_estimate = 0.0

    return AdhesionRisk(
        bed_contact_area=bed_contact_area,
        contact_ratio=contact_ratio,
        first_layer_coverage=first_layer_coverage,
        adhesion_type_score=adhesion_type_score,
        perimeter_length=perimeter_length,
        lift_force_estimate=lift_force_estimate,
    )
