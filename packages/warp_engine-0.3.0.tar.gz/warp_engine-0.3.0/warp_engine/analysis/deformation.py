"""STL warp deformation solver.

Maps thermal stress field onto mesh vertices and computes predicted
warp displacement using thermal contraction modeling.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np
import trimesh

from warp_engine.models import ThermalField, Vec3
from warp_engine.materials.profiles import get_material


@dataclass
class DeformationRegion:
    """A contiguous region of significant deformation.

    Attributes:
        vertex_indices: Indices of vertices in this region.
        avg_deviation_mm: Average displacement magnitude in mm.
        max_deviation_mm: Maximum displacement magnitude in mm.
        direction: Dominant displacement direction.
        cause: Human-readable description of the deformation cause.
    """
    vertex_indices: np.ndarray
    avg_deviation_mm: float
    max_deviation_mm: float
    direction: Vec3
    cause: str


@dataclass
class DeformationResult:
    """Result of the warp deformation analysis.

    Attributes:
        original_mesh: The unmodified input mesh.
        deformed_mesh: The mesh with warp displacements applied.
        displacement_field: (N, 3) per-vertex displacement vectors in mm.
        max_deviation_mm: Maximum scalar deviation across all vertices.
        deviation_map: (N,) per-vertex scalar deviation magnitude in mm.
        problem_regions: List of identified problem regions.
    """
    original_mesh: trimesh.Trimesh
    deformed_mesh: trimesh.Trimesh
    displacement_field: np.ndarray   # (N, 3) per-vertex displacement
    max_deviation_mm: float
    deviation_map: np.ndarray        # (N,) per-vertex scalar deviation
    problem_regions: list[DeformationRegion] = field(default_factory=list)


def _assign_layers(
    vertices: np.ndarray,
    layer_z_heights: list[float],
) -> np.ndarray:
    """Assign each vertex to the nearest layer by z-height.

    Args:
        vertices: (N, 3) array of vertex positions.
        layer_z_heights: Sorted list of layer z-heights.

    Returns:
        (N,) integer array of layer indices.
    """
    z_vals = vertices[:, 2]
    z_arr = np.array(layer_z_heights)
    # For each vertex z, find the closest layer z-height
    # Use broadcasting: |z_vals[:, None] - z_arr[None, :]| -> (N, n_layers)
    diffs = np.abs(z_vals[:, None] - z_arr[None, :])
    return np.argmin(diffs, axis=1)


def _identify_edge_vertices(
    vertices: np.ndarray,
    min_z: float,
    tolerance: float = 0.1,
    edge_fraction: float = 0.15,
) -> np.ndarray:
    """Identify vertices near the bottom edges/corners of the mesh.

    These vertices are at the bottom layer but near the XY perimeter,
    which is where classic corner-lift warping occurs.

    Args:
        vertices: (N, 3) array of vertex positions.
        min_z: The minimum z value (bed surface).
        tolerance: Z tolerance for considering a vertex on the bed.
        edge_fraction: Fraction of XY extent to consider as edge zone.

    Returns:
        Boolean mask of shape (N,) indicating bottom-edge vertices.
    """
    bottom_mask = np.abs(vertices[:, 2] - min_z) < tolerance

    # Compute XY bounding box
    xy_min = vertices[:, :2].min(axis=0)
    xy_max = vertices[:, :2].max(axis=0)
    xy_extent = xy_max - xy_min

    # Edge zone: vertices within edge_fraction of any XY boundary
    margin = xy_extent * edge_fraction
    near_min = vertices[:, :2] < (xy_min + margin)
    near_max = vertices[:, :2] > (xy_max - margin)
    on_edge_xy = np.any(near_min | near_max, axis=1)

    return bottom_mask & on_edge_xy


def compute_deformation(
    mesh: trimesh.Trimesh,
    thermal_field: ThermalField,
    material_name: str,
    nozzle_temp: float,
    bed_temp: float,
) -> DeformationResult:
    """Compute predicted warp deformation for an STL mesh.

    Maps thermal stress from the thermal field onto mesh vertices and
    computes displacement vectors based on thermal contraction modeling.

    The solver logic:
    1. Look up material CTE, shrinkage, and Young's modulus.
    2. For each vertex, assign it to the nearest layer by z-height.
    3. Look up the thermal stress factor for that layer.
    4. Compute thermal strain: CTE * delta_T * stress_factor.
    5. Displacement direction: contraction toward center of mass
       with upward curl at edges (classic warp pattern).
    6. Bottom vertices on the bed are constrained to zero displacement
       (adhesion holds them flat).
    7. Bottom-edge vertices get slight upward displacement (corner lift).
    8. Build deformed mesh by applying displacement field.

    Args:
        mesh: Input STL mesh (trimesh.Trimesh).
        thermal_field: Thermal field with per-layer stress data.
        material_name: Material name (e.g. "PLA", "ABS").
        nozzle_temp: Nozzle temperature in degrees C.
        bed_temp: Bed temperature in degrees C.

    Returns:
        DeformationResult with displacement field and deformed mesh.

    Raises:
        ValueError: If the material is not found in the database.
    """
    material = get_material(material_name)
    if material is None:
        raise ValueError(f"Unknown material: {material_name!r}")

    vertices = np.array(mesh.vertices, dtype=np.float64)
    n_verts = len(vertices)

    # --- Layer assignment ---
    layer_z_heights = [lt.z_height for lt in thermal_field.layer_temps]
    layer_indices = _assign_layers(vertices, layer_z_heights)

    # Build lookup: layer_index -> LayerThermalState
    layer_states = {lt.layer_index: lt for lt in thermal_field.layer_temps}

    # --- Compute per-vertex strain ---
    displacement = np.zeros((n_verts, 3), dtype=np.float64)

    # Mesh center of mass in XY (contraction reference point)
    centroid_xy = vertices[:, :2].mean(axis=0)

    # Z range
    min_z = vertices[:, 2].min()
    max_z = vertices[:, 2].max()
    z_range = max_z - min_z
    if z_range < 1e-9:
        z_range = 1.0  # avoid division by zero for flat meshes

    # Material properties
    cte = material.cte                    # 1/K
    shrinkage = material.shrinkage_rate   # percent
    youngs = material.youngs_modulus      # MPa
    warp_susceptibility = material.warp_susceptibility

    # Identify constrained bottom vertices and edge vertices
    bottom_tolerance = 0.1
    bottom_mask = np.abs(vertices[:, 2] - min_z) < bottom_tolerance
    edge_mask = _identify_edge_vertices(vertices, min_z, tolerance=bottom_tolerance)

    for i in range(n_verts):
        layer_idx = layer_indices[i]

        # Get thermal state for this layer
        state = layer_states.get(layer_idx)
        if state is None:
            continue

        # Get stress factor for this layer
        stress_factor = thermal_field.stress_map.get(layer_idx, 0.0)

        # Temperature delta: how much the material cools from nozzle
        # to the estimated temperature at this layer
        delta_t = nozzle_temp - state.estimated_temp

        # Thermal strain = CTE * delta_T * stress_factor
        strain = cte * delta_t * stress_factor

        # Add shrinkage contribution (convert percent to fraction)
        strain += (shrinkage / 100.0) * stress_factor

        # Height factor: higher vertices deform more (lever arm effect)
        height_fraction = (vertices[i, 2] - min_z) / z_range

        # --- Displacement direction ---
        # Lateral: contraction toward centroid (shrinkage pulls inward)
        xy_offset = vertices[i, :2] - centroid_xy
        xy_dist = np.linalg.norm(xy_offset)

        if xy_dist > 1e-9:
            # Inward contraction proportional to distance from center
            lateral_mag = strain * xy_dist * warp_susceptibility
            displacement[i, 0] = -xy_offset[0] / xy_dist * lateral_mag
            displacement[i, 1] = -xy_offset[1] / xy_dist * lateral_mag

        # Vertical: upward curl increases with height and distance from center
        # This models the bimetallic-strip-like curl of warping
        vertical_mag = strain * height_fraction * warp_susceptibility * xy_dist * 0.1
        displacement[i, 2] = vertical_mag

    # --- Constrain bottom vertices ---
    # Bed adhesion holds bottom vertices flat (zero displacement)
    displacement[bottom_mask] = 0.0

    # --- Corner lift for bottom-edge vertices ---
    # Classic warp pattern: corners lift slightly off the bed
    edge_indices = np.where(edge_mask)[0]
    for idx in edge_indices:
        layer_idx = layer_indices[idx]
        stress_factor = thermal_field.stress_map.get(layer_idx, 0.0)
        delta_t = nozzle_temp - bed_temp  # full delta from nozzle to bed
        lift_strain = cte * delta_t * stress_factor
        lift_mag = lift_strain * warp_susceptibility * (shrinkage / 100.0) * 10.0
        # Only upward lift, no lateral at the bed
        displacement[idx] = [0.0, 0.0, lift_mag]

    # --- Build results ---
    deviation_map = np.linalg.norm(displacement, axis=1)
    max_deviation = float(deviation_map.max()) if n_verts > 0 else 0.0

    # Create deformed mesh (copy topology, offset vertices)
    deformed_vertices = vertices + displacement
    deformed_mesh = trimesh.Trimesh(
        vertices=deformed_vertices,
        faces=np.array(mesh.faces),
        process=False,
    )

    # --- Identify problem regions ---
    problem_regions = _find_problem_regions(
        vertices, displacement, deviation_map, threshold_mm=0.05,
    )

    return DeformationResult(
        original_mesh=mesh,
        deformed_mesh=deformed_mesh,
        displacement_field=displacement,
        max_deviation_mm=max_deviation,
        deviation_map=deviation_map,
        problem_regions=problem_regions,
    )


def _find_problem_regions(
    vertices: np.ndarray,
    displacement: np.ndarray,
    deviation_map: np.ndarray,
    threshold_mm: float = 0.05,
) -> list[DeformationRegion]:
    """Identify contiguous regions with significant deformation.

    Args:
        vertices: (N, 3) original vertex positions.
        displacement: (N, 3) displacement vectors.
        deviation_map: (N,) scalar deviations.
        threshold_mm: Minimum deviation to flag as a problem.

    Returns:
        List of DeformationRegion objects.
    """
    problem_mask = deviation_map > threshold_mm
    if not np.any(problem_mask):
        return []

    problem_indices = np.where(problem_mask)[0]

    # For simplicity, treat all high-deviation vertices as one region
    # A more sophisticated approach would use spatial clustering
    avg_dev = float(deviation_map[problem_indices].mean())
    max_dev = float(deviation_map[problem_indices].max())

    # Dominant direction: average normalized displacement
    mean_disp = displacement[problem_indices].mean(axis=0)
    norm = np.linalg.norm(mean_disp)
    if norm > 1e-9:
        direction = mean_disp / norm
    else:
        direction = np.array([0.0, 0.0, 1.0])

    region = DeformationRegion(
        vertex_indices=problem_indices,
        avg_deviation_mm=avg_dev,
        max_deviation_mm=max_dev,
        direction=Vec3(float(direction[0]), float(direction[1]), float(direction[2])),
        cause="Thermal contraction and shrinkage-induced warp",
    )
    return [region]
