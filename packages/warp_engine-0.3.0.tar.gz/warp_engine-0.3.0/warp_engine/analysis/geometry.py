"""Geometry risk analyzer.

Detects structural warp risks from the geometry encoded in a PrintIR,
including large flat surfaces and extreme aspect ratios.
"""
from __future__ import annotations

import math

from warp_engine.models import (
    BBox3D,
    GeometryRisk,
    PrintIR,
    Region,
    Vec3,
)

# A flat region whose largest XY extent exceeds this threshold (in mm)
# is considered a warp risk.
LARGE_FLAT_THRESHOLD_MM: float = 50.0

# If height / min(xy extent) exceeds this ratio the part is considered
# dangerously tall and narrow.
ASPECT_RATIO_THRESHOLD: float = 8.0


def _layer_bbox(layer) -> BBox3D | None:  # noqa: ANN001
    """Compute an axis-aligned bounding box for a single layer's segments."""
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []

    for seg in layer.segments:
        xs.extend((seg.start.x, seg.end.x))
        ys.extend((seg.start.y, seg.end.y))
        zs.extend((seg.start.z, seg.end.z))

    if not xs:
        return None

    return BBox3D(
        min=Vec3(min(xs), min(ys), min(zs)),
        max=Vec3(max(xs), max(ys), max(zs)),
    )


def _overall_bbox(ir: PrintIR) -> BBox3D | None:
    """Compute the axis-aligned bounding box spanning the entire print."""
    all_min_x: float = math.inf
    all_min_y: float = math.inf
    all_min_z: float = math.inf
    all_max_x: float = -math.inf
    all_max_y: float = -math.inf
    all_max_z: float = -math.inf

    found = False
    for layer in ir.layers:
        bbox = _layer_bbox(layer)
        if bbox is None:
            continue
        found = True
        all_min_x = min(all_min_x, bbox.min.x)
        all_min_y = min(all_min_y, bbox.min.y)
        all_min_z = min(all_min_z, bbox.min.z)
        all_max_x = max(all_max_x, bbox.max.x)
        all_max_y = max(all_max_y, bbox.max.y)
        all_max_z = max(all_max_z, bbox.max.z)

    if not found:
        return None

    return BBox3D(
        min=Vec3(all_min_x, all_min_y, all_min_z),
        max=Vec3(all_max_x, all_max_y, all_max_z),
    )


def _detect_large_flat_regions(ir: PrintIR) -> list[Region]:
    """Flag layers whose XY footprint exceeds the flat-surface threshold."""
    regions: list[Region] = []

    for idx, layer in enumerate(ir.layers):
        bbox = _layer_bbox(layer)
        if bbox is None:
            continue

        x_extent = bbox.max.x - bbox.min.x
        y_extent = bbox.max.y - bbox.min.y

        if max(x_extent, y_extent) > LARGE_FLAT_THRESHOLD_MM:
            regions.append(
                Region(
                    bounding_box=bbox,
                    affected_layers=(idx, idx),
                    description=(
                        f"Large flat surface at z={layer.z_height:.2f}mm "
                        f"({x_extent:.1f} x {y_extent:.1f} mm)"
                    ),
                )
            )

    return regions


def _detect_aspect_ratio_flags(ir: PrintIR) -> list[Region]:
    """Flag the overall print when height-to-base ratio is extreme."""
    bbox = _overall_bbox(ir)
    if bbox is None:
        return []

    x_extent = bbox.max.x - bbox.min.x
    y_extent = bbox.max.y - bbox.min.y
    z_extent = bbox.max.z - bbox.min.z

    min_xy = min(x_extent, y_extent) if min(x_extent, y_extent) > 0 else 0

    if min_xy == 0 or z_extent == 0:
        return []

    ratio = z_extent / min_xy

    if ratio > ASPECT_RATIO_THRESHOLD:
        return [
            Region(
                bounding_box=bbox,
                affected_layers=(0, len(ir.layers) - 1),
                description=(
                    f"Extreme aspect ratio {ratio:.1f}:1 "
                    f"(height {z_extent:.1f}mm vs base {min_xy:.1f}mm)"
                ),
            )
        ]

    return []


def analyze_geometry(ir: PrintIR) -> GeometryRisk:
    """Analyse *ir* for geometry-related warp risks.

    Currently detects:
    * Large flat regions (XY extent > 50 mm)
    * Extreme height-to-base aspect ratios (> 8:1)

    Returns a :class:`GeometryRisk` dataclass with findings.
    """
    return GeometryRisk(
        large_flat_regions=_detect_large_flat_regions(ir),
        aspect_ratio_flags=_detect_aspect_ratio_flags(ir),
    )
