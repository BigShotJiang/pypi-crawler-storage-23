"""Thermal analysis module for warp prediction.

Provides a quick-tier heuristic thermal model using simplified Newton
cooling, a standard-tier 1D heat equation solver, and a performance-tier
FEA-lite 1D finite difference thermal solver with sub-layer resolution.
"""

from __future__ import annotations

import math

from warp_engine.materials.profiles import get_material
from warp_engine.models import (
    AnalysisTier,
    LayerThermalState,
    PrintIR,
    ThermalEnvironment,
    ThermalField,
    Vec3,
)


def analyze_thermal(
    ir: PrintIR,
    env: ThermalEnvironment,
    tier: AnalysisTier,
) -> ThermalField:
    """Dispatch thermal analysis to the appropriate tier implementation.

    Args:
        ir: The parsed print intermediate representation.
        env: Thermal environment conditions (bed/chamber/ambient temps, airflow).
        tier: Analysis tier controlling fidelity vs speed trade-off.

    Returns:
        A ThermalField containing per-layer thermal states, hotspots, and
        a stress map keyed by layer index.
    """
    if tier is AnalysisTier.QUICK:
        return _quick_thermal(ir, env)
    elif tier is AnalysisTier.STANDARD:
        return _standard_thermal(ir, env)
    elif tier is AnalysisTier.PERFORMANCE:
        return _performance_thermal(ir, env)
    # Fallback for any unexpected tier value.
    return _quick_thermal(ir, env)


def _quick_thermal(ir: PrintIR, env: ThermalEnvironment) -> ThermalField:
    """Heuristic thermal analysis using a simplified Newton cooling model.

    For each layer the model:
      1. Computes a cooling coefficient *k* that accounts for part-cooling
         fan speed: ``k = 0.05 + (fan_speed / 255) * 0.1``.
      2. Estimates the temperature drop factor as
         ``min(1.0, k * cool_time)`` where *cool_time* is the layer time.
      3. Derives the surface temperature by interpolating between the
         nozzle temperature and the chamber temperature.
      4. Computes the thermal gradient versus the previous layer.
      5. Maps gradient to a stress score scaled by the material's
         ``warp_susceptibility``.

    Args:
        ir: Print intermediate representation.
        env: Thermal environment.

    Returns:
        Populated ThermalField.
    """
    if not ir.layers:
        return ThermalField(layer_temps=[], hotspots=[], stress_map={})

    nozzle_temp = ir.settings.nozzle_temp
    chamber_temp = env.chamber_temp

    # Look up material; fall back to default susceptibility if unknown.
    material = get_material(ir.settings.material)
    warp_susceptibility = material.warp_susceptibility if material else 0.5

    layer_temps: list[LayerThermalState] = []
    stress_map: dict[int, float] = {}
    cumulative_time = 0.0

    for i, layer in enumerate(ir.layers):
        cool_time = layer.layer_time
        fan_speed = layer.fan_speed

        # Newton cooling heuristic
        k = 0.05 + (fan_speed / 255.0) * 0.1
        temp_drop_factor = min(1.0, k * cool_time)

        # Estimated surface temperature after cooling
        estimated_temp = nozzle_temp - temp_drop_factor * (nozzle_temp - chamber_temp)

        # Gradient versus previous layer
        if i == 0:
            prev_temp = nozzle_temp
        else:
            prev_temp = layer_temps[i - 1].estimated_temp
        temp_gradient = abs(estimated_temp - prev_temp)

        # Stress: susceptibility * normalised gradient
        temp_range = nozzle_temp - chamber_temp
        if temp_range > 0:
            stress = warp_susceptibility * (temp_gradient / temp_range)
        else:
            stress = 0.0

        time_since_previous = cool_time if i > 0 else 0.0
        cumulative_time += cool_time

        state = LayerThermalState(
            layer_index=i,
            z_height=layer.z_height,
            deposition_time=cumulative_time,
            layer_duration=cool_time,
            time_since_previous=time_since_previous,
            cool_time=cool_time,
            estimated_temp=estimated_temp,
            temp_gradient=temp_gradient,
        )
        layer_temps.append(state)
        stress_map[i] = stress

    return ThermalField(
        layer_temps=layer_temps,
        hotspots=[],
        stress_map=stress_map,
    )


def _standard_thermal(ir: PrintIR, env: ThermalEnvironment) -> ThermalField:
    """Standard-tier thermal analysis using a 1D heat equation model.

    Treats each layer as a thermal slab and tracks an array of current
    temperatures for all deposited layers. When a new layer is deposited
    its temperature is set to nozzle_temp. All existing layers cool via
    Newton's law of cooling during the time it takes to print the next
    layer:

        T_new = T_ambient + (T_old - T_ambient) * exp(-h_eff * dt / (rho * cp * thickness))

    The first layer uses bed_temp as its ambient temperature (the bed acts
    as a heat source). Fan speed modulates the convective heat transfer
    coefficient:

        h_eff = h_base + h_fan * (fan_speed / 255)

    with h_base = 10.0 W/(m^2*K) and h_fan = 30.0 W/(m^2*K).

    Args:
        ir: Print intermediate representation.
        env: Thermal environment.

    Returns:
        Populated ThermalField with per-layer thermal states.
    """
    if not ir.layers:
        return ThermalField(layer_temps=[], hotspots=[], stress_map={})

    nozzle_temp = ir.settings.nozzle_temp
    bed_temp = env.bed_temp
    chamber_temp = env.chamber_temp

    # Material properties
    material = get_material(ir.settings.material)
    if material is not None:
        rho = material.density          # kg/m^3
        cp = material.specific_heat     # J/(kg*K)
        warp_susceptibility = material.warp_susceptibility
    else:
        # Sensible defaults when material is unknown
        rho = 1240.0
        cp = 1800.0
        warp_susceptibility = 0.5

    # Convection coefficients in W/(m^2*K)
    h_base = 10.0
    h_fan = 30.0

    # Layer thickness in metres (layer_height is in mm)
    layer_height_m = ir.settings.layer_height / 1000.0

    # Live temperature array: tracks the current temperature of every
    # deposited layer. Grows as new layers are deposited.
    live_temps: list[float] = []

    # ------------------------------------------------------------------
    # Phase 1: Simulate the thermal evolution during the entire print.
    # For each layer we (a) deposit it at nozzle_temp, then (b) cool
    # every deposited layer for the duration it takes to print the
    # current layer.
    # ------------------------------------------------------------------
    cumulative_time = 0.0
    # Track per-layer metadata gathered during deposition.
    deposition_times: list[float] = []
    layer_durations: list[float] = []

    for i, layer in enumerate(ir.layers):
        dt = layer.layer_time          # seconds to print this layer
        fan_speed = layer.fan_speed

        # Effective convective coefficient for this layer's print time
        h_eff = h_base + h_fan * (fan_speed / 255.0)

        # --- Deposit this new layer at nozzle temperature ---
        live_temps.append(nozzle_temp)

        # --- Cool ALL layers (including the new one) during this layer's
        #     print time. The new layer cools while it is being printed. ---
        for j in range(len(live_temps)):
            # First layer (j == 0) uses bed_temp as its ambient; the bed
            # acts as a constant heat source.
            t_ambient = bed_temp if j == 0 else chamber_temp
            thickness = layer_height_m

            # Newton cooling: exponential decay towards ambient
            decay = math.exp(-h_eff * dt / (rho * cp * thickness))
            live_temps[j] = t_ambient + (live_temps[j] - t_ambient) * decay

        cumulative_time += dt
        deposition_times.append(cumulative_time)
        layer_durations.append(dt)

    # ------------------------------------------------------------------
    # Phase 2: Build per-layer thermal states from the final live_temps.
    # At this point live_temps[i] holds the temperature of layer i after
    # the entire print has completed, which captures cumulative cooling.
    # ------------------------------------------------------------------
    layer_temps: list[LayerThermalState] = []
    stress_map: dict[int, float] = {}

    for i, layer in enumerate(ir.layers):
        estimated_temp = live_temps[i]

        # Gradient versus the adjacent layer below
        if i == 0:
            prev_temp = bed_temp
        else:
            prev_temp = live_temps[i - 1]
        temp_gradient = abs(estimated_temp - prev_temp)

        # Stress: susceptibility * normalised gradient
        temp_range = nozzle_temp - chamber_temp
        if temp_range > 0:
            stress = warp_susceptibility * (temp_gradient / temp_range)
        else:
            stress = 0.0

        dt = layer_durations[i]
        time_since_previous = dt if i > 0 else 0.0

        state = LayerThermalState(
            layer_index=i,
            z_height=layer.z_height,
            deposition_time=deposition_times[i],
            layer_duration=dt,
            time_since_previous=time_since_previous,
            cool_time=dt,
            estimated_temp=estimated_temp,
            temp_gradient=temp_gradient,
        )
        layer_temps.append(state)
        stress_map[i] = stress

    return ThermalField(
        layer_temps=layer_temps,
        hotspots=[],
        stress_map=stress_map,
    )


def _performance_thermal(ir: PrintIR, env: ThermalEnvironment) -> ThermalField:
    """Performance-tier thermal analysis using a 1D FEA-lite voxel column solver.

    Discretizes the layer stack into a 1D column of voxel cells (3-5 cells per
    layer) and solves the transient heat equation using explicit finite
    differences:

        T[i] += alpha * dt * (T[i+1] - 2*T[i] + T[i-1]) / dz^2

    Boundary conditions:
        - Bottom (z=0): Dirichlet BC at bed_temp (heated bed acts as constant
          temperature source).
        - Top (current top surface): Robin/Newton convective BC using the
          spatially-varying convection coefficient from the airflow module.

    New layers are deposited at nozzle_temp when their cumulative print time
    arrives. Adaptive time stepping satisfies the CFL stability condition:

        dt <= 0.5 * dz^2 / alpha

    After simulation, per-layer average temperatures are extracted from the
    voxel grid and stress scores are computed from inter-layer gradients.

    Args:
        ir: Print intermediate representation.
        env: Thermal environment.

    Returns:
        Populated ThermalField with per-layer thermal states and stress map.
    """
    from warp_engine.analysis.airflow import compute_convection_coefficient

    if not ir.layers:
        return ThermalField(layer_temps=[], hotspots=[], stress_map={})

    nozzle_temp = ir.settings.nozzle_temp
    bed_temp = env.bed_temp
    chamber_temp = env.chamber_temp

    # Material properties
    material = get_material(ir.settings.material)
    if material is not None:
        k_cond = material.thermal_conductivity   # W/(m*K)
        rho = material.density                    # kg/m^3
        cp = material.specific_heat               # J/(kg*K)
        alpha = material.thermal_diffusivity      # m^2/s
        warp_susceptibility = material.warp_susceptibility
    else:
        k_cond = 0.13
        rho = 1240.0
        cp = 1800.0
        alpha = k_cond / (rho * cp)
        warp_susceptibility = 0.5

    # Discretization parameters
    cells_per_layer = 4
    layer_height_m = ir.settings.layer_height / 1000.0  # mm -> m
    dz = layer_height_m / cells_per_layer                # cell size in m

    # CFL-limited maximum time step for stability
    dt_max = 0.5 * dz * dz / alpha

    # Build the voxel temperature column incrementally.
    # T holds the temperature of each voxel cell. Cells are added as layers
    # are deposited.
    T: list[float] = []

    # Track cumulative time and per-layer deposition times
    cumulative_time = 0.0
    deposition_times: list[float] = []
    layer_durations: list[float] = []
    num_layers_deposited = 0

    # Compute a representative point for convection coefficient lookup.
    # Use the midpoint of the first segment of the first layer as a
    # representative XY location; the Z will be updated per-layer.
    if ir.layers and ir.layers[0].segments:
        seg0 = ir.layers[0].segments[0]
        repr_x = (seg0.start.x + seg0.end.x) / 2.0
        repr_y = (seg0.start.y + seg0.end.y) / 2.0
    else:
        repr_x, repr_y = 5.0, 5.0

    for i, layer in enumerate(ir.layers):
        dt_layer = layer.layer_time  # seconds to print this layer

        # --- Deposit new layer cells at nozzle temperature ---
        for _ in range(cells_per_layer):
            T.append(nozzle_temp)
        num_layers_deposited += 1

        # --- Simulate cooling during this layer's print time ---
        # Use adaptive sub-stepping to respect CFL condition.
        time_remaining = dt_layer
        n_cells = len(T)

        # Compute convection coefficient at the current top surface
        top_z = layer.z_height
        repr_point = Vec3(repr_x, repr_y, top_z)
        h_conv = compute_convection_coefficient(
            repr_point, env.airflow_sources, layer_index=i
        )

        while time_remaining > 1e-12:
            dt = min(dt_max, time_remaining)
            time_remaining -= dt

            # Build updated temperature array using explicit FD scheme.
            # We operate on T[0..n_cells-1].
            # BC at bottom (index -1, ghost): T = bed_temp (Dirichlet)
            # BC at top (index n_cells, ghost): Robin/Newton convective BC
            T_new = T[:]

            for j in range(n_cells):
                # Neighbour temperatures with boundary conditions
                if j == 0:
                    T_below = bed_temp  # Dirichlet BC: heated bed
                else:
                    T_below = T[j - 1]

                if j == n_cells - 1:
                    # Robin BC at the top surface:
                    # -k dT/dz = h (T_surface - T_ambient)
                    # Ghost node: T_ghost = T[j] - (h * dz / k_cond) * (T[j] - chamber_temp)
                    T_above = T[j] - (h_conv * dz / k_cond) * (T[j] - chamber_temp)
                else:
                    T_above = T[j + 1]

                # Explicit finite difference update
                laplacian = (T_above - 2.0 * T[j] + T_below) / (dz * dz)
                T_new[j] = T[j] + alpha * dt * laplacian

            T = T_new

        cumulative_time += dt_layer
        deposition_times.append(cumulative_time)
        layer_durations.append(dt_layer)

    # --- Extract per-layer average temperatures and compute stress ---
    layer_temps: list[LayerThermalState] = []
    stress_map: dict[int, float] = {}
    layer_avg_temps: list[float] = []

    for i in range(num_layers_deposited):
        start_cell = i * cells_per_layer
        end_cell = start_cell + cells_per_layer
        layer_cells = T[start_cell:end_cell]
        avg_temp = sum(layer_cells) / len(layer_cells)
        layer_avg_temps.append(avg_temp)

    for i, layer in enumerate(ir.layers):
        estimated_temp = layer_avg_temps[i]

        # Gradient versus the adjacent layer below
        if i == 0:
            prev_temp = bed_temp
        else:
            prev_temp = layer_avg_temps[i - 1]
        temp_gradient = abs(estimated_temp - prev_temp)

        # Stress: susceptibility * normalised gradient
        temp_range = nozzle_temp - chamber_temp
        if temp_range > 0:
            stress = warp_susceptibility * (temp_gradient / temp_range)
        else:
            stress = 0.0

        dt_l = layer_durations[i]
        time_since_previous = dt_l if i > 0 else 0.0

        state = LayerThermalState(
            layer_index=i,
            z_height=layer.z_height,
            deposition_time=deposition_times[i],
            layer_duration=dt_l,
            time_since_previous=time_since_previous,
            cool_time=dt_l,
            estimated_temp=estimated_temp,
            temp_gradient=temp_gradient,
        )
        layer_temps.append(state)
        stress_map[i] = stress

    return ThermalField(
        layer_temps=layer_temps,
        hotspots=[],
        stress_map=stress_map,
    )
