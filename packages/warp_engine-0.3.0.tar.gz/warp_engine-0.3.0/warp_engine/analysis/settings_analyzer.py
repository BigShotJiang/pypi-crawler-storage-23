"""Print settings risk analyzer.

Evaluates print settings (bed temperature, layer height, infill density)
against material profiles to identify configuration risks that may
contribute to warping.
"""

from __future__ import annotations

from warp_engine.materials.profiles import get_material
from warp_engine.models import PrintSettings, SettingsRisk


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp *value* between *lo* and *hi*."""
    if value < lo:
        return lo
    if value > hi:
        return hi
    return value


def _check_bed_temp(settings: PrintSettings) -> bool:
    """Return True if bed temp is outside the material's recommended range.

    If the material is unknown (not in the database), return False so that
    we never flag an unrecognised material as a mismatch.
    """
    profile = get_material(settings.material)
    if profile is None:
        return False
    lo, hi = profile.bed_temp_range
    return settings.bed_temp < lo or settings.bed_temp > hi


def _layer_height_risk(settings: PrintSettings) -> float:
    """Compute layer-height risk score in [0, 1].

    Formula: (layer_height - 0.1) / 0.3, clamped to [0, 1].
    A 0.1 mm layer height is considered baseline (risk 0); anything at or
    above 0.4 mm saturates at risk 1.
    """
    return _clamp((settings.layer_height - 0.1) / 0.3)


def _infill_risk(settings: PrintSettings) -> float:
    """Compute infill-density risk score in [0, 1].

    Formula: 1.0 - (infill_density / 0.3), clamped to [0, 1].
    An infill density of 0.3 (30 %) or higher is considered safe (risk 0);
    lower densities increase the risk up to a maximum of 1.
    """
    return _clamp(1.0 - (settings.infill_density / 0.3))


def analyze_settings(settings: PrintSettings) -> SettingsRisk:
    """Analyse *settings* and return a populated :class:`SettingsRisk`.

    The function inspects bed temperature against the material database,
    evaluates layer height, and checks infill density.  It never raises
    for unknown materials.

    Args:
        settings: The print settings to evaluate.

    Returns:
        A :class:`SettingsRisk` dataclass with all risk fields populated.
    """
    return SettingsRisk(
        bed_temp_mismatch=_check_bed_temp(settings),
        layer_height_risk=_layer_height_risk(settings),
        infill_risk=_infill_risk(settings),
    )
