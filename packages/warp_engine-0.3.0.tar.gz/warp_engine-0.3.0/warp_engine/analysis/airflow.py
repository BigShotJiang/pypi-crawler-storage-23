"""Airflow-aware convection coefficient computation.

Computes spatially varying convective heat transfer coefficient h(x,y,z)
based on distance and angle from each AirflowSource.
"""
from __future__ import annotations

import math

from warp_engine.models import AirflowSource, AirflowType, Vec3

# Base natural convection coefficient (no forced airflow)
H_NATURAL = 8.0  # W/(m**2*K)

# Maximum forced convection from a fan at 100% speed
H_FAN_MAX = 40.0  # W/(m**2*K)


def compute_convection_coefficient(
    point: Vec3,
    airflow_sources: list[AirflowSource],
    layer_index: int = 0,
) -> float:
    """Compute the convective heat transfer coefficient at a point.

    Args:
        point: The (x,y,z) position to evaluate.
        airflow_sources: List of fan/airflow sources.
        layer_index: Current layer index (used to look up fan speed curves).

    Returns:
        h in W/(m**2*K) -- sum of natural convection + all fan contributions.
    """
    h = H_NATURAL

    for source in airflow_sources:
        h += _fan_contribution(point, source, layer_index)

    return h


def _fan_contribution(point: Vec3, source: AirflowSource, layer_index: int) -> float:
    """Compute convection contribution from a single airflow source."""
    # Get fan speed at this layer
    speed_pct = _get_speed_at_layer(source.speed_curve, layer_index)
    if speed_pct <= 0:
        return 0.0

    speed_factor = speed_pct / 100.0

    # Vector from fan to point
    dx = point.x - source.position.x
    dy = point.y - source.position.y
    dz = point.z - source.position.z
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)

    if dist < 1e-6:
        return H_FAN_MAX * speed_factor

    # Angle between fan direction and vector to point
    dot = (
        dx * source.direction.x + dy * source.direction.y + dz * source.direction.z
    ) / dist
    dir_mag = math.sqrt(
        source.direction.x ** 2
        + source.direction.y ** 2
        + source.direction.z ** 2
    )
    if dir_mag > 0:
        dot /= dir_mag

    # Cosine of angle -- 1.0 = directly in line, 0 = perpendicular, -1 = behind
    cos_angle = max(0.0, dot)  # No contribution from behind the fan

    # Angular falloff -- within spread angle: full effect, outside: decays
    spread_rad = math.radians(source.spread_angle)
    angle = math.acos(min(1.0, cos_angle))
    if angle <= spread_rad:
        angle_factor = 1.0
    else:
        # Exponential decay outside spread cone
        angle_factor = math.exp(-(angle - spread_rad) / spread_rad)

    # Distance falloff -- inverse square but capped
    dist_factor = 1.0 / (1.0 + (dist / 100.0) ** 2)

    return H_FAN_MAX * speed_factor * angle_factor * dist_factor


def _get_speed_at_layer(
    speed_curve: list[tuple[int, float]], layer_index: int
) -> float:
    """Look up fan speed percentage at a given layer from the speed curve."""
    if not speed_curve:
        return 0.0

    # Find the last entry at or before this layer
    result = speed_curve[0][1]
    for layer, speed in speed_curve:
        if layer <= layer_index:
            result = speed
        else:
            break
    return result
