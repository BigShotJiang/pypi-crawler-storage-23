"""Material profiles for common 3D printing filaments.

Each profile captures thermal, mechanical, and warp-related properties
used by the warp prediction engine to estimate warping risk.

Base material properties sourced from manufacturer datasheets and
Bambu Lab Filament Guide (2026).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class MaterialProfile:
    """Immutable material property profile for a 3D printing filament.

    Attributes:
        name: Material identifier (e.g. "PLA", "ABS").
        glass_transition_temp: Glass transition temperature in degrees C.
        extrusion_temp_range: (min, max) extrusion temperature in degrees C.
        bed_temp_range: (min, max) bed temperature in degrees C.
        thermal_conductivity: Thermal conductivity in W/(m*K).
        specific_heat: Specific heat capacity in J/(kg*K).
        density: Density in kg/m^3.
        cte: Coefficient of thermal expansion in 1/K.
        shrinkage_rate: Volumetric shrinkage rate in percent.
        youngs_modulus: Young's modulus (or bending modulus) in MPa.
        warp_susceptibility: Normalized warp susceptibility score 0..1.
        thermal_weight: Weight factor for thermal contribution to warping.
        adhesion_weight: Weight factor for adhesion contribution to warping.
        cooling_weight: Weight factor for cooling contribution to warping.
        geometry_weight: Weight factor for geometry contribution to warping.
    """

    name: str
    glass_transition_temp: float
    extrusion_temp_range: tuple[float, float]
    bed_temp_range: tuple[float, float]
    thermal_conductivity: float
    specific_heat: float
    density: float
    cte: float
    shrinkage_rate: float
    youngs_modulus: float
    warp_susceptibility: float
    thermal_weight: float
    adhesion_weight: float
    cooling_weight: float
    geometry_weight: float

    @property
    def thermal_diffusivity(self) -> float:
        """Derived thermal diffusivity in m^2/s.

        Calculated as: thermal_conductivity / (density * specific_heat)
        """
        return self.thermal_conductivity / (self.density * self.specific_heat)


# ---------------------------------------------------------------------------
# Built-in material database
# ---------------------------------------------------------------------------

MATERIAL_DB: dict[str, MaterialProfile] = {
    # ===================================================================
    # Standard filaments
    # ===================================================================
    "PLA": MaterialProfile(
        name="PLA",
        glass_transition_temp=60.0,
        extrusion_temp_range=(190.0, 230.0),
        bed_temp_range=(35.0, 65.0),
        thermal_conductivity=0.13,
        specific_heat=1800.0,
        density=1240.0,
        cte=68e-6,
        shrinkage_rate=0.3,
        youngs_modulus=2750.0,
        warp_susceptibility=0.25,
        thermal_weight=0.3,
        adhesion_weight=0.3,
        cooling_weight=0.2,
        geometry_weight=0.2,
    ),
    "PETG": MaterialProfile(
        name="PETG",
        glass_transition_temp=80.0,
        extrusion_temp_range=(230.0, 260.0),
        bed_temp_range=(60.0, 80.0),
        thermal_conductivity=0.19,
        specific_heat=1200.0,
        density=1270.0,
        cte=60e-6,
        shrinkage_rate=0.4,
        youngs_modulus=2050.0,
        warp_susceptibility=0.35,
        thermal_weight=0.3,
        adhesion_weight=0.3,
        cooling_weight=0.2,
        geometry_weight=0.2,
    ),
    "ABS": MaterialProfile(
        name="ABS",
        glass_transition_temp=105.0,
        extrusion_temp_range=(240.0, 280.0),
        bed_temp_range=(90.0, 100.0),
        thermal_conductivity=0.17,
        specific_heat=1400.0,
        density=1040.0,
        cte=90e-6,
        shrinkage_rate=0.7,
        youngs_modulus=1880.0,
        warp_susceptibility=0.8,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.25,
        geometry_weight=0.15,
    ),
    "ASA": MaterialProfile(
        name="ASA",
        glass_transition_temp=100.0,
        extrusion_temp_range=(240.0, 280.0),
        bed_temp_range=(90.0, 100.0),
        thermal_conductivity=0.18,
        specific_heat=1300.0,
        density=1070.0,
        cte=85e-6,
        shrinkage_rate=0.6,
        youngs_modulus=1920.0,
        warp_susceptibility=0.7,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.25,
        geometry_weight=0.15,
    ),
    "TPU": MaterialProfile(
        name="TPU",
        glass_transition_temp=-40.0,
        extrusion_temp_range=(220.0, 240.0),
        bed_temp_range=(30.0, 45.0),
        thermal_conductivity=0.19,
        specific_heat=1600.0,
        density=1210.0,
        cte=150e-6,
        shrinkage_rate=0.5,
        youngs_modulus=12.0,
        warp_susceptibility=0.1,
        thermal_weight=0.2,
        adhesion_weight=0.2,
        cooling_weight=0.3,
        geometry_weight=0.3,
    ),
    "NYLON": MaterialProfile(
        name="NYLON",
        glass_transition_temp=70.0,
        extrusion_temp_range=(240.0, 270.0),
        bed_temp_range=(60.0, 80.0),
        thermal_conductivity=0.25,
        specific_heat=1700.0,
        density=1140.0,
        cte=80e-6,
        shrinkage_rate=1.5,
        youngs_modulus=1700.0,
        warp_susceptibility=0.75,
        thermal_weight=0.3,
        adhesion_weight=0.3,
        cooling_weight=0.2,
        geometry_weight=0.2,
    ),
    "PC": MaterialProfile(
        name="PC",
        glass_transition_temp=147.0,
        extrusion_temp_range=(260.0, 280.0),
        bed_temp_range=(90.0, 110.0),
        thermal_conductivity=0.20,
        specific_heat=1200.0,
        density=1200.0,
        cte=65e-6,
        shrinkage_rate=0.6,
        youngs_modulus=2310.0,
        warp_susceptibility=0.7,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.25,
        geometry_weight=0.15,
    ),
    # ===================================================================
    # Composite filaments — carbon fiber reinforced
    # ===================================================================
    "PLA-CF": MaterialProfile(
        name="PLA-CF",
        glass_transition_temp=58.0,
        extrusion_temp_range=(210.0, 240.0),
        bed_temp_range=(45.0, 65.0),
        thermal_conductivity=0.40,
        specific_heat=1500.0,
        density=1300.0,
        cte=30e-6,
        shrinkage_rate=0.2,
        youngs_modulus=3950.0,
        warp_susceptibility=0.2,
        thermal_weight=0.25,
        adhesion_weight=0.25,
        cooling_weight=0.2,
        geometry_weight=0.3,
    ),
    "PETG-CF": MaterialProfile(
        name="PETG-CF",
        glass_transition_temp=78.0,
        extrusion_temp_range=(240.0, 270.0),
        bed_temp_range=(60.0, 80.0),
        thermal_conductivity=0.40,
        specific_heat=1100.0,
        density=1350.0,
        cte=25e-6,
        shrinkage_rate=0.3,
        youngs_modulus=2910.0,
        warp_susceptibility=0.3,
        thermal_weight=0.25,
        adhesion_weight=0.25,
        cooling_weight=0.2,
        geometry_weight=0.3,
    ),
    "ASA-CF": MaterialProfile(
        name="ASA-CF",
        glass_transition_temp=100.0,
        extrusion_temp_range=(250.0, 290.0),
        bed_temp_range=(90.0, 100.0),
        thermal_conductivity=0.40,
        specific_heat=1200.0,
        density=1200.0,
        cte=35e-6,
        shrinkage_rate=0.3,
        youngs_modulus=3740.0,
        warp_susceptibility=0.5,
        thermal_weight=0.35,
        adhesion_weight=0.2,
        cooling_weight=0.2,
        geometry_weight=0.25,
    ),
    "PET-CF": MaterialProfile(
        name="PET-CF",
        glass_transition_temp=80.0,
        extrusion_temp_range=(260.0, 300.0),
        bed_temp_range=(70.0, 100.0),
        thermal_conductivity=0.50,
        specific_heat=1100.0,
        density=1400.0,
        cte=15e-6,
        shrinkage_rate=0.3,
        youngs_modulus=5320.0,
        warp_susceptibility=0.35,
        thermal_weight=0.3,
        adhesion_weight=0.25,
        cooling_weight=0.2,
        geometry_weight=0.25,
    ),
    # ===================================================================
    # Composite filaments — glass fiber reinforced
    # ===================================================================
    "ABS-GF": MaterialProfile(
        name="ABS-GF",
        glass_transition_temp=105.0,
        extrusion_temp_range=(240.0, 280.0),
        bed_temp_range=(90.0, 100.0),
        thermal_conductivity=0.30,
        specific_heat=1200.0,
        density=1200.0,
        cte=40e-6,
        shrinkage_rate=0.4,
        youngs_modulus=2860.0,
        warp_susceptibility=0.6,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.2,
        geometry_weight=0.2,
    ),
    "PA6-GF": MaterialProfile(
        name="PA6-GF",
        glass_transition_temp=75.0,
        extrusion_temp_range=(260.0, 290.0),
        bed_temp_range=(100.0, 120.0),
        thermal_conductivity=0.35,
        specific_heat=1400.0,
        density=1350.0,
        cte=30e-6,
        shrinkage_rate=0.9,
        youngs_modulus=3670.0,
        warp_susceptibility=0.6,
        thermal_weight=0.3,
        adhesion_weight=0.3,
        cooling_weight=0.2,
        geometry_weight=0.2,
    ),
    # ===================================================================
    # Engineering / high-temperature filaments
    # ===================================================================
    "PC-FR": MaterialProfile(
        name="PC-FR",
        glass_transition_temp=145.0,
        extrusion_temp_range=(260.0, 280.0),
        bed_temp_range=(90.0, 110.0),
        thermal_conductivity=0.20,
        specific_heat=1200.0,
        density=1200.0,
        cte=65e-6,
        shrinkage_rate=0.5,
        youngs_modulus=1890.0,
        warp_susceptibility=0.65,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.25,
        geometry_weight=0.15,
    ),
    "PAHT-CF": MaterialProfile(
        name="PAHT-CF",
        glass_transition_temp=100.0,
        extrusion_temp_range=(260.0, 300.0),
        bed_temp_range=(100.0, 120.0),
        thermal_conductivity=0.50,
        specific_heat=1300.0,
        density=1250.0,
        cte=20e-6,
        shrinkage_rate=0.5,
        youngs_modulus=4230.0,
        warp_susceptibility=0.55,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.15,
        geometry_weight=0.25,
    ),
    "PA6-CF": MaterialProfile(
        name="PA6-CF",
        glass_transition_temp=75.0,
        extrusion_temp_range=(260.0, 300.0),
        bed_temp_range=(100.0, 120.0),
        thermal_conductivity=0.50,
        specific_heat=1400.0,
        density=1250.0,
        cte=20e-6,
        shrinkage_rate=0.8,
        youngs_modulus=5460.0,
        warp_susceptibility=0.55,
        thermal_weight=0.3,
        adhesion_weight=0.3,
        cooling_weight=0.15,
        geometry_weight=0.25,
    ),
    "PPA-CF": MaterialProfile(
        name="PPA-CF",
        glass_transition_temp=130.0,
        extrusion_temp_range=(280.0, 310.0),
        bed_temp_range=(100.0, 120.0),
        thermal_conductivity=0.60,
        specific_heat=1200.0,
        density=1350.0,
        cte=10e-6,
        shrinkage_rate=0.5,
        youngs_modulus=9860.0,
        warp_susceptibility=0.5,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.15,
        geometry_weight=0.25,
    ),
    "PPS-CF": MaterialProfile(
        name="PPS-CF",
        glass_transition_temp=90.0,
        extrusion_temp_range=(310.0, 340.0),
        bed_temp_range=(100.0, 120.0),
        thermal_conductivity=0.50,
        specific_heat=1100.0,
        density=1450.0,
        cte=12e-6,
        shrinkage_rate=0.3,
        youngs_modulus=7160.0,
        warp_susceptibility=0.4,
        thermal_weight=0.35,
        adhesion_weight=0.25,
        cooling_weight=0.15,
        geometry_weight=0.25,
    ),
}


def get_material(name: str) -> Optional[MaterialProfile]:
    """Look up a material profile by name (case-insensitive).

    Args:
        name: Material name, e.g. "PLA", "pla", "Pla".

    Returns:
        The matching MaterialProfile, or None if not found.
    """
    return MATERIAL_DB.get(name.upper())


def list_materials() -> list[str]:
    """Return a sorted list of all available material names.

    Returns:
        Sorted list of material name strings.
    """
    return sorted(MATERIAL_DB.keys())
