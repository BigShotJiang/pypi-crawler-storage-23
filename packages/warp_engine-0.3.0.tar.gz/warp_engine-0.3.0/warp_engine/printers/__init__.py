"""Printer profile database with airflow configurations."""
