"""Printer profile database with airflow configurations.

Each profile describes a printer's physical characteristics and default
airflow sources so the thermal simulation can account for printer-specific
cooling behaviour.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from warp_engine.models import (
    AirflowSource,
    AirflowType,
    BedShape,
    Vec3,
)


@dataclass(frozen=True)
class PrinterProfile:
    """Immutable description of a printer's physical properties."""

    name: str
    bed_size: tuple[float, float]
    bed_shape: BedShape
    max_z: float
    has_enclosure: bool
    default_chamber_temp: Optional[float]
    airflow_sources: tuple[AirflowSource, ...]


# ---------------------------------------------------------------------------
# Helper factories for common airflow sources
# ---------------------------------------------------------------------------

def _part_cooling(
    position: Vec3 | None = None,
    direction: Vec3 | None = None,
    spread_angle: float = 60.0,
) -> AirflowSource:
    """Return a standard part-cooling fan source."""
    return AirflowSource(
        position=position or Vec3(0.0, 0.0, 2.0),
        direction=direction or Vec3(0.0, 0.0, -1.0),
        type=AirflowType.PART_COOLING,
        speed_curve=[(0, 0.0), (255, 1.0)],
        spread_angle=spread_angle,
    )


def _chamber_circ(
    position: Vec3 | None = None,
    direction: Vec3 | None = None,
    spread_angle: float = 90.0,
) -> AirflowSource:
    """Return a chamber-circulation fan source."""
    return AirflowSource(
        position=position or Vec3(0.0, 0.0, 300.0),
        direction=direction or Vec3(0.0, 0.0, -1.0),
        type=AirflowType.CHAMBER_CIRCULATION,
        speed_curve=[(0, 0.0), (255, 1.0)],
        spread_angle=spread_angle,
    )


# ---------------------------------------------------------------------------
# Printer database
# ---------------------------------------------------------------------------

PRINTER_DB: dict[str, PrinterProfile] = {
    # -- Bambu Lab ----------------------------------------------------------
    "bambu_x1c": PrinterProfile(
        name="Bambu Lab X1 Carbon",
        bed_size=(256.0, 256.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=256.0,
        has_enclosure=True,
        default_chamber_temp=40.0,
        airflow_sources=(
            _part_cooling(),
            _chamber_circ(),
        ),
    ),
    "bambu_h2d": PrinterProfile(
        name="Bambu Lab H2D",
        bed_size=(256.0, 256.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=256.0,
        has_enclosure=True,
        default_chamber_temp=45.0,
        airflow_sources=(
            _part_cooling(),
            _chamber_circ(),
            AirflowSource(
                position=Vec3(0.0, 128.0, 50.0),
                direction=Vec3(1.0, 0.0, 0.0),
                type=AirflowType.SIDE_FAN,
                speed_curve=[(0, 0.0), (255, 1.0)],
                spread_angle=45.0,
            ),
        ),
    ),
    "bambu_p1s": PrinterProfile(
        name="Bambu Lab P1S",
        bed_size=(256.0, 256.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=256.0,
        has_enclosure=True,
        default_chamber_temp=38.0,
        airflow_sources=(
            _part_cooling(),
            _chamber_circ(),
        ),
    ),
    "bambu_a1": PrinterProfile(
        name="Bambu Lab A1",
        bed_size=(256.0, 256.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=256.0,
        has_enclosure=False,
        default_chamber_temp=None,
        airflow_sources=(
            _part_cooling(),
        ),
    ),
    "bambu_a1_mini": PrinterProfile(
        name="Bambu Lab A1 Mini",
        bed_size=(180.0, 180.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=180.0,
        has_enclosure=False,
        default_chamber_temp=None,
        airflow_sources=(
            _part_cooling(),
        ),
    ),
    # -- Prusa --------------------------------------------------------------
    "prusa_mk4": PrinterProfile(
        name="Prusa MK4",
        bed_size=(250.0, 210.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=220.0,
        has_enclosure=False,
        default_chamber_temp=None,
        airflow_sources=(
            _part_cooling(),
        ),
    ),
    # -- Creality -----------------------------------------------------------
    "ender_3_v3": PrinterProfile(
        name="Creality Ender-3 V3",
        bed_size=(220.0, 220.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=250.0,
        has_enclosure=False,
        default_chamber_temp=None,
        airflow_sources=(
            _part_cooling(),
        ),
    ),
    # -- Voron --------------------------------------------------------------
    "voron_2.4": PrinterProfile(
        name="Voron 2.4 (350mm)",
        bed_size=(350.0, 350.0),
        bed_shape=BedShape.RECTANGULAR,
        max_z=340.0,
        has_enclosure=True,
        default_chamber_temp=50.0,
        airflow_sources=(
            _part_cooling(),
            _chamber_circ(),
        ),
    ),
}


# ---------------------------------------------------------------------------
# Public look-up helpers
# ---------------------------------------------------------------------------

def get_printer(printer_id: str) -> PrinterProfile | None:
    """Return a printer profile by ID, or *None* if not found."""
    return PRINTER_DB.get(printer_id)


def list_printers() -> list[str]:
    """Return a sorted list of all printer IDs in the database."""
    return sorted(PRINTER_DB.keys())
