"""Core data models for the warp prediction engine.

All input/output contracts are defined here as dataclasses. This module
has no Django dependencies.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum


@dataclass(frozen=True)
class Vec3:
    x: float
    y: float
    z: float

    def distance_to(self, other: Vec3) -> float:
        return math.sqrt(
            (self.x - other.x) ** 2
            + (self.y - other.y) ** 2
            + (self.z - other.z) ** 2
        )


@dataclass(frozen=True)
class BBox3D:
    min: Vec3
    max: Vec3

    def volume(self) -> float:
        return (
            (self.max.x - self.min.x)
            * (self.max.y - self.min.y)
            * (self.max.z - self.min.z)
        )


class MoveType(Enum):
    PERIMETER = "perimeter"
    INFILL = "infill"
    SUPPORT = "support"
    TRAVEL = "travel"
    WIPE = "wipe"
    CUSTOM = "custom"


class AdhesionType(Enum):
    NONE = "none"
    SKIRT = "skirt"
    BRIM = "brim"
    RAFT = "raft"


class GcodeFlavor(Enum):
    MARLIN = "marlin"
    KLIPPER = "klipper"
    REPRAP = "reprap"
    SMOOTHIEWARE = "smoothieware"
    SAILFISH = "sailfish"
    UNKNOWN = "unknown"


class BedShape(Enum):
    RECTANGULAR = "rectangular"
    CIRCULAR = "circular"


class RiskLevel(Enum):
    LOW = 1
    MODERATE = 2
    HIGH = 3
    CRITICAL = 4


class AirflowType(Enum):
    PART_COOLING = "part_cooling"
    SIDE_FAN = "side_fan"
    CHAMBER_CIRCULATION = "chamber"
    EXHAUST = "exhaust"


class AnalysisTier(Enum):
    QUICK = "quick"
    STANDARD = "standard"
    PERFORMANCE = "performance"


@dataclass
class MoveSegment:
    start: Vec3
    end: Vec3
    extrusion: float
    speed: float
    move_type: MoveType

    @property
    def length(self) -> float:
        return self.start.distance_to(self.end)


@dataclass
class Layer:
    z_height: float
    segments: list[MoveSegment]
    layer_time: float
    fan_speed: float

    @property
    def total_extrusion(self) -> float:
        return sum(s.extrusion for s in self.segments)


@dataclass
class PrintSettings:
    bed_temp: float
    nozzle_temp: float
    material: str
    layer_height: float
    first_layer_height: float
    adhesion_type: AdhesionType
    infill_density: float
    infill_pattern: str


@dataclass
class PrintIR:
    layers: list[Layer]
    settings: PrintSettings
    bed_shape: BedShape
    flavor: GcodeFlavor

    @property
    def layer_count(self) -> int:
        return len(self.layers)


@dataclass
class AirflowSource:
    position: Vec3
    direction: Vec3
    type: AirflowType
    speed_curve: list[tuple[int, float]]
    spread_angle: float


@dataclass
class ThermalEnvironment:
    bed_temp: float
    chamber_temp: float
    ambient_temp: float
    airflow_sources: list[AirflowSource] = field(default_factory=list)


@dataclass
class LayerThermalState:
    layer_index: int
    z_height: float
    deposition_time: float
    layer_duration: float
    time_since_previous: float
    cool_time: float
    estimated_temp: float
    temp_gradient: float


@dataclass
class Region:
    bounding_box: BBox3D
    affected_layers: tuple[int, int]
    description: str = ""


@dataclass
class ThermalField:
    layer_temps: list[LayerThermalState]
    hotspots: list[Region]
    stress_map: dict[int, float]


@dataclass
class GeometryRisk:
    large_flat_regions: list[Region] = field(default_factory=list)
    thin_walls: list[Region] = field(default_factory=list)
    sharp_corners: list[Region] = field(default_factory=list)
    overhangs: list[Region] = field(default_factory=list)
    aspect_ratio_flags: list[Region] = field(default_factory=list)
    cross_section_changes: list[Region] = field(default_factory=list)


@dataclass
class AdhesionRisk:
    bed_contact_area: float = 0.0
    contact_ratio: float = 0.0
    first_layer_coverage: float = 0.0
    adhesion_type_score: float = 0.0
    perimeter_length: float = 0.0
    lift_force_estimate: float = 0.0


@dataclass
class SettingsRisk:
    cooling_too_aggressive: bool = False
    bed_temp_mismatch: bool = False
    speed_risk: float = 0.0
    layer_height_risk: float = 0.0
    infill_risk: float = 0.0


@dataclass
class RiskRegion:
    bounding_box: BBox3D
    affected_layers: tuple[int, int]
    score: float
    primary_cause: str
    contributing_factors: list[str] = field(default_factory=list)


@dataclass
class Recommendation:
    priority: int
    category: str
    message: str
    expected_improvement: float
    setting_change: dict | None = None


@dataclass
class AnalysisMetadata:
    tier: AnalysisTier
    time_ms: int
    version: str


@dataclass
class WarpReport:
    overall_score: float
    risk_level: RiskLevel
    regions: list[RiskRegion]
    recommendations: list[Recommendation]
    thermal_field: ThermalField
    metadata: AnalysisMetadata

    def to_dict(self) -> dict:
        """Serialize to JSON-safe dictionary."""
        import dataclasses
        return dataclasses.asdict(self)
