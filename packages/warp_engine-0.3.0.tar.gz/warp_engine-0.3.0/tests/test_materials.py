"""Tests for material property database."""
from warp_engine.materials.profiles import (
    MaterialProfile, get_material, list_materials, MATERIAL_DB,
)


def test_pla_exists():
    pla = get_material("PLA")
    assert pla is not None
    assert pla.name == "PLA"


def test_abs_exists():
    abs_mat = get_material("ABS")
    assert abs_mat is not None
    assert abs_mat.glass_transition_temp > 100


def test_pla_glass_transition():
    pla = get_material("PLA")
    assert 55 <= pla.glass_transition_temp <= 65


def test_abs_higher_warp_susceptibility_than_pla():
    pla = get_material("PLA")
    abs_mat = get_material("ABS")
    assert abs_mat.warp_susceptibility > pla.warp_susceptibility


def test_list_materials_returns_all():
    materials = list_materials()
    assert "PLA" in materials
    assert "ABS" in materials
    assert "PETG" in materials
    assert len(materials) >= 7


def test_get_material_case_insensitive():
    assert get_material("pla") is not None
    assert get_material("Pla") is not None


def test_get_unknown_material_returns_none():
    assert get_material("unobtainium") is None


def test_all_materials_have_valid_cte():
    for name in list_materials():
        mat = get_material(name)
        assert mat.cte > 0, f"{name} has invalid CTE"


def test_thermal_diffusivity_derived():
    pla = get_material("PLA")
    expected = pla.thermal_conductivity / (pla.density * pla.specific_heat)
    assert abs(pla.thermal_diffusivity - expected) < 1e-12
