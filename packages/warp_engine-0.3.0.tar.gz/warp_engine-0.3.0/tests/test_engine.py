"""Tests for the main engine entry point."""
from warp_engine.engine import Engine
from warp_engine.models import WarpReport, RiskLevel, AnalysisTier


SIMPLE_GCODE = """\
;FLAVOR:Marlin
M140 S60
M104 S210
M190 S60
M109 S210
G28
M83
G1 Z0.3 F600
G1 X80 Y0 E5.0 F1200
G1 X80 Y80 E10.0
G1 X0 Y80 E15.0
G1 X0 Y0 E20.0
G1 Z0.5
G1 X80 Y0 E25.0
G1 X80 Y80 E30.0
G1 X0 Y80 E35.0
G1 X0 Y0 E40.0
"""


def test_engine_analyze_returns_report():
    engine = Engine()
    result = engine.analyze(gcode=SIMPLE_GCODE, material="PLA")
    assert isinstance(result, WarpReport)


def test_engine_default_tier_is_quick():
    engine = Engine()
    result = engine.analyze(gcode=SIMPLE_GCODE, material="PLA")
    assert result.metadata.tier == AnalysisTier.QUICK


def test_engine_with_printer_profile():
    engine = Engine()
    result = engine.analyze(
        gcode=SIMPLE_GCODE, material="PLA", printer_profile="bambu_x1c",
    )
    assert isinstance(result, WarpReport)


def test_engine_abs_higher_risk_than_pla():
    engine = Engine()
    pla = engine.analyze(gcode=SIMPLE_GCODE, material="PLA")
    abs_r = engine.analyze(gcode=SIMPLE_GCODE, material="ABS")
    assert abs_r.overall_score >= pla.overall_score


def test_engine_empty_gcode():
    engine = Engine()
    result = engine.analyze(gcode="", material="PLA")
    assert result.overall_score == 0.0
    assert result.risk_level == RiskLevel.LOW
