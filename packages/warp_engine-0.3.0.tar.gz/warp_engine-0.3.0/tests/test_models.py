"""Tests for core data models."""
from warp_engine.models import (
    Vec3, BBox3D, MoveType, AdhesionType, GcodeFlavor, BedShape,
    RiskLevel, AirflowType, AnalysisTier,
    MoveSegment, Layer, PrintSettings, PrintIR,
    AirflowSource, ThermalEnvironment, LayerThermalState, ThermalField,
    Region, GeometryRisk, AdhesionRisk, SettingsRisk,
    RiskRegion, Recommendation, AnalysisMetadata, WarpReport,
)


def test_vec3_creation():
    v = Vec3(1.0, 2.0, 3.0)
    assert v.x == 1.0
    assert v.y == 2.0
    assert v.z == 3.0


def test_vec3_distance():
    a = Vec3(0.0, 0.0, 0.0)
    b = Vec3(3.0, 4.0, 0.0)
    assert abs(a.distance_to(b) - 5.0) < 1e-9


def test_bbox3d_volume():
    box = BBox3D(min=Vec3(0, 0, 0), max=Vec3(10, 20, 30))
    assert box.volume() == 6000.0


def test_move_segment_length():
    seg = MoveSegment(
        start=Vec3(0, 0, 0), end=Vec3(10, 0, 0),
        extrusion=1.0, speed=60.0, move_type=MoveType.PERIMETER,
    )
    assert abs(seg.length - 10.0) < 1e-9


def test_layer_total_extrusion():
    seg1 = MoveSegment(
        start=Vec3(0, 0, 0), end=Vec3(10, 0, 0),
        extrusion=1.5, speed=60.0, move_type=MoveType.PERIMETER,
    )
    seg2 = MoveSegment(
        start=Vec3(10, 0, 0), end=Vec3(20, 0, 0),
        extrusion=1.5, speed=60.0, move_type=MoveType.INFILL,
    )
    layer = Layer(z_height=0.2, segments=[seg1, seg2], layer_time=10.0, fan_speed=0.0)
    assert abs(layer.total_extrusion - 3.0) < 1e-9


def test_print_settings_defaults():
    ps = PrintSettings(
        bed_temp=60.0, nozzle_temp=210.0, material="PLA",
        layer_height=0.2, first_layer_height=0.3,
        adhesion_type=AdhesionType.SKIRT,
        infill_density=0.2, infill_pattern="grid",
    )
    assert ps.material == "PLA"


def test_print_ir_layer_count():
    ir = PrintIR(
        layers=[], settings=PrintSettings(
            bed_temp=60, nozzle_temp=210, material="PLA",
            layer_height=0.2, first_layer_height=0.3,
            adhesion_type=AdhesionType.NONE,
            infill_density=0.2, infill_pattern="grid",
        ),
        bed_shape=BedShape.RECTANGULAR, flavor=GcodeFlavor.MARLIN,
    )
    assert ir.layer_count == 0


def test_thermal_field_creation():
    tf = ThermalField(layer_temps=[], hotspots=[], stress_map={})
    assert tf.layer_temps == []


def test_warp_report_creation():
    report = WarpReport(
        overall_score=0.5, risk_level=RiskLevel.MODERATE,
        regions=[], recommendations=[],
        thermal_field=ThermalField(layer_temps=[], hotspots=[], stress_map={}),
        metadata=AnalysisMetadata(tier=AnalysisTier.QUICK, time_ms=100, version="0.1.0"),
    )
    assert report.risk_level == RiskLevel.MODERATE


def test_risk_level_ordering():
    assert RiskLevel.LOW.value < RiskLevel.MODERATE.value
    assert RiskLevel.MODERATE.value < RiskLevel.HIGH.value
    assert RiskLevel.HIGH.value < RiskLevel.CRITICAL.value


def test_recommendation_creation():
    rec = Recommendation(
        priority=1, category="temperature",
        message="Increase bed temp to 65C",
        expected_improvement=0.15,
        setting_change={"bed_temp": 65},
    )
    assert rec.priority == 1
    assert rec.setting_change == {"bed_temp": 65}
