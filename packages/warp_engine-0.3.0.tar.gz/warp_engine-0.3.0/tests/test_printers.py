"""Tests for printer profile database."""
from warp_engine.printers.profiles import (
    PrinterProfile, get_printer, list_printers,
)
from warp_engine.models import AirflowType, BedShape


def test_bambu_x1c_exists():
    printer = get_printer("bambu_x1c")
    assert printer is not None
    assert "X1" in printer.name


def test_bambu_h2d_has_side_fan():
    printer = get_printer("bambu_h2d")
    assert printer is not None
    fan_types = [af.type for af in printer.airflow_sources]
    assert AirflowType.SIDE_FAN in fan_types


def test_bambu_a1_no_enclosure():
    printer = get_printer("bambu_a1")
    assert printer is not None
    assert printer.has_enclosure is False
    assert printer.default_chamber_temp is None


def test_enclosed_printer_has_chamber_temp():
    printer = get_printer("bambu_x1c")
    assert printer.has_enclosure is True
    assert printer.default_chamber_temp is not None


def test_list_printers_has_entries():
    printers = list_printers()
    assert len(printers) >= 4


def test_get_unknown_printer_returns_none():
    assert get_printer("nonexistent_printer") is None


def test_all_printers_have_part_cooling():
    for pid in list_printers():
        printer = get_printer(pid)
        fan_types = [af.type for af in printer.airflow_sources]
        assert AirflowType.PART_COOLING in fan_types, f"{pid} missing part cooling"


def test_bed_shape():
    printer = get_printer("bambu_x1c")
    assert printer.bed_shape == BedShape.RECTANGULAR
