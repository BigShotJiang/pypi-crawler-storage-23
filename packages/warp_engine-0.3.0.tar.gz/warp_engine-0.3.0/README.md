# warp-engine

A predictive warp analysis engine for 3D printing. Feed it G-code and it tells you where your print is likely to warp, why, and what to do about it.

warp-engine parses G-code from any major slicer, runs a multi-factor risk analysis (thermal, geometry, adhesion, print settings), and produces a scored report with per-region risk breakdowns and actionable recommendations.

## Installation

```bash
pip install warp-engine
```

Requires Python 3.11+.

## Quick Start

```python
from warp_engine.engine import Engine
from warp_engine.models import AnalysisTier

engine = Engine()

# Read your G-code file
with open("my_print.gcode") as f:
    gcode = f.read()

# Run analysis
report = engine.analyze(
    gcode=gcode,
    material="ABS",
    tier=AnalysisTier.STANDARD,
    printer_profile="bambu_x1c",
)

# Check results
print(f"Risk: {report.risk_level.name} ({report.overall_score:.0%})")
for rec in report.recommendations:
    print(f"  [{rec.category}] {rec.message}")
```

## Analysis Tiers

| Tier | Method | Speed | Best For |
|------|--------|-------|----------|
| Quick | Heuristic lookup tables | < 1s | Fast screening, free-tier API |
| Standard | 1D heat equation per layer stack | 5-15s | Most prints, good accuracy |
| Performance | 3D FEA-lite voxel solver | 30s-5min | Large/complex prints, maximum accuracy |

All tiers produce the same `WarpReport` output structure.

## Risk Factors

The engine evaluates four independent risk categories and combines them with material-specific weights:

- **Thermal** -- inter-layer cooling, temperature gradients, airflow effects
- **Geometry** -- large flat regions, thin walls, sharp corners, overhangs
- **Adhesion** -- bed contact area, first layer coverage, adhesion type
- **Settings** -- cooling fan speed, bed temp, print speed, layer height

## Supported Materials

PLA, ABS, PETG, ASA, TPU, Nylon, PC -- each with calibrated thermal properties and risk weights. See [docs/materials.md](docs/materials.md) for full property tables.

## Supported Printers

Bambu Lab X1C, H2D, P1S, A1, A1 Mini | Prusa MK4 | Creality Ender-3 V3 | Voron 2.4

Printer profiles include airflow source positions for accurate thermal simulation. See [docs/printers.md](docs/printers.md) for details.

## G-code Compatibility

Parses all major G-code flavors: Marlin, Klipper, RepRap, Smoothieware, Sailfish. Auto-detects the flavor from slicer comments.

## Documentation

- [Getting Started](docs/getting-started.md) -- installation, first analysis, interpreting results
- [API Reference](docs/api-reference.md) -- Engine class, data models, WarpReport structure
- [Materials](docs/materials.md) -- built-in material profiles and properties
- [Printers](docs/printers.md) -- built-in printer profiles and airflow configs
- [REST API](docs/rest-api.md) -- Django integration endpoints

## License

MIT -- see [LICENSE](LICENSE).
