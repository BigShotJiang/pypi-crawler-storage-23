# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.6 - sm_infra                                                      ║
║  Shared Memory Infrastructure Package                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.6.0                                                             ║
║  Date    : 2026-03-04                                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Modules:                                                                    ║
║    sm_ring_buffer  - SmRingBuffer (Lock-free SPSC 링 버퍼)                  ║
║    sm_block        - SmBlock, SmBlockBuffer, SmBlockHandler (이미지 블록 풀) ║
║    sm_value        - SmValue (고속 스칼라 값)                                 ║
║    sm_queue        - SmQueue (SharedMemory IPC Queue)                       ║
║    sm_signal       - SmSignalRegistry, SmSignalStats (시그널 인프라)         ║
║    sm_blackbox     - SmBlackBox (시그널 체인 세션 감시)                      ║
║    sm_sync         - SmKernelEvent, SmLockFreeEvent, SmMutex (동기화)       ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from .sm_block import SmBlock, SmBlockBuffer, SmBlockHandler
from .sm_value import SmValue
from .sm_ring_buffer import SmRingBuffer, SpscViolationError
from .sm_queue import SmQueue
from .sm_signal import SmSignalRegistry, SmSignalStats, RegistryFullError
from .sm_blackbox import SmBlackBox
from .sm_sync import SmKernelEvent, SmLockFreeEvent, SmMutex

__all__ = [
    "SmBlock", "SmBlockBuffer", "SmBlockHandler",
    "SmValue", "SmRingBuffer", "SmQueue",
    "SmSignalRegistry", "SmSignalStats", "SmBlackBox",
    "SmKernelEvent", "SmLockFreeEvent", "SmMutex",
    "SpscViolationError", "RegistryFullError",
]
