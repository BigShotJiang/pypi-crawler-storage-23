# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.6 - py_alaska                                                     ║
║  Multiprocess Task Management Framework                                      ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.6.0                                                             ║
║  Date    : 2026-03-04                                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from .core import (
    # Task Manager
    TaskManager, TaskInfo, TaskRuntime,
    # RMI & Client
    RmiClient, DirectClient,
    # Task Decorators & Validation
    rmi_run, rmi_signal, has_run_flag, get_signal_handlers,
    get_rmi_signal_forward, TaskValidator, task, rmi_task,
    _DEFAULT_RESTART_DELAY,
    # Signal
    Signal, SignalBroker, SignalClient, PayloadTooLargeError, QoS, PriorityScheduler,
    # Config
    gconfig, GConfig,
    ConfigError, ConfigFileNotFoundError, ConfigPathNotFoundError,
    ConfigLockTimeoutError, ConfigValidationError, ConfigParseError,
    ConfigIntegrityError, ConfigSecurityError, ConfigStaleLockError,
    ConfigMandatoryFieldError, ConfigRecoveryError,
    # Error
    AlaskaError, TaskNotFoundError, SmBlockNotFoundError,
    RmiTimeoutError, TaskRemovedError, InjectionError,
    InvokeDeadlockError, CircularRmiError,
    task_not_found_error, smblock_not_found_error, rmi_timeout_error,
    pickle_error, config_mandatory_field_error,
    # Log
    LogRecord, RmiLogger, LogTask,
    # Log Handler
    SafeRotatingFileHandler, QueueFileHandler, QueueFileListener,
    create_safe_file_handler, setup_safe_logging,
    # Performance
    MethodPerformance, TaskPerformance, SystemPerformance,
    TimingRecorder, PerformanceCollector,
    # Profiler
    task_profiler, TaskProfiler, LapRecord,
    # Banner
    banner,
)

from .sm_infra import (
    SmBlock, SmBlockBuffer, SmBlockHandler, SmValue, SmRingBuffer, SmQueue,
    SmSignalStats, SmSignalRegistry, SmBlackBox, SmLockFreeEvent, SmKernelEvent,
    SmMutex, SpscViolationError, RegistryFullError,
)

from .device import DeviceProperty, DeviceTaskMixin, DeviceSchema

from .monitor import (
    TaskMonitor,
    HwInfoCollector,
    ExternalLinkManager,
    SlackSender,
    EmailSender,
    WebhookSender,
    HealthReporter,
    ReportScheduler,
)

# Qt Integration (optional — requires PySide6)
try:
    from .qt import AlaskaApp, ui_thread
except ImportError:
    pass

__version__ = "2.6.0"
__all__ = [
    # Task Manager
    "TaskManager", "TaskInfo", "TaskRuntime",
    # RMI & Client
    "RmiClient", "DirectClient",
    # Task Decorators & Validation
    "rmi_run", "rmi_signal", "task", "rmi_task", "has_run_flag",
    "get_signal_handlers", "get_rmi_signal_forward", "TaskValidator",
    "_DEFAULT_RESTART_DELAY",
    # Signal
    "Signal", "SignalBroker", "SignalClient", "PayloadTooLargeError", "QoS", "PriorityScheduler",
    # Config
    "gconfig", "GConfig",
    "ConfigError", "ConfigFileNotFoundError", "ConfigPathNotFoundError",
    "ConfigLockTimeoutError", "ConfigValidationError", "ConfigParseError",
    "ConfigIntegrityError", "ConfigSecurityError", "ConfigStaleLockError",
    "ConfigMandatoryFieldError", "ConfigRecoveryError",
    # Error
    "AlaskaError", "TaskNotFoundError", "SmBlockNotFoundError",
    "RmiTimeoutError", "TaskRemovedError", "InjectionError",
    "InvokeDeadlockError", "CircularRmiError",
    "task_not_found_error", "smblock_not_found_error", "rmi_timeout_error",
    "pickle_error", "config_mandatory_field_error",
    # Log
    "LogRecord", "RmiLogger", "LogTask",
    # Log Handler
    "SafeRotatingFileHandler", "QueueFileHandler", "QueueFileListener",
    "create_safe_file_handler", "setup_safe_logging",
    # Performance
    "MethodPerformance", "TaskPerformance", "SystemPerformance",
    "TimingRecorder", "PerformanceCollector",
    # Profiler
    "task_profiler", "TaskProfiler", "LapRecord",
    # Banner
    "banner",
    # SmBlock & Shared Memory
    "SmBlock", "SmBlockBuffer", "SmBlockHandler", "SmValue", "SmRingBuffer", "SmQueue",
    "SmSignalStats", "SmSignalRegistry", "SmBlackBox", "SmLockFreeEvent", "SmKernelEvent",
    "SmMutex", "SpscViolationError", "RegistryFullError",
    # Device
    "DeviceProperty", "DeviceTaskMixin", "DeviceSchema",
    # Monitor
    "TaskMonitor", "HwInfoCollector",
    "ExternalLinkManager", "SlackSender", "EmailSender",
    "WebhookSender", "HealthReporter", "ReportScheduler",
    # Qt (optional)
    "AlaskaApp", "ui_thread",
]
