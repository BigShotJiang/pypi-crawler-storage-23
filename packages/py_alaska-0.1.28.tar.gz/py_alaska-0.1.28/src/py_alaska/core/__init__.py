# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.6 - core                                                          ║
║  Core Task Execution Framework Package                                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.6.0                                                             ║
║  Date    : 2026-03-04                                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Modules:                                                                    ║
║    task_manager     - Task 생명주기 관리 (TaskManager, TaskRuntime)         ║
║    task_signal      - Signal/Event Broker (QoS, SubscriberCache)            ║
║    task_decorator   - Task 등록 데코레이터 (@task, @rmi_task)               ║
║    task_error       - 에러 핸들링 및 예외 클래스                             ║
║    task_performance - 성능 메트릭 수집                                       ║
║    gconfig          - 글로벌 설정 관리 (Singleton)                          ║
║    task_log         - 중앙 로깅 시스템                                       ║
║    _log_handler     - 멀티프로세스 안전 파일 로깅                            ║
║    task_profiler    - 코드 블록 프로파일링                                   ║
║    _banner          - 배너 출력 유틸리티                                     ║
║  Internal:                                                                   ║
║    _rmi_client      - RmiProtocol + RmiClient + DirectClient              ║
║    _signal_core     - QoS, Signal, PriorityScheduler                        ║
║    _task_runtime    - TaskRuntime (Task 실행 래퍼, InvokeDispenser)        ║
║    _comm_utils      - 통신 유틸리티 (디버그, 체인, 비동기)                 ║
║    _task_validator   - TaskValidator (태스크 검증)                           ║
║    _config_infra    - GConfig 예외 11종 + 인프라 (FileLock, PathParser 등) ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# Task Manager
from .task_manager import TaskManager, TaskInfo, TaskRuntime

# RMI & Client (직접 소스 참조)
from ._rmi_client import RmiClient, DirectClient

# Task Decorators & Validation
from .task_decorator import (
    rmi_run, rmi_signal, has_run_flag, get_signal_handlers,
    get_rmi_signal_forward, task, rmi_task,
    _DEFAULT_RESTART_DELAY,
)
from ._task_validator import TaskValidator

# Signal
from .task_signal import Signal, SignalBroker, SignalClient, PayloadTooLargeError, QueueFullError, QoS, PriorityScheduler

# Config
from .gconfig import (
    gconfig, GConfig,
    ConfigError, ConfigFileNotFoundError, ConfigPathNotFoundError,
    ConfigLockTimeoutError, ConfigValidationError, ConfigParseError,
    ConfigIntegrityError, ConfigSecurityError, ConfigStaleLockError,
    ConfigMandatoryFieldError, ConfigRecoveryError,
)

# Error
from .task_error import (
    AlaskaError, TaskNotFoundError, SmBlockNotFoundError,
    RmiTimeoutError, TaskRemovedError, InjectionError,
    InvokeDeadlockError, CircularRmiError,
    task_not_found_error, smblock_not_found_error, rmi_timeout_error,
    pickle_error, config_mandatory_field_error,
)

# Log
from .task_log import LogRecord, RmiLogger, LogTask

# Log Handler
from ._log_handler import (
    SafeRotatingFileHandler, QueueFileHandler, QueueFileListener,
    create_safe_file_handler, setup_safe_logging,
)

# Performance
from .task_performance import (
    MethodPerformance, TaskPerformance, SystemPerformance,
    TimingRecorder, PerformanceCollector,
)

# Profiler
from .task_profiler import task_profiler, TaskProfiler, LapRecord

# Banner
from ._banner import banner

__all__ = [
    # Task Manager
    "TaskManager", "TaskInfo", "TaskRuntime",
    # RMI & Client
    "RmiClient", "DirectClient",
    # Task Decorators & Validation
    "rmi_run", "rmi_signal", "task", "rmi_task", "has_run_flag",
    "get_signal_handlers", "get_rmi_signal_forward", "TaskValidator",
    "_DEFAULT_RESTART_DELAY",
    # Signal
    "Signal", "SignalBroker", "SignalClient", "PayloadTooLargeError", "QueueFullError", "QoS", "PriorityScheduler",
    # Config
    "gconfig", "GConfig",
    "ConfigError", "ConfigFileNotFoundError", "ConfigPathNotFoundError",
    "ConfigLockTimeoutError", "ConfigValidationError", "ConfigParseError",
    "ConfigIntegrityError", "ConfigSecurityError", "ConfigStaleLockError",
    "ConfigMandatoryFieldError", "ConfigRecoveryError",
    # Error
    "AlaskaError", "TaskNotFoundError", "SmBlockNotFoundError",
    "RmiTimeoutError", "TaskRemovedError", "InjectionError",
    "InvokeDeadlockError", "CircularRmiError",
    "task_not_found_error", "smblock_not_found_error", "rmi_timeout_error",
    "pickle_error", "config_mandatory_field_error",
    # Log
    "LogRecord", "RmiLogger", "LogTask",
    # Log Handler
    "SafeRotatingFileHandler", "QueueFileHandler", "QueueFileListener",
    "create_safe_file_handler", "setup_safe_logging",
    # Performance
    "MethodPerformance", "TaskPerformance", "SystemPerformance",
    "TimingRecorder", "PerformanceCollector",
    # Profiler
    "task_profiler", "TaskProfiler", "LapRecord",
    # Banner
    "banner",
]
