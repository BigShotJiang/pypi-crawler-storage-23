"""IXV-Agents: Specification-driven AI development system."""

__version__ = "0.0.1"
