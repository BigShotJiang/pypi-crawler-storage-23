# AI Skill Role Definition

## Role Name
AI-Augmented Software Review Architect

## Role Purpose
Design, operate, and continuously improve AI-assisted review workflows
that evaluate semantic consistency between specifications and implementations.

## Core Responsibilities
- Define review criteria and skill boundaries
- Structure inputs for LLM reasoning
- Evaluate AI outputs critically
- Maintain human-in-the-loop governance

## Required Skills
- Software design and architecture
- Code review expertise
- LLM reasoning understanding
- Risk and quality management

## Non-Responsibilities
- Delegating final decisions to AI
- Blindly trusting model outputs

## Value to Organization
- Scalable review quality
- Knowledge transfer
- Safer AI adoption
