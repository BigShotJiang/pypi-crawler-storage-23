# Review Criteria

Use these criteria to evaluate the consistency between specifications and code.

## 1. Functional Coverage
- Does the code implement every "Shall" or "Must" statement in the spec?
- Are all functional requirements addressed?

## 2. Interface Consistency
- Do API endpoints match the spec?
- Are function parameters and return types as defined?

## 3. Business Logic Accuracy
- Are calculations performed according to the formulas in the spec?
- Are state transitions enforced as described?

## 4. Edge Case Handling
- Are error conditions mentioned in the spec handled in the code?
- Is there validation for all input constraints?
