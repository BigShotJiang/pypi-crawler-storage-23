# Anthropic Skill Taxonomy Mapping

## Skill Category
Human-in-the-loop Workflow Reasoning Skill

## Mapping Table
- Reasoning Skill: Semantic comparison between spec and code
- Workflow Skill: Structured review pipeline
- Human-in-the-loop: Human final judgment
- Transferable Skill: Applicable across projects and domains
- Tool-independent: LLM and tool agnostic

## Official Description
This skill represents a human-in-the-loop reasoning workflow where LLMs
surface semantic inconsistencies while humans retain responsibility.
