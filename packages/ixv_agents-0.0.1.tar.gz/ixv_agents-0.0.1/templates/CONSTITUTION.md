<!--
IMPORTANT:
This file is a project Ccnstitution.
Do NOT modify this file unless explicitly instructed.
-->

# プロジェクト憲章（Constitution）

## 1. 存在意義（Purpose）
- このプロジェクトが存在する理由を明記する

## 2. 基本原則（4つの原則）
1. 仕様は「生きたドキュメント」である
2. 仕様は「信頼できる唯一の情報源」とする
3. 仕様は「変更と反復が前提」とする
4. AIでコストを抑えて実現する（人間が最終判断）

## 3. 変更禁止の範囲（非交渉事項）
- この憲章は例外的事情を除き変更しない
- 変更する場合はPOが指示し、SMが実行、人間（ユーザー）が最終承認

## 4. セキュリティと品質
- 仕様とコードの整合性を常に確認
- AI出力は必ず人間がレビュー
