"""Unit tests for model classes."""
