"""DevRev MCP Server - Model Context Protocol server for the DevRev platform."""

from __future__ import annotations

__version__ = __import__("importlib.metadata", fromlist=["version"]).version("devrev-Python-SDK")
