def read_file(file_path):
    with open(file_path, "r") as in_stream:
        return in_stream.read()