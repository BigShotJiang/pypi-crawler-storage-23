class AbstractMinIriStrategy(object):

    def annotate_shape_iri(self, shape):
        raise NotImplementedError()