def reverse_keys_and_values(target_dict):
    return {y: x for x, y in target_dict.items()}
