class ParseError(Exception):
    pass