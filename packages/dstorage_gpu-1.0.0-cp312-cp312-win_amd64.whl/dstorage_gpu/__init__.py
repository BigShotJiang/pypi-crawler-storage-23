"""
dstorage_gpu — Fast GPU tensor loading via DirectStorage on Windows.

Loads binary files directly from NVMe into GPU VRAM via DirectStorage +
D3D12-CUDA interop. No CPU RAM is involved in the data transfer path.

Usage:
    from dstorage_gpu import DirectStorageLoader

    loader = DirectStorageLoader()
    tensor = loader.load_tensor("weights.bin", num_elements=131072000)

    # Batch load (single DirectStorage submit + fence):
    tensors = loader.load_tensors([("f1.bin", n1), ("f2.bin", n2)])

    # Convenience function (singleton loader):
    from dstorage_gpu import load_tensor
    tensor = load_tensor("weights.bin", num_elements=131072000)
"""

from dstorage_gpu._loader import DirectStorageLoader, load_tensor

__all__ = ["DirectStorageLoader", "load_tensor"]
__version__ = "1.0.0"
