# dstorage_gpu — DirectStorage GPU-Direct Loader

Loads binary files from NVMe directly into CUDA GPU memory with **no CPU bounce buffer**.

```
NVMe  ->  DirectStorage  ->  D3D12 GPU buffer  ->  CUDA external memory  ->  torch.Tensor
```

## Installation

```powershell
pip install dstorage-gpu
```

Or from source:
```powershell
pip install -e .
```

## Python API

### DirectStorageLoader

```python
from dstorage_gpu import DirectStorageLoader

loader = DirectStorageLoader()
```

**`load_tensor(filepath, num_elements, dtype=torch.float32, device="cuda")`**
Load a single binary file directly to a CUDA tensor.

```python
tensor = loader.load_tensor("weights.bin", num_elements=131_072_000)
# Returns: torch.Tensor on CUDA, shape [131072000], dtype float32
```

**`load_tensors(file_specs, dtype=torch.float32)`**
Batch-load multiple files with a single DirectStorage submit + fence.

```python
tensors = loader.load_tensors([
    ("layer1.bin", 1_024_000),
    ("layer2.bin", 2_048_000),
    ("layer3.bin", 4_096_000),
])
# Returns: list of torch.Tensor on CUDA
```

**`load_tensor_timed(filepath, num_elements, dtype=torch.float32)`**
Same as load_tensor but returns `(tensor, elapsed_seconds)`.

```python
tensor, elapsed = loader.load_tensor_timed("weights.bin", 131_072_000)
size_gb = 131_072_000 * 4 / 1e9
print(f"{size_gb:.2f} GB in {elapsed:.3f}s = {size_gb/elapsed:.1f} GB/s")
```

### Convenience function

```python
from dstorage_gpu import load_tensor

# Uses a singleton DirectStorageLoader
tensor = load_tensor("weights.bin", num_elements=131_072_000)
```

## Suggested Usage Patterns

### Loading model weights

```python
import struct
from dstorage_gpu import DirectStorageLoader

loader = DirectStorageLoader()

# Load a raw float32 weight file
weight_path = "model/layer0_weight.bin"
num_floats = 768 * 3072  # weight matrix dimensions
weight = loader.load_tensor(weight_path, num_floats).reshape(768, 3072)
```

### Batch-loading transformer layers

```python
layer_specs = []
for i in range(12):
    path = f"model/layer{i}.bin"
    num_elements = Path(path).stat().st_size // 4
    layer_specs.append((path, num_elements))

# Single DirectStorage submit for all 12 layers
layers = loader.load_tensors(layer_specs)
```

### Benchmarking your own files

```python
tensor, elapsed = loader.load_tensor_timed("my_weights.bin", num_elements)
size_gb = num_elements * 4 / 1e9
print(f"Throughput: {size_gb / elapsed:.1f} GB/s")
```

## Performance

| File Size | Mean (ms) | GB/s | vs torch.load |
|---|---|---|---|
| 500 MB single | 42 | 11.7 | 16x faster |
| 512 MB batch (8x64 MB) | 54 | 9.4 | 17x faster |

## Key Technical Notes

1. **Buffer alignment**: D3D12 allocates in 64 KB multiples. `GetResourceAllocationInfo.SizeInBytes` (not `num_bytes`) must be passed to CUDA external memory.

2. **`cudaExternalMemoryDedicated` is mandatory** for committed D3D12 resources.

3. **LUID matching**: No `cudaD3D12GetDevice()` exists — compare `cudaDeviceProp::luid` with `DXGI_ADAPTER_DESC1::Luid`.

4. **Close NT handle immediately** after `cudaImportExternalMemory` — CUDA duplicates it internally.

5. **32-bit file size field**: `DSTORAGE_REQUEST::Source.File.Size` is `uint32_t`, capping individual reads at 4 GB. For larger files, use multiple requests with offsets.

## Known Limitations

- Windows only (Linux: use cuFile / GPUDirect Storage)
- Minimum 64 KB buffer allocation (D3D12 alignment)
- D3D12 feature level 12.0 required (NVIDIA Pascal / GTX 10xx and later)
- 4 GB per-request limit (use offsets for larger files)
- CUDA GPU required (no AMD ROCm support yet — see CONTRIBUTING.md)
