"""
DirectStorage GPU-direct Python wrapper.

Loads binary files directly from NVMe into GPU VRAM via DirectStorage +
D3D12-CUDA interop. No CPU RAM is involved in the data transfer path.
"""

import ctypes
import os
import sys
import time
from pathlib import Path

import torch


def _load_native():
    """Import the _native pybind11 extension, loading DLL dependencies first."""
    pkg_dir = Path(__file__).parent

    # Try package-local _native.pyd first (pip-installed wheel)
    native_pyd = pkg_dir / "_native.pyd"
    if native_pyd.exists():
        os.add_dll_directory(str(pkg_dir))
        for dep in ("dstoragecore.dll", "dstorage.dll"):
            dep_path = pkg_dir / dep
            if dep_path.exists():
                ctypes.WinDLL(str(dep_path))
        from dstorage_gpu import _native
        return _native

    # Fallback: development build directory
    for build_dir in [
        pkg_dir / "build" / "Release",           # dstorage_gpu/build/Release
        pkg_dir.parent / "build" / "Release",     # repo/build/Release
    ]:
        pyd_path = build_dir / "_native.pyd"
        if pyd_path.exists():
            os.add_dll_directory(str(build_dir))
            sys.path.insert(0, str(build_dir))
            for dep in ("dstoragecore.dll", "dstorage.dll"):
                dep_path = build_dir / dep
                if dep_path.exists():
                    ctypes.WinDLL(str(dep_path))
            import _native  # type: ignore
            return _native

    raise ImportError(
        "Could not find _native.pyd. Either:\n"
        "  1. pip install dstorage-gpu  (pre-built wheel)\n"
        "  2. Build from source:\n"
        "     cmake -B build -DDIRECTSTORAGE_PATH=$env:DIRECTSTORAGE_PATH\n"
        "     cmake --build build --config Release"
    )


class DirectStorageLoader:
    """
    GPU-direct file loader using DirectStorage + D3D12-CUDA interop.

    Data path: NVMe -> D3D12 GPU buffer -> CUDA external memory -> tensor
    """

    def __init__(self):
        self._ext = _load_native()
        self._cudart = None

        # Create persistent C++ instance (caches D3D12/DS objects)
        self._gpu = self._ext.DirectStorageGPU()

        info = self._ext.get_cuda_device_info()
        print(
            f"[DirectStorage] GPU-direct loader ready\n"
            f"  GPU  : {info['name']}\n"
            f"  VRAM : {info['total_memory'] / 1e9:.1f} GB\n"
            f"  LUID : {info['luid']}"
        )

    def _ensure_cudart(self):
        if self._cudart is None:
            torch_lib = Path(torch.__file__).parent / "lib"
            cudart_paths = list(torch_lib.glob("cudart64_*.dll"))
            if not cudart_paths:
                cudart_paths = list(torch_lib.glob("cudart*.dll"))
            if not cudart_paths:
                raise FileNotFoundError("cudart64_*.dll not found in PyTorch lib dir")
            self._cudart = ctypes.CDLL(str(cudart_paths[0]))
            self._cudart.cudaMemcpy.argtypes = [
                ctypes.c_void_p, ctypes.c_void_p,
                ctypes.c_size_t, ctypes.c_int
            ]
            self._cudart.cudaMemcpy.restype = ctypes.c_int

    def _d2d_copy(self, src_ptr_int, num_bytes, num_elements, dtype):
        """cudaMemcpy D2D from DirectStorage buffer to new PyTorch tensor."""
        tensor = torch.empty(num_elements, dtype=dtype, device="cuda")
        self._ensure_cudart()
        # cudaMemcpyDeviceToDevice = 3
        err = self._cudart.cudaMemcpy(tensor.data_ptr(), src_ptr_int, num_bytes, 3)
        if err != 0:
            raise RuntimeError(f"cudaMemcpy D2D failed: error {err}")
        return tensor

    def load_tensor(
        self,
        filepath: str | Path,
        num_elements: int,
        dtype: torch.dtype = torch.float32,
        device: str = "cuda",
    ) -> torch.Tensor:
        """
        Load a flat binary file directly to a CUDA tensor (no CPU copy).

        Args:
            filepath: Path to raw binary file (e.g. float32 weights).
            num_elements: Number of elements in the file.
            dtype: PyTorch dtype (default: torch.float32).
            device: Must be "cuda" (GPU-direct only).

        Returns:
            torch.Tensor on CUDA device.
        """
        if device != "cuda":
            raise ValueError("DirectStorage GPU-direct requires device='cuda'.")
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is not available.")

        elem_size = torch.empty(1, dtype=dtype).element_size()
        num_bytes = num_elements * elem_size
        filepath = str(Path(filepath).resolve())

        ptr_int, ext_mem_token, actual_bytes = self._gpu.load_to_gpu(filepath, num_bytes)

        try:
            tensor = self._d2d_copy(ptr_int, num_bytes, num_elements, dtype)
        finally:
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            self._ext.free_gpu_buffer(ext_mem_token)

        return tensor

    def load_tensors(
        self,
        file_specs: list[tuple[str | Path, int]],
        dtype: torch.dtype = torch.float32,
    ) -> list[torch.Tensor]:
        """
        Batch-load multiple files with a single DirectStorage submit + fence.

        Args:
            file_specs: List of (filepath, num_elements) tuples.
            dtype: PyTorch dtype (default: torch.float32).

        Returns:
            List of torch.Tensor on CUDA device.
        """
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is not available.")

        elem_size = torch.empty(1, dtype=dtype).element_size()
        filepaths = [str(Path(fp).resolve()) for fp, _ in file_specs]
        byte_sizes = [n_elem * elem_size for _, n_elem in file_specs]

        results = self._gpu.load_batch(filepaths, byte_sizes)

        tensors = []
        tokens = []
        try:
            for i, (ptr_int, ext_mem_token, actual_bytes) in enumerate(results):
                tokens.append(ext_mem_token)
                n_elem = file_specs[i][1]
                nb = n_elem * elem_size
                tensors.append(self._d2d_copy(ptr_int, nb, n_elem, dtype))
        finally:
            torch.cuda.synchronize()
            for token in tokens:
                self._ext.free_gpu_buffer(token)

        return tensors

    def load_tensor_timed(
        self,
        filepath: str | Path,
        num_elements: int,
        dtype: torch.dtype = torch.float32,
    ) -> tuple[torch.Tensor, float]:
        """Same as load_tensor but returns (tensor, total_time_s)."""
        elem_size = torch.empty(1, dtype=dtype).element_size()
        num_bytes = num_elements * elem_size
        filepath  = str(Path(filepath).resolve())

        torch.cuda.synchronize()
        t0 = time.perf_counter()

        ptr_int, ext_mem_token, _ = self._gpu.load_to_gpu(filepath, num_bytes)
        tensor = self._d2d_copy(ptr_int, num_bytes, num_elements, dtype)

        torch.cuda.synchronize()
        t1 = time.perf_counter()

        self._ext.free_gpu_buffer(ext_mem_token)

        return tensor, t1 - t0


# ── Convenience function ──────────────────────────────────────────────────────

_default_loader: DirectStorageLoader | None = None


def load_tensor(
    filepath: str | Path,
    num_elements: int,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """Module-level convenience function with singleton loader."""
    global _default_loader
    if _default_loader is None:
        _default_loader = DirectStorageLoader()
    return _default_loader.load_tensor(filepath, num_elements, dtype)
