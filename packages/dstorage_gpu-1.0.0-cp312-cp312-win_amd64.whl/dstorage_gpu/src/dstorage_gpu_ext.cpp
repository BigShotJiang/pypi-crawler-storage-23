/**
 * dstorage_gpu_ext.cpp — DirectStorage GPU-direct path
 *
 * Loads binary files directly from NVMe into GPU VRAM via DirectStorage +
 * D3D12 + CUDA external memory interop. No CPU RAM is involved.
 *
 * DirectStorageGPU class caches DXGI factory, D3D12 device, DS factory,
 * and DS queue — created once in the constructor, reused for all loads.
 *
 * Build: CMakeLists.txt in parent directory
 * Links: dstorage.lib, d3d12.lib, dxgi.lib, CUDA::cudart, CUDA::cuda_driver
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <dstorage.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <wrl/client.h>
#include <cuda_runtime.h>

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>

namespace py = pybind11;
using Microsoft::WRL::ComPtr;

// ── Error helpers ─────────────────────────────────────────────────────────────

static void ThrowHR(HRESULT hr, const char* context)
{
    if (FAILED(hr)) {
        char buf[256];
        snprintf(buf, sizeof(buf), "%s failed (HRESULT 0x%08X)", context, (unsigned)hr);
        throw std::runtime_error(buf);
    }
}

static void ThrowCuda(cudaError_t err, const char* context)
{
    if (err != cudaSuccess) {
        char buf[256];
        snprintf(buf, sizeof(buf), "%s: %s (%s)",
                 context, cudaGetErrorName(err), cudaGetErrorString(err));
        throw std::runtime_error(buf);
    }
}

// ── LUID matching ─────────────────────────────────────────────────────────────

static int FindCudaDeviceByLuid(LUID targetLuid)
{
    int deviceCount = 0;
    cudaGetDeviceCount(&deviceCount);

    for (int i = 0; i < deviceCount; i++) {
        cudaDeviceProp prop = {};
        cudaGetDeviceProperties(&prop, i);

        LUID deviceLuid;
        static_assert(sizeof(deviceLuid) == 8, "LUID must be 8 bytes");
        memcpy(&deviceLuid, prop.luid, sizeof(LUID));

        if (deviceLuid.LowPart  == targetLuid.LowPart &&
            deviceLuid.HighPart == targetLuid.HighPart)
        {
            return i;
        }
    }
    return -1;
}

// ── DirectStorageGPU class ────────────────────────────────────────────────────

class DirectStorageGPU {
public:
    DirectStorageGPU()
    {
        HRESULT hr = S_OK;

        // Configure: enable bypass-IO (both FALSE = default)
        {
            DSTORAGE_CONFIGURATION1 cfg = {};
            cfg.DisableBypassIO    = FALSE;
            cfg.ForceFileBuffering = FALSE;
            DStorageSetConfiguration1(&cfg);
        }

        // DXGI factory + adapter matching
        hr = CreateDXGIFactory1(IID_PPV_ARGS(&m_dxgiFactory));
        ThrowHR(hr, "CreateDXGIFactory1");

        int cudaDevice = 0;
        cudaDeviceProp cudaProp = {};
        ThrowCuda(cudaGetDeviceProperties(&cudaProp, cudaDevice), "cudaGetDeviceProperties");

        LUID cudaLuid;
        memcpy(&cudaLuid, cudaProp.luid, sizeof(LUID));

        ComPtr<IDXGIAdapter1> adapter;
        for (UINT i = 0; m_dxgiFactory->EnumAdapters1(i, &adapter) != DXGI_ERROR_NOT_FOUND; i++) {
            DXGI_ADAPTER_DESC1 desc;
            adapter->GetDesc1(&desc);
            if (desc.AdapterLuid.LowPart  == cudaLuid.LowPart &&
                desc.AdapterLuid.HighPart == cudaLuid.HighPart)
            {
                m_adapter = adapter;
                break;
            }
            adapter = nullptr;
        }

        if (!m_adapter) {
            m_dxgiFactory->EnumAdapters1(0, &m_adapter);
            py::print("[DirectStorage] WARNING: No LUID match found. Using default adapter.");
        }

        // D3D12 device
        hr = D3D12CreateDevice(m_adapter.Get(), D3D_FEATURE_LEVEL_12_0,
                               IID_PPV_ARGS(&m_d3dDevice));
        ThrowHR(hr, "D3D12CreateDevice");

        // DirectStorage factory + queue
        hr = DStorageGetFactory(IID_PPV_ARGS(&m_dsFactory));
        ThrowHR(hr, "DStorageGetFactory");

        m_dsFactory->SetStagingBufferSize(32 * 1024 * 1024);

        DSTORAGE_QUEUE_DESC queueDesc = {};
        queueDesc.Capacity   = DSTORAGE_MAX_QUEUE_CAPACITY;
        queueDesc.Priority   = DSTORAGE_PRIORITY_NORMAL;
        queueDesc.SourceType = DSTORAGE_REQUEST_SOURCE_FILE;
        queueDesc.Device     = m_d3dDevice.Get();

        hr = m_dsFactory->CreateQueue(&queueDesc, IID_PPV_ARGS(&m_dsQueue));
        ThrowHR(hr, "IDStorageFactory::CreateQueue (GPU)");
    }

    /**
     * load_to_gpu(filepath, num_bytes) -> (device_ptr_int, ext_mem_token, actual_bytes)
     */
    py::tuple load_to_gpu(const std::string& filepath, uint64_t num_bytes)
    {
        HRESULT hr = S_OK;

        // Open file
        std::wstring wpath(filepath.begin(), filepath.end());
        ComPtr<IDStorageFile> dsFile;
        hr = m_dsFactory->OpenFile(wpath.c_str(), IID_PPV_ARGS(&dsFile));
        ThrowHR(hr, "IDStorageFactory::OpenFile");

        // Create D3D12 shared buffer
        D3D12_RESOURCE_DESC bufDesc = {};
        bufDesc.Dimension          = D3D12_RESOURCE_DIMENSION_BUFFER;
        bufDesc.Alignment          = 0;
        bufDesc.Width              = num_bytes;
        bufDesc.Height             = 1;
        bufDesc.DepthOrArraySize   = 1;
        bufDesc.MipLevels          = 1;
        bufDesc.Format             = DXGI_FORMAT_UNKNOWN;
        bufDesc.SampleDesc.Count   = 1;
        bufDesc.SampleDesc.Quality = 0;
        bufDesc.Layout             = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
        bufDesc.Flags              = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;

        D3D12_RESOURCE_ALLOCATION_INFO allocInfo =
            m_d3dDevice->GetResourceAllocationInfo(0, 1, &bufDesc);
        uint64_t actualBytes = allocInfo.SizeInBytes;

        D3D12_HEAP_PROPERTIES heapProps = {};
        heapProps.Type                 = D3D12_HEAP_TYPE_DEFAULT;
        heapProps.CPUPageProperty      = D3D12_CPU_PAGE_PROPERTY_UNKNOWN;
        heapProps.MemoryPoolPreference = D3D12_MEMORY_POOL_UNKNOWN;

        ComPtr<ID3D12Resource> d3dBuffer;
        hr = m_d3dDevice->CreateCommittedResource(
            &heapProps,
            D3D12_HEAP_FLAG_SHARED,
            &bufDesc,
            D3D12_RESOURCE_STATE_COMMON,
            nullptr,
            IID_PPV_ARGS(&d3dBuffer));
        ThrowHR(hr, "ID3D12Device::CreateCommittedResource (shared buffer)");

        // Enqueue DirectStorage request
        DSTORAGE_REQUEST req = {};
        req.Options.SourceType        = DSTORAGE_REQUEST_SOURCE_FILE;
        req.Options.DestinationType   = DSTORAGE_REQUEST_DESTINATION_BUFFER;
        req.Options.CompressionFormat = DSTORAGE_COMPRESSION_FORMAT_NONE;
        req.Source.File.Source        = dsFile.Get();
        req.Source.File.Offset        = 0;
        req.Source.File.Size          = (uint32_t)num_bytes;
        req.UncompressedSize          = (uint32_t)num_bytes;
        req.Destination.Buffer.Resource = d3dBuffer.Get();
        req.Destination.Buffer.Offset   = 0;
        req.Destination.Buffer.Size     = (uint32_t)num_bytes;
        m_dsQueue->EnqueueRequest(&req);

        // Fence wait
        ComPtr<ID3D12Fence> fence;
        hr = m_d3dDevice->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence));
        ThrowHR(hr, "ID3D12Device::CreateFence");

        HANDLE fenceEvent = CreateEvent(nullptr, FALSE, FALSE, nullptr);
        if (!fenceEvent) ThrowHR(HRESULT_FROM_WIN32(GetLastError()), "CreateEvent");

        hr = fence->SetEventOnCompletion(1, fenceEvent);
        ThrowHR(hr, "ID3D12Fence::SetEventOnCompletion");

        m_dsQueue->EnqueueSignal(fence.Get(), 1);
        m_dsQueue->Submit();

        DWORD waitResult = WaitForSingleObject(fenceEvent, 30000);
        CloseHandle(fenceEvent);

        if (waitResult == WAIT_TIMEOUT)
            throw std::runtime_error("DirectStorage GPU request timed out after 30 s");
        if (waitResult != WAIT_OBJECT_0)
            throw std::runtime_error("WaitForSingleObject failed for DirectStorage fence");

        // CUDA import
        HANDLE sharedHandle = nullptr;
        hr = m_d3dDevice->CreateSharedHandle(
            d3dBuffer.Get(), nullptr, GENERIC_ALL, nullptr, &sharedHandle);
        ThrowHR(hr, "ID3D12Device::CreateSharedHandle");

        cudaExternalMemoryHandleDesc extMemDesc = {};
        extMemDesc.type                  = cudaExternalMemoryHandleTypeD3D12Resource;
        extMemDesc.handle.win32.handle   = sharedHandle;
        extMemDesc.size                  = actualBytes;
        extMemDesc.flags                 = cudaExternalMemoryDedicated;

        cudaExternalMemory_t extMem = nullptr;
        ThrowCuda(cudaImportExternalMemory(&extMem, &extMemDesc),
                  "cudaImportExternalMemory");

        CloseHandle(sharedHandle);

        cudaExternalMemoryBufferDesc cudaBufDesc = {};
        cudaBufDesc.offset = 0;
        cudaBufDesc.size   = actualBytes;
        cudaBufDesc.flags  = 0;

        void* devPtr = nullptr;
        ThrowCuda(cudaExternalMemoryGetMappedBuffer(&devPtr, extMem, &cudaBufDesc),
                  "cudaExternalMemoryGetMappedBuffer");

        uint64_t ptrInt      = reinterpret_cast<uint64_t>(devPtr);
        uint64_t extMemToken = reinterpret_cast<uint64_t>(extMem);

        return py::make_tuple(ptrInt, extMemToken, actualBytes);
    }

    /**
     * load_batch(filepaths, byte_sizes) -> list of (device_ptr_int, ext_mem_token, actual_bytes)
     *
     * Loads multiple files with a shared fence for all requests.
     */
    std::vector<py::tuple> load_batch(
        const std::vector<std::string>& filepaths,
        const std::vector<uint64_t>& byte_sizes)
    {
        if (filepaths.size() != byte_sizes.size())
            throw std::invalid_argument("filepaths and byte_sizes must have same length");

        size_t count = filepaths.size();
        HRESULT hr = S_OK;

        // Per-file state
        struct FileState {
            ComPtr<IDStorageFile> dsFile;
            ComPtr<ID3D12Resource> d3dBuffer;
            uint64_t actualBytes;
        };
        std::vector<FileState> states(count);

        // Open files, create buffers, enqueue
        for (size_t i = 0; i < count; i++) {
            auto& s = states[i];
            std::wstring wpath(filepaths[i].begin(), filepaths[i].end());

            hr = m_dsFactory->OpenFile(wpath.c_str(), IID_PPV_ARGS(&s.dsFile));
            ThrowHR(hr, "IDStorageFactory::OpenFile (batch)");

            D3D12_RESOURCE_DESC bufDesc = {};
            bufDesc.Dimension          = D3D12_RESOURCE_DIMENSION_BUFFER;
            bufDesc.Width              = byte_sizes[i];
            bufDesc.Height             = 1;
            bufDesc.DepthOrArraySize   = 1;
            bufDesc.MipLevels          = 1;
            bufDesc.Format             = DXGI_FORMAT_UNKNOWN;
            bufDesc.SampleDesc.Count   = 1;
            bufDesc.Layout             = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
            bufDesc.Flags              = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;

            D3D12_RESOURCE_ALLOCATION_INFO allocInfo =
                m_d3dDevice->GetResourceAllocationInfo(0, 1, &bufDesc);
            s.actualBytes = allocInfo.SizeInBytes;

            D3D12_HEAP_PROPERTIES heapProps = {};
            heapProps.Type = D3D12_HEAP_TYPE_DEFAULT;

            hr = m_d3dDevice->CreateCommittedResource(
                &heapProps, D3D12_HEAP_FLAG_SHARED, &bufDesc,
                D3D12_RESOURCE_STATE_COMMON, nullptr,
                IID_PPV_ARGS(&s.d3dBuffer));
            ThrowHR(hr, "CreateCommittedResource (batch)");

            DSTORAGE_REQUEST req = {};
            req.Options.SourceType        = DSTORAGE_REQUEST_SOURCE_FILE;
            req.Options.DestinationType   = DSTORAGE_REQUEST_DESTINATION_BUFFER;
            req.Options.CompressionFormat = DSTORAGE_COMPRESSION_FORMAT_NONE;
            req.Source.File.Source        = s.dsFile.Get();
            req.Source.File.Offset        = 0;
            req.Source.File.Size          = (uint32_t)byte_sizes[i];
            req.UncompressedSize          = (uint32_t)byte_sizes[i];
            req.Destination.Buffer.Resource = s.d3dBuffer.Get();
            req.Destination.Buffer.Offset   = 0;
            req.Destination.Buffer.Size     = (uint32_t)byte_sizes[i];

            m_dsQueue->EnqueueRequest(&req);
        }

        // Single fence for all
        ComPtr<ID3D12Fence> fence;
        hr = m_d3dDevice->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence));
        ThrowHR(hr, "CreateFence (batch)");

        HANDLE fenceEvent = CreateEvent(nullptr, FALSE, FALSE, nullptr);
        if (!fenceEvent) ThrowHR(HRESULT_FROM_WIN32(GetLastError()), "CreateEvent");
        fence->SetEventOnCompletion(1, fenceEvent);

        m_dsQueue->EnqueueSignal(fence.Get(), 1);
        m_dsQueue->Submit();

        DWORD waitResult = WaitForSingleObject(fenceEvent, 60000);
        CloseHandle(fenceEvent);

        if (waitResult == WAIT_TIMEOUT)
            throw std::runtime_error("Batch GPU load timed out after 60 s");
        if (waitResult != WAIT_OBJECT_0)
            throw std::runtime_error("WaitForSingleObject failed (batch)");

        // CUDA import for each buffer
        std::vector<py::tuple> results;
        results.reserve(count);

        for (size_t i = 0; i < count; i++) {
            auto& s = states[i];

            HANDLE sharedHandle = nullptr;
            hr = m_d3dDevice->CreateSharedHandle(
                s.d3dBuffer.Get(), nullptr, GENERIC_ALL, nullptr, &sharedHandle);
            ThrowHR(hr, "CreateSharedHandle (batch)");

            cudaExternalMemoryHandleDesc extMemDesc = {};
            extMemDesc.type                = cudaExternalMemoryHandleTypeD3D12Resource;
            extMemDesc.handle.win32.handle = sharedHandle;
            extMemDesc.size                = s.actualBytes;
            extMemDesc.flags               = cudaExternalMemoryDedicated;

            cudaExternalMemory_t extMem = nullptr;
            ThrowCuda(cudaImportExternalMemory(&extMem, &extMemDesc),
                      "cudaImportExternalMemory (batch)");
            CloseHandle(sharedHandle);

            cudaExternalMemoryBufferDesc cudaBufDesc = {};
            cudaBufDesc.offset = 0;
            cudaBufDesc.size   = s.actualBytes;
            cudaBufDesc.flags  = 0;

            void* devPtr = nullptr;
            ThrowCuda(cudaExternalMemoryGetMappedBuffer(&devPtr, extMem, &cudaBufDesc),
                      "cudaExternalMemoryGetMappedBuffer (batch)");

            results.push_back(py::make_tuple(
                reinterpret_cast<uint64_t>(devPtr),
                reinterpret_cast<uint64_t>(extMem),
                s.actualBytes));
        }

        return results;
    }

private:
    ComPtr<IDXGIFactory4>      m_dxgiFactory;
    ComPtr<IDXGIAdapter1>      m_adapter;
    ComPtr<ID3D12Device>       m_d3dDevice;
    ComPtr<IDStorageFactory>   m_dsFactory;
    ComPtr<IDStorageQueue>     m_dsQueue;
};

// ── Free function (works with any instance) ──────────────────────────────────

void free_gpu_buffer(uint64_t extMemToken)
{
    if (extMemToken == 0) return;
    auto extMem = reinterpret_cast<cudaExternalMemory_t>(extMemToken);
    cudaError_t err = cudaDestroyExternalMemory(extMem);
    if (err != cudaSuccess) {
        py::print("[DirectStorage] WARNING: cudaDestroyExternalMemory:", cudaGetErrorString(err));
    }
}

py::dict get_cuda_device_info()
{
    int device = 0;
    cudaDeviceProp prop = {};
    cudaGetDeviceProperties(&prop, device);

    char luidHex[32];
    LUID luid;
    memcpy(&luid, prop.luid, sizeof(LUID));
    snprintf(luidHex, sizeof(luidHex), "0x%08X%08X",
             (unsigned)luid.HighPart, (unsigned)luid.LowPart);

    py::dict info;
    info["name"]         = std::string(prop.name);
    info["total_memory"] = (uint64_t)prop.totalGlobalMem;
    info["luid"]         = std::string(luidHex);
    info["cuda_device"]  = device;
    return info;
}

// ── Module-level default instance for backward compat ─────────────────────────

static std::unique_ptr<DirectStorageGPU> g_default;

static DirectStorageGPU& get_default()
{
    if (!g_default) {
        g_default = std::make_unique<DirectStorageGPU>();
    }
    return *g_default;
}

static py::tuple compat_load_to_gpu(const std::string& filepath, uint64_t num_bytes)
{
    return get_default().load_to_gpu(filepath, num_bytes);
}

// ── pybind11 module ────────────────────────────────────────────────────────────

PYBIND11_MODULE(_native, m)
{
    m.doc() = R"doc(
DirectStorage GPU-direct loader.

Loads binary files directly from NVMe into CUDA GPU memory via:
  NVMe -> DirectStorage -> D3D12 GPU buffer -> CUDA external memory -> device pointer

No CPU RAM is involved in the data path.

Classes:
    DirectStorageGPU  — persistent instance with cached D3D12/DS objects

Functions:
    load_to_gpu(filepath, num_bytes) -> (device_ptr_int, ext_mem_token, actual_bytes)
    free_gpu_buffer(ext_mem_token)
    get_cuda_device_info() -> dict
)doc";

    py::class_<DirectStorageGPU>(m, "DirectStorageGPU")
        .def(py::init<>())
        .def("load_to_gpu", &DirectStorageGPU::load_to_gpu,
             py::arg("filepath"), py::arg("num_bytes"))
        .def("load_batch", &DirectStorageGPU::load_batch,
             py::arg("filepaths"), py::arg("byte_sizes"));

    m.def("load_to_gpu", &compat_load_to_gpu,
          py::arg("filepath"), py::arg("num_bytes"),
          "Load num_bytes from filepath directly to GPU (uses default cached instance).");

    m.def("free_gpu_buffer", &free_gpu_buffer,
          py::arg("ext_mem_token"),
          "Free CUDA external memory allocated by load_to_gpu. Call after tensor.clone().");

    m.def("get_cuda_device_info", &get_cuda_device_info,
          "Return dict with CUDA device name, total memory, LUID, and device index.");
}
