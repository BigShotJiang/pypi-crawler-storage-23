type HookObject = dict # TODO: Change to TypedDict

type HooksList = list[HookObject | str]