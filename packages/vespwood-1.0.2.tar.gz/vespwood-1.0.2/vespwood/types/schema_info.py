type SchemaObject = dict # TODO: Change to TypedDict

type SchemaInfo = SchemaObject | str