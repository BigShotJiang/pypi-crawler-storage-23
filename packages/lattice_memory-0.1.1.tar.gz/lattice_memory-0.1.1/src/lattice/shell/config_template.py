"""
Configuration template for Lattice.

This module provides the default config.toml template with all configurable
options and their documentation.
"""

CONFIG_TEMPLATE = """# Lattice Configuration
# https://github.com/tefx/lattice
#
# This file configures the Lattice memory system for AI agents.
# All sections are optional - Lattice will use sensible defaults.
#
# Quick Start:
#   1. Run `lattice auth login openai` to save your API key securely
#   2. Set your model below (no need to add api_key - it's automatic!)
#   3. Run `lattice evolve` to extract rules from conversations

# =============================================================================
# Compiler Configuration
# =============================================================================
# The Compiler uses an LLM to extract patterns from conversation logs
# and generate rules. This is the core of Lattice's "evolution" feature.
#
# Model format: Use litellm format "provider/model"
# Examples:
#   - "openai/gpt-4o"           # OpenAI
#   - "openrouter/openai/gpt-5-mini"  # OpenRouter
#   - "anthropic/claude-3-5-sonnet"   # Anthropic
#   - "ollama/llama3.2:3b"     # Local Ollama
#
# API Key Resolution Priority:
#   1. api_key / api_key_env in this file
#   2. auth.json (use `lattice auth login <provider>`)
#   3. Environment variable (e.g., OPENAI_API_KEY)
#   4. LiteLLM defaults

[compiler]
# Required: LLM model for the Compiler
model = "openai/gpt-5-mini"

# Optional: API key (use `lattice auth login` instead for secure storage)
# api_key = "sk-..."                    # Direct key (not recommended)
# api_key = "{auth:openai}"             # Use auth.json (recommended)
# api_key = "{env:OPENAI_API_KEY}"      # Use environment variable
# api_key = "{file:~/.secrets/openai}"  # Read from file

# Optional: Environment variable for API key
# api_key_env = "OPENAI_API_KEY"

# Optional: Batch size for rule processing (default: 30)
# Higher values = faster but more tokens per request
# batch_cap = 30

# Optional: Custom prompt template (advanced)
# prompt_template = "~/.config/lattice/custom_prompt.md"

# =============================================================================
# Embedding Configuration (Optional)
# =============================================================================
# Enable vector search for semantic similarity.
# When configured, Lattice uses hybrid search (FTS5 + vector).
# When not configured, Lattice uses FTS5-only (keyword search).
#
# For most users, this is optional. Enable it if you need:
#   - Semantic search across conversations
#   - Better context retrieval for similar topics

# [embedding]
# model = "openai/text-embedding-3-small"
# dimensions = 1536
# api_key = "{auth:openai}"             # Or use auth.json

# Local Ollama example (zero cost!):
# [embedding]
# model = "ollama/nomic-embed-text"
# dimensions = 768

# =============================================================================
# Token Thresholds Configuration
# =============================================================================
# Control token usage warnings and limits.
# These help prevent runaway token consumption.

[thresholds]
# Warn when session approaches limit (default: 3000)
warn_tokens = 3000

# Alert when session hits limit (default: 5000)
alert_tokens = 5000

# Maximum tokens per session before eviction (default: 4000)
# Sessions exceeding this are marked for Layer 1 summarization
per_session_tokens = 4000

# =============================================================================
# Safety Configuration
# =============================================================================
# Control rule application behavior and security settings.

[safety]
# Auto-apply generated rules without confirmation (default: false)
# DANGER: Only enable in trusted environments
auto_apply = false

# Number of rule backups to keep (default: 10)
backup_keep = 10

# Regex patterns to detect and sanitize secrets in logs
# These patterns are matched against all logged content
# Note: In TOML strings, backslashes must be escaped (\\\\s for regex \\s)
secret_patterns = [
    "(?i)api[_-]?key",            # api_key, API_KEY, api-key
    "(?i)secret[_-]?key",         # secret_key, SECRET_KEY
    "(?i)auth[_-]?token",         # auth_token, AUTH_TOKEN
    "(?i)bearer\\\\s+[a-z0-9_-]+",  # Bearer tokens
    "sk-[a-zA-Z0-9]{20,}",        # OpenAI-style keys
    "xox[baprs]-[a-zA-Z0-9-]+",   # Slack tokens
]

# =============================================================================
# Capture Configuration
# =============================================================================
# Control how Lattice captures conversation data.
#
# Mode options:
#   - "passive": MCP server is read-only, no log_turn tool
#   - "active": MCP server can log turns via log_turn tool
#
# CLI Override: The mode can be overridden per-session via CLI flag:
#   lattice serve --capture-mode active|passive
#
#   - Claude Code: Use --capture-mode active (agent calls log_turn via MCP)
#   - OpenCode: Use --capture-mode passive (plugin captures data, MCP is read-only)
#
# The value in this file becomes the fallback default when no CLI flag is provided.

[capture]
# Default: passive (read-only, use OpenCode plugin for capture)
mode = "passive"

# =============================================================================
# Layer 1 Configuration (Optional)
# =============================================================================
# Enable local model summarization for large sessions.
# Uses Ollama for local inference (zero API cost).
#
# Layer 1 compresses old sessions before Layer 2 evolution,
# reducing token costs for long-running projects.

# [layer1]
# enabled = false
# model = "llama3.2:3b"             # Ollama model name

# =============================================================================
# Experimental Features
# =============================================================================
# These features are under active development and may change.

# [experimental]
# enable_feature_x = false

# =============================================================================
# Usage Examples
# =============================================================================
#
# Minimal config (uses auth.json for API key):
#   [compiler]
#   model = "openai/gpt-5-mini"
#
# With embedding for semantic search:
#   [compiler]
#   model = "openai/gpt-5-mini"
#   
#   [embedding]
#   model = "openai/text-embedding-3-small"
#
# Using OpenRouter for cost optimization:
#   [compiler]
#   model = "openrouter/openai/gpt-5-mini"
#   
#   [embedding]
#   model = "openrouter/openai/text-embedding-3-small"
#
# Using local Ollama (zero API cost):
#   [compiler]
#   model = "ollama/llama3.2:3b"
#   
#   [embedding]
#   model = "ollama/nomic-embed-text"
#   dimensions = 768
"""


# @invar:allow shell_result: Returns static string template, no I/O
# @invar:allow shell_pure_logic: Returns static template, no I/O operations
def get_config_template() -> str:
    """Return the default config.toml template.

    >>> template = get_config_template()
    >>> "[compiler]" in template
    True
    >>> "[embedding]" in template
    True
    >>> "[thresholds]" in template
    True
    """
    return CONFIG_TEMPLATE
