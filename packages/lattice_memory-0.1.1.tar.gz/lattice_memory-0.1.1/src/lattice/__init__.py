"""
Lattice — Local-first, persistent memory system for AI agents.

This package implements the Bicameral Memory Architecture (RFC-002):
- System 1 (Instinct): Always-on rules loaded from .lattice/rules/
- System 2 (Memory): Deep recall via SQLite store.db

Architecture:
- core/: Pure business logic (no I/O, @pre/@post contracts, doctests)
- shell/: I/O adapters (returns Result[T, E] from 'returns' library)
"""

from lattice.client import Client
from lattice.logging_config import configure_logging
from lattice.types import PatternType, RuleProposal, SearchResult

__version__ = "0.1.1"

# Initialize logging on import
configure_logging()

__all__ = [
    "Client",
    "PatternType",
    "SearchResult",
    "RuleProposal",
]
