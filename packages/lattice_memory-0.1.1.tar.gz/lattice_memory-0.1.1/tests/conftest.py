"""
Root pytest configuration.

Registers plugin hooks that must be available globally.
"""

import pytest


def pytest_addoption(parser):
    """Add --run-e2e option for E2E tests with real LLM calls."""
    parser.addoption(
        "--run-e2e",
        action="store_true",
        default=False,
        help="Run E2E tests with real LLM API calls",
    )
