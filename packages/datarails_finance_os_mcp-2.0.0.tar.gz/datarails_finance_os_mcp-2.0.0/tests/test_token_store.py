"""Tests for token_store module."""

import json
import pytest
from unittest.mock import patch, MagicMock

from datarails_mcp.token_store import (
    Connection,
    StoredCredentials,
    TokenStore,
)


def _make_connection(**overrides):
    defaults = {
        "token_url": "https://app.datarails.com/oauth/token",
        "revoke_url": "https://app.datarails.com/oauth/revoke",
        "api_url": "https://app.datarails.com/finance-os/api",
        "environment": "production",
        "organization": "Acme Corp",
        "organization_id": "org_abc123",
    }
    defaults.update(overrides)
    return Connection(**defaults)


def _make_credentials(**overrides):
    defaults = {
        "oauth_token": "dro_test123",
        "jwt_access_token": "eyJ.test.access",
        "jwt_refresh_token": "ref_test456",
        "jwt_expires_at": 9999999999.0,
        "connection": _make_connection(),
    }
    defaults.update(overrides)
    return StoredCredentials(**defaults)


class TestStoredCredentials:
    def test_jwt_expires_in_future(self):
        creds = _make_credentials(jwt_expires_at=9999999999.0)
        assert creds.jwt_expires_in > 0
        assert not creds.is_jwt_expired

    def test_jwt_expired(self):
        creds = _make_credentials(jwt_expires_at=0.0)
        assert creds.jwt_expires_in == 0.0
        assert creds.is_jwt_expired

    def test_jwt_expired_within_buffer(self):
        import time
        # Expires in 10 seconds — within the 30s buffer
        creds = _make_credentials(jwt_expires_at=time.time() + 10)
        assert creds.is_jwt_expired


class TestTokenStore:
    @patch("datarails_mcp.token_store._keyring_get_with_timeout")
    @patch("datarails_mcp.token_store._keyring_set_with_timeout")
    def test_save_and_load_roundtrip(self, mock_set, mock_get):
        store = TokenStore(service="test-svc", account="test-acc")
        creds = _make_credentials()

        # Capture what save writes
        saved_value = None
        def capture_set(svc, acc, val):
            nonlocal saved_value
            saved_value = val
        mock_set.side_effect = capture_set

        store.save(creds)
        assert saved_value is not None

        # load returns the saved value
        mock_get.return_value = saved_value
        loaded = store.load()

        assert loaded is not None
        assert loaded.oauth_token == creds.oauth_token
        assert loaded.jwt_access_token == creds.jwt_access_token
        assert loaded.jwt_refresh_token == creds.jwt_refresh_token
        assert loaded.jwt_expires_at == creds.jwt_expires_at
        assert loaded.connection.token_url == creds.connection.token_url
        assert loaded.connection.organization == creds.connection.organization

    @patch("datarails_mcp.token_store._keyring_get_with_timeout", return_value=None)
    def test_load_empty(self, mock_get):
        store = TokenStore(service="test-svc", account="test-acc")
        assert store.load() is None

    @patch("datarails_mcp.token_store._keyring_get_with_timeout", return_value="{invalid json")
    def test_load_corrupt_data(self, mock_get):
        store = TokenStore(service="test-svc", account="test-acc")
        assert store.load() is None

    @patch("datarails_mcp.token_store._keyring_delete_with_timeout")
    @patch("datarails_mcp.token_store._keyring_get_with_timeout")
    @patch("datarails_mcp.token_store._keyring_set_with_timeout")
    def test_clear(self, mock_set, mock_get, mock_delete):
        store = TokenStore(service="test-svc", account="test-acc")

        # Save then clear
        mock_set.side_effect = lambda s, a, v: None
        store.save(_make_credentials())

        store.clear()
        mock_delete.assert_called_once_with("test-svc", "test-acc")

    @patch("datarails_mcp.token_store._keyring_get_with_timeout")
    def test_has_credentials_true(self, mock_get):
        mock_get.return_value = '{"some": "data"}'
        store = TokenStore(service="test-svc", account="test-acc")
        assert store.has_credentials()

    @patch("datarails_mcp.token_store._keyring_get_with_timeout", return_value=None)
    def test_has_credentials_false(self, mock_get):
        store = TokenStore(service="test-svc", account="test-acc")
        assert not store.has_credentials()

    @patch("datarails_mcp.token_store._keyring_get_with_timeout", return_value="")
    def test_has_credentials_empty_string(self, mock_get):
        store = TokenStore(service="test-svc", account="test-acc")
        assert not store.has_credentials()
