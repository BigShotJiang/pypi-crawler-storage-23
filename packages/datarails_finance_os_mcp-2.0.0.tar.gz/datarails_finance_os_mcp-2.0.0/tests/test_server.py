"""Tests for the Datarails MCP server."""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from datarails_mcp.token_store import Connection, StoredCredentials, TokenStore


def _make_connection(**overrides):
    defaults = {
        "token_url": "https://app.datarails.com/jwt/api/token/refresh/cookie/",
        "revoke_url": "https://app.datarails.com/descope/logout",
        "api_url": "https://app.datarails.com/finance-os/api",
        "environment": "https://app.datarails.com",
        "organization": "acme.com",
        "organization_id": "1",
    }
    defaults.update(overrides)
    return Connection(**defaults)


def _make_credentials(**overrides):
    defaults = {
        "oauth_token": "dro_test123",
        "jwt_access_token": "eyJ.test.access",
        "jwt_refresh_token": "ref_test456",
        "jwt_expires_at": 9999999999.0,
        "connection": _make_connection(),
    }
    defaults.update(overrides)
    return StoredCredentials(**defaults)


# ---------------------------------------------------------------------------
# Auth tool tests
# ---------------------------------------------------------------------------


class TestMCPServerAuthTools:
    """Tests for the new authenticate / disable / auth_status tools."""

    async def test_auth_status_not_authenticated(self):
        import datarails_mcp.server as mod

        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = None
            result = await mod.auth_status()

        data = json.loads(result)
        assert data["authenticated"] is False
        assert "Not authenticated" in data["message"]

    async def test_auth_status_authenticated(self):
        import datarails_mcp.server as mod

        creds = _make_credentials()
        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = creds
            result = await mod.auth_status()

        data = json.loads(result)
        assert data["authenticated"] is True
        assert data["organization"] == "acme.com"
        assert data["environment"] == "https://app.datarails.com"
        assert "jwt_expires_in_seconds" in data

    async def test_authenticate_already_authenticated(self):
        import datarails_mcp.server as mod

        creds = _make_credentials()
        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = creds
            result = await mod.authenticate()

        data = json.loads(result)
        assert data["authenticated"] is True
        assert "Already authenticated" in data["message"]

    async def test_authenticate_calls_oauth(self):
        import datarails_mcp.server as mod

        creds = _make_credentials()
        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = None  # not authenticated
            with patch("datarails_mcp.server.oauth_authenticate", new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = creds
                result = await mod.authenticate()
        mock_auth.assert_called_once()

        data = json.loads(result)
        assert data["authenticated"] is True
        assert data["organization"] == "acme.com"

    async def test_authenticate_timeout(self):
        import datarails_mcp.server as mod
        from datarails_mcp.oauth import AuthTimeoutError

        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = None
            with patch("datarails_mcp.server.oauth_authenticate", new_callable=AsyncMock) as mock_auth:
                mock_auth.side_effect = AuthTimeoutError()
                result = await mod.authenticate()

        data = json.loads(result)
        assert data["authenticated"] is False
        assert "Timed out" in data["message"]

    async def test_authenticate_denied(self):
        import datarails_mcp.server as mod
        from datarails_mcp.oauth import AuthDeniedError

        with patch.object(mod, "_store") as mock_store:
            mock_store.load.return_value = None
            with patch("datarails_mcp.server.oauth_authenticate", new_callable=AsyncMock) as mock_auth:
                mock_auth.side_effect = AuthDeniedError()
                result = await mod.authenticate()

        data = json.loads(result)
        assert data["authenticated"] is False
        assert "denied" in data["message"]

    async def test_disable_calls_oauth_disable(self):
        import datarails_mcp.server as mod

        with patch("datarails_mcp.server.oauth_disable", new_callable=AsyncMock) as mock_disable:
            mock_disable.return_value = {"success": True, "message": "Tokens revoked"}
            result = await mod.disable()

        data = json.loads(result)
        assert data["success"] is True


# ---------------------------------------------------------------------------
# DatarailsClient tests (via server tools)
# ---------------------------------------------------------------------------


class TestDatarailsClient:
    """Tests for the Datarails API client."""

    @pytest.fixture
    def client(self):
        from datarails_mcp.client import DatarailsClient

        store = MagicMock(spec=TokenStore)
        creds = _make_credentials()
        store.load.return_value = creds
        c = DatarailsClient(store)
        return c

    async def test_list_tables(self, client):
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "data": [
                    {"id": "1", "name": "Revenue"},
                    {"id": "2", "name": "Expenses"},
                ]
            }

            result = await client.list_tables()

            mock_request.assert_called_once_with("GET", "/tables/v1/")
            assert "Revenue" in result
            assert "Expenses" in result

    async def test_get_schema(self, client):
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "data": {
                    "id": "123",
                    "name": "Test Table",
                    "fields": [
                        {"name": "id", "type": "integer"},
                        {"name": "amount", "type": "decimal"},
                    ]
                }
            }

            result = await client.get_schema("123")

            mock_request.assert_called_once_with("GET", "/tables/v1/123")
            assert "id" in result
            assert "amount" in result

    async def test_profile_numeric(self, client):
        with patch.object(client, "_request_async_poll", new_callable=AsyncMock) as mock_poll:
            mock_poll.return_value = {"data": [{"amount_SUM": 10000, "amount_AVG": 500}]}

            result = await client.profile_numeric("123", ["amount"])

            mock_poll.assert_called_once()
            call_args = mock_poll.call_args
            assert "/aggregate" in call_args[0][0]

    async def test_get_filtered_respects_limit(self, client):
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"data": []}

            await client.get_filtered("123", {"status": "active"}, limit=1000)

            mock_request.assert_called_once()
            call_args = mock_request.call_args
            assert call_args[1]["json_data"]["limit"] == 500

    async def test_get_sample_respects_limit(self, client):
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"data": []}

            await client.get_sample("123", n=50)

            mock_request.assert_called_once()
            call_args = mock_request.call_args
            assert call_args[1]["json_data"]["limit"] == 20

    async def test_error_handling(self, client):
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"error": "Not found"}

            result = await client.list_tables()

            assert "error" in result
            assert "Not found" in result


# ---------------------------------------------------------------------------
# MCP server data tool tests
# ---------------------------------------------------------------------------


class TestMCPServerDataTools:
    """Tests for the MCP server data tools."""

    @pytest.fixture
    def mock_client(self):
        import datarails_mcp.server as mod

        mock_instance = MagicMock()
        with patch.object(mod, "get_client", return_value=mock_instance):
            yield mock_instance

    async def test_list_finance_tables(self, mock_client):
        from datarails_mcp.server import list_finance_tables

        mock_client.list_tables = AsyncMock(return_value='{"tables": []}')

        result = await list_finance_tables()

        mock_client.list_tables.assert_called_once()
        assert "tables" in result

    async def test_get_table_schema(self, mock_client):
        from datarails_mcp.server import get_table_schema

        mock_client.get_schema = AsyncMock(return_value='{"columns": []}')

        result = await get_table_schema("123")

        mock_client.get_schema.assert_called_once_with("123")
        assert "columns" in result

    async def test_detect_anomalies(self, mock_client):
        from datarails_mcp.server import detect_anomalies

        mock_client.detect_anomalies = AsyncMock(
            return_value='{"anomalies": [], "severity": "low"}'
        )

        result = await detect_anomalies("123")

        mock_client.detect_anomalies.assert_called_once_with("123")
        assert "anomalies" in result

    async def test_get_records_by_filter_caps_limit(self, mock_client):
        from datarails_mcp.server import get_records_by_filter

        mock_client.get_filtered = AsyncMock(return_value='{"records": []}')

        await get_records_by_filter("123", {"status": "active"}, limit=1000)

        mock_client.get_filtered.assert_called_once_with(
            "123", {"status": "active"}, 500
        )

    async def test_get_sample_records_caps_limit(self, mock_client):
        from datarails_mcp.server import get_sample_records

        mock_client.get_sample = AsyncMock(return_value='{"records": []}')

        await get_sample_records("123", n=100)

        mock_client.get_sample.assert_called_once_with("123", 20)
