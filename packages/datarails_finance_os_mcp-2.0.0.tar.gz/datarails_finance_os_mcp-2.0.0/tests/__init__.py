"""Tests for Datarails MCP server."""
