"""Tests for oauth module."""

import json
import os
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from datarails_mcp.oauth import (
    AuthDeniedError,
    AuthError,
    AuthInProgressError,
    AuthTimeoutError,
    _generate_state,
    _acquire_lock,
    _release_lock,
    authenticate,
    disable,
)
from datarails_mcp.token_store import Connection, StoredCredentials, TokenStore


# ---------------------------------------------------------------------------
# State parameter tests
# ---------------------------------------------------------------------------


class TestState:
    def test_state_uniqueness(self):
        s1 = _generate_state()
        s2 = _generate_state()
        assert s1 != s2

    def test_state_length(self):
        s = _generate_state()
        assert len(s) == 64  # 32 bytes hex = 64 chars


# ---------------------------------------------------------------------------
# Lock file tests
# ---------------------------------------------------------------------------


class TestLockFile:
    @patch("datarails_mcp.oauth.LOCK_FILE_PATH", "/tmp/test-datarails-mcp-auth.lock")
    def test_acquire_and_release(self):
        # Clean up first
        try:
            os.remove("/tmp/test-datarails-mcp-auth.lock")
        except FileNotFoundError:
            pass

        _acquire_lock()
        assert os.path.exists("/tmp/test-datarails-mcp-auth.lock")

        _release_lock()
        assert not os.path.exists("/tmp/test-datarails-mcp-auth.lock")

    @patch("datarails_mcp.oauth.LOCK_FILE_PATH", "/tmp/test-datarails-mcp-auth.lock")
    @patch("datarails_mcp.oauth._is_pid_alive", return_value=True)
    def test_lock_contention(self, mock_pid_alive):
        lock_path = "/tmp/test-datarails-mcp-auth.lock"
        try:
            os.remove(lock_path)
        except FileNotFoundError:
            pass

        # Write a lock from a "live" process
        with open(lock_path, "w") as f:
            json.dump({"pid": 99999, "started_at": time.time()}, f)

        with pytest.raises(AuthInProgressError) as exc_info:
            _acquire_lock()
        assert exc_info.value.pid == 99999

        # Clean up
        os.remove(lock_path)

    @patch("datarails_mcp.oauth.LOCK_FILE_PATH", "/tmp/test-datarails-mcp-auth.lock")
    @patch("datarails_mcp.oauth._is_pid_alive", return_value=False)
    def test_stale_lock_dead_pid(self, mock_pid_alive):
        lock_path = "/tmp/test-datarails-mcp-auth.lock"
        # Write a lock from a dead process
        with open(lock_path, "w") as f:
            json.dump({"pid": 99999, "started_at": time.time()}, f)

        # Should succeed — dead PID means stale lock
        _acquire_lock()
        assert os.path.exists(lock_path)

        _release_lock()

    @patch("datarails_mcp.oauth.LOCK_FILE_PATH", "/tmp/test-datarails-mcp-auth.lock")
    @patch("datarails_mcp.oauth._is_pid_alive", return_value=True)
    def test_stale_lock_old_age(self, mock_pid_alive):
        lock_path = "/tmp/test-datarails-mcp-auth.lock"
        # Write a lock from 10 minutes ago (>3 min = stale)
        with open(lock_path, "w") as f:
            json.dump({"pid": 99999, "started_at": time.time() - 600}, f)

        # Should succeed — old lock is stale
        _acquire_lock()
        assert os.path.exists(lock_path)

        _release_lock()


# ---------------------------------------------------------------------------
# disable() tests
# ---------------------------------------------------------------------------


class TestDisable:
    async def test_disable_not_authenticated(self):
        store = MagicMock(spec=TokenStore)
        store.load.return_value = None

        result = await disable(store)
        assert result["success"] is True
        assert "Nothing to do" in result["message"]

    async def test_disable_clears_credentials(self):
        store = MagicMock(spec=TokenStore)
        store.load.return_value = StoredCredentials(
            oauth_token="tok",
            jwt_access_token="acc",
            jwt_refresh_token="ref",
            jwt_expires_at=9999999999.0,
            connection=Connection(
                token_url="https://app.datarails.com/descope/single_login_complete",
                revoke_url="https://app.datarails.com/descope/logout",
                api_url="https://app.datarails.com/finance-os/api",
                environment="https://app.datarails.com",
                organization="",
                organization_id="",
            ),
        )

        result = await disable(store)

        assert result["success"] is True
        assert "logged out" in result["message"]
        store.clear.assert_called_once()