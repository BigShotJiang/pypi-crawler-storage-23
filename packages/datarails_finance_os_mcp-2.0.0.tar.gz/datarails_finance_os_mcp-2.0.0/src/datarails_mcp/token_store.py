"""Token storage for Datarails OAuth credentials.

Persists OAuth tokens, JWT tokens, and connection info in the system keyring.
Uses a single keyring entry (service: "datarails-mcp", account: "oauth-tokens")
containing a JSON blob with all credential and connection data.
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

from datarails_mcp.constants import KEYRING_ACCOUNT, KEYRING_SERVICE, KEYRING_TIMEOUT

# Lazy keyring import with availability check
_keyring_available: bool | None = None
_keyring_module = None


def _get_keyring():
    """Get keyring module with lazy import and availability check."""
    global _keyring_available, _keyring_module
    if _keyring_available is not None:
        return _keyring_module if _keyring_available else None
    try:
        import keyring

        _keyring_module = keyring
        _keyring_available = True
        return keyring
    except ImportError:
        _keyring_available = False
        return None


def _keyring_get_with_timeout(
    service: str, account: str, timeout: float = KEYRING_TIMEOUT
) -> str | None:
    """Call keyring.get_password with a timeout to prevent hanging."""
    kr = _get_keyring()
    if kr is None:
        return None

    result: list[str | None] = [None]

    def _get():
        try:
            result[0] = kr.get_password(service, account)
        except Exception:
            pass

    thread = threading.Thread(target=_get, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    if thread.is_alive():
        return None

    return result[0]


def _keyring_set_with_timeout(
    service: str, account: str, value: str, timeout: float = KEYRING_TIMEOUT
) -> bool:
    """Call keyring.set_password with a timeout."""
    kr = _get_keyring()
    if kr is None:
        return False

    success = [False]

    def _set():
        try:
            kr.set_password(service, account, value)
            success[0] = True
        except Exception:
            pass

    thread = threading.Thread(target=_set, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    return success[0] and not thread.is_alive()


def _keyring_delete_with_timeout(
    service: str, account: str, timeout: float = KEYRING_TIMEOUT
) -> bool:
    """Call keyring.delete_password with a timeout."""
    kr = _get_keyring()
    if kr is None:
        return False

    success = [False]

    def _delete():
        try:
            kr.delete_password(service, account)
            success[0] = True
        except Exception:
            pass

    thread = threading.Thread(target=_delete, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    return success[0] and not thread.is_alive()


@dataclass
class Connection:
    """Connection info provided by auth.datarails.com. Immutable after authenticate."""

    token_url: str  # where to get/refresh JWTs
    revoke_url: str  # where to revoke JWTs (/disable)
    api_url: str  # where to send API requests
    environment: str  # "production", "development", etc.
    organization: str  # "Acme Corp"
    organization_id: str  # "org_abc123"


@dataclass
class StoredCredentials:
    """Everything MCP persists in keyring."""

    oauth_token: str  # from auth.datarails.com (long-lived)
    jwt_access_token: str  # from {token_url} (short-lived)
    jwt_refresh_token: str  # from {token_url}
    jwt_expires_at: float  # unix timestamp
    connection: Connection

    @property
    def jwt_expires_in(self) -> float:
        """Seconds until JWT access token expires."""
        return max(0.0, self.jwt_expires_at - time.time())

    @property
    def is_jwt_expired(self) -> bool:
        """Check if JWT access token is expired or about to expire (30s buffer)."""
        return time.time() > (self.jwt_expires_at - 30)


class TokenStore:
    """Keyring-backed storage for OAuth and JWT credentials.

    Stores a single set of credentials (one environment at a time).
    The keyring entry is: service="datarails-mcp", account="oauth-tokens".
    """

    def __init__(
        self,
        service: str = KEYRING_SERVICE,
        account: str = KEYRING_ACCOUNT,
    ):
        self._service = service
        self._account = account

    def save(self, credentials: StoredCredentials) -> None:
        """Serialize credentials to JSON and write to keyring."""
        data = {
            "oauth_token": credentials.oauth_token,
            "jwt_access_token": credentials.jwt_access_token,
            "jwt_refresh_token": credentials.jwt_refresh_token,
            "jwt_expires_at": credentials.jwt_expires_at,
            "connection": asdict(credentials.connection),
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }
        _keyring_set_with_timeout(self._service, self._account, json.dumps(data))

    def load(self) -> StoredCredentials | None:
        """Read from keyring and deserialize. Returns None if not found."""
        raw = _keyring_get_with_timeout(self._service, self._account)
        if not raw:
            return None

        try:
            data = json.loads(raw)
            return StoredCredentials(
                oauth_token=data["oauth_token"],
                jwt_access_token=data["jwt_access_token"],
                jwt_refresh_token=data["jwt_refresh_token"],
                jwt_expires_at=float(data["jwt_expires_at"]),
                connection=Connection(**data["connection"]),
            )
        except (json.JSONDecodeError, KeyError, TypeError):
            return None

    def clear(self) -> None:
        """Delete credentials from keyring."""
        _keyring_delete_with_timeout(self._service, self._account)

    def has_credentials(self) -> bool:
        """Check if credentials exist in keyring (without full deserialization)."""
        raw = _keyring_get_with_timeout(self._service, self._account)
        return raw is not None and len(raw) > 0
