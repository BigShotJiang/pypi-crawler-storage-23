"""Datarails Finance OS API client.

Handles all API communication with the Datarails Finance OS backend.
Uses TokenStore for authentication — JWT tokens are auto-refreshed via {token_url}.

Endpoints (relative to api_url from connection):
  - /tables/v1/ - List tables
  - /tables/v1/{id} - Get table schema
  - /tables/v1/{id}/data - Query table data (POST)
  - /tables/v1/{id}/fields/by-name/{field}/distinct - Get distinct values
  - /tables/v1/{id}/aggregate - Aggregate data (POST)
"""

import asyncio
import json
import time
from typing import Any

import httpx

from datarails_mcp.constants import CLIENT_ID
from datarails_mcp.token_store import TokenStore


class DatarailsClient:
    """Client for Datarails Finance OS API."""

    def __init__(self, store: TokenStore):
        self.store = store
        self._client: httpx.AsyncClient | None = None
        self._schema_cache: dict[str, dict] = {}

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=60.0)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    def _get_api_url(self) -> str | None:
        """Get the api_url from stored credentials."""
        creds = self.store.load()
        if creds:
            return creds.connection.api_url
        return None

    def _get_headers(self) -> dict[str, str]:
        """Build request headers from stored JWT."""
        headers = {"Content-Type": "application/json"}
        creds = self.store.load()
        if creds:
            headers["Authorization"] = f"Bearer {creds.jwt_access_token}"
        return headers

    async def _refresh_jwt(self) -> bool:
        """Refresh JWT using refresh_token via {token_url}.

        Returns True if refresh succeeded, False otherwise.
        On failure, clears the store (session expired).
        """
        creds = self.store.load()
        if not creds:
            return False

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    creds.connection.token_url,
                    json={"refresh": creds.jwt_refresh_token},
                )

            if response.status_code != 200:
                self.store.clear()
                return False

            data = response.json()
            new_access = data.get("access", "")
            new_refresh = data.get("refresh", creds.jwt_refresh_token)

            if not new_access:
                self.store.clear()
                return False

            # Extract expiry from new JWT
            from datarails_mcp.oauth import _decode_jwt_payload
            claims = _decode_jwt_payload(new_access)
            jwt_exp = float(claims.get("exp", time.time() + 3600))

            from datarails_mcp.token_store import StoredCredentials

            updated = StoredCredentials(
                oauth_token=creds.oauth_token,
                jwt_access_token=new_access,
                jwt_refresh_token=new_refresh,
                jwt_expires_at=jwt_exp,
                connection=creds.connection,
            )
            self.store.save(updated)
            return True

        except Exception:
            self.store.clear()
            return False

    async def _ensure_auth(self) -> dict[str, Any] | None:
        """Check auth and return error dict if not authenticated, None if OK."""
        creds = self.store.load()
        if not creds:
            return {
                "error": "authentication_required",
                "message": "Not authenticated. Run /authenticate to connect to Datarails.",
            }

        # Refresh JWT if expired or about to expire
        if creds.is_jwt_expired:
            if not await self._refresh_jwt():
                return {
                    "error": "session_expired",
                    "message": "Session expired. Run /authenticate to reconnect.",
                }

        return None

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        json_data: dict | None = None,
    ) -> dict[str, Any]:
        """Make an authenticated API request."""
        auth_error = await self._ensure_auth()
        if auth_error:
            return auth_error

        client = await self._get_client()
        api_url = self._get_api_url()
        if not api_url:
            return {"error": "No API URL configured. Run /authenticate."}

        url = f"{api_url}{endpoint}"

        try:
            response = await client.request(
                method=method,
                url=url,
                headers=self._get_headers(),
                params=params,
                json=json_data,
            )

            if response.status_code == 401:
                # Token expired mid-request — try refresh once
                if await self._refresh_jwt():
                    response = await client.request(
                        method=method,
                        url=url,
                        headers=self._get_headers(),
                        params=params,
                        json=json_data,
                    )
                    if response.status_code == 401:
                        self.store.clear()
                        return {
                            "error": "session_expired",
                            "message": "Session expired. Run /authenticate to reconnect.",
                        }
                else:
                    return {
                        "error": "session_expired",
                        "message": "Session expired. Run /authenticate to reconnect.",
                    }

            if response.status_code >= 400:
                return {
                    "error": f"API error: {response.status_code}",
                    "details": response.text,
                }

            return response.json()

        except httpx.TimeoutException:
            return {"error": "Request timed out. Please try again."}
        except httpx.RequestError as e:
            return {"error": f"Request failed: {str(e)}"}
        except json.JSONDecodeError:
            return {"error": "Invalid response from server"}

    async def _request_async_poll(
        self,
        endpoint: str,
        json_data: dict,
        poll_interval: float = 3.0,
        max_polls: int = 20,
    ) -> dict[str, Any]:
        """POST request that handles async 202 + Location polling pattern.

        The Finance OS aggregation API uses a long-running task pattern:
        1. POST returns 202 Accepted with a Location header
        2. GET the Location URL to poll for results
        3. Returns 200 when done, 202 if still processing
        """
        auth_error = await self._ensure_auth()
        if auth_error:
            return auth_error

        client = await self._get_client()
        api_url = self._get_api_url()
        if not api_url:
            return {"error": "No API URL configured. Run /authenticate."}

        url = f"{api_url}{endpoint}"

        try:
            response = await client.post(
                url,
                headers=self._get_headers(),
                json=json_data,
            )

            if response.status_code == 401:
                if await self._refresh_jwt():
                    response = await client.post(
                        url,
                        headers=self._get_headers(),
                        json=json_data,
                    )
                else:
                    return {
                        "error": "session_expired",
                        "message": "Session expired. Run /authenticate to reconnect.",
                    }

            if response.status_code == 200:
                return response.json()

            if response.status_code >= 400:
                return {
                    "error": f"API error: {response.status_code}",
                    "details": response.text,
                }

            if response.status_code == 202:
                location = response.headers.get("location")
                if not location:
                    return {"error": "Aggregation returned 202 but no Location header"}

                # Location is relative (e.g., /tables/v1/...), needs api_url prefix
                if location.startswith("/tables/"):
                    poll_url = f"{api_url}{location}"
                elif location.startswith("/finance-os/"):
                    # Strip /finance-os/api prefix if api_url already includes it
                    poll_url = f"{api_url}{location}"
                elif location.startswith("http"):
                    poll_url = location
                else:
                    poll_url = f"{api_url}{location}"

                for _ in range(max_polls):
                    await asyncio.sleep(poll_interval)

                    # Refresh token if needed before each poll
                    creds = self.store.load()
                    if creds and creds.is_jwt_expired:
                        await self._refresh_jwt()

                    poll_resp = await client.get(
                        poll_url,
                        headers=self._get_headers(),
                    )

                    if poll_resp.status_code == 200:
                        return poll_resp.json()
                    elif poll_resp.status_code == 202:
                        continue
                    elif poll_resp.status_code == 401:
                        if not await self._refresh_jwt():
                            return {"error": "Authentication expired during polling."}
                        continue
                    else:
                        return {
                            "error": f"Aggregation poll failed: {poll_resp.status_code}",
                            "details": poll_resp.text,
                        }

                return {"error": "Aggregation timed out after polling"}

            return {"error": f"Unexpected status: {response.status_code}"}

        except httpx.TimeoutException:
            return {"error": "Request timed out. Please try again."}
        except httpx.RequestError as e:
            return {"error": f"Request failed: {str(e)}"}
        except json.JSONDecodeError:
            return {"error": "Invalid response from server"}

    def _format_response(self, data: dict[str, Any] | None) -> str:
        """Format API response as a readable string."""
        if data is None:
            return json.dumps({"error": "Empty response from API"}, indent=2)

        if isinstance(data, dict) and "error" in data and data["error"]:
            return json.dumps(data, indent=2, default=str)
        # Finance OS API wraps responses in {"success": true, "data": [...], ...}
        if isinstance(data, dict) and "data" in data:
            return json.dumps(data["data"], indent=2, default=str)
        return json.dumps(data, indent=2, default=str)

    # Discovery Tools

    async def list_tables(self) -> str:
        """List all available Finance OS tables."""
        result = await self._request("GET", "/tables/v1/")
        return self._format_response(result)

    async def get_schema(self, table_id: str) -> str:
        """Get schema (columns, types) for a Finance OS table."""
        if table_id in self._schema_cache:
            return json.dumps(self._schema_cache[table_id], indent=2, default=str)

        result = await self._request("GET", f"/tables/v1/{table_id}")
        if "error" not in result:
            schema = result.get("data", result)
            self._schema_cache[table_id] = schema
            return json.dumps(schema, indent=2, default=str)
        return self._format_response(result)

    async def get_distinct_values(
        self, table_id: str, field_name: str, limit: int = 100
    ) -> str:
        """Get distinct values for a field."""
        result = await self._request(
            "GET",
            f"/tables/v1/{table_id}/fields/by-name/{field_name}/distinct",
        )
        if "error" not in result:
            values = result.get("data", {}).get("values", [])
            return json.dumps(values[:limit], indent=2, default=str)
        return self._format_response(result)

    # Profiling Tools

    async def profile_summary(self, table_id: str) -> str:
        """Get comprehensive summary: row count, column stats, data quality metrics."""
        schema_result = await self._request("GET", f"/tables/v1/{table_id}")
        if "error" in schema_result:
            return self._format_response(schema_result)

        schema = schema_result.get("data", {})

        await self._request(
            "POST",
            f"/tables/v1/{table_id}/data",
            json_data={"limit": 1, "offset": 0},
        )

        summary = {
            "table_id": table_id,
            "name": schema.get("name"),
            "alias": schema.get("alias"),
            "fields": schema.get("fields", []),
            "field_count": len(schema.get("fields", [])),
        }
        return json.dumps(summary, indent=2, default=str)

    async def profile_numeric(
        self, table_id: str, fields: list[str] | None = None
    ) -> str:
        """Profile numeric fields using aggregation: MIN, MAX, AVG, SUM, COUNT."""
        if not fields:
            schema_result = await self._request("GET", f"/tables/v1/{table_id}")
            if "error" in schema_result:
                return self._format_response(schema_result)
            schema = schema_result.get("data", {})
            fields = [
                f["name"]
                for f in schema.get("fields", [])
                if f.get("type") in ("number", "integer", "float", "decimal", "currency")
            ]

        if not fields:
            return json.dumps({"message": "No numeric fields found"}, indent=2)

        metrics = []
        for field in fields:
            metrics.extend([
                {"field": field, "agg": "SUM"},
                {"field": field, "agg": "AVG"},
                {"field": field, "agg": "MIN"},
                {"field": field, "agg": "MAX"},
                {"field": field, "agg": "COUNT"},
            ])

        result = await self._request_async_poll(
            f"/tables/v1/{table_id}/aggregate",
            json_data={"dimensions": [], "metrics": metrics},
        )
        return self._format_response(result)

    async def profile_categorical(
        self, table_id: str, fields: list[str] | None = None
    ) -> str:
        """Profile categorical fields: distinct values, cardinality."""
        if not fields:
            schema_result = await self._request("GET", f"/tables/v1/{table_id}")
            if "error" in schema_result:
                return self._format_response(schema_result)
            schema = schema_result.get("data", {})
            fields = [
                f["name"]
                for f in schema.get("fields", [])
                if f.get("type") in ("string", "text", "category", "enum")
            ]

        if not fields:
            return json.dumps({"message": "No categorical fields found"}, indent=2)

        results = {}
        for field in fields[:5]:
            distinct_result = await self._request(
                "GET",
                f"/tables/v1/{table_id}/fields/by-name/{field}/distinct",
            )
            if "error" not in distinct_result:
                values = distinct_result.get("data", {}).get("values", [])
                results[field] = {
                    "distinct_count": len(values),
                    "sample_values": values[:10],
                }
            else:
                results[field] = {"error": distinct_result.get("error")}

        return json.dumps(results, indent=2, default=str)

    # Analysis Tools

    async def detect_anomalies(self, table_id: str) -> str:
        """Run automated anomaly detection via profiling."""
        schema_result = await self._request("GET", f"/tables/v1/{table_id}")
        if "error" in schema_result:
            return self._format_response(schema_result)

        schema = schema_result.get("data", {})
        fields = schema.get("fields", [])

        numeric_fields = [
            f["name"]
            for f in fields
            if f.get("type") in ("number", "integer", "float", "decimal", "currency")
        ]

        findings = []

        if numeric_fields:
            metrics = []
            for field in numeric_fields[:5]:
                metrics.extend([
                    {"field": field, "agg": "MIN"},
                    {"field": field, "agg": "MAX"},
                    {"field": field, "agg": "AVG"},
                    {"field": field, "agg": "COUNT"},
                ])

            agg_result = await self._request_async_poll(
                f"/tables/v1/{table_id}/aggregate",
                json_data={"dimensions": [], "metrics": metrics},
            )

            if "error" not in agg_result:
                findings.append({
                    "type": "numeric_summary",
                    "description": "Numeric field statistics for anomaly baseline",
                    "data": agg_result.get("data", []),
                })

        return json.dumps({
            "table_id": table_id,
            "table_name": schema.get("name"),
            "fields_analyzed": len(fields),
            "findings": findings,
            "note": "Basic profiling complete. Use get_records_by_filter to investigate specific anomalies.",
        }, indent=2, default=str)

    # Query Tools

    async def get_filtered(
        self, table_id: str, filters: dict[str, Any], limit: int = 100
    ) -> str:
        """Fetch specific records matching filters. Hard limit: 500 rows."""
        safe_limit = min(limit, 500)

        filter_list = []
        for field, value in filters.items():
            if isinstance(value, dict):
                if "in" in value:
                    filter_list.append({
                        "name": field,
                        "values": value["in"],
                        "is_excluded": False,
                    })
                elif "not_in" in value:
                    filter_list.append({
                        "name": field,
                        "values": value["not_in"],
                        "is_excluded": True,
                    })
            else:
                filter_list.append({
                    "name": field,
                    "values": [value] if not isinstance(value, list) else value,
                    "is_excluded": False,
                })

        result = await self._request(
            "POST",
            f"/tables/v1/{table_id}/data",
            json_data={
                "filters": filter_list if filter_list else None,
                "limit": safe_limit,
                "offset": 0,
                "get_all_versions": False,
            },
        )
        return self._format_response(result)

    async def get_sample(self, table_id: str, n: int = 20) -> str:
        """Get a random sample of records. Max 20 rows."""
        safe_n = min(n, 20)
        result = await self._request(
            "POST",
            f"/tables/v1/{table_id}/data",
            json_data={
                "limit": safe_n,
                "offset": 0,
                "get_all_versions": False,
            },
        )
        return self._format_response(result)

    async def execute_query(self, table_id: str, query: str) -> str:
        """Execute a custom query against Finance OS. Returns max 1000 rows."""
        result = await self._request(
            "POST",
            f"/tables/v1/{table_id}/data",
            json_data={
                "limit": 1000,
                "offset": 0,
                "get_all_versions": False,
            },
        )
        return self._format_response(result)

    # Aggregation Tools

    async def aggregate_raw(
        self,
        table_id: str,
        dimensions: list[str],
        metrics: list[dict],
        filters: list[dict] | None = None,
    ) -> dict[str, Any]:
        """Aggregate table data, returning raw dict result for inspection."""
        request_body: dict[str, Any] = {
            "dimensions": dimensions,
            "metrics": metrics,
        }

        if filters:
            request_body["filters"] = filters

        return await self._request_async_poll(
            f"/tables/v1/{table_id}/aggregate",
            json_data=request_body,
        )

    async def aggregate(
        self,
        table_id: str,
        dimensions: list[str],
        metrics: list[dict],
        filters: list[dict] | None = None,
    ) -> str:
        """Aggregate table data with grouping dimensions and metrics. NO ROW LIMIT."""
        result = await self.aggregate_raw(table_id, dimensions, metrics, filters)
        return self._format_response(result)
