"""Constants for Datarails Finance OS MCP Server.

Centralized configuration for OAuth, keyring, and server settings.
"""

import os

# OAuth / Auth Server
AUTH_SERVER_URL = os.environ.get(
    "DATARAILS_AUTH_SERVER", "https://auth.datarails.com"
)
CLIENT_ID = "datarails-mcp"

# Named auth server environments
AUTH_SERVERS = {
    "prod": "https://auth.datarails.com",
    "dev": "https://dev-auth.datarails.com",
    "test": "https://test-auth.datarails.com",
}
DEFAULT_AUTH_ENV = "prod"

# Keyring
KEYRING_SERVICE = "datarails-mcp"
KEYRING_ACCOUNT = "oauth-tokens"
KEYRING_TIMEOUT = 5  # seconds — prevents hanging in environments without a keyring backend

# OAuth callback server
LOCAL_AUTH_HOST = "127.0.0.1"
AUTH_CALLBACK_PATH = "/callback"
CALLBACK_TIMEOUT_SECONDS = 120
MAX_PORT_ATTEMPTS = 5

# Lock file for parallel session handling
LOCK_FILE_PATH = "/tmp/datarails-mcp-auth.lock"
LOCK_MAX_AGE_SECONDS = 180

# CLI colors (for rich output)
COLORS = {
    "success": "green",
    "error": "red",
    "warning": "yellow",
    "info": "blue",
    "dim": "dim",
}
