"""OAuth authentication flow for Datarails.

Implements the authentication flow:
1. Start localhost callback server
2. Open browser to auth.datarails.com
3. Receive session token + env_url via callback
4. Exchange session token for JWT access + refresh tokens
5. Store everything in TokenStore

Also handles /disable (credential clearing) and lock file management.
"""

from __future__ import annotations

import asyncio
import json
import os
import secrets
import time
import webbrowser
from urllib.parse import urlencode

import httpx
from aiohttp import web

from datarails_mcp.constants import (
    AUTH_CALLBACK_PATH,
    AUTH_SERVER_URL,
    CALLBACK_TIMEOUT_SECONDS,
    CLIENT_ID,
    LOCAL_AUTH_HOST,
    LOCK_FILE_PATH,
    LOCK_MAX_AGE_SECONDS,
    MAX_PORT_ATTEMPTS,
)
from datarails_mcp.token_store import Connection, StoredCredentials, TokenStore


class AuthError(Exception):
    """Base error for authentication failures."""


class AuthInProgressError(AuthError):
    """Another authentication flow is already running."""

    def __init__(self, pid: int):
        self.pid = pid
        super().__init__(f"Authentication already in progress (PID {pid})")


class AuthTimeoutError(AuthError):
    """User did not complete authentication within the timeout."""


class AuthDeniedError(AuthError):
    """User denied the authorization request."""


class AuthExchangeError(AuthError):
    """Token exchange with server failed."""


# ---------------------------------------------------------------------------
# State parameter for CSRF protection
# ---------------------------------------------------------------------------


def _generate_state() -> str:
    """Generate a random state parameter for CSRF protection."""
    return secrets.token_hex(32)


# ---------------------------------------------------------------------------
# PKCE helpers
# ---------------------------------------------------------------------------


def _decode_jwt_payload(token: str) -> dict:
    """Decode the payload of a JWT without verification (for extracting claims)."""
    import base64

    parts = token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1] + "=" * (4 - len(parts[1]) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:
        return {}


def _generate_code_verifier() -> str:
    """Generate a PKCE code verifier (RFC 7636)."""
    return secrets.token_urlsafe(64)[:128]


def _generate_code_challenge(verifier: str) -> str:
    """Generate a PKCE code challenge from a verifier (S256)."""
    import base64
    import hashlib

    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


# ---------------------------------------------------------------------------
# Lock file — prevents parallel auth flows
# ---------------------------------------------------------------------------


def _is_pid_alive(pid: int) -> bool:
    """Check if a process with the given PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _acquire_lock() -> None:
    """Acquire the auth lock file. Raises AuthInProgressError if contended."""
    try:
        if os.path.exists(LOCK_FILE_PATH):
            with open(LOCK_FILE_PATH) as f:
                lock_data = json.load(f)

            pid = lock_data.get("pid", 0)
            started_at = lock_data.get("started_at", 0.0)
            age = time.time() - started_at

            if _is_pid_alive(pid) and age < LOCK_MAX_AGE_SECONDS:
                raise AuthInProgressError(pid)

            # Stale lock — remove it
            os.remove(LOCK_FILE_PATH)
    except (json.JSONDecodeError, IOError, KeyError):
        # Corrupt lock file — remove and proceed
        try:
            os.remove(LOCK_FILE_PATH)
        except OSError:
            pass

    # Write our lock
    with open(LOCK_FILE_PATH, "w") as f:
        json.dump({"pid": os.getpid(), "started_at": time.time()}, f)


def _release_lock() -> None:
    """Release the auth lock file."""
    try:
        os.remove(LOCK_FILE_PATH)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Localhost callback server
# ---------------------------------------------------------------------------


async def _start_callback_server(
    expected_state: str,
) -> tuple[web.AppRunner, int, asyncio.Future[dict]]:
    """Start a localhost HTTP server to receive the OAuth callback.

    Returns (runner, port, result_future).
    result_future resolves with {"token": "...", "env_url": "..."} or {"error": "..."}.
    """
    loop = asyncio.get_event_loop()
    result_future: asyncio.Future[dict] = loop.create_future()

    async def handle_callback(request: web.Request) -> web.Response:
        state = request.query.get("state", "")
        error = request.query.get("error")
        token = request.query.get("token")
        env_url = request.query.get("env_url")

        if state != expected_state:
            if not result_future.done():
                result_future.set_result({"error": "state_mismatch"})
            return web.Response(
                text="<html><body><h2>Error: state mismatch</h2></body></html>",
                content_type="text/html",
            )

        if error:
            if not result_future.done():
                result_future.set_result({"error": error})
            return web.Response(
                text="<html><body><h2>Authentication denied</h2><p>You can close this tab.</p></body></html>",
                content_type="text/html",
            )

        if token and env_url:
            if not result_future.done():
                result_future.set_result({"token": token, "env_url": env_url})
            return web.Response(
                text="<html><body><h2>Authentication successful!</h2><p>You can close this tab.</p></body></html>",
                content_type="text/html",
            )

        if not result_future.done():
            result_future.set_result({"error": "missing_token_or_env_url"})
        return web.Response(
            text="<html><body><h2>Error: missing token or environment URL</h2></body></html>",
            content_type="text/html",
        )

    app = web.Application()
    app.router.add_get(AUTH_CALLBACK_PATH, handle_callback)

    runner = web.AppRunner(app)
    await runner.setup()

    # Try ports until one works
    for attempt in range(MAX_PORT_ATTEMPTS):
        port = secrets.randbelow(10000) + 49152  # ephemeral range
        try:
            site = web.TCPSite(runner, LOCAL_AUTH_HOST, port)
            await site.start()
            return runner, port, result_future
        except OSError:
            if attempt == MAX_PORT_ATTEMPTS - 1:
                await runner.cleanup()
                raise AuthError("Could not find an available port for callback server")

    # Should not reach here, but satisfy type checker
    await runner.cleanup()
    raise AuthError("Could not start callback server")


# ---------------------------------------------------------------------------
# Token exchange
# ---------------------------------------------------------------------------


async def _exchange_session_for_jwt(
    session_token: str, env_url: str
) -> tuple[str, str]:
    """Exchange Descope session token for JWT access + refresh tokens.

    GET {env_url}/descope/single_login_complete?descope_session_token={token}&return_jwt=true
    Returns (access_token, refresh_token).
    """
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        response = await client.get(
            f"{env_url}/descope/single_login_complete",
            params={
                "descope_session_token": session_token,
                "return_jwt": "true",
            },
        )

    if response.status_code != 200:
        raise AuthExchangeError(
            f"Failed to exchange session token for JWT (HTTP {response.status_code}): {response.text[:500]}"
        )

    if not response.text.strip():
        raise AuthExchangeError(
            f"Empty response from JWT exchange (HTTP {response.status_code}, "
            f"url={response.url}, headers={dict(response.headers)})"
        )

    data = response.json()
    access_token = data.get("access")
    refresh_token = data.get("refresh")

    if not access_token:
        raise AuthExchangeError(f"No access token in response: {data}")

    return access_token, refresh_token or ""


# ---------------------------------------------------------------------------
# Main flows
# ---------------------------------------------------------------------------


async def authenticate(
    store: TokenStore, auth_server_url: str = AUTH_SERVER_URL
) -> StoredCredentials:
    """Run the full authentication flow.

    Args:
        store: TokenStore for persisting credentials.
        auth_server_url: Base URL of the auth server (default: production).

    Steps:
    1. Acquire lock
    2. Generate state (CSRF protection)
    3. Start callback server
    4. Open browser to auth server
    5. Wait for callback with session token + env_url
    6. Exchange session token for JWT via env_url
    7. Save to store
    8. Cleanup (finally: stop server, release lock)

    Returns StoredCredentials on success.
    Raises AuthError subclass on failure.
    """
    _acquire_lock()
    runner = None

    try:
        # Generate state + PKCE
        state = _generate_state()
        code_verifier = _generate_code_verifier()
        code_challenge = _generate_code_challenge(code_verifier)

        # Start callback server
        runner, port, result_future = await _start_callback_server(state)
        redirect_uri = f"http://{LOCAL_AUTH_HOST}:{port}{AUTH_CALLBACK_PATH}"

        # Build authorization URL
        params = urlencode({
            "response_type": "code",
            "client_id": CLIENT_ID,
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        })
        authorize_url = f"{auth_server_url}/?{params}#/authorize"

        # Open browser
        if not webbrowser.open(authorize_url):
            # Browser didn't open — print URL for manual use
            print(f"\nOpen this URL manually: {authorize_url}\n")

        # Wait for callback
        try:
            callback_result = await asyncio.wait_for(
                result_future, timeout=CALLBACK_TIMEOUT_SECONDS
            )
        except asyncio.TimeoutError:
            raise AuthTimeoutError("Timed out. Run /authenticate to retry.")

        # Check result
        if "error" in callback_result:
            error = callback_result["error"]
            if error == "access_denied":
                raise AuthDeniedError("Authentication denied by user.")
            raise AuthError(f"Authentication failed: {error}")

        session_token = callback_result["token"]
        env_url = callback_result["env_url"]

        # Exchange session token for JWT
        jwt_access, jwt_refresh = await _exchange_session_for_jwt(
            session_token, env_url
        )

        # Extract org info and expiry from JWT payload
        jwt_claims = _decode_jwt_payload(jwt_access)
        organization = jwt_claims.get("organization_domain", "")
        organization_id = str(jwt_claims.get("organization_id", ""))
        jwt_exp = jwt_claims.get("exp", time.time() + 3600)

        # Build connection info from env_url
        # env_url is like "https://app.datarails.com"
        connection = Connection(
            token_url=f"{env_url}/jwt/api/token/refresh/cookie/",
            revoke_url=f"{env_url}/descope/logout",
            api_url=f"{env_url}/finance-os/api",
            environment=env_url,
            organization=organization,
            organization_id=organization_id,
        )

        # Build and save credentials
        credentials = StoredCredentials(
            oauth_token=session_token,
            jwt_access_token=jwt_access,
            jwt_refresh_token=jwt_refresh,
            jwt_expires_at=float(jwt_exp),
            connection=connection,
        )
        store.save(credentials)

        return credentials

    finally:
        if runner:
            await runner.cleanup()
        _release_lock()


async def disable(store: TokenStore) -> dict:
    """Clear local credentials.

    Returns a status dict with 'success' and 'message'.
    """
    credentials = store.load()
    if not credentials:
        return {"success": True, "message": "Not authenticated. Nothing to do."}

    env = credentials.connection.environment

    # Clear local credentials
    store.clear()

    return {
        "success": True,
        "message": f"Disabled — logged out from {env}. Local tokens cleared.",
    }