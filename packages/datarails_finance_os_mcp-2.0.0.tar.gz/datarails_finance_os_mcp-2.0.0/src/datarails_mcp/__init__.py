"""Datarails Finance OS MCP Server for Claude.

A Model Context Protocol (MCP) server that provides Claude with access
to Datarails Finance OS data for analysis and insights.

Installation:
    pip install datarails-finance-os-mcp          # Core (MCP tools only)
    pip install datarails-finance-os-mcp[reports]  # With report generation
    pip install datarails-finance-os-mcp[all]      # Everything

Quick Start:
    datarails-mcp authenticate   # Connect to Datarails (opens browser)
    datarails-mcp status         # Check authentication status
    datarails-mcp serve          # Run the MCP server

Disconnect:
    datarails-mcp disable        # Revoke tokens and log out

For more information, see: https://github.com/Datarails/dr-datarails-mcp-re
"""

__version__ = "2.0.0"

from datarails_mcp.client import DatarailsClient
from datarails_mcp.oauth import authenticate, disable
from datarails_mcp.token_store import Connection, StoredCredentials, TokenStore

__all__ = [
    "DatarailsClient",
    "TokenStore",
    "StoredCredentials",
    "Connection",
    "authenticate",
    "disable",
]
