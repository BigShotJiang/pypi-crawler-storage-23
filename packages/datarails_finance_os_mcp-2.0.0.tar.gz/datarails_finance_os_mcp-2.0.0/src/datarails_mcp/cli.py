"""Command-line interface for Datarails Finance OS MCP Server.

Provides commands for:
- authenticate: Connect to Datarails via OAuth (browser-based)
- disable: Disconnect and revoke tokens
- status: Check authentication status
- serve: Run the MCP server (called by Claude)
- setup: Configure Claude clients
"""

import asyncio
import json
import os
import sys
from pathlib import Path

import click

from datarails_mcp.constants import AUTH_SERVERS, DEFAULT_AUTH_ENV
from datarails_mcp.oauth import (
    AuthDeniedError,
    AuthError,
    AuthInProgressError,
    AuthTimeoutError,
    authenticate as oauth_authenticate,
    disable as oauth_disable,
)
from datarails_mcp.token_store import TokenStore

# Check for rich library (optional, for better output)
try:
    from rich.console import Console

    console = Console()
    RICH_AVAILABLE = True
except ImportError:
    console = None
    RICH_AVAILABLE = False


def echo(message: str, style: str | None = None, **kwargs):
    """Print message with optional styling (uses rich if available)."""
    if RICH_AVAILABLE and console and style:
        console.print(message, style=style, **kwargs)
    else:
        click.echo(message, **kwargs)


def echo_success(message: str):
    if RICH_AVAILABLE and console:
        console.print(f"[green]\u2713[/green] {message}")
    else:
        click.echo(f"\u2713 {message}")


def echo_error(message: str):
    if RICH_AVAILABLE and console:
        console.print(f"[red]\u2717[/red] {message}", style="red")
    else:
        click.echo(f"\u2717 {message}", err=True)


def echo_warning(message: str):
    if RICH_AVAILABLE and console:
        console.print(f"[yellow]![/yellow] {message}")
    else:
        click.echo(f"! {message}")


def echo_info(message: str):
    if RICH_AVAILABLE and console:
        console.print(f"[blue]\u2022[/blue] {message}")
    else:
        click.echo(f"\u2022 {message}")


@click.group()
@click.version_option(package_name="datarails-finance-os-mcp")
def main():
    """Datarails Finance OS MCP Server.

    A Model Context Protocol server that provides Claude with access
    to Datarails Finance OS data for analysis and insights.

    \b
    Quick start:
      datarails-mcp authenticate   # Connect to Datarails (opens browser)
      datarails-mcp status         # Check authentication status
      datarails-mcp serve          # Start the MCP server

    \b
    Disconnect:
      datarails-mcp disable        # Revoke tokens and log out

    For more information, visit: https://github.com/Datarails/dr-datarails-mcp-re
    """
    pass


@main.command()
@click.option(
    "--env",
    "auth_env",
    type=click.Choice(list(AUTH_SERVERS.keys()), case_sensitive=False),
    default=DEFAULT_AUTH_ENV,
    help=f"Auth server environment (default: {DEFAULT_AUTH_ENV})",
)
def authenticate(auth_env: str):
    """Connect to Datarails via OAuth.

    Opens your browser for login, environment selection, and consent.
    After approval, tokens are stored securely in your system keychain.

    \b
    Examples:
      datarails-mcp authenticate            # Uses prod (default)
      datarails-mcp authenticate --env dev   # Uses dev auth server
      datarails-mcp authenticate --env test  # Uses test auth server
    """
    store = TokenStore()

    # Check if already authenticated
    creds = store.load()
    if creds and not creds.is_jwt_expired:
        org = creds.connection.organization
        env = creds.connection.environment
        echo_success(f"Already authenticated — {org} ({env}).")
        echo_info("Run 'datarails-mcp disable' to disconnect and switch.")
        return

    auth_server_url = AUTH_SERVERS[auth_env]
    echo_info(f"Opening browser for Datarails authentication ({auth_env})...")
    echo("")

    try:
        creds = asyncio.run(oauth_authenticate(store, auth_server_url=auth_server_url))
        org = creds.connection.organization
        env = creds.connection.environment
        echo("")
        echo_success(f"Authenticated — {org} ({env})")
    except AuthInProgressError as e:
        echo_warning(f"Authentication already in progress (PID {e.pid}). Complete it in your browser.")
        sys.exit(1)
    except AuthTimeoutError:
        echo_error("Timed out. Run 'datarails-mcp authenticate' to retry.")
        sys.exit(1)
    except AuthDeniedError:
        echo_error("Authentication denied by user.")
        sys.exit(1)
    except AuthError as e:
        echo_error(f"Authentication failed: {e}")
        sys.exit(1)


@main.command()
def disable():
    """Disconnect from Datarails.

    Revokes JWT tokens on the server and clears local credentials.
    Run 'datarails-mcp authenticate' to reconnect.

    \b
    Examples:
      datarails-mcp disable
    """
    store = TokenStore()

    creds = store.load()
    if not creds:
        echo_info("Not authenticated. Nothing to do.")
        return

    org = creds.connection.organization
    env = creds.connection.environment

    result = asyncio.run(oauth_disable(store))

    if "Server revocation failed" in result.get("message", ""):
        echo_success(f"Disabled — local tokens cleared. [{org} ({env})]")
        echo_warning("Server revocation failed — tokens will expire.")
    else:
        echo_success(f"Disabled — logged out from {org} ({env}). Tokens revoked.")


@main.command()
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output status as JSON",
)
def status(output_json: bool):
    """Check authentication status.

    Shows whether you're connected to Datarails and displays
    connection details.

    \b
    Examples:
      datarails-mcp status         # Human-readable output
      datarails-mcp status --json  # JSON output
    """
    store = TokenStore()
    creds = store.load()

    if creds:
        status_data = {
            "authenticated": True,
            "organization": creds.connection.organization,
            "environment": creds.connection.environment,
            "api_url": creds.connection.api_url,
            "jwt_expires_in_seconds": int(creds.jwt_expires_in),
            "jwt_expired": creds.is_jwt_expired,
        }
    else:
        status_data = {
            "authenticated": False,
            "message": "Not authenticated. Run 'datarails-mcp authenticate' to connect.",
        }

    if output_json:
        click.echo(json.dumps(status_data, indent=2))
        return

    # Human-readable output
    echo("")
    echo("Datarails MCP Status")
    echo("=" * 40)
    echo("")

    if creds:
        echo_success("Authenticated")
        echo_info(f"Organization: {creds.connection.organization}")
        echo_info(f"Environment: {creds.connection.environment}")
        echo_info(f"API URL: {creds.connection.api_url}")

        expires_in = int(creds.jwt_expires_in)
        if expires_in > 0:
            echo_info(f"JWT expires in: {expires_in}s")
        else:
            echo_warning("JWT expired (will auto-refresh on next API call)")
    else:
        echo_error("Not authenticated")
        echo_info("Run 'datarails-mcp authenticate' to connect")

    echo("")


@main.command()
def serve():
    """Run the MCP server.

    This command is called by Claude clients (Claude Code, Claude Desktop)
    to start the MCP server. You typically don't need to run this manually.

    The server communicates via stdio using the MCP protocol.
    """
    from datarails_mcp.server import main as server_main

    server_main()


@main.command()
@click.option(
    "--claude-code",
    is_flag=True,
    help="Configure Claude Code (global settings)",
)
@click.option(
    "--claude-desktop",
    is_flag=True,
    help="Configure Claude Desktop",
)
@click.option(
    "--project",
    is_flag=True,
    help="Configure current project (.mcp.json)",
)
def setup(claude_code: bool, claude_desktop: bool, project: bool):
    """Configure Claude clients to use this MCP server.

    Automatically detects and configures available Claude clients.
    If no specific client is selected, configures all detected clients.

    \b
    Examples:
      datarails-mcp setup                    # Auto-detect and configure all
      datarails-mcp setup --claude-code      # Configure Claude Code only
      datarails-mcp setup --claude-desktop   # Configure Claude Desktop only
      datarails-mcp setup --project          # Configure current project only
    """
    configure_all = not (claude_code or claude_desktop or project)

    if configure_all:
        echo_info("Auto-detecting Claude clients...")
        echo("")

    configs_updated = []

    if configure_all or claude_code:
        path = _get_claude_code_config_path()
        if path:
            if _configure_client(path, "Claude Code (global)"):
                configs_updated.append(("Claude Code (global)", path))

    if configure_all or claude_desktop:
        path = _get_claude_desktop_config_path()
        if path:
            if _configure_client(path, "Claude Desktop"):
                configs_updated.append(("Claude Desktop", path))

    if configure_all or project:
        path = Path.cwd() / ".mcp.json"
        if _configure_client(path, "Project"):
            configs_updated.append(("Project", path))

    echo("")
    if configs_updated:
        echo_success(f"Configured {len(configs_updated)} client(s):")
        for name, path in configs_updated:
            echo_info(f"  {name}: {path}")
        echo("")
        echo_info("Restart your Claude client for changes to take effect.")
    else:
        echo_warning("No Claude clients were configured.")
        echo_info("Run with --project to create a project config file.")


def _get_claude_code_config_path() -> Path | None:
    config_dir = Path.home() / ".claude"
    if config_dir.exists():
        return config_dir / "settings.json"
    return None


def _get_claude_desktop_config_path() -> Path | None:
    if sys.platform == "darwin":
        path = Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            path = Path(appdata) / "Claude" / "claude_desktop_config.json"
        else:
            return None
    else:
        path = Path.home() / ".config" / "claude" / "claude_desktop_config.json"

    if path.parent.exists():
        return path
    return None


def _configure_client(path: Path, name: str) -> bool:
    """Configure a Claude client config file."""
    path.parent.mkdir(parents=True, exist_ok=True)

    config = {}
    if path.exists():
        try:
            config = json.loads(path.read_text())
        except json.JSONDecodeError:
            echo_warning(f"  {name}: Invalid JSON, creating new config")
            config = {}

    if "mcpServers" not in config:
        config["mcpServers"] = {}

    config["mcpServers"]["datarails-finance-os"] = {
        "command": "datarails-mcp",
        "args": ["serve"],
    }

    try:
        path.write_text(json.dumps(config, indent=2) + "\n")
        echo_success(f"  {name}: Configured")
        return True
    except Exception as e:
        echo_error(f"  {name}: Failed to write config - {e}")
        return False


if __name__ == "__main__":
    main()
