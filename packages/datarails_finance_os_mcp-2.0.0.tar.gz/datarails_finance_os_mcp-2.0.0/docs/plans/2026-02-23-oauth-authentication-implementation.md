# OAuth Authentication Implementation Plan

**Based on:** `MCP_AUTHENTICATION_HLD.md` (2026-02-19)
**Scope:** MCP server repository only (`dr-datarails-mcp-re`)
**Date:** 2026-02-23

---

## Summary

Replace browser cookie extraction auth with OAuth 2.0 Authorization Code + PKCE.
Two new files (`oauth.py`, `token_store.py`), three modified files (`server.py`, `client.py`, `cli.py`),
three deleted files (`auth.py`, `browser_cookies.py`, `config/environments.json`),
updated tests, updated dependencies.

---

## Step-by-step Plan

### Step 1: Create `token_store.py` — keyring persistence layer

**File:** `src/datarails_mcp/token_store.py` (new)

**What:** Data models and keyring read/write for all OAuth + JWT credentials.

**Contains:**
- `Connection` dataclass (`token_url`, `revoke_url`, `api_url`, `environment`, `organization`, `organization_id`)
- `StoredCredentials` dataclass (`oauth_token`, `jwt_access_token`, `jwt_refresh_token`, `jwt_expires_at`, `connection`)
- `TokenStore` class:
  - `save(credentials: StoredCredentials) -> None` — serialize to JSON, write to keyring (`datarails-mcp` / `oauth-tokens`)
  - `load() -> StoredCredentials | None` — read from keyring, deserialize
  - `clear() -> None` — delete from keyring
  - `has_credentials() -> bool`
- Reuse existing keyring timeout wrappers (`_keyring_get_with_timeout`, `_keyring_set_with_timeout`, `_keyring_delete_with_timeout`) — extract these from current `auth.py` into a private `_keyring.py` helper or keep inline in `token_store.py`

**Depends on:** nothing
**Tests:** `tests/test_token_store.py` — serialize/deserialize round-trip, clear, missing keyring fallback

---

### Step 2: Create `oauth.py` — OAuth flow engine

**File:** `src/datarails_mcp/oauth.py` (new)

**What:** Full OAuth 2.0 Authorization Code + PKCE flow against `auth.datarails.com`.

**Contains:**
- `AUTH_SERVER = "https://auth.datarails.com"`
- `CLIENT_ID = "datarails-mcp"`
- PKCE generation:
  - `_generate_code_verifier() -> str` (43-128 chars, RFC 7636)
  - `_generate_code_challenge(verifier: str) -> str` (BASE64URL(SHA256(verifier)))
  - `_generate_state() -> str` (random 32 bytes, hex)
- Lock file management (`/tmp/datarails-mcp-auth.lock`):
  - `_acquire_lock() -> bool` — check PID alive + age < 3 min
  - `_release_lock() -> None`
  - `_is_lock_stale(lock_data: dict) -> bool`
- Localhost callback server (aiohttp):
  - `_start_callback_server() -> tuple[aiohttp.web.AppRunner, int, asyncio.Future]`
  - Handler: verify `state`, extract `code` or `error`, signal future, return HTML "success/failure" page
  - Port selection: try random ports, up to 5 attempts
- Main flow orchestrator:
  - `async authenticate() -> StoredCredentials` — the 13-step flow from HLD:
    1. Acquire lock
    2. Generate PKCE + state
    3. Start callback server on `localhost:{port}`
    4. Open browser to `auth.datarails.com/oauth/authorize?...`
    5. Await callback (120s timeout)
    6. Verify state
    7. POST `auth.datarails.com/oauth/token` (code exchange) -> `oauth_token` + `connection`
    8. POST `{connection.token_url}` (JWT exchange, `grant_type=oauth_token`) -> `jwt_access + jwt_refresh`
    9. Build `StoredCredentials`, return
    10. Finally: stop callback server, release lock
- `async disable(store: TokenStore) -> None`:
  - Load credentials from store
  - POST `{revoke_url}` with `jwt_refresh_token`
  - Clear store (even if revoke fails)

**Depends on:** Step 1 (TokenStore, Connection, StoredCredentials)
**Tests:** `tests/test_oauth.py` — PKCE generation, state verification, lock file logic, code exchange (mocked HTTP), error paths (timeout, denied, stale lock)

---

### Step 3: Update `constants.py` — remove environment config

**File:** `src/datarails_mcp/constants.py` (modify)

**What:** Remove multi-environment URL management. MCP now knows only `auth.datarails.com`; all env URLs come from OAuth flow.

**Changes:**
- Remove `DEFAULT_ENVIRONMENTS` dict
- Remove `_load_environments_config()`, `_save_environments_config()`
- Remove `get_environments()`, `get_active_environment()`, `set_active_environment()`, `get_environment_names()`
- Remove `_EnvironmentsProxy`, `ENVIRONMENTS`
- Remove `DEFAULT_ENV`
- Keep `KEYRING_SERVICE = "datarails-mcp"` (used by token_store)
- Keep `AUTH_TIMEOUT_SECONDS`, `AUTH_CALLBACK_PATH`, `LOCAL_AUTH_HOST`
- Add `AUTH_SERVER_URL = "https://auth.datarails.com"`
- Add `CLIENT_ID = "datarails-mcp"`
- Add `LOCK_FILE_PATH = "/tmp/datarails-mcp-auth.lock"`
- Add `LOCK_MAX_AGE_SECONDS = 180`
- Add `CALLBACK_TIMEOUT_SECONDS = 120`
- Add `MAX_PORT_ATTEMPTS = 5`

**Depends on:** nothing (but Steps 1-2 import from here)
**Tests:** none needed (pure constants)

---

### Step 4: Update `client.py` — use JWT from TokenStore + auto-refresh via `{token_url}`

**File:** `src/datarails_mcp/client.py` (modify)

**What:** Replace `BrowserAuth`/`EnvAuth` dependency with `TokenStore`-based auth. Use dynamic `api_url` from connection info. Auto-refresh JWT via `{token_url}`.

**Changes:**
- Remove `from datarails_mcp.auth import BrowserAuth, EnvAuth`
- Constructor: `__init__(self, store: TokenStore)` instead of `__init__(self, auth: BrowserAuth | EnvAuth)`
- `self.store = store` — loads credentials on demand
- `self.base_url` -> computed from `store.load().connection.api_url` (no more hardcoded env URLs)
- New `_ensure_auth()`:
  - Load credentials from store
  - If no credentials -> return error "Run /authenticate"
  - If `jwt_expires_at` is near expiry -> call `_refresh_jwt()`
  - Return None if OK
- New `async _refresh_jwt()`:
  - POST `{token_url}` with `grant_type=refresh_token`, `refresh_token`, `client_id`
  - On success: update `jwt_access_token`, `jwt_refresh_token`, `jwt_expires_at` in store
  - On 401/failure: clear store, return error "Session expired. Run /authenticate"
- `_request()`: use `api_url` from connection instead of `self.base_url + "/finance-os/api"`
  - URL construction: `{api_url}{endpoint}` (api_url already includes `/finance-os/api`)
- `get_headers()`: just `Authorization: Bearer {jwt_access_token}` (no more CSRF header)
- Remove all `BrowserAuth`/`EnvAuth` branching (isinstance checks, needs_auth_response, clear_cookies)

**Depends on:** Step 1 (TokenStore)
**Tests:** update `tests/test_server.py` — mock TokenStore instead of auth classes

---

### Step 5: Update `server.py` — replace 4 auth tools with 3 new ones

**File:** `src/datarails_mcp/server.py` (modify)

**What:** Replace `check_auth_status`, `set_auth_cookies`, `clear_auth_cookies`, `get_cookie_extraction_script` with `authenticate`, `disable`, `auth_status`.

**Changes:**
- Remove old imports: `from datarails_mcp.auth import BrowserAuth, get_auth, set_session_cookies, clear_auth`
- Add new imports: `from datarails_mcp.oauth import authenticate as oauth_authenticate, disable as oauth_disable` and `from datarails_mcp.token_store import TokenStore`
- Replace global `_client` init:
  - `_store = TokenStore()`
  - `get_client()` creates `DatarailsClient(_store)` instead of `DatarailsClient(get_auth())`
  - Remove stale-auth re-creation logic (no more checking if cookies appeared externally)
- **New tool `authenticate()`:**
  - Check if already authenticated -> "Already authenticated — {org} ({env}). Run /disable to switch."
  - Call `oauth_authenticate()` (the full OAuth flow)
  - Save result to `_store`
  - Return "Authenticated — {org} ({env})"
  - Handle errors: lock contention, timeout, denied
- **New tool `disable()`:**
  - Check if authenticated -> if not, "Not authenticated. Nothing to do."
  - Call `oauth_disable(_store)`
  - Reset client
  - Return "Disabled — logged out from {org} ({env}). Tokens revoked."
  - Handle revoke failure gracefully
- **New tool `auth_status()`:**
  - Load from store, return structured status: authenticated (bool), environment, organization, jwt_expires_in
- Remove `_AGGREGATION_FIELD_ALTERNATIVES` logic changes (keep as-is, unrelated to auth)
- Remove `--env` params from `generate_intelligence_workbook` and `extract_financials` — env comes from stored connection

**Depends on:** Steps 1, 2, 4
**Tests:** update `tests/test_server.py` — test new tools with mocked OAuth flow

---

### Step 6: Update `cli.py` — replace `auth` command with `authenticate` / `disable`

**File:** `src/datarails_mcp/cli.py` (modify)

**What:** Replace multi-env auth CLI with two simple commands.

**Changes:**
- Remove imports: `browser_cookies`, old `auth` functions, `constants` env functions
- Remove `EnvChoice`, `ENV_CHOICE`
- **Remove `auth` command** (and all sub-functions: `_list_environments`, `_logout_env`, `_logout_all`, `_switch_environment`, `_auth_manual`, `_auth_browser_cookies`)
- **Remove `envs` command**
- **New `authenticate` command:**
  - No flags (no `--env`)
  - Calls `oauth_authenticate()` (async, run via `asyncio.run()`)
  - Prints result or error messages matching HLD Section 8.1
- **New `disable` command:**
  - No flags
  - Calls `oauth_disable(TokenStore())` (async)
  - Prints result matching HLD Section 8.2
- **Update `status` command:**
  - Remove `--env`, `--all` flags
  - Load from `TokenStore`, show: authenticated (bool), org, env, jwt_expires_in
  - Keep `--json` flag
- **Keep `serve` command** as-is
- **Update `setup` command:**
  - Remove `--env` flag
  - Server config no longer needs `DATARAILS_ENV` env var

**Depends on:** Steps 1, 2
**Tests:** manual CLI testing

---

### Step 7: Update `__init__.py` — clean up public API

**File:** `src/datarails_mcp/__init__.py` (modify)

**What:** Export new auth classes, remove old ones.

**Changes:**
- Remove: `BrowserAuth`, `EnvAuth`, `get_auth`, `set_session_cookies`, `clear_auth`, `clear_all_auth`, `get_authenticated_environments`, `get_environments`, `get_environment_names`, `get_active_environment`, `set_active_environment`
- Add: `TokenStore`, `StoredCredentials`, `Connection`, `authenticate`, `disable`
- Keep: `DatarailsClient`

**Depends on:** Steps 1, 2, 4

---

### Step 8: Delete old files

**Files to delete:**
- `src/datarails_mcp/auth.py` — replaced by `oauth.py` + `token_store.py`
- `src/datarails_mcp/browser_cookies.py` — no longer needed
- `config/environments.json` — URLs come from auth.datarails.com

**Depends on:** Steps 1-7 (all new code in place)

---

### Step 9: Update `pyproject.toml` — dependencies

**File:** `pyproject.toml` (modify)

**Changes:**
- Remove: `browser-cookie3>=0.20.0` (no more cookie extraction)
- Remove: `cryptography>=46.0.5` (was for cookie decryption)
- Keep: `aiohttp>=3.9.0` (used for callback server)
- Keep: `keyring>=25.0.0` (still used by TokenStore)
- Bump version: `1.0.0` -> `2.0.0` (breaking auth change)

**Depends on:** nothing

---

### Step 10: Write tests

**Files:**
- `tests/test_token_store.py` (new)
- `tests/test_oauth.py` (new)
- `tests/test_server.py` (rewrite auth tests)
- `tests/test_client.py` (extract from test_server.py, update for TokenStore)

**test_token_store.py:**
- `test_save_and_load_roundtrip` — save credentials, load, verify all fields match
- `test_load_empty` — returns None when no credentials
- `test_clear` — save then clear, verify load returns None
- `test_has_credentials` — True after save, False after clear
- `test_keyring_timeout` — verify doesn't hang if keyring is unavailable

**test_oauth.py:**
- `test_generate_code_verifier_length` — 43-128 chars
- `test_generate_code_verifier_charset` — only unreserved chars
- `test_generate_code_challenge` — known test vector from RFC 7636
- `test_generate_state_uniqueness` — two calls produce different values
- `test_lock_acquire_and_release` — happy path
- `test_lock_stale_removal` — dead PID or old lock gets removed
- `test_lock_contention` — live PID, recent lock -> error
- `test_authenticate_success` — mock HTTP: code exchange + JWT exchange, verify StoredCredentials
- `test_authenticate_denied` — callback with `error=access_denied`
- `test_authenticate_timeout` — no callback within 120s
- `test_authenticate_already_authenticated` — store has credentials -> short-circuit
- `test_disable_success` — mock revoke endpoint, verify store cleared
- `test_disable_revoke_fails` — network error, still clears local store
- `test_disable_not_authenticated` — no credentials -> "Nothing to do"

**test_server.py updates:**
- Remove `TestBrowserAuth`, `TestEnvAuth`, `TestGetAuth` classes
- Update `TestMCPServerAuthTools` -> test `authenticate`, `disable`, `auth_status`
- Update `TestDatarailsClient` fixtures to use mocked `TokenStore`
- Keep data tool tests as-is

**Depends on:** Steps 1-8

---

### Step 11: Update Dockerfile

**File:** `Dockerfile` (modify)

**Changes:**
- Remove `libsecret-1-0` if keyring fallback is sufficient in Docker (or keep if using SecretService backend)
- No other changes — `datarails-mcp serve` still works

**Depends on:** nothing

---

### Step 12: Update README.md and .mcp.json.example

**Files:** `README.md`, `.mcp.json.example` (modify)

**Changes:**
- Update auth instructions: remove cookie extraction, add `/authenticate` flow
- Update CLI examples: `datarails-mcp authenticate` / `datarails-mcp disable`
- Remove `--env` references
- Update `.mcp.json.example`: remove `DATARAILS_ENV` from env vars

**Depends on:** Steps 1-10

---

## Dependency Graph

```
Step 3 (constants)  ─────────────────────────────────────┐
                                                          │
Step 1 (token_store) ──┬── Step 2 (oauth) ──┐            │
                       │                     │            │
                       ├── Step 4 (client) ──┼── Step 5 (server) ──┐
                       │                     │                      │
                       └── Step 6 (cli) ─────┘                     │
                                                                    │
                                             Step 7 (__init__) ─────┤
                                                                    │
                                             Step 8 (delete old) ───┤
                                                                    │
Step 9 (pyproject.toml) ───────────────────────────────────────────┤
                                                                    │
                                             Step 10 (tests) ──────┤
                                                                    │
Step 11 (Dockerfile) ──────────────────────────────────────────────┤
                                                                    │
Step 12 (README) ──────────────────────────────────────────────────┘
```

**Parallel tracks:**
- Steps 1 + 3 + 9 can start simultaneously
- Steps 2, 4, 6 depend on Step 1
- Step 5 depends on Steps 2 + 4
- Steps 7, 8 depend on all code being in place
- Step 10 can partially start with Steps 1-2

---

## Execution Order (sequential)

| Order | Step | Description | Est. Size |
|-------|------|-------------|-----------|
| 1 | Step 3 | Update constants.py | ~50 lines changed |
| 2 | Step 1 | Create token_store.py | ~120 lines new |
| 3 | Step 2 | Create oauth.py | ~250 lines new |
| 4 | Step 4 | Update client.py | ~150 lines changed |
| 5 | Step 5 | Update server.py | ~100 lines changed |
| 6 | Step 6 | Update cli.py | ~300 lines changed |
| 7 | Step 7 | Update __init__.py | ~20 lines changed |
| 8 | Step 8 | Delete old files | 3 files deleted |
| 9 | Step 9 | Update pyproject.toml | ~5 lines changed |
| 10 | Step 10 | Write/update tests | ~400 lines new/changed |
| 11 | Step 11 | Update Dockerfile | ~2 lines changed |
| 12 | Step 12 | Update docs | ~50 lines changed |

**Total:** ~2 new files, ~6 modified files, ~3 deleted files, ~1,450 lines of work

---

## Risk Notes

1. **Backend not ready:** auth.datarails.com OAuth endpoints may not exist yet. Implementation can proceed with mocked endpoints in tests. Consider a feature flag or env var (`DATARAILS_AUTH_SERVER`) to override auth server URL for testing.

2. **EnvAuth removal:** CI pipelines using `DATARAILS_SESSION_ID` / `DATARAILS_JWT_TOKEN` env vars will break. Consider keeping `EnvAuth` as a fallback path in `client.py` (check env vars first, then TokenStore). This is a decision point — HLD doesn't mention it.

3. **Backward compatibility:** This is a breaking change (v2.0.0). Old auth data in keyring (`session_{env}` accounts) will be orphaned. `TokenStore` uses a new keyring account (`oauth-tokens`), so no conflict.

4. **aiohttp in MCP context:** The callback server uses aiohttp. Since MCP server already runs an asyncio event loop, the callback server needs to run within it (not `asyncio.run()`). The CLI authenticate command will need its own `asyncio.run()`.
