"""
Adapter implementations for data and trade gateways.
"""
