from fractal_repositories.contrib.gcp.firestore.mixins import (
    FirestoreRepositoryMixin,
)

__all__ = ["FirestoreRepositoryMixin"]
