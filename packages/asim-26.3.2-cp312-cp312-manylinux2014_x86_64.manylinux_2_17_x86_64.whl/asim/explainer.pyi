import logging

from .dataset import PhysicalDataManage
from .model import PhysicalFieldModel

log = logging.getLogger(__name__)

class Explainer:
    def __init__(self, dm: PhysicalDataManage, fm: PhysicalFieldModel):
        pass

    def checkGrad(self, n_samples=5000):
        pass
