import pandas as pd

class DummyDatasets:
    @classmethod
    def boiler_minimum(cls, size: int = 1440 * 2, seed: int = 42):
        pass

    @classmethod
    def boiler_complex(cls, size: int = 1440 * 2, seed: int = 42):
        pass
