"""
FluxLoop CLI - Command-line interface for running agent simulations.
"""

__version__ = "0.3.11"

from .main import app

__all__ = ["app"]
