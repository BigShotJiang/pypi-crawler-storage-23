"""Shared file handling utilities used by both Telegram bot and API server."""
