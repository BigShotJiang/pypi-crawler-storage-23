"""SimpleAIBLE – an AI-friendly MCP server for BLE devices powered by SimplePyBLE."""
