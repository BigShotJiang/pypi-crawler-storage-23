"""scrapli_scp.asyncscp.base"""
import asyncio
import hashlib
import os
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import PurePath, Path
from time import time
from typing import Literal, Optional, TypedDict, Union
from collections.abc import Callable
from scrapli.driver.network import AsyncNetworkDriver

import aiofiles
import asyncssh
from asyncssh import SSHClientConnectionOptions, connect
from scrapli_scp.logging import logger


@dataclass()
class FileCheckResult:
    """
    hash - hash value string (empty on error)

    size - size in bytes

    free - free space in bytes (0 on error)
    """

    hash: str
    size: int
    free: int


@dataclass()
class SCPConnectionParameterType(TypedDict):
    """
    Collection of authentication data needed to open a second SCP connection to the device.

    username: SSH username

    password: SSH password

    host: SSH host

    port: SSH port

    options: current SSH connection options
    """

    username: str
    password: str
    host: str
    port: int
    options: SSHClientConnectionOptions


@dataclass()
class FileTransferResult:
    """
    exists - True if destination existed or created

    transferred - True if the file was transferred

    verified - True if files are identical (hashes match)
    """

    exists: bool
    transferred: bool
    verified: bool


class AsyncSCPFeature(ABC):
    """
    This class extends a driver with SCP capabilities

    You need to implement device-specific methods. If your device does not support that method,
    just return a value described in the abstract methods.
    """

    def __init__(self, connection: AsyncNetworkDriver):
        # \x0C is CTRL-L that usually refresh the prompt and harmless to send as keepalive
        self.keepalive_pattern = "\x0C"
        self.conn = connection

    @abstractmethod
    async def check_device_file(self, device_fs: Optional[str], file_name: str) -> FileCheckResult:
        """
        Check remote file and storage space
        Returning empty hash means error accessing the file

        Args:
            device_fs: filesystem on the device (e.g., disk0:/)
            file_name: file to examine

        Returns:
            FileCheckResult
        """
        ...

    @abstractmethod
    async def _ensure_scp_capability(self, force: Optional[bool] = False) -> Union[bool, None]:
        """
        Ensure the device is capable of using scp.

        Args:
            force: Try to reconfigure the device if it doesn't support scp. If set to `None`, don't check
                   anything.

        Returns:
            bool: `True` if the device supports scp now, and we changed the configuration.
                  `False` if the device does not support scp, or we didn't force configuration which was
                          needed.
                  `None` if we are good to proceed, or we didn't check at all.
        """
        ...

    @abstractmethod
    async def _cleanup_after_transfer(self) -> None:
        """
        Device-specific cleanup procedure if needed. Useful to restore configuration in case
        _ensure_scp_capability reconfigured the device.

        Returns:
            None
        """
        ...

    @abstractmethod
    async def _get_device_fs(self) -> Optional[str]:
        """
        Device-specific drive detection.

        Returns:
            Drive as a string. E.g., disk0:/ or flash0:/
            `None`, if the drive is not detected, or detection is not supported
        """
        ...

    @staticmethod
    async def check_local_file(device_fs: Optional[str], file_name: str) -> FileCheckResult:
        """
        Check local file and storage space

        Args:
            device_fs: If specified, this path will be checked for free space. Otherwise, the path will be
                       taken from `file_name`
            file_name: local file to examine. This should be the full path of the local file

        Returns:
            FileCheckResult
        """
        try:
            async with aiofiles.open(file_name, "rb") as f:
                file_hash = hashlib.md5(await f.read()).hexdigest()
                logger.debug(f"'{file_name}' hash is '{file_hash}'")
            file_size = os.path.getsize(file_name)
        except FileNotFoundError:
            file_size = 0
            file_hash = ""
        try:
            path = device_fs if device_fs else os.path.dirname(file_name)
            # check free space in the directory of the file or the local dir
            free_space = shutil.disk_usage(path if path else ".").free
        except FileNotFoundError:
            free_space = 0
        return FileCheckResult(hash=file_hash, size=file_size, free=free_space)

    async def _async_file_transfer(  # noqa: C901
        self,
        operation: Literal["get", "put"],
        src: str,
        dst: str,
        progress_handler: Optional[Callable[[str, str, int, int], None]] = None,
        prevent_timeout: Optional[float] = None,
        block_size: int = 65536,
    ) -> bool:
        """
        SCP a file from device to localhost

        Args:
            operation: 'get' or 'put' files from or to the device
            src: Source file name
            dst: Destination file name
            progress_handler: scp callback function to be able to follow the copy progress
            prevent_timeout: interval in seconds when we send an empty command to keep the SSH channel
                             up, 0 to turn it off,
                             default is same as `timeout_ops`
            block_size: Amount of bytes to transfer at once

        Returns:
            bool: True on success
        """

        copy_finished = asyncio.Event()
        if prevent_timeout is None:
            prevent_timeout = self.conn.timeout_ops

        async def _prevent_timeout(timeout: float):
            """Send preventive char to the idle SSH channel to prevent timing out while transferring the file"""
            nonlocal start_time, copy_finished
            timeout_start = time()
            while not copy_finished.is_set():
                await asyncio.sleep(0.5)
                if not self.conn.isalive():
                    break
                if 0 < timeout <= (time() - timeout_start):
                    logger.debug("Preventing timeout")
                    self.conn.channel.write(self.keepalive_pattern)
                    timeout_start = time()

        def error_handler(exc: Exception):
            logger.error(f"SCP error: {exc}")
            raise exc

        # Helper to run the actual SCP
        async def _do_scp(conn_obj):
            if operation == "get":
                await asyncssh.scp(
                    (conn_obj, src),
                    dst,
                    progress_handler=progress_handler,
                    block_size=block_size,
                    error_handler=error_handler,
                )
            else:  # put
                await asyncssh.scp(
                    src,
                    (conn_obj, dst),
                    progress_handler=progress_handler,
                    block_size=block_size,
                    error_handler=error_handler,
                )

        async def _do_scp_with_keepalive(conn_obj):
            timeout_task = asyncio.create_task(_prevent_timeout(prevent_timeout))
            scp_task = asyncio.create_task(_do_scp(conn_obj))
            try:
                # Run both concurrently but wait for SCP to finish
                await scp_task
            except (asyncio.CancelledError, Exception):
                # Non-cancellation error: clean up and propagate
                copy_finished.set()
                if not timeout_task.done():
                    timeout_task.cancel()
                try:
                    await timeout_task
                except asyncio.CancelledError:
                    pass
                raise
            finally:
                # Ensure the keepalive loop exits and the task is cleaned up
                copy_finished.set()
                if not timeout_task.done():
                    timeout_task.cancel()
                try:
                    await timeout_task
                except asyncio.CancelledError:
                    pass

        result = False
        try:
            start_time = time()
            try:
                await _do_scp_with_keepalive(self.conn.transport.session)
            except asyncssh.misc.ChannelOpenError as e:
                logger.debug(f"SCP channel refused on existing session. Falling back to a fresh AsyncSSH connection...")
                copy_finished.clear()
                # Open a new AsyncSSH connection directly
                async with connect(
                        self.conn.host,
                        username=self.conn.auth_username,
                        password=self.conn.auth_password,
                        options=self.conn.transport.session._options,
                ) as fresh_conn:
                    await _do_scp_with_keepalive(fresh_conn)
            result = True

        except (asyncssh.SFTPError,) as e:
            logger.warning(f"SCP error: {e}")
        except Exception as e:
            logger.warning(f"Other error: {e}")
            raise e
        else:
            elapsed = time() - start_time
            logger.info(f"SCP {operation} completed in {elapsed:.2f} seconds")

        return result

    async def file_transfer(  # noqa: C901
        self,
        operation: Literal["get", "put"],
        src: str,
        dst: str = "",
        verify: bool = True,
        device_fs: Optional[str] = None,
        overwrite: bool = False,
        force_scp_config: bool = False,
        cleanup: bool = True,
        progress_handler: Optional[Callable] = None,
        prevent_timeout: Optional[float] = None,
        block_size: int = 65536,
    ) -> FileTransferResult:
        """SCP for network devices

        This transfer is idempotent and does the following checks before/after transfer:

        #. | checksum
        #. | existence of the file at destination (also with hash)
        #. | available space at destination
        #. | scp enablement on the device (and tries to turn it on if needed)
        #. | restore configuration after transfer if it was changed
        #. | check MD5 after transfer

        The file won't be transferred if the hash of the files on local/device is the same!

        Args:
            operation: put/get file to/from device
            src: source file name
            dst: destination file name (same as src if omitted)
            verify: `True` if verification is needed (checksum, file existence, disk space)
            device_fs: IOS device filesystem (autodetect if empty)
            overwrite: If set to `True`, destination will be overwritten in case hash verification
                       fails
                       If set to `False`, the destination file won't be overwritten.
                       Beware: turning off `verify` will make this parameter ignored, and the destination
                        will be overwritten regardless! (Logic is that if the user does not care about
                        checking, just copy it over)
            force_scp_config: If set to `True`, SCP function will be enabled in the device configuration
                               before transfer.
                              If set to `False`, SCP functionality will be checked but won't
                              configure the device.
                              If set to `None`, capability won't be checked.
            cleanup: If set to True, call the cleanup procedure to restore configuration if it was
                     altered
            progress_handler: function to call by file copy (used by asyncssh.scp function)
            prevent_timeout: interval in seconds when we send an empty command to keep the SSH channel
                             up, 0 to turn it off, default is the same as `timeout_ops`
            block_size: Amount of bytes to transfer at once (default 32000)

        Returns:
            FileTransferResult
        """
        result = FileTransferResult(False, False, False)
        src_file_data = FileCheckResult("", 0, 0)
        dst_file_data = FileCheckResult("", 0, 0)
        if prevent_timeout is None:
            prevent_timeout = self.conn.timeout_ops
        dst_device_fs: Optional[str] = None
        src_device_fs: Optional[str] = None

        # set the destination filename to source if missing
        if dst in ("", "."):
            # set destination to filename and strip all paths
            dst = PurePath(src).name

        # Detect default filesystem the device uses
        if not device_fs:
            device_fs = await self._get_device_fs()

        if operation == "get":
            src_check = self.check_device_file
            src_device_fs = device_fs
            dst_check = self.check_local_file
            logger.info(f"Downloading '{src_device_fs+src}' as '{dst}'")
        elif operation == "put":
            src_check = self.check_local_file
            dst_check = self.check_device_file
            dst_device_fs = device_fs
            logger.info(f"Uploading '{src}' as '{dst_device_fs+dst}'")
        else:
            raise ValueError(f"Operation '{operation}' is not supported")
        if verify:
            # gather info on the source side
            src_file_data = await src_check(src_device_fs, src)
            logger.debug(f"Source file '{src}': {src_file_data}")
            if not src_file_data.hash:
                # source file cannot be found, we are done here
                logger.warning(f"Source file '{src}' does NOT exists!")
                return result
            # gather info on the destination file
            dst_file_data = await dst_check(dst_device_fs, dst)
            logger.debug(f"Destination file '{dst}': {dst_file_data}")
            # check if the destination file exists
            if dst_file_data.hash:
                result.exists = True
            # check if the destination file has the same hash as the source
            if dst_file_data.hash and src_file_data.hash == dst_file_data.hash:
                result.verified = True
                # no need to transfer the file
                logger.debug(f"'{dst}' file already exists at destination and verified OK")
                return result

            # if hash does not match and we want to overwrite
            if dst_file_data.hash and not overwrite:
                logger.warning(f"'{dst}' file will NOT be overwritten!")
                return result

            # check if we have enough free space to transfer the file
            if dst_file_data.free < src_file_data.size:
                logger.warning(
                    f"'{dst}' file is too big ({src_file_data.size}). Destination free space: "
                    f"{dst_file_data.free}"
                )
                return result

        # check if we are capable of transferring files
        scp_capability = await self._ensure_scp_capability(force=force_scp_config)
        if scp_capability is False:
            logger.error("SCP feature is not enabled on device!")
            return result

        _need_to_cleanup = scp_capability

        # transfer the file
        try:
            _transferred = await self._async_file_transfer(
                operation,
                src,
                dst,
                progress_handler=progress_handler,
                prevent_timeout=prevent_timeout,
                block_size=block_size,
            )
            result.transferred = _transferred
        except asyncio.CancelledError:
            logger.error("SCP operation was cancelled!")
            raise
        except Exception as e:
            raise e

        # clean up if needed
        if cleanup and _need_to_cleanup:
            await self._cleanup_after_transfer()

        if verify:
            # check destination file after copy
            dst_file_data = await dst_check(dst_device_fs, dst)
            # check if the file was created
            if dst_file_data.hash:
                result.exists = True
            # check if the file has the same hash as the source
            if dst_file_data.hash and dst_file_data.hash == src_file_data.hash:
                result.verified = True
            else:
                logger.warning(f"'{dst}' failed hash verification!")
        else:
            # assuming transfer created the file even if we did not check hash
            if result.transferred:
                result.exists = True
        return result
