"""scrapli_scp.exceptions"""


class ScrapliSCPException(Exception):
    pass
