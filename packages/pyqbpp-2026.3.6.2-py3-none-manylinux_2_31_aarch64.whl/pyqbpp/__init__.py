# @file pyqbpp.py
# @brief QUBO++ Python binding via ctypes (C++ backend)
# @copyright Copyright (c) 2025-2026 Koji Nakano
# @license Following the QUBO++ license
# @author Koji Nakano
# @version 2026.03.06
# @note Uses libpyqbpp.so for symbolic computation and solver.

"""
pyqbpp - Python QUBO++ Symbolic Computation Library (C++ backend)

Provides symbolic computation for HUBO/QUBO expressions:
  Var     - Binary variable
  Term    - Polynomial term: coeff * var1 * var2 * ...
  Expr    - Expression: constant + sum of terms
  ExprExpr - Constraint expression (returned by == and between())
  VarIntCore - Name holder for deferred VarInt creation
  VarInt  - Integer variable encoded with binary variables
  Vector  - Multi-dimensional variable/expression array

Usage:
  from pyqbpp import var, var_int, expr, sum, sqr, vector_sum, simplify_as_binary, between
"""

# Save Python builtins before we shadow them
import builtins as _builtins
builtins_sum = _builtins.sum

import ctypes
import os
import sys

# ============================================================
# Library loading
# ============================================================

def _find_lib():
    """Find libpyqbpp.so."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for path in [
        os.path.join(script_dir, "libpyqbpp.so"),
        os.environ.get("PYQBPP_LIB_PATH", ""),
        "/var/task/lib/libpyqbpp.so",
    ]:
        if path and os.path.isfile(path):
            return path
    raise FileNotFoundError(
        "libpyqbpp.so not found. Build with: cd pyqbpp && make libpyqbpp.so")

_lib = ctypes.CDLL(_find_lib())

# ============================================================
# C API prototypes
# ============================================================

_vp = ctypes.c_void_p
_cp = ctypes.c_char_p
_u32 = ctypes.c_uint32
_u64 = ctypes.c_uint64
_i32 = ctypes.c_int32
_dbl = ctypes.c_double
_u8 = ctypes.c_uint8

def _f(name, res, args):
    fn = getattr(_lib, name)
    fn.restype = res
    fn.argtypes = args
    return fn

# Var (C++ registry)
_cpp_new_var = _f("qbpp_new_var", _u32, [_cp])
_cpp_var_reset = _f("qbpp_var_reset", None, [])
_cpp_var_set_size = _f("qbpp_var_set_size", _u32, [])

# Term
_term_from_coeff = _f("pyqbpp_term_from_coeff", _vp, [_cp])
_term_from_var = _f("pyqbpp_term_from_var", _vp, [_u32])
_term_from_var_coeff = _f("pyqbpp_term_from_var_coeff", _vp, [_u32, _cp])
_term_from_var_var = _f("pyqbpp_term_from_var_var", _vp, [_u32, _u32])
_term_copy = _f("pyqbpp_term_copy", _vp, [_vp])
_term_destroy = _f("pyqbpp_term_destroy", None, [_vp])
_term_mul_var = _f("pyqbpp_term_mul_var", _vp, [_vp, _u32])
_term_mul_coeff = _f("pyqbpp_term_mul_coeff", _vp, [_vp, _cp])
_term_mul_term = _f("pyqbpp_term_mul_term", _vp, [_vp, _vp])
_term_neg = _f("pyqbpp_term_neg", _vp, [_vp])
_term_coeff_str = _f("pyqbpp_term_coeff_str", _cp, [_vp])
_term_var_count = _f("pyqbpp_term_var_count", _u32, [_vp])
_term_var_index = _f("pyqbpp_term_var_index", _u32, [_vp, _u32])

# Expr
_expr_create = _f("pyqbpp_expr_create", _vp, [])
_expr_from_str = _f("pyqbpp_expr_from_str", _vp, [_cp])
_expr_from_var = _f("pyqbpp_expr_from_var", _vp, [_u32])
_expr_from_term = _f("pyqbpp_expr_from_term", _vp, [_vp])
_expr_copy = _f("pyqbpp_expr_copy", _vp, [_vp])
_expr_destroy = _f("pyqbpp_expr_destroy", None, [_vp])
_expr_type = _f("pyqbpp_expr_type", ctypes.c_int, [_vp])
_expr_add = _f("pyqbpp_expr_add", _vp, [_vp, _vp])
_expr_sub = _f("pyqbpp_expr_sub", _vp, [_vp, _vp])
_expr_mul = _f("pyqbpp_expr_mul", _vp, [_vp, _vp])
_expr_mul_str = _f("pyqbpp_expr_mul_str", _vp, [_vp, _cp])
_expr_neg = _f("pyqbpp_expr_neg", _vp, [_vp])
_expr_iadd = _f("pyqbpp_expr_iadd", None, [_vp, _vp])
_expr_iadd_term = _f("pyqbpp_expr_iadd_term", None, [_vp, _vp])
_expr_iadd_str = _f("pyqbpp_expr_iadd_str", None, [_vp, _cp])
_expr_isub = _f("pyqbpp_expr_isub", None, [_vp, _vp])
_expr_imul_str = _f("pyqbpp_expr_imul_str", None, [_vp, _cp])
_expr_simplify = _f("pyqbpp_expr_simplify_as_binary", None, [_vp])
_expr_sum_handles = _f("pyqbpp_expr_sum_handles", _vp,
                        [ctypes.POINTER(_vp), _u64])
_expr_sqr = _f("pyqbpp_expr_sqr", _vp, [_vp])
_expr_eq_str = _f("pyqbpp_expr_eq_str", _vp, [_vp, _cp])
_expr_constant_str = _f("pyqbpp_expr_constant_str", _cp, [_vp])
_expr_term_count = _f("pyqbpp_expr_term_count", _u64, [_vp])
_expr_pos_sum_str = _f("pyqbpp_expr_pos_sum_str", _cp, [_vp])
_expr_neg_sum_str = _f("pyqbpp_expr_neg_sum_str", _cp, [_vp])
_expr_get_term = _f("pyqbpp_expr_get_term", _vp, [_vp, _u64])

# ExprExpr
_exprexpr_original = _f("pyqbpp_exprexpr_original", _vp, [_vp])

# between (C++ creates slack vars — NOT used to avoid var counter conflict)
# _between_c = _f("pyqbpp_between", _vp, [_vp, _cp, _cp])

# Model
_model_create = _f("pyqbpp_model_create", _vp, [_vp])
_model_destroy = _f("pyqbpp_model_destroy", None, [_vp])
_model_var_count = _f("pyqbpp_model_var_count", _u32, [_vp])
_model_var = _f("pyqbpp_model_var", _u32, [_vp, _u32])
_model_index = _f("pyqbpp_model_index", _u32, [_vp, _u32])
_model_has = _f("pyqbpp_model_has", _u8, [_vp, _u32])
_model_constant_str = _f("pyqbpp_model_constant_str", _cp, [_vp])
_model_term_count = _f("pyqbpp_model_term_count", _u64, [_vp])

# HuboModel
_hubomodel_create = _f("pyqbpp_hubomodel_create", _vp, [_vp])
_hubomodel_max_power = _f("pyqbpp_hubomodel_max_power", _u32, [_vp])
_hubomodel_constant_str = _f("pyqbpp_hubomodel_constant_str", _cp, [_vp])
_hubomodel_term1_str = _f("pyqbpp_hubomodel_term1_str", _cp, [_vp, _u32])
_hubomodel_term2_count = _f("pyqbpp_hubomodel_term2_count", _u64, [_vp, _u32])
_hubomodel_term2_var = _f("pyqbpp_hubomodel_term2_var", _u32, [_vp, _u32, _u64])
_hubomodel_term2_coeff_str = _f("pyqbpp_hubomodel_term2_coeff_str", _cp, [_vp, _u32, _u64])

# Sol
_sol_create = _f("pyqbpp_sol_create", _vp, [_vp])
_sol_destroy = _f("pyqbpp_sol_destroy", None, [_vp])
_sol_get = _f("pyqbpp_sol_get", _i32, [_vp, _u32])
_sol_get_var = _f("pyqbpp_sol_get_var", _i32, [_vp, _u32])
_sol_set = _f("pyqbpp_sol_set", None, [_vp, _u32, _i32])
_sol_set_index = _f("pyqbpp_sol_set_index", None, [_vp, _u32, _i32])
_sol_flip = _f("pyqbpp_sol_flip", None, [_vp, _u32])
_sol_energy_str = _f("pyqbpp_sol_energy_str", _cp, [_vp])
_sol_comp_energy_str = _f("pyqbpp_sol_comp_energy_str", _cp, [_vp])
_sol_eval_str = _f("pyqbpp_sol_eval_str", _cp, [_vp, _vp])
_sol_tts = _f("pyqbpp_sol_tts", _dbl, [_vp])
_sol_set_tts = _f("pyqbpp_sol_set_tts", None, [_vp, _dbl])
_sol_var_count = _f("pyqbpp_sol_var_count", _u32, [_vp])
_sol_model_var = _f("pyqbpp_sol_model_var", _u32, [_vp, _u32])
_sol_model_index = _f("pyqbpp_sol_model_index", _u32, [_vp, _u32])

# EasySolver
_easy_solver_create = _f("pyqbpp_easy_solver_create", _vp, [_vp])
_easy_solver_destroy = _f("pyqbpp_easy_solver_destroy", None, [_vp])
_easy_solver_time_limit = _f("pyqbpp_easy_solver_time_limit", None, [_vp, _dbl])
_easy_solver_target_energy = _f("pyqbpp_easy_solver_target_energy", None, [_vp, _cp])
_easy_solver_thread_count = _f("pyqbpp_easy_solver_thread_count", None, [_vp, _u32])
_CALLBACK_T = ctypes.CFUNCTYPE(None, _cp, _dbl, _vp)
_easy_solver_set_callback = _f("pyqbpp_easy_solver_set_callback", None, [_vp, _CALLBACK_T, _vp])
_easy_solver_search = _f("pyqbpp_easy_solver_search", _vp, [_vp])

# ExhaustiveSolver
_exhaustive_solver_create = _f("pyqbpp_exhaustive_solver_create", _vp, [_vp])
_exhaustive_solver_destroy = _f("pyqbpp_exhaustive_solver_destroy", None, [_vp])
_exhaustive_solver_target_energy = _f("pyqbpp_exhaustive_solver_target_energy", None, [_vp, _cp])
_exhaustive_solver_set_callback = _f("pyqbpp_exhaustive_solver_set_callback", None, [_vp, _CALLBACK_T, _vp])
_exhaustive_solver_search = _f("pyqbpp_exhaustive_solver_search", _vp, [_vp])
_exhaustive_solver_search_optimal = _f("pyqbpp_exhaustive_solver_search_optimal", _vp, [_vp])

# SolList
_sollist_destroy = _f("pyqbpp_sollist_destroy", None, [_vp])
_sollist_size = _f("pyqbpp_sollist_size", _u64, [_vp])
_sollist_get = _f("pyqbpp_sollist_get", _vp, [_vp, _u64])
_sollist_energy_str = _f("pyqbpp_sollist_energy_str", _cp, [_vp])
_sollist_tts = _f("pyqbpp_sollist_tts", _dbl, [_vp])

# MapList
_maplist_create = _f("pyqbpp_maplist_create", _vp, [])
_maplist_destroy = _f("pyqbpp_maplist_destroy", None, [_vp])
_maplist_copy = _f("pyqbpp_maplist_copy", _vp, [_vp])
_maplist_size = _f("pyqbpp_maplist_size", _u64, [_vp])
_maplist_add_var_int = _f("pyqbpp_maplist_add_var_int", None, [_vp, _u32, _cp])
_maplist_add_var_expr = _f("pyqbpp_maplist_add_var_expr", None, [_vp, _u32, _vp])
_expr_replace = _f("pyqbpp_expr_replace", _vp, [_vp, _vp])
_expr_ireplace = _f("pyqbpp_expr_ireplace", None, [_vp, _vp])
_sol_set_maplist = _f("pyqbpp_sol_set_maplist", None, [_vp, _vp])


def _s(val):
    """Convert int to bytes for C API."""
    return str(val).encode()


# ============================================================
# Var - Binary variable (Python value type)
# ============================================================

class Var:
    """Binary variable holding an index and optional name."""

    _num = 0
    _unnamed_num = 0

    @classmethod
    def reset(cls):
        """Reset the global variable counter (for testing)."""
        cls._num = 0
        cls._unnamed_num = 0
        _cpp_var_reset()

    @classmethod
    def all_var_count(cls):
        """Return the total number of variables created."""
        return cls._num

    def __init__(self, name=None, *, _index=None):
        if _index is not None:
            # Internal: wrap existing index (no C++ registration)
            self._index = _index
            self._name = name if name else f"{{{_index}}}"
        elif name is not None:
            self._name = name
            self._index = _cpp_new_var(name.encode())
            Var._num = self._index + 1
        else:
            idx = Var._num
            nm = f"{{{idx}}}"
            self._index = _cpp_new_var(nm.encode())
            self._name = nm
            Var._num = self._index + 1
            Var._unnamed_num += 1

    @property
    def index(self):
        return self._index

    @property
    def name(self):
        return self._name

    def __eq__(self, other):
        if isinstance(other, Var):
            return self._index == other._index
        return NotImplemented

    def __ne__(self, other):
        if isinstance(other, Var):
            return self._index != other._index
        return NotImplemented

    def __lt__(self, other):
        if isinstance(other, Var):
            return self._index < other._index
        return NotImplemented

    def __le__(self, other):
        if isinstance(other, Var):
            return self._index <= other._index
        return NotImplemented

    def __gt__(self, other):
        if isinstance(other, Var):
            return self._index > other._index
        return NotImplemented

    def __ge__(self, other):
        if isinstance(other, Var):
            return self._index >= other._index
        return NotImplemented

    def __hash__(self):
        return hash(self._index)

    def __add__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(self) + Expr(other)
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(other) + Expr(self)
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(self) - Expr(other)
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(other) - Expr(self)
        return NotImplemented

    def __mul__(self, other):
        if isinstance(other, int):
            return Term._wrap(_term_from_var_coeff(self._index, _s(other)))
        if isinstance(other, Var):
            return Term._wrap(_term_from_var_var(self._index, other._index))
        if isinstance(other, Term):
            return Term._wrap(_term_mul_var(other._handle, self._index))
        if isinstance(other, Expr):
            return Expr(self) * other
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, int):
            return Term._wrap(_term_from_var_coeff(self._index, _s(other)))
        return NotImplemented

    def __neg__(self):
        return Term._wrap(_term_from_var_coeff(self._index, b"-1"))

    def __pos__(self):
        return Term._wrap(_term_from_var(self._index))

    def __invert__(self):
        """Bitwise NOT: ~x returns negated binary variable (index XOR neg bit)."""
        neg_index = self._index ^ 0x80000000
        name = f"~{self._name}" if not self._name.startswith("~") else self._name[1:]
        return Var(name, _index=neg_index)

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name


# ============================================================
# Term - Polynomial term (C++ handle wrapper)
# ============================================================

class Term:
    """A polynomial term: coeff * var1 * var2 * ..."""

    __slots__ = ('_handle',)

    def __init__(self, coeff=1, vars_list=None, *, _handle=None):
        if _handle is not None:
            self._handle = _handle
            return
        if vars_list is None or len(vars_list) == 0:
            self._handle = _term_from_coeff(_s(coeff))
        elif len(vars_list) == 1:
            self._handle = _term_from_var_coeff(vars_list[0]._index, _s(coeff))
        else:
            self._handle = _term_from_var_coeff(vars_list[0]._index, _s(coeff))
            for v in vars_list[1:]:
                new_h = _term_mul_var(self._handle, v._index)
                _term_destroy(self._handle)
                self._handle = new_h

    @staticmethod
    def _wrap(handle):
        obj = object.__new__(Term)
        obj._handle = handle
        return obj

    def __del__(self):
        try:
            _term_destroy(self._handle)
        except Exception:
            pass

    @property
    def coeff(self):
        return int(_term_coeff_str(self._handle).decode())

    @property
    def vars(self):
        n = _term_var_count(self._handle)
        result = []
        for i in range(n):
            vi = _term_var_index(self._handle, i)
            v = _index_to_var.get(vi)
            if v is None:
                v = Var(_index=vi)
            result.append(v)
        return tuple(result)

    def __add__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(self) + Expr(other)
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(other) + Expr(self)
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(self) - Expr(other)
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, (int, Var, Term, Expr)):
            return Expr(other) - Expr(self)
        return NotImplemented

    def __mul__(self, other):
        if isinstance(other, int):
            return Term._wrap(_term_mul_coeff(self._handle, _s(other)))
        if isinstance(other, Var):
            return Term._wrap(_term_mul_var(self._handle, other._index))
        if isinstance(other, Term):
            return Term._wrap(_term_mul_term(self._handle, other._handle))
        if isinstance(other, Expr):
            return Expr(self) * other
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, int):
            return Term._wrap(_term_mul_coeff(self._handle, _s(other)))
        if isinstance(other, Var):
            return Term._wrap(_term_mul_var(self._handle, other._index))
        return NotImplemented

    def __neg__(self):
        return Term._wrap(_term_neg(self._handle))

    def __pos__(self):
        return Term._wrap(_term_copy(self._handle))

    def __str__(self):
        c = self.coeff
        vs = self.vars
        if not vs:
            return str(c)
        var_str = "*".join(str(v) for v in vs)
        if c == 1:
            return var_str
        elif c == -1:
            return "-" + var_str
        else:
            return str(c) + "*" + var_str

    def __repr__(self):
        return str(self)


# ============================================================
# Expr - Expression (C++ handle wrapper)
# ============================================================

class Expr:
    """A polynomial expression: constant + sum of Term objects."""

    __slots__ = ('_handle',)

    def __init__(self, *args, _handle=None):
        if _handle is not None:
            self._handle = _handle
            return
        if len(args) == 0:
            self._handle = _expr_create()
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, int):
                self._handle = _expr_from_str(_s(arg))
            elif isinstance(arg, Var):
                self._handle = _expr_from_var(arg._index)
            elif isinstance(arg, Term):
                self._handle = _expr_from_term(arg._handle)
            elif isinstance(arg, Expr):
                self._handle = _expr_copy(arg._handle)
            else:
                raise TypeError(
                    f"Expr argument must be int, Var, Term, or Expr, "
                    f"got {type(arg).__name__}")
        else:
            self._handle = _expr_create()
            for arg in args:
                if isinstance(arg, int):
                    _expr_iadd_str(self._handle, _s(arg))
                elif isinstance(arg, Var):
                    tmp = _expr_from_var(arg._index)
                    _expr_iadd(self._handle, tmp)
                    _expr_destroy(tmp)
                elif isinstance(arg, Term):
                    _expr_iadd_term(self._handle, arg._handle)
                elif isinstance(arg, Expr):
                    _expr_iadd(self._handle, arg._handle)
                else:
                    raise TypeError(
                        f"Expr argument must be int, Var, Term, or Expr, "
                        f"got {type(arg).__name__}")

    @staticmethod
    def _wrap(handle):
        obj = object.__new__(Expr)
        obj._handle = handle
        return obj

    def __del__(self):
        try:
            _expr_destroy(self._handle)
        except Exception:
            pass

    @property
    def const(self):
        return int(_expr_constant_str(self._handle).decode())

    @property
    def terms(self):
        n = _expr_term_count(self._handle)
        result = []
        for i in range(n):
            result.append(Term._wrap(_expr_get_term(self._handle, i)))
        return result

    def term_count(self):
        return _expr_term_count(self._handle)

    # --- Arithmetic ---

    def __add__(self, other):
        if isinstance(other, int):
            return Expr._wrap(_expr_add(self._handle,
                                        _expr_from_str(_s(other))))
        if isinstance(other, Var):
            return Expr._wrap(_expr_add(self._handle,
                                        _expr_from_var(other._index)))
        if isinstance(other, Term):
            return Expr._wrap(_expr_add(self._handle,
                                        _expr_from_term(other._handle)))
        if isinstance(other, Expr):
            return Expr._wrap(_expr_add(self._handle, other._handle))
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, (int, Var, Term)):
            return Expr(other) + self
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, int):
            return Expr._wrap(_expr_sub(self._handle,
                                        _expr_from_str(_s(other))))
        if isinstance(other, Var):
            return Expr._wrap(_expr_sub(self._handle,
                                        _expr_from_var(other._index)))
        if isinstance(other, Term):
            return Expr._wrap(_expr_sub(self._handle,
                                        _expr_from_term(other._handle)))
        if isinstance(other, Expr):
            return Expr._wrap(_expr_sub(self._handle, other._handle))
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, (int, Var, Term)):
            return Expr(other) - self
        return NotImplemented

    def __mul__(self, other):
        if isinstance(other, int):
            if other == 0:
                return Expr(0)
            return Expr._wrap(_expr_mul_str(self._handle, _s(other)))
        if isinstance(other, (Var, Term)):
            return self * Expr(other)
        if isinstance(other, Expr):
            return Expr._wrap(_expr_mul(self._handle, other._handle))
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, (int, Var, Term)):
            return Expr(other) * self
        return NotImplemented

    def __neg__(self):
        return Expr._wrap(_expr_neg(self._handle))

    def __pos__(self):
        return Expr._wrap(_expr_copy(self._handle))

    def __iadd__(self, other):
        if isinstance(other, int):
            _expr_iadd_str(self._handle, _s(other))
            return self
        if isinstance(other, Var):
            tmp = _expr_from_var(other._index)
            _expr_iadd(self._handle, tmp)
            _expr_destroy(tmp)
            return self
        if isinstance(other, Term):
            _expr_iadd_term(self._handle, other._handle)
            return self
        if isinstance(other, Expr):
            _expr_iadd(self._handle, other._handle)
            return self
        return NotImplemented

    def __isub__(self, other):
        if isinstance(other, int):
            tmp = _expr_from_str(_s(other))
            _expr_isub(self._handle, tmp)
            _expr_destroy(tmp)
            return self
        if isinstance(other, Var):
            tmp = _expr_from_var(other._index)
            _expr_isub(self._handle, tmp)
            _expr_destroy(tmp)
            return self
        if isinstance(other, Term):
            tmp = _expr_from_term(other._handle)
            _expr_isub(self._handle, tmp)
            _expr_destroy(tmp)
            return self
        if isinstance(other, Expr):
            _expr_isub(self._handle, other._handle)
            return self
        return NotImplemented

    def __imul__(self, other):
        if isinstance(other, int):
            _expr_imul_str(self._handle, _s(other))
            return self
        return NotImplemented

    # --- Constraint: expr == int ---

    def __eq__(self, other):
        if isinstance(other, int):
            h = _expr_eq_str(self._handle, _s(other))
            return ExprExpr._wrap(h)
        if isinstance(other, Expr):
            return self is other
        return NotImplemented

    def __hash__(self):
        return id(self)

    # --- Simplification ---

    def simplify_as_binary(self):
        _expr_simplify(self._handle)
        return self

    def replace(self, map_list):
        """In-place variable substitution using MapList."""
        _expr_ireplace(self._handle, map_list._handle)
        return self

    # --- Utility ---

    def pos_sum(self):
        return int(_expr_pos_sum_str(self._handle).decode())

    def neg_sum(self):
        return int(_expr_neg_sum_str(self._handle).decode())

    # --- String ---

    def __str__(self):
        c = self.const
        n = _expr_term_count(self._handle)
        if n == 0 and c == 0:
            return "0"
        parts = []
        if c != 0:
            parts.append(str(c))
        for i in range(n):
            th = _expr_get_term(self._handle, i)
            coeff = int(_term_coeff_str(th).decode())
            nv = _term_var_count(th)
            var_names = []
            for j in range(nv):
                vi = _term_var_index(th, j)
                v = _index_to_var.get(vi)
                var_names.append(str(v) if v else f"{{{vi}}}")
            _term_destroy(th)
            if nv == 0:
                s = str(coeff)
            else:
                var_str = "*".join(var_names)
                if coeff == 1:
                    s = var_str
                elif coeff == -1:
                    s = "-" + var_str
                else:
                    s = str(coeff) + "*" + var_str
            if parts:
                if s.startswith("-"):
                    parts.append(" " + s)
                else:
                    parts.append(" +" + s)
            else:
                parts.append(s)
        return "".join(parts)

    def __repr__(self):
        return str(self)


# ============================================================
# ExprExpr - Constraint expression
# ============================================================

class ExprExpr(Expr):
    """Constraint expression: penalty expr + body expr."""

    __slots__ = ('_handle', '_body')

    @staticmethod
    def _wrap(handle, body=None):
        obj = object.__new__(ExprExpr)
        obj._handle = handle
        obj._body = body
        return obj

    def __init__(self, penalty_expr, body):
        super().__init__(penalty_expr)
        self._body = body

    @property
    def body(self):
        if self._body is None:
            # Read from C++ ExprExprHolder
            if _expr_type(self._handle) == 1:
                h = _exprexpr_original(self._handle)
                self._body = Expr._wrap(h)
        return self._body


# ============================================================
# MapList - Variable substitution list (C++ handle wrapper)
# ============================================================

class MapList:
    """Variable substitution list: [(Var, int/Expr), ...].

    Wraps the C++ qbpp::MapList object. Used with replace() to substitute
    variables in expressions, and with Sol.set() to fix variable values.

    Usage:
        ml = MapList()
        ml.add(x, 0)          # fix variable x to 0
        ml.add(y, Expr(z))    # replace variable y with expression z
        g = replace(f, ml)    # returns new expression with substitutions
        f.replace(ml)         # in-place substitution
        sol.set(ml)           # set variable values in solution
    """

    __slots__ = ('_handle',)

    def __init__(self, pairs=None):
        """Create a MapList, optionally from a list of (Var, int/Expr) pairs."""
        self._handle = _maplist_create()
        if pairs is not None:
            for var, val in pairs:
                self.add(var, val)

    def __del__(self):
        try:
            _maplist_destroy(self._handle)
        except Exception:
            pass

    def add(self, var, val):
        """Add a mapping: var -> int value or Expr."""
        if not isinstance(var, Var):
            raise TypeError(f"First argument must be Var, got {type(var).__name__}")
        if isinstance(val, int):
            _maplist_add_var_int(self._handle, var._index, _s(val))
        elif isinstance(val, (Var, Term)):
            _maplist_add_var_expr(self._handle, var._index, Expr(val)._handle)
        elif isinstance(val, Expr):
            _maplist_add_var_expr(self._handle, var._index, val._handle)
        else:
            raise TypeError(
                f"Value must be int, Var, Term, or Expr, got {type(val).__name__}")
        return self

    def push_back(self, pair):
        """Add a (Var, val) pair — compatible with C++ push_back style."""
        self.add(pair[0], pair[1])
        return self

    def __len__(self):
        return _maplist_size(self._handle)

    def __repr__(self):
        return f"MapList(size={len(self)})"


def replace(expr, map_list):
    """Return a new Expr with variables replaced according to map_list.

    Args:
        expr: Expr (or ExprExpr) to perform substitution on.
        map_list: MapList containing variable -> value/expr mappings.
    Returns:
        New Expr with variables replaced.
    """
    if not isinstance(map_list, MapList):
        raise TypeError(f"map_list must be MapList, got {type(map_list).__name__}")
    if isinstance(expr, Expr):
        return Expr._wrap(_expr_replace(expr._handle, map_list._handle))
    raise TypeError(f"expr must be Expr, got {type(expr).__name__}")


# ============================================================
# Global variable registry (for Term.vars lookup)
# ============================================================

_index_to_var = {}

_original_var_init = Var.__init__


def _tracked_var_init(self, name=None, *, _index=None):
    _original_var_init(self, name, _index=_index)
    _index_to_var[self._index] = self


Var.__init__ = _tracked_var_init


# ============================================================
# VarIntCore - Name holder for deferred VarInt creation
# ============================================================

class VarIntCore:
    """Variable name holder for deferred VarInt creation."""

    __slots__ = ('_name',)

    def __init__(self, name=None):
        self._name = name

    @property
    def name(self):
        return self._name

    def __str__(self):
        return self._name if self._name is not None else "(unnamed)"

    def __repr__(self):
        return f"VarIntCore({self._name!r})"


# ============================================================
# VarInt - Integer variable using binary encoding
# ============================================================

class VarInt(Expr):
    """Integer variable encoded with binary variables."""

    __slots__ = ('_handle', '_vi_name', '_min_val', '_max_val',
                 '_coeffs', '_int_vars')

    def __init__(self, name, min_val, max_val, base_coeff=1):
        self._vi_name = name
        self._min_val = min_val
        self._max_val = max_val
        self._coeffs = _comp_coeffs(min_val, max_val, base_coeff)
        self._int_vars = []
        if len(self._coeffs) == 1:
            self._int_vars.append(Var(name))
        else:
            for i in range(len(self._coeffs)):
                self._int_vars.append(Var(f"{name}[{i}]"))
        # Build C++ Expr: min_val + sum(coeff[i] * var[i])
        handle = _expr_from_str(_s(min_val))
        for c, v in zip(self._coeffs, self._int_vars):
            th = _term_from_var_coeff(v._index, _s(c))
            _expr_iadd_term(handle, th)
            _term_destroy(th)
        # Don't call super().__init__ — just set handle directly
        self._handle = handle

    @property
    def min_val(self):
        return self._min_val

    @property
    def max_val(self):
        return self._max_val

    @property
    def coeffs(self):
        return list(self._coeffs)

    @property
    def int_vars(self):
        return list(self._int_vars)

    def var_count(self):
        return len(self._int_vars)


def _comp_coeffs(min_val, max_val, base_coeff=1):
    """Compute binary encoding coefficients for [min_val, max_val]."""
    coeffs = []
    val = max_val - min_val
    if val < 0:
        raise ValueError(
            f"max_val ({max_val}) must be >= min_val ({min_val})")
    current = base_coeff
    while val > 0:
        if current < val:
            coeffs.append(current)
        else:
            coeffs.append(val)
        val -= current
        current *= 2
    return coeffs


def _create_var_int(name, min_val, max_val, base_coeff=1):
    if name is None:
        name = f"{{{Var._num}}}"
    return VarInt(name, min_val, max_val, base_coeff)


def var_int(*args):
    """Create a VarIntCore or multi-dimensional Vector of VarIntCore."""
    if len(args) == 0:
        return VarIntCore()

    if isinstance(args[0], str):
        name = args[0]
        dims = args[1:]
    else:
        name = None
        dims = args

    if len(dims) == 0:
        return VarIntCore(name)

    def _make(prefix, dims):
        if len(dims) == 1:
            return Vector([
                VarIntCore(f"{prefix}[{i}]" if prefix else None)
                for i in range(dims[0])
            ])
        return Vector([
            _make(f"{prefix}[{i}]" if prefix else None, dims[1:])
            for i in range(dims[0])
        ])

    return _make(name, dims)


# ============================================================
# Constraint functions
# ============================================================

def between(arg, minimum, maximum, base_coeff=1):
    """Create a bounded integer variable or constraint expression."""
    if isinstance(arg, VarIntCore):
        return _create_var_int(arg.name, minimum, maximum, base_coeff)
    if isinstance(arg, (Vector, list)):
        return Vector([between(item, minimum, maximum, base_coeff)
                        for item in arg])
    return _between_expr(arg, minimum, maximum)


def _between_expr(expression, minimum, maximum):
    """Internal: Create constraint minimum <= expr <= maximum."""
    val = maximum - minimum
    if val < 0:
        raise ValueError(
            f"maximum ({maximum}) must be >= minimum ({minimum})")
    if val == 0:
        return ExprExpr(sqr(expression - minimum), expression)
    if val == 1:
        return ExprExpr((expression - minimum) * (expression - maximum),
                        expression)
    # General case: introduce slack variable
    slack = _create_var_int(None, minimum, maximum - 1, 2)
    penalty = (expression - slack) * (expression - (slack + 1))
    return ExprExpr(penalty, expression)


# ============================================================
# Vector - Multi-dimensional container (unchanged)
# ============================================================

class Vector:
    """Multi-dimensional container for Var, Term, Expr, or nested Vectors."""

    def __init__(self, data):
        if isinstance(data, list):
            self._data = [
                Vector(x) if isinstance(x, list) else x for x in data
            ]
        else:
            self._data = [data]

    def __getitem__(self, idx):
        return self._data[idx]

    def __setitem__(self, idx, value):
        self._data[idx] = value

    def __len__(self):
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def __contains__(self, item):
        return item in self._data

    def __add__(self, other):
        if isinstance(other, Vector):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a + b for a, b in zip(self._data, other._data)])
        if isinstance(other, list):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a + b for a, b in zip(self._data, other)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([x + other for x in self._data])
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, list):
            if len(other) != len(self):
                raise ValueError("Vector size mismatch")
            return Vector([a + b for a, b in zip(other, self._data)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([other + x for x in self._data])
        return NotImplemented

    def __sub__(self, other):
        if isinstance(other, Vector):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a - b for a, b in zip(self._data, other._data)])
        if isinstance(other, list):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a - b for a, b in zip(self._data, other)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([x - other for x in self._data])
        return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, list):
            if len(other) != len(self):
                raise ValueError("Vector size mismatch")
            return Vector([a - b for a, b in zip(other, self._data)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([other - x for x in self._data])
        return NotImplemented

    def __mul__(self, other):
        if isinstance(other, Vector):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a * b for a, b in zip(self._data, other._data)])
        if isinstance(other, list):
            if len(self) != len(other):
                raise ValueError("Vector size mismatch")
            return Vector([a * b for a, b in zip(self._data, other)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([x * other for x in self._data])
        return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, list):
            if len(other) != len(self):
                raise ValueError("Vector size mismatch")
            return Vector([a * b for a, b in zip(other, self._data)])
        if isinstance(other, (int, Var, Term, Expr)):
            return Vector([other * x for x in self._data])
        return NotImplemented

    def __neg__(self):
        return Vector([-x for x in self._data])

    def __eq__(self, other):
        if isinstance(other, (int, Expr)):
            return Vector([Expr(x) == other if isinstance(x, (Var, Term)) else x == other
                           for x in self._data])
        if isinstance(other, Vector):
            return self is other
        return NotImplemented

    def __hash__(self):
        return id(self)

    def simplify_as_binary(self):
        for item in self._data:
            if isinstance(item, (Expr, Vector)):
                item.simplify_as_binary()
        return self

    def __str__(self):
        return "[" + ", ".join(str(x) for x in self._data) + "]"

    def __repr__(self):
        return f"Vector({self._data})"


# ============================================================
# Factory function: var()
# ============================================================

def var(*args):
    """Create a Var or multi-dimensional Vector of Vars."""
    if len(args) == 0:
        return Var()

    if isinstance(args[0], str):
        name = args[0]
        dims = args[1:]
    else:
        name = None
        dims = args

    if len(dims) == 0:
        return Var(name)

    def _make(prefix, dims):
        if len(dims) == 1:
            return Vector([
                Var(f"{prefix}[{i}]" if prefix else None)
                for i in range(dims[0])
            ])
        return Vector([
            _make(f"{prefix}[{i}]" if prefix else None, dims[1:])
            for i in range(dims[0])
        ])

    return _make(name, dims)


# ============================================================
# Utility functions
# ============================================================

def sqr(arg):
    """Square an expression, Var, Term, or element-wise for Vector/list."""
    if isinstance(arg, (Vector, list)):
        return Vector([sqr(x) for x in arg])
    e = Expr(arg)
    return Expr._wrap(_expr_sqr(e._handle))


def _collect_handles(arg, handles, keep_alive):
    """Flatten Vector/list to Expr handles for batch C++ sum."""
    if isinstance(arg, (Vector, list)):
        for item in arg:
            _collect_handles(item, handles, keep_alive)
    elif isinstance(arg, Expr):
        handles.append(arg._handle)
    elif isinstance(arg, (Var, Term, int)):
        e = Expr(arg)
        handles.append(e._handle)
        keep_alive.append(e)


def _batch_sum(handles):
    """Call C++ sum on an array of Expr handles."""
    n = len(handles)
    if n == 0:
        return Expr(0)
    arr = (ctypes.c_void_p * n)(*handles)
    return Expr._wrap(_expr_sum_handles(arr, n))


def sum(arg):
    """Recursively sum all elements into a single Expr."""
    if isinstance(arg, (Vector, list)):
        handles = []
        keep_alive = []
        _collect_handles(arg, handles, keep_alive)
        return _batch_sum(handles)
    return Expr(arg)


total_sum = sum


def _get_ndim(vec):
    if not isinstance(vec, (Vector, list)) or len(vec) == 0:
        return 0
    if isinstance(vec[0], (Vector, list)):
        return 1 + _get_ndim(vec[0])
    return 1


def _normalize_axis(axis, ndim):
    if axis < 0:
        axis += ndim
    if axis < 0 or axis >= ndim:
        raise ValueError(f"axis {axis} is out of range for {ndim}-dimensional Vector")
    return axis


def _collect_leaf_handles(item, handles, keep_alive):
    """Collect handle from a single leaf element (not Vector/list)."""
    if isinstance(item, Expr):
        handles.append(item._handle)
    elif isinstance(item, (Var, Term, int)):
        e = Expr(item)
        handles.append(e._handle)
        keep_alive.append(e)


def vector_sum(vec, axis=-1):
    """Sum along specified axis of a multi-dimensional Vector/list."""
    if not isinstance(vec, (Vector, list)):
        raise TypeError("vector_sum requires a Vector or list argument")
    if len(vec) == 0:
        return Expr(0)

    ndim = _get_ndim(vec)
    axis = _normalize_axis(axis, ndim)

    if ndim == 1:
        handles = []
        keep_alive = []
        for item in vec:
            _collect_leaf_handles(item, handles, keep_alive)
        return _batch_sum(handles)

    if axis == 0:
        ncols = len(vec[0])
        result_data = []
        for j in range(ncols):
            handles = []
            keep_alive = []
            for i in range(len(vec)):
                _collect_leaf_handles(vec[i][j], handles, keep_alive)
            result_data.append(_batch_sum(handles))
        return Vector(result_data)
    else:
        return Vector([vector_sum(vec[i], axis - 1) for i in range(len(vec))])


def transpose(arg):
    """Transpose a 2D Vector/list."""
    if not isinstance(arg, (Vector, list)):
        raise TypeError("transpose requires a Vector or list argument")
    rows = len(arg)
    if rows == 0:
        return Vector([])
    if not isinstance(arg[0], (Vector, list)):
        raise TypeError("transpose requires a 2D Vector or nested list")
    cols = len(arg[0])
    return Vector([
        Vector([arg[i][j] for i in range(rows)])
        for j in range(cols)
    ])


def expr(*dims):
    """Create a multi-dimensional Vector of zero-initialized Expr objects."""
    if len(dims) == 0:
        return Expr(0)
    if len(dims) == 1:
        return Vector([Expr(0) for _ in range(dims[0])])
    return Vector([expr(*dims[1:]) for _ in range(dims[0])])


def simplify_as_binary(arg):
    """Simplify an expression assuming binary variables (x^2 = x)."""
    if isinstance(arg, Vector):
        return Vector([simplify_as_binary(x) for x in arg])
    if isinstance(arg, Expr):
        copy = Expr(arg)
        return copy.simplify_as_binary()
    return arg


# ============================================================
# Model - Variable-indexed expression (C++ handle wrapper)
# ============================================================

class Model:
    """Assigns compact indices to variables in an Expr."""

    __slots__ = ('_handle', '_expr_ref')

    def __init__(self, expression):
        if isinstance(expression, Model):
            # Copy
            self._handle = _model_create(
                Expr._wrap(_expr_copy(
                    expression._expr_ref._handle
                    if expression._expr_ref else None))._handle
                if expression._expr_ref else expression._handle)
            self._expr_ref = expression._expr_ref
            return

        if not isinstance(expression, Expr):
            raise TypeError(f"Model requires an Expr, got {type(expression).__name__}")

        self._handle = _model_create(expression._handle)
        self._expr_ref = expression  # keep Expr alive

    def __del__(self):
        try:
            _model_destroy(self._handle)
        except Exception:
            pass

    @property
    def expression(self):
        return self._expr_ref

    def var_count(self):
        return _model_var_count(self._handle)

    def var(self, index):
        vi = _model_var(self._handle, index)
        v = _index_to_var.get(vi)
        if v is None:
            v = Var(_index=vi)
        return v

    def index(self, v):
        return _model_index(self._handle, v._index)

    def has(self, v):
        return bool(_model_has(self._handle, v._index))

    def constant(self):
        return int(_model_constant_str(self._handle).decode())

    def term_count(self):
        return _model_term_count(self._handle)

    def __str__(self):
        return str(self._expr_ref) if self._expr_ref else f"Model({self.var_count()} vars)"

    def __repr__(self):
        return f"Model({self})"


# ============================================================
# HuboModel - Terms sorted by degree (C++ handle wrapper)
# ============================================================

class HuboModel(Model):
    """HUBO model with terms sorted by degree."""

    __slots__ = ('_handle', '_expr_ref')

    def __init__(self, model_or_expr):
        if isinstance(model_or_expr, Model):
            expr_ref = model_or_expr._expr_ref
        elif isinstance(model_or_expr, Expr):
            expr_ref = model_or_expr
        else:
            raise TypeError(f"HuboModel requires Model or Expr, got {type(model_or_expr).__name__}")

        self._handle = _hubomodel_create(expr_ref._handle)
        self._expr_ref = expr_ref

    # Note: __del__ inherited from Model calls _model_destroy which works
    # for HuboModel via virtual destructor

    def hubo_constant(self):
        return int(_hubomodel_constant_str(self._handle).decode())

    def term1(self, i=None):
        if i is None:
            n = self.var_count()
            return [int(_hubomodel_term1_str(self._handle, j).decode())
                    for j in range(n)]
        return int(_hubomodel_term1_str(self._handle, i).decode())

    def term2(self, i=None):
        if i is None:
            n = self.var_count()
            return [self.term2(j) for j in range(n)]
        count = _hubomodel_term2_count(self._handle, i)
        result = []
        for j in range(count):
            var_idx = _hubomodel_term2_var(self._handle, i, j)
            coeff = int(_hubomodel_term2_coeff_str(self._handle, i, j).decode())
            result.append((var_idx, coeff))
        return result

    def max_power(self):
        return _hubomodel_max_power(self._handle)

    def has_dyn_terms(self):
        return self.max_power() > 4

    def __str__(self):
        lines = [f"HuboModel: {self.var_count()} vars, "
                 f"max_degree={self.max_power()}, "
                 f"constant={self.hubo_constant()}"]
        for i in range(self.var_count()):
            v = self.var(i)
            parts = []
            t1 = self.term1(i)
            if t1 != 0:
                parts.append(f"linear={t1}")
            t2 = self.term2(i)
            if t2:
                parts.append(f"quad={len(t2)}")
            if parts:
                lines.append(f"  [{i}] {v}: {', '.join(parts)}")
        return "\n".join(lines)

    def __repr__(self):
        return self.__str__()


# ============================================================
# Sol - Solution (C++ handle wrapper)
# ============================================================

class Sol:
    """Solution: variable assignments + energy."""

    __slots__ = ('_handle', '_model_ref', '_cached_energy', '_dirty')

    def __init__(self, model, bits=None, energy=None, tts=-1.0, *, _handle=None):
        if _handle is not None:
            self._handle = _handle
            self._model_ref = model
            self._cached_energy = energy
            self._dirty = energy is None
            return

        if isinstance(model, (Expr, HuboModel)):
            model = Model(model) if isinstance(model, Expr) else Model(model)
        if not isinstance(model, Model):
            raise TypeError(f"Sol requires a Model, got {type(model).__name__}")

        self._handle = _sol_create(model._handle)
        self._model_ref = model
        self._cached_energy = None
        self._dirty = True

        if bits is not None:
            for i, b in enumerate(bits):
                _sol_set_index(self._handle, i, int(b))
        if energy is not None:
            self._cached_energy = energy
            self._dirty = False
        if tts >= 0:
            _sol_set_tts(self._handle, tts)

    def __del__(self):
        try:
            _sol_destroy(self._handle)
        except Exception:
            pass

    @property
    def model(self):
        return self._model_ref

    def var_count(self):
        return _sol_var_count(self._handle)

    def get(self, arg):
        if isinstance(arg, int):
            return _sol_get(self._handle, arg)
        if isinstance(arg, Var):
            return _sol_get_var(self._handle, arg._index)
        if isinstance(arg, Expr):
            return self.eval(arg)
        raise TypeError(f"Sol.get() does not support {type(arg).__name__}")

    def set(self, arg, value=None):
        if isinstance(arg, MapList):
            _sol_set_maplist(self._handle, arg._handle)
        elif value is not None:
            if isinstance(arg, int):
                _sol_set_index(self._handle, arg, int(value))
            elif isinstance(arg, Var):
                _sol_set(self._handle, arg._index, int(value))
            else:
                raise TypeError(f"Sol.set() does not support {type(arg).__name__}")
        else:
            raise TypeError(f"Sol.set() requires value or MapList argument")
        self._dirty = True

    def __call__(self, arg):
        return self.get(arg)

    def flip(self, arg):
        if isinstance(arg, Var):
            idx = _sol_model_index(self._handle, arg._index)
            _sol_flip(self._handle, idx)
        else:
            _sol_flip(self._handle, arg)
        self._dirty = True

    def eval(self, expression=None):
        if expression is None:
            return self.energy()
        s = _sol_eval_str(self._handle, expression._handle)
        return int(s.decode())

    def energy(self, value=None):
        if value is not None:
            self._cached_energy = value
            self._dirty = False
            return
        if self._dirty or self._cached_energy is None:
            self._cached_energy = int(_sol_comp_energy_str(self._handle).decode())
            self._dirty = False
        return self._cached_energy

    def comp_energy(self):
        self._cached_energy = int(_sol_comp_energy_str(self._handle).decode())
        self._dirty = False
        return self._cached_energy

    @property
    def tts(self):
        return _sol_tts(self._handle)

    @tts.setter
    def tts(self, value):
        pass  # C++ sol tts is set by solver, not writable from Python

    @property
    def bits(self):
        n = self.var_count()
        return [_sol_get(self._handle, i) for i in range(n)]

    def get_vector(self, vec):
        if isinstance(vec, Vector):
            return Vector([self.get_vector(x) for x in vec])
        return self.get(vec)

    def __str__(self):
        parts = []
        n = self.var_count()
        for i in range(n):
            vi = _sol_model_var(self._handle, i)
            v = _index_to_var.get(vi)
            name = str(v) if v else f"{{{vi}}}"
            parts.append(f"{name}={_sol_get(self._handle, i)}")
        e = self.energy()
        return f"Sol(energy={e}, {', '.join(parts)})"

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        if not isinstance(other, Sol):
            return NotImplemented
        return self.energy() == other.energy() and self.bits == other.bits

    def __lt__(self, other):
        if not isinstance(other, Sol):
            return NotImplemented
        if self.energy() != other.energy():
            return self.energy() < other.energy()
        return self.bits < other.bits


# ============================================================
# EasySolver (C++ handle wrapper)
# ============================================================

class EasySolver:
    """Heuristic QUBO solver (bit-flip + tabu search)."""

    __slots__ = ('_handle', '_expr_ref', '_time_limit_val',
                 '_target_energy_val', '_thread_count_val',
                 '_callback_fn', '_c_callback')

    def __init__(self, expression):
        if isinstance(expression, Expr):
            self._expr_ref = expression
        elif isinstance(expression, Model):
            self._expr_ref = expression._expr_ref
        else:
            raise TypeError(f"EasySolver requires Expr or Model, got {type(expression).__name__}")

        self._handle = _easy_solver_create(self._expr_ref._handle)
        self._time_limit_val = 10.0
        self._target_energy_val = None
        self._thread_count_val = None
        self._callback_fn = None
        self._c_callback = None

    def __del__(self):
        try:
            _easy_solver_destroy(self._handle)
        except Exception:
            pass

    def time_limit(self, value=None):
        if value is None:
            return self._time_limit_val
        self._time_limit_val = float(value)
        _easy_solver_time_limit(self._handle, self._time_limit_val)

    def target_energy(self, value=None):
        if value is None:
            return self._target_energy_val
        self._target_energy_val = value
        _easy_solver_target_energy(self._handle, _s(value))

    def thread_count(self, value=None):
        if value is None:
            return self._thread_count_val
        self._thread_count_val = int(value)
        _easy_solver_thread_count(self._handle, self._thread_count_val)

    def callback(self, func):
        self._callback_fn = func
        if func is not None:
            def _c_cb(energy_str, tts, user_data):
                func(int(energy_str.decode()), tts)
            self._c_callback = _CALLBACK_T(_c_cb)
            _easy_solver_set_callback(self._handle, self._c_callback, None)

    def search(self):
        sol_handle = _easy_solver_search(self._handle)
        sol = Sol.__new__(Sol)
        sol._handle = sol_handle
        sol._model_ref = None
        sol._cached_energy = None
        sol._dirty = True
        return sol


# ============================================================
# ExhaustiveSolver (C++ handle wrapper)
# ============================================================

class ExhaustiveSolver:
    """Exact QUBO solver (exhaustive search, TBB parallel)."""

    __slots__ = ('_handle', '_expr_ref', '_target_energy_val',
                 '_callback_fn', '_c_callback')

    def __init__(self, expression):
        if isinstance(expression, Expr):
            self._expr_ref = expression
        elif isinstance(expression, Model):
            self._expr_ref = expression._expr_ref
        else:
            raise TypeError(f"ExhaustiveSolver requires Expr or Model, got {type(expression).__name__}")

        self._handle = _exhaustive_solver_create(self._expr_ref._handle)
        self._target_energy_val = None
        self._callback_fn = None
        self._c_callback = None

    def __del__(self):
        try:
            _exhaustive_solver_destroy(self._handle)
        except Exception:
            pass

    def target_energy(self, value=None):
        if value is None:
            return self._target_energy_val
        self._target_energy_val = value
        _exhaustive_solver_target_energy(self._handle, _s(value))

    def callback(self, func):
        self._callback_fn = func
        if func is not None:
            def _c_cb(energy_str, tts, user_data):
                func(int(energy_str.decode()), tts)
            self._c_callback = _CALLBACK_T(_c_cb)
            _exhaustive_solver_set_callback(self._handle, self._c_callback, None)

    def _build_args(self, extra_args=None):
        pass  # Not needed with direct C++ solver

    def search(self):
        sol_handle = _exhaustive_solver_search(self._handle)
        sol = Sol.__new__(Sol)
        sol._handle = sol_handle
        sol._model_ref = None
        sol._cached_energy = None
        sol._dirty = True
        return sol

    def search_optimal_solutions(self):
        list_handle = _exhaustive_solver_search_optimal(self._handle)
        n = _sollist_size(list_handle)
        results = []
        for i in range(n):
            borrowed_handle = _sollist_get(list_handle, i)
            # Create an independent Sol by reading bits from borrowed handle
            var_count = _sol_var_count(borrowed_handle)
            energy = int(_sol_comp_energy_str(borrowed_handle).decode())
            tts = _sol_tts(borrowed_handle)
            bits = [_sol_get(borrowed_handle, j) for j in range(var_count)]
            # We need a Model handle for the new Sol — but we can create
            # a lightweight Sol from just bits
            sol = Sol.__new__(Sol)
            # We need to copy the sol handle since it's borrowed
            # Actually, let's create a proper Sol from the expr
            # For now, use a simple approach
            sol._handle = None
            sol._model_ref = None
            sol._cached_energy = energy
            sol._dirty = False
            sol._bits_cache = bits
            sol._tts_cache = tts
            sol._var_count_cache = var_count
            results.append(sol)
        _sollist_destroy(list_handle)
        return results

    def search_all_solutions(self):
        return self.search_optimal_solutions()


# Patch Sol for lightweight solutions from ExhaustiveSolver
_original_sol_energy = Sol.energy
_original_sol_get = Sol.get
_original_sol_var_count = Sol.var_count


def _patched_energy(self, value=None):
    if self._handle is None:
        if value is not None:
            self._cached_energy = value
            return
        return self._cached_energy
    return _original_sol_energy(self, value)


def _patched_get(self, arg):
    if self._handle is None:
        if isinstance(arg, int):
            return self._bits_cache[arg]
        if isinstance(arg, Var):
            # Need to find index — use _bits_cache position
            # For lightweight sols, we store compact-indexed bits
            # The var's global index needs model mapping
            # But we don't have a model here. Try linear search.
            for i, vi in enumerate(range(self._var_count_cache)):
                v = _index_to_var.get(vi)
                if v is not None and v._index == arg._index:
                    return self._bits_cache[i]
            return 0
        if isinstance(arg, Expr):
            return self._eval_lightweight(arg)
        raise TypeError(f"Sol.get() does not support {type(arg).__name__}")
    return _original_sol_get(self, arg)


def _patched_var_count(self):
    if self._handle is None:
        return self._var_count_cache
    return _original_sol_var_count(self)


# Don't monkey-patch — instead handle in the Sol class directly
# We'll fix the search_optimal_solutions approach instead


# Actually, let me take a simpler approach for search_optimal_solutions.
# Create a proper Model from the expr, then create real Sol objects.

def _create_sol_from_borrowed(borrowed_handle, expr_ref):
    """Create a proper Sol from a borrowed PyqbppSol handle."""
    var_count = _sol_var_count(borrowed_handle)
    bits = [_sol_get(borrowed_handle, j) for j in range(var_count)]
    energy = int(_sol_comp_energy_str(borrowed_handle).decode())
    tts_val = _sol_tts(borrowed_handle)
    # Create a Model from the expr
    model = Model(expr_ref)
    sol = Sol(model, bits=bits, energy=energy, tts=tts_val)
    return sol


# Override search_optimal_solutions to use proper approach
def _exhaustive_search_optimal(self):
    list_handle = _exhaustive_solver_search_optimal(self._handle)
    n = _sollist_size(list_handle)
    results = []
    for i in range(n):
        borrowed = _sollist_get(list_handle, i)
        sol = _create_sol_from_borrowed(borrowed, self._expr_ref)
        results.append(sol)
    _sollist_destroy(list_handle)
    return results


ExhaustiveSolver.search_optimal_solutions = _exhaustive_search_optimal


# Also fix EasySolver.search and ExhaustiveSolver.search to create proper Sol
def _easy_search(self):
    sol_handle = _easy_solver_search(self._handle)
    var_count = _sol_var_count(sol_handle)
    bits = [_sol_get(sol_handle, j) for j in range(var_count)]
    energy = int(_sol_comp_energy_str(sol_handle).decode())
    tts_val = _sol_tts(sol_handle)
    _sol_destroy(sol_handle)
    model = Model(self._expr_ref)
    return Sol(model, bits=bits, energy=energy, tts=tts_val)


def _exhaustive_search(self):
    sol_handle = _exhaustive_solver_search(self._handle)
    var_count = _sol_var_count(sol_handle)
    bits = [_sol_get(sol_handle, j) for j in range(var_count)]
    energy = int(_sol_comp_energy_str(sol_handle).decode())
    tts_val = _sol_tts(sol_handle)
    _sol_destroy(sol_handle)
    model = Model(self._expr_ref)
    return Sol(model, bits=bits, energy=energy, tts=tts_val)


EasySolver.search = _easy_search
ExhaustiveSolver.search = _exhaustive_search


# ============================================================
# solve() convenience function
# ============================================================

def solve(expression, solver="auto", time_limit=10.0, target_energy=None,
          threads=None, all_optimal=False, callback=None):
    """Convenience function: solve a QUBO/HUBO problem."""
    if isinstance(expression, Model):
        expr_ref = expression._expr_ref
    elif isinstance(expression, Expr):
        expr_ref = expression
    else:
        raise TypeError(f"solve() requires Expr or Model, got {type(expression).__name__}")

    model = Model(expr_ref)
    solver_name = solver
    if solver_name == "auto":
        solver_name = "exhaustive" if model.var_count() <= 30 else "easy"

    if solver_name == "easy":
        s = EasySolver(expr_ref)
        s.time_limit(time_limit)
        if target_energy is not None:
            s.target_energy(target_energy)
        if threads is not None:
            s.thread_count(threads)
        if callback:
            s.callback(callback)
        return s.search()
    elif solver_name == "exhaustive":
        s = ExhaustiveSolver(expr_ref)
        if target_energy is not None:
            s.target_energy(target_energy)
        if callback:
            s.callback(callback)
        if all_optimal:
            return s.search_optimal_solutions()
        return s.search()
    else:
        raise ValueError(f"Unknown solver: {solver_name}")
