"""TUI styles."""
