"""CLI tools for TraceCraft."""
