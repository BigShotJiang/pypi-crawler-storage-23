"""Defines DiffusionPerturber, a PerturbImage implementation that uses diffusion models for prompt-based perturbations.

Classes:
    DiffusionPerturber: An implementation of the ``PerturbImage`` interface that applies diffusion-based
    perturbations to input images using pre-trained models and text prompts.

Dependencies:
    - numpy for handling image data arrays
    - torch for PyTorch functionality
    - diffusers for Stable Diffusion models
    - PIL for image processing
    - nrtk.interfaces.perturb_image.PerturbImage for the base perturbation interface
    - smqtk_image_io for bounding box handling

Example:
    >>> import numpy as np
    >>> diffusion_perturber = DiffusionPerturber(
    ...     model_name="timbrooks/instruct-pix2pix", prompt="add rain to the image", seed=42
    ... )
    >>> image = np.ones((256, 256, 3))
    >>> perturbed_image, _ = diffusion_perturber(image=image)  # doctest: +SKIP

Note:
    This implementation uses the Instruct Pix2Pix model for prompt-based image transformations.
    The model is loaded on first use and cached for subsequent operations.
    Bounding boxes are not expected to be accurate after perturbation due to the generative nature of diffusion.
"""

from __future__ import annotations

__all__ = ["DiffusionPerturber"]

import warnings
from collections.abc import Hashable, Iterable
from typing import Any, cast

import numpy as np
import torch
from diffusers.pipelines.stable_diffusion.pipeline_stable_diffusion_instruct_pix2pix import (
    StableDiffusionInstructPix2PixPipeline,
)
from diffusers.schedulers.scheduling_euler_ancestral_discrete import EulerAncestralDiscreteScheduler
from PIL.Image import Image, Resampling, fromarray
from smqtk_image_io.bbox import AxisAlignedBoundingBox
from transformers import CLIPTextModel
from typing_extensions import override

from nrtk.impls.perturb_image._base import TorchRandomPerturbImage


class DiffusionPerturber(TorchRandomPerturbImage):
    """Diffusion-based implementation of the ``PerturbImage`` interface for prompt-guided perturbations.

    This class uses diffusion models (specifically the Instruct Pix2Pix model) to generate realistic
    perturbations on input images based on text prompts. The perturber can apply various effects
    and transformations guided by natural language descriptions.

    Args:
        model_name: Name of the pre-trained diffusion model from Hugging Face.
            Default is "timbrooks/instruct-pix2pix".

        prompt: Text prompt describing the desired perturbation or transformation.
        seed: Random seed for reproducible results. Defaults to None for non-deterministic behavior.
        is_static: If True, resets RNG after each call for consistent results.
        num_inference_steps: Number of denoising steps. Default is 50.
        text_guidance_scale: Guidance scale for text prompt. Default is 8.0.
        image_guidance_scale: Guidance scale for image conditioning. Default is 2.0.
        device: Device for computation, e.g., "cpu" or "cuda". If None, selects
            CUDA if available, otherwise CPU. Default is None.

    Note:
        The model is loaded lazily on first use and cached for subsequent operations.
        Images are automatically resized to be compatible with the diffusion model.
        Images will be resized to a minimum dimension of 256 pixels and dimensions
        divisible by 8 for optimal diffusion model performance.
        Device selection is automatic: CUDA is used if available, otherwise CPU.
    """

    def __init__(
        self,
        *,
        model_name: str = "timbrooks/instruct-pix2pix",
        prompt: str = "do not change the image",
        seed: int | None = None,
        is_static: bool = False,
        num_inference_steps: int = 50,
        text_guidance_scale: float = 8.0,
        image_guidance_scale: float = 2.0,
        device: str | None = None,
    ) -> None:
        """Initialize the DiffusionPerturber with configuration parameters.

        Args:
            model_name:
                Name of the pre-trained diffusion model. Default is "timbrooks/instruct-pix2pix".
            prompt:
                Text prompt describing the desired perturbation. Examples include
                "add rain to the image", "make it foggy", "add snow", "darken the scene", etc.
                To apply a no-op, use "do not change the image". Default is "do not change the image".
            seed:
                Random seed for reproducible results. Defaults to None for non-deterministic behavior.
            is_static:
                If True and seed is provided, resets RNG after each perturb call for consistent
                results across multiple calls (useful for video frame processing).
            num_inference_steps:
                Number of denoising steps. Default is 50.
            text_guidance_scale:
                Guidance scale for text prompt. Default is 8.0.
            image_guidance_scale:
                Guidance scale for image conditioning. Default is 2.0.
            device:
                Device for computation, e.g., "cpu" or "cuda". If None, selects
                CUDA if available, otherwise CPU. Default is None.
        """
        self._device_config = device  # original value for config serialization
        self._device = device if device is not None else ("cuda" if torch.cuda.is_available() else "cpu")
        super().__init__(seed=seed, is_static=is_static)
        self.model_name = model_name
        self.prompt = prompt
        self.num_inference_steps = num_inference_steps
        self.text_guidance_scale = text_guidance_scale
        self.image_guidance_scale = image_guidance_scale
        self._pipeline: StableDiffusionInstructPix2PixPipeline | None = None

    def _warn_on_cpu_fallback(self, device: str) -> None:
        """Warn user about CPU usage if CUDA is available or if CPU is fallback."""
        if device == "cpu":
            if self._device_config == "cpu" and torch.cuda.is_available():
                warnings.warn(
                    "Device is set to 'cpu' but CUDA is available. This will be significantly slower.",
                    UserWarning,
                    stacklevel=2,
                )
            elif self._device_config is None and not torch.cuda.is_available():
                warnings.warn(
                    "CUDA not available, using CPU. This will be significantly slower.",
                    UserWarning,
                    stacklevel=2,
                )

    def _get_pipeline(self) -> StableDiffusionInstructPix2PixPipeline:
        """Get or initialize the diffusion pipeline."""
        if self._pipeline is not None:
            return self._pipeline

        device = self._get_device()

        try:
            # First attempt: standard load, disable low-CPU path to reduce kwargs forwarding
            self._pipeline = StableDiffusionInstructPix2PixPipeline.from_pretrained(
                self.model_name,
                safety_checker=None,
                low_cpu_mem_usage=False,
                torch_dtype=torch.float32,
            )
        except TypeError as te:
            # transformers>=4.55 can inject `offload_state_dict` into CLIPTextModel.__init__
            # via a weights_only=True default in the sub-loader. If so, take control of the
            # text encoder load and set weights_only=False explicitly.
            if "offload_state_dict" not in str(te):
                # Unknown TypeError path; bubble it up wrapped.
                raise RuntimeError(
                    f"Failed to load diffusion model '{self.model_name}': {te}",
                ) from te

            text_encoder = self._get_text_encoder()

            self._pipeline = StableDiffusionInstructPix2PixPipeline.from_pretrained(
                self.model_name,
                safety_checker=None,
                low_cpu_mem_usage=False,
                text_encoder=text_encoder,  # let diffusers load tokenizer itself
                torch_dtype=torch.float32,
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to load diffusion model '{self.model_name}': {e}",
            ) from e

        self._finalize_pipeline(device)

        return self._pipeline

    def _get_text_encoder(self) -> CLIPTextModel:
        # Most SD repos store the text encoder in a `text_encoder/` subfolder.
        try:
            text_encoder = CLIPTextModel.from_pretrained(
                self.model_name,
                subfolder="text_encoder",
                low_cpu_mem_usage=False,
                weights_only=False,
            )
        except (OSError, ValueError, RuntimeError):
            # Fallback: load without subfolder if layout differs.
            text_encoder = CLIPTextModel.from_pretrained(
                self.model_name,
                low_cpu_mem_usage=False,
                weights_only=False,
            )

        return text_encoder

    def _finalize_pipeline(self, device: str) -> None:
        self._pipeline = cast(StableDiffusionInstructPix2PixPipeline, self._pipeline)
        self._pipeline = self._pipeline.to(device)

        # keep most of the pipeline in fp16, but run the CLIP image encoder in fp32
        if hasattr(self._pipeline, "image_encoder") and self._pipeline.image_encoder is not None:
            self._pipeline.image_encoder = self._pipeline.image_encoder.to(
                device=self._get_device(),
                dtype=torch.float32,
            )

        self._warn_on_cpu_fallback(device)
        self._pipeline.scheduler = EulerAncestralDiscreteScheduler.from_config(
            self._pipeline.scheduler.config,
        )

    def _resize_image(self, image: Image) -> Image:
        """Resize image for Stable Diffusion with proper dimensions.

        Args:
            image: PIL Image to resize

        Returns:
            Resized PIL Image with dimensions suitable for diffusion model
        """
        original_w, original_h = image.size
        # The model was trained on 256x256 images, so it's best suited for images of that size.
        # Documentation states any width over 768px will lead to artifacts.
        min_dimension = 256

        # scale image down to minimum dimension
        scale = min_dimension / min(original_w, original_h)
        new_w = int(original_w * scale)
        new_h = int(original_h * scale)

        # Round to nearest multiple of 8 (required by diffusion model)
        new_w = round(new_w / 8) * 8
        new_h = round(new_h / 8) * 8

        # Lanczos resampling improves image quality: https://mazzo.li/posts/lanczos.html
        # Lancoz is more computationally expensive
        return image.resize(size=(new_w, new_h), resample=Resampling.LANCZOS)

    def _get_generator(self) -> torch.Generator:
        """Return torch generator from base class. Manages reproducibility."""
        return self._generator

    @override
    def perturb(
        self,
        *,
        image: np.ndarray[Any, Any],
        boxes: Iterable[tuple[AxisAlignedBoundingBox, dict[Hashable, float]]] | None = None,
        **kwargs: Any,
    ) -> tuple[np.ndarray[Any, Any], Iterable[tuple[AxisAlignedBoundingBox, dict[Hashable, float]]] | None]:
        """Generate a prompt-guided perturbed image using diffusion models.

        If the prompt is "do not change the image", this method will perform a no-op
        and return the original image and bounding boxes.

        Args:
            image: Input image as a numpy array. PIL will handle format validation.
                Common supported formats: (H, W) grayscale, (H, W, 3) RGB, (H, W, 4) RGBA.
                Input is automatically converted to RGB for processing.
            boxes: Optional iterable of tuples containing AxisAlignedBoundingBox objects
                and their corresponding detection confidence dictionaries.

            kwargs: Additional perturbation keyword arguments (currently unused).

        Returns:
            A tuple containing:
            - Perturbed RGB image as uint8 numpy array (H, W, 3) at diffusion model resolution
            - Updated bounding boxes (currently returned unchanged)

        Raises:
            ValueError:
                If the input image cannot be converted to PIL format.
            RuntimeError:
                If the diffusion model fails to load or process the image.
        """
        perturbed_image, perturbed_boxes = super().perturb(image=image, boxes=boxes, **kwargs)

        if self.prompt == "do not change the image":
            return perturbed_image, perturbed_boxes

        try:
            pil_image = fromarray(perturbed_image).convert("RGB")

            resized_image = self._resize_image(pil_image)

            pipeline = self._get_pipeline()
            generator = self._get_generator()

            pipeline_result = pipeline(
                self.prompt,
                image=resized_image,
                num_inference_steps=self.num_inference_steps,
                guidance_scale=self.text_guidance_scale,
                image_guidance_scale=self.image_guidance_scale,
                generator=generator,
                return_dict=False,
            )
            # pull single image from list of images
            _images, _ = pipeline_result

            if isinstance(_images, Image):
                perturbed_image = np.array(_images, dtype=np.uint8)
            else:
                perturbed_image = np.array(_images[0], dtype=np.uint8)

            return perturbed_image, perturbed_boxes

        except Exception as e:
            raise RuntimeError(f"Failed to generate perturbed image: {e}") from e

    @override
    def get_config(self) -> dict[str, Any]:
        """Return the current configuration of the DiffusionPerturber."""
        cfg = super().get_config()
        cfg["model_name"] = self.model_name
        cfg["prompt"] = self.prompt
        cfg["num_inference_steps"] = self.num_inference_steps
        cfg["text_guidance_scale"] = self.text_guidance_scale
        cfg["image_guidance_scale"] = self.image_guidance_scale
        cfg["device"] = self._device_config
        return cfg
