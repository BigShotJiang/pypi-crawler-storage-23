"""Blur perturber implementations."""
