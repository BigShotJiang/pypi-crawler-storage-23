"""Defines RandomTranslationPerturber for random image shifts with bounding box adjustment for labeled datasets.

Classes:
    RandomTranslationPerturber: A perturbation class for applying random translation
    on images and the corresponding bounding boxes.

Dependencies:
    - numpy: For numerical operations and random number generation.
    - smqtk_image_io.AxisAlignedBoundingBox: For handling and adjusting bounding boxes.
    - nrtk.interfaces.perturb_image.PerturbImage: Base class for perturbation algorithms.

Example usage:
    >>> perturber = RandomTranslationPerturber(seed=42)
    >>> image = np.ones((256, 256, 3))
    >>> max_translation_limit = (image.shape[0] // 2, image.shape[1] // 2)
    >>> perturbed_image, _ = perturber(image=image, max_translation_limit=max_translation_limit)
"""

from __future__ import annotations

__all__ = ["RandomTranslationPerturber"]

from collections.abc import Hashable, Iterable, Sequence
from copy import deepcopy
from typing import Any

import numpy as np
from smqtk_image_io.bbox import AxisAlignedBoundingBox
from typing_extensions import override

from nrtk.impls.perturb_image._base import NumpyRandomPerturbImage


class RandomTranslationPerturber(NumpyRandomPerturbImage):
    """RandomTranslationPerturber randomly translates an image and adjusts bounding boxes accordingly.

    Attributes:
        seed (int | None):
            Random seed for reproducibility. None for non-deterministic behavior.
        is_static (bool):
            If True, resets RNG after each call for consistent results.
        color_fill (numpy.array):
            Background color fill for RGB image.
    """

    def __init__(
        self,
        *,
        seed: int | None = None,
        is_static: bool = False,
        color_fill: Sequence[int] | None = [0, 0, 0],
    ) -> None:
        """RandomTranslationPerturber applies a random translation perturbation to an input image.

        It ensures that bounding boxes are adjusted correctly to reflect the translated
        image coordinates.

        Args:
            seed:
                Random seed for reproducible results. Defaults to None for non-deterministic
                behavior.
            is_static:
                If True and seed is provided, resets RNG after each perturb call for consistent
                results across multiple calls (useful for video frame processing).
            color_fill:
                Background color fill for RGB image. Defaults to [0, 0, 0] (black).

        """
        if color_fill is None:
            color_fill = [0, 0, 0]
        super().__init__(seed=seed, is_static=is_static)
        self.color_fill: np.ndarray[np.int64, Any] = np.array(color_fill)

    @override
    def perturb(  # noqa: C901 - translation logic with directional boundary checks
        self,
        *,
        image: np.ndarray[Any, Any],
        boxes: Iterable[tuple[AxisAlignedBoundingBox, dict[Hashable, float]]] | None = None,
        max_translation_limit: tuple[int, int] | None = None,
        **kwargs: Any,
    ) -> tuple[np.ndarray[Any, Any], Iterable[tuple[AxisAlignedBoundingBox, dict[Hashable, float]]] | None]:
        """Randomly translates an image and adjusts bounding boxes.

        Args:
            image:
                Input image as a numpy array of shape (H, W, C).
            boxes:
                List of bounding boxes in AxisAlignedBoundingBox format and their corresponding classes.
            max_translation_limit:
                Max translation magnitude (translate_h, translate_w) lesser than or equal to the size of the input
                image.
            kwargs:
                Additional perturbation keyword arguments (currently unused).

        Returns:
            Translated image with the modified bounding boxes.
        """
        perturbed_image, perturbed_boxes = super().perturb(image=image, boxes=boxes, **kwargs)

        if max_translation_limit is None:
            translate_h, translate_w = (perturbed_image.shape[0], perturbed_image.shape[1])
        else:
            translate_h, translate_w = max_translation_limit

        if abs(translate_h) > perturbed_image.shape[0] or abs(translate_w) > perturbed_image.shape[1]:
            raise ValueError(f"Max translation limit should be less than or equal to {perturbed_image.shape[:2]}")

        # Randomly select the translation magnitude for each direction
        translate_x, translate_y = (0, 0)
        if translate_w > 0:
            translate_x = self._rng.integers(low=-translate_w, high=translate_w)
        if translate_h > 0:
            translate_y = self._rng.integers(low=-translate_h, high=translate_h)

        # Apply background color fill based on the number of image dimensions
        if perturbed_image.ndim == 3:
            final_image = np.full_like(
                perturbed_image,
                self.color_fill.astype(perturbed_image.dtype),
                dtype=perturbed_image.dtype,
            )
        else:
            final_image = np.zeros_like(perturbed_image, dtype=perturbed_image.dtype)

        # Perform the translation
        translated_image = np.roll(perturbed_image.copy(), (translate_y, translate_x), axis=[0, 1])

        # Apply the valid translated image region to the final background image
        if translate_x >= 0 and translate_y >= 0:
            final_image[translate_y:, translate_x:, ...] = translated_image[translate_y:, translate_x:, ...]
        elif translate_x < 0 and translate_y >= 0:
            final_image[translate_y:, :translate_x, ...] = translated_image[translate_y:, :translate_x, ...]
        elif translate_x >= 0 and translate_y < 0:
            final_image[:translate_y, translate_x:, ...] = translated_image[:translate_y, translate_x:, ...]
        else:
            final_image[:translate_y, :translate_x, ...] = translated_image[:translate_y, :translate_x, ...]

        # Adjust bounding boxes
        perturbed_boxes = []
        if boxes is not None:
            for bbox, metadata in boxes:
                # Compute the shifted_min coords for the bounding box to align with
                # the translated min_vertex coordinates
                shifted_min_x = bbox.min_vertex[0] + translate_x
                shifted_min_y = bbox.min_vertex[1] + translate_y

                # Check boundary conditions for the shifted_min bounding box coordinates
                if shifted_min_x < 0:
                    shifted_min_x = 0
                elif shifted_min_x > bbox.max_vertex[0]:
                    shifted_min_x = bbox.max_vertex[0]
                if shifted_min_y < 0:
                    shifted_min_y = 0
                elif shifted_min_y > bbox.max_vertex[1]:
                    shifted_min_y = bbox.max_vertex[1]

                shifted_min = (shifted_min_x, shifted_min_y)

                # Compute the shifted_max coords for the bounding box to align with
                # the translated max_vertex coordinates
                shifted_max_x = bbox.max_vertex[0] + translate_x
                shifted_max_y = bbox.max_vertex[1] + translate_y

                # Assign boundary conditions for the shifted_max bounding box coordinates
                if shifted_max_x < 0:
                    shifted_max_x = 0
                elif shifted_max_x > bbox.max_vertex[0]:
                    shifted_max_x = bbox.max_vertex[0]
                if shifted_max_y < 0:
                    shifted_max_y = 0
                elif shifted_max_y > bbox.max_vertex[1]:
                    shifted_max_y = bbox.max_vertex[1]

                shifted_max = (shifted_max_x, shifted_max_y)

                # Apply the shifted coordinates to the output bounding box
                adjusted_box = AxisAlignedBoundingBox(min_vertex=shifted_min, max_vertex=shifted_max)
                perturbed_boxes.append((adjusted_box, deepcopy(metadata)))

        perturbed_image = final_image
        return perturbed_image, perturbed_boxes

    @override
    def get_config(self) -> dict[str, Any]:
        """Returns the current configuration of the RandomTranslationPerturber instance."""
        cfg = super().get_config()
        cfg["color_fill"] = self.color_fill.tolist()
        return cfg
