"""Cortex Context-as-a-Service (CaaS) — HTTP API for AI platform integration."""
