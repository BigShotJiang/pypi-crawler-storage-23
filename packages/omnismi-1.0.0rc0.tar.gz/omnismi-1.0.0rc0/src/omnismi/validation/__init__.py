"""Validation utilities for Omnismi."""
