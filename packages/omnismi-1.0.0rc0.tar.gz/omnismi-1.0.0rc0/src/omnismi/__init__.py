"""Omnismi: unified, minimal GPU observability API."""

from omnismi.api import GPU, count, gpu, gpus
from omnismi.errors import BackendError, OmnismiError, ValidationError
from omnismi.models import GPUMetrics, GPUInfo

__version__ = "1.0.0rc"

__all__ = [
    "BackendError",
    "GPU",
    "GPUInfo",
    "GPUMetrics",
    "OmnismiError",
    "ValidationError",
    "count",
    "gpu",
    "gpus",
]
