## [0.3.11](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.10...v0.3.11) (2026-02-20)


### Bug Fixes

* properly traverse sids and display child/parent domain names for adcs certificate templates ([3e8b113](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/3e8b113832ab66e3139a081344fdad0dd38af59d))

## [0.3.10](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.9...v0.3.10) (2026-02-20)


### Bug Fixes

* properly catch referrals to parent ([3626f24](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/3626f2410301216b6969e724d8119e158ce372ff))

## [0.3.9](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.8...v0.3.9) (2026-02-19)


### Bug Fixes

* columns coloring for user and computer stats tab ([c7b8b02](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/c7b8b0209722614685e5c4326a7d5c6d7328ec6d))

## [0.3.8](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.7...v0.3.8) (2026-02-19)


### Bug Fixes

* support forest-child enumerations with proper sid resolving ([15aff39](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/15aff39c015a5d017e8c6c9cb7a3dd4763af6d0b))

## [0.3.7](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.6...v0.3.7) (2026-02-19)


### Bug Fixes

* forest support for child domain environments ([1deacd3](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/1deacd355dc4ce58e336a3b72ba758209e24297d))

