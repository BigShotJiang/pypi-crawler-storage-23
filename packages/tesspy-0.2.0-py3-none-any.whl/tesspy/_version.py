"""Single source of truth for the package version string."""

__version__ = "0.2.0"
