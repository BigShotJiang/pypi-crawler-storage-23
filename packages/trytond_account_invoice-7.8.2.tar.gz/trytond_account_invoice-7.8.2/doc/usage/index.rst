*****
Usage
*****

Customer and supplier invoices can be found under the
:menuselection:`Financial --> Invoices` menu item.

.. include:: prepare.inc.rst
.. include:: process.inc.rst
.. include:: amend.inc.rst
