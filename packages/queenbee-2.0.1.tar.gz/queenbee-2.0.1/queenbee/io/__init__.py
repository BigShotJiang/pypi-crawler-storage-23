"""Input and Output (IO) objects."""
