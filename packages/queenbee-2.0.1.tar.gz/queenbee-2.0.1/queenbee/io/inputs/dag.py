"""Queenbee input types for a DAG."""

import os
from typing import Dict, Union, List
from typing import Literal
from pydantic import Field, field_validator, ValidationInfo
from jsonschema import validate as json_schema_validator

from ..common import ItemType, GenericInput
from ..artifact_source import HTTP, S3, ProjectFolder
from .alias import DAGAliasInputs
from ...base.variable import validate_inputs_outputs_var_format, get_ref_variable


class DAGGenericInput(GenericInput):
    """Base class for DAG inputs.

    This class adds a handler to input to handle the process of loading the input
    from different graphical interfaces.
    """
    type: Literal['DAGGenericInput'] = 'DAGGenericInput'

    default: Union[str, None] = Field(
        None,
        description='Default value for generic input.'
    )

    alias: List[DAGAliasInputs] = Field(
        default_factory=list,
        description='A list of aliases for this input in different platforms.'
    )

    # see: https://github.com/ladybug-tools/queenbee/issues/172
    required: bool = Field(
        False,
        description='A field to indicate if this input is required. This input needs to '
        'be set explicitly even when a default value is provided.'
    )

    spec: Union[Dict, None] = Field(
        None,
        description='An optional JSON Schema specification to validate the input value. '
        'You can use validate_spec method to validate a value against the spec.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            json_schema_validator(value, spec)
        return value

    @field_validator('required', mode='before')
    @classmethod
    def check_required(cls, v: bool, info: ValidationInfo) -> bool:
        """Ensure required is set to True when default value is not provided."""
        default = info.data.get('default', None)
        name = info.data.get('name', None)
        if default is None and v is False:
            raise ValueError(
                f'{cls.__name__}.{name} -> required should be true if no default'
                f' is provided (default: {default}).'
            )
        return v

    @field_validator('spec')
    @classmethod
    def validate_default_value(cls, v: Dict, info: ValidationInfo) -> Dict:
        """Validate default value against spec if provided."""
        if 'type' not in info.data:
            raise ValueError(f'Input with missing type: {cls.__name__}')

        type_ = info.data.get('type')

        if type_ != cls.__name__:
            # this is a check to ensure the default value only gets validated againt the
            # correct class type. The reason we need to do this is that Pydantic doesn't
            # support discriminators (https://github.com/samuelcolvin/pydantic/issues/619).
            # As a result in case of checking for Union it checks every possible item
            # from the start until it finds one. For inputs it causes this check to fail
            # on a string before it gets to the integer class for an integer input.
            return v

        if 'default' not in info.data:
            # spec is not set
            return v

        default = info.data.get('default')
        if v is not None and default is not None:
            json_schema_validator(default, v)
        return v

    @field_validator('default')
    @classmethod
    def validate_default_refs(cls, v: str, info: ValidationInfo) -> str:
        """Validate referenced variables in the command"""
        if 'type' not in info.data:
            raise ValueError(f'Input with missing type: {cls.__name__}')

        if info.data.get('type') != cls.__name__ or not isinstance(v, (str, bytes)):
            # this is a check to ensure the default value only gets validated againt the
            # correct class type. See spec validation for more information
            return v

        ref_var = get_ref_variable(v)
        add_info = []
        for ref in ref_var:
            add_info.append(validate_inputs_outputs_var_format(ref))

        if add_info:
            raise ValueError('\n'.join(add_info))

        return v

    @field_validator('alias')
    @classmethod
    def check_alias_required(cls, v: List[DAGAliasInputs]) -> List[DAGAliasInputs]:
        for alias in v:
            default = alias.default
            name = alias.name
            required = alias.required
            if default is None and required is False:
                raise ValueError(
                    f'{cls.__name__}Alias.{name} -> required should be true if no '
                    f'default value is provided (default: {default}).'
                )
        return v


class DAGStringInput(DAGGenericInput):
    """A String input.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/string.html#string for
    more information.

    .. code-block:: python

        "schema": {
            "type": "string",
            "maxLength": 50,
            "pattern": "(?i)(^.*\\.epw$)"
        }

    """

    type: Literal['DAGStringInput'] = 'DAGStringInput'

    default: Union[str, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'string'
            json_schema_validator(value, spec)
        return value


class DAGIntegerInput(DAGGenericInput):
    """An integer input.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/numeric.html#numeric
    for more information.

    """
    type: Literal['DAGIntegerInput'] = 'DAGIntegerInput'

    default: Union[int, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'integer'
            json_schema_validator(value, spec)
        return value


class DAGNumberInput(DAGGenericInput):
    """A number input.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/numeric.html#numeric
    for more information.
    """
    type: Literal['DAGNumberInput'] = 'DAGNumberInput'

    default: Union[float, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'number'
            json_schema_validator(value, spec)
        return value


class DAGBooleanInput(DAGGenericInput):
    """The boolean type matches only two special values: True and False.

    Note that values that evaluate to true or false, such as 1 and 0, are not accepted.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/boolean.html for more
    information.
    """
    type: Literal['DAGBooleanInput'] = 'DAGBooleanInput'

    default: Union[bool, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'boolean'
            json_schema_validator(value, spec)
        return value


class DAGFolderInput(DAGGenericInput):
    """A folder input.

    Folder is a special string input. Unlike other string inputs, a folder will be copied
    from its location to execution folder when a workflow is executed.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/string.html#string for
    more information.

    .. code-block:: python

        "schema": {
            "type": "string",
            "maxLength": 50,
        }
    """
    type: Literal['DAGFolderInput'] = 'DAGFolderInput'

    default: Union[HTTP, S3, ProjectFolder, None] = Field(
        None,
        description='The default source for file if the value is not provided.'
    )

    @field_validator('required', mode='before')
    @classmethod
    def check_required(cls, v: bool) -> bool:
        """Overwrite check_required for artifacts to allow optional artifacts."""
        return v if v is not None else False

    @field_validator('alias', mode='before')
    @classmethod
    def check_alias_required(cls, v: List[DAGAliasInputs]) -> List[DAGAliasInputs]:
        """Overwrite check_alias_required for artifacts.

        This will allow None input for aliases for optional artifacts.
        """
        return [] if v is None else v

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        assert os.path.isdir(value), f'There is no folder at {value}'
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'string'
            json_schema_validator(value, spec)

        return value

    @property
    def is_artifact(self):
        return True

    @property
    def is_optional(self):
        """A boolean that indicates if an artifact is optional."""
        return self.default is None and self.required is False


class DAGFileInput(DAGFolderInput):
    """A file input.

    File is a special string input. Unlike other string inputs, a file will be copied
    from its location to execution folder when a workflow is executed.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/string.html#string for
    more information.

    .. code-block:: python

        # a file with maximum 50 characters with an ``epw`` extension.

        "schema": {
            "type": "string",
            "maxLength": 50,
            "pattern": "(?i)(^.*\\.epw$)"
        }

    """
    type: Literal['DAGFileInput'] = 'DAGFileInput'

    extensions: Union[List[str], None] = Field(
        None,
        description='Optional list of extensions for file. The check for extension is '
        'case-insensitive.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        assert os.path.isfile(value), f'There is no file at {value}'
        if self.extensions:
            assert value.lower().endswith(self.extension.lower()), \
                f'Input file extension for {value} must be {self.extensions}'
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'string'
            json_schema_validator(value, spec)

        return value


class DAGPathInput(DAGFolderInput):
    """A file or a folder input.

    Use this input only in cases that the input can be either a file or folder. For file
    or folder-only inputs see File and Folder.

    Path is a special string input. Unlike other string inputs, a path will be copied
    from its location to execution folder when a workflow is executed.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/string.html#string for
    more information.

    .. code-block:: python

        # a file with maximum 50 characters with an ``epw`` extension.

        "schema": {
            "type": "string",
            "maxLength": 50,
            "pattern": "(?i)(^.*\\.epw$)"
        }

    """
    type: Literal['DAGPathInput'] = 'DAGPathInput'

    extensions: Union[List[str], None] = Field(
        None,
        description='Optional list of extensions for path. The check for extension is '
        'case-insensitive. The extension will only be validated for file inputs.'
    )

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if os.path.isfile(value):
            if self.extensions:
                assert value.lower().endswith(self.extension.lower()), \
                    f'Input file extension for {value} must be {self.extensions}'
        elif not os.path.isdir(value):
            raise ValueError(f'{value} is not a valid file or folder.')

        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'string'
            json_schema_validator(value, spec)


class DAGArrayInput(DAGGenericInput):
    """A JSON array input.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/array.html for
    more information.
    """
    type: Literal['DAGArrayInput'] = 'DAGArrayInput'

    default: Union[List, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    items_type: ItemType = Field(
        ItemType.String,
        description='Type of items in an array. All the items in an array must be from '
        'the same type.'
    )

    @field_validator('default', mode='before')
    @classmethod
    def replace_none_value(cls, v: List) -> List:
        return [] if not v else v

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'array'
            spec['items'] = self.items_type.lower()
            json_schema_validator(value, spec)


class DAGJSONObjectInput(DAGGenericInput):
    """A JSON object input.

    JSON objects are similar to Python dictionaries.

    You can add additional validation by defining a JSONSchema specification.

    See http://json-schema.org/understanding-json-schema/reference/object.html for
    more information.
    """
    type: Literal['DAGJSONObjectInput'] = 'DAGJSONObjectInput'

    default: Union[Dict, None] = Field(
        None,
        description='Default value to use for an input if a value was not supplied.'
    )

    @field_validator('default', mode='before')
    @classmethod
    def replace_none_value(cls, v: Dict) -> Dict:
        return {} if not v else v

    def validate_spec(self, value):
        """Validate an input value against specification.

        Use this for validating workflow inputs against a recipe.
        """
        if self.spec:
            spec = dict(self.spec)
            spec['type'] = 'object'
            json_schema_validator(value, spec)


DAGInputs = Union[
    DAGStringInput, DAGIntegerInput, DAGNumberInput, DAGBooleanInput,
    DAGFolderInput, DAGFileInput, DAGPathInput, DAGArrayInput, DAGJSONObjectInput,
    DAGGenericInput
]
