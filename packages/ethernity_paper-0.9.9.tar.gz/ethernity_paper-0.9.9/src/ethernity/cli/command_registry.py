#!/usr/bin/env python3
# Copyright (C) 2026 Alex Stoyanov
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import typer

from .commands import (
    backup as backup_command,
    config as config_command,
    kit as kit_command,
    recover as recover_command,
    render as render_command,
)


def register(app: typer.Typer) -> None:
    backup_command.register(app)
    config_command.register(app)
    kit_command.register(app)
    render_command.register(app)
    recover_command.register(app)
