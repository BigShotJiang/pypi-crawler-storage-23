"""``synth edit agent`` command — interactive wizard for modifying existing agents.

Reads ``agent.py`` and ``agentcore.yaml`` (if present), parses the current
configuration, presents an edit menu, collects changes, shows a diff-style
summary, and writes files atomically via ``tempfile`` + ``os.replace()``.

Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 5.10, 5.11
"""

from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click

from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Provider model lists (for non-AgentCore providers)
# ---------------------------------------------------------------------------

_PROVIDER_MODELS: dict[str, list[str]] = {
    "anthropic": [
        "claude-sonnet-4-5",
        "claude-opus-4",
        "claude-3-7-sonnet-20250219",
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
    ],
    "openai": [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "gpt-3.5-turbo",
    ],
    "llama": [
        "ollama/llama3.2",
        "ollama/llama3.1",
        "ollama/mistral",
    ],
    "gemini": [
        "gemini/gemini-2.0-flash",
        "gemini/gemini-1.5-pro",
        "gemini/gemini-1.5-flash",
    ],
}


# ---------------------------------------------------------------------------
# Parsed agent configuration
# ---------------------------------------------------------------------------


@dataclass
class AgentConfig:
    """Parsed configuration extracted from ``agent.py`` and ``agentcore.yaml``.

    Parameters
    ----------
    model:
        The model string from the ``Agent(model=...)`` call.
    instructions:
        The instructions string from the ``Agent(instructions=...)`` call.
    tools:
        Tool names found in the ``tools=[...]`` list.
    mcp_registrations:
        MCP client registration lines found in the file.
    provider:
        Detected provider (``"agentcore"``, ``"anthropic"``, etc.).
    agentcore_config:
        Parsed ``agentcore.yaml`` fields, if present.
    """

    model: str = ""
    instructions: str = ""
    tools: list[str] = field(default_factory=list)
    mcp_registrations: list[str] = field(default_factory=list)
    provider: str = ""
    agentcore_config: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Pending changes
# ---------------------------------------------------------------------------


@dataclass
class PendingChanges:
    """Accumulated edits before writing to disk.

    Parameters
    ----------
    new_model:
        Replacement model string, or ``None`` if unchanged.
    new_instructions:
        Replacement instructions string, or ``None`` if unchanged.
    tools_to_add:
        Tool names to add to ``tools.py`` and ``agent.py``.
    tools_to_remove:
        Tool names to remove from ``agent.py``.
    mcp_to_add:
        MCP server names to add.
    mcp_to_remove:
        MCP server names to remove.
    new_agentcore_config:
        Updated agentcore fields (region, model_id, cris_enabled, aws_profile).
    new_tools_code:
        New content for ``tools.py`` if tools were added.
    """

    new_model: str | None = None
    new_instructions: str | None = None
    tools_to_add: list[str] = field(default_factory=list)
    tools_to_remove: list[str] = field(default_factory=list)
    mcp_to_add: list[str] = field(default_factory=list)
    mcp_to_remove: list[str] = field(default_factory=list)
    new_agentcore_config: dict[str, Any] = field(default_factory=dict)
    new_tools_code: str = ""

    def has_changes(self) -> bool:
        """Return ``True`` if any changes are pending."""
        return bool(
            self.new_model is not None
            or self.new_instructions is not None
            or self.tools_to_add
            or self.tools_to_remove
            or self.mcp_to_add
            or self.mcp_to_remove
        )


# ---------------------------------------------------------------------------
# Config parsing helpers
# ---------------------------------------------------------------------------


def _parse_agent_config(agent_source: str, yaml_config: dict[str, Any]) -> AgentConfig:
    """Parse ``agent.py`` source text into an ``AgentConfig``.

    Uses ``re`` patterns to extract model, instructions, tools, and MCP
    registrations without executing the file.

    Parameters
    ----------
    agent_source:
        The full text content of ``agent.py``.
    yaml_config:
        Parsed ``agentcore.yaml`` fields (may be empty dict).

    Returns
    -------
    AgentConfig
        Populated configuration object.
    """
    config = AgentConfig(agentcore_config=yaml_config)

    # Extract model
    model_match = re.search(r'model\s*=\s*["\']([^"\']+)["\']', agent_source)
    if model_match:
        config.model = model_match.group(1)

    # Extract instructions (handles multi-line strings in parentheses)
    instr_match = re.search(
        r'instructions\s*=\s*(?:\(\s*)?["\']([^"\']*)["\']',
        agent_source,
        re.DOTALL,
    )
    if instr_match:
        config.instructions = instr_match.group(1).strip()

    # Extract tools list
    tools_match = re.search(r'tools\s*=\s*\[([^\]]*)\]', agent_source)
    if tools_match:
        raw_tools = tools_match.group(1)
        config.tools = [
            t.strip().strip('"\'')
            for t in raw_tools.split(",")
            if t.strip() and t.strip() not in ('', '[]')
        ]

    # Extract MCP registrations (MCPClient lines)
    mcp_matches = re.findall(
        r'MCPClient\s*\(\s*["\']([^"\']+)["\']',
        agent_source,
    )
    config.mcp_registrations = mcp_matches

    # Detect provider from model string
    model = config.model
    if "bedrock" in model or yaml_config:
        config.provider = "agentcore"
    elif "gpt" in model or "openai" in model:
        config.provider = "openai"
    elif "gemini" in model:
        config.provider = "gemini"
    elif "ollama" in model or "llama" in model:
        config.provider = "llama"
    else:
        config.provider = "anthropic"

    return config


def _read_agentcore_yaml(agent_file: str) -> dict[str, Any]:
    """Read ``agentcore.yaml`` from the same directory as *agent_file*.

    Parameters
    ----------
    agent_file:
        Path to the agent Python file.

    Returns
    -------
    dict
        Parsed YAML fields, or empty dict if not present.
    """
    yaml_path = Path(agent_file).parent / "agentcore.yaml"
    if not yaml_path.exists():
        return {}

    try:
        import yaml  # type: ignore[import-untyped]
        with yaml_path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return data if isinstance(data, dict) else {}
    except ImportError:
        pass
    except Exception:
        return {}

    # Minimal fallback parser
    result: dict[str, Any] = {}
    try:
        for line in yaml_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                key, _, value = line.partition(":")
                v = value.strip().strip('"').strip("'")
                if v.lower() == "true":
                    result[key.strip()] = True
                elif v.lower() == "false":
                    result[key.strip()] = False
                else:
                    result[key.strip()] = v
    except Exception:
        pass
    return result


# ---------------------------------------------------------------------------
# Diff display
# ---------------------------------------------------------------------------


def _display_diff(
    agent_file: str,
    config: AgentConfig,
    changes: PendingChanges,
) -> None:
    """Display a diff-style summary of all pending changes.

    Shows ``- old value`` / ``+ new value`` lines for each changed field
    before asking the user to confirm (Requirement 5.9).

    Parameters
    ----------
    agent_file:
        Path to the agent file being edited.
    config:
        Current parsed configuration.
    changes:
        Accumulated pending changes.
    """
    click.echo("")
    click.echo(click.style("  Pending changes:", fg="cyan", bold=True))
    click.echo(f"  File: {agent_file}")
    click.echo("")

    if changes.new_model is not None:
        click.echo(f"  model:")
        click.echo(click.style(f"    - {config.model}", fg="red"))
        click.echo(click.style(f"    + {changes.new_model}", fg="green"))

    if changes.new_instructions is not None:
        old_preview = config.instructions[:60] + ("..." if len(config.instructions) > 60 else "")
        new_preview = changes.new_instructions[:60] + (
            "..." if len(changes.new_instructions) > 60 else ""
        )
        click.echo(f"  instructions:")
        click.echo(click.style(f"    - {old_preview}", fg="red"))
        click.echo(click.style(f"    + {new_preview}", fg="green"))

    for tool_name in changes.tools_to_add:
        click.echo(click.style(f"  + tool: {tool_name}", fg="green"))

    for tool_name in changes.tools_to_remove:
        click.echo(click.style(f"  - tool: {tool_name}", fg="red"))

    for mcp_name in changes.mcp_to_add:
        click.echo(click.style(f"  + MCP server: {mcp_name}", fg="green"))

    for mcp_name in changes.mcp_to_remove:
        click.echo(click.style(f"  - MCP server: {mcp_name}", fg="red"))

    if changes.new_agentcore_config:
        ac = changes.new_agentcore_config
        if "aws_region" in ac:
            click.echo(f"  agentcore.yaml / aws_region:")
            click.echo(click.style(
                f"    - {config.agentcore_config.get('aws_region', '(unset)')}", fg="red"
            ))
            click.echo(click.style(f"    + {ac['aws_region']}", fg="green"))
        if "model_id" in ac:
            click.echo(f"  agentcore.yaml / model_id:")
            click.echo(click.style(
                f"    - {config.agentcore_config.get('model_id', '(unset)')}", fg="red"
            ))
            click.echo(click.style(f"    + {ac['model_id']}", fg="green"))

    click.echo("")


# ---------------------------------------------------------------------------
# Atomic write helper
# ---------------------------------------------------------------------------


def _atomic_write(path: str, content: str) -> None:
    """Write *content* to *path* atomically via a temp file + ``os.replace()``.

    Writes to a ``NamedTemporaryFile`` in the same directory as *path*, then
    renames it to *path* so that a failure mid-write does not corrupt the
    existing file (Requirement 5.10).

    Parameters
    ----------
    path:
        Destination file path.
    content:
        Text content to write.
    """
    dest = Path(path)
    dir_ = str(dest.parent)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=dir_,
        delete=False,
        suffix=".tmp",
    ) as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    os.replace(tmp_path, path)


# ---------------------------------------------------------------------------
# Source patching helpers
# ---------------------------------------------------------------------------


def _patch_model(source: str, new_model: str) -> str:
    """Replace the ``model=...`` argument in *source*.

    Parameters
    ----------
    source:
        The agent.py source text.
    new_model:
        The new model string to write.

    Returns
    -------
    str
        Updated source text.
    """
    return re.sub(
        r'(model\s*=\s*)["\'][^"\']*["\']',
        lambda m: f'{m.group(1)}"{new_model}"',
        source,
        count=1,
    )


def _patch_instructions(source: str, new_instructions: str) -> str:
    """Replace the ``instructions=...`` argument in *source*.

    Parameters
    ----------
    source:
        The agent.py source text.
    new_instructions:
        The new instructions string.

    Returns
    -------
    str
        Updated source text.
    """
    escaped = new_instructions.replace("\\", "\\\\").replace('"', '\\"')
    return re.sub(
        r'(instructions\s*=\s*(?:\(\s*)?)["\'][^"\']*["\'](\s*\))?',
        lambda m: f'{m.group(1)}"{escaped}"{m.group(2) or ""}',
        source,
        count=1,
        flags=re.DOTALL,
    )


def _patch_tools_list(source: str, tools: list[str]) -> str:
    """Replace the ``tools=[...]`` list in *source* with *tools*.

    Parameters
    ----------
    source:
        The agent.py source text.
    tools:
        The new list of tool names.

    Returns
    -------
    str
        Updated source text.
    """
    if not tools:
        new_list = "[]"
    else:
        new_list = "[" + ", ".join(tools) + "]"
    return re.sub(
        r'tools\s*=\s*\[[^\]]*\]',
        f"tools={new_list}",
        source,
        count=1,
    )


# ---------------------------------------------------------------------------
# agentcore.yaml writer
# ---------------------------------------------------------------------------


def _write_agentcore_yaml(agent_file: str, config: AgentConfig, ac: dict[str, Any]) -> None:
    """Write updated fields to ``agentcore.yaml`` atomically.

    Parameters
    ----------
    agent_file:
        Path to the agent Python file (used to locate ``agentcore.yaml``).
    config:
        Current parsed configuration (provides existing field values).
    ac:
        New agentcore fields to merge in.
    """
    yaml_path = str(Path(agent_file).parent / "agentcore.yaml")

    # Merge new values over existing config
    merged = dict(config.agentcore_config)
    merged.update(ac)

    agent_name = merged.get("agent_name", "my-agent")
    agent_desc = merged.get("agent_description", "AI agent deployed to AWS AgentCore")
    aws_region = merged.get("aws_region", "us-east-1")
    model_id = merged.get("model_id", "")
    cris_enabled = merged.get("cris_enabled", False)
    aws_profile = merged.get("aws_profile")

    lines = [
        "# AgentCore Deployment Configuration",
        "#",
        "# This file is used by: synth deploy --target agentcore",
        "#",
        "# Agent Metadata",
        f"agent_name: {agent_name}",
        f'agent_description: "{agent_desc}"',
        "",
        "# AWS Configuration",
        f"aws_region: {aws_region}",
        f"model_id: {model_id}",
        f"cris_enabled: {'true' if cris_enabled else 'false'}",
    ]
    if aws_profile:
        lines.append(f"aws_profile: {aws_profile}")

    # Preserve permissions / runtime / environment blocks from existing config
    existing_text = ""
    existing_yaml_path = Path(yaml_path)
    if existing_yaml_path.exists():
        existing_text = existing_yaml_path.read_text(encoding="utf-8")

    # Extract and re-append the permissions/runtime/environment sections
    sections_match = re.search(
        r'(# IAM Permissions.*)',
        existing_text,
        re.DOTALL,
    )
    if sections_match:
        lines.extend(["", sections_match.group(1).rstrip()])
    else:
        lines.extend([
            "",
            "# IAM Permissions (least-privilege)",
            "permissions:",
            '  - "bedrock:InvokeModel"',
            '  - "bedrock:InvokeModelWithResponseStream"',
            '  - "bedrock-agentcore:*"',
            "",
            "# Runtime Configuration",
            "runtime:",
            "  memory_mb: 512",
            "  timeout_seconds: 300",
            "",
            "# Environment Variables (non-sensitive only)",
            "environment:",
            '  SYNTH_NO_BANNER: "1"',
            "",
        ])

    _atomic_write(yaml_path, "\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Menu handlers
# ---------------------------------------------------------------------------


def _edit_instructions(config: AgentConfig, changes: PendingChanges) -> None:
    """Prompt the user to replace the agent instructions (Requirement 5.4).

    Parameters
    ----------
    config:
        Current parsed configuration.
    changes:
        Pending changes object to update in place.
    """
    click.echo("")
    click.echo(click.style("  Current instructions:", fg="cyan"))
    click.echo(f"    {config.instructions}")
    click.echo("")
    new_instr = click.prompt(
        click.style("  New instructions", fg="cyan"),
        default=config.instructions,
    )
    if new_instr != config.instructions:
        changes.new_instructions = new_instr


def _edit_model_agentcore(config: AgentConfig, changes: PendingChanges) -> None:
    """Run the AgentCore region + model selection flow (Requirement 5.5).

    Invokes the same ``_run_agentcore_setup()`` helper used during init,
    then stores the new model and agentcore config in *changes*.

    Parameters
    ----------
    config:
        Current parsed configuration.
    changes:
        Pending changes object to update in place.
    """
    from synth.cli.init_cmd import _run_agentcore_setup

    setup = _run_agentcore_setup()
    new_model = setup["model_id"]
    if new_model != config.model:
        changes.new_model = new_model
    changes.new_agentcore_config = setup


def _edit_model_provider(config: AgentConfig, changes: PendingChanges) -> None:
    """Present a model list for non-AgentCore providers (Requirement 5.6).

    Parameters
    ----------
    config:
        Current parsed configuration.
    changes:
        Pending changes object to update in place.
    """
    models = _PROVIDER_MODELS.get(config.provider, [])
    if not models:
        click.echo(
            click.style(
                f"  No model list available for provider '{config.provider}'.",
                fg="yellow",
            )
        )
        new_model = click.prompt(
            click.style("  Enter model ID", fg="cyan"),
            default=config.model,
        )
        if new_model != config.model:
            changes.new_model = new_model
        return

    click.echo("")
    click.echo(click.style(f"  Available models for {config.provider}:", fg="cyan"))
    for idx, m in enumerate(models, start=1):
        marker = click.style(" (current)", fg="green") if m == config.model else ""
        click.echo(f"    {idx}. {m}{marker}")
    click.echo("")

    choice = click.prompt(
        click.style("  Select model (number)", fg="cyan"),
        type=click.IntRange(1, len(models)),
        default=1,
    )
    new_model = models[choice - 1]
    if new_model != config.model:
        changes.new_model = new_model


def _edit_tools(config: AgentConfig, changes: PendingChanges) -> None:
    """Present the Tool_Catalog for add/remove operations (Requirement 5.7).

    Parameters
    ----------
    config:
        Current parsed configuration.
    changes:
        Pending changes object to update in place.
    """
    from synth.cli.init_cmd import _TOOL_CATALOG

    click.echo("")
    click.echo(click.style("  Current tools:", fg="cyan"))
    if config.tools:
        for t in config.tools:
            click.echo(f"    - {t}")
    else:
        click.echo("    (none)")

    click.echo("")
    click.echo(click.style("  Tool catalog:", fg="cyan"))
    for idx, entry in enumerate(_TOOL_CATALOG, start=1):
        in_use = entry["import"] in config.tools
        marker = click.style(" [active]", fg="green") if in_use else ""
        click.echo(f"    {idx}. {entry['display']}{marker}")
    click.echo("")

    action = click.prompt(
        click.style("  Action", fg="cyan"),
        type=click.Choice(["add", "remove", "skip"], case_sensitive=False),
        default="skip",
    )

    if action == "skip":
        return

    if action == "add":
        raw = click.prompt(
            click.style("  Select tools to add (comma-separated numbers)", fg="cyan"),
            default="",
        ).strip()
        for part in raw.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part)
                if 1 <= idx <= len(_TOOL_CATALOG):
                    name = _TOOL_CATALOG[idx - 1]["import"]
                    if name not in config.tools and name not in changes.tools_to_add:
                        changes.tools_to_add.append(name)
                        # Collect code for tools.py
                        changes.new_tools_code += _TOOL_CATALOG[idx - 1]["code"] + "\n\n"

    elif action == "remove":
        if not config.tools:
            click.echo(click.style("  No tools to remove.", fg="yellow"))
            return
        click.echo("")
        for idx, t in enumerate(config.tools, start=1):
            click.echo(f"    {idx}. {t}")
        raw = click.prompt(
            click.style("  Select tools to remove (comma-separated numbers)", fg="cyan"),
            default="",
        ).strip()
        for part in raw.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part)
                if 1 <= idx <= len(config.tools):
                    name = config.tools[idx - 1]
                    if name not in changes.tools_to_remove:
                        changes.tools_to_remove.append(name)


def _edit_mcp_servers(config: AgentConfig, changes: PendingChanges) -> None:
    """Present the MCP_Catalog for add/remove operations (Requirement 5.8).

    Parameters
    ----------
    config:
        Current parsed configuration.
    changes:
        Pending changes object to update in place.
    """
    from synth.cli.init_cmd import _MCP_CATALOG

    click.echo("")
    click.echo(click.style("  Current MCP servers:", fg="cyan"))
    if config.mcp_registrations:
        for m in config.mcp_registrations:
            click.echo(f"    - {m}")
    else:
        click.echo("    (none)")

    click.echo("")
    click.echo(click.style("  MCP catalog:", fg="cyan"))
    for idx, entry in enumerate(_MCP_CATALOG, start=1):
        in_use = entry["key"] in config.mcp_registrations
        marker = click.style(" [active]", fg="green") if in_use else ""
        click.echo(f"    {idx}. {entry['display']}{marker}")
    click.echo("")

    action = click.prompt(
        click.style("  Action", fg="cyan"),
        type=click.Choice(["add", "remove", "skip"], case_sensitive=False),
        default="skip",
    )

    if action == "skip":
        return

    if action == "add":
        choice = click.prompt(
            click.style("  Select MCP server (number)", fg="cyan"),
            type=click.IntRange(1, len(_MCP_CATALOG)),
            default=1,
        )
        name = _MCP_CATALOG[choice - 1]["key"]
        if name not in config.mcp_registrations and name not in changes.mcp_to_add:
            changes.mcp_to_add.append(name)

    elif action == "remove":
        if not config.mcp_registrations:
            click.echo(click.style("  No MCP servers to remove.", fg="yellow"))
            return
        click.echo("")
        for idx, m in enumerate(config.mcp_registrations, start=1):
            click.echo(f"    {idx}. {m}")
        raw = click.prompt(
            click.style("  Select MCP servers to remove (comma-separated numbers)", fg="cyan"),
            default="",
        ).strip()
        for part in raw.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part)
                if 1 <= idx <= len(config.mcp_registrations):
                    name = config.mcp_registrations[idx - 1]
                    if name not in changes.mcp_to_remove:
                        changes.mcp_to_remove.append(name)


# ---------------------------------------------------------------------------
# Apply changes
# ---------------------------------------------------------------------------


def _apply_changes(
    agent_file: str,
    source: str,
    config: AgentConfig,
    changes: PendingChanges,
) -> None:
    """Apply all pending changes and write files atomically.

    Writes ``agent.py`` (and optionally ``tools.py`` and ``agentcore.yaml``)
    using ``tempfile`` + ``os.replace()`` for atomicity (Requirement 5.10).

    Parameters
    ----------
    agent_file:
        Path to the agent Python file.
    source:
        Current source text of ``agent.py``.
    config:
        Current parsed configuration.
    changes:
        Accumulated pending changes.
    """
    updated = source

    # Patch model
    if changes.new_model is not None:
        updated = _patch_model(updated, changes.new_model)

    # Patch instructions
    if changes.new_instructions is not None:
        updated = _patch_instructions(updated, changes.new_instructions)

    # Patch tools list
    if changes.tools_to_add or changes.tools_to_remove:
        current_tools = list(config.tools)
        for t in changes.tools_to_remove:
            if t in current_tools:
                current_tools.remove(t)
        for t in changes.tools_to_add:
            if t not in current_tools:
                current_tools.append(t)
        updated = _patch_tools_list(updated, current_tools)

        # Add import for new tools if tools.py exists
        tools_py = str(Path(agent_file).parent / "tools.py")
        if changes.tools_to_add:
            if os.path.exists(tools_py):
                existing_tools_src = Path(tools_py).read_text(encoding="utf-8")
                # Append new tool code
                if changes.new_tools_code:
                    from synth.cli.init_cmd import _TOOL_CATALOG
                    new_src = existing_tools_src.rstrip() + "\n\n" + changes.new_tools_code.strip() + "\n"
                    _atomic_write(tools_py, new_src)
            else:
                # Create tools.py from scratch
                if changes.new_tools_code:
                    header = (
                        '"""Custom tools for the agent."""\n\n'
                        "from __future__ import annotations\n\n"
                        "from synth import tool\n\n\n"
                    )
                    _atomic_write(tools_py, header + changes.new_tools_code.strip() + "\n")

            # Ensure import line exists in agent.py
            import_names = ", ".join(changes.tools_to_add)
            import_line = f"from tools import {import_names}"
            if import_line not in updated:
                # Insert after existing 'from tools import' line or after last import
                existing_import = re.search(r'from tools import [^\n]+', updated)
                if existing_import:
                    old_line = existing_import.group(0)
                    existing_names = old_line.replace("from tools import ", "").split(", ")
                    all_names = existing_names + changes.tools_to_add
                    updated = updated.replace(
                        old_line,
                        f"from tools import {', '.join(all_names)}",
                        1,
                    )
                else:
                    # Add after last import block
                    last_import = list(re.finditer(r'^(?:from|import) .+$', updated, re.MULTILINE))
                    if last_import:
                        pos = last_import[-1].end()
                        updated = updated[:pos] + f"\n{import_line}" + updated[pos:]

    # Handle MCP additions — append registration comment to agent.py
    if changes.mcp_to_add:
        for mcp_name in changes.mcp_to_add:
            registration = (
                f"\n\n# MCP server registration\n"
                f"# from synth.tools.mcp import MCPClient\n"
                f"# mcp_client = MCPClient(\"{mcp_name}/server.py\")\n"
            )
            updated = updated.rstrip() + registration

    # Handle MCP removals — remove MCPClient lines
    if changes.mcp_to_remove:
        for mcp_name in changes.mcp_to_remove:
            updated = re.sub(
                rf'.*MCPClient\s*\(\s*["\'].*{re.escape(mcp_name)}.*["\'].*\n?',
                "",
                updated,
            )

    # Write agent.py atomically
    _atomic_write(agent_file, updated)

    # Write agentcore.yaml if model changed for agentcore provider
    if changes.new_agentcore_config:
        _write_agentcore_yaml(agent_file, config, changes.new_agentcore_config)

    click.echo("")
    click.echo(click.style("  Changes written successfully.", fg="green"))


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run_edit_agent(file: str) -> None:
    """Run the interactive Edit_Wizard for the specified agent file.

    Reads ``agent.py`` and ``agentcore.yaml`` (if present), displays the
    current configuration, presents an edit menu, collects changes, shows
    a diff-style summary, and writes files atomically.

    Parameters
    ----------
    file:
        Path to the agent Python file to edit.

    Raises
    ------
    SynthConfigError
        If the specified file does not exist (Requirement 5.11).

    Examples
    --------
    >>> run_edit_agent("agent.py")  # doctest: +SKIP
    """
    # Requirement 5.11 — file must exist
    if not Path(file).exists():
        raise SynthConfigError(
            message=f"Agent file not found: '{file}'",
            component="EditWizard",
            suggestion=(
                f"Check the path and try again. "
                f"Run 'synth init' to create a new project."
            ),
        )

    # Read source files (Requirement 5.2)
    source = Path(file).read_text(encoding="utf-8")
    yaml_config = _read_agentcore_yaml(file)
    config = _parse_agent_config(source, yaml_config)

    click.echo("")
    click.echo(click.style("  SYNTH EDIT AGENT", fg="green", bold=True))
    click.echo(click.style(f"  Editing: {file}\n", dim=True))

    # Display current configuration summary (Requirement 5.2)
    click.echo(click.style("  Current configuration:", fg="cyan", bold=True))
    click.echo(f"    Provider:     {config.provider or '(unknown)'}")
    click.echo(f"    Model:        {config.model or '(not found)'}")
    instr_preview = config.instructions[:60] + (
        "..." if len(config.instructions) > 60 else ""
    )
    click.echo(f"    Instructions: {instr_preview or '(not found)'}")
    click.echo(f"    Tools:        {', '.join(config.tools) or '(none)'}")
    click.echo(f"    MCP servers:  {', '.join(config.mcp_registrations) or '(none)'}")
    if yaml_config:
        click.echo(f"    AWS region:   {yaml_config.get('aws_region', '(not set)')}")
        click.echo(f"    Model ID:     {yaml_config.get('model_id', '(not set)')}")
    click.echo("")

    changes = PendingChanges()

    # Edit menu loop (Requirement 5.3)
    while True:
        click.echo(click.style("  What would you like to edit?", fg="cyan"))
        click.echo("    a. Instructions")
        click.echo("    b. Model")
        click.echo("    c. Tools")
        click.echo("    d. MCP servers")
        click.echo("    q. Done / quit")
        click.echo("")

        choice = click.prompt(
            click.style("  Choice", fg="cyan"),
            default="q",
        ).strip().lower()

        if choice == "q":
            break
        elif choice == "a":
            _edit_instructions(config, changes)
        elif choice == "b":
            if config.provider == "agentcore":
                _edit_model_agentcore(config, changes)
            else:
                _edit_model_provider(config, changes)
        elif choice == "c":
            _edit_tools(config, changes)
        elif choice == "d":
            _edit_mcp_servers(config, changes)
        else:
            click.echo(click.style("  Invalid choice. Enter a, b, c, d, or q.", fg="yellow"))

        click.echo("")

    # No changes — exit cleanly
    if not changes.has_changes() and not changes.new_agentcore_config:
        click.echo(click.style("  No changes made.", fg="yellow"))
        return

    # Diff summary + confirmation (Requirement 5.9)
    _display_diff(file, config, changes)

    confirmed = click.confirm(
        click.style("  Apply these changes?", fg="cyan"),
        default=True,
    )
    if not confirmed:
        click.echo(click.style("  Cancelled — no files written.", fg="yellow"))
        return

    # Atomic write (Requirement 5.10)
    _apply_changes(file, source, config, changes)
