"""AgentCore memory integration.

Routes memory operations to AgentCore's managed memory service when
available, falling back to the Synth-native Memory backend otherwise.
"""

from __future__ import annotations

import os
from typing import Any

from synth.errors import SynthConfigError
from synth.memory.base import BaseMemory
from synth.types import Message


class AgentCoreMemory(BaseMemory):
    """Memory backend that delegates to AgentCore's managed memory.

    Falls back to a Synth-native backend if AgentCore memory is
    unavailable.  In production, refuses to fall back to unauthenticated
    local storage.

    Parameters
    ----------
    fallback:
        Optional Synth-native memory backend for fallback.
    """

    def __init__(self, fallback: BaseMemory | None = None) -> None:
        self._fallback = fallback
        self._agentcore_available = self._check_agentcore()

    @staticmethod
    def _check_agentcore() -> bool:
        """Check if AgentCore memory service is available."""
        return os.environ.get("AGENTCORE_MEMORY_ENDPOINT") is not None

    async def get_messages(self, thread_id: str) -> list[Message]:
        """Retrieve messages from AgentCore or fallback."""
        if self._agentcore_available:
            # Stub: would call AgentCore memory API
            return []

        if self._fallback is not None:
            return await self._fallback.get_messages(thread_id)

        raise SynthConfigError(
            message="No memory backend available in AgentCore deployment.",
            component="AgentCoreMemory",
            suggestion=(
                "Configure AGENTCORE_MEMORY_ENDPOINT or provide a "
                "fallback memory backend."
            ),
        )

    async def add_messages(
        self, thread_id: str, messages: list[Message],
    ) -> None:
        """Store messages in AgentCore or fallback."""
        if self._agentcore_available:
            # Stub: would call AgentCore memory API
            return

        if self._fallback is not None:
            await self._fallback.add_messages(thread_id, messages)
            return

        raise SynthConfigError(
            message="No memory backend available in AgentCore deployment.",
            component="AgentCoreMemory",
            suggestion=(
                "Configure AGENTCORE_MEMORY_ENDPOINT or provide a "
                "fallback memory backend."
            ),
        )
