"""
Synth SDK — Autonomous agents, engineered.

A Python SDK for building production-grade AI agents and multi-agent systems.

Usage::

    from synth import Agent, tool
    agent = Agent(model="claude-sonnet-4-5", instructions="You are helpful.")
    result = agent.run("Hello!")
"""

__version__ = "0.5.7"

# ---------------------------------------------------------------------------
# Public API imports
# ---------------------------------------------------------------------------

# Core
from synth.agent import Agent

# Tools
from synth.tools.decorator import tool
from synth.tools.toolkit import ToolKit

# Orchestration
from synth.orchestration.graph import Graph, node
from synth.orchestration.pipeline import ParallelGroup, Pipeline
from synth.orchestration.team import AgentTeam

# Middleware
from synth.memory.base import Memory
from synth.guards.base import Guard

# Evaluation
from synth.eval.eval import Eval

# Tracing
from synth.tracing.trace import Trace

# Types / Results
from synth.types import (
    Checkpoint,
    DoneEvent,
    ErrorEvent,
    PausedRun,
    RunResult,
    StageEvent,
    StreamEvent,
    TeamResult,
    ThinkingEvent,
    TokenEvent,
    ToolCallEvent,
    ToolResultEvent,
)

# Errors
from synth.errors import (
    SynthConfigError,
    SynthError,
    ToolDefinitionError,
    ToolExecutionError,
)

__all__ = [
    # Core
    "Agent",
    # Tools
    "tool",
    "ToolKit",
    # Orchestration
    "Graph",
    "node",
    "Pipeline",
    "ParallelGroup",
    "AgentTeam",
    # Middleware
    "Memory",
    "Guard",
    # Evaluation
    "Eval",
    # Tracing
    "Trace",
    # Types / Results
    "RunResult",
    "StreamEvent",
    "TokenEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "ThinkingEvent",
    "DoneEvent",
    "ErrorEvent",
    "StageEvent",
    "TeamResult",
    "PausedRun",
    "Checkpoint",
    # Errors
    "SynthError",
    "SynthConfigError",
    "ToolDefinitionError",
    "ToolExecutionError",
]
