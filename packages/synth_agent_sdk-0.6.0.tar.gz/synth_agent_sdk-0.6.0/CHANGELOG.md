# Changelog

All notable changes to the Synth SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.6.0] - 2026-02-20

### Added
- **AgentCore credential detection** — `CredentialResolver` auto-detects AWS credentials from env vars, `~/.aws/credentials`, and AWS Toolkit VS Code profiles during `synth init` and `synth create agent --provider agentcore`
- **Model selection with CRIS validation** — region-aware model picker backed by `ModelCatalog` and `RegionValidator`; automatically selects the correct base or cross-region inference profile ID and writes `aws_region`, `model_id`, `cris_enabled`, `aws_profile` to `agentcore.yaml`
- **Tool Wizard and MCP Wizard** — optional sub-wizards during `synth init` to scaffold pre-built tools (`tools.py`) or MCP servers (`server.py`) from a catalog, or generate custom `@tool` / `@mcp.tool()` stubs
- **Deploy Wizard** (`synth deploy --target agentcore`) — six-stage guided deployment with `[  OK  ]` / `[FAIL]` status output, `--dry-run` support, and a success summary showing agent ARN, region, and model ID
- **Edit Wizard** (`synth edit agent <file>`) — interactive wizard to modify instructions, model, tools, or MCP servers in an existing agent; shows a diff before writing; uses atomic temp-file rename
- **AgentCore Doctor checks** — `synth doctor` now validates `agentcore.yaml` fields (`aws_region`, `model_id`, `cris_enabled`, `aws_profile`) when the file is present, printing `[  OK  ]` or `[FAIL]` for each
- **Packager credential scan** — `synth deploy` packaging step aborts with `SynthConfigError` if `agentcore.yaml` contains AWS access key or secret key patterns; `.env` files are always excluded from artifacts

### Changed
- **Google provider** — migrated from deprecated `google-generativeai` to `google-genai>=1.0` SDK; updated to the new `genai.Client` / `client.aio.models.generate_content` API
- **`synth doctor`** — core dependency version detection now uses `importlib.metadata.version()` instead of `pkg.__version__` (eliminates Click 9.x `DeprecationWarning`)
- **`pyproject.toml`** — `synth[google]` extra updated to `google-genai>=1.0`

### Fixed
- Unclosed file handles in `test_init_wizard.py` (eliminated `ResourceWarning`)

## [0.5.7] - 2026-02-19

### Fixed
- **`synth create agentcore`** — fixed `KeyError: 'name'` crash when scaffolding an AgentCore agent. The `greet` tool's f-string literal `{name}` was unescaped inside a `.format()` call, causing Python to treat it as a missing format key. Escaped to `{{name}}` so the generated code renders correctly.

## [0.5.6] - 2026-02-19

### Added
- **Interactive shell** — running `synth` with no arguments now launches a persistent REPL instead of printing help. Commands are typed without the `synth` prefix (e.g. `run agent.py "Hello"`, `create agent my-bot`). Features tab completion, persistent `~/.synth_history`, Ctrl+C to clear line, Ctrl+D or `exit`/`quit` to leave.

## [0.5.5] - 2025-02-19

### Added
- **`synth/deploy/agentcore/auth.py`** — `extract_user_id()` securely extracts user identity from the AgentCore `RequestContext` JWT (prevents prompt injection impersonation); `get_gateway_token()` implements OAuth2 client credentials flow for Gateway authentication
- **`synth/deploy/agentcore/ssm.py`** — `get_ssm_parameter()` helper for reading runtime config from AWS SSM Parameter Store
- **`synth/deploy/agentcore/gateway.py`** — `GatewayMCPClient` and `create_gateway_client()` factory for connecting agents to AgentCore Gateway via MCP, with automatic credential resolution from SSM + Secrets Manager; supports both Strands (`as_mcp_client()`) and LangGraph (`as_langgraph_client()`) integration styles
- **`synth/deploy/agentcore/code_interpreter.py`** — `CodeInterpreterTools` framework-agnostic wrapper for AgentCore Code Interpreter; lazy session init, persistent sandbox state, `execute()` and `execute_python()` methods
- **`agentcore` extra** — added `PyJWT>=2.8` and `requests>=2.31` dependencies

### Changed
- **`AgentCoreAdapter`** — now accepts optional `RequestContext` and extracts user ID from JWT; passes `thread_id` from `runtimeSessionId`; validates payload schema before processing
- **`agentcore_handler()`** — entrypoint now passes `context` through to the adapter for JWT user extraction
- **`synth create agentcore`** scaffolding — generates full production-ready agent with Gateway MCP client, Code Interpreter tool, JWT user extraction, SSM config, and updated `agentcore.yaml` with correct IAM permissions
- **`synth/deploy/agentcore/__init__.py`** — exports all new public symbols

### Fixed
- **Packager self-copy bug** — `synth deploy` no longer crashes when `dist/` exists inside the source directory

## [0.5.4] - 2025-02-19

### Fixed
- **Packager self-copy bug**: `synth deploy` no longer crashes with `shutil.Error` when the `dist` output directory exists inside the source directory. The packager now resolves and skips the output path during iteration to prevent recursive self-copy on Windows and Linux.

## [0.5.3] - 2025-02-19

### Fixed
- **AgentCore deployment pattern**: Updated `agentcore_handler()` to use the correct `BedrockAgentCoreApp` pattern required by AgentCore runtime
- **AgentCore dependencies**: Added `bedrock-agentcore>=0.1.0` to the `agentcore` extra for proper deployment support

### Changed
- `agentcore_handler()` now returns a `BedrockAgentCoreApp` instance instead of a plain function
- Updated all AgentCore scaffolding templates to use `app = agentcore_handler(agent)` pattern

## [0.5.2] - 2025-02-19

### Added
- **Quickstart extra**: New `synth-agent-sdk[quickstart]` installs both Anthropic and OpenAI providers for easy demos
- **First-run welcome message**: Beautiful onboarding experience on first `synth` command with setup guide
- **`synth info` command**: Shows what's included in each installation option (provider, dependencies, models)
- **Enhanced `synth doctor`**: Now suggests specific install commands when providers are missing

### Improved
- **Installation documentation**: Reorganized README to lead with most common use case
- **Error messages**: All provider errors now include clear `pip install` instructions
- **User experience**: Better guidance for new users throughout the installation and setup process

### Changed
- Installation section in README now recommends `synth-agent-sdk[anthropic]` as the starting point

## [0.5.1] - Previous Release

Initial release with core SDK functionality.
