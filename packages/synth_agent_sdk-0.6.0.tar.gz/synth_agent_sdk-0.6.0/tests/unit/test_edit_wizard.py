"""Unit tests for ``synth/cli/edit_cmd.py`` — Edit_Wizard.

Tests cover:
- Config reading from agent.py and agentcore.yaml
- Each menu option updates the correct file
- Diff summary shown before write
- Atomic write: original file intact if write fails
- Missing file raises SynthConfigError
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from synth.cli.edit_cmd import (
    AgentConfig,
    PendingChanges,
    _atomic_write,
    _parse_agent_config,
    _patch_instructions,
    _patch_model,
    _patch_tools_list,
    _read_agentcore_yaml,
    run_edit_agent,
)
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_SAMPLE_AGENT = '''\
"""Sample agent."""

from __future__ import annotations

from synth import Agent, tool
from tools import web_search, calculate

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a helpful assistant.",
    tools=[web_search, calculate],
)

if __name__ == "__main__":
    result = agent.run("Hello")
    print(result.text)
'''

_AGENTCORE_AGENT = '''\
"""AgentCore agent."""

from __future__ import annotations

from synth import Agent

agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    instructions="You are an AWS agent.",
    tools=[],
)
'''

_SAMPLE_YAML = """\
agent_name: my-agent
agent_description: "Test agent"
aws_region: us-east-1
model_id: anthropic.claude-sonnet-4-5-20250514-v1:0
cris_enabled: false
aws_profile: default
"""


# ---------------------------------------------------------------------------
# Tests: _parse_agent_config
# ---------------------------------------------------------------------------

class TestParseAgentConfig:
    """Tests for config parsing from agent.py source."""

    def test_extracts_model(self) -> None:
        config = _parse_agent_config(_SAMPLE_AGENT, {})
        assert config.model == "claude-sonnet-4-5"

    def test_extracts_instructions(self) -> None:
        config = _parse_agent_config(_SAMPLE_AGENT, {})
        assert config.instructions == "You are a helpful assistant."

    def test_extracts_tools(self) -> None:
        config = _parse_agent_config(_SAMPLE_AGENT, {})
        assert "web_search" in config.tools
        assert "calculate" in config.tools

    def test_detects_agentcore_provider_from_model(self) -> None:
        config = _parse_agent_config(_AGENTCORE_AGENT, {})
        assert config.provider == "agentcore"

    def test_detects_agentcore_provider_from_yaml(self) -> None:
        config = _parse_agent_config(_SAMPLE_AGENT, {"aws_region": "us-east-1"})
        assert config.provider == "agentcore"

    def test_detects_anthropic_provider(self) -> None:
        config = _parse_agent_config(_SAMPLE_AGENT, {})
        assert config.provider == "anthropic"

    def test_detects_openai_provider(self) -> None:
        src = _SAMPLE_AGENT.replace("claude-sonnet-4-5", "gpt-4o")
        config = _parse_agent_config(src, {})
        assert config.provider == "openai"

    def test_stores_agentcore_config(self) -> None:
        yaml_cfg = {"aws_region": "us-west-2", "model_id": "some-model"}
        config = _parse_agent_config(_SAMPLE_AGENT, yaml_cfg)
        assert config.agentcore_config == yaml_cfg

    def test_empty_tools_list(self) -> None:
        src = _SAMPLE_AGENT.replace("tools=[web_search, calculate]", "tools=[]")
        config = _parse_agent_config(src, {})
        # Empty list — tools should be empty or contain only empty strings filtered out
        assert all(t for t in config.tools)  # no empty strings


# ---------------------------------------------------------------------------
# Tests: _read_agentcore_yaml
# ---------------------------------------------------------------------------

class TestReadAgentcoreYaml:
    """Tests for reading agentcore.yaml."""

    def test_returns_empty_dict_when_no_yaml(self, tmp_path: Path) -> None:
        agent_file = str(tmp_path / "agent.py")
        Path(agent_file).write_text("", encoding="utf-8")
        result = _read_agentcore_yaml(agent_file)
        assert result == {}

    def test_reads_yaml_fields(self, tmp_path: Path) -> None:
        agent_file = str(tmp_path / "agent.py")
        Path(agent_file).write_text("", encoding="utf-8")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(_SAMPLE_YAML, encoding="utf-8")

        result = _read_agentcore_yaml(agent_file)
        assert result.get("aws_region") == "us-east-1"
        assert result.get("agent_name") == "my-agent"


# ---------------------------------------------------------------------------
# Tests: source patching helpers
# ---------------------------------------------------------------------------

class TestPatchHelpers:
    """Tests for source-level patching functions."""

    def test_patch_model_replaces_model(self) -> None:
        result = _patch_model(_SAMPLE_AGENT, "gpt-4o")
        assert 'model="gpt-4o"' in result
        assert "claude-sonnet-4-5" not in result

    def test_patch_model_only_replaces_first(self) -> None:
        src = 'model="a"\nmodel="b"'
        result = _patch_model(src, "new")
        assert result.count('model="new"') == 1

    def test_patch_instructions_replaces_text(self) -> None:
        result = _patch_instructions(_SAMPLE_AGENT, "New instructions here.")
        assert 'instructions="New instructions here."' in result
        assert "You are a helpful assistant." not in result

    def test_patch_tools_list_replaces_list(self) -> None:
        result = _patch_tools_list(_SAMPLE_AGENT, ["search", "calc"])
        assert "tools=[search, calc]" in result

    def test_patch_tools_list_empty(self) -> None:
        result = _patch_tools_list(_SAMPLE_AGENT, [])
        assert "tools=[]" in result


# ---------------------------------------------------------------------------
# Tests: _atomic_write
# ---------------------------------------------------------------------------

class TestAtomicWrite:
    """Tests for atomic file writing."""

    def test_writes_content(self, tmp_path: Path) -> None:
        dest = str(tmp_path / "out.py")
        _atomic_write(dest, "hello world")
        assert Path(dest).read_text(encoding="utf-8") == "hello world"

    def test_overwrites_existing(self, tmp_path: Path) -> None:
        dest = str(tmp_path / "out.py")
        Path(dest).write_text("old content", encoding="utf-8")
        _atomic_write(dest, "new content")
        assert Path(dest).read_text(encoding="utf-8") == "new content"

    def test_original_intact_on_failure(self, tmp_path: Path) -> None:
        """If write fails mid-way, original file should be untouched."""
        dest = str(tmp_path / "out.py")
        Path(dest).write_text("original", encoding="utf-8")

        # Simulate failure by patching os.replace to raise
        with patch("synth.cli.edit_cmd.os.replace", side_effect=OSError("disk full")):
            with pytest.raises(OSError):
                _atomic_write(dest, "new content")

        # Original file must still be intact
        assert Path(dest).read_text(encoding="utf-8") == "original"


# ---------------------------------------------------------------------------
# Tests: run_edit_agent — missing file
# ---------------------------------------------------------------------------

class TestRunEditAgentMissingFile:
    """Tests for missing file error handling (Requirement 5.11)."""

    def test_raises_synth_config_error_for_missing_file(self) -> None:
        with pytest.raises(SynthConfigError) as exc_info:
            run_edit_agent("/nonexistent/path/agent.py")
        assert exc_info.value.component == "EditWizard"
        assert "not found" in str(exc_info.value).lower()

    def test_error_includes_suggestion(self) -> None:
        with pytest.raises(SynthConfigError) as exc_info:
            run_edit_agent("/nonexistent/agent.py")
        assert exc_info.value.suggestion


# ---------------------------------------------------------------------------
# Tests: run_edit_agent — interactive flows via CliRunner
# ---------------------------------------------------------------------------

class TestRunEditAgentInteractive:
    """Integration-style tests using CliRunner input simulation."""

    def _write_agent(self, tmp_path: Path, content: str = _SAMPLE_AGENT) -> str:
        agent_file = str(tmp_path / "agent.py")
        Path(agent_file).write_text(content, encoding="utf-8")
        return agent_file

    def test_quit_immediately_makes_no_changes(self, tmp_path: Path) -> None:
        agent_file = self._write_agent(tmp_path)
        original = Path(agent_file).read_text(encoding="utf-8")

        with patch("click.prompt", return_value="q"), \
             patch("click.confirm", return_value=False):
            run_edit_agent(agent_file)

        assert Path(agent_file).read_text(encoding="utf-8") == original

    def test_edit_instructions_updates_agent_py(self, tmp_path: Path) -> None:
        agent_file = self._write_agent(tmp_path)

        prompts = iter(["a", "New instructions text.", "q"])
        confirms = iter([True])

        with patch("click.prompt", side_effect=lambda *a, **kw: next(prompts)), \
             patch("click.confirm", side_effect=lambda *a, **kw: next(confirms)):
            run_edit_agent(agent_file)

        updated = Path(agent_file).read_text(encoding="utf-8")
        assert "New instructions text." in updated

    def test_edit_model_non_agentcore_updates_agent_py(self, tmp_path: Path) -> None:
        agent_file = self._write_agent(tmp_path)

        # Sequence: choose 'b' (model), pick model index 2, then 'q', confirm
        prompts = iter(["b", 2, "q"])
        confirms = iter([True])

        with patch("click.prompt", side_effect=lambda *a, **kw: next(prompts)), \
             patch("click.confirm", side_effect=lambda *a, **kw: next(confirms)):
            run_edit_agent(agent_file)

        updated = Path(agent_file).read_text(encoding="utf-8")
        # Model should have changed from claude-sonnet-4-5
        assert "claude-sonnet-4-5" not in updated or "claude-opus-4" in updated

    def test_diff_shown_before_write(self, tmp_path: Path) -> None:
        """Diff summary must be displayed before any file is written."""
        agent_file = self._write_agent(tmp_path)
        diff_shown = []

        original_display_diff = __import__(
            "synth.cli.edit_cmd", fromlist=["_display_diff"]
        )._display_diff

        def mock_display_diff(*args: object, **kwargs: object) -> None:
            diff_shown.append(True)
            original_display_diff(*args, **kwargs)

        prompts = iter(["a", "Updated instructions.", "q"])
        confirms = iter([True])

        with patch("synth.cli.edit_cmd._display_diff", side_effect=mock_display_diff), \
             patch("click.prompt", side_effect=lambda *a, **kw: next(prompts)), \
             patch("click.confirm", side_effect=lambda *a, **kw: next(confirms)):
            run_edit_agent(agent_file)

        assert diff_shown, "Diff must be shown before writing"

    def test_cancel_after_diff_does_not_write(self, tmp_path: Path) -> None:
        agent_file = self._write_agent(tmp_path)
        original = Path(agent_file).read_text(encoding="utf-8")

        prompts = iter(["a", "New instructions.", "q"])
        # First confirm = True (for the diff), second = False (cancel)
        confirms = iter([False])

        with patch("click.prompt", side_effect=lambda *a, **kw: next(prompts)), \
             patch("click.confirm", side_effect=lambda *a, **kw: next(confirms)):
            run_edit_agent(agent_file)

        assert Path(agent_file).read_text(encoding="utf-8") == original

    def test_agentcore_model_edit_updates_yaml(self, tmp_path: Path) -> None:
        agent_file = self._write_agent(tmp_path, _AGENTCORE_AGENT)
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(_SAMPLE_YAML, encoding="utf-8")

        mock_setup = {
            "aws_region": "eu-west-1",
            "model_id": "anthropic.claude-3-5-haiku-20241022-v1:0",
            "cris_enabled": False,
            "aws_profile": None,
        }

        prompts = iter(["b", "q"])
        confirms = iter([True])

        with patch("synth.cli.init_cmd._run_agentcore_setup", return_value=mock_setup), \
             patch("click.prompt", side_effect=lambda *a, **kw: next(prompts)), \
             patch("click.confirm", side_effect=lambda *a, **kw: next(confirms)):
            run_edit_agent(agent_file)

        updated_agent = Path(agent_file).read_text(encoding="utf-8")
        assert "anthropic.claude-3-5-haiku-20241022-v1:0" in updated_agent

        updated_yaml = yaml_file.read_text(encoding="utf-8")
        assert "eu-west-1" in updated_yaml
        assert "anthropic.claude-3-5-haiku-20241022-v1:0" in updated_yaml


# ---------------------------------------------------------------------------
# Tests: PendingChanges.has_changes
# ---------------------------------------------------------------------------

class TestPendingChanges:
    """Tests for PendingChanges helper."""

    def test_no_changes_initially(self) -> None:
        changes = PendingChanges()
        assert not changes.has_changes()

    def test_has_changes_when_model_set(self) -> None:
        changes = PendingChanges(new_model="gpt-4o")
        assert changes.has_changes()

    def test_has_changes_when_instructions_set(self) -> None:
        changes = PendingChanges(new_instructions="new text")
        assert changes.has_changes()

    def test_has_changes_when_tools_added(self) -> None:
        changes = PendingChanges(tools_to_add=["search"])
        assert changes.has_changes()

    def test_has_changes_when_tools_removed(self) -> None:
        changes = PendingChanges(tools_to_remove=["search"])
        assert changes.has_changes()
