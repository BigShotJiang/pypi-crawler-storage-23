import json
from typing import Any, Literal

from llama_cpp import LLAMA_DEFAULT_SEED
from llama_cpp.llama_grammar import LlamaGrammar
from pydantic import BaseModel, ConfigDict, Field
from sinapsis_chatbots_base.helpers.llm_keys import LLMChatKeys
from sinapsis_chatbots_base.templates.llm_text_completion_base import (
    LLMCompletionArgs,
    LLMInitArgs,
)
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR


class LLaMAInitArgs(LLMInitArgs):
    """LLaMA-specific arguments for initializing the `llama_cpp.Llama` model.

    Attributes:
        llm_model_name (str): Model repo/name or local identifier to load from.
        llm_model_file (str): GGUF filename to load.
        n_gpu_layers (int): Layers to offload to GPU (0=CPU, -1=all). Defaults to `0`.
        split_mode (Literal[0,1,2]): Multi-GPU split mode (0=none, 1=row, 2=layer). Defaults to `0`.
        main_gpu (int): Primary GPU index (some split modes). Defaults to `0`.
        tensor_split (list[float] | None): Per-GPU split fractions (None=disabled). Defaults to `None`.
        use_mmap (bool): Memory-map model file. Defaults to `True`.
        use_mlock (bool): Lock model in RAM (reduces paging). Defaults to `False`.
        seed (int): Base RNG seed (can be overridden per request). Defaults to `LLAMA_DEFAULT_SEED`.
        n_ctx (int): Context window (higher = more memory). Defaults to `512`.
        n_batch (int): Prompt/prefill batch size (clamped to <= n_ctx). Defaults to `2048`.
        n_ubatch (int): Micro-batch size (often <= n_batch). Defaults to `512`.
        n_threads (int | None): CPU threads for generation. Defaults to `None`.
        n_threads_batch (int | None): CPU threads for prompt/batch eval. Defaults to `None`.
        flash_attn_type (Literal[-1,0,1]): Flash-attn policy (-1=auto, 0=off, 1=on). Defaults to `-1`.
        offload_kqv (bool): Offload KV/attention tensors to GPU (more VRAM, often faster). Defaults to `False`.
        lora_path (str | None): LoRA adapter path. Defaults to `None`.
        lora_scale (float | None): LoRA strength (1.0 typical). Defaults to `None`.
        lora_base (str | None): Optional base model path for some LoRA setups. Defaults to `None`.
        chat_format (str | None): Chat template id used by `create_chat_completion`. Defaults to `None`.
        verbose (bool): Verbose llama.cpp logging. Defaults to `True`.
    """

    llm_model_file: str
    n_gpu_layers: int = 0
    split_mode: Literal[0, 1, 2] = 0
    main_gpu: int = 0
    tensor_split: list[float] | None = None
    use_mmap: bool = True
    use_mlock: bool = False
    seed: int = LLAMA_DEFAULT_SEED
    n_ctx: int = 512
    n_batch: int = 2048
    n_ubatch: int = 512
    n_threads: int | None = None
    n_threads_batch: int | None = None
    flash_attn_type: Literal[-1, 0, 1] = -1
    offload_kqv: bool = False
    lora_base: str | None = None
    lora_scale: float = 1.0
    lora_path: str | None = None
    chat_format: str | None = None
    verbose: bool = True


class PropertyDefinition(BaseModel):
    """Rich definition for a single property in a structured output schema.

    Allows specifying type constraints, enumerated allowed values, and a
    description to guide the LLM's output for this field.

    Attributes:
        type_ (str): The JSON Schema type (e.g. 'string', 'integer', 'number', 'boolean').
            Aliased to 'type'. Defaults to `"string"`.
        description (str | None): Human-readable description of the field's purpose.
            Included in the JSON Schema to help guide the LLM. Defaults to `None`.
        enum (list[str] | None): List of allowed values. When set, the GBNF grammar
            will physically constrain the model to only output one of these values.
            Defaults to `None`.
    """

    type_: str = Field(default="string", alias="type")
    description: str | None = None
    enum: list[str] | None = None

    model_config = ConfigDict(populate_by_name=True)

    def to_json_schema(self) -> dict[str, Any]:
        """Converts to a JSON Schema property definition dict.

        Returns:
            dict[str, Any]: A dict with 'type' and optionally 'description' and 'enum'.
        """
        result: dict[str, Any] = {"type": self.type_}
        if self.description is not None:
            result["description"] = self.description
        if self.enum is not None:
            result["enum"] = self.enum
        return result


class SchemaDefinition(BaseModel):
    """JSON Schema definition for structured LLM outputs.

    Properties can be defined in two formats:
        - **Simple**: ``{field_name: type_string}`` (e.g. ``{"name": "string"}``)
        - **Rich**: ``{field_name: PropertyDefinition}`` with type, enum, and description

    Both formats can be mixed within the same schema.

    Attributes:
        properties (dict[str, str | PropertyDefinition]): Mapping of field names to either
            a type string or a full PropertyDefinition. Defaults to empty dict.
        required (list[str]): List of field names that must be present in the output.
            Defaults to empty list.
    """

    properties: dict[str, str | PropertyDefinition] = Field(default_factory=dict)
    required: list[str] = Field(default_factory=list)

    def to_json_schema(self) -> dict[str, Any]:
        """Converts to a full JSON Schema dict.

        Simple string values are expanded to ``{"type": value}``. PropertyDefinition
        instances are converted via their own ``to_json_schema()`` method.

        Returns:
            dict[str, Any]: A JSON Schema object with 'type', 'properties', and 'required'.
        """
        json_properties: dict[str, Any] = {}
        for k, v in self.properties.items():
            if isinstance(v, str):
                json_properties[k] = {"type": v}
            else:
                json_properties[k] = v.to_json_schema()
        return {
            "type": "object",
            "properties": json_properties,
            "required": self.required,
        }


class ResponseFormat(BaseModel):
    """Defines the response format for structured LLM outputs.

    Attributes:
        type_ (Literal["text", "json_object"]): The output format type. Use 'json_object'
            to constrain the model output to valid JSON. Aliased to 'type'. Defaults to `"text"`.
        schema_ (SchemaDefinition): Schema defining the expected JSON structure. Only used
            when type is 'json_object'. Aliased to 'schema'. Defaults to empty schema.
    """

    type_: Literal["text", "json_object"] = Field(default="text", alias="type")
    schema_: SchemaDefinition = Field(default_factory=SchemaDefinition, alias="schema")

    model_config = ConfigDict(populate_by_name=True)

    def to_llama_format(self) -> dict[str, Any]:
        """Converts to the dict format expected by `llama_cpp.Llama.create_chat_completion`.

        When type is 'json_object' and properties are defined, builds a full JSON Schema
        object. When type is 'text' or no properties are defined, returns just the type.

        Returns:
            dict[str, Any]: A dict with 'type' and optionally 'schema' keys.
        """
        result: dict[str, Any] = {"type": self.type_}
        if self.type_ == "json_object" and self.schema_.properties:
            result["schema"] = self.schema_.to_json_schema()
        return result

    def to_grammar(self) -> LlamaGrammar | None:
        """Builds a GBNF grammar for use with `llama_cpp.Llama.create_completion`.

        This is the path used by llama_index's `LlamaCPP.complete()`, which calls
        `create_completion(grammar=...)` instead of `create_chat_completion(response_format=...)`.

        Returns:
            LlamaGrammar | None: A grammar object constraining output to valid JSON
                (with schema if defined), or None if type is 'text'.
        """
        if self.type_ != "json_object":
            return None
        if self.schema_.properties:
            return LlamaGrammar.from_json_schema(json.dumps(self.schema_.to_json_schema()))
        return LlamaGrammar.from_json_schema(json.dumps({"type": "object"}))


class LLaMACompletionArgs(LLMCompletionArgs):
    """LLaMA-specific arguments for `create_chat_completion`, inheriting base parameters.

    Attributes:
        max_tokens (int): Max new tokens to generate.
        min_p (float): Drop tokens below this prob (0 disables). Defaults to `0.05`.
        typical_p (float): Typical sampling (1 disables). Defaults to `1.0`.
        stop (str | list[str] | None): Stop sequence(s). Defaults to `None`.
        seed (int | None): Per-request seed override. Defaults to `None`.
        frequency_penalty (float): Penalize frequent tokens. Defaults to `0.0`.
        present_penalty (float): Penalize already-seen tokens. Defaults to `0.0`.
        repeat_penalty (float): Repetition penalty (1 disables). Defaults to `1.0`.
        penalty_last_n (int): Window for repetition penalty. Defaults to `64`.
        logit_bias (dict[int, float] | None): Logit bias per token id. Defaults to `None`.
        response_format (ResponseFormat): Output format hint (e.g. json_object + schema).
            Defaults to `ResponseFormat()`.
    """

    max_tokens: int
    min_p: float = 0.05
    typical_p: float = 1.0
    stop: str | list[str] | None = None
    frequency_penalty: float = 0.0
    present_penalty: float = 0.0
    repeat_penalty: float = 1.0
    penalty_last_n: int = 64
    seed: int | None = None
    logit_bias: dict[int, float] | None = None
    response_format: ResponseFormat = Field(default_factory=ResponseFormat)


class LLamaMultiModalKeys(LLMChatKeys):
    """Keys for specific Llama format for chat template.

    Keys:
        type (str): key for type
        text (str): key for text
        image (str): key for image
        video (str): key for video
    """

    type: str = "type"
    text: str = "text"
    image: str = "image"
    video: str = "video"


class LLaMA4CompletionArgs(LLMCompletionArgs):
    """Base arguments for controlling LLM text generation (sampling).

    Attributes:
        temperature (float): Controls randomness. 0.0 = deterministic, >0.0 = random. Defaults to `0.2`.
        top_p (float): Nucleus sampling. Considers tokens with cumulative probability >= top_p. Defaults to `0.95`.
        top_k (int): Top-k sampling. Considers the top 'k' most probable tokens. Defaults to `40`.
        max_length (int): The maximum length of the sequence (prompt + generation). Defaults to `20`.
        max_new_tokens (int | None): The maximum number of *new* tokens to generate, excluding the prompt. Defaults to
            `None`.
        do_sample (bool): Whether to use sampling (True) or greedy decoding (False). Defaults to `True`.
        min_p (float | None): Min-p sampling. Filters tokens below this probability threshold. Defaults to `None`.
        repetition_penalty (float): Penalty applied to repeated tokens (1.0 = no penalty). Defaults to `1.0`.
    """

    max_length: int = 20
    max_new_tokens: int | None = None
    do_sample: bool = True
    min_p: float | None = None
    repetition_penalty: float = 1.0


class LLaMA4InitArgs(LLMInitArgs):
    """Initialization arguments for loading a Transformers Llama 4 model.

    Inherits 'llm_model_name' from the base class.

    Attributes:
        llm_model_name (str): The name or path of the LLM model to use
                            (e.g., 'meta-llama/Llama-4-Scout-17B-16E-Instruct').
        cache_dir (str): Path to use for the model cache and download. Defaults to `SINAPSIS_CACHE_DIR`.
        device_map (str): Device mapping for `from_pretrained`. Defaults to `auto`.
        torch_dtype (str | None): Model tensor precision (e.g., 'auto', 'float16'). Defaults to `auto`.
        max_memory (dict | None): Max memory allocation per device. Defaults to `None`.
    """

    cache_dir: str = SINAPSIS_CACHE_DIR
    device_map: str = "auto"
    torch_dtype: str | None = "auto"
    max_memory: dict | None = None
