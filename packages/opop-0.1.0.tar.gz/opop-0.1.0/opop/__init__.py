"""OpOp -- The Optimizer Optimizer.

A tiny brain that watches your training and learns what helps.
Wraps any optimizer. 50KB memory. Can't make things worse.
"""

__version__ = "0.1.0"

from opop.brain import OptBrain, Brain, TrainingObserver

__all__ = ["OptBrain", "Brain", "TrainingObserver"]
