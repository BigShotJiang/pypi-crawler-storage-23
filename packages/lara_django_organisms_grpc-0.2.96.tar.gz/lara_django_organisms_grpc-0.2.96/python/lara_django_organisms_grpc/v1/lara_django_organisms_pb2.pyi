from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ClassisDestroyRequest(_message.Message):
    __slots__ = ("classis_id",)
    CLASSIS_ID_FIELD_NUMBER: _ClassVar[int]
    classis_id: str
    def __init__(self, classis_id: _Optional[str] = ...) -> None: ...

class ClassisListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ClassisListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ClassisResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ClassisResponse, _Mapping]]] = ...) -> None: ...

class ClassisPartialUpdateRequest(_message.Message):
    __slots__ = ("classis_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CLASSIS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    classis_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, classis_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class ClassisRequest(_message.Message):
    __slots__ = ("classis_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CLASSIS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    classis_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, classis_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class ClassisResponse(_message.Message):
    __slots__ = ("classis_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CLASSIS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    classis_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, classis_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class ClassisRetrieveRequest(_message.Message):
    __slots__ = ("classis_id",)
    CLASSIS_ID_FIELD_NUMBER: _ClassVar[int]
    classis_id: str
    def __init__(self, classis_id: _Optional[str] = ...) -> None: ...

class ClassisStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CultivarDestroyRequest(_message.Message):
    __slots__ = ("cultivar_id",)
    CULTIVAR_ID_FIELD_NUMBER: _ClassVar[int]
    cultivar_id: str
    def __init__(self, cultivar_id: _Optional[str] = ...) -> None: ...

class CultivarListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CultivarListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[CultivarResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[CultivarResponse, _Mapping]]] = ...) -> None: ...

class CultivarPartialUpdateRequest(_message.Message):
    __slots__ = ("cultivar_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CULTIVAR_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    cultivar_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, cultivar_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class CultivarRequest(_message.Message):
    __slots__ = ("cultivar_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CULTIVAR_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    cultivar_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, cultivar_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class CultivarResponse(_message.Message):
    __slots__ = ("cultivar_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    CULTIVAR_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    cultivar_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, cultivar_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class CultivarRetrieveRequest(_message.Message):
    __slots__ = ("cultivar_id",)
    CULTIVAR_ID_FIELD_NUMBER: _ClassVar[int]
    cultivar_id: str
    def __init__(self, cultivar_id: _Optional[str] = ...) -> None: ...

class CultivarStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DomainDestroyRequest(_message.Message):
    __slots__ = ("domain_id",)
    DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    domain_id: str
    def __init__(self, domain_id: _Optional[str] = ...) -> None: ...

class DomainListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DomainListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[DomainResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[DomainResponse, _Mapping]]] = ...) -> None: ...

class DomainPartialUpdateRequest(_message.Message):
    __slots__ = ("domain_id", "_partial_update_fields", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    domain_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, domain_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class DomainRequest(_message.Message):
    __slots__ = ("domain_id", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    domain_id: str
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, domain_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class DomainResponse(_message.Message):
    __slots__ = ("domain_id", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    domain_id: str
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, domain_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class DomainRetrieveRequest(_message.Message):
    __slots__ = ("domain_id",)
    DOMAIN_ID_FIELD_NUMBER: _ClassVar[int]
    domain_id: str
    def __init__(self, domain_id: _Optional[str] = ...) -> None: ...

class DomainStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FamiliaDestroyRequest(_message.Message):
    __slots__ = ("familia_id",)
    FAMILIA_ID_FIELD_NUMBER: _ClassVar[int]
    familia_id: str
    def __init__(self, familia_id: _Optional[str] = ...) -> None: ...

class FamiliaListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FamiliaListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[FamiliaResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[FamiliaResponse, _Mapping]]] = ...) -> None: ...

class FamiliaPartialUpdateRequest(_message.Message):
    __slots__ = ("familia_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    FAMILIA_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    familia_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, familia_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class FamiliaRequest(_message.Message):
    __slots__ = ("familia_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    FAMILIA_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    familia_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, familia_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class FamiliaResponse(_message.Message):
    __slots__ = ("familia_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    FAMILIA_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    familia_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, familia_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class FamiliaRetrieveRequest(_message.Message):
    __slots__ = ("familia_id",)
    FAMILIA_ID_FIELD_NUMBER: _ClassVar[int]
    familia_id: str
    def __init__(self, familia_id: _Optional[str] = ...) -> None: ...

class FamiliaStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GenusDestroyRequest(_message.Message):
    __slots__ = ("genus_id",)
    GENUS_ID_FIELD_NUMBER: _ClassVar[int]
    genus_id: str
    def __init__(self, genus_id: _Optional[str] = ...) -> None: ...

class GenusListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GenusListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[GenusResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[GenusResponse, _Mapping]]] = ...) -> None: ...

class GenusPartialUpdateRequest(_message.Message):
    __slots__ = ("genus_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    GENUS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    genus_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, genus_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class GenusRequest(_message.Message):
    __slots__ = ("genus_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    GENUS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    genus_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, genus_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class GenusResponse(_message.Message):
    __slots__ = ("genus_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    GENUS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    genus_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, genus_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class GenusRetrieveRequest(_message.Message):
    __slots__ = ("genus_id",)
    GENUS_ID_FIELD_NUMBER: _ClassVar[int]
    genus_id: str
    def __init__(self, genus_id: _Optional[str] = ...) -> None: ...

class GenusStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatClassDestroyRequest(_message.Message):
    __slots__ = ("habitatclass_id",)
    HABITATCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    habitatclass_id: str
    def __init__(self, habitatclass_id: _Optional[str] = ...) -> None: ...

class HabitatClassListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatClassListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[HabitatClassResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[HabitatClassResponse, _Mapping]]] = ...) -> None: ...

class HabitatClassPartialUpdateRequest(_message.Message):
    __slots__ = ("habitatclass_id", "_partial_update_fields", "name", "iri", "description")
    HABITATCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    habitatclass_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, habitatclass_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class HabitatClassRequest(_message.Message):
    __slots__ = ("habitatclass_id", "name", "iri", "description")
    HABITATCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    habitatclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, habitatclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class HabitatClassResponse(_message.Message):
    __slots__ = ("habitatclass_id", "name", "iri", "description")
    HABITATCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    habitatclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, habitatclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class HabitatClassRetrieveRequest(_message.Message):
    __slots__ = ("habitatclass_id",)
    HABITATCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    habitatclass_id: str
    def __init__(self, habitatclass_id: _Optional[str] = ...) -> None: ...

class HabitatClassStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatDestroyRequest(_message.Message):
    __slots__ = ("habitat_id",)
    HABITAT_ID_FIELD_NUMBER: _ClassVar[int]
    habitat_id: str
    def __init__(self, habitat_id: _Optional[str] = ...) -> None: ...

class HabitatListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[HabitatResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[HabitatResponse, _Mapping]]] = ...) -> None: ...

class HabitatParameterDestroyRequest(_message.Message):
    __slots__ = ("habitatparameter_id",)
    HABITATPARAMETER_ID_FIELD_NUMBER: _ClassVar[int]
    habitatparameter_id: str
    def __init__(self, habitatparameter_id: _Optional[str] = ...) -> None: ...

class HabitatParameterListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatParameterListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[HabitatParameterResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[HabitatParameterResponse, _Mapping]]] = ...) -> None: ...

class HabitatParameterPartialUpdateRequest(_message.Message):
    __slots__ = ("habitatparameter_id", "unit", "data_extra", "_partial_update_fields", "name", "iri", "value_range", "description", "datetime_last_modified", "name_display")
    HABITATPARAMETER_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitatparameter_id: str
    unit: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    value_range: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitatparameter_id: _Optional[str] = ..., unit: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatParameterRequest(_message.Message):
    __slots__ = ("habitatparameter_id", "unit", "data_extra", "name", "iri", "value_range", "description", "datetime_last_modified", "name_display")
    HABITATPARAMETER_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitatparameter_id: str
    unit: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    value_range: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitatparameter_id: _Optional[str] = ..., unit: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatParameterResponse(_message.Message):
    __slots__ = ("habitatparameter_id", "unit", "data_extra", "name", "iri", "value_range", "description", "datetime_last_modified", "name_display")
    HABITATPARAMETER_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitatparameter_id: str
    unit: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    value_range: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitatparameter_id: _Optional[str] = ..., unit: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatParameterRetrieveRequest(_message.Message):
    __slots__ = ("habitatparameter_id",)
    HABITATPARAMETER_ID_FIELD_NUMBER: _ClassVar[int]
    habitatparameter_id: str
    def __init__(self, habitatparameter_id: _Optional[str] = ...) -> None: ...

class HabitatParameterStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HabitatPartialUpdateRequest(_message.Message):
    __slots__ = ("habitat_id", "habitat_class", "parameters", "_partial_update_fields", "name", "iri", "description", "datetime_last_modified", "name_display")
    HABITAT_ID_FIELD_NUMBER: _ClassVar[int]
    HABITAT_CLASS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitat_id: str
    habitat_class: str
    parameters: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitat_id: _Optional[str] = ..., habitat_class: _Optional[str] = ..., parameters: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatRequest(_message.Message):
    __slots__ = ("habitat_id", "habitat_class", "parameters", "name", "iri", "description", "datetime_last_modified", "name_display")
    HABITAT_ID_FIELD_NUMBER: _ClassVar[int]
    HABITAT_CLASS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitat_id: str
    habitat_class: str
    parameters: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitat_id: _Optional[str] = ..., habitat_class: _Optional[str] = ..., parameters: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatResponse(_message.Message):
    __slots__ = ("habitat_id", "habitat_class", "parameters", "name", "iri", "description", "datetime_last_modified", "name_display")
    HABITAT_ID_FIELD_NUMBER: _ClassVar[int]
    HABITAT_CLASS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    habitat_id: str
    habitat_class: str
    parameters: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, habitat_id: _Optional[str] = ..., habitat_class: _Optional[str] = ..., parameters: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class HabitatRetrieveRequest(_message.Message):
    __slots__ = ("habitat_id",)
    HABITAT_ID_FIELD_NUMBER: _ClassVar[int]
    habitat_id: str
    def __init__(self, habitat_id: _Optional[str] = ...) -> None: ...

class HabitatStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class OrdoDestroyRequest(_message.Message):
    __slots__ = ("ordo_id",)
    ORDO_ID_FIELD_NUMBER: _ClassVar[int]
    ordo_id: str
    def __init__(self, ordo_id: _Optional[str] = ...) -> None: ...

class OrdoListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrdoListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrdoResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrdoResponse, _Mapping]]] = ...) -> None: ...

class OrdoPartialUpdateRequest(_message.Message):
    __slots__ = ("ordo_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    ORDO_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ordo_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, ordo_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class OrdoRequest(_message.Message):
    __slots__ = ("ordo_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    ORDO_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ordo_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, ordo_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class OrdoResponse(_message.Message):
    __slots__ = ("ordo_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    ORDO_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ordo_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, ordo_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class OrdoRetrieveRequest(_message.Message):
    __slots__ = ("ordo_id",)
    ORDO_ID_FIELD_NUMBER: _ClassVar[int]
    ordo_id: str
    def __init__(self, ordo_id: _Optional[str] = ...) -> None: ...

class OrdoStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismDestroyRequest(_message.Message):
    __slots__ = ("organism_id",)
    ORGANISM_ID_FIELD_NUMBER: _ClassVar[int]
    organism_id: str
    def __init__(self, organism_id: _Optional[str] = ...) -> None: ...

class OrganismListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismResponse, _Mapping]]] = ...) -> None: ...

class OrganismPartialUpdateRequest(_message.Message):
    __slots__ = ("organism_id", "domain", "regnum", "phylum", "classis", "ordo", "familia", "genus", "species", "subspecies", "variant", "cultivar", "habitats", "traits", "organisms", "data_extra", "tags", "_partial_update_fields", "name", "name_common", "iri", "pac_id", "genome", "hybrid", "chimera", "description", "datetime_last_modified", "name_display", "characteristics")
    ORGANISM_ID_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    REGNUM_FIELD_NUMBER: _ClassVar[int]
    PHYLUM_FIELD_NUMBER: _ClassVar[int]
    CLASSIS_FIELD_NUMBER: _ClassVar[int]
    ORDO_FIELD_NUMBER: _ClassVar[int]
    FAMILIA_FIELD_NUMBER: _ClassVar[int]
    GENUS_FIELD_NUMBER: _ClassVar[int]
    SPECIES_FIELD_NUMBER: _ClassVar[int]
    SUBSPECIES_FIELD_NUMBER: _ClassVar[int]
    VARIANT_FIELD_NUMBER: _ClassVar[int]
    CULTIVAR_FIELD_NUMBER: _ClassVar[int]
    HABITATS_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    organism_id: str
    domain: str
    regnum: str
    phylum: str
    classis: str
    ordo: str
    familia: str
    genus: str
    species: str
    subspecies: str
    variant: str
    cultivar: str
    habitats: _containers.RepeatedScalarFieldContainer[str]
    traits: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    iri: str
    pac_id: str
    genome: str
    hybrid: bool
    chimera: bool
    description: str
    datetime_last_modified: str
    name_display: str
    characteristics: _struct_pb2.Struct
    def __init__(self, organism_id: _Optional[str] = ..., domain: _Optional[str] = ..., regnum: _Optional[str] = ..., phylum: _Optional[str] = ..., classis: _Optional[str] = ..., ordo: _Optional[str] = ..., familia: _Optional[str] = ..., genus: _Optional[str] = ..., species: _Optional[str] = ..., subspecies: _Optional[str] = ..., variant: _Optional[str] = ..., cultivar: _Optional[str] = ..., habitats: _Optional[_Iterable[str]] = ..., traits: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., iri: _Optional[str] = ..., pac_id: _Optional[str] = ..., genome: _Optional[str] = ..., hybrid: bool = ..., chimera: bool = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class OrganismRequest(_message.Message):
    __slots__ = ("organism_id", "domain", "regnum", "phylum", "classis", "ordo", "familia", "genus", "species", "subspecies", "variant", "cultivar", "habitats", "traits", "organisms", "data_extra", "tags", "name", "name_common", "iri", "pac_id", "genome", "hybrid", "chimera", "description", "datetime_last_modified", "name_display", "characteristics")
    ORGANISM_ID_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    REGNUM_FIELD_NUMBER: _ClassVar[int]
    PHYLUM_FIELD_NUMBER: _ClassVar[int]
    CLASSIS_FIELD_NUMBER: _ClassVar[int]
    ORDO_FIELD_NUMBER: _ClassVar[int]
    FAMILIA_FIELD_NUMBER: _ClassVar[int]
    GENUS_FIELD_NUMBER: _ClassVar[int]
    SPECIES_FIELD_NUMBER: _ClassVar[int]
    SUBSPECIES_FIELD_NUMBER: _ClassVar[int]
    VARIANT_FIELD_NUMBER: _ClassVar[int]
    CULTIVAR_FIELD_NUMBER: _ClassVar[int]
    HABITATS_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    organism_id: str
    domain: str
    regnum: str
    phylum: str
    classis: str
    ordo: str
    familia: str
    genus: str
    species: str
    subspecies: str
    variant: str
    cultivar: str
    habitats: _containers.RepeatedScalarFieldContainer[str]
    traits: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    iri: str
    pac_id: str
    genome: str
    hybrid: bool
    chimera: bool
    description: str
    datetime_last_modified: str
    name_display: str
    characteristics: _struct_pb2.Struct
    def __init__(self, organism_id: _Optional[str] = ..., domain: _Optional[str] = ..., regnum: _Optional[str] = ..., phylum: _Optional[str] = ..., classis: _Optional[str] = ..., ordo: _Optional[str] = ..., familia: _Optional[str] = ..., genus: _Optional[str] = ..., species: _Optional[str] = ..., subspecies: _Optional[str] = ..., variant: _Optional[str] = ..., cultivar: _Optional[str] = ..., habitats: _Optional[_Iterable[str]] = ..., traits: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., iri: _Optional[str] = ..., pac_id: _Optional[str] = ..., genome: _Optional[str] = ..., hybrid: bool = ..., chimera: bool = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class OrganismResponse(_message.Message):
    __slots__ = ("organism_id", "domain", "regnum", "phylum", "classis", "ordo", "familia", "genus", "species", "subspecies", "variant", "cultivar", "habitats", "traits", "organisms", "data_extra", "tags", "name", "name_common", "iri", "pac_id", "genome", "hybrid", "chimera", "description", "datetime_last_modified", "name_display", "characteristics")
    ORGANISM_ID_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    REGNUM_FIELD_NUMBER: _ClassVar[int]
    PHYLUM_FIELD_NUMBER: _ClassVar[int]
    CLASSIS_FIELD_NUMBER: _ClassVar[int]
    ORDO_FIELD_NUMBER: _ClassVar[int]
    FAMILIA_FIELD_NUMBER: _ClassVar[int]
    GENUS_FIELD_NUMBER: _ClassVar[int]
    SPECIES_FIELD_NUMBER: _ClassVar[int]
    SUBSPECIES_FIELD_NUMBER: _ClassVar[int]
    VARIANT_FIELD_NUMBER: _ClassVar[int]
    CULTIVAR_FIELD_NUMBER: _ClassVar[int]
    HABITATS_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    organism_id: str
    domain: str
    regnum: str
    phylum: str
    classis: str
    ordo: str
    familia: str
    genus: str
    species: str
    subspecies: str
    variant: str
    cultivar: str
    habitats: _containers.RepeatedScalarFieldContainer[str]
    traits: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    iri: str
    pac_id: str
    genome: str
    hybrid: bool
    chimera: bool
    description: str
    datetime_last_modified: str
    name_display: str
    characteristics: _struct_pb2.Struct
    def __init__(self, organism_id: _Optional[str] = ..., domain: _Optional[str] = ..., regnum: _Optional[str] = ..., phylum: _Optional[str] = ..., classis: _Optional[str] = ..., ordo: _Optional[str] = ..., familia: _Optional[str] = ..., genus: _Optional[str] = ..., species: _Optional[str] = ..., subspecies: _Optional[str] = ..., variant: _Optional[str] = ..., cultivar: _Optional[str] = ..., habitats: _Optional[_Iterable[str]] = ..., traits: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., iri: _Optional[str] = ..., pac_id: _Optional[str] = ..., genome: _Optional[str] = ..., hybrid: bool = ..., chimera: bool = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class OrganismRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class OrganismRetrieveRequest(_message.Message):
    __slots__ = ("organism_id",)
    ORGANISM_ID_FIELD_NUMBER: _ClassVar[int]
    organism_id: str
    def __init__(self, organism_id: _Optional[str] = ...) -> None: ...

class OrganismStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismsSubsetDestroyRequest(_message.Message):
    __slots__ = ("organismssubset_id",)
    ORGANISMSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    organismssubset_id: str
    def __init__(self, organismssubset_id: _Optional[str] = ...) -> None: ...

class OrganismsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismsSubsetResponse, _Mapping]]] = ...) -> None: ...

class OrganismsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("organismssubset_id", "namespace", "group", "organisms", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismssubset_id: str
    namespace: str
    group: str
    organisms: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organismssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organisms: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsSubsetRequest(_message.Message):
    __slots__ = ("organismssubset_id", "namespace", "group", "organisms", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismssubset_id: str
    namespace: str
    group: str
    organisms: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organismssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organisms: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsSubsetResponse(_message.Message):
    __slots__ = ("organismssubset_id", "namespace", "group", "organisms", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismssubset_id: str
    namespace: str
    group: str
    organisms: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organismssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organisms: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("organismssubset_id",)
    ORGANISMSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    organismssubset_id: str
    def __init__(self, organismssubset_id: _Optional[str] = ...) -> None: ...

class OrganismsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhylumDestroyRequest(_message.Message):
    __slots__ = ("phylum_id",)
    PHYLUM_ID_FIELD_NUMBER: _ClassVar[int]
    phylum_id: str
    def __init__(self, phylum_id: _Optional[str] = ...) -> None: ...

class PhylumListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhylumListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PhylumResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PhylumResponse, _Mapping]]] = ...) -> None: ...

class PhylumPartialUpdateRequest(_message.Message):
    __slots__ = ("phylum_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    PHYLUM_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    phylum_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, phylum_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class PhylumRequest(_message.Message):
    __slots__ = ("phylum_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    PHYLUM_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    phylum_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, phylum_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class PhylumResponse(_message.Message):
    __slots__ = ("phylum_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    PHYLUM_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    phylum_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, phylum_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class PhylumRetrieveRequest(_message.Message):
    __slots__ = ("phylum_id",)
    PHYLUM_ID_FIELD_NUMBER: _ClassVar[int]
    phylum_id: str
    def __init__(self, phylum_id: _Optional[str] = ...) -> None: ...

class PhylumStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RegnumDestroyRequest(_message.Message):
    __slots__ = ("regnum_id",)
    REGNUM_ID_FIELD_NUMBER: _ClassVar[int]
    regnum_id: str
    def __init__(self, regnum_id: _Optional[str] = ...) -> None: ...

class RegnumListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RegnumListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[RegnumResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[RegnumResponse, _Mapping]]] = ...) -> None: ...

class RegnumPartialUpdateRequest(_message.Message):
    __slots__ = ("regnum_id", "_partial_update_fields", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    REGNUM_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    regnum_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, regnum_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class RegnumRequest(_message.Message):
    __slots__ = ("regnum_id", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    REGNUM_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    regnum_id: str
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, regnum_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class RegnumResponse(_message.Message):
    __slots__ = ("regnum_id", "name", "iri", "characteristics", "description", "datetime_last_modified", "traits", "name_display")
    REGNUM_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    regnum_id: str
    name: str
    iri: str
    characteristics: _struct_pb2.Struct
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, regnum_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class RegnumRetrieveRequest(_message.Message):
    __slots__ = ("regnum_id",)
    REGNUM_ID_FIELD_NUMBER: _ClassVar[int]
    regnum_id: str
    def __init__(self, regnum_id: _Optional[str] = ...) -> None: ...

class RegnumStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SpeciesDestroyRequest(_message.Message):
    __slots__ = ("species_id",)
    SPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    species_id: str
    def __init__(self, species_id: _Optional[str] = ...) -> None: ...

class SpeciesListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SpeciesListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SpeciesResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SpeciesResponse, _Mapping]]] = ...) -> None: ...

class SpeciesPartialUpdateRequest(_message.Message):
    __slots__ = ("species_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    species_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, species_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SpeciesRequest(_message.Message):
    __slots__ = ("species_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    species_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, species_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SpeciesResponse(_message.Message):
    __slots__ = ("species_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    species_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, species_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SpeciesRetrieveRequest(_message.Message):
    __slots__ = ("species_id",)
    SPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    species_id: str
    def __init__(self, species_id: _Optional[str] = ...) -> None: ...

class SpeciesStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubspeciesDestroyRequest(_message.Message):
    __slots__ = ("subspecies_id",)
    SUBSPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    subspecies_id: str
    def __init__(self, subspecies_id: _Optional[str] = ...) -> None: ...

class SubspeciesListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubspeciesListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubspeciesResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubspeciesResponse, _Mapping]]] = ...) -> None: ...

class SubspeciesPartialUpdateRequest(_message.Message):
    __slots__ = ("subspecies_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SUBSPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    subspecies_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, subspecies_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SubspeciesRequest(_message.Message):
    __slots__ = ("subspecies_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SUBSPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    subspecies_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, subspecies_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SubspeciesResponse(_message.Message):
    __slots__ = ("subspecies_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    SUBSPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    subspecies_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, subspecies_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class SubspeciesRetrieveRequest(_message.Message):
    __slots__ = ("subspecies_id",)
    SUBSPECIES_ID_FIELD_NUMBER: _ClassVar[int]
    subspecies_id: str
    def __init__(self, subspecies_id: _Optional[str] = ...) -> None: ...

class SubspeciesStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TraitDestroyRequest(_message.Message):
    __slots__ = ("trait_id",)
    TRAIT_ID_FIELD_NUMBER: _ClassVar[int]
    trait_id: str
    def __init__(self, trait_id: _Optional[str] = ...) -> None: ...

class TraitListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TraitListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[TraitResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[TraitResponse, _Mapping]]] = ...) -> None: ...

class TraitPartialUpdateRequest(_message.Message):
    __slots__ = ("trait_id", "unit", "_partial_update_fields", "name", "value_range", "characteristics", "iri", "description", "datetime_last_modified", "name_display")
    TRAIT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    trait_id: str
    unit: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    value_range: _struct_pb2.Struct
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, trait_id: _Optional[str] = ..., unit: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class TraitRequest(_message.Message):
    __slots__ = ("trait_id", "unit", "name", "value_range", "characteristics", "iri", "description", "datetime_last_modified", "name_display")
    TRAIT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    trait_id: str
    unit: str
    name: str
    value_range: _struct_pb2.Struct
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, trait_id: _Optional[str] = ..., unit: _Optional[str] = ..., name: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class TraitResponse(_message.Message):
    __slots__ = ("trait_id", "unit", "name", "value_range", "characteristics", "iri", "description", "datetime_last_modified", "name_display")
    TRAIT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_RANGE_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    trait_id: str
    unit: str
    name: str
    value_range: _struct_pb2.Struct
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, trait_id: _Optional[str] = ..., unit: _Optional[str] = ..., name: _Optional[str] = ..., value_range: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class TraitRetrieveRequest(_message.Message):
    __slots__ = ("trait_id",)
    TRAIT_ID_FIELD_NUMBER: _ClassVar[int]
    trait_id: str
    def __init__(self, trait_id: _Optional[str] = ...) -> None: ...

class TraitStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class VariantDestroyRequest(_message.Message):
    __slots__ = ("variant_id",)
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    def __init__(self, variant_id: _Optional[str] = ...) -> None: ...

class VariantListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class VariantListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[VariantResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[VariantResponse, _Mapping]]] = ...) -> None: ...

class VariantPartialUpdateRequest(_message.Message):
    __slots__ = ("variant_id", "_partial_update_fields", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, variant_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class VariantRequest(_message.Message):
    __slots__ = ("variant_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, variant_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class VariantResponse(_message.Message):
    __slots__ = ("variant_id", "name", "name_common", "characteristics", "iri", "description", "datetime_last_modified", "traits", "name_display")
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_COMMON_FIELD_NUMBER: _ClassVar[int]
    CHARACTERISTICS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    name: str
    name_common: str
    characteristics: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    traits: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    def __init__(self, variant_id: _Optional[str] = ..., name: _Optional[str] = ..., name_common: _Optional[str] = ..., characteristics: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., traits: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ...) -> None: ...

class VariantRetrieveRequest(_message.Message):
    __slots__ = ("variant_id",)
    VARIANT_ID_FIELD_NUMBER: _ClassVar[int]
    variant_id: str
    def __init__(self, variant_id: _Optional[str] = ...) -> None: ...

class VariantStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
