"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms high_level_interface *

:details: lara_django_organisms high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_grpc.v1.lara_django_organisms_pb2 as lara_django_organisms_pb2
import lara_django_organisms_grpc.v1.lara_django_organisms_pb2_grpc as lara_django_organisms_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_organisms_grpc.lara_django_organisms_data_model as organisms_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_organisms_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_organisms_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_organisms_pb2.FileUploadChunk


        # self.extradata_full_client = lara_django_organisms_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  extradata:  list[organisms_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_organisms_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if extradata.namespace == "" or extradata.namespace == "default":
                    extradata.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_organisms_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> organisms_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_organisms_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_organisms_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, extradata : organisms_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            res = await self.extradata_client.Update(
                lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_organisms_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  HabitatClass  ______________________


class HabitatClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.habitatclass_client = lara_django_organisms_pb2_grpc.HabitatClassControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  habitatclasses:  list[organisms_dm.HabitatClass] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.HabitatClass]]:
        try:
            create_coroutines = ( self.habitatclass_client.Create(lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump())) for habitatclass in habitatclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitatclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating habitatclass: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        habitatclass_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.HabitatClass]:
        """ retrieve a list of habitatclass instances by habitatclass_id, name or filter_dict,
               returns a list of habitatclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  habitatclass_id is not None:
            try:
                res =  await self.habitatclass_client.Retrieve(
                    lara_django_organisms_pb2.HabitatClassRetrieveRequest(habitatclass_id=habitatclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving habitatclass_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.habitatclass_client.List(
                    lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving habitatclass name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the habitatclass_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].habitatclass_id
        else:
            raise ValueError(f"Error retrieving habitatclass_id - no or too many results found.")
    
    async def get_by_id(self, habitatclass_id: str = None) -> organisms_dm.HabitatClass:
        """ retrieve a habitatclass data model by habitatclass_id """
        try:
            res = await self.habitatclass_client.Retrieve(
                lara_django_organisms_pb2.HabitatClassRetrieveRequest(habitatclass_id=habitatclass_id)
            )
            return organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitatclass_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.HabitatClass | str:
        """ retrieve a habitatclass data model by name """
        try:
            res = await self.habitatclass_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.HabitatClassRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["habitatclass_id"]
            else:
                return organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitatclass name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all habitatclasss """
        if filter_dict is None:
            res = await self.habitatclass_client.List(lara_django_organisms_pb2.HabitatClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitatclass_client.List(
                lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all habitatclasss """
        if self.habitatclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, habitatclass : organisms_dm.HabitatClass = None) -> None:
        """ update a habitatclass model instance """
        try:
            res = await self.habitatclass_client.Update(
                lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating habitatclass_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a habitatclass by habitatclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.habitatclass_client.Destroy(lara_django_organisms_pb2.HabitatClassDestroyRequest(habitatclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting habitatclass_id: {e}")

#_________________  HabitatParameter  ______________________


class HabitatParameterInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.habitatparameter_client = lara_django_organisms_pb2_grpc.HabitatParameterControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  habitatparameters:  list[organisms_dm.HabitatParameter] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.HabitatParameter]]:
        try:
            create_coroutines = ( self.habitatparameter_client.Create(lara_django_organisms_pb2.HabitatParameterRequest(**habitatparameter.model_dump())) for habitatparameter in habitatparameters )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitatparameter_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating habitatparameter: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        habitatparameter_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.HabitatParameter]:
        """ retrieve a list of habitatparameter instances by habitatparameter_id, name or filter_dict,
               returns a list of habitatparameter data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  habitatparameter_id is not None:
            try:
                res =  await self.habitatparameter_client.Retrieve(
                    lara_django_organisms_pb2.HabitatParameterRetrieveRequest(habitatparameter_id=habitatparameter_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving habitatparameter_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.habitatparameter_client.List(
                    lara_django_organisms_pb2.HabitatParameterListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving habitatparameter name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the habitatparameter_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].habitatparameter_id
        else:
            raise ValueError(f"Error retrieving habitatparameter_id - no or too many results found.")
    
    async def get_by_id(self, habitatparameter_id: str = None) -> organisms_dm.HabitatParameter:
        """ retrieve a habitatparameter data model by habitatparameter_id """
        try:
            res = await self.habitatparameter_client.Retrieve(
                lara_django_organisms_pb2.HabitatParameterRetrieveRequest(habitatparameter_id=habitatparameter_id)
            )
            return organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitatparameter_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.HabitatParameter | str:
        """ retrieve a habitatparameter data model by name """
        try:
            res = await self.habitatparameter_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.HabitatParameterRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["habitatparameter_id"]
            else:
                return organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitatparameter name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all habitatparameters """
        if filter_dict is None:
            res = await self.habitatparameter_client.List(lara_django_organisms_pb2.HabitatParameterListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitatparameter_client.List(
                lara_django_organisms_pb2.HabitatParameterListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatparameter_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all habitatparameters """
        if self.habitatparameter_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitatparameter_full_client.List(
                lara_django_organisms_pb2.HabitatParameterFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitatparameter_full_client.List(
                lara_django_organisms_pb2.HabitatParameterFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, habitatparameter : organisms_dm.HabitatParameter = None) -> None:
        """ update a habitatparameter model instance """
        try:
            res = await self.habitatparameter_client.Update(
                lara_django_organisms_pb2.HabitatParameterRequest(**habitatparameter.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating habitatparameter_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a habitatparameter by habitatparameter_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.habitatparameter_client.Destroy(lara_django_organisms_pb2.HabitatParameterDestroyRequest(habitatparameter_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting habitatparameter_id: {e}")

#_________________  Habitat  ______________________


class HabitatInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.habitat_client = lara_django_organisms_pb2_grpc.HabitatControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  habitats:  list[organisms_dm.Habitat] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Habitat]]:
        try:
            create_coroutines = ( self.habitat_client.Create(lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump())) for habitat in habitats )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitat_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating habitat: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        habitat_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Habitat]:
        """ retrieve a list of habitat instances by habitat_id, name or filter_dict,
               returns a list of habitat data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  habitat_id is not None:
            try:
                res =  await self.habitat_client.Retrieve(
                    lara_django_organisms_pb2.HabitatRetrieveRequest(habitat_id=habitat_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving habitat_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.habitat_client.List(
                    lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving habitat name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the habitat_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].habitat_id
        else:
            raise ValueError(f"Error retrieving habitat_id - no or too many results found.")
    
    async def get_by_id(self, habitat_id: str = None) -> organisms_dm.Habitat:
        """ retrieve a habitat data model by habitat_id """
        try:
            res = await self.habitat_client.Retrieve(
                lara_django_organisms_pb2.HabitatRetrieveRequest(habitat_id=habitat_id)
            )
            return organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitat_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Habitat | str:
        """ retrieve a habitat data model by name """
        try:
            res = await self.habitat_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.HabitatRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["habitat_id"]
            else:
                return organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving habitat name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all habitats """
        if filter_dict is None:
            res = await self.habitat_client.List(lara_django_organisms_pb2.HabitatListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitat_client.List(
                lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitat_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all habitats """
        if self.habitat_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, habitat : organisms_dm.Habitat = None) -> None:
        """ update a habitat model instance """
        try:
            res = await self.habitat_client.Update(
                lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating habitat_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a habitat by habitat_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.habitat_client.Destroy(lara_django_organisms_pb2.HabitatDestroyRequest(habitat_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting habitat_id: {e}")

#_________________  Trait  ______________________


class TraitInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.trait_client = lara_django_organisms_pb2_grpc.TraitControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  featureclasses:  list[organisms_dm.Trait] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Trait]]:
        try:
            create_coroutines = ( self.trait_client.Create(lara_django_organisms_pb2.TraitRequest(**trait.model_dump())) for trait in featureclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.trait_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating trait: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        trait_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Trait]:
        """ retrieve a list of trait instances by trait_id, name or filter_dict,
               returns a list of trait data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  trait_id is not None:
            try:
                res =  await self.trait_client.Retrieve(
                    lara_django_organisms_pb2.TraitRetrieveRequest(trait_id=trait_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving trait_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.trait_client.List(
                    lara_django_organisms_pb2.TraitListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving trait name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the trait_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].trait_id
        else:
            raise ValueError(f"Error retrieving trait_id - no or too many results found.")
    
    async def get_by_id(self, trait_id: str = None) -> organisms_dm.Trait:
        """ retrieve a trait data model by trait_id """
        try:
            res = await self.trait_client.Retrieve(
                lara_django_organisms_pb2.TraitRetrieveRequest(trait_id=trait_id)
            )
            return organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving trait_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Trait | str:
        """ retrieve a trait data model by name """
        try:
            res = await self.trait_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.TraitRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["trait_id"]
            else:
                return organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving trait name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all traits """
        if filter_dict is None:
            res = await self.trait_client.List(lara_django_organisms_pb2.TraitListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.trait_client.List(
                lara_django_organisms_pb2.TraitListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.trait_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all traits """
        if self.trait_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.trait_full_client.List(
                lara_django_organisms_pb2.TraitFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.trait_full_client.List(
                lara_django_organisms_pb2.TraitFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, trait : organisms_dm.Trait = None) -> None:
        """ update a trait model instance """
        try:
            res = await self.trait_client.Update(
                lara_django_organisms_pb2.TraitRequest(**trait.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating trait_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a trait by trait_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.trait_client.Destroy(lara_django_organisms_pb2.TraitDestroyRequest(trait_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting trait_id: {e}")

#_________________  Domain  ______________________


class DomainInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.domain_client = lara_django_organisms_pb2_grpc.DomainControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  domains:  list[organisms_dm.Domain] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Domain]]:
        try:
            create_coroutines = ( self.domain_client.Create(lara_django_organisms_pb2.DomainRequest(**domain.model_dump())) for domain in domains )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.domain_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating domain: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        domain_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Domain]:
        """ retrieve a list of domain instances by domain_id, name or filter_dict,
               returns a list of domain data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  domain_id is not None:
            try:
                res =  await self.domain_client.Retrieve(
                    lara_django_organisms_pb2.DomainRetrieveRequest(domain_id=domain_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving domain_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.domain_client.List(
                    lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving domain name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the domain_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].domain_id
        else:
            raise ValueError(f"Error retrieving domain_id - no or too many results found.")
    
    async def get_by_id(self, domain_id: str = None) -> organisms_dm.Domain:
        """ retrieve a domain data model by domain_id """
        try:
            res = await self.domain_client.Retrieve(
                lara_django_organisms_pb2.DomainRetrieveRequest(domain_id=domain_id)
            )
            return organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving domain_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Domain | str:
        """ retrieve a domain data model by name """
        try:
            res = await self.domain_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.DomainRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["domain_id"]
            else:
                return organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving domain name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all domains """
        if filter_dict is None:
            res = await self.domain_client.List(lara_django_organisms_pb2.DomainListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.domain_client.List(
                lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.domain_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all domains """
        if self.domain_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, domain : organisms_dm.Domain = None) -> None:
        """ update a domain model instance """
        try:
            res = await self.domain_client.Update(
                lara_django_organisms_pb2.DomainRequest(**domain.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating domain_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a domain by domain_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.domain_client.Destroy(lara_django_organisms_pb2.DomainDestroyRequest(domain_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting domain_id: {e}")

#_________________  Regnum  ______________________


class RegnumInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.regnum_client = lara_django_organisms_pb2_grpc.RegnumControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  regna:  list[organisms_dm.Regnum] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Regnum]]:
        try:
            create_coroutines = ( self.regnum_client.Create(lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump())) for regnum in regna )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.regnum_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating regnum: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        regnum_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Regnum]:
        """ retrieve a list of regnum instances by regnum_id, name or filter_dict,
               returns a list of regnum data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  regnum_id is not None:
            try:
                res =  await self.regnum_client.Retrieve(
                    lara_django_organisms_pb2.RegnumRetrieveRequest(regnum_id=regnum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving regnum_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.regnum_client.List(
                    lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving regnum name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the regnum_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].regnum_id
        else:
            raise ValueError(f"Error retrieving regnum_id - no or too many results found.")
    
    async def get_by_id(self, regnum_id: str = None) -> organisms_dm.Regnum:
        """ retrieve a regnum data model by regnum_id """
        try:
            res = await self.regnum_client.Retrieve(
                lara_django_organisms_pb2.RegnumRetrieveRequest(regnum_id=regnum_id)
            )
            return organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving regnum_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Regnum | str:
        """ retrieve a regnum data model by name """
        try:
            res = await self.regnum_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.RegnumRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["regnum_id"]
            else:
                return organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving regnum name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all regnums """
        if filter_dict is None:
            res = await self.regnum_client.List(lara_django_organisms_pb2.RegnumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.regnum_client.List(
                lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.regnum_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all regnums """
        if self.regnum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, regnum : organisms_dm.Regnum = None) -> None:
        """ update a regnum model instance """
        try:
            res = await self.regnum_client.Update(
                lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating regnum_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a regnum by regnum_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.regnum_client.Destroy(lara_django_organisms_pb2.RegnumDestroyRequest(regnum_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting regnum_id: {e}")

#_________________  Phylum  ______________________


class PhylumInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.phylum_client = lara_django_organisms_pb2_grpc.PhylumControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  phyla:  list[organisms_dm.Phylum] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Phylum]]:
        try:
            create_coroutines = ( self.phylum_client.Create(lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump())) for phylum in phyla )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.phylum_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating phylum: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        phylum_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Phylum]:
        """ retrieve a list of phylum instances by phylum_id, name or filter_dict,
               returns a list of phylum data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  phylum_id is not None:
            try:
                res =  await self.phylum_client.Retrieve(
                    lara_django_organisms_pb2.PhylumRetrieveRequest(phylum_id=phylum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving phylum_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.phylum_client.List(
                    lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving phylum name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the phylum_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].phylum_id
        else:
            raise ValueError(f"Error retrieving phylum_id - no or too many results found.")
    
    async def get_by_id(self, phylum_id: str = None) -> organisms_dm.Phylum:
        """ retrieve a phylum data model by phylum_id """
        try:
            res = await self.phylum_client.Retrieve(
                lara_django_organisms_pb2.PhylumRetrieveRequest(phylum_id=phylum_id)
            )
            return organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving phylum_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Phylum | str:
        """ retrieve a phylum data model by name """
        try:
            res = await self.phylum_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.PhylumRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["phylum_id"]
            else:
                return organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving phylum name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all phylums """
        if filter_dict is None:
            res = await self.phylum_client.List(lara_django_organisms_pb2.PhylumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.phylum_client.List(
                lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.phylum_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all phylums """
        if self.phylum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, phylum : organisms_dm.Phylum = None) -> None:
        """ update a phylum model instance """
        try:
            res = await self.phylum_client.Update(
                lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating phylum_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a phylum by phylum_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.phylum_client.Destroy(lara_django_organisms_pb2.PhylumDestroyRequest(phylum_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting phylum_id: {e}")

#_________________  Classis  ______________________


class ClassisInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.classis_client = lara_django_organisms_pb2_grpc.ClassisControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  classes:  list[organisms_dm.Classis] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Classis]]:
        try:
            create_coroutines = ( self.classis_client.Create(lara_django_organisms_pb2.ClassisRequest(**classis.model_dump())) for classis in classes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.classis_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating classis: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        classis_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Classis]:
        """ retrieve a list of classis instances by classis_id, name or filter_dict,
               returns a list of classis data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  classis_id is not None:
            try:
                res =  await self.classis_client.Retrieve(
                    lara_django_organisms_pb2.ClassisRetrieveRequest(classis_id=classis_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving classis_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.classis_client.List(
                    lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving classis name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the classis_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].classis_id
        else:
            raise ValueError(f"Error retrieving classis_id - no or too many results found.")
    
    async def get_by_id(self, classis_id: str = None) -> organisms_dm.Classis:
        """ retrieve a classis data model by classis_id """
        try:
            res = await self.classis_client.Retrieve(
                lara_django_organisms_pb2.ClassisRetrieveRequest(classis_id=classis_id)
            )
            return organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving classis_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Classis | str:
        """ retrieve a classis data model by name """
        try:
            res = await self.classis_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.ClassisRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["classis_id"]
            else:
                return organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving classis name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all classiss """
        if filter_dict is None:
            res = await self.classis_client.List(lara_django_organisms_pb2.ClassisListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.classis_client.List(
                lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.classis_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all classiss """
        if self.classis_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, classis : organisms_dm.Classis = None) -> None:
        """ update a classis model instance """
        try:
            res = await self.classis_client.Update(
                lara_django_organisms_pb2.ClassisRequest(**classis.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating classis_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a classis by classis_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.classis_client.Destroy(lara_django_organisms_pb2.ClassisDestroyRequest(classis_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting classis_id: {e}")

#_________________  Ordo  ______________________


class OrdoInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.ordo_client = lara_django_organisms_pb2_grpc.OrdoControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  ordae:  list[organisms_dm.Ordo] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Ordo]]:
        try:
            create_coroutines = ( self.ordo_client.Create(lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump())) for ordo in ordae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.ordo_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating ordo: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        ordo_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Ordo]:
        """ retrieve a list of ordo instances by ordo_id, name or filter_dict,
               returns a list of ordo data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  ordo_id is not None:
            try:
                res =  await self.ordo_client.Retrieve(
                    lara_django_organisms_pb2.OrdoRetrieveRequest(ordo_id=ordo_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving ordo_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.ordo_client.List(
                    lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving ordo name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the ordo_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].ordo_id
        else:
            raise ValueError(f"Error retrieving ordo_id - no or too many results found.")
    
    async def get_by_id(self, ordo_id: str = None) -> organisms_dm.Ordo:
        """ retrieve a ordo data model by ordo_id """
        try:
            res = await self.ordo_client.Retrieve(
                lara_django_organisms_pb2.OrdoRetrieveRequest(ordo_id=ordo_id)
            )
            return organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving ordo_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Ordo | str:
        """ retrieve a ordo data model by name """
        try:
            res = await self.ordo_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.OrdoRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["ordo_id"]
            else:
                return organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving ordo name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all ordos """
        if filter_dict is None:
            res = await self.ordo_client.List(lara_django_organisms_pb2.OrdoListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.ordo_client.List(
                lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.ordo_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all ordos """
        if self.ordo_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, ordo : organisms_dm.Ordo = None) -> None:
        """ update a ordo model instance """
        try:
            res = await self.ordo_client.Update(
                lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating ordo_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a ordo by ordo_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.ordo_client.Destroy(lara_django_organisms_pb2.OrdoDestroyRequest(ordo_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting ordo_id: {e}")

#_________________  Familia  ______________________


class FamiliaInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.familia_client = lara_django_organisms_pb2_grpc.FamiliaControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  familiae:  list[organisms_dm.Familia] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Familia]]:
        try:
            create_coroutines = ( self.familia_client.Create(lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump())) for familia in familiae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.familia_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating familia: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        familia_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Familia]:
        """ retrieve a list of familia instances by familia_id, name or filter_dict,
               returns a list of familia data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  familia_id is not None:
            try:
                res =  await self.familia_client.Retrieve(
                    lara_django_organisms_pb2.FamiliaRetrieveRequest(familia_id=familia_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving familia_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.familia_client.List(
                    lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving familia name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the familia_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].familia_id
        else:
            raise ValueError(f"Error retrieving familia_id - no or too many results found.")
    
    async def get_by_id(self, familia_id: str = None) -> organisms_dm.Familia:
        """ retrieve a familia data model by familia_id """
        try:
            res = await self.familia_client.Retrieve(
                lara_django_organisms_pb2.FamiliaRetrieveRequest(familia_id=familia_id)
            )
            return organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving familia_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Familia | str:
        """ retrieve a familia data model by name """
        try:
            res = await self.familia_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.FamiliaRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["familia_id"]
            else:
                return organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving familia name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all familias """
        if filter_dict is None:
            res = await self.familia_client.List(lara_django_organisms_pb2.FamiliaListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.familia_client.List(
                lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.familia_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all familias """
        if self.familia_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, familia : organisms_dm.Familia = None) -> None:
        """ update a familia model instance """
        try:
            res = await self.familia_client.Update(
                lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating familia_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a familia by familia_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.familia_client.Destroy(lara_django_organisms_pb2.FamiliaDestroyRequest(familia_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting familia_id: {e}")

#_________________  Genus  ______________________


class GenusInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.genus_client = lara_django_organisms_pb2_grpc.GenusControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  genera:  list[organisms_dm.Genus] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Genus]]:
        try:
            create_coroutines = ( self.genus_client.Create(lara_django_organisms_pb2.GenusRequest(**genus.model_dump())) for genus in genera )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.genus_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating genus: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        genus_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Genus]:
        """ retrieve a list of genus instances by genus_id, name or filter_dict,
               returns a list of genus data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  genus_id is not None:
            try:
                res =  await self.genus_client.Retrieve(
                    lara_django_organisms_pb2.GenusRetrieveRequest(genus_id=genus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving genus_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.genus_client.List(
                    lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving genus name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the genus_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].genus_id
        else:
            raise ValueError(f"Error retrieving genus_id - no or too many results found.")
    
    async def get_by_id(self, genus_id: str = None) -> organisms_dm.Genus:
        """ retrieve a genus data model by genus_id """
        try:
            res = await self.genus_client.Retrieve(
                lara_django_organisms_pb2.GenusRetrieveRequest(genus_id=genus_id)
            )
            return organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving genus_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Genus | str:
        """ retrieve a genus data model by name """
        try:
            res = await self.genus_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.GenusRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["genus_id"]
            else:
                return organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving genus name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all genuss """
        if filter_dict is None:
            res = await self.genus_client.List(lara_django_organisms_pb2.GenusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.genus_client.List(
                lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.genus_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all genuss """
        if self.genus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, genus : organisms_dm.Genus = None) -> None:
        """ update a genus model instance """
        try:
            res = await self.genus_client.Update(
                lara_django_organisms_pb2.GenusRequest(**genus.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating genus_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a genus by genus_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.genus_client.Destroy(lara_django_organisms_pb2.GenusDestroyRequest(genus_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting genus_id: {e}")

#_________________  Species  ______________________


class SpeciesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.species_client = lara_django_organisms_pb2_grpc.SpeciesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  speciae:  list[organisms_dm.Species] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Species]]:
        try:
            create_coroutines = ( self.species_client.Create(lara_django_organisms_pb2.SpeciesRequest(**species.model_dump())) for species in speciae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.species_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating species: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        species_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Species]:
        """ retrieve a list of species instances by species_id, name or filter_dict,
               returns a list of species data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  species_id is not None:
            try:
                res =  await self.species_client.Retrieve(
                    lara_django_organisms_pb2.SpeciesRetrieveRequest(species_id=species_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving species_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.species_client.List(
                    lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving species name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the species_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].species_id
        else:
            raise ValueError(f"Error retrieving species_id - no or too many results found.")
    
    async def get_by_id(self, species_id: str = None) -> organisms_dm.Species:
        """ retrieve a species data model by species_id """
        try:
            res = await self.species_client.Retrieve(
                lara_django_organisms_pb2.SpeciesRetrieveRequest(species_id=species_id)
            )
            return organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving species_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Species | str:
        """ retrieve a species data model by name """
        try:
            res = await self.species_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.SpeciesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["species_id"]
            else:
                return organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving species name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all speciess """
        if filter_dict is None:
            res = await self.species_client.List(lara_django_organisms_pb2.SpeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.species_client.List(
                lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.species_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all speciess """
        if self.species_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, species : organisms_dm.Species = None) -> None:
        """ update a species model instance """
        try:
            res = await self.species_client.Update(
                lara_django_organisms_pb2.SpeciesRequest(**species.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating species_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a species by species_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.species_client.Destroy(lara_django_organisms_pb2.SpeciesDestroyRequest(species_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting species_id: {e}")

#_________________  Subspecies  ______________________


class SubspeciesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.subspecies_client = lara_django_organisms_pb2_grpc.SubspeciesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  subspecieae:  list[organisms_dm.Subspecies] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Subspecies]]:
        try:
            create_coroutines = ( self.subspecies_client.Create(lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump())) for subspecies in subspecieae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.subspecies_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating subspecies: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        subspecies_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Subspecies]:
        """ retrieve a list of subspecies instances by subspecies_id, name or filter_dict,
               returns a list of subspecies data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  subspecies_id is not None:
            try:
                res =  await self.subspecies_client.Retrieve(
                    lara_django_organisms_pb2.SubspeciesRetrieveRequest(subspecies_id=subspecies_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving subspecies_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.subspecies_client.List(
                    lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving subspecies name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the subspecies_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].subspecies_id
        else:
            raise ValueError(f"Error retrieving subspecies_id - no or too many results found.")
    
    async def get_by_id(self, subspecies_id: str = None) -> organisms_dm.Subspecies:
        """ retrieve a subspecies data model by subspecies_id """
        try:
            res = await self.subspecies_client.Retrieve(
                lara_django_organisms_pb2.SubspeciesRetrieveRequest(subspecies_id=subspecies_id)
            )
            return organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subspecies_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Subspecies | str:
        """ retrieve a subspecies data model by name """
        try:
            res = await self.subspecies_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.SubspeciesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["subspecies_id"]
            else:
                return organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subspecies name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all subspeciess """
        if filter_dict is None:
            res = await self.subspecies_client.List(lara_django_organisms_pb2.SubspeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.subspecies_client.List(
                lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subspecies_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all subspeciess """
        if self.subspecies_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, subspecies : organisms_dm.Subspecies = None) -> None:
        """ update a subspecies model instance """
        try:
            res = await self.subspecies_client.Update(
                lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating subspecies_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a subspecies by subspecies_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.subspecies_client.Destroy(lara_django_organisms_pb2.SubspeciesDestroyRequest(subspecies_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting subspecies_id: {e}")

#_________________  Variant  ______________________


class VariantInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.variant_client = lara_django_organisms_pb2_grpc.VariantControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  variants:  list[organisms_dm.Variant] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Variant]]:
        try:
            create_coroutines = ( self.variant_client.Create(lara_django_organisms_pb2.VariantRequest(**variant.model_dump())) for variant in variants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.variant_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating variant: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        variant_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Variant]:
        """ retrieve a list of variant instances by variant_id, name or filter_dict,
               returns a list of variant data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  variant_id is not None:
            try:
                res =  await self.variant_client.Retrieve(
                    lara_django_organisms_pb2.VariantRetrieveRequest(variant_id=variant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving variant_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.variant_client.List(
                    lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving variant name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the variant_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].variant_id
        else:
            raise ValueError(f"Error retrieving variant_id - no or too many results found.")
    
    async def get_by_id(self, variant_id: str = None) -> organisms_dm.Variant:
        """ retrieve a variant data model by variant_id """
        try:
            res = await self.variant_client.Retrieve(
                lara_django_organisms_pb2.VariantRetrieveRequest(variant_id=variant_id)
            )
            return organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving variant_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Variant | str:
        """ retrieve a variant data model by name """
        try:
            res = await self.variant_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.VariantRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["variant_id"]
            else:
                return organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving variant name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all variants """
        if filter_dict is None:
            res = await self.variant_client.List(lara_django_organisms_pb2.VariantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.variant_client.List(
                lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.variant_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all variants """
        if self.variant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, variant : organisms_dm.Variant = None) -> None:
        """ update a variant model instance """
        try:
            res = await self.variant_client.Update(
                lara_django_organisms_pb2.VariantRequest(**variant.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating variant_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a variant by variant_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.variant_client.Destroy(lara_django_organisms_pb2.VariantDestroyRequest(variant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting variant_id: {e}")

#_________________  Cultivar  ______________________


class CultivarInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.cultivar_client = lara_django_organisms_pb2_grpc.CultivarControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  cultivars:  list[organisms_dm.Cultivar] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Cultivar]]:
        try:
            create_coroutines = ( self.cultivar_client.Create(lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump())) for cultivar in cultivars )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.cultivar_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating cultivar: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        cultivar_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Cultivar]:
        """ retrieve a list of cultivar instances by cultivar_id, name or filter_dict,
               returns a list of cultivar data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  cultivar_id is not None:
            try:
                res =  await self.cultivar_client.Retrieve(
                    lara_django_organisms_pb2.CultivarRetrieveRequest(cultivar_id=cultivar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving cultivar_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.cultivar_client.List(
                    lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving cultivar name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the cultivar_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].cultivar_id
        else:
            raise ValueError(f"Error retrieving cultivar_id - no or too many results found.")
    
    async def get_by_id(self, cultivar_id: str = None) -> organisms_dm.Cultivar:
        """ retrieve a cultivar data model by cultivar_id """
        try:
            res = await self.cultivar_client.Retrieve(
                lara_django_organisms_pb2.CultivarRetrieveRequest(cultivar_id=cultivar_id)
            )
            return organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving cultivar_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Cultivar | str:
        """ retrieve a cultivar data model by name """
        try:
            res = await self.cultivar_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.CultivarRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["cultivar_id"]
            else:
                return organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving cultivar name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all cultivars """
        if filter_dict is None:
            res = await self.cultivar_client.List(lara_django_organisms_pb2.CultivarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.cultivar_client.List(
                lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.cultivar_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all cultivars """
        if self.cultivar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, cultivar : organisms_dm.Cultivar = None) -> None:
        """ update a cultivar model instance """
        try:
            res = await self.cultivar_client.Update(
                lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating cultivar_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a cultivar by cultivar_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.cultivar_client.Destroy(lara_django_organisms_pb2.CultivarDestroyRequest(cultivar_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting cultivar_id: {e}")

#_________________  Organism  ______________________


class OrganismInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.organism_client = lara_django_organisms_pb2_grpc.OrganismControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  organisms:  list[organisms_dm.Organism] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.Organism]]:
        try:
            create_coroutines = ( self.organism_client.Create(lara_django_organisms_pb2.OrganismRequest(**organism.model_dump())) for organism in organisms )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organism_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organism: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        organism_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Organism]:
        """ retrieve a list of organism instances by organism_id, name or filter_dict,
               returns a list of organism data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  organism_id is not None:
            try:
                res =  await self.organism_client.Retrieve(
                    lara_django_organisms_pb2.OrganismRetrieveRequest(organism_id=organism_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organism_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organism_client.List(
                    lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organism name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organism_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].organism_id
        else:
            raise ValueError(f"Error retrieving organism_id - no or too many results found.")
    
    async def get_by_id(self, organism_id: str = None) -> organisms_dm.Organism:
        """ retrieve a organism data model by organism_id """
        try:
            res = await self.organism_client.Retrieve(
                lara_django_organisms_pb2.OrganismRetrieveRequest(organism_id=organism_id)
            )
            return organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organism_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.Organism | str:
        """ retrieve a organism data model by name """
        try:
            res = await self.organism_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.OrganismRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["organism_id"]
            else:
                return organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organism name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organisms """
        if filter_dict is None:
            res = await self.organism_client.List(lara_django_organisms_pb2.OrganismListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organism_client.List(
                lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organism_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organisms """
        if self.organism_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organism : organisms_dm.Organism = None) -> None:
        """ update a organism model instance """
        try:
            res = await self.organism_client.Update(
                lara_django_organisms_pb2.OrganismRequest(**organism.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organism_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organism by organism_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organism_client.Destroy(lara_django_organisms_pb2.OrganismDestroyRequest(organism_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organism_id: {e}")

#_________________  OrganismsSubset  ______________________


class OrganismsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organismssubset_class_client = (
        #     lara_django_organisms_pb2_grpc.OrganismsSubsetclassByIRIControllerStub(channel)
        # )

        self.organismssubset_client = lara_django_organisms_pb2_grpc.OrganismsSubsetControllerStub(channel)
        

        # self.organismssubset_full_client = lara_django_organisms_pb2_grpc.OrganismsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organismssubsets:  list[organisms_dm.OrganismsSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_dm.OrganismsSubset]]:
        """ create a list of organismssubset instances,
               returns a list of organismssubset data model objects or ids_only

        :param organismssubsets: list of organismssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismssubset data model objects or ids_only
        """
        organismssubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismssubset_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrganismsSubsetclassRetrieveRequest(iri=organismssubset_class_iri)
        #     )
        #     organismssubsetclass_id = res.organismssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismssubsetclass_id: {e}")
        for organismssubset in organismssubsets:
            if organismssubset.namespace == "" or organismssubset.namespace == "default":
                    organismssubset.namespace = namespace_id
            # organismssubset.organismssubset_class = organismssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismssubset_client.Create(lara_django_organisms_pb2.OrganismsSubsetRequest(**organismssubset.model_dump())) for organismssubset in organismssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organismssubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.OrganismsSubset]:
        """ retrieve a list of organismssubset instances by organismssubset_id, name or filter_dict,
               returns a list of organismssubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organismssubset_id is not None:
            try:
                res =  await self.organismssubset_client.Retrieve(
                    lara_django_organisms_pb2.OrganismsSubsetRetrieveRequest(organismssubset_id=organismssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.OrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismssubset_client.List(
                    lara_django_organisms_pb2.OrganismsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.OrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismssubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organismssubset_id
        else:
            raise ValueError(f"Error retrieving organismssubset_id - no or too many results found.")
    
    async def get_by_id(self, organismssubset_id: str = None, id_only: bool = False) -> organisms_dm.OrganismsSubset:
        """ retrieve a organismssubset data model by organismssubset_id """
        try:
            res = await self.organismssubset_client.Retrieve(
                lara_django_organisms_pb2.OrganismsSubsetRetrieveRequest(organismssubset_id=organismssubset_id)
            )
            item = organisms_dm.OrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organismssubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organismssubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_dm.OrganismsSubset | str:
        """ retrieve a organismssubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismssubset_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.OrganismsSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organismssubset_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_dm.OrganismsSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving organismssubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismssubsets """
        if filter_dict is None:
            res = await self.organismssubset_client.List(lara_django_organisms_pb2.OrganismsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismssubset_client.List(
                lara_django_organisms_pb2.OrganismsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismssubsets """
        if self.organismssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismssubset_full_client.List(
                lara_django_organisms_pb2.OrganismsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismssubset_full_client.List(
                lara_django_organisms_pb2.OrganismsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismssubset : organisms_dm.OrganismsSubset = None) -> None:
        """ update a organismssubset model instance """
        try:
            res = await self.organismssubset_client.Update(
                lara_django_organisms_pb2.OrganismsSubsetRequest(**organismssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismssubset by organismssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismssubset_client.Destroy(lara_django_organisms_pb2.OrganismsSubsetDestroyRequest(organismssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismssubset_id: {e}")

#_________________  OrderedOrganismsOrganismsSubset  ______________________


class OrderedOrganismsOrganismsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedorganismsorganismssubset_client = lara_django_organisms_pb2_grpc.OrderedOrganismsOrganismsSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedorganismsorganismssubsets:  list[organisms_dm.OrderedOrganismsOrganismsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_dm.OrderedOrganismsOrganismsSubset]]:
        try:
            create_coroutines = ( self.orderedorganismsorganismssubset_client.Create(lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetRequest(**orderedorganismsorganismssubset.model_dump())) for orderedorganismsorganismssubset in orderedorganismsorganismssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedorganismsorganismssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedorganismsorganismssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedorganismsorganismssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.OrderedOrganismsOrganismsSubset]:
        """ retrieve a list of orderedorganismsorganismssubset instances by orderedorganismsorganismssubset_id, name or filter_dict,
               returns a list of orderedorganismsorganismssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedorganismsorganismssubset_id is not None:
            try:
                res =  await self.orderedorganismsorganismssubset_client.Retrieve(
                    lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetRetrieveRequest(orderedorganismsorganismssubset_id=orderedorganismsorganismssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.OrderedOrganismsOrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedorganismsorganismssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedorganismsorganismssubset_client.List(
                    lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_dm.OrderedOrganismsOrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsorganismssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedorganismsorganismssubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedorganismsorganismssubset_id
        else:
            raise ValueError(f"Error retrieving orderedorganismsorganismssubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedorganismsorganismssubset_id: str = None) -> organisms_dm.OrderedOrganismsOrganismsSubset:
        """ retrieve a orderedorganismsorganismssubset data model by orderedorganismsorganismssubset_id """
        try:
            res = await self.orderedorganismsorganismssubset_client.Retrieve(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetRetrieveRequest(orderedorganismsorganismssubset_id=orderedorganismsorganismssubset_id)
            )
            return organisms_dm.OrderedOrganismsOrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsorganismssubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_dm.OrderedOrganismsOrganismsSubset | str:
        """ retrieve a orderedorganismsorganismssubset data model by name """
        try:
            res = await self.orderedorganismsorganismssubset_client.RetrieveByNameNamespace(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedorganismsorganismssubset_id"]
            else:
                return organisms_dm.OrderedOrganismsOrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsorganismssubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedorganismsorganismssubsets """
        if filter_dict is None:
            res = await self.orderedorganismsorganismssubset_client.List(lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedorganismsorganismssubset_client.List(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedorganismsorganismssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedorganismsorganismssubsets """
        if self.orderedorganismsorganismssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedorganismsorganismssubset_full_client.List(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedorganismsorganismssubset_full_client.List(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedorganismsorganismssubset : organisms_dm.OrderedOrganismsOrganismsSubset = None) -> None:
        """ update a orderedorganismsorganismssubset model instance """
        try:
            res = await self.orderedorganismsorganismssubset_client.Update(
                lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetRequest(**orderedorganismsorganismssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedorganismsorganismssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedorganismsorganismssubset by orderedorganismsorganismssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedorganismsorganismssubset_client.Destroy(lara_django_organisms_pb2.OrderedOrganismsOrganismsSubsetDestroyRequest(orderedorganismsorganismssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedorganismsorganismssubset_id: {e}")

