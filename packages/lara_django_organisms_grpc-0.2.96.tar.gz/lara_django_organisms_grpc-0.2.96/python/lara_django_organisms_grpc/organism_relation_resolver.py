"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django material relation resolver *

:details: The relation resolver is used to resolve foreign keys, e.g. by name or IRI instead of an id.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import logging
import grpc
from typing import Any, Union, List, Dict, Tuple, Optional

from lara_django_base_grpc.relation_resolver_interface import (
    RetrMethod,
    RelationResolverBase,
)

# from lara_django_base_grpc.lara_django_base_interface import AddressInterface
# from lara_django_people_grpc.lara_django_people_interface import EntityInterface, EntityRoleInterface, EntityClassInterface
from lara_django_organisms_grpc.lara_django_organisms_interface import (
    RegnumInterface, PhylumInterface, ClassisInterface, OrdoInterface, FamiliaInterface, GenusInterface, SpeciesInterface, SubspeciesInterface, VariantInterface, CultivarInterface, OrganismInterface, OrganismsSubsetInterface, HabitatInterface, HabitatParameterInterface, HabitatClassInterface, TraitInterface, DomainInterface
)

logger = logging.getLogger(__name__)


class OrganismRelationResolver(RelationResolverBase):
    """Relation Resolver for LARA part models"""

    def __init__(self, channel: grpc.Channel = None):
        try:
            self.regnum_if = RegnumInterface(channel=channel)
            self.phylum_if = PhylumInterface(channel=channel)
            self.classis_if = ClassisInterface(channel=channel)
            self.ordo_if = OrdoInterface(channel=channel)
            self.familia_if = FamiliaInterface(channel=channel)
            self.genus_if = GenusInterface(channel=channel)
            self.species_if = SpeciesInterface(channel=channel)
            self.subspecies_if = SubspeciesInterface(channel=channel)
            self.variant_if = VariantInterface(channel=channel)
            self.cultivar_if = CultivarInterface(channel=channel)
            self.organism_if = OrganismInterface(channel=channel)
        except Exception as e:
            logger.error(f"Error creating interfaces: {e}")

        self.relation_finder_dict = {
            "regnum": [
                RetrMethod(
                    method=self.regnum_if.retrieve_id,
                    params={"name": "regnum"},
                ),
                RetrMethod(
                    method=self.regnum_if.retrieve_id,
                    params={"name_display": "regnum"},
                ), 
            ],
            "phylum": [
                RetrMethod(
                    method=self.phylum_if.retrieve_id,
                    params={"name": "phylum"},
                ),
                RetrMethod(
                    method=self.phylum_if.retrieve_id,
                    params={"name_display": "phylum"},
                ), 
            ],
            "classis": [
                RetrMethod(
                    method=self.classis_if.retrieve_id,
                    params={"name": "classis"},
                ),
                RetrMethod(
                    method=self.classis_if.retrieve_id,
                    params={"name_display": "classis"},
                ), 
            ],
            "ordo": [
                RetrMethod(
                    method=self.ordo_if.retrieve_id,
                    params={"name": "ordo"},
                ),
                RetrMethod(
                    method=self.ordo_if.retrieve_id,
                    params={"name_display": "ordo"},
                ), 
                RetrMethod(
                    method=self.ordo_if.retrieve_id,
                    params={"name_common": "ordo"},
                ),
            ],
            "familia": [
                RetrMethod(
                    method=self.familia_if.retrieve_id,
                    params={"name": "familia"},
                ),
                RetrMethod(
                    method=self.familia_if.retrieve_id,
                    params={"name_display": "familia"},
                ), 
                RetrMethod(
                    method=self.familia_if.retrieve_id,
                    params={"name_common": "familia"},
                ),
            ],
            "genus": [
                RetrMethod(
                    method=self.genus_if.retrieve_id,
                    params={"name": "genus"},
                ),
                RetrMethod(
                    method=self.genus_if.retrieve_id,
                    params={"name_display": "genus"},
                ), 
                RetrMethod(
                    method=self.genus_if.retrieve_id,
                    params={"name_common": "genus"},
                ),
            ],
            "species": [
                RetrMethod(
                    method=self.species_if.retrieve_id,
                    params={"name": "species"},
                ),
                RetrMethod(
                    method=self.species_if.retrieve_id,
                    params={"name_display": "species"},
                ), 
                RetrMethod(
                    method=self.species_if.retrieve_id,
                    params={"name_common": "species"},
                ),
            ],
            "subspecies": [
                RetrMethod(
                    method=self.subspecies_if.retrieve_id,
                    params={"name": "subspecies"},
                ),
                RetrMethod(
                    method=self.subspecies_if.retrieve_id,
                    params={"name_display": "subspecies"},
                ), 
                RetrMethod(
                    method=self.subspecies_if.retrieve_id,
                    params={"name_common": "subspecies"},
                ),
            ],
            "variant": [
                RetrMethod(
                    method=self.variant_if.retrieve_id,
                    params={"name": "variant"},
                ),
                RetrMethod(
                    method=self.variant_if.retrieve_id,
                    params={"name_display": "variant"},
                ), 
                RetrMethod(
                    method=self.variant_if.retrieve_id,
                    params={"name_common": "variant"},
                ),
            ],
            "cultivar": [
                RetrMethod(
                    method=self.cultivar_if.retrieve_id,
                    params={"name": "cultivar"},
                ),
                RetrMethod(
                    method=self.cultivar_if.retrieve_id,
                    params={"name_display": "cultivar"},
                ), 
                RetrMethod(
                    method=self.cultivar_if.retrieve_id,
                    params={"name_common": "cultivar"},
                ),
            ],
        }
