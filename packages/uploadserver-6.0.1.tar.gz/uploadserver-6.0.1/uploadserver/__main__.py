import uploadserver

if __name__ == '__main__':
    uploadserver.main()
