"""
HTTP Push Worker Entrypoint.

Receives task execution callbacks from Managed Scheduler via HTTP POST.
Deserializes the task payload, resolves the function, and executes it
within an IntegrationContext for observability.
"""
import importlib
import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from beamflow_lib.context import integration_context, current_context
from beamflow_lib.observability.ingestion import (
    record_run_started,
    record_run_ended,
)
from beamflow_lib.queue.backend import get_backend

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/schedules")
async def get_schedules():
    """
    Return all scheduled tasks registered in the active backend.
    
    Used by the Platform API deployment flow to discover schedules
    via a pull model instead of an INIT job push model.
    """
    backend = get_backend()
    
    # We expect ManagedTasksBackend to populate _registered_tasks
    if hasattr(backend, "_registered_tasks"):
        return {"tasks": backend._registered_tasks}
    
    return {"tasks": []}


# ─── Request Model ───────────────────────────────────────────────────


class TaskPayload(BaseModel):
    """Payload pushed by Managed Scheduler."""
    task_id: Optional[str] = None
    task_name: str
    func_ref: Optional[str] = None  # e.g. "my_module.my_function"
    args: list = []
    kwargs: dict = {}
    integration: Optional[str] = None
    pipeline: Optional[str] = None
    triggered_by: Optional[str] = None
    cron: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


# ─── Function Registry ───────────────────────────────────────────────


_task_registry: Dict[str, Any] = {}


def register_task(task_id: str, func: Any) -> None:
    """
    Register a callable task by its ID.

    Called during worker startup to build the function lookup table.
    """
    _task_registry[task_id] = func
    logger.info(f"Registered task handler: {task_id}")


def get_task_registry() -> Dict[str, Any]:
    """Return the current task registry."""
    return _task_registry


def _resolve_function(func_ref: str) -> Any:
    """
    Resolve a function reference like 'module.path.function_name' to a callable.

    First checks the local registry, then falls back to dynamic import.
    """
    # Check registry first
    if func_ref in _task_registry:
        return _task_registry[func_ref]

    # Dynamic import fallback
    parts = func_ref.rsplit(".", 1)
    if len(parts) != 2:
        raise ValueError(f"Invalid function reference: {func_ref}")

    module_path, func_name = parts
    try:
        module = importlib.import_module(module_path)
        func = getattr(module, func_name)
        return func
    except (ImportError, AttributeError) as e:
        raise ValueError(f"Cannot resolve function '{func_ref}': {e}")


# ─── Handler Endpoint ────────────────────────────────────────────────


@router.post("/handle_task")
async def handle_task(request: Request):
    """
    Receive and execute a task triggered in managed mode.

    This endpoint:
    1. Parses the task payload from the request body.
    2. Resolves the function reference to a callable.
    3. Executes it within an IntegrationContext for observability.
    4. Returns success/failure status.

    Managed Scheduler will retry on 5xx responses.
    """
    try:
        body = await request.json()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid JSON body: {e}",
        )

    # Support both flat and nested payload formats
    # Flat: Managed Scheduler trigger endpoint sends task metadata directly
    # Nested: ManagedTasksBackend wraps function call info in "payload"
    if "payload" in body and isinstance(body["payload"], dict):
        inner = body["payload"]
        func_ref = inner.get("func_ref") or body.get("task_name", "")
        args = inner.get("args", [])
        kwargs = inner.get("kwargs", {})
        ctx_data = inner.get("context", {})
    else:
        func_ref = body.get("func_ref") or body.get("task_name", "")
        args = body.get("args", [])
        kwargs = body.get("kwargs", {})
        ctx_data = body.get("context", {})

    if not func_ref:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing 'func_ref' or 'task_name' in payload",
        )

    # Resolve function
    try:
        func = _resolve_function(func_ref)
    except ValueError as e:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"status": "TASK_NOT_FOUND", "detail": str(e)},
        )

    # Execute within integration context
    integration = ctx_data.get("integration") or body.get("integration", "unknown")
    pipeline = ctx_data.get("pipeline") or body.get("pipeline", "unknown")
    run_id = ctx_data.get("run_id")
    tags = ctx_data.get("tags", {})
    
    # Add trigger metadata
    if body.get("triggered_by"):
        tags["triggered_by"] = body["triggered_by"]
    if body.get("cron"):
        tags["cron"] = body["cron"]

    status_result = "SUCCEEDED"
    error = None

    with integration_context(
        integration=integration,
        integration_pipeline=pipeline,
        run_id=run_id,
        tags=tags,
    ) as ctx:
        await record_run_started(correlation=ctx.corelation)

        try:
            # Handle both TaskWrapper.run() and plain callables
            if hasattr(func, "run"):
                result = await func.run(*args, **kwargs)
            elif hasattr(func, "func"):
                # TaskWrapper — call the underlying func
                import asyncio
                import inspect
                underlying = func.func
                if inspect.iscoroutinefunction(underlying):
                    result = await underlying(*args, **kwargs)
                else:
                    result = underlying(*args, **kwargs)
            else:
                import asyncio
                import inspect
                if inspect.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)

        except Exception as e:
            status_result = "FAILED"
            error = str(e)
            logger.error(f"Task execution failed: {func_ref}: {e}", exc_info=True)
            await record_run_ended(
                status=status_result,
                correlation=ctx.corelation,
            )
            # Return 500 so Managed Scheduler will retry
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Task execution failed: {e}",
            )

        await record_run_ended(
            status=status_result,
            correlation=ctx.corelation,
        )

    return {
        "status": "ok",
        "task": func_ref,
    }
