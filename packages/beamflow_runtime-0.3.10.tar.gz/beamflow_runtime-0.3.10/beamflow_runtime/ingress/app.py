"""
FastAPI application factory for webhook ingress.

Provides a convenience function to create a fully configured FastAPI app.
"""
from fastapi import FastAPI
from beamflow_lib.config.runtime_config import RuntimeConfig
from .router import build_webhook_router
from ..wiring.runtime import initialize_runtime


from typing import List, Union, Optional
from pathlib import Path

def create_fastapi_app(
    config: RuntimeConfig, 
    auto_import: Optional[List[Union[str, Path]]] = None
) -> FastAPI:
    """
    Create FastAPI app with webhook routes.
    
    Usage in ingress service:
        from beamflow_runtime.ingress.app import create_fastapi_app
        from beamflow_lib.config.loader import load_runtime_config
        
        config = load_runtime_config("/path/to/config")
        app = create_fastapi_app(config)
    
    Args:
        config: RuntimeConfig with webhooks configuration
        auto_import: List of paths to auto-import modules from
        
    Returns:
        FastAPI application with webhook routes included
    """
    # Build runtime (imports modules, sets up backend)
    rt = initialize_runtime(config, auto_import=auto_import)
    
    # Create app
    app = FastAPI(title="Ingress API")
    
    # Include webhook router with configured prefix
    app.include_router(build_webhook_router(), prefix=config.webhooks.prefix)
    
    # Store runtime reference on app for access in middleware/dependencies if needed
    app.state.runtime = rt
    
    import logging
    import sys
    app_logger = logging.getLogger(__name__)
    app_logger.setLevel(logging.INFO)
    if not app_logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter('INFO:     %(message)s'))
        app_logger.addHandler(handler)

    # Include auto-imported routers
    if hasattr(rt, 'imported_modules'):
        for mod in rt.imported_modules:
            if hasattr(mod, "router"):
                app.include_router(mod.router)
                mod_file = getattr(mod, "__file__", mod.__name__)
                app_logger.info(f"router automimpoted from [{mod_file}]")
                
    app_logger.info("Registered paths:")
    for route in app.routes:
        methods = getattr(route, "methods", None)
        path = getattr(route, "path", None)
        name = getattr(route, "name", getattr(route, "endpoint", "").__name__ if hasattr(route, "endpoint") else "")
        if path:
            methods_str = ",".join(methods) if methods else "ANY"
            app_logger.info(f"- {methods_str} {path} [{name}]")
    
    return app
