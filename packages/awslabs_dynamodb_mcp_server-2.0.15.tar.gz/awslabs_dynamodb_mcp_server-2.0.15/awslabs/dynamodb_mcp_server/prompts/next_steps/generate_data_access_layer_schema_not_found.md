Error: schema.json not found at {schema_path}. Call `dynamodb_data_model_schema_converter` first.
