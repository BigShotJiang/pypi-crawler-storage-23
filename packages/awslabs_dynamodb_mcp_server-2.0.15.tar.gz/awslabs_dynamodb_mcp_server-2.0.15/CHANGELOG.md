# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.4] - 2025-11-21

### Added

- **DynamoDB Command Execution:** Added `execute_dynamodb_command` tool that integrates with [AWS API MCP Server](https://github.com/awslabs/mcp/tree/main/src/aws-api-mcp-server) to execute DynamoDB operations directly without requiring separate AWS API MCP Server configuration.

## [2.0.0] - 2025-09-11

### Removed

- **BREAKING CHANGE:** DynamoDB Native API functions have been removed in favour of the [AWS API MCP Server](https://github.com/awslabs/mcp/tree/main/src/aws-api-mcp-server).

- The following functionality has been removed:
  - Table Operations
  - Item Operations
  - Query and Scan Operations
  - Backup and Recovery Operations
  - Time to Live Operations
  - Export Operations
  - Tags and Resource Policies Operations
  - Miscellaneous Operations (describe endpoints and describe limits)

- **Migration:** Use the AWS API MCP Server to perform these operations going forward.

## [1.0.0] - 2025-05-26

### Removed

- **BREAKING CHANGE:** Server Sent Events (SSE) support has been removed in accordance with the Model Context Protocol specification's [backwards compatibility guidelines](https://modelcontextprotocol.io/specification/2025-03-26/basic/transports#backwards-compatibility)
- This change prepares for future support of [Streamable HTTP](https://modelcontextprotocol.io/specification/draft/basic/transports#streamable-http) transport

## Unreleased

### Added

- Initial project setup
