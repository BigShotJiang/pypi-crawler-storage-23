from __future__ import annotations

from pathlib import Path

import pytest

from omtx.dataframes import (
    OmDataFrame,
    load_binders_export_dataframe,
    load_nonbinders_export_dataframe,
)
from omtx.exceptions import OMTXError


def _write_polars_parquet(path: Path, rows: list[dict[str, object]]) -> None:
    pl = pytest.importorskip("polars")
    pl.DataFrame(rows).write_parquet(str(path))


def test_load_binders_export_dataframe_loads_full_pool_when_n_is_none(tmp_path: Path):
    binder_path = tmp_path / "binders_full.parquet"
    _write_polars_parquet(
        binder_path,
        [
            {"smiles": "CCO", "binding_score": 0.9},
            {"smiles": "CCN", "binding_score": 0.8},
            {"smiles": "CCC", "binding_score": 0.7},
        ],
    )

    export = {
        "binder_urls": [str(binder_path)],
        "non_binder_urls": [],
    }

    df = load_binders_export_dataframe(export, n=None)
    assert df.height == 3


def test_load_nonbinders_export_dataframe_sampling_is_seeded_and_deterministic(tmp_path: Path):
    non_binder_path = tmp_path / "nonbinders_seeded.parquet"
    _write_polars_parquet(
        non_binder_path,
        [
            {"idx": i, "smiles": f"SMI{i}"}
            for i in range(20)
        ],
    )

    export = {
        "binder_urls": [],
        "non_binder_urls": [str(non_binder_path)],
    }

    first = load_nonbinders_export_dataframe(export, n=7, sample_seed=123)
    second = load_nonbinders_export_dataframe(export, n=7, sample_seed=123)

    assert first.height == 7
    assert second.height == 7
    assert first.sort("idx").to_dicts() == second.sort("idx").to_dicts()


def test_load_nonbinders_export_dataframe_raises_when_n_exceeds_available(tmp_path: Path):
    non_binder_path = tmp_path / "nonbinders_small.parquet"
    _write_polars_parquet(
        non_binder_path,
        [
            {"smiles": "CO"},
            {"smiles": "CN"},
        ],
    )

    export = {
        "binder_urls": [],
        "non_binder_urls": [str(non_binder_path)],
    }

    with pytest.raises(
        OMTXError,
        match="Requested nonbinders n=3, but only 2 rows are available.",
    ):
        load_nonbinders_export_dataframe(export, n=3, sample_seed=42)


def test_show_resolves_binding_score_alias_to_om_score():
    pl = pytest.importorskip("polars")
    wrapped = OmDataFrame(
        pl.DataFrame(
            {
                "product": ["CCO", "CCN", "CCC"],
                "om_score": [0.2, 0.9, 0.5],
            }
        )
    )

    wrapped.show(top_n=2, sort_by="binding_score")
    assert wrapped.metadata.get("show_sorted_by") == "om_score"


def test_show_resolves_selectivity_alias_to_e_score_norm():
    pl = pytest.importorskip("polars")
    wrapped = OmDataFrame(
        pl.DataFrame(
            {
                "product": ["CCO", "CCN", "CCC"],
                "e_score_norm": [0.1, 0.8, 0.4],
            }
        )
    )

    wrapped.show(top_n=2, sort_by="selectivity_score")
    assert wrapped.metadata.get("show_sorted_by") == "e_score_norm"


def test_show_sort_by_unknown_column_raises():
    pl = pytest.importorskip("polars")
    wrapped = OmDataFrame(pl.DataFrame({"product": ["CCO", "CCN"]}))

    with pytest.raises(OMTXError, match="sort_by='binding_score' not found"):
        wrapped.show(top_n=2, sort_by="binding_score")
