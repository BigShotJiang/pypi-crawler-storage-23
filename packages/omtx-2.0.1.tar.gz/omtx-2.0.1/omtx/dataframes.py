"""Dataframe helpers for shard exports and visualization."""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional

from .exceptions import OMTXError


def _concat_frames(frame_lib: Any, frames: List[Any]) -> Any:
    concat = getattr(frame_lib, "concat", None)
    if not callable(concat):
        raise OMTXError("Dataframe library does not provide concat(...)")

    attempts = (
        {"how": "vertical_relaxed", "rechunk": True},
        {"how": "diagonal_relaxed", "rechunk": True},
        {"how": "vertical", "rechunk": True},
    )
    last_exc: Exception | None = None
    for kwargs in attempts:
        try:
            return concat(frames, **kwargs)
        except Exception as exc:
            last_exc = exc
            continue

    if last_exc is not None:
        raise OMTXError(f"Failed to concatenate dataframes: {last_exc}") from last_exc
    raise OMTXError("Failed to concatenate dataframes")


class OmDataFrame:
    """Lightweight wrapper around a Polars DataFrame with SDK convenience helpers."""

    def __init__(self, dataframe: Any, *, metadata: Optional[Dict[str, Any]] = None):
        self._df = dataframe
        self.metadata = dict(metadata or {})

    @property
    def df(self) -> Any:
        return self._df

    @property
    def columns(self) -> List[str]:
        columns = getattr(self._df, "columns", None)
        if columns is None:
            return []
        return list(columns)

    @property
    def shape(self) -> Any:
        return getattr(self._df, "shape", ())

    def to_polars(self) -> Any:
        return self._df

    def __len__(self) -> int:
        try:
            return len(self._df)
        except Exception:
            return 0

    def __repr__(self) -> str:
        return f"OmDataFrame({self._df!r})"

    def __getattr__(self, name: str) -> Any:
        return getattr(self._df, name)

    def show(
        self,
        *,
        top_n: int = 24,
        smiles_col: str = "product",
        score_col: str = "om_score",
        sort_by: Optional[str] = None,
        cols: int = 6,
        size: tuple[int, int] = (250, 200),
    ) -> Any:
        """Render top molecules in a grid (RDKit) or return a summary table fallback."""
        if top_n <= 0:
            raise OMTXError("top_n must be > 0")

        df = self._df
        is_polars_df = hasattr(df, "select") and hasattr(df, "head")
        if not is_polars_df:
            raise OMTXError(
                "show() requires a Polars DataFrame-backed OmDataFrame."
            )

        columns = set(self.columns)
        if smiles_col not in columns:
            raise OMTXError(
                f"Column '{smiles_col}' not found. Available columns: {sorted(columns)}"
            )

        resolved_sort_col = _resolve_sort_column(columns, sort_by) if sort_by else None
        display_score_col = score_col
        if sort_by and score_col == "om_score":
            display_score_col = resolved_sort_col or score_col
        include_score = display_score_col in columns

        preview: Any
        preview_rows: List[Dict[str, Any]]
        ordered = df
        sort_col = resolved_sort_col or (display_score_col if include_score else None)
        if sort_col and hasattr(df, "sort"):
            try:
                ordered = df.sort(sort_col, descending=True, nulls_last=True)
            except TypeError:
                ordered = df.sort(sort_col, descending=True)

        selected_cols = [smiles_col]
        if include_score:
            selected_cols.append(display_score_col)
        preview = ordered.select(selected_cols).head(top_n)
        preview_rows = preview.to_dicts()

        try:
            from rdkit import Chem
            from rdkit.Chem import Draw
        except ImportError:
            # Fallback for environments without RDKit rendering.
            return preview

        mols: list[Any] = []
        legends: list[str] = []
        skipped = 0
        for row in preview_rows:
            smiles = row.get(smiles_col)
            if not smiles:
                skipped += 1
                continue

            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                skipped += 1
                continue

            mols.append(mol)
            if include_score:
                legends.append(f"{row.get(display_score_col, '')}")
            else:
                legends.append("")

        if not mols:
            raise OMTXError("No valid SMILES were available for rendering.")

        image = Draw.MolsToGridImage(
            mols,
            molsPerRow=max(1, int(cols)),
            subImgSize=size,
            legends=legends,
        )

        try:
            from IPython.display import display

            display(image)
        except Exception:
            pass

        if skipped:
            self.metadata["show_skipped_smiles"] = skipped
        if sort_col:
            self.metadata["show_sorted_by"] = sort_col

        return image


def _resolve_sort_column(columns: set[str], sort_by: str) -> str:
    if sort_by in columns:
        return sort_by

    aliases: Dict[str, tuple[str, ...]] = {
        "binding_score": ("binding_score", "om_score"),
        "selectivity_score": ("selectivity_score", "e_score_norm", "r_score_norm"),
    }
    for candidate in aliases.get(sort_by, ()):
        if candidate in columns:
            return candidate

    raise OMTXError(
        f"sort_by='{sort_by}' not found. Available columns: {sorted(columns)}"
    )


def as_om_dataframe(
    dataframe: Any,
    *,
    metadata: Optional[Dict[str, Any]] = None,
) -> OmDataFrame:
    if isinstance(dataframe, OmDataFrame):
        if metadata:
            dataframe.metadata.update(metadata)
        return dataframe
    return OmDataFrame(dataframe, metadata=metadata)


def _read_shards(
    frame_lib: Any,
    urls: List[str],
    max_rows: Optional[int],
):
    frames: list[Any] = []
    remaining = max_rows

    for url in urls:
        if remaining is not None and remaining <= 0:
            break

        df = frame_lib.read_parquet(url)
        row_count = _row_count(df)
        if remaining is not None and row_count > remaining:
            df = df.head(remaining)
            row_count = _row_count(df)

        frames.append(df)
        if remaining is not None:
            remaining -= row_count

    if not frames:
        return _empty_dataframe(frame_lib)

    return _concat_frames(frame_lib, frames)


def _row_count(df: Any) -> int:
    height = getattr(df, "height", None)
    if isinstance(height, int):
        return height
    try:
        return len(df)
    except Exception:
        return 0


def _empty_dataframe(frame_lib: Any) -> Any:
    dataframe_ctor = getattr(frame_lib, "DataFrame", None)
    if callable(dataframe_ctor):
        return dataframe_ctor()
    raise OMTXError("Dataframe library does not provide DataFrame constructor")


def _extract_url_list(export: Dict[str, Any], *, flat_key: str, nested_key: str) -> List[str]:
    direct_urls = export.get(flat_key)
    if isinstance(direct_urls, list):
        return [str(url) for url in direct_urls if isinstance(url, str) and url]

    nested_urls = (export.get(nested_key) or {}).get("urls", [])
    urls: List[str] = []
    if not isinstance(nested_urls, list):
        return urls

    for row in nested_urls:
        if isinstance(row, str) and row:
            urls.append(row)
            continue
        if isinstance(row, dict):
            url = row.get("url")
            if isinstance(url, str) and url:
                urls.append(url)
    return urls


def _sample_rows(
    df: Any,
    *,
    n: Optional[int],
    sample_seed: int,
    pool_name: str,
) -> Any:
    if n is None:
        return df
    if n < 0:
        raise OMTXError(f"{pool_name} n must be >= 0")

    total_rows = _row_count(df)
    if n > total_rows:
        raise OMTXError(
            f"Requested {pool_name} n={n}, but only {total_rows} rows are available."
        )
    if n == total_rows:
        return df
    if n == 0:
        return df.head(0)

    sample = getattr(df, "sample", None)
    if not callable(sample):
        raise OMTXError("Dataframe library does not provide sample(...)")

    try:
        return sample(n=n, with_replacement=False, shuffle=True, seed=int(sample_seed))
    except TypeError:
        return sample(n=n, with_replacement=False, shuffle=True)


def load_binders_export_dataframe(
    export: Dict[str, Any],
    *,
    n: Optional[int] = None,
    sample_seed: int = 42,
):
    try:
        import polars as frame_lib
    except ImportError as exc:
        raise OMTXError("Polars is required. Install with: pip install omtx") from exc

    binder_urls = _extract_url_list(
        export,
        flat_key="binder_urls",
        nested_key="binders",
    )
    if n is None:
        binders_df = _read_shards(frame_lib, binder_urls, None)
    else:
        shuffled_urls = list(binder_urls)
        random.Random(int(sample_seed)).shuffle(shuffled_urls)
        oversample_target = max(n, min(int(n * 3), int(n + 50000)))
        binders_df = _read_shards(frame_lib, shuffled_urls, oversample_target)
    return _sample_rows(
        binders_df,
        n=n,
        sample_seed=sample_seed,
        pool_name="binders",
    )


def load_nonbinders_export_dataframe(
    export: Dict[str, Any],
    *,
    n: Optional[int] = None,
    sample_seed: int = 42,
):
    try:
        import polars as frame_lib
    except ImportError as exc:
        raise OMTXError("Polars is required. Install with: pip install omtx") from exc

    non_binder_urls = _extract_url_list(
        export,
        flat_key="non_binder_urls",
        nested_key="non_binders",
    )
    if n is None:
        non_binders_df = _read_shards(frame_lib, non_binder_urls, None)
    else:
        shuffled_urls = list(non_binder_urls)
        random.Random(int(sample_seed)).shuffle(shuffled_urls)
        oversample_target = max(n, min(int(n * 3), int(n + 50000)))
        non_binders_df = _read_shards(frame_lib, shuffled_urls, oversample_target)
    return _sample_rows(
        non_binders_df,
        n=n,
        sample_seed=sample_seed,
        pool_name="nonbinders",
    )


__all__ = [
    "OmDataFrame",
    "as_om_dataframe",
    "load_binders_export_dataframe",
    "load_nonbinders_export_dataframe",
]
