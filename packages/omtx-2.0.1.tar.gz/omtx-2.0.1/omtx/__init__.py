"""OMTX Python SDK."""

from typing import Optional

from .client import OmClient, JobTimeoutError
from .constants import DEFAULT_TIMEOUT_SECONDS
from .dataframes import OmDataFrame
from .exceptions import AuthenticationError, InsufficientCreditsError, OMTXError

__version__ = "2.0.1"


def load_binders(
    *,
    protein_uuid: str,
    n: Optional[int] = None,
    sample_seed: int = 42,
    idempotency_key: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    include_metadata: bool = False,
) -> OmDataFrame | tuple[OmDataFrame, dict]:
    """Convenience helper for binder-only dataset loading via OmClient."""
    with OmClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.load_binders(
            protein_uuid=protein_uuid,
            n=n,
            sample_seed=sample_seed,
            idempotency_key=idempotency_key,
            include_metadata=include_metadata,
        )


def load_nonbinders(
    *,
    protein_uuid: str,
    n: Optional[int] = None,
    sample_seed: int = 42,
    idempotency_key: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    include_metadata: bool = False,
) -> OmDataFrame | tuple[OmDataFrame, dict]:
    """Convenience helper for non-binder-only dataset loading via OmClient."""
    with OmClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.load_nonbinders(
            protein_uuid=protein_uuid,
            n=n,
            sample_seed=sample_seed,
            idempotency_key=idempotency_key,
            include_metadata=include_metadata,
        )


__all__ = [
    "AuthenticationError",
    "InsufficientCreditsError",
    "JobTimeoutError",
    "load_binders",
    "load_nonbinders",
    "OmDataFrame",
    "OmClient",
    "OMTXError",
]
