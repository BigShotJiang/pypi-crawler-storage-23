"""
Supreme 2 MAX — MCP Server Package

Provides Model Context Protocol (MCP) integration:
- State management (SQLite + JSON persistence)
- MCP tools (analyze_project, run_security_scan, get_scan_results,
  generate_report, analyze_findings)
- MCP resources (scan results, reports, config, scanners)
- MCP prompts (security_scan_workflow, pr_security_check, …)
- MCP client auto-setup (Claude Desktop, Cline, Cursor, Copilot)
- Configuration management (mcp_config.yml)
- Security module (path validation, secrets filtering)
"""

__version__ = "1.0.0"


def main():
    """Main entry point for the supreme2l MCP server."""
    from supreme_max.mcp_server.__main__ import main as _main
    _main()


__all__ = ["main", "__version__"]

