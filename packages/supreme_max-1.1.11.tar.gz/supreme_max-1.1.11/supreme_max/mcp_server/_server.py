"""
Supreme 2 MAX — shared FastMCP server instance.

Centralises the ``FastMCP`` object so that ``tools.py``, ``resources.py``,
``prompts.py`` (decorator registration) and ``__main__.py`` (entry-point)
can all import the same instance without circular imports.

Also loads the MCP-specific configuration (``~/.supreme2l/mcp_config.yml``)
and wires workspace-root into the security module when configured.
"""

from __future__ import annotations

import logging
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from supreme_max.mcp_server.config import MCPConfigManager

# Load MCP-specific configuration (from ~/.supreme2l/mcp_config.yml)
config_manager = MCPConfigManager()
config = config_manager.config

# Apply log level from config
logging.getLogger("supreme2l.mcp_server").setLevel(
    getattr(logging, config.log_level, logging.INFO),
)

# Wire workspace_root into the security module when configured
if config.workspace_root:
    from supreme_max.mcp_server.security import set_workspace_root
    set_workspace_root(Path(config.workspace_root))

mcp = FastMCP(
    "Supreme 2 MAX",
    instructions=(
        "Supreme 2 MAX is an AI-first security scanner with 74+ analyzers. "
        "Use the tools below to scan projects, retrieve results, and generate reports."
    ),
)
