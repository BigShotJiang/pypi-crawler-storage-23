"""
Supreme 2 MAX IDE Integrations
Auto-configuration for Claude Code, Cursor, VS Code, Gemini CLI
"""

from supreme_max.ide.claude_code import setup_claude_code

__all__ = ['setup_claude_code']
