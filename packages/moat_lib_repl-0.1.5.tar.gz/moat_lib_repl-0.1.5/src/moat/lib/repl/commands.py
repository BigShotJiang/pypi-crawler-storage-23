#   Copyright 2000-2010 Michael Hudson-Doyle <micahel@gmail.com>  # noqa: D100
#                       Antonio Cuni
#                       Armin Rigo
#
#                        All Rights Reserved
#
#
# Permission to use, copy, modify, and distribute this software and
# its documentation for any purpose is hereby granted without fee,
# provided that the above copyright notice appear in all copies and
# that both that copyright notice and this permission notice appear in
# supporting documentation.
#
# THE AUTHOR MICHAEL HUDSON DISCLAIMS ALL WARRANTIES WITH REGARD TO
# THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
# AND FITNESS, IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
# INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
# RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
# CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
# CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import annotations

import os
import time

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .historical_reader import HistoricalReader

# Categories of actions:
#  killing
#  yanking
#  motion
#  editing
#  history
#  finishing
# [completion]

from .trace import trace

__all__ = [
    "Command",
    "EditCommand",
    "FinishCommand",
    "KillCommand",
    "MotionCommand",
    "YankCommand",
    "is_kill",
    "is_yank",
]


class Command:  # noqa: D101
    finish: bool = False
    kills_digit_arg: bool = True

    def __init__(self, reader: HistoricalReader, event_name: str, event: list[str]) -> None:
        # Reader should really be "any reader" but there's too much usage of
        # HistoricalReader methods and fields in the code below for us to
        # refactor at the moment.

        self.reader = reader
        self.event = event
        self.event_name = event_name

    async def do(self) -> None:  # noqa: D102
        pass


class KillCommand(Command):  # noqa: D101
    def kill_range(self, start: int, end: int) -> None:  # noqa: D102
        if start == end:
            return
        r = self.reader
        b = r.buffer
        text = b[start:end]
        del b[start:end]
        if is_kill(r.last_command):
            if start < r.pos:
                r.kill_ring[-1] = text + r.kill_ring[-1]
            else:
                r.kill_ring[-1] = r.kill_ring[-1] + text
        else:
            r.kill_ring.append(text)
        r.pos = start
        r.dirty = True


class YankCommand(Command):  # noqa: D101
    pass


class MotionCommand(Command):  # noqa: D101
    pass


class EditCommand(Command):  # noqa: D101
    pass


class FinishCommand(Command):  # noqa: D101
    finish = True
    pass


def is_kill(command: type[Command] | None) -> bool:  # noqa: D103
    return command is not None and issubclass(command, KillCommand)


def is_yank(command: type[Command] | None) -> bool:  # noqa: D103
    return command is not None and issubclass(command, YankCommand)


# etc


class digit_arg(Command):
    kills_digit_arg = False

    async def do(self) -> None:
        r = self.reader
        c = self.event[-1]
        if c == "-":
            if r.arg is not None:
                r.arg = -r.arg
            else:
                r.arg = -1
        else:
            d = int(c)
            if r.arg is None:
                r.arg = d
            else:
                if r.arg < 0:
                    r.arg = 10 * r.arg - d
                else:
                    r.arg = 10 * r.arg + d
        r.dirty = True


class clear_screen(Command):
    async def do(self) -> None:
        r = self.reader
        r.console.clear()
        r.dirty = True


class refresh(Command):
    async def do(self) -> None:
        self.reader.dirty = True


class repaint(Command):
    async def do(self) -> None:
        self.reader.dirty = True
        self.reader.console.repaint()


class kill_line(KillCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        eol = r.eol()
        for c in b[r.pos : eol]:
            if not c.isspace():
                self.kill_range(r.pos, eol)
                return
        self.kill_range(r.pos, eol + 1)


class unix_line_discard(KillCommand):
    async def do(self) -> None:
        r = self.reader
        self.kill_range(r.bol(), r.pos)


class unix_word_rubout(KillCommand):
    async def do(self) -> None:
        r = self.reader
        for _i in range(r.get_arg()):
            self.kill_range(r.bow(), r.pos)


class kill_word(KillCommand):
    async def do(self) -> None:
        r = self.reader
        for _i in range(r.get_arg()):
            self.kill_range(r.pos, r.eow())


class backward_kill_word(KillCommand):
    async def do(self) -> None:
        r = self.reader
        for _i in range(r.get_arg()):
            self.kill_range(r.bow(), r.pos)


class yank(YankCommand):
    async def do(self) -> None:
        r = self.reader
        if not r.kill_ring:
            await r.error("nothing to yank")
            return
        r.insert(r.kill_ring[-1])


class yank_pop(YankCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        if not r.kill_ring:
            await r.error("nothing to yank")
            return
        if not is_yank(r.last_command):
            await r.error("previous command was not a yank")
            return
        repl = len(r.kill_ring[-1])
        r.kill_ring.insert(0, r.kill_ring.pop())
        t = r.kill_ring[-1]
        b[r.pos - repl : r.pos] = t
        r.pos = r.pos - repl + len(t)
        r.dirty = True


class interrupt(FinishCommand):
    async def do(self) -> None:
        import signal  # noqa: PLC0415

        await self.reader.console.finish()
        await self.reader.finish()
        os.kill(os.getpid(), signal.SIGINT)


class ctrl_c(Command):
    async def do(self) -> None:
        # await self.reader.console.finish()
        # await self.reader.finish()
        raise KeyboardInterrupt


class suspend(Command):
    async def do(self) -> None:
        import signal  # noqa: PLC0415

        r = self.reader
        p = r.pos
        await r.console.finish()
        os.kill(os.getpid(), signal.SIGSTOP)
        ## this should probably be done
        ## in a handler for SIGCONT?
        await r.console.prepare()
        r.pos = p
        # r.posxy = 0, 0  # XXX this is invalid
        r.dirty = True
        r.console.screen = []


class up(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        for _ in range(r.get_arg()):
            x, y = r.pos2xy()
            new_y = y - 1

            if r.bol() == 0:
                if r.historyi > 0:
                    r.select_item(r.historyi - 1)
                    return
                r.pos = 0
                await r.error("start of buffer")
                return

            if (
                x > (new_x := r.max_column(new_y))  # we're past the end of the previous line
                or (
                    x == r.max_column(y) and any(not i.isspace() for i in r.buffer[r.bol() :])
                )  # move between eols
            ):
                x = new_x

            r.setpos_from_xy(x, new_y)


class down(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        for _ in range(r.get_arg()):
            x, y = r.pos2xy()
            new_y = y + 1

            if r.eol() == len(b):
                if r.historyi < len(r.history):
                    r.select_item(r.historyi + 1)
                    r.pos = r.eol(0)
                    return
                r.pos = len(b)
                await r.error("end of buffer")
                return

            if (
                x > (new_x := r.max_column(new_y))  # we're past the end of the previous line
                or (
                    x == r.max_column(y) and any(not i.isspace() for i in r.buffer[r.bol() :])
                )  # move between eols
            ):
                x = new_x

            r.setpos_from_xy(x, new_y)


class left(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        for _ in range(r.get_arg()):
            p = r.pos - 1
            if p >= 0:
                r.pos = p
            else:
                await self.reader.error("start of buffer")


class right(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        for _ in range(r.get_arg()):
            p = r.pos + 1
            if p <= len(b):
                r.pos = p
            else:
                await self.reader.error("end of buffer")


class beginning_of_line(MotionCommand):
    async def do(self) -> None:
        self.reader.pos = self.reader.bol()


class end_of_line(MotionCommand):
    async def do(self) -> None:
        self.reader.pos = self.reader.eol()


class home(MotionCommand):
    async def do(self) -> None:
        self.reader.pos = 0


class end(MotionCommand):
    async def do(self) -> None:
        self.reader.pos = len(self.reader.buffer)


class forward_word(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        for _i in range(r.get_arg()):
            r.pos = r.eow()


class backward_word(MotionCommand):
    async def do(self) -> None:
        r = self.reader
        for _i in range(r.get_arg()):
            r.pos = r.bow()


class self_insert(EditCommand):
    async def do(self) -> None:
        r = self.reader
        text = self.event * r.get_arg()
        r.insert(text)
        if r.paste_mode:
            data = ""
            ev = await r.console.getpending()
            data += ev.data
            if data:
                r.insert(data)
                r.last_refresh_cache.invalidated = True


class insert_nl(EditCommand):
    async def do(self) -> None:
        r = self.reader
        r.insert("\n" * r.get_arg())


class transpose_characters(EditCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        s = r.pos - 1
        if s < 0:
            await r.error("cannot transpose at start of buffer")
        else:
            if s == len(b):
                s -= 1
            t = min(s + r.get_arg(), len(b) - 1)
            c = b[s]
            del b[s]
            b.insert(t, c)
            r.pos = t
            r.dirty = True


class backspace(EditCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        for _i in range(r.get_arg()):
            if r.pos > 0:
                r.pos -= 1
                del b[r.pos]
                r.dirty = True
            else:
                await self.reader.error("can't backspace at start")


class delete(EditCommand):
    async def do(self) -> None:
        r = self.reader
        b = r.buffer
        if self.event[-1] == "\004":
            if b and b[-1].endswith("\n"):
                self.finish = True
            elif (
                r.pos == 0 and len(b) == 0  # this is something of a hack
            ):
                await r.update_screen()
                await r.console.finish()
                raise EOFError

        for _i in range(r.get_arg()):
            if r.pos != len(b):
                del b[r.pos]
                r.dirty = True
            else:
                await self.reader.error("end of buffer")


class accept(FinishCommand):
    async def do(self) -> None:
        pass


class help(Command):
    async def do(self) -> None:
        import _sitebuiltins  # noqa: PLC0415

        with self.reader.suspend():
            _sitebuiltins._Helper()()  # Displays help interactively  # noqa:SLF001
            self.reader.msg = ""  # Clear any previous message


class invalid_key(Command):
    async def do(self) -> None:
        pending = await self.reader.console.getpending()
        s = "".join(self.event) + pending.data
        await self.reader.error(f"`{s!r}' not bound")


class invalid_command(Command):
    async def do(self) -> None:
        s = self.event_name
        await self.reader.error(f"command `{s}' not known")


class show_history(Command):
    async def do(self) -> None:
        from site import (  # noqa:PLC0415
            gethistoryfile,  # ty: ignore[unresolved-import]  # Python 3.13+
        )

        from .pager import get_pager  # noqa: PLC0415

        history = os.linesep.join(self.reader.history[:])
        await self.reader.console.restore()
        pager = get_pager()
        pager(history, gethistoryfile())
        await self.reader.console.prepare()

        # We need to copy over the state so that it's consistent between
        # console and reader, and console does not overwrite/append stuff
        self.reader.console.screen = self.reader.screen.copy()
        self.reader.console.posxy = self.reader.cxy


class paste_mode(Command):
    async def do(self) -> None:
        self.reader.paste_mode = not self.reader.paste_mode
        self.reader.dirty = True


class perform_bracketed_paste(Command):
    async def do(self) -> None:
        done = "\x1b[201~"
        data = ""
        start = time.time()
        while done not in data:
            ev = await self.reader.console.getpending()
            data += ev.data
        trace(
            "bracketed pasting of {l} chars done in {s:.2f}s",
            l=len(data),
            s=time.time() - start,
        )
        self.reader.insert(data.replace(done, ""))
        self.reader.last_refresh_cache.invalidated = True
