"""Frontend Developer lens for Principal Audit.

Focuses on UI components, state management, rendering patterns,
and frontend-specific code quality concerns.
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule


class FrontendLens(BaseLens):
    """Frontend Developer perspective for code quality analysis.

    Focuses on:
    - Component complexity and prop drilling
    - State management patterns
    - Rendering optimization
    - UI layer separation
    """

    @property
    def lens_type(self) -> PrincipalLens:
        return PrincipalLens.FRONTEND

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=PrincipalLens.FRONTEND,
            display_name="Frontend Developer",
            description="UI components, state management, rendering patterns",
            complexity_rules=[
                LensRule(
                    id="FE-C001",
                    category=FindingCategory.COMPLEXITY,
                    name="Component Complexity",
                    description="React/Vue/Angular component with too many responsibilities",
                    severity_default="high",
                    check_guidance=[
                        "Check component line count (>200 lines is concerning)",
                        "Count number of useState/useReducer hooks (>5 is high)",
                        "Identify components with >10 props",
                        "Look for components handling multiple domains",
                    ],
                ),
                LensRule(
                    id="FE-C002",
                    category=FindingCategory.COMPLEXITY,
                    name="Conditional Rendering Complexity",
                    description="Excessive conditional rendering logic in JSX/templates",
                    severity_default="medium",
                    check_guidance=[
                        "Count ternary operators in render/return block",
                        "Look for nested conditionals in JSX",
                        "Identify >3 conditional render branches",
                        "Check for complex && chains in templates",
                    ],
                ),
                LensRule(
                    id="FE-C003",
                    category=FindingCategory.COMPLEXITY,
                    name="Effect Hook Complexity",
                    description="useEffect/lifecycle hooks with complex dependencies",
                    severity_default="high",
                    check_guidance=[
                        "Check effect dependency arrays (>5 deps is concerning)",
                        "Look for effects with multiple responsibilities",
                        "Identify effects that could be custom hooks",
                        "Find effects with complex cleanup logic",
                    ],
                ),
            ],
            dry_rules=[
                LensRule(
                    id="FE-D001",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Duplicated Component Logic",
                    description="Similar logic repeated across multiple components",
                    severity_default="high",
                    check_guidance=[
                        "Find similar useState patterns across components",
                        "Look for repeated fetch/API call patterns",
                        "Identify duplicated form handling logic",
                        "Check for similar event handler implementations",
                    ],
                ),
                LensRule(
                    id="FE-D002",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Style Duplication",
                    description="Repeated inline styles or CSS-in-JS patterns",
                    severity_default="medium",
                    check_guidance=[
                        "Look for repeated style objects",
                        "Check for duplicated Tailwind class patterns",
                        "Identify similar styled-components definitions",
                        "Find copy-pasted CSS modules",
                    ],
                ),
                LensRule(
                    id="FE-D003",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Repeated Validation Logic",
                    description="Form validation rules duplicated across forms",
                    severity_default="medium",
                    check_guidance=[
                        "Find similar validation functions",
                        "Look for repeated regex patterns",
                        "Check for duplicated error message handling",
                        "Identify repeated schema definitions",
                    ],
                ),
            ],
            coupling_rules=[
                LensRule(
                    id="FE-CP001",
                    category=FindingCategory.COUPLING,
                    name="Prop Drilling",
                    description="Props passed through multiple component levels",
                    severity_default="high",
                    check_guidance=[
                        "Trace props through component hierarchy",
                        "Identify props passed >3 levels deep",
                        "Look for intermediate components just passing props",
                        "Check for callbacks drilled through layers",
                    ],
                ),
                LensRule(
                    id="FE-CP002",
                    category=FindingCategory.COUPLING,
                    name="Component-Store Coupling",
                    description="Components tightly coupled to global state structure",
                    severity_default="medium",
                    check_guidance=[
                        "Check for components accessing deep store paths",
                        "Look for store structure assumptions in components",
                        "Identify components that break with store changes",
                        "Find selectors embedded in components",
                    ],
                ),
                LensRule(
                    id="FE-CP003",
                    category=FindingCategory.COUPLING,
                    name="External API Coupling",
                    description="Components directly calling APIs without abstraction",
                    severity_default="high",
                    check_guidance=[
                        "Find fetch/axios calls directly in components",
                        "Look for API URL strings in component files",
                        "Identify components that transform API responses",
                        "Check for missing service/repository layer",
                    ],
                ),
            ],
            separation_rules=[
                LensRule(
                    id="FE-S001",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Mixed Business Logic in UI",
                    description="Business rules embedded in presentation components",
                    severity_default="critical",
                    check_guidance=[
                        "Find calculations/algorithms in render logic",
                        "Look for business rules in event handlers",
                        "Identify domain logic in component methods",
                        "Check for pricing/tax calculations in UI",
                    ],
                ),
                LensRule(
                    id="FE-S002",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Data Fetching in Components",
                    description="API calls mixed with presentation logic",
                    severity_default="medium",
                    check_guidance=[
                        "Find useEffect with fetch calls",
                        "Look for loading/error state in same component",
                        "Identify components doing CRUD operations",
                        "Check for data transformation in components",
                    ],
                ),
                LensRule(
                    id="FE-S003",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Styling Mixed with Logic",
                    description="Complex styling logic intertwined with behavior",
                    severity_default="low",
                    check_guidance=[
                        "Find computed styles based on business logic",
                        "Look for theme logic in components",
                        "Identify conditional classes with complex rules",
                        "Check for animation logic in components",
                    ],
                ),
            ],
            maintainability_rules=[
                LensRule(
                    id="FE-M001",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Missing Component Documentation",
                    description="Complex components without props documentation",
                    severity_default="medium",
                    check_guidance=[
                        "Check for PropTypes or TypeScript interfaces",
                        "Look for JSDoc on component functions",
                        "Identify undocumented required props",
                        "Find components without usage examples",
                    ],
                ),
                LensRule(
                    id="FE-M002",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Inconsistent Component Structure",
                    description="Components not following team conventions",
                    severity_default="low",
                    check_guidance=[
                        "Check file/folder naming conventions",
                        "Look for inconsistent hook ordering",
                        "Identify varying export patterns",
                        "Find mixed component patterns (class/function)",
                    ],
                ),
                LensRule(
                    id="FE-M003",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Magic Numbers in Styles",
                    description="Hardcoded values instead of design tokens",
                    severity_default="medium",
                    check_guidance=[
                        "Find hardcoded pixel values",
                        "Look for color hex codes outside theme",
                        "Identify magic breakpoint numbers",
                        "Check for hardcoded z-index values",
                    ],
                ),
            ],
        )
