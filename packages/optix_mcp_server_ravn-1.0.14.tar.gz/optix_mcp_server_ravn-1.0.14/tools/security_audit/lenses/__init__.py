"""Security Audit Lenses - Specialized security analysis perspectives.

Available lenses:
- backend: Senior Backend Engineer - SQL injection, auth flaws, API security
- frontend: Senior Frontend Engineer - XSS, CSRF, DOM security, client storage
- devsecops: DevSecOps Engineer - secrets, dependencies, CI/CD, supply chain
- compliance: Compliance Officer - PII, GDPR, HIPAA, PCI-DSS, data handling
- comprehensive: Full team review (default)
"""

from typing import Optional, Union

from tools.security_audit.domains import SecurityLens
from tools.security_audit.lenses.backend import BackendLens
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule
from tools.security_audit.lenses.compliance import ComplianceLens
from tools.security_audit.lenses.comprehensive import ComprehensiveLens
from tools.security_audit.lenses.devsecops import DevSecOpsLens
from tools.security_audit.lenses.frontend import FrontendLens

LENS_REGISTRY: dict[SecurityLens, type[BaseLens]] = {
    SecurityLens.BACKEND: BackendLens,
    SecurityLens.FRONTEND: FrontendLens,
    SecurityLens.DEVSECOPS: DevSecOpsLens,
    SecurityLens.COMPLIANCE: ComplianceLens,
    SecurityLens.COMPREHENSIVE: ComprehensiveLens,
}


def get_lens(lens_type: Optional[Union[SecurityLens, str]] = None) -> BaseLens:
    """Get a lens instance by type.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        BaseLens instance for the specified type
    """
    if isinstance(lens_type, str):
        lens_type = SecurityLens.from_string(lens_type)
    elif lens_type is None:
        lens_type = SecurityLens.COMPREHENSIVE

    lens_class = LENS_REGISTRY.get(lens_type, ComprehensiveLens)
    return lens_class()


def get_lens_config(lens_type: Optional[Union[SecurityLens, str]] = None) -> LensConfig:
    """Get the configuration for a lens.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        LensConfig for the specified lens
    """
    return get_lens(lens_type).get_config()


def list_available_lenses() -> list[dict[str, str]]:
    """List all available lenses with descriptions.

    Returns:
        List of dicts with id, display_name, and description
    """
    return [
        {
            "id": lens.value,
            "display_name": lens.display_name,
            "description": lens.description,
        }
        for lens in SecurityLens
    ]


__all__ = [
    "BaseLens",
    "LensConfig",
    "LensRule",
    "BackendLens",
    "FrontendLens",
    "DevSecOpsLens",
    "ComplianceLens",
    "ComprehensiveLens",
    "LENS_REGISTRY",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
