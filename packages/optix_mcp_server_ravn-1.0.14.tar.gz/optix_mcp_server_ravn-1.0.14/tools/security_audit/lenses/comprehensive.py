"""Comprehensive lens for Security Audit.

Combines the most important rules from all specialized lenses to provide
a complete security review covering all perspectives.
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComprehensiveLens(BaseLens):
    """Comprehensive security perspective.

    Combines key rules from Backend, Frontend, DevSecOps, and Compliance
    lenses to provide a full-spectrum security review.
    """

    @property
    def lens_type(self) -> SecurityLens:
        return SecurityLens.COMPREHENSIVE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=SecurityLens.COMPREHENSIVE,
            display_name="Comprehensive",
            description="Full security review covering all perspectives",
            reconnaissance_rules=[
                LensRule(
                    id="COMP-R001",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Application Security Profile",
                    description="Complete security reconnaissance",
                    severity_default="info",
                    check_guidance=[
                        "Identify application type and technology stack",
                        "Map all entry points (APIs, web, files, etc.)",
                        "Document authentication and session mechanisms",
                        "Identify data flows and storage locations",
                        "Map third-party integrations and dependencies",
                    ],
                ),
            ],
            auth_rules=[
                LensRule(
                    id="COMP-A001",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Authentication Security",
                    description="Complete authentication review",
                    severity_default="critical",
                    check_guidance=[
                        "Review authentication mechanism implementation",
                        "Check for authentication bypass vulnerabilities",
                        "Verify password hashing and storage",
                        "Check token storage and handling",
                        "Review session management security",
                    ],
                ),
                LensRule(
                    id="COMP-A002",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Authorization Security",
                    description="Complete authorization review",
                    severity_default="critical",
                    check_guidance=[
                        "Verify role-based access control",
                        "Check for IDOR vulnerabilities",
                        "Test privilege escalation paths",
                        "Review admin and sensitive endpoint protection",
                    ],
                ),
            ],
            input_rules=[
                LensRule(
                    id="COMP-I001",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Injection Vulnerabilities",
                    description="All injection attack vectors",
                    severity_default="critical",
                    check_guidance=[
                        "Check for SQL/NoSQL injection",
                        "Review command injection possibilities",
                        "Test for XSS (reflected, stored, DOM-based)",
                        "Check LDAP, XML, and path injection",
                    ],
                ),
                LensRule(
                    id="COMP-I002",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Input Validation",
                    description="Input validation and sanitization",
                    severity_default="high",
                    check_guidance=[
                        "Verify server-side validation",
                        "Check output encoding",
                        "Review file upload security",
                        "Check for SSRF vulnerabilities",
                    ],
                ),
                LensRule(
                    id="COMP-I003",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Cryptography",
                    description="Cryptographic implementation review",
                    severity_default="high",
                    check_guidance=[
                        "Check encryption algorithms",
                        "Review key management",
                        "Verify TLS configuration",
                        "Check for weak random number generation",
                    ],
                ),
            ],
            owasp_rules=[
                LensRule(
                    id="COMP-O001",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="OWASP A01 - Broken Access Control",
                    description="Access control vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Verify access control on all endpoints",
                        "Check for missing function-level access control",
                        "Review CORS configuration",
                    ],
                ),
                LensRule(
                    id="COMP-O002",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="OWASP A02 - Cryptographic Failures",
                    description="Data protection and cryptography",
                    severity_default="high",
                    check_guidance=[
                        "Verify encryption for sensitive data",
                        "Check for sensitive data exposure",
                        "Review key storage and management",
                    ],
                ),
                LensRule(
                    id="COMP-O003",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="OWASP A03-A10",
                    description="Remaining OWASP categories",
                    severity_default="high",
                    check_guidance=[
                        "A03: Injection vulnerabilities",
                        "A04: Insecure design patterns",
                        "A05: Security misconfiguration",
                        "A06: Vulnerable components",
                        "A07: Auth failures",
                        "A08: Software integrity",
                        "A09: Logging failures",
                        "A10: SSRF",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="COMP-D001",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Secrets in Code",
                    description="Hardcoded secrets and credentials",
                    severity_default="critical",
                    check_guidance=[
                        "Search for API keys and tokens",
                        "Check for hardcoded passwords",
                        "Review .env and config files",
                        "Check for secrets in logs",
                    ],
                ),
                LensRule(
                    id="COMP-D002",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Dependency Vulnerabilities",
                    description="Third-party component security",
                    severity_default="high",
                    check_guidance=[
                        "Check for known CVEs in dependencies",
                        "Verify lockfile presence",
                        "Review dependency update policies",
                    ],
                ),
                LensRule(
                    id="COMP-D003",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Configuration Security",
                    description="Security configuration review",
                    severity_default="high",
                    check_guidance=[
                        "Check security headers",
                        "Review CORS settings",
                        "Verify debug mode is disabled",
                        "Check error handling",
                    ],
                ),
            ],
            compliance_rules=[
                LensRule(
                    id="COMP-C001",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Data Protection",
                    description="Data protection and privacy",
                    severity_default="high",
                    check_guidance=[
                        "Review PII handling",
                        "Check data encryption",
                        "Verify data retention policies",
                        "Review consent mechanisms",
                    ],
                ),
                LensRule(
                    id="COMP-C002",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Compliance Requirements",
                    description="Regulatory compliance verification",
                    severity_default="medium",
                    check_guidance=[
                        "Check GDPR requirements if applicable",
                        "Review HIPAA compliance if healthcare",
                        "Verify PCI-DSS if payment processing",
                        "Check audit logging requirements",
                    ],
                ),
            ],
        )
