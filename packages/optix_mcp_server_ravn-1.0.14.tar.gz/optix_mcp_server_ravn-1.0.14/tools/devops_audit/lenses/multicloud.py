"""Multi-Cloud lens for DevOps audit."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class MultiCloudLens(BaseLens):
    """Multi-Cloud lens focusing on AWS/Azure/GCP patterns, IaC."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.MULTICLOUD

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.MULTICLOUD,
            display_name="Multi-Cloud",
            description="Focus on AWS/Azure/GCP patterns and IaC",
            docker_rules=[
                LensRule(
                    id="CLOUD-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Hardcoded Cloud Credentials",
                    description="AWS/Azure/GCP credentials in image",
                    severity_default="critical",
                    check_guidance=[
                        "Search for AWS_ACCESS_KEY, AZURE_*, GOOGLE_*",
                        "Check for cloud credential files copied",
                        "Look for service account JSON in layers",
                    ],
                ),
                LensRule(
                    id="CLOUD-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Cloud CLI Version Unpinned",
                    description="AWS CLI, gcloud, az CLI without version",
                    severity_default="medium",
                    check_guidance=[
                        "Check cloud CLI installation for versions",
                        "Verify aws-cli, gcloud, az version pinned",
                        "Look for :latest in cloud SDK images",
                    ],
                ),
                LensRule(
                    id="CLOUD-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing Registry Login",
                    description="ECR/ACR/GCR push without auth setup",
                    severity_default="medium",
                    check_guidance=[
                        "Check for cloud registry authentication",
                        "Verify ECR/ACR/GCR login commands",
                        "Look for registry credential helpers",
                    ],
                ),
                LensRule(
                    id="CLOUD-D004",
                    category=DevOpsCategory.DOCKERFILE,
                    name="No Multi-Arch Support",
                    description="Missing multi-architecture build config",
                    severity_default="low",
                    check_guidance=[
                        "Check for buildx multi-platform support",
                        "Verify ARM64/AMD64 compatibility",
                        "Look for architecture-specific base images",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="CLOUD-C001",
                    category=DevOpsCategory.CICD,
                    name="Overly Permissive IAM Role",
                    description="IAM role with excessive permissions",
                    severity_default="high",
                    check_guidance=[
                        "Check OIDC role trust policy",
                        "Verify role permissions are scoped",
                        "Look for AdministratorAccess or PowerUser",
                    ],
                ),
                LensRule(
                    id="CLOUD-C002",
                    category=DevOpsCategory.CICD,
                    name="OIDC Not Configured",
                    description="Using static credentials instead of OIDC",
                    severity_default="medium",
                    check_guidance=[
                        "Check for OIDC token authentication",
                        "Verify aws-actions/configure-aws-credentials",
                        "Look for static ACCESS_KEY secrets",
                    ],
                ),
                LensRule(
                    id="CLOUD-C003",
                    category=DevOpsCategory.CICD,
                    name="Region Hardcoded",
                    description="Cloud region hardcoded in workflow",
                    severity_default="low",
                    check_guidance=[
                        "Check for hardcoded AWS_REGION values",
                        "Verify region is configurable",
                        "Look for multi-region deployment support",
                    ],
                ),
                LensRule(
                    id="CLOUD-C004",
                    category=DevOpsCategory.CICD,
                    name="No State Backend Encryption",
                    description="Terraform state without encryption",
                    severity_default="high",
                    check_guidance=[
                        "Check S3/GCS backend encryption config",
                        "Verify state locking enabled",
                        "Look for sensitive data in state",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="CLOUD-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Cloud SDK Outdated",
                    description="AWS SDK, Azure SDK, or GCP libraries old",
                    severity_default="medium",
                    check_guidance=[
                        "Check aws-sdk, @azure/*, @google-cloud/* versions",
                        "Verify SDK is within supported versions",
                        "Look for deprecated SDK features used",
                    ],
                ),
                LensRule(
                    id="CLOUD-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="IaC Module Unpinned",
                    description="Terraform/Pulumi modules without version",
                    severity_default="high",
                    check_guidance=[
                        "Check Terraform module source versions",
                        "Verify module registry versions pinned",
                        "Look for ref=main in module sources",
                    ],
                ),
                LensRule(
                    id="CLOUD-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Provider Version Floating",
                    description="Terraform provider without constraint",
                    severity_default="medium",
                    check_guidance=[
                        "Check required_providers version constraints",
                        "Verify provider versions locked",
                        "Look for ~> or >= without upper bound",
                    ],
                ),
                LensRule(
                    id="CLOUD-P004",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No Drift Detection",
                    description="Missing IaC drift detection setup",
                    severity_default="medium",
                    check_guidance=[
                        "Check for terraform plan in CI",
                        "Verify drift detection scheduled",
                        "Look for state refresh configuration",
                    ],
                ),
            ],
        )
