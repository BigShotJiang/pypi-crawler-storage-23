import json
import logging
import urllib.request
import urllib.error
from dataclasses import dataclass

from tools.findings_to_tickets.config import LinearConfig
from tools.findings_to_tickets.models import TicketData, TicketResult

logger = logging.getLogger(__name__)

LINEAR_API_URL = "https://api.linear.app/graphql"

PRIORITY_MAP = {
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "0": 0,
}


@dataclass
class LinearClient:
    config: LinearConfig

    def create_issue(self, ticket: TicketData, team_id: str) -> TicketResult:
        mutation = """
        mutation CreateIssue($input: IssueCreateInput!) {
            issueCreate(input: $input) {
                success
                issue {
                    id
                    identifier
                    url
                }
            }
        }
        """

        priority = PRIORITY_MAP.get(ticket.priority, 0)

        variables = {
            "input": {
                "teamId": team_id,
                "title": ticket.title,
                "description": ticket.description,
                "priority": priority,
                "labelIds": [],
            }
        }

        try:
            result = self._execute_graphql(mutation, variables)

            if result.get("errors"):
                error_msg = result["errors"][0].get("message", "Unknown error")
                return TicketResult(
                    finding_id=ticket.finding_id,
                    ticket_id="",
                    ticket_url="",
                    success=False,
                    error=error_msg,
                )

            issue_data = result.get("data", {}).get("issueCreate", {})
            if not issue_data.get("success"):
                return TicketResult(
                    finding_id=ticket.finding_id,
                    ticket_id="",
                    ticket_url="",
                    success=False,
                    error="Linear API returned success=false",
                )

            issue = issue_data.get("issue", {})
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id=issue.get("identifier", ""),
                ticket_url=issue.get("url", ""),
                success=True,
            )

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            logger.error(f"Linear API error: {e.code} - {error_body}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=f"HTTP {e.code}: {self._parse_error(error_body)}",
            )
        except Exception as e:
            logger.error(f"Linear API error: {e}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=str(e),
            )

    def get_team_id(self, team_key: str) -> str | None:
        query = """
        query Teams {
            teams {
                nodes {
                    id
                    key
                    name
                }
            }
        }
        """

        try:
            result = self._execute_graphql(query, {})
            teams = result.get("data", {}).get("teams", {}).get("nodes", [])

            for team in teams:
                if team.get("key", "").lower() == team_key.lower():
                    return team.get("id")
                if team.get("name", "").lower() == team_key.lower():
                    return team.get("id")

            return None
        except Exception as e:
            logger.error(f"Failed to get Linear team: {e}")
            return None

    def _execute_graphql(self, query: str, variables: dict) -> dict:
        payload = json.dumps({"query": query, "variables": variables}).encode("utf-8")

        request = urllib.request.Request(
            LINEAR_API_URL,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": self.config.api_key,
            },
            method="POST",
        )

        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))

    def _parse_error(self, error_body: str) -> str:
        try:
            data = json.loads(error_body)
            if "errors" in data and data["errors"]:
                return data["errors"][0].get("message", error_body)
            return data.get("message", error_body)
        except json.JSONDecodeError:
            return error_body[:200]
