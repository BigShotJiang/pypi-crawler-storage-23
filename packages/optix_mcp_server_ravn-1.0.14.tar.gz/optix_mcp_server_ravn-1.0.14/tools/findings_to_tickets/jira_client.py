import base64
import json
import logging
import urllib.request
import urllib.error
from dataclasses import dataclass

from tools.findings_to_tickets.config import JiraConfig
from tools.findings_to_tickets.models import TicketData, TicketResult

logger = logging.getLogger(__name__)

PRIORITY_MAP = {
    "Highest": "1",
    "High": "2",
    "Medium": "3",
    "Low": "4",
    "Lowest": "5",
}


@dataclass
class JiraClient:
    config: JiraConfig

    def create_issue(self, ticket: TicketData, project_key: str) -> TicketResult:
        url = f"{self.config.instance_url}/rest/api/3/issue"

        priority_id = PRIORITY_MAP.get(ticket.priority, "3")

        payload = {
            "fields": {
                "project": {"key": project_key.upper()},
                "summary": ticket.title[:255],
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {"type": "text", "text": ticket.description}
                            ]
                        }
                    ]
                },
                "issuetype": {"name": "Task"},
                "priority": {"id": priority_id},
            }
        }

        try:
            result = self._make_request("POST", url, payload)

            issue_key = result.get("key", "")
            issue_url = f"{self.config.instance_url}/browse/{issue_key}"

            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id=issue_key,
                ticket_url=issue_url,
                success=True,
            )

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            logger.error(f"Jira API error: {e.code} - {error_body}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=f"HTTP {e.code}: {self._parse_error(error_body)}",
            )
        except Exception as e:
            logger.error(f"Jira API error: {e}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=str(e),
            )

    def _make_request(self, method: str, url: str, data: dict | None = None) -> dict:
        credentials = f"{self.config.user_email}:{self.config.api_token}"
        auth_header = base64.b64encode(credentials.encode()).decode()

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        }

        body = json.dumps(data).encode("utf-8") if data else None

        request = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method=method,
        )

        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))

    def _parse_error(self, error_body: str) -> str:
        try:
            data = json.loads(error_body)
            errors = data.get("errorMessages", [])
            if errors:
                return errors[0]
            field_errors = data.get("errors", {})
            if field_errors:
                return str(field_errors)
            return data.get("message", error_body[:200])
        except json.JSONDecodeError:
            return error_body[:200]
