"""Slack Block Kit message formatter for audit notifications."""

from datetime import datetime, timezone


class SlackMessageFormatter:
    """Formats audit findings into Slack Block Kit messages."""

    AUDIT_EMOJIS = {
        "security_audit": "🔒",
        "a11y_audit": "♿",
        "devops_audit": "🔧",
        "principal_audit": "📊",
    }

    SEVERITY_EMOJIS = {
        "critical": "🔴",
        "high": "🟠",
        "medium": "🟡",
        "low": "🔵",
        "info": "⚪",
    }

    @staticmethod
    def format_audit_notification(
        tool_name: str,
        findings_by_severity: dict[str, list[dict]],
        severity_counts: dict[str, int],
        total_findings: int,
        files_examined: int,
        lens: str | None,
    ) -> dict:
        """Build Slack Block Kit payload for audit notification.

        Args:
            tool_name: Audit tool name (e.g., "security_audit")
            findings_by_severity: Findings grouped by severity level
            severity_counts: Count of findings per severity
            total_findings: Total number of findings
            files_examined: Number of files examined
            lens: Audit lens used (e.g., "backend", "comprehensive")

        Returns:
            Slack API payload dict with Block Kit blocks
        """
        audit_label = SlackMessageFormatter._get_audit_label(tool_name)
        emoji = SlackMessageFormatter.AUDIT_EMOJIS.get(tool_name, "📋")

        blocks = []

        blocks.append({
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"{emoji} {audit_label} Complete",
            }
        })

        blocks.append({"type": "divider"})

        severity_text = SlackMessageFormatter._build_severity_summary(severity_counts)
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": severity_text,
            }
        })

        blocks.append({"type": "divider"})

        top_findings_text = SlackMessageFormatter._build_top_findings(
            findings_by_severity,
            total_findings
        )
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": top_findings_text,
            }
        })

        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lens_display = lens.title() if lens else "Comprehensive"
        context_text = (
            f"📋 {total_findings} findings | {files_examined} files examined | "
            f"Lens: {lens_display} | {timestamp}"
        )
        blocks.append({
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": context_text,
                }
            ]
        })

        fallback_text = (
            f"{audit_label} complete: {total_findings} findings "
            f"({files_examined} files examined)"
        )

        return {
            "blocks": blocks,
            "text": fallback_text,
        }

    @staticmethod
    def _get_audit_label(tool_name: str) -> str:
        """Get human-readable audit label from tool name."""
        labels = {
            "security_audit": "Security Audit",
            "a11y_audit": "Accessibility Audit",
            "devops_audit": "DevOps Audit",
            "principal_audit": "Principal Audit",
        }
        return labels.get(tool_name, tool_name.replace("_", " ").title())

    @staticmethod
    def _build_severity_summary(severity_counts: dict[str, int]) -> str:
        """Build severity breakdown text with emojis."""
        severity_order = ["critical", "high", "medium", "low", "info"]
        parts = []

        for severity in severity_order:
            count = severity_counts.get(severity, 0)
            emoji = SlackMessageFormatter.SEVERITY_EMOJIS.get(severity, "•")
            label = severity.title()
            parts.append(f"{emoji} {label}: {count}")

        return "  ".join(parts)

    @staticmethod
    def _build_top_findings(
        findings_by_severity: dict[str, list[dict]],
        total_findings: int
    ) -> str:
        """Build top findings summary (max 5 findings)."""
        severity_order = ["critical", "high", "medium", "low", "info"]
        top_findings = []

        for severity in severity_order:
            findings = findings_by_severity.get(severity, [])
            for finding in findings:
                if len(top_findings) >= 5:
                    break
                top_findings.append((severity, finding))
            if len(top_findings) >= 5:
                break

        if not top_findings:
            return "*No findings to display*"

        lines = ["*Top Findings:*"]
        for severity, finding in top_findings:
            severity_upper = severity.upper()
            description = finding.get("description", "No description")
            affected_files = finding.get("affected_files", [])

            if isinstance(affected_files, list) and affected_files:
                if isinstance(affected_files[0], dict):
                    file_path = affected_files[0].get("file_path", "unknown")
                else:
                    file_path = str(affected_files[0])
            else:
                file_path = "unknown"

            description_truncated = (
                description[:80] + "..." if len(description) > 80 else description
            )
            lines.append(f"• *[{severity_upper}]* {description_truncated} in `{file_path}`")

        remaining = total_findings - len(top_findings)
        if remaining > 0:
            lines.append(f"\n_... and {remaining} more findings_")

        return "\n".join(lines)
