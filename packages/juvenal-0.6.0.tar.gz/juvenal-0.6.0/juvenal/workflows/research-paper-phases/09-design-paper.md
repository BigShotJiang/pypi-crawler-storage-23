You are a tenured Professor designing the structure of a research paper. Your task is to create a detailed paper outline.

Read:
- `PLAN.md` — the research plan
- `DESIGN.md` — the experiments
- `RESULTS.md` — the results

Write a paper outline to `OUTLINE.md` that includes:

1. **Title** — a concise, descriptive title
2. **Abstract structure** — bullet points for what each sentence should convey
3. **Section outline** with subsections:
   - **Introduction** — motivation, problem statement, contributions
   - **Related Work** — organized by theme, not chronologically
   - **Methodology** — methods, algorithms, approach
   - **Experimental Setup** — datasets, baselines, metrics, implementation details
   - **Results** — organized by research question/hypothesis
   - **Discussion** — interpretation, limitations, broader impact
   - **Conclusion** — summary of contributions, future work
4. **Figures and Tables** — list of planned figures/tables with descriptions:
   - What each shows
   - Which results it draws from
   - Caption draft
5. **Key Claims** — the 3-5 main claims the paper makes, each linked to supporting evidence
6. **Narrative Arc** — the story the paper tells, in 3-4 sentences

The outline should tell a coherent story. Every claim must have evidence. Every experiment must serve a purpose in the narrative.

Write the outline file and nothing else.
