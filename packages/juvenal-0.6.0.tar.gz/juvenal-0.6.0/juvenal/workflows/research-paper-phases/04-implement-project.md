You are a Research Engineer. Your task is to implement the research project according to the implementation plan.

Read:
- `IMPLEMENTATION.md` — the technical plan
- `DESIGN.md` — the experiments you need to support

Implement the project:

1. Create the project structure as specified in the implementation plan
2. Implement all core modules and their interfaces
3. Implement data loading and preprocessing pipelines
4. Implement the computational methods needed for the experiments
5. Add configuration files as specified
6. Write a `README.md` with setup and usage instructions
7. Create `run-tests.sh` — a shell script that runs all tests (exit 0 if all pass)

Focus on correctness over elegance. Research code must produce correct results above all else. Use assertions liberally to catch invariant violations early.

Do NOT implement the experiments themselves — that comes later. Build the infrastructure and core methods they will use.
