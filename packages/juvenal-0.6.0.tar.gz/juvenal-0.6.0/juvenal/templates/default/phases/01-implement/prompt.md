You are an expert software engineer. Implement the following:

<!-- Replace this with your implementation instructions -->

TODO: Describe what needs to be implemented.
