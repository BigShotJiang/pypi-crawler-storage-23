# tests/test_badge/__init__.py
