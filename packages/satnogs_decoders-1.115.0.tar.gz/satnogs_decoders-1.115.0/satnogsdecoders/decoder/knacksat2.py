# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Knacksat2(KaitaiStruct):
    """:field dest_callsign: id1.id2.ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field src_callsign: id1.id2.ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field src_ssid: id1.id2.ax25_frame.ax25_header.src_ssid_raw.ssid
    :field dest_ssid: id1.id2.ax25_frame.ax25_header.dest_ssid_raw.ssid
    :field ctl: id1.id2.ax25_frame.ax25_header.ctl
    :field pid: id1.id2.ax25_frame.payload.pid
    :field pcdu_en: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.pcdu.enable
    :field mppt_r1: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.res.res_1
    :field mppt_r2: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.res.res_2
    :field mppt_r3: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.res.res_3
    :field mppt_power: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.power
    :field mppt_vbus: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.vbus
    :field mppt_isens: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.solar.mppt.isens
    :field batt_r1: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.res.res_1
    :field batt_r2: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.res.res_2
    :field batt_r3: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.res.res_3
    :field batt_heater_cnt: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.heater_cnt
    :field batt_vout: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.vout
    :field batt_iout: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.iout
    :field batt_vin: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.vin
    :field batt_iin: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.iin
    :field batt_temp: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.battery.temperature
    :field status_1: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.antenna.isis_ant
    :field status_2: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.antenna.lora_ant
    :field obc_r1: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.obc.res.res_1
    :field obc_r2: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.obc.res.res_2
    :field obc_r3: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.obc.res.res_3
    :field ident: id1.id2.ax25_frame.ax25_payload.csp_data.tm_data.identify
    :field digi_dest_callsign: id1.id2.ax25frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field digi_src_callsign: id1.id2.ax25frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field digi_src_ssid: id1.id2.ax25frame.ax25_header.src_ssid_raw.ssid
    :field digi_dest_ssid: id1.id2.ax25frame.ax25_header.dest_ssid_raw.ssid
    :field rpt_instance___callsign: id1.id2.ax25frame.ax25_header.repeater.rpt_instance.___.rpt_callsign_raw.callsign_ror.callsign
    :field rpt_instance___ssid: id1.id2.ax25frame.ax25_header.repeater.rpt_instance.___.rpt_ssid_raw.ssid
    :field rpt_instance___hbit: id1.id2.ax25frame.ax25_header.repeater.rpt_instance.___.rpt_ssid_raw.hbit
    :field digi_ctl: id1.id2.ax25frame.ax25_header.ctl
    :field digi_pid: id1.id2.ax25frame.ax25_header.pid
    :field digi_message: id1.id2.ax25frame.digi_message
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.id1 = Knacksat2.Type1(self._io, self, self._root)

    class Type1(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            _on = self.message_type1
            if _on == 2426822786:
                self.id2 = Knacksat2.Telemetry(self._io, self, self._root)
            else:
                self.id2 = Knacksat2.Digi(self._io, self, self._root)

        @property
        def message_type1(self):
            """KNACKSAT-2 Telemetry validation
            """
            if hasattr(self, '_m_message_type1'):
                return self._m_message_type1

            _pos = self._io.pos()
            self._io.seek(0)
            self._m_message_type1 = self._io.read_u4be()
            self._io.seek(_pos)
            if not self.message_type1 == 2426822786:
                raise kaitaistruct.ValidationNotEqualError(2426822786, self.message_type1, self._io, u"/types/type1/instances/message_type1")
            return getattr(self, '_m_message_type1', None)


    class Telemetry(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_frame = Knacksat2.Telemetry.Ax25Frame(self._io, self, self._root)

        class Ax25Frame(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.ax25_header = Knacksat2.Telemetry.Ax25Header(self._io, self, self._root)
                self.ax25_payload = Knacksat2.Telemetry.Ax25Payload(self._io, self, self._root)


        class Ax25Payload(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.csp_data = Knacksat2.Telemetry.CspDataT(self._io, self, self._root)


        class Ax25Header(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.dest_callsign_raw = Knacksat2.Telemetry.CallsignRaw(self._io, self, self._root)
                self.dest_ssid_raw = Knacksat2.Telemetry.SsidMask(self._io, self, self._root)
                self.src_callsign_raw = Knacksat2.Telemetry.CallsignRaw(self._io, self, self._root)
                self.src_ssid_raw = Knacksat2.Telemetry.SsidMask(self._io, self, self._root)
                self.ctl = self._io.read_u1()
                self.pid = self._io.read_u1()


        class Callsign(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")


        class ResT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.csp_flags = []
                for i in range(5):
                    self.csp_flags.append(self._io.read_u1())


            @property
            def source(self):
                if hasattr(self, '_m_source'):
                    return self._m_source

                self._m_source = ((self.csp_flags[3] >> 1) & 31)
                return getattr(self, '_m_source', None)

            @property
            def res_1(self):
                if hasattr(self, '_m_res_1'):
                    return self._m_res_1

                self._m_res_1 = self.csp_flags[0]
                return getattr(self, '_m_res_1', None)

            @property
            def rdp(self):
                if hasattr(self, '_m_rdp'):
                    return self._m_rdp

                self._m_rdp = ((self.csp_flags[0] >> 1) & 1)
                return getattr(self, '_m_rdp', None)

            @property
            def src_port(self):
                if hasattr(self, '_m_src_port'):
                    return self._m_src_port

                self._m_src_port = (self.csp_flags[1] & 63)
                return getattr(self, '_m_src_port', None)

            @property
            def destination(self):
                if hasattr(self, '_m_destination'):
                    return self._m_destination

                self._m_destination = (((self.csp_flags[2] | (self.csp_flags[3] << 8)) >> 4) & 31)
                return getattr(self, '_m_destination', None)

            @property
            def res_3(self):
                if hasattr(self, '_m_res_3'):
                    return self._m_res_3

                self._m_res_3 = ((self.csp_flags[3] << 8) | self.csp_flags[4])
                return getattr(self, '_m_res_3', None)

            @property
            def dst_port(self):
                if hasattr(self, '_m_dst_port'):
                    return self._m_dst_port

                self._m_dst_port = (((self.csp_flags[1] | (self.csp_flags[2] << 8)) >> 6) & 63)
                return getattr(self, '_m_dst_port', None)

            @property
            def priority(self):
                if hasattr(self, '_m_priority'):
                    return self._m_priority

                self._m_priority = (self.csp_flags[3] >> 6)
                return getattr(self, '_m_priority', None)

            @property
            def reserved(self):
                if hasattr(self, '_m_reserved'):
                    return self._m_reserved

                self._m_reserved = (self.csp_flags[0] >> 4)
                return getattr(self, '_m_reserved', None)

            @property
            def res_2(self):
                if hasattr(self, '_m_res_2'):
                    return self._m_res_2

                self._m_res_2 = ((self.csp_flags[1] << 8) | self.csp_flags[2])
                return getattr(self, '_m_res_2', None)

            @property
            def xtea(self):
                if hasattr(self, '_m_xtea'):
                    return self._m_xtea

                self._m_xtea = ((self.csp_flags[0] >> 2) & 1)
                return getattr(self, '_m_xtea', None)

            @property
            def hmac(self):
                if hasattr(self, '_m_hmac'):
                    return self._m_hmac

                self._m_hmac = ((self.csp_flags[0] >> 3) & 1)
                return getattr(self, '_m_hmac', None)

            @property
            def crc(self):
                if hasattr(self, '_m_crc'):
                    return self._m_crc

                self._m_crc = (self.csp_flags[0] & 1)
                return getattr(self, '_m_crc', None)


        class PcduT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.res = Knacksat2.Telemetry.ResT(self._io, self, self._root)
                self.enable = self._io.read_u1()


        class CspDataT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.tm_data = Knacksat2.Telemetry.TmDataT(self._io, self, self._root)


        class CommT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.res = Knacksat2.Telemetry.ResT(self._io, self, self._root)


        class SsidMask(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.ssid_mask = self._io.read_u1()

            @property
            def ssid(self):
                if hasattr(self, '_m_ssid'):
                    return self._m_ssid

                self._m_ssid = ((self.ssid_mask & 31) >> 1)
                return getattr(self, '_m_ssid', None)


        class ObcT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.res = Knacksat2.Telemetry.ResT(self._io, self, self._root)


        class TmDataT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.pcdu = Knacksat2.Telemetry.PcduT(self._io, self, self._root)
                self.comm = Knacksat2.Telemetry.CommT(self._io, self, self._root)
                self.solar = Knacksat2.Telemetry.SolarT(self._io, self, self._root)
                self.battery = Knacksat2.Telemetry.BatteryT(self._io, self, self._root)
                self.antenna = Knacksat2.Telemetry.AntennaT(self._io, self, self._root)
                self.obc = Knacksat2.Telemetry.ObcT(self._io, self, self._root)
                self.identify = (self._io.read_bytes(3)).decode(u"ascii")


        class SolarT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.mppt = Knacksat2.Telemetry.MpptT(self._io, self, self._root)


        class AntennaT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.antenna_status = []
                for i in range(2):
                    self.antenna_status.append(self._io.read_u1())


            @property
            def isis_ant(self):
                if hasattr(self, '_m_isis_ant'):
                    return self._m_isis_ant

                self._m_isis_ant = self.antenna_status[0]
                return getattr(self, '_m_isis_ant', None)

            @property
            def lora_ant(self):
                if hasattr(self, '_m_lora_ant'):
                    return self._m_lora_ant

                self._m_lora_ant = self.antenna_status[1]
                return getattr(self, '_m_lora_ant', None)


        class CallsignRaw(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self._raw__raw_callsign_ror = self._io.read_bytes(6)
                self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
                _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
                self.callsign_ror = Knacksat2.Telemetry.Callsign(_io__raw_callsign_ror, self, self._root)


        class MpptT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.res = Knacksat2.Telemetry.ResT(self._io, self, self._root)
                self.isens = []
                for i in range(7):
                    self.isens.append(self._io.read_f4le())

                self.power = []
                for i in range(7):
                    self.power.append(self._io.read_f4le())

                self.vbus = []
                for i in range(7):
                    self.vbus.append(self._io.read_f4le())



        class BatteryT(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.res = Knacksat2.Telemetry.ResT(self._io, self, self._root)
                self.heater_cnt = self._io.read_u2le()
                self.temperature = []
                for i in range(4):
                    self.temperature.append(self._io.read_f4le())

                self.vout = self._io.read_f4le()
                self.iout = self._io.read_f4le()
                self.vin = self._io.read_f4le()
                self.iin = self._io.read_f4le()



    class Digi(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25frame = Knacksat2.Digi.Ax25frame(self._io, self, self._root)

        class Ax25Header(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.dest_callsign_raw = Knacksat2.Digi.CallsignRaw(self._io, self, self._root)
                self.dest_ssid_raw = Knacksat2.Digi.SsidMask(self._io, self, self._root)
                self.src_callsign_raw = Knacksat2.Digi.CallsignRaw(self._io, self, self._root)
                self.src_ssid_raw = Knacksat2.Digi.SsidMask(self._io, self, self._root)
                if (self.src_ssid_raw.ssid_mask & 1) == 0:
                    self.repeater = Knacksat2.Digi.Repeater(self._io, self, self._root)

                self.ctl = self._io.read_u1()
                self.pid = self._io.read_u1()


        class Callsign(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")


        class Ax25frame(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.ax25_header = Knacksat2.Digi.Ax25Header(self._io, self, self._root)
                self.digi_message = (self._io.read_bytes_full()).decode(u"utf-8")


        class SsidMask(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.ssid_mask = self._io.read_u1()

            @property
            def ssid(self):
                if hasattr(self, '_m_ssid'):
                    return self._m_ssid

                self._m_ssid = ((self.ssid_mask & 31) >> 1)
                return getattr(self, '_m_ssid', None)

            @property
            def hbit(self):
                if hasattr(self, '_m_hbit'):
                    return self._m_hbit

                self._m_hbit = ((self.ssid_mask & 128) >> 7)
                return getattr(self, '_m_hbit', None)


        class Repeaters(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.rpt_callsign_raw = Knacksat2.Digi.CallsignRaw(self._io, self, self._root)
                self.rpt_ssid_raw = Knacksat2.Digi.SsidMask(self._io, self, self._root)


        class Repeater(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.rpt_instance = []
                i = 0
                while True:
                    _ = Knacksat2.Digi.Repeaters(self._io, self, self._root)
                    self.rpt_instance.append(_)
                    if (_.rpt_ssid_raw.ssid_mask & 1) == 1:
                        break
                    i += 1


        class CallsignRaw(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self._raw__raw_callsign_ror = self._io.read_bytes(6)
                self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
                _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
                self.callsign_ror = Knacksat2.Digi.Callsign(_io__raw_callsign_ror, self, self._root)




