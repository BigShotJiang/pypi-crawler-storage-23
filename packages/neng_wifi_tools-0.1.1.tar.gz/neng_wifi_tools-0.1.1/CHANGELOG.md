# Changelog

All notable changes to **neng-wifi-tools** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] — 2026-02-23

## [0.1.0] — 2026-02-22

### Added in v0.1.0

- Initial extraction of WiFi/OTA modules from monorepo subprojects.
- `device_scanner` — Fast network scanner for NEnG instruments on SCPI port 5025 with configurable timeouts and subnet auto-detection.
- `wifi_config_gui` — Professional WiFi Configuration GUI (tkinter) for CircuitPython devices with live status display, credentials management, and per-device SSID/password entry.
- `ota_client` — OTA firmware update client with git-aware deployment, file diffing, progress tracking, and selective file synchronization.
- `ota_manager_gui` — OTA Firmware Update Manager GUI (tkinter) with multi-device management, batch updates, device discovery, and real-time progress.
- CLI entry points: `wifi-config-gui`, `neng-device-scan`, `update-firmware`, `ota-manager-gui`.
- Generalized `verify_neng_device()` — accepts any non-empty `*IDN?` response (not limited to TMP117).
- Pluggable integration with `neng-scpi-tools` for WiFi auto-detect in `scpi_client`.
- Unit tests for all module imports, class methods, and source-level invariants.
- CI/CD pipeline (`.gitlab-ci.yml`) with lint → test → build → publish stages.
- Release automation (`release.sh`) for GitLab Package Registry and optional PyPI.

[Unreleased]: https://gitlab.flavio.be/flavio/neng-wifi-tools/-/compare/v0.1.1...HEAD
[0.1.1]: https://gitlab.flavio.be/flavio/neng-wifi-tools/-/compare/v0.1.0...v0.1.1[0.1.0]: https://gitlab.flavio.be/flavio/neng-wifi-tools/-/releases/v0.1.0
