# neng-wifi-tools

WiFi configuration, OTA firmware updates, and device scanning for NEnG instruments.

## Overview

This package provides **WiFi and OTA management tools** used by NEnG subproject
GUIs (primarily temp-logger, but available to all subprojects):

| Module | Description |
| ------ | ----------- |
| `neng_wifi_tools.device_scanner` | Fast network scanner for NEnG instruments on SCPI port 5025 |
| `neng_wifi_tools.wifi_config_gui` | Professional WiFi Configuration GUI (tkinter) |
| `neng_wifi_tools.ota_client` | OTA firmware update client with git-aware deployment |
| `neng_wifi_tools.ota_manager_gui` | OTA Firmware Update Manager GUI (tkinter) |

## CLI Entry Points

| Command | Description |
| ------- | ----------- |
| `wifi-config-gui` | Launch the WiFi Configuration GUI |
| `neng-device-scan` | Scan the local network for NEnG instruments |
| `update-firmware` | OTA firmware update from the command line |
| `ota-manager-gui` | Launch the OTA Firmware Update Manager GUI |

## Installation

### For development (editable, from monorepo root)

```bash
pip install -e neng-scpi-tools/    # dependency
pip install -e neng-wifi-tools/
```

### As a dependency of a subproject

```bash
# Install the shared tools + the subproject together
pip install -e neng-scpi-tools/
pip install -e neng-wifi-tools/
pip install -e TMP117/Python/temp-logger/
```

## Usage

```python
from neng_wifi_tools.device_scanner import scan_for_devices
from neng_wifi_tools.wifi_config_gui import WiFiConfigGUI
from neng_wifi_tools.ota_client import OTAClient
from neng_wifi_tools.ota_manager_gui import OTAManagerGUI
```

### Quick device scan

```bash
neng-device-scan                   # scan default subnet
neng-device-scan --subnet 10.0.0   # scan custom subnet
neng-device-scan --timeout 0.5     # faster scan, shorter timeout
```

## Architecture

This package is the **single source of truth** for WiFi/OTA code shared across
NEnG subprojects. It depends on `neng-scpi-tools` for the underlying serial/WiFi
communication layer.

```txt
neng-controllers-platform/
├── neng-scpi-tools/          ← serial/WiFi communication (shared)
├── neng-wifi-tools/          ← THIS PACKAGE (WiFi config + OTA)
│   └── src/neng_wifi_tools/
│       ├── device_scanner.py
│       ├── wifi_config_gui.py
│       ├── ota_client.py
│       └── ota_manager_gui.py
├── TMP117/Python/temp-logger/     ← depends on neng-wifi-tools
├── BTS7960/Python/bts7960-gui/    ← depends on neng-scpi-tools
└── ...
```

## Dependencies

- `neng-scpi-tools` — shared SCPI serial/WiFi communication layer
- `pyserial>=3.5` — serial port access

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
