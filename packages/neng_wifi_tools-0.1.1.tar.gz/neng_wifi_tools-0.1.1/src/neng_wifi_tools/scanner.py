"""Entry point for the ``neng-device-scan`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .device_scanner import main as scanner_main


def main() -> int:
    """Launch the NEnG device scanner."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"neng-device-scan {__version__}")
        return 0
    return scanner_main()


if __name__ == "__main__":
    sys.exit(main())
