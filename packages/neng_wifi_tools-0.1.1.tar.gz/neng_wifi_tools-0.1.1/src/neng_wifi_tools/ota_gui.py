"""Entry point for the ``ota-manager-gui`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys
import tkinter as tk

from . import __version__
from .ota_manager_gui import OTAManagerGUI


def main() -> None:
    """Launch the OTA Firmware Manager GUI."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"ota-manager-gui {__version__}")
        return
    root = tk.Tk()
    OTAManagerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
