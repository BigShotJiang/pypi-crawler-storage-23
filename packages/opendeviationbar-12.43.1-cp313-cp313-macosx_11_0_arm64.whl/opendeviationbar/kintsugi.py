# FILE-SIZE-OK: Cohesive reconciliation engine (discover/repair/verify)
"""Kintsugi: Self-healing gap reconciliation for the ClickHouse cache (Issue #115).

Named after the Japanese art of repairing broken pottery with gold lacquer
(金継ぎ). Interior gaps ("shards") in the cache are discovered and repaired
autonomously, making the dataset stronger than before.

**Every repair uses Ariadne + Ouroboros by default.**  Ariadne's fromId cursor
pagination eliminates trade drops at millisecond boundaries.  Ouroboros
boundary-aware splits prevent processor state bleed across reset points.

Architecture
------------
::

    detect_gaps.py --json  →  discover_shards()  →  classify → repair → verify
                                                         │
                         ┌───────────────────────────────┘
                         ▼
              P0/P1: backfill_recent()     (now Ariadne-native, Phase 2)
              P2:    populate_cache_resumable()  (already Ariadne-native)

Usage
-----
Single pass::

    >>> from opendeviationbar.kintsugi import kintsugi_pass
    >>> results = kintsugi_pass()

Daemon mode::

    >>> from opendeviationbar.kintsugi import kintsugi_daemon
    >>> kintsugi_daemon()  # Long-running, adaptive polling
"""

from __future__ import annotations

import json
import logging
import os
import socket as _socket
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# NDJSON telemetry (persists independently of ClickHouse)
# ---------------------------------------------------------------------------

_KINTSUGI_LOG_DIR = Path.home() / "opendeviationbar-py" / "logs"
_KINTSUGI_NDJSON = _KINTSUGI_LOG_DIR / "kintsugi.ndjson"
_KINTSUGI_NDJSON_MAX_BYTES = 10 * 1024 * 1024  # 10 MB


def _emit_telemetry(event: str, **fields: object) -> None:
    """Append structured NDJSON telemetry line to kintsugi.ndjson.

    Persists independently of ClickHouse — survives tunnel drops.
    Rotates at 10 MB, keeping one backup (.ndjson.1).
    """
    try:
        _KINTSUGI_LOG_DIR.mkdir(parents=True, exist_ok=True)
        # Rotate if >10 MB
        if (
            _KINTSUGI_NDJSON.exists()
            and _KINTSUGI_NDJSON.stat().st_size > _KINTSUGI_NDJSON_MAX_BYTES
        ):
            rotated = _KINTSUGI_NDJSON.with_suffix(".ndjson.1")
            rotated.unlink(missing_ok=True)
            _KINTSUGI_NDJSON.rename(rotated)
        record = {
            "ts": datetime.now(UTC).isoformat(),
            "pid": os.getpid(),
            "event": event,
            **fields,
        }
        with _KINTSUGI_NDJSON.open("a") as f:
            f.write(json.dumps(record, default=str) + "\n")
    except OSError:
        pass  # Best-effort — never crash kintsugi for telemetry


def _sd_notify(state: str) -> None:
    """Send sd_notify message to systemd (if NOTIFY_SOCKET is set).

    This is a minimal implementation — no external dependency needed.
    Used for WatchdogSec integration (Issue #117).
    """
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return
    try:
        sock = _socket.socket(_socket.AF_UNIX, _socket.SOCK_DGRAM)
        try:
            if addr.startswith("@"):
                addr = "\0" + addr[1:]
            sock.sendto(state.encode(), addr)
        finally:
            sock.close()
    except OSError:
        logger.debug("sd_notify(%s) failed", state, exc_info=True)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_P1_THRESHOLD_HOURS = 48.0  # Recent gap boundary
_MEGA_GAP_THRESHOLD_HOURS = 168.0  # 7 days — force P2 (Vision path) for large gaps
_MAX_P2_GAP_HOURS = 720.0  # 30 days — skip P2 repairs beyond this (manual backfill)
_MAX_ATTEMPTS_PER_SHARD = 3  # Per 24h, tracked in kintsugi_log
_DEFAULT_MAX_P2_JOBS = 1
_DETECT_GAPS_EXIT_ERROR = 2  # detect_gaps.py connection/query failure
_MIN_DEAD_LETTER_PARTS = 3  # symbol_threshold_timestamp
_MAX_FAILURES_IN_ALERT = 5  # Max failures shown in Telegram alert
_STALE_P1_DAYS = 14  # P1 gaps older than this → P2 (prevents futile REST backfill)

# Symbols that get bandwidth priority when multiple gaps compete.
# BTCUSDT is the primary trading pair — its recency is non-negotiable.
_PRIORITY_SYMBOLS = ("BTCUSDT",)

# Transient error patterns — don't count toward max attempts (Issue #156)
_TRANSIENT_ERROR_PATTERNS = (
    "timeout",
    "connection",
    "rate limit",
    "503",
    "502",
    "500",
    "network",
    "timed out",
    "reset by peer",
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class Shard:
    """A gap in the data timeline — a broken shard to be repaired with gold."""

    symbol: str
    threshold_decimal_bps: int
    gap_start_ms: int
    gap_end_ms: int
    gap_hours: float
    priority: str  # "P0", "P1", "P2"
    last_agg_trade_id_before: int | None = None  # Ariadne anchor
    ouroboros_boundaries: list[int] = field(default_factory=list)


@dataclass
class KintsugiResult:
    """Result of a single repair operation."""

    shard: Shard
    healed: bool
    bars_written: int
    duration_seconds: float
    ariadne_used: bool  # Always True unless first-ever backfill
    ouroboros_splits: int  # Number of boundary sub-repairs
    error: str | None = None


# ---------------------------------------------------------------------------
# Shard discovery
# ---------------------------------------------------------------------------


def discover_shards(
    *,
    min_gap_hours: float = 6.0,
    max_stale_hours: float = 72.0,
    symbol: str | None = None,
    threshold: int | None = None,
) -> list[Shard]:
    """Discover shards by running ``detect_gaps.py --json`` as subprocess.

    For each gap, queries ``last_agg_trade_id`` from the bar before the gap
    (Ariadne anchor) and computes Ouroboros boundaries within the gap.
    """
    cmd = [
        sys.executable,
        "-W",
        "ignore",
        "scripts/detect_gaps.py",
        "--json",
        "--min-gap-hours",
        str(min_gap_hours),
        "--max-stale-hours",
        str(max_stale_hours),
    ]
    if symbol:
        cmd.extend(["--symbol", symbol])
    if threshold:
        cmd.extend(["--threshold", str(threshold)])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired:
        logger.exception("detect_gaps.py timed out after 120s")
        return []

    if result.returncode == _DETECT_GAPS_EXIT_ERROR:
        logger.error(
            "detect_gaps.py connection error: %s",
            result.stderr.strip(),
        )
        return []

    # Parse JSON output (exit code 0 = clean, 1 = gaps found)
    try:
        data = json.loads(result.stdout)
    except (json.JSONDecodeError, ValueError):
        logger.exception("failed to parse detect_gaps.py JSON output")
        return []

    raw_gaps = data.get("gaps", [])
    raw_stale = data.get("stale_pairs", [])

    shards: list[Shard] = []

    # Convert temporal gaps to shards
    for g in raw_gaps:
        if g.get("gap_type") not in ("temporal", "both"):
            continue
        shard = Shard(
            symbol=g["symbol"],
            threshold_decimal_bps=g["threshold_dbps"],
            gap_start_ms=g["gap_start_ms"],
            gap_end_ms=g["gap_end_ms"],
            gap_hours=g["gap_hours"],
            priority=classify_shard_priority(g["gap_hours"]),
        )
        shards.append(shard)

    # Convert stale pairs to P0 shards
    for s in raw_stale:
        shard = Shard(
            symbol=s["symbol"],
            threshold_decimal_bps=s["threshold_dbps"],
            gap_start_ms=0,  # Will be resolved by backfill_recent
            gap_end_ms=int(time.time() * 1000),
            gap_hours=s["hours_since_last_bar"],
            priority="P0",
        )
        shards.append(shard)

    # Issue #156: Reclassify mega-gaps to P2 and enrich
    _reclassify_mega_gaps(shards)

    # Reclassify ancient P1 gaps to P2 (prevents futile REST backfill)
    _reclassify_stale_p1_to_p2(shards)

    # Enrich with Ariadne anchors and Ouroboros boundaries
    _enrich_shards(shards)

    # Issue #117-119: Emit GAP_DETECTED hook for each shard
    if shards:
        try:
            from opendeviationbar.hooks import HookEvent, emit_hook

            for shard in shards:
                emit_hook(
                    HookEvent.GAP_DETECTED,
                    symbol=shard.symbol,
                    threshold_dbps=shard.threshold_decimal_bps,
                    gap_hours=shard.gap_hours,
                    priority=shard.priority,
                )
        except (ImportError, OSError, RuntimeError, ValueError):
            logger.debug("failed to emit GAP_DETECTED hooks", exc_info=True)

    return shards


def classify_shard_priority(gap_hours: float) -> str:
    """Classify gap into P0 (staleness), P1 (<48h), P2 (>=48h)."""
    if gap_hours < _P1_THRESHOLD_HOURS:
        return "P1"
    return "P2"


def _is_transient_error(error_message: str) -> bool:
    """Check if an error message indicates a transient (retriable) failure.

    Transient errors (network, timeout, rate limit, server errors) should
    not count toward the per-shard max attempt limit (Issue #156).
    """
    lower = error_message.lower()
    return any(pattern in lower for pattern in _TRANSIENT_ERROR_PATTERNS)


# Priority rank for sorting — lower value = higher priority.
_PRIORITY_RANK = {"P0": 0, "P1": 1, "P2": 2}


def _shard_sort_key(shard: Shard) -> tuple[int, int, int]:
    """Sort key: recency first, then BTCUSDT priority, then tier.

    Most-recent gaps are repaired first regardless of priority tier.
    Among same-recency gaps, BTCUSDT (and other priority symbols) get
    bandwidth first.  Priority tier is a tiebreaker only.

    This ensures the live-trading gap (e.g. Dec 2025-Feb 2026 BTCUSDT)
    is repaired before ancient 2023 historical gaps, even if the ancient
    gaps are classified P1 and the recent gap is P2.
    """
    symbol_rank = 0 if shard.symbol in _PRIORITY_SYMBOLS else 1
    return (-shard.gap_end_ms, symbol_rank, _PRIORITY_RANK.get(shard.priority, 9))


def _select_repair_candidates(
    shards: list[Shard],
    max_p2_jobs: int,
) -> list[Shard]:
    """Select shards eligible for repair this pass.

    Applies two filters in order:
    1. **P2 budget**: At most ``max_p2_jobs`` P2 shards per pass.
    2. **Rate limit**: Skip shards with ≥3 non-transient attempts in 24h.

    Budget is only consumed for shards that pass *both* filters —
    a rate-limited P2 shard does not waste a ``max_p2_jobs`` slot.

    Returns the selected shards in their original (pre-sorted) order.
    """
    candidates: list[Shard] = []
    p2_budget = max_p2_jobs

    for shard in shards:
        # P2 budget gate
        if shard.priority == "P2" and p2_budget <= 0:
            logger.info(
                "skipping P2 shard %s@%d (max_p2_jobs=%d reached)",
                shard.symbol,
                shard.threshold_decimal_bps,
                max_p2_jobs,
            )
            continue

        # Rate limit gate (kintsugi_log: max 3 non-transient attempts/24h)
        if _is_rate_limited(shard):
            logger.info(
                "skipping %s@%d — rate limited (%d attempts in 24h)",
                shard.symbol,
                shard.threshold_decimal_bps,
                _MAX_ATTEMPTS_PER_SHARD,
            )
            continue

        # Both gates passed — consume budget and accept
        if shard.priority == "P2":
            p2_budget -= 1

        candidates.append(shard)

    return candidates


def _reclassify_mega_gaps(shards: list[Shard]) -> None:
    """Reclassify mega-gaps (>7 days) to P2 regardless of recency (Issue #156).

    P0/P1 use backfill_recent() (REST, 1000 trades/req) — Sisyphean for large gaps.
    P2 uses populate_cache_resumable() with day-by-day checkpoints + Vision archives.
    """
    for shard in shards:
        if shard.gap_hours > _MEGA_GAP_THRESHOLD_HOURS and shard.priority != "P2":
            logger.info(
                "reclassifying %s@%d from %s to P2 (gap=%.1fh > %dh mega-gap threshold)",
                shard.symbol,
                shard.threshold_decimal_bps,
                shard.priority,
                shard.gap_hours,
                int(_MEGA_GAP_THRESHOLD_HOURS),
            )
            shard.priority = "P2"


def _reclassify_stale_p1_to_p2(shards: list[Shard]) -> None:
    """Reclassify P1 gaps whose gap_end is older than 14 days to P2.

    P1 uses backfill_recent() (REST API, last 1000 trades) — useless for gaps
    that ended weeks/months/years ago.  P2 uses populate_cache_resumable()
    with Binance Vision archives, which can actually fetch old data.

    Without this, kintsugi spins endlessly on ancient P1 gaps (e.g. 2023
    low-vol periods at @250) that write 0 bars, burning bandwidth that
    should go to recent gaps.
    """
    now_ms = int(time.time() * 1000)
    cutoff_ms = now_ms - int(_STALE_P1_DAYS * 86400 * 1000)

    for shard in shards:
        if shard.priority == "P1" and shard.gap_end_ms < cutoff_ms:
            logger.info(
                "reclassifying %s@%d from P1 to P2 (gap_end %s is >%dd old)",
                shard.symbol,
                shard.threshold_decimal_bps,
                datetime.fromtimestamp(shard.gap_end_ms / 1000, tz=UTC).strftime(
                    "%Y-%m-%d"
                ),
                _STALE_P1_DAYS,
            )
            shard.priority = "P2"


def _enrich_shards(shards: list[Shard]) -> None:
    """Add Ariadne anchors and Ouroboros boundaries to shards."""
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.ouroboros import get_ouroboros_boundaries

    if not shards:
        return

    try:
        with OpenDeviationBarCache() as cache:
            for shard in shards:
                # Ariadne anchor: last_agg_trade_id before the gap
                hwm = cache.get_ariadne_high_water_mark(
                    shard.symbol,
                    shard.threshold_decimal_bps,
                )
                shard.last_agg_trade_id_before = hwm

                # Ouroboros boundaries within the gap
                if shard.gap_start_ms > 0 and shard.gap_end_ms > 0:
                    start_date = datetime.fromtimestamp(
                        shard.gap_start_ms / 1000,
                        tz=UTC,
                    ).date()
                    end_date = datetime.fromtimestamp(
                        shard.gap_end_ms / 1000,
                        tz=UTC,
                    ).date()
                    # Issue #126: resolve mode from config instead of hardcoding
                    from opendeviationbar.ouroboros import (
                        get_operational_ouroboros_mode,
                    )

                    boundaries = get_ouroboros_boundaries(
                        start_date,
                        end_date,
                        get_operational_ouroboros_mode(),
                    )
                    shard.ouroboros_boundaries = [b.timestamp_ms for b in boundaries]
    except (OSError, RuntimeError, ConnectionError) as e:
        logger.warning("failed to enrich shards: %s", e)


# ---------------------------------------------------------------------------
# Shard repair
# ---------------------------------------------------------------------------


def repair_shard(
    shard: Shard,
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> KintsugiResult:
    """Repair a single shard using Ariadne + Ouroboros.

    P0/P1 shards use ``backfill_recent()`` (now Ariadne-native).
    P2 shards use ``populate_cache_resumable()`` with per-boundary splits.
    """
    # Validate threshold before attempting repair — reject orphaned invalid data
    from opendeviationbar.threshold import resolve_and_validate_threshold

    try:
        resolve_and_validate_threshold(
            shard.symbol,
            shard.threshold_decimal_bps,
        )
    except ValueError:
        return KintsugiResult(
            shard=shard,
            healed=False,
            bars_written=0,
            duration_seconds=0.0,
            ariadne_used=False,
            ouroboros_splits=0,
            error=(
                f"threshold {shard.threshold_decimal_bps} dbps "
                f"below minimum for {shard.symbol}"
            ),
        )

    t0 = time.monotonic()
    total_bars = 0
    n_splits = max(len(shard.ouroboros_boundaries), 1)
    ariadne_used = shard.last_agg_trade_id_before is not None

    is_partial = False
    try:
        if shard.priority in ("P0", "P1"):
            total_bars = _repair_p0_p1(
                shard,
                include_microstructure=include_microstructure,
                verbose=verbose,
            )
        else:
            total_bars, is_partial = _repair_p2(
                shard,
                include_microstructure=include_microstructure,
                verbose=verbose,
            )
    except (OSError, RuntimeError, ConnectionError, ValueError) as e:
        elapsed = time.monotonic() - t0
        logger.exception(
            "repair failed for %s@%d (%s)",
            shard.symbol,
            shard.threshold_decimal_bps,
            shard.priority,
        )
        return KintsugiResult(
            shard=shard,
            healed=False,
            bars_written=0,
            duration_seconds=elapsed,
            ariadne_used=ariadne_used,
            ouroboros_splits=n_splits,
            error=str(e),
        )

    elapsed = time.monotonic() - t0
    # Partial repairs (progressive P2) are not "healed" — the remaining
    # segments are picked up on subsequent daemon passes.
    healed = total_bars > 0 and not is_partial

    state_label = "HEALED" if healed else "PARTIAL" if is_partial else "NO_BARS"
    logger.info(
        "repair %s for %s@%d: %d bars in %.1fs (ariadne=%s, splits=%d)",
        state_label,
        shard.symbol,
        shard.threshold_decimal_bps,
        total_bars,
        elapsed,
        ariadne_used,
        n_splits,
    )

    return KintsugiResult(
        shard=shard,
        healed=healed,
        bars_written=total_bars,
        duration_seconds=elapsed,
        ariadne_used=ariadne_used,
        ouroboros_splits=n_splits,
    )


def _repair_p0_p1(
    shard: Shard,
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> int:
    """Repair P0/P1 shard via backfill_recent() (Ariadne-native)."""
    from opendeviationbar.recency import backfill_recent

    result = backfill_recent(
        shard.symbol,
        shard.threshold_decimal_bps,
        include_microstructure=include_microstructure,
        verbose=verbose,
    )
    if result.error:
        msg = f"backfill_recent error: {result.error}"
        raise RuntimeError(msg)
    return result.bars_written


def _repair_p2(
    shard: Shard,
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> tuple[int, bool]:
    """Repair P2 shard via populate_cache_resumable() with Ouroboros splits.

    For gaps exceeding ``_MAX_P2_GAP_HOURS``, processes only the most recent
    Ouroboros segment per pass (progressive repair).  The daemon will discover
    the remaining gap on the next iteration and repair the next segment.

    Returns:
        (total_bars_written, is_partial) — partial=True when segments were clamped.
    """
    from opendeviationbar.checkpoint import populate_cache_resumable

    total_bars = 0

    # Split at Ouroboros boundaries (monthly by default)
    segments = _split_at_boundaries(shard)
    is_partial = False

    # For oversized gaps, process only the newest segment per pass.
    # The daemon re-discovers the remaining gap next iteration.
    if shard.gap_hours > _MAX_P2_GAP_HOURS and len(segments) > 1:
        logger.info(
            "progressive P2 repair for %s@%d: %.0fh gap, %d segments — "
            "processing newest segment only (remaining picked up next pass)",
            shard.symbol,
            shard.threshold_decimal_bps,
            shard.gap_hours,
            len(segments),
        )
        segments = segments[-1:]  # Most recent segment
        is_partial = True

    for seg_start, seg_end in segments:
        start_str = datetime.fromtimestamp(
            seg_start / 1000,
            tz=UTC,
        ).strftime("%Y-%m-%d")
        end_str = datetime.fromtimestamp(
            seg_end / 1000,
            tz=UTC,
        ).strftime("%Y-%m-%d")

        bars = populate_cache_resumable(
            shard.symbol,
            start_str,
            end_str,
            threshold_decimal_bps=shard.threshold_decimal_bps,
            include_microstructure=include_microstructure,
            verbose=verbose,
            notify=False,
        )
        total_bars += bars

    return total_bars, is_partial


def _split_at_boundaries(
    shard: Shard,
) -> list[tuple[int, int]]:
    """Split a shard's time range at Ouroboros boundaries.

    Returns list of (start_ms, end_ms) segments.
    """
    if not shard.ouroboros_boundaries:
        return [(shard.gap_start_ms, shard.gap_end_ms)]

    segments: list[tuple[int, int]] = []
    current_start = shard.gap_start_ms

    for boundary_ms in sorted(shard.ouroboros_boundaries):
        if current_start < boundary_ms < shard.gap_end_ms:
            segments.append((current_start, boundary_ms - 1))
            current_start = boundary_ms

    segments.append((current_start, shard.gap_end_ms))
    return segments


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------


def verify_repair(shard: Shard) -> bool:
    """Re-run gap detection for the specific pair to confirm gap is healed."""
    cmd = [
        sys.executable,
        "-W",
        "ignore",
        "scripts/detect_gaps.py",
        "--json",
        "--symbol",
        shard.symbol,
        "--threshold",
        str(shard.threshold_decimal_bps),
        "--min-gap-hours",
        str(max(shard.gap_hours * 0.5, 1.0)),
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
    except subprocess.TimeoutExpired:
        logger.warning(
            "verify_repair timed out for %s@%d",
            shard.symbol,
            shard.threshold_decimal_bps,
        )
        return False

    if result.returncode == 0:
        return True  # Clean — no gaps

    # Check if our specific gap still exists
    try:
        data = json.loads(result.stdout)
        for g in data.get("gaps", []):
            if (
                g.get("gap_start_ms") == shard.gap_start_ms
                and g.get("gap_end_ms") == shard.gap_end_ms
            ):
                return False  # Same gap still present
    except (json.JSONDecodeError, ValueError):
        return False

    return True  # Gap not found in results — healed


# ---------------------------------------------------------------------------
# Kintsugi log (ClickHouse)
# ---------------------------------------------------------------------------


def _maybe_log_repair(result: KintsugiResult) -> None:
    """Log repair result, skipping kintsugi_log for transient errors (Issue #156).

    Transient errors (network, timeout, 5xx) are not written to the kintsugi_log
    table, so they don't count toward the 3-attempt-per-24h rate limit.
    """
    if result.error and _is_transient_error(result.error):
        logger.info(
            "transient error for %s@%d — not counting toward attempt limit: %s",
            result.shard.symbol,
            result.shard.threshold_decimal_bps,
            result.error,
        )
        return
    _log_repair(result)


def _log_repair(result: KintsugiResult) -> None:
    """Write repair result to kintsugi_log ClickHouse table."""
    try:
        from opendeviationbar.clickhouse import OpenDeviationBarCache

        with OpenDeviationBarCache() as cache:
            cache.client.command(
                "INSERT INTO opendeviationbar_cache.kintsugi_log "
                "(symbol, threshold_decimal_bps, priority, "
                "gap_start_ms, gap_end_ms, gap_hours, "
                "action, result, ariadne_from_id, ouroboros_splits, "
                "bars_written, duration_seconds, error_message) "
                "VALUES "
                "({symbol:String}, {threshold:UInt32}, {priority:String}, "
                "{gap_start:Int64}, {gap_end:Int64}, {gap_hours:Float64}, "
                "{action:String}, {result:String}, {ariadne:Int64}, "
                "{splits:UInt8}, {bars:UInt32}, {duration:Float64}, "
                "{error:String})",
                parameters={
                    "symbol": result.shard.symbol,
                    "threshold": result.shard.threshold_decimal_bps,
                    "priority": result.shard.priority,
                    "gap_start": result.shard.gap_start_ms,
                    "gap_end": result.shard.gap_end_ms,
                    "gap_hours": result.shard.gap_hours,
                    "action": (
                        "backfill_recent"
                        if result.shard.priority in ("P0", "P1")
                        else "populate_cache"
                    ),
                    "result": (
                        "healed"
                        if result.healed
                        else "clean"
                        if not result.error
                        else "failed"
                    ),
                    "ariadne": (result.shard.last_agg_trade_id_before or 0),
                    "splits": result.ouroboros_splits,
                    "bars": result.bars_written,
                    "duration": result.duration_seconds,
                    "error": result.error or "",
                },
            )
    except (OSError, RuntimeError, ConnectionError) as e:
        logger.warning("failed to log kintsugi result: %s", e)


# ---------------------------------------------------------------------------
# Pass + daemon
# ---------------------------------------------------------------------------


def kintsugi_pass(
    *,
    dry_run: bool = False,
    symbol: str | None = None,
    max_p2_jobs: int = _DEFAULT_MAX_P2_JOBS,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> list[KintsugiResult]:
    """Single pass: discover shards, classify, repair, verify, log.

    Parameters
    ----------
    dry_run
        If True, discover and classify only — no repairs.
    symbol
        Filter to a specific symbol.
    max_p2_jobs
        Maximum concurrent P2 (historical) repairs per pass.
    include_microstructure
        Include microstructure features in repaired bars.
    verbose
        Enable detailed logging.

    Returns
    -------
    list[KintsugiResult]
        Results for each shard repaired (or discovered in dry_run).
    """
    pass_t0 = time.monotonic()
    logger.info("kintsugi pass starting (dry_run=%s)", dry_run)
    _emit_telemetry("pass_start", dry_run=dry_run)
    shards = discover_shards(symbol=symbol, min_gap_hours=24.0)

    p0 = sum(1 for s in shards if s.priority == "P0")
    p1 = sum(1 for s in shards if s.priority == "P1")
    p2 = sum(1 for s in shards if s.priority == "P2")

    if not shards:
        logger.info("kintsugi: no shards found — cache is clean")
        _emit_telemetry(
            "discovery_complete", total_shards=0, p0=0, p1=0, p2=0, min_gap_hours=24.0
        )
        return []

    # Sort: priority tier first, then most-recent gap_end first (Issue #157)
    shards.sort(key=_shard_sort_key)

    _emit_telemetry(
        "discovery_complete",
        total_shards=len(shards),
        p0=p0,
        p1=p1,
        p2=p2,
        min_gap_hours=24.0,
    )
    logger.info(
        "kintsugi: discovered %d shards (P0=%d, P1=%d, P2=%d)",
        len(shards),
        p0,
        p1,
        p2,
    )

    # Per-tier queue visibility (Issue #157)
    for tier in ("P0", "P1", "P2"):
        tier_shards = [s for s in shards if s.priority == tier]
        if tier_shards:
            first = tier_shards[0]
            logger.info(
                "  %s queue: %d shards, next=%s@%d gap_end=%s",
                tier,
                len(tier_shards),
                first.symbol,
                first.threshold_decimal_bps,
                datetime.fromtimestamp(first.gap_end_ms / 1000, tz=UTC).strftime(
                    "%Y-%m-%d"
                ),
            )

    if dry_run:
        for s in shards:
            logger.info(
                "  [DRY-RUN] %s %s@%d gap=%.1fh ariadne=%s ouro_splits=%d",
                s.priority,
                s.symbol,
                s.threshold_decimal_bps,
                s.gap_hours,
                s.last_agg_trade_id_before is not None,
                len(s.ouroboros_boundaries),
            )
        return []

    results: list[KintsugiResult] = []

    for shard in _select_repair_candidates(shards, max_p2_jobs):
        shard_label = f"{shard.symbol}@{shard.threshold_decimal_bps}"
        _emit_telemetry(
            "repair_start",
            symbol=shard.symbol,
            threshold=shard.threshold_decimal_bps,
            priority=shard.priority,
            gap_hours=shard.gap_hours,
            gap_end_ms=shard.gap_end_ms,
        )
        result = repair_shard(
            shard,
            include_microstructure=include_microstructure,
            verbose=verbose,
        )

        result_state = (
            "healed" if result.healed else "clean" if not result.error else "failed"
        )
        _emit_telemetry(
            "repair_complete",
            symbol=shard.symbol,
            threshold=shard.threshold_decimal_bps,
            result=result_state,
            bars_written=result.bars_written,
            duration_s=round(result.duration_seconds, 1),
            error=result.error,
        )

        # Ping watchdog after each repair to prevent timeout during long P2 repairs
        _sd_notify("WATCHDOG=1")
        _emit_telemetry("watchdog_ping", after_shard=shard_label)

        # Verify repair
        if result.healed:
            verified = verify_repair(shard)
            if not verified:
                logger.warning(
                    "repair for %s@%d reported healed but gap persists",
                    shard.symbol,
                    shard.threshold_decimal_bps,
                )
                result.healed = False
                result.error = (
                    f"verification failed: gap persists after writing "
                    f"{result.bars_written} bars"
                )

        _maybe_log_repair(result)
        results.append(result)

    # Summary (three-state: healed / clean / failed)
    pass_duration = time.monotonic() - pass_t0
    healed = sum(1 for r in results if r.healed)
    clean = sum(1 for r in results if not r.healed and not r.error)
    failed = sum(1 for r in results if r.error)
    total_bars = sum(r.bars_written for r in results)
    logger.info(
        "kintsugi pass complete: %d healed, %d clean, %d failed, %d bars written (%.1fs)",
        healed,
        clean,
        failed,
        total_bars,
        pass_duration,
    )
    _emit_telemetry(
        "pass_complete",
        healed=healed,
        clean=clean,
        failed=failed,
        total_bars=total_bars,
        duration_s=round(pass_duration, 1),
    )

    # Issue #117-119: Emit KINTSUGI_PASS_COMPLETE hook + quiet Telegram
    try:
        from opendeviationbar.hooks import HookEvent, emit_hook

        emit_hook(
            HookEvent.KINTSUGI_PASS_COMPLETE,
            symbol="*",
            n_discovered=len(shards),
            n_healed=healed,
            n_failed=failed,
            total_bars=total_bars,
            pass_duration=pass_duration,
        )
    except (ImportError, OSError, RuntimeError, ValueError):
        logger.debug("failed to emit KINTSUGI_PASS_COMPLETE hook", exc_info=True)
    try:
        from opendeviationbar.notify.telegram import _build_context_block, send_telegram

        # Per-tier queue status
        tier_summary = " | ".join(
            f"{tier}:{sum(1 for s in shards if s.priority == tier)}"
            for tier in ("P0", "P1", "P2")
            if any(s.priority == tier for s in shards)
        )
        pass_msg = (
            "<b>KINTSUGI PASS COMPLETE</b>\n"
            f"<b>Duration:</b> {pass_duration:.0f}s\n"
            f"<b>Shards discovered:</b> {len(shards)}\n"
            f"<b>Healed:</b> {healed} | <b>Clean:</b> {clean} | <b>Failed:</b> {failed}\n"
            f"<b>Bars written:</b> {total_bars:,}\n"
            f"<b>Queue:</b> {len(shards) - len(results)} remaining\n"
            f"<b>Tiers:</b> {tier_summary}" + _build_context_block("kintsugi")
        )
        send_telegram(pass_msg, disable_notification=True)
    except (ImportError, OSError, RuntimeError):
        logger.debug("failed to send kintsugi pass Telegram", exc_info=True)

    # Notify on real failures only (not "clean" results)
    if failed > 0:
        _notify_kintsugi_failures(results, pass_duration=pass_duration)

    return results


def _is_rate_limited(shard: Shard) -> bool:
    """Check if shard has exceeded max attempts in the last 24h."""
    try:
        from opendeviationbar.clickhouse import OpenDeviationBarCache

        with OpenDeviationBarCache() as cache:
            result = cache.client.query(
                "SELECT count() FROM opendeviationbar_cache.kintsugi_log "
                "WHERE symbol = {sym:String} "
                "  AND threshold_decimal_bps = {thr:UInt32} "
                "  AND gap_start_ms = {gs:Int64} "
                "  AND result != 'clean' "
                "  AND timestamp > now() - INTERVAL 24 HOUR",
                parameters={
                    "sym": shard.symbol,
                    "thr": shard.threshold_decimal_bps,
                    "gs": shard.gap_start_ms,
                },
            )
            count = result.result_rows[0][0] if result.result_rows else 0
    except (OSError, RuntimeError, ConnectionError):
        return False  # On error, allow repair attempt
    else:
        return count >= _MAX_ATTEMPTS_PER_SHARD


def _notify_kintsugi_failures(
    results: list[KintsugiResult],
    pass_duration: float = 0.0,
) -> None:
    """Send Telegram alert for failed repairs."""
    try:
        from opendeviationbar.notify.telegram import _build_context_block, send_telegram
    except ImportError:
        return

    failed = [r for r in results if r.error]
    if not failed:
        return

    healed_count = sum(1 for r in results if r.healed)
    total_shards = len(results)

    lines = [
        f"<b>KINTSUGI</b>: {len(failed)} repair(s) failed\n",
        f"<b>Pass duration:</b> {pass_duration:.1f}s",
        f"<b>Total shards:</b> {total_shards} "
        f"({healed_count} healed, {len(failed)} failed)",
    ]
    for r in failed[:_MAX_FAILURES_IN_ALERT]:
        lines.append(
            f"  {r.shard.symbol}@{r.shard.threshold_decimal_bps} "
            f"({r.shard.priority}, {r.shard.gap_hours:.1f}h): "
            f"<code>{r.error or 'unknown'}</code>"
        )
    if len(failed) > _MAX_FAILURES_IN_ALERT:
        lines.append(f"  ... and {len(failed) - _MAX_FAILURES_IN_ALERT} more")
    lines.append(_build_context_block("kintsugi"))

    try:
        send_telegram("\n".join(lines), disable_notification=False)
    except (OSError, RuntimeError, ConnectionError):
        logger.exception("failed to send kintsugi failure alert")


def kintsugi_daemon(
    *,
    interval_clean_s: int = 1800,
    interval_active_s: int = 900,
    max_p2_jobs: int = _DEFAULT_MAX_P2_JOBS,
    symbol: str | None = None,
    include_microstructure: bool = True,
) -> None:
    """Long-running daemon with adaptive polling.

    Runs ``kintsugi_pass()`` repeatedly:
    - Every ``interval_clean_s`` (30 min) when cache is clean
    - Every ``interval_active_s`` (15 min) when shards are found

    Stop with Ctrl+C (SIGINT) or SIGTERM.
    """
    logger.info(
        "kintsugi daemon starting (clean=%ds, active=%ds, max_p2=%d)",
        interval_clean_s,
        interval_active_s,
        max_p2_jobs,
    )

    # Issue #126: SIGHUP reloads config (enables runtime ouroboros_mode switching)
    import signal

    def _sighup_handler(*_args: object) -> None:
        from opendeviationbar.config import Settings

        Settings.reload_and_clear()
        new_mode = Settings.get().population.ouroboros_mode
        logger.info("SIGHUP: config reloaded (ouroboros_mode=%s)", new_mode)
        # Issue #134: Notify operators of runtime config change
        try:
            from opendeviationbar.notify.telegram import send_telegram

            send_telegram(
                f"<b>SIGHUP: kintsugi config reloaded</b>\n"
                f"<b>ouroboros_mode:</b> {new_mode}\n"
                f"<b>PID:</b> {os.getpid()}",
                disable_notification=True,
            )
        except (ImportError, OSError):
            logger.debug("SIGHUP: Telegram notification failed (non-fatal)")

    signal.signal(signal.SIGHUP, _sighup_handler)

    # Issue #121: Notify on daemon startup (confirms EnvironmentFile worked)
    _sd_notify("READY=1")
    try:
        from opendeviationbar.notify.telegram import _build_context_block, send_telegram

        send_telegram(
            "<b>KINTSUGI STARTED</b>\n"
            f"<b>Interval:</b> clean={interval_clean_s}s, active={interval_active_s}s\n"
            f"<b>Max P2:</b> {max_p2_jobs}\n"
            f"<b>PID:</b> {os.getpid()}" + _build_context_block("kintsugi"),
            disable_notification=True,
        )
    except (ImportError, OSError, RuntimeError):
        logger.debug("failed to send kintsugi startup Telegram", exc_info=True)

    iteration = 0
    try:
        while True:
            iteration += 1
            logger.info("=== kintsugi iteration %d ===", iteration)

            results = kintsugi_pass(
                symbol=symbol,
                max_p2_jobs=max_p2_jobs,
                include_microstructure=include_microstructure,
            )

            # Issue #117: Ping systemd watchdog after each pass
            _sd_notify("WATCHDOG=1")

            has_activity = any(r.healed or r.error for r in results)
            sleep_s = interval_active_s if has_activity else interval_clean_s

            logger.info(
                "kintsugi sleeping %ds (%s)",
                sleep_s,
                "active" if has_activity else "clean",
            )
            time.sleep(sleep_s)

    except KeyboardInterrupt:
        logger.info("kintsugi daemon stopped after %d iterations", iteration)


# ---------------------------------------------------------------------------
# Dead-letter replay
# ---------------------------------------------------------------------------


def replay_dead_letters() -> int:
    """Replay any dead-letter Parquet files from sidecar flush failures.

    Returns number of bars successfully replayed.
    """
    from opendeviationbar.sidecar import _DEAD_LETTER_DIR

    if not _DEAD_LETTER_DIR.exists():
        return 0

    import polars as pl

    from opendeviationbar.clickhouse import OpenDeviationBarCache

    total_replayed = 0
    for path in sorted(_DEAD_LETTER_DIR.glob("*.parquet")):
        parts = path.stem.split("_")
        if len(parts) < _MIN_DEAD_LETTER_PARTS:
            logger.warning("skipping malformed dead-letter: %s", path)
            continue

        symbol = parts[0]
        threshold = int(parts[1])

        try:
            bars_df = pl.read_parquet(path)
            with OpenDeviationBarCache() as cache:
                written = cache.store_bars_batch(
                    symbol=symbol,
                    threshold_decimal_bps=threshold,
                    bars=bars_df,
                )
            total_replayed += written
            path.unlink()
            logger.info(
                "replayed dead-letter %s: %d bars",
                path.name,
                written,
            )
        except (OSError, RuntimeError, ConnectionError, ValueError) as e:
            logger.warning("failed to replay dead-letter %s: %s", path, e)
            break  # Stop on first failure (ClickHouse likely down)

    if total_replayed > 0:
        logger.info("dead-letter replay: %d bars total", total_replayed)

    return total_replayed


__all__ = [
    "_PRIORITY_SYMBOLS",
    "_STALE_P1_DAYS",
    "KintsugiResult",
    "Shard",
    "discover_shards",
    "kintsugi_daemon",
    "kintsugi_pass",
    "repair_shard",
    "replay_dead_letters",
    "verify_repair",
]
