"""Unit tests for pytest-mcp-tools plugin.

The list_tools tests are now dynamically generated in plugin.py
when --mcp-tools is used.
"""


def test_unit():
    """Basic unit test to verify test collection works."""
    assert True
