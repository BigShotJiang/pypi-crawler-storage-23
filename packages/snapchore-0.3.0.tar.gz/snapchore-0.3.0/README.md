# snapchore

Standalone Python client for SnapChore — moment-authenticated hashing, verification, sealing, and evidence-chain management.

## Install

```bash
pip install snapchore
```

## Quick start

```python
from snapchore import SnapChoreClient

client = SnapChoreClient(base_url="https://api.smartblocks.network")
client.authenticate("sbn_live_abc123")

# Capture — hash a payload and register in the ledger
result = client.capture({"event": "signup", "user": "u-42"})
print(result["hash"])

# Verify — confirm a hash matches the payload
ok = client.verify(result["hash"], {"event": "signup", "user": "u-42"})
print(ok["valid"])  # True

# Seal — commit a block to the lattice
block = client.seal(
    {"event": "signup", "user": "u-42"},
    domain="auth.events",
    block_type="event",
)
```

## Features

- **Capture & verify** — content-addressed hashing with canonical serialization
- **Seal** — commit blocks to the SmartBlocks lattice via the aggregator
- **Chains** — create, append, and verify tamper-evident evidence chains
- **Discovery** — look up hashes, list recent entries, cross-project receipt search
- **API key management** — create, list, and revoke SnapChore-scoped keys
- **Auth** — API key, bearer token, and token provider authentication
- **Retry** — configurable exponential backoff for transient failures

## Auth methods

```python
# API key (most common)
client.authenticate("sbn_live_...")

# Bearer token (console sessions, service-to-service)
client.authenticate_bearer("eyJ...")
```

## Context manager

```python
with SnapChoreClient(base_url="https://api.smartblocks.network") as client:
    client.authenticate("sbn_live_...")
    client.capture({"event": "signup"})
# transport auto-closed
```

## Relationship to sbn-sdk

This package provides a **standalone** SnapChore client for projects that only need hashing and chain management. If you need the full SmartBlocks Network surface (gateway, governance, lattice, control plane), use [sbn-sdk](https://pypi.org/project/sbn-sdk/) which includes an equivalent `client.snapchore` sub-client.

For local hashing without network calls, see [snapchore-core](https://pypi.org/project/snapchore-core/).

## License

MIT
