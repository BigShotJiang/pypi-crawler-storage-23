"""SnapChore standalone client — capture, verify, seal, and chain management.

This is the top-level entry point for the standalone SnapChore SDK.
It wraps all SnapChore operations in a single class with built-in
authentication, retry, and error handling.
"""

from __future__ import annotations

from typing import Any, Mapping

from snapchore._http import AuthState, HttpTransport, RetryConfig

PREFIX = "/internal/snapchore"

# SBN server whitelist — seal rejects anything outside this set.
_VALID_BLOCK_TYPES = {"event", "stimulus", "audit", "instruction", "meta"}


class SnapChoreClient:
    """Standalone client for the SnapChore moment-authentication service.

    Provides capture, verification, sealing, and evidence-chain
    management without requiring the full SmartBlocks Network SDK.

    Example::

        from snapchore import SnapChoreClient

        client = SnapChoreClient(base_url="https://api.smartblocks.network")
        client.authenticate("sbn_live_abc123")

        snap = client.capture({"event": "signup"})
        ok = client.verify(snap["hash"], {"event": "signup"})
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8090",
        retry: RetryConfig | None = None,
        timeout: float = 10.0,
        user_agent: str = "snapchore-sdk/0.3",
    ) -> None:
        self._auth = AuthState()
        self._transport = HttpTransport(
            base_url=base_url,
            auth=self._auth,
            retry=retry,
            timeout=timeout,
            user_agent=user_agent,
        )

    # ── Auth ───────────────────────────────────────────────────────────

    def authenticate(self, api_key: str) -> None:
        """Set API key auth for all subsequent requests."""
        self._auth.api_key = api_key
        self._auth.bearer_token = None
        self._auth.token_provider = None

    def authenticate_bearer(self, token: str) -> None:
        """Set a static bearer token for all subsequent requests."""
        self._auth.bearer_token = token
        self._auth.api_key = None
        self._auth.token_provider = None

    # ── Core block operations ──────────────────────────────────────────

    def capture(
        self,
        payload: Mapping[str, Any],
        *,
        volatile_keys: list[str] | None = None,
    ) -> dict[str, Any]:
        """Capture a block — hash the payload and register in the ledger.

        Returns ``{"hash": "<64-char hex>", "canon_version": "SVP-1.0"}``.
        """
        body: dict[str, Any] = {"payload": dict(payload)}
        if volatile_keys:
            body["volatile_keys"] = volatile_keys
        return self._transport.post(f"{PREFIX}/capture", json=body).json()

    def verify(
        self,
        expected_hash: str,
        payload: Mapping[str, Any],
        *,
        volatile_keys: list[str] | None = None,
    ) -> dict[str, Any]:
        """Verify a snapchore hash matches the given payload.

        Returns ``{"valid": true/false, ...}``.
        """
        body: dict[str, Any] = {
            "expected_hash": expected_hash,
            "payload": dict(payload),
        }
        if volatile_keys:
            body["volatile_keys"] = volatile_keys
        return self._transport.post(f"{PREFIX}/verify", json=body).json()

    def seal(
        self,
        payload: Mapping[str, Any],
        *,
        domain: str = "general",
        block_type: str = "event",
        metadata: Mapping[str, Any] | None = None,
        metrics: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Seal a block — commit it to the lattice via the aggregator.

        Raises:
            ValueError: If *block_type* is not in the server whitelist.
        """
        if block_type not in _VALID_BLOCK_TYPES:
            raise ValueError(
                f"Invalid block_type {block_type!r}; "
                f"must be one of {sorted(_VALID_BLOCK_TYPES)}"
            )
        body: dict[str, Any] = {
            "domain": domain,
            "block_type": block_type,
            "payload": dict(payload),
        }
        if metadata is not None:
            body["metadata"] = dict(metadata)
        if metrics is not None:
            body["metrics"] = dict(metrics)
        return self._transport.post(f"{PREFIX}/seal", json=body).json()

    def verify_block(
        self,
        block: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Verify a sealed block's integrity."""
        return self._transport.post(
            f"{PREFIX}/block/verify", json={"block": dict(block)}
        ).json()

    def discover(self, snapchore_hash: str) -> dict[str, Any]:
        """Look up a hash in the ledger by exact match."""
        return self._transport.get(f"{PREFIX}/discover/{snapchore_hash}").json()

    def discover_recent(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        since: str | None = None,
        source: str | None = None,
        domain: str | None = None,
    ) -> dict[str, Any]:
        """List recent hashes from the ledger.

        Args:
            limit: Max entries per page (default 20).
            offset: Pagination offset.
            since: ISO-8601 cursor — only entries created after this time.
            source: Filter by ledger entry source.
            domain: Filter by domain (wildcard prefix OK).
        """
        params: dict[str, str] = {"limit": str(limit)}
        if offset:
            params["offset"] = str(offset)
        if since:
            params["since"] = since
        if source:
            params["source"] = source
        if domain:
            params["domain"] = domain
        return self._transport.get(f"{PREFIX}/discover", params=params).json()

    def receipts_discover(
        self,
        *,
        domain: str | None = None,
        hash: str | None = None,
        project_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
        since: str | None = None,
    ) -> dict[str, Any]:
        """Cross-project receipt discovery (service-auth).

        Endpoint: ``GET /internal/snapchore/receipts/discover``

        Args:
            domain: Filter by domain (wildcard suffix OK, e.g. ``"numa.*"``).
            hash: Exact receipt hash lookup.
            project_id: Scope to a specific project.
            limit: Max entries per page (default 20, max 200).
            offset: Pagination offset.
            since: ISO-8601 cursor — only receipts created after this time.
        """
        params: dict[str, str] = {"limit": str(limit)}
        if offset:
            params["offset"] = str(offset)
        if since:
            params["since"] = since
        if domain:
            params["domain"] = domain
        if hash:
            params["hash"] = hash
        if project_id:
            params["project_id"] = project_id
        return self._transport.get(f"{PREFIX}/receipts/discover", params=params).json()

    # ── Chain operations ───────────────────────────────────────────────

    def create_chain(
        self,
        chain_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a new evidence chain."""
        body: dict[str, Any] = {}
        if chain_id:
            body["chain_id"] = chain_id
        return self._transport.post(f"{PREFIX}/chain", json=body).json()

    def append_to_chain(
        self,
        chain_id: str,
        *,
        block_hash: str,
        block_id: str | None = None,
        event_type: str = "block_sealed",
        metadata: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Append an entry to an existing chain."""
        body: dict[str, Any] = {
            "block_hash": block_hash,
            "event_type": event_type,
        }
        if block_id:
            body["block_id"] = block_id
        if metadata is not None:
            body["metadata"] = dict(metadata)
        return self._transport.post(f"{PREFIX}/chain/{chain_id}/append", json=body).json()

    def get_chain(self, chain_id: str) -> dict[str, Any]:
        """Retrieve the full chain state."""
        return self._transport.get(f"{PREFIX}/chain/{chain_id}").json()

    def list_chains(self) -> dict[str, Any]:
        """List all chains for the current project."""
        return self._transport.get(f"{PREFIX}/chains").json()

    def verify_chain(self, chain_id: str) -> dict[str, Any]:
        """Verify chain integrity."""
        return self._transport.post(f"{PREFIX}/chain/{chain_id}/verify", json={}).json()

    # ── Stats & usage ──────────────────────────────────────────────────

    def get_stats(self) -> dict[str, Any]:
        """Get SnapChore system statistics."""
        return self._transport.get(f"{PREFIX}/stats").json()

    def get_usage(self) -> dict[str, Any]:
        """Get monthly usage meters for the current billing period."""
        return self._transport.get(f"{PREFIX}/usage").json()

    # ── API key management ─────────────────────────────────────────────

    def create_api_key(
        self,
        *,
        name: str = "SnapChore key",
        mode: str = "live",
        plan: str | None = None,
    ) -> dict[str, Any]:
        """Create a SnapChore-scoped API key."""
        body: dict[str, Any] = {"name": name, "mode": mode}
        if plan:
            body["plan"] = plan
        return self._transport.post(f"{PREFIX}/api-keys", json=body).json()

    def list_api_keys(self) -> dict[str, Any]:
        """List all SnapChore API keys for the current project."""
        return self._transport.get(f"{PREFIX}/api-keys").json()

    def revoke_api_key(self, key_id: str) -> dict[str, Any]:
        """Revoke a SnapChore API key.  Idempotent."""
        return self._transport.post(f"{PREFIX}/api-keys/{key_id}/revoke", json={}).json()

    def reconcile(self) -> dict[str, Any]:
        """Reconcile unconfirmed ledger entries against the receipt catalogue."""
        return self._transport.post(f"{PREFIX}/reconcile", json={}).json()

    # ── Lifecycle ──────────────────────────────────────────────────────

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> SnapChoreClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
