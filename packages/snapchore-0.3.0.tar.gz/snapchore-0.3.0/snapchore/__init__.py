"""SnapChore SDK — standalone client for moment-authenticated hashing.

SnapChore provides tamper-evident hashing, verification, sealing, and
evidence-chain management.  This package can be used independently of
the full SmartBlocks Network SDK.

Usage::

    from snapchore import SnapChoreClient

    client = SnapChoreClient(base_url="https://api.smartblocks.network")
    client.authenticate("sbn_live_abc123")

    # Hash a payload
    result = client.capture({"event": "signup", "user": "u-42"})
    print(result["hash"])

    # Verify
    ok = client.verify(result["hash"], {"event": "signup", "user": "u-42"})
    print(ok["valid"])  # True
"""

from __future__ import annotations

__version__ = "0.3.0"

from snapchore.client import SnapChoreClient
from snapchore._http import SnapChoreError, SnapChoreTransportError, RetryConfig

__all__ = [
    "SnapChoreClient",
    "SnapChoreError",
    "SnapChoreTransportError",
    "RetryConfig",
]
