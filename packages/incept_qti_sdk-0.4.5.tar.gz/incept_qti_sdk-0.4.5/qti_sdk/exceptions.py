"""SDK-specific exception hierarchy.

All public exceptions inherit from :class:`QtiSdkError` so callers can
catch ``except QtiSdkError`` to handle any SDK failure uniformly.
"""


class QtiSdkError(Exception):
    """Base exception for all qti_sdk errors."""


class ValidationError(QtiSdkError, ValueError):
    """Raised when model or input validation fails.

    Also inherits from :class:`ValueError` for backward compatibility
    with code that catches ``ValueError``.
    """


class BuildError(QtiSdkError):
    """Raised when QTI XML generation fails."""


class UploadError(QtiSdkError):
    """Raised when a TimeBack upload or network request fails."""


class AuthenticationError(UploadError):
    """Raised when OAuth token acquisition fails."""


class CurriculumNotFoundError(QtiSdkError, KeyError):
    """Raised when a curriculum registry key is not found.

    Also inherits from :class:`KeyError` for backward compatibility.
    """
