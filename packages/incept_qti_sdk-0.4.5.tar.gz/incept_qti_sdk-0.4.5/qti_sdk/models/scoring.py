"""Score maps and Score Expression DSL types.

Score maps provide weighted per-option scoring (``qti-mapping``).
The Score Expression DSL provides a typed, serializable expression tree
that compiles 1:1 to QTI expression elements.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Score maps (per interaction type)
# ---------------------------------------------------------------------------


class ChoiceScoreMap(BaseModel):
    """Weighted per-choice scoring.  Maps choice IDs to point values."""

    entries: dict[str, float] = Field(
        description="Mapping of choice_id -> score value.",
    )
    default_value: float = 0.0
    lower_bound: float | None = None
    upper_bound: float | None = None


class TextEntryScoreMap(BaseModel):
    """Weighted per-response-string scoring for text entry."""

    entries: dict[str, float] = Field(
        description="Mapping of response_string -> score value.",
    )
    default_value: float = 0.0
    case_sensitive: bool = Field(
        default=False,
        description="Inherits from interaction if not set.",
    )


class MatchScoreEntry(BaseModel):
    """A single source-target pair with its score."""

    source: str = Field(description="Source item id.")
    target: str = Field(description="Target item id.")
    score: float


class MatchScoreMap(BaseModel):
    """Weighted per-pair scoring for match interactions."""

    entries: list[MatchScoreEntry] = Field(
        description="Structured source-target score pairs.",
    )
    default_value: float = 0.0
    lower_bound: float | None = None
    upper_bound: float | None = None


# ---------------------------------------------------------------------------
# Score Expression DSL
# ---------------------------------------------------------------------------


class MapResponseExpr(BaseModel):
    """References a RESPONSE variable's mapping (``qti-map-response``)."""

    type: Literal["map_response"] = "map_response"
    identifier: str = Field(description="References a RESPONSE variable's mapping.")


class VariableExpr(BaseModel):
    """References any variable (``qti-variable``)."""

    type: Literal["variable"] = "variable"
    identifier: str


class BaseValueExpr(BaseModel):
    """A literal numeric value (``qti-base-value``)."""

    type: Literal["base_value"] = "base_value"
    base_type: Literal["float", "integer"]
    value: str


class SumExpr(BaseModel):
    """Sum of operands (``qti-sum``)."""

    type: Literal["sum"] = "sum"
    operands: list[ScoreExpression]


class SubtractExpr(BaseModel):
    """Difference of operands (``qti-subtract``)."""

    type: Literal["subtract"] = "subtract"
    operands: list[ScoreExpression]


class ProductExpr(BaseModel):
    """Product of operands (``qti-product``)."""

    type: Literal["product"] = "product"
    operands: list[ScoreExpression]


class DivideExpr(BaseModel):
    """Division of operands (``qti-divide``)."""

    type: Literal["divide"] = "divide"
    operands: list[ScoreExpression]


ScoreExpression = Annotated[
    Union[
        MapResponseExpr,
        VariableExpr,
        BaseValueExpr,
        SumExpr,
        SubtractExpr,
        ProductExpr,
        DivideExpr,
    ],
    Field(discriminator="type"),
]
"""Typed expression tree that compiles 1:1 to QTI expression elements."""

# Pydantic v2 needs model_rebuild for forward-ref resolution on recursive types.
SumExpr.model_rebuild()
SubtractExpr.model_rebuild()
ProductExpr.model_rebuild()
DivideExpr.model_rebuild()
