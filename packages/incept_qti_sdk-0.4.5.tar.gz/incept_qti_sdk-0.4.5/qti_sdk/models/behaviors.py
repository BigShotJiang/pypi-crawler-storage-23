"""Behavior types — discriminated union controlling how an item scores,
gives feedback, and manages attempts.

Only three genuinely distinct modes exist:
- **SummativeBehavior**: no feedback, score only.
- **FeedbackEnabled**: all feedback scenarios, configurable via
  ``max_attempts`` and ``FeedbackPolicy``.
- **ExternalGraded**: no automated scoring or response processing.

Feedback *content* lives on interactions and items (via ``Feedback``
entries), not on the behavior.  The behavior is policy only.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from .base import FeedbackPolicy


class SummativeBehavior(BaseModel):
    """High-stakes test, one attempt. No feedback during test. SCORE only."""

    type: Literal["summative"] = "summative"


class FeedbackEnabled(BaseModel):
    """All feedback scenarios — formative practice, adaptive scaffolding,
    diagnostic, and remediation.  The ``max_attempts`` and ``policy``
    fields control attempt limits and default reveal timing.  Feedback
    content itself lives on ``Choice.feedback``, interaction-level
    ``feedback``, or ``QuestionItem.feedback``."""

    type: Literal["feedback_enabled"] = "feedback_enabled"
    max_attempts: int = Field(
        default=1,
        ge=1,
        description="Maximum submissions allowed. 1 = single attempt (formative/diagnostic).",
    )
    policy: FeedbackPolicy = Field(default_factory=FeedbackPolicy)


class ExternalGraded(BaseModel):
    """No automated scoring. Flags for human or AI grader.

    The SDK omits ``<qti-response-processing>`` entirely.  SCORE outcome
    carries ``external-scored="human"`` (or ``"externalMachine"``).
    """

    type: Literal["external_graded"] = "external_graded"


AssessmentBehavior = Annotated[
    Union[
        SummativeBehavior,
        FeedbackEnabled,
        ExternalGraded,
    ],
    Field(discriminator="type"),
]
"""Discriminated union of all behavior types.  Generator authors pick one."""
