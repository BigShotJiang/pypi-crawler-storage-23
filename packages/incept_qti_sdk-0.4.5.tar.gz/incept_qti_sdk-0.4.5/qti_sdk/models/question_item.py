"""QuestionItem — the unified item-level container.

Holds the shared stem, behavior, one or more interactions, and all optional
cross-cutting fields (stimulus, companion materials, accessibility catalog,
item-level feedback, scoring dimensions, template config, etc.).

Cross-field validators enforce structural constraints.
"""

from __future__ import annotations

import re
from typing import Annotated, Union

from pydantic import BaseModel, Field, model_validator

from ..exceptions import ValidationError
from .base import (
    AccessibilityCatalogEntry,
    CompanionMaterials,
    ContextVariable,
    Feedback,
    ItemPackaging,
    MarkdownStr,
    ScoringDimension,
    Stimulus,
    TemplateConfig,
)
from .behaviors import (
    AssessmentBehavior,
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from .interactions import (
    Interaction,
    TextEntryConfig,
)

_RESERVED_PATTERNS: list[re.Pattern] = [
    re.compile(r"^RESPONSE$"),
    re.compile(r"^RESPONSE_\d+$"),
    re.compile(r"^RESPONSE_BLANK_\d+$"),
    re.compile(r"^RESPONSE_\d+_BLANK_\d+$"),
    re.compile(r"^RESPONSE_END_ATTEMPT$"),
    re.compile(r"^SCORE$"),
    re.compile(r"^SCORE_\d+$"),
    re.compile(r"^FEEDBACK$"),
    re.compile(r"^FEEDBACK_\d+$"),
    re.compile(r"^MODAL_FEEDBACK$"),
    re.compile(r"^completionStatus$"),
    re.compile(r"^HINT_FEEDBACK$"),
    re.compile(r"^WORKED_SOLUTION_FEEDBACK$"),
    re.compile(r"^REVEAL_ANSWER_FEEDBACK$"),
    re.compile(r"^LEARNING_CONTENT_FEEDBACK$"),
    re.compile(r"^MAXSCORE$"),
]


def _is_reserved(identifier: str) -> bool:
    return any(p.match(identifier) for p in _RESERVED_PATTERNS)


class QuestionItem(BaseModel):
    """The unified item-level container that generators produce."""

    item_id: str | None = Field(
        default=None,
        description=(
            "Optional item identifier. If provided, used as-is for the QTI "
            "assessment-item identifier and file name. If omitted, an ID is "
            "auto-generated from a content hash."
        ),
    )
    question: MarkdownStr = Field(description="Shared stem / prompt.")
    title: str | None = Field(
        default=None,
        description="Human-readable item title (falls back to auto-generated).",
    )
    behavior: AssessmentBehavior
    interactions: list[Interaction] = Field(min_length=1, description="1+ interaction configs.")

    stimulus: Annotated[
        Union[Stimulus, list[Stimulus], None],
        Field(default=None, description="Text, image, audio, or video passage."),
    ] = None
    companion_materials: CompanionMaterials | None = None
    accessibility_catalog: list[AccessibilityCatalogEntry] | None = None

    feedback: list[Feedback] = Field(
        default_factory=list,
        description=(
            "Item-level feedback entries. Rendered as qti-modal-feedback "
            "or qti-feedback-block at end of item body, depending on type."
        ),
    )

    scoring_dimensions: list[ScoringDimension] | None = None
    max_score: float | None = None
    grading_rubric: str | None = Field(
        default=None, description="HTML shown to scorers.",
    )

    lang: str | None = Field(
        default=None, description="BCP 47 language tag for xml:lang.",
    )
    context_declarations: list[ContextVariable] | None = None
    template: TemplateConfig | None = None
    extension_attributes: dict[str, str] | None = None

    packaging: ItemPackaging = Field(
        description="Manifest-level metadata (difficulty, curriculum standards, freeform metadata).",
    )

    # ------------------------------------------------------------------
    # Cross-field validators
    # ------------------------------------------------------------------

    @model_validator(mode="after")
    def _validate_cross_field_rules(self) -> QuestionItem:
        self._check_feedback_behavior_compat()
        self._check_template_correct_expression()
        self._check_score_expression_max_score()
        self._check_reserved_identifiers()
        self._check_text_entry_blanks_in_question()
        return self

    def _check_feedback_behavior_compat(self) -> None:
        """Summative and ExternalGraded must not carry feedback entries."""
        if not isinstance(self.behavior, (SummativeBehavior, ExternalGraded)):
            return
        has_feedback = bool(self.feedback)
        if not has_feedback:
            for interaction in self.interactions:
                if getattr(interaction, "feedback", None):
                    has_feedback = True
                    break
        if has_feedback:
            raise ValidationError(
                f"{type(self.behavior).__name__} cannot have feedback entries "
                f"(no feedback in {self.behavior.type} mode)"
            )

    def _check_template_correct_expression(self) -> None:
        """correct_expression requires template; dict keys must match blanks."""
        for interaction in self.interactions:
            if not isinstance(interaction, TextEntryConfig):
                continue
            if interaction.correct_expression is None:
                continue

            if self.template is None:
                raise ValidationError(
                    "TextEntryConfig.correct_expression requires QuestionItem.template to be set"
                )

            if isinstance(interaction.correct_expression, dict) and interaction.prompt:
                ce_keys = set(interaction.correct_expression.keys())
                blank_ids = set(interaction.blank_ids)
                if ce_keys != blank_ids:
                    raise ValidationError(
                        f"correct_expression keys {ce_keys} don't match "
                        f"blank IDs {blank_ids} in prompt"
                    )

    def _check_score_expression_max_score(self) -> None:
        """score_expression requires max_score or target_dimension with max."""
        dimension_names = set()
        if self.scoring_dimensions:
            dimension_names = {d.name for d in self.scoring_dimensions}

        for interaction in self.interactions:
            se = getattr(interaction, "score_expression", None)
            if se is None:
                continue

            td = getattr(interaction, "target_dimension", None)
            if td and td in dimension_names:
                continue

            if self.max_score is not None:
                continue

            raise ValidationError(
                "Interaction with score_expression requires QuestionItem.max_score "
                "or a target_dimension pointing to a ScoringDimension with max_score"
            )

    def _check_text_entry_blanks_in_question(self) -> None:
        """When TextEntryConfig.prompt is None, validate that blanks in
        question match the answer keys for multi-blank items."""
        for interaction in self.interactions:
            if not isinstance(interaction, TextEntryConfig):
                continue
            if interaction.prompt is not None:
                continue
            if not interaction.is_multi_blank:
                if "<blank>" not in self.question:
                    raise ValidationError(
                        "Single-blank TextEntryConfig requires <blank> in "
                        "QuestionItem.question when prompt is not set"
                    )
                continue
            blanks_in_q = set(re.findall(r"<(blank-\d+)>", self.question))
            answer_keys = set(interaction.answers.keys())  # type: ignore[union-attr]
            if not blanks_in_q:
                raise ValidationError(
                    "Multi-blank TextEntryConfig requires <blank-N> placeholders in "
                    "QuestionItem.question when prompt is not set"
                )
            if blanks_in_q != answer_keys:
                raise ValidationError(
                    f"Blanks in question {blanks_in_q} don't match "
                    f"answer keys {answer_keys}"
                )

    def _check_reserved_identifiers(self) -> None:
        """context_declarations identifiers must not collide with reserved patterns."""
        if not self.context_declarations:
            return
        for cv in self.context_declarations:
            if _is_reserved(cv.identifier):
                raise ValidationError(
                    f"Context declaration identifier '{cv.identifier}' collides "
                    f"with a reserved SDK identifier pattern"
                )
