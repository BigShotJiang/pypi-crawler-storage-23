"""CLI entry-point: python -m qti_sdk {schema,discover,build,upload,status}"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import sys
from pathlib import Path

from qti_sdk.models import QuestionItem
from qti_sdk.models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)

_MODELS: dict[str, type] = {
    "QuestionItem": QuestionItem,
    "ChoiceConfig": ChoiceConfig,
    "TextEntryConfig": TextEntryConfig,
    "ExtendedTextConfig": ExtendedTextConfig,
    "MatchConfig": MatchConfig,
    "OrderConfig": OrderConfig,
    "PCIConfig": PCIConfig,
}

logger = logging.getLogger("qti_sdk.cli")

EXIT_OK = 0
EXIT_VALIDATION = 1
EXIT_BUILD = 2
EXIT_UPLOAD = 3
EXIT_TIMEOUT = 4

# ---------------------------------------------------------------------------
# Shared CLI helpers
# ---------------------------------------------------------------------------


def _setup_logging(*, verbose: bool = False, quiet: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.WARNING if quiet else logging.INFO
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _read_input(args: argparse.Namespace) -> list | dict:
    """Read JSON from --input FILE or stdin."""
    source = getattr(args, "input", None)
    if source:
        with open(source, encoding="utf-8") as f:
            return json.load(f)
    if sys.stdin.isatty():
        _exit_error("ValidationError", "No input provided. Use --input FILE or pipe JSON to stdin.", exit_code=EXIT_VALIDATION)
    return json.load(sys.stdin)


def _write_output(data: dict | list, args: argparse.Namespace) -> None:
    """Write JSON to -o FILE or stdout."""
    text = json.dumps(data, indent=2, ensure_ascii=False)
    output_path = getattr(args, "output", None)
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
            f.write("\n")
    else:
        sys.stdout.write(text)
        sys.stdout.write("\n")
        sys.stdout.flush()


def _exit_error(
    error_type: str,
    message: str,
    *,
    details: list | None = None,
    exit_code: int = EXIT_BUILD,
) -> None:
    """Write a structured JSON error to stdout and exit."""
    payload: dict = {"error": error_type, "message": message}
    if details is not None:
        payload["details"] = details
    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()
    sys.exit(exit_code)


def _resolve_config():
    """Build TimeBackConfig from env vars. Exits with error if missing."""
    from qti_sdk.upload.config import TimeBackConfig

    base_url = os.environ.get("TIMEBACK_PLATFORM_API_URL")
    client_id = os.environ.get("TIMEBACK_APPLICATION_CLIENT_ID")
    client_secret = os.environ.get("TIMEBACK_APPLICATION_CLIENT_SECRET")

    missing = []
    if not base_url:
        missing.append("TIMEBACK_PLATFORM_API_URL")
    if not client_id:
        missing.append("TIMEBACK_APPLICATION_CLIENT_ID")
    if not client_secret:
        missing.append("TIMEBACK_APPLICATION_CLIENT_SECRET")

    if missing:
        _exit_error(
            "ConfigurationError",
            f"Missing required environment variables: {', '.join(missing)}",
            exit_code=EXIT_VALIDATION,
        )

    return TimeBackConfig(
        base_url=base_url,
        client_id=client_id,
        client_secret=client_secret,
    )


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--input", "-i", default=None,
        help="Path to QuestionItem JSON file. Reads from stdin if omitted.",
    )
    parser.add_argument(
        "--output", "-o", default=None,
        help="Output path (directory for build, file for upload/status).",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show DEBUG-level logs on stderr.",
    )
    group.add_argument(
        "--quiet", "-q", action="store_true",
        help="Suppress INFO logs; show only WARNING and above.",
    )


def _parse_items(raw: dict | list) -> list[QuestionItem]:
    """Validate raw JSON as one or more QuestionItem instances."""
    items_raw = raw if isinstance(raw, list) else [raw]
    return [QuestionItem.model_validate(item) for item in items_raw]


def _dump(model_cls: type) -> str:
    return json.dumps(model_cls.model_json_schema(), indent=2)


# ---------------------------------------------------------------------------
# context sub-command
# ---------------------------------------------------------------------------


def _run_context(args: argparse.Namespace) -> None:
    context_path = Path(__file__).parent / "data" / "model_context.md"
    content = context_path.read_text(encoding="utf-8")

    if not args.no_schema:
        schema = json.dumps(QuestionItem.model_json_schema(), indent=2)
        content += "\n---\n\n## 10. JSON Schema\n\n"
        content += "Full JSON Schema for `QuestionItem` (auto-generated):\n\n"
        content += f"```json\n{schema}\n```\n"

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Context written to {args.output}", file=sys.stderr)
    else:
        sys.stdout.buffer.write(content.encode("utf-8"))
        sys.stdout.buffer.flush()


# ---------------------------------------------------------------------------
# discover sub-command
# ---------------------------------------------------------------------------

def _slugify(text: str) -> str:
    """Turn a human title into a UPPER_SNAKE registry key fragment."""
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text)
    text = text.strip("_").upper()
    return text


def _generate_key(doc_title: str, course_title: str, subject: str) -> str:
    doc = _slugify(doc_title)
    doc = doc.replace("COMMON_CORE_STATE_STANDARDS", "CCSS")
    course = _slugify(course_title)
    subj = _slugify(subject)
    return f"{doc}_{subj}_{course}"


async def _run_discover(args: argparse.Namespace) -> None:
    import httpx

    from qti_sdk.curriculum.registry import CourseEntry, load_registry, save_registry
    from qti_sdk.upload.auth import get_token
    from qti_sdk.upload.config import TimeBackConfig

    base_url = args.base_url or os.environ.get("TIMEBACK_PLATFORM_API_URL")
    client_id = args.client_id or os.environ.get("TIMEBACK_APPLICATION_CLIENT_ID")
    client_secret = args.client_secret or os.environ.get("TIMEBACK_APPLICATION_CLIENT_SECRET")

    if not all([base_url, client_id, client_secret]):
        print(
            "Error: Provide --base-url, --client-id, --client-secret "
            "or set TIMEBACK_PLATFORM_API_URL, "
            "TIMEBACK_APPLICATION_CLIENT_ID, "
            "TIMEBACK_APPLICATION_CLIENT_SECRET env vars.",
            file=sys.stderr,
        )
        sys.exit(1)

    config = TimeBackConfig(
        base_url=base_url,
        client_id=client_id,
        client_secret=client_secret,
    )
    token = await get_token(config)
    headers = {"Authorization": f"Bearer {token}"}
    api = base_url.rstrip("/")

    registry = load_registry()
    registered_course_ids = {e.course_id for e in registry.values()}

    async with httpx.AsyncClient() as client:
        print("\nFetching documents...")
        docs: list[dict] = []
        offset = 0
        page_limit = 100
        while True:
            resp = await client.get(
                f"{api}/case/1.1/CFDocuments",
                headers=headers,
                params={"limit": page_limit, "offset": offset},
                timeout=30.0,
            )
            resp.raise_for_status()
            body = resp.json()
            page = body.get("CFDocuments", [])
            docs.extend(page)
            total = body.get("total", len(docs))
            if len(docs) >= total or not page:
                break
            offset += len(page)

        if not docs:
            print("No documents found.")
            return

        print()
        for i, doc in enumerate(docs, 1):
            print(f"  {i:3d}. {doc.get('title', '(untitled)')}  [{doc['identifier'][:12]}...]")
        print()

        choice = input("Select document number: ").strip()
        try:
            doc_idx = int(choice) - 1
            selected_doc = docs[doc_idx]
        except (ValueError, IndexError):
            print("Invalid selection.")
            return

        doc_id = selected_doc["identifier"]
        doc_title = selected_doc.get("title", doc_id)
        print(f"\nSelected: {doc_title}")

        print(f"\nFetching courses for '{doc_title}'...")
        resp = await client.get(
            f"{api}/curriculum/1.0/documents/{doc_id}/courses",
            headers=headers,
            timeout=30.0,
        )
        resp.raise_for_status()
        body = resp.json()
        courses = body if isinstance(body, list) else body.get("items", body.get("courses", []))

        if not courses:
            print("No courses found for this document.")
            return

        print()
        for i, c in enumerate(courses, 1):
            title = c.get("title", c.get("name", "(untitled)"))
            subjects = ", ".join(s.get("title", "") for s in c.get("subjects", []))
            tag = " (already registered)" if c["id"] in registered_course_ids else ""
            subj_display = f"  ({subjects})" if subjects else ""
            print(f"  {i:3d}. {title:30s}{subj_display}{tag}")
        print()

        choices = input("Select course numbers (comma-separated): ").strip()
        try:
            indices = [int(x.strip()) - 1 for x in choices.split(",")]
            selected_courses = [courses[i] for i in indices]
        except (ValueError, IndexError):
            print("Invalid selection.")
            return

        new_entries: dict[str, CourseEntry] = {}
        for c in selected_courses:
            title = c.get("title", c.get("name", ""))
            subjects = [s.get("title", "") for s in c.get("subjects", [])]
            subject = subjects[0] if subjects else ""
            key = _generate_key(doc_title, title, subject)

            entry = CourseEntry(
                document_id=doc_id,
                course_id=c["id"],
                document_title=doc_title,
                course_title=title,
            )

            print(f"\n  Key:    {key}")
            print(f"  Course: {title} ({subject})")
            print(f"  IDs:    doc={doc_id[:12]}...  course={c['id'][:12]}...")
            custom = input(f"  Accept key or type a new one [{key}]: ").strip()
            if custom:
                key = custom

            new_entries[key] = entry

        registry.update(new_entries)
        save_registry(registry)

        print(f"\nSaved {len(new_entries)} entry(ies) to curriculum registry.")
        for key in new_entries:
            print(f"  {key}")
        print()


# ---------------------------------------------------------------------------
# build sub-command
# ---------------------------------------------------------------------------

def _run_build(args: argparse.Namespace) -> None:
    from qti_sdk.builders import QtiBuilder
    from qti_sdk.builders.base_builder import BuildResult

    raw = _read_input(args)
    items = _parse_items(raw)

    stimulus_mode = getattr(args, "stimulus_mode", "separate")
    output_dir = Path(args.output)

    logger.info("Building %d item(s)...", len(items))

    builder = QtiBuilder()
    results: list[BuildResult] = []
    for item in items:
        results.append(builder.build(item, stimulus_mode=stimulus_mode))

    items_dir = output_dir / "items"
    items_dir.mkdir(parents=True, exist_ok=True)

    seen_stimuli: set[str] = set()
    has_stimuli = any(r.stimulus_xml for r in results)
    if has_stimuli:
        stimuli_dir = output_dir / "stimuli"
        stimuli_dir.mkdir(parents=True, exist_ok=True)

    manifest_items: list[dict] = []
    for result in results:
        item_rel = f"items/{result.item_id}.xml"
        (items_dir / f"{result.item_id}.xml").write_text(result.item_xml, encoding="utf-8")

        stim_rel = None
        if result.stimulus_xml and result.stimulus_id:
            stim_rel = f"stimuli/{result.stimulus_id}.xml"
            if result.stimulus_id not in seen_stimuli:
                seen_stimuli.add(result.stimulus_id)
                (output_dir / stim_rel).write_text(result.stimulus_xml, encoding="utf-8")

        manifest_items.append({
            "item_id": result.item_id,
            "item_xml": item_rel,
            "stimulus_xml": stim_rel,
            "stimulus_id": result.stimulus_id,
            "metadata": result.metadata,
        })

    generated_media: list[str] = []
    for result in results:
        for zip_path, svg_content in result.generated_assets.items():
            asset_path = output_dir / zip_path
            asset_path.parent.mkdir(parents=True, exist_ok=True)
            asset_path.write_text(svg_content, encoding="utf-8")
            generated_media.append(zip_path)

    manifest = {
        "output_dir": str(output_dir),
        "items": manifest_items,
    }
    if generated_media:
        manifest["generated_media"] = generated_media

    logger.info(
        "Wrote %d item(s), %d stimulus file(s), and %d media asset(s) to %s",
        len(results), len(seen_stimuli), len(generated_media), output_dir,
    )

    sys.stdout.write(json.dumps(manifest, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# upload sub-command
# ---------------------------------------------------------------------------

async def _run_upload(args: argparse.Namespace) -> None:
    from qti_sdk.builders import QtiBuilder
    from qti_sdk.upload import get_job_status, upload_qti_package
    from qti_sdk.upload.status import TERMINAL_STATUSES

    raw = _read_input(args)
    items = _parse_items(raw)

    stimulus_mode = getattr(args, "stimulus_mode", "separate")
    media_root = Path(args.media_root) if args.media_root else None
    save_zip = Path(args.save_zip) if args.save_zip else None

    config = _resolve_config()

    logger.info("Building %d item(s)...", len(items))
    builder = QtiBuilder()
    results = [builder.build(item, stimulus_mode=stimulus_mode) for item in items]

    logger.info("Uploading to %s...", config.base_url)
    upload_resp = await upload_qti_package(
        results,
        config,
        media_root=media_root,
        save_zip=save_zip,
    )

    output: dict = {
        "job_id": upload_resp.job_id,
        "warnings": upload_resp.warnings,
    }
    logger.info("Upload complete. Job ID: %s", upload_resp.job_id)
    if upload_resp.warnings:
        for w in upload_resp.warnings:
            logger.warning("%s", w)

    if args.poll:
        logger.info("Polling for job completion...")
        status = await get_job_status(
            upload_resp.job_id,
            config,
            poll=True,
            poll_interval=3.0,
            poll_timeout=120.0,
        )
        status_data = status.model_dump()
        output["status"] = status_data["status"]
        output["last_updated"] = status_data["last_updated"]
        output["item_statuses"] = status_data["item_statuses"]
        logger.info("Final status: %s", status.status)

        if status.status not in TERMINAL_STATUSES:
            _write_output(output, args)
            logger.error("Poll timed out. Status: %s", status.status)
            sys.exit(EXIT_TIMEOUT)

    _write_output(output, args)


# ---------------------------------------------------------------------------
# status sub-command
# ---------------------------------------------------------------------------

async def _run_status(args: argparse.Namespace) -> None:
    from qti_sdk.upload import get_job_status
    from qti_sdk.upload.status import TERMINAL_STATUSES

    config = _resolve_config()
    job_id = args.job_id

    if args.poll:
        logger.info("Polling job %s for completion...", job_id)
    else:
        logger.info("Checking status of job %s...", job_id)

    status = await get_job_status(
        job_id,
        config,
        poll=args.poll,
        poll_interval=3.0,
        poll_timeout=120.0,
    )

    output = status.model_dump()
    logger.info("Status: %s", status.status)

    if args.poll and status.status not in TERMINAL_STATUSES:
        _write_output(output, args)
        logger.error("Poll timed out. Status: %s", status.status)
        sys.exit(EXIT_TIMEOUT)

    _write_output(output, args)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="python -m qti_sdk",
        description="QTI SDK utilities",
    )
    sub = parser.add_subparsers(dest="command")

    # -- schema --
    schema_cmd = sub.add_parser(
        "schema",
        help="Dump JSON Schema for one or all models.",
    )
    schema_cmd.add_argument(
        "--model",
        choices=list(_MODELS.keys()),
        default=None,
        help="Model to export. Omit to export all models.",
    )
    schema_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write to file instead of stdout.",
    )

    # -- transformer-context --
    context_cmd = sub.add_parser(
        "transformer-context",
        help="Export model guide and examples to help build a mapping from your data model to QuestionItem.",
    )
    context_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write to file instead of stdout.",
    )
    context_cmd.add_argument(
        "--no-schema",
        action="store_true",
        help="Omit the JSON Schema appendix.",
    )

    # -- list-curricula --
    list_cur_cmd = sub.add_parser(
        "list-curricula",
        help="List all available curriculum keys for use in packaging.curriculum.",
    )
    list_cur_cmd.add_argument(
        "--output", "-o", default=None,
        help="Write to file instead of stdout.",
    )

    # -- generate-keys --
    sub.add_parser(
        "generate-keys",
        help="Regenerate CurriculumKey enum from registry.json.",
    )

    # -- discover --
    discover_cmd = sub.add_parser(
        "discover",
        help="Interactively register curriculum courses for standard resolution.",
    )
    discover_cmd.add_argument("--base-url", default=None)
    discover_cmd.add_argument("--client-id", default=None)
    discover_cmd.add_argument("--client-secret", default=None)

    # -- build --
    build_cmd = sub.add_parser(
        "build",
        help="Build QuestionItem JSON into QTI 3.0 XML files.",
    )
    _add_common_args(build_cmd)
    build_cmd.add_argument(
        "--stimulus-mode",
        choices=["separate", "inline"],
        default="separate",
        help="Stimulus handling: 'separate' (default) or 'inline'.",
    )

    # -- upload --
    upload_cmd = sub.add_parser(
        "upload",
        help="Build, package, and upload items to TimeBack.",
    )
    _add_common_args(upload_cmd)
    upload_cmd.add_argument(
        "--stimulus-mode",
        choices=["separate", "inline"],
        default="separate",
        help="Stimulus handling: 'separate' (default) or 'inline'.",
    )
    upload_cmd.add_argument(
        "--media-root",
        default=None,
        help="Directory to resolve local asset paths against.",
    )
    upload_cmd.add_argument(
        "--save-zip",
        default=None,
        help="Save assembled ZIP to this path (for debugging).",
    )
    upload_cmd.add_argument(
        "--poll",
        action="store_true",
        help="Wait for job to reach terminal status before exiting.",
    )

    # -- status --
    status_cmd = sub.add_parser(
        "status",
        help="Check or poll a TimeBack ingest job.",
    )
    status_cmd.add_argument(
        "job_id",
        help="Ingest job ID returned by the upload command.",
    )
    status_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write result JSON to file instead of stdout.",
    )
    status_cmd.add_argument(
        "--poll",
        action="store_true",
        help="Wait for job to reach terminal status before exiting.",
    )
    group = status_cmd.add_mutually_exclusive_group()
    group.add_argument("--verbose", "-v", action="store_true")
    group.add_argument("--quiet", "-q", action="store_true")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    # Set up logging for commands that use it
    if args.command in ("build", "upload", "status"):
        _setup_logging(verbose=args.verbose, quiet=args.quiet)

    # Load .env for commands that need credentials
    if args.command in ("upload", "status", "discover"):
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass

    try:
        if args.command == "schema":
            if args.model:
                output = _dump(_MODELS[args.model])
            else:
                combined = {
                    name: cls.model_json_schema() for name, cls in _MODELS.items()
                }
                output = json.dumps(combined, indent=2)

            if args.output:
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(output)
                    f.write("\n")
                print(f"Schema written to {args.output}")
            else:
                print(output)

        elif args.command == "transformer-context":
            _run_context(args)

        elif args.command == "list-curricula":
            from qti_sdk.curriculum import list_curricula
            entries = list_curricula()
            data = {
                key: {"document_title": e.document_title, "course_title": e.course_title}
                for key, e in entries.items()
            }
            _write_output(data, args)

        elif args.command == "generate-keys":
            from qti_sdk.curriculum.codegen import generate
            generate()
            print("CurriculumKey enum regenerated in qti_sdk/curriculum/keys.py")

        elif args.command == "discover":
            asyncio.run(_run_discover(args))

        elif args.command == "build":
            if not args.output:
                _exit_error(
                    "ValidationError",
                    "The build command requires -o / --output to specify an output directory.",
                    exit_code=EXIT_VALIDATION,
                )
            _run_build(args)

        elif args.command == "upload":
            asyncio.run(_run_upload(args))

        elif args.command == "status":
            asyncio.run(_run_status(args))

    except KeyboardInterrupt:
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as exc:
        _handle_exception(exc)


def _handle_exception(exc: Exception) -> None:
    from pydantic import ValidationError as PydanticValidationError

    from qti_sdk.exceptions import BuildError, QtiSdkError, UploadError

    if isinstance(exc, PydanticValidationError):
        _exit_error(
            "ValidationError",
            str(exc.error_count()) + " validation error(s)",
            details=[
                {"loc": list(e["loc"]), "msg": e["msg"], "type": e["type"]}
                for e in exc.errors()
            ],
            exit_code=EXIT_VALIDATION,
        )
    elif isinstance(exc, json.JSONDecodeError):
        _exit_error(
            "ValidationError",
            f"Invalid JSON: {exc.msg} (line {exc.lineno}, col {exc.colno})",
            exit_code=EXIT_VALIDATION,
        )
    elif isinstance(exc, UploadError):
        _exit_error("UploadError", str(exc), exit_code=EXIT_UPLOAD)
    elif isinstance(exc, BuildError):
        _exit_error("BuildError", str(exc), exit_code=EXIT_BUILD)
    elif isinstance(exc, QtiSdkError):
        _exit_error("SdkError", str(exc), exit_code=EXIT_BUILD)
    else:
        logger.debug("Unhandled exception", exc_info=True)
        _exit_error("InternalError", str(exc), exit_code=EXIT_BUILD)


if __name__ == "__main__":
    main()
