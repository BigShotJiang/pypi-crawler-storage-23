"""Builder for standalone qti-assessment-stimulus XML files."""

from __future__ import annotations

from typing import Union

from lxml import etree

from ..models.base import (
    AudioStimulus,
    ImageStimulus,
    Stimulus,
    TextStimulus,
    VideoStimulus,
)
from .base_builder import BaseBuilder, NSMAP, QTI_SCHEMA_LOCATION, XSI_NS


class StimulusBuilder(BaseBuilder):
    """Generates a standalone QTI 3.0 assessment stimulus XML document."""

    def build(
        self,
        stimulus: Union[Stimulus, list[Stimulus], None],
        identifier: str,
    ) -> str | None:
        if stimulus is None:
            return None
        self._reset_build_state(identifier)

        root = etree.Element(
            "qti-assessment-stimulus",
            nsmap=NSMAP,
            attrib={
                f"{{{XSI_NS}}}schemaLocation": QTI_SCHEMA_LOCATION,
                "identifier": identifier,
                "title": f"Stimulus {identifier}",
            },
        )

        stim_body = etree.SubElement(root, "qti-stimulus-body")

        if isinstance(stimulus, list):
            self._render_list(stim_body, stimulus)
        else:
            self._render_single(stim_body, stimulus)

        return self.serialize(root)

    def _render_single(
        self, parent: etree._Element, stimulus: Stimulus,
    ) -> None:
        div = etree.SubElement(parent, "div")
        div.set("class", "stimulus-container")

        if isinstance(stimulus, TextStimulus):
            content_html = self._process_content(stimulus.text)
            self._set_inner_html(div, content_html)

        elif isinstance(stimulus, ImageStimulus):
            img_html = self._build_image_tag(stimulus)
            self._set_inner_html(div, img_html)
            if stimulus.credit:
                credit = etree.SubElement(div, "p")
                credit.set("class", "credit")
                credit.text = stimulus.credit

        elif isinstance(stimulus, AudioStimulus):
            audio = etree.SubElement(div, "audio")
            audio.set("src", stimulus.url)
            audio.set("controls", "controls")

        elif isinstance(stimulus, VideoStimulus):
            video = etree.SubElement(div, "video")
            video.set("src", stimulus.url)
            video.set("controls", "controls")

    def _render_list(
        self, parent: etree._Element, stimuli: list[Stimulus],
    ) -> None:
        """Render multiple stimuli, wrapping in <details>/<summary> when labeled."""
        for stim in stimuli:
            label = getattr(stim, "label", None)
            if label:
                details = etree.SubElement(parent, "details")
                summary = etree.SubElement(details, "summary")
                summary.text = label
                self._render_single(details, stim)
            else:
                self._render_single(parent, stim)
