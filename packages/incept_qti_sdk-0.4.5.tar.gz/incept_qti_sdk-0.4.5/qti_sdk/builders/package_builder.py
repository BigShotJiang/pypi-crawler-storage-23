"""Builder for imsmanifest.xml content packaging."""

from __future__ import annotations

import uuid

from lxml import etree

from .._version import SDK_TOOL_NAME, SDK_TOOL_VERSION
from ..models.base import StandardAlignment
from .base_builder import BuildResult

CP_NS = "http://www.imsglobal.org/xsd/qti/qtiv3p0/imscp_v1p1"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"

CP_NSMAP = {
    None: CP_NS,
    "xsi": XSI_NS,
}

XML_NS = "http://www.w3.org/XML/1998/namespace"


def _sub(parent: etree._Element, tag: str, text: str | None = None) -> etree._Element:
    """Create an unprefixed child element (no namespace)."""
    el = etree.SubElement(parent, tag)
    if text is not None:
        el.text = text
    return el


def _langstring(parent: etree._Element, text: str, lang: str = "en") -> etree._Element:
    el = _sub(parent, "langstring", text)
    el.set(f"{{{XML_NS}}}lang", lang)
    return el


class PackageBuilder:
    """Generates an imsmanifest.xml for a batch of QTI items."""

    def build(
        self,
        results: list[BuildResult],
        package_id: str = "pkg_001",
        *,
        schema: str = "QTI Item Bank",
        pci_item_files: dict[str, list[str]] | None = None,
    ) -> str:
        root = etree.Element("manifest", nsmap=CP_NSMAP, attrib={"identifier": package_id})

        metadata = etree.SubElement(root, "metadata")
        schema_el = etree.SubElement(metadata, "schema")
        schema_el.text = schema
        sv = etree.SubElement(metadata, "schemaversion")
        sv.text = "3.0.1"

        etree.SubElement(root, "organizations")

        resources = etree.SubElement(root, "resources")
        seen_stimuli: set[str] = set()

        stim_standards = self._aggregate_stimulus_standards(results)

        for result in results:
            item_res = etree.SubElement(resources, "resource")
            item_res.set("identifier", result.item_id)
            item_res.set("type", "imsqti_item_xmlv3p0")
            item_res.set("href", f"items/{result.item_id}.xml")

            item_md = etree.SubElement(item_res, "metadata")

            self._emit_lom(item_md, result)
            self._emit_qti_metadata(item_md, result)
            self._emit_csm_block(item_md, result)

            f = etree.SubElement(item_res, "file")
            f.set("href", f"items/{result.item_id}.xml")

            if pci_item_files and result.item_id in pci_item_files:
                for pci_path in pci_item_files[result.item_id]:
                    pf = etree.SubElement(item_res, "file")
                    pf.set("href", pci_path)

            if result.stimulus_id:
                dep = etree.SubElement(item_res, "dependency")
                dep.set("identifierref", result.stimulus_id)

                if result.stimulus_id not in seen_stimuli:
                    seen_stimuli.add(result.stimulus_id)
                    stim_res = etree.SubElement(resources, "resource")
                    stim_res.set("identifier", result.stimulus_id)
                    stim_res.set("type", "imsqti_stimulus_xmlv3p0")
                    stim_res.set("href", f"stimuli/{result.stimulus_id}.xml")

                    stim_md = etree.SubElement(stim_res, "metadata")
                    self._emit_stimulus_lom(stim_md, result.stimulus_id)
                    self._emit_csm_standards(
                        stim_md,
                        stim_standards.get(result.stimulus_id, []),
                    )

                    sf = etree.SubElement(stim_res, "file")
                    sf.set("href", f"stimuli/{result.stimulus_id}.xml")

        return etree.tostring(
            root,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8",
        ).decode("utf-8")

    # ------------------------------------------------------------------
    # LOM — unprefixed elements so TimeBack's parser can find them.
    # The parser walks: lom → general → identifier → entry
    #                   lom → general → title → langstring
    #                   lom → classification → taxonPath → ...
    # ------------------------------------------------------------------

    @staticmethod
    def _emit_lom(parent: etree._Element, result: BuildResult) -> None:
        pkg = result.packaging

        lom = _sub(parent, "lom")

        # <general> with required identifier + title
        general = _sub(lom, "general")

        identifier = _sub(general, "identifier")
        _sub(identifier, "entry", result.item_id)

        title_el = _sub(general, "title")
        title_text = result.metadata.get("title", result.item_id)
        _langstring(title_el, title_text)

        # <classification> for timeback-extended-attributes
        taxons: list[tuple[str, str]] = []

        # RFC 9562-compliant UUID so TimeBack's cursor pagination (Zod z.uuid()) works
        tb_meta = dict(pkg.timeback_metadata) if pkg and pkg.timeback_metadata else {}
        if "expectedId" not in tb_meta:
            expected = uuid.uuid5(uuid.NAMESPACE_URL, result.item_id)
            taxons.append(("expectedId", str(expected)))

        if pkg is not None:
            taxons.append(("difficulty", str(pkg.difficulty)))

        if "serializer" not in tb_meta:
            taxons.append(("serializer", f"{SDK_TOOL_NAME}@{SDK_TOOL_VERSION}"))
        for key, val in tb_meta.items():
            taxons.append((key, val))

        classification = _sub(lom, "classification")
        taxon_path = _sub(classification, "taxonPath")

        source = _sub(taxon_path, "source")
        _langstring(source, "timeback-extended-attributes")

        for tid, tval in taxons:
            taxon = _sub(taxon_path, "taxon")
            _sub(taxon, "id", tid)
            entry = _sub(taxon, "entry")
            _langstring(entry, tval)

    # ------------------------------------------------------------------
    # Stimulus LOM — minimal identifier + title required by TimeBack
    # ------------------------------------------------------------------

    @staticmethod
    def _emit_stimulus_lom(parent: etree._Element, stimulus_id: str) -> None:
        lom = _sub(parent, "lom")
        general = _sub(lom, "general")

        identifier = _sub(general, "identifier")
        _sub(identifier, "entry", stimulus_id)

        title_el = _sub(general, "title")
        _langstring(title_el, f"Stimulus {stimulus_id}")

    # ------------------------------------------------------------------
    # QTI metadata — unprefixed
    # ------------------------------------------------------------------

    @staticmethod
    def _emit_qti_metadata(parent: etree._Element, result: BuildResult) -> None:
        qti_md = _sub(parent, "qtiMetadata")
        if result.metadata.get("interaction_type"):
            _sub(qti_md, "interactionType", result.metadata["interaction_type"])
        if result.metadata.get("feedback_type"):
            _sub(qti_md, "feedbackType", result.metadata["feedback_type"])
        _sub(qti_md, "toolName", SDK_TOOL_NAME)
        _sub(qti_md, "toolVersion", SDK_TOOL_VERSION)

    # ------------------------------------------------------------------
    # CSM block for curriculum standards — unprefixed
    # ------------------------------------------------------------------

    @staticmethod
    def _emit_csm_standards(
        parent: etree._Element,
        standards: list[StandardAlignment],
    ) -> None:
        """Emit a ``curriculumStandardsMetadataSet`` for the given standards."""
        if not standards:
            return

        csm_set = _sub(parent, "curriculumStandardsMetadataSet")
        csm_md = _sub(csm_set, "curriculumStandardsMetadata")
        guids = _sub(csm_md, "setOfGUIDs")

        for standard in standards:
            labelled = _sub(guids, "labelledGUID")
            _sub(labelled, "label", standard.label)
            _sub(labelled, "GUID", standard.case_item_uri)

    @staticmethod
    def _emit_csm_block(parent: etree._Element, result: BuildResult) -> None:
        pkg = result.packaging
        if pkg is None or not pkg.curriculum_standards:
            return

        resolved = [s for s in pkg.curriculum_standards if s.case_item_uri]
        PackageBuilder._emit_csm_standards(parent, resolved)

    # ------------------------------------------------------------------
    # Pre-pass: collect CASE standards for each stimulus from its items
    # ------------------------------------------------------------------

    @staticmethod
    def _aggregate_stimulus_standards(
        results: list[BuildResult],
    ) -> dict[str, list[StandardAlignment]]:
        """Collect unique resolved CASE standards per stimulus_id.

        Multiple items can share a stimulus; the stimulus resource must
        carry the union of all their CASE linkages.
        """
        stim_standards: dict[str, list[StandardAlignment]] = {}
        seen_guids: dict[str, set[str]] = {}

        for result in results:
            if not result.stimulus_id or not result.packaging:
                continue
            for std in result.packaging.curriculum_standards or []:
                if not std.case_item_uri:
                    continue
                guid_set = seen_guids.setdefault(result.stimulus_id, set())
                if std.case_item_uri not in guid_set:
                    guid_set.add(std.case_item_uri)
                    stim_standards.setdefault(result.stimulus_id, []).append(std)

        return stim_standards
