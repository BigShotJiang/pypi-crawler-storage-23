"""Post-processing transforms for BuildResult objects."""

from __future__ import annotations

from lxml import etree

from .base_builder import BuildResult, QTI_NS


def inline_stimulus(result: BuildResult) -> BuildResult:
    """Inline stimulus content into the item body, eliminating the separate stimulus file.

    Replaces <qti-assessment-stimulus-ref> with the actual stimulus body content
    prepended inside <qti-item-body>. Returns a new BuildResult with
    stimulus_xml and stimulus_id cleared.

    Pass-through for items with no stimulus.
    """
    if not result.stimulus_xml or not result.stimulus_id:
        return result

    item_root = etree.fromstring(result.item_xml.encode("utf-8"))
    stim_root = etree.fromstring(result.stimulus_xml.encode("utf-8"))

    stim_ref = item_root.find(f"{{{QTI_NS}}}qti-assessment-stimulus-ref")
    if stim_ref is not None:
        item_root.remove(stim_ref)

    stim_body = stim_root.find(f"{{{QTI_NS}}}qti-stimulus-body")
    item_body = item_root.find(f"{{{QTI_NS}}}qti-item-body")

    if stim_body is not None and item_body is not None:
        children = list(stim_body)
        for i, child in enumerate(children):
            item_body.insert(i, child)

    serialized = etree.tostring(
        item_root,
        pretty_print=True,
        xml_declaration=True,
        encoding="UTF-8",
    ).decode("utf-8")

    return BuildResult(
        item_xml=serialized,
        stimulus_xml=None,
        stimulus_id=None,
        item_id=result.item_id,
        metadata=result.metadata,
    )


def inline_all_stimuli(results: list[BuildResult]) -> list[BuildResult]:
    """Apply inline_stimulus to every result in a batch."""
    return [inline_stimulus(r) for r in results]
