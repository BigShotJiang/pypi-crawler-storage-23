"""Builder for composite QuestionItems (multiple interactions)."""

from __future__ import annotations

from lxml import etree

from ..exceptions import BuildError
from ..models.behaviors import (
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)
from ..models.question_item import QuestionItem
from ..templates._helpers import set_outcome
from ..templates._scoring import derive_interaction_max, derive_item_normal_maximum
from ..templates.choice_templates import ChoiceTemplates
from ..templates.extended_text_templates import ExtendedTextTemplates
from ..templates.match_templates import MatchTemplates
from ..templates.order_templates import OrderTemplates
from ..templates.pci_templates import PCITemplates
from ..templates.text_entry_templates import TextEntryTemplates
from ._naming import feedback_id as _feedback_id
from ._naming import response_id as _response_id
from ._naming import score_id as _score_id
from .base_builder import BaseBuilder, BuildResult
from .choice_builder import ChoiceBuilder
from .extended_text_builder import ExtendedTextBuilder
from .match_builder import MatchBuilder
from .order_builder import OrderBuilder
from .pci_builder import PCIBuilder
from .text_entry_builder import TextEntryBuilder

Interaction = ChoiceConfig | TextEntryConfig | ExtendedTextConfig | MatchConfig | OrderConfig | PCIConfig

_TEMPLATE_MAP: dict[str, type] = {
    "choice": ChoiceTemplates,
    "text_entry": TextEntryTemplates,
    "extended_text": ExtendedTextTemplates,
    "match": MatchTemplates,
    "order": OrderTemplates,
    "pci": PCITemplates,
}

_INTERACTION_TYPE_LABEL: dict[str, str] = {
    "choice": "choiceInteraction",
    "text_entry": "textEntryInteraction",
    "extended_text": "extendedTextInteraction",
    "match": "matchInteraction",
    "order": "orderInteraction",
    "pci": "portableCustomInteraction",
}


class CompositeBuilder(BaseBuilder):
    """Builds a composite QTI item from multiple interactions."""

    def __init__(self) -> None:
        super().__init__()
        self._choice = ChoiceBuilder()
        self._text_entry = TextEntryBuilder()
        self._extended_text = ExtendedTextBuilder()
        self._match = MatchBuilder()
        self._order = OrderBuilder()
        self._pci = PCIBuilder()

    def build(self, item: QuestionItem) -> BuildResult:
        """Build a composite item with multiple interactions into QTI 3.0 XML.

        Combines response declarations, per-interaction scoring, and a
        shared item body stem.  The total SCORE is the sum of all
        per-interaction scores and dimension scores.
        """
        n = len(item.interactions)
        is_composite = n > 1

        item_id = self._make_item_id("composite", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "CompositeInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        # Per-interaction response declarations
        for i, config in enumerate(item.interactions):
            resp_id = _response_id(i, is_composite)
            children.extend(self._response_decls_for(item, config, resp_id))

        # End-attempt response declaration (adaptive)
        if is_adaptive:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT", "single", "boolean",
                )
            )

        # Outcome declarations
        children.extend(self._build_composite_outcomes(item, is_composite))

        # Template declarations & processing
        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        # Stimulus ref (item-level)
        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus, item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        # Companion materials
        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        # Item body
        children.append(
            self._build_composite_item_body(item, is_composite, is_adaptive),
        )

        # Catalog info
        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        # Response processing
        rp = self._build_composite_rp(item, is_composite)
        if rp is not None:
            children.append(rp)

        # Modal feedback elements (after response processing per QTI schema)
        fmt = self._get_format_map(item)
        children.extend(
            self._build_modal_feedback_elements(item.feedback, format_map=fmt),
        )

        root = self._build_assessment_item(
            item_id, title, is_adaptive, children,
            lang=item.lang, extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder
            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        types = [_INTERACTION_TYPE_LABEL.get(c.type, c.type) for c in item.interactions]
        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "composite",
                "interaction_types": ",".join(types),
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    # ------------------------------------------------------------------
    # Response declarations
    # ------------------------------------------------------------------

    def _response_decls_for(
        self, item: QuestionItem, config: Interaction, resp_id: str,
    ) -> list[etree._Element]:
        if isinstance(config, ChoiceConfig):
            correct_ids = [c.id for c in config.choices if c.correct]
            cardinality = "multiple" if config.max_selections != 1 else "single"
            return [
                self._build_response_declaration(
                    resp_id, cardinality, "identifier", correct_ids,
                    mapping=config.score_map,
                )
            ]

        if isinstance(config, TextEntryConfig):
            return self._text_entry._build_response_decls(item, config, resp_id)

        if isinstance(config, ExtendedTextConfig):
            return [
                self._build_response_declaration(resp_id, "single", "string")
            ]

        if isinstance(config, MatchConfig):
            correct_pairs = [f"{s} {t}" for s, t in config.correct_mapping]
            return [
                self._build_response_declaration(
                    resp_id, "multiple", "directedPair", correct_pairs,
                    mapping=config.score_map,
                )
            ]

        if isinstance(config, OrderConfig):
            return [
                self._build_response_declaration(
                    resp_id, "ordered", "identifier", config.correct_order,
                )
            ]

        if isinstance(config, PCIConfig):
            return [
                self._build_response_declaration(resp_id, "single", "string")
            ]

        raise BuildError(f"Unknown interaction type: {config.type}")

    # ------------------------------------------------------------------
    # Outcome declarations
    # ------------------------------------------------------------------

    def _build_composite_outcomes(
        self, item: QuestionItem, is_composite: bool,
    ) -> list[etree._Element]:
        outcomes: list[etree._Element] = []
        normal_max = derive_item_normal_maximum(item)
        ext_scored = "human" if isinstance(item.behavior, ExternalGraded) else None

        # Item-level SCORE and MAXSCORE
        outcomes.append(
            self._build_outcome_declaration(
                "SCORE", "float", default_value="0",
                normal_maximum=normal_max,
                external_scored=ext_scored,
            ),
        )
        outcomes.append(
            self._build_outcome_declaration(
                "MAXSCORE", "float", default_value=str(normal_max),
            ),
        )

        # completionStatus (adaptive)
        if self._is_adaptive(item.behavior):
            outcomes.append(
                self._build_outcome_declaration(
                    "completionStatus", "identifier", default_value="unknown",
                )
            )

        # Per-dimension outcome declarations
        if item.scoring_dimensions:
            for dim in item.scoring_dimensions:
                dim_ext = "human" if dim.scoring_method == "human" else None
                outcomes.append(
                    self._build_outcome_declaration(
                        dim.name, "float", default_value="0",
                        normal_maximum=dim.max_score,
                        external_scored=dim_ext,
                    ),
                )

        # Per-interaction SCORE_i (only for untargeted interactions) and FEEDBACK_i
        has_feedback = not isinstance(
            item.behavior, (SummativeBehavior, ExternalGraded),
        )
        for i, config in enumerate(item.interactions):
            td = getattr(config, "target_dimension", None)
            if not td:
                sid = _score_id(i, is_composite)
                i_max = derive_interaction_max(item, config)
                outcomes.append(
                    self._build_outcome_declaration(
                        sid, "float", default_value="0",
                        normal_maximum=i_max,
                    ),
                )
            if has_feedback:
                fid = _feedback_id(i, is_composite)
                outcomes.append(
                    self._build_outcome_declaration(fid, "identifier"),
                )

        # Scaffold outcomes (item-level, from Feedback entries)
        all_fb = self._collect_all_feedback(item)
        fb_types = self._feedback_type_set(all_fb)
        if "hint" in fb_types:
            outcomes.append(
                self._build_outcome_declaration("HINT_FEEDBACK", "identifier"),
            )
        if "solution_steps" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "WORKED_SOLUTION_FEEDBACK", "identifier",
                ),
            )
        if "learning_content" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "LEARNING_CONTENT_FEEDBACK", "identifier",
                ),
            )
        if "answer_reveal" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "REVEAL_ANSWER_FEEDBACK", "identifier",
                ),
            )

        if any(fb.type == "explanation" for fb in item.feedback):
            outcomes.append(
                self._build_outcome_declaration("MODAL_FEEDBACK", "identifier"),
            )

        return outcomes

    # ------------------------------------------------------------------
    # Item body
    # ------------------------------------------------------------------

    def _build_composite_item_body(
        self,
        item: QuestionItem,
        is_composite: bool,
        is_adaptive: bool,
    ) -> etree._Element:
        body = etree.Element("qti-item-body")

        # Rubric block
        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        # Shared stem
        fmt = self._get_format_map(item)
        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        has_feedback = not isinstance(
            item.behavior, (SummativeBehavior, ExternalGraded),
        )

        # Per-interaction elements
        for i, config in enumerate(item.interactions):
            resp_id = _response_id(i, is_composite)
            fid = _feedback_id(i, is_composite) if has_feedback else "FEEDBACK"

            # Part label
            label = getattr(config, "label", None)
            if label:
                label_div = etree.SubElement(
                    body, "div", attrib={"class": "part-label"},
                )
                label_div.text = label

            # Interaction element
            el = self._interaction_element_for(item, config, resp_id, fid)
            body.append(el)

            # Per-interaction feedback blocks (formative/diagnostic)
            if has_feedback and not isinstance(config, (ExtendedTextConfig, PCIConfig)):
                body.append(self._build_feedback_block(
                    identifier="correct",
                    outcome_identifier=fid,
                    content_html="<p>Correct!</p>",
                    css_class="qti-feedback-correct",
                ))
                body.append(self._build_feedback_block(
                    identifier="incorrect",
                    outcome_identifier=fid,
                    content_html="<p>Incorrect.</p>",
                    css_class="qti-feedback-incorrect",
                ))

        # Scaffold feedback blocks (item-level)
        for fb in self._build_scaffold_feedback(list(item.feedback), format_map=fmt):
            body.append(fb)

        # Combined reveal-answer block (when answer_reveal feedback present)
        if any(fb.type == "answer_reveal" for fb in item.feedback):
            body.append(self._build_combined_reveal_answer(item))

        # End-attempt interaction (adaptive)
        if is_adaptive:
            body.append(self._build_end_attempt_interaction())

        return body

    def _interaction_element_for(
        self,
        item: QuestionItem,
        config: Interaction,
        resp_id: str,
        feedback_id: str,
    ) -> etree._Element:
        if isinstance(config, ChoiceConfig):
            return self._choice._build_interaction_element(
                item, config, resp_id, feedback_id,
            )
        if isinstance(config, TextEntryConfig):
            return self._build_text_entry_composite_element(
                item, config, resp_id,
            )
        if isinstance(config, ExtendedTextConfig):
            return self._extended_text._build_interaction_element(
                item, config, resp_id, feedback_id,
            )
        if isinstance(config, MatchConfig):
            return self._match._build_interaction_element(
                item, config, resp_id, feedback_id,
            )
        if isinstance(config, OrderConfig):
            return self._order._build_interaction_element(
                item, config, resp_id, feedback_id,
            )
        if isinstance(config, PCIConfig):
            return self._pci._build_interaction_element(
                item, config, resp_id, feedback_id,
            )
        raise BuildError(f"Unknown interaction type: {config.type}")

    def _build_text_entry_composite_element(
        self,
        item: QuestionItem,
        config: TextEntryConfig,
        resp_id: str,
    ) -> etree._Element:
        """Build a text entry section for a composite item.

        If the config has a prompt with blanks, processes it. Otherwise
        renders a simple ``<qti-text-entry-interaction>`` element.
        """
        from ..templates.text_entry_templates import _response_id_for_blank

        div = etree.Element("div", attrib={"class": "text-entry-part"})
        expected_length = self._text_entry._calculate_expected_length(config)

        if config.prompt:
            fmt = self._get_format_map(item)
            prompt_html = self._process_content(config.prompt, format_map=fmt)

            if not config.is_multi_blank:
                interaction_xml = (
                    f'<qti-text-entry-interaction '
                    f'response-identifier="{resp_id}" '
                    f'expected-length="{expected_length}" '
                    f'class="inline-text-entry"/>'
                )
                prompt_html = prompt_html.replace("&lt;blank&gt;", interaction_xml)
            else:
                for bid in reversed(config.blank_ids):
                    rid = _response_id_for_blank(bid, resp_id)
                    interaction_xml = (
                        f'<qti-text-entry-interaction '
                        f'response-identifier="{rid}" '
                        f'expected-length="{expected_length}" '
                        f'class="inline-text-entry"/>'
                    )
                    placeholder = f"&lt;{bid}&gt;"
                    prompt_html = prompt_html.replace(placeholder, interaction_xml)

            self._set_inner_html(div, prompt_html)
        else:
            etree.SubElement(
                div, "qti-text-entry-interaction",
                attrib={
                    "response-identifier": resp_id,
                    "expected-length": str(expected_length),
                    "class": "inline-text-entry",
                },
            )

        return div

    def _build_combined_reveal_answer(
        self, item: QuestionItem,
    ) -> etree._Element:
        """Build a single reveal-answer block covering all interactions."""
        parts: list[str] = []
        for config in item.interactions:
            parts.append(self._reveal_answer_text_for(config))

        html = "<div>" + "".join(
            f"<p>{part}</p>" for part in parts
        ) + "</div>"

        return self._build_feedback_block(
            identifier="reveal_answer_feedback",
            outcome_identifier="REVEAL_ANSWER_FEEDBACK",
            content_html=html,
            css_class="reveal-answer",
        )

    @staticmethod
    def _reveal_answer_text_for(config: Interaction) -> str:
        if isinstance(config, ChoiceConfig):
            correct = [c.content for c in config.choices if c.correct]
            return f"<strong>Correct answer:</strong> {', '.join(correct)}"
        if isinstance(config, TextEntryConfig):
            if isinstance(config.answers, dict):
                parts = [
                    f"{bid}: {', '.join(vals)}"
                    for bid, vals in config.answers.items()
                ]
                return f"<strong>Correct answer:</strong> {'; '.join(parts)}"
            return f"<strong>Correct answer:</strong> {', '.join(config.answers)}"
        if isinstance(config, OrderConfig):
            return f"<strong>Correct order:</strong> {' → '.join(config.correct_order)}"
        if isinstance(config, MatchConfig):
            pairs = [f"{s} → {t}" for s, t in config.correct_mapping]
            return f"<strong>Correct matching:</strong> {', '.join(pairs)}"
        return "<strong>See the correct answer above.</strong>"

    # ------------------------------------------------------------------
    # Response processing
    # ------------------------------------------------------------------

    def _build_composite_rp(
        self, item: QuestionItem, is_composite: bool,
    ) -> etree._Element | None:
        if isinstance(item.behavior, ExternalGraded):
            return None

        rp = etree.Element("qti-response-processing")

        has_feedback = not isinstance(
            item.behavior, (SummativeBehavior, ExternalGraded),
        )

        # Per-interaction RP fragments
        for i, config in enumerate(item.interactions):
            resp_id = _response_id(i, is_composite)
            td = getattr(config, "target_dimension", None)
            sid = td if td else _score_id(i, is_composite)
            fid = _feedback_id(i, is_composite) if has_feedback else None

            template_cls = _TEMPLATE_MAP.get(config.type)
            if template_cls is None:
                raise BuildError(f"No template for type: {config.type}")

            fragments = template_cls.get_interaction_rp(
                item, config, resp_id, sid, fid,
            )
            for el in fragments:
                rp.append(el)

        # Item-level total score: SCORE = sum(SCORE_1 ... SCORE_N)
        self._append_total_score(rp, item, is_composite)

        # Modal feedback level comparison (after scoring is final)
        if any(fb.type == "explanation" for fb in item.feedback):
            from ..templates._helpers import build_modal_feedback_rp
            build_modal_feedback_rp(rp)

        # Item-level completionStatus (adaptive)
        if self._is_adaptive(item.behavior):
            self._append_completion_status(rp)

        # Scaffold triggers (item-level, from Feedback entries)
        if self._is_adaptive(item.behavior) and isinstance(item.behavior, FeedbackEnabled):
            self._append_scaffold_triggers(rp, item)

        return rp

    def _append_total_score(
        self,
        rp: etree._Element,
        item: QuestionItem,
        is_composite: bool,
    ) -> None:
        """SCORE = sum of dimension variables + untargeted SCORE_N variables."""
        sov = etree.SubElement(
            rp, "qti-set-outcome-value", attrib={"identifier": "SCORE"},
        )
        sum_el = etree.SubElement(sov, "qti-sum")

        added_dims: set[str] = set()
        for i, config in enumerate(item.interactions):
            td = getattr(config, "target_dimension", None)
            if td:
                if td not in added_dims:
                    etree.SubElement(sum_el, "qti-variable", attrib={"identifier": td})
                    added_dims.add(td)
            else:
                sid = _score_id(i, is_composite)
                etree.SubElement(sum_el, "qti-variable", attrib={"identifier": sid})

    def _append_completion_status(self, rp: etree._Element) -> None:
        """completionStatus = completed if SCORE >= MAXSCORE else incomplete."""
        cond = etree.SubElement(rp, "qti-response-condition")

        if_el = etree.SubElement(cond, "qti-response-if")
        gte = etree.SubElement(if_el, "qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
        set_outcome(if_el, "completionStatus", "identifier", "completed")

        else_el = etree.SubElement(cond, "qti-response-else")
        set_outcome(else_el, "completionStatus", "identifier", "incomplete")

    def _append_scaffold_triggers(
        self,
        rp: etree._Element,
        item: QuestionItem,
    ) -> None:
        """Append scaffold RP conditions from Feedback entries and FeedbackPolicy."""
        _SCAFFOLD_OUTCOME_MAP: dict[str, tuple[str, str]] = {
            "hint": ("HINT_FEEDBACK", "hint_feedback"),
            "solution_steps": ("WORKED_SOLUTION_FEEDBACK", "worked_solution_feedback"),
            "learning_content": ("LEARNING_CONTENT_FEEDBACK", "learning_content_feedback"),
            "answer_reveal": ("REVEAL_ANSWER_FEEDBACK", "reveal_answer_feedback"),
        }
        behavior: FeedbackEnabled = item.behavior  # type: ignore[assignment]
        all_fb: list = list(item.feedback)
        for config in item.interactions:
            all_fb.extend(getattr(config, "feedback", []))

        seen: set[str] = set()
        for fb in all_fb:
            entry = _SCAFFOLD_OUTCOME_MAP.get(fb.type)
            if entry is None or fb.type in seen:
                continue
            seen.add(fb.type)
            outcome_id, element_id = entry

            show = fb.show_when
            if show is None:
                show = getattr(behavior.policy, fb.type, None)
            if show is None:
                continue

            cond = etree.SubElement(rp, "qti-response-condition")
            if_el = etree.SubElement(cond, "qti-response-if")
            self._build_show_condition(if_el, show)
            set_outcome(if_el, outcome_id, "identifier", element_id)

    def _build_show_condition(self, parent: etree._Element, show) -> None:
        """Translate a ShowCondition into QTI RP condition elements."""
        parts: list[etree._Element] = []
        if show.after_attempt is not None:
            gte = etree.Element("qti-gte")
            etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
            bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
            bv.text = str(show.after_attempt)
            parts.append(gte)
        if show.on_correct is False:
            lt = etree.Element("qti-lt")
            etree.SubElement(lt, "qti-variable", attrib={"identifier": "SCORE"})
            etree.SubElement(lt, "qti-variable", attrib={"identifier": "MAXSCORE"})
            parts.append(lt)
        elif show.on_correct is True:
            gte = etree.Element("qti-gte")
            etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
            etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
            parts.append(gte)
        if len(parts) > 1:
            and_el = etree.SubElement(parent, "qti-and")
            for p in parts:
                and_el.append(p)
        elif parts:
            parent.append(parts[0])

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

