"""Builder for QuestionItem with MatchConfig -> QTI 3.0 XML."""

from __future__ import annotations

from collections import Counter

from lxml import etree

from ..models.behaviors import (
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.interactions import MatchConfig
from ..models.question_item import QuestionItem
from ..templates.match_templates import MatchTemplates
from .base_builder import BaseBuilder, BuildResult


class MatchBuilder(BaseBuilder):
    """Converts a QuestionItem with a single MatchConfig into QTI 3.0 XML."""

    def build(self, item: QuestionItem) -> BuildResult:
        """Build a matching / drag-and-drop item into QTI 3.0 XML.

        Pairs source items with target items according to ``correct_mapping``.
        Supports categorization (many-to-one) via ``max_associations`` and
        per-pair score mappings.
        """
        config: MatchConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("match", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "MatchInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        correct_pairs = [
            f"{src} {tgt}" for src, tgt in config.correct_mapping
        ]
        children.append(
            self._build_response_declaration(
                "RESPONSE", "multiple", "directedPair", correct_pairs,
                mapping=config.score_map,
            )
        )

        if is_adaptive:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT", "single", "boolean",
                )
            )

        children.extend(self._build_outcome_declarations(item))

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus, item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        children.append(self._build_item_body(item, config, is_adaptive))

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        sid = self._effective_score_id(config)
        rp = MatchTemplates.get(item, config, score_id=sid)
        if rp is not None:
            self._append_dimension_to_score(rp, item)
            if any(fb.type == "explanation" for fb in item.feedback):
                from ..templates._helpers import build_modal_feedback_rp
                build_modal_feedback_rp(rp)
            children.append(rp)

        fmt = self._get_format_map(item)
        children.extend(
            self._build_modal_feedback_elements(item.feedback, format_map=fmt),
        )

        root = self._build_assessment_item(
            item_id, title, is_adaptive, children,
            lang=item.lang, extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder
            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "matchInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: MatchConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-match-interaction>`` element with source/target sets."""
        max_assoc = config.max_associations or len(config.correct_mapping)
        interaction = etree.Element("qti-match-interaction")
        interaction.set("response-identifier", response_id)
        interaction.set("max-associations", str(max_assoc))
        if config.shuffle:
            interaction.set("shuffle", "true")

        fmt = self._get_format_map(item)

        if config.prompt:
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        target_counts = Counter(tgt for _, tgt in config.correct_mapping)

        source_set_el = etree.SubElement(interaction, "qti-simple-match-set")
        for src_item in config.source_set:
            choice = etree.SubElement(source_set_el, "qti-simple-associable-choice")
            choice.set("identifier", src_item.id)
            choice.set("match-max", "1")
            if src_item.fixed:
                choice.set("fixed", "true")

            choice_html = self._process_content(src_item.content, format_map=fmt)
            self._set_inner_html(choice, choice_html)

        target_set_el = etree.SubElement(interaction, "qti-simple-match-set")
        for tgt_item in config.target_set:
            choice = etree.SubElement(target_set_el, "qti-simple-associable-choice")
            choice.set("identifier", tgt_item.id)
            choice.set("match-max", str(target_counts.get(tgt_item.id, 1)))
            if tgt_item.fixed:
                choice.set("fixed", "true")

            choice_html = self._process_content(tgt_item.content, format_map=fmt)
            self._set_inner_html(choice, choice_html)

        return interaction

    def _build_match_explanation_blocks(
        self,
        feedback_entries: list,
        format_map: dict | None,
    ) -> list:
        """Build feedback blocks for explanation content (correct/incorrect).

        For match (all-or-nothing), explanations are shown in blocks when
        FEEDBACK is set to 'correct' or 'incorrect' by response processing.
        """
        from ..models.base import Feedback

        explanations = [fb for fb in feedback_entries if isinstance(fb, Feedback) and fb.type == "explanation"]
        if not explanations:
            return []

        correct_parts: list[str] = []
        incorrect_parts: list[str] = []
        for fb in explanations:
            on_correct = fb.show_when.on_correct if fb.show_when else None
            html = self._render_feedback_content(fb, format_map=format_map)
            if on_correct is False:
                incorrect_parts.append(html)
            elif on_correct is True:
                correct_parts.append(html)
            else:
                correct_parts.append(html)
                incorrect_parts.append(html)

        blocks: list = []
        if correct_parts:
            combined = "<div class='explanation'>" + "".join((f"<div>{p}</div>" for p in correct_parts)) + "</div>"
            blocks.append(self._build_feedback_block(
                identifier="correct",
                outcome_identifier="FEEDBACK",
                content_html=combined,
                css_class="explanation",
            ))
        if incorrect_parts:
            combined = "<div class='explanation'>" + "".join((f"<div>{p}</div>" for p in incorrect_parts)) + "</div>"
            blocks.append(self._build_feedback_block(
                identifier="incorrect",
                outcome_identifier="FEEDBACK",
                content_html=combined,
                css_class="explanation",
            ))
        return blocks

    def _build_item_body(
        self, item: QuestionItem, config: MatchConfig, is_adaptive: bool,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        _all_fb = list(getattr(config, "feedback", [])) + list(item.feedback)
        for mi in config.source_set + config.target_set:
            _all_fb.extend(getattr(mi, "feedback", []))
        for fb in self._build_scaffold_feedback(_all_fb, format_map=fmt):
            body.append(fb)

        if any(fb.type == "answer_reveal" for fb in _all_fb):
            body.append(self._build_reveal_answer_block(config))

        if isinstance(item.behavior, FeedbackEnabled):
            for block in self._build_match_explanation_blocks(_all_fb, fmt):
                body.append(block)

        if is_adaptive:
            body.append(self._build_end_attempt_interaction())

        return body
