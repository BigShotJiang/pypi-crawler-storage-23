"""Builder for QuestionItem with OrderConfig -> QTI 3.0 XML."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import FeedbackEnabled
from ..models.interactions import OrderConfig
from ..models.question_item import QuestionItem
from ..templates.order_templates import OrderTemplates
from .base_builder import BaseBuilder, BuildResult


class OrderBuilder(BaseBuilder):
    """Converts a QuestionItem with a single OrderConfig into QTI 3.0 XML."""

    def build(self, item: QuestionItem) -> BuildResult:
        """Build an ordering / sequencing item into QTI 3.0 XML.

        Students arrange items into the sequence defined by ``correct_order``.
        Supports optional partial credit (points per correctly-placed item).
        """
        config: OrderConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("order", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "OrderInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        children.append(
            self._build_response_declaration(
                "RESPONSE", "ordered", "identifier", config.correct_order,
            )
        )

        if is_adaptive:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT", "single", "boolean",
                )
            )

        children.extend(self._build_outcome_declarations(item))

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus, item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        children.append(self._build_item_body(item, config, is_adaptive))

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        sid = self._effective_score_id(config)
        rp = OrderTemplates.get(item, config, score_id=sid)
        if rp is not None:
            self._append_dimension_to_score(rp, item)
            if any(fb.type == "explanation" for fb in item.feedback):
                from ..templates._helpers import build_modal_feedback_rp
                build_modal_feedback_rp(rp)
            children.append(rp)

        fmt = self._get_format_map(item)
        children.extend(
            self._build_modal_feedback_elements(item.feedback, format_map=fmt),
        )

        root = self._build_assessment_item(
            item_id, title, is_adaptive, children,
            lang=item.lang, extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder
            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "orderInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: OrderConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-order-interaction>`` element with choices."""
        interaction = etree.Element("qti-order-interaction")
        interaction.set("response-identifier", response_id)
        if config.shuffle:
            interaction.set("shuffle", "true")

        fmt = self._get_format_map(item)

        if config.prompt:
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        for order_item in config.items:
            simple_choice = etree.SubElement(interaction, "qti-simple-choice")
            simple_choice.set("identifier", order_item.id)

            choice_html = self._process_content(order_item.content, format_map=fmt)
            self._set_inner_html(simple_choice, choice_html)

        return interaction

    def _build_item_body(
        self, item: QuestionItem, config: OrderConfig, is_adaptive: bool,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        _all_fb = list(getattr(config, "feedback", [])) + list(item.feedback)
        for oi in config.items:
            _all_fb.extend(oi.feedback)
        for fb in self._build_scaffold_feedback(_all_fb, format_map=fmt):
            body.append(fb)

        if any(fb.type == "answer_reveal" for fb in _all_fb):
            body.append(self._build_reveal_answer_block(config))

        if isinstance(item.behavior, FeedbackEnabled):
            _order_explanations = [
                fbe for oi in config.items for fbe in oi.feedback
                if fbe.type == "explanation"
            ]
            if _order_explanations:
                parts = [
                    self._render_feedback_content(fbe, format_map=fmt)
                    for fbe in _order_explanations
                ]
                body.append(self._build_feedback_block(
                    identifier="correct",
                    outcome_identifier="FEEDBACK",
                    content_html="".join(parts),
                    css_class="explanation",
                ))

        if is_adaptive:
            body.append(self._build_end_attempt_interaction())

        return body
