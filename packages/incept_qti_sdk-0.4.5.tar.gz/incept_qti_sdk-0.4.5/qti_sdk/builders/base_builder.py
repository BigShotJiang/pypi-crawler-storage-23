"""Shared XML assembly logic for all QTI builders."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Sequence, Union

from lxml import etree

from .._version import SDK_TOOL_NAME, SDK_TOOL_VERSION
from ..content.pipeline import ContentPipeline
from ..content.svg_extractor import extract_inline_svgs, restore_img_placeholders
from ..models.base import (
    AccessibilityCatalogEntry,
    AudioStimulus,
    CompanionMaterials,
    Feedback,
    ImageStimulus,
    ItemPackaging,
    LearningContent,
    Stimulus,
    TextLearningContent,
    TextStimulus,
    VideoLearningContent,
    VideoStimulus,
)
from ..models.behaviors import (
    AssessmentBehavior,
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.scoring import (
    ChoiceScoreMap,
    MatchScoreMap,
    TextEntryScoreMap,
)

if TYPE_CHECKING:
    from ..models.question_item import QuestionItem

ScoreMapType = Union[ChoiceScoreMap, TextEntryScoreMap, MatchScoreMap]

QTI_NS = "http://www.imsglobal.org/xsd/imsqtiasi_v3p0"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
QTI_SCHEMA_LOCATION = (
    "http://www.imsglobal.org/xsd/imsqtiasi_v3p0 "
    "https://purl.imsglobal.org/spec/qti/v3p0/schema/xsd/imsqti_asiv3p0_v1p0.xsd"
)

NSMAP = {None: QTI_NS, "xsi": XSI_NS}


@dataclass
class BuildResult:
    """Output of a builder: the item XML and optionally stimulus file(s)."""

    item_xml: str
    stimulus_xml: str | None = None
    stimulus_id: str | None = None
    item_id: str = ""
    metadata: dict[str, str] = field(default_factory=dict)
    packaging: ItemPackaging | None = None
    generated_assets: dict[str, str] = field(default_factory=dict)


class BaseBuilder:
    """Shared XML assembly methods used by all interaction builders."""

    def __init__(self) -> None:
        self.pipeline = ContentPipeline()
        self._generated_assets: dict[str, str] = {}
        self._current_item_id: str = ""

    def _reset_build_state(self, item_id: str) -> None:
        """Reset per-build state. Call at the start of every build()."""
        self._generated_assets = {}
        self._current_item_id = item_id

    def _process_content(
        self,
        text: str,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Extract inline SVGs then run the content pipeline."""
        text, svgs, img_map = extract_inline_svgs(text, self._current_item_id)
        self._generated_assets.update(svgs)
        result = self.pipeline.process(text, format_map=format_map)
        return restore_img_placeholders(result, img_map)

    @staticmethod
    def _make_item_id(prefix: str, override: str | None = None) -> str:
        if override:
            return override
        return f"{prefix}_{uuid.uuid4().hex[:12]}"

    @staticmethod
    def _content_hash(content: str) -> str:
        """Hash used for stimulus deduplication (not item IDs)."""
        import hashlib
        return hashlib.sha256(content.encode()).hexdigest()

    @staticmethod
    def _is_adaptive(behavior: AssessmentBehavior) -> bool:
        return isinstance(behavior, FeedbackEnabled) and behavior.max_attempts > 1

    # --- Root element ---

    def _build_assessment_item(
        self,
        identifier: str,
        title: str,
        adaptive: bool,
        children: list[etree._Element],
        *,
        lang: str | None = None,
        extension_attributes: dict[str, str] | None = None,
    ) -> etree._Element:
        attrib: dict[str, str] = {
            f"{{{XSI_NS}}}schemaLocation": QTI_SCHEMA_LOCATION,
            "identifier": identifier,
            "title": title,
            "adaptive": str(adaptive).lower(),
            "time-dependent": "false",
            "tool-name": SDK_TOOL_NAME,
            "tool-version": SDK_TOOL_VERSION,
        }
        if lang is not None:
            attrib["{http://www.w3.org/XML/1998/namespace}lang"] = lang
        if extension_attributes:
            attrib.update(extension_attributes)
        root = etree.Element("qti-assessment-item", nsmap=NSMAP, attrib=attrib)
        for child in children:
            root.append(child)
        return root

    # --- Context declarations ---

    def _build_context_declarations(
        self,
        context_declarations: list | None,
    ) -> list[etree._Element]:
        """Build ``<qti-context-declaration>`` elements from ContextVariable list."""
        if not context_declarations:
            return []
        elements: list[etree._Element] = []
        for cv in context_declarations:
            attrib: dict[str, str] = {
                "identifier": cv.identifier,
                "cardinality": cv.cardinality,
            }
            if cv.base_type is not None:
                attrib["base-type"] = cv.base_type
            el = etree.Element("qti-context-declaration", attrib=attrib)
            if cv.default_value is not None:
                dv = etree.SubElement(el, "qti-default-value")
                v = etree.SubElement(dv, "qti-value")
                v.text = cv.default_value
            elements.append(el)
        return elements

    # --- Declarations ---

    def _build_response_declaration(
        self,
        identifier: str,
        cardinality: str,
        base_type: str,
        correct_values: Sequence[str] | None = None,
        mapping: ScoreMapType | None = None,
    ) -> etree._Element:
        el = etree.Element(
            "qti-response-declaration",
            attrib={
                "identifier": identifier,
                "cardinality": cardinality,
                "base-type": base_type,
            },
        )
        if correct_values:
            cr = etree.SubElement(el, "qti-correct-response")
            for val in correct_values:
                v = etree.SubElement(cr, "qti-value")
                v.text = val
        if mapping is not None:
            el.append(self._build_mapping(mapping))
        return el

    @staticmethod
    def _build_mapping(score_map: ScoreMapType) -> etree._Element:
        """Build a ``<qti-mapping>`` element from a score map model."""
        attrib: dict[str, str] = {
            "default-value": str(score_map.default_value),
        }
        lb = getattr(score_map, "lower_bound", None)
        ub = getattr(score_map, "upper_bound", None)
        if lb is not None:
            attrib["lower-bound"] = str(lb)
        if ub is not None:
            attrib["upper-bound"] = str(ub)

        mapping_el = etree.Element("qti-mapping", attrib=attrib)

        if isinstance(score_map, ChoiceScoreMap):
            for key, val in score_map.entries.items():
                etree.SubElement(
                    mapping_el, "qti-map-entry",
                    attrib={"map-key": key, "mapped-value": str(val)},
                )
        elif isinstance(score_map, TextEntryScoreMap):
            cs = str(score_map.case_sensitive).lower()
            for key, val in score_map.entries.items():
                etree.SubElement(
                    mapping_el, "qti-map-entry",
                    attrib={
                        "map-key": key,
                        "mapped-value": str(val),
                        "case-sensitive": cs,
                    },
                )
        elif isinstance(score_map, MatchScoreMap):
            for entry in score_map.entries:
                etree.SubElement(
                    mapping_el, "qti-map-entry",
                    attrib={
                        "map-key": f"{entry.source} {entry.target}",
                        "mapped-value": str(entry.score),
                    },
                )

        return mapping_el

    def _build_outcome_declaration(
        self,
        identifier: str,
        base_type: str,
        cardinality: str = "single",
        default_value: str | None = None,
        normal_maximum: float | None = None,
        external_scored: str | None = None,
    ) -> etree._Element:
        attrib: dict[str, str] = {
            "identifier": identifier,
            "cardinality": cardinality,
            "base-type": base_type,
        }
        if normal_maximum is not None:
            attrib["normal-maximum"] = str(normal_maximum)
        if external_scored is not None:
            attrib["external-scored"] = external_scored
        el = etree.Element("qti-outcome-declaration", attrib=attrib)
        if default_value is not None:
            dv = etree.SubElement(el, "qti-default-value")
            v = etree.SubElement(dv, "qti-value")
            v.text = default_value
        return el

    @staticmethod
    def _collect_all_feedback(item: QuestionItem) -> list[Feedback]:
        """Collect all feedback entries across the entire item."""
        all_fb: list[Feedback] = list(item.feedback)
        for interaction in item.interactions:
            all_fb.extend(getattr(interaction, "feedback", []))
            for attr in ("choices", "items", "source_set", "target_set"):
                for sub in getattr(interaction, attr, []):
                    all_fb.extend(getattr(sub, "feedback", []))
        return all_fb

    @staticmethod
    def _feedback_type_set(entries: list[Feedback]) -> set[str]:
        return {fb.type for fb in entries}

    def _build_outcome_declarations(
        self,
        item: QuestionItem,
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
        normal_max: float | None = None,
        supports_reveal: bool = True,
        supports_modal: bool = True,
    ) -> list[etree._Element]:
        """Build the standard set of outcome declarations for an item.

        Derives scaffold/modal outcome variables from ``Feedback`` entries
        instead of behavior-type fields.
        """
        from ..templates._scoring import derive_item_normal_maximum

        if normal_max is None:
            normal_max = derive_item_normal_maximum(item)

        ext_scored = "human" if isinstance(item.behavior, ExternalGraded) else None

        outcomes: list[etree._Element] = []
        outcomes.append(
            self._build_outcome_declaration(
                score_id, "float", default_value="0",
                normal_maximum=normal_max,
                external_scored=ext_scored,
            ),
        )
        outcomes.append(
            self._build_outcome_declaration(
                "MAXSCORE", "float",
                default_value=str(normal_max),
            ),
        )

        if item.scoring_dimensions:
            for dim in item.scoring_dimensions:
                dim_ext = "human" if dim.scoring_method == "human" else None
                outcomes.append(
                    self._build_outcome_declaration(
                        dim.name, "float", default_value="0",
                        normal_maximum=dim.max_score,
                        external_scored=dim_ext,
                    ),
                )

        if self._is_adaptive(item.behavior):
            outcomes.append(
                self._build_outcome_declaration(
                    "completionStatus", "identifier", default_value="unknown",
                )
            )

        if isinstance(item.behavior, FeedbackEnabled):
            outcomes.append(
                self._build_outcome_declaration(feedback_id, "identifier"),
            )

        all_fb = self._collect_all_feedback(item)
        fb_types = self._feedback_type_set(all_fb)

        if "hint" in fb_types:
            outcomes.append(
                self._build_outcome_declaration("HINT_FEEDBACK", "identifier"),
            )
        if "solution_steps" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "WORKED_SOLUTION_FEEDBACK", "identifier",
                ),
            )
        if "learning_content" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "LEARNING_CONTENT_FEEDBACK", "identifier",
                ),
            )
        if supports_reveal and "answer_reveal" in fb_types:
            outcomes.append(
                self._build_outcome_declaration(
                    "REVEAL_ANSWER_FEEDBACK", "identifier",
                ),
            )

        item_explanation_fb = [
            fb for fb in item.feedback if fb.type == "explanation"
        ]
        if supports_modal and item_explanation_fb:
            outcomes.append(
                self._build_outcome_declaration("MODAL_FEEDBACK", "identifier"),
            )

        return outcomes

    # --- Stimulus ref ---

    def _stimulus_content_str(self, stimulus: Stimulus) -> str:
        """Return a content string for a single stimulus (for hashing)."""
        if isinstance(stimulus, TextStimulus):
            return self._process_content(stimulus.text)
        if isinstance(stimulus, ImageStimulus):
            return self._build_image_tag(stimulus)
        if isinstance(stimulus, AudioStimulus):
            return f'<audio src="{stimulus.url}" controls="controls"/>'
        if isinstance(stimulus, VideoStimulus):
            return f'<video src="{stimulus.url}" controls="controls"/>'
        return ""

    def _build_stimulus_ref(
        self,
        stimulus: Union[Stimulus, list[Stimulus], None],
        item_id: str,
    ) -> tuple[etree._Element | None, str | None, str | None]:
        """Returns (ref_element, stimulus_content, stimulus_id) or (None, None, None).

        For a list of stimuli the content is concatenated with details/summary
        wrappers when labels are present.
        """
        if stimulus is None:
            return None, None, None

        if isinstance(stimulus, list):
            parts: list[str] = []
            for s in stimulus:
                part = self._stimulus_content_str(s)
                label = getattr(s, "label", None)
                if label:
                    part = f"<details><summary>{label}</summary>{part}</details>"
                parts.append(part)
            content = "\n".join(parts)
        else:
            content = self._stimulus_content_str(stimulus)

        stim_id = f"stim_{self._content_hash(content)[:12]}"
        ref = etree.Element(
            "qti-assessment-stimulus-ref",
            attrib={
                "identifier": stim_id,
                "href": f"stimuli/{stim_id}.xml",
            },
        )
        return ref, content, stim_id

    # --- Companion Materials ---

    def _build_companion_materials(
        self, materials: CompanionMaterials | None
    ) -> etree._Element | None:
        if materials is None:
            return None

        has_any = materials.calculator or materials.ruler or materials.protractor
        if not has_any:
            return None

        el = etree.Element("qti-companion-materials-info")
        if materials.calculator:
            calc = etree.SubElement(el, "qti-calculator")
            calc.set("calculator-type", materials.calculator)
        if materials.ruler:
            etree.SubElement(el, "qti-rule")
        if materials.protractor:
            etree.SubElement(el, "qti-protractor")
        return el

    # --- Accessibility Catalog ---

    def _build_catalog_info(
        self, entries: list[AccessibilityCatalogEntry] | None
    ) -> etree._Element | None:
        if not entries:
            return None

        catalog_info = etree.Element("qti-catalog-info")

        targets: dict[str, list[AccessibilityCatalogEntry]] = {}
        for entry in entries:
            targets.setdefault(entry.target_id, []).append(entry)

        for target_id, target_entries in targets.items():
            catalog = etree.SubElement(catalog_info, "qti-catalog")
            catalog.set("id", f"catalog_{target_id}")

            for entry in target_entries:
                card = etree.SubElement(catalog, "qti-card")
                card.set("support", entry.support.value)
                card.set("{http://www.w3.org/XML/1998/namespace}lang", "en")

                if entry.support in (
                    "sign-language",
                    "braille",
                    "tactile",
                ):
                    file_href = etree.SubElement(card, "qti-file-href")
                    file_href.set("href", entry.content)
                else:
                    html_content = etree.SubElement(card, "qti-html-content")
                    html_content.text = entry.content

        return catalog_info

    # --- Rubric block ---

    def _build_rubric_block(self, grading_rubric: str | None) -> etree._Element | None:
        if not grading_rubric:
            return None
        rubric_html, svgs, img_map = extract_inline_svgs(
            grading_rubric, self._current_item_id,
        )
        self._generated_assets.update(svgs)
        rubric_html = restore_img_placeholders(rubric_html, img_map)
        rb = etree.Element(
            "qti-rubric-block",
            attrib={"use": "scoring", "view": "scorer"},
        )
        div = etree.SubElement(rb, "div")
        self._set_inner_html(div, rubric_html)
        return rb

    # --- Feedback ---

    def _build_feedback_block(
        self,
        identifier: str,
        outcome_identifier: str,
        content_html: str,
        css_class: str = "",
    ) -> etree._Element:
        fb = etree.Element(
            "qti-feedback-block",
            attrib={
                "identifier": identifier,
                "outcome-identifier": outcome_identifier,
                "show-hide": "show",
            },
        )
        content_body = etree.SubElement(fb, "qti-content-body")
        div = etree.SubElement(content_body, "div")
        if css_class:
            div.set("class", css_class)
        self._set_inner_html(div, content_html)
        return fb

    def _build_feedback_inline(
        self,
        identifier: str,
        outcome_identifier: str,
        content_html: str,
    ) -> etree._Element:
        """Build a ``<qti-feedback-inline>`` element for per-option feedback."""
        fi = etree.Element(
            "qti-feedback-inline",
            attrib={
                "identifier": identifier,
                "outcome-identifier": outcome_identifier,
                "show-hide": "show",
            },
        )
        self._set_inner_html(fi, content_html)
        return fi

    _FB_TYPE_TO_OUTCOME: dict[str, str] = {
        "hint": "HINT_FEEDBACK",
        "solution_steps": "WORKED_SOLUTION_FEEDBACK",
        "learning_content": "LEARNING_CONTENT_FEEDBACK",
        "answer_reveal": "REVEAL_ANSWER_FEEDBACK",
    }
    _FB_TYPE_TO_BLOCK_ID: dict[str, str] = {
        "hint": "hint_feedback",
        "solution_steps": "worked_solution_feedback",
        "learning_content": "learning_content_feedback",
        "answer_reveal": "reveal_answer_feedback",
    }
    _FB_TYPE_TO_CSS: dict[str, str] = {
        "hint": "hint",
        "solution_steps": "worked-solution",
        "learning_content": "learning-content",
        "answer_reveal": "reveal-answer",
    }

    def _build_scaffold_feedback(
        self,
        feedback_entries: list[Feedback],
        format_map: dict[str, str] | None = None,
    ) -> list[etree._Element]:
        """Build feedback blocks from ``Feedback`` entries.

        Handles types: hint, solution_steps, learning_content, answer_reveal.
        Skips ``explanation`` (those are per-choice inline elements built
        by individual interaction builders).
        """
        blocks: list[etree._Element] = []

        for fb in feedback_entries:
            if fb.type == "explanation":
                continue
            if fb.type == "answer_reveal" and isinstance(fb.content, str) and not fb.content.strip():
                continue

            outcome_id = self._FB_TYPE_TO_OUTCOME.get(fb.type)
            if outcome_id is None:
                continue

            css = self._FB_TYPE_TO_CSS.get(fb.type, "")
            identifier = self._FB_TYPE_TO_BLOCK_ID.get(fb.type, f"{fb.type}_feedback")
            html = self._render_feedback_content(fb, format_map)

            blocks.append(self._build_feedback_block(
                identifier=identifier,
                outcome_identifier=outcome_id,
                content_html=html,
                css_class=css,
            ))

        return blocks

    def _render_feedback_content(
        self,
        fb: Feedback,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Render a ``Feedback`` entry's content to HTML."""
        content = fb.content
        if isinstance(content, str):
            return self._process_content(content, format_map=format_map)
        if isinstance(content, TextLearningContent):
            return self._process_content(content.text, format_map=format_map)
        if isinstance(content, VideoLearningContent):
            html = f'<video src="{content.url}" controls="controls"/>'
            if content.transcript:
                html += (
                    f'<div class="transcript">'
                    f'{self._process_content(content.transcript, format_map=format_map)}'
                    f'</div>'
                )
            return html
        return ""

    def _build_reveal_answer_block(
        self, config: object,
    ) -> etree._Element:
        """Build a ``<qti-feedback-block>`` that reveals the correct answer.

        Dispatches by interaction config type to produce human-readable text.
        """
        from ..models.interactions import (
            ChoiceConfig,
            MatchConfig,
            OrderConfig,
            TextEntryConfig,
        )

        if isinstance(config, ChoiceConfig):
            correct = [c.content for c in config.choices if c.correct]
            answer = ", ".join(correct)
            html = f"<p><strong>Correct answer:</strong> {answer}</p>"
        elif isinstance(config, TextEntryConfig):
            if isinstance(config.answers, dict):
                parts = [
                    f"{bid}: {', '.join(vals)}"
                    for bid, vals in config.answers.items()
                ]
                answer = "; ".join(parts)
            else:
                answer = ", ".join(config.answers)
            html = f"<p><strong>Correct answer:</strong> {answer}</p>"
        elif isinstance(config, OrderConfig):
            answer = " → ".join(config.correct_order)
            html = f"<p><strong>Correct order:</strong> {answer}</p>"
        elif isinstance(config, MatchConfig):
            pairs = [f"{s} → {t}" for s, t in config.correct_mapping]
            answer = ", ".join(pairs)
            html = f"<p><strong>Correct matching:</strong> {answer}</p>"
        else:
            html = "<p><strong>See the correct answer above.</strong></p>"

        return self._build_feedback_block(
            identifier="reveal_answer_feedback",
            outcome_identifier="REVEAL_ANSWER_FEEDBACK",
            content_html=html,
            css_class="reveal-answer",
        )

    def _build_end_attempt_interaction(self) -> etree._Element:
        """Build ``<qti-end-attempt-interaction>`` for adaptive behaviors."""
        return etree.Element(
            "qti-end-attempt-interaction",
            attrib={
                "response-identifier": "RESPONSE_END_ATTEMPT",
                "title": "Submit Answer",
            },
        )

    # --- Modal feedback ---

    def _build_modal_feedback_elements(
        self,
        feedback_entries: list[Feedback],
        format_map: dict[str, str] | None = None,
    ) -> list[etree._Element]:
        """Build ``<qti-modal-feedback>`` elements from item-level ``Feedback``
        entries of type ``"explanation"``.

        Maps ``show_when.on_correct=True`` → ``modal_feedback_correct``,
        ``show_when.on_correct=False`` → ``modal_feedback_incorrect``.
        Entries without ``on_correct`` get a generic identifier.
        """
        explanations = [fb for fb in feedback_entries if fb.type == "explanation"]
        if not explanations:
            return []

        elements: list[etree._Element] = []
        partial_assigned = False
        for i, fb in enumerate(explanations):
            on_correct = fb.show_when.on_correct if fb.show_when else None
            if on_correct is True:
                identifier = "modal_feedback_correct"
            elif on_correct is False:
                identifier = "modal_feedback_incorrect"
            elif on_correct is None and not partial_assigned:
                identifier = "modal_feedback_partial"
                partial_assigned = True
            else:
                identifier = f"modal_feedback_{i}"

            mf = etree.Element(
                "qti-modal-feedback",
                attrib={
                    "outcome-identifier": "MODAL_FEEDBACK",
                    "identifier": identifier,
                    "show-hide": "show",
                },
            )
            cb = etree.SubElement(mf, "qti-content-body")
            div = etree.SubElement(cb, "div")
            processed = self._render_feedback_content(fb, format_map=format_map)
            self._set_inner_html(div, processed)
            elements.append(mf)
        return elements

    # --- Scoring dimension helpers ---

    @staticmethod
    def _effective_score_id(config: object) -> str:
        """Return the score target: dimension name if targeted, else ``"SCORE"``."""
        td = getattr(config, "target_dimension", None)
        return td if td else "SCORE"

    @staticmethod
    def _append_dimension_to_score(rp: etree._Element, item: QuestionItem) -> None:
        """For single-interaction items with scoring dimensions, set SCORE = sum(dims)."""
        if not item.scoring_dimensions:
            return
        sov = etree.SubElement(
            rp, "qti-set-outcome-value", attrib={"identifier": "SCORE"},
        )
        sum_el = etree.SubElement(sov, "qti-sum")
        for dim in item.scoring_dimensions:
            etree.SubElement(sum_el, "qti-variable", attrib={"identifier": dim.name})

    # --- Template declarations & processing ---

    def _get_format_map(self, item: QuestionItem) -> dict[str, str] | None:
        """Build a variable-name -> format-string map from template config."""
        if not item.template:
            return None
        fmt: dict[str, str] = {}
        for var in item.template.variables:
            if var.display_format:
                fmt[var.name] = var.display_format
        return fmt or None

    def _build_template_elements(
        self, item: QuestionItem, response_id: str = "RESPONSE",
    ) -> tuple[list[etree._Element], etree._Element | None]:
        """Build template declarations and processing for an item.

        Returns ``(declarations, processing_element)`` or ``([], None)``
        when the item has no template.
        """
        if not item.template:
            return [], None

        from ..templates.template_processing import (
            build_template_declarations,
            build_template_processing,
        )

        correct_expr = self._find_correct_expression(item)
        decls = build_template_declarations(
            item.template,
            correct_expression=correct_expr,
            response_id=response_id,
        )
        tp = build_template_processing(
            item.template,
            correct_expression=correct_expr,
            response_id=response_id,
        )
        return decls, tp

    @staticmethod
    def _find_correct_expression(
        item: QuestionItem,
    ) -> str | dict[str, str] | None:
        """Extract ``correct_expression`` from the first TextEntryConfig, if any."""
        from ..models.interactions import TextEntryConfig

        for ix in item.interactions:
            if isinstance(ix, TextEntryConfig) and ix.correct_expression is not None:
                return ix.correct_expression
        return None

    # --- Utilities ---

    def _build_image_tag(self, img: ImageStimulus) -> str:
        alt = img.alt or ""
        return f'<img src="{img.url}" alt="{alt}" style="max-width:680px; max-height:345px;"/>'

    def _set_inner_html(self, parent: etree._Element, html: str) -> None:
        """Parse an HTML fragment and append it as child nodes."""
        try:
            wrapper = f"<wrapper>{html}</wrapper>"
            parsed = etree.fromstring(wrapper.encode())
            if parsed.text:
                if len(parent) == 0:
                    parent.text = (parent.text or "") + parsed.text
                else:
                    last = parent[-1]
                    last.tail = (last.tail or "") + parsed.text
            for child in parsed:
                parent.append(child)
        except etree.XMLSyntaxError:
            parent.text = html

    def serialize(self, element: etree._Element) -> str:
        return etree.tostring(
            element,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8",
        ).decode("utf-8")
