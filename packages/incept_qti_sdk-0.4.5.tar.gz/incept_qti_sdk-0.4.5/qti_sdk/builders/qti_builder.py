"""Unified builder entry point for QuestionItem -> QTI 3.0 XML."""

from __future__ import annotations

from ..content.svg_extractor import has_inline_svg
from ..exceptions import BuildError
from ..models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)
from ..models.question_item import QuestionItem
from .base_builder import BuildResult
from .choice_builder import ChoiceBuilder
from .composite_builder import CompositeBuilder
from .extended_text_builder import ExtendedTextBuilder
from .match_builder import MatchBuilder
from .order_builder import OrderBuilder
from .pci_builder import PCIBuilder
from .text_entry_builder import TextEntryBuilder
from .transforms import inline_stimulus


class QtiBuilder:
    """Unified entry point: ``QuestionItem`` -> ``BuildResult``.

    Dispatches to the appropriate per-interaction builder for single-
    interaction items, or to ``CompositeBuilder`` when the item has
    multiple interactions.
    """

    def __init__(self) -> None:
        self._choice = ChoiceBuilder()
        self._text_entry = TextEntryBuilder()
        self._extended_text = ExtendedTextBuilder()
        self._match = MatchBuilder()
        self._order = OrderBuilder()
        self._pci = PCIBuilder()
        self._composite = CompositeBuilder()

    def build(
        self,
        item: QuestionItem,
        *,
        stimulus_mode: str = "separate",
    ) -> BuildResult:
        """Build a ``QuestionItem`` into QTI 3.0 XML.

        Parameters
        ----------
        item:
            The validated QuestionItem model.
        stimulus_mode:
            ``"separate"`` (default) generates a standalone stimulus XML
            file and a ``<qti-assessment-stimulus-ref>`` in the item.
            ``"inline"`` injects stimulus content directly into the item
            body.
        """
        if stimulus_mode == "inline" and has_inline_svg(item.model_dump_json()):
            raise BuildError(
                "Inline SVG content cannot be used with stimulus_mode='inline'. "
                "Use stimulus_mode='separate' to extract SVG to media files, "
                "or replace inline SVG with <img src='...' /> references."
            )

        if len(item.interactions) > 1:
            result = self._composite.build(item)
        else:
            interaction = item.interactions[0]

            if isinstance(interaction, ChoiceConfig):
                result = self._choice.build(item)
            elif isinstance(interaction, TextEntryConfig):
                result = self._text_entry.build(item)
            elif isinstance(interaction, ExtendedTextConfig):
                result = self._extended_text.build(item)
            elif isinstance(interaction, MatchConfig):
                result = self._match.build(item)
            elif isinstance(interaction, OrderConfig):
                result = self._order.build(item)
            elif isinstance(interaction, PCIConfig):
                result = self._pci.build(item)
            else:
                raise BuildError(f"Unknown interaction type: {interaction.type}")

        if stimulus_mode == "inline":
            result = inline_stimulus(result)

        return result
