"""Single source of truth for SDK version and tool metadata."""

__version__ = "0.4.5"

SDK_TOOL_NAME = "incept-qti-sdk"
SDK_TOOL_VERSION = __version__
