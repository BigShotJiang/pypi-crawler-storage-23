"""Resolve human-readable standard labels to CASE UUIDs via the Curriculum API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import httpx

from ..curriculum.registry import get_course
from ..exceptions import UploadError

if TYPE_CHECKING:
    from ..models.base import StandardAlignment
    from .config import TimeBackConfig

logger = logging.getLogger(__name__)

CURRICULUM_API_PREFIX = "curriculum/1.0"


class CaseResolver:
    """Resolves standard labels to CASE item UUIDs.

    Uses the TimeBack Curriculum API to fetch the full course tree for a
    pre-registered curriculum course, then matches ``StandardAlignment.label``
    values against the ``code`` (``humanCodingScheme``) field of each node.

    Typical usage::

        resolver = CaseResolver(config, token, curriculum_key="COMMON_CORE_STANDARD_MATH_3RD_GRADE")
        warnings = await resolver.resolve(standards_list)
    """

    def __init__(
        self,
        config: TimeBackConfig,
        token: str,
        *,
        curriculum_key: str,
    ) -> None:
        self._base_url = config.base_url.rstrip("/")
        self._token = token
        self._curriculum_key = curriculum_key
        self._code_map: dict[str, str] | None = None

    async def resolve(
        self,
        standards: list[StandardAlignment],
    ) -> list[str]:
        """Resolve unresolved standards in-place. Returns list of warning messages."""
        warnings: list[str] = []
        unresolved = [s for s in standards if s.case_item_uri is None]
        if not unresolved:
            return warnings

        if self._code_map is None:
            self._code_map = await self._fetch_course_tree()

        for standard in unresolved:
            uuid = self._code_map.get(standard.label)
            if uuid:
                standard.case_item_uri = uuid
            else:
                warnings.append(
                    f"Could not resolve standard label to CASE UUID: "
                    f"{standard.label}"
                )

        return warnings

    async def _fetch_course_tree(self) -> dict[str, str]:
        """Fetch the full course tree and build a code -> UUID map."""
        entry = get_course(self._curriculum_key)

        url = (
            f"{self._base_url}/{CURRICULUM_API_PREFIX}"
            f"/documents/{entry.document_id}/courses/{entry.course_id}"
        )
        headers = {"Authorization": f"Bearer {self._token}"}

        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(url, headers=headers, timeout=120.0)
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise UploadError(
                    f"Failed to fetch course tree for '{self._curriculum_key}': {exc}"
                ) from exc
            body = resp.json()

        items = body.get("items", [])
        code_map: dict[str, str] = {}
        self._walk_tree(items, code_map)

        logger.info(
            "Loaded %d code->UUID mappings from course %s (key=%s)",
            len(code_map),
            entry.course_id,
            self._curriculum_key,
        )
        return code_map

    @staticmethod
    def _walk_tree(nodes: list[dict[str, Any]], code_map: dict[str, str]) -> None:
        """Recursively collect code -> id pairs from the course tree."""
        for node in nodes:
            code = node.get("code")
            node_id = node.get("id")
            if code and node_id:
                code_map[code] = node_id
            children = node.get("children", [])
            if children:
                CaseResolver._walk_tree(children, code_map)
