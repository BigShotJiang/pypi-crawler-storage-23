"""Resolve PCI module manifests and download module files for ZIP bundling.

At package time, scans item XMLs for ``data-item-path-uri`` attributes,
fetches the RequireJS ``module_resolution.json`` manifest from each unique
base URL, and downloads all module ``.js`` files listed in ``paths``.

The item XMLs are rewritten so ``data-item-path-uri`` points to a
relative directory inside the ZIP instead of an external URL.  This
freezes the module versions at package time and eliminates runtime
network dependencies.

Works identically for standard registered modules and generator-supplied
custom PCI modules — the only requirement is that the base URL hosts a
valid ``module_resolution.json`` with all dependencies listed in
``paths``.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass, field
from posixpath import dirname as posix_dirname
from urllib.parse import urljoin

import httpx

from ..builders.base_builder import BuildResult

logger = logging.getLogger(__name__)

_DATA_ITEM_PATH_URI_RE = re.compile(
    r'data-item-path-uri\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_PRIMARY_CFG_RE = re.compile(
    r'primary-configuration\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)


@dataclass
class PCIModuleSet:
    """All module files for a single PCI base URL."""

    base_url: str
    primary_configuration: str
    uri_prefix: str
    zip_dir: str


@dataclass
class PCIManifest:
    """Result of scanning item XMLs for PCI module references."""

    module_sets: dict[str, PCIModuleSet] = field(default_factory=dict)
    rewritten_xmls: dict[str, str] = field(default_factory=dict)

    @property
    def has_modules(self) -> bool:
        return bool(self.module_sets)


def _hash_url(url: str) -> str:
    return hashlib.sha256(url.encode()).hexdigest()[:8]


def resolve_pci_modules(
    results: list,
    prior_rewrites: dict[str, str] | None = None,
) -> PCIManifest:
    """Scan BuildResult XMLs for PCI module references.

    Extracts unique ``(data-item-path-uri, primary-configuration)``
    pairs and prepares rewritten XMLs with relative paths.

    Parameters
    ----------
    results:
        List of BuildResult objects.
    prior_rewrites:
        Previously rewritten XMLs (e.g. from ``resolve_assets``).
        When provided, PCI rewriting is applied on top of these
        to preserve prior modifications.

    This is synchronous — it only parses XML strings.  Call
    :func:`fetch_pci_modules` afterward to download the actual files.
    """
    manifest = PCIManifest()
    seen_base_urls: dict[str, str] = {}
    prior = prior_rewrites or {}

    for r in results:
        xml = prior.get(r.item_id, r.item_xml)
        _scan_item_xml(xml, r.item_id, manifest, seen_base_urls)

    return manifest


def _scan_item_xml(
    xml_str: str,
    item_id: str,
    manifest: PCIManifest,
    seen_base_urls: dict[str, str],
) -> None:
    uri_matches = _DATA_ITEM_PATH_URI_RE.findall(xml_str)
    if not uri_matches:
        return

    cfg_matches = _PRIMARY_CFG_RE.findall(xml_str)
    primary_cfg = cfg_matches[0] if cfg_matches else "modules/module_resolution.json"

    for base_url in uri_matches:
        if not base_url.startswith(("http://", "https://")):
            continue

        normalized = base_url.rstrip("/") + "/"

        if normalized not in seen_base_urls:
            dir_hash = _hash_url(normalized)
            uri_prefix = f"pci-modules/{dir_hash}"
            seen_base_urls[normalized] = uri_prefix
            manifest.module_sets[normalized] = PCIModuleSet(
                base_url=normalized,
                primary_configuration=primary_cfg,
                uri_prefix=uri_prefix,
                zip_dir=f"items/{uri_prefix}",
            )

        uri_prefix = seen_base_urls[normalized]

        rewritten = xml_str.replace(
            f'"{base_url}"', f'"{uri_prefix}/"',
        ).replace(
            f"'{base_url}'", f"'{uri_prefix}/'",
        )
        if rewritten != xml_str:
            manifest.rewritten_xmls[item_id] = rewritten


async def fetch_pci_modules(
    manifest: PCIManifest,
) -> dict[str, bytes]:
    """Download PCI module files for all module sets in the manifest.

    For each unique base URL:

    1. Fetch ``module_resolution.json`` from
       ``<base_url>/<primary_configuration>``.
    2. Parse the ``paths`` object to discover module names.
    3. Download ``<module_name>.js`` for each entry.

    Returns a dict mapping ZIP paths to file bytes.
    """
    result: dict[str, bytes] = {}

    async with httpx.AsyncClient() as client:
        for ms in manifest.module_sets.values():
            manifest_url = urljoin(ms.base_url, ms.primary_configuration)
            modules_base = urljoin(ms.base_url, posix_dirname(ms.primary_configuration) + "/")
            cfg_zip_path = f"{ms.zip_dir}/{ms.primary_configuration}"

            try:
                resp = await client.get(manifest_url, timeout=30.0, follow_redirects=True)
                resp.raise_for_status()
            except httpx.HTTPError:
                logger.error("Failed to fetch PCI manifest: %s", manifest_url)
                continue

            result[cfg_zip_path] = resp.content

            try:
                manifest_data = json.loads(resp.content)
            except (json.JSONDecodeError, ValueError):
                logger.error("Invalid JSON in PCI manifest: %s", manifest_url)
                continue

            paths = manifest_data.get("paths", {})
            if not isinstance(paths, dict):
                logger.error("PCI manifest 'paths' is not an object: %s", manifest_url)
                continue

            for module_name, module_path in paths.items():
                js_filename = f"{module_path}.js"
                js_url = urljoin(modules_base, js_filename)
                js_zip_path = f"{ms.zip_dir}/{posix_dirname(ms.primary_configuration)}/{js_filename}"

                try:
                    js_resp = await client.get(js_url, timeout=60.0, follow_redirects=True)
                    js_resp.raise_for_status()
                    result[js_zip_path] = js_resp.content
                    logger.debug("Downloaded PCI module: %s (%d bytes)", module_name, len(js_resp.content))
                except httpx.HTTPError:
                    logger.warning("Failed to download PCI module: %s from %s", module_name, js_url)

    return result
