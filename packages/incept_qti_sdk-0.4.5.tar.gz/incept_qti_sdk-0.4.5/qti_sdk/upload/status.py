"""Job status polling for TimeBack ingest jobs."""

from __future__ import annotations

import asyncio
from typing import Any

import httpx
from pydantic import BaseModel, Field

from ..exceptions import UploadError
from .auth import get_token
from .config import TimeBackConfig

TERMINAL_STATUSES = frozenset({"COMPLETED", "COMPLETED_WITH_ERRORS", "FAILED"})


class ItemStatus(BaseModel):
    """Status of a single item within an ingest job."""

    item_id: str = Field(description="TimeBack content item UUID.")
    status: str = Field(description="COMPLETED or FAILED.")
    last_updated: str = Field(description="ISO 8601 timestamp.")
    message: str | None = Field(
        default=None, description="Error message when FAILED.",
    )


class JobStatus(BaseModel):
    """Status of a TimeBack ingest job."""

    job_id: str
    status: str = Field(
        description="AWAITING_UPLOAD, PROCESSING, COMPLETED, COMPLETED_WITH_ERRORS, or FAILED.",
    )
    last_updated: str = Field(description="ISO 8601 timestamp.")
    item_statuses: list[ItemStatus] = Field(default_factory=list)


async def get_job_status(
    job_id: str,
    config: TimeBackConfig,
    *,
    poll: bool = False,
    poll_interval: float = 2.0,
    poll_timeout: float = 300.0,
) -> JobStatus:
    """Check the status of an ingest job.

    Parameters
    ----------
    job_id:
        The ingest job ID returned by ``upload_qti_package``.
    config:
        TimeBack platform credentials.
    poll:
        If False, returns immediately with current status.
        If True, polls until a terminal state or timeout.
    poll_interval:
        Seconds between polls (only when ``poll=True``).
    poll_timeout:
        Maximum seconds to wait (only when ``poll=True``).
    """
    token = await get_token(config)
    base_url = config.base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {token}"}

    elapsed = 0.0

    async with httpx.AsyncClient() as client:
        while True:
            try:
                resp = await client.get(
                    f"{base_url}/content/1.0/ingest/jobs/{job_id}",
                    headers=headers,
                    timeout=30.0,
                )
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise UploadError(
                    f"Failed to fetch job status for '{job_id}': {exc}"
                ) from exc
            data = resp.json()

            status = _parse_job_status(job_id, data)

            if not poll or status.status in TERMINAL_STATUSES:
                return status

            if elapsed >= poll_timeout:
                return status

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval


def _parse_job_status(job_id: str, data: dict[str, Any]) -> JobStatus:
    items = [
        ItemStatus(
            item_id=item.get("itemId", ""),
            status=item.get("status", ""),
            last_updated=item.get("lastUpdated", ""),
            message=item.get("message"),
        )
        for item in data.get("itemStatuses", [])
    ]

    return JobStatus(
        job_id=job_id,
        status=data.get("status", "UNKNOWN"),
        last_updated=data.get("lastUpdated", ""),
        item_statuses=items,
    )
