"""Response processing templates for ChoiceConfig interactions."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import ExternalGraded, FeedbackEnabled, SummativeBehavior
from ..models.interactions import ChoiceConfig
from ..models.question_item import QuestionItem
from ._helpers import append_gte_attempts, set_outcome
from ._scoring import build_score_rule

_SCAFFOLD_OUTCOME_MAP: dict[str, tuple[str, str]] = {
    "hint": ("HINT_FEEDBACK", "hint_feedback"),
    "solution_steps": ("WORKED_SOLUTION_FEEDBACK", "worked_solution_feedback"),
    "learning_content": ("LEARNING_CONTENT_FEEDBACK", "learning_content_feedback"),
    "answer_reveal": ("REVEAL_ANSWER_FEEDBACK", "reveal_answer_feedback"),
}


class ChoiceTemplates:
    """Generates ``<qti-response-processing>`` for choice interactions."""

    @staticmethod
    def get(
        item: QuestionItem,
        config: ChoiceConfig,
        *,
        response_id: str = "RESPONSE",
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element | None:
        if isinstance(item.behavior, ExternalGraded):
            return None

        rp = etree.Element("qti-response-processing")
        is_adaptive = (
            isinstance(item.behavior, FeedbackEnabled)
            and item.behavior.max_attempts > 1
        )
        has_feedback = isinstance(item.behavior, FeedbackEnabled)
        fb_id = feedback_id if has_feedback else None

        for el in ChoiceTemplates.get_interaction_rp(
            item, config, response_id, score_id, fb_id,
            include_completion=is_adaptive,
        ):
            rp.append(el)

        if is_adaptive:
            _append_scaffold_triggers(rp, item, config)
        elif has_feedback:
            _append_non_adaptive_reveal(rp, item, config)

        return rp

    @staticmethod
    def get_interaction_rp(
        item: QuestionItem,
        config: ChoiceConfig,
        response_id: str,
        score_id: str,
        feedback_id: str | None,
        *,
        include_completion: bool = False,
    ) -> list[etree._Element]:
        """Return per-interaction RP fragments (no wrapper, no scaffolding).

        When choices carry feedback entries and the interaction is single-select,
        generates per-choice conditions that set ``FEEDBACK`` to ``feedback_{id}``
        so inline feedback elements actually display.
        """
        if isinstance(item.behavior, ExternalGraded):
            return []

        container = etree.Element("_container")
        non_binary = build_score_rule(container, config, response_id, score_id)

        has_choice_fb = any(c.feedback for c in config.choices)
        has_feedback = feedback_id is not None

        if has_choice_fb and has_feedback and config.max_selections == 1:
            _per_choice_rules(
                container, config, response_id, score_id,
                feedback_id, non_binary, include_completion,
            )
        else:
            needs_condition = has_feedback or not non_binary or include_completion
            if needs_condition:
                correct_ids = [c.id for c in config.choices if c.correct]
                cond = etree.SubElement(container, "qti-response-condition")
                if_el = etree.SubElement(cond, "qti-response-if")
                if_el.append(_build_correct_match(correct_ids, config, response_id))
                if not non_binary:
                    set_outcome(if_el, score_id, "float", "1")
                if include_completion:
                    set_outcome(if_el, "completionStatus", "identifier", "completed")
                if has_feedback:
                    set_outcome(if_el, feedback_id, "identifier", "correct")

                else_el = etree.SubElement(cond, "qti-response-else")
                if not non_binary:
                    set_outcome(else_el, score_id, "float", "0")
                if include_completion:
                    set_outcome(else_el, "completionStatus", "identifier", "incomplete")
                if has_feedback:
                    set_outcome(else_el, feedback_id, "identifier", "incorrect")

        return list(container)


# --- Private helpers ---


def _build_correct_match(
    correct_ids: list[str],
    config: ChoiceConfig,
    response_id: str = "RESPONSE",
) -> etree._Element:
    """Build the match expression for single-select or multi-select."""
    if config.max_selections == 1:
        match = etree.Element("qti-match")
        etree.SubElement(match, "qti-variable", attrib={"identifier": response_id})
        bv = etree.SubElement(match, "qti-base-value", attrib={"base-type": "identifier"})
        bv.text = correct_ids[0]
        return match

    match = etree.Element("qti-match")
    etree.SubElement(match, "qti-variable", attrib={"identifier": response_id})
    etree.SubElement(match, "qti-correct", attrib={"identifier": response_id})
    return match


def _per_choice_rules(
    container: etree._Element,
    config: ChoiceConfig,
    response_id: str,
    score_id: str,
    feedback_id: str,
    non_binary: bool,
    include_completion: bool,
) -> None:
    """Build per-choice RP conditions that set FEEDBACK to ``feedback_{id}``.

    This ensures each inline feedback element's identifier is actually
    matched by the response processing.
    """
    for choice in config.choices:
        cond = etree.SubElement(container, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")

        match = etree.SubElement(if_el, "qti-match")
        etree.SubElement(match, "qti-variable", attrib={"identifier": response_id})
        bv = etree.SubElement(match, "qti-base-value", attrib={"base-type": "identifier"})
        bv.text = choice.id

        if not non_binary:
            score = "1" if choice.correct else "0"
            set_outcome(if_el, score_id, "float", score)

        set_outcome(if_el, feedback_id, "identifier", f"feedback_{choice.id}")

        if include_completion:
            status = "completed" if choice.correct else "incomplete"
            set_outcome(if_el, "completionStatus", "identifier", status)


def _append_scaffold_triggers(
    rp: etree._Element,
    item: QuestionItem,
    config: ChoiceConfig,
) -> None:
    """Append scaffold RP conditions (hint, solution_steps, etc.) derived
    from ``Feedback`` entries and ``FeedbackPolicy`` defaults."""
    behavior: FeedbackEnabled = item.behavior  # type: ignore[assignment]
    all_fb = list(config.feedback) + list(item.feedback)

    seen: set[str] = set()
    for fb in all_fb:
        entry = _SCAFFOLD_OUTCOME_MAP.get(fb.type)
        if entry is None or fb.type in seen:
            continue
        seen.add(fb.type)
        outcome_id, element_id = entry

        show = fb.show_when
        if show is None:
            show = getattr(behavior.policy, fb.type, None)
        if show is None:
            continue

        cond = etree.SubElement(rp, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")
        _build_show_condition(if_el, show)
        set_outcome(if_el, outcome_id, "identifier", element_id)


def _append_non_adaptive_reveal(
    rp: etree._Element,
    item: QuestionItem,
    config: ChoiceConfig,
) -> None:
    """For non-adaptive FeedbackEnabled items, unconditionally set
    REVEAL_ANSWER_FEEDBACK so the answer block displays after the
    single submission."""
    all_fb = list(config.feedback) + list(item.feedback)
    if not any(fb.type == "answer_reveal" for fb in all_fb):
        return
    set_outcome(rp, "REVEAL_ANSWER_FEEDBACK", "identifier", "reveal_answer_feedback")


def _build_show_condition(parent: etree._Element, show) -> None:
    """Translate a ``ShowCondition`` into QTI RP condition elements."""
    parts: list[etree._Element] = []

    if show.after_attempt is not None:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
        bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
        bv.text = str(show.after_attempt)
        parts.append(gte)

    if show.on_correct is False:
        lt = etree.Element("qti-lt")
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(lt)
    elif show.on_correct is True:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(gte)

    if len(parts) > 1:
        and_el = etree.SubElement(parent, "qti-and")
        for p in parts:
            and_el.append(p)
    elif parts:
        parent.append(parts[0])
