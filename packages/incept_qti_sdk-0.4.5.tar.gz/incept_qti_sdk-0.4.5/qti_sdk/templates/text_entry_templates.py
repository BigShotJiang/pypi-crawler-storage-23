"""Response processing templates for TextEntryConfig behaviors."""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import ExternalGraded, FeedbackEnabled
from ..models.interactions import TextEntryConfig
from ..models.question_item import QuestionItem
from ._helpers import set_outcome
from ._scoring import build_score_rule

_SCAFFOLD_OUTCOME_MAP: dict[str, tuple[str, str]] = {
    "hint": ("HINT_FEEDBACK", "hint_feedback"),
    "solution_steps": ("WORKED_SOLUTION_FEEDBACK", "worked_solution_feedback"),
    "learning_content": ("LEARNING_CONTENT_FEEDBACK", "learning_content_feedback"),
    "answer_reveal": ("REVEAL_ANSWER_FEEDBACK", "reveal_answer_feedback"),
}


def _response_id_for_blank(blank_id: str, prefix: str = "RESPONSE") -> str:
    """Convert ``blank-1`` -> ``RESPONSE_BLANK_1`` (or ``RESPONSE_2_BLANK_1`` etc.)."""
    return f"{prefix}_{blank_id.upper().replace('-', '_')}"


class TextEntryTemplates:
    """Generates ``<qti-response-processing>`` for text entry behaviors."""

    @staticmethod
    def get(
        item: QuestionItem,
        config: TextEntryConfig,
        *,
        response_id: str = "RESPONSE",
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element | None:
        if isinstance(item.behavior, ExternalGraded):
            return None

        rp = etree.Element("qti-response-processing")
        is_adaptive = (
            isinstance(item.behavior, FeedbackEnabled)
            and item.behavior.max_attempts > 1
        )
        has_feedback = isinstance(item.behavior, FeedbackEnabled)
        fb_id = feedback_id if has_feedback else None

        for el in TextEntryTemplates.get_interaction_rp(
            item, config, response_id, score_id, fb_id,
            include_completion=is_adaptive,
        ):
            rp.append(el)

        if is_adaptive:
            _append_scaffold_triggers(rp, item, config)

        return rp

    @staticmethod
    def get_interaction_rp(
        item: QuestionItem,
        config: TextEntryConfig,
        response_id: str,
        score_id: str,
        feedback_id: str | None,
        *,
        include_completion: bool = False,
    ) -> list[etree._Element]:
        """Return per-interaction RP fragments (no wrapper, no scaffolding)."""
        if isinstance(item.behavior, ExternalGraded):
            return []

        container = etree.Element("_container")
        non_binary = build_score_rule(container, config, response_id, score_id)

        tolerance = getattr(item.template, "tolerance", None) if item.template else None

        has_feedback = feedback_id is not None
        needs_condition = has_feedback or not non_binary or include_completion
        if needs_condition:
            cond = etree.SubElement(container, "qti-response-condition")
            if_el = etree.SubElement(cond, "qti-response-if")
            if_el.append(
                _build_match_expression(config, response_id, item.question, tolerance=tolerance),
            )
            if not non_binary:
                set_outcome(if_el, score_id, "float", "1")
            if include_completion:
                set_outcome(if_el, "completionStatus", "identifier", "completed")
            if has_feedback:
                set_outcome(if_el, feedback_id, "identifier", "correct")

            else_el = etree.SubElement(cond, "qti-response-else")
            if not non_binary:
                set_outcome(else_el, score_id, "float", "0")
            if include_completion:
                set_outcome(else_el, "completionStatus", "identifier", "incomplete")
            if has_feedback:
                set_outcome(else_el, feedback_id, "identifier", "incorrect")

        return list(container)


# --- Private helpers ---


def _append_scaffold_triggers(
    rp: etree._Element,
    item: QuestionItem,
    config: TextEntryConfig,
) -> None:
    """Append scaffold RP conditions (hint, solution_steps, etc.) derived
    from ``Feedback`` entries and ``FeedbackPolicy`` defaults."""
    behavior: FeedbackEnabled = item.behavior  # type: ignore[assignment]
    all_fb = list(config.feedback) + list(item.feedback)

    seen: set[str] = set()
    for fb in all_fb:
        entry = _SCAFFOLD_OUTCOME_MAP.get(fb.type)
        if entry is None or fb.type in seen:
            continue
        seen.add(fb.type)
        outcome_id, element_id = entry

        show = fb.show_when
        if show is None:
            show = getattr(behavior.policy, fb.type, None)
        if show is None:
            continue

        cond = etree.SubElement(rp, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")
        _build_show_condition(if_el, show)
        set_outcome(if_el, outcome_id, "identifier", element_id)


def _build_show_condition(parent: etree._Element, show) -> None:
    """Translate a ``ShowCondition`` into QTI RP condition elements."""
    parts: list[etree._Element] = []

    if show.after_attempt is not None:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
        bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
        bv.text = str(show.after_attempt)
        parts.append(gte)

    if show.on_correct is False:
        lt = etree.Element("qti-lt")
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(lt)
    elif show.on_correct is True:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(gte)

    if len(parts) > 1:
        and_el = etree.SubElement(parent, "qti-and")
        for p in parts:
            and_el.append(p)
    elif parts:
        parent.append(parts[0])


def _build_string_match(
    resp_id: str, value: str, case_sensitive: bool,
) -> etree._Element:
    sm = etree.Element(
        "qti-string-match",
        attrib={"case-sensitive": str(case_sensitive).lower()},
    )
    etree.SubElement(sm, "qti-variable", attrib={"identifier": resp_id})
    bv = etree.SubElement(sm, "qti-base-value", attrib={"base-type": "string"})
    bv.text = value
    return sm


def _build_correct_match(
    response_id: str,
    tolerance: float | None = None,
) -> etree._Element:
    """Match against the dynamically-set ``<qti-correct>`` value.

    Used when ``correct_expression`` is present (template items).
    When *tolerance* is set, uses ``<qti-equal tolerance-mode="absolute">``
    instead of ``<qti-match>``.
    """
    if tolerance is not None:
        eq = etree.Element(
            "qti-equal",
            attrib={
                "tolerance-mode": "absolute",
                "tolerance": f"{tolerance} {tolerance}",
            },
        )
        etree.SubElement(eq, "qti-variable", attrib={"identifier": response_id})
        etree.SubElement(eq, "qti-correct", attrib={"identifier": response_id})
        return eq

    match = etree.Element("qti-match")
    etree.SubElement(match, "qti-variable", attrib={"identifier": response_id})
    etree.SubElement(match, "qti-correct", attrib={"identifier": response_id})
    return match


def _build_match_expression(
    config: TextEntryConfig,
    response_id: str = "RESPONSE",
    question: str = "",
    tolerance: float | None = None,
) -> etree._Element:
    """Build the matching expression for correct answer checking.

    When ``correct_expression`` is present, matches against the
    dynamically-set correct value via ``<qti-correct>``.
    """
    if config.correct_expression is not None:
        if not config.is_multi_blank:
            return _build_correct_match(response_id, tolerance)
        and_el = etree.Element("qti-and")
        for bid in config.resolve_blank_ids(question):
            rid = _response_id_for_blank(bid, response_id)
            and_el.append(_build_correct_match(rid, tolerance))
        return and_el

    case_sensitive = config.case_sensitive

    if not config.is_multi_blank:
        assert isinstance(config.answers, list)
        if len(config.answers) == 1:
            return _build_string_match(response_id, config.answers[0], case_sensitive)
        or_el = etree.Element("qti-or")
        for ans in config.answers:
            or_el.append(_build_string_match(response_id, ans, case_sensitive))
        return or_el

    assert isinstance(config.answers, dict)
    blank_ids = config.resolve_blank_ids(question)

    max_answers = max(len(v) for v in config.answers.values())

    if max_answers == 1:
        and_el = etree.Element("qti-and")
        for bid in blank_ids:
            rid = _response_id_for_blank(bid, response_id)
            and_el.append(
                _build_string_match(rid, config.answers[bid][0], case_sensitive)
            )
        return and_el

    or_el = etree.Element("qti-or")
    for i in range(max_answers):
        and_el = etree.SubElement(or_el, "qti-and")
        for bid in blank_ids:
            rid = _response_id_for_blank(bid, response_id)
            answers_for_blank = config.answers[bid]
            ans = answers_for_blank[i] if i < len(answers_for_blank) else answers_for_blank[0]
            and_el.append(_build_string_match(rid, ans, case_sensitive))
    return or_el
