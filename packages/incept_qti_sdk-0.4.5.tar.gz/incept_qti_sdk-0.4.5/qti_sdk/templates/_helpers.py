"""Shared helpers for response processing template generation."""

from __future__ import annotations

from lxml import etree


def set_outcome(
    parent: etree._Element,
    identifier: str,
    base_type: str,
    value: str,
) -> None:
    """Append a ``<qti-set-outcome-value>`` with a base-value child."""
    sov = etree.SubElement(
        parent, "qti-set-outcome-value", attrib={"identifier": identifier}
    )
    bv = etree.SubElement(sov, "qti-base-value", attrib={"base-type": base_type})
    bv.text = value


def append_gte_attempts(parent: etree._Element, threshold: int) -> None:
    """Append a ``<qti-gte>`` comparing ``numAttempts`` to *threshold*."""
    gte = etree.SubElement(parent, "qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
    bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
    bv.text = str(threshold)


def build_modal_feedback_rp(rp: etree._Element) -> None:
    """Append MODAL_FEEDBACK level comparison to response processing.

    Sets MODAL_FEEDBACK to ``"modal_feedback_correct"`` when SCORE >= MAXSCORE,
    ``"modal_feedback_partial"`` when SCORE > 0, ``"modal_feedback_incorrect"``
    otherwise.
    """
    cond = etree.SubElement(rp, "qti-response-condition")

    # correct: SCORE >= MAXSCORE
    if_el = etree.SubElement(cond, "qti-response-if")
    gte = etree.SubElement(if_el, "qti-gte")
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
    etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
    set_outcome(if_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_correct")

    # partial: SCORE > 0
    elif_el = etree.SubElement(cond, "qti-response-else-if")
    gt = etree.SubElement(elif_el, "qti-gt")
    etree.SubElement(gt, "qti-variable", attrib={"identifier": "SCORE"})
    bv_zero = etree.SubElement(gt, "qti-base-value", attrib={"base-type": "float"})
    bv_zero.text = "0"
    set_outcome(elif_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_partial")

    # incorrect: else
    else_el = etree.SubElement(cond, "qti-response-else")
    set_outcome(else_el, "MODAL_FEEDBACK", "identifier", "modal_feedback_incorrect")
