"""Response processing templates for ExtendedTextConfig behaviors.

Extended text (essay / free response) cannot be auto-scored, so response
processing only checks whether the candidate submitted a non-empty response.
Actual scoring is deferred to an external scorer.
"""

from __future__ import annotations

from lxml import etree

from ..models.behaviors import ExternalGraded, FeedbackEnabled, SummativeBehavior
from ..models.interactions import ExtendedTextConfig
from ..models.question_item import QuestionItem
from ._helpers import set_outcome

_SCAFFOLD_OUTCOME_MAP: dict[str, tuple[str, str]] = {
    "hint": ("HINT_FEEDBACK", "hint_feedback"),
    "solution_steps": ("WORKED_SOLUTION_FEEDBACK", "worked_solution_feedback"),
    "learning_content": ("LEARNING_CONTENT_FEEDBACK", "learning_content_feedback"),
    "answer_reveal": ("REVEAL_ANSWER_FEEDBACK", "reveal_answer_feedback"),
}


def _build_submitted_check(response_id: str = "RESPONSE") -> etree._Element:
    """``<qti-not><qti-is-null><qti-variable identifier="..."/></qti-is-null></qti-not>``"""
    not_el = etree.Element("qti-not")
    is_null = etree.SubElement(not_el, "qti-is-null")
    etree.SubElement(is_null, "qti-variable", attrib={"identifier": response_id})
    return not_el


class ExtendedTextTemplates:
    """Generates ``<qti-response-processing>`` for extended text behaviors."""

    @staticmethod
    def get(
        item: QuestionItem,
        config: ExtendedTextConfig,
        *,
        response_id: str = "RESPONSE",
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element | None:
        if isinstance(item.behavior, ExternalGraded):
            return None

        rp = etree.Element("qti-response-processing")
        is_adaptive = (
            isinstance(item.behavior, FeedbackEnabled)
            and item.behavior.max_attempts > 1
        )
        has_feedback = isinstance(item.behavior, FeedbackEnabled)
        fb_id = feedback_id if has_feedback else None

        for el in ExtendedTextTemplates.get_interaction_rp(
            item, config, response_id, score_id, fb_id,
            include_completion=is_adaptive,
        ):
            rp.append(el)

        if is_adaptive:
            _append_scaffold_triggers(rp, item, config)

        return rp

    @staticmethod
    def get_interaction_rp(
        item: QuestionItem,
        config: ExtendedTextConfig,
        response_id: str,
        score_id: str,
        feedback_id: str | None,
        *,
        include_completion: bool = False,
    ) -> list[etree._Element]:
        """Return per-interaction RP fragments (no wrapper, no scaffolding).

        Extended text has no correctness check — only a non-null submission
        check.  Score is always externally assigned.
        """
        if isinstance(item.behavior, ExternalGraded):
            return []

        container = etree.Element("_container")
        has_feedback = feedback_id is not None

        needs_condition = has_feedback or include_completion
        if needs_condition:
            cond = etree.SubElement(container, "qti-response-condition")
            if_el = etree.SubElement(cond, "qti-response-if")
            if_el.append(_build_submitted_check(response_id))
            if include_completion:
                set_outcome(if_el, "completionStatus", "identifier", "completed")
            if has_feedback:
                set_outcome(if_el, feedback_id, "identifier", "submitted")
        elif isinstance(item.behavior, SummativeBehavior):
            cond = etree.SubElement(container, "qti-response-condition")
            if_el = etree.SubElement(cond, "qti-response-if")
            if_el.append(_build_submitted_check(response_id))
            set_outcome(if_el, score_id, "float", "0")

        return list(container)


def _append_scaffold_triggers(
    rp: etree._Element,
    item: QuestionItem,
    config: ExtendedTextConfig,
) -> None:
    """Append scaffold RP conditions from Feedback entries and FeedbackPolicy."""
    behavior: FeedbackEnabled = item.behavior  # type: ignore[assignment]
    all_fb = list(getattr(config, "feedback", [])) + list(item.feedback)

    seen: set[str] = set()
    for fb in all_fb:
        entry = _SCAFFOLD_OUTCOME_MAP.get(fb.type)
        if entry is None or fb.type in seen:
            continue
        seen.add(fb.type)
        outcome_id, element_id = entry

        show = fb.show_when
        if show is None:
            show = getattr(behavior.policy, fb.type, None)
        if show is None:
            continue

        cond = etree.SubElement(rp, "qti-response-condition")
        if_el = etree.SubElement(cond, "qti-response-if")
        _build_show_condition(if_el, show)
        set_outcome(if_el, outcome_id, "identifier", element_id)


def _build_show_condition(parent: etree._Element, show) -> None:
    """Translate a ShowCondition into QTI RP condition elements."""
    parts: list[etree._Element] = []

    if show.after_attempt is not None:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "numAttempts"})
        bv = etree.SubElement(gte, "qti-base-value", attrib={"base-type": "integer"})
        bv.text = str(show.after_attempt)
        parts.append(gte)

    if show.on_correct is False:
        lt = etree.Element("qti-lt")
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(lt, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(lt)
    elif show.on_correct is True:
        gte = etree.Element("qti-gte")
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "SCORE"})
        etree.SubElement(gte, "qti-variable", attrib={"identifier": "MAXSCORE"})
        parts.append(gte)

    if len(parts) > 1:
        and_el = etree.SubElement(parent, "qti-and")
        for p in parts:
            and_el.append(p)
    elif parts:
        parent.append(parts[0])
