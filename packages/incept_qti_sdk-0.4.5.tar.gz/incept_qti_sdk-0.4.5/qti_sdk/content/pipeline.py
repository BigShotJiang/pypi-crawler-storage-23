"""Content processing pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML."""

from __future__ import annotations

import re
import uuid

from .latex_converter import LatexConverter
from .markdown_converter import MarkdownConverter
from .xml_utils import html_to_xml

_MATH_PLACEHOLDER_PREFIX = "MATHML_PIPE_"
_TVAR_PLACEHOLDER_PREFIX = "TVAR_PIPE_"
_TVAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")


class ContentPipeline:
    """Orchestrates the full content processing chain.

    Each step is also available individually for cases where only
    partial processing is needed.
    """

    def __init__(self) -> None:
        self.latex = LatexConverter()
        self.markdown = MarkdownConverter()

    def process(
        self,
        text: str,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Run the full pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML.

        MathML produced by the LaTeX step is shielded from the markdown
        parser via placeholders so that mistune cannot escape the tags.

        ``{{var}}`` tokens are likewise shielded and restored as
        ``<qti-printed-variable identifier="var"/>`` elements after
        XML normalisation.  *format_map* maps variable names to C-style
        format strings (e.g. ``{"%0.2f"}``) which become ``format``
        attributes on the emitted elements.
        """
        if not text:
            return text
        result, tvar_map = _protect_template_vars(text, format_map)
        result = self.latex.convert(result)
        result, math_map = _protect_mathml(result)
        result = self.markdown.convert(result)
        result = _restore_mathml(result, math_map)
        result = html_to_xml(result)
        result = _restore_template_vars(result, tvar_map)
        return result

    def process_plain(self, text: str) -> str:
        """Process without markdown (for content already in HTML)."""
        if not text:
            return text
        result = self.latex.convert(text)
        result = html_to_xml(result)
        return result


def _protect_mathml(text: str) -> tuple[str, dict[str, str]]:
    """Replace <math>...</math> blocks with unique placeholders."""
    mapping: dict[str, str] = {}
    for match in re.finditer(r"<math[\s>].*?</math>", text, re.DOTALL):
        key = f"{_MATH_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        mapping[key] = match.group(0)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_mathml(text: str, mapping: dict[str, str]) -> str:
    """Put the original <math> blocks back in place of their placeholders."""
    for key, original in mapping.items():
        text = text.replace(key, original)
    return text


def _protect_template_vars(
    text: str, format_map: dict[str, str] | None,
) -> tuple[str, dict[str, str]]:
    """Replace ``{{var}}`` tokens with unique placeholders.

    Returns ``(text_with_placeholders, {placeholder: xml_element_string})``.
    """
    mapping: dict[str, str] = {}
    for match in _TVAR_PATTERN.finditer(text):
        var_name = match.group(1)
        key = f"{_TVAR_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        fmt = (format_map or {}).get(var_name)
        fmt_attr = f' format="{fmt}"' if fmt else ""
        xml_str = f'<qti-printed-variable identifier="{var_name}"{fmt_attr}/>'
        mapping[key] = xml_str
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_template_vars(text: str, mapping: dict[str, str]) -> str:
    """Replace template-variable placeholders with ``<qti-printed-variable>`` elements."""
    for key, xml_str in mapping.items():
        text = text.replace(key, xml_str)
    return text
