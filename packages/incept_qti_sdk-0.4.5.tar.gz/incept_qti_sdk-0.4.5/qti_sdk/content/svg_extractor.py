"""Extract inline SVG blocks from content text into standalone .svg files.

Inline ``<svg>...</svg>`` markup is replaced with ``<img>`` references
pointing to generated media files, keeping the QTI XML spec-compliant.

The extraction returns *placeholder tokens* rather than actual ``<img>``
tags so that downstream markdown processing does not mangle them.  Call
:func:`restore_img_placeholders` after markdown conversion to swap
the placeholders for real ``<img>`` elements.
"""

from __future__ import annotations

import hashlib
import re

_SVG_BLOCK_RE = re.compile(r"<svg[\s>].*?</svg>", re.DOTALL | re.IGNORECASE)
_SVG_DETECT_RE = re.compile(r"<svg[\s>]", re.IGNORECASE)

_XMLNS_RE = re.compile(r'\bxmlns\s*=\s*["\']', re.IGNORECASE)
_SVG_OPEN_RE = re.compile(r"<svg\b", re.IGNORECASE)

_WIDTH_RE = re.compile(r'\bwidth\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_HEIGHT_RE = re.compile(r'\bheight\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_VIEWBOX_RE = re.compile(r'\bviewBox\s*=\s*["\']([^"\']+)["\']')

SVG_XMLNS = 'xmlns="http://www.w3.org/2000/svg"'
SVG_XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>\n'

_PLACEHOLDER_PREFIX = "\x00SVG_IMG_"
_PLACEHOLDER_SUFFIX = "\x00"


def has_inline_svg(text: str) -> bool:
    """Fast check for the presence of inline ``<svg>`` tags."""
    return bool(_SVG_DETECT_RE.search(text))


def extract_inline_svgs(
    text: str,
    item_id: str,
) -> tuple[str, dict[str, str], dict[str, str]]:
    """Replace inline ``<svg>`` blocks with placeholder tokens.

    Returns ``(rewritten_text, {zip_path: svg_file_content},
    {placeholder: img_tag})``.
    If no SVG blocks are found the original text and empty dicts are
    returned.
    """
    assets: dict[str, str] = {}
    placeholders: dict[str, str] = {}
    counter = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal counter
        svg_source = match.group(0)
        svg_file = _ensure_xmlns(svg_source)
        svg_file = SVG_XML_DECL + svg_file

        digest = hashlib.sha256(svg_source.encode()).hexdigest()[:12]
        zip_path = f"media/{item_id}/svg_{digest}.svg"

        style = _img_style(svg_source)
        rel_src = f"../{zip_path}"
        img_tag = f'<img src="{rel_src}" alt="embedded SVG graphic" {style}/>'

        placeholder = f"{_PLACEHOLDER_PREFIX}{counter}{_PLACEHOLDER_SUFFIX}"
        counter += 1

        assets[zip_path] = svg_file
        placeholders[placeholder] = img_tag
        return placeholder

    rewritten = _SVG_BLOCK_RE.sub(_replace, text)
    return rewritten, assets, placeholders


def restore_img_placeholders(
    text: str,
    placeholders: dict[str, str],
) -> str:
    """Replace placeholder tokens with actual ``<img>`` tags."""
    for placeholder, img_tag in placeholders.items():
        text = text.replace(placeholder, img_tag)
    return text


def _ensure_xmlns(svg: str) -> str:
    """Add the SVG namespace declaration if missing."""
    if _XMLNS_RE.search(svg):
        return svg
    return _SVG_OPEN_RE.sub(f"<svg {SVG_XMLNS}", svg, count=1)


def _img_style(svg: str) -> str:
    """Build a ``style`` attribute string from SVG dimensions."""
    w_match = _WIDTH_RE.search(svg)
    h_match = _HEIGHT_RE.search(svg)

    if w_match and h_match:
        return f'style="width:{w_match.group(1)}; height:{h_match.group(1)};"'

    vb_match = _VIEWBOX_RE.search(svg)
    if vb_match:
        parts = vb_match.group(1).split()
        if len(parts) == 4:
            vb_w, vb_h = parts[2], parts[3]
            return f'style="max-width:{vb_w}px; max-height:{vb_h}px;"'

    return 'style="max-width:680px; max-height:345px;"'
