"""LaTeX to MathML conversion with annotation preservation for round-tripping."""

from __future__ import annotations

import re
import uuid


_MATHML_PLACEHOLDER_PREFIX = "MATHML_PRESERVE_"
_ESCAPED_DOLLAR_PLACEHOLDER = "ESCAPED_DOLLAR_SIGN_PLACEHOLDER"


class LatexConverter:
    """Converts LaTeX math expressions to MathML.

    Handles $...$ (inline) and $$...$$ (display) delimiters.
    Protects existing MathML and escaped dollar signs.
    Wraps output in <semantics> with <annotation> for round-trip.
    """

    def convert(self, text: str) -> str:
        if not text or "$" not in text:
            return text

        text, mathml_map = self._protect_existing_mathml(text)
        text = text.replace(r"\$", _ESCAPED_DOLLAR_PLACEHOLDER)

        text = self._convert_display_math(text)
        text = self._convert_inline_math(text)

        text = text.replace(_ESCAPED_DOLLAR_PLACEHOLDER, "$")
        text = self._restore_mathml(text, mathml_map)
        return text

    def _protect_existing_mathml(
        self, text: str
    ) -> tuple[str, dict[str, str]]:
        mapping: dict[str, str] = {}
        for match in re.finditer(r"<math[\s>].*?</math>", text, re.DOTALL):
            key = f"{_MATHML_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
            mapping[key] = match.group(0)
            text = text.replace(match.group(0), key, 1)
        return text, mapping

    def _restore_mathml(self, text: str, mapping: dict[str, str]) -> str:
        for key, original in mapping.items():
            text = text.replace(key, original)
        return text

    def _convert_display_math(self, text: str) -> str:
        def _replace(m: re.Match[str]) -> str:
            latex = m.group(1).strip()
            return self._latex_to_mathml(latex, display=True)

        return re.sub(r"\$\$(.+?)\$\$", _replace, text, flags=re.DOTALL)

    def _convert_inline_math(self, text: str) -> str:
        def _replace(m: re.Match[str]) -> str:
            latex = m.group(1).strip()
            if "<" in latex and ">" in latex:
                return m.group(0)
            return self._latex_to_mathml(latex, display=False)

        return re.sub(r"\$(.+?)\$", _replace, text)

    def _latex_to_mathml(self, latex: str, *, display: bool) -> str:
        try:
            from latex2mathml.converter import convert as l2m_convert

            mathml = l2m_convert(latex)
        except Exception:
            return f"${latex}$" if not display else f"$${latex}$$"

        escaped_latex = (
            latex.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )
        annotation = (
            f'<annotation encoding="application/x-tex">'
            f"{escaped_latex}</annotation>"
        )
        mathml = mathml.replace(
            "</math>",
            f"<semantics>{annotation}</semantics></math>",
        )

        if display:
            mathml = mathml.replace("<math>", '<math display="block">', 1)

        return mathml
