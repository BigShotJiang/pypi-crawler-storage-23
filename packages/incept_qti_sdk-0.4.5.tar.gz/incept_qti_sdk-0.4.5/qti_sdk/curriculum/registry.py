"""Load, save, and query the curriculum registry (registry.json)."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, Field

from ..exceptions import CurriculumNotFoundError

_REGISTRY_PATH = Path(__file__).parent / "registry.json"


class CourseEntry(BaseModel):
    """A single curriculum-course entry in the registry."""

    document_id: str = Field(description="CASE CFDocument UUID.")
    course_id: str = Field(description="Curriculum course UUID.")
    document_title: str = Field(
        default="", description="Human-readable document name (informational only).",
    )
    course_title: str = Field(
        default="", description="Human-readable course name (informational only).",
    )


def load_registry(path: Path | None = None) -> dict[str, CourseEntry]:
    """Read the registry JSON file and return validated entries."""
    p = path or _REGISTRY_PATH
    if not p.exists():
        return {}
    raw = json.loads(p.read_text(encoding="utf-8"))
    return {key: CourseEntry.model_validate(val) for key, val in raw.items()}


def save_registry(
    entries: dict[str, CourseEntry],
    path: Path | None = None,
) -> None:
    """Write entries back to the registry JSON file."""
    p = path or _REGISTRY_PATH
    data = {key: entry.model_dump() for key, entry in entries.items()}
    p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def get_course(key: str, *, path: Path | None = None) -> CourseEntry:
    """Look up a course by registry key. Raises ``CurriculumNotFoundError`` if not found."""
    registry = load_registry(path)
    if key not in registry:
        available = ", ".join(sorted(registry.keys())) or "(none)"
        raise CurriculumNotFoundError(
            f"Curriculum key {key!r} not found in registry. "
            f"Available keys: {available}. "
            f"Run 'python -m qti_sdk discover' to register courses."
        )
    return registry[key]
