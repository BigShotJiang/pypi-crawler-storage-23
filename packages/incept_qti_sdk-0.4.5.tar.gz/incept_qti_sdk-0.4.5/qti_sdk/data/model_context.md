# QTI SDK — QuestionItem Model Reference

> This document is designed for LLM consumption. Use it as context when writing
> code that maps your data model to the SDK's `QuestionItem` format.
> Generate it anytime with: `qti-sdk transformer-context`

## 1. What This SDK Does

The QTI SDK converts a JSON representation of assessment items (`QuestionItem`)
into QTI 3.0 XML, packages them into a ZIP, and uploads them to TimeBack.

**Pipeline**: `QuestionItem JSON` → `build` → `QTI 3.0 XML files` → `upload` → `TimeBack`

**CLI quick reference**:
```
qti-sdk build   -i items.json -o output_dir/     # JSON → XML files
qti-sdk upload  -i items.json --poll              # JSON → build → upload → poll
qti-sdk status  JOB_ID --poll                     # check upload job status
qti-sdk schema                                    # dump JSON Schema
```

---

## 2. QuestionItem Structure

A `QuestionItem` is the top-level object. It represents one assessment item.

### Required Fields

| Field | Type | Description |
|---|---|---|
| `question` | `string` | The stem / prompt. Supports Markdown and LaTeX (`$...$` inline, `$$...$$` block). |
| `behavior` | `object` | How the item scores and gives feedback. See Section 4. |
| `interactions` | `array` (min 1) | One or more interaction configs. See Section 3. |
| `packaging` | `object` | Manifest metadata: `difficulty` (required, 0.0–1.0), curriculum standards, freeform metadata. |

### Optional Fields

| Field | Type | Description |
|---|---|---|
| `item_id` | `string` | Custom identifier. Auto-generated from content hash if omitted. |
| `title` | `string` | Human-readable title. |
| `stimulus` | `object` or `array` | Passage, image, audio, or video shown alongside the item. See Section 6. |
| `feedback` | `list[Feedback]` | Item-level feedback entries (explanation, hint, solution_steps, etc.). See Section 4a. |
| `companion_materials` | `object` | Tools available: `calculator` (`"basic"/"standard"/"scientific"`), `ruler`, `protractor`. |
| `scoring_dimensions` | `array` | Named rubric dimensions for multi-dimensional scoring. |
| `max_score` | `number` | Maximum possible score. |
| `grading_rubric` | `string` | HTML shown to human scorers. |
| `lang` | `string` | BCP 47 language tag (e.g. `"en-US"`, `"ar-AE"`). |
| `template` | `object` | Randomized template variables. See Advanced Features. |
| `context_declarations` | `array` | Advanced: custom QTI context variables. |
| `extension_attributes` | `object` | Freeform key-value attributes on the root element. |

---

## 3. Choosing an Interaction Type

Each entry in the `interactions` array is a discriminated union — set the `type` field to select.

### Decision Tree

| Your question format | Use this type | Key |
|---|---|---|
| Multiple choice, pick ONE answer | `choice` | `max_selections: 1` (default) |
| Multiple choice, pick SEVERAL answers | `choice` | `max_selections: <N>` or `0` for unlimited |
| Typed answer, one blank | `text_entry` | `answers: ["accepted", "variations"]` |
| Typed answer, multiple blanks | `text_entry` | `answers: {"blank-1": [...], "blank-2": [...]}` with `<blank-N>` in prompt |
| Free response / essay / open-ended | `extended_text` | `expected_length: "brief" / "paragraph" / "essay"` |
| Matching / drag-and-drop between two sets | `match` | `source_set` + `target_set` + `correct_mapping` |
| Ordering / sequencing items | `order` | `items` + `correct_order` |
| Custom interactive widget (number line, graph) | `pci` | `interaction_type: "number-line-question"` etc. |

### Choice (`type: "choice"`)

```json
{
  "type": "choice",
  "choices": [
    {"id": "A", "content": "Option A", "correct": false},
    {"id": "B", "content": "Option B", "correct": true},
    {"id": "C", "content": "Option C", "correct": false},
    {"id": "D", "content": "Option D", "correct": false}
  ],
  "max_selections": 1,
  "shuffle": false
}
```

- `choices`: min 2 required. Each has `id`, `content` (Markdown), `correct` (bool).
- `max_selections`: `1` = single-select (exactly 1 correct required), `>1` or `0` = multi-select.
- `feedback` on a Choice: `list[Feedback]` — per-option feedback entries (e.g. explanation shown when that option is selected). Used with `feedback_enabled` behavior.
- `fixed` on a Choice: opts that choice out of shuffle.
- `feedback` on ChoiceConfig: `list[Feedback]` — interaction-level feedback entries (hint, solution_steps, etc.).

### Text Entry (`type: "text_entry"`)

**Single blank:**
```json
{
  "type": "text_entry",
  "prompt": "The capital of France is <blank>.",
  "answers": ["Paris"],
  "case_sensitive": false
}
```

**Multiple blanks:**
```json
{
  "type": "text_entry",
  "prompt": "Water is <blank-1> parts hydrogen and <blank-2> part oxygen.",
  "answers": {
    "blank-1": ["2", "two"],
    "blank-2": ["1", "one"]
  }
}
```

- `prompt`: Contains `<blank>` (single) or `<blank-1>`, `<blank-2>`, etc. (multi). If omitted, the main `question` field must contain the blank markers instead.
- `answers`: `list[str]` for single blank, `dict[str, list[str]]` for multi blank. Keys must match blank IDs (`blank-1`, `blank-2`, etc.) in `prompt` or `question`.
- `tolerance`: Absolute numeric tolerance for math answers (e.g. `0.01`).
- `case_sensitive`: Default `false`.
- `feedback`: `list[Feedback]` — interaction-level feedback entries.

### Extended Text (`type: "extended_text"`)

```json
{
  "type": "extended_text",
  "expected_length": "paragraph",
  "scoring_mode": "human"
}
```

- Use for essays, short-answer, free-response questions.
- `expected_length`: `"brief"`, `"paragraph"`, or `"essay"`.
- `scoring_mode`: `"human"` or `"machine"`.
- Pair with `external_graded` behavior (no auto-scoring).

### Match (`type: "match"`)

```json
{
  "type": "match",
  "source_set": [
    {"id": "a1", "content": "H₂O"},
    {"id": "a2", "content": "NaCl"},
    {"id": "a3", "content": "CO₂"}
  ],
  "target_set": [
    {"id": "b1", "content": "Water"},
    {"id": "b2", "content": "Salt"},
    {"id": "b3", "content": "Carbon dioxide"}
  ],
  "correct_mapping": [["a1", "b1"], ["a2", "b2"], ["a3", "b3"]]
}
```

- `source_set` / `target_set`: Lists of `{id, content}` items. Each item also accepts `feedback: list[Feedback]` for per-option feedback.
- `correct_mapping`: Array of `[source_id, target_id]` pairs.
- All IDs referenced in `correct_mapping` must exist in the respective sets.
- `feedback` on MatchConfig: `list[Feedback]` — interaction-level feedback entries.

### Order (`type: "order"`)

```json
{
  "type": "order",
  "items": [
    {"id": "s1", "content": "Mix ingredients"},
    {"id": "s2", "content": "Preheat oven"},
    {"id": "s3", "content": "Bake for 30 minutes"},
    {"id": "s4", "content": "Let cool"}
  ],
  "correct_order": ["s2", "s1", "s3", "s4"],
  "partial_credit": true
}
```

- `correct_order`: List of item IDs in the correct sequence. Must contain every item ID exactly once.
- `partial_credit`: Award points per correctly placed item.
- Each `OrderItem` also accepts `feedback: list[Feedback]` for per-option feedback.
- `feedback` on OrderConfig: `list[Feedback]` — interaction-level feedback entries.

### PCI — Portable Custom Interaction (`type: "pci"`)

```json
{
  "type": "pci",
  "interaction_type": "number-line-question",
  "data_attributes": {
    "data-steps": "0,1,2,3,4,5,6,7,8,9,10",
    "data-labels": "0,2,4,6,8,10"
  }
}
```

- `interaction_type`: A registered module name or custom URN.
- Registered modules: `number-line-question`, `graph-based-question`, `graph-plot-points-question`, `graph-line-inequality-question`. These auto-resolve `module`, `data_item_path_uri`, and `primary_configuration`.
- `data_attributes`: Key-value strings set as data-* attributes. This is the primary config channel for registered modules.
- For custom (non-registered) modules, you must also provide `module` and `data_item_path_uri`.

---

## 4. Choosing a Behavior

The `behavior` field is a discriminated union — set the `type` field to select.

There are exactly **3** behavior types:

| Behavior | `type` value | Purpose |
|---|---|---|
| `SummativeBehavior` | `"summative"` | High-stakes test, score only, no feedback. |
| `FeedbackEnabled` | `"feedback_enabled"` | All feedback scenarios: formative practice, adaptive scaffolding, diagnostics, remediation. |
| `ExternalGraded` | `"external_graded"` | No automated scoring — human or AI grader. |

### Decision Tree

| Scenario | Use this behavior | Notes |
|---|---|---|
| Practice with immediate per-option feedback | `feedback_enabled` | Use `Choice.feedback` for per-option feedback |
| High-stakes test, no feedback shown | `summative` | Cannot have any `feedback` entries |
| Multi-attempt with hints and worked solution | `feedback_enabled` | Set `max_attempts > 1` and add hint/solution_steps Feedback entries |
| Multi-attempt with remediation content | `feedback_enabled` | Set `max_attempts > 1` and add learning_content Feedback entries |
| Human or AI graded, no auto-scoring | `external_graded` | Cannot have any `feedback` entries |
| Misconception identification | `feedback_enabled` | Single-attempt with per-option explanation feedback |

### Inference Guidance

When your source data doesn't explicitly specify a behavior, infer from context:

- **If you have per-option explanations** (e.g. `answer_explanation` in generator output) → use `feedback_enabled`. The explanations become `Choice.feedback` entries with `type: "explanation"`.
- **If the content is for practice / homework / low-stakes** → `feedback_enabled`.
- **If the content is for a test / exam / high-stakes assessment** → `summative`.
- **If questions are open-ended (essay, free-response)** → `external_graded`.
- **If you want to allow retries with progressive help** → `feedback_enabled` with `max_attempts > 1` and hint/solution_steps Feedback entries on the interaction or item.
- **When in doubt**, `feedback_enabled` is the safest default for generated content.

### `FeedbackEnabled` Fields

| Field | Type | Default | Description |
|---|---|---|---|
| `type` | `"feedback_enabled"` | — | Discriminator. |
| `max_attempts` | `int` (≥ 1) | `1` | Maximum submissions allowed. `1` = single-attempt (formative/diagnostic). `> 1` = multi-attempt (adaptive). |
| `policy` | `FeedbackPolicy` | `FeedbackPolicy()` | Default show conditions per feedback type. See Section 4a. |

### Behavior JSON Examples

```json
{"type": "summative"}
```

```json
{"type": "feedback_enabled"}
```

```json
{"type": "feedback_enabled", "max_attempts": 5}
```

```json
{
  "type": "feedback_enabled",
  "max_attempts": 3,
  "policy": {
    "hint": {"after_attempt": 1},
    "solution_steps": {"after_attempt": 2},
    "answer_reveal": {"after_attempt": 3}
  }
}
```

```json
{"type": "external_graded"}
```

---

## 4a. Feedback Model

Feedback is a first-class entity. Instead of separate fields for hints, explanations, and modal feedback, the SDK uses a unified `Feedback` object that can be attached at three levels:

1. **Per-option**: `Choice.feedback`, `MatchItem.feedback`, `OrderItem.feedback` — shown when that specific option is selected.
2. **Per-interaction**: `ChoiceConfig.feedback`, `TextEntryConfig.feedback`, `MatchConfig.feedback`, `OrderConfig.feedback` — scoped to the interaction.
3. **Per-item**: `QuestionItem.feedback` — item-level feedback rendered as modal feedback or feedback blocks.

### Feedback Entity

```json
{
  "type": "explanation",
  "content": "7 × 8 = 56 because multiplication means repeated addition.",
  "show_when": {"on_correct": true}
}
```

| Field | Type | Description |
|---|---|---|
| `type` | one of: `"explanation"`, `"hint"`, `"solution_steps"`, `"learning_content"`, `"answer_reveal"` | Feedback category. Drives default show conditions and QTI presentation. |
| `content` | `string` (Markdown) or `LearningContent` | The feedback body. Plain string for text/markdown. Use `LearningContent` for structured remediation (text or video). |
| `show_when` | `ShowCondition` or `null` | Per-feedback condition override. `null` = use defaults from `FeedbackPolicy`. |

### ShowCondition

Controls when feedback is revealed. All fields within a single `ShowCondition` are AND-ed together.

```json
{"after_attempt": 1, "on_correct": false}
```

| Field | Type | Default | Description |
|---|---|---|---|
| `after_attempt` | `int` or `null` | `null` | Show after N submissions (SDK maps to `numAttempts >= N`). |
| `on_correct` | `bool` or `null` | `null` | `true` = show on correct, `false` = show on incorrect, `null` = show regardless. |
| `match` | `list[ConditionMatch]` | `[]` | Typed matchers AND-ed together. For OR logic, use separate `Feedback` entries. |

`ConditionMatch` is a discriminated union with two variants:

- `MatchResponse`: `{"type": "response", "value": "A"}` — match against the response variable.
- `MatchTemplateVar`: `{"type": "template", "variable": "x", "value": "5"}` — match against a template variable.

### FeedbackPolicy

Attached to `FeedbackEnabled.policy`. Provides default `ShowCondition` per feedback type. Individual `Feedback` entries can override via their own `show_when`.

| Feedback type | Default ShowCondition |
|---|---|
| `explanation` | `ShowCondition()` (always shown) |
| `hint` | `ShowCondition(after_attempt=1)` |
| `solution_steps` | `ShowCondition(after_attempt=3)` |
| `learning_content` | `ShowCondition(on_correct=false)` |
| `answer_reveal` | `ShowCondition(after_attempt=4)` |

### LearningContent

Used as the `content` field in a `Feedback` entry when structured remediation is needed (instead of a plain string).

| Type | Fields | Use for |
|---|---|---|
| `text` | `text` (Markdown) | Inline instructional text |
| `video` | `url`, `speaker` (optional), `transcript` (optional) | Video-based remediation |

Example with `LearningContent`:
```json
{
  "type": "learning_content",
  "content": {
    "type": "video",
    "url": "https://example.com/area-review.mp4",
    "speaker": "Ms. Smith",
    "transcript": "Area equals length times width..."
  },
  "show_when": {"on_correct": false, "after_attempt": 2}
}
```

### Feedback Placement Summary

| Location | Field | Purpose |
|---|---|---|
| `Choice.feedback` | `list[Feedback]` | Per-option feedback shown when that choice is selected |
| `OrderItem.feedback` | `list[Feedback]` | Per-option feedback for ordering items |
| `MatchItem.feedback` | `list[Feedback]` | Per-option feedback for match items |
| `ChoiceConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `TextEntryConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `MatchConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `OrderConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `QuestionItem.feedback` | `list[Feedback]` | Item-level feedback (modal feedback or feedback blocks) |

---

## 5. Generator Output → QuestionItem Mapping

This section shows how to transform common generator output formats into valid `QuestionItem` JSON.

### MCQ → QuestionItem

Generator output:
```json
{
  "question": "What is 7 × 8?",
  "answer": "C",
  "answer_explanation": "7 × 8 = 56",
  "answer_options": [
    {"key": "A", "text": "$48$"},
    {"key": "B", "text": "$54$"},
    {"key": "C", "text": "$56$"},
    {"key": "D", "text": "$64$"}
  ],
  "image_url": [],
  "additional_details": ""
}
```

Mapping:
- `question` → `QuestionItem.question`
- `answer_options` → `interactions[0].choices` — map `key` → `id`, `text` → `content`, set `correct: true` on the choice whose `key` matches `answer`
- `answer_explanation` → `Choice.feedback` on the correct choice: `[{"type": "explanation", "content": "7 × 8 = 56"}]`
- `image_url` → `stimulus` (see Section 6)
- `additional_details` → `packaging.timeback_metadata.additional_details`
- Behavior: `{"type": "feedback_enabled"}` (explanations present)

Result:
```json
{
  "question": "What is 7 × 8?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$48$", "correct": false},
      {"id": "B", "content": "$54$", "correct": false},
      {"id": "C", "content": "$56$", "correct": true, "feedback": [{"type": "explanation", "content": "7 × 8 = 56"}]},
      {"id": "D", "content": "$64$", "correct": false}
    ]
  }],
  "packaging": {"difficulty": 0.5}
}
```

### MSQ (Multi-Select) → QuestionItem

Same as MCQ except:
- `answer` is an array of keys (e.g. `["A", "C"]`) — mark ALL matching choices as `correct: true`
- Set `max_selections` to `len(answer)` (or `0` for unlimited selection)
- Put `answer_explanation` on `QuestionItem.feedback` as an explanation entry (since it applies to the combination, not a single choice): `[{"type": "explanation", "content": "...", "show_when": {"on_correct": true}}]`

### Fill-In → QuestionItem

Generator output:
```json
{
  "question": "The chemical formula for water is ___.",
  "answer": [
    {
      "id": "RESP_1",
      "accepted_answers": ["H2O", "h2o"],
      "answer_explanation": "Water consists of 2 hydrogen atoms and 1 oxygen atom."
    }
  ]
}
```

Mapping:
- Place blank markers in `question` (or `prompt`) using SDK format: single blank → `<blank>`, multiple blanks → `<blank-1>`, `<blank-2>`, etc. When blanks are in `question`, `prompt` can be omitted.
- `answer[].accepted_answers` → `interactions[0].answers`
  - Single blank: `answers: ["H2O", "h2o"]`
  - Multi blank: `answers: {"blank-1": [...], "blank-2": [...]}` — keys must be `blank-1`, `blank-2`, etc. (not `response1`, `RESP_1`, etc.)
- `answer[].id` (e.g. `RESP_1`, `RESP_2`) → rename to `blank-1`, `blank-2` in order
- Per-blank `answer_explanation` → `QuestionItem.feedback` as explanation entries: `[{"type": "explanation", "content": "Water consists of 2 hydrogen atoms and 1 oxygen atom."}]`

Result (single blank):
```json
{
  "question": "The chemical formula for water is ___.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "The chemical formula for water is <blank>.",
    "answers": ["H2O", "h2o"],
    "case_sensitive": false
  }],
  "feedback": [
    {"type": "explanation", "content": "Water consists of 2 hydrogen atoms and 1 oxygen atom."}
  ],
  "packaging": {"difficulty": 0.5}
}
```

### Match → QuestionItem

Generator output:
```json
{
  "question": "Match each compound to its common name.",
  "answer": {"a1": "b2", "a2": "b3", "a3": "b1"},
  "column_a": [
    {"id": "a1", "content": "H₂O"},
    {"id": "a2", "content": "NaCl"},
    {"id": "a3", "content": "CO₂"}
  ],
  "column_b": [
    {"id": "b1", "content": "Carbon dioxide"},
    {"id": "b2", "content": "Water"},
    {"id": "b3", "content": "Salt"}
  ],
  "answer_explanation": "H₂O is water, NaCl is table salt, CO₂ is carbon dioxide."
}
```

Mapping:
- `column_a` → `interactions[0].source_set` as `[{id, content}, ...]`
- `column_b` → `interactions[0].target_set`
- `answer` dict → `interactions[0].correct_mapping` as array of `[key, value]` pairs
- `answer_explanation` → `QuestionItem.feedback` as an explanation entry: `[{"type": "explanation", "content": "..."}]`

Result:
```json
{
  "question": "Match each compound to its common name.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "match",
    "source_set": [
      {"id": "a1", "content": "H₂O"},
      {"id": "a2", "content": "NaCl"},
      {"id": "a3", "content": "CO₂"}
    ],
    "target_set": [
      {"id": "b1", "content": "Carbon dioxide"},
      {"id": "b2", "content": "Water"},
      {"id": "b3", "content": "Salt"}
    ],
    "correct_mapping": [["a1", "b2"], ["a2", "b3"], ["a3", "b1"]]
  }],
  "feedback": [
    {"type": "explanation", "content": "H₂O is water, NaCl is table salt, CO₂ is carbon dioxide."}
  ],
  "packaging": {"difficulty": 0.5}
}
```

### Difficulty Mapping

Generator difficulty strings map to `packaging.difficulty` (0.0–1.0):

| Generator value | SDK value |
|---|---|
| `"easy"` | `0.25` |
| `"medium"` | `0.50` |
| `"hard"` | `0.75` |

### Building `packaging` from Request Metadata

The `packaging` field is required. Build it from the generator's request context:

```json
{
  "packaging": {
    "difficulty": 0.50,
    "curriculum": "COMMON_CORE_STANDARD_MATH_3RD_GRADE",
    "curriculum_standards": [
      {"label": "CCSS.MATH.CONTENT.3.OA.A.1+1"}
    ],
    "timeback_metadata": {
      "subject": "Mathematics",
      "grade": "3",
      "toolName": "my-generator@1.0.0"
    }
  }
}
```

- `difficulty`: Required. Float 0.0–1.0.
- `curriculum`: Required for upload. Identifies which course tree to search when resolving standard labels. Use a `CurriculumKey` enum value for type safety (e.g. `CurriculumKey.COMMON_CORE_STANDARD_MATH_3RD_GRADE`) or pass the key as a plain string. List available keys with `list_curricula()` (Python), `qti-sdk list-curricula` (CLI), or browse `CurriculumKey` members via IDE autocomplete. See the table below for common keys.
- `curriculum_standards`: Required for upload — at least one entry per item. Array of `{"label": "..."}` objects. The `label` is the human-readable standard code (e.g. `CCSS.MATH.CONTENT.3.OA.A.1`, typically from `skills.substandard_id` in your source data). The SDK resolves these to CASE UUIDs automatically.
- `timeback_metadata`: Freeform key-value pairs stored as extended attributes in the manifest.

**Common curriculum keys:**

| Key | Course |
|-----|--------|
| `COMMON_CORE_STANDARD_MATH_3RD_GRADE` | Common Core / 3rd Grade Math |
| `COMMON_CORE_STANDARD_READING_5TH_GRADE` | Common Core / 5th Grade Reading |
| `COMMON_CORE_STANDARD_LANGUAGE_7TH_GRADE` | Common Core / 7th Grade Language |
| `COMMON_CORE_STANDARD_MATH_ALGEBRA_1` | Common Core / Algebra 1 |

**Validation**: Items missing `curriculum_standards` or using an unregistered `curriculum` key are rejected before upload with a per-item error report.

---

## 6. Stimulus (Passages and Media)

The `stimulus` field attaches a passage, image, audio, or video to the item. It can be a single object or an array for multi-passage items.

### Types

| Type | Key fields | Use for |
|---|---|---|
| `text` | `text` (Markdown) | Reading passages, data tables, problem context |
| `image` | `url`, `alt` | Diagrams, charts, photos |
| `audio` | `url` | Listening passages |
| `video` | `url` | Video clips |

### Examples

```json
"stimulus": {
  "type": "image",
  "url": "https://example.com/diagram.png",
  "alt": "A bar chart showing monthly rainfall"
}
```

```json
"stimulus": [
  {"type": "text", "text": "Read the following passage:\n\nThe water cycle..."},
  {"type": "image", "url": "https://example.com/water_cycle.png", "alt": "Water cycle diagram"}
]
```

### Mapping `image_url` from Generator Output

If the generator provides `image_url` as an array of URLs:
- Empty array → omit `stimulus`
- One URL → `"stimulus": {"type": "image", "url": "<url>", "alt": ""}`
- Multiple URLs → `"stimulus": [{"type": "image", "url": "<url1>", "alt": ""}, ...]`

---

## 7. Validation Rules

These constraints are enforced at parse time. Violations produce a `ValidationError`.

1. **`SummativeBehavior` and `ExternalGraded` cannot have `feedback`.** Remove all `feedback` entries (on the item, interactions, and choices) when using these behaviors, or switch to `feedback_enabled`.

2. **Single-select choice (`max_selections: 1`) requires exactly 1 correct choice.** Multi-select requires at least 1 correct.

3. **Choice IDs must be unique** within each interaction.

4. **Blank IDs must match answer keys.** For multi-blank text entry, `<blank-1>` and `<blank-2>` in `prompt` (or `question` when `prompt` is omitted) must exactly correspond to keys `"blank-1"` and `"blank-2"` in the `answers` dict.

5. **Single-blank text must contain `<blank>`.** Either `prompt` or `question` (when `prompt` is omitted) must include the `<blank>` placeholder for single-blank text entry.

6. **`correct_expression` on text entry requires `template` on the parent QuestionItem.** This is for template-computed answers.

7. **`score_expression` requires `max_score` or a matching `scoring_dimension`.** If an interaction has a custom score expression, the SDK needs to know the maximum possible score.

8. **`correct_order` must contain every item ID exactly once** in order interactions.

9. **`correct_mapping` source/target IDs must exist** in their respective `source_set`/`target_set`.

---

## 8. Complete Examples

### 8.1 Single-Select MCQ with Feedback

```json
{
  "question": "There are 5 bags with 3 apples in each bag. Which expression shows the total number of apples?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$5 + 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Addition finds the sum, not the total of equal groups."}]},
      {"id": "B", "content": "$5 \\times 3$", "correct": true, "feedback": [{"type": "explanation", "content": "Correct! 5 groups of 3 = 5 × 3 = 15."}]},
      {"id": "C", "content": "$5 - 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Subtraction finds the difference."}]},
      {"id": "D", "content": "$5 \\div 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Division splits into groups, not combines them."}]}
    ]
  }],
  "packaging": {
    "difficulty": 0.25,
    "curriculum": "COMMON_CORE_STANDARD_MATH_3RD_GRADE",
    "curriculum_standards": [
      {"label": "CCSS.MATH.CONTENT.3.OA.A.1+1"}
    ],
    "timeback_metadata": {"subject": "Mathematics", "grade": "3"}
  }
}
```

### 8.2 Multi-Select Choice

```json
{
  "question": "Which of the following are prime numbers? Select all that apply.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "2", "correct": true},
      {"id": "B", "content": "4", "correct": false},
      {"id": "C", "content": "7", "correct": true},
      {"id": "D", "content": "9", "correct": false},
      {"id": "E", "content": "11", "correct": true}
    ],
    "max_selections": 3
  }],
  "packaging": {"difficulty": 0.5}
}
```

### 8.3 Single-Blank Text Entry

```json
{
  "question": "What is $7 \\times 8$?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "$7 \\times 8 =$ <blank>",
    "answers": ["56"]
  }],
  "packaging": {"difficulty": 0.35}
}
```

### 8.4 Multi-Blank Text Entry

```json
{
  "question": "Fill in the missing values.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "The factors of 12 that are also factors of 8 are <blank-1> and <blank-2>.",
    "answers": {
      "blank-1": ["1", "4"],
      "blank-2": ["4", "1"]
    }
  }],
  "packaging": {"difficulty": 0.6}
}
```

### 8.5 Match Interaction

```json
{
  "question": "Match each fraction with its decimal equivalent.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "match",
    "source_set": [
      {"id": "s1", "content": "$\\frac{1}{2}$"},
      {"id": "s2", "content": "$\\frac{1}{4}$"},
      {"id": "s3", "content": "$\\frac{3}{4}$"}
    ],
    "target_set": [
      {"id": "t1", "content": "0.25"},
      {"id": "t2", "content": "0.5"},
      {"id": "t3", "content": "0.75"}
    ],
    "correct_mapping": [["s1", "t2"], ["s2", "t1"], ["s3", "t3"]]
  }],
  "packaging": {"difficulty": 0.4}
}
```

### 8.6 Order Interaction

```json
{
  "question": "Arrange these fractions from least to greatest.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "order",
    "items": [
      {"id": "f1", "content": "$\\frac{3}{4}$"},
      {"id": "f2", "content": "$\\frac{1}{8}$"},
      {"id": "f3", "content": "$\\frac{1}{2}$"},
      {"id": "f4", "content": "$\\frac{7}{8}$"}
    ],
    "correct_order": ["f2", "f3", "f1", "f4"],
    "partial_credit": true
  }],
  "packaging": {"difficulty": 0.55}
}
```

### 8.7 Item with Image Stimulus

```json
{
  "question": "Look at the picture below. How many circles are there in all?",
  "behavior": {"type": "feedback_enabled"},
  "stimulus": {
    "type": "image",
    "url": "https://example.com/3_groups_of_2.png",
    "alt": "Three groups of 2 circles each"
  },
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$3 + 2 = 5$", "correct": false},
      {"id": "B", "content": "$3 \\times 2 = 6$", "correct": true},
      {"id": "C", "content": "$2 \\times 2 = 4$", "correct": false},
      {"id": "D", "content": "$3 \\times 3 = 9$", "correct": false}
    ]
  }],
  "packaging": {"difficulty": 0.3}
}
```

### 8.8 Extended Text with External Grading

```json
{
  "question": "Explain how the water cycle affects weather patterns. Use evidence from the passage to support your answer.",
  "behavior": {"type": "external_graded"},
  "stimulus": {
    "type": "text",
    "text": "The water cycle is the continuous movement of water on, above, and below the surface of the Earth..."
  },
  "interactions": [{
    "type": "extended_text",
    "expected_length": "paragraph",
    "scoring_mode": "human"
  }],
  "scoring_dimensions": [
    {"name": "Content", "max_score": 3.0, "scoring_method": "human"},
    {"name": "Evidence", "max_score": 2.0, "scoring_method": "human"}
  ],
  "max_score": 5.0,
  "packaging": {"difficulty": 0.7}
}
```

### 8.9 Multi-Attempt Adaptive with Hints and Solution Steps

```json
{
  "question": "What is the area of a rectangle with length 8 cm and width 5 cm?",
  "behavior": {
    "type": "feedback_enabled",
    "max_attempts": 3,
    "policy": {
      "hint": {"after_attempt": 1},
      "solution_steps": {"after_attempt": 2}
    }
  },
  "interactions": [{
    "type": "text_entry",
    "prompt": "Area = <blank> cm²",
    "answers": ["40"],
    "feedback": [
      {"type": "hint", "content": "Think about what operation combines length and width to find area."},
      {"type": "solution_steps", "content": "Area = length × width = 8 × 5 = 40 cm²"}
    ]
  }],
  "packaging": {"difficulty": 0.4}
}
```

---

## 9. Shared Building Blocks (Quick Reference)

| Type | Description |
|---|---|
| `MarkdownStr` | `string` supporting Markdown formatting and LaTeX math (`$...$`, `$$...$$`). |
| `BlankTemplateStr` | `string` with `<blank>` or `<blank-N>` placeholders for text entry interactions. |
| `Stimulus` | Union of `TextStimulus`, `ImageStimulus`, `AudioStimulus`, `VideoStimulus`. |
| `CompanionMaterials` | Calculator, ruler, protractor availability. |
| `Feedback` | Feedback entry: `type` + `content` + optional `show_when`. See Section 4a. |
| `FeedbackPolicy` | Default `ShowCondition` per feedback type, attached to `FeedbackEnabled.policy`. |
| `ShowCondition` | When to reveal feedback: `after_attempt`, `on_correct`, `match`. |
| `LearningContent` | Union of `TextLearningContent` and `VideoLearningContent`. Used as `Feedback.content` for structured remediation. |
| `ScoringDimension` | Named rubric dimension with max score and scoring method. |
| `TemplateConfig` | Randomized template variables, constraints, and computed values. |
| `ContextVariable` | Advanced: custom QTI context declaration. |
| `ItemPackaging` | Manifest metadata: difficulty, curriculum, standards, freeform metadata. |

---

## 10. Advanced Features (Compact Reference)

**Companion Materials**: Attach tools available during the item. `"companion_materials": {"calculator": "scientific", "ruler": true, "protractor": false}`.

**Accessibility Catalog**: Provide alternate representations (glossary, sign language, spoken text, braille, etc.) for assistive technologies. Each entry targets an element by ID and provides content for a specific support type.

**Scoring Dimensions**: For rubric-scored items, define named dimensions with max scores: `"scoring_dimensions": [{"name": "Thesis", "max_score": 3.0, "scoring_method": "human"}]`. Interactions can target a dimension via `target_dimension`.

**Template Variables**: Randomize numeric values across item clones. Define variables with min/max/step in `template.variables`, reference them in question text as `{{var_name}}`, and optionally set `template.constraints` (e.g. `["a != b"]`) and `template.computed_values` (e.g. `{"sum": "a + b"}`).

**Score Maps**: Override default all-or-nothing scoring with weighted per-option scores. Available on choice (`ChoiceScoreMap`), text entry (`TextEntryScoreMap`), and match (`MatchScoreMap`) interactions.

**Score Expressions**: A typed expression tree for custom scoring logic. Supports `map_response`, `variable`, `base_value`, `sum`, `subtract`, `product`, `divide`. Compiles 1:1 to QTI expression elements.

**PCI (Portable Custom Interaction)**: For interactive widgets not covered by standard QTI interactions. Registered modules (`number-line-question`, `graph-based-question`, `graph-plot-points-question`, `graph-line-inequality-question`) auto-resolve from the built-in registry. Custom modules require explicit `module` and `data_item_path_uri`.

**Inline SVG**: SVG images can be embedded directly in `question`, `Choice.content`, or any Markdown string field. Use standard `<svg>...</svg>` tags. The SDK's content pipeline preserves block-level HTML through the Markdown-to-XML conversion.
