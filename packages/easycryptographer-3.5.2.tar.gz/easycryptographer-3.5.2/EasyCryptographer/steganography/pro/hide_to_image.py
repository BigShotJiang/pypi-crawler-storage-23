import numpy as np
from PIL import Image
from publicmodel.common import animation_progress_bar, auto_line_wrap

from EasyCryptographer import SecurityLevelError, ImageError


class Encryptor:
    """LSB 图片隐写加密器。

    使用最低有效位（LSB）技术将文本嵌入图片像素中，
    security_level 控制每个颜色通道使用的位数（1-3），
    确保修改后的图片在视觉上与原图几乎无差异。
    """

    def __init__(self, image_path: str, text: str, security_level: int = 3):
        self.image_path = image_path
        self.text = text
        self.security_level = security_level

        if security_level not in [1, 2, 3]:
            raise SecurityLevelError("Invalid security level. Choose from 1, 2, or 3.")

    def _text_to_bits(self) -> np.ndarray:
        """将文本转换为 bit 数组，前 32 位存储文本字节长度。"""
        text_bytes = self.text.encode('utf-8')
        text_length = len(text_bytes)
        # 32 位长度头 + 文本数据
        length_bits = np.array(
            [int(b) for b in format(text_length, '032b')], dtype=np.uint8
        )
        text_bits = np.unpackbits(
            np.frombuffer(text_bytes, dtype=np.uint8)
        )
        return np.concatenate([length_bits, text_bits])

    def create_image(self) -> Image.Image:
        """创建隐写图片。

        将文本 bit 流嵌入到图片像素 RGB 通道的最低 N 位中，
        N 由 security_level 决定。
        """
        bits = self._text_to_bits()
        bits_per_pixel = 3 * self.security_level  # 每像素可嵌入的 bit 数

        image = Image.open(self.image_path).convert('RGB')
        pixels = np.array(image, dtype=np.uint8)
        h, w, c = pixels.shape
        total_pixels = h * w

        # 第一个像素保留用于存储 security_level 元信息
        capacity = (total_pixels - 1) * bits_per_pixel
        if len(bits) > capacity:
            raise ImageError(
                f"图片容量不足：需要 {len(bits)} bits，"
                f"但仅有 {capacity} bits 可用。"
            )

        # 将 bit 流补齐到 bits_per_pixel 的整数倍
        padded_length = ((len(bits) + bits_per_pixel - 1) // bits_per_pixel) * bits_per_pixel
        padded_bits = np.zeros(padded_length, dtype=np.uint8)
        padded_bits[:len(bits)] = bits

        # 重塑为 (N, 3, security_level)，每像素 3 通道各 security_level 位
        num_embed_pixels = padded_length // bits_per_pixel
        bit_groups = padded_bits.reshape(num_embed_pixels, 3, self.security_level)

        # 将每通道的 security_level 个 bit 合并为一个整数值
        # 例如 security_level=3 时，[1,0,1] → 5
        powers = 2 ** np.arange(self.security_level - 1, -1, -1, dtype=np.uint8)
        embed_values = np.sum(bit_groups * powers, axis=2).astype(np.uint8)  # (N, 3)

        # 展平像素数组以进行嵌入操作
        flat_pixels = pixels.reshape(-1, 3)

        # 第一个像素存储 security_level 元信息
        flat_pixels[0] = [self.security_level, self.security_level, self.security_level]

        # 清除目标像素的最低 N 位，然后嵌入数据
        mask = np.uint8((0xFF << self.security_level) & 0xFF)  # 高位掩码
        target = flat_pixels[1:1 + num_embed_pixels]
        target[:] = (target & mask) | embed_values

        result_image = Image.fromarray(pixels)
        return result_image

    def save_image(self, filename: str):
        """保存隐写图片到文件。"""
        image = self.create_image()
        image.save(filename)


class Decryptor:
    """LSB 图片隐写解密器。

    从隐写图片中提取最低有效位数据，还原隐藏的文本。
    """

    def __init__(self, image_path: str):
        self.image_path = image_path

    def extract_text(self) -> str:
        """从隐写图片中提取隐藏的文本。"""
        image = Image.open(self.image_path).convert('RGB')
        pixels = np.array(image, dtype=np.uint8)
        flat_pixels = pixels.reshape(-1, 3)

        # 从第一个像素读取 security_level
        security_level = int(min(flat_pixels[0][0], 3))
        if security_level < 1:
            security_level = 1

        # 提取所有数据像素的最低 N 位
        data_pixels = flat_pixels[1:]  # 跳过元信息像素
        lsb_mask = np.uint8((1 << security_level) - 1)
        channel_values = data_pixels & lsb_mask  # (M, 3)

        # 将每个通道值拆解为 security_level 个 bit
        # 按 (pixel, channel, bit_pos) 的顺序排列
        num_pixels = len(data_pixels)
        bit_array = np.zeros((num_pixels, 3, security_level), dtype=np.uint8)
        for bit_pos in range(security_level):
            shift = security_level - 1 - bit_pos
            bit_array[:, :, bit_pos] = (channel_values >> shift) & 1

        flat_bits = bit_array.reshape(-1)

        # 读取前 32 位获取文本长度
        if len(flat_bits) < 32:
            return ''
        length_bits = flat_bits[:32]
        text_length = int(''.join(str(b) for b in length_bits), 2)

        # 提取文本 bit 数据
        total_text_bits = text_length * 8
        if len(flat_bits) < 32 + total_text_bits:
            return ''
        text_bits = flat_bits[32:32 + total_text_bits]

        # 转换为字节
        text_bytes = np.packbits(text_bits)[:text_length]
        return bytes(text_bytes).decode('utf-8')


if __name__ == '__main__':
    text = (
        "Steganography is a technique used to hide information within other non-secret data. In encryption, text"
        " is converted into binary and embedded into an image's pixel values. The image size is adjusted to"
        " accommodate the data. For decryption, the binary data is extracted from the image and converted back to"
        " text. This method ensures that the hidden message is not easily detectable, providing an additional layer"
        " of security."
    )

    image_path = '../../generated_items/images/hide_to_image_pro_input.png'
    security_level = 3

    encryptor = Encryptor(image_path, text, security_level)
    animation_progress_bar(
        "Encrypting...",
        None,
        0.25,
        encryptor.save_image,
        "process",
        '../../generated_items/images/hide_to_image_pro_output.png',
    )
    print("Encryption is complete.")

    decryptor = Decryptor('../../generated_items/images/hide_to_image_pro_output.png')
    extracted_text = animation_progress_bar(
        "Decrypting...",
        None,
        0.25,
        decryptor.extract_text,
        "process",
    )

    new_extracted_text = auto_line_wrap(extracted_text, 100, True)

    print("Decryption is completed.\n")
    print("Decrypted text:")
    print(new_extracted_text)
