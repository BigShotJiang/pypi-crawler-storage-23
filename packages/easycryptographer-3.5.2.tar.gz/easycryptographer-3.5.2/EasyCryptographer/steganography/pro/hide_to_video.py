import os
import shutil
import subprocess
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor
from math import ceil

import cv2
import numpy as np
from publicmodel.common import auto_line_wrap, animation_progress_bar

from EasyCryptographer import FormatError, one_layer_encryption, second_level_decryption

# "<end>" 标记的 UTF-8 比特序列，用于解密时快速匹配
_END_MARKER = "<end>"
_END_MARKER_BYTES = _END_MARKER.encode('utf-8')
_END_MARKER_BITS_LEN = len(_END_MARKER_BYTES) * 8


def _text_to_bits(text: str) -> np.ndarray:
    """将文本转换为 numpy uint8 比特数组（每个元素为 0 或 1）。"""
    byte_array = np.frombuffer(text.encode('utf-8'), dtype=np.uint8)
    # 将每个字节展开为 8 个 bit
    return np.unpackbits(byte_array)


def _bits_to_text(bits: np.ndarray) -> str:
    """将 numpy uint8 比特数组转换回文本。"""
    # 截断到 8 的倍数
    truncated_len = (len(bits) // 8) * 8
    if truncated_len == 0:
        return ""
    bits_truncated = bits[:truncated_len]
    byte_array = np.packbits(bits_truncated)
    return bytes(byte_array).decode('utf-8', errors='ignore')


def _embed_bits_into_frame(frame: np.ndarray, bits: np.ndarray, bit_offset: int) -> int:
    """使用 NumPy 向量化将比特嵌入帧的 LSB 中。

    Args:
        frame: 视频帧（会被就地修改）。
        bits: 完整的比特数组。
        bit_offset: 当前已写入的比特偏移。

    Returns:
        更新后的比特偏移。
    """
    total_bits = len(bits)
    if bit_offset >= total_bits:
        return bit_offset

    # 将帧展平为一维数组
    flat = frame.reshape(-1)
    available_pixels = len(flat)
    bits_to_write = min(total_bits - bit_offset, available_pixels)

    if bits_to_write > 0:
        # 向量化：清除 LSB 并设置新值
        segment = flat[:bits_to_write]
        flat[:bits_to_write] = (segment & 0xFE) | bits[bit_offset:bit_offset + bits_to_write]
        bit_offset += bits_to_write

    return bit_offset


def _write_segment(args: tuple) -> str:
    """多进程 worker：将一批帧编码写入临时 FFV1 视频文件。

    Args:
        args: (frames_list, fps, frame_size, segment_index, temp_dir) 元组。

    Returns:
        临时文件路径。
    """
    frames_list, fps, frame_size, segment_index, temp_dir = args
    temp_path = os.path.join(temp_dir, f"segment_{segment_index:04d}.avi")
    fourcc = cv2.VideoWriter_fourcc(*'FFV1')
    writer = cv2.VideoWriter(temp_path, fourcc, fps, frame_size)
    for frame in frames_list:
        writer.write(frame)
    writer.release()
    return temp_path


# FFV1 无损编码器兼容的容器格式
_COMPATIBLE_EXTENSIONS = ['.avi', '.mkv']


def _check_compatible_extension(output_file: str) -> None:
    """检查输出文件的扩展名是否与 FFV1 无损编码器兼容。

    Args:
        output_file: 输出文件路径。

    Raises:
        FormatError: 文件扩展名不兼容 FFV1 编码器。
    """
    file_extension = os.path.splitext(output_file)[1].lower()
    if file_extension not in _COMPATIBLE_EXTENSIONS:
        raise FormatError(
            f"文件扩展名 '{file_extension}' 不兼容 FFV1 无损编码器。"
            f"请使用以下格式之一：{_COMPATIBLE_EXTENSIONS}"
        )


class Encryptor:
    """视频隐写加密器，使用多进程并行 FFV1 编码 + NumPy 向量化加速。

    加密流程：
    1. 串行读取所有帧（I/O 受限，无法并行）
    2. 主进程内 NumPy 向量化嵌入 bit（微秒级，无需多进程）
    3. 多进程并行 FFV1 编码写入分段文件（真正的 CPU 瓶颈）
    4. 使用 ffmpeg 无损拼接分段文件（极快）
    """

    def __init__(self, text: str, input_file: str, output_file: str, max_workers: int = None):
        _check_compatible_extension(output_file)
        self.text = one_layer_encryption(text) + _END_MARKER
        self.input_file = input_file
        self.output_file = output_file
        # 默认使用 CPU 核心数，预留 1 核给系统
        self.max_workers = max_workers or max(1, (os.cpu_count() or 4) - 1)

    def save_video(self) -> None:
        """读取输入视频，将加密文本嵌入帧 LSB，输出加密视频。

        优化策略：
        - bit 嵌入在主进程内完成（NumPy 向量化，极快）
        - FFV1 编码通过多进程并行处理不同帧段
        """
        bits = _text_to_bits(self.text)
        total_bits = len(bits)

        video_capture = cv2.VideoCapture(self.input_file)
        fps = int(video_capture.get(cv2.CAP_PROP_FPS))
        frame_width = int(video_capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        frame_height = int(video_capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        frame_size = (frame_width, frame_height)
        pixels_per_frame = frame_width * frame_height * 3

        # 第一步：串行读取所有帧
        frames = []
        while True:
            ret, frame = video_capture.read()
            if not ret:
                break
            frames.append(frame)
        video_capture.release()

        if not frames:
            return

        # 第二步：主进程内 NumPy 向量化嵌入 bit（极快，无需多进程）
        bit_offset = 0
        for frame in frames:
            if bit_offset >= total_bits:
                break
            bit_offset = _embed_bits_into_frame(frame, bits, bit_offset)

        # 第三步：多进程并行 FFV1 编码
        num_workers = min(self.max_workers, len(frames))
        frames_per_segment = ceil(len(frames) / num_workers)

        with tempfile.TemporaryDirectory() as temp_dir:
            # 将帧分成 num_workers 段
            tasks = []
            for i in range(num_workers):
                start = i * frames_per_segment
                end = min(start + frames_per_segment, len(frames))
                if start >= len(frames):
                    break
                segment_frames = frames[start:end]
                tasks.append((segment_frames, fps, frame_size, i, temp_dir))

            # 多进程并行编码各段
            with ProcessPoolExecutor(max_workers=num_workers) as executor:
                segment_paths = list(executor.map(_write_segment, tasks))

            if len(segment_paths) == 1:
                # 只有一段，直接重命名
                os.replace(segment_paths[0], self.output_file)
            else:
                # 使用 ffmpeg 无损拼接（极快，仅复制流不重编码）
                self._concat_segments(segment_paths)

        # 第四步：将原始视频的音频轨道合并到输出视频
        self._mux_audio()

    def _concat_segments(self, segment_paths: list) -> None:
        """使用 ffmpeg 无损拼接多个视频段。

        Args:
            segment_paths: 各段临时视频文件路径。
        """
        # 创建 ffmpeg concat 文件列表
        concat_dir = os.path.dirname(segment_paths[0])
        concat_list_path = os.path.join(concat_dir, "concat_list.txt")
        with open(concat_list_path, 'w') as f:
            for path in segment_paths:
                # ffmpeg concat 格式需要转义单引号
                escaped = path.replace("'", "'\\''")
                f.write(f"file '{escaped}'\n")

        try:
            subprocess.run(
                [
                    'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
                    '-i', concat_list_path,
                    '-c', 'copy',  # 直接复制流，不重编码
                    self.output_file
                ],
                check=True,
                capture_output=True,
            )
        except FileNotFoundError:
            # ffmpeg 不可用，回退到 OpenCV 逐帧合并
            self._concat_segments_fallback(segment_paths)
        except subprocess.CalledProcessError:
            # ffmpeg 执行失败，回退
            self._concat_segments_fallback(segment_paths)

    @staticmethod
    def _has_audio_stream(file_path: str) -> bool:
        """检测视频文件是否包含音频流。

        Args:
            file_path: 视频文件路径。

        Returns:
            如果包含音频流返回 True，否则返回 False。
        """
        try:
            result = subprocess.run(
                [
                    'ffprobe', '-v', 'error',
                    '-select_streams', 'a',
                    '-show_entries', 'stream=codec_type',
                    '-of', 'csv=p=0',
                    file_path
                ],
                capture_output=True,
                text=True,
            )
            return 'audio' in result.stdout
        except (FileNotFoundError, subprocess.CalledProcessError):
            return False

    def _mux_audio(self) -> None:
        """将原始输入视频的音频轨道合并到加密后的输出视频中。

        使用 ffmpeg 将输出视频的视频流与输入视频的音频流合并，
        音频直接复制不重编码，保持无损。如果原始视频没有音频或
        ffmpeg 不可用，则跳过。
        """
        if not self._has_audio_stream(self.input_file):
            return

        # 先将当前输出重命名为临时文件，再合并
        temp_output = self.output_file + ".tmp_mux.avi"
        try:
            shutil.move(self.output_file, temp_output)
            subprocess.run(
                [
                    'ffmpeg', '-y',
                    '-i', temp_output,  # 加密后的视频（无音频）
                    '-i', self.input_file,  # 原始视频（有音频）
                    '-map', '0:v',  # 取第一个输入的视频流
                    '-map', '1:a',  # 取第二个输入的音频流
                    '-c:v', 'copy',  # 视频流直接复制，不重编码
                    '-c:a', 'copy',  # 音频流直接复制，不重编码
                    '-shortest',  # 以较短的流为准
                    self.output_file
                ],
                check=True,
                capture_output=True,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            # ffmpeg 不可用或执行失败，回退：保留无音频的视频
            if not os.path.exists(self.output_file) and os.path.exists(temp_output):
                shutil.move(temp_output, self.output_file)
        finally:
            # 清理临时文件
            if os.path.exists(temp_output):
                os.remove(temp_output)

    def _concat_segments_fallback(self, segment_paths: list) -> None:
        """当 ffmpeg 不可用时，使用 OpenCV 逐帧读取并合并。

        Args:
            segment_paths: 各段临时视频文件路径。
        """
        writer = None
        for seg_path in segment_paths:
            cap = cv2.VideoCapture(seg_path)
            if writer is None:
                fps = int(cap.get(cv2.CAP_PROP_FPS))
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                fourcc = cv2.VideoWriter_fourcc(*'FFV1')
                writer = cv2.VideoWriter(self.output_file, fourcc, fps, (w, h))
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                writer.write(frame)
            cap.release()
        if writer:
            writer.release()


class Decryptor:
    """视频隐写解密器，使用 NumPy 向量化加速提取。"""

    def __init__(self, input_file: str):
        self.input_file = input_file

    def video_to_text(self) -> str:
        """从加密视频中提取隐藏文本。

        使用 NumPy 向量化批量提取每帧 LSB，在帧级别检测 <end> 标记。
        仅对最新帧的尾部解码来检测结束标记，避免重复拼接和全量解码。

        Returns:
            解密后的原始文本。
        """
        video_capture = cv2.VideoCapture(self.input_file)
        all_bits = []
        total_bits_count = 0

        while True:
            ret, frame = video_capture.read()
            if not ret:
                break

            # NumPy 向量化提取 LSB
            flat = frame.reshape(-1)
            frame_bits = (flat & 1).astype(np.uint8)
            all_bits.append(frame_bits)
            total_bits_count += len(frame_bits)

            # 高效检测 "<end>" 标记：
            # 只解码最新帧的尾部区域，而非每次拼接全部 bits
            # "<end>" = 5 字节 = 40 bit，检查最后 1024 字节（8192 bit）足够覆盖跨帧边界
            check_bits_count = min(total_bits_count, 8192)
            if check_bits_count <= len(frame_bits):
                # 检查范围完全在当前帧内
                check_start = max(0, (len(frame_bits) // 8 - 1024) * 8)
                tail_text = _bits_to_text(frame_bits[check_start:])
            else:
                # 检查范围跨越多帧，需要拼接最近的帧
                recent_bits = np.concatenate(all_bits[-2:]) if len(all_bits) >= 2 else frame_bits
                check_start = max(0, (len(recent_bits) // 8 - 1024) * 8)
                tail_text = _bits_to_text(recent_bits[check_start:])

            if _END_MARKER in tail_text:
                break

        video_capture.release()

        if not all_bits:
            return ""

        # 拼接所有 bits 并解码
        combined = np.concatenate(all_bits)
        text = _bits_to_text(combined)
        end_index = text.find(_END_MARKER)
        if end_index != -1:
            text = text[:end_index]

        return second_level_decryption(text)


if __name__ == '__main__':
    start_time = time.time()
    text = (
        'This advanced steganography method hides text within video frames using LSB (Least Significant Bit) '
        'embedding. The Encryptor class reads each frame of the input video, converts the encrypted text into '
        'binary bits, and embeds them into the pixel values using NumPy vectorized operations. Multi-process '
        'parallel FFV1 encoding is used to significantly speed up the output. The Decryptor class extracts the '
        'hidden bits from each frame and reconstructs the original text. Audio from the original video is '
        'preserved in the output. This approach provides a robust and efficient solution for hiding sensitive '
        'information within video files.'
    )

    encryptor = Encryptor(
        text,
        '../../generated_items/video/hide_to_video_input_pro.mp4',
        '../../generated_items/video/hide_to_video_output_pro.avi',
    )
    animation_progress_bar(
        "Encrypting...",
        None,
        0.25,
        encryptor.save_video,
        "process",
    )
    print(f"Encryption is complete. {time.time() - start_time}")

    start_time = time.time()
    decryptor = Decryptor(
        '../../generated_items/video/hide_to_video_output_pro.avi'
    )
    extracted_text = animation_progress_bar(
        "Decrypting...",
        None,
        0.25,
        decryptor.video_to_text,
        "process",
    )
    try:
        extracted_text = auto_line_wrap(extracted_text, 100, True)
    except AttributeError:
        pass

    print(f"Decryption is completed. {time.time() - start_time}\n")
    print("Decrypted text:")
    print(f"{extracted_text}")
