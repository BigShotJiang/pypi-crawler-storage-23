import numpy as np
from publicmodel.common import animation_progress_bar, auto_line_wrap
from pydub import AudioSegment

from EasyCryptographer import one_layer_encryption, second_level_decryption


class Encryptor:
    """音频 LSB 隐写加密器。

    使用最低有效位（LSB）技术将加密文本嵌入音频采样数据中，
    输出为无损 WAV 格式，原始音频文件不会被修改。
    """

    def __init__(self, text: str, input_audio_path: str, output_audio_path: str):
        self.text = one_layer_encryption(text) + "<END>"  # 添加结束标志
        self.input_audio_path = input_audio_path
        self.output_audio_path = output_audio_path
        self.sample_rate, self.carrier_audio = self._read_audio(input_audio_path)
        self.text_bits = self._text_to_bits(self.text)

    @staticmethod
    def _read_audio(path: str):
        """读取音频文件并转换为单声道采样数组。"""
        audio = AudioSegment.from_file(path)
        audio = audio.set_channels(1)  # 转换为单声道
        samples = np.array(audio.get_array_of_samples())
        return audio.frame_rate, samples

    @staticmethod
    def _text_to_bits(text: str) -> str:
        """将文本转换为二进制比特字符串。"""
        bits = ''.join(format(ord(char), '08b') for char in text)
        return bits

    def _hide_text_in_audio(self) -> np.ndarray:
        """将文本比特嵌入音频采样的最低有效位中。"""
        audio_data = self.carrier_audio.copy()
        bit_index = 0
        for i in range(len(audio_data)):
            if bit_index < len(self.text_bits):
                audio_data[i] = (audio_data[i] & ~1) | int(self.text_bits[bit_index])
                bit_index += 1
        return audio_data

    def save_audio(self) -> None:
        """将加密音频保存到输出路径（不覆写原始文件）。"""
        audio_data = self._hide_text_in_audio()
        audio_segment = AudioSegment(
            audio_data.tobytes(),
            frame_rate=self.sample_rate,
            sample_width=audio_data.dtype.itemsize,
            channels=1
        )
        audio_segment.export(self.output_audio_path, format="wav")


class Decryptor:
    """音频 LSB 隐写解密器。

    从隐写音频中提取最低有效位数据，还原隐藏的文本。
    """

    def __init__(self, audio_path: str):
        self.audio_path = audio_path
        self.sample_rate, self.audio_data = self._read_audio(audio_path)

    @staticmethod
    def _read_audio(path: str):
        """读取音频文件并转换为单声道采样数组。"""
        audio = AudioSegment.from_file(path)
        audio = audio.set_channels(1)  # 转换为单声道
        samples = np.array(audio.get_array_of_samples())
        return audio.frame_rate, samples

    @staticmethod
    def _bits_to_text(bits: str) -> str:
        """将二进制比特字符串转换为文本。"""
        chars = [chr(int(bits[i:i + 8], 2)) for i in range(0, len(bits), 8)]
        return ''.join(chars)

    def audio_to_text(self) -> str:
        """从隐写音频中提取隐藏的文本。"""
        bits = ''
        for i in range(len(self.audio_data)):
            bits += str(self.audio_data[i] & 1)
        text = self._bits_to_text(bits)
        end_index = text.find("<END>")
        if end_index != -1:
            text = text[:end_index]
        return second_level_decryption(text)


if __name__ == '__main__':
    text = (
        'This encryption method embeds text into audio files using bit manipulation. The text is first encrypted with '
        'a custom function and appended with "<END>". The audio file is converted to mono and its samples are modified '
        'to hide the text bits. The modified audio is saved as a WAV file. For decryption, the audio file is read, and '
        'the hidden bits are extracted and converted back to text, stopping at "<END>". The text is then decrypted '
        'using the custom function.'
    )

    encryptor = Encryptor(
        text,
        '../../generated_items/audio/hide_to_audio_pro_input.wav',
        '../../generated_items/audio/hide_to_audio_pro_output.wav',
    )
    animation_progress_bar(
        "Encrypting...",
        None,
        0.25,
        encryptor.save_audio,
        "process",
    )
    print("Encryption is complete.")

    decryptor = Decryptor('../../generated_items/audio/hide_to_audio_pro_output.wav')
    extracted_text = animation_progress_bar(
        "Decrypting...",
        None,
        0.25,
        decryptor.audio_to_text,
        "process",
    )
    try:
        extracted_text = auto_line_wrap(extracted_text, 100, True)
    except AttributeError:
        pass

    print("Decryption is completed.\n")
    print("Decrypted text:")
    print(extracted_text)
