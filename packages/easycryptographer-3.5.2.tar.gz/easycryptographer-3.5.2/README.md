# 🔐 EasyCryptographer

> 让用户能够简单、方便地进行加密解密，同时支持将信息隐藏到图片、音频、视频等多媒体文件中（隐写术）。

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.6%2B-brightgreen.svg)](https://www.python.org/)
[![Version](https://img.shields.io/badge/Version-3.5.2-orange.svg)](https://gitee.com/yanxinle1123/EasyCryptographer)

## 📖 简介

EasyCryptographer 是一个基于 Python 的加密/解密及隐写术工具库，提供了：

- **8 种加密算法**的统一封装，支持自动选择和自动识别
- **6 种隐写术方案**（3 种媒体类型 × lite/pro 两个版本）
- 一个带设置和快捷键的 **Tkinter GUI** 桌面应用

## 🏗️ 项目结构

```
EasyCryptographer/
├── setup.py                      # 包安装配置
├── requirements.txt              # 依赖清单
├── test.py                       # 测试文件
├── LICENSE                       # MIT 许可证
└── EasyCryptographer/            # 核心包
    ├── __init__.py               # 包入口 + 工具函数 + 自定义异常
    ├── cryptography_program.py   # Tkinter GUI 主程序
    ├── convention/               # 传统加密算法模块
    │   ├── AEAD/                 # ChaCha20 流密码（AEAD）
    │   ├── AES/                  # AES-256-GCM
    │   ├── Blowfish/             # Blowfish-CBC
    │   ├── Camellia/             # Camellia 对称加密
    │   ├── CAST5/                # CAST5 对称加密
    │   ├── Fernet/               # Fernet 对称加密
    │   ├── RC4/                  # RC4 流密码
    │   ├── RSA/                  # ChaCha20 流密码（注：实际使用 ChaCha20 算法）
    │   └── images/               # 图标资源
    └── steganography/            # 隐写术模块
        ├── lite/                 # 轻量版（生成新媒体文件）
        │   ├── hide_to_image.py  # 文本 → 图片
        │   ├── hide_to_audio.py  # 文本 → 音频
        │   └── hide_to_video.py  # 文本 → 视频
        └── pro/                  # 专业版（嵌入现有媒体文件，LSB 隐写）
            ├── hide_to_image.py  # 文本嵌入图片
            ├── hide_to_audio.py  # 文本嵌入音频
            └── hide_to_video.py  # 文本嵌入视频
```

## 🚀 安装

### 通过 pip 安装

```bash
pip install EasyCryptographer
```

### 从源码安装

```bash
git clone https://gitee.com/yanxinle1123/EasyCryptographer.git
cd EasyCryptographer
pip install -r requirements.txt
pip install -e .
```

### 系统依赖

隐写术的视频处理功能需要安装 FFmpeg：

- **macOS**: `brew install ffmpeg`
- **Ubuntu/Debian**: `sudo apt install ffmpeg`
- **Windows**: 从 [FFmpeg 官网](https://ffmpeg.org/download.html) 下载并添加到环境变量

## 📝 快速开始

### 加密 & 解密

```python
from EasyCryptographer.convention.AES.AES_method import AESEncryptionMethod, AESDecryptionMethod

# 加密
encryptor = AESEncryptionMethod("Hello, World!")
cipher_text, key = encryptor.encryption()
print(f"密文: {cipher_text}")
print(f"密钥: {key}")

# 解密
decryptor = AESDecryptionMethod(cipher_text, key)
plain_text = decryptor.decryption()
print(f"明文: {plain_text}")
```

### 隐写术 — Lite 版（生成新图片）

```python
from EasyCryptographer.steganography.lite.hide_to_image import Encryptor, Decryptor

# 将文本隐藏到图片中
encryptor = Encryptor("这是一段秘密消息", "output.png")
encryptor.save_image()

# 从图片中提取文本
decryptor = Decryptor("output.png")
text = decryptor.image_to_text()
print(f"提取的文本: {text}")
```

### 隐写术 — Pro 版（嵌入现有图片）

```python
from EasyCryptographer.steganography.pro.hide_to_image import Encryptor, Decryptor

# 将文本嵌入到现有图片中
encryptor = Encryptor("这是一段秘密消息", "input.png", "output.png")
encryptor.save_image()

# 从图片中提取文本
decryptor = Decryptor("output.png")
text = decryptor.image_to_text()
print(f"提取的文本: {text}")
```

### 启动 GUI 程序

```bash
python -m EasyCryptographer.cryptography_program
```

## 🔑 支持的加密算法


| 算法名   | 密钥标识码 | 说明                              |
| -------- | ---------- | --------------------------------- |
| AES      | `2`        | AES-256-GCM 认证加密，推荐使用    |
| Fernet   | `3`        | 基于 AES-128-CBC + HMAC，简单安全 |
| RSA      | `4`        | 实际使用 ChaCha20 流密码          |
| AEAD     | `5`        | ChaCha20 流密码                   |
| Blowfish | `6`        | Blowfish-CBC 对称加密             |
| CAST5    | `7`        | CAST5 对称加密                    |
| RC4      | `8`        | RC4 流密码                        |
| Camellia | `9`        | Camellia 对称加密                 |

> **密钥自动识别**：密钥的首字符为数字（2-9），解密时程序自动识别使用了哪种算法，无需手动选择。

> **自动加密策略**：当设置为"自动"模式时，程序会根据明文长度自动选择最适合的加密算法。

## 🖼️ 隐写术模块

### Lite 版（轻量）

将文本信息编码后**生成全新的**媒体文件：

- **图片**：文本转二进制后映射为 RGB 像素值
- **音频**：基于字符频率映射生成 WAV 音频
- **视频**：字符编码为灰度帧，使用 FFV1 无损编解码器

### Pro 版（专业）

使用 **LSB（最低有效位）隐写术**将文本嵌入到现有媒体文件中：

- **图片**：支持 1/2/3 个通道的 LSB 隐写
- **音频**：文本比特嵌入音频采样的最低有效位
- **视频**：LSB 隐写 + 多进程并行处理

## ⌨️ GUI 快捷键


| 快捷键        | 功能         |
| ------------- | ------------ |
| `Command + ,` | 打开设置窗口 |
| `F1`          | 打开使用说明 |
| `Q`           | 退出程序     |

## 📦 依赖列表

- `cryptography` — 核心加密库
- `TkinterLite` — Tkinter 增强组件
- `Pillow` / `opencv-python` — 图像处理
- `pydub` / `scipy` / `numpy` — 音频处理
- `moviepy` / `ffmpeg-python` — 视频处理
- `publicmodel` — 公共工具模型
- `stegano` — 隐写术辅助

## 📄 许可证

本项目基于 [MIT License](LICENSE) 开源。

## 👤 作者

**YanXinle** — [1020121123@qq.com](mailto:1020121123@qq.com)

项目地址：[https://gitee.com/yanxinle1123/EasyCryptographer](https://gitee.com/yanxinle1123/EasyCryptographer)
