::: pynspd.errors.PynspdError

::: pynspd.errors.UnknownLayer
::: pynspd.errors.AmbiguousSearchError
::: pynspd.errors.TooBigContour

::: pynspd.errors.PynspdResponseError
::: pynspd.errors.PynspdServerError
::: pynspd.errors.BlockedIP
::: pynspd.errors.TooManyRequests
::: pynspd.errors.NotFound