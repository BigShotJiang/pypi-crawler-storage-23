import logging

logger = logging.getLogger("pynspd")
