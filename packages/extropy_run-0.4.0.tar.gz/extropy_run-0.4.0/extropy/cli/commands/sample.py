"""Sample command for generating agents from scenario specs."""

import time
from pathlib import Path

import typer

from ...core.models import PopulationSpec
from ...core.models.scenario import ScenarioSpec
from ...population.validator import validate_spec
from ...utils import topological_sort, CircularDependencyError
from ..app import app, console, is_agent_mode, get_study_path
from ..study import StudyContext, detect_study_folder, resolve_scenario
from ..utils import (
    Output,
    ExitCode,
    format_elapsed,
    format_validation_for_json,
    format_sampling_stats_for_json,
    save_invalid_json_artifact,
)


@app.command("sample")
def sample_command(
    scenario: str = typer.Option(
        None,
        "--scenario",
        "-s",
        help="Scenario name (auto-selects if only one exists)",
    ),
    count: int = typer.Option(
        ...,
        "--count",
        "-n",
        help="Number of agents to sample",
    ),
    seed: int | None = typer.Option(
        None, "--seed", help="Random seed for reproducibility"
    ),
    report: bool = typer.Option(
        False, "--report", "-r", help="Show distribution summaries and stats"
    ),
    skip_validation: bool = typer.Option(
        False, "--skip-validation", help="Skip validator errors"
    ),
    strict_gates: bool = typer.Option(
        False,
        "--strict-gates",
        help="Fail on high-risk warnings and post-sampling coherence gate violations",
    ),
):
    """
    Sample agents from a scenario's merged population spec.

    Loads the scenario's base population and extended attributes, merges them,
    validates the merged spec, and samples the requested number of agents.

    Prerequisites:
        - Population spec must exist
        - Scenario spec must exist
        - Persona config must exist for the scenario

    EXIT CODES:
        0 = Success
        1 = Validation error
        3 = File not found
        4 = Sampling error

    Examples:
        extropy sample -s ai-adoption -n 500
        extropy sample -s ai-adoption -n 1000 --seed 42 --report
        extropy sample -n 500  # auto-selects scenario if only one exists
    """
    from ...population.sampler import sample_population, SamplingError

    agent_mode = is_agent_mode()
    out = Output(console=console, json_mode=agent_mode)
    start_time = time.time()
    out.blank()

    # Resolve study context
    study_path = get_study_path()
    detected = detect_study_folder(study_path)
    if detected is None:
        out.error(
            "Not in a study folder. Use --study to specify or run from a study folder.",
            exit_code=ExitCode.FILE_NOT_FOUND,
        )
        raise typer.Exit(out.finish())

    study_ctx = StudyContext(detected)

    # Resolve scenario
    try:
        scenario_name, scenario_version = resolve_scenario(study_ctx, scenario)
    except ValueError as e:
        out.error(str(e), exit_code=ExitCode.FILE_NOT_FOUND)
        raise typer.Exit(out.finish())

    # Pre-flight: Check persona config exists
    try:
        study_ctx.get_persona_path(scenario_name)
    except FileNotFoundError:
        out.error(
            f"No persona config found for scenario: {scenario_name}. "
            f"Run 'extropy persona -s {scenario_name}' first.",
            exit_code=ExitCode.FILE_NOT_FOUND,
        )
        raise typer.Exit(out.finish())

    # Load scenario spec
    try:
        scenario_path = study_ctx.get_scenario_path(scenario_name, scenario_version)
        scenario_spec = ScenarioSpec.from_yaml(scenario_path)
    except FileNotFoundError:
        out.error(
            f"Scenario not found: {scenario_name}", exit_code=ExitCode.FILE_NOT_FOUND
        )
        raise typer.Exit(out.finish())
    except Exception as e:
        out.error(f"Failed to load scenario: {e}")
        raise typer.Exit(out.finish())

    # Load base population spec
    try:
        pop_name, pop_version = scenario_spec.meta.get_population_ref()
    except ValueError as e:
        out.error(str(e))
        raise typer.Exit(1)

    pop_path = study_ctx.get_population_path(pop_name, pop_version)

    try:
        pop_spec = PopulationSpec.from_yaml(pop_path)
    except Exception as e:
        out.error(f"Failed to load population spec: {e}")
        raise typer.Exit(1)

    # Merge attributes: base population + scenario extended attributes
    merged_attributes = list(pop_spec.attributes)
    extended_attrs = scenario_spec.extended_attributes or []
    merged_attributes.extend(extended_attrs)

    # Compute merged sampling order deterministically via topological sort
    try:
        merged_deps: dict[str, list[str]] = {
            attr.name: list(attr.sampling.depends_on or [])
            for attr in merged_attributes
        }
        merged_names = set(merged_deps.keys())
        merged_deps = {
            name: [dep for dep in deps if dep in merged_names]
            for name, deps in merged_deps.items()
        }
        merged_sampling_order = topological_sort(merged_deps)
    except CircularDependencyError as e:
        invalid_path = save_invalid_json_artifact(
            {
                "stage": "sample",
                "scenario": scenario_name,
                "error": f"merged_sampling_order_cycle: {e}",
            },
            study_ctx.get_scenario_dir(scenario_name) / "sample.json",
            stem="sample",
            extension=".json",
        )
        out.error(
            f"Merged sampling order has circular dependency: {e}. Saved: {invalid_path}",
            exit_code=ExitCode.VALIDATION_ERROR,
        )
        raise typer.Exit(out.finish())

    # Create merged spec for sampling
    merged_spec = PopulationSpec(
        meta=pop_spec.meta.model_copy(),
        grounding=pop_spec.grounding,
        attributes=merged_attributes,
        sampling_order=merged_sampling_order,
    )

    # Get household config and agent focus mode from scenario
    household_config = scenario_spec.household_config
    agent_focus_mode = scenario_spec.agent_focus_mode
    sampling_semantic_roles = scenario_spec.sampling_semantic_roles

    out.success(
        f"Loaded scenario: [bold]{scenario_name}[/bold] "
        f"({len(merged_attributes)} attributes: {len(pop_spec.attributes)} base + {len(extended_attrs)} extended)",
        scenario=scenario_name,
        base_population=f"{pop_name}.v{pop_version}",
        attribute_count=len(merged_attributes),
        agent_count=count,
        strict_gates=strict_gates,
    )

    # Validation Gate
    out.blank()
    if not agent_mode:
        with console.status("[cyan]Validating merged spec...[/cyan]"):
            validation_result = validate_spec(merged_spec)
    else:
        validation_result = validate_spec(merged_spec)

    out.set_data("validation", format_validation_for_json(validation_result))

    if not validation_result.valid:
        if skip_validation:
            out.warning(
                f"Spec has {len(validation_result.errors)} error(s) - skipping validation"
            )
        else:
            invalid_path = save_invalid_json_artifact(
                {
                    "stage": "sample",
                    "scenario": scenario_name,
                    "error": "merged_spec_validation_failed",
                    "validation": format_validation_for_json(validation_result),
                },
                study_ctx.get_scenario_dir(scenario_name) / "sample.json",
                stem="sample",
                extension=".json",
            )
            out.error(
                f"Merged spec has {len(validation_result.errors)} error(s). Saved: {invalid_path}",
                exit_code=ExitCode.VALIDATION_ERROR,
            )
            if not agent_mode:
                for err in validation_result.errors[:5]:
                    out.text(f"  [red]✗[/red] {err.location}: {err.message}")
                if len(validation_result.errors) > 5:
                    out.text(
                        f"  [dim]... and {len(validation_result.errors) - 5} more[/dim]"
                    )
                out.blank()
                out.text("[dim]Use --skip-validation to sample anyway[/dim]")
            raise typer.Exit(out.finish())
    else:
        if validation_result.warnings:
            out.success(
                f"Spec validated with {len(validation_result.warnings)} warning(s)"
            )
        else:
            out.success("Spec validated")

    if strict_gates:
        strict_warning_categories = {"CONDITION_VALUE", "MODIFIER_OVERLAP"}
        promoted = [
            warn
            for warn in (validation_result.warnings or [])
            if warn.category in strict_warning_categories
        ]
        if promoted:
            invalid_path = save_invalid_json_artifact(
                {
                    "stage": "sample",
                    "scenario": scenario_name,
                    "error": "strict_gate_pre_sample_failed",
                    "promoted_warnings": [
                        {
                            "location": w.location,
                            "category": w.category,
                            "message": w.message,
                        }
                        for w in promoted
                    ],
                },
                study_ctx.get_scenario_dir(scenario_name) / "sample.json",
                stem="sample",
                extension=".json",
            )
            out.error(
                f"Strict gate blocked sampling due to high-risk warnings ({len(promoted)}). Saved: {invalid_path}",
                exit_code=ExitCode.VALIDATION_ERROR,
            )
            raise typer.Exit(out.finish())

    # Sampling
    out.blank()
    sampling_start = time.time()
    result = None
    sampling_error = None

    show_progress = count >= 100 and not agent_mode

    if show_progress:
        from rich.progress import (
            Progress,
            SpinnerColumn,
            TextColumn,
            BarColumn,
            TaskProgressColumn,
        )

        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Sampling agents...[/cyan]"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Sampling", total=count)

            def on_progress(current: int, total: int):
                progress.update(task, completed=current)

            try:
                result = sample_population(
                    merged_spec,
                    count=count,
                    seed=seed,
                    on_progress=on_progress,
                    household_config=household_config,
                    agent_focus_mode=agent_focus_mode,
                    semantic_roles=sampling_semantic_roles,
                )
            except SamplingError as e:
                sampling_error = e
    else:
        if not agent_mode:
            with console.status("[cyan]Sampling agents...[/cyan]"):
                try:
                    result = sample_population(
                        merged_spec,
                        count=count,
                        seed=seed,
                        household_config=household_config,
                        agent_focus_mode=agent_focus_mode,
                        semantic_roles=sampling_semantic_roles,
                    )
                except SamplingError as e:
                    sampling_error = e
        else:
            try:
                result = sample_population(
                    merged_spec,
                    count=count,
                    seed=seed,
                    household_config=household_config,
                    agent_focus_mode=agent_focus_mode,
                    semantic_roles=sampling_semantic_roles,
                )
            except SamplingError as e:
                sampling_error = e

    if sampling_error:
        invalid_path = save_invalid_json_artifact(
            {
                "stage": "sample",
                "scenario": scenario_name,
                "error": str(sampling_error),
            },
            study_ctx.get_scenario_dir(scenario_name) / "sample.json",
            stem="sample",
            extension=".json",
        )
        out.error(
            f"Sampling failed: {sampling_error}. Saved: {invalid_path}",
            exit_code=ExitCode.SAMPLING_ERROR,
            suggestion="Check attribute dependencies and formula syntax",
        )
        raise typer.Exit(out.finish())

    sampling_elapsed = time.time() - sampling_start
    out.success(
        f"Sampled {len(result.agents)} agents ({format_elapsed(sampling_elapsed)}, seed={result.meta['seed']})",
        sampled_count=len(result.agents),
        seed=result.meta["seed"],
        sampling_time_seconds=sampling_elapsed,
    )

    # Post-sampling deterministic rule-pack gate
    rule_pack = _evaluate_rule_pack(result, strict_gates=strict_gates)
    result.stats.rule_pack = rule_pack
    out.set_data("rule_pack", rule_pack)
    gate_failed = rule_pack["status"] == "fail"
    if gate_failed:
        invalid_path = save_invalid_json_artifact(
            {
                "stage": "sample",
                "scenario": scenario_name,
                "error": "post_sample_rule_pack_failed",
                "rule_pack": rule_pack,
                "reconciliation_counts": result.stats.reconciliation_counts,
                "constraint_violations": result.stats.constraint_violations,
                "condition_warnings": result.stats.condition_warnings,
            },
            study_ctx.get_scenario_dir(scenario_name) / "sample.json",
            stem="sample",
            extension=".json",
        )
        out.error(
            f"Post-sampling quality gate failed. Saved: {invalid_path}",
            exit_code=ExitCode.SAMPLING_ERROR,
        )
        raise typer.Exit(out.finish())
    if rule_pack.get("status") == "warn":
        out.warning(
            rule_pack.get("summary", "Sampling completed with plausibility warnings")
        )

    # Report
    if agent_mode or report:
        out.set_data("stats", format_sampling_stats_for_json(result.stats, merged_spec))

    if report and not agent_mode:
        _show_sampling_report(out, result, merged_spec)

    # Household report (if applicable)
    households = getattr(result, "_households", [])
    if households and report and not agent_mode:
        _show_household_report(out, households, result)

    if households and agent_mode:
        out.set_data("household_count", len(households))
        out.set_data(
            "household_type_distribution",
            result.meta.get("household_type_distribution", {}),
        )

    # Save to canonical DB with scenario_id
    out.blank()
    db_path = study_ctx.db_path

    if not agent_mode:
        with console.status(f"[cyan]Saving to study DB: {db_path}...[/cyan]"):
            sample_run_id = _save_to_db(
                db_path, scenario_name, pop_spec, pop_path, result, households
            )
    else:
        sample_run_id = _save_to_db(
            db_path, scenario_name, pop_spec, pop_path, result, households
        )

    elapsed = time.time() - start_time

    out.set_data("study_db", str(db_path))
    out.set_data("scenario_id", scenario_name)
    out.set_data("sample_run_id", sample_run_id)
    out.set_data("total_time_seconds", elapsed)

    out.divider()
    out.success(
        f"Saved {len(result.agents)} agents to [bold]{db_path}[/bold] "
        f"(scenario_id={scenario_name}, sample_run_id={sample_run_id})"
    )
    out.text(f"[dim]Total time: {format_elapsed(elapsed)}[/dim]")
    out.divider()

    raise typer.Exit(out.finish())


def _evaluate_rule_pack(result, *, strict_gates: bool) -> dict:
    """Evaluate deterministic impossible/implausible gates on sampled output."""
    total_agents = max(1, len(result.agents))
    impossible_count = sum(result.stats.constraint_violations.values())
    implausible_count = sum(result.stats.reconciliation_counts.values())
    implausible_rate = implausible_count / total_agents

    if strict_gates and result.stats.condition_warnings:
        return {
            "status": "fail",
            "summary": "Condition-evaluation warnings present in strict mode",
            "impossible_count": impossible_count,
            "implausible_count": implausible_count,
            "implausible_rate": implausible_rate,
            "condition_warning_count": len(result.stats.condition_warnings),
        }

    if impossible_count > 0:
        return {
            "status": "fail",
            "summary": "Impossible rule violations detected",
            "impossible_count": impossible_count,
            "implausible_count": implausible_count,
            "implausible_rate": implausible_rate,
        }

    if implausible_rate > 0.05:
        status = "fail"
        summary = "Implausible reconciliation rate exceeds 5%"
    elif implausible_rate >= 0.01:
        status = "warn"
        summary = "Implausible reconciliation rate between 1% and 5%"
    else:
        status = "pass"
        summary = "Rule-pack checks passed"

    return {
        "status": status,
        "summary": summary,
        "impossible_count": impossible_count,
        "implausible_count": implausible_count,
        "implausible_rate": implausible_rate,
    }


def _save_to_db(
    db_path: Path,
    scenario_name: str,
    pop_spec: PopulationSpec,
    pop_path: Path,
    result,
    households: list,
) -> str:
    """Save sampling results to study database."""
    from ...storage import open_study_db

    with open_study_db(db_path) as db:
        # Save population spec (using scenario_name as population_id for backwards compat)
        db.save_population_spec(
            population_id=scenario_name,
            spec_yaml=pop_path.read_text(encoding="utf-8"),
            source_path=str(pop_path),
        )

        # Save agents with scenario_id
        sample_run_id = db.save_sample_result(
            population_id=scenario_name,
            agents=result.agents,
            meta=result.meta,
            seed=result.meta.get("seed"),
            scenario_id=scenario_name,
        )

        if households:
            db.save_households(
                population_id=scenario_name,
                sample_run_id=sample_run_id,
                households=households,
            )

    return sample_run_id


def _show_sampling_report(out: Output, result, spec: PopulationSpec) -> None:
    """Display sampling statistics report."""
    out.header("SAMPLING REPORT")

    # Numeric attributes
    numeric_attrs = [a for a in spec.attributes if a.type in ("int", "float")]
    if numeric_attrs:
        numeric_rows = []
        for attr in numeric_attrs[:20]:
            mean = result.stats.attribute_means.get(attr.name, 0)
            std = result.stats.attribute_stds.get(attr.name, 0)
            numeric_rows.append([attr.name, f"{mean:.2f}", f"{std:.2f}"])
        out.table(
            "Numeric Attributes",
            ["Attribute", "Mean", "Std"],
            numeric_rows,
            styles=["cyan", None, "dim"],
        )
        if len(numeric_attrs) > 20:
            out.text(f"  [dim]... and {len(numeric_attrs) - 20} more[/dim]")
        out.blank()

    # Categorical attributes
    cat_attrs = [a for a in spec.attributes if a.type == "categorical"]
    if cat_attrs:
        cat_rows = []
        for attr in cat_attrs[:15]:
            counts = result.stats.categorical_counts.get(attr.name, {})
            total = sum(counts.values()) or 1
            top_3 = sorted(counts.items(), key=lambda x: -x[1])[:3]
            dist_str = ", ".join(f"{k}: {v / total:.0%}" for k, v in top_3)
            cat_rows.append([attr.name, dist_str])
        out.table(
            "Categorical Attributes",
            ["Attribute", "Top Values"],
            cat_rows,
            styles=["cyan", None],
        )
        if len(cat_attrs) > 15:
            out.text(f"  [dim]... and {len(cat_attrs) - 15} more[/dim]")
        out.blank()

    # Boolean attributes
    bool_attrs = [a for a in spec.attributes if a.type == "boolean"]
    if bool_attrs:
        bool_rows = []
        for attr in bool_attrs[:15]:
            counts = result.stats.boolean_counts.get(attr.name, {True: 0, False: 0})
            total = sum(counts.values()) or 1
            pct_true = counts.get(True, 0) / total
            bool_rows.append([attr.name, f"{pct_true:.1%}"])
        out.table(
            "Boolean Attributes",
            ["Attribute", "True %"],
            bool_rows,
            styles=["cyan", None],
        )
        out.blank()


def _show_household_report(out: Output, households: list, result) -> None:
    """Display household statistics report."""
    out.header("HOUSEHOLD REPORT")
    type_counts: dict[str, int] = {}
    for hh in households:
        ht = hh["household_type"]
        type_counts[ht] = type_counts.get(ht, 0) + 1
    hh_rows = [[htype, str(cnt)] for htype, cnt in sorted(type_counts.items())]
    out.table(
        "Household Types",
        ["Type", "Count"],
        hh_rows,
        styles=["cyan", None],
    )
    out.text(
        f"  Total households: {len(households)}, Total agents: {len(result.agents)}"
    )
    out.blank()
