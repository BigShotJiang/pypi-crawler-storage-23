"""Simulation Engine models for Extropy (Phase 3).

Defines all state and event models used during simulation execution:
- SimulationEventType: Enum of event types
- ExposureRecord: Record of a single exposure
- AgentState: Complete agent state during simulation
- SimulationEvent: Timeline event
- PeerOpinion: Opinion of connected peer
- ReasoningContext: Context for agent reasoning
- ReasoningResponse: Response from agent LLM call (Pass 1)
- ClassificationResponse: Response from classification pass (Pass 2)
- MemoryEntry: Agent reasoning memory trace
- SimulationRunConfig: Configuration for a run
- TimestepSummary: Summary statistics per timestep
- ConvictionLevel: Categorical conviction levels
"""

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


# =============================================================================
# Conviction Levels
# =============================================================================


class ConvictionLevel(str, Enum):
    """Categorical conviction levels.

    The agent picks from these in Pass 1. Mapped to floats for storage/thresholds.
    The agent never sees the numeric value.
    """

    VERY_UNCERTAIN = "very_uncertain"
    LEANING = "leaning"
    MODERATE = "moderate"
    FIRM = "firm"
    ABSOLUTE = "absolute"


# Map conviction levels to float values for storage and threshold math
CONVICTION_MAP: dict[str, float] = {
    ConvictionLevel.VERY_UNCERTAIN: 0.1,
    ConvictionLevel.LEANING: 0.3,
    ConvictionLevel.MODERATE: 0.5,
    ConvictionLevel.FIRM: 0.7,
    ConvictionLevel.ABSOLUTE: 0.9,
}

# Reverse map: float -> level name (for display in re-reasoning prompts)
CONVICTION_REVERSE_MAP: dict[float, str] = {v: k for k, v in CONVICTION_MAP.items()}


def conviction_to_float(level: str | None) -> float | None:
    """Convert a conviction level string to its float value."""
    if level is None:
        return None
    return CONVICTION_MAP.get(level)


def float_to_conviction(value: float | None) -> str | None:
    """Convert a float to the nearest conviction level string."""
    if value is None:
        return None
    # Find nearest level
    closest = min(CONVICTION_MAP.items(), key=lambda x: abs(x[1] - value))
    return closest[0].value


def score_to_conviction_float(score: int | float | None) -> float | None:
    """Convert a 0-100 conviction score to conviction float.

    Buckets:
        0-15  → very_uncertain (0.1)
        16-35 → leaning (0.3)
        36-60 → moderate (0.5)
        61-85 → firm (0.7)
        86-100 → absolute (0.9)
    """
    if score is None:
        return None
    # Some models (e.g. DeepSeek) return conviction as 0-1 float instead of 0-100 int.
    # Detect and rescale: any value in (0, 1] exclusive is almost certainly 0-1 scale.
    if isinstance(score, float) and 0 < score <= 1.0:
        score = int(score * 100)
    else:
        score = int(score)
    if score <= 15:
        return 0.1  # very_uncertain
    elif score <= 35:
        return 0.3  # leaning
    elif score <= 60:
        return 0.5  # moderate
    elif score <= 85:
        return 0.7  # firm
    else:
        return 0.9  # absolute


# =============================================================================
# Event Types
# =============================================================================


class SimulationEventType(str, Enum):
    """Type of simulation event."""

    SEED_EXPOSURE = "seed_exposure"  # Initial exposure from channel
    NETWORK_EXPOSURE = "network_exposure"  # Heard from another agent
    AGENT_REASONED = "agent_reasoned"  # Agent processed and formed opinion
    AGENT_SHARED = "agent_shared"  # Agent shared with network
    STATE_CHANGED = "state_changed"  # Agent's position/intent changed


# =============================================================================
# Exposure Records
# =============================================================================


class ExposureRecord(BaseModel):
    """Record of a single exposure event for an agent."""

    timestep: int = Field(description="When this exposure occurred")
    channel: str = Field(description="Which channel exposed them (or 'network')")
    source_agent_id: str | None = Field(
        default=None, description="If from network, who told them"
    )
    content: str = Field(description="What they heard")
    credibility: float = Field(
        ge=0, le=1, description="Perceived credibility of this exposure"
    )
    info_epoch: int | None = Field(
        default=None,
        description="Optional provenance epoch for newly introduced timeline information",
    )
    force_rereason: bool = Field(
        default=False,
        description="Whether this exposure should force re-reasoning for committed agents",
    )


# =============================================================================
# Memory Entry
# =============================================================================


class MemoryEntry(BaseModel):
    """A single entry in an agent's reasoning memory trace.

    Stored after each reasoning pass. All entries are retained (no cap).
    Fed back into the prompt so agents remember their own reasoning history.
    """

    timestep: int = Field(description="When this reasoning occurred")
    sentiment: float | None = Field(default=None, description="Sentiment at this time")
    conviction: float | None = Field(
        default=None, description="Conviction float value at this time"
    )
    summary: str = Field(description="1-sentence summary of reasoning at this time")
    raw_reasoning: str | None = Field(
        default=None, description="Full monologue text, stored but selectively rendered"
    )
    action_intent: str | None = Field(
        default=None, description="What the agent said they intended to do"
    )


# =============================================================================
# Agent State
# =============================================================================


class AgentState(BaseModel):
    """Complete state of an agent during simulation."""

    agent_id: str = Field(description="Unique agent identifier")
    aware: bool = Field(default=False, description="Has heard about event")
    exposure_count: int = Field(default=0, description="How many times exposed")
    exposures: list[ExposureRecord] = Field(
        default_factory=list, description="History of exposures"
    )
    last_reasoning_timestep: int = Field(
        default=-1, description="When they last reasoned"
    )
    position: str | None = Field(
        default=None, description="Current position (from Pass 2 classification)"
    )
    sentiment: float | None = Field(
        default=None, description="Current sentiment (-1 to 1)"
    )
    conviction: float | None = Field(
        default=None, description="Conviction as float (from categorical level)"
    )
    public_statement: str | None = Field(
        default=None, description="1-2 sentence argument for peers"
    )
    action_intent: str | None = Field(
        default=None, description="What they intend to do"
    )
    will_share: bool = Field(default=False, description="Will they propagate")
    public_position: str | None = Field(
        default=None, description="Publicly expressed position"
    )
    public_sentiment: float | None = Field(
        default=None, description="Publicly expressed sentiment (-1 to 1)"
    )
    public_conviction: float | None = Field(
        default=None, description="Publicly expressed conviction"
    )
    private_position: str | None = Field(
        default=None, description="Private behavioral position"
    )
    private_sentiment: float | None = Field(
        default=None, description="Private sentiment (-1 to 1)"
    )
    private_conviction: float | None = Field(
        default=None, description="Private conviction"
    )
    private_outcomes: dict[str, Any] = Field(
        default_factory=dict, description="Private outcome values used for evaluation"
    )
    committed: bool = Field(
        default=False,
        description="Conviction >= firm; won't re-reason from repeated network exposure",
    )
    outcomes: dict[str, Any] = Field(
        default_factory=dict, description="All extracted outcomes (from Pass 2)"
    )
    raw_reasoning: str | None = Field(default=None, description="Full reasoning text")
    latest_info_epoch: int = Field(
        default=-1,
        description="Most recent provenance epoch seen via exposures",
    )
    last_reasoned_info_epoch: int = Field(
        default=-1,
        description="Most recent provenance epoch already reasoned on",
    )
    updated_at: int = Field(default=0, description="Last state change timestep")


# =============================================================================
# Simulation Events (Timeline)
# =============================================================================


class SimulationEvent(BaseModel):
    """A single event in the simulation timeline."""

    timestep: int = Field(description="When this event occurred")
    event_type: SimulationEventType = Field(description="Type of event")
    agent_id: str = Field(description="Which agent was involved")
    details: dict[str, Any] = Field(
        default_factory=dict, description="Event-specific data"
    )
    timestamp: datetime = Field(
        default_factory=datetime.now, description="Wall clock time"
    )


# =============================================================================
# Peer Opinions (for reasoning context)
# =============================================================================


class PeerOpinion(BaseModel):
    """Opinion of a connected peer (for social influence).

    In the redesigned simulation, peers influence via public_statement + sentiment,
    NOT position labels. Position is output-only (Pass 2).
    """

    agent_id: str = Field(description="The peer's ID")
    peer_name: str | None = Field(default=None, description="The peer's first name")
    relationship: str = Field(description="Edge type (colleague, mentor, etc.)")
    position: str | None = Field(
        default=None, description="Their current position (for backwards compat only)"
    )
    sentiment: float | None = Field(default=None, description="Their sentiment")
    public_statement: str | None = Field(
        default=None, description="Their argument/statement"
    )
    credibility: float = Field(
        default=0.85, description="Dynamic credibility of this peer"
    )


# =============================================================================
# Reasoning Context
# =============================================================================


class ReasoningContext(BaseModel):
    """Context provided to agent for reasoning."""

    agent_id: str = Field(description="Agent being reasoned")
    persona: str = Field(description="Generated persona text")
    event_content: str = Field(description="What the event is")
    exposure_history: list[ExposureRecord] = Field(description="How they learned")
    peer_opinions: list[PeerOpinion] = Field(
        default_factory=list, description="What neighbors think (if known)"
    )
    current_state: AgentState | None = Field(
        default=None, description="Previous state if re-reasoning"
    )
    memory_trace: list[MemoryEntry] = Field(
        default_factory=list, description="Agent's previous reasoning summaries"
    )
    timestep: int = Field(default=0, description="Current simulation timestep")
    timestep_unit: str = Field(default="day", description="Unit for timestep display")
    agent_name: str | None = Field(
        default=None, description="Agent's first name for prompt personalization"
    )
    prior_action_intent: str | None = Field(
        default=None,
        description="Action intent from the agent's most recent reasoning (for accountability)",
    )
    macro_summary: str | None = Field(
        default=None, description="Deterministic summary of population-level trends"
    )
    local_mood_summary: str | None = Field(
        default=None, description="Deterministic summary of neighborhood sentiment"
    )
    background_context: str | None = Field(
        default=None, description="Scenario-level background context"
    )
    agent_names: dict[str, str] = Field(
        default_factory=dict,
        description="Mapping of agent_id → first name for resolving peer references",
    )
    # Phase C additions
    timeline_recap: list[str] | None = Field(
        default=None,
        description="Bullet list of what's happened so far in the scenario",
    )
    current_development: str | None = Field(
        default=None,
        description="This timestep's new development (if any)",
    )
    observable_peer_actions: int | None = Field(
        default=None,
        description="Count of neighbors who visibly acted (shared/posted)",
    )
    conformity: float | None = Field(
        default=None,
        description="Agent's conformity attribute (0-1)",
    )
    # Phase D additions
    available_contacts: list[dict[str, Any]] = Field(
        default_factory=list,
        description="People the agent can talk to (name, relationship, observable state)",
    )
    social_feed: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Recent public statements from the broader population (beyond direct network)",
    )
    identity_threat_summary: str | None = Field(
        default=None,
        description="Summary of which identity dimensions feel threatened by this scenario",
    )


# =============================================================================
# Reasoning Response (Pass 1 — free-text role-play)
# =============================================================================


class ReasoningResponse(BaseModel):
    """Response from agent reasoning LLM call (Pass 1).

    This is the free-text role-play pass. No categorical enums here —
    the agent reasons naturally. Classification happens in Pass 2.
    """

    position: str | None = Field(
        default=None, description="Classified position (filled by Pass 2)"
    )
    public_position: str | None = Field(
        default=None,
        description="Public-facing position when THINK/SAY diverges (high fidelity)",
    )
    sentiment: float | None = Field(
        default=None, description="Sentiment value (-1 to 1)"
    )
    conviction: float | None = Field(
        default=None, description="Conviction as float (mapped from categorical)"
    )
    public_statement: str | None = Field(
        default=None, description="1-2 sentence argument for peers"
    )
    reasoning_summary: str | None = Field(
        default=None, description="1-sentence summary for memory trace"
    )
    action_intent: str | None = Field(default=None, description="Intended action")
    will_share: bool = Field(default=False, description="Will they share")
    reasoning: str = Field(default="", description="Full internal monologue")
    outcomes: dict[str, Any] = Field(
        default_factory=dict, description="All structured outcomes (from Pass 2)"
    )
    actions: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Actions the agent intends to take (talk_to, etc.)",
    )

    # Token usage tracking (populated by two-pass reasoning)
    pass1_input_tokens: int = Field(default=0, description="Pass 1 input tokens")
    pass1_output_tokens: int = Field(default=0, description="Pass 1 output tokens")
    pass2_input_tokens: int = Field(default=0, description="Pass 2 input tokens")
    pass2_output_tokens: int = Field(default=0, description="Pass 2 output tokens")


# =============================================================================
# Simulation Configuration
# =============================================================================


class SimulationRunConfig(BaseModel):
    """Configuration for a simulation run."""

    scenario_path: str = Field(description="Path to scenario YAML")
    output_dir: str = Field(description="Directory for results output")
    strong: str = Field(
        default="",
        description="Strong model for Pass 1 role-play reasoning (provider/model format, empty = config default)",
    )
    fast: str = Field(
        default="",
        description="Fast model for Pass 2 classification (provider/model format, empty = config default)",
    )
    reasoning_effort: str = Field(default="low", description="Reasoning effort level")
    multi_touch_threshold: int = Field(
        default=3, description="Re-reason after N new exposures"
    )
    max_retries: int = Field(default=3, description="Max LLM retry attempts")
    random_seed: int | None = Field(
        default=None, description="Random seed for reproducibility"
    )
    chunk_size: int = Field(
        default=50, description="Agents per reasoning chunk for checkpointing"
    )
    max_concurrent: int | None = Field(
        default=None,
        description="Max concurrent async reasoning calls (None = auto from RPM)",
    )
    merged_pass: bool = Field(
        default=False,
        description="Use single merged pass instead of two-pass reasoning (experimental)",
    )
    fidelity: Literal["low", "medium", "high"] = Field(
        default="medium",
        description="Fidelity level controlling conversation depth and prompt richness",
    )

    # Backward compat aliases
    @property
    def model(self) -> str:
        return self.strong

    @property
    def pivotal_model(self) -> str:
        return self.strong

    @property
    def routine_model(self) -> str:
        return self.fast


# =============================================================================
# Timestep Summary
# =============================================================================


class TimestepSummary(BaseModel):
    """Summary statistics for a single timestep."""

    timestep: int = Field(description="Timestep number")
    new_exposures: int = Field(default=0, description="New exposures this step")
    agents_reasoned: int = Field(default=0, description="Agents who reasoned this step")
    shares_occurred: int = Field(default=0, description="Share events this step")
    state_changes: int = Field(default=0, description="Agents whose state changed")
    exposure_rate: float = Field(
        default=0.0, description="Fraction of population aware"
    )
    position_distribution: dict[str, int] = Field(
        default_factory=dict, description="Count per position"
    )
    average_sentiment: float | None = Field(
        default=None, description="Mean sentiment of aware agents"
    )
    average_conviction: float | None = Field(
        default=None, description="Mean conviction of aware agents"
    )
    sentiment_variance: float | None = Field(
        default=None, description="Variance of sentiment (for convergence detection)"
    )
