| Study | Config | Files | Validate(pop/scn) | Ground truth doc | Leakage triage | Status |
|---|---|---|---|---|---|---|
| apple-att-privacy | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| bud-light-boycott | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| london-ulez-expansion-2023 | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md,README.md; registry=True) | clean | READY |
| ma-mobile-sports-betting-launch-2023 | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md,README.md; registry=True) | flagged | BLOCKED |
| netflix-ad-tier-launch | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| netflix-password-sharing | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md,README.md; registry=False) | clean | READY |
| ny-mobile-sports-betting-launch-2022 | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md,README.md; registry=True) | flagged | BLOCKED |
| nyc-congestion-pricing | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| plant-based-meat | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| reddit-api-protest | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| snapchat-plus-launch | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| spotify-price-hike | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| threads-launch | 00-baseline | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md; registry=-) | clean | READY |
| x-premium-adoption | 01-revised-options | ok | PASS/PASS | yes (ground-truth.md,GROUND-TRUTH.md,README.md; registry=False) | clean | READY |
