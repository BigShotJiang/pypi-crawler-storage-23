# PyMoku Applets

This library supplies GUI support for PyMoku with a primary interface to find
and connect with your Moku device, and support for plugin based applets for
various functions.

    pip install pymoku[gui]
    pymoku
