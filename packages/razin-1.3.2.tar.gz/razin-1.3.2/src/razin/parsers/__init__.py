"""Parser package for Razin."""

from .skill_markdown import parse_skill_markdown_file

__all__ = ["parse_skill_markdown_file"]
