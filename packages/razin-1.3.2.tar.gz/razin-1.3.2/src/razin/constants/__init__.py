"""Centralized constants for Razin.

Import constants from their specific submodules, e.g.
``from razin.constants.cache import CACHE_FILENAME``.
"""
