"""Constants for deterministic identifier generation."""

from __future__ import annotations

FINDING_ID_HEX_LENGTH: int = 16
