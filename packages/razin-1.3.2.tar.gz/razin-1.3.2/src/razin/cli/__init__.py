"""CLI package for Razin."""
