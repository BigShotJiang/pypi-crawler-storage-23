"""Scanner pipeline subpackage.

Contains extracted helpers from the orchestrator module,
split by responsibility.
"""
