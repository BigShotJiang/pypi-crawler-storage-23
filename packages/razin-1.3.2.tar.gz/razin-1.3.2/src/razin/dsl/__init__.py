"""DSL package for Option C declarative rule engine."""

from .runtime import DslEngine

__all__ = ["DslEngine"]
