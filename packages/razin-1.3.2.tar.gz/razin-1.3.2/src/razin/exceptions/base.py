"""Base exception type for Razin."""

from __future__ import annotations


class RazinError(Exception):
    """Base class for scanner errors."""
