---
name: manifest-priority-skill
description: Manifest priority fixture.
---
# Manifest Skill
