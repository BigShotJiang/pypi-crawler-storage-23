---
name: benign-skill
description: Benign skill fixture with safe docs.
---
# Benign Skill

This skill documents safe operations only.
