#!/usr/bin/env bash

echo "fixture script"
