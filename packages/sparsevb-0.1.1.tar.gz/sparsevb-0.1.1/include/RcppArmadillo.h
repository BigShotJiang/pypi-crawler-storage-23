
// RcppArmadillo.h: Rcpp/Armadillo glue
//
// Copyright (C)  2010 - 2021  Dirk Eddelbuettel, Romain Francois and Douglas Bates
//
// This file is part of RcppArmadillo.
//
// RcppArmadillo is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// (at your option) any later version.
//
// RcppArmadillo is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RcppArmadillo.  If not, see <http://www.gnu.org/licenses/>.

#ifndef RcppArmadillo__RcppArmadillo__h
#define RcppArmadillo__RcppArmadillo__h

#if defined(Rcpp_hpp) && !defined(COMPILING_RCPPARMADILLO)
    #error "The file 'Rcpp.h' should not be included. Please correct to include only 'RcppArmadillo.h'."
#endif

// Deal with Armadillo 14.6.3 (fallback) versus 15.0.* (or later, preference) selection
#include <RcppArmadillo/version/arma.h>

// Set up actual #include <armadillo> after first #include <RcppArmadilloConfig> and more config
#include <RcppArmadillo/interface/RcppArmadilloForward.h>

// Now automatically include Rcpp as well
#include <Rcpp.h>

// Remaining RcppArmadillo code
#include <RcppArmadillo/interface/RcppArmadilloWrap.h>
#include <RcppArmadillo/interface/RcppArmadilloAs.h>
#include <RcppArmadillo/interface/RcppArmadilloSugar.h>

#endif
