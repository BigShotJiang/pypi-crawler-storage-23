"""Utility helpers for imgsh."""
