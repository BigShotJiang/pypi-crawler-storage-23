"""GUI modules for imgsh."""
