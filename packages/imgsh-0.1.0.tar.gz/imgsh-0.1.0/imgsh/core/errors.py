class ImgshError(Exception):
    """Base error for imgsh."""
