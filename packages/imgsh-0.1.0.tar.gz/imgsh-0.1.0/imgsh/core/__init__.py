"""Core image processing modules."""
