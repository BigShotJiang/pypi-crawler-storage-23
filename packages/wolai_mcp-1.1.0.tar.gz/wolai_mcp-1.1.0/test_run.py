import requests
import json
import sys

# Constants from server.py logic
APP_ID = "woP8AnStv1Zy4adqtyCSyT"
APP_SECRET = "dfb64d3468a32452d0fb8e4cb3a8530b1a1bdb38efe75a32a3a168b4f25c7884"
BASE_URL = "https://openapi.wolai.com/v1"
ROOT_ID = "8nHKEkC7tuuiZz4htJoycF"

def get_token():
    url = f"{BASE_URL}/token"
    payload = {"appId": APP_ID, "appSecret": APP_SECRET}
    response = requests.post(url, json=payload)
    return response.json()["data"]["app_token"]

def test_workflow():
    print("--- 1. Testing Authentication ---")
    token = get_token()
    headers = {"Authorization": token, "Content-Type": "application/json"}
    print(f"Token acquired: {token[:10]}...")

    print(f"\n--- 2. Testing Root Page Info ({ROOT_ID}) ---")
    res = requests.get(f"{BASE_URL}/blocks/{ROOT_ID}", headers=headers)
    if res.status_code == 200:
        root_data = res.json().get("data", {})
        print(f"Root Title: {root_data.get('content', 'No Content')}")
    else:
        print(f"Error fetching root: {res.text}")
        return

    print("\n--- 3. Testing Child Listing ---")
    res = requests.get(f"{BASE_URL}/blocks/{ROOT_ID}/children", headers=headers)
    if res.status_code == 200:
        children = res.json().get("data", [])
        print(f"Found {len(children)} children:")
        for child in children[:5]:
            print(f"- [{child.get('type')}] {child.get('content', '(No Title)')} (ID: {child.get('id')})")
        
        if not children:
            print("No children found. Is the ID correct or does the app have permission to read this page?")
    else:
        print(f"Error listing children: {res.text}")

if __name__ == "__main__":
    try:
        test_workflow()
    except Exception as e:
        print(f"Test failed with error: {e}")
