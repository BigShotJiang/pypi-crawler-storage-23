"""
ContentFlow - AI Marketing Content Generator
"""

__version__ = "0.4.0"

from .generator import ContentGenerator
