#!/usr/bin/env python
import json
import sys
import traceback
from typing import Any, Callable
import os
import inspect
from .import_module import import_module
from .storage import get_automation_callable
from .errors import AutomationNotDefinedError


def get_mandatory_argcount(f: Callable[..., Any]) -> int:
    sig = inspect.signature(f)

    def parameter_is_mandatory(p: inspect.Parameter) -> bool:
        return p.default is inspect.Parameter.empty and p.kind not in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        )

    return sum(parameter_is_mandatory(p) for p in sig.parameters.values())


if __name__ == "__main__":

    if len(sys.argv) < 2:
        raise Exception("arg file path missing")
    arg_file_path = sys.argv[1]

    with open(arg_file_path, "r") as f:
        arg_data = json.load(f)

    automation_path = arg_data["automation_path"]
    seed = arg_data["automation_argument"]
    output_file = arg_data.get("output_file", None)

    try:
        import_module(automation_path)

        datallog_callable_function = get_automation_callable()
        if datallog_callable_function is None:
            raise AutomationNotDefinedError()
        if seed is None:
            if get_mandatory_argcount(datallog_callable_function) > 0:
                automation_result = datallog_callable_function(None)
            else:
                automation_result = datallog_callable_function()

        step_result = datallog_callable_function(seed)
        result = {"type": "result", "step_result": step_result}

    except Exception as e:
        import traceback

        formatted_tb = traceback.format_exc()
        print(formatted_tb, file=sys.stderr)

        result = {
            "type": "error",
            "message": str(e),
            "traceback": formatted_tb,
        }

    with open(output_file, "w") as f:
        json.dump(result, f)
        f.flush()

    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)
