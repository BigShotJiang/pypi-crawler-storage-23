"""Command-line interface for neuracore importer."""

from neuracore.importer.cli.app import app, main

__all__ = ["app", "main"]
