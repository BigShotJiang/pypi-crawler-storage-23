#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MoleditPy — A Python-based molecular editing software

Author: Hiromichi Yokoyama
License: GPL-3.0 license
Repo: https://github.com/HiroYokoyama/python_molecular_editor
DOI: 10.5281/zenodo.17268532
"""

import math
import re
import numpy as np

from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot

# RDKit
from rdkit import Chem
from rdkit.Chem import AllChem, rdGeometry
from rdkit.DistanceGeometry import DoTriangleSmoothing

try:
    from . import OBABEL_AVAILABLE
except Exception:
    from modules import OBABEL_AVAILABLE
# Only import pybel on demand — `moleditpy` itself doesn't expose `pybel`.
if OBABEL_AVAILABLE:
    try:
        from openbabel import pybel
    except Exception:
        # If import fails here, disable OBABEL locally; avoid raising
        pybel = None
        OBABEL_AVAILABLE = False
        print(
            "Warning: openbabel.pybel not available. Open Babel fallback and OBabel-based options will be disabled."
        )
else:
    pybel = None


class WorkerHaltError(Exception):
    """Custom exception raised when a calculation worker is requested to halt."""
    pass


def _adjust_collision_avoidance(rd_mol, check_halted_cb, safe_status_cb):
    """
    Optimized collision avoidance using spatial partitioning (grid-based).
    This avoids the O(F^2 * N^2) complexity of the previous implementation.
    """
    try:
        frags = Chem.GetMolFrags(rd_mol, asMols=False, sanitizeFrags=False)
        if len(frags) <= 1:
            return

        safe_status_cb(f"Resolving potential collisions among {len(frags)} fragments...")

        conf = rd_mol.GetConformer()
        pt = Chem.GetPeriodicTable()

        # 1. Precalculate fragment data
        frag_data = []
        for f_indices in frags:
            pos_list = []
            radii_list = []
            for idx in f_indices:
                p = conf.GetAtomPosition(idx)
                pos_list.append([p.x, p.y, p.z])
                try:
                    radii_list.append(pt.GetRvdw(rd_mol.GetAtomWithIdx(idx).GetAtomicNum()))
                except Exception:
                    radii_list.append(1.5)

            pos_np = np.array(pos_list)
            radii_np = np.array(radii_list)
            frag_data.append({
                "indices": f_indices,
                "positions": pos_np,
                "radii": radii_np,
                "max_radius": np.max(radii_np) if len(radii_np) > 0 else 1.5
            })

        # Parameters
        scale = 1.1  # Collision threshold scale
        max_iters = 50
        grid_size = 5.0

        for iteration in range(max_iters):
            if check_halted_cb():
                raise WorkerHaltError("Halted")

            moved = False
            grid = {}
            for i, fd in enumerate(frag_data):
                fd_min = np.min(fd["positions"], axis=0)
                fd_max = np.max(fd["positions"], axis=0)
                margin = fd["max_radius"] * scale
                fd["bbox_min"] = fd_min - margin
                fd["bbox_max"] = fd_max + margin
                g_min = (fd["bbox_min"] / grid_size).astype(int)
                g_max = (fd["bbox_max"] / grid_size).astype(int)
                for gx in range(g_min[0], g_max[0] + 1):
                    for gy in range(g_min[1], g_max[1] + 1):
                        for gz in range(g_min[2], g_max[2] + 1):
                            cell = (gx, gy, gz)
                            if cell not in grid:
                                grid[cell] = []
                            grid[cell].append(i)

            all_push_vectors = [np.zeros(3) for _ in range(len(frag_data))]
            processed_pairs = set()

            for cell_indices in grid.values():
                if len(cell_indices) < 2:
                    continue
                for idx_idx_i, i in enumerate(cell_indices):
                    for j in cell_indices[idx_idx_i + 1:]:
                        pair = tuple(sorted((i, j)))
                        if pair in processed_pairs:
                            continue
                        processed_pairs.add(pair)
                        if np.any(frag_data[i]["bbox_min"] > frag_data[j]["bbox_max"]) or \
                           np.any(frag_data[j]["bbox_min"] > frag_data[i]["bbox_max"]):
                            continue
                        fd_i = frag_data[i]
                        fd_j = frag_data[j]
                        push_i = np.zeros(3)
                        push_j = np.zeros(3)
                        collision_count = 0
                        for p_idx_i, p_i in enumerate(fd_i["positions"]):
                            r_i = fd_i["radii"][p_idx_i]
                            for p_idx_j, p_j in enumerate(fd_j["positions"]):
                                r_j = fd_j["radii"][p_idx_j]
                                diff = p_i - p_j
                                dist_sq = np.dot(diff, diff)
                                min_dist = (r_i + r_j) * scale
                                if dist_sq < 0.0001:
                                    diff = np.random.uniform(-0.1, 0.1, 3)
                                    dist_sq = np.dot(diff, diff)
                                if dist_sq < min_dist * min_dist:
                                    dist = np.sqrt(dist_sq)
                                    if dist < 0.0001:
                                        dist = 0.0001
                                    push_mag = (min_dist - dist) / 2.0
                                    vec = (diff / dist) * push_mag
                                    push_i += vec
                                    push_j -= vec
                                    collision_count += 1
                        if collision_count > 0:
                            all_push_vectors[i] += push_i / collision_count
                            all_push_vectors[j] += push_j / collision_count
                            moved = True

            if not moved:
                break

            for i, push in enumerate(all_push_vectors):
                if np.any(push != 0):
                    frag_data[i]["positions"] += push
                    for local_idx, global_idx in enumerate(frag_data[i]["indices"]):
                        conf.SetAtomPosition(global_idx, frag_data[i]["positions"][local_idx].tolist())

        safe_status_cb("Collision avoidance completed.")
    except WorkerHaltError:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        safe_status_cb(f"Collision avoidance warning: {e}")


def _iterative_optimize(mol, method, check_halted_cb, safe_status_cb, max_iters=4000, chunk_size=100):
    """Perform force field optimization in small chunks to avoid UI freezing and allow halts."""
    try:
        if method in ("MMFF", "MMFF94", "MMFF94S", "MMFF94s"):
            mmff_variant = "MMFF94" if method == "MMFF94" else "MMFF94s"
            props = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant=mmff_variant)
            if props is None:
                return False
            ff = AllChem.MMFFGetMoleculeForceField(mol, props, confId=0)
        elif method == "UFF":
            ff = AllChem.UFFGetMoleculeForceField(mol, confId=0)
        else:
            return False

        if ff is None:
            return False

        ff.Initialize()
        iters_done = 0
        while iters_done < max_iters:
            if check_halted_cb():
                raise WorkerHaltError("Halted")
            res = ff.Minimize(maxIts=chunk_size)
            iters_done += chunk_size
            if res == 0:
                break
            import time
            time.sleep(0.001)

        return True
    except WorkerHaltError:
        raise
    except Exception as e:
        safe_status_cb(f"Iterative optimization ({method}) error: {e}")
        return False


class CalculationWorker(QObject):
    status_update = pyqtSignal(str)
    finished = pyqtSignal(object)
    error = pyqtSignal(object)
    start_work = pyqtSignal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        try:
            self.start_work.connect(self.run_calculation)
        except Exception:  # pragma: no cover
            import traceback
            traceback.print_exc()

    @pyqtSlot(str, object)
    def run_calculation(self, mol_block, options=None):
        worker_id = None

        # The worker may be asked to halt via a shared set `halt_ids` and
        # identifies its own run by options['worker_id'] (int).
        def _check_halted():
            try:
                halt_ids = getattr(self, "halt_ids", None)
                if worker_id is None:
                    if getattr(self, "halt_all", False):
                        return True
                    if halt_ids is None:
                        return False
                    # Support both None-in-set and string sentinel for compatibility
                    return (None in halt_ids) or ("ALL" in halt_ids)

                if halt_ids is None:
                    return False
                return worker_id in halt_ids
            except Exception:
                return False

        # Safe-emission helpers: do nothing if this worker has been halted.
        def _safe_status(msg):
            try:
                if _check_halted():
                    raise WorkerHaltError("Halted")
                self.status_update.emit(msg)
            except WorkerHaltError:
                raise
            except Exception:
                # Swallow any signal-emission errors to avoid crashing the worker
                pass

        def _safe_finished(payload):  # pragma: no cover
            try:
                if _check_halted():
                    raise WorkerHaltError("Halted")
                try:
                    self.finished.emit(payload)
                except WorkerHaltError:
                    raise
                except TypeError:
                    try:
                        if isinstance(payload, (list, tuple)) and len(payload) >= 2:
                            self.finished.emit(payload[1])
                        else:
                            self.finished.emit(payload)
                    except WorkerHaltError:
                        raise
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
            except WorkerHaltError:
                raise
            except Exception:  # pragma: no cover
                import traceback
                traceback.print_exc()

        def _safe_error(msg):  # pragma: no cover
            try:
                if msg != "Halted" and _check_halted():
                    raise WorkerHaltError("Halted")
                try:
                    self.error.emit((worker_id, msg))
                except WorkerHaltError:
                    raise
                except Exception:
                    try:
                        self.error.emit(msg)
                    except WorkerHaltError:
                        raise
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
            except WorkerHaltError:
                raise
            except Exception:  # pragma: no cover
                import traceback
                traceback.print_exc()

        try:
            worker_id = None
            try:
                worker_id = options.get("worker_id") if options else None
            except Exception:
                worker_id = None

            _warned_no_worker_id = False
            if worker_id is None:
                try:
                    # best-effort, swallow any errors (signals may not be connected)
                    self.status_update.emit(
                        "Warning: worker started without 'worker_id'; will listen for global halt signals."
                    )
                except Exception:  # pragma: no cover
                    import traceback
                    traceback.print_exc()
                _warned_no_worker_id = True

            # options: dict-like with keys: 'conversion_mode' -> 'fallback'|'rdkit'|'obabel'|'direct'
            if options is None:
                options = {}
            conversion_mode = options.get("conversion_mode", "fallback")
            params = None
            if not mol_block:
                raise ValueError("No atoms to convert.")

            _safe_status("Creating 3D structure...")

            mol = Chem.MolFromMolBlock(mol_block, removeHs=False)
            if mol is None:
                raise ValueError("Failed to create molecule from MOL block.")

            # Check early whether this run has been requested to halt
            if _check_halted():
                raise WorkerHaltError("Halted")

            explicit_stereo = {}
            mol_lines = mol_block.split("\n")
            for line in mol_lines:
                if line.startswith("M  CFG"):
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            bond_idx = int(parts[3]) - 1  # MOL format is 1-indexed
                            cfg_value = int(parts[4])
                            # cfg_value: 1=Z, 2=E in MOL format
                            if cfg_value == 1:
                                explicit_stereo[bond_idx] = Chem.BondStereo.STEREOZ
                            elif cfg_value == 2:
                                explicit_stereo[bond_idx] = Chem.BondStereo.STEREOE
                        except (ValueError, IndexError):
                            continue

            # Force explicit stereo labels regardless of coordinates
            for bond_idx, stereo_type in explicit_stereo.items():
                if bond_idx < mol.GetNumBonds():
                    bond = mol.GetBondWithIdx(bond_idx)
                    if bond.GetBondType() == Chem.BondType.DOUBLE:
                        # Find suitable stereo atoms
                        begin_atom = bond.GetBeginAtom()
                        end_atom = bond.GetEndAtom()

                        # Pick heavy atom neighbors preferentially
                        begin_neighbors = [
                            nbr
                            for nbr in begin_atom.GetNeighbors()
                            if nbr.GetIdx() != end_atom.GetIdx()
                        ]
                        end_neighbors = [
                            nbr
                            for nbr in end_atom.GetNeighbors()
                            if nbr.GetIdx() != begin_atom.GetIdx()
                        ]

                        if begin_neighbors and end_neighbors:
                            # Prefer heavy atoms
                            begin_heavy = [
                                n for n in begin_neighbors if n.GetAtomicNum() > 1
                            ]
                            end_heavy = [
                                n for n in end_neighbors if n.GetAtomicNum() > 1
                            ]

                            stereo_atom1 = (
                                begin_heavy[0] if begin_heavy else begin_neighbors[0]
                            ).GetIdx()
                            stereo_atom2 = (
                                end_heavy[0] if end_heavy else end_neighbors[0]
                            ).GetIdx()

                            bond.SetStereoAtoms(stereo_atom1, stereo_atom2)
                            bond.SetStereo(stereo_type)

            # Do NOT call AssignStereochemistry here as it overrides our explicit labels

            mol = Chem.AddHs(mol)

            # Check after adding Hs (may be a long operation)
            if _check_halted():
                raise WorkerHaltError("Halted")

            # Support for optimize_only mode
            if conversion_mode == "optimize_only":
                _safe_status("Optimizing existing 3D structure...")
                opt_method = str(options.get("optimization_method", "MMFF94s")).upper()
                if "MMFF" in opt_method:
                    method_key = "MMFF94" if "MMFF94" in opt_method and "MMFF94S" not in opt_method else "MMFF94s"
                    if not _iterative_optimize(mol, method_key, _check_halted, _safe_status):
                        _safe_status(f"{method_key} failed, falling back to UFF...")
                        _iterative_optimize(mol, "UFF", _check_halted, _safe_status)
                elif "UFF" in opt_method:
                    _iterative_optimize(mol, "UFF", _check_halted, _safe_status)
                else:
                    if not _iterative_optimize(mol, "MMFF94s", _check_halted, _safe_status):
                        _iterative_optimize(mol, "UFF", _check_halted, _safe_status)
                if _check_halted():
                    raise WorkerHaltError("Halted")
                try:
                    _safe_finished((worker_id, mol))
                except Exception:
                    _safe_finished(mol)
                _safe_status("Optimization completed.")
                return

            # CRITICAL: Re-apply explicit stereo after AddHs which may renumber atoms
            for bond_idx, stereo_type in explicit_stereo.items():
                if bond_idx < mol.GetNumBonds():
                    bond = mol.GetBondWithIdx(bond_idx)
                    if bond.GetBondType() == Chem.BondType.DOUBLE:
                        # Re-find suitable stereo atoms after hydrogen addition
                        begin_atom = bond.GetBeginAtom()
                        end_atom = bond.GetEndAtom()

                        # Pick heavy atom neighbors preferentially
                        begin_neighbors = [
                            nbr
                            for nbr in begin_atom.GetNeighbors()
                            if nbr.GetIdx() != end_atom.GetIdx()
                        ]
                        end_neighbors = [
                            nbr
                            for nbr in end_atom.GetNeighbors()
                            if nbr.GetIdx() != begin_atom.GetIdx()
                        ]

                        if begin_neighbors and end_neighbors:
                            # Prefer heavy atoms
                            begin_heavy = [
                                n for n in begin_neighbors if n.GetAtomicNum() > 1
                            ]
                            end_heavy = [
                                n for n in end_neighbors if n.GetAtomicNum() > 1
                            ]

                            stereo_atom1 = (
                                begin_heavy[0] if begin_heavy else begin_neighbors[0]
                            ).GetIdx()
                            stereo_atom2 = (
                                end_heavy[0] if end_heavy else end_neighbors[0]
                            ).GetIdx()

                            bond.SetStereoAtoms(stereo_atom1, stereo_atom2)
                            bond.SetStereo(stereo_type)

            # Direct mode: construct a 3D conformer without embedding by using
            # the 2D coordinates from the MOL block (z=0) and placing added
            # hydrogens close to their parent heavy atoms with a small z offset.
            # This avoids 3D embedding entirely and is useful for quick viewing
            # when stereochemistry/geometry refinement is not desired.
            if conversion_mode == "direct":
                _safe_status(
                    "Direct conversion: using 2D coordinates + adding missing H (no embedding)."
                )
                try:
                    # 1) Parse MOL block *with* existing hydrogens (removeHs=False)
                    #    to get coordinates for *all existing* atoms.
                    parsed_coords = []  # all-atom coordinates (x, y, z)
                    stereo_dirs = []  # list of (begin_idx, end_idx, stereo_flag)

                    base2d_all = None
                    try:
                        # H原子を含めてパース
                        base2d_all = Chem.MolFromMolBlock(
                            mol_block, removeHs=False, sanitize=True
                        )
                    except Exception:
                        try:
                            base2d_all = Chem.MolFromMolBlock(
                                mol_block, removeHs=False, sanitize=False
                            )
                        except Exception:
                            base2d_all = None

                    if base2d_all is not None and base2d_all.GetNumConformers() > 0:
                        oconf = base2d_all.GetConformer()
                        for i in range(base2d_all.GetNumAtoms()):
                            p = oconf.GetAtomPosition(i)
                            parsed_coords.append((float(p.x), float(p.y), 0.0))

                    # 2) Parse wedge/dash bond information (using all atoms)
                    try:
                        lines = mol_block.splitlines()
                        counts_idx = None

                        for i, ln in enumerate(lines[:40]):
                            if re.match(r"^\s*\d+\s+\d+", ln):
                                counts_idx = i
                                break

                        if counts_idx is not None:
                            parts = lines[counts_idx].split()
                            try:
                                natoms = int(parts[0])
                                nbonds = int(parts[1])
                            except Exception:
                                natoms = nbonds = 0

                            # 全原子マップ (MOL 1-based index -> 0-based index)
                            atom_map = {i + 1: i for i in range(natoms)}

                            bond_start = counts_idx + 1 + natoms
                            for j in range(
                                min(nbonds, max(0, len(lines) - bond_start))
                            ):
                                bond_line = lines[bond_start + j]
                                try:
                                    m = re.match(
                                        r"^\s*(\d+)\s+(\d+)\s+(\d+)(?:\s+(-?\d+))?",
                                        bond_line,
                                    )
                                    if m:
                                        try:
                                            atom1_mol = int(
                                                m.group(1)
                                            )  # 1-based MOL index
                                            atom2_mol = int(
                                                m.group(2)
                                            )  # 1-based MOL index
                                        except Exception:
                                            continue
                                        try:
                                            stereo_raw = (
                                                int(m.group(4))
                                                if m.group(4) is not None
                                                else 0
                                            )
                                        except Exception:
                                            stereo_raw = 0
                                    else:
                                        fields = bond_line.split()
                                        if len(fields) >= 4:
                                            try:
                                                atom1_mol = int(
                                                    fields[0]
                                                )  # 1-based MOL index
                                                atom2_mol = int(
                                                    fields[1]
                                                )  # 1-based MOL index
                                            except Exception:
                                                continue
                                            try:
                                                stereo_raw = (
                                                    int(fields[3])
                                                    if len(fields) > 3
                                                    else 0
                                                )
                                            except Exception:
                                                stereo_raw = 0
                                        else:
                                            continue

                                    # V2000の立体表記を正規化
                                    if stereo_raw == 1:
                                        stereo_flag = 1  # Wedge
                                    elif stereo_raw == 2:
                                        stereo_flag = 6  # Dash (V2000では 6 がDash)
                                    else:
                                        stereo_flag = stereo_raw

                                    # 全原子マップでチェック
                                    if atom1_mol in atom_map and atom2_mol in atom_map:
                                        idx1 = atom_map[atom1_mol]
                                        idx2 = atom_map[atom2_mol]
                                        if stereo_flag in (
                                            1,
                                            6,
                                        ):  # Wedge (1) or Dash (6)
                                            stereo_dirs.append(
                                                (idx1, idx2, stereo_flag)
                                            )
                                except Exception:
                                    continue
                    except Exception:
                        stereo_dirs = []

                    # Fallback for parsed_coords (if RDKit parse failed)
                    if not parsed_coords:
                        try:
                            lines = mol_block.splitlines()
                            counts_idx = None
                            for i, ln in enumerate(lines[:40]):
                                if re.match(r"^\s*\d+\s+\d+", ln):
                                    counts_idx = i
                                    break
                            if counts_idx is not None:
                                parts = lines[counts_idx].split()
                                try:
                                    natoms = int(parts[0])
                                except Exception:
                                    natoms = 0
                                atom_start = counts_idx + 1
                                for j in range(
                                    min(natoms, max(0, len(lines) - atom_start))
                                ):
                                    atom_line = lines[atom_start + j]
                                    try:
                                        x = float(atom_line[0:10].strip())
                                        y = float(atom_line[10:20].strip())
                                        z = float(atom_line[20:30].strip())
                                    except Exception:
                                        fields = atom_line.split()
                                        if len(fields) >= 4:
                                            try:
                                                x = float(fields[0])
                                                y = float(fields[1])
                                                z = float(fields[2])
                                            except Exception:
                                                continue
                                        else:
                                            continue
                                    # H原子もスキップしない
                                    parsed_coords.append((x, y, z))
                        except Exception:
                            parsed_coords = []

                    if not parsed_coords:
                        raise ValueError(
                            "Failed to parse coordinates from MOL block for direct conversion."
                        )

                    # 3) `mol` は既に AddHs された状態
                    #    元の原子数 (H含む) を parsed_coords の長さから取得
                    num_existing_atoms = len(parsed_coords)

                    # 4) コンフォーマを作成
                    conf = Chem.Conformer(mol.GetNumAtoms())

                    for i in range(mol.GetNumAtoms()):
                        if i < num_existing_atoms:
                            # 既存原子 (H含む): 2D座標 (z=0) を設定
                            x, y, z_ignored = parsed_coords[i]
                            try:
                                conf.SetAtomPosition(
                                    i, rdGeometry.Point3D(float(x), float(y), 0.0)
                                )
                            except Exception:  # pragma: no cover
                                import traceback
                                traceback.print_exc()
                        else:
                            # 新規追加されたH原子: 親原子の近くに配置
                            atom = mol.GetAtomWithIdx(i)
                            if atom.GetAtomicNum() == 1:
                                neighs = [
                                    n
                                    for n in atom.GetNeighbors()
                                    if n.GetIdx() < num_existing_atoms
                                ]
                                heavy_pos_found = False
                                for nb in neighs:  # 親原子 (重原子または既存H)
                                    try:
                                        nb_idx = nb.GetIdx()
                                        # if nb_idx < num_existing_atoms: # チェックは不要 (neighs で既にフィルタ済み)
                                        nbpos = conf.GetAtomPosition(nb_idx)
                                        # Geometry-based placement:
                                        # Compute an "empty" direction around the parent atom by
                                        # summing existing bond unit vectors and taking the
                                        # opposite. If degenerate, pick a perpendicular or
                                        # fallback vector. Rotate slightly if multiple Hs already
                                        # attached to avoid overlap.
                                        parent_idx = nb_idx
                                        try:
                                            parent_pos = conf.GetAtomPosition(
                                                parent_idx
                                            )
                                            parent_atom = mol.GetAtomWithIdx(parent_idx)
                                            # collect unit vectors to already-placed neighbors (idx < i)
                                            vecs = []
                                            for nbr in parent_atom.GetNeighbors():
                                                nidx = nbr.GetIdx()
                                                if nidx == i:
                                                    continue
                                                # only consider neighbors whose positions are already set
                                                if nidx < i:
                                                    try:
                                                        p = conf.GetAtomPosition(nidx)
                                                        vx = float(p.x) - float(
                                                            parent_pos.x
                                                        )
                                                        vy = float(p.y) - float(
                                                            parent_pos.y
                                                        )
                                                        nrm = math.hypot(vx, vy)
                                                        if nrm > 1e-6:
                                                            vecs.append(
                                                                (vx / nrm, vy / nrm)
                                                            )
                                                    except Exception:
                                                        continue

                                            if vecs:
                                                sx = sum(v[0] for v in vecs)
                                                sy = sum(v[1] for v in vecs)
                                                fx = -sx
                                                fy = -sy
                                                fn = math.hypot(fx, fy)
                                                if fn < 1e-6:
                                                    # degenerate: pick a perpendicular to first bond
                                                    fx = -vecs[0][1]
                                                    fy = vecs[0][0]
                                                    fn = math.hypot(fx, fy)
                                                fx /= fn
                                                fy /= fn

                                                # Avoid placing multiple Hs at identical directions
                                                existing_h_count = sum(
                                                    1
                                                    for nbr in parent_atom.GetNeighbors()
                                                    if nbr.GetIdx() < i
                                                    and nbr.GetAtomicNum() == 1
                                                )
                                                angle = existing_h_count * (
                                                    math.pi / 6.0
                                                )  # 30deg steps
                                                cos_a = math.cos(angle)
                                                sin_a = math.sin(angle)
                                                rx = fx * cos_a - fy * sin_a
                                                ry = fx * sin_a + fy * cos_a

                                                bond_length = 1.0
                                                conf.SetAtomPosition(
                                                    i,
                                                    rdGeometry.Point3D(
                                                        float(parent_pos.x)
                                                        + rx * bond_length,
                                                        float(parent_pos.y)
                                                        + ry * bond_length,
                                                        0.3,
                                                    ),
                                                )
                                            else:
                                                # No existing placed neighbors: fallback to small offset
                                                conf.SetAtomPosition(
                                                    i,
                                                    rdGeometry.Point3D(
                                                        float(parent_pos.x) + 0.5,
                                                        float(parent_pos.y) + 0.5,
                                                        0.3,
                                                    ),
                                                )

                                            heavy_pos_found = True
                                            break
                                        except Exception:
                                            # fall back to trying the next neighbor if any
                                            continue
                                    except Exception:
                                        continue
                                if not heavy_pos_found:
                                    # フォールバック (原点近く)
                                    try:
                                        conf.SetAtomPosition(
                                            i, rdGeometry.Point3D(0.0, 0.0, 0.10)
                                        )
                                    except Exception:  # pragma: no cover
                                        import traceback
                                        traceback.print_exc()
                    # 5) Wedge/Dash の Zオフセットを適用
                    try:
                        stereo_z_offset = 1.5  # wedge -> +1.5, dash -> -1.5
                        for begin_idx, end_idx, stereo_flag in stereo_dirs:
                            try:
                                # インデックスは既存原子内のはず
                                if (
                                    begin_idx >= num_existing_atoms
                                    or end_idx >= num_existing_atoms
                                ):
                                    continue

                                if stereo_flag not in (1, 6):
                                    continue

                                sign = 1.0 if stereo_flag == 1 else -1.0

                                # end_idx (立体表記の終点側原子) にZオフセットを適用
                                pos = conf.GetAtomPosition(end_idx)
                                newz = float(pos.z) + (
                                    stereo_z_offset * sign
                                )  # 既存のZ=0にオフセットを加算
                                conf.SetAtomPosition(
                                    end_idx,
                                    rdGeometry.Point3D(
                                        float(pos.x), float(pos.y), float(newz)
                                    ),
                                )
                            except Exception:
                                continue
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
                    # コンフォーマを入れ替えて終了
                    try:
                        mol.RemoveAllConformers()
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
                    mol.AddConformer(conf, assignId=True)

                    # Optimization (respects do_optimize flag)
                    do_optimize = options.get("do_optimize", True) if options else True
                    if do_optimize:
                        _safe_status("Direct conversion: optimizing geometry...")
                        if _check_halted():
                            raise WorkerHaltError("Halted")
                        mmff_method = "MMFF94s"
                        if options and str(options.get("optimization_method", "")).upper() == "MMFF94_RDKIT":
                            mmff_method = "MMFF94"
                        if not _iterative_optimize(mol, mmff_method, _check_halted, _safe_status):
                            if _check_halted():
                                raise WorkerHaltError("Halted")
                            _iterative_optimize(mol, "UFF", _check_halted, _safe_status)

                    if _check_halted():
                        raise WorkerHaltError("Halted")
                    if do_optimize:
                        _adjust_collision_avoidance(mol, _check_halted, _safe_status)

                    try:
                        _safe_finished((worker_id, mol))
                    except WorkerHaltError:
                        raise
                    except Exception:
                        _safe_finished(mol)
                    _safe_status("Direct conversion completed.")
                    return
                except WorkerHaltError:
                    raise
                except Exception as e:
                    _safe_status(f"Direct conversion failed: {e}")

            params = AllChem.ETKDGv2()
            params.randomSeed = 42
            # CRITICAL: Force ETKDG to respect the existing stereochemistry
            params.useExpTorsionAnglePrefs = True
            params.useBasicKnowledge = True
            params.enforceChirality = True  # This is critical for stereo preservation

            # Store original stereochemistry before embedding (prioritizing explicit labels)
            original_stereo_info = []
            for bond_idx, stereo_type in explicit_stereo.items():
                if bond_idx < mol.GetNumBonds():
                    bond = mol.GetBondWithIdx(bond_idx)
                    if bond.GetBondType() == Chem.BondType.DOUBLE:
                        stereo_atoms = bond.GetStereoAtoms()
                        original_stereo_info.append(
                            (bond.GetIdx(), stereo_type, stereo_atoms)
                        )

            # Also store any other stereo bonds not in explicit_stereo
            for bond in mol.GetBonds():
                if (
                    bond.GetBondType() == Chem.BondType.DOUBLE
                    and bond.GetStereo() != Chem.BondStereo.STEREONONE
                    and bond.GetIdx() not in explicit_stereo
                ):
                    stereo_atoms = bond.GetStereoAtoms()
                    original_stereo_info.append(
                        (bond.GetIdx(), bond.GetStereo(), stereo_atoms)
                    )

            if conversion_mode in ("fallback", "rdkit"):
                _safe_status("RDKit: Embedding 3D coordinates...")
            elif conversion_mode == "obabel":
                pass
            else:
                # direct mode (or any other explicit non-RDKit mode)
                pass
            if _check_halted():
                raise WorkerHaltError("Halted")

            # Try multiple times with different approaches if needed
            conf_id = -1

            # First attempt: Standard ETKDG with stereo enforcement
            try:
                # Only attempt RDKit embedding if mode allows
                if conversion_mode in ("fallback", "rdkit"):
                    conf_id = AllChem.EmbedMolecule(mol, params)
                else:
                    conf_id = -1
                # Final check before returning success
                if _check_halted():
                    raise WorkerHaltError("Halted")
            except WorkerHaltError:
                raise
            except Exception as e:
                # Standard embedding failed; report and continue to fallback attempts
                _safe_status(f"Standard embedding failed: {e}")

                # Second attempt: Use constraint embedding if available (only when RDKit is allowed)
                if conf_id == -1 and conversion_mode in ("fallback", "rdkit"):
                    try:
                        # Create distance constraints for double bonds to enforce E/Z geometry
                        bounds_matrix = AllChem.GetMoleculeBoundsMatrix(mol)

                        # Add constraints for E/Z bonds
                        for bond_idx, stereo, stereo_atoms in original_stereo_info:
                            bond = mol.GetBondWithIdx(bond_idx)
                            if len(stereo_atoms) == 2:
                                atom1_idx = bond.GetBeginAtomIdx()
                                atom2_idx = bond.GetEndAtomIdx()
                                neighbor1_idx = stereo_atoms[0]
                                neighbor2_idx = stereo_atoms[1]

                                # For Z (cis): neighbors should be closer
                                # For E (trans): neighbors should be farther
                                if stereo == Chem.BondStereo.STEREOZ:
                                    # Z configuration: set shorter distance constraint
                                    target_dist = 3.0  # Angstroms
                                    bounds_matrix[neighbor1_idx][neighbor2_idx] = min(
                                        bounds_matrix[neighbor1_idx][neighbor2_idx],
                                        target_dist,
                                    )
                                    bounds_matrix[neighbor2_idx][neighbor1_idx] = min(
                                        bounds_matrix[neighbor2_idx][neighbor1_idx],
                                        target_dist,
                                    )
                                elif stereo == Chem.BondStereo.STEREOE:
                                    # E configuration: set longer distance constraint
                                    target_dist = 5.0  # Angstroms
                                    bounds_matrix[neighbor1_idx][neighbor2_idx] = max(
                                        bounds_matrix[neighbor1_idx][neighbor2_idx],
                                        target_dist,
                                    )
                                    bounds_matrix[neighbor2_idx][neighbor1_idx] = max(
                                        bounds_matrix[neighbor2_idx][neighbor1_idx],
                                        target_dist,
                                    )

                        DoTriangleSmoothing(bounds_matrix)
                        conf_id = AllChem.EmbedMolecule(mol, bounds_matrix, params)
                        _safe_status("Constraint-based embedding succeeded")
                    except Exception:
                        # Constraint embedding failed: only raise error if mode is 'rdkit', otherwise allow fallback
                        _safe_status("RDKit: Constraint embedding failed")
                        if conversion_mode == "rdkit":
                            raise RuntimeError("RDKit: Constraint embedding failed")
                        conf_id = -1

            # Fallback: Try basic embedding
            if conf_id == -1:
                try:
                    if conversion_mode in ("fallback", "rdkit"):
                        basic_params = AllChem.ETKDGv2()
                        basic_params.randomSeed = 42
                        conf_id = AllChem.EmbedMolecule(mol, basic_params)
                    else:
                        conf_id = -1
                except Exception:  # pragma: no cover
                    import traceback
                    traceback.print_exc()
            """
            if conf_id == -1:
                        _safe_status("Initial embedding failed, retrying with ignoreSmoothingFailures=True...")
                # Try again with ignoreSmoothingFailures instead of random-seed retries
                params.ignoreSmoothingFailures = True
                # Use a deterministic seed to avoid random-coordinate behavior here
                params.randomSeed = 0
                conf_id = AllChem.EmbedMolecule(mol, params)

            if conf_id == -1:
                self.status_update.emit("Random-seed retry failed, attempting with random coordinates...")
                try:
                    conf_id = AllChem.EmbedMolecule(mol, useRandomCoords=True, ignoreSmoothingFailures=True)
                except TypeError:
                    # Some RDKit versions expect useRandomCoords in params
                    params.useRandomCoords = True
                    conf_id = AllChem.EmbedMolecule(mol, params)
            """

            # Determine requested MMFF variant from options (fall back to MMFF94s)
            opt_method = None
            try:
                opt_method = options.get("optimization_method") if options else None
            except Exception:
                opt_method = None

            if conf_id != -1:
                # Success with RDKit: optimize and finish
                # CRITICAL: Restore original stereochemistry after embedding (explicit labels first)
                for bond_idx, stereo, stereo_atoms in original_stereo_info:
                    bond = mol.GetBondWithIdx(bond_idx)
                    if len(stereo_atoms) == 2:
                        bond.SetStereoAtoms(stereo_atoms[0], stereo_atoms[1])
                    bond.SetStereo(stereo)

                try:
                    mmff_method = "MMFF94s"
                    if opt_method and str(opt_method).upper() == "MMFF94_RDKIT":
                        mmff_method = "MMFF94"
                    if not _iterative_optimize(mol, mmff_method, _check_halted, _safe_status):
                        if _check_halted():
                            raise WorkerHaltError("Halted")
                        _iterative_optimize(mol, "UFF", _check_halted, _safe_status)
                except WorkerHaltError:
                    raise
                except Exception as opt_err:
                    _safe_status(f"RDKit optimization failed (ignoring): {opt_err}")
                # CRITICAL: Restore stereochemistry again after optimization (explicit labels priority)
                for bond_idx, stereo, stereo_atoms in original_stereo_info:
                    bond = mol.GetBondWithIdx(bond_idx)
                    if len(stereo_atoms) == 2:
                        bond.SetStereoAtoms(stereo_atoms[0], stereo_atoms[1])
                    bond.SetStereo(stereo)

                # CRITICAL: Check for halt *before* emitting finished signal
                if _check_halted():
                    raise WorkerHaltError("Halted")

                # Collision avoidance
                _adjust_collision_avoidance(mol, _check_halted, _safe_status)

                try:
                    _safe_finished((worker_id, mol))
                except WorkerHaltError:
                    raise
                except Exception:
                    _safe_finished(mol)
                _safe_status("RDKit 3D conversion succeeded.")
                return

            # If RDKit did not produce a conf and OBabel is allowed, try Open Babel
            if conf_id == -1 and conversion_mode in ("fallback", "obabel"):
                _safe_status(
                    "RDKit embedding failed or disabled. Attempting Open Babel..."
                )
                try:
                    if not OBABEL_AVAILABLE:
                        raise RuntimeError(
                            "Open Babel (pybel) is not available in this Python environment."
                        )
                    ob_mol = pybel.readstring("mol", mol_block)
                    try:
                        ob_mol.addh()
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
                    ob_mol.make3D()
                    try:
                        _safe_status("Optimizing with Open Babel (MMFF94)...")
                        if _check_halted():
                            raise WorkerHaltError("Halted")
                        ob_mol.localopt(forcefield="mmff94", steps=500)
                    except Exception:
                        try:
                            _safe_status("MMFF94 failed, falling back to UFF...")
                            if _check_halted():
                                raise WorkerHaltError("Halted")
                            ob_mol.localopt(forcefield="uff", steps=500)
                        except Exception:
                            _safe_status("UFF optimization also failed.")
                    molblock_ob = ob_mol.write("mol")
                    rd_mol = Chem.MolFromMolBlock(molblock_ob, removeHs=False)
                    if rd_mol is None:
                        raise ValueError("Open Babel produced invalid MOL block.")
                    rd_mol = Chem.AddHs(rd_mol)
                    try:
                        mmff_method = "MMFF94s"
                        if opt_method and str(opt_method).upper() == "MMFF94_RDKIT":
                            mmff_method = "MMFF94"
                        if _check_halted():
                            raise WorkerHaltError("Halted")
                        if not _iterative_optimize(rd_mol, mmff_method, _check_halted, _safe_status):
                            if _check_halted():
                                raise WorkerHaltError("Halted")
                            _iterative_optimize(rd_mol, "UFF", _check_halted, _safe_status)
                    except WorkerHaltError:
                        raise
                    except Exception:  # pragma: no cover
                        import traceback
                        traceback.print_exc()
                    _safe_status(
                        "Open Babel embedding succeeded. Warning: Conformation accuracy may be limited."
                    )
                    # CRITICAL: Check for halt *before* emitting finished signal
                    if _check_halted():
                        raise WorkerHaltError("Halted")

                    # Collision avoidance
                    _adjust_collision_avoidance(rd_mol, _check_halted, _safe_status)
                    try:
                        _safe_finished((worker_id, rd_mol))
                    except Exception:
                        _safe_finished(rd_mol)
                    return
                except WorkerHaltError:
                    raise
                except Exception as ob_err:
                    if conversion_mode == "obabel":
                        # obabel-only mode: no further fallback
                        raise RuntimeError(f"Open Babel 3D conversion failed: {ob_err}")
                    # fallback mode: continue to direct conversion below
                    _safe_status(
                        f"Open Babel unavailable or failed ({ob_err}). "
                        "Falling back to direct conversion..."
                    )

            if conf_id == -1 and conversion_mode == "rdkit":
                raise RuntimeError("RDKit 3D conversion failed (rdkit-only mode)")

            # --- Last-resort fallback: direct conversion ---
            if conf_id == -1 and conversion_mode == "fallback":
                _safe_status(
                    "All embedding methods failed. Using direct conversion as last resort..."
                )
                direct_opts = dict(options) if options else {}
                direct_opts["conversion_mode"] = "direct"
                self.run_calculation(mol_block, direct_opts)
                return

        except WorkerHaltError:
            _safe_error("Halted")
            return
        except Exception as e:
            _safe_error(str(e))
