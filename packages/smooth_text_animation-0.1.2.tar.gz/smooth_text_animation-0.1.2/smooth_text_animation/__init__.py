# smooth-text-animation/smooth_text_animation/__init__.py
"""
Smooth Text Animation - Beautiful text animations for terminal
"""

__version__ = "0.1.2"
__author__ = "traitimtrongvag"
__email__ = "tbinh831@gmail.com"

from .animations import (
    animated_line,
    animated_line_dual,
    fade_in_text,
    marquee_text,
    wave_text,
    blinking_text,
    random_fill,
    reverse_text,
    rotate_text,
    combined_animation_simultaneous,
    glitch_text,
    rainbow_text,
    matrix_reveal,
    typewriter_advanced,
    bounce_text,
    scramble_solve,
    slide_in,
    pulse_text,
    reveal_mask,
    zigzag_text,
    expanding_center,
    neon_flicker,
)

__all__ = [
    "animated_line",
    "animated_line_dual",
    "fade_in_text",
    "marquee_text",
    "wave_text",
    "blinking_text",
    "random_fill",
    "reverse_text",
    "rotate_text",
    "combined_animation_simultaneous",
    "glitch_text",
    "rainbow_text",
    "matrix_reveal",
    "typewriter_advanced",
    "bounce_text",
    "scramble_solve",
    "slide_in",
    "pulse_text",
    "reveal_mask",
    "zigzag_text",
    "expanding_center",
    "neon_flicker",
]
