
"""Bohra 
.. moduleauthor:: Kristy Horan <kristyhoran15@gmail.com>
"""
__author__ = "Kristy Horan"
__license__ = "GPL"
__maintainer__ = "Kristy Horan"
__email__ = "kristyhoran15@gmail.com"
__status__ = "Development"