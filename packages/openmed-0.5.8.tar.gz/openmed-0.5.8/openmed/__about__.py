"""Version information for OpenMed."""

__version__ = "0.5.8"
