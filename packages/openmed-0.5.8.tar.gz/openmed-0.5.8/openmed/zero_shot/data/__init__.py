"""Data assets for OpenMed zero-shot tooling."""

from __future__ import annotations

__all__ = []
