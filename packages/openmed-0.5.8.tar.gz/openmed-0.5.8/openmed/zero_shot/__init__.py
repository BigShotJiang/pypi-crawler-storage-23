"""Zero-shot tooling (CLI + assets) for OpenMed."""

from __future__ import annotations

__all__ = []
