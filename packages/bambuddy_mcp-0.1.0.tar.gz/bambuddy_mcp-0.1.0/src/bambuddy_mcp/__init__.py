"""Bambuddy MCP Server - dynamically exposes REST API as MCP tools."""

from bambuddy_mcp.server import main

__all__ = ["main"]
