import math
import sys

class PrettyTable:
    """
    A lightweight, professional TUI table generator for Python.
    Designed for simplicity and maximum compatibility across terminals.
    """
    def __init__(self, headers=None):
        self.headers = [str(h) for h in headers] if headers else []
        self.rows = []
        self.chars = {
            "t": "┌", "m": "┬", "tr": "┐", 
            "l": "├", "c": "┼", "r": "┤", 
            "b": "└", "bm": "┴", "br": "┘", 
            "v": "│", "h": "─"
        }

    def add_row(self, row):
        """Adds a single row of data."""
        self.rows.append([str(item) for item in row])

    @staticmethod
    def show(data):
        """
        Universal static method. Automatically detects format (Dict, Matrix, or List of Dicts)
        and prints the table immediately.
        """
        if not data:
            print("No data to display")
            return

        # Case 1: Dictionary of lists {Header: [Items]}
        if isinstance(data, dict):
            headers = list(data.keys())
            lists = list(data.values())
            max_len = max(len(lst) for lst in lists) if lists else 0
            
            table = PrettyTable(headers)
            for i in range(max_len):
                row = []
                for lst in lists:
                    row.append(str(lst[i]) if i < len(lst) else "-")
                table.add_row(row)
            print(table.render())
            return

        # Case 2: List of something
        if isinstance(data, list) and len(data) > 0:
            # Check for List of Dicts (API Style)
            if isinstance(data[0], dict):
                headers = list(data[0].keys())
                table = PrettyTable(headers)
                for item in data:
                    table.add_row(list(item.values()))
                print(table.render())
                return
            
            # Check for List of Lists (Matrix)
            elif isinstance(data[0], list):
                table = PrettyTable(data[0])
                for row in data[1:]:
                    table.add_row(row)
                print(table.render())
                return
        
        print("Error: Unsupported data format")

    def _get_col_widths(self):
        """Calculates column widths based on the longest content."""
        widths = [len(str(h)) for h in self.headers]
        for row in self.rows:
            for i, cell in enumerate(row):
                if i < len(widths):
                    widths[i] = max(widths[i], len(str(cell)))
                else:
                    widths.append(len(str(cell)))
        return [w + 2 for w in widths]

    def _format_cell(self, text, width):
        """Formatting: Everything is left-aligned."""
        clean_text = str(text).strip()
        inner_w = width - 2
        return f" {clean_text.ljust(inner_w)} "

    def _build_line(self, widths, left, mid, right):
        """Constructs a horizontal boundary line."""
        line = left
        for i, w in enumerate(widths):
            line += self.chars["h"] * w
            if i < len(widths) - 1:
                line += mid
        return line + right

    def render(self):
        """Assembles the table into a single string."""
        if not self.headers and not self.rows:
            return "Empty Table"

        widths = self._get_col_widths()
        output = []
        
        output.append(self._build_line(widths, self.chars["t"], self.chars["m"], self.chars["tr"]))
        
        header_line = self.chars["v"]
        for i, h in enumerate(self.headers):
            header_line += self._format_cell(h, widths[i]) + self.chars["v"]
        output.append(header_line)
        
        output.append(self._build_line(widths, self.chars["l"], self.chars["c"], self.chars["r"]))
        
        for row in self.rows:
            row_line = self.chars["v"]
            for i, cell in enumerate(row):
                if i < len(widths):
                    row_line += self._format_cell(cell, widths[i]) + self.chars["v"]
            output.append(row_line)
            
        output.append(self._build_line(widths, self.chars["b"], self.chars["bm"], self.chars["br"]))
        
        return "\n".join(output)