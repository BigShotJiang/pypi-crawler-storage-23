
# lb-pretty-table: lib for lazy

© Copyright logic-break 2026

https://logic-break.github.io

  

> lib made for lazy, by lazy

  

installation:

  

pip install lb-pretty-table

**NOTE: in code, you must import lb-pretty-table**

## Usage:

The library is "omnivore" — it accepts data in three different formats:

#### A. Dictionary Mode (Column-based)

Best for merging separate lists. It automatically handles different list lengths by adding a `-` placeholder.

```
from lb_pretty_table import PrettyTable

data = {
    "Users": ["logic-break", "abobus", "admin"],
    "Status": ["Coding", "Offline"], # Shorter list
    "Balance": [1000]                 # Only one item
}
PrettyTable.show(data)

```

#### B. Matrix Mode (Row-based)

Perfect for structured data. The **first row** is always treated as the header.

```
matrix = [
    ["ID", "Task", "Priority"],
    ["1", "Initial Commit", "Low"],
    ["2", "Fix UI Bugs", "High"]
]
PrettyTable.show(matrix)

```

#### C. API/JSON Mode (List of Dicts)

Commonly used when fetching data from databases or web APIs.

```
json_data = [
    {"Service": "Web-Server", "Health": "OK"},
    {"Service": "Database", "Health": "Warning"}
]
PrettyTable.show(json_data)
```



## Example:

    from lb_pretty_table import PrettyTable
    
      
    
    # --- FUNCTIONS AND USAGE EXAMPLES ---
    
      
    
    # 1. Automatic Mode (Static Method .show)
    
    # Ideal for quick data printing without manual object creation.
    
    # It automatically detects format and renders the table.
    
      
    
    print("--- Example 1: Smart Dict (Automatic Alignment) ---")
    
    # If lists have different lengths, the library automatically adds "-"
    
    developers = ["logic-break",  "abobus"]
    
    ranks = ["God",  "Junior",  "Newbie"]  # This list is longer
    
    status = ["Online"]
    
      
    
    # Simply pass a dictionary: {Header: List}
    
    PrettyTable.show({
    
    "Developer": developers,
    
    "Rank": ranks,
    
    "Status": status
    
    })
    
      
      
    
    print("\n--- Example 2: Matrix (List of Lists) ---")
    
    # The first row is automatically treated as the header.
    
    matrix_data = [
    
    ["Project",  "Language",  "Version"],
    
    ["lb-auto-tk",  "Python",  "0.0.5"],
    
    ["lb-pretty-table",  "Python",  "0.0.1"],
    
    ["server-controller",  "Python",  "1.0.0"]
    
    ]
    
    PrettyTable.show(matrix_data)
    
      
      
    
    print("\n--- Example 3: List of Dictionaries (API Style) ---")
    
    # If data comes from a database or API as a list of dictionaries.
    
    json_data = [
    
    {"Name":  "North-Server",  "Uptime":  "99.9%"},
    
    {"Name":  "South-Server",  "Uptime":  "85.0%"}
    
    ]
    
    PrettyTable.show(json_data)
    
      
      
    
    print("\n--- Example 4: Manual Object Control ---")
    
    # Useful for building tables dynamically during program execution.
    
    # Create a table object with specific headers
    
    table = PrettyTable(["Command",  "Description"])
    
      
    
    # Add rows one by one
    
    table.add_row(["/start",  "Launch the system"])
    
    table.add_row(["/stop",  "Shutdown all modules"])
    
      
    
    # The .render() method returns a string for printing or writing to a file
    
    rendered_string = table.render()
    
    print(rendered_string)
