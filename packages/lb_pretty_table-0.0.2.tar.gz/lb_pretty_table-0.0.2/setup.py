from setuptools import setup

setup(
    name="lb-pretty-table",
    version="0.0.2",
    py_modules=["lb_pretty_table"],
    description="Professional TUI table generator with auto-alignment",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="logic-break",
    author_email="abibasqabiba@gmail.com", # ASCII only!
    url="https://github.com/logic-break/lb-pretty-table",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)