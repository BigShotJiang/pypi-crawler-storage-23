"""Utilities for MCP tools - shared constants and helper functions."""
