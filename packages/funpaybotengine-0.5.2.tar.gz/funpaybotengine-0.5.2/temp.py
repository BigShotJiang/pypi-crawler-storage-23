from funpaybotengine import Bot
from funpaybotengine.methods.get_orders import GetOrders
import json


bot = Bot(golden_key='j9k09a1lnifuw3ngpdc9pphxuqe94bqy', proxy='socks5://user148429:dgej93@45.39.104.142:19392')

async def main():
    await bot.update()
    print(bot.username)

    method = GetOrders(order_ids=['B72YEFH9'])
    r = (await method.execute(bot)).response_obj
    print(json.dumps(r, indent=4, ensure_ascii=False))


if __name__ == '__main__':
    import asyncio
    asyncio.run(main())