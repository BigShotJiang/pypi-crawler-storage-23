"""OomLlama CLI entry point."""
from oomllama import cli

if __name__ == "__main__":
    cli()
