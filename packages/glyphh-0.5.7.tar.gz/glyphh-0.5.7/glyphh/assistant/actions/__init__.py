"""Glyphh Actions model — routes user intents to executable platform actions."""
