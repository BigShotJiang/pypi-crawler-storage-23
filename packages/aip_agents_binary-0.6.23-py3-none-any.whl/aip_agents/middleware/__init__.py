"""Middleware package.

Provides composable middleware components for enhancing agent capabilities with
planning, file storage, memory, and custom lifecycle hooks.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from typing import TYPE_CHECKING, Any

from aip_agents.middleware.base import AgentMiddleware, ModelRequest
from aip_agents.middleware.filesystem import FilesystemMiddleware
from aip_agents.middleware.manager import MiddlewareManager
from aip_agents.middleware.memory import MemoryMiddleware
from aip_agents.middleware.todolist import TodoListMiddleware, TodoStatus

if TYPE_CHECKING:
    from aip_agents.middleware.skills import SkillsMiddleware

__all__ = [
    "AgentMiddleware",
    "FilesystemMiddleware",
    "ModelRequest",
    "MiddlewareManager",
    "MemoryMiddleware",
    "TodoListMiddleware",
    "TodoStatus",
    "SkillsMiddleware",
]


def __getattr__(name: str) -> Any:
    """Lazy import middleware modules to avoid eager optional dependencies.

    Args:
        name (str): Attribute name requested from this module.

    Returns:
        Any: The requested attribute.

    Raises:
        AttributeError: If the attribute is not defined.
    """
    if name == "SkillsMiddleware":
        from aip_agents.middleware.skills import SkillsMiddleware as SkillsMiddlewareType

        return SkillsMiddlewareType
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Return module attributes for dir().

    Returns:
        list[str]: Sorted list of public attributes.
    """
    return sorted(__all__)
