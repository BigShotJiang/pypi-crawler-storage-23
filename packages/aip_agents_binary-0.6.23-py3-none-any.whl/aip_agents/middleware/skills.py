"""Skills middleware (DeepAgents-compatible, prompt-only).

This module implements a DeepAgents-style skills middleware for AIP. Skills are:
- staged into backend storage under `/skills/<skill-name>/`,
- discovered from backend sources by reading SKILL.md YAML frontmatter,
- injected into the model request system prompt (not appended to base instructions).

Author:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

import asyncio
import posixpath
import re
import shutil
from pathlib import Path, PurePosixPath
from typing import Any, Final, NotRequired, TypedDict

import yaml
from pydantic import BaseModel, ConfigDict, Field

from aip_agents.middleware.backends.in_memory import InMemoryBackend
from aip_agents.middleware.backends.protocol import BackendProtocol, FileInfo
from aip_agents.middleware.base import AgentMiddleware, ModelRequest
from aip_agents.skills.errors import SkillInstallError
from aip_agents.skills.installer import parse_github_tree_source
from aip_agents.skills.models import Skill
from aip_agents.skills.stager import SkillStager
from aip_agents.skills.validation import validate_skill_name
from aip_agents.utils.logger import get_logger

logger = get_logger(__name__)

MAX_SKILL_FILE_SIZE: Final[int] = 10 * 1024 * 1024
MAX_SKILL_NAME_LENGTH: Final[int] = 64
MAX_SKILL_DESCRIPTION_LENGTH: Final[int] = 1024

__all__ = [
    "SkillConfig",
    "SkillMetadata",
    "SkillsMiddleware",
]


class SkillConfig(BaseModel):
    """Configuration for skills middleware setup.

    Attributes:
        skills (list[Skill | str] | None): Local skill objects or GitHub sources. Defaults to None.
        backend (BackendProtocol | None): Backend for staging/reading. Defaults to None (InMemoryBackend).
        sources (list[str] | None): Backend source roots to scan for skills. Defaults to ["/skills/"].
        destination_root (str): Backend root under which skills are staged. Defaults to "/skills".
        auto_read (bool): Whether to auto-load SKILL.md bodies into the system prompt. Defaults to False.
        auto_read_limit (int | None): Maximum number of skills to auto-load. Defaults to None (all).
        include_read_tool (bool): Whether to expose the read_file tool. Defaults to True.
        local_skill_root (str | Path): Local install root for GitHub skill sources. Defaults to ".agents/skills".
    """

    skills: list[Skill | str] | None = Field(default=None)
    backend: Any | None = Field(default=None)
    sources: list[str] | None = Field(default=None)
    destination_root: str = Field(default="/skills")
    auto_read: bool = Field(default=False)
    auto_read_limit: int | None = Field(default=None)
    include_read_tool: bool = Field(default=True)
    local_skill_root: str | Path = Field(default=".agents/skills")

    def create_backend(self, backend: BackendProtocol | None = None) -> BackendProtocol:
        """Create a backend instance for skills.

        Args:
            backend (BackendProtocol | None): Optional backend override. Defaults to None.

        Returns:
            BackendProtocol: Backend instance for SkillsMiddleware.
        """
        resolved_backend = self.backend if self.backend is not None else backend
        return resolved_backend or InMemoryBackend()

    def create_middleware(self, *, backend: BackendProtocol | None = None) -> SkillsMiddleware:
        """Create SkillsMiddleware from this configuration.

        Args:
            backend (BackendProtocol | None): Optional backend override when none is configured. Defaults to None.

        Returns:
            SkillsMiddleware: Configured middleware instance.
        """
        return SkillsMiddleware(
            backend=self.create_backend(backend),
            skills=self.skills,
            sources=self.sources,
            destination_root=self.destination_root,
            auto_read=self.auto_read,
            auto_read_limit=self.auto_read_limit,
            include_read_tool=self.include_read_tool,
            local_skill_root=self.local_skill_root,
        )

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)


class SkillMetadata(TypedDict):
    """Parsed metadata for a skill (from SKILL.md YAML frontmatter)."""

    name: str
    description: str
    path: str
    license: NotRequired[str | None]
    compatibility: NotRequired[str | None]
    metadata: NotRequired[dict[str, Any]]
    allowed_tools: NotRequired[list[str]]


_SKILLS_SYSTEM_PROMPT_TEMPLATE: Final[str] = """

## Skills System

You have access to a skills library that provides specialized capabilities and domain knowledge.

{skills_locations}

**Available Skills:**

{skills_list}

**How to Use Skills (Progressive Disclosure):**

Skills follow a **progressive disclosure** pattern - you see their name and description above, but only read full instructions when needed:

1. **Recognize when a skill applies**: Check if the user's task matches a skill's description
2. **Read the skill's full instructions**: Use the path shown in the skill list above
3. **Follow the skill's instructions**: SKILL.md contains step-by-step workflows, best practices, and examples
4. **Access supporting files**: Skills may include helper scripts, configs, or reference docs - use absolute paths

**When to Use Skills:**
- User's request matches a skill's domain (e.g., "research X" -> web-research skill)
- You need specialized knowledge or structured workflows
- A skill provides proven patterns for complex tasks

**Example Workflow:**

User: "Can you research the latest developments in quantum computing?"

1. Check available skills -> See "web-research" skill with its path
2. Read the skill using the path shown
3. Follow the skill's research workflow (search -> organize -> synthesize)
4. Use any helper scripts with absolute paths

Remember: Skills make you more capable and consistent. When in doubt, check if a skill exists for the task!
"""


def _ensure_posix_absolute(path: str) -> str:
    """Normalize a path to an absolute POSIX path.

    Args:
        path (str): Path to normalize.

    Returns:
        str: Normalized absolute path.
    """
    normalized = path.strip()
    if not normalized.startswith("/"):
        normalized = "/" + normalized
    return normalized


def _extract_frontmatter(content: str) -> str | None:
    """Extract YAML frontmatter without regex backtracking.

    Args:
        content (str): Full SKILL.md contents.

    Returns:
        str | None: Frontmatter content if present, otherwise None.
    """
    if not content.startswith("---"):
        return None

    start = content.find("\n")
    if start == -1:
        return None

    end = content.find("\n---", start + 1)
    if end == -1:
        return None

    end_line = content.find("\n", end + 1)
    if end_line == -1:
        return None

    return content[start + 1 : end]


def _validate_skill_name(name: str, directory_name: str) -> tuple[bool, str]:
    """Validate skill name per Agent Skills specification.

    Args:
        name (str): Skill name from YAML frontmatter.
        directory_name (str): Parent directory name.

    Returns:
        tuple[bool, str]: (is_valid, error_message) tuple. Error message is empty if valid.
    """
    if not name:
        return False, "name is required"
    if len(name) > MAX_SKILL_NAME_LENGTH:
        return False, "name exceeds 64 characters"
    if not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", name):
        return False, "name must be lowercase alphanumeric with single hyphens only"
    if name != directory_name:
        return False, f"name '{name}' must match directory name '{directory_name}'"
    return True, ""


def _parse_skill_metadata(content: str, *, skill_path: str, directory_name: str) -> SkillMetadata | None:
    """Parse YAML frontmatter from SKILL.md content.

    Args:
        content (str): Content of the SKILL.md file.
        skill_path (str): Backend path to the SKILL.md file.
        directory_name (str): Name of the parent directory containing the skill.

    Returns:
        SkillMetadata | None: Parsed metadata, or None if parsing/validation fails.
    """
    if len(content) > MAX_SKILL_FILE_SIZE:
        logger.warning("Skipping %s: content too large (%d bytes)", skill_path, len(content))
        return None

    frontmatter_str = _extract_frontmatter(content)
    if frontmatter_str is None:
        logger.warning("Skipping %s: no valid YAML frontmatter found", skill_path)
        return None

    try:
        frontmatter_data = yaml.safe_load(frontmatter_str)
    except yaml.YAMLError as exc:
        logger.warning("Invalid YAML in %s: %s", skill_path, exc)
        return None

    if not isinstance(frontmatter_data, dict):
        logger.warning("Skipping %s: frontmatter is not a mapping", skill_path)
        return None

    name = frontmatter_data.get("name")
    description = frontmatter_data.get("description")
    if not name or not description:
        logger.warning("Skipping %s: missing required 'name' or 'description'", skill_path)
        return None

    is_valid, error = _validate_skill_name(str(name), directory_name)
    if not is_valid:
        logger.warning(
            "Skill '%s' in %s does not follow Agent Skills specification: %s. Consider renaming for spec compliance.",
            name,
            skill_path,
            error,
        )

    description_str = str(description).strip()
    if len(description_str) > MAX_SKILL_DESCRIPTION_LENGTH:
        logger.warning("Description exceeds %d characters in %s, truncating", MAX_SKILL_DESCRIPTION_LENGTH, skill_path)
        description_str = description_str[:MAX_SKILL_DESCRIPTION_LENGTH]

    allowed_tools: list[str]
    allowed_tools_raw = frontmatter_data.get("allowed-tools")
    if allowed_tools_raw:
        allowed_tools = str(allowed_tools_raw).split(" ")
    else:
        allowed_tools = []

    return SkillMetadata(
        name=str(name),
        description=description_str,
        path=skill_path,
        metadata=frontmatter_data.get("metadata", {}) if isinstance(frontmatter_data.get("metadata", {}), dict) else {},
        license=str(frontmatter_data.get("license", "")).strip() or None,
        compatibility=str(frontmatter_data.get("compatibility", "")).strip() or None,
        allowed_tools=allowed_tools,
    )


def _candidate_skill_md_paths(items: list[FileInfo], *, source_path: str) -> list[str]:
    """Infer SKILL.md paths from backend ls_info results.

    Args:
        items (list[FileInfo]): Entries returned by backend.ls_info().
        source_path (str): Backend source path being scanned.

    Returns:
        list[str]: Candidate SKILL.md paths.
    """
    candidates: list[str] = []
    for item in items:
        path = str(item.get("path", ""))
        entry_type = str(item.get("type", ""))
        if not path:
            continue

        abs_path = _ensure_posix_absolute(path)

        if entry_type == "directory":
            candidates.append(posixpath.join(abs_path.rstrip("/"), "SKILL.md"))
            continue

        if entry_type == "file" and abs_path.endswith("/SKILL.md"):
            candidates.append(abs_path)

    # As a fallback (e.g., in-memory backend returning only files), attempt to derive
    # skill directories by scanning for any SKILL.md under the source prefix.
    source_abs = _ensure_posix_absolute(source_path).rstrip("/") + "/"
    for item in items:
        path = str(item.get("path", ""))
        if not path:
            continue
        abs_path = _ensure_posix_absolute(path)
        if abs_path.startswith(source_abs) and abs_path.endswith("/SKILL.md"):
            candidates.append(abs_path)

    # De-dupe but keep stable order.
    seen: set[str] = set()
    unique: list[str] = []
    for p in candidates:
        if p in seen:
            continue
        seen.add(p)
        unique.append(p)
    return unique


def _read_skill_files(backend: BackendProtocol, skill_md_paths: list[str]) -> dict[str, str]:
    """Read raw SKILL.md contents for a list of backend paths.

    This prefers a backend-native `download_files()` API if present. If not present, it falls back
    to reading the file as UTF-8 text directly from the backend by using `read()` and stripping
    leading line numbers. The fallback is best-effort and not suitable for all backends.

    Args:
        backend (BackendProtocol): Backend instance.
        skill_md_paths (list[str]): SKILL.md backend paths.

    Returns:
        dict[str, str]: Mapping from SKILL.md path to decoded content.
    """
    downloader = getattr(backend, "download_files", None)
    if callable(downloader):
        responses = downloader(skill_md_paths)
        out: dict[str, str] = {}
        for response in responses:
            error = getattr(response, "error", None)
            content = getattr(response, "content", None)
            path = getattr(response, "path", None)

            if error or content is None or not path:
                continue
            try:
                out[str(path)] = content.decode("utf-8")
            except UnicodeDecodeError as exc:
                logger.warning("Error decoding %s: %s", path, exc)
        return out

    # Best-effort fallback for backends that only expose formatted `read()`.
    out: dict[str, str] = {}
    for path in skill_md_paths:
        try:
            formatted = backend.read(path, offset=0, limit=2000)
        except Exception:
            continue

        lines = []
        for line in formatted.splitlines():
            # DeepAgents uses `format_content_with_line_numbers` which prefixes with a right-justified
            # integer and a tab. Strip leading `<spaces><digits><tab>` if present.
            lines.append(re.sub(r"^\s*\d+(?:\.\d+)?\t", "", line))
        out[path] = "\n".join(lines)
    return out


def _list_skills(backend: BackendProtocol, source_path: str) -> list[SkillMetadata]:
    """List all skills from a backend source.

    Args:
        backend (BackendProtocol): Backend instance to use for file operations.
        source_path (str): Path to the skills directory in the backend.

    Returns:
        list[SkillMetadata]: Skills successfully parsed from SKILL.md frontmatter.
    """
    try:
        items = backend.ls_info(source_path)
    except (FileNotFoundError, NotADirectoryError):
        return []

    skill_md_paths = _candidate_skill_md_paths(items, source_path=source_path)
    if not skill_md_paths:
        return []

    content_by_path = _read_skill_files(backend, skill_md_paths)
    skills: list[SkillMetadata] = []

    for skill_md_path, content in content_by_path.items():
        # Derive directory name from path using PurePosixPath.
        directory_name = PurePosixPath(skill_md_path).parent.name
        parsed = _parse_skill_metadata(content, skill_path=skill_md_path, directory_name=directory_name)
        if parsed:
            skills.append(parsed)

    return skills


class SkillsMiddleware(AgentMiddleware):
    """AIP middleware that exposes prompt-only skills via progressive disclosure."""

    def __init__(
        self,
        *,
        backend: BackendProtocol,
        skills: list[Skill | str] | None = None,
        sources: list[str] | None = None,
        destination_root: str = "/skills",
        auto_read: bool = False,
        auto_read_limit: int | None = None,
        include_read_tool: bool = True,
        local_skill_root: str | Path = ".agents/skills",
    ) -> None:
        """Initialize SkillsMiddleware.

        Args:
            backend (BackendProtocol): Backend instance providing storage and file APIs.
            skills (list[Skill] | None, optional): Local skills to stage into backend. Defaults to None.
            sources (list[str] | None, optional): Backend source roots to scan for skills. Defaults to ["/skills/"].
            destination_root (str, optional): Backend root under which skills are staged. Defaults to "/skills".
            auto_read (bool, optional): Whether to auto-load SKILL.md bodies into the system prompt. Defaults to False.
            auto_read_limit (int | None, optional): Maximum number of skills to auto-load. Defaults to None (all).
            include_read_tool (bool, optional): Whether to expose the read_file tool. Defaults to True.
            local_skill_root (str | Path, optional): Local install root for GitHub skill sources. Defaults to
                ".agents/skills".

        Returns:
            None: This initializer returns None.
        """
        self._backend = backend
        raw_skills = skills or []
        self._skills = [skill for skill in raw_skills if isinstance(skill, Skill)]
        self._skill_sources = [skill for skill in raw_skills if isinstance(skill, str)]
        self._sources = sources or ["/skills/"]
        self._destination_root = destination_root
        self._auto_read = auto_read
        self._auto_read_limit = auto_read_limit
        self._local_skill_root = Path(local_skill_root)
        self._stager = SkillStager(backend=backend, destination_root=destination_root)

        self.tools: list[Any] = []
        if include_read_tool:
            from aip_agents.middleware.tools.read_file import ReadFileTool

            self.tools = [ReadFileTool(backend=backend)]
        self.system_prompt_additions: str | None = None

    async def _install_skill_sources_if_needed(self, state: dict[str, Any]) -> dict[str, Any]:
        """Install skill sources and update state flags when needed.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates indicating installation completion.
        """
        if not self._skill_sources or state.get("_skills_installed"):
            return {}

        installed = await self._install_skill_sources()
        self._skills.extend(installed)
        return {"_skills_installed": True}

    async def _install_skill_sources(self) -> list[Skill]:
        """Install skill sources into the local root.

        Returns:
            list[Skill]: Installed skills.
        """
        if not self._skill_sources:
            return []

        self._local_skill_root.mkdir(parents=True, exist_ok=True)
        installed: list[Skill] = []
        for source in self._skill_sources:
            self._cleanup_invalid_install(source)
            installed.append(await Skill.from_github(source=source, destination_root=self._local_skill_root))
        self._skill_sources = []
        return installed

    def _cleanup_invalid_install(self, source: str) -> None:
        """Remove invalid local skill folders missing SKILL.md.

        Args:
            source (str): GitHub tree URL for the skill.

        Returns:
            None: This helper returns None.
        """
        try:
            skill_name = parse_github_tree_source(source).skill_name
            validate_skill_name(skill_name)
        except Exception:
            return

        skill_root = (self._local_skill_root / skill_name).resolve()
        local_root = self._local_skill_root.resolve()
        try:
            skill_root.relative_to(local_root)
        except ValueError:
            return

        skill_md_path = skill_root / "SKILL.md"
        if skill_root.exists() and not skill_md_path.is_file():
            shutil.rmtree(skill_root)

    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Stage skills and load skills metadata into state.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
        updates: dict[str, Any] = {}

        if self._skill_sources and not state.get("_skills_installed"):
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                updates.update(asyncio.run(self._install_skill_sources_if_needed(state)))
            else:
                raise SkillInstallError(
                    "Skills require async installation when an event loop is already running. "
                    "Use async agent execution or pre-install skills before running sync flows."
                )

        if self._skills and not state.get("_skills_staged"):
            self._stager.stage(self._skills)
            updates["_skills_staged"] = True

        # Load metadata once per thread/state.
        if "skills_metadata" not in state:
            all_skills: dict[str, SkillMetadata] = {}
            for source_path in self._sources:
                for skill in _list_skills(self._backend, source_path):
                    all_skills[skill["name"]] = skill
            updates["skills_metadata"] = list(all_skills.values())
            if self._auto_read:
                limit = self._auto_read_limit
                if limit is None:
                    limit = len(updates["skills_metadata"])
                if limit > 0:
                    updates.update(self._auto_read_skill_bodies(updates["skills_metadata"], limit))

        return updates

    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Inject skills section into the model request system prompt.

        Args:
            request (ModelRequest): Model request to modify.
            state (dict[str, Any]): Agent state containing skills metadata.

        Returns:
            ModelRequest: Modified request.
        """
        skills_metadata: list[SkillMetadata] = state.get("skills_metadata", [])
        skills_locations = self._format_skills_locations()
        skills_list = self._format_skills_list(skills_metadata)

        skills_section = _SKILLS_SYSTEM_PROMPT_TEMPLATE.format(
            skills_locations=skills_locations,
            skills_list=skills_list,
        )

        current_system_prompt = request.get("system_prompt", "")
        system_prompt = current_system_prompt + skills_section
        auto_read_bodies: list[dict[str, str]] = state.get("skills_fulltext", [])
        if auto_read_bodies:
            system_prompt += "\n\n## Auto-Loaded Skill Instructions\n\n"
            for entry in auto_read_bodies:
                name = entry.get("name", "unknown-skill")
                path = entry.get("path", "")
                content = entry.get("content", "")
                if not content.strip():
                    continue
                system_prompt += f"### {name}\n"
                if path:
                    system_prompt += f"Path: `{path}`\n\n"
                system_prompt += f"{content}\n\n"
        request["system_prompt"] = system_prompt
        return request

    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """No-op after_model hook.

        Args:
            state (dict[str, Any]): Agent state.

        Returns:
            dict[str, Any]: Empty updates.
        """
        return {}

    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async before_model hook.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
        updates: dict[str, Any] = {}
        updates.update(await self._install_skill_sources_if_needed(state))

        merged_state = {**state, **updates}
        updates.update(self.before_model(merged_state))
        return updates

    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Async after_model hook.

        Args:
            state (dict[str, Any]): Agent state dict.

        Returns:
            dict[str, Any]: State updates to merge.
        """
        return self.after_model(state)

    def _format_skills_locations(self) -> str:
        """Format skills locations for display in system prompt.

        Returns:
            str: Markdown string listing sources and their priority.
        """
        lines: list[str] = []
        for i, source_path in enumerate(self._sources):
            name = PurePosixPath(_ensure_posix_absolute(source_path).rstrip("/")).name.capitalize()
            suffix = " (higher priority)" if i == len(self._sources) - 1 else ""
            lines.append(f"**{name} Skills**: `{_ensure_posix_absolute(source_path)}`{suffix}")
        return "\n".join(lines)

    def _format_skills_list(self, skills: list[SkillMetadata]) -> str:
        """Format skills metadata for display in system prompt.

        Args:
            skills (list[SkillMetadata]): Skills metadata list.

        Returns:
            str: Markdown list of skills and their read paths.
        """
        if not skills:
            paths = [f"{_ensure_posix_absolute(source_path)}" for source_path in self._sources]
            return f"(No skills available yet. You can create skills in {' or '.join(paths)})"

        lines: list[str] = []
        for skill in skills:
            lines.append(f"- **{skill['name']}**: {skill['description']}")
            allowed = skill.get("allowed_tools") or []
            if allowed:
                lines.append(f"  -> Allowed tools: {', '.join(allowed)}")
            lines.append(f"  -> Read `{skill['path']}` for full instructions")
        return "\n".join(lines)

    def _auto_read_skill_bodies(self, skills: list[SkillMetadata], limit: int) -> dict[str, Any]:
        """Auto-read SKILL.md bodies into state when enabled.

        Args:
            skills (list[SkillMetadata]): Skills metadata list.
            limit (int): Maximum number of skills to load.

        Returns:
            dict[str, Any]: State updates containing skills_fulltext when populated.
        """
        if not skills or limit <= 0:
            return {}

        limited = skills[:limit]
        skill_paths = [skill["path"] for skill in limited]
        content_by_path = _read_skill_files(self._backend, skill_paths)

        fulltext: list[dict[str, str]] = []
        for skill in limited:
            path = skill["path"]
            content = content_by_path.get(path, "")
            if not content:
                continue
            fulltext.append(
                {
                    "name": skill["name"],
                    "path": path,
                    "content": content,
                }
            )

        if not fulltext:
            return {}
        return {"skills_fulltext": fulltext}
