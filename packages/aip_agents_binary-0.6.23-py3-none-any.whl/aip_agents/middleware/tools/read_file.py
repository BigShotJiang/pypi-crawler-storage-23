"""Read file tool for agents.

TODO: After migrating to deepagents:
  - Keep this tool implementation (it's incompatible with deepagents' version)
  - Reuse from deepagents: BackendProtocol, FileInfo, format_content_with_line_numbers()

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

READ_FILE_TOOL_DESCRIPTION = """Reads a file from the filesystem.

Assume this tool is able to read all files. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

Usage:
- By default, it reads up to 100 lines starting from the beginning of the file
- **IMPORTANT for large files and codebase exploration**: Use pagination with offset and limit parameters to avoid context overflow
  - First scan: read_file(path, limit=100) to see file structure
  - Read more sections: read_file(path, offset=100, limit=200) for next 200 lines
  - Only omit limit (read full file) when necessary for editing
- Specify offset and limit: read_file(path, offset=0, limit=100) reads first 100 lines
- Results are returned using cat -n format, with line numbers starting at 1
- Lines longer than 5,000 characters will be split into multiple lines with continuation markers (e.g., 5.1, 5.2, etc.). When you specify a limit, these continuation lines count towards the limit.
- You have the capability to call multiple tools in a single response. It is always better to speculatively read multiple files as a batch that are potentially useful.
- If you read a file that exists but has empty contents you will receive a system reminder warning in place of file contents.
- You should ALWAYS make sure a file has been read before editing it."""  # noqa: E501


class ReadFileInput(BaseModel):
    """Input schema for read_file tool."""

    path: str = Field(description="File path to read")
    offset: int = Field(default=0, description="Line offset (0-indexed)")
    limit: int = Field(default=100, description="Max lines to return")


class ReadFileTool(BaseTool):
    """Tool for reading file contents with optional pagination."""

    name: str = "read_file"
    description: str = READ_FILE_TOOL_DESCRIPTION
    args_schema: type[BaseModel] = ReadFileInput
    backend: Annotated[Any, SkipValidation()]  # BackendProtocol - skip validation for Protocol type

    def _run(self, path: str, offset: int = 0, limit: int = 100) -> str:
        """Execute the read operation.

        Args:
            path (str): File path to read.
            offset (int, optional): Line offset to start from. Defaults to 0.
            limit (int, optional): Maximum lines to return. Defaults to 100.

        Returns:
            str: File contents or error message.
        """
        try:
            return self.backend.read(path, offset=offset, limit=limit)
        except FileNotFoundError:
            return f"Error: File not found: {path}"
        except ValueError as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Error reading file: {str(e)}"
