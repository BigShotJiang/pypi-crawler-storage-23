"""Skill installation helpers.

PR-001 defines an explicit, object-first installation flow. Installation is performed
via GL Connectors' `gl_connectors_tools.skills.SkillFactory`.

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from aip_agents.skills.errors import SkillInstallError, SkillValidationError
from aip_agents.skills.validation import validate_skill_name

try:
    from gl_connectors_tools.skills import SkillFactory
    from gl_connectors_tools.skills.exceptions.exception import InvalidSkillException, SkillException

    _SKILL_FACTORY_IMPORT_ERROR: ImportError | None = None
except ImportError as exc:
    SkillFactory = None
    _SKILL_FACTORY_IMPORT_ERROR = exc

    class InvalidSkillException(Exception):
        """Fallback exception when gl-connectors-tools is unavailable."""

    class SkillException(Exception):
        """Fallback exception when gl-connectors-tools is unavailable."""


@dataclass(frozen=True, slots=True)
class GitHubTreeSource:
    """A GitHub "tree" URL normalized into components."""

    owner: str
    repo: str
    ref: str
    subdir: str

    @property
    def skill_name(self) -> str:
        """Return the skill directory name (last segment of subdir).

        Returns:
            str: Skill directory name.
        """
        return Path(self.subdir).name


def parse_github_tree_source(source: str) -> GitHubTreeSource:
    """Parse a GitHub tree URL into a normalized form.

    Args:
        source (str): A GitHub URL of the form:
            `https://github.com/<owner>/<repo>/tree/<ref>/<path>`.

    Returns:
        GitHubTreeSource: Parsed components.

    Raises:
        SkillInstallError: If the source is not a supported GitHub tree URL.
    """
    parsed = urlparse(source if "://" in source else f"https://{source}")
    if parsed.scheme and parsed.scheme != "https":
        raise SkillInstallError("Only https:// GitHub URLs are supported.")
    if parsed.netloc not in {"github.com", "www.github.com"}:
        raise SkillInstallError(f"Unsupported skill source host: {parsed.netloc!r}.")

    parts = [p for p in parsed.path.split("/") if p]
    # Expected: owner/repo/tree/ref/<subdir...>
    if len(parts) < 5 or parts[2] != "tree":
        raise SkillInstallError(
            "Unsupported GitHub skill URL format. Expected 'https://github.com/<owner>/<repo>/tree/<ref>/<path>'."
        )

    owner, repo, ref = parts[0], parts[1], parts[3]
    subdir = "/".join(parts[4:])
    return GitHubTreeSource(owner=owner, repo=repo, ref=ref, subdir=subdir)


class SkillInstaller:
    """Install skills into a canonical local destination root."""

    def __init__(self, *, token: str | None = None) -> None:
        """Initialize a SkillInstaller.

        Args:
            token (str | None, optional): GitHub token used for private repos. Defaults to
                `GITHUB_PERSONAL_ACCESS_TOKEN`, `GITHUB_TOKEN`, or `GH_TOKEN` from the environment.

        Returns:
            None: This initializer returns None.
        """
        self._token = (
            token or os.getenv("GITHUB_PERSONAL_ACCESS_TOKEN") or os.getenv("GITHUB_TOKEN") or os.getenv("GH_TOKEN")
        )

    @staticmethod
    def _ensure_skill_factory_available() -> None:
        if SkillFactory is None:
            raise SkillInstallError(
                "gl-connectors-tools is required for skill installation. "
                "Install it with 'pip install \"aip-agents[skills]\"' or 'poetry add gl-connectors-tools'."
            ) from _SKILL_FACTORY_IMPORT_ERROR

    async def install_github_tree(self, *, source: str, destination_root: str | os.PathLike[str]) -> Path:
        """Install a skill from a GitHub tree URL into the destination root.

        If the destination already contains a valid skill folder, this is a no-op and
        returns the existing path.

        Args:
            source (str): A GitHub tree URL pointing at a skill directory.
            destination_root (str | os.PathLike[str]): Root directory to install into.

        Returns:
            Path: The installed skill directory path.

        Raises:
            SkillInstallError: If installation fails.
            SkillValidationError: If the installed skill is invalid.
        """
        parsed = parse_github_tree_source(source)
        validate_skill_name(parsed.skill_name)

        destination_root_path = Path(destination_root).expanduser()
        if destination_root_path.exists() and not destination_root_path.is_dir():
            raise SkillValidationError(f"Destination root is not a directory: {destination_root_path}.")
        try:
            destination_root_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise SkillInstallError(f"Failed to prepare destination root: {destination_root_path}.") from exc

        dest_skill_root = destination_root_path / parsed.skill_name
        skill_md_path = dest_skill_root / "SKILL.md"
        if skill_md_path.is_file():
            return dest_skill_root
        if dest_skill_root.exists():
            raise SkillValidationError(
                f"Destination already exists but is not a valid skill (missing SKILL.md): {dest_skill_root}."
            )

        kwargs: dict[str, object] = {
            "source": source,
            "destination": [str(destination_root_path)],
            "zipped": False,
        }
        if self._token:
            kwargs["token"] = self._token

        self._ensure_skill_factory_available()

        try:
            await SkillFactory.from_github(**kwargs)  # type: ignore[union-attr]
        except InvalidSkillException as exc:
            raise SkillValidationError(
                "Skill installation failed because the skill is invalid (SKILL.md missing)."
            ) from exc
        except SkillException as exc:
            raise SkillInstallError("Failed to install skill from GitHub via GL Connectors SkillFactory.") from exc
        except Exception as exc:  # pragma: no cover
            raise SkillInstallError("Failed to install skill from GitHub via GL Connectors SkillFactory.") from exc

        if not skill_md_path.is_file():
            raise SkillValidationError(f"Installed skill is missing SKILL.md: {skill_md_path}.")
        return dest_skill_root
