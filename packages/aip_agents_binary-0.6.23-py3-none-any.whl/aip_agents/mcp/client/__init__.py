"""MCP Client.

This module provides a adapter client for interacting with MCP servers.

Authors:
    Fachriza Dian Adhiatma (fachriza.d.adhiatma@gdplabs.id)
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

import importlib.util
from typing import TYPE_CHECKING, Any

from aip_agents.mcp.client.base_mcp_client import BaseMCPClient

if TYPE_CHECKING:
    from aip_agents.mcp.client.google_adk.client import GoogleADKMCPClient
    from aip_agents.mcp.client.langchain.client import LangchainMCPClient

__all__ = ["LangchainMCPClient", "BaseMCPClient"]

if importlib.util.find_spec("google.adk") is not None:
    __all__.append("GoogleADKMCPClient")


GOOGLE_ADK_IMPORT_ERROR_MESSAGE = (
    'Google ADK MCP support requires the optional dependency. Install with: pip install "aip-agents[google-adk]"'
)


def __getattr__(name: str) -> Any:
    """Lazy import of MCP client implementations.

    This avoids importing heavy dependencies (Google ADK, Vertex AI, etc.)
    when they are not needed.

    Args:
        name: Attribute name to import.

    Returns:
        The requested class.

    Raises:
        AttributeError: If attribute is not found.
    """
    if name == "GoogleADKMCPClient":
        try:
            from aip_agents.mcp.client.google_adk.client import (
                GoogleADKMCPClient as _GoogleADKMCPClient,
            )
        except ModuleNotFoundError as e:
            if e.name and e.name.startswith("google"):
                raise ImportError(GOOGLE_ADK_IMPORT_ERROR_MESSAGE) from e
            raise

        return _GoogleADKMCPClient
    elif name == "LangchainMCPClient":
        from aip_agents.mcp.client.langchain.client import (
            LangchainMCPClient as _LangchainMCPClient,
        )

        return _LangchainMCPClient
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
