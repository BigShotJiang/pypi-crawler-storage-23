"""Google ADK MCP Client.

This module provides a client for interacting with MCP servers using Google ADK.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aip_agents.mcp.client.google_adk.client import GoogleADKMCPClient

__all__ = ["GoogleADKMCPClient"]

GOOGLE_ADK_IMPORT_ERROR_MESSAGE = (
    'Google ADK MCP support requires the optional dependency. Install with: pip install "aip-agents[google-adk]"'
)


def __getattr__(name: str) -> Any:
    """Lazy load Google ADK MCP client class.

    Args:
        name: Attribute name to resolve.

    Returns:
        Requested attribute.

    Raises:
        AttributeError: If attribute name is unknown.
    """
    if name != "GoogleADKMCPClient":
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

    try:
        from aip_agents.mcp.client.google_adk.client import (
            GoogleADKMCPClient as _GoogleADKMCPClient,
        )
    except ModuleNotFoundError as e:
        if e.name and e.name.startswith("google"):
            raise ImportError(GOOGLE_ADK_IMPORT_ERROR_MESSAGE) from e
        raise

    return _GoogleADKMCPClient
