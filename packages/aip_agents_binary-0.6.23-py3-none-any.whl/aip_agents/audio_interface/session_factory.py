"""Factory for transport-specific audio sessions."""

from __future__ import annotations

from collections.abc import Awaitable
from typing import Any, Protocol

from aip_agents.audio_interface.config import AudioSessionConfig
from aip_agents.audio_interface.errors import AudioConfigError
from aip_agents.audio_interface.livekit_audio_session import LiveKitAudioSession
from aip_agents.audio_interface.livekit_realtime_audio_session import LiveKitRealtimeAudioSession


class AudioSession(Protocol):
    """Minimal transport session contract for audio providers."""

    def start(self, aip_agent: Any, *, instructions: str) -> Awaitable[None]:
        """Start the session."""

    def stop(self) -> Awaitable[None]:
        """Stop the session and cleanup resources."""

    def wait_closed(self) -> Awaitable[None]:
        """Wait until the remote session closes."""


def create_audio_session(config: AudioSessionConfig) -> AudioSession:
    """Create an audio transport session for the configured provider.

    This is the single entry point for "one interface, many implementations".
    """
    provider = (config.provider or "livekit").strip().lower()
    if provider == "livekit":
        return LiveKitAudioSession(config)
    if provider == "livekit_realtime":
        return LiveKitRealtimeAudioSession(config)

    raise AudioConfigError(
        f"Unsupported audio provider '{config.provider}'. Supported providers: livekit, livekit_realtime"
    )
