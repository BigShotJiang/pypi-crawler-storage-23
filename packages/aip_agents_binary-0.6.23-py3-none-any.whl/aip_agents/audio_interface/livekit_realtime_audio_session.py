"""Adapter over gllm_inference LiveKitRealtimeSession.

This implementation ports the gllm-inference realtime session API to the local
audio session interface used by `aip_agents.audio_interface`.
"""

from __future__ import annotations

import asyncio
import importlib
from typing import Any

from aip_agents.audio_interface.config import AudioSessionConfig, LiveKitConfig
from aip_agents.audio_interface.errors import AudioConfigError, AudioSessionUnavailableError
from aip_agents.utils.logger import get_logger

logger = get_logger(__name__)


def _resolve_gllm_livekit_realtime_cls() -> type[Any]:
    """Resolve gllm-inference LiveKitRealtimeSession and validate base interface."""
    try:
        realtime_mod = importlib.import_module("gllm_inference.realtime_session")
        base_mod = importlib.import_module("gllm_inference.realtime_session.realtime_session")
    except Exception as exc:
        raise AudioSessionUnavailableError(
            "gllm-inference realtime_session modules are unavailable. "
            "Install/upgrade gllm-inference with livekit support."
        ) from exc

    livekit_cls = getattr(realtime_mod, "LiveKitRealtimeSession", None)
    base_cls = getattr(base_mod, "BaseRealtimeSession", None)

    if livekit_cls is None:
        raise AudioSessionUnavailableError(
            "Installed gllm-inference does not expose LiveKitRealtimeSession. "
            "Upgrade gllm-inference to a version that includes "
            "`gllm_inference.realtime_session.LiveKitRealtimeSession`."
        )

    if base_cls is not None and not issubclass(livekit_cls, base_cls):
        raise AudioSessionUnavailableError("LiveKitRealtimeSession does not implement BaseRealtimeSession")

    return livekit_cls


class LiveKitRealtimeAudioSession:
    """Bridge class for provider=`livekit_realtime`."""

    def __init__(self, config: AudioSessionConfig) -> None:
        """Initialize the LiveKit realtime audio session wrapper.

        Args:
            config (AudioSessionConfig): Session configuration including provider and provider config.

        Returns:
            None: This initializer returns None.
        """
        provider = (config.provider or "").strip().lower()
        if provider != "livekit_realtime":
            raise AudioConfigError(
                f"LiveKitRealtimeAudioSession requires provider='livekit_realtime' "
                f"(got provider={config.provider!r})"
            )

        self._config = config
        self._close_event = asyncio.Event()
        self._session: Any | None = None
        self._run_task: asyncio.Task[Any] | None = None

    def _resolve_livekit_config(self) -> LiveKitConfig:
        cfg = self._config.provider_config
        if isinstance(cfg, LiveKitConfig):
            return cfg
        if isinstance(cfg, dict):
            url = cfg.get("url")
            if not url:
                raise AudioConfigError("livekit_realtime.url is required")
            return LiveKitConfig(
                url=str(url),
                api_key=cfg.get("api_key"),
                api_secret=cfg.get("api_secret"),
                room_name=cfg.get("room_name"),
                identity=cfg.get("identity"),
            )
        raise AudioConfigError("provider_config must be LiveKitConfig or dict")

    async def start(self, aip_agent: Any, *, instructions: str) -> None:
        """Start gllm-inference LiveKitRealtimeSession in a background task.

        Note:
            This provider adapts the transport/session layer only. The `aip_agent`
            and `instructions` parameters are currently ignored by the underlying
            gllm-inference LiveKit realtime session API.
        """
        del aip_agent, instructions

        if self._run_task is not None and not self._run_task.done():
            raise AudioConfigError("LiveKitRealtimeAudioSession is already started")

        lk_cfg = self._resolve_livekit_config()
        session_cls = _resolve_gllm_livekit_realtime_cls()
        self._close_event.clear()

        self._session = session_cls(
            url=lk_cfg.url,
            api_key=lk_cfg.resolve_api_key(),
            api_secret=lk_cfg.resolve_api_secret(),
            room_name=lk_cfg.room_name,
            identity=lk_cfg.identity,
        )

        async def _run() -> None:
            try:
                await self._session.start()
            finally:
                self._close_event.set()

        self._run_task = asyncio.create_task(_run())
        await asyncio.sleep(0)
        if self._run_task.done():
            err = self._run_task.exception()
            if err is not None:
                raise err

    async def stop(self) -> None:
        """Stop background run task."""
        task = self._run_task
        if task is None:
            self._close_event.set()
            return

        if not task.done():
            task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        self._run_task = None
        self._session = None
        self._close_event.set()

    async def wait_closed(self) -> None:
        """Wait for session termination."""
        await self._close_event.wait()
