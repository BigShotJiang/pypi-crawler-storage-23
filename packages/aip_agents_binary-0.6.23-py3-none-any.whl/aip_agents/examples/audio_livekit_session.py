"""[DEMO] LiveKit voice session backed by an AIP agent.

Run (from python/aip-agents):
  poetry run python -m aip_agents.examples.audio_livekit_session
"""

from __future__ import annotations

import asyncio
import os
from contextlib import suppress

from dotenv import find_dotenv, load_dotenv
from langgraph.checkpoint.memory import MemorySaver

from aip_agents.agent import LangGraphReactAgent
from aip_agents.audio_interface import (
    AudioIOConfig,
    AudioModelConfig,
    AudioSessionConfig,
    LiveKitConfig,
    create_audio_session,
)
from aip_agents.schema.step_limit import StepLimitConfig
from aip_agents.tools.web_search.serper_tool import GoogleSerperTool


def main() -> None:
    """Run the LiveKit audio demo session."""
    dotenv_path = find_dotenv(usecwd=True)
    if dotenv_path:
        load_dotenv(dotenv_path)

    try:
        max_steps = int(os.environ.get("AIP_AUDIO_MAX_STEPS", "8"))
    except ValueError:
        max_steps = 8

    agent = LangGraphReactAgent(
        name="AIP",
        instruction=(
            "You are AIP, the GDPLabs-native AI Agent.\n"
            "\n"
            "You are running in a LiveKit voice session: user speech is transcribed to text and provided to you.\n"
            "Treat incoming messages as the user's voice (do not claim you 'can't hear audio').\n"
            "\n"
            "You have access to a web search tool (`google_serper`) for up-to-date info when needed.\n"
            "\n"
            "For responsiveness in voice mode, do at most 2 tool calls per user turn. "
            "If results are insufficient, ask one focused follow-up question.\n"
            "\n"
            "When asked about your identity, say you are AIP."
        ),
        model="openai/gpt-5-mini",
        tools=[GoogleSerperTool()],
        step_limit_config=StepLimitConfig(max_steps=max_steps),
        checkpointer=MemorySaver(),
    )

    livekit_url = os.environ.get("LIVEKIT_URL")
    livekit_api_key = os.environ.get("LIVEKIT_API_KEY")
    livekit_api_secret = os.environ.get("LIVEKIT_API_SECRET")
    livekit_room_name = os.environ.get("LIVEKIT_ROOM_NAME")
    livekit_identity = os.environ.get("LIVEKIT_IDENTITY") or "aip-agent"

    missing = [
        name
        for name, value in (
            ("LIVEKIT_URL", livekit_url),
            ("LIVEKIT_API_KEY", livekit_api_key),
            ("LIVEKIT_API_SECRET", livekit_api_secret),
            ("LIVEKIT_ROOM_NAME", livekit_room_name),
            ("SERPER_API_KEY", os.environ.get("SERPER_API_KEY")),
        )
        if not value
    ]
    if missing:
        raise SystemExit(
            "Missing required env vars for LiveKit demo: "
            f"{', '.join(missing)}.\n\n"
            "Fix: set them in `python/aip-agents/.env` (recommended) or export them."
        )

    audio_cfg = AudioSessionConfig(
        provider="livekit",
        io=AudioIOConfig(input_enabled=True, output_enabled=True),
        model=AudioModelConfig(provider="openai", voice=os.environ.get("OPENAI_TTS_VOICE") or "echo"),
        provider_config=LiveKitConfig(
            url=str(livekit_url),
            api_key=str(livekit_api_key),
            api_secret=str(livekit_api_secret),
            room_name=str(livekit_room_name),
            identity=str(livekit_identity),
        ),
    )

    session = create_audio_session(audio_cfg)

    async def _run() -> None:
        await session.start(agent, instructions=agent.instruction)
        try:
            await session.wait_closed()
        finally:
            # Ensure we shut down LiveKit/HTTP contexts before the loop closes.
            with suppress(Exception):
                await asyncio.shield(session.stop())

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        # asyncio.run() will cancel the main task; cleanup happens in _run()'s finally.
        return


if __name__ == "__main__":
    main()
