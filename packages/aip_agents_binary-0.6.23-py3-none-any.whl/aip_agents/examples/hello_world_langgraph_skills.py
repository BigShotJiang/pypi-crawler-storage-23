"""Hello world LangGraph example with prompt-only skills.

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

import asyncio
from typing import Any

from langchain_openai import ChatOpenAI

from aip_agents.agent import LangGraphReactAgent

_SKILL_SOURCE = "https://github.com/coreyhaines31/marketingskills/tree/main/skills/copywriting"


def _format_response(response: Any) -> str:
    """Format the response output for printing.

    Args:
        response (Any): Response returned by LangGraphReactAgent.arun.

    Returns:
        str: Best-effort string representation of the response.
    """
    if isinstance(response, dict):
        for key in ("output", "content", "text"):
            value = response.get(key)
            if isinstance(value, str) and value.strip():
                return value
        return str(response)
    return str(response)


async def langgraph_example() -> None:
    """Demonstrate LangGraphReactAgent with prompt-only skills (Milestone 1)."""
    model = ChatOpenAI(model="gpt-5-mini", temperature=0)
    agent_name = "LangGraphHelloWorldSkillsAgent"

    langgraph_agent = LangGraphReactAgent(
        name=agent_name,
        instruction="You are a helpful assistant.",
        model=model,
        skills=_SKILL_SOURCE,  # Can also accept an array of strings or Skill objects.
    )

    query = "Draft landing page copy for PulsePath, a habit-tracking app for runners that turns streaks into medals."
    print(f"--- Agent: {agent_name} ---")
    print(f"Query: {query}")

    print("\nRunning arun...")
    response = await langgraph_agent.arun(
        query=query,
        configurable={"configurable": {"thread_id": "lgraph_skills_example_arun"}},
    )
    print(f"[arun] Final Response: {_format_response(response)}")
    print("--- End of LangGraph Skills Example ---")


if __name__ == "__main__":
    # OPENAI_API_KEY should be set in the environment.
    asyncio.run(langgraph_example())
