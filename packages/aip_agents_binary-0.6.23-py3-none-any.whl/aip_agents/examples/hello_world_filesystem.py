"""Hello World example demonstrating filesystem capabilities.

This example shows how to use the filesystem middleware with LangGraphReactAgent
to read and search files. The agent can use read_file and grep_file tools to
analyze file contents.

Prerequisites:
    - OPENAI_API_KEY environment variable set
    - aip-agents installed

Usage:
    export OPENAI_API_KEY=your-key
    python hello_world_filesystem.py
"""

from __future__ import annotations

import os

from aip_agents.agent import LangGraphReactAgent
from aip_agents.middleware.backends.in_memory import InMemoryBackend


def create_sample_files(backend: InMemoryBackend) -> None:
    """Create sample files for the agent to read.

    Args:
        backend: The filesystem backend to write files to.
    """
    # Create a simple configuration file
    config_content = """# Application Configuration

[database]
host = localhost
port = 5432
name = myapp_db

[api]
endpoint = https://api.example.com
version = v1
timeout = 30

[logging]
level = INFO
format = json
"""
    backend.write("/config/app.conf", config_content)

    # Create a log file with various entries
    log_content = """2024-01-15 10:00:00 INFO Application started
2024-01-15 10:00:01 INFO Connected to database
2024-01-15 10:00:05 WARN API response slow (2.5s)
2024-01-15 10:00:10 ERROR Failed to fetch user data
2024-01-15 10:00:15 INFO Retrying connection...
2024-01-15 10:00:20 INFO Connection successful
2024-01-15 10:01:00 INFO Processing batch job #1234
2024-01-15 10:02:30 WARN Memory usage at 75%
2024-01-15 10:05:00 INFO Batch job completed successfully
"""
    backend.write("/logs/app.log", log_content)

    # Create a notes file
    notes_content = """# Project Notes

## TODO
- Review pull request #42
- Update documentation
- Fix failing tests

## Ideas
- Add caching layer for API responses
- Implement rate limiting
- Add metrics collection

## Meeting Notes (2024-01-15)
Discussed:
- Q1 roadmap priorities
- Resource allocation
- Technical debt reduction
"""
    backend.write("/docs/notes.md", notes_content)


def main() -> None:
    """Run the filesystem hello world example."""
    # Check for API key
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY environment variable not set")
        print("Please set it with: export OPENAI_API_KEY=your-key")
        return

    print("=" * 60)
    print("Filesystem Hello World Example")
    print("=" * 60)

    # Create backend with sample files
    backend = InMemoryBackend()
    create_sample_files(backend)
    print("\nCreated sample files:")
    print("  - /config/app.conf")
    print("  - /logs/app.log")
    print("  - /docs/notes.md")

    # Create agent with filesystem middleware
    print("\nCreating agent with filesystem=True...")
    agent = LangGraphReactAgent(
        name="filesystem_demo",
        instruction="""You are a helpful assistant with filesystem access.

You have access to these filesystem tools:
- read_file: Read the contents of a file
- grep_file: Search for patterns in files

Use these tools to help users analyze file contents.
Always be concise and helpful.""",
        model="openai/gpt-5-nano",
        filesystem=True,
    )

    # Test 1: Read a configuration file
    print("\n" + "-" * 60)
    print("Test 1: Read configuration file")
    print("-" * 60)
    query1 = "Read the configuration file at /config/app.conf and tell me the database port."
    print(f"Query: {query1}")
    response1 = agent.run(query1)
    print(f"Response: {response1.get('output', 'No output')}")

    # Test 2: Search for errors in log file
    print("\n" + "-" * 60)
    print("Test 2: Search for errors in log file")
    print("-" * 60)
    query2 = "Search for ERROR entries in /logs/app.log and summarize what went wrong."
    print(f"Query: {query2}")
    response2 = agent.run(query2)
    print(f"Response: {response2.get('output', 'No output')}")

    # Test 3: Read and analyze notes
    print("\n" + "-" * 60)
    print("Test 3: Read and analyze notes")
    print("-" * 60)
    query3 = "Read /docs/notes.md and list all the TODO items."
    print(f"Query: {query3}")
    response3 = agent.run(query3)
    print(f"Response: {response3.get('output', 'No output')}")

    # Test 4: Combined search across files
    print("\n" + "-" * 60)
    print("Test 4: Search for specific term")
    print("-" * 60)
    query4 = "Search for 'api' in /config/app.conf and tell me what API-related settings exist."
    print(f"Query: {query4}")
    response4 = agent.run(query4)
    print(f"Response: {response4.get('output', 'No output')}")

    print("\n" + "=" * 60)
    print("Filesystem demo completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
