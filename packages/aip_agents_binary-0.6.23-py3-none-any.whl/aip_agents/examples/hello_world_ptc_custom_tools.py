"""Minimal PTC hello world example with custom tools.

Author: Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)

Required environment variables:
- OPENAI_API_KEY
- E2B_API_KEY
"""

import asyncio
import json
from pathlib import Path

from langchain_openai import ChatOpenAI

from aip_agents.agent import LangGraphReactAgent
from aip_agents.examples.tools.multiply_tool import MultiplyTool
from aip_agents.ptc import PromptConfig, PTCCustomToolConfig, PTCSandboxConfig, file_tool, package_tool
from aip_agents.tools.time_tool import TimeTool


async def main() -> None:
    """Run a hello-world PTC flow with custom tools."""
    repo_root = Path.cwd()
    multiply_tool_path = repo_root / "aip_agents/examples/tools/multiply_tool.py"

    instruction = (
        "You are a helpful assistant with access to execute_ptc_code. "
        "Use execute_ptc_code to run Python and print output. "
        "Custom tools are available under tools.custom (import with "
        "'from tools.custom import <tool_name>')."
    )

    agent = LangGraphReactAgent(
        name="ptc_custom_tools_hello_world",
        instruction=instruction,
        model=ChatOpenAI(model="gpt-5.2"),
        tools=[TimeTool(), MultiplyTool()],
        tool_configs={"multiply": {"offset": 20}},
        ptc_config=PTCSandboxConfig(
            enabled=True,
            sandbox_timeout=180.0,
            prompt=PromptConfig(mode="auto"),
            custom_tools=PTCCustomToolConfig(
                enabled=True,
                bundle_roots=[str(repo_root)],
                requirements=[],
                tools=[
                    package_tool(
                        "time_tool",
                        import_path="aip_agents.tools.time_tool",
                        class_name="TimeTool",
                    ),
                    file_tool(
                        "multiply",
                        file_path=str(multiply_tool_path),
                        class_name="MultiplyTool",
                    ),
                ],
            ),
        ),
    )

    try:
        # Pass tool config at runtime via metadata
        # The multiply tool will use offset=10, so multiply(a=6, b=7) returns 6*7+10=52
        print("execute_ptc_code output: ", end="")
        last_chunk = None
        async for chunk in agent.arun_sse_stream(
            query=("Use execute_ptc_code to import from tools.custom. Print time_tool() and multiply(a=6, b=7)."),
            metadata={"tool_configs": {"multiply": {"offset": 10}}},
        ):
            last_chunk = chunk
            print(json.dumps(chunk))
            print("-" * 20)
    finally:
        await agent.cleanup()

    print("execute_ptc_code output: ", last_chunk["content"])


if __name__ == "__main__":
    asyncio.run(main())
