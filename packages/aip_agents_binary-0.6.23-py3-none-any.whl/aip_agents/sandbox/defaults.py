"""Defaults for PTC sandbox templates and packages."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from aip_agents.mcp.client.base_mcp_client import BaseMCPClient
    from aip_agents.ptc.custom_tools import PTCCustomToolConfig

DEFAULT_PTC_TEMPLATE = "aip-agents-ptc-v1"
AIP_AGENTS_BINARY_LOCAL = "aip-agents-binary[local]"
DEFAULT_PTC_PACKAGES: tuple[str, ...] = (
    AIP_AGENTS_BINARY_LOCAL,
    "mcp",
    "httpx",
    "gllm-plugin-binary==0.0.7",
)


def _has_mcp_tools(mcp_client: BaseMCPClient | None) -> bool:
    """Check if MCP tools are present.

    Args:
        mcp_client: The MCP client to check.

    Returns:
        True if MCP client has servers configured.
    """
    return mcp_client is not None and bool(getattr(mcp_client, "servers", None))


def _has_custom_tools(custom_tools_config: PTCCustomToolConfig | None) -> bool:
    """Check if custom tools are present and enabled.

    Args:
        custom_tools_config: The custom tools configuration to check.

    Returns:
        True if custom tools are enabled and tools list is non-empty.
    """
    return custom_tools_config is not None and custom_tools_config.enabled and bool(custom_tools_config.tools)


def _has_native_aip_tools(custom_tools_config: PTCCustomToolConfig | None) -> bool:
    """Check if native AIP tools are present.

    Native AIP tools are package-based custom tools with import_path starting with "aip_agents.tools.".

    Args:
        custom_tools_config: The custom tools configuration to check.

    Returns:
        True if at least one native AIP tool is found.
    """
    if not _has_custom_tools(custom_tools_config):
        return False

    assert custom_tools_config is not None
    for tool in custom_tools_config.tools:
        if tool.get("kind") == "package":
            import_path = tool.get("import_path", "")
            if import_path.startswith("aip_agents.tools."):
                return True

    return False


def _merge_requirements(packages: list[str], requirements: list[str]) -> None:
    """Merge requirements into packages list, avoiding duplicates.

    Args:
        packages: Target list to merge into (modified in place).
        requirements: Requirements to merge.
    """
    for req in requirements:
        if req not in packages:
            packages.append(req)


def _merge_custom_requirements(
    packages: list[str],
    custom_tools_config: PTCCustomToolConfig | None,
) -> None:
    """Merge custom tool requirements into packages list.

    Args:
        packages: Target list to merge into (modified in place).
        custom_tools_config: Custom tools configuration.
    """
    if not _has_custom_tools(custom_tools_config):
        return

    assert custom_tools_config is not None
    if custom_tools_config.requirements:
        _merge_requirements(packages, custom_tools_config.requirements)


def _packages_for_default_template(
    custom_tools_config: PTCCustomToolConfig | None,
    user_ptc_packages: list[str] | None,
) -> list[str] | None:
    """Build package list when using the default template.

    Args:
        custom_tools_config: Custom tools configuration.
        user_ptc_packages: Explicitly provided packages by user (None if not set).

    Returns:
        List of packages to install, or None to skip installation.
    """
    packages = list(user_ptc_packages) if user_ptc_packages is not None else []
    _merge_custom_requirements(packages, custom_tools_config)
    return packages if packages else None


def _packages_for_other_templates(
    *,
    mcp_client: BaseMCPClient | None,
    custom_tools_config: PTCCustomToolConfig | None,
    user_ptc_packages: list[str] | None,
) -> list[str] | None:
    """Build package list when using a non-default template.

    Args:
        mcp_client: The MCP client (check if has servers for MCP tools).
        custom_tools_config: Custom tools configuration.
        user_ptc_packages: Explicitly provided packages by user (None if not set).

    Returns:
        List of packages to install, or None to skip installation.
    """
    packages = list(user_ptc_packages) if user_ptc_packages is not None else []
    base_packages = _build_base_packages(mcp_client=mcp_client, custom_tools_config=custom_tools_config)
    _merge_requirements(packages, base_packages)
    _merge_custom_requirements(packages, custom_tools_config)
    return packages if packages else None


def _build_base_packages(
    *,
    mcp_client: BaseMCPClient | None,
    custom_tools_config: PTCCustomToolConfig | None,
) -> list[str]:
    """Build base package list based on tool types.

    Args:
        mcp_client: The MCP client (check if has servers for MCP tools).
        custom_tools_config: Custom tools configuration.

    Returns:
        List of base packages needed for the tool types present.
    """
    packages: list[str] = []

    if _has_mcp_tools(mcp_client):
        packages.extend(["mcp", "httpx"])

    if _has_custom_tools(custom_tools_config):
        packages.extend(["langchain", "gllm-plugin-binary==0.0.7"])

    if _has_native_aip_tools(custom_tools_config):
        if AIP_AGENTS_BINARY_LOCAL not in packages:
            packages.append(AIP_AGENTS_BINARY_LOCAL)

    return packages


def select_sandbox_packages(
    *,
    mcp_client: BaseMCPClient | None,
    custom_tools_config: PTCCustomToolConfig | None,
    template: str | None,
    user_ptc_packages: list[str] | None,
) -> list[str] | None:
    """Select minimal packages to install in sandbox based on tool types.

    This function implements the smart package selection logic:
    - DEFAULT_PTC_TEMPLATE + no user packages: Skip install (template has all deps)
    - DEFAULT_PTC_TEMPLATE + user packages: User packages + PTCCustomToolConfig.requirements
    - Other template + no user packages: Build packages from tool types
    - Other template + user packages: User packages + tool-type packages + PTCCustomToolConfig.requirements

    Key principle: Tools won't work without their required packages. Always ensure:
    - MCP tools → mcp + httpx installed
    - Custom LangChain tools → langchain + gllm-plugin-binary installed
    - Native AIP tools → aip-agents-binary[local] installed

    Args:
        mcp_client: The MCP client (check if has servers for MCP tools).
        custom_tools_config: Custom tools configuration (includes tools list and .requirements field).
        template: Sandbox template being used.
        user_ptc_packages: Explicitly provided packages by user (None if not set).

    Returns:
        List of packages to install, or None to skip installation.
    """
    if template == DEFAULT_PTC_TEMPLATE:
        return _packages_for_default_template(custom_tools_config, user_ptc_packages)

    return _packages_for_other_templates(
        mcp_client=mcp_client,
        custom_tools_config=custom_tools_config,
        user_ptc_packages=user_ptc_packages,
    )
