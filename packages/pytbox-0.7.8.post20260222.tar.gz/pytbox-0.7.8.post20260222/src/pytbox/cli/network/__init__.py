"""Network CLI command group."""

from .commands import network_group

__all__ = ["network_group"]

