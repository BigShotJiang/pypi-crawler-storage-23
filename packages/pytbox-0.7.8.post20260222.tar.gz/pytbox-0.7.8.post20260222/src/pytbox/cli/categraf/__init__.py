"""
Categraf CLI 模块
"""

from .commands import categraf_group

__all__ = ['categraf_group']
