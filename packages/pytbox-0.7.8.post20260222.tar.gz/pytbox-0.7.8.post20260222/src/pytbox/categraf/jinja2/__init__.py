"""
Categraf Jinja2 模板文件包
"""

# 这个文件确保 jinja2 目录被 Python 识别为包
# 这样模板文件就会被包含在安装包中
