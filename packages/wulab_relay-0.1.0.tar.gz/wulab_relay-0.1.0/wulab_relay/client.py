"""Relay client: bridges WebSocket commands to local SSH."""
import asyncio
import json
import shlex
import sys
from typing import Optional

import asyncssh
import websockets

RECONNECT_BASE = 1
RECONNECT_MAX = 60


class RelayClient:
    """Connects to WuLab backend via WebSocket and proxies SSH commands."""

    def __init__(
        self,
        ws_url: str,
        ssh_host: str,
        ssh_port: int,
        ssh_user: str,
        ssh_password: Optional[str] = None,
        ssh_key: Optional[str] = None,
    ):
        self.ws_url = ws_url
        self.ssh_host = ssh_host
        self.ssh_port = ssh_port
        self.ssh_user = ssh_user
        self.ssh_password = ssh_password
        self.ssh_key = ssh_key
        self._ssh_conn: Optional[asyncssh.SSHClientConnection] = None

    async def _connect_ssh(self) -> asyncssh.SSHClientConnection:
        """Establish SSH connection to local cluster."""
        kwargs: dict = {
            "host": self.ssh_host,
            "port": self.ssh_port,
            "username": self.ssh_user,
            "known_hosts": None,
        }
        if self.ssh_key:
            kwargs["client_keys"] = [asyncssh.import_private_key(self.ssh_key)]
        elif self.ssh_password:
            kwargs["password"] = self.ssh_password
        return await asyncssh.connect(**kwargs)

    async def _ensure_ssh(self) -> asyncssh.SSHClientConnection:
        """Get or create SSH connection."""
        if self._ssh_conn is None or self._ssh_conn.is_closed():
            self._ssh_conn = await self._connect_ssh()
        return self._ssh_conn

    async def _handle_run_command(self, data: dict) -> dict:
        """Execute a command via SSH and return the result."""
        request_id = data["request_id"]
        command = data["command"]
        try:
            conn = await self._ensure_ssh()
            result = await asyncio.wait_for(conn.run(command, check=False), timeout=25)
            return {
                "type": "result",
                "request_id": request_id,
                "stdout": result.stdout or "",
                "stderr": result.stderr or "",
                "exit_code": result.exit_status or 0,
            }
        except Exception as e:
            return {
                "type": "result",
                "request_id": request_id,
                "stdout": "",
                "stderr": str(e),
                "exit_code": -1,
            }

    async def _handle_read_file(self, data: dict) -> dict:
        """Read a file via SSH and return its content."""
        request_id = data["request_id"]
        path = data["path"]
        try:
            conn = await self._ensure_ssh()
            result = await conn.run(f"cat {shlex.quote(path)}", check=False)
            if result.exit_status != 0:
                return {
                    "type": "file_content",
                    "request_id": request_id,
                    "content": None,
                    "error": result.stderr or f"Exit code {result.exit_status}",
                }
            return {
                "type": "file_content",
                "request_id": request_id,
                "content": result.stdout or "",
                "error": None,
            }
        except Exception as e:
            return {
                "type": "file_content",
                "request_id": request_id,
                "content": None,
                "error": str(e),
            }

    async def _handle_write_file(self, data: dict) -> dict:
        """Write content to a file via SSH."""
        request_id = data["request_id"]
        path = data["path"]
        content = data["content"]
        try:
            conn = await self._ensure_ssh()
            result = await conn.run(
                f"cat > {shlex.quote(path)}",
                input=content,
                check=False,
            )
            if result.exit_status != 0:
                return {
                    "type": "write_result",
                    "request_id": request_id,
                    "success": False,
                    "error": result.stderr or f"Exit code {result.exit_status}",
                }
            return {
                "type": "write_result",
                "request_id": request_id,
                "success": True,
                "error": None,
            }
        except Exception as e:
            return {
                "type": "write_result",
                "request_id": request_id,
                "success": False,
                "error": str(e),
            }

    async def _dispatch_command(self, ws, data: dict):
        """Handle a single command and send the response."""
        msg_type = data.get("type")
        handler = {
            "run_command": self._handle_run_command,
            "read_file": self._handle_read_file,
            "write_file": self._handle_write_file,
        }.get(msg_type)
        if handler:
            response = await handler(data)
            await ws.send(json.dumps(response))

    async def run(self):
        """Main loop: connect WebSocket, handle commands, reconnect on failure."""
        backoff = RECONNECT_BASE

        while True:
            try:
                # Test SSH first
                print("正在连接本地集群...", end=" ", flush=True)
                conn = await self._connect_ssh()
                self._ssh_conn = conn
                result = await conn.run("echo ok", check=False)
                if result.stdout.strip() != "ok":
                    print("失败")
                    print(f"SSH 连接异常: {result.stderr}")
                    sys.exit(1)
                print("✓")

                # Connect WebSocket
                print("正在连接 WuLab 云端...", end=" ", flush=True)
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=20,
                    ping_timeout=10,
                ) as ws:
                    # Wait for auth_ok
                    auth_resp = json.loads(await ws.recv())
                    if auth_resp.get("type") != "auth_ok":
                        print("失败")
                        reason = auth_resp.get("reason", auth_resp)
                        print(f"认证失败: {reason}")
                        print("Token 可能已过期，请重新获取。")
                        sys.exit(1)

                    print("✓")
                    print("⟳ 中继就绪，等待指令... (Ctrl+C 退出)")
                    backoff = RECONNECT_BASE

                    async for message in ws:
                        data = json.loads(message)
                        msg_type = data.get("type")

                        if msg_type == "ping":
                            await ws.send(json.dumps({"type": "pong"}))
                            continue

                        # Dispatch command concurrently so we don't block on slow SSH ops
                        asyncio.create_task(self._dispatch_command(ws, data))

            except websockets.ConnectionClosed as e:
                # Code 4001 = auth failure (expired token) — don't retry
                if e.code == 4001:
                    print(f"\n认证失败 (token 已过期或无效)，请重新获取 token。")
                    sys.exit(1)
                print(f"\n连接断开，{backoff}秒后重连...")
            except ConnectionRefusedError:
                print(f"\n无法连接服务器，{backoff}秒后重连...")
            except Exception as e:
                print(f"\n错误: {e}，{backoff}秒后重连...")
            finally:
                # Clean up SSH connection on disconnect
                if self._ssh_conn and not self._ssh_conn.is_closed():
                    self._ssh_conn.close()
                    self._ssh_conn = None

            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, RECONNECT_MAX)
