"""CLI entry point for wulab-relay."""
import argparse
import asyncio
import getpass
import re
import sys

from .client import RelayClient


def parse_ssh_command(ssh_cmd: str) -> dict:
    """Parse SSH command string into host, port, user."""
    port_match = re.search(r'-p\s+(\d+)', ssh_cmd)
    port = int(port_match.group(1)) if port_match else 22
    user_host = re.search(r'(\w+)@([\d.]+|[\w.-]+)', ssh_cmd)
    if not user_host:
        print("Error: cannot parse user@host from SSH command")
        sys.exit(1)
    return {"user": user_host.group(1), "host": user_host.group(2), "port": port}


def main():
    parser = argparse.ArgumentParser(
        description="WuLab Relay — bridge your local cluster to WuLab cloud"
    )
    parser.add_argument("--token", required=True, help="JWT auth token (from browser)")
    parser.add_argument("--server-id", required=True, help="Server ID (from WuLab UI)")
    parser.add_argument(
        "--server-url",
        default="wss://www.wulabllm.com/api/relay/ws",
        help="WuLab WebSocket URL (default: wss://www.wulabllm.com/api/relay/ws)",
    )
    args = parser.parse_args()

    print("WuLab Relay v0.1.0")
    print("─" * 40)

    # Interactive SSH setup
    ssh_cmd = input("SSH 命令: ").strip()
    if not ssh_cmd:
        print("Error: SSH command required")
        sys.exit(1)

    parsed = parse_ssh_command(ssh_cmd)
    print(f"  → {parsed['user']}@{parsed['host']}:{parsed['port']}")

    # Ask for credential
    credential = getpass.getpass("SSH 密码: ").strip()
    if not credential:
        print("Error: credential required")
        sys.exit(1)

    is_key = credential.startswith("-----BEGIN")

    client = RelayClient(
        ws_url=f"{args.server_url}?token={args.token}&server_id={args.server_id}",
        ssh_host=parsed["host"],
        ssh_port=parsed["port"],
        ssh_user=parsed["user"],
        ssh_password=None if is_key else credential,
        ssh_key=credential if is_key else None,
    )

    try:
        asyncio.run(client.run())
    except KeyboardInterrupt:
        print("\n中继已停止")


if __name__ == "__main__":
    main()
