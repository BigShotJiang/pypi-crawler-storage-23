"""tmux-pane-mover: drag-and-drop tmux pane rearranger."""

__version__ = "0.1.0"
