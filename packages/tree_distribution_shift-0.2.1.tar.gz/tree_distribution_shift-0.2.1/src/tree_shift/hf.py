from __future__ import annotations

from typing import List, Optional

from datasets import get_dataset_config_names

from .constants import HF_REPO_ID


def list_configs(
    repo_id: str = HF_REPO_ID, revision: Optional[str] = None
) -> List[str]:
    """List available configs from the HF dataset repo (no data download)."""
    return get_dataset_config_names(repo_id, revision=revision)
