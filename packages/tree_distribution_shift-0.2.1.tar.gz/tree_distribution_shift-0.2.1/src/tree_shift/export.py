from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Union

import orjson
from datasets import load_dataset
from tqdm import tqdm

from .constants import DEFAULT_SPLITS, HF_REPO_ID


class _SplitStats:
    """Track statistics for a single split export."""
    def __init__(self):
        self.images = 0
        self.skipped = 0
        self.annotations = 0


def _normalize_categories(raw_categories: Any) -> list[dict]:
    """Normalize category payloads to COCO-compliant list[dict]."""
    normalized: list[dict] = []

    if isinstance(raw_categories, dict):
        # Handle shapes like {"1": "tree"}.
        for k, v in raw_categories.items():
            try:
                cid = int(k)
            except (TypeError, ValueError):
                continue
            name = str(v)
            normalized.append(
                {"id": cid, "name": name, "supercategory": name}
            )
        return normalized

    if not isinstance(raw_categories, list):
        return normalized

    for c in raw_categories:
        if not isinstance(c, dict):
            # Ignore invalid entries (e.g., stray strings).
            continue
        if "id" not in c or "name" not in c:
            continue
        try:
            cid = int(c["id"])
        except (TypeError, ValueError):
            continue
        name = str(c["name"])
        normalized.append(
            {
                "id": cid,
                "name": name,
                "supercategory": str(c.get("supercategory", name)),
            }
        )
    return normalized


def _normalize_annotations(raw_annos: Any, image_id: int, start_ann_id: int) -> tuple[list[dict], int]:
    """Normalize annotation payloads to COCO-compliant dicts."""
    if not isinstance(raw_annos, list):
        return [], start_ann_id

    normalized: list[dict] = []
    ann_id = start_ann_id
    for a in raw_annos:
        if not isinstance(a, dict):
            continue
        bbox = a.get("bbox", [0.0, 0.0, 0.0, 0.0])
        if not isinstance(bbox, list) or len(bbox) != 4:
            continue
        try:
            x, y, w, h = [float(v) for v in bbox]
        except (TypeError, ValueError):
            continue
        try:
            cat_id = int(a.get("category_id", 1))
        except (TypeError, ValueError):
            cat_id = 1

        area = a.get("area", w * h)
        try:
            area = float(area)
        except (TypeError, ValueError):
            area = float(w * h)

        iscrowd = a.get("iscrowd", 0)
        try:
            iscrowd = int(iscrowd)
        except (TypeError, ValueError):
            iscrowd = 0

        normalized.append(
            {
                "id": ann_id,
                "image_id": int(image_id),
                "category_id": cat_id,
                "bbox": [x, y, w, h],
                "area": area,
                "iscrowd": 1 if iscrowd else 0,
            }
        )
        ann_id += 1
    return normalized, ann_id


def _validate_coco_payload(categories: list[dict], annotations: list[dict]) -> None:
    """Fail fast when payload is not COCO-compliant."""
    if not isinstance(categories, list):
        raise ValueError("COCO categories must be a list.")
    if not all(isinstance(c, dict) and "id" in c and "name" in c for c in categories):
        raise ValueError("COCO categories must be list[dict] containing id and name.")
    if not all(isinstance(a.get("category_id"), int) for a in annotations):
        raise ValueError("All annotations must have integer category_id.")

    category_ids = {int(c["id"]) for c in categories}
    anno_category_ids = {int(a["category_id"]) for a in annotations}
    if not anno_category_ids.issubset(category_ids):
        raise ValueError(
            "Annotation category_id values must be a subset of category ids."
        )


def _export_split_iter(ds: Iterable[dict], out_dir: Path, split_name: str) -> _SplitStats:
    """Stream a single split to COCO format on disk.

    Resume-safe: images that already exist on disk are skipped.
    The COCO annotation JSON is always regenerated so it stays
    consistent with the full set of images.
    """
    images_dir = out_dir / split_name / "images"
    ann_dir = out_dir / split_name / "annotations"
    images_dir.mkdir(parents=True, exist_ok=True)
    ann_dir.mkdir(parents=True, exist_ok=True)

    images: list[dict] = []
    annotations: list[dict] = []
    categories: list[dict] | None = None
    ann_id = 1

    stats = _SplitStats()

    for ex in ds:
        stats.images += 1
        if stats.images % 500 == 0:
            tqdm.write(f"[{split_name}] processed {stats.images} images ({stats.skipped} skipped)...")

        image_id = int(ex["image_id"])
        filename = ex["filename"]
        width = int(ex["width"])
        height = int(ex["height"])

        # Resume-safe: skip writing if the image already exists on disk
        img_path = images_dir / filename
        if img_path.exists():
            stats.skipped += 1
        else:
            img_path.write_bytes(ex["image_bytes"])

        images.append(
            {"id": image_id, "file_name": filename, "width": width, "height": height}
        )

        annos = orjson.loads(ex["coco_annotations"].encode("utf-8"))
        if categories is None:
            raw_categories = orjson.loads(ex["coco_categories"].encode("utf-8"))
            categories = _normalize_categories(raw_categories)

        normalized_annos, ann_id = _normalize_annotations(annos, image_id, ann_id)
        annotations.extend(normalized_annos)

    stats.annotations = len(annotations)

    categories = categories or []

    # If this is a single-class export, force canonical tree category.
    if len(categories) == 1:
        canonical_id = 1
        source_id = int(categories[0]["id"])
        categories = [{"id": canonical_id, "name": "tree", "supercategory": "tree"}]
        for a in annotations:
            if int(a["category_id"]) == source_id:
                a["category_id"] = canonical_id
            else:
                a["category_id"] = canonical_id

    # If categories are missing, fallback to single-class tree and map all annos.
    if not categories:
        categories = [{"id": 1, "name": "tree", "supercategory": "tree"}]
        for a in annotations:
            a["category_id"] = 1

    # Ensure annotation category ids are valid category ids.
    category_ids = {int(c["id"]) for c in categories}
    if len(category_ids) == 1:
        only_id = next(iter(category_ids))
        for a in annotations:
            if int(a["category_id"]) not in category_ids:
                a["category_id"] = only_id

    _validate_coco_payload(categories, annotations)

    coco = {
        "images": images,
        "annotations": annotations,
        "categories": categories,
    }
    (ann_dir / f"instances_{split_name}.json").write_bytes(orjson.dumps(coco))
    tqdm.write(
        f"[{split_name}] done — {stats.images} images ({stats.skipped} skipped), "
        f"{stats.annotations} annotations"
    )

    return stats


def export_coco(
    config: str,
    out_root: Union[str, Path],
    repo_id: str = HF_REPO_ID,
    splits: Optional[List[str]] = None,
    revision: Optional[str] = None,
    streaming: bool = True,
) -> Path:
    """
    Export a HF config to COCO folders.

    Writes to: <out_root>/<config>/<split>/{images, annotations}
    Also writes <out_root>/<config>/manifest.json with export metadata.
    """
    out_root = Path(out_root)
    out_dir = out_root / config
    out_dir.mkdir(parents=True, exist_ok=True)

    if splits is None:
        splits = DEFAULT_SPLITS

    split_counts: Dict[str, Any] = {}

    for split in splits:
        tqdm.write(f"Exporting split '{split}' for config '{config}' ...")
        ds = load_dataset(
            repo_id,
            config,
            split=split,
            streaming=streaming,
            revision=revision,
        )
        stats = _export_split_iter(ds, out_dir, split)
        split_counts[split] = {
            "images": stats.images,
            "annotations": stats.annotations,
        }

    # Write manifest.json
    manifest = {
        "repo_id": repo_id,
        "config": config,
        "revision": revision,
        "splits": splits,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "counts": split_counts,
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_bytes(orjson.dumps(manifest, option=orjson.OPT_INDENT_2))
    tqdm.write(f"Manifest written to {manifest_path}")

    return out_dir
