from __future__ import annotations

import argparse
import logging
import os
import sys

import datasets
import huggingface_hub

from .constants import DEFAULT_SPLITS, HF_REPO_ID
from .export import export_coco
from .hf import list_configs
from . import __version__


def _setup_token(token: str | None) -> None:
    """Authenticate with HF Hub if a token is provided, otherwise print a hint."""
    # Suppress the noisy "unauthenticated requests" warning from huggingface_hub
    logging.getLogger("huggingface_hub.utils._auth").setLevel(logging.ERROR)

    if token:
        huggingface_hub.login(token=token, add_to_git_credential=False)
    elif not huggingface_hub.utils.get_token():
        print(
            "Tip: set HF_TOKEN for higher rate limits "
            "(export HF_TOKEN=... or run: huggingface-cli login)",
            file=sys.stderr,
        )


def _doctor() -> int:
    """Print diagnostic information."""
    token = huggingface_hub.utils.get_token()
    print(f"tree-distribution-shift version: {__version__}")
    print(f"datasets version: {datasets.__version__}")
    print(f"huggingface_hub version: {huggingface_hub.__version__}")
    print(f"HF_TOKEN: {'set' if token else 'not set'}")
    print(f"HF_HUB_ENABLE_HF_TRANSFER: {os.environ.get('HF_HUB_ENABLE_HF_TRANSFER', 'not set')}")
    print(f"HF_HOME: {os.environ.get('HF_HOME', 'not set (using default ~/.cache/huggingface)')}")
    print(f"Default repo id: {HF_REPO_ID}")
    print(f"Python version: {sys.version}")
    return 0


def main() -> None:
    ap = argparse.ArgumentParser(prog="tree-shift")
    sub = ap.add_subparsers(dest="cmd", required=True)

    # ── list ──────────────────────────────────────────────────────────
    ls = sub.add_parser("list", help="List available configs from the Hub")
    ls.add_argument("--repo", default=HF_REPO_ID)
    ls.add_argument("--revision", default=None)
    ls.add_argument("--token", default=None, help="HF Hub token (or set HF_TOKEN env var)")

    # ── export ────────────────────────────────────────────────────────
    ex = sub.add_parser("export", help="Export a config to COCO on disk")
    ex.add_argument("--repo", default=HF_REPO_ID)
    ex.add_argument("--config", required=True)
    ex.add_argument("--out", required=True)
    ex.add_argument("--revision", default=None)
    ex.add_argument("--splits", nargs="*", default=DEFAULT_SPLITS)
    ex.add_argument("--no-streaming", action="store_true")
    ex.add_argument("--token", default=None, help="HF Hub token (or set HF_TOKEN env var)")

    # ── doctor ───────────────────────────────────────────────────────
    sub.add_parser("doctor", help="Print diagnostic info for debugging")

    args = ap.parse_args()

    if args.cmd == "doctor":
        return _doctor()

    _setup_token(getattr(args, "token", None))

    if args.cmd == "list":
        for c in list_configs(repo_id=args.repo, revision=args.revision):
            print(c)
        return

    if args.cmd == "export":
        export_coco(
            repo_id=args.repo,
            config=args.config,
            out_root=args.out,
            splits=args.splits,
            revision=args.revision,
            streaming=(not args.no_streaming),
        )
        return
