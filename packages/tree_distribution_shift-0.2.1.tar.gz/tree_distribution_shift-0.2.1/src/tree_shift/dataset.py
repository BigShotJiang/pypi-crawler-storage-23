from __future__ import annotations

import io
import json
from typing import Any, Dict, List, Optional, Tuple

import torch
from datasets import load_dataset
from PIL import Image
from torch.utils.data import Dataset

from .constants import DEFAULT_SPLITS, HF_REPO_ID, METADATA_FIELDS, SPLIT_DESCRIPTIONS
from .evaluator import COCODetectionEvaluator


def _parse_json_field(value):
    """Parse a JSON-encoded field that may be a str or already decoded."""
    if isinstance(value, str):
        parsed = json.loads(value)
        # Handle double-encoded JSON
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        return parsed
    return value


class TreeShiftDataset:
    """Top-level dataset object for a single benchmark config.

    Mirrors the WILDS ``get_dataset`` / ``get_subset`` workflow.
    Downloading and caching are handled by HuggingFace Datasets.

    Parameters
    ----------
    config : str
        Config name (e.g. ``"intl_train_IN__ood_US"``).
    download : bool
        If *True* (default) the dataset is downloaded when not cached.
        If *False* and the data is not cached, an error is raised.
    root_dir : str | None
        Custom HuggingFace cache directory.  Defaults to ``~/.cache/huggingface``.
    """

    def __init__(
        self,
        config: str,
        download: bool = True,
        root_dir: Optional[str] = None,
    ) -> None:
        self._config = config
        self._root_dir = root_dir

        download_mode = None if download else "reuse_cache_if_exists"

        self._hf = load_dataset(
            HF_REPO_ID,
            config,
            cache_dir=root_dir,
            download_mode=download_mode,
        )

        self._split_names = [s for s in DEFAULT_SPLITS if s in self._hf]

        raw_cats = _parse_json_field(
            self._hf[self._split_names[0]][0]["coco_categories"]
        )
        self._categories: List[Dict[str, Any]] = [
            c for c in raw_cats if isinstance(c, dict) and "id" in c
        ]
        self._cat_id_to_idx = {c["id"]: i for i, c in enumerate(self._categories)}

        self._metadata_fields = METADATA_FIELDS
        self._metadata_encoders: Dict[str, Dict[str, int]] = {f: {} for f in METADATA_FIELDS}
        self._metadata_decoders: Dict[str, List[str]] = {f: [] for f in METADATA_FIELDS}
        self._build_metadata_maps()

        self._evaluator = COCODetectionEvaluator()

    # ------------------------------------------------------------------
    # Metadata encoding
    # ------------------------------------------------------------------

    def _build_metadata_maps(self) -> None:
        """Scan all splits to build integer encodings for categorical metadata."""
        unique: Dict[str, set] = {f: set() for f in self._metadata_fields}
        for split in self._split_names:
            ds = self._hf[split]
            for field in self._metadata_fields:
                if field in ds.column_names:
                    unique[field].update(ds.unique(field))

        for field in self._metadata_fields:
            sorted_vals = sorted(v for v in unique[field] if v is not None)
            self._metadata_encoders[field] = {v: i for i, v in enumerate(sorted_vals)}
            self._metadata_decoders[field] = sorted_vals

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def config_name(self) -> str:
        return self._config

    @property
    def n_classes(self) -> int:
        return len(self._categories)

    @property
    def categories(self) -> List[Dict[str, Any]]:
        return list(self._categories)

    @property
    def metadata_fields(self) -> List[str]:
        return list(self._metadata_fields)

    @property
    def metadata_map(self) -> Dict[str, List[str]]:
        """Mapping from field name to ordered list of string values.

        ``metadata_map[field][int_code]`` gives the original string.
        """
        return dict(self._metadata_decoders)

    @property
    def split_names(self) -> List[str]:
        return list(self._split_names)

    @property
    def split_descriptions(self) -> Dict[str, str]:
        return {s: SPLIT_DESCRIPTIONS.get(s, s) for s in self._split_names}

    def get_subset(
        self,
        split: str,
        transform=None,
    ) -> "TreeShiftSubset":
        """Return a PyTorch :class:`Dataset` for *split*.

        Parameters
        ----------
        split : str
            One of ``"train"``, ``"val"``, or ``"ood_test"``.
        transform : callable | None
            A torchvision-style transform applied to the PIL image.
        """
        if split not in self._hf:
            raise ValueError(
                f"Split '{split}' not found in config '{self._config}'. "
                f"Available: {list(self._hf.keys())}"
            )
        return TreeShiftSubset(
            dataset=self,
            hf_split=self._hf[split],
            split_name=split,
            transform=transform,
        )

    def eval(
        self,
        y_pred: List[Dict[str, torch.Tensor]],
        y_true: List[Dict[str, torch.Tensor]],
        metadata: Optional[torch.Tensor] = None,
    ) -> Dict[str, float]:
        """Evaluate predictions using COCO mAP metrics.

        Parameters
        ----------
        y_pred : list[dict]
            Per-image predictions. Each dict has ``"boxes"`` ``[N, 4]``,
            ``"scores"`` ``[N]``, and ``"labels"`` ``[N]``.
        y_true : list[dict]
            Per-image ground truth. Each dict has ``"boxes"`` ``[N, 4]``,
            ``"labels"`` ``[N]``, and ``"image_id"`` (int).
        metadata : Tensor | None
            ``[B, M]`` integer-encoded metadata (unused for global metrics,
            reserved for future per-group evaluation).
        """
        return self._evaluator.evaluate(y_pred, y_true)

    def __repr__(self) -> str:
        splits_info = ", ".join(
            f"{s}={len(self._hf[s])}" for s in self._split_names
        )
        return (
            f"TreeShiftDataset(config='{self._config}', "
            f"classes={self.n_classes}, splits=[{splits_info}])"
        )


class TreeShiftSubset(Dataset):
    """A PyTorch :class:`~torch.utils.data.Dataset` wrapping one split.

    Each item is a ``(image, target, metadata)`` triple:

    * **image** – PIL Image (or transformed tensor).
    * **target** – dict with ``boxes`` ``[N, 4]`` (xyxy), ``labels`` ``[N]``,
      ``area`` ``[N]``, ``image_id`` (int).
    * **metadata** – ``LongTensor[M]`` of integer-encoded categorical fields.
    """

    def __init__(
        self,
        dataset: TreeShiftDataset,
        hf_split,
        split_name: str,
        transform=None,
    ) -> None:
        self._dataset = dataset
        self._data = hf_split
        self._split_name = split_name
        self.transform = transform

    # ------------------------------------------------------------------
    # Dataset interface
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._data)

    def __getitem__(self, idx: int) -> Tuple[Any, Dict[str, Any], torch.Tensor]:
        example = self._data[idx]

        image = Image.open(io.BytesIO(example["image_bytes"])).convert("RGB")

        target = self._parse_target(example)

        metadata = self._encode_metadata(example)

        if self.transform is not None:
            image = self.transform(image)

        return image, target, metadata

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def split_name(self) -> str:
        return self._split_name

    @property
    def metadata_fields(self) -> List[str]:
        return self._dataset.metadata_fields

    @property
    def dataset(self) -> TreeShiftDataset:
        return self._dataset

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse_target(self, example: dict) -> Dict[str, Any]:
        """Convert COCO annotations to torchvision detection format."""
        annos = _parse_json_field(example["coco_annotations"])
        image_id = int(example["image_id"])

        if not annos:
            return {
                "boxes": torch.zeros((0, 4), dtype=torch.float32),
                "labels": torch.zeros((0,), dtype=torch.int64),
                "area": torch.zeros((0,), dtype=torch.float32),
                "image_id": image_id,
            }

        boxes = []
        labels = []
        areas = []

        for a in annos:
            x, y, w, h = a["bbox"]
            boxes.append([x, y, x + w, y + h])
            cat_idx = self._dataset._cat_id_to_idx.get(a["category_id"], 0)
            labels.append(cat_idx)
            areas.append(a.get("area", w * h))

        return {
            "boxes": torch.as_tensor(boxes, dtype=torch.float32),
            "labels": torch.as_tensor(labels, dtype=torch.int64),
            "area": torch.as_tensor(areas, dtype=torch.float32),
            "image_id": image_id,
        }

    def _encode_metadata(self, example: dict) -> torch.Tensor:
        """Return a LongTensor of integer-encoded metadata fields."""
        codes = []
        for field in self._dataset._metadata_fields:
            val = example.get(field, "")
            code = self._dataset._metadata_encoders[field].get(val, -1)
            codes.append(code)
        return torch.tensor(codes, dtype=torch.long)

    def __repr__(self) -> str:
        return (
            f"TreeShiftSubset(config='{self._dataset.config_name}', "
            f"split='{self._split_name}', n={len(self)})"
        )


def get_dataset(
    config: str,
    download: bool = True,
    root_dir: Optional[str] = None,
) -> TreeShiftDataset:
    """Load a Tree Distribution Shift benchmark config.

    This is the main entry point, mirroring ``wilds.get_dataset()``.

    Parameters
    ----------
    config : str
        Config name (e.g. ``"intl_train_IN__ood_US"``).
        Run :func:`tree_shift.list_configs` to see all options.
    download : bool
        Allow downloading from HuggingFace Hub (default *True*).
    root_dir : str | None
        Custom HuggingFace cache directory.

    Returns
    -------
    TreeShiftDataset
    """
    return TreeShiftDataset(config=config, download=download, root_dir=root_dir)
