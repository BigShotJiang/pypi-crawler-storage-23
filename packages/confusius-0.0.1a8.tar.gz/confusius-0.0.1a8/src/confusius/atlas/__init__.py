"""Brain atlas integration via BrainGlobe."""

from confusius.atlas.atlas import Atlas

__all__ = ["Atlas"]
