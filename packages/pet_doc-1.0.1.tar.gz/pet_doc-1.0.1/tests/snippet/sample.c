#include <stdio.h>

/**
 * snippet sample
 this is a sample snip.pet content...
 * end snippet
 */
main(int argc, char *argv[]){


}