# Snip.pet Demonstration



Here is the content of the snippet:

1 this is a sample snip.pet content...

This is after the snip.pet included.

Note that the dot had to be included in the word snip.pet for two reasons:

1. Emphasize it is part of PET (just kidding)
2. W/o the dot in it the script tries to process this files and makes an error.
Try it.