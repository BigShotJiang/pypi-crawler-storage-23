from pet.cli import main

main()
