#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier"
__version__ = "2.0.0"
