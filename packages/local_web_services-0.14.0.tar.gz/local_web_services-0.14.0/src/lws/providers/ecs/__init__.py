"""ECS service provider for LDK."""
