"""Mock server provider for LWS — mock external HTTP/GraphQL/gRPC services."""

from lws.providers.mockserver.provider import MockServerProvider

__all__ = ["MockServerProvider"]
