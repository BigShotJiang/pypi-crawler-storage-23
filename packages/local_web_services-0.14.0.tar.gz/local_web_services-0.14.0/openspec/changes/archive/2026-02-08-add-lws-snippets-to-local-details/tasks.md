## 1. Implementation
- [x] 1.1 Update `_build_local_details` in `src/lws/cli/main.py` to generate `lws` CLI snippets for each resource type
- [x] 1.2 Update `tests/unit/cli/test_display.py` to assert `lws` snippets in local details
