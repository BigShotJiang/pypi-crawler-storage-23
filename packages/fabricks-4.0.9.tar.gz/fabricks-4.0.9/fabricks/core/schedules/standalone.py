from fabricks.core.schedules.dags import standalone

__all__ = ["standalone"]
