from abc import abstractmethod
from functools import partial

from pyspark.sql import DataFrame

from fabricks.context import IS_TYPE_WIDENING
from fabricks.context.log import DEFAULT_LOGGER
from fabricks.core.jobs.base.exception import (
    PostRunCheckException,
    PostRunCheckWarning,
    PostRunInvokeException,
    PreRunCheckException,
    PreRunCheckWarning,
    PreRunInvokeException,
    SchemaDriftException,
    SkipRunCheckWarning,
    SkipRunTimeWarning,
)
from fabricks.core.jobs.base.invoker import Invoker
from fabricks.models import JobBronzeOptions, JobSilverOptions
from fabricks.utils.write import write_stream


class Processor(Invoker):
    def filter_where(self, df: DataFrame) -> DataFrame:
        assert isinstance(self.options, (JobBronzeOptions, JobSilverOptions))

        f = self.options.filter_where
        if f:
            DEFAULT_LOGGER.debug(f"filter where {f}", extra={"label": self})
            df = df.where(f"{f}")

        return df

    def restore(self, last_version: str | None = None, last_batch: str | None = None):
        """
        Restores the processor to a specific version and batch.

        Args:
            last_version (Optional[str]): The last version to restore to. If None, no version restore will be performed.
            last_batch (Optional[str]): The last batch to restore to. If None, no batch restore will be performed.
        """
        if self.persist:
            if last_version is not None:
                _last_version = int(last_version)
                if self.table.get_last_version() > _last_version:
                    self.table.restore_to_version(_last_version)

            if last_batch is not None:
                current_batch = int(last_batch) + 1
                self.rm_commit(current_batch)

                assert last_batch == self.table.get_property("fabricks.last_batch")
                assert self.paths.to_commits.joinpath(last_batch).exists()

    def _for_each_batch(self, df: DataFrame, batch: int | None = None, **kwargs):
        DEFAULT_LOGGER.debug("start (for each batch)", extra={"label": self})
        if batch is not None:
            DEFAULT_LOGGER.debug(f"batch {batch}", extra={"label": self})

        df = self.base_transform(df)

        diffs = self.get_schema_differences(df)
        if diffs:
            if self.schema_drift or kwargs.get("reload", False):
                DEFAULT_LOGGER.warning("schema drifted", extra={"label": self, "diffs": diffs})
                self.update_schema(df=df)

            else:
                only_type_widening_compatible = all(d.type_widening_compatible for d in diffs if d.status == "changed")
                if only_type_widening_compatible and self.table.type_widening_enabled and IS_TYPE_WIDENING:
                    self.update_schema(df=df, widen_types=True)
                else:
                    raise SchemaDriftException.from_diffs(str(self), diffs)

        self.for_each_batch(df, batch, **kwargs)

        if batch is not None:
            self.table.set_property("fabricks.last_batch", batch)

        self.table.create_restore_point()
        DEFAULT_LOGGER.debug("end (for each batch)", extra={"label": self})

    def for_each_run(self, **kwargs):
        DEFAULT_LOGGER.debug("start (for each run)", extra={"label": self})

        if self.virtual:
            self.create_or_replace_view()

        elif self.persist:
            assert self.table.registered, f"{self} is not registered"

            df = self.get_data(stream=self.stream, **kwargs)
            assert df is not None, "no data"

            partial(self._for_each_batch, **kwargs)

            if self.stream:
                DEFAULT_LOGGER.debug("use streaming", extra={"label": self})
                write_stream(
                    df,
                    checkpoints_path=self.paths.to_checkpoints,
                    func=self._for_each_batch,
                    timeout=self.timeout,
                )
            else:
                self._for_each_batch(df, **kwargs)

        else:
            raise ValueError(f"{self.mode} - not allowed")

        DEFAULT_LOGGER.debug("end (for each run)", extra={"label": self})

    def run(
        self,
        retry: bool | None = True,
        schedule: str | None = None,
        schedule_id: str | None = None,
        invoke: bool | None = True,
        reload: bool | None = None,
        vacuum: bool | None = None,
        optimize: bool | None = None,
        compute_statistics: bool | None = None,
        **kwargs,
    ):
        """
        Run the processor.

        Args:
            retry (bool, optional): Whether to retry the execution in case of failure. Defaults to True.
            schedule (str, optional): The schedule to run the processor on. Defaults to None.
            schedule_id (str, optional): The ID of the schedule. Defaults to None.
            invoke (bool, optional): Whether to invoke pre-run and post-run methods. Defaults to True.
        """
        last_version = None
        last_batch = None
        exception = None

        if self.persist:
            last_version = self.table.get_property("fabricks.last_version")
            if last_version is not None:
                DEFAULT_LOGGER.debug(f"last version {last_version}", extra={"label": self})
            else:
                last_version = str(self.table.last_version)

            last_batch = self.table.get_property("fabricks.last_batch")
            if last_batch is not None:
                DEFAULT_LOGGER.debug(f"last batch {last_batch}", extra={"label": self})

        try:
            DEFAULT_LOGGER.info("start (run)", extra={"label": self})

            if reload:
                DEFAULT_LOGGER.debug("force reload", extra={"label": self})

            if not reload:
                self.check_run_before()
                self.check_run_after()

                self.check_skip_run()

            if invoke:
                self.invoke_pre_run(schedule=schedule)

            try:
                self.check_pre_run()
            except PreRunCheckWarning as e:
                exception = e

            self.for_each_run(schedule=schedule, reload=reload)

            try:
                self.check_post_run()
            except PostRunCheckWarning as e:
                exception = e

            self.check_post_run_extra()

            if invoke:
                self.invoke_post_run(schedule=schedule)

            if exception:
                raise exception

            if vacuum is None:
                vacuum = self.options.vacuum if self.options and self.options.vacuum is not None else False
            if optimize is None:
                optimize = self.options.optimize if self.options and self.options.optimize is not None else False
            if compute_statistics is None:
                compute_statistics = (
                    self.options.compute_statistics
                    if self.options and self.options.compute_statistics is not None
                    else False
                )

            if vacuum or optimize or compute_statistics:
                self.maintain(
                    compute_statistics=compute_statistics,
                    optimize=optimize,
                    vacuum=vacuum,
                )

            DEFAULT_LOGGER.info("end (run)", extra={"label": self})

        except SkipRunCheckWarning as e:
            DEFAULT_LOGGER.warning("skip run", extra={"label": self})
            raise e

        except SkipRunTimeWarning as e:
            DEFAULT_LOGGER.warning("fail to pass time check", extra={"label": self})
            raise e

        except (PreRunCheckWarning, PostRunCheckWarning) as e:
            DEFAULT_LOGGER.warning("fail to pass warning check", extra={"label": self})
            raise e

        except (PreRunInvokeException, PostRunInvokeException) as e:
            DEFAULT_LOGGER.exception("fail to run invoker", extra={"label": self})
            raise e

        except (PreRunCheckException, PostRunCheckException) as e:
            DEFAULT_LOGGER.exception("fail to pass check", extra={"label": self})
            self.restore(last_version, last_batch)
            raise e

        except AssertionError as e:
            DEFAULT_LOGGER.exception("fail to run", extra={"label": self})
            self.restore(last_version, last_batch)
            raise e

        except Exception as e:
            if not self.stream or not retry:
                DEFAULT_LOGGER.exception("fail to run", extra={"label": self})
                self.restore(last_version, last_batch)
                raise e

            else:
                DEFAULT_LOGGER.warning("retry to run", extra={"label": self})
                self.run(retry=False, schedule_id=schedule_id, schedule=schedule)

    @abstractmethod
    def overwrite(self) -> None: ...
