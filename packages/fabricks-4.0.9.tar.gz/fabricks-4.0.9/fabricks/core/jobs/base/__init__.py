from fabricks.core.jobs.base.job import BaseJob

__all__ = ["BaseJob"]
