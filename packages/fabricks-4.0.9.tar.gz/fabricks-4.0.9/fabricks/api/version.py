import importlib.metadata

FABRICKS_VERSION = importlib.metadata.version("fabricks")

__all__ = ["FABRICKS_VERSION"]
