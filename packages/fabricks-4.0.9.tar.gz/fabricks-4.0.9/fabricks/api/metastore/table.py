from fabricks.metastore import Table

__all__ = ["Table"]
