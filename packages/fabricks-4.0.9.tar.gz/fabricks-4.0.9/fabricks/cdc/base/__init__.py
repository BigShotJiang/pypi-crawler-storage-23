from fabricks.cdc.base.cdc import BaseCDC

__all__ = ["BaseCDC"]
