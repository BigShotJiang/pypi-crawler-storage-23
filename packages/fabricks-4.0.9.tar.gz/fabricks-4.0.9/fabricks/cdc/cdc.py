from fabricks.cdc.base import BaseCDC


class CDC(BaseCDC):
    pass
