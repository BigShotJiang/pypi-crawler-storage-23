"""Path-based security guards — prevent agent from reading/writing credential files."""

import os
from pathlib import Path

_HOME = Path.home()

# Denied path prefixes (resolved, no trailing slash)
_DENIED_PREFIXES = [
    str(_HOME / ".ssh"),
    str(_HOME / ".aws"),
    str(_HOME / ".gnupg"),
]

# Denied exact files (resolved)
_DENIED_FILES = [
    str(_HOME / ".fliiq" / ".env"),
    str(_HOME / ".fliiq" / "google_tokens.json"),
    str(_HOME / ".fliiq" / "daemon.secret"),
]


def check_path_allowed(path: str) -> None:
    """Raise PermissionError if the path points to a protected credential location.

    Resolves symlinks and normalizes before checking.
    """
    resolved = os.path.realpath(os.path.expanduser(path))

    # Check exact file matches
    for denied in _DENIED_FILES:
        if resolved == denied:
            raise PermissionError(
                f"Access denied: {path} is a protected credential file."
            )

    # Check prefix matches (entire directories)
    for prefix in _DENIED_PREFIXES:
        if resolved == prefix or resolved.startswith(prefix + os.sep):
            raise PermissionError(
                f"Access denied: {path} is inside a protected directory."
            )
