---
name: send_telegram
description: "Send a message via Telegram Bot API. Requires TELEGRAM_BOT_TOKEN environment variable."
---

Send a text message to a Telegram chat via the Bot API. Supports Markdown formatting.

Setup: Create a bot via @BotFather on Telegram, copy the token, and set TELEGRAM_BOT_TOKEN in your .env file. The chat_id is the numeric ID of the user or group to message.
