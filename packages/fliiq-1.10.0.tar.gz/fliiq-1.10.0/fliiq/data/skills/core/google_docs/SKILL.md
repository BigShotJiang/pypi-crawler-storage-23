---
name: google_docs
description: "Manage Google Docs: create documents, read content, insert text, batch update formatting. Supports multiple Google accounts. Requires OAuth via `fliiq google auth`."
---

Use this tool to create and edit Google Docs documents. Supports reading document content, inserting text, and performing batch updates for complex formatting.

## Setup Required
1. Create a Google Cloud project at https://console.cloud.google.com/
2. Enable the Google Docs API
3. Create OAuth 2.0 credentials (Desktop app type), set redirect URI to http://localhost:8080/callback
4. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file
5. Run `fliiq google auth` to authorize each Google account

If you authorized before Docs support was added, run `fliiq google auth` again to grant Docs permissions.

## Available Actions
- create: Create a new blank document
- read: Read document content (returns plain text and raw structure)
- insert_text: Insert text at a specific position
- batch_update: Apply multiple structured updates (formatting, inserting, deleting)

## Batch Update Requests
The `requests` parameter accepts a list of Google Docs API request objects. Common ones:
- `{"insertText": {"location": {"index": 1}, "text": "Hello"}}`
- `{"deleteContentRange": {"range": {"startIndex": 1, "endIndex": 10}}}`
- `{"updateTextStyle": {"range": {...}, "textStyle": {"bold": true}, "fields": "bold"}}`

Max 100 requests per batch. All requests are applied atomically.

## Multi-Account
Use the `account_email` parameter to specify which Google account to use. Defaults to the first authorized account.
