---
name: google_calendar
description: "Manage Google Calendar: list calendars, list/create/update/delete events. Supports multiple Google accounts and shared calendars. Requires OAuth setup via `fliiq google auth`."
---

Use this tool to manage Google Calendar events. Supports listing available calendars (including shared ones), listing events, creating meetings with attendees and agendas, updating existing events, and deleting events.

## Setup Required
1. Create a Google Cloud project at https://console.cloud.google.com/
2. Enable the Google Calendar API
3. Create OAuth 2.0 credentials (Desktop app type), set redirect URI to http://localhost:8080/callback
4. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file
5. Run `fliiq google auth` to authorize each Google account you want to manage

## Available Actions
- list_calendars: Discover all accessible calendars (own, shared, subscribed)
- list_events: Fetch events in a time range (for checking schedule / finding availability)
- create_event: Create a new calendar event with optional attendees and agenda
- update_event: Modify an existing event (title, time, attendees, etc.)
- delete_event: Remove a calendar event

## Multi-Account
Run `fliiq google auth` once per Google account. Use the `calendar_account` parameter to specify which account to use. Defaults to the first authorized account.

## Shared Calendars
Use `list_calendars` to discover shared/secondary calendars, then pass the `calendar_id` parameter to target a specific calendar. Defaults to the primary calendar.
