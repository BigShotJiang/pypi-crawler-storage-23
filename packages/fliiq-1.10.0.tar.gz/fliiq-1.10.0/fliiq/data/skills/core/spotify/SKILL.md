---
name: spotify
description: "Create and manage Spotify playlists using the Spotify Web API."
---

Use this tool to create playlists, add tracks, and search for music on Spotify. Requires SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET, and SPOTIFY_ACCESS_TOKEN environment variables.

## Setup Required
1. Create a Spotify app at https://developer.spotify.com/dashboard
2. Set redirect URI to http://localhost:8888/callback
3. Get your Client ID and Client Secret
4. Get an access token with playlist-modify-public and playlist-modify-private scopes

## Available Actions
- create_playlist: Create a new playlist
- search_tracks: Search for tracks to add to playlists
- add_tracks_to_playlist: Add tracks to an existing playlist