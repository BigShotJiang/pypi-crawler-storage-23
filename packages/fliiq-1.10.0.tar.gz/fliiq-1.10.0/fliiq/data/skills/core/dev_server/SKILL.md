---
name: dev_server
description: "Start, stop, and manage background dev servers (Flask, npm, etc.)."
---

Manage background development servers. Use `start` to launch a server process,
`stop` to terminate it, `status` to check a specific server, and `list` to see
all tracked servers. Servers persist across tool calls within a session.
