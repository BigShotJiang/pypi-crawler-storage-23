---
name: write_file
description: "Create or overwrite a file with the given content."
---

Use this tool to write content to a file. Creates parent directories if they don't exist. Overwrites existing files.
