---
name: get_current_time
description: "Returns the current date and time in a specified timezone. Defaults to UTC if no timezone is provided."
---

Use this tool to get the current date and time. Supports IANA timezone identifiers like 'America/New_York', 'Europe/Paris', 'UTC'.
