"""
Tests for cloud inventory (obelisk) parsing - both ASE and ASA formats.
"""

import pytest
from pathlib import Path

from arkparser import CloudInventory


class TestASECloudInventory:
    """Tests for ASE cloud inventory parsing."""

    def test_load_ase_obelisk(self, ase_obelisk_path: Path) -> None:
        """ASE obelisk file should load successfully."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert inv is not None

    def test_ase_format_version(self, ase_obelisk_path: Path) -> None:
        """ASE obelisk should be detected as ASE format."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert not inv.is_asa

    def test_ase_has_creature(self, ase_obelisk_path: Path) -> None:
        """ASE obelisk should contain exactly 1 uploaded creature (Dodo)."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert inv.creature_count == 1

    def test_ase_creature_name(self, ase_obelisk_path: Path) -> None:
        """First creature in the ASE obelisk should be named Rex (case-insensitive)."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert inv.creature_count >= 1
        creature = inv.uploaded_creatures[0]
        assert creature.name.lower() == "rex"

    def test_ase_creature_level(self, ase_obelisk_path: Path) -> None:
        """The Dodo should be level 226."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert inv.creature_count >= 1
        creature = inv.uploaded_creatures[0]
        assert creature.level == 226

    def test_ase_has_items(self, ase_obelisk_path: Path) -> None:
        """ASE obelisk should contain at least 2 items (longneck + cryopod)."""
        inv = CloudInventory.load(ase_obelisk_path)
        assert inv.item_count >= 2

    def test_ase_item_has_blueprint(self, ase_obelisk_path: Path) -> None:
        """Uploaded items should have a non-empty blueprint path."""
        inv = CloudInventory.load(ase_obelisk_path)
        for item in inv.uploaded_items:
            assert isinstance(item.blueprint, str)
            assert len(item.blueprint) > 0

    def test_ase_longneck_is_mastercraft(self, ase_obelisk_path: Path) -> None:
        """The longneck rifle should be Mastercraft (quality_index=4)."""
        inv = CloudInventory.load(ase_obelisk_path)
        longneck = next(
            (i for i in inv.uploaded_items if "LongNeck" in i.blueprint or "RifleBase" in i.blueprint),
            None,
        )
        if longneck is not None:
            assert longneck.quality_index == 4
            assert longneck.quality_name == "Mastercraft"


class TestASACloudInventory:
    """Tests for ASA cloud inventory parsing."""

    def test_load_asa_obelisk(self, asa_obelisk_path: Path) -> None:
        """ASA obelisk file should load successfully."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv is not None

    def test_asa_format_version(self, asa_obelisk_path: Path) -> None:
        """ASA obelisk should be detected as ASA format."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv.is_asa

    def test_asa_has_creature(self, asa_obelisk_path: Path) -> None:
        """ASA obelisk should contain exactly 1 uploaded creature (Dodo)."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv.creature_count == 1

    def test_asa_creature_name(self, asa_obelisk_path: Path) -> None:
        """First creature in the ASA obelisk should be named Rex (case-insensitive)."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv.creature_count >= 1
        creature = inv.uploaded_creatures[0]
        assert creature.name.lower() == "rex"

    def test_asa_creature_level(self, asa_obelisk_path: Path) -> None:
        """The Dodo should be level 226."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv.creature_count >= 1
        creature = inv.uploaded_creatures[0]
        assert creature.level == 226

    def test_asa_has_items(self, asa_obelisk_path: Path) -> None:
        """ASA obelisk should contain at least 2 items (longneck + cryopod)."""
        inv = CloudInventory.load(asa_obelisk_path)
        assert inv.item_count >= 2

    def test_asa_item_has_blueprint(self, asa_obelisk_path: Path) -> None:
        """Uploaded items should have a non-empty blueprint path."""
        inv = CloudInventory.load(asa_obelisk_path)
        for item in inv.uploaded_items:
            assert isinstance(item.blueprint, str)
            assert len(item.blueprint) > 0

    def test_asa_longneck_is_mastercraft(self, asa_obelisk_path: Path) -> None:
        """The longneck rifle should be Mastercraft (quality_index=4)."""
        inv = CloudInventory.load(asa_obelisk_path)
        longneck = next(
            (i for i in inv.uploaded_items if "LongNeck" in i.blueprint or "RifleBase" in i.blueprint),
            None,
        )
        if longneck is not None:
            assert longneck.quality_index == 4
            assert longneck.quality_name == "Mastercraft"


class TestCloudInventoryStats:
    """Tests for creature stat parsing from obelisk files."""

    def test_ase_base_stats_object(self, ase_obelisk_path: Path) -> None:
        """Stats should return a DinoStats object."""
        from arkparser import DinoStats
        inv = CloudInventory.load(ase_obelisk_path)
        creature = inv.uploaded_creatures[0]
        assert isinstance(creature.stats, DinoStats)

    def test_asa_base_stats_object(self, asa_obelisk_path: Path) -> None:
        """Stats should return a DinoStats object."""
        from arkparser import DinoStats
        inv = CloudInventory.load(asa_obelisk_path)
        creature = inv.uploaded_creatures[0]
        assert isinstance(creature.stats, DinoStats)

    def test_ase_creature_stats_to_dict(self, ase_obelisk_path: Path) -> None:
        """to_dict should include all expected fields."""
        inv = CloudInventory.load(ase_obelisk_path)
        creature = inv.uploaded_creatures[0]
        d = creature.to_dict()
        assert "name" in d
        assert "level" in d
        assert "stats" in d

