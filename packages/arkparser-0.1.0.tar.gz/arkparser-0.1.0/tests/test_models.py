"""
Tests for model classes (CreatureStats, Location, MapConfig, etc.).
"""

import pytest

from arkparser.models import CreatureStats, Location
from arkparser.common.map_config import MapConfig, get_map_config, get_map_config_by_name, list_maps


class TestCreatureStats:
    """Tests for CreatureStats class."""

    def test_default_values(self) -> None:
        """Default stats should all be zero."""
        stats = CreatureStats()
        assert stats.health == 0
        assert stats.stamina == 0
        assert stats.torpidity == 0
        assert stats.oxygen == 0
        assert stats.food == 0
        assert stats.water == 0
        assert stats.temperature == 0
        assert stats.weight == 0
        assert stats.melee == 0
        assert stats.speed == 0
        assert stats.fortitude == 0
        assert stats.crafting == 0

    def test_from_array(self) -> None:
        """Test creating stats from a 12-element array."""
        points = [10, 20, 0, 5, 15, 0, 0, 30, 25, 0, 5, 0]
        stats = CreatureStats.from_array(points)

        assert stats.health == 10
        assert stats.stamina == 20
        assert stats.torpidity == 0
        assert stats.oxygen == 5
        assert stats.food == 15
        assert stats.weight == 30
        assert stats.melee == 25
        assert stats.fortitude == 5

    def test_from_short_array(self) -> None:
        """Short array should pad with zeros."""
        stats = CreatureStats.from_array([10, 20])
        assert stats.health == 10
        assert stats.stamina == 20
        assert stats.oxygen == 0
        assert stats.weight == 0

    def test_from_none(self) -> None:
        """None input should return all zeros."""
        stats = CreatureStats.from_array(None)
        assert stats.health == 0
        assert stats.total == 0

    def test_to_array(self) -> None:
        """to_array should round-trip correctly."""
        points = [10, 20, 0, 5, 15, 0, 0, 30, 25, 0, 5, 0]
        stats = CreatureStats.from_array(points)
        assert stats.to_array() == points

    def test_to_dict(self) -> None:
        """to_dict should include all 12 stat keys."""
        stats = CreatureStats.from_array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
        d = stats.to_dict()
        assert d["health"] == 1
        assert d["stamina"] == 2
        assert d["torpidity"] == 3
        assert d["oxygen"] == 4
        assert d["food"] == 5
        assert d["water"] == 6
        assert d["temperature"] == 7
        assert d["weight"] == 8
        assert d["melee"] == 9
        assert d["speed"] == 10
        assert d["fortitude"] == 11
        assert d["crafting"] == 12

    def test_total_excludes_torpidity(self) -> None:
        """Total should exclude torpidity (index 2) and some other minor stats."""
        stats = CreatureStats.from_array([1, 1, 999, 1, 1, 1, 0, 1, 1, 1, 0, 0])
        # Total only sums: health, stamina, oxygen, food, water, weight, melee, speed
        assert stats.total == 8


class TestLocation:
    """Tests for Location class."""

    def test_default_location(self) -> None:
        """Default location should be at origin."""
        loc = Location()
        assert loc.x == 0.0
        assert loc.y == 0.0
        assert loc.z == 0.0
        assert loc.pitch == 0.0
        assert loc.yaw == 0.0
        assert loc.roll == 0.0

    def test_no_gps_without_map(self) -> None:
        """Without a map config, GPS coords should be None."""
        loc = Location(x=100.0, y=200.0, z=300.0)
        assert loc.latitude is None
        assert loc.longitude is None

    def test_gps_with_map(self) -> None:
        """With a map config, GPS conversion should work."""
        map_config = MapConfig(
            name="Test",
            filename="test.ark",
            lat_shift=50.0,
            lat_div=8000.0,
            lon_shift=50.0,
            lon_div=8000.0,
        )
        # x=80000, y=0 → lat=50.0, lon=60.0
        loc = Location(x=80000.0, y=0.0, z=0.0).with_map(map_config)
        assert loc.latitude == 50.0  # lat_shift + (0 / 8000)
        assert loc.longitude == 60.0  # lon_shift + (80000 / 8000)

    def test_ccc_property(self) -> None:
        """ccc should return space-separated x y z string."""
        loc = Location(x=1.0, y=2.0, z=3.0)
        assert loc.ccc == "1.0 2.0 3.0"

    def test_with_map_returns_new_instance(self) -> None:
        """with_map() should not mutate the original."""
        original = Location(x=1.0, y=2.0, z=3.0)
        mc = MapConfig("Test", "test.ark")
        mapped = original.with_map(mc)
        assert original._map_config is None
        assert mapped._map_config is mc

    def test_to_dict_includes_gps(self) -> None:
        """to_dict should include lat/lon when map config is present."""
        mc = MapConfig("Test", "test.ark", 50.0, 8000.0, 50.0, 8000.0)
        loc = Location(x=0.0, y=0.0, z=0.0).with_map(mc)
        d = loc.to_dict()
        assert "x" in d
        assert "y" in d
        assert "z" in d
        assert "lat" in d
        assert "lon" in d

    def test_to_dict_no_gps(self) -> None:
        """to_dict should not include lat/lon without map config."""
        loc = Location(x=1.0, y=2.0, z=3.0)
        d = loc.to_dict()
        assert "lat" not in d
        assert "lon" not in d


class TestMapConfig:
    """Tests for MapConfig and lookup functions."""

    def test_get_map_config_known(self) -> None:
        """Known map filename should return correct config."""
        cfg = get_map_config("theisland.ark")
        assert cfg.name == "The Island (Evolved)"
        assert cfg.lat_div == 8000.0

    def test_get_map_config_case_insensitive(self) -> None:
        """Filename lookup should be case-insensitive."""
        cfg = get_map_config("TheIsland.ARK")
        assert cfg.name == "The Island (Evolved)"

    def test_get_map_config_unknown(self) -> None:
        """Unknown filename should return default config."""
        cfg = get_map_config("unknown_map.ark")
        assert cfg.name == "Unknown"

    def test_get_map_config_by_name(self) -> None:
        """Partial name match should work."""
        cfg = get_map_config_by_name("Ragnarok")
        assert "Ragnarok" in cfg.name

    def test_list_maps_includes_asa(self) -> None:
        """list_maps should include ASA maps."""
        maps = list_maps()
        names = [m.name for m in maps]
        assert any("Ascended" in n for n in names)
        assert any("Evolved" in n for n in names)

    def test_ragnarok_gps_conversion(self) -> None:
        """Ragnarok should have larger divisors than The Island."""
        island = get_map_config("theisland.ark")
        ragnarok = get_map_config("ragnarok.ark")
        assert ragnarok.lat_div > island.lat_div

    def test_ue_to_gps_returns_tuple(self) -> None:
        """ue_to_gps should return (lat, lon) tuple."""
        mc = MapConfig("Test", "test.ark", 50.0, 8000.0, 50.0, 8000.0)
        lat, lon = mc.ue_to_gps(x=80000.0, y=0.0)
        assert lat == 50.0
        assert lon == 60.0
