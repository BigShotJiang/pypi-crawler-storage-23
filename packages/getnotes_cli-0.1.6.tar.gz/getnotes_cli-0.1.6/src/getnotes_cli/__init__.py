"""getnotes-cli — 得到笔记 CLI 下载工具"""

__version__ = "0.1.6"
