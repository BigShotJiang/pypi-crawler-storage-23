"""ORATS application entrypoints."""
