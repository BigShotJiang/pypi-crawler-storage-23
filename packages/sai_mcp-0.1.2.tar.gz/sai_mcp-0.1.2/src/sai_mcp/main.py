from sai_mcp.feishu_cloud_bitable_ops import create_bitable, create_table, list_tables, list_fields, add_records, query_records
from sai_mcp.feishu_user import search_user
from sai_mcp.feishu_cloud_file_ops import *
import sys
import io
import json
import traceback
# MCP imports
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# if __name__ == "__main__":
#     parser = argparse.ArgumentParser()
#     subparsers = parser.add_subparsers(title='子命令', dest='subcommand')
#
#     # 上传子命令
#     upload_parser = subparsers.add_parser('upload', help='上传文件')
#     upload_parser.add_argument('src', help='要上传的文件路径')
#     upload_parser.add_argument('dst', help='飞书云文档目录token')
#
#     # 创建目录
#     create_parser = subparsers.add_parser('mkdir', help='创建目录')
#     create_parser.add_argument('name', help='目录名称')
#     create_parser.add_argument('-p', '--parent', help='父目录token')
#
#     # 列出目录下所有文件及子目录
#     list_parser = subparsers.add_parser('ls', help='列出目录下所有文件及子目录')
#     list_parser.add_argument('-f', '--folder', help='目录名称')
#
#     # 获取根目录token
#     root_token_parser = subparsers.add_parser('root', help='获取根目录token')
#
#     # 根据关键字搜索目录（最多三层）
#     search_doc_parser = subparsers.add_parser('search-dir', help='根据关键字搜索目录（最多三层）')
#     search_doc_parser.add_argument('name', help='目录名称')
#
#     # 根据关键字搜索文档
#     search_doc_parser = subparsers.add_parser('search-doc', help='根据关键字搜索文档（不包含目录）')
#     search_doc_parser.add_argument('query', help='查询关键字')
#     search_doc_parser.add_argument('-l', '--limit', help='返回条数')
#
#     # 下载文件
#     download_parser = subparsers.add_parser('download', help='下载云文档到指定路径')
#     download_parser.add_argument('token', help='云文档token')
#     download_parser.add_argument('path', help='本地路径')
#
#     # 导出文件
#     create_export_parser = subparsers.add_parser('export-create', help='创建导出文件任务')
#     create_export_parser.add_argument('token', help='云文档token')
#     create_export_parser.add_argument('doc_type', help='云文档类型')
#     create_export_parser.add_argument('file_extension', help='导出成本地文档的后缀')
#     create_export_parser.add_argument('--sub-id', help='电子表格工作表的 ID 或多维表格数据表的 ID')
#
#     query_export_parser = subparsers.add_parser('export-query', help='查询导出任务状态')
#     query_export_parser.add_argument('ticket', help='导出任务id')
#     query_export_parser.add_argument('token', help='云文档token')
#
#     download_export_parser = subparsers.add_parser('export-download', help='下载导出文件')
#     download_export_parser.add_argument('file_token', help='导出文件token')
#     download_export_parser.add_argument('download_path', help='下载路径')
#
#     # 新建docx文件
#     touch_parser = subparsers.add_parser('touch', help='新建docx文件')
#     touch_parser.add_argument('-ft', '--file-token', help='指定文档所在文件夹 的 Token。不传或传空表示根目录。')
#     touch_parser.add_argument('-t', '--title', help='文档标题')
#
#     args = parser.parse_args()
#     client = FeishuCloudClient()
#     if args.subcommand == 'upload':
#         # 上传文档
#         upload_file(client, args.src, parent_node_id=args.dst)
#     elif args.subcommand == 'mkdir':
#         # 创建目录
#         if args.parent:
#             create_folder(client, name=args.name, folder_token=args.parent)
#         else:
#             create_folder(client, name=args.name, folder_token='')
#     elif args.subcommand == 'ls':
#         if args.folder:
#             print(list_files(client, folder_token=args.folder))
#         else:
#             print(list_files(client))
#     elif args.subcommand == 'root':
#         print(get_root_token(client))
#     elif args.subcommand == 'search-doc':
#         print(search_documents(client, args.query, limit=args.limit))
#     elif args.subcommand == 'search-dir':
#         print(search_dir(client, args.name))
#     elif args.subcommand == 'download':
#         download_file(client, args.token, args.path)
#     elif args.subcommand == 'export-create':
#         print(create_export_task(client, file_extension=args.file_extension, token=args.token, doc_type=args.doc_type,
#                                  sub_id=args.sub_id))
#     elif args.subcommand == 'export-query':
#         print(query_export_task(client, ticket=args.ticket, token=args.token))
#     elif args.subcommand == 'export-download':
#         download_export(client, file_token=args.file_token, download_path=args.path)
#     elif args.subcommand == 'touch':
#         create_document(client, folder_token=args.file_token, title=args.title)

# 创建全局客户端实例
client = FeishuCloudClient()

# 创建 MCP 服务器
app = Server("feishu-cloud-doc", instructions="")


@app.list_tools()
async def list_tools() -> List[Tool]:
    """列出所有可用的工具"""
    return [
        Tool(
            name="get_root_token",
            description="获取飞书云盘根目录的 token",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="list_files",
            description="列出指定目录下的所有文件和子目录",
            inputSchema={
                "type": "object",
                "properties": {
                    "folder_token": {
                        "type": "string",
                        "description": "目录 token，不传则列出根目录"
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="create_folder",
            description="在指定目录下创建新目录",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "目录名称"
                    },
                    "folder_token": {
                        "type": "string",
                        "description": "父目录 token，为空表示在根目录创建"
                    }
                },
                "required": ["name"]
            }
        ),
        # Tool(
        #     name="delete_document",
        #     description="删除指定类型和 ID 的文档",
        #     inputSchema={
        #         "type": "object",
        #         "properties": {
        #             "document_id": {
        #                 "type": "string",
        #                 "description": "文档 ID"
        #             },
        #             "document_type": {
        #                 "type": "string",
        #                 "description": "文档类型：doc(文档)、sheet(表格)",
        #                 "enum": ["doc", "sheet"],
        #                 "default": "doc"
        #             }
        #         },
        #         "required": ["document_id"]
        #     }
        # ),
        Tool(
            name="upload_file",
            description="上传本地文件到飞书云盘",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "本地文件路径"
                    },
                    "parent_node_id": {
                        "type": "string",
                        "description": "父目录 ID"
                    },
                    "file_name": {
                        "type": "string",
                        "description": "自定义文件名，不传则使用原文件名"
                    }
                },
                "required": ["file_path", "parent_node_id"]
            }
        ),
        Tool(
            name="search_documents",
            description="根据关键词搜索文档",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索关键词"
                    },
                    "document_type": {
                        "type": "string",
                        "description": "文档类型过滤（可选）"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "返回结果数量限制",
                        "default": 20
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="search_dir",
            description="根据名称搜索目录（最多搜索三层）",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "目录名称"
                    }
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="download_file",
            description="下载云空间中的文件，如 PDF 文件。不包含飞书文档、电子表格以及多维表格等在线文档",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_token": {
                        "type": "string",
                        "description": "文件 token"
                    },
                    "download_path": {
                        "type": "string",
                        "description": "本地保存路径"
                    }
                },
                "required": ["file_token", "download_path"]
            }
        ),
        Tool(
            name="create_export_task",
            description="创建导出文件任务，将云文档导出为其他格式",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_extension": {
                        "type": "string",
                        "description": "将云文档导出为本地文件后，本地文件的扩展名，可选值有docx、pdf、xlsx、csv"
                    },
                    "token": {
                        "type": "string",
                        "description": "云文档 token"
                    },
                    "doc_type": {
                        "type": "string",
                        "description": "要导出的云文档的类型,可通过云文档的链接判断。可选值有sheet：飞书电子表格。支持导出扩展名为 xlsx 和 csv 的文件.bitable：飞书多维表格。支持导出扩展名为 xlsx 和 csv 格式的文件。docx：新版飞书文档。支持导出扩展名为 docx 和 pdf 格式的文件。"
                    },
                    "sub_id": {
                        "type": "string",
                        "description": "电子表格工作表 ID 或多维表格数据表 ID（可选）"
                    }
                },
                "required": ["file_extension", "token", "doc_type"]
            }
        ),
        Tool(
            name="query_export_task",
            description="查询导出文件任务的进度",
            inputSchema={
                "type": "object",
                "properties": {
                    "ticket": {
                        "type": "string",
                        "description": "导出任务 ID"
                    },
                    "token": {
                        "type": "string",
                        "description": "云文档 token"
                    }
                },
                "required": ["ticket", "token"]
            }
        ),
        Tool(
            name="download_export",
            description="下载导出的文件到本地",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_token": {
                        "type": "string",
                        "description": "导出文件 token"
                    },
                    "download_path": {
                        "type": "string",
                        "description": "本地保存路径"
                    }
                },
                "required": ["file_token", "download_path"]
            }
        ),
        Tool(
            name="search_user",
            description="通过用户名关键词搜索用户",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索关键词，通过传入的关键词搜索相匹配的用户名"
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="create_bitable",
            description="创建多维表格",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "多维表格App名称。最长为255个字符。"
                    },
                    "folder_token": {
                        "type": "string",
                        "description": "多维表格App归属文件夹。默认为空，表示多维表格将被创建在云空间根目录。"
                    }
                    ,
                    "time_zone": {
                        "type": "string",
                        "description": "文档时区,Asia/Shanghai"
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="create_table",
            description="在多维表格下新增一个数据表",
            inputSchema={
                "type": "object",
                "required": ["app_token"],
                "properties": {
                    "app_token": {
                        "type": "string",
                        "description": "多维表格App的唯一标识。URL中以feishu.cn/base开头时，取高亮部分；以feishu.cn/wiki开头时，需通过获取知识空间节点信息接口获取"
                    },
                    "name": {
                        "type": "string",
                        "description": "数据表名称。该字段必填，长度1-100字符，不允许包含/\\?*:[]等特殊字符，首尾空格会被去除"
                    },
                    "default_view_name": {
                        "type": "string",
                        "description": "默认表格视图的名称。如果传入此字段，则必须传入fields字段。名称中不允许包含[]两个字符"
                    },
                    "fields": {
                        "type": "array",
                        "description": "数据表的初始字段数组。第一个字段为索引字段，索引字段仅支持类型：1多行文本、2数字、5日期、13电话号码、15超链接、20公式、22地理位置",
                        "items": {
                            "type": "object",
                            "required": ["field_name", "type"],
                            "properties": {
                                "field_name": {
                                    "type": "string",
                                    "description": "字段名称"
                                },
                                "type": {
                                    "type": "integer",
                                    "description": "字段类型。1:文本, 2:数字, 3:单选, 4:多选, 5:日期, 7:复选框, 11:人员, 13:电话号码, 15:超链接, 17:附件, 18:单向关联, 20:公式, 21:双向关联, 22:地理位置, 23:群组, 1001:创建时间, 1002:最后更新时间, 1003:创建人, 1004:修改人, 1005:自动编号",
                                    "enum": [1, 2, 3, 4, 5, 7, 11, 13, 15, 17, 18, 20, 21, 22, 23, 1001, 1002,
                                             1003, 1004, 1005]
                                },
                                "ui_type": {
                                    "type": "string",
                                    "description": "字段在界面上的展示类型",
                                    "enum": ["Text", "Barcode", "Number", "Progress", "Currency", "Rating",
                                             "SingleSelect", "MultiSelect", "DateTime", "Checkbox", "User",
                                             "GroupChat", "Phone", "Url", "Attachment", "SingleLink", "Formula",
                                             "DuplexLink", "Location", "CreatedTime", "ModifiedTime",
                                             "CreatedUser", "ModifiedUser", "AutoNumber"]
                                },
                                "property": {
                                    "type": "object",
                                    "description": "字段属性",
                                    "properties": {
                                        "options": {
                                            "type": "array",
                                            "description": "单选、多选字段的选项信息",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "name": {
                                                        "type": "string",
                                                        "description": "选项名"
                                                    },
                                                    "id": {
                                                        "type": "string",
                                                        "description": "选项ID，创建时不可指定ID"
                                                    },
                                                    "color": {
                                                        "type": "integer",
                                                        "description": "选项颜色，取值范围0-54",
                                                        "minimum": 0,
                                                        "maximum": 54
                                                    }
                                                }
                                            }
                                        },
                                        "formatter": {
                                            "type": "string",
                                            "description": "数字、公式字段的显示格式"
                                        },
                                        "date_formatter": {
                                            "type": "string",
                                            "description": "日期、创建时间、最后更新时间字段的显示格式，默认为yyyy/MM/dd"
                                        },
                                        "auto_fill": {
                                            "type": "boolean",
                                            "description": "日期字段中新记录自动填写创建时间，默认为false"
                                        },
                                        "multiple": {
                                            "type": "boolean",
                                            "description": "人员字段中允许添加多个成员，单向关联、双向关联中允许添加多个记录"
                                        },
                                        "table_id": {
                                            "type": "string",
                                            "description": "单向关联、双向关联字段中关联的数据表的id"
                                        },
                                        "table_name": {
                                            "type": "string",
                                            "description": "单向关联、双向关联字段中关联的数据表的名字"
                                        },
                                        "back_field_name": {
                                            "type": "string",
                                            "description": "双向关联字段中关联的数据表中对应的双向关联字段的名字"
                                        },
                                        "auto_serial": {
                                            "type": "object",
                                            "description": "自动编号类型",
                                            "properties": {
                                                "type": {
                                                    "type": "string",
                                                    "description": "自动编号类型",
                                                    "enum": ["custom", "auto_increment_number"]
                                                },
                                                "options": {
                                                    "type": "array",
                                                    "description": "自动编号规则列表",
                                                    "items": {
                                                        "type": "object",
                                                        "properties": {
                                                            "type": {
                                                                "type": "string",
                                                                "description": "可选规则项类型",
                                                                "enum": ["system_number", "fixed_text",
                                                                         "created_time"]
                                                            },
                                                            "value": {
                                                                "type": "string",
                                                                "description": "与规则项类型相对应的取值"
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                        "location": {
                                            "type": "object",
                                            "description": "地理位置输入方式",
                                            "properties": {
                                                "input_type": {
                                                    "type": "string",
                                                    "description": "地理位置输入限制",
                                                    "enum": ["only_mobile", "not_limit"]
                                                }
                                            }
                                        },
                                        "formula_expression": {
                                            "type": "string",
                                            "description": "公式字段的表达式"
                                        },
                                        "allowed_edit_modes": {
                                            "type": "object",
                                            "description": "字段支持的编辑模式",
                                            "properties": {
                                                "manual": {
                                                    "type": "boolean",
                                                    "description": "是否允许手动录入"
                                                },
                                                "scan": {
                                                    "type": "boolean",
                                                    "description": "是否允许移动端录入"
                                                }
                                            }
                                        },
                                        "min": {
                                            "type": "number",
                                            "description": "进度、评分等字段的数据范围最小值"
                                        },
                                        "max": {
                                            "type": "number",
                                            "description": "进度、评分等字段的数据范围最大值"
                                        },
                                        "range_customize": {
                                            "type": "boolean",
                                            "description": "进度等字段是否支持自定义范围"
                                        },
                                        "currency_code": {
                                            "type": "string",
                                            "description": "货币币种，如CNY"
                                        },
                                        "rating": {
                                            "type": "object",
                                            "description": "评分字段的相关设置",
                                            "properties": {
                                                "symbol": {
                                                    "type": "string",
                                                    "description": "评分字段的符号展示，如star"
                                                }
                                            }
                                        },
                                        "description": {
                                            "type": "object",
                                            "description": "字段的描述",
                                            "properties": {
                                                "disable_sync": {
                                                    "type": "boolean",
                                                    "description": "是否禁止同步描述内容到表单的问题描述，默认为true"
                                                },
                                                "text": {
                                                    "type": "string",
                                                    "description": "字段描述内容，支持换行"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ),
        Tool(
            name="list_tables",
            description="列出多维表格下的数据表",
            inputSchema={
                "type": "object",
                "properties": {
                    "app_token": {
                        "type": "string",
                        "description": "多维表格App名称。最长为255个字符。"
                    },
                    "page_token": {
                        "type": "string",
                        "description": "分页标记，第一次请求不填，表示从头开始遍历；分页查询结果还有更多项时会同时返回新的 page_token，下次遍历可采用该 page_token 获取查询结果"
                    }
                    ,
                    "page_size": {
                        "type": "number",
                        "description": "分页大小"
                    }
                },
                "required": ["app_token"]
            }
        ),
        Tool(
            name="list_fields",
            description="获取多维表格数据表中的的所有字段",
            inputSchema={
                "type": "object",
                "properties": {
                    "app_token": {
                        "type": "string",
                        "description": "多维表格 App 的唯一标识"
                    },
                    "table_id": {
                        "type": "string",
                        "description": "多维表格数据表的唯一标识"
                    },
                    "view_id": {
                        "type": "string",
                        "description": "多维表格中视图的唯一标识"
                    },
                    "text_field_as_array": {
                        "type": "boolean",
                        "description": "控制字段描述 description 数据的返回格式，默认为 false。true 表示 description 将以数组形式返回"
                    },
                    "page_token": {
                        "type": "string",
                        "description": "分页标记，第一次请求不填，表示从头开始遍历；分页查询结果还有更多项时会同时返回新的 page_token，下次遍历可采用该 page_token 获取查询结果"
                    },
                    "page_size": {
                        "type": "number",
                        "description": "分页大小"
                    }
                },
                "required": ["app_token", "table_id"]
            }
        ),
        Tool(
            name="add_records",
            description="新增多条记录，单次调用最多新增1000条记录",
            inputSchema={
                "type": "object",
                "properties": {
                    "app_token": {
                        "type": "string",
                        "description": "多维表格 App 的唯一标识"
                    },
                    "table_id": {
                        "type": "string",
                        "description": "多维表格数据表的唯一标识"
                    },
                    "records": {
                        "type": "array",
                        "description": "要新增的记录列表，每条记录包含 fields 字段",
                        "items": {
                            "type": "object",
                            "properties": {
                                "fields": {
                                    "type": "object",
                                    "description": "记录数据，字段名到值的映射，例如 字段名1:值1",
                                    "additionalProperties": True
                                }
                            },
                            "required": ["fields"]
                        }
                    },
                    "user_id_type": {
                        "type": "string",
                        "description": "用户ID类型，可选值：open_id, union_id, user_id",
                        "enum": ["open_id", "union_id", "user_id"]
                    },
                    "client_token": {
                        "type": "string",
                        "description": "幂等操作标识，格式为标准的 uuidv4"
                    },
                    "ignore_consistency_check": {
                        "type": "boolean",
                        "description": "是否忽略一致性读写检查，默认为 false"
                    }
                },
                "required": ["app_token", "table_id", "records"]
            }
        ),
        Tool(
            name="query_records",
            description="查询数据表中的现有记录，单次最多查询 500 行记录，支持分页获取",
            inputSchema={
                "type": "object",
                "properties": {
                    "app_token": {
                        "type": "string",
                        "description": "多维表格 App 的唯一标识"
                    },
                    "table_id": {
                        "type": "string",
                        "description": "多维表格数据表的唯一标识"
                    },
                    "view_id": {
                        "type": "string",
                        "description": "多维表格中视图的唯一标识"
                    },
                    "field_names": {
                        "type": "array",
                        "description": "字段名称，用于指定本次查询返回记录中包含的字段，不填返回所有字段",
                        "items": {
                            "type": "string"
                        }
                    },
                    "sort": {
                        "type": "array",
                        "description": "是否按指定字段倒排",
                        "items": {
                            "type": "object",
                            "properties": {
                                "field_name": {
                                    "type": "string",
                                    "description": "字段名称"
                                },
                                "desc": {
                                    "type": "boolean",
                                    "description": "是否倒序排序"
                                }
                            }
                        }
                    },
                    "filter": {
                        "type": "object",
                        "description": "根据条件筛选记录",
                        "properties": {
                            "conditions": {
                                "type": "array",
                                "description": "筛选条件集合",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "field_name": {
                                            "type": "string",
                                            "description": "筛选条件的左值，值为字段的名称"
                                        },
                                        "operator": {
                                            "type": "string",
                                            "description": "条件运算符",
                                            "enum": ["is", "isNot", "contains", "doesNotContain", "isEmpty",
                                                     "isNotEmpty", "isGreater", "isGreaterEqual", "isLess",
                                                     "isLessEqual"]
                                        },
                                        "value": {
                                            "type": "array",
                                            "description": "条件的值，可以是单个值或多个值的数组。不同字段类型和不同的 operator 可填的值不同",
                                            "items": {
                                                "type": "string"
                                            }
                                        }
                                    },
                                    "required": ["field_name", "operator"]
                                }
                            },
                            "conjunction": {
                                "type": "string",
                                "description": "表示条件之间的逻辑连接词，该字段必填,可选值有：and(满足所有条件),or(满足任一条件)",
                                "enum": ["and", "or"]
                            }
                        },
                        "required": ["conditions", "conjunction"]
                    },
                    "user_id_type": {
                        "type": "string",
                        "description": "用户ID类型，可选值：open_id, union_id, user_id",
                        "enum": ["open_id", "union_id", "user_id"]
                    },
                    "automatic_fields": {
                        "type": "boolean",
                        "description": "是否自动计算并返回创建时间（created_time）、修改时间（last_modified_time）、创建人（created_by）、修改人（last_modified_by）这四类字段。默认为 false，表示不返回。"
                    },
                    "page_token": {
                        "type": "string",
                        "description": "分页标记，第一次请求不填，表示从头开始遍历；分页查询结果还有更多项时会同时返回新的 page_token，下次遍历可采用该 page_token 获取查询结果"
                    },
                    "page_size": {
                        "type": "number",
                        "description": "分页大小"
                    }
                },
                "required": ["app_token", "table_id"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """调用工具"""
    try:
        if name == "get_root_token":
            result = await get_root_token(client)
            return [
                TextContent(type="text", text=json.dumps({"success": True, "root_token": result}, ensure_ascii=False))]

        elif name == "list_files":
            folder_token = arguments.get("folder_token")
            result = await list_files(client, folder_token)
            return [TextContent(type="text", text=json.dumps({"success": True, "files": result}, ensure_ascii=False))]

        elif name == "create_folder":
            name = arguments["name"]
            folder_token = arguments.get("folder_token", "")
            result = await create_folder(client, name, folder_token)
            return [TextContent(type="text", text=json.dumps({"success": True, "result": result}, ensure_ascii=False))]

        # elif name == "delete_document":
        #     document_id = arguments["document_id"]
        #     document_type = arguments.get("document_type", "doc")
        #     result = client.delete_document(document_id, document_type)
        #     return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "upload_file":
            file_path = arguments["file_path"]
            parent_node_id = arguments["parent_node_id"]
            file_name = arguments.get("file_name")
            result = await upload_file(client, file_path, parent_node_id, file_name)
            return [
                TextContent(type="text", text=json.dumps({"success": True, "file_token": result}, ensure_ascii=False))]

        elif name == "search_documents":
            query = arguments["query"]
            document_type = arguments.get("document_type")
            limit = arguments.get("limit", 20)
            result = await search_documents(client, query, document_type, limit)
            return [TextContent(type="text", text=json.dumps({"success": True, "results": result}, ensure_ascii=False))]

        elif name == "search_dir":
            name = arguments["name"]
            result = await search_dir(client, name)
            return [TextContent(type="text", text=json.dumps({"success": True, "token": result}, ensure_ascii=False))]

        elif name == "download_file":
            file_token = arguments["file_token"]
            download_path = arguments["download_path"]
            result = await download_file(client, file_token, download_path)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "create_export_task":
            file_extension = arguments["file_extension"]
            token = arguments["token"]
            doc_type = arguments["doc_type"]
            sub_id = arguments.get("sub_id")
            result = await create_export_task(client, file_extension, token, doc_type, sub_id)
            return [TextContent(type="text", text=json.dumps({"success": True, "ticket": result}, ensure_ascii=False))]

        elif name == "query_export_task":
            ticket = arguments["ticket"]
            token = arguments["token"]
            result = await query_export_task(client, ticket, token)
            return [TextContent(type="text", text=json.dumps({"success": True, "result": result}, ensure_ascii=False))]

        elif name == "download_export":
            file_token = arguments["file_token"]
            download_path = arguments["download_path"]
            result = await download_export(client, file_token, download_path)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "search_user":
            query = arguments["query"]
            result = await search_user(client, query)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "create_bitable":
            name = arguments["name"]
            folder_token = arguments["folder_token"]
            time_zone = arguments["time_zone"]
            result = await create_bitable(client, name, folder_token, time_zone)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "create_table":
            app_token = arguments["app_token"]
            name = arguments["name"]
            default_view_name = arguments["default_view_name"]
            fields = arguments["fields"]
            result = await create_table(client, app_token, name, default_view_name, fields)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "list_tables":
            app_token = arguments["app_token"]
            page_token = arguments.get("page_token", None)
            page_size = arguments.get("page_size", None)
            result = await list_tables(client, app_token, page_token, page_size)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "list_fields":
            app_token = arguments["app_token"]
            table_id = arguments["table_id"]
            view_id = arguments.get("view_id", None)
            text_field_as_array = arguments.get("text_field_as_array", None)
            page_token = arguments.get("page_token", None)
            page_size = arguments.get("page_size", None)
            result = await list_fields(client, app_token, table_id, view_id, text_field_as_array, page_token, page_size)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "add_records":
            app_token = arguments["app_token"]
            table_id = arguments["table_id"]
            records = arguments["records"]
            user_id_type = arguments.get("user_id_type", None)
            client_token = arguments.get("client_token", None)
            ignore_consistency_check = arguments.get("ignore_consistency_check", None)
            result = await add_records(client, app_token, table_id, records, user_id_type, client_token,
                                       ignore_consistency_check)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        elif name == "query_records":
            app_token = arguments["app_token"]
            table_id = arguments["table_id"]
            view_id = arguments.get("view_id", None)
            field_names = arguments.get("field_names", None)
            sort = arguments.get("sort", None)
            filter_info = arguments.get("filter", None)
            automatic_fields = arguments.get("automatic_fields", None)
            user_id_type = arguments.get("user_id_type", None)
            page_token = arguments.get("page_token", None)
            page_size = arguments.get("page_size", None)
            result = await query_records(client, app_token, table_id, view_id, field_names, sort,
                                         filter_info, automatic_fields, user_id_type, page_token, page_size)
            return [TextContent(type="text", text=json.dumps({"success": result}, ensure_ascii=False))]

        else:
            return [TextContent(type="text", text=json.dumps({"success": False, "error": f"Unknown tool: {name}"},
                                                             ensure_ascii=False))]

    except Exception as e:
        traceback.print_exc()
        logger.error(f"工具调用错误: {e}")
        return [TextContent(type="text", text=json.dumps({"success": False, "error": str(e)}, ensure_ascii=False))]


async def main():
    """启动 MCP 服务器"""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
