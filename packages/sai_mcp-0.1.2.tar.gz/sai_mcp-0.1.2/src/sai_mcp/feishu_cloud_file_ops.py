import traceback

from sai_mcp.feishu_client import FeishuCloudClient
from sai_mcp.feishu_client import FeishuAPIError
from pathlib import Path
from typing import Optional, Dict, List, Any
from requests_toolbelt import MultipartEncoder
import logging

logger = logging.getLogger(__name__)


# ==================== 获取根目录token ====================
async def get_root_token(client: FeishuCloudClient):
    request_url = "/drive/explorer/v2/root_folder/meta"
    data = await client.make_request(
        "GET",
        request_url
    )
    return data.get("token")


# ==================== 获取目录中文件清单操作 ====================
async def list_files(client: FeishuCloudClient, folder_token: Optional[str] = None) -> List[Dict]:
    request_url = "/drive/v1/files?direction=DESC&order_by=EditedTime&page_size=50"
    if folder_token:
        request_url += f"&folder_token={folder_token}"
    data = await client.make_request(
        "GET",
        request_url
    )
    return data.get("files", [])


# ==================== 新建目录 ====================
async def create_folder(client: FeishuCloudClient, name: str, folder_token: str) -> Dict:
    request_url = "/drive/v1/files/create_folder"
    payload = {
        "folder_token": folder_token,
        "name": name
    }
    data = await client.make_request("POST", request_url, json=payload)
    logger.info("创建目录成功")
    return data


# ==================== 文档删除操作 ====================
def delete_document(
        client: FeishuCloudClient,
        document_id: str,
        document_type: str = "doc"
) -> bool:
    """
    删除文档

    Args:
        document_id: 文档 ID
        document_type: 文档类型

    Returns:
        是否成功
    """
    logger.info(f"删除文档: {document_id} (类型: {document_type})")

    try:
        if document_type == "doc":
            client.make_request(
                "DELETE",
                f"/docx/v1/documents/{document_id}"
            )
        elif document_type == "sheet":
            client.make_request(
                "DELETE",
                f"/sheets/v3/spreadsheets/{document_id}"
            )
        else:
            raise ValueError(f"不支持的文档类型: {document_type}")

        logger.info(f"文档删除成功: {document_id}")
        return True

    except FeishuAPIError as e:
        logger.error(f"删除文档失败: {e}")
        return False


# ==================== 文件上传操作 ====================
async def upload_file(
        client: FeishuCloudClient,
        file_path: str,
        parent_node_id: str,
        file_name: Optional[str] = None
) -> str:
    """
    上传文件到飞书云空间

    Args:
        client: 客户端
        file_path: 本地文件路径
        parent_node_id: 父节点 ID (可选)
        file_name: 自定义文件名 (可选)

    Returns:
        上传后的文件 ID
    """
    file_path_obj = Path(file_path)
    if not file_path_obj.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")

    file_name = file_name or file_path_obj.name

    logger.info(f"上传文件: {file_path} -> {file_name}")

    # 读取文件内容
    with open(file_path, "rb") as f:
        file_content = f.read()

    # 获取上传地址
    token = await client.get_user_access_token()
    upload_url = f"{client.base_url}/drive/v1/files/upload_all"

    # 分块上传
    file_size = len(file_content)
    chunk_size = 20 * 1024 * 1024  # 20MB

    if file_size <= chunk_size:
        # 小文件直接上传
        data = {
            "parent_type": "explorer",
            "parent_node": parent_node_id,
            "size": str(file_size),
            "file_name": file_name,
            "file": file_content
        }
        multi_form = MultipartEncoder(data)

        response = client.session.post(
            upload_url,
            headers={"Authorization": f"Bearer {token}", "Content-Type": multi_form.content_type},
            data=multi_form
        )
        response.raise_for_status()
        result = response.json()

        if result.get("code") != 0:
            raise FeishuAPIError(f"文件上传失败: {result.get('msg')}")

        file_token = result.get("data", {}).get("file_token")
        logger.info(f"文件上传成功: {file_token}")
        return file_token

    else:
        # 大文件分块上传
        return _upload_large_file(file_path, file_name, parent_node_id)


def _upload_large_file(
        file_path: str,
        file_name: str,
        parent_node_id: Optional[str]
) -> str:
    """分块上传大文件"""
    # 简化实现，实际需要更复杂的分块上传逻辑
    logger.warning("大文件分块上传功能待实现")
    return ""


# ==================== 搜索文档操作 ====================
async def search_documents(
        client: FeishuCloudClient,
        query: str,
        document_type: Optional[str] = None,
        limit: int = 20
) -> List[Dict[str, Any]]:
    """
    搜索文档

    Args:
        client: 客户端
        query: 搜索关键词
        document_type: 文档类型过滤 (可选)
        limit: 返回结果数量

    Returns:
        搜索结果列表
    """
    logger.info(f"搜索文档: {query}")

    payload = {
        "search_key": query,
        "count": limit
    }

    if document_type:
        payload["msg_type"] = document_type

    data = await client.make_request(
        "POST",
        "/suite/docs-api/search/object",
        json=payload
    )

    results = []
    for item in data.get("docs_entities", []):
        results.append({
            "title": item.get("title", ""),
            "docs_token": item.get("docs_token", ""),
            "docs_type": item.get("docs_type", ""),
            "owner_id": item.get("owner_id", "")
        })

    logger.info(f"找到 {len(results)} 个结果")
    return results


# ==================== 搜索目录操作 ====================
async def search_dir(
        client: FeishuCloudClient,
        name: str
):
    """
    搜索文档

    Args:
        client: 客户端
        name: 搜索关键词

    Returns:
        搜索结果列表
    """
    root_files = await list_files(client)
    dir_list = []
    for file in root_files:
        if file["type"] == "folder":
            if name == file["name"]:
                print(file["token"])
                return file["token"]
            else:
                dir_list.append(file["token"])
    sub_dir_list = []
    for d in dir_list:
        sub_dir = await list_files(client, d)
        for file in sub_dir:
            if file["type"] == "folder":
                if name == file["name"]:
                    return file["token"]
                else:
                    sub_dir_list.append(file["token"])
    for d in sub_dir_list:
        sub_dir = await list_files(client, d)
        for file in sub_dir:
            if file["type"] == "folder":
                if name == file["name"]:
                    return file["token"]
    return None


# ==================== 下载文件操作 ====================
async def download_file(client: FeishuCloudClient, file_token: str, download_path: str):
    token = await client.get_user_access_token()
    url = f"https://open.feishu.cn/open-apis/drive/v1/files/{file_token}/download"
    headers = {
        "Authorization": f"Bearer {token}"
    }
    try:
        response = client.session.get(url, headers=headers)
        with open(download_path, 'wb') as file:
            file.write(response.content)
        print("文件下载完成")
    except Exception as e:
        traceback.print_exc()
        print(e)


# ==================== 创建导出文件任务 ====================
async def create_export_task(client: FeishuCloudClient, file_extension: str, token: str, doc_type: str, sub_id: Optional[str] = None):
    payload = {
        "file_extension": file_extension,
        "token": token,
        "type": doc_type
    }

    if sub_id:
        payload["sub_id"] = sub_id

    data = await client.make_request(
        "POST",
        "/drive/v1/export_tasks",
        json=payload
    )
    return data["ticket"]


# ==================== 查询导出文件任务进度 ====================
async def query_export_task(client: FeishuCloudClient, ticket: str, token: str):
    request_url = f"/drive/v1/export_tasks/{ticket}?token={token}"
    data = await client.make_request(
        "GET",
        request_url
    )
    result = data["result"]
    if result["job_status"] == 0:
        return result["file_token"]
    elif result["job_status"] == 1:
        return "初始化"
    elif result["job_status"] == 2:
        return "处理中"
    else:
        return result["job_error_msg"]


# ==================== 下载导出的文件 ====================
async def download_export(client: FeishuCloudClient, file_token: str, download_path: str):
    token = await client.get_user_access_token()
    url = f"https://open.feishu.cn/open-apis/drive/v1/export_tasks/file/{file_token}/download"
    headers = {
        "Authorization": f"Bearer {token}"
    }
    try:
        response = client.session.get(url, headers=headers)
        with open(download_path, 'wb') as file:
            file.write(response.content)
        print("文件下载完成")
    except Exception as e:
        print(e)

# ==================== 创建文档 ====================
def create_document(
        client: FeishuCloudClient,
        title: Optional[str] = None,
        folder_token: Optional[str] = None
) -> Dict[str, Any]:
    """
    创建文档类型为 docx 的文档

    Args:
        client: 飞书云客户端
        title: 文档标题，只支持纯文本，长度范围 1-800 字符
        folder_token: 指定文档所在文件夹的 Token，不传或传空表示根目录

    Returns:
        包含文档信息的字典，包括 document_id、revision_id、title 等字段

    Raises:
        FeishuAPIError: 创建文档失败时抛出

    注意事项:
        - 单个应用调用频率上限为每秒 3 次
        - 该接口仅支持指定文档标题，不支持带内容创建文档
        - 若使用 tenant_access_token，folder_token 仅可指定应用创建的文件夹
    """
    logger.info(f"创建文档: title={title}, folder_token={folder_token}")

    request_url = "/docx/v1/documents"
    payload = {}

    if title:
        payload["title"] = title
    if folder_token:
        payload["folder_token"] = folder_token

    data = client.make_request("POST", request_url, json=payload)

    document_info = data.get("document", {})
    logger.info(f"文档创建成功: document_id={document_info.get('document_id')}")
    return document_info
