# Metronomo

Python API to interact with the Metronomo hardware.

## Quickstart

Install from PyPI using `pip`:
```
python -m pip install intermod-metronomo
```

Control your Metronomo unit from Python using `metronomo.Metronomo`:
```python
from metronomo import Metronomo

with Metronomo("172.23.40.1") as mtr:
    mtr.set_ref_internal()
    mtr.set_out_clk_freq(100e6)
    mtr.sync_out()
```

## Documentation
See the [online documentation](https://intermod.pro/manuals/metronomo/) for setup and installation instruction and for the API reference.
