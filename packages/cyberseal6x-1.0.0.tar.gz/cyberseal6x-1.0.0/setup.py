"""
Setup configuration for cyberseal6x Python SDK.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="cyberseal6x",
    version="1.0.0",
    author="CyberSeal6x",
    author_email="security@cyberseal6x.com",
    description="Official Python SDK for CyberSeal6x Prompt Security API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/cyberseal6x/python-sdk",
    project_urls={
        "Documentation": "https://docs.cyberseal6x.com",
        "API Reference": "https://cyberseal6x.com/tools/api-docs",
        "Bug Reports": "https://github.com/cyberseal6x/python-sdk/issues",
        "Source": "https://github.com/cyberseal6x/python-sdk",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Typing :: Typed",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
    ],
    extras_require={
        "async": ["httpx[http2]>=0.24.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "ruff>=0.1.0",
        ],
    },
    keywords=[
        "cybersecurity",
        "prompt-injection",
        "ai-security",
        "llm-security",
        "prompt-security",
        "security-scanner",
        "threat-detection",
    ],
    license="MIT",
    include_package_data=True,
    zip_safe=False,
)
