"""
Data models for CyberSeal6x API responses.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime


@dataclass
class Threat:
    """Detected security threat in a prompt."""
    
    type: str
    severity: str
    confidence: float
    description: str
    pattern_matched: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Threat":
        """Create Threat from API response."""
        return cls(
            type=data["type"],
            severity=data["severity"],
            confidence=data["confidence"],
            description=data["description"],
            pattern_matched=data.get("pattern_matched"),
        )
    
    def __str__(self) -> str:
        return f"[{self.severity}] {self.type}: {self.description}"


@dataclass
class ScanResult:
    """Result from a prompt security scan."""
    
    scan_id: str
    timestamp: str
    risk_score: int
    recommendation: str
    threats: List[Threat]
    metadata: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ScanResult":
        """Create ScanResult from API response."""
        threats = [
            Threat.from_dict(t) for t in data.get("threats_detected", [])
        ]
        
        return cls(
            scan_id=data["scan_id"],
            timestamp=data["timestamp"],
            risk_score=data["risk_score"],
            recommendation=data["recommendation"],
            threats=threats,
            metadata=data.get("metadata", {}),
        )
    
    @property
    def is_safe(self) -> bool:
        """Check if prompt is safe (recommendation is ALLOW)."""
        return self.recommendation == "ALLOW"
    
    @property
    def is_risky(self) -> bool:
        """Check if prompt is risky (recommendation is BLOCK)."""
        return self.recommendation == "BLOCK"
    
    @property
    def has_threats(self) -> bool:
        """Check if any threats were detected."""
        return len(self.threats) > 0
    
    @property
    def critical_threats(self) -> List[Threat]:
        """Get only critical severity threats."""
        return [t for t in self.threats if t.severity == "CRITICAL"]
    
    @property
    def high_threats(self) -> List[Threat]:
        """Get only high severity threats."""
        return [t for t in self.threats if t.severity == "HIGH"]
    
    def __str__(self) -> str:
        status = "🔴 BLOCK" if self.is_risky else "🟢 ALLOW"
        return f"{status} (Risk: {self.risk_score}%, Threats: {len(self.threats)})"


@dataclass
class BatchJob:
    """Batch scanning job status."""
    
    batch_id: str
    status: str
    total_prompts: int
    estimated_completion: Optional[str] = None
    created_at: Optional[str] = None
    callback_url: Optional[str] = None
    results_url: Optional[str] = None
    processed: int = 0
    failed: int = 0
    completed_at: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchJob":
        """Create BatchJob from API response."""
        return cls(
            batch_id=data["batch_id"],
            status=data["status"],
            total_prompts=data["total_prompts"],
            processed=data.get("processed", 0),
            failed=data.get("failed", 0),
            estimated_completion=data.get("estimated_completion"),
            created_at=data.get("created_at"),
            completed_at=data.get("completed_at"),
            callback_url=data.get("callback_url"),
            results_url=data.get("results_url"),
        )
    
    @property
    def is_processing(self) -> bool:
        """Check if batch is still processing."""
        return self.status == "processing"
    
    @property
    def is_completed(self) -> bool:
        """Check if batch is completed."""
        return self.status == "completed"
    
    @property
    def is_failed(self) -> bool:
        """Check if batch failed."""
        return self.status == "failed"
    
    @property
    def progress_percent(self) -> float:
        """Get completion progress as percentage."""
        if self.total_prompts == 0:
            return 0.0
        return (self.processed / self.total_prompts) * 100
    
    def __str__(self) -> str:
        return f"Batch {self.batch_id}: {self.status} ({self.processed}/{self.total_prompts})"


@dataclass
class BatchResult:
    """Results from a completed batch job."""
    
    batch_id: str
    total_results: int
    results: List[Dict[str, Any]]
    pagination: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchResult":
        """Create BatchResult from API response."""
        return cls(
            batch_id=data["batch_id"],
            total_results=data["total_results"],
            results=data.get("results", []),
            pagination=data.get("pagination"),
        )
    
    @property
    def high_risk_count(self) -> int:
        """Count of high-risk results (score >= 70)."""
        return sum(1 for r in self.results if r.get("risk_score", 0) >= 70)
    
    @property
    def medium_risk_count(self) -> int:
        """Count of medium-risk results (40 <= score < 70)."""
        return sum(
            1 for r in self.results
            if 40 <= r.get("risk_score", 0) < 70
        )
    
    @property
    def low_risk_count(self) -> int:
        """Count of low-risk results (score < 40)."""
        return sum(1 for r in self.results if r.get("risk_score", 0) < 40)
    
    def __str__(self) -> str:
        return (
            f"BatchResult: {self.total_results} results "
            f"(High: {self.high_risk_count}, "
            f"Medium: {self.medium_risk_count}, "
            f"Low: {self.low_risk_count})"
        )


@dataclass
class AnalyticsSummary:
    """API usage analytics summary."""
    
    total_scans: int
    threats_blocked: int
    avg_risk_score: float
    total_batch_jobs: int = 0
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    top_threat_types: List[Dict[str, Any]] = field(default_factory=list)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnalyticsSummary":
        """Create AnalyticsSummary from API response."""
        return cls(
            total_scans=data.get("total_scans", 0),
            threats_blocked=data.get("threats_blocked", 0),
            avg_risk_score=data.get("avg_risk_score", 0.0),
            total_batch_jobs=data.get("total_batch_jobs", 0),
            period_start=data.get("period_start"),
            period_end=data.get("period_end"),
            top_threat_types=data.get("top_threat_types", []),
        )
    
    def __str__(self) -> str:
        return (
            f"Analytics: {self.total_scans} scans, "
            f"{self.threats_blocked} blocked "
            f"(Avg risk: {self.avg_risk_score:.1f}%)"
        )
