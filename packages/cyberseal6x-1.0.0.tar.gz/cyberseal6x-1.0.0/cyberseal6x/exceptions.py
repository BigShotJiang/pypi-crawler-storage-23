"""
Exception classes for CyberSeal6x SDK.
"""

from typing import Optional, Dict, Any


class CyberSealError(Exception):
    """Base exception for all CyberSeal6x errors."""
    
    def __init__(
        self,
        message: str,
        request_id: Optional[str] = None,
    ):
        self.message = message
        self.request_id = request_id
        super().__init__(self.message)
    
    def __str__(self) -> str:
        if self.request_id:
            return f"{self.message} (Request ID: {self.request_id})"
        return self.message


class AuthenticationError(CyberSealError):
    """
    Raised when API authentication fails.
    
    Common causes:
    - Invalid API key
    - Expired API key
    - Missing API key
    - Insufficient permissions
    """
    pass


class RateLimitError(CyberSealError):
    """
    Raised when API rate limit is exceeded.
    
    Solution: Wait and retry, or upgrade your plan.
    """
    
    def __init__(
        self,
        message: str,
        request_id: Optional[str] = None,
        retry_after: Optional[int] = None,
    ):
        super().__init__(message, request_id)
        self.retry_after = retry_after
    
    def __str__(self) -> str:
        msg = super().__str__()
        if self.retry_after:
            msg += f" (Retry after {self.retry_after} seconds)"
        return msg


class InvalidRequestError(CyberSealError):
    """
    Raised when the API request is invalid.
    
    Common causes:
    - Missing required fields
    - Invalid field types
    - Out-of-range values
    - Malformed JSON
    """
    
    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, request_id)
        self.details = details
    
    def __str__(self) -> str:
        msg = super().__str__()
        if self.details:
            msg += f" (Details: {self.details})"
        return msg


class APIError(CyberSealError):
    """
    Raised when the API returns an error response.
    
    This is typically a server-side error.
    """
    
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, request_id)
        self.status_code = status_code
    
    def __str__(self) -> str:
        msg = super().__str__()
        if self.status_code:
            msg = f"[{self.status_code}] {msg}"
        return msg
