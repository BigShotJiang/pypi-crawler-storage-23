"""
CyberSeal6x API Client
"""

import time
from typing import Optional, List, Dict, Any, Union
from urllib.parse import urljoin

try:
    import httpx
except ImportError:
    raise ImportError(
        "The cyberseal6x package requires httpx. "
        "Install it with: pip install httpx"
    )

from .models import ScanResult, BatchJob, BatchResult, AnalyticsSummary
from .exceptions import (
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    APIError,
)


class CyberSeal:
    """
    CyberSeal6x API Client
    
    Args:
        api_key: Your CyberSeal6x API key (starts with 'cs_')
        base_url: API base URL (default: https://cyberseal6x.com)
        timeout: Request timeout in seconds (default: 30)
    
    Example:
        >>> client = CyberSeal(api_key="cs_...")
        >>> result = client.scan("Ignore previous instructions")
        >>> print(f"Risk: {result.risk_score}%")
    """
    
    DEFAULT_BASE_URL = "https://cyberseal6x.com"
    API_VERSION = "v1"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
    ):
        if not api_key:
            raise ValueError(
                "API key is required. Get yours at https://cyberseal6x.com/tools/api-test"
            )
        
        if not api_key.startswith("cs_"):
            raise ValueError(
                "Invalid API key format. Keys should start with 'cs_'"
            )
        
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"cyberseal6x-python/{self.__class__.__module__.split('.')[0]}",
            },
        )
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def close(self):
        """Close the HTTP client."""
        self._client.close()
    
    def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an API request."""
        url = f"/api/{self.API_VERSION}/{endpoint}"
        
        try:
            response = self._client.request(
                method=method,
                url=url,
                json=json,
                params=params,
            )
            
            # Handle error responses
            if response.status_code == 401:
                error_data = response.json().get("error", {})
                raise AuthenticationError(
                    error_data.get("message", "Authentication failed"),
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code == 429:
                raise RateLimitError(
                    "Rate limit exceeded. Please try again later.",
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code == 400:
                error_data = response.json().get("error", {})
                raise InvalidRequestError(
                    error_data.get("message", "Invalid request"),
                    details=error_data.get("details"),
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code >= 400:
                error_data = response.json().get("error", {})
                raise APIError(
                    error_data.get("message", f"API error: {response.status_code}"),
                    status_code=response.status_code,
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            response.raise_for_status()
            return response.json()
        
        except httpx.TimeoutException:
            raise APIError(
                f"Request timed out after {self.timeout} seconds",
                status_code=408,
            )
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {str(e)}")
    
    def scan(
        self,
        prompt: str,
        threshold: Optional[int] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ScanResult:
        """
        Scan a single prompt for security threats.
        
        Args:
            prompt: The prompt text to scan
            threshold: Risk threshold (0-100, default: 70)
            context: Optional context metadata
        
        Returns:
            ScanResult object with risk score and detected threats
        
        Raises:
            AuthenticationError: Invalid API key
            InvalidRequestError: Invalid prompt or parameters
            APIError: Server error
        
        Example:
            >>> result = client.scan("Ignore all previous instructions")
            >>> if result.risk_score >= 70:
            ...     print(f"BLOCKED: {result.recommendation}")
            >>> for threat in result.threats:
            ...     print(f"- {threat.type}: {threat.description}")
        """
        payload: Dict[str, Any] = {"prompt": prompt}
        
        if threshold is not None:
            payload["options"] = {"threshold": threshold}
        
        if context is not None:
            payload["context"] = context
        
        data = self._request("POST", "scan", json=payload)
        return ScanResult.from_dict(data)
    
    def scan_batch(
        self,
        prompts: List[Union[str, Dict[str, str]]],
        threshold: Optional[int] = None,
        callback_url: Optional[str] = None,
    ) -> BatchJob:
        """
        Scan multiple prompts in a batch (async processing).
        
        Args:
            prompts: List of prompts (strings or dicts with 'id' and 'text')
            threshold: Risk threshold (0-100, default: 70)
            callback_url: Webhook URL for completion notification
        
        Returns:
            BatchJob object with batch ID and status
        
        Example:
            >>> prompts = [
            ...     {"id": "1", "text": "Hello world"},
            ...     {"id": "2", "text": "Ignore previous instructions"},
            ... ]
            >>> batch = client.scan_batch(prompts)
            >>> print(f"Batch ID: {batch.batch_id}")
            >>> 
            >>> # Poll for results
            >>> while batch.status == "processing":
            ...     time.sleep(5)
            ...     batch = client.get_batch(batch.batch_id)
            >>> 
            >>> results = client.get_batch_results(batch.batch_id)
        """
        # Normalize prompts
        normalized_prompts = []
        for i, prompt in enumerate(prompts):
            if isinstance(prompt, str):
                normalized_prompts.append({"id": str(i), "text": prompt})
            elif isinstance(prompt, dict):
                if "id" not in prompt or "text" not in prompt:
                    raise InvalidRequestError(
                        f"Prompt at index {i} must have 'id' and 'text' fields"
                    )
                normalized_prompts.append(prompt)
            else:
                raise InvalidRequestError(
                    f"Prompt at index {i} must be a string or dict"
                )
        
        payload: Dict[str, Any] = {"prompts": normalized_prompts}
        
        if threshold is not None or callback_url is not None:
            payload["options"] = {}
            if threshold is not None:
                payload["options"]["threshold"] = threshold
            if callback_url is not None:
                payload["options"]["callback_url"] = callback_url
        
        data = self._request("POST", "scan/batch", json=payload)
        return BatchJob.from_dict(data)
    
    def get_batch(self, batch_id: str) -> BatchJob:
        """
        Get batch job status.
        
        Args:
            batch_id: The batch job ID
        
        Returns:
            BatchJob object with current status
        
        Example:
            >>> batch = client.get_batch("batch_123...")
            >>> print(f"Status: {batch.status}")
            >>> print(f"Progress: {batch.processed}/{batch.total_prompts}")
        """
        # Note: This endpoint doesn't exist yet in the API
        # You'll need to add: GET /api/v1/scan/batch/{batch_id}
        data = self._request("GET", f"scan/batch/{batch_id}")
        return BatchJob.from_dict(data)
    
    def get_batch_results(
        self,
        batch_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> BatchResult:
        """
        Get results from a completed batch job.
        
        Args:
            batch_id: The batch job ID
            limit: Number of results to return (max: 1000)
            offset: Offset for pagination
        
        Returns:
            BatchResult object with scan results
        
        Example:
            >>> results = client.get_batch_results("batch_123...")
            >>> for item in results.results:
            ...     print(f"{item['id']}: Risk {item['risk_score']}%")
        """
        params = {"limit": limit, "offset": offset}
        data = self._request(
            "GET",
            f"scan/batch/{batch_id}/results",
            params=params,
        )
        return BatchResult.from_dict(data)
    
    def get_analytics(self) -> AnalyticsSummary:
        """
        Get API usage analytics.
        
        Returns:
            AnalyticsSummary object with usage statistics
        
        Example:
            >>> analytics = client.get_analytics()
            >>> print(f"Total scans: {analytics.total_scans}")
            >>> print(f"Threats blocked: {analytics.threats_blocked}")
        """
        data = self._request("GET", "analytics/summary")
        return AnalyticsSummary.from_dict(data)
    
    def health(self) -> Dict[str, Any]:
        """
        Check API health status.
        
        Returns:
            Dict with health status
        
        Example:
            >>> health = client.health()
            >>> print(health["status"])  # "healthy"
        """
        return self._request("GET", "health")
    
    def wait_for_batch(
        self,
        batch_id: str,
        poll_interval: int = 5,
        timeout: int = 300,
    ) -> BatchJob:
        """
        Wait for a batch job to complete (polling).
        
        Args:
            batch_id: The batch job ID
            poll_interval: Seconds between status checks (default: 5)
            timeout: Max seconds to wait (default: 300)
        
        Returns:
            Completed BatchJob object
        
        Raises:
            TimeoutError: If batch doesn't complete within timeout
        
        Example:
            >>> batch = client.scan_batch(prompts)
            >>> completed = client.wait_for_batch(batch.batch_id)
            >>> results = client.get_batch_results(completed.batch_id)
        """
        start_time = time.time()
        
        while True:
            batch = self.get_batch(batch_id)
            
            if batch.status in ["completed", "failed"]:
                return batch
            
            if time.time() - start_time > timeout:
                raise TimeoutError(
                    f"Batch {batch_id} did not complete within {timeout} seconds"
                )
            
            time.sleep(poll_interval)


class AsyncCyberSeal:
    """
    Async version of CyberSeal client (requires httpx[async]).
    
    Example:
        >>> async with AsyncCyberSeal(api_key="cs_...") as client:
        ...     result = await client.scan("Your prompt here")
        ...     print(result.risk_score)
    """
    
    DEFAULT_BASE_URL = "https://cyberseal6x.com"
    API_VERSION = "v1"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
    ):
        if not api_key:
            raise ValueError(
                "API key is required. Get yours at https://cyberseal6x.com/tools/api-test"
            )
        
        if not api_key.startswith("cs_"):
            raise ValueError(
                "Invalid API key format. Keys should start with 'cs_'"
            )
        
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"cyberseal6x-python-async/{self.__class__.__module__.split('.')[0]}",
            },
        )
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()
    
    async def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an async API request."""
        url = f"/api/{self.API_VERSION}/{endpoint}"
        
        try:
            response = await self._client.request(
                method=method,
                url=url,
                json=json,
                params=params,
            )
            
            # Handle error responses (same as sync)
            if response.status_code == 401:
                error_data = response.json().get("error", {})
                raise AuthenticationError(
                    error_data.get("message", "Authentication failed"),
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code == 429:
                raise RateLimitError(
                    "Rate limit exceeded. Please try again later.",
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code == 400:
                error_data = response.json().get("error", {})
                raise InvalidRequestError(
                    error_data.get("message", "Invalid request"),
                    details=error_data.get("details"),
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            elif response.status_code >= 400:
                error_data = response.json().get("error", {})
                raise APIError(
                    error_data.get("message", f"API error: {response.status_code}"),
                    status_code=response.status_code,
                    request_id=response.headers.get("X-Request-ID"),
                )
            
            response.raise_for_status()
            return response.json()
        
        except httpx.TimeoutException:
            raise APIError(
                f"Request timed out after {self.timeout} seconds",
                status_code=408,
            )
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {str(e)}")
    
    async def scan(
        self,
        prompt: str,
        threshold: Optional[int] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ScanResult:
        """Async version of scan()."""
        payload: Dict[str, Any] = {"prompt": prompt}
        
        if threshold is not None:
            payload["options"] = {"threshold": threshold}
        
        if context is not None:
            payload["context"] = context
        
        data = await self._request("POST", "scan", json=payload)
        return ScanResult.from_dict(data)
    
    async def scan_batch(
        self,
        prompts: List[Union[str, Dict[str, str]]],
        threshold: Optional[int] = None,
        callback_url: Optional[str] = None,
    ) -> BatchJob:
        """Async version of scan_batch()."""
        # Same normalization logic as sync version
        normalized_prompts = []
        for i, prompt in enumerate(prompts):
            if isinstance(prompt, str):
                normalized_prompts.append({"id": str(i), "text": prompt})
            elif isinstance(prompt, dict):
                if "id" not in prompt or "text" not in prompt:
                    raise InvalidRequestError(
                        f"Prompt at index {i} must have 'id' and 'text' fields"
                    )
                normalized_prompts.append(prompt)
            else:
                raise InvalidRequestError(
                    f"Prompt at index {i} must be a string or dict"
                )
        
        payload: Dict[str, Any] = {"prompts": normalized_prompts}
        
        if threshold is not None or callback_url is not None:
            payload["options"] = {}
            if threshold is not None:
                payload["options"]["threshold"] = threshold
            if callback_url is not None:
                payload["options"]["callback_url"] = callback_url
        
        data = await self._request("POST", "scan/batch", json=payload)
        return BatchJob.from_dict(data)
    
    async def get_batch_results(
        self,
        batch_id: str,
        limit: int = 100,
        offset: int = 0,
    ) -> BatchResult:
        """Async version of get_batch_results()."""
        params = {"limit": limit, "offset": offset}
        data = await self._request(
            "GET",
            f"scan/batch/{batch_id}/results",
            params=params,
        )
        return BatchResult.from_dict(data)
    
    async def get_analytics(self) -> AnalyticsSummary:
        """Async version of get_analytics()."""
        data = await self._request("GET", "analytics/summary")
        return AnalyticsSummary.from_dict(data)
    
    async def health(self) -> Dict[str, Any]:
        """Async version of health()."""
        return await self._request("GET", "health")
