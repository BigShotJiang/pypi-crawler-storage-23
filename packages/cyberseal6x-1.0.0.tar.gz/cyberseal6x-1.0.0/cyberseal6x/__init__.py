"""
CyberSeal6x Python SDK
~~~~~~~~~~~~~~~~~~~~~

Official Python SDK for the CyberSeal6x Prompt Security API.

Basic usage:

    >>> from cyberseal6x import CyberSeal
    >>> client = CyberSeal(api_key="cs_...")
    >>> result = client.scan("Your prompt here")
    >>> print(result.risk_score)
    25

Full documentation: https://docs.cyberseal6x.com
"""

__version__ = "1.0.0"
__author__ = "CyberSeal6x"
__license__ = "MIT"

from .client import CyberSeal
from .exceptions import (
    CyberSealError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    APIError,
)
from .models import (
    ScanResult,
    BatchJob,
    BatchResult,
    Threat,
    AnalyticsSummary,
)

__all__ = [
    "CyberSeal",
    "CyberSealError",
    "AuthenticationError",
    "RateLimitError",
    "InvalidRequestError",
    "APIError",
    "ScanResult",
    "BatchJob",
    "BatchResult",
    "Threat",
    "AnalyticsSummary",
]
