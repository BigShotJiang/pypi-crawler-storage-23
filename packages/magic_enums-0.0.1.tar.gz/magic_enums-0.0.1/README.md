# magic-enums

[![PyPI - Version](https://img.shields.io/pypi/v/magic-enums.svg)](https://pypi.org/project/magic-enums)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/magic-enums.svg)](https://pypi.org/project/magic-enums)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install magic-enums
```

## License

`magic-enums` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
