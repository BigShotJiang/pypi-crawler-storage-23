# SPDX-FileCopyrightText: 2026-present Jonathan Lajus <jonathan.lajus@mhcomm.fr>
#
# SPDX-License-Identifier: MIT
