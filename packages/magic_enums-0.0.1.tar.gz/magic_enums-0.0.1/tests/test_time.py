from magic_enums.time import (NumberOfDaysIn, NumberOfHoursIn,
                              NumberOfMinutesIn, NumberOfSecondsIn)


def test_seconds():
    assert NumberOfSecondsIn.ONE_SECOND == 1
    assert NumberOfSecondsIn.ONE_MINUTE == 60
    assert NumberOfSecondsIn.ONE_HOUR == 60 * 60
    assert NumberOfSecondsIn.ONE_DAY == 24 * 60 * 60
    assert NumberOfSecondsIn.ONE_WEEK == 7 * 24 * 60 * 60
    assert NumberOfSecondsIn.ONE_MONTH_OF_THIRTY_DAYS == 30 * 24 * 60 * 60
    assert NumberOfSecondsIn.ONE_COMMON_YEAR == 365 * 24 * 60 * 60


def test_minutes():
    assert NumberOfMinutesIn.ONE_MINUTE == 1
    assert NumberOfMinutesIn.ONE_HOUR == 60
    assert NumberOfMinutesIn.ONE_DAY == 24 * 60
    assert NumberOfMinutesIn.ONE_WEEK == 7 * 24 * 60
    assert NumberOfMinutesIn.ONE_MONTH_OF_THIRTY_DAYS == 30 * 24 * 60
    assert NumberOfMinutesIn.ONE_COMMON_YEAR == 365 * 24 * 60


def test_hours():
    assert NumberOfHoursIn.ONE_HOUR == 1
    assert NumberOfHoursIn.ONE_DAY == 24
    assert NumberOfHoursIn.ONE_WEEK == 7 * 24
    assert NumberOfHoursIn.ONE_MONTH_OF_THIRTY_DAYS == 30 * 24
    assert NumberOfHoursIn.ONE_COMMON_YEAR == 365 * 24


def test_days():
    assert NumberOfDaysIn.ONE_DAY == 1
    assert NumberOfDaysIn.ONE_WEEK == 7
    assert NumberOfDaysIn.ONE_MONTH_OF_THIRTY_DAYS == 30
    assert NumberOfDaysIn.ONE_COMMON_YEAR == 365
