import sys

MSG = """
========================================================
  Krasis is no longer distributed via PyPI.

  Install from GitHub instead:

    curl -sSf https://raw.githubusercontent.com/brontoguana/krasis/main/install.sh | bash

  More info: https://github.com/brontoguana/krasis
========================================================
"""

print(MSG, file=sys.stderr)
