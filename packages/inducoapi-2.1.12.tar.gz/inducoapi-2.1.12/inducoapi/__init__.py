from .inducoapi import build_openapi

__all__ = ["build_openapi"]
__version__ = "2.1.12"
