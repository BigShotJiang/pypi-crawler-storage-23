"""Maniac SDK exceptions."""

from __future__ import annotations


class ManiacError(Exception):
    """Base exception for all Maniac SDK errors."""

    pass


class APIError(ManiacError):
    """API returned an error response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class AuthenticationError(ManiacError):
    """Authentication failed (401/403)."""

    pass


class RateLimitError(ManiacError):
    """Rate limit exceeded (429)."""

    def __init__(self, message: str, *, retry_after: int | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class NotFoundError(ManiacError):
    """Resource not found (404)."""

    pass


class BadRequestError(ManiacError):
    """Bad request (400/422)."""

    pass


class APIConnectionError(ManiacError):
    """Network/connection error."""

    pass
