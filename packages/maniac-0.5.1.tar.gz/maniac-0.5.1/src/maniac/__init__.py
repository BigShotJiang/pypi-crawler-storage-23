"""Maniac Python SDK.

A Python client for the Maniac Inference Gateway API with an OpenAI-compatible interface.

Usage:
    from maniac import Maniac, AsyncManiac

    # Sync client
    client = Maniac(api_key="your-api-key")
    response = client.chat.completions.create(
        model="openai/gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}]
    )

    # Async client
    async with AsyncManiac() as client:
        response = await client.chat.completions.create(
            model="openai/gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}]
        )
"""

from ._client import Maniac, AsyncManiac
from ._exceptions import (
    ManiacError,
    APIError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    BadRequestError,
    APIConnectionError,
)
from . import types

__version__ = "0.5.0"

__all__ = [
    # Clients
    "Maniac",
    "AsyncManiac",
    # Exceptions
    "ManiacError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "BadRequestError",
    "APIConnectionError",
    # Types
    "types",
]
