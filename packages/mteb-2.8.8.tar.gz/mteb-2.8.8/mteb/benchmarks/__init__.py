from mteb.benchmarks.benchmark import Benchmark
from mteb.benchmarks.get_benchmark import (
    get_benchmark,
    get_benchmarks,
)

__all__ = [
    "Benchmark",
    "Benchmark",
    "get_benchmark",
    "get_benchmarks",
]
