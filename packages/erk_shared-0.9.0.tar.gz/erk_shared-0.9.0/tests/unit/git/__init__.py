"""Unit tests for git module."""
