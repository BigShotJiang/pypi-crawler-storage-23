# Tests for erk_shared.gateway.gt
