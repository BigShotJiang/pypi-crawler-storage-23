"""Unit tests for erk-shared package."""
