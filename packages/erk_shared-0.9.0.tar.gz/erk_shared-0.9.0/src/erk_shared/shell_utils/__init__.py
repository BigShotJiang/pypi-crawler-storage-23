"""Shell utilities.

Import from submodules:
- temp_files: cleanup_stale_scripts, write_script_to_temp
"""
