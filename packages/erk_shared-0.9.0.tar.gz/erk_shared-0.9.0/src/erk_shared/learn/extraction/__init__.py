"""Extraction module for session discovery, selection, and preprocessing."""
