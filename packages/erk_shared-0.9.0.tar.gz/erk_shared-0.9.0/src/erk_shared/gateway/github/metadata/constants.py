"""Constants for GitHub metadata operations."""

GITHUB_COMMENT_SIZE_LIMIT = 65536
CHUNK_SAFETY_BUFFER = 1000
