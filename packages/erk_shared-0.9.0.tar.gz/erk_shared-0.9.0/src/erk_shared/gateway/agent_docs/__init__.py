"""Agent documentation gateway for reading/writing docs/learned/ files."""
