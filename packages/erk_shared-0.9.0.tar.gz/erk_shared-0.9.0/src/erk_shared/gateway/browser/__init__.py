"""Browser launch integration.

Import from submodules:
- abc: BrowserLauncher
- real: RealBrowserLauncher
- fake: FakeBrowserLauncher
"""
