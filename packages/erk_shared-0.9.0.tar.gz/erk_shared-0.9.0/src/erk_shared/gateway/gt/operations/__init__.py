"""GT kit operations - pure business logic without CLI dependencies.

Import from submodules:
- erk_shared.gateway.gt.operations.finalize: is_learn_plan, ERK_SKIP_LEARN_LABEL
- erk_shared.gateway.gt.operations.land_pr: execute_land_pr
- erk_shared.gateway.gt.operations.squash: execute_squash
"""
