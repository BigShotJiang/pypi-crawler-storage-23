"""Git worktree operations subgateway."""
