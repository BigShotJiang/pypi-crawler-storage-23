"""Git interface and utilities.

Import from submodules:
- abc: Git, WorktreeInfo, find_worktree_for_branch
- real: RealGit
"""
