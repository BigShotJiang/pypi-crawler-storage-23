"""Shell detection and tool availability operations.

Import from submodules:
- erk_shared.gateway.shell.abc: Shell, detect_shell_from_env
- erk_shared.gateway.shell.fake: FakeShell, SpawnSubshellCall
- erk_shared.gateway.shell.real: RealShell
"""
