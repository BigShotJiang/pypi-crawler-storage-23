"""Live display gateway for real-time output."""
