"""
diversity_metrics.py - Ecosystem diversity indices.

Provides multiple diversity measures for the model ecosystem:
- Pairwise diversity (mean squared distance)
- Shannon diversity (entropy-based)
- Simpson diversity (probability-based)
- Spectral diversity (eigenvalue-based)
- Effective number of species
"""

import numpy as np
from typing import List, Optional


def pairwise_diversity(capabilities: np.ndarray) -> float:
    """
    Compute mean pairwise squared distance between model capability vectors.

    Div(t) = (1 / (N choose 2)) * sum_{i < j} ||c_i - c_j||^2

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)
        Capability vectors for N models in d dimensions.

    Returns
    -------
    float
        Pairwise diversity index. 0 means all models are identical.
    """
    N = capabilities.shape[0]
    if N <= 1:
        return 0.0

    total = 0.0
    count = 0
    for i in range(N):
        for j in range(i + 1, N):
            total += np.sum((capabilities[i] - capabilities[j]) ** 2)
            count += 1

    return float(total / count)


def shannon_diversity(capabilities: np.ndarray, n_bins: int = 20) -> float:
    """
    Shannon diversity index based on discretized capability distributions.

    Discretizes each dimension into bins and computes the entropy of the
    joint distribution of model positions.

    H = -sum_k p_k * log(p_k)

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)
        Capability vectors.
    n_bins : int
        Number of bins per dimension for discretization.

    Returns
    -------
    float
        Shannon diversity index (higher = more diverse).
    """
    N, d = capabilities.shape
    if N <= 1:
        return 0.0

    # Use PCA-projected 1D representation for tractability
    mean = np.mean(capabilities, axis=0)
    centered = capabilities - mean
    if np.all(np.abs(centered) < 1e-12):
        return 0.0

    # Project onto first principal component
    U, S, Vt = np.linalg.svd(centered, full_matrices=False)
    projected = centered @ Vt[0]

    # Discretize
    if np.max(projected) - np.min(projected) < 1e-12:
        return 0.0

    hist, _ = np.histogram(projected, bins=n_bins, density=True)
    hist = hist[hist > 0]
    hist = hist / hist.sum()

    return float(-np.sum(hist * np.log(hist + 1e-15)))


def simpson_diversity(capabilities: np.ndarray, n_bins: int = 20) -> float:
    """
    Simpson diversity index (1 - sum of squared proportions).

    D = 1 - sum_k p_k^2

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)
    n_bins : int

    Returns
    -------
    float
        Simpson diversity in [0, 1). Higher = more diverse.
    """
    N, d = capabilities.shape
    if N <= 1:
        return 0.0

    mean = np.mean(capabilities, axis=0)
    centered = capabilities - mean
    if np.all(np.abs(centered) < 1e-12):
        return 0.0

    U, S, Vt = np.linalg.svd(centered, full_matrices=False)
    projected = centered @ Vt[0]

    if np.max(projected) - np.min(projected) < 1e-12:
        return 0.0

    hist, _ = np.histogram(projected, bins=n_bins, density=False)
    proportions = hist / hist.sum()

    return float(1.0 - np.sum(proportions ** 2))


def spectral_diversity(capabilities: np.ndarray) -> float:
    """
    Spectral diversity based on eigenvalues of the capability covariance matrix.

    Measures the effective dimensionality of the model distribution using
    the entropy of normalized eigenvalues.

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)

    Returns
    -------
    float
        Spectral diversity (higher = models spread across more dimensions).
    """
    N, d = capabilities.shape
    if N <= 1:
        return 0.0

    cov = np.cov(capabilities.T)
    if cov.ndim == 0:
        return 0.0

    eigenvalues = np.linalg.eigvalsh(cov)
    eigenvalues = np.maximum(eigenvalues, 0)  # Numerical stability

    total = eigenvalues.sum()
    if total < 1e-15:
        return 0.0

    # Normalized eigenvalues as probabilities
    p = eigenvalues / total
    p = p[p > 1e-15]

    # Entropy of eigenvalue distribution
    return float(-np.sum(p * np.log(p)))


def effective_number_of_species(capabilities: np.ndarray, epsilon: float = 0.1) -> int:
    """
    Estimate the effective number of distinct model 'species' via clustering.

    Two models are considered the same species if their distance is < epsilon.

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)
    epsilon : float
        Distance threshold for considering models as same species.

    Returns
    -------
    int
        Number of distinct species.
    """
    N = capabilities.shape[0]
    if N <= 1:
        return N

    # Simple greedy clustering
    species: list[int] = []
    assigned = np.zeros(N, dtype=bool)

    for i in range(N):
        if assigned[i]:
            continue
        species.append(i)
        assigned[i] = True
        for j in range(i + 1, N):
            if not assigned[j]:
                dist = np.linalg.norm(capabilities[i] - capabilities[j])
                if dist < epsilon:
                    assigned[j] = True

    return len(species)


def diversity_report(capabilities: np.ndarray) -> dict:
    """
    Compute a comprehensive diversity report.

    Parameters
    ----------
    capabilities : np.ndarray of shape (N, d)

    Returns
    -------
    dict
        Dictionary with all diversity metrics.
    """
    return {
        "pairwise": pairwise_diversity(capabilities),
        "shannon": shannon_diversity(capabilities),
        "simpson": simpson_diversity(capabilities),
        "spectral": spectral_diversity(capabilities),
        "effective_species": effective_number_of_species(capabilities),
        "n_models": capabilities.shape[0],
        "n_dimensions": capabilities.shape[1],
    }
