"""
phase_transitions.py - Critical threshold detection and bifurcation analysis.

Implements tools for detecting phase transitions in the ecosystem dynamics,
including:
- Diversity erosion transitions (Theorem 1)
- Benchmark overfitting transitions (Theorem 2)
- Paradoxical intervention detection (Theorem 3)
- Bifurcation analysis across parameter ranges
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.theory.equilibria import (
    stability_analysis,
    compute_jacobian_eigenvalues,
    compute_diversity_erosion_threshold,
)


@dataclass
class PhaseTransitionResult:
    """Result of a phase transition analysis."""
    parameter_name: str
    parameter_values: np.ndarray
    diversity_values: np.ndarray
    benchmark_scores: np.ndarray
    real_world_performance: np.ndarray
    brg_values: np.ndarray
    critical_value: Optional[float]
    transition_type: str  # "erosion", "overfitting", "paradoxical"


def scan_contamination_rate(
    alpha_range: np.ndarray = None,
    n_steps: int = 200,
    n_models: int = 2,
    dim: int = 5,
    eta: float = 0.1,
    beta: float = 0.05,
    gamma: float = 0.0,
    seed: int = 42,
) -> PhaseTransitionResult:
    """
    Scan contamination rate alpha to detect diversity erosion transition.

    For each alpha value, runs the ecosystem simulation and records the
    final diversity, benchmark score, and real-world performance.

    Parameters
    ----------
    alpha_range : np.ndarray
        Array of alpha values to scan. Default: linspace(0, 1, 50).
    n_steps : int
        Number of simulation steps per alpha value.
    Other parameters: ecosystem configuration.

    Returns
    -------
    PhaseTransitionResult
    """
    if alpha_range is None:
        alpha_range = np.linspace(0, 1, 50)

    diversities: List[float] = []
    bench_scores: List[float] = []
    rw_perfs: List[float] = []
    brgs: List[float] = []

    for alpha in alpha_range:
        eco: Ecosystem = Ecosystem.create_default(
            n_models=n_models,
            dim=dim,
            contamination_rate=alpha,
            benchmark_adaptation_rate=gamma,
            learning_rate=eta,
            benchmark_pressure=beta,
            seed=seed,
        )
        eco.run(n_steps)
        state = eco.current_state
        diversities.append(state.diversity_index)
        bench_scores.append(state.mean_benchmark_score)
        rw_perfs.append(state.mean_real_world_performance)
        brgs.append(state.benchmark_reality_gap)

    diversities = np.array(diversities)
    bench_scores = np.array(bench_scores)
    rw_perfs = np.array(rw_perfs)
    brgs = np.array(brgs)

    # Detect critical alpha (where diversity drops below 50% of baseline)
    threshold: float = 0.5 * diversities[0] if diversities[0] > 0 else 0.01
    critical_idx = np.where(diversities < threshold)[0]
    critical_alpha: Optional[float] = float(alpha_range[critical_idx[0]]) if len(critical_idx) > 0 else None

    return PhaseTransitionResult(
        parameter_name="contamination_rate (alpha)",
        parameter_values=alpha_range,
        diversity_values=diversities,
        benchmark_scores=bench_scores,
        real_world_performance=rw_perfs,
        brg_values=brgs,
        critical_value=critical_alpha,
        transition_type="erosion",
    )


def scan_benchmark_pressure(
    beta_range: np.ndarray = None,
    n_steps: int = 200,
    n_models: int = 2,
    dim: int = 5,
    alpha: float = 0.3,
    eta: float = 0.1,
    gamma: float = 0.1,
    seed: int = 42,
) -> PhaseTransitionResult:
    """
    Scan benchmark pressure beta to detect benchmark overfitting transition.

    Parameters
    ----------
    beta_range : np.ndarray
        Array of beta values to scan. Default: linspace(0, 0.5, 50).

    Returns
    -------
    PhaseTransitionResult
    """
    if beta_range is None:
        beta_range = np.linspace(0, 0.5, 50)

    diversities: List[float] = []
    bench_scores: List[float] = []
    rw_perfs: List[float] = []
    brgs: List[float] = []

    for beta in beta_range:
        eco: Ecosystem = Ecosystem.create_default(
            n_models=n_models,
            dim=dim,
            contamination_rate=alpha,
            benchmark_adaptation_rate=gamma,
            learning_rate=eta,
            benchmark_pressure=beta,
            seed=seed,
        )
        eco.run(n_steps)
        state = eco.current_state
        diversities.append(state.diversity_index)
        bench_scores.append(state.mean_benchmark_score)
        rw_perfs.append(state.mean_real_world_performance)
        brgs.append(state.benchmark_reality_gap)

    diversities = np.array(diversities)
    bench_scores = np.array(bench_scores)
    rw_perfs = np.array(rw_perfs)
    brgs = np.array(brgs)

    # Detect overfitting: where BRG becomes positive (closer to benchmark than reality)
    critical_idx = np.where(brgs > 0)[0]
    critical_beta: Optional[float] = float(beta_range[critical_idx[0]]) if len(critical_idx) > 0 else None

    return PhaseTransitionResult(
        parameter_name="benchmark_pressure (beta)",
        parameter_values=beta_range,
        diversity_values=diversities,
        benchmark_scores=bench_scores,
        real_world_performance=rw_perfs,
        brg_values=brgs,
        critical_value=critical_beta,
        transition_type="overfitting",
    )


def detect_paradoxical_intervention(
    n_steps: int = 100,
    intervention_step: int = 50,
    improvement_magnitude: float = 0.5,
    n_models: int = 2,
    dim: int = 5,
    alpha: float = 0.5,
    eta: float = 0.1,
    beta: float = 0.05,
    gamma: float = 0.0,
    seed: int = 42,
) -> Dict:
    """
    Test for paradoxical intervention (Theorem 3).

    Runs two simulations:
    1. Baseline: no intervention
    2. Intervention: at step `intervention_step`, improve Model_A by moving
       it closer to natural_mean

    Checks if the intervention degrades overall ecosystem fitness.

    Parameters
    ----------
    n_steps : int
        Total simulation steps.
    intervention_step : int
        Step at which to intervene.
    improvement_magnitude : float
        How much to improve the target model (fraction of distance to natural).

    Returns
    -------
    dict
        Results including whether paradox was detected.
    """
    # Baseline run
    eco_baseline: Ecosystem = Ecosystem.create_default(
        n_models=n_models, dim=dim, contamination_rate=alpha,
        learning_rate=eta, benchmark_pressure=beta,
        benchmark_adaptation_rate=gamma, seed=seed,
    )
    eco_baseline.run(n_steps)
    baseline_fitness = eco_baseline.get_real_world_performance_trajectory()

    # Compute per-model baseline trajectories
    baseline_other_dists: List[np.ndarray] = []
    natural_mean_base: Optional[np.ndarray] = eco_baseline.data_pool.natural_mean
    for m in eco_baseline.models[1:]:
        baseline_other_dists.append(
            np.array([np.linalg.norm(h - natural_mean_base) for h in m.history])
        )

    # Intervention run
    eco_intervention: Ecosystem = Ecosystem.create_default(
        n_models=n_models, dim=dim, contamination_rate=alpha,
        learning_rate=eta, benchmark_pressure=beta,
        benchmark_adaptation_rate=gamma, seed=seed,
    )
    eco_intervention.run(intervention_step)

    # Intervene: improve Model_A
    model_a = eco_intervention.models[0]
    natural_mean: Optional[np.ndarray] = eco_intervention.data_pool.natural_mean
    direction = natural_mean - model_a.capability
    model_a.capability = model_a.capability + improvement_magnitude * direction

    # Continue simulation
    eco_intervention.run(n_steps - intervention_step)
    intervention_fitness = eco_intervention.get_real_world_performance_trajectory()

    # Compute per-model intervention trajectories for OTHER models
    intervention_other_dists: List[np.ndarray] = []
    for m in eco_intervention.models[1:]:
        intervention_other_dists.append(
            np.array([np.linalg.norm(h - natural_mean) for h in m.history])
        )

    # Check for paradox using multiple criteria:
    # 1. Overall ecosystem fitness at end
    baseline_final = float(np.mean(baseline_fitness[-20:]))
    intervention_final = float(np.mean(intervention_fitness[-20:]))
    paradox_overall: bool = intervention_final < baseline_final

    # 2. Short-term impact (10-30 steps after intervention)
    window_start: int = intervention_step + 5
    window_end: int = min(intervention_step + 30, n_steps)
    if window_end > window_start:
        baseline_short = float(np.mean(baseline_fitness[window_start:window_end]))
        intervention_short = float(np.mean(intervention_fitness[window_start:window_end]))
        paradox_short: bool = intervention_short < baseline_short
    else:
        paradox_short = False
        baseline_short: float = baseline_final
        intervention_short: float = intervention_final

    # 3. Impact on OTHER models (not the improved one)
    paradox_other = False
    if baseline_other_dists and intervention_other_dists:
        base_other_final = float(np.mean([d[-20:].mean() for d in baseline_other_dists]))
        int_other_final = float(np.mean([d[-20:].mean() for d in intervention_other_dists]))
        paradox_other: bool = int_other_final > base_other_final  # Other models got WORSE

    paradox_detected: bool = paradox_overall or paradox_short or paradox_other

    return {
        "paradox_detected": paradox_detected,
        "paradox_overall": paradox_overall,
        "paradox_short_term": paradox_short,
        "paradox_other_models": paradox_other,
        "baseline_final_fitness": baseline_final,
        "intervention_final_fitness": intervention_final,
        "fitness_change": intervention_final - baseline_final,
        "short_term_change": intervention_short - baseline_short if window_end > window_start else 0.0,
        "baseline_trajectory": baseline_fitness,
        "intervention_trajectory": intervention_fitness,
        "intervention_step": intervention_step,
    }


def compute_phase_diagram(
    alpha_range: np.ndarray = None,
    beta_range: np.ndarray = None,
    n_steps: int = 200,
    n_models: int = 2,
    dim: int = 5,
    eta: float = 0.1,
    gamma: float = 0.0,
    seed: int = 42,
    metric: str = "diversity",
) -> Dict:
    """
    Compute a 2D phase diagram over alpha and beta.

    Parameters
    ----------
    alpha_range, beta_range : np.ndarray
        Parameter ranges to scan.
    metric : str
        Which metric to compute: "diversity", "benchmark_score", "real_world", "brg".

    Returns
    -------
    dict
        Contains alpha_range, beta_range, and 2D metric array.
    """
    if alpha_range is None:
        alpha_range = np.linspace(0, 1, 25)
    if beta_range is None:
        beta_range = np.linspace(0, 0.5, 25)

    metric_map = {
        "diversity": lambda s: s.diversity_index,
        "benchmark_score": lambda s: s.mean_benchmark_score,
        "real_world": lambda s: s.mean_real_world_performance,
        "brg": lambda s: s.benchmark_reality_gap,
    }

    if metric not in metric_map:
        raise ValueError(f"Unknown metric: {metric}. Choose from {list(metric_map.keys())}")

    extract = metric_map[metric]
    result = np.zeros((len(alpha_range), len(beta_range)))

    for i, alpha in enumerate(alpha_range):
        for j, beta in enumerate(beta_range):
            eco: Ecosystem = Ecosystem.create_default(
                n_models=n_models, dim=dim,
                contamination_rate=alpha,
                benchmark_adaptation_rate=gamma,
                learning_rate=eta,
                benchmark_pressure=beta,
                seed=seed,
            )
            eco.run(n_steps)
            result[i, j] = extract(eco.current_state)

    return {
        "alpha_range": alpha_range,
        "beta_range": beta_range,
        "values": result,
        "metric": metric,
    }


def bifurcation_analysis(
    parameter_name: str = "alpha",
    parameter_range: np.ndarray = None,
    n_steps: int = 300,
    n_models: int = 2,
    dim: int = 5,
    base_params: Optional[Dict] = None,
    seed: int = 42,
) -> Dict:
    """
    Compute bifurcation diagram: track long-term behavior as a parameter varies.

    Records the last `n_record` values of diversity to detect oscillations,
    fixed points, or chaos.

    Parameters
    ----------
    parameter_name : str
        Which parameter to vary: "alpha", "eta", "beta", "gamma".
    parameter_range : np.ndarray
        Values to scan.
    n_steps : int
        Total simulation steps.
    base_params : dict
        Base parameter values.

    Returns
    -------
    dict
        Bifurcation data.
    """
    if parameter_range is None:
        parameter_range = np.linspace(0, 1, 100)

    if base_params is None:
        base_params = {
            "alpha": 0.3, "eta": 0.1, "beta": 0.05, "gamma": 0.0
        }

    n_record = 50  # Record last 50 steps
    all_diversities: List[np.ndarray] = []

    for val in parameter_range:
        params = base_params.copy()
        params[parameter_name] = val

        eco: Ecosystem = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=params["alpha"],
            learning_rate=params["eta"],
            benchmark_pressure=params["beta"],
            benchmark_adaptation_rate=params["gamma"],
            seed=seed,
        )
        eco.run(n_steps)
        div_traj = eco.get_diversity_trajectory()
        all_diversities.append(div_traj[-n_record:])

    return {
        "parameter_name": parameter_name,
        "parameter_range": parameter_range,
        "diversity_samples": all_diversities,
        "n_steps": n_steps,
        "n_record": n_record,
    }
