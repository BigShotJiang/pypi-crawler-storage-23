"""
equilibria.py - Fixed point computation and stability analysis.

Analyzes the dynamical system to find equilibrium points and characterize
their stability through Jacobian eigenvalue analysis.

The update rule for model i is:

    c_i(t+1) = c_i(t) + η(1+κα) · [μ_D(t) - c_i(t)]
                       + β · [b(t) - c_i(t)]
                       + σ · [s_i - c_i(t)]
                       + ε_i(t)

where:
- μ_D(t) = (1-α)·μ_nat + α·c̄(t) is the contaminated data pool mean
- η_eff(α) = η(1+κα) is the variance-compression effective learning rate
- κ is the variance coupling parameter
- σ is the specialization strength
"""

import numpy as np
from typing import Tuple, List, Optional, Dict
from dataclasses import dataclass

from llm_eco_sim.theory.formal_proofs import compute_full_jacobian


@dataclass
class FixedPoint:
    """Represents a fixed point of the ecosystem dynamics."""
    capabilities: np.ndarray   # (N, d) array of model capabilities at equilibrium
    data_pool_mean: np.ndarray  # (d,) effective data pool mean
    benchmark_target: np.ndarray  # (d,) benchmark target
    eigenvalues: np.ndarray   # Eigenvalues of the Jacobian
    is_stable: bool           # Whether all eigenvalues have magnitude < 1
    spectral_radius: float    # Maximum eigenvalue magnitude


def compute_fixed_point_analytical(
    n_models: int,
    dim: int,
    alpha: float,
    eta: float,
    beta: float,
    gamma: float,
    natural_mean: np.ndarray,
    benchmark_initial: np.ndarray,
    kappa: float = 3.0,
    sigma: float = 0.12,
) -> FixedPoint:
    """
    Analytically compute the fixed point for the symmetric case.

    In the symmetric case (all models identical at equilibrium):
    c_1* = c_2* = ... = c*

    For static benchmark (γ=0):
        c* = [η_eff(α)(1-α)·μ_nat + β·b + σ·S] / [η_eff(α)(1-α) + β + σ]

    where η_eff(α) = η(1+κα).
    """
    natural_mean = np.array(natural_mean, dtype=np.float64)
    benchmark_initial = np.array(benchmark_initial, dtype=np.float64)

    eta_eff: float = eta * (1.0 + kappa * alpha)

    if gamma == 0:
        b_star = benchmark_initial.copy()
        denom: float = eta_eff * (1.0 - alpha) + beta + sigma
        if abs(denom) < 1e-15:
            c_star = natural_mean.copy()
        else:
            # S = μ_nat for symmetric initialization
            c_star = (eta_eff * (1.0 - alpha) * natural_mean
                      + beta * b_star
                      + sigma * natural_mean) / denom
    else:
        if eta_eff * (1.0 - alpha) > 1e-15:
            c_star = natural_mean.copy()
            b_star = natural_mean.copy()
        else:
            c_star = benchmark_initial.copy()
            b_star = benchmark_initial.copy()

    capabilities = np.tile(c_star, (n_models, 1))
    data_pool_mean = (1.0 - alpha) * natural_mean + alpha * c_star

    eigenvalues = compute_jacobian_eigenvalues(
        n_models, alpha, eta, beta, gamma, kappa, sigma
    )
    spectral_radius = float(np.max(np.abs(eigenvalues)))
    is_stable: bool = spectral_radius < 1.0

    return FixedPoint(
        capabilities=capabilities,
        data_pool_mean=data_pool_mean,
        benchmark_target=b_star,
        eigenvalues=eigenvalues,
        is_stable=is_stable,
        spectral_radius=spectral_radius,
    )


def compute_jacobian_eigenvalues(
    n_models: int,
    alpha: float,
    eta: float,
    beta: float,
    gamma: float,
    kappa: float = 3.0,
    sigma: float = 0.12,
) -> np.ndarray:
    """
    Compute eigenvalues of the coupling Jacobian J_coupling.

    Delegates to ``compute_full_jacobian`` in ``formal_proofs`` for the
    matrix construction, then returns its numerical eigenvalues.
    """
    J = compute_full_jacobian(n_models, 1, alpha, eta, beta, gamma, kappa, sigma)
    eigenvalues = np.linalg.eigvals(J)
    return eigenvalues


def stability_analysis(
    alpha: float,
    eta: float,
    beta: float,
    gamma: float,
    n_models: int = 2,
    kappa: float = 3.0,
    sigma: float = 0.12,
) -> Dict:
    """Perform stability analysis for given parameters."""
    eigenvalues = compute_jacobian_eigenvalues(
        n_models, alpha, eta, beta, gamma, kappa, sigma
    )
    spectral_radius = float(np.max(np.abs(eigenvalues)))

    return {
        "eigenvalues": eigenvalues,
        "spectral_radius": spectral_radius,
        "is_stable": spectral_radius < 1.0,
        "is_oscillatory": any(np.abs(np.imag(eigenvalues)) > 1e-10),
        "convergence_rate": (-np.log(spectral_radius) if 0 < spectral_radius < 1
                             else float('inf') if spectral_radius == 0
                             else float('-inf')),
        "dominant_eigenvalue": eigenvalues[np.argmax(np.abs(eigenvalues))],
    }


def find_critical_alpha(
    eta: float,
    beta: float,
    gamma: float = 0.0,
    n_models: int = 2,
    kappa: float = 3.0,
    sigma: float = 0.12,
    resolution: int = 1000,
) -> float:
    """Find the critical α where the system becomes unstable."""
    alphas = np.linspace(0, 1, resolution)
    prev_stable = None

    for alpha in alphas:
        result: dict = stability_analysis(alpha, eta, beta, gamma, n_models, kappa, sigma)
        if prev_stable is not None and prev_stable and not result["is_stable"]:
            return float(alpha)
        prev_stable = result["is_stable"]

    if prev_stable:
        return 1.0
    return 0.0


def compute_diversity_erosion_threshold(
    eta: float,
    beta: float,
    n_models: int = 2,
    kappa: float = 3.0,
    sigma: float = 0.12,
    dim: int = 10,
    noise_std: float = 0.005,
    target_ratio: float = 0.5,
) -> float:
    """
    Compute the α where diversity drops to target_ratio of the α=0 baseline.

    Uses the exact equilibrium formula:
        D_eq(α) = σ²/(1-λ)² + 2dε²/((1-λ)(1+λ))
    where λ(α) = 1 - η(1+κα) - β - σ

    Binary search for α where D_eq(α)/D_eq(0) = target_ratio.
    """
    from llm_eco_sim.theory.formal_proofs import compute_diversity_curve
    curve: dict = compute_diversity_curve(
        eta=eta, beta=beta, kappa=kappa, sigma=sigma,
        dim=dim, noise_std=noise_std, n_points=1000,
    )
    # Find where ratio crosses target
    for i, r in enumerate(curve['D_ratio']):
        if r < target_ratio:
            return float(curve['alpha_range'][i])
    return 1.0
