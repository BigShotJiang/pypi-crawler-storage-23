"""Theory modules for ecosystem analysis."""

from llm_eco_sim.theory.diversity_metrics import (
    pairwise_diversity,
    shannon_diversity,
    simpson_diversity,
    spectral_diversity,
    effective_number_of_species,
    diversity_report,
)
from llm_eco_sim.theory.equilibria import (
    FixedPoint,
    compute_fixed_point_analytical,
    compute_jacobian_eigenvalues,
    stability_analysis,
    find_critical_alpha,
    compute_diversity_erosion_threshold,
)
from llm_eco_sim.theory.phase_transitions import (
    PhaseTransitionResult,
    scan_contamination_rate,
    scan_benchmark_pressure,
    detect_paradoxical_intervention,
    compute_phase_diagram,
    bifurcation_analysis,
)
from llm_eco_sim.theory.formal_proofs import (
    compute_full_jacobian,
    compute_eigenvalues_analytical,
    compute_diversity_curve,
    compute_stability_map,
    verify_eigenvalue_derivation,
    prove_theorem_1,
    prove_theorem_2,
    prove_theorem_3,
    Theorem1Result,
    Theorem2Result,
    Theorem3Result,
)

__all__: list[str] = [
    # Diversity metrics
    "pairwise_diversity", "shannon_diversity", "simpson_diversity",
    "spectral_diversity", "effective_number_of_species", "diversity_report",
    # Equilibria
    "FixedPoint", "compute_fixed_point_analytical", "compute_jacobian_eigenvalues",
    "stability_analysis", "find_critical_alpha", "compute_diversity_erosion_threshold",
    # Phase transitions
    "PhaseTransitionResult", "scan_contamination_rate", "scan_benchmark_pressure",
    "detect_paradoxical_intervention", "compute_phase_diagram", "bifurcation_analysis",
    # Formal proofs
    "compute_full_jacobian", "compute_eigenvalues_analytical",
    "compute_diversity_curve", "compute_stability_map",
    "verify_eigenvalue_derivation",
    "prove_theorem_1", "prove_theorem_2", "prove_theorem_3",
    "Theorem1Result", "Theorem2Result", "Theorem3Result",
]
