"""
data_pool.py - Data distribution with contamination dynamics.

The data pool represents the shared training data available to all models.
It is a mixture of natural (human-generated) data and synthetic (AI-generated)
data, controlled by the contamination parameter alpha.

D(t) = (1 - alpha) * D_natural + alpha * D_synthetic(t)
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class DataPool:
    """
    Shared data pool with contamination dynamics.

    Parameters
    ----------
    dim : int
        Dimensionality of the data space (must match model capability_dim).
    natural_mean : Optional[np.ndarray]
        Mean of the natural data distribution. If None, defaults to zeros.
    natural_variance : float
        Variance of the natural data distribution (isotropic).
    contamination_rate : float
        Alpha in [0, 1] - fraction of synthetic data in the pool.
    """

    dim: int
    natural_mean: Optional[np.ndarray] = None
    natural_variance: float = 1.0
    contamination_rate: float = 0.0

    # Internal state
    synthetic_mean: np.ndarray = field(init=False, repr=False)
    synthetic_variance: float = field(init=False, repr=False)
    _history: list = field(init=False, repr=False, default_factory=list)

    def __post_init__(self) -> None:
        if self.natural_mean is None:
            self.natural_mean = np.zeros(self.dim)
        else:
            self.natural_mean = np.array(self.natural_mean, dtype=np.float64)

        if self.natural_mean.shape != (self.dim,):
            raise ValueError(
                f"natural_mean shape {self.natural_mean.shape} != ({self.dim},)"
            )

        if not 0.0 <= self.contamination_rate <= 1.0:
            raise ValueError(f"contamination_rate must be in [0, 1], got {self.contamination_rate}")

        # Initialize synthetic component to match natural (no contamination effect yet)
        self.synthetic_mean = self.natural_mean.copy()
        self.synthetic_variance = self.natural_variance

        self._history = [self._snapshot()]

    def _snapshot(self) -> dict:
        return {
            "effective_mean": self.effective_mean.copy(),
            "effective_variance": self.effective_variance,
            "synthetic_mean": self.synthetic_mean.copy(),
            "synthetic_variance": self.synthetic_variance,
            "contamination_rate": self.contamination_rate,
        }

    @property
    def alpha(self) -> float:
        """Alias for contamination_rate."""
        return self.contamination_rate

    @alpha.setter
    def alpha(self, value: float) -> None:
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"alpha must be in [0, 1], got {value}")
        self.contamination_rate = value

    @property
    def effective_mean(self) -> np.ndarray:
        """
        Effective mean of the data pool:
        mu_D(t) = (1 - alpha) * mu_natural + alpha * mu_synthetic(t)
        """
        return (1 - self.contamination_rate) * self.natural_mean + \
            self.contamination_rate * self.synthetic_mean

    @property
    def effective_variance(self) -> float:
        """
        Effective variance of the data pool (simplified isotropic model):
        sigma_D^2 = (1 - alpha) * sigma_nat^2 + alpha * sigma_syn^2
        """
        return (1 - self.contamination_rate) * self.natural_variance + \
            self.contamination_rate * self.synthetic_variance

    def update_synthetic(
        self,
        model_means: List[np.ndarray],
        model_variances: List[float],
    ) -> None:
        """
        Update the synthetic component based on current model outputs.

        mu_synthetic(t+1) = (1/N) * sum_i c_i(t)
        sigma_synthetic(t+1) = (1/N) * sum_i sigma_i^2

        Parameters
        ----------
        model_means : List[np.ndarray]
            List of capability vectors (generative means) from each model.
        model_variances : List[float]
            List of generative variances from each model.
        """
        N = len(model_means)
        if N == 0:
            return

        self.synthetic_mean = np.mean(model_means, axis=0)
        self.synthetic_variance = np.mean(model_variances)
        self._model_means = [m.copy() for m in model_means]
        self._history.append(self._snapshot())

    def effective_mean_for_model(self, model_index: int, self_weight: float = 0.3) -> np.ndarray:
        """
        Compute the effective data pool mean as seen by a specific model.

        Each model sees a data pool that is biased toward its own outputs
        (self-reinforcement). This creates alpha-dependent coupling that
        drives diversity erosion.

        mu_D_i(t) = (1-alpha) * mu_natural + alpha * [(1-w)*c_bar(t) + w*c_i(t)]

        where w is the self-reinforcement weight.

        Parameters
        ----------
        model_index : int
            Index of the model.
        self_weight : float
            Weight of self-reinforcement (0 = no self-bias, 1 = only own data).

        Returns
        -------
        np.ndarray
            Effective data pool mean as seen by model i.
        """
        if not hasattr(self, '_model_means') or not self._model_means:
            return self.effective_mean

        N = len(self._model_means)
        if model_index >= N:
            return self.effective_mean

        # Synthetic mean biased toward this model's own outputs
        c_bar = np.mean(self._model_means, axis=0)
        c_i = self._model_means[model_index]
        biased_synthetic = (1 - self_weight) * c_bar + self_weight * c_i

        return (1 - self.contamination_rate) * self.natural_mean + \
            self.contamination_rate * biased_synthetic

    def contamination_divergence(self) -> float:
        """
        Measure how far the synthetic data has diverged from natural data.
        Returns ||mu_synthetic - mu_natural|| / ||mu_natural|| (or absolute if natural is zero).
        """
        diff = np.linalg.norm(self.synthetic_mean - self.natural_mean)
        nat_norm = np.linalg.norm(self.natural_mean)
        if nat_norm > 1e-10:
            return float(diff / nat_norm)
        return float(diff)

    def effective_contamination(self) -> float:
        """
        Effective contamination level accounting for how different synthetic is from natural.
        Contam(t) = alpha * (divergence between synthetic and natural means)
        """
        return self.contamination_rate * self.contamination_divergence()

    @property
    def history(self) -> List[dict]:
        """Return the full history of data pool states."""
        return self._history

    def reset(self) -> None:
        """Reset synthetic component to match natural data."""
        self.synthetic_mean = self.natural_mean.copy()
        self.synthetic_variance = self.natural_variance
        self._history = [self._snapshot()]

    def __repr__(self) -> str:
        return (
            f"DataPool(dim={self.dim}, alpha={self.contamination_rate:.3f}, "
            f"effective_mean_norm={np.linalg.norm(self.effective_mean):.4f})"
        )
