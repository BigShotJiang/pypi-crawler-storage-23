"""
benchmark.py - Evolving benchmark with difficulty adaptation.

The benchmark represents the evaluation standard against which models are measured.
It can be static (fixed target) or adaptive (moves in response to model performance).

Static mode (gamma=0):  b(t+1) = b(t)
Adaptive mode (gamma>0): b(t+1) = b(t) + gamma * [b(t) - c_bar(t)]

In adaptive mode, the benchmark moves AWAY from the mean model performance,
simulating the real-world phenomenon where benchmarks get harder as models improve.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Benchmark:
    """
    Benchmark with optional adaptive difficulty.

    Parameters
    ----------
    dim : int
        Dimensionality of the benchmark target space.
    initial_target : Optional[np.ndarray]
        Initial benchmark target vector b(0). If None, defaults to ones (normalized).
    adaptation_rate : float
        Gamma >= 0. Rate at which benchmark adapts to model performance.
        gamma=0 means static benchmark.
    difficulty : float
        Spread/tolerance of the benchmark (sigma_b). Lower = harder.
    target_drift_noise : float
        Optional noise added to benchmark updates for stochasticity.
    """

    dim: int
    initial_target: Optional[np.ndarray] = None
    adaptation_rate: float = 0.0
    difficulty: float = 1.0
    target_drift_noise: float = 0.0
    seed: int = 42

    # Internal state
    target: np.ndarray = field(init=False, repr=False)
    _rng: np.random.Generator = field(init=False, repr=False)
    _history: list = field(init=False, repr=False, default_factory=list)

    def __post_init__(self) -> None:
        self._rng = np.random.default_rng(self.seed)

        if self.initial_target is not None:
            self.target = np.array(self.initial_target, dtype=np.float64)
            if self.target.shape != (self.dim,):
                raise ValueError(
                    f"initial_target shape {self.target.shape} != ({self.dim},)"
                )
        else:
            # Default: unit vector in all dimensions (represents "ideal" capability)
            self.target = np.ones(self.dim) / np.sqrt(self.dim)

        self._history = [self.target.copy()]

    @property
    def is_adaptive(self) -> bool:
        """Whether the benchmark adapts to model performance."""
        return self.adaptation_rate > 0.0

    def update(self, mean_model_capability: np.ndarray) -> None:
        """
        Update the benchmark based on mean model performance.

        b(t+1) = b(t) + gamma * [b(t) - c_bar(t)] + noise

        In adaptive mode, the benchmark moves AWAY from where models currently are,
        making it progressively harder. This captures the real-world dynamic where
        benchmarks are updated to remain challenging.

        Parameters
        ----------
        mean_model_capability : np.ndarray
            Mean capability vector across all models: c_bar(t) = (1/N) sum c_i(t)
        """
        if self.adaptation_rate > 0:
            # Benchmark moves away from current model performance
            drift = self.adaptation_rate * (self.target - mean_model_capability)
            noise = self._rng.normal(0, self.target_drift_noise, size=self.dim) \
                if self.target_drift_noise > 0 else np.zeros(self.dim)
            self.target = self.target + drift + noise

            # Prevent unbounded divergence: clamp benchmark norm
            max_norm = 10.0 * max(np.linalg.norm(self._history[0]), 1.0)
            current_norm = np.linalg.norm(self.target)
            if current_norm > max_norm:
                self.target = self.target * (max_norm / current_norm)

        self._history.append(self.target.copy())

    def score_model(self, capability: np.ndarray) -> float:
        """
        Score a model's capability against this benchmark.

        Score = exp(-||c - b||^2 / (2 * sigma_b^2))

        Returns a value in (0, 1] where 1 = perfect match.

        Parameters
        ----------
        capability : np.ndarray
            Model's capability vector.

        Returns
        -------
        float
            Benchmark score in (0, 1].
        """
        dist_sq = np.sum((capability - self.target) ** 2)
        return float(np.exp(-dist_sq / (2 * self.difficulty ** 2)))

    def distance_from(self, capability: np.ndarray) -> float:
        """Euclidean distance from a capability vector to the benchmark target."""
        return float(np.linalg.norm(capability - self.target))

    def distance_from_natural(self, natural_mean: np.ndarray) -> float:
        """
        Distance between benchmark target and natural data distribution.
        Measures how much the benchmark has diverged from reality.
        """
        return float(np.linalg.norm(self.target - natural_mean))

    @property
    def history(self) -> np.ndarray:
        """Return the full trajectory of benchmark targets as (T+1, d) array."""
        return np.array(self._history)

    def reset(self) -> None:
        """Reset benchmark to initial state."""
        self.target = self._history[0].copy()
        self._history = [self.target.copy()]
        self._rng = np.random.default_rng(self.seed)

    def __repr__(self) -> str:
        mode = "adaptive" if self.is_adaptive else "static"
        return (
            f"Benchmark(dim={self.dim}, mode={mode}, "
            f"gamma={self.adaptation_rate}, difficulty={self.difficulty})"
        )
