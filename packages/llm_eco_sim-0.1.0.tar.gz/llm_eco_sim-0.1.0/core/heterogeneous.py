"""
heterogeneous.py - Generalized ecosystem with heterogeneous agents.

Extends the base Ecosystem to support:
1. Heterogeneous agents (different η_i, β_i, σ_i per model)
2. Asymmetric contamination (higher-performing models contribute more)
3. Compute cost functions (linking performance to resources)
4. Market share dynamics (popularity affects data pool influence)

Uses the same variance-compression mechanism as the base Ecosystem:
    η_eff_i(α) = η_i · √(compute_i) · (1 + κ·α)
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Callable

from llm_eco_sim.core.model_agent import ModelAgent
from llm_eco_sim.core.data_pool import DataPool
from llm_eco_sim.core.benchmark import Benchmark
from llm_eco_sim.core.ecosystem import Ecosystem, EcosystemState


@dataclass
class HeterogeneousModelAgent(ModelAgent):
    """
    Extended model agent with heterogeneous parameters and market dynamics.

    Additional parameters beyond ModelAgent:
    - market_share: fraction of the data pool this model influences
    - compute_budget: computational resources available for training
    - strategy: 'generalist' or 'specialist' (affects specialization strength)
    """
    market_share: float = 1.0  # will be normalized
    compute_budget: float = 1.0
    strategy: str = 'generalist'
    _market_share_history: list = field(init=False, repr=False, default_factory=list)

    def __post_init__(self) -> None:
        super().__post_init__()
        self._market_share_history = [self.market_share]

    def effective_learning_rate(self) -> float:
        """
        Effective learning rate scales with compute budget.
        More compute -> faster learning, with diminishing returns.
        η_eff = η · √(compute_budget)
        """
        return self.learning_rate * np.sqrt(self.compute_budget)

    def effective_noise(self) -> float:
        """
        Training noise decreases with compute budget.
        More compute -> lower noise (better optimization).
        ε_eff = ε / √(compute_budget)
        """
        return self.noise_std / np.sqrt(max(self.compute_budget, 0.01))

    def update_market_share(self, new_share: float) -> None:
        """Update market share and record history."""
        self.market_share = new_share
        self._market_share_history.append(new_share)

    @property
    def market_share_history(self) -> np.ndarray:
        return np.array(self._market_share_history)

    def reset(self) -> None:
        """Reset including market share history."""
        super().reset()
        self._market_share_history = [self._market_share_history[0]]


class HeterogeneousEcosystem(Ecosystem):
    """
    Generalized ecosystem with heterogeneous agents and asymmetric dynamics.

    Uses the variance-compression mechanism from the base Ecosystem, extended
    with per-model compute budgets and market share dynamics.

    Parameters
    ----------
    models : List[HeterogeneousModelAgent]
        Heterogeneous model agents.
    data_pool : DataPool
        Shared data pool.
    benchmark : Benchmark
        Benchmark (static or adaptive).
    variance_coupling : float
        κ parameter: how much contamination accelerates convergence.
    market_dynamics : str
        How market shares evolve: 'fixed', 'proportional', 'winner_take_all'.
    market_sensitivity : float
        How quickly market shares respond to performance differences.
    asymmetric_contamination : bool
        If True, model contributions to data pool are weighted by market share.
    """

    def __init__(
        self,
        models: List[HeterogeneousModelAgent],
        data_pool: DataPool,
        benchmark: Benchmark,
        variance_coupling: float = 3.0,
        market_dynamics: str = 'proportional',
        market_sensitivity: float = 1.0,
        asymmetric_contamination: bool = True,
    ) -> None:
        self.market_dynamics = market_dynamics
        self.market_sensitivity = market_sensitivity
        self.asymmetric_contamination = asymmetric_contamination

        super().__init__(
            models=models,
            data_pool=data_pool,
            benchmark=benchmark,
            variance_coupling=variance_coupling,
        )

        # Normalize initial market shares
        total = sum(m.market_share for m in self.models)
        if total > 0:
            for m in self.models:
                m.market_share /= total

    @classmethod
    def create_heterogeneous(
        cls,
        model_configs: List[Dict[str, Any]] = None,
        dim: int = 5,
        contamination_rate: float = 0.3,
        benchmark_adaptation_rate: float = 0.0,
        variance_coupling: float = 3.0,
        market_dynamics: str = 'proportional',
        market_sensitivity: float = 1.0,
        asymmetric_contamination: bool = True,
        seed: int = 42,
    ) -> "HeterogeneousEcosystem":
        """Factory method to create a heterogeneous ecosystem."""
        rng = np.random.default_rng(seed)

        if model_configs is None:
            model_configs = [
                {
                    'name': 'Frontier_Lab',
                    'learning_rate': 0.08,
                    'benchmark_pressure': 0.05,
                    'noise_std': 0.003,
                    'specialization_strength': 0.08,
                    'compute_budget': 4.0,
                    'market_share': 0.5,
                    'strategy': 'generalist',
                },
                {
                    'name': 'Mid_Tier',
                    'learning_rate': 0.05,
                    'benchmark_pressure': 0.03,
                    'noise_std': 0.008,
                    'specialization_strength': 0.12,
                    'compute_budget': 1.0,
                    'market_share': 0.3,
                    'strategy': 'generalist',
                },
                {
                    'name': 'Specialist',
                    'learning_rate': 0.03,
                    'benchmark_pressure': 0.01,
                    'noise_std': 0.008,
                    'specialization_strength': 0.20,
                    'compute_budget': 0.5,
                    'market_share': 0.2,
                    'strategy': 'specialist',
                },
            ]

        natural_mean = np.zeros(dim)
        models: list[HeterogeneousModelAgent] = []
        for cfg in model_configs:
            model_seed = int(rng.integers(0, 2**31))
            init_cap = natural_mean + rng.standard_normal(dim) * 1.0
            models.append(
                HeterogeneousModelAgent(
                    name=cfg.get('name', f'Model_{len(models)}'),
                    capability_dim=dim,
                    initial_capability=init_cap,
                    learning_rate=cfg.get('learning_rate', 0.05),
                    benchmark_pressure=cfg.get('benchmark_pressure', 0.02),
                    noise_std=cfg.get('noise_std', 0.005),
                    specialization_strength=cfg.get('specialization_strength', 0.12),
                    compute_budget=cfg.get('compute_budget', 1.0),
                    market_share=cfg.get('market_share', 1.0),
                    strategy=cfg.get('strategy', 'generalist'),
                    seed=model_seed,
                )
            )

        data_pool = DataPool(
            dim=dim,
            natural_mean=natural_mean,
            contamination_rate=contamination_rate,
        )

        benchmark = Benchmark(
            dim=dim,
            adaptation_rate=benchmark_adaptation_rate,
            seed=int(rng.integers(0, 2**31)),
        )

        return cls(
            models=models,
            data_pool=data_pool,
            benchmark=benchmark,
            variance_coupling=variance_coupling,
            market_dynamics=market_dynamics,
            market_sensitivity=market_sensitivity,
            asymmetric_contamination=asymmetric_contamination,
        )

    def step(self) -> EcosystemState:
        """
        Execute one time step with heterogeneous dynamics.

        Update order:
        1. Models generate outputs (weighted by market share if asymmetric)
        2. Data pool updates
        3. Models retrain with compute-dependent and α-dependent rates
        4. Benchmark adapts
        5. Market shares update based on performance
        """
        # Step 1 & 2: Data pool update (possibly asymmetric)
        if self.asymmetric_contamination:
            model_means: list = []
            model_variances: list[float] = []
            shares = np.array([m.market_share for m in self.models])
            shares = shares / shares.sum()

            for m in self.models:
                model_means.append(m.generative_mean())
                model_variances.append(m.generative_variance())

            # Weighted synthetic mean (popular models contribute more)
            weighted_mean = np.zeros(self.dim)
            weighted_var = 0.0
            for i, (mean, var) in enumerate(zip(model_means, model_variances)):
                weighted_mean += shares[i] * mean
                weighted_var += shares[i] * var

            self.data_pool.synthetic_mean = weighted_mean
            self.data_pool.synthetic_variance = weighted_var
            self.data_pool._model_means = [m.copy() for m in model_means]
            self.data_pool._history.append(self.data_pool._snapshot())
        else:
            model_means = [m.generative_mean() for m in self.models]
            model_variances: list[float] = [m.generative_variance() for m in self.models]
            self.data_pool.update_synthetic(model_means, model_variances)

        # Step 3: Each model retrains with variance-compression mechanism
        data_mean = self.data_pool.effective_mean
        alpha = self.data_pool.contamination_rate
        lr_multiplier = 1.0 + self.variance_coupling * alpha

        for model in self.models:
            orig_lr = model.learning_rate
            orig_noise = model.noise_std

            if isinstance(model, HeterogeneousModelAgent):
                # Compute-dependent + α-dependent effective learning rate
                model.learning_rate = model.effective_learning_rate() * lr_multiplier
                model.noise_std = model.effective_noise()
            else:
                model.learning_rate = orig_lr * lr_multiplier

            model.update(
                data_pool_mean=data_mean,
                benchmark_target=self.benchmark.target,
            )

            # Restore original parameters
            model.learning_rate = orig_lr
            model.noise_std = orig_noise

        # Step 4: Benchmark adapts
        mean_capability = np.mean(
            [m.capability for m in self.models], axis=0
        )
        self.benchmark.update(mean_capability)

        # Step 5: Update market shares
        self._update_market_shares()

        # Advance time and record state
        self.time_step += 1
        state = self._compute_state()
        self._state_history.append(state)

        return state

    def _update_market_shares(self) -> None:
        """
        Update market shares based on benchmark performance.

        Three dynamics:
        - 'fixed': shares don't change (but history is still recorded)
        - 'proportional': shares proportional to softmax of benchmark scores
        - 'winner_take_all': top performer gets increasing share
        """
        if self.market_dynamics == 'fixed':
            for model in self.models:
                if isinstance(model, HeterogeneousModelAgent):
                    model._market_share_history.append(model.market_share)
            return

        scores = np.array([
            self.benchmark.score_model(m.capability) for m in self.models
        ])

        if self.market_dynamics == 'proportional':
            exp_scores = np.exp(self.market_sensitivity * scores)
            new_shares = exp_scores / exp_scores.sum()

            for i, model in enumerate(self.models):
                if isinstance(model, HeterogeneousModelAgent):
                    blended = 0.95 * model.market_share + 0.05 * new_shares[i]
                    model.market_share = blended

        elif self.market_dynamics == 'winner_take_all':
            best_idx = np.argmax(scores)
            for i, model in enumerate(self.models):
                if isinstance(model, HeterogeneousModelAgent):
                    if i == best_idx:
                        new_share = min(model.market_share * 1.01, 0.9)
                    else:
                        new_share = max(model.market_share * 0.99, 0.05)
                    model.market_share = new_share

        # Normalize first, then append to history (avoids discontinuous jumps)
        total = sum(m.market_share for m in self.models)
        if total > 0:
            for m in self.models:
                if isinstance(m, HeterogeneousModelAgent):
                    m.market_share = m.market_share / total
                    m._market_share_history.append(m.market_share)

    def get_market_share_trajectories(self) -> Dict[str, np.ndarray]:
        """Return market share trajectories for each model."""
        result: dict[str, np.ndarray] = {}
        for m in self.models:
            if isinstance(m, HeterogeneousModelAgent):
                result[m.name] = m.market_share_history
        return result

    def get_gini_coefficient(self) -> float:
        """
        Gini coefficient of market shares.
        0 = perfect equality, 1 = perfect inequality.
        """
        shares = np.array([
            m.market_share for m in self.models
            if isinstance(m, HeterogeneousModelAgent)
        ])
        shares = np.sort(shares)
        n = len(shares)
        if n == 0 or shares.sum() == 0:
            return 0.0
        index = np.arange(1, n + 1)
        return float((2 * np.sum(index * shares) - (n + 1) * shares.sum()) / (n * shares.sum()))

    def get_herfindahl_index(self) -> float:
        """
        Herfindahl-Hirschman Index (HHI) of market concentration.
        1/N = perfect competition, 1 = monopoly.
        """
        shares = np.array([
            m.market_share for m in self.models
            if isinstance(m, HeterogeneousModelAgent)
        ])
        return float(np.sum(shares ** 2))

    def summary(self) -> str:
        """Extended summary with market dynamics."""
        base = super().summary()
        lines: list[str] = [base, "---", "Market Dynamics:"]
        for m in self.models:
            if isinstance(m, HeterogeneousModelAgent):
                lines.append(
                    f"  {m.name}: share={m.market_share:.3f}, "
                    f"compute={m.compute_budget:.1f}, strategy={m.strategy}"
                )
        return "\n".join(lines)
