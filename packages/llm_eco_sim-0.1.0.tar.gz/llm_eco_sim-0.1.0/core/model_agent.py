"""
model_agent.py - Abstract model agent with capability vector and update rules.

Each model agent represents a deployed AI model characterized by:
- A capability vector c_i(t) in R^d
- A generative distribution G_i that produces synthetic data
- Update rules for retraining on contaminated data

Update Rule (per the mathematical framework):
    c_i(t+1) = c_i(t) + η·[μ_D^(i)(t) - c_i(t)]
                       + β·[b(t) - c_i(t)]
                       + σ·[s_i - c_i(t)]
                       + ε_i(t)

where μ_D^(i)(t) is the per-model effective data pool mean, which depends
on the contamination rate α and the self-reinforcement parameter w.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ModelAgent:
    """
    Represents a single AI model in the ecosystem.

    Parameters
    ----------
    name : str
        Human-readable identifier for this model.
    capability_dim : int
        Dimensionality d of the capability space.
    initial_capability : Optional[np.ndarray]
        Initial capability vector c_i(0). If None, sampled randomly.
    learning_rate : float
        Rate η at which the model adapts to the data pool.
    benchmark_pressure : float
        Rate β at which the model optimizes toward the benchmark.
    noise_std : float
        Standard deviation of stochastic training noise ε.
    generation_noise_std : float
        Noise in the model's generative distribution.
    specialization_strength : float
        Rate σ at which the model is pulled toward its specialization niche.
        Represents inherent architectural advantages and proprietary data.
    seed : Optional[int]
        Random seed for reproducibility.
    """

    name: str
    capability_dim: int
    initial_capability: Optional[np.ndarray] = None
    learning_rate: float = 0.1
    benchmark_pressure: float = 0.05
    noise_std: float = 0.01
    generation_noise_std: float = 0.05
    specialization_strength: float = 0.08
    seed: Optional[int] = None

    # Internal state (set in __post_init__)
    capability: np.ndarray = field(init=False, repr=False)
    specialization_target: np.ndarray = field(init=False, repr=False)
    _rng: np.random.Generator = field(init=False, repr=False)
    _history: list = field(init=False, repr=False, default_factory=list)

    def __post_init__(self) -> None:
        self._rng = np.random.default_rng(self.seed)
        if self.initial_capability is not None:
            self.capability = np.array(self.initial_capability, dtype=np.float64)
            if self.capability.shape != (self.capability_dim,):
                raise ValueError(
                    f"initial_capability shape {self.capability.shape} != ({self.capability_dim},)"
                )
        else:
            self.capability = self._rng.standard_normal(self.capability_dim)
        # Each model has a specialization niche (its initial position).
        # This represents the model's unique architecture/training data advantage.
        self.specialization_target = self.capability.copy()
        self._history = [self.capability.copy()]

    def generate(self, n_samples: int = 1) -> np.ndarray:
        """
        Generate synthetic data from this model's generative distribution.
        G_i ~ N(c_i, σ_gen² · I).
        """
        noise = self._rng.normal(
            0, self.generation_noise_std, size=(n_samples, self.capability_dim)
        )
        return self.capability[np.newaxis, :] + noise

    def generative_mean(self) -> np.ndarray:
        """Return the mean of the generative distribution (= capability vector)."""
        return self.capability.copy()

    def generative_variance(self) -> float:
        """Return the scalar variance of the generative distribution."""
        return self.generation_noise_std ** 2

    def update(
        self,
        data_pool_mean: np.ndarray,
        benchmark_target: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        Perform one retraining step.

        c_i(t+1) = c_i(t) + η·[μ_D^(i)(t) - c_i(t)]
                           + β·[b(t) - c_i(t)]
                           + σ·[s_i - c_i(t)]
                           + ε_i(t)

        The data_pool_mean passed here is the PER-MODEL effective mean
        μ_D^(i)(t), which already encodes the contamination dynamics.
        The α-dependent diversity erosion emerges from the fact that
        different models see different data pool means (due to
        self-reinforcement), and these means converge as α increases.

        Parameters
        ----------
        data_pool_mean : np.ndarray
            Per-model effective data pool mean μ_D^(i)(t).
        benchmark_target : Optional[np.ndarray]
            Current benchmark target vector. If None, no benchmark pressure.

        Returns
        -------
        np.ndarray
            Updated capability vector.
        """
        # Data-driven learning: pull toward per-model data pool mean
        data_gradient = self.learning_rate * (data_pool_mean - self.capability)

        # Benchmark pressure: pull toward benchmark target
        if benchmark_target is not None:
            bench_gradient = self.benchmark_pressure * (benchmark_target - self.capability)
        else:
            bench_gradient = np.zeros(self.capability_dim)

        # Specialization pressure: pull toward niche
        # Represents inherent architectural advantages, proprietary data,
        # and unique training methodologies that maintain diversity
        spec_gradient = self.specialization_strength * (
            self.specialization_target - self.capability
        )

        # Stochastic noise (training randomness)
        noise = self._rng.normal(0, self.noise_std, size=self.capability_dim)

        # Update
        self.capability = (self.capability + data_gradient + bench_gradient
                           + spec_gradient + noise)
        self._history.append(self.capability.copy())

        return self.capability.copy()

    def distance_to(self, target: np.ndarray) -> float:
        """Euclidean distance from current capability to a target vector."""
        return float(np.linalg.norm(self.capability - target))

    def performance_on(self, benchmark_target: np.ndarray) -> float:
        """Performance score on a benchmark (negative distance, higher is better)."""
        return -self.distance_to(benchmark_target)

    def real_world_performance(self, natural_mean: np.ndarray) -> float:
        """Real-world performance (negative distance to natural data distribution)."""
        return -self.distance_to(natural_mean)

    @property
    def history(self) -> np.ndarray:
        """Return the full trajectory of capability vectors as (T+1, d) array."""
        return np.array(self._history)

    def reset(self) -> None:
        """Reset the model to its initial state."""
        self.capability = self._history[0].copy()
        self.specialization_target = self.capability.copy()
        self._history = [self.capability.copy()]
        self._rng = np.random.default_rng(self.seed)

    def __repr__(self) -> str:
        return (
            f"ModelAgent(name='{self.name}', dim={self.capability_dim}, "
            f"η={self.learning_rate}, β={self.benchmark_pressure}, "
            f"σ={self.specialization_strength})"
        )
