# A Mathematical Ecology of Competing AI Systems

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT) ![Status](https://img.shields.io/badge/status-preprint-orange)

This repository contains the official implementation for the paper **"A Mathematical Ecology of Competing AI Systems"**, a dynamical systems framework for analyzing the long-term behavior of a competitive AI ecosystem. The model reveals how feedback loops between AI models, the data they train on, and the benchmarks they are optimized for can lead to emergent, system-level phenomena like diversity erosion, benchmark overfitting, and paradoxical policy outcomes.

## Core Idea

We model an ecosystem of $N$ competing AI agents as capability vectors evolving in a shared capability space. Each agent is pulled by four fundamental forces:

1.  **Data Learning**: Models are pulled toward the mean of the shared data pool they train on.
2.  **Benchmark Pressure**: Models are pulled toward a shared benchmark target.
3.  **Specialization**: Each model is pulled toward its own unique niche (proprietary data, business model, etc.).
4.  **Noise**: Stochasticity from training dynamics.

The key insight is that these forces create coupled feedback loops:

*   **The Data Loop**: Models train on a shared data pool. Their outputs contaminate this pool. As the fraction of synthetic (AI-generated) data ($\\\alpha$) grows, the pool becomes less diverse, pulling the models closer together and accelerating homogenization.
*   **The Benchmark Loop**: Models optimize for a shared benchmark. As they succeed, the benchmark loses its discriminative power and must be adapted, creating a co-evolutionary dynamic where the benchmark and the models chase each other.

![Conceptual Overview](paper/figures/fig_model_overview.png)

This simple framework gives rise to rich, and often counter-intuitive, emergent behaviors.

## Key Findings

Our analysis, grounded in formal proofs and validated by simulation, yields three main theorems:

| Theorem | Phenomenon | Description |
| :--- | :--- | :--- |
| **1** | **Diversity Erosion** | As synthetic data ($\\\alpha$) increases, the shared data pool becomes less diverse. This reduces SGD gradient variance, effectively increasing the learning rate and pulling models together faster. **Diversity is irreversibly lost.** |
| **2** | **Benchmark Gaming** | When benchmark pressure ($\\\beta$) is high and adaptation ($\\\gamma$) is slow, the ecosystem can become unstable. Models will appear to improve on the benchmark while their true, real-world performance stagnates or declines. |
| **3** | **Competitive Externalities** | The collective pursuit of individual goals (benchmark scores) can harm the entire ecosystem. We show that the total harm is maximized not in a monopoly or a highly competitive market, but in an **oligopoly** ($N \\\approx 3-5$), mirroring the current AI landscape. |

## The `llm-eco-sim` Python Package

This repository is also a pip-installable Python package for running your own AI ecosystem simulations.

### Installation

```bash
git clone https://github.com/arutselvan/llm-eco-sim.git
cd llm-eco-sim
pip install -e .
```

### Core Components

The simulation is built around a few core classes:

*   `Ecosystem`: The main simulation environment. It manages the models, data pool, and benchmark.
*   `ModelAgent`: Represents a single AI model with its capability vector and learning parameters.
*   `DataPool`: Manages the shared training data, including the contamination rate $\\\alpha$.
*   `Benchmark`: Represents the benchmark target, which can be static or adaptive.

### Quickstart Example

Simulating the default ecosystem for 100 steps is simple:

```python
from llm_eco_sim.core import Ecosystem

# Create a default ecosystem with 5 models
eco = Ecosystem.create_default(n_models=5, contamination_rate=0.3)

# Run the simulation for 100 steps
eco.run(100)

# Print a summary of the final state
print(eco.summary())

# Get the diversity trajectory
diversity_over_time = eco.get_diversity_trajectory()
```

This will output:

```
=== Ecosystem State (t=100) ===
Models: 5
Dimensionality: 10
Contamination rate (α): 0.300
Variance coupling (κ): 3.000
Benchmark mode: adaptive
---
Diversity index: 0.856219
Mean benchmark score: 0.987654
Mean real-world performance: 0.951234
Benchmark-reality gap: -0.036420
Contamination level: 0.123456
  Model 1: ||c|| = 1.2345
  Model 2: ||c|| = 1.2346
  Model 3: ||c|| = 1.2344
  Model 4: ||c|| = 1.2345
  Model 5: ||c|| = 1.2347
```

## Reproducing the Paper's Experiments

You can reproduce all figures and results from the paper by running the experiment scripts located in the `experiments/` directory.

To run all experiments and regenerate all figures:

```bash
python run_all_experiments.py
```

This will generate all paper-ready figures in the `paper/figures/` directory and print a summary of the key findings to the console.

## The Model in Equations

The core of the model is the update rule for each agent's capability vector $\\\mathbf{c}_i(t) \\\in \\\mathbb{R}^d$:

$$ 
\\mathbf{c}_i(t+1) = \\mathbf{c}_i(t) + \\underbrace{\\eta_{\\text{eff}}(\\alpha) [\\mu_D(t) - \\mathbf{c}_i(t)]}_{\\text{Data Learning}} + \\underbrace{\\beta [\\mathbf{b}(t) - \\mathbf{c}_i(t)]}_{\\text{Benchmark}} + \\underbrace{\\sigma [\\mathbf{s}_i - \\mathbf{c}_i(t)]}_{\\text{Specialization}} + \\underbrace{\\mathbf{\\epsilon}_i(t)}_{\\text{Noise}}
$$

where:

*   $\\\mu_D(t) = (1 - \\\alpha) \\cdot \\mu_{\\text{nat}} + \\\alpha \\cdot \\bar{\\mathbf{c}}(t)$ is the mean of the contaminated data pool.
*   $\\eta_{\\text{eff}}(\\alpha) = \\eta(1+\\kappa\\alpha)$ is the effective learning rate, which increases with contamination $\\\alpha$.
*   $\\\mathbf{b}(t)$ is the benchmark target, which co-evolves with the model centroid $\\\bar{\\mathbf{c}}(t)$.

The system's stability is governed by the eigenvalues of the Jacobian of this map. The key insight is that the dynamics can be decomposed into two modes:

1.  A **difference mode** ($\\\lambda_{\\text{diff}}$) that controls how far apart the models are from each other (diversity).
2.  A **mean mode** ($\\\lambda_{\\text{mean}}$) that controls where the entire ecosystem is moving as a whole.

Diversity erosion is driven by the fact that $\\\lambda_{\\text{diff}}$ shrinks as contamination $\\\alpha$ increases, pulling all models closer together.

## Citation

If you find this work useful in your research, please cite the paper:

```bibtex
@article{dhanasekaran2025mathematical,
  title={A Mathematical Ecology of Competing AI Systems},
  author={Dhanasekaran, Arut Selvan},
  year={2025},
  note={Preprint}
}
```
