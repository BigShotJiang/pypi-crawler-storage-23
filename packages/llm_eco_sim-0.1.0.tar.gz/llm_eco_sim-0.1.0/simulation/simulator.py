"""
simulator.py - Main simulation loop with configurable scenarios.

The Simulator wraps the Ecosystem with additional features:
- Progress tracking and logging
- Callback hooks for custom analysis
- Intervention scheduling
- Batch parameter sweeps
- Result aggregation and export
"""

import numpy as np
from typing import List, Dict, Optional, Callable, Any, Tuple
from dataclasses import dataclass, field
import time
import json

from llm_eco_sim.core.ecosystem import Ecosystem, EcosystemState


@dataclass
class SimulationConfig:
    """Configuration for a simulation run."""
    n_models: int = 2
    dim: int = 5
    contamination_rate: float = 0.3
    learning_rate: float = 0.1
    benchmark_pressure: float = 0.05
    benchmark_adaptation_rate: float = 0.0
    noise_std: float = 0.01
    n_steps: int = 200
    seed: int = 42
    natural_mean: Optional[np.ndarray] = None
    name: str = "default"
    description: str = ""

    def to_dict(self) -> dict:
        d: dict[str, float | int | str] = {
            "n_models": self.n_models,
            "dim": self.dim,
            "contamination_rate": self.contamination_rate,
            "learning_rate": self.learning_rate,
            "benchmark_pressure": self.benchmark_pressure,
            "benchmark_adaptation_rate": self.benchmark_adaptation_rate,
            "noise_std": self.noise_std,
            "n_steps": self.n_steps,
            "seed": self.seed,
            "name": self.name,
            "description": self.description,
        }
        if self.natural_mean is not None:
            d["natural_mean"] = self.natural_mean.tolist()
        return d


@dataclass
class SimulationResult:
    """Result of a simulation run."""
    config: SimulationConfig
    states: List[EcosystemState]
    ecosystem: Ecosystem
    wall_time: float
    interventions_applied: List[Dict]

    @property
    def diversity_trajectory(self) -> np.ndarray:
        return np.array([s.diversity_index for s in self.states])

    @property
    def benchmark_score_trajectory(self) -> np.ndarray:
        return np.array([s.mean_benchmark_score for s in self.states])

    @property
    def real_world_performance_trajectory(self) -> np.ndarray:
        return np.array([s.mean_real_world_performance for s in self.states])

    @property
    def brg_trajectory(self) -> np.ndarray:
        return np.array([s.benchmark_reality_gap for s in self.states])

    @property
    def contamination_trajectory(self) -> np.ndarray:
        return np.array([s.contamination_level for s in self.states])

    @property
    def time_steps(self) -> np.ndarray:
        return np.array([s.time_step for s in self.states])

    def summary(self) -> Dict:
        """Return summary statistics of the simulation."""
        return {
            "config_name": self.config.name,
            "n_steps": len(self.states) - 1,
            "wall_time_seconds": self.wall_time,
            "initial_diversity": self.states[0].diversity_index,
            "final_diversity": self.states[-1].diversity_index,
            "diversity_erosion_ratio": (
                self.states[-1].diversity_index / max(self.states[0].diversity_index, 1e-15)
            ),
            "initial_benchmark_score": self.states[0].mean_benchmark_score,
            "final_benchmark_score": self.states[-1].mean_benchmark_score,
            "initial_real_world_perf": self.states[0].mean_real_world_performance,
            "final_real_world_perf": self.states[-1].mean_real_world_performance,
            "final_brg": self.states[-1].benchmark_reality_gap,
            "n_interventions": len(self.interventions_applied),
        }


class Simulator:
    """
    Main simulation engine for llm-eco-sim.

    Provides a high-level interface for running simulations with:
    - Configurable parameters
    - Scheduled interventions
    - Progress callbacks
    - Batch sweeps

    Examples
    --------
    >>> sim = Simulator(SimulationConfig(n_steps=100, contamination_rate=0.5))
    >>> result = sim.run()
    >>> print(result.summary())
    """

    def __init__(self, config: Optional[SimulationConfig] = None) -> None:
        self.config = config or SimulationConfig()
        self._interventions: List[Tuple[int, Callable]] = []
        self._callbacks: List[Callable] = []
        self._ecosystem: Optional[Ecosystem] = None

    def set_config(self, config: SimulationConfig) -> None:
        """Set the simulation configuration."""
        self.config = config

    def add_intervention(self, step: int, intervention_fn: Callable[[Ecosystem], None]) -> None:
        """
        Schedule an intervention at a specific time step.

        Parameters
        ----------
        step : int
            Time step at which to apply the intervention.
        intervention_fn : Callable
            Function that takes an Ecosystem and modifies it in-place.
        """
        self._interventions.append((step, intervention_fn))
        self._interventions.sort(key=lambda x: x[0])

    def add_callback(self, callback_fn: Callable[[Ecosystem, int], None]) -> None:
        """
        Add a callback that runs after each time step.

        Parameters
        ----------
        callback_fn : Callable
            Function(ecosystem, step) called after each step.
        """
        self._callbacks.append(callback_fn)

    def run(self, verbose: bool = False) -> SimulationResult:
        """
        Run the simulation.

        Parameters
        ----------
        verbose : bool
            If True, print progress updates.

        Returns
        -------
        SimulationResult
        """
        start_time: float = time.time()

        # Create ecosystem
        self._ecosystem = Ecosystem.create_default(
            n_models=self.config.n_models,
            dim=self.config.dim,
            contamination_rate=self.config.contamination_rate,
            benchmark_adaptation_rate=self.config.benchmark_adaptation_rate,
            learning_rate=self.config.learning_rate,
            benchmark_pressure=self.config.benchmark_pressure,
            noise_std=self.config.noise_std,
            natural_mean=self.config.natural_mean,
            seed=self.config.seed,
        )

        # Prepare intervention schedule
        intervention_dict: dict = {}
        for step, fn in self._interventions:
            if step not in intervention_dict:
                intervention_dict[step] = []
            intervention_dict[step].append(fn)

        interventions_applied: list[dict] = []

        # Run simulation
        all_states: list[EcosystemState] = [self._ecosystem.current_state]

        for step in range(1, self.config.n_steps + 1):
            # Apply interventions
            if step in intervention_dict:
                for fn in intervention_dict[step]:
                    fn(self._ecosystem)
                    interventions_applied.append({
                        "step": step,
                        "function": fn.__name__ if hasattr(fn, '__name__') else str(fn),
                    })

            # Step the ecosystem
            state: EcosystemState = self._ecosystem.step()
            all_states.append(state)

            # Run callbacks
            for cb in self._callbacks:
                cb(self._ecosystem, step)

            # Progress
            if verbose and step % (self.config.n_steps // 10 or 1) == 0:
                print(
                    f"  Step {step}/{self.config.n_steps}: "
                    f"div={state.diversity_index:.4f}, "
                    f"bench={state.mean_benchmark_score:.4f}, "
                    f"rw={state.mean_real_world_performance:.4f}"
                )

        wall_time: float = time.time() - start_time

        return SimulationResult(
            config=self.config,
            states=all_states,
            ecosystem=self._ecosystem,
            wall_time=wall_time,
            interventions_applied=interventions_applied,
        )

    @staticmethod
    def parameter_sweep(
        param_name: str,
        param_values: np.ndarray,
        base_config: Optional[SimulationConfig] = None,
        verbose: bool = False,
    ) -> List[SimulationResult]:
        """
        Run a parameter sweep over a single parameter.

        Parameters
        ----------
        param_name : str
            Name of the parameter to sweep (must be a SimulationConfig field).
        param_values : np.ndarray
            Array of values to sweep over.
        base_config : SimulationConfig
            Base configuration (the swept parameter will be overridden).

        Returns
        -------
        List[SimulationResult]
            Results for each parameter value.
        """
        if base_config is None:
            base_config = SimulationConfig()

        results: list[SimulationResult] = []
        for val in param_values:
            config = SimulationConfig(**{
                **base_config.to_dict(),
                param_name: val,
                "name": f"{base_config.name}_{param_name}={val:.4f}",
            })
            # Remove natural_mean from dict if it was None
            sim = Simulator(config)
            result: SimulationResult = sim.run(verbose=verbose)
            results.append(result)

            if verbose:
                s: dict = result.summary()
                print(f"{param_name}={val:.4f}: div={s['final_diversity']:.4f}, "
                      f"bench={s['final_benchmark_score']:.4f}")

        return results

    @staticmethod
    def compare_scenarios(
        configs: List[SimulationConfig],
        verbose: bool = False,
    ) -> List[SimulationResult]:
        """
        Run multiple scenario configurations and return results for comparison.

        Parameters
        ----------
        configs : List[SimulationConfig]
            List of configurations to compare.

        Returns
        -------
        List[SimulationResult]
        """
        results: list[SimulationResult] = []
        for config in configs:
            sim = Simulator(config)
            result: SimulationResult = sim.run(verbose=verbose)
            results.append(result)
            if verbose:
                print(f"Scenario '{config.name}': {result.summary()}")
        return results
