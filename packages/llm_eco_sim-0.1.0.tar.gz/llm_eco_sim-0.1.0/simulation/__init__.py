"""Simulation engine and pre-built scenarios."""

from llm_eco_sim.simulation.simulator import Simulator, SimulationConfig, SimulationResult
from llm_eco_sim.simulation.scenarios import (
    open_web_scenario,
    walled_garden_scenario,
    regulated_scenario,
    race_to_bottom_scenario,
    diversity_erosion_scenario,
    benchmark_gaming_scenario,
    all_scenarios,
)
from llm_eco_sim.simulation.interventions import (
    reduce_contamination,
    set_contamination,
    diversity_regularization,
    benchmark_rotation,
    improve_model,
    add_new_model,
    data_filtering,
)

__all__: list[str] = [
    "Simulator", "SimulationConfig", "SimulationResult",
    "open_web_scenario", "walled_garden_scenario", "regulated_scenario",
    "race_to_bottom_scenario", "diversity_erosion_scenario",
    "benchmark_gaming_scenario", "all_scenarios",
    "reduce_contamination", "set_contamination", "diversity_regularization",
    "benchmark_rotation", "improve_model", "add_new_model", "data_filtering",
]
