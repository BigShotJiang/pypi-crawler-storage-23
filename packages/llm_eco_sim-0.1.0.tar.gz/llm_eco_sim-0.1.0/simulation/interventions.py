"""
interventions.py - Mitigation strategy implementations.

Provides intervention functions that can be applied to an Ecosystem
at specific time steps to test mitigation strategies:
- Data filtering (reduce contamination)
- Diversity regularization (push models apart)
- Benchmark rotation (change benchmark target)
- Model improvement (improve a specific model)
- Contamination cap (limit alpha)
"""

import numpy as np
from typing import Callable, Optional
from llm_eco_sim.core.ecosystem import Ecosystem


def reduce_contamination(factor: float = 0.5) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that reduces the contamination rate.

    Parameters
    ----------
    factor : float
        Multiply alpha by this factor (0.5 = halve contamination).

    Returns
    -------
    Callable
        Intervention function.
    """
    def intervention(eco: Ecosystem) -> None:
        eco.data_pool.contamination_rate = eco.data_pool.contamination_rate * factor
    intervention.__name__ = f"reduce_contamination(factor={factor})"
    return intervention


def set_contamination(alpha: float) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that sets contamination to a specific value.

    Parameters
    ----------
    alpha : float
        New contamination rate.

    Returns
    -------
    Callable
    """
    def intervention(eco: Ecosystem) -> None:
        eco.data_pool.contamination_rate = alpha
    intervention.__name__ = f"set_contamination(alpha={alpha})"
    return intervention


def diversity_regularization(strength: float = 0.1, seed: int = 42) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that pushes models apart (diversity regularization).

    Adds a repulsive force between models proportional to their similarity.

    Parameters
    ----------
    strength : float
        Strength of the repulsive perturbation.
    seed : int
        Random seed.

    Returns
    -------
    Callable
    """
    def intervention(eco: Ecosystem) -> None:
        rng = np.random.default_rng(seed)
        N: int = len(eco.models)
        capabilities = np.array([m.capability for m in eco.models])
        mean_cap = np.mean(capabilities, axis=0)

        for model in eco.models:
            # Push away from the mean
            direction = model.capability - mean_cap
            norm = np.linalg.norm(direction)
            if norm > 1e-10:
                direction = direction / norm
            else:
                direction = rng.standard_normal(eco.dim)
                direction = direction / np.linalg.norm(direction)

            model.capability = model.capability + strength * direction

    intervention.__name__ = f"diversity_regularization(strength={strength})"
    return intervention


def benchmark_rotation(rotation_magnitude: float = 0.5, seed: int = 42) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that rotates the benchmark target.

    Simulates benchmark committees introducing new evaluation criteria.

    Parameters
    ----------
    rotation_magnitude : float
        How much to perturb the benchmark target.
    seed : int
        Random seed.

    Returns
    -------
    Callable
    """
    def intervention(eco: Ecosystem) -> None:
        rng = np.random.default_rng(seed)
        perturbation = rng.standard_normal(eco.dim) * rotation_magnitude
        eco.benchmark.target = eco.benchmark.target + perturbation

    intervention.__name__ = f"benchmark_rotation(magnitude={rotation_magnitude})"
    return intervention


def improve_model(model_index: int = 0, improvement: float = 0.5) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that improves a specific model.

    Moves the model closer to the natural data distribution.

    Parameters
    ----------
    model_index : int
        Index of the model to improve.
    improvement : float
        Fraction of the distance to natural mean to close (0 to 1).

    Returns
    -------
    Callable
    """
    def intervention(eco: Ecosystem) -> None:
        model = eco.models[model_index]
        natural: Optional[np.ndarray] = eco.data_pool.natural_mean
        direction = natural - model.capability
        model.capability = model.capability + improvement * direction

    intervention.__name__ = f"improve_model(index={model_index}, improvement={improvement})"
    return intervention


def add_new_model(
    name: str = "Model_New",
    capability: Optional[np.ndarray] = None,
    learning_rate: float = 0.1,
    benchmark_pressure: float = 0.05,
    seed: int = 99,
) -> Callable[[Ecosystem], None]:
    """
    Create an intervention that adds a new model to the ecosystem.

    Parameters
    ----------
    name : str
        Name of the new model.
    capability : Optional[np.ndarray]
        Initial capability. If None, uses natural mean.
    learning_rate, benchmark_pressure : float
        Model parameters.
    seed : int
        Random seed for the new model.

    Returns
    -------
    Callable
    """
    from llm_eco_sim.core.model_agent import ModelAgent

    def intervention(eco: Ecosystem) -> None:
        cap = capability if capability is not None else eco.data_pool.natural_mean.copy()
        new_model = ModelAgent(
            name=name,
            capability_dim=eco.dim,
            initial_capability=cap,
            learning_rate=learning_rate,
            benchmark_pressure=benchmark_pressure,
            seed=seed,
        )
        eco.models.append(new_model)

    intervention.__name__ = f"add_new_model(name={name})"
    return intervention


def data_filtering(quality_threshold: float = 0.5) -> Callable[[Ecosystem], None]:
    """
    Create an intervention simulating data quality filtering.

    Moves the synthetic data mean closer to the natural mean,
    simulating removal of low-quality AI-generated content.

    Parameters
    ----------
    quality_threshold : float
        Fraction of synthetic-natural gap to close (0 to 1).

    Returns
    -------
    Callable
    """
    def intervention(eco: Ecosystem) -> None:
        natural: Optional[np.ndarray] = eco.data_pool.natural_mean
        synthetic = eco.data_pool.synthetic_mean
        direction = natural - synthetic
        eco.data_pool.synthetic_mean = synthetic + quality_threshold * direction

    intervention.__name__ = f"data_filtering(threshold={quality_threshold})"
    return intervention
