"""
scenarios.py - Pre-built scenarios for common ecosystem configurations.

Provides ready-to-use SimulationConfig instances modeling real-world
AI ecosystem scenarios:
- Open Web: high contamination, many models, adaptive benchmarks
- Walled Garden: low contamination, few models, static benchmarks
- Regulated: moderate contamination with interventions
- Race to Bottom: high benchmark pressure, adaptive benchmarks
- Diversity Erosion: parameters tuned to demonstrate Theorem 1
- Benchmark Gaming: parameters tuned to demonstrate Theorem 2
"""

import numpy as np
from llm_eco_sim.simulation.simulator import SimulationConfig


def open_web_scenario(
    n_models: int = 5,
    dim: int = 10,
    n_steps: int = 500,
    seed: int = 42,
) -> SimulationConfig:
    """
    Open Web scenario: many models freely polluting shared data.

    Characteristics:
    - High contamination rate (alpha=0.6)
    - Multiple models competing
    - Adaptive benchmarks that get harder
    - Moderate learning rate
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.6,
        learning_rate=0.1,
        benchmark_pressure=0.05,
        benchmark_adaptation_rate=0.05,
        noise_std=0.01,
        n_steps=n_steps,
        seed=seed,
        name="open_web",
        description="Open web ecosystem with high contamination and adaptive benchmarks",
    )


def walled_garden_scenario(
    n_models: int = 2,
    dim: int = 10,
    n_steps: int = 500,
    seed: int = 42,
) -> SimulationConfig:
    """
    Walled Garden scenario: controlled environment with curated data.

    Characteristics:
    - Low contamination rate (alpha=0.1)
    - Few models with careful data curation
    - Static benchmarks
    - Higher learning rate (better data quality)
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.1,
        learning_rate=0.15,
        benchmark_pressure=0.03,
        benchmark_adaptation_rate=0.0,
        noise_std=0.005,
        n_steps=n_steps,
        seed=seed,
        name="walled_garden",
        description="Walled garden with curated data and static benchmarks",
    )


def regulated_scenario(
    n_models: int = 3,
    dim: int = 10,
    n_steps: int = 500,
    seed: int = 42,
) -> SimulationConfig:
    """
    Regulated scenario: government/industry regulation limits contamination.

    Characteristics:
    - Moderate contamination (alpha=0.25)
    - Moderate benchmark adaptation
    - Higher noise (diverse training approaches mandated)
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.25,
        learning_rate=0.1,
        benchmark_pressure=0.04,
        benchmark_adaptation_rate=0.02,
        noise_std=0.02,
        n_steps=n_steps,
        seed=seed,
        name="regulated",
        description="Regulated ecosystem with contamination limits and diversity mandates",
    )


def race_to_bottom_scenario(
    n_models: int = 4,
    dim: int = 10,
    n_steps: int = 500,
    seed: int = 42,
) -> SimulationConfig:
    """
    Race to Bottom scenario: extreme benchmark optimization pressure.

    Characteristics:
    - High benchmark pressure (beta >> eta)
    - Rapidly adapting benchmarks
    - Moderate contamination
    - Demonstrates benchmark overfitting (Theorem 2)
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.3,
        learning_rate=0.05,
        benchmark_pressure=0.2,
        benchmark_adaptation_rate=0.1,
        noise_std=0.01,
        n_steps=n_steps,
        seed=seed,
        name="race_to_bottom",
        description="Race to bottom with extreme benchmark pressure and adaptation",
    )


def diversity_erosion_scenario(
    n_models: int = 2,
    dim: int = 5,
    n_steps: int = 300,
    seed: int = 42,
) -> SimulationConfig:
    """
    Scenario tuned to clearly demonstrate diversity erosion (Theorem 1).

    High contamination + moderate learning = rapid convergence.
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.7,
        learning_rate=0.15,
        benchmark_pressure=0.05,
        benchmark_adaptation_rate=0.0,
        noise_std=0.005,
        n_steps=n_steps,
        seed=seed,
        name="diversity_erosion",
        description="Demonstrates diversity erosion under high contamination",
    )


def benchmark_gaming_scenario(
    n_models: int = 3,
    dim: int = 5,
    n_steps: int = 300,
    seed: int = 42,
) -> SimulationConfig:
    """
    Scenario tuned to demonstrate benchmark overfitting (Theorem 2).

    High benchmark pressure + adaptive benchmark = models chase benchmark
    away from real-world distribution.
    """
    return SimulationConfig(
        n_models=n_models,
        dim=dim,
        contamination_rate=0.3,
        learning_rate=0.05,
        benchmark_pressure=0.15,
        benchmark_adaptation_rate=0.08,
        noise_std=0.005,
        n_steps=n_steps,
        seed=seed,
        name="benchmark_gaming",
        description="Demonstrates benchmark overfitting with adaptive benchmarks",
    )


def all_scenarios() -> dict:
    """Return a dictionary of all pre-built scenarios."""
    return {
        "open_web": open_web_scenario(),
        "walled_garden": walled_garden_scenario(),
        "regulated": regulated_scenario(),
        "race_to_bottom": race_to_bottom_scenario(),
        "diversity_erosion": diversity_erosion_scenario(),
        "benchmark_gaming": benchmark_gaming_scenario(),
    }
