"""Tests for ModelAgent lifecycle and update rules."""

import numpy as np
import pytest

from llm_eco_sim.core.model_agent import ModelAgent

DIM = 10
SEED = 42


def _make_agent(**kwargs):
    defaults = dict(
        name="test", capability_dim=DIM, learning_rate=0.05,
        benchmark_pressure=0.02, noise_std=0.0, specialization_strength=0.12,
        seed=SEED,
    )
    defaults.update(kwargs)
    return ModelAgent(**defaults)


class TestModelAgentCreation:
    def test_default_init_shape(self):
        agent = _make_agent()
        assert agent.capability.shape == (DIM,)

    def test_custom_initial_capability(self):
        init = np.ones(DIM) * 0.5
        agent = _make_agent(initial_capability=init)
        np.testing.assert_array_equal(agent.capability, init)

    def test_invalid_initial_shape_raises(self):
        with pytest.raises(ValueError, match="initial_capability shape"):
            _make_agent(initial_capability=np.ones(DIM + 1))

    def test_specialization_target_equals_initial(self):
        agent = _make_agent()
        np.testing.assert_array_equal(agent.specialization_target, agent.capability)

    def test_seed_reproducibility(self):
        a = _make_agent(seed=123)
        b = _make_agent(seed=123)
        np.testing.assert_array_equal(a.capability, b.capability)

    def test_different_seeds_differ(self):
        a = _make_agent(seed=1)
        b = _make_agent(seed=2)
        assert not np.allclose(a.capability, b.capability)


class TestModelAgentUpdate:
    def test_deterministic_update_all_gradients_nonzero(self):
        """With noise_std=0, verify update exercises all gradient terms.

        We use an initial capability that differs from the specialization
        target (which is set to init), the data pool mean, AND the benchmark.
        After one update the capability should have moved along each axis.
        """
        init = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        agent = _make_agent(initial_capability=init, noise_std=0.0)

        # Now move agent away from its specialization target so that all
        # three gradient terms (data, benchmark, specialization) are nonzero.
        # Manually set capability to something different from init.
        new_cap = np.full(DIM, 0.5)
        agent.capability = new_cap
        # specialization_target is still `init`

        data_mean = np.zeros(DIM)
        bench = np.ones(DIM) / np.sqrt(DIM)
        s = agent.specialization_target  # = init = [1,0,...,0]

        eta, beta, sigma = 0.05, 0.02, 0.12

        data_grad = eta * (data_mean - new_cap)
        bench_grad = beta * (bench - new_cap)
        spec_grad = sigma * (s - new_cap)
        expected = new_cap + data_grad + bench_grad + spec_grad

        # All gradient terms should be nonzero vectors
        assert np.linalg.norm(data_grad) > 0
        assert np.linalg.norm(bench_grad) > 0
        assert np.linalg.norm(spec_grad) > 0

        result = agent.update(data_mean, bench)
        np.testing.assert_allclose(result, expected, atol=1e-14)

    def test_update_without_benchmark(self):
        """Update with benchmark_target=None uses zero benchmark gradient."""
        init = np.ones(DIM)
        agent = _make_agent(initial_capability=init, noise_std=0.0)
        data_mean = np.zeros(DIM)

        result_no_bench = agent.update(data_mean, benchmark_target=None)

        # Redo with fresh agent and explicit benchmark
        agent2 = _make_agent(initial_capability=init, noise_std=0.0)
        result_with_bench = agent2.update(data_mean, benchmark_target=np.ones(DIM) * 5.0)

        # These should differ (benchmark pulled agent2 toward 5.0)
        assert not np.allclose(result_no_bench, result_with_bench)

    def test_learning_rate_controls_data_pull(self):
        """Higher η should pull capability faster toward data mean."""
        init = np.ones(DIM)
        data_mean = np.zeros(DIM)

        a_slow = _make_agent(initial_capability=init.copy(), learning_rate=0.01, noise_std=0.0)
        a_fast = _make_agent(initial_capability=init.copy(), learning_rate=0.20, noise_std=0.0)
        r_slow = a_slow.update(data_mean)
        r_fast = a_fast.update(data_mean)

        # Fast learner should be closer to data_mean (zeros)
        assert np.linalg.norm(r_fast) < np.linalg.norm(r_slow)

    def test_history_grows(self):
        agent = _make_agent()
        assert agent.history.shape == (1, DIM)
        agent.update(np.zeros(DIM))
        assert agent.history.shape == (2, DIM)
        agent.update(np.zeros(DIM))
        assert agent.history.shape == (3, DIM)

    def test_reset_restores_initial(self):
        agent = _make_agent()
        init = agent.capability.copy()
        agent.update(np.zeros(DIM))
        agent.update(np.zeros(DIM))
        agent.reset()
        np.testing.assert_array_equal(agent.capability, init)
        assert agent.history.shape == (1, DIM)


class TestModelAgentMetrics:
    def test_distance_to_self_is_zero(self):
        agent = _make_agent()
        assert agent.distance_to(agent.capability) == 0.0

    def test_performance_on_is_negative_distance(self):
        agent = _make_agent()
        target = np.ones(DIM)
        assert agent.performance_on(target) == pytest.approx(-agent.distance_to(target))
