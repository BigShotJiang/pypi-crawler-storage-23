"""Tests for DataPool contamination dynamics."""

import numpy as np
import pytest

from llm_eco_sim.core.data_pool import DataPool

DIM = 10


class TestDataPoolCreation:
    def test_default_natural_mean_is_zero(self):
        pool = DataPool(dim=DIM)
        np.testing.assert_array_equal(pool.natural_mean, np.zeros(DIM))

    def test_custom_natural_mean(self):
        mu = np.ones(DIM)
        pool = DataPool(dim=DIM, natural_mean=mu)
        np.testing.assert_array_equal(pool.natural_mean, mu)

    def test_invalid_contamination_raises(self):
        with pytest.raises(ValueError):
            DataPool(dim=DIM, contamination_rate=1.5)

    def test_alpha_property(self):
        pool = DataPool(dim=DIM, contamination_rate=0.4)
        assert pool.alpha == 0.4


class TestEffectiveMean:
    def test_alpha_zero_gives_natural(self):
        pool = DataPool(dim=DIM, contamination_rate=0.0)
        np.testing.assert_array_equal(pool.effective_mean, pool.natural_mean)

    def test_alpha_one_gives_synthetic(self):
        pool = DataPool(dim=DIM, contamination_rate=1.0)
        # Before any update, synthetic == natural
        np.testing.assert_array_equal(pool.effective_mean, pool.synthetic_mean)
        # After update with shifted models
        model_means = [np.ones(DIM) * 2.0]
        model_vars = [0.01]
        pool.update_synthetic(model_means, model_vars)
        np.testing.assert_allclose(pool.effective_mean, np.ones(DIM) * 2.0)

    def test_alpha_03_mixture(self):
        pool = DataPool(dim=DIM, contamination_rate=0.3)
        model_means = [np.ones(DIM)]
        model_vars = [0.01]
        pool.update_synthetic(model_means, model_vars)
        expected = 0.7 * np.zeros(DIM) + 0.3 * np.ones(DIM)
        np.testing.assert_allclose(pool.effective_mean, expected)


class TestUpdateSynthetic:
    def test_synthetic_mean_is_average_of_models(self):
        pool = DataPool(dim=DIM, contamination_rate=0.5)
        m1 = np.ones(DIM) * 1.0
        m2 = np.ones(DIM) * 3.0
        pool.update_synthetic([m1, m2], [0.01, 0.01])
        np.testing.assert_allclose(pool.synthetic_mean, np.ones(DIM) * 2.0)

    def test_history_grows_on_update(self):
        pool = DataPool(dim=DIM)
        assert len(pool.history) == 1
        pool.update_synthetic([np.ones(DIM)], [0.01])
        assert len(pool.history) == 2

    def test_reset_clears(self):
        pool = DataPool(dim=DIM, contamination_rate=0.5)
        pool.update_synthetic([np.ones(DIM) * 5.0], [0.1])
        pool.reset()
        np.testing.assert_array_equal(pool.synthetic_mean, pool.natural_mean)
        assert len(pool.history) == 1

    def test_contamination_divergence_zero_initially(self):
        pool = DataPool(dim=DIM, contamination_rate=0.5)
        assert pool.contamination_divergence() == pytest.approx(0.0)
