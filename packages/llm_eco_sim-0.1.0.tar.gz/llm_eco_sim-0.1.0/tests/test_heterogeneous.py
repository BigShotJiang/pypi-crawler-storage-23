"""Tests for HeterogeneousModelAgent and HeterogeneousEcosystem."""

import numpy as np
import pytest

from llm_eco_sim.core.heterogeneous import (
    HeterogeneousModelAgent,
    HeterogeneousEcosystem,
)

DIM = 5
SEED = 42


class TestHeterogeneousModelAgent:
    def test_effective_learning_rate(self):
        agent = HeterogeneousModelAgent(
            name="h", capability_dim=DIM, learning_rate=0.1,
            compute_budget=4.0, seed=SEED,
        )
        assert agent.effective_learning_rate() == pytest.approx(0.1 * 2.0)

    def test_effective_noise(self):
        agent = HeterogeneousModelAgent(
            name="h", capability_dim=DIM, noise_std=0.01,
            compute_budget=4.0, seed=SEED,
        )
        assert agent.effective_noise() == pytest.approx(0.01 / 2.0)

    def test_market_share_history(self):
        agent = HeterogeneousModelAgent(
            name="h", capability_dim=DIM, market_share=0.5, seed=SEED,
        )
        agent.update_market_share(0.6)
        agent.update_market_share(0.7)
        hist = agent.market_share_history
        np.testing.assert_allclose(hist, [0.5, 0.6, 0.7])


class TestHeterogeneousEcosystem:
    def test_create_default_configs(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(dim=DIM, seed=SEED)
        assert len(eco.models) == 3  # default 3 configs

    def test_market_shares_normalized(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(dim=DIM, seed=SEED)
        shares = [m.market_share for m in eco.models]
        assert sum(shares) == pytest.approx(1.0)

    def test_proportional_dynamics_run(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(
            dim=DIM, market_dynamics='proportional', seed=SEED,
        )
        eco.run(10)
        shares = eco.get_market_share_trajectories()
        assert len(shares) == 3
        for name, traj in shares.items():
            assert len(traj) >= 10

    def test_fixed_dynamics_shares_stable(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(
            dim=DIM, market_dynamics='fixed', seed=SEED,
        )
        initial_shares = [m.market_share for m in eco.models]
        eco.run(10)
        final_shares = [m.market_share for m in eco.models]
        np.testing.assert_allclose(initial_shares, final_shares)

    def test_gini_coefficient_range(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(dim=DIM, seed=SEED)
        eco.run(5)
        gini = eco.get_gini_coefficient()
        assert 0.0 <= gini <= 1.0

    def test_herfindahl_index_range(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(dim=DIM, seed=SEED)
        eco.run(5)
        hhi = eco.get_herfindahl_index()
        n = len(eco.models)
        assert 1.0 / n - 0.01 <= hhi <= 1.0

    def test_summary_includes_market(self):
        eco = HeterogeneousEcosystem.create_heterogeneous(dim=DIM, seed=SEED)
        s = eco.summary()
        assert "Market Dynamics" in s
