"""Tests for Benchmark static/adaptive behavior."""

import numpy as np
import pytest

from llm_eco_sim.core.benchmark import Benchmark

DIM = 10
SEED = 42


class TestBenchmarkCreation:
    def test_default_target_normalized(self):
        b = Benchmark(dim=DIM, seed=SEED)
        expected = np.ones(DIM) / np.sqrt(DIM)
        np.testing.assert_allclose(b.target, expected)

    def test_custom_target(self):
        t = np.arange(DIM, dtype=float)
        b = Benchmark(dim=DIM, initial_target=t, seed=SEED)
        np.testing.assert_array_equal(b.target, t)

    def test_invalid_target_shape_raises(self):
        with pytest.raises(ValueError):
            Benchmark(dim=DIM, initial_target=np.ones(DIM + 1))


class TestStaticBenchmark:
    def test_is_not_adaptive(self):
        b = Benchmark(dim=DIM, adaptation_rate=0.0, seed=SEED)
        assert not b.is_adaptive

    def test_target_unchanged_after_update(self):
        b = Benchmark(dim=DIM, adaptation_rate=0.0, seed=SEED)
        original = b.target.copy()
        b.update(np.zeros(DIM))
        np.testing.assert_array_equal(b.target, original)


class TestAdaptiveBenchmark:
    def test_is_adaptive(self):
        b = Benchmark(dim=DIM, adaptation_rate=0.05, seed=SEED)
        assert b.is_adaptive

    def test_target_moves_away_from_models(self):
        """Adaptive benchmark should move away from mean model capability."""
        b = Benchmark(dim=DIM, adaptation_rate=0.1, seed=SEED)
        initial_target = b.target.copy()
        model_mean = np.zeros(DIM)
        b.update(model_mean)
        # b(t+1) = b(t) + gamma * (b(t) - c_bar)
        # = b(t) * (1 + gamma) - gamma * c_bar
        expected = initial_target * (1 + 0.1) - 0.1 * model_mean
        np.testing.assert_allclose(b.target, expected)


class TestBenchmarkScoring:
    def test_score_perfect_match(self):
        b = Benchmark(dim=DIM, seed=SEED)
        assert b.score_model(b.target) == pytest.approx(1.0)

    def test_score_decreases_with_distance(self):
        b = Benchmark(dim=DIM, seed=SEED)
        near = b.target + np.ones(DIM) * 0.01
        far = b.target + np.ones(DIM) * 1.0
        assert b.score_model(near) > b.score_model(far)

    def test_score_formula(self):
        """Verify score = exp(-||c-b||^2 / (2*sigma_b^2))."""
        b = Benchmark(dim=DIM, difficulty=2.0, seed=SEED)
        c = np.zeros(DIM)
        dist_sq = np.sum((c - b.target) ** 2)
        expected = np.exp(-dist_sq / (2 * 2.0**2))
        assert b.score_model(c) == pytest.approx(expected)

    def test_reset_restores(self):
        b = Benchmark(dim=DIM, adaptation_rate=0.1, seed=SEED)
        init = b.target.copy()
        b.update(np.zeros(DIM))
        b.update(np.zeros(DIM))
        b.reset()
        np.testing.assert_array_equal(b.target, init)
