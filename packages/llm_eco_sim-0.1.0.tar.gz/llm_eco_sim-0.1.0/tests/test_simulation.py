"""Tests for Simulator, configs, and sweeps."""

import numpy as np
import pytest

from llm_eco_sim.simulation.simulator import (
    Simulator,
    SimulationConfig,
    SimulationResult,
)
from llm_eco_sim.simulation.scenarios import all_scenarios


class TestSimulationConfig:
    def test_to_dict_roundtrip(self):
        cfg = SimulationConfig(n_models=3, dim=5, contamination_rate=0.4)
        d = cfg.to_dict()
        assert d["n_models"] == 3
        assert d["contamination_rate"] == 0.4

    def test_default_values(self):
        cfg = SimulationConfig()
        assert cfg.seed == 42
        assert cfg.n_steps == 200


class TestSimulator:
    def test_basic_run(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=20, seed=42)
        sim = Simulator(cfg)
        result = sim.run()
        assert isinstance(result, SimulationResult)
        assert len(result.states) == 21  # initial + 20 steps

    def test_result_trajectories(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=15, seed=42)
        result = Simulator(cfg).run()
        # states = initial + n_steps
        assert len(result.diversity_trajectory) == 16
        assert len(result.benchmark_score_trajectory) == 16

    def test_summary_keys(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=10, seed=42)
        result = Simulator(cfg).run()
        s = result.summary()
        for key in ["config_name", "n_steps", "wall_time_seconds",
                     "initial_diversity", "final_diversity",
                     "diversity_erosion_ratio"]:
            assert key in s

    def test_intervention_applied(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=20, seed=42)
        sim = Simulator(cfg)

        def halve_alpha(eco):
            eco.data_pool.alpha *= 0.5

        sim.add_intervention(10, halve_alpha)
        result = sim.run()
        assert len(result.interventions_applied) == 1
        assert result.interventions_applied[0]["step"] == 10

    def test_callback_called(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=10, seed=42)
        sim = Simulator(cfg)
        steps_seen = []
        sim.add_callback(lambda eco, step: steps_seen.append(step))
        sim.run()
        assert steps_seen == list(range(1, 11))

    def test_seed_reproducibility(self):
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=20, seed=42)
        r1 = Simulator(cfg).run()
        r2 = Simulator(cfg).run()
        np.testing.assert_array_equal(
            r1.diversity_trajectory, r2.diversity_trajectory,
        )


class TestParameterSweep:
    def test_sweep_contamination(self):
        base = SimulationConfig(n_models=2, dim=3, n_steps=10, seed=42)
        results = Simulator.parameter_sweep(
            "contamination_rate", np.array([0.0, 0.5, 1.0]),
            base_config=base,
        )
        assert len(results) == 3


class TestScenarios:
    def test_all_scenarios_loadable(self):
        scenarios = all_scenarios()
        assert len(scenarios) >= 4
        for name, cfg in scenarios.items():
            assert isinstance(cfg, SimulationConfig)
