"""Tests for diversity measures."""

import numpy as np
import pytest

from llm_eco_sim.theory.diversity_metrics import (
    pairwise_diversity,
    shannon_diversity,
    simpson_diversity,
    spectral_diversity,
    effective_number_of_species,
    diversity_report,
)


class TestPairwiseDiversity:
    def test_identical_models_zero(self):
        caps = np.ones((3, 5))
        assert pairwise_diversity(caps) == pytest.approx(0.0)

    def test_single_model_zero(self):
        assert pairwise_diversity(np.array([[1.0, 2.0]])) == 0.0

    def test_known_value(self):
        """Two models: [0,0] and [1,0] → ||diff||² = 1."""
        caps = np.array([[0.0, 0.0], [1.0, 0.0]])
        assert pairwise_diversity(caps) == pytest.approx(1.0)

    def test_three_models(self):
        caps = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]])
        # Pairs: (0,1)=1, (0,2)=1, (1,2)=2. Mean = 4/3
        assert pairwise_diversity(caps) == pytest.approx(4.0 / 3.0)


class TestShannonDiversity:
    def test_identical_zero(self):
        caps = np.ones((5, 3))
        assert shannon_diversity(caps) == pytest.approx(0.0)

    def test_positive_for_spread(self):
        rng = np.random.default_rng(42)
        caps = rng.standard_normal((20, 5))
        assert shannon_diversity(caps) > 0


class TestSimpsonDiversity:
    def test_identical_zero(self):
        caps = np.ones((5, 3))
        assert simpson_diversity(caps) == pytest.approx(0.0)

    def test_range_zero_one(self):
        rng = np.random.default_rng(42)
        caps = rng.standard_normal((20, 5))
        val = simpson_diversity(caps)
        assert 0.0 <= val < 1.0


class TestSpectralDiversity:
    def test_single_model_zero(self):
        assert spectral_diversity(np.array([[1.0, 2.0]])) == 0.0

    def test_positive_for_spread(self):
        rng = np.random.default_rng(42)
        caps = rng.standard_normal((10, 5))
        assert spectral_diversity(caps) > 0


class TestEffectiveSpecies:
    def test_identical_models_one_species(self):
        caps = np.ones((5, 3))
        assert effective_number_of_species(caps, epsilon=0.1) == 1

    def test_distinct_models_correct_count(self):
        caps = np.array([[0.0, 0.0], [10.0, 0.0], [0.0, 10.0]])
        assert effective_number_of_species(caps, epsilon=1.0) == 3


class TestDiversityReport:
    def test_report_keys(self):
        rng = np.random.default_rng(42)
        caps = rng.standard_normal((5, 3))
        report = diversity_report(caps)
        for key in ["pairwise", "shannon", "simpson", "spectral",
                     "effective_species", "n_models", "n_dimensions"]:
            assert key in report
        assert report["n_models"] == 5
        assert report["n_dimensions"] == 3
