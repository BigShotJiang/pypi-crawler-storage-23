"""End-to-end integration tests: simulation vs analytical predictions.

These tests run actual simulations and compare against theory.
They are the ultimate test that the math and the code agree.
"""

import numpy as np
import pytest

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.theory.formal_proofs import (
    compute_diversity_curve,
    compute_eigenvalues_analytical,
    prove_theorem_2,
)
from llm_eco_sim.simulation.simulator import Simulator, SimulationConfig
from llm_eco_sim.simulation.interventions import reduce_contamination

ETA = 0.05
BETA = 0.02
SIGMA = 0.12
KAPPA = 3.0
NOISE_STD = 0.005


class TestDiversityPrediction:
    @pytest.mark.parametrize("alpha", [0.3, 0.5, 0.7])
    def test_diversity_ratio_within_tolerance(self, alpha):
        """Simulation diversity ratio should be within 15% of analytical
        at multiple α values (not just one cherry-picked α)."""
        dim = 5
        n_steps = 500
        n_models = 2

        # Run at α=0
        eco_0 = Ecosystem.create_default(
            n_models=n_models, dim=dim, contamination_rate=0.0,
            learning_rate=ETA, benchmark_pressure=BETA,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco_0.run(n_steps)
        D_0 = np.mean(eco_0.get_diversity_trajectory()[-50:])

        # Run at target α
        eco_a = Ecosystem.create_default(
            n_models=n_models, dim=dim, contamination_rate=alpha,
            learning_rate=ETA, benchmark_pressure=BETA,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco_a.run(n_steps)
        D_a = np.mean(eco_a.get_diversity_trajectory()[-50:])

        sim_ratio = D_a / D_0 if D_0 > 0 else 0

        # Analytical prediction
        curve = compute_diversity_curve(
            alpha_range=np.array([alpha]),
            eta=ETA, beta=BETA, kappa=KAPPA, sigma=SIGMA,
            dim=dim, noise_std=NOISE_STD,
        )
        analytical_ratio = curve['D_ratio'][0]

        assert abs(sim_ratio - analytical_ratio) / max(analytical_ratio, 1e-10) < 0.15, (
            f"α={alpha}: sim_ratio={sim_ratio:.4f} vs analytical={analytical_ratio:.4f}"
        )


class TestHigherAlphaFasterDecay:
    def test_higher_alpha_lower_diversity(self):
        """Higher α should lead to lower equilibrium diversity.
        Test with 4 values to ensure it's not a fluke."""
        dim, n_steps = 3, 200
        final_divs = []
        for alpha in [0.0, 0.2, 0.5, 0.8]:
            eco = Ecosystem.create_default(
                n_models=2, dim=dim, contamination_rate=alpha,
                learning_rate=ETA, benchmark_pressure=BETA,
                noise_std=NOISE_STD, specialization_strength=SIGMA,
                variance_coupling=KAPPA, seed=42,
            )
            eco.run(n_steps)
            final_divs.append(np.mean(eco.get_diversity_trajectory()[-20:]))
        # Diversity should be monotonically decreasing with α
        for i in range(len(final_divs) - 1):
            assert final_divs[i] > final_divs[i + 1], (
                f"D(α={[0.0,0.2,0.5,0.8][i]})={final_divs[i]:.4f} "
                f"should > D(α={[0.0,0.2,0.5,0.8][i+1]})={final_divs[i+1]:.4f}"
            )


class TestAdaptiveBenchmarkBRG:
    def test_adaptive_benchmark_growing_brg(self):
        """With adaptive benchmark (γ>0), BRG magnitude should grow."""
        eco = Ecosystem.create_default(
            n_models=2, dim=3, contamination_rate=0.3,
            benchmark_adaptation_rate=0.1,
            learning_rate=ETA, benchmark_pressure=0.1,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco.run(100)
        brg = eco.get_brg_trajectory()
        assert np.mean(np.abs(brg[-10:])) > np.mean(np.abs(brg[:10]))

    def test_static_benchmark_stable_brg(self):
        """With static benchmark (γ=0), BRG should not grow unboundedly."""
        eco = Ecosystem.create_default(
            n_models=2, dim=3, contamination_rate=0.3,
            benchmark_adaptation_rate=0.0,
            learning_rate=ETA, benchmark_pressure=0.1,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco.run(200)
        brg = eco.get_brg_trajectory()
        # BRG should stabilize (last 20 steps should have low variance)
        assert np.std(brg[-20:]) < np.std(brg[:20]) + 0.1


class TestInterventionImprovesDiversity:
    def test_contamination_reduction_helps(self):
        """Reducing contamination mid-run should improve diversity."""
        cfg = SimulationConfig(
            n_models=2, dim=3, contamination_rate=0.7,
            learning_rate=ETA, benchmark_pressure=BETA,
            noise_std=NOISE_STD, n_steps=100, seed=42,
        )
        # Without intervention
        r_baseline = Simulator(cfg).run()
        div_baseline = r_baseline.states[-1].diversity_index

        # With intervention at step 50
        sim = Simulator(cfg)
        sim.add_intervention(50, reduce_contamination(factor=0.1))
        r_intervention = sim.run()
        div_intervention = r_intervention.states[-1].diversity_index

        assert div_intervention > div_baseline


class TestParadoxicalIntervention:
    def test_improving_one_model_perturbs_others(self):
        """Theorem 3 in simulation: improving model 0 should perturb model 1's
        trajectory through the data pool coupling.

        Use high α and large improvement to make the effect clearly visible.
        Compare trajectories immediately after intervention (not after convergence).
        """
        from llm_eco_sim.simulation.interventions import improve_model
        dim = 5
        intervention_step = 50

        # Baseline: no intervention, run to step 55
        cfg = SimulationConfig(
            n_models=3, dim=dim, contamination_rate=0.8,
            learning_rate=ETA, benchmark_pressure=BETA,
            noise_std=NOISE_STD, n_steps=55, seed=42,
        )
        r_base = Simulator(cfg).run()
        caps_base_model1 = r_base.ecosystem.models[1].history[52]  # 2 steps after intervention point

        # With intervention: improve model 0 with large Δ
        sim = Simulator(cfg)
        sim.add_intervention(intervention_step, improve_model(model_index=0, improvement=0.9))
        r_inter = sim.run()
        caps_inter_model1 = r_inter.ecosystem.models[1].history[52]

        # Model 1's capability at step 52 should differ
        diff = np.linalg.norm(caps_base_model1 - caps_inter_model1)
        assert diff > 1e-4, (
            f"Improving model 0 should have perturbed model 1, but diff={diff:.2e}"
        )


class TestResetRerun:
    def test_reset_identical_rerun(self):
        """Reset + rerun should produce identical trajectories."""
        eco = Ecosystem.create_default(
            n_models=2, dim=3, contamination_rate=0.3,
            learning_rate=ETA, benchmark_pressure=BETA,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco.run(50)
        traj1 = eco.get_diversity_trajectory().copy()
        eco.reset()
        eco.run(50)
        traj2 = eco.get_diversity_trajectory()
        np.testing.assert_array_equal(traj1, traj2)


class TestTheorem2Simulation:
    def test_unstable_params_benchmark_diverges(self):
        """With parameters the theory predicts are unstable, the benchmark
        should actually diverge (or be clamped) in simulation."""
        # Find params where Theorem 2 predicts instability
        result = prove_theorem_2(
            eta=0.05, beta=0.15, gamma=0.10, kappa=3.0, sigma=0.12, alpha=0.3,
        )
        assert result.is_unstable, "Params should be analytically unstable"

        eco = Ecosystem.create_default(
            n_models=2, dim=3, contamination_rate=0.3,
            benchmark_adaptation_rate=0.10,
            learning_rate=0.05, benchmark_pressure=0.15,
            noise_std=NOISE_STD, specialization_strength=SIGMA,
            variance_coupling=KAPPA, seed=42,
        )
        eco.run(200)
        bench_norms = [np.linalg.norm(s.benchmark_target) for s in eco.state_history]
        # Benchmark should have grown significantly (even if clamped)
        assert max(bench_norms) > bench_norms[0] * 2, (
            "Unstable params should cause benchmark to diverge"
        )


class TestSpeedBudget:
    def test_small_sim_fast(self):
        """Verify a small simulation runs in <1s."""
        import time
        cfg = SimulationConfig(n_models=2, dim=3, n_steps=50, seed=42)
        start = time.time()
        Simulator(cfg).run()
        elapsed = time.time() - start
        assert elapsed < 1.0
