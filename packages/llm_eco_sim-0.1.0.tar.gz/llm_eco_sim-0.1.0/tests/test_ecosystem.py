"""Tests for Ecosystem dynamics."""

import numpy as np
import pytest

from llm_eco_sim.core.ecosystem import Ecosystem, EcosystemState
from llm_eco_sim.core.model_agent import ModelAgent
from llm_eco_sim.core.data_pool import DataPool
from llm_eco_sim.core.benchmark import Benchmark

DIM = 5
ETA = 0.05
BETA = 0.02
SIGMA = 0.12
KAPPA = 3.0
NOISE_STD = 0.005
SEED = 42


def _make_eco(**kwargs):
    defaults = dict(
        n_models=2, dim=DIM, contamination_rate=0.3,
        learning_rate=ETA, benchmark_pressure=BETA,
        noise_std=NOISE_STD, specialization_strength=SIGMA,
        variance_coupling=KAPPA, seed=SEED,
    )
    defaults.update(kwargs)
    return Ecosystem.create_default(**defaults)


class TestEcosystemCreation:
    def test_create_default_n_models(self):
        eco = _make_eco(n_models=3)
        assert len(eco.models) == 3

    def test_create_default_dim(self):
        eco = _make_eco()
        assert eco.dim == DIM
        for m in eco.models:
            assert m.capability_dim == DIM

    def test_dimension_mismatch_raises(self):
        m = ModelAgent("m", 5, seed=1)
        dp = DataPool(dim=10)
        b = Benchmark(dim=5)
        with pytest.raises(ValueError, match="Dimension mismatch"):
            Ecosystem(models=[m], data_pool=dp, benchmark=b)

    def test_initial_state_recorded(self):
        eco = _make_eco()
        assert len(eco.state_history) == 1
        assert eco.current_state.time_step == 0


class TestEcosystemStep:
    def test_step_advances_time(self):
        eco = _make_eco()
        eco.step()
        assert eco.time_step == 1

    def test_state_history_grows(self):
        eco = _make_eco()
        eco.step()
        eco.step()
        assert len(eco.state_history) == 3  # initial + 2 steps

    def test_variance_compression_actually_used(self):
        """Verify η_eff = η(1+κα) produces different trajectories than η alone.

        Run two ecosystems: one with κ=3.0, one with κ=0.0. Same seed.
        After one step with α>0, their capabilities must differ — proving
        the variance-compression multiplier actually affected the update.
        """
        eco_with_kappa = _make_eco(variance_coupling=3.0, noise_std=0.0)
        eco_no_kappa = _make_eco(variance_coupling=0.0, noise_std=0.0)

        eco_with_kappa.step()
        eco_no_kappa.step()

        cap_with = eco_with_kappa.models[0].capability
        cap_without = eco_no_kappa.models[0].capability
        assert not np.allclose(cap_with, cap_without), (
            "κ>0 should produce different capabilities than κ=0 when α>0"
        )

    def test_variance_compression_no_effect_at_alpha_zero(self):
        """With α=0, κ should have no effect (η_eff = η regardless of κ)."""
        eco_k3 = _make_eco(contamination_rate=0.0, variance_coupling=3.0, noise_std=0.0)
        eco_k0 = _make_eco(contamination_rate=0.0, variance_coupling=0.0, noise_std=0.0)

        eco_k3.step()
        eco_k0.step()

        cap_k3 = eco_k3.models[0].capability
        cap_k0 = eco_k0.models[0].capability
        np.testing.assert_allclose(cap_k3, cap_k0, atol=1e-14)

    def test_diversity_computable(self):
        eco = _make_eco()
        eco.step()
        div = eco.current_state.diversity_index
        assert isinstance(div, float)
        assert div >= 0


class TestEcosystemRun:
    def test_run_returns_correct_length(self):
        eco = _make_eco()
        states = eco.run(n_steps=20)
        assert len(states) == 20

    def test_diversity_trajectory_length(self):
        eco = _make_eco()
        eco.run(30)
        traj = eco.get_diversity_trajectory()
        assert len(traj) == 31  # initial + 30 steps

    def test_brg_trajectory_length(self):
        eco = _make_eco()
        eco.run(10)
        assert len(eco.get_brg_trajectory()) == 11

    def test_model_trajectories_shape(self):
        eco = _make_eco(n_models=2)
        eco.run(15)
        trajs = eco.get_model_trajectories()
        assert len(trajs) == 2
        for name, traj in trajs.items():
            assert traj.shape == (16, DIM)


class TestEcosystemReproducibility:
    def test_seed_reproducibility(self):
        eco1 = _make_eco(seed=99)
        eco2 = _make_eco(seed=99)
        eco1.run(20)
        eco2.run(20)
        d1 = eco1.get_diversity_trajectory()
        d2 = eco2.get_diversity_trajectory()
        np.testing.assert_array_equal(d1, d2)

    def test_reset_yields_same_trajectory(self):
        eco = _make_eco()
        eco.run(20)
        traj1 = eco.get_diversity_trajectory().copy()
        eco.reset()
        eco.run(20)
        traj2 = eco.get_diversity_trajectory()
        np.testing.assert_array_equal(traj1, traj2)

    def test_summary_runs(self):
        eco = _make_eco()
        eco.run(5)
        s = eco.summary()
        assert "Ecosystem State" in s
        assert "Diversity" in s
