"""Tests for formal theorem verification — CRITICAL mathematical correctness.

Design principles:
- Never recompute the same formula the code uses and check equality (tautological).
- Instead, verify properties that MUST hold if the formula is correct:
  symmetry, boundary conditions, monotonicity, cross-validation between
  independent computations, and simulation agreement.
"""

import numpy as np
import pytest

from llm_eco_sim.theory.formal_proofs import (
    compute_full_jacobian,
    compute_eigenvalues_analytical,
    compute_diversity_curve,
    compute_stability_map,
    verify_eigenvalue_derivation,
    prove_theorem_1,
    prove_theorem_2,
    prove_theorem_3,
)


class TestJacobianStructure:
    """Verify structural properties of the Jacobian that follow from the
    dynamical system definition, not by recalculating the same formula."""

    def test_shape(self):
        J = compute_full_jacobian(N=3, d=1, alpha=0.3, eta=0.05, beta=0.02,
                                  gamma=0.05, kappa=3.0, sigma=0.12)
        assert J.shape == (4, 4)

    def test_model_block_row_sums(self):
        """Each model row should sum to 1 - σ + β (from the update structure).

        Row i (model): diag + (N-1)*off_diag + β
          = [1 - η_eff(1-α/N) - β - σ] + (N-1)*[η_eff*α/N] + β
          = 1 - η_eff + η_eff*α - σ
          = 1 - η_eff(1-α) - σ

        This must hold regardless of parameter values.
        """
        for N, alpha, eta, beta, gamma, kappa, sigma in [
            (3, 0.3, 0.05, 0.02, 0.05, 3.0, 0.12),
            (5, 0.7, 0.10, 0.08, 0.00, 1.0, 0.05),
            (2, 0.0, 0.15, 0.03, 0.10, 5.0, 0.20),
        ]:
            J = compute_full_jacobian(N=N, d=1, alpha=alpha, eta=eta, beta=beta,
                                      gamma=gamma, kappa=kappa, sigma=sigma)
            eta_eff = eta * (1.0 + kappa * alpha)
            expected_row_sum = 1.0 - eta_eff * (1.0 - alpha) - sigma
            for i in range(N):
                assert np.sum(J[i, :]) == pytest.approx(expected_row_sum), (
                    f"Failed at N={N}, α={alpha}, η={eta}, β={beta}"
                )

    def test_model_block_symmetry(self):
        """Off-diagonal model-model entries should all be equal."""
        J = compute_full_jacobian(N=4, d=1, alpha=0.5, eta=0.08, beta=0.03,
                                  gamma=0.05, kappa=2.0, sigma=0.10)
        for i in range(4):
            for j in range(4):
                if i != j:
                    assert J[i, j] == pytest.approx(J[0, 1])

    def test_benchmark_row_sums(self):
        """Benchmark row: sum of c_j entries = -γ, b entry = 1+γ.
        Total row sum = 1."""
        for gamma in [0.0, 0.05, 0.15]:
            N = 3
            J = compute_full_jacobian(N=N, d=1, alpha=0.3, eta=0.05, beta=0.02,
                                      gamma=gamma, kappa=3.0, sigma=0.12)
            model_sum = sum(J[N, j] for j in range(N))
            assert model_sum == pytest.approx(-gamma)
            assert J[N, N] == pytest.approx(1.0 + gamma)
            assert np.sum(J[N, :]) == pytest.approx(1.0)

    def test_alpha_zero_decouples_models(self):
        """At α=0, off-diagonal model-model entries should be zero
        (no inter-model coupling through data pool)."""
        J = compute_full_jacobian(N=3, d=1, alpha=0.0, eta=0.05, beta=0.02,
                                  gamma=0.05, kappa=3.0, sigma=0.12)
        for i in range(3):
            for j in range(3):
                if i != j:
                    assert J[i, j] == pytest.approx(0.0)


class TestAnalyticalEigenvalues:
    """Cross-validate analytical eigenvalues against numerical eigenvalues
    of the Jacobian (independent computation paths)."""

    @pytest.mark.parametrize("N,alpha,eta,beta,gamma,kappa,sigma", [
        (2, 0.0, 0.10, 0.05, 0.00, 3.0, 0.12),
        (3, 0.3, 0.05, 0.02, 0.05, 3.0, 0.12),
        (4, 0.5, 0.05, 0.02, 0.10, 3.0, 0.12),
        (3, 0.8, 0.08, 0.01, 0.05, 3.0, 0.12),
        (5, 1.0, 0.03, 0.04, 0.02, 5.0, 0.08),
        (2, 0.6, 0.15, 0.10, 0.08, 1.0, 0.20),
    ])
    def test_analytical_matches_numerical(self, N, alpha, eta, beta, gamma, kappa, sigma):
        """Cross-validate: analytical formulas vs numpy.linalg.eigvals on Jacobian."""
        result = verify_eigenvalue_derivation(
            N=N, alpha=alpha, eta=eta, beta=beta, gamma=gamma,
            kappa=kappa, sigma=sigma, tol=1e-10,
        )
        assert result['match'], (
            f"N={N}, α={alpha}: max_error={result['max_error']:.2e}"
        )

    def test_lambda_diff_multiplicity(self):
        """The difference eigenvalue should appear N-1 times in numerical spectrum."""
        N = 5
        J = compute_full_jacobian(N=N, d=1, alpha=0.3, eta=0.05, beta=0.02,
                                  gamma=0.05, kappa=3.0, sigma=0.12)
        numerical = np.sort(np.real(np.linalg.eigvals(J)))
        eigs = compute_eigenvalues_analytical(
            N=N, alpha=0.3, eta=0.05, beta=0.02, gamma=0.05,
            kappa=3.0, sigma=0.12,
        )
        ld = eigs['lambda_diff']
        count = sum(1 for e in numerical if abs(e - ld) < 1e-8)
        assert count == N - 1

    def test_lambda_diff_decreases_with_alpha(self):
        """λ_diff should strictly decrease as α increases (for κ>0)."""
        alphas = np.linspace(0, 1, 20)
        lds = []
        for a in alphas:
            eigs = compute_eigenvalues_analytical(
                N=3, alpha=a, eta=0.05, beta=0.02, gamma=0.05,
                kappa=3.0, sigma=0.12,
            )
            lds.append(eigs['lambda_diff'])
        diffs = np.diff(lds)
        assert np.all(diffs < 0), "λ_diff should decrease with α when κ > 0"

    def test_lambda_diff_independent_of_gamma(self):
        """λ_diff should NOT depend on γ (diversity mode decouples from benchmark)."""
        for gamma in [0.0, 0.05, 0.15, 0.5]:
            eigs = compute_eigenvalues_analytical(
                N=3, alpha=0.3, eta=0.05, beta=0.02, gamma=gamma,
                kappa=3.0, sigma=0.12,
            )
            assert eigs['lambda_diff'] == pytest.approx(
                compute_eigenvalues_analytical(
                    N=3, alpha=0.3, eta=0.05, beta=0.02, gamma=0.0,
                    kappa=3.0, sigma=0.12,
                )['lambda_diff']
            )

    def test_lambda_diff_independent_of_N(self):
        """λ_diff should NOT depend on N."""
        for N in [2, 3, 5, 10]:
            eigs = compute_eigenvalues_analytical(
                N=N, alpha=0.3, eta=0.05, beta=0.02, gamma=0.05,
                kappa=3.0, sigma=0.12,
            )
            assert eigs['lambda_diff'] == pytest.approx(
                compute_eigenvalues_analytical(
                    N=2, alpha=0.3, eta=0.05, beta=0.02, gamma=0.05,
                    kappa=3.0, sigma=0.12,
                )['lambda_diff']
            )

    def test_2x2_eigenvalues_via_trace_det(self):
        """Verify λ± from the 2×2 mean-benchmark system using characteristic polynomial."""
        alpha, gamma = 0.3, 0.05
        eigs = compute_eigenvalues_analytical(
            N=2, alpha=alpha, eta=0.05, beta=0.02, gamma=gamma,
            kappa=3.0, sigma=0.12,
        )
        lp = eigs['lambda_mean_bench_plus']
        lm = eigs['lambda_mean_bench_minus']
        # λ+ * λ- = det, λ+ + λ- = trace
        A = eigs['lambda_mean']
        expected_trace = A + 1.0 + gamma
        expected_det = A * (1.0 + gamma) + 0.02 * gamma
        assert (lp + lm) == pytest.approx(expected_trace, abs=1e-12)
        assert (lp * lm) == pytest.approx(expected_det, abs=1e-12)


class TestTheorem1:
    """Theorem 1: Diversity erosion via variance compression.
    Key predictions:
    - D_eq(α)/D_eq(0) is monotonically decreasing in α
    - D_eq(0)/D_eq(0) = 1.0
    - The ratio at α=1 matches independent numerical simulation
    - Holds across a range of parameter values, not just one cherry-picked set
    """

    def test_diversity_curve_monotone_decreasing_multiple_params(self):
        """D_ratio must be monotonically decreasing across diverse parameter sets."""
        param_sets = [
            dict(eta=0.05, beta=0.02, kappa=3.0, sigma=0.12),
            dict(eta=0.10, beta=0.05, kappa=1.0, sigma=0.08),
            dict(eta=0.03, beta=0.01, kappa=5.0, sigma=0.20),
        ]
        for params in param_sets:
            curve = compute_diversity_curve(**params, dim=10, noise_std=0.005)
            diffs = np.diff(curve['D_ratio'])
            assert np.all(diffs <= 1e-10), f"Not monotone at {params}"

    def test_diversity_ratio_one_at_alpha_zero(self):
        """D_ratio should be 1.0 at α=0 (normalization)."""
        curve = compute_diversity_curve(
            eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
        )
        assert curve['D_ratio'][0] == pytest.approx(1.0)

    def test_diversity_ratio_strictly_less_than_one_at_alpha_one(self):
        """For κ>0, diversity must drop at α=1."""
        for kappa in [1.0, 3.0, 5.0]:
            result = prove_theorem_1(eta=0.05, beta=0.02, kappa=kappa, sigma=0.12)
            assert 0 < result.diversity_ratio_predicted < 1.0, (
                f"At κ={kappa}: ratio={result.diversity_ratio_predicted}"
            )

    def test_higher_kappa_means_more_erosion(self):
        """Larger κ should produce a lower diversity ratio (more erosion)."""
        ratios = []
        for kappa in [0.5, 1.0, 3.0, 5.0]:
            result = prove_theorem_1(eta=0.05, beta=0.02, kappa=kappa, sigma=0.12)
            ratios.append(result.diversity_ratio_predicted)
        # Should be strictly decreasing
        assert all(ratios[i] > ratios[i + 1] for i in range(len(ratios) - 1))

    def test_kappa_zero_means_no_erosion(self):
        """With κ=0, diversity ratio at α=1 should equal 1.0 (no variance compression)."""
        result = prove_theorem_1(eta=0.05, beta=0.02, kappa=0.0, sigma=0.12)
        assert result.diversity_ratio_predicted == pytest.approx(1.0, abs=1e-10)

    def test_d_eq_formula_via_ar1_monte_carlo(self):
        """Cross-validate the D_eq formula against a direct AR(1) Monte Carlo.

        The theorem says δ(t+1) = λ·δ(t) + σ·Δs + (ε_i - ε_j), where
        Δs = s_i - s_j is fixed. At equilibrium:
            E[||δ||²] = σ²·||Δs||²/(1-λ)² + 2d·σ_ε²/(1-λ²)

        We simulate this AR(1) directly (no ecosystem code) and compare
        the empirical E[||δ||²] against the analytical formula.
        """
        rng = np.random.default_rng(42)
        dim = 5
        sigma = 0.12
        noise_std = 0.02  # non-negligible noise so both terms matter
        eta, beta, kappa = 0.05, 0.02, 3.0

        for alpha in [0.0, 0.3, 0.7]:
            lam = 1.0 - eta * (1.0 + kappa * alpha) - beta - sigma
            assert abs(lam) < 1.0, "Stability required"

            # Fixed specialization difference vector
            delta_s = rng.standard_normal(dim)

            # Run AR(1): δ(t+1) = λ·δ(t) + σ·Δs + noise
            delta = np.zeros(dim)
            n_burn = 2000
            n_sample = 10000
            samples = []
            for t in range(n_burn + n_sample):
                noise = rng.normal(0, noise_std, dim) - rng.normal(0, noise_std, dim)
                delta = lam * delta + sigma * delta_s + noise
                if t >= n_burn:
                    samples.append(np.sum(delta**2))

            empirical_D = np.mean(samples)

            # Analytical formula
            D_spec_term = sigma**2 * np.sum(delta_s**2) / (1.0 - lam)**2
            D_noise_term = 2 * dim * noise_std**2 / (1.0 - lam**2)
            analytical_D = D_spec_term + D_noise_term

            assert empirical_D == pytest.approx(analytical_D, rel=0.08), (
                f"α={alpha}: empirical={empirical_D:.4f} vs analytical={analytical_D:.4f}"
            )

    def test_proof_conditions_actually_constrain(self):
        """prove_theorem_1 should reject params that violate stability at α=1.

        With large κ, η_eff(1) = η(1+κ) can push |λ_diff(1)| ≥ 1.
        """
        # With η=0.3, κ=5: η_eff(1) = 0.3*6 = 1.8. λ_diff(1) = 1 - 1.8 - 0.02 - 0.12 = -0.94
        # But that's still |λ_diff| < 1. Push harder:
        # η=0.5, κ=3: η_eff(1) = 0.5*4 = 2.0. λ_diff(1) = 1 - 2.0 - 0.1 - 0.1 = -1.2 → |λ| > 1
        result = prove_theorem_1(eta=0.5, beta=0.1, kappa=3.0, sigma=0.1)
        assert not result.conditions['stability_alpha_1']
        assert not result.proof_valid


class TestTheorem2:
    """Theorem 2: Benchmark gaming / overfitting.
    Key prediction: there exists a critical β* where the mean-benchmark
    system transitions from stable to unstable.
    """

    def test_higher_gamma_higher_spectral_radius(self):
        """Increasing γ should increase spectral radius (benchmark diverges faster).

        This is the core Theorem 2 mechanism: adaptive benchmark (γ>0) pushes
        the dominant eigenvalue above 1, and stronger γ makes it worse.
        """
        rhos = []
        for gamma in [0.0, 0.02, 0.05, 0.10, 0.20]:
            eigs = compute_eigenvalues_analytical(
                N=2, alpha=0.3, eta=0.05, beta=0.02, gamma=gamma,
                kappa=3.0, sigma=0.12,
            )
            rho = max(abs(eigs['lambda_mean_bench_plus']),
                      abs(eigs['lambda_mean_bench_minus']))
            rhos.append(rho)
        for i in range(len(rhos) - 1):
            assert rhos[i] <= rhos[i + 1] + 1e-10, (
                f"ρ should increase with γ: ρ[{i}]={rhos[i]}, ρ[{i+1}]={rhos[i+1]}"
            )

    def test_static_benchmark_never_diverges(self):
        """With γ=0 (static benchmark), system should never have benchmark divergence."""
        for beta in [0.01, 0.1, 0.5, 1.0]:
            eigs = compute_eigenvalues_analytical(
                N=3, alpha=0.3, eta=0.05, beta=beta, gamma=0.0,
                kappa=3.0, sigma=0.12,
            )
            # With γ=0, benchmark eigenvalue is exactly 1+γ=1.0.
            # The mean-benchmark eigenvalues are just λ_mean and 1.0.
            rho = max(abs(eigs['lambda_mean_bench_plus']),
                      abs(eigs['lambda_mean_bench_minus']))
            assert rho <= 1.0 + 1e-10, (
                f"Static benchmark should not diverge, but ρ={rho} at β={beta}"
            )

    def test_higher_gamma_lower_beta_star(self):
        """More aggressive benchmark adaptation (higher γ) should make instability
        easier to trigger (lower β*)."""
        beta_stars = []
        for gamma in [0.02, 0.05, 0.10, 0.20]:
            result = prove_theorem_2(
                eta=0.05, beta=0.02, gamma=gamma, kappa=3.0, sigma=0.12,
            )
            beta_stars.append(result.beta_star)
        # β* should decrease as γ increases
        assert all(beta_stars[i] >= beta_stars[i + 1] for i in range(len(beta_stars) - 1))

    def test_proof_requires_adaptive_benchmark(self):
        """Theorem 2 should not validate with γ=0."""
        result = prove_theorem_2(
            eta=0.05, beta=0.02, gamma=0.0, kappa=3.0, sigma=0.12,
        )
        assert not result.proof_valid


class TestTheorem3:
    """Theorem 3: Paradoxical intervention.
    Key prediction: improving one model can hurt others through the data pool.
    Coupling strength = η_eff·α·Δ/N.
    """

    def test_coupling_increases_with_alpha(self):
        """Higher α should produce stronger inter-model coupling."""
        couplings = []
        for alpha in [0.0, 0.1, 0.3, 0.5, 0.8, 1.0]:
            result = prove_theorem_3(
                eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
                alpha=alpha, N=3, improvement=0.5,
            )
            couplings.append(result.coupling_strength)
        # Should be strictly increasing
        assert all(couplings[i] < couplings[i + 1] for i in range(len(couplings) - 1))

    def test_coupling_increases_with_kappa(self):
        """Higher κ amplifies the coupling (through η_eff)."""
        couplings = []
        for kappa in [0.0, 1.0, 3.0, 5.0]:
            result = prove_theorem_3(
                eta=0.05, beta=0.02, kappa=kappa, sigma=0.12,
                alpha=0.3, N=3, improvement=0.5,
            )
            couplings.append(result.coupling_strength)
        assert all(couplings[i] < couplings[i + 1] for i in range(len(couplings) - 1))

    def test_coupling_inversely_proportional_to_N(self):
        """More models should dilute the per-model perturbation."""
        c2 = prove_theorem_3(
            eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
            alpha=0.3, N=2, improvement=0.5,
        ).coupling_strength
        c6 = prove_theorem_3(
            eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
            alpha=0.3, N=6, improvement=0.5,
        ).coupling_strength
        # coupling ∝ 1/N, so c2/c6 ≈ 3
        assert c2 / c6 == pytest.approx(3.0)

    def test_no_coupling_at_alpha_zero(self):
        """At α=0, there's no data pool coupling, so no paradox."""
        result = prove_theorem_3(
            eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
            alpha=0.0, N=3, improvement=0.5,
        )
        assert result.coupling_strength == pytest.approx(0.0)
        assert not result.paradox_exists

    def test_proof_requires_contamination(self):
        """Theorem 3 should not validate at α=0."""
        result = prove_theorem_3(
            eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
            alpha=0.0, N=3, improvement=0.5,
        )
        assert not result.proof_valid


class TestStabilityMap:
    def test_shape(self):
        smap = compute_stability_map(
            alpha_range=np.linspace(0, 1, 10),
            beta_range=np.linspace(0, 0.5, 10),
            eta=0.05, gamma=0.05, kappa=3.0, sigma=0.12, N=3,
        )
        assert smap['stability_class'].shape == (10, 10)
        assert smap['spectral_radius_map'].shape == (10, 10)

    def test_alpha_zero_row_no_diversity_erosion(self):
        """At α=0, there should be no diversity erosion (class 0 or 2 only)."""
        smap = compute_stability_map(
            alpha_range=np.array([0.0]),
            beta_range=np.linspace(0, 0.5, 20),
            eta=0.05, gamma=0.05, kappa=3.0, sigma=0.12, N=3,
        )
        classes = smap['stability_class'][0, :]
        # Classes 1 and 3 indicate diversity erosion
        assert not np.any((classes == 1) | (classes == 3))

    def test_high_alpha_has_diversity_erosion(self):
        """At high α, there should be diversity erosion somewhere."""
        smap = compute_stability_map(
            alpha_range=np.array([0.8]),
            beta_range=np.linspace(0.0, 0.3, 20),
            eta=0.05, gamma=0.05, kappa=3.0, sigma=0.12, N=3,
        )
        classes = smap['stability_class'][0, :]
        # At least some points should show diversity erosion
        assert np.any((classes == 1) | (classes == 3))
