"""Tests for fixed points, eigenvalues, and stability analysis."""

import numpy as np
import pytest

from llm_eco_sim.theory.equilibria import (
    FixedPoint,
    compute_fixed_point_analytical,
    compute_jacobian_eigenvalues,
    stability_analysis,
    find_critical_alpha,
    compute_diversity_erosion_threshold,
)

ETA = 0.05
BETA = 0.02
SIGMA = 0.12
KAPPA = 3.0
DIM = 5


class TestFixedPoint:
    def test_static_benchmark_fixed_point_shape(self):
        fp = compute_fixed_point_analytical(
            n_models=2, dim=DIM, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.0, natural_mean=np.zeros(DIM),
            benchmark_initial=np.ones(DIM) / np.sqrt(DIM),
            kappa=KAPPA, sigma=SIGMA,
        )
        assert isinstance(fp, FixedPoint)
        assert fp.capabilities.shape == (2, DIM)

    def test_fixed_point_symmetric(self):
        """In symmetric case, all model capabilities should be equal at equilibrium."""
        fp = compute_fixed_point_analytical(
            n_models=3, dim=DIM, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.0, natural_mean=np.zeros(DIM),
            benchmark_initial=np.ones(DIM) / np.sqrt(DIM),
            kappa=KAPPA, sigma=SIGMA,
        )
        np.testing.assert_allclose(fp.capabilities[0], fp.capabilities[1])
        np.testing.assert_allclose(fp.capabilities[1], fp.capabilities[2])

    def test_fixed_point_between_natural_and_benchmark(self):
        """With static benchmark, c* should lie between μ_nat and b
        (it's a weighted average of natural mean, benchmark, and spec target)."""
        nat = np.zeros(DIM)
        bench = np.ones(DIM) * 2.0
        fp = compute_fixed_point_analytical(
            n_models=2, dim=DIM, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.0, natural_mean=nat,
            benchmark_initial=bench,
            kappa=KAPPA, sigma=SIGMA,
        )
        c_star = fp.capabilities[0]
        # c* should be pulled toward benchmark (positive components)
        assert np.all(c_star >= 0), "c* should be between nat=0 and bench=2"
        # but not past the benchmark
        assert np.linalg.norm(c_star) < np.linalg.norm(bench)


class TestJacobianEigenvalues:
    def test_eigenvalue_count(self):
        eigs = compute_jacobian_eigenvalues(
            n_models=3, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.05, kappa=KAPPA, sigma=SIGMA,
        )
        assert len(eigs) == 4  # N+1 = 3+1

    def test_eigenvalues_match_formal_proofs_module(self):
        """Cross-validate: equilibria.py eigenvalues should match formal_proofs.py."""
        from llm_eco_sim.theory.formal_proofs import compute_eigenvalues_analytical
        for alpha in [0.0, 0.3, 0.7, 1.0]:
            eigs_eq = compute_jacobian_eigenvalues(
                n_models=3, alpha=alpha, eta=ETA, beta=BETA,
                gamma=0.05, kappa=KAPPA, sigma=SIGMA,
            )
            eigs_fp = compute_eigenvalues_analytical(
                N=3, alpha=alpha, eta=ETA, beta=BETA, gamma=0.05,
                kappa=KAPPA, sigma=SIGMA,
            )
            # Numerical eigenvalues from equilibria should match analytical
            num_sorted = np.sort(np.real(eigs_eq))
            # Build analytical list
            ana_list = [eigs_fp['lambda_diff']] * 2  # N-1 = 2
            ana_list.append(float(np.real(eigs_fp['lambda_mean_bench_plus'])))
            ana_list.append(float(np.real(eigs_fp['lambda_mean_bench_minus'])))
            ana_sorted = np.sort(ana_list)
            np.testing.assert_allclose(num_sorted, ana_sorted, atol=1e-10,
                                       err_msg=f"Mismatch at α={alpha}")

    def test_spectral_radius_increases_with_gamma(self):
        """Higher γ should increase spectral radius (more instability potential)."""
        eigs_low = compute_jacobian_eigenvalues(
            n_models=2, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.01, kappa=KAPPA, sigma=SIGMA,
        )
        eigs_high = compute_jacobian_eigenvalues(
            n_models=2, alpha=0.3, eta=ETA, beta=BETA,
            gamma=0.2, kappa=KAPPA, sigma=SIGMA,
        )
        rho_low = np.max(np.abs(eigs_low))
        rho_high = np.max(np.abs(eigs_high))
        assert rho_high > rho_low


class TestStabilityAnalysis:
    def test_returns_required_keys(self):
        result = stability_analysis(
            alpha=0.3, eta=ETA, beta=BETA, gamma=0.0,
            n_models=2, kappa=KAPPA, sigma=SIGMA,
        )
        for key in ["eigenvalues", "spectral_radius", "is_stable",
                     "convergence_rate", "dominant_eigenvalue"]:
            assert key in result

    def test_higher_alpha_increases_diversity_contraction(self):
        """Higher α → stronger contraction of diversity mode (smaller λ_diff).

        This tests the core mechanism: α increases η_eff, which decreases λ_diff.
        """
        from llm_eco_sim.theory.formal_proofs import compute_eigenvalues_analytical
        lds = []
        for alpha in np.linspace(0, 1, 20):
            eigs = compute_eigenvalues_analytical(
                N=2, alpha=alpha, eta=ETA, beta=BETA, gamma=0.05,
                kappa=KAPPA, sigma=SIGMA,
            )
            lds.append(eigs['lambda_diff'])
        # λ_diff should be strictly decreasing
        for i in range(len(lds) - 1):
            assert lds[i] > lds[i + 1]

    def test_find_critical_alpha_meaningful(self):
        """Critical α should be < 1 for parameters with strong benchmark adaptation."""
        alpha_c = find_critical_alpha(
            eta=0.05, beta=0.1, gamma=0.1,
            n_models=2, kappa=KAPPA, sigma=SIGMA,
        )
        # With strong β and γ, system should go unstable before α=1
        assert alpha_c < 1.0
        # Verify: stable just below, unstable at or above
        if alpha_c > 0.01:
            r_below = stability_analysis(
                alpha=alpha_c - 0.01, eta=0.05, beta=0.1, gamma=0.1,
                n_models=2, kappa=KAPPA, sigma=SIGMA,
            )
            assert r_below["is_stable"]

    def test_diversity_erosion_threshold_ordering(self):
        """Higher κ should give a lower erosion threshold (diversity drops faster)."""
        thresholds = []
        for kappa in [1.0, 3.0, 5.0]:
            alpha_50 = compute_diversity_erosion_threshold(
                eta=ETA, beta=BETA, n_models=2,
                kappa=kappa, sigma=SIGMA, dim=DIM, noise_std=0.005,
            )
            thresholds.append(alpha_50)
        assert all(thresholds[i] > thresholds[i + 1]
                   for i in range(len(thresholds) - 1))
