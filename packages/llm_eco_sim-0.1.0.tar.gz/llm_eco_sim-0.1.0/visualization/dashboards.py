"""
dashboards.py - Interactive dashboard for exploration.

Provides functions to create comprehensive static dashboards and
export-ready figure collections for the llm-eco-sim framework.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from typing import Optional, List, Tuple, Dict

from llm_eco_sim.simulation.simulator import SimulationResult, Simulator, SimulationConfig
from llm_eco_sim.visualization.trajectories import (
    plot_diversity_trajectory,
    plot_performance_trajectories,
    plot_brg_trajectory,
    plot_model_trajectories_2d,
    plot_contamination_trajectory,
)


def create_scenario_comparison_dashboard(
    results: List[SimulationResult],
    figsize: Tuple[int, int] = (20, 16),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Create a comprehensive dashboard comparing multiple scenarios.

    Parameters
    ----------
    results : List[SimulationResult]
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    n_scenarios: int = len(results)
    fig = plt.figure(figsize=figsize)
    gs = gridspec.GridSpec(4, n_scenarios, hspace=0.4, wspace=0.3)

    colors = plt.cm.tab10(np.linspace(0, 1, 10))

    for col, result in enumerate(results):
        # Diversity
        ax = fig.add_subplot(gs[0, col])
        plot_diversity_trajectory(result, ax=ax,
                                  title=f"{result.config.name}\nDiversity")

        # Performance
        ax = fig.add_subplot(gs[1, col])
        plot_performance_trajectories(result, ax=ax, title="Performance")

        # BRG
        ax = fig.add_subplot(gs[2, col])
        plot_brg_trajectory(result, ax=ax, title="BRG")

        # 2D Trajectories
        ax = fig.add_subplot(gs[3, col])
        plot_model_trajectories_2d(result, ax=ax, title="Trajectories")

    fig.suptitle(
        "Ecosystem Scenario Comparison Dashboard",
        fontsize=18, fontweight="bold", y=0.98
    )

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def create_parameter_sweep_dashboard(
    param_name: str,
    param_values: np.ndarray,
    results: List[SimulationResult],
    figsize: Tuple[int, int] = (18, 10),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Create a dashboard showing how metrics change across a parameter sweep.

    Parameters
    ----------
    param_name : str
    param_values : np.ndarray
    results : List[SimulationResult]
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    fig, axes = plt.subplots(2, 3, figsize=figsize)

    # Extract final metrics
    final_div = [r.diversity_trajectory[-1] for r in results]
    final_bench = [r.benchmark_score_trajectory[-1] for r in results]
    final_rw = [r.real_world_performance_trajectory[-1] for r in results]
    final_brg = [r.brg_trajectory[-1] for r in results]
    final_contam = [r.contamination_trajectory[-1] for r in results]

    # Diversity vs parameter
    ax = axes[0, 0]
    ax.plot(param_values, final_div, "o-", color="#2196F3", linewidth=2, markersize=4)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Final Diversity", fontsize=11)
    ax.set_title("Diversity", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Benchmark score vs parameter
    ax = axes[0, 1]
    ax.plot(param_values, final_bench, "o-", color="#4CAF50", linewidth=2, markersize=4)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Final Benchmark Score", fontsize=11)
    ax.set_title("Benchmark Score", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Real-world performance vs parameter
    ax = axes[0, 2]
    ax.plot(param_values, final_rw, "o-", color="#FF4336", linewidth=2, markersize=4)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Final Real-World Perf", fontsize=11)
    ax.set_title("Real-World Performance", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # BRG vs parameter
    ax = axes[1, 0]
    ax.plot(param_values, final_brg, "o-", color="#FF9800", linewidth=2, markersize=4)
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Final BRG", fontsize=11)
    ax.set_title("Benchmark-Reality Gap", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Diversity trajectories (overlay)
    ax = axes[1, 1]
    cmap = plt.cm.viridis(np.linspace(0, 1, len(results)))
    for i, result in enumerate(results):
        ax.plot(result.time_steps, result.diversity_trajectory,
                color=cmap[i], linewidth=1, alpha=0.7)
    ax.set_xlabel("Time Step", fontsize=11)
    ax.set_ylabel("Diversity", fontsize=11)
    ax.set_title("Diversity Trajectories", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Erosion ratio
    ax = axes[1, 2]
    erosion_ratios = [r.summary()["diversity_erosion_ratio"] for r in results]
    ax.plot(param_values, erosion_ratios, "o-", color="#9C27B0", linewidth=2, markersize=4)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Erosion Ratio", fontsize=11)
    ax.set_title("Diversity Erosion Ratio", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    fig.suptitle(
        f"Parameter Sweep Dashboard — {param_name}",
        fontsize=15, fontweight="bold"
    )
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def generate_paper_figures(
    output_dir: str = "./figures",
    n_steps: int = 300,
    seed: int = 42,
) -> Dict[str, str]:
    """
    Generate publication-quality figures for the paper.

    Creates all key figures needed for the paper.

    Parameters
    ----------
    output_dir : str
        Directory to save figures.
    n_steps : int
        Simulation steps.
    seed : int
        Random seed.

    Returns
    -------
    Dict[str, str]
        Mapping of figure names to file paths.
    """
    import os
    os.makedirs(output_dir, exist_ok=True)

    plt.rcParams.update({
        "font.size": 12,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "figure.dpi": 150,
    })

    figures: Dict[str, str] = {}

    # Figure 1: Diversity erosion across alpha values
    from llm_eco_sim.theory.phase_transitions import scan_contamination_rate
    result = scan_contamination_rate(
        alpha_range=np.linspace(0, 1, 50),
        n_steps=n_steps, seed=seed,
    )
    from llm_eco_sim.visualization.phase_diagrams import plot_phase_transition
    fig = plot_phase_transition(result, save_path=f"{output_dir}/fig1_diversity_erosion.png")
    figures["diversity_erosion"] = f"{output_dir}/fig1_diversity_erosion.png"
    plt.close(fig)

    # Figure 2: Benchmark gaming
    from llm_eco_sim.theory.phase_transitions import scan_benchmark_pressure
    result2 = scan_benchmark_pressure(
        beta_range=np.linspace(0, 0.5, 50),
        n_steps=n_steps, seed=seed,
    )
    fig = plot_phase_transition(result2, save_path=f"{output_dir}/fig2_benchmark_gaming.png")
    figures["benchmark_gaming"] = f"{output_dir}/fig2_benchmark_gaming.png"
    plt.close(fig)

    # Figure 3: Phase diagram
    from llm_eco_sim.theory.phase_transitions import compute_phase_diagram
    phase_data = compute_phase_diagram(
        alpha_range=np.linspace(0, 1, 20),
        beta_range=np.linspace(0, 0.4, 20),
        n_steps=n_steps, seed=seed,
    )
    from llm_eco_sim.visualization.phase_diagrams import plot_phase_diagram
    fig = plot_phase_diagram(phase_data, save_path=f"{output_dir}/fig3_phase_diagram.png")
    figures["phase_diagram"] = f"{output_dir}/fig3_phase_diagram.png"
    plt.close(fig)

    # Figure 4: Scenario comparison
    from llm_eco_sim.simulation.scenarios import (
        open_web_scenario, walled_garden_scenario, regulated_scenario
    )
    configs: List[SimulationConfig] = [
        open_web_scenario(n_steps=n_steps, seed=seed),
        walled_garden_scenario(n_steps=n_steps, seed=seed),
        regulated_scenario(n_steps=n_steps, seed=seed),
    ]
    sim_results: List[SimulationResult] = Simulator.compare_scenarios(configs)
    from llm_eco_sim.visualization.trajectories import compare_results
    fig = compare_results(sim_results, metric="diversity",
                          save_path=f"{output_dir}/fig4_scenario_comparison.png")
    figures["scenario_comparison"] = f"{output_dir}/fig4_scenario_comparison.png"
    plt.close(fig)

    return figures
