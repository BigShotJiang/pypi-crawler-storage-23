"""
trajectories.py - Ecosystem evolution over time.

Visualization functions for plotting how the ecosystem evolves:
- Diversity over time
- Benchmark scores over time
- Real-world performance over time
- Model capability trajectories
- Benchmark-reality gap
- Multi-metric dashboard panels
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from typing import List, Optional, Dict, Tuple

from llm_eco_sim.simulation.simulator import SimulationResult


def plot_diversity_trajectory(
    result: SimulationResult,
    ax: Optional[plt.Axes] = None,
    title: str = "Diversity Index Over Time",
    color: str = "#2196F3",
    log_scale: bool = False,
) -> plt.Axes:
    """
    Plot diversity index over time.

    Parameters
    ----------
    result : SimulationResult
    ax : Optional[plt.Axes]
    title : str
    color : str
    log_scale : bool

    Returns
    -------
    plt.Axes
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 5))

    t = result.time_steps
    div = result.diversity_trajectory

    ax.plot(t, div, color=color, linewidth=2, label="Diversity")
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Diversity Index", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)

    if log_scale and np.all(div > 0):
        ax.set_yscale("log")

    ax.legend(fontsize=10)
    return ax


def plot_performance_trajectories(
    result: SimulationResult,
    ax: Optional[plt.Axes] = None,
    title: str = "Performance Over Time",
) -> plt.Axes:
    """
    Plot benchmark score and real-world performance over time.

    Parameters
    ----------
    result : SimulationResult
    ax : Optional[plt.Axes]
    title : str

    Returns
    -------
    plt.Axes
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 5))

    t = result.time_steps

    ax.plot(t, result.benchmark_score_trajectory, color="#4CAF50",
            linewidth=2, label="Benchmark Score")
    ax.plot(t, -result.real_world_performance_trajectory, color="#F44336",
            linewidth=2, label="Real-World Distance (lower-better)")

    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Score / Distance", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=10)
    return ax


def plot_brg_trajectory(
    result: SimulationResult,
    ax: Optional[plt.Axes] = None,
    title: str = "Benchmark-Reality Gap",
) -> plt.Axes:
    """
    Plot benchmark-reality gap over time.

    Positive BRG = models closer to benchmark than reality (overfitting).

    Parameters
    ----------
    result : SimulationResult
    ax : Optional[plt.Axes]
    title : str

    Returns
    -------
    plt.Axes
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 5))

    t = result.time_steps
    brg = result.brg_trajectory

    ax.plot(t, brg, color="#FF9800", linewidth=2, label="BRG")
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.fill_between(t, 0, brg, where=brg > 0, alpha=0.2, color="#FF9800",
                    label="Overfitting region")
    ax.fill_between(t, 0, brg, where=brg <= 0, alpha=0.2, color="#2196F3",
                    label="Reality-aligned region")

    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Benchmark-Reality Gap", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=10)
    return ax


def plot_model_trajectories_2d(
    result: SimulationResult,
    dims: Tuple[int, int] = (0, 1),
    ax: Optional[plt.Axes] = None,
    title: str = "Model Trajectories in Capability Space",
    show_natural: bool = True,
    show_benchmark: bool = True,
) -> plt.Axes:
    """
    Plot model capability trajectories projected onto 2 dimensions.

    Parameters
    ----------
    result : SimulationResult
    dims : Tuple[int, int]
        Which two dimensions to project onto.
    ax : Optional[plt.Axes]
    title : str
    show_natural : bool
    show_benchmark : bool

    Returns
    -------
    plt.Axes
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 8))

    d1, d2 = dims
    colors = plt.cm.tab10(np.linspace(0, 1, len(result.ecosystem.models)))

    trajectories = result.ecosystem.get_model_trajectories()
    for idx, (name, traj) in enumerate(trajectories.items()):
        ax.plot(traj[:, d1], traj[:, d2], color=colors[idx], linewidth=1.5,
                alpha=0.7, label=name)
        ax.scatter(traj[0, d1], traj[0, d2], color=colors[idx], marker="o",
                   s=100, zorder=5, edgecolors="black")
        ax.scatter(traj[-1, d1], traj[-1, d2], color=colors[idx], marker="x",
                   s=200, zorder=5, edgecolors="black")

    if show_natural:
        nat = result.ecosystem.data_pool.natural_mean
        ax.scatter(nat[d1], nat[d2], color="green", marker="D", s=150,
                   zorder=6, edgecolors="black", label="Natural Mean")

    if show_benchmark:
        bench_hist = result.ecosystem.benchmark.history
        ax.plot(bench_hist[:, d1], bench_hist[:, d2], color="red",
                linestyle="--", linewidth=1.5, alpha=0.7, label="Benchmark")
        ax.scatter(bench_hist[-1, d1], bench_hist[-1, d2], color="red",
                   marker="X", s=150, zorder=6, edgecolors="black")

    ax.set_xlabel(f"Dimension {d1}", fontsize=12)
    ax.set_ylabel(f"Dimension {d2}", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=9, loc="best")
    ax.set_aspect("equal")
    return ax


def plot_contamination_trajectory(
    result: SimulationResult,
    ax: Optional[plt.Axes] = None,
    title: str = "Contamination Level Over Time",
) -> plt.Axes:
    """Plot effective contamination level over time."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(10, 5))

    t = result.time_steps
    contam = result.contamination_trajectory

    ax.plot(t, contam, color="#9C27B0", linewidth=2, label="Effective Contamination")
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Contamination Level", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=10)
    return ax


def plot_ecosystem_dashboard(
    result: SimulationResult,
    figsize: Tuple[int, int] = (16, 12),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Create a comprehensive dashboard with all key metrics.

    Parameters
    ----------
    result : SimulationResult
    figsize : Tuple[int, int]
    save_path : Optional[str]
        If provided, save the figure to this path.

    Returns
    -------
    plt.Figure
    """
    fig = plt.figure(figsize=figsize)
    gs = gridspec.GridSpec(3, 2, hspace=0.35, wspace=0.3)

    # Diversity
    ax1 = fig.add_subplot(gs[0, 0])
    plot_diversity_trajectory(result, ax=ax1, title="Diversity Index")

    # Performance
    ax2 = fig.add_subplot(gs[0, 1])
    plot_performance_trajectories(result, ax=ax2, title="Performance Metrics")

    # BRG
    ax3 = fig.add_subplot(gs[1, 0])
    plot_brg_trajectory(result, ax=ax3, title="Benchmark-Reality Gap")

    # Contamination
    ax4 = fig.add_subplot(gs[1, 1])
    plot_contamination_trajectory(result, ax=ax4, title="Contamination Level")

    # 2D Trajectories
    ax5 = fig.add_subplot(gs[2, 0])
    plot_model_trajectories_2d(result, ax=ax5, title="Capability Trajectories (dim 0-1)")

    # Summary text
    ax6 = fig.add_subplot(gs[2, 1])
    ax6.axis("off")
    summary = result.summary()
    text = "\n".join([
        f"Configuration: {summary['config_name']}",
        f"Steps: {summary['n_steps']}",
        f"Wall time: {summary['wall_time_seconds']:.2f}s",
        "",
        f"Diversity: {summary['initial_diversity']:.4f} -> {summary['final_diversity']:.4f}",
        f"Erosion ratio: {summary['diversity_erosion_ratio']:.4f}",
        "",
        f"Benchmark: {summary['initial_benchmark_score']:.4f} -> {summary['final_benchmark_score']:.4f}",
        f"Real-world: {summary['initial_real_world_perf']:.4f} -> {summary['final_real_world_perf']:.4f}",
        "",
        f"Final BRG: {summary['final_brg']:.4f}",
        f"Interventions: {summary['n_interventions']}",
    ])
    ax6.text(0.1, 0.9, text, transform=ax6.transAxes, fontsize=11,
             verticalalignment="top", fontfamily="monospace",
             bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))
    ax6.set_title("Simulation Summary", fontsize=14, fontweight="bold")

    fig.suptitle(
        f"Ecosystem Simulation Dashboard — {result.config.name}",
        fontsize=16, fontweight="bold", y=0.98
    )

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def compare_results(
    results: List[SimulationResult],
    metric: str = "diversity",
    figsize: Tuple[int, int] = (12, 6),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Compare multiple simulation results on a single plot.

    Parameters
    ----------
    results : List[SimulationResult]
    metric : str
        "diversity", "benchmark_score", "real_world", "brg", "contamination"
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    metric_map: Dict[str, Tuple[str, str]] = {
        "diversity": ("diversity_trajectory", "Diversity Index"),
        "benchmark_score": ("benchmark_score_trajectory", "Benchmark Score"),
        "real_world": ("real_world_performance_trajectory", "Real-World Performance"),
        "brg": ("brg_trajectory", "Benchmark-Reality Gap"),
        "contamination": ("contamination_trajectory", "Contamination Level"),
    }

    if metric not in metric_map:
        raise ValueError(f"Unknown metric: {metric}")

    attr, ylabel = metric_map[metric]

    fig, ax = plt.subplots(figsize=figsize)
    colors = plt.cm.tab10(np.linspace(0, 1, len(results)))

    for idx, result in enumerate(results):
        t = result.time_steps
        values = getattr(result, attr)
        ax.plot(t, values, color=colors[idx], linewidth=2,
                label=result.config.name)

    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(f"Scenario Comparison — {ylabel}", fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=10)

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig
