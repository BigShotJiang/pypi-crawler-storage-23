"""
phase_diagrams.py - Phase space and bifurcation plots.

Visualization functions for:
- 2D phase diagrams (heatmaps over parameter pairs)
- Bifurcation diagrams
- Phase transition curves
- Stability regions
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from typing import Optional, Dict, Tuple, List

from llm_eco_sim.theory.phase_transitions import PhaseTransitionResult


def plot_phase_diagram(
    phase_data: Dict,
    figsize: Tuple[int, int] = (10, 8),
    cmap: str = "RdYlBu_r",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Plot a 2D phase diagram as a heatmap.

    Parameters
    ----------
    phase_data : Dict
        Output from compute_phase_diagram() containing:
        - alpha_range, beta_range, values, metric
    figsize : Tuple[int, int]
    cmap : str
        Colormap name.
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    fig, ax = plt.subplots(figsize=figsize)

    alpha_range = phase_data["alpha_range"]
    beta_range = phase_data["beta_range"]
    values = phase_data["values"]
    metric = phase_data["metric"]

    im = ax.imshow(
        values.T,
        origin="lower",
        extent=[alpha_range[0], alpha_range[-1], beta_range[0], beta_range[-1]],
        aspect="auto",
        cmap=cmap,
        interpolation="bilinear",
    )

    cbar = fig.colorbar(im, ax=ax, label=metric.replace("_", " ").title())

    ax.set_xlabel("Contamination Rate (α)", fontsize=13)
    ax.set_ylabel("Benchmark Pressure (β)", fontsize=13)
    ax.set_title(
        f"Phase Diagram — {metric.replace('_', ' ').title()}",
        fontsize=15, fontweight="bold"
    )

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_phase_transition(
    result: PhaseTransitionResult,
    figsize: Tuple[int, int] = (12, 8),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Plot a phase transition curve showing how metrics change with a parameter.

    Parameters
    ----------
    result : PhaseTransitionResult
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    fig, axes = plt.subplots(2, 2, figsize=figsize)

    param = result.parameter_values
    param_name: str = result.parameter_name

    # Diversity
    ax = axes[0, 0]
    ax.plot(param, result.diversity_values, color="#2196F3", linewidth=2)
    if result.critical_value is not None:
        ax.axvline(x=result.critical_value, color="red", linestyle="--",
                   alpha=0.7, label=f"Critical = {result.critical_value:.3f}")
        ax.legend(fontsize=9)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Diversity Index", fontsize=11)
    ax.set_title("Diversity", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Benchmark Score
    ax = axes[0, 1]
    ax.plot(param, result.benchmark_scores, color="#4CAF50", linewidth=2)
    if result.critical_value is not None:
        ax.axvline(x=result.critical_value, color="red", linestyle="--", alpha=0.7)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Benchmark Score", fontsize=11)
    ax.set_title("Benchmark Score", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Real-world Performance
    ax = axes[1, 0]
    ax.plot(param, result.real_world_performance, color="#F44336", linewidth=2)
    if result.critical_value is not None:
        ax.axvline(x=result.critical_value, color="red", linestyle="--", alpha=0.7)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Real-World Performance", fontsize=11)
    ax.set_title("Real-World Performance", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # BRG
    ax = axes[1, 1]
    ax.plot(param, result.brg_values, color="#FF9800", linewidth=2)
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.fill_between(param, 0, result.brg_values,
                    where=result.brg_values > 0, alpha=0.2, color="#FF9800")
    if result.critical_value is not None:
        ax.axvline(x=result.critical_value, color="red", linestyle="--", alpha=0.7)
    ax.set_xlabel(param_name, fontsize=11)
    ax.set_ylabel("Benchmark-Reality Gap", fontsize=11)
    ax.set_title("Benchmark-Reality Gap", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.3)

    fig.suptitle(
        f"Phase Transition Analysis — {result.transition_type.title()}",
        fontsize=14, fontweight="bold"
    )
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_bifurcation_diagram(
    bifurcation_data: Dict,
    figsize: Tuple[int, int] = (12, 6),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Plot a bifurcation diagram showing long-term behavior vs parameter.

    Parameters
    ----------
    bifurcation_data : Dict
        Output from bifurcation_analysis().
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    fig, ax = plt.subplots(figsize=figsize)

    param_range = bifurcation_data["parameter_range"]
    param_name = bifurcation_data["parameter_name"]
    diversity_samples = bifurcation_data["diversity_samples"]

    for i, (val, samples) in enumerate(zip(param_range, diversity_samples)):
        x = np.full(len(samples), val)
        ax.scatter(x, samples, s=0.5, color="#2196F3", alpha=0.3)

    ax.set_xlabel(f"{param_name}", fontsize=13)
    ax.set_ylabel("Diversity Index (long-term)", fontsize=13)
    ax.set_title(
        f"Bifurcation Diagram — {param_name}",
        fontsize=15, fontweight="bold"
    )
    ax.grid(True, alpha=0.3)

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def plot_stability_region(
    alpha_range: np.ndarray = None,
    beta_range: np.ndarray = None,
    eta: float = 0.1,
    gamma: float = 0.0,
    n_models: int = 2,
    figsize: Tuple[int, int] = (10, 8),
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Plot the stability region in (alpha, beta) space.

    Parameters
    ----------
    alpha_range, beta_range : np.ndarray
    eta, gamma : float
    n_models : int
    figsize : Tuple[int, int]
    save_path : Optional[str]

    Returns
    -------
    plt.Figure
    """
    from llm_eco_sim.theory.equilibria import stability_analysis

    if alpha_range is None:
        alpha_range = np.linspace(0, 1, 100)
    if beta_range is None:
        beta_range = np.linspace(0, 0.5, 100)

    stability_map = np.zeros((len(alpha_range), len(beta_range)))
    spectral_map = np.zeros((len(alpha_range), len(beta_range)))

    for i, alpha in enumerate(alpha_range):
        for j, beta in enumerate(beta_range):
            result = stability_analysis(alpha, eta, beta, gamma, n_models)
            stability_map[i, j] = 1.0 if result["is_stable"] else 0.0
            spectral_map[i, j] = result["spectral_radius"]

    fig, axes = plt.subplots(1, 2, figsize=figsize)

    # Stability region
    ax = axes[0]
    ax.imshow(
        stability_map.T, origin="lower",
        extent=[alpha_range[0], alpha_range[-1], beta_range[0], beta_range[-1]],
        aspect="auto", cmap="RdYlGn", interpolation="nearest",
    )
    ax.set_xlabel("Contamination Rate (α)", fontsize=12)
    ax.set_ylabel("Benchmark Pressure (β)", fontsize=12)
    ax.set_title("Stability Region", fontsize=13, fontweight="bold")

    # Spectral radius
    ax = axes[1]
    im = ax.imshow(
        spectral_map.T, origin="lower",
        extent=[alpha_range[0], alpha_range[-1], beta_range[0], beta_range[-1]],
        aspect="auto", cmap="hot_r", interpolation="bilinear",
    )
    fig.colorbar(im, ax=ax, label="Spectral Radius")
    ax.contour(
        alpha_range, beta_range, spectral_map.T,
        levels=[1.0], colors="white", linewidths=2
    )
    ax.set_xlabel("Contamination Rate (α)", fontsize=12)
    ax.set_ylabel("Benchmark Pressure (β)", fontsize=12)
    ax.set_title("Spectral Radius", fontsize=13, fontweight="bold")

    fig.suptitle(
        f"Stability Analysis (η={eta}, γ={gamma}, N={n_models})",
        fontsize=14, fontweight="bold"
    )
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig
