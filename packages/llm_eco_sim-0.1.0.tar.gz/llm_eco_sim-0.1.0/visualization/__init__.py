"""Visualization modules for llm_eco_sim."""

from llm_eco_sim.visualization.trajectories import (
    plot_diversity_trajectory,
    plot_performance_trajectories,
    plot_brg_trajectory,
    plot_model_trajectories_2d,
    plot_contamination_trajectory,
    plot_ecosystem_dashboard,
    compare_results,
)
from llm_eco_sim.visualization.phase_diagrams import (
    plot_phase_diagram,
    plot_phase_transition,
    plot_bifurcation_diagram,
    plot_stability_region,
)
from llm_eco_sim.visualization.dashboards import (
    create_scenario_comparison_dashboard,
    create_parameter_sweep_dashboard,
    generate_paper_figures,
)

__all__: list[str] = [
    "plot_diversity_trajectory", "plot_performance_trajectories",
    "plot_brg_trajectory", "plot_model_trajectories_2d",
    "plot_contamination_trajectory", "plot_ecosystem_dashboard",
    "compare_results",
    "plot_phase_diagram", "plot_phase_transition",
    "plot_bifurcation_diagram", "plot_stability_region",
    "create_scenario_comparison_dashboard", "create_parameter_sweep_dashboard",
    "generate_paper_figures",
]
