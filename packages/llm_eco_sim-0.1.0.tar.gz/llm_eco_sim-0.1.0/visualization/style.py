"""
Unified figure style for llm-eco-sim publication-quality figures.

Provides consistent colors, fonts, and layout settings across all figures.
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl


# — Color Palette —
# Primary: blue family for simulation data
# Secondary: red/orange for analytical predictions and warnings
# Tertiary: green for interventions and positive outcomes

COLORS: dict[str, str] = {
    # Main palette
    'primary': '#1565c0',      # deep blue
    'secondary': '#c62828',    # deep red
    'tertiary': '#2e7d32',     # deep green
    'quaternary': '#e65100',   # deep orange
    'quinary': '#6a1b9a',      # deep purple

    # Contamination gradient (blue → red for α=0 → α=1)
    'alpha_0': '#1a237e',      # dark navy
    'alpha_low': '#1565c0',    # blue
    'alpha_mid': '#f9a825',    # amber
    'alpha_high': '#e65100',   # orange
    'alpha_1': '#b71c1c',      # dark red

    # Scenario colors
    'status_quo': '#455a64',   # blue-grey
    'increasing': '#c62828',   # red
    'filtering': '#1565c0',    # blue
    'mandate': '#2e7d32',      # green
    'combined': '#6a1b9a',     # purple

    # N-model colors
    'n2': '#1565c0',
    'n5': '#2e7d32',
    'n10': '#f57f17',
    'n20': '#c62828',

    # Utility
    'grid': '#e0e0e0',
    'annotation': '#616161',
    'threshold': '#9e9e9e',
}

# Sequential colormap for α sweeps
ALPHA_CMAP = plt.cm.RdYlBu_r


def apply_style() -> None:
    """Apply the llm-eco-sim publication style to matplotlib."""
    plt.style.use('default')

    mpl.rcParams.update({
        # Font
        'font.family': 'sans-serif',
        'font.sans-serif': ['DejaVu Sans', 'Helvetica', 'Arial'],
        'font.size': 11,

        # Axes
        'axes.titlesize': 13,
        'axes.titleweight': 'bold',
        'axes.labelsize': 12,
        'axes.linewidth': 0.8,
        'axes.grid': True,
        'axes.grid.which': 'major',

        # Grid
        'grid.alpha': 0.3,
        'grid.linewidth': 0.5,

        # Ticks
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'xtick.direction': 'out',
        'ytick.direction': 'out',

        # Legend
        'legend.fontsize': 10,
        'legend.framealpha': 0.9,
        'legend.edgecolor': '#cccccc',

        # Figure
        'figure.dpi': 150,
        'figure.facecolor': 'white',
        'savefig.dpi': 150,
        'savefig.bbox': 'tight',
        'savefig.facecolor': 'white',

        # Lines
        'lines.linewidth': 2,
        'lines.markersize': 6,
    })


def get_alpha_color(alpha, n_levels=5):
    """Get color for a given contamination rate α."""
    return ALPHA_CMAP(alpha)


def get_scenario_colors() -> dict[str, str]:
    """Get the standard scenario color mapping."""
    return {
        'Status quo': COLORS['status_quo'],
        'Increasing contamination': COLORS['increasing'],
        'Data filtering': COLORS['filtering'],
        'Diversity mandate': COLORS['mandate'],
        'Combined intervention': COLORS['combined'],
    }


def add_panel_label(ax, label, x=-0.12, y=1.05) -> None:
    """Add a panel label (A, B, C, ...) to an axes."""
    ax.text(x, y, label, transform=ax.transAxes,
            fontsize=15, fontweight='bold', va='bottom', ha='left')
