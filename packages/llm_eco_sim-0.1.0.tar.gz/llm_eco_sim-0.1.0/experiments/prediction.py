"""
prediction.py — Comprehensive prediction experiment for AI ecosystem futures.

This module runs the calibrated llm-eco-sim model forward to generate quantitative
predictions about AI ecosystem diversity under different policy scenarios.

Uses the variance-compression dynamics: η_eff(α) = η(1+κα).
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import json
from typing import Dict, List

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.core.heterogeneous import HeterogeneousEcosystem, HeterogeneousModelAgent
from llm_eco_sim.theory.formal_proofs import compute_diversity_curve


# ===================================================================
# CALIBRATED PARAMETERS (from calibration.py)
# ===================================================================

CALIBRATED: dict[str, float | int] = {
    'alpha': 0.565,         # calibrated effective contamination rate (from Hivemind data)
    'eta': 0.05,            # learning rate
    'beta': 0.02,           # benchmark pressure
    'kappa': 3.0,           # variance coupling
    'sigma': 0.12,          # specialization strength
    'noise_std': 0.005,     # training noise
    'steps_per_year': 50,   # simulation-to-real time mapping
    'n_models': 10,         # major LLM providers
    'dim': 20,              # capability dimensions
}


def run_heterogeneous_prediction(
    prediction_years: int = 5,
    seed: int = 42,
) -> Dict:
    """
    Run predictions using the heterogeneous ecosystem model.

    Models 10 LLM providers with realistic heterogeneity:
    - 2 frontier labs (high compute, generalist)
    - 3 mid-tier labs (medium compute, generalist)
    - 3 specialist labs (low compute, specialist)
    - 2 open-source projects (low compute, generalist)
    """
    total_steps: int = CALIBRATED['steps_per_year'] * prediction_years
    dim: int = CALIBRATED['dim']

    model_configs: list[dict[str, float | str]] = [
        # Frontier labs
        {'name': 'Frontier_A', 'learning_rate': 0.08, 'benchmark_pressure': 0.05,
         'noise_std': 0.002, 'specialization_strength': 0.06,
         'compute_budget': 5.0, 'market_share': 0.25, 'strategy': 'generalist'},
        {'name': 'Frontier_B', 'learning_rate': 0.07, 'benchmark_pressure': 0.04,
         'noise_std': 0.003, 'specialization_strength': 0.08,
         'compute_budget': 4.0, 'market_share': 0.20, 'strategy': 'generalist'},
        # Mid-tier labs
        {'name': 'MidTier_A', 'learning_rate': 0.05, 'benchmark_pressure': 0.03,
         'noise_std': 0.005, 'specialization_strength': 0.12,
         'compute_budget': 1.5, 'market_share': 0.12, 'strategy': 'generalist'},
        {'name': 'MidTier_B', 'learning_rate': 0.05, 'benchmark_pressure': 0.03,
         'noise_std': 0.005, 'specialization_strength': 0.12,
         'compute_budget': 1.0, 'market_share': 0.10, 'strategy': 'generalist'},
        {'name': 'MidTier_C', 'learning_rate': 0.04, 'benchmark_pressure': 0.02,
         'noise_std': 0.006, 'specialization_strength': 0.14,
         'compute_budget': 0.8, 'market_share': 0.08, 'strategy': 'generalist'},
        # Specialist labs
        {'name': 'Specialist_Code', 'learning_rate': 0.03, 'benchmark_pressure': 0.01,
         'noise_std': 0.008, 'specialization_strength': 0.25,
         'compute_budget': 0.5, 'market_share': 0.06, 'strategy': 'specialist'},
        {'name': 'Specialist_Science', 'learning_rate': 0.03, 'benchmark_pressure': 0.01,
         'noise_std': 0.008, 'specialization_strength': 0.25,
         'compute_budget': 0.4, 'market_share': 0.05, 'strategy': 'specialist'},
        {'name': 'Specialist_Creative', 'learning_rate': 0.03, 'benchmark_pressure': 0.01,
         'noise_std': 0.008, 'specialization_strength': 0.25,
         'compute_budget': 0.3, 'market_share': 0.04, 'strategy': 'specialist'},
        # Open-source projects
        {'name': 'OpenSource_A', 'learning_rate': 0.04, 'benchmark_pressure': 0.02,
         'noise_std': 0.010, 'specialization_strength': 0.10,
         'compute_budget': 0.3, 'market_share': 0.06, 'strategy': 'generalist'},
        {'name': 'OpenSource_B', 'learning_rate': 0.03, 'benchmark_pressure': 0.02,
         'noise_std': 0.012, 'specialization_strength': 0.10,
         'compute_budget': 0.2, 'market_share': 0.04, 'strategy': 'generalist'},
    ]

    results: dict = {}
    scenarios: dict[str, dict[str, float | str]] = {
        'status_quo': {
            'alpha': CALIBRATED['alpha'],
            'market_dynamics': 'proportional',
            'description': f'Current trajectory (α={CALIBRATED["alpha"]})',
        },
        'increasing_contamination': {
            'alpha': CALIBRATED['alpha'],
            'market_dynamics': 'proportional',
            'description': 'Increasing synthetic data (α→0.90)',
        },
        'data_filtering': {
            'alpha': CALIBRATED['alpha'] * 0.5,
            'market_dynamics': 'proportional',
            'description': 'Data provenance filtering (α halved)',
        },
        'diversity_mandate': {
            'alpha': CALIBRATED['alpha'],
            'market_dynamics': 'fixed',
            'description': 'Diversity mandate (2x specialization)',
        },
        'combined_intervention': {
            'alpha': CALIBRATED['alpha'] * 0.5,
            'market_dynamics': 'fixed',
            'description': 'Combined: filtering + mandate',
        },
    }

    for scenario_name, config in scenarios.items():
        print(f"  Running {scenario_name}...")

        configs: list[dict[str, float | str]] = [c.copy() for c in model_configs]
        if 'mandate' in scenario_name or 'combined' in scenario_name:
            for c in configs:
                c['specialization_strength'] = c.get('specialization_strength', 0.12) * 2.0

        eco: HeterogeneousEcosystem = HeterogeneousEcosystem.create_heterogeneous(
            model_configs=configs,
            dim=dim,
            contamination_rate=config['alpha'],
            market_dynamics=config['market_dynamics'],
            market_sensitivity=2.0,
            asymmetric_contamination=True,
            seed=seed,
        )

        if scenario_name == 'increasing_contamination':
            alpha_traj = np.linspace(CALIBRATED['alpha'], 0.90, total_steps)
            for t in range(total_steps):
                eco.data_pool.contamination_rate = alpha_traj[t]
                eco.step()
        else:
            eco.run(total_steps)

        div_traj = eco.get_diversity_trajectory()
        market_shares: dict = eco.get_market_share_trajectories()

        results[scenario_name] = {
            'diversity': div_traj,
            'market_shares': market_shares,
            'gini': eco.get_gini_coefficient(),
            'hhi': eco.get_herfindahl_index(),
            'description': config['description'],
            'final_ratio': div_traj[-1] / div_traj[0] if div_traj[0] > 0 else 0,
        }

    return results


def plot_prediction_figure(
    results: Dict,
    save_dir: str = 'results/prediction',
) -> None:
    """Generate the main prediction figure (Figure 5 of the paper)."""
    os.makedirs(save_dir, exist_ok=True)

    fig = plt.figure(figsize=(16, 12))
    gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.3)

    spy: int = CALIBRATED['steps_per_year']
    colors: dict[str, str] = {
        'status_quo': '#F44336',
        'increasing_contamination': '#FF9800',
        'data_filtering': '#4CAF50',
        'diversity_mandate': '#2196F3',
        'combined_intervention': '#9C27B0',
    }
    labels: dict[str, str] = {
        'status_quo': 'Status quo',
        'increasing_contamination': 'Increasing contamination',
        'data_filtering': 'Data filtering',
        'diversity_mandate': 'Diversity mandate',
        'combined_intervention': 'Combined intervention',
    }

    # Panel A: Diversity trajectories
    ax1 = fig.add_subplot(gs[0, 0])
    for scenario, data in results.items():
        div = np.array(data['diversity'])
        t_years = np.arange(len(div)) / spy
        div_ratio = div / div[0] if div[0] > 0 else div
        ax1.plot(t_years, div_ratio, color=colors[scenario], linewidth=2,
                 label=labels[scenario])

    ax1.set_xlabel('Time (years from 2025)', fontsize=11)
    ax1.set_ylabel('Diversity ratio $D(t)/D(0)$', fontsize=11)
    ax1.set_title('A. Predicted AI Ecosystem Diversity (2025\u20132030)',
                  fontsize=12, fontweight='bold')
    ax1.legend(fontsize=8, loc='upper right')
    ax1.set_xlim(0, 5)
    ax1.set_ylim(0, 1.0)
    ax1.grid(True, alpha=0.3)
    for y in range(1, 6):
        ax1.axvline(y, color='gray', linestyle=':', alpha=0.2)

    # Panel B: Final diversity bar chart
    ax2 = fig.add_subplot(gs[0, 1])
    scenario_order: list[str] = ['increasing_contamination', 'status_quo', 'data_filtering',
                                  'diversity_mandate', 'combined_intervention']
    final_ratios: list = [results[s]['final_ratio'] for s in scenario_order]
    bar_colors: list[str] = [colors[s] for s in scenario_order]
    bar_labels: list[str] = [labels[s] for s in scenario_order]

    bars = ax2.barh(range(len(bar_labels)), final_ratios, color=bar_colors,
                    edgecolor='black', linewidth=0.5, height=0.6)
    for i, (bar, val) in enumerate(zip(bars, final_ratios)):
        pct = val * 100
        ax2.text(val + 0.01, bar.get_y() + bar.get_height() / 2,
                 f'{pct:.1f}%', va='center', fontsize=10, fontweight='bold')

    ax2.set_yticks(range(len(bar_labels)))
    ax2.set_yticklabels(bar_labels, fontsize=9)
    ax2.set_xlabel('Diversity preserved at Year 5 (%)', fontsize=11)
    ax2.set_title('B. Intervention Effectiveness', fontsize=12, fontweight='bold')
    ax2.set_xlim(0, max(final_ratios) * 1.4 if final_ratios else 1)
    ax2.grid(True, alpha=0.3, axis='x')

    # Panel C: Per-model capability spread (more informative than Gini)
    ax3 = fig.add_subplot(gs[1, 0])

    # Show how individual model distances from centroid evolve for status_quo vs combined
    for scenario_name in ['status_quo', 'combined_intervention']:
        data = results[scenario_name]
        div = np.array(data['diversity'])
        t_years = np.arange(len(div)) / spy
        # Normalize diversity to show relative change
        div_norm = div / div[0] if div[0] > 0 else div
        ax3.plot(t_years, div_norm, color=colors[scenario_name], linewidth=2.5,
                 label=labels[scenario_name])

    # Add the analytical prediction as dashed line
    curve: dict = compute_diversity_curve(
        eta=CALIBRATED['eta'], beta=CALIBRATED['beta'],
        kappa=CALIBRATED['kappa'], sigma=CALIBRATED['sigma'],
        dim=CALIBRATED['dim'], noise_std=CALIBRATED['noise_std'],
    )
    # The analytical equilibrium ratio at calibrated α
    # NOTE: This is D_eq(α)/D_eq(0), but simulation shows D(t)/D(0)
    # The simulation normalizes by initial diversity, not equilibrium at α=0
    # So the analytical line will be higher than simulation curves
    idx = np.argmin(np.abs(curve['alpha_range'] - CALIBRATED['alpha']))
    eq_ratio = curve['D_ratio'][idx]
    ax3.axhline(eq_ratio, color='gray', linestyle='--', alpha=0.7,
                label=f'Analytical equilibrium ({eq_ratio:.2f})')

    ax3.set_xlabel('Time (years from 2025)', fontsize=11)
    ax3.set_ylabel('Diversity ratio $D(t)/D(0)$', fontsize=11)
    ax3.set_title('C. Status Quo vs Best Intervention', fontsize=12, fontweight='bold')
    ax3.legend(fontsize=9, loc='upper right')
    ax3.set_xlim(0, 5)
    ax3.set_ylim(0, 1.0)
    ax3.grid(True, alpha=0.3)

    # Panel D: Headline result summary
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.axis('off')

    sq = results['status_quo']['final_ratio']
    inc = results['increasing_contamination']['final_ratio']
    df = results['data_filtering']['final_ratio']
    dm = results['diversity_mandate']['final_ratio']
    ci = results['combined_intervention']['final_ratio']

    improvement_filter = (df - sq) / sq * 100 if sq > 0 else 0
    improvement_mandate = (dm - sq) / sq * 100 if sq > 0 else 0
    improvement_combined = (ci - sq) / sq * 100 if sq > 0 else 0
    mandate_vs_filter = dm / df if df > 0 else 0

    text: str = (
        "KEY PREDICTIONS\n"
        "\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\n\n"
        f"Without intervention, the AI ecosystem\n"
        f"will retain only {sq*100:.0f}% of its diversity\n"
        f"by 2030.\n\n"
        f"If synthetic data increases to 90%,\n"
        f"diversity erodes to {inc*100:.1f}%.\n\n"
        "INTERVENTION EFFECTIVENESS\n"
        "\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\n\n"
        f"Data filtering:     +{improvement_filter:.0f}% vs status quo\n"
        f"Diversity mandate:  +{improvement_mandate:.0f}% vs status quo\n"
        f"Combined:           +{improvement_combined:.0f}% vs status quo\n\n"
        f"Mandate preserves {mandate_vs_filter:.1f}x more diversity\n"
        f"than filtering alone.\n\n"
        "\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\n\n"
        "Calibrated against:\n"
        "  Artificial Hivemind (NeurIPS 2025)\n"
        "  Stanford AI Index 2025\n"
        f"  alpha_calibrated = {CALIBRATED['alpha']:.2f}\n\n"
        "CAVEATS: Predictions depend on\n"
        "calibration assumptions. See paper\n"
        "for full uncertainty analysis."
    )
    ax4.text(0.05, 0.95, text, transform=ax4.transAxes,
             fontsize=10, fontfamily='monospace',
             verticalalignment='top',
             bbox=dict(boxstyle='round,pad=0.5', facecolor='lightyellow',
                       edgecolor='gray', alpha=0.8))
    ax4.set_title('D. Summary', fontsize=12, fontweight='bold')

    plt.savefig(os.path.join(save_dir, 'prediction_figure.png'),
                dpi=200, bbox_inches='tight')
    plt.close()
    print(f"Saved prediction figure to {save_dir}/prediction_figure.png")


def run_prediction_experiment(save_dir: str = 'results/prediction') -> dict:
    """Run the full prediction experiment."""
    os.makedirs(save_dir, exist_ok=True)

    print("=" * 60)
    print("LLM-ECO-SIM PREDICTION EXPERIMENT")
    print("Heterogeneous AI Ecosystem, 5-Year Horizon")
    print("=" * 60)
    print()

    print("Running heterogeneous ecosystem predictions...")
    results = run_heterogeneous_prediction(prediction_years=5, seed=42)
    print()

    print("Generating figures...")
    plot_prediction_figure(results, save_dir=save_dir)

    # Save numerical results
    summary: dict = {}
    for scenario, data in results.items():
        summary[scenario] = {
            'description': data['description'],
            'final_diversity_ratio': float(data['final_ratio']),
            'gini': float(data['gini']),
            'hhi': float(data['hhi']),
        }

    with open(os.path.join(save_dir, 'prediction_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    print()
    print("=" * 60)
    sq = results['status_quo']['final_ratio']
    dm = results['diversity_mandate']['final_ratio']
    ci = results['combined_intervention']['final_ratio']
    df = results['data_filtering']['final_ratio']
    print(f"  Status quo (2030):  {sq*100:.1f}% diversity retained")
    print(f"  Data filtering:     {df*100:.1f}% diversity retained")
    print(f"  Diversity mandate:  {dm*100:.1f}% diversity retained")
    print(f"  Combined:           {ci*100:.1f}% diversity retained")
    print("=" * 60)

    return results


if __name__ == '__main__':
    run_prediction_experiment()
