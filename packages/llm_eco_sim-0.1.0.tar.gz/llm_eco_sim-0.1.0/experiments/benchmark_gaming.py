"""
benchmark_gaming.py - Reproduce Theorem 2: Benchmark Overfitting.

Theorem 2 (Benchmark Overfitting):
When γ > 0 and the spectral radius ρ > 1 (i.e., β exceeds a critical
threshold β* that depends on γ, η, κ, σ, α), the ecosystem converges to
a state where:
    ||c_bar(inf) - b(inf)|| < epsilon  (models match benchmark)
    ||c_bar(inf) - mu_natural|| > delta  (models diverge from reality)
for arbitrarily small epsilon and some delta > 0.

This experiment:
1. Shows that adaptive benchmarks + high benchmark pressure leads to
   models chasing the benchmark away from reality
2. Demonstrates the benchmark-reality gap grows over time
3. Compares static vs adaptive benchmark scenarios
4. Shows the paradox: benchmark scores improve while real-world performance degrades
"""

import numpy as np
import matplotlib.pyplot as plt
import os

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.simulation.simulator import Simulator, SimulationConfig
from llm_eco_sim.theory.phase_transitions import scan_benchmark_pressure


def run_benchmark_gaming_experiment(
    n_steps: int = 400,
    n_models: int = 3,
    dim: int = 5,
    alpha: float = 0.3,
    eta: float = 0.05,
    seed: int = 42,
    output_dir: str = "./results/benchmark_gaming",
    verbose: bool = True,
) -> dict:
    """
    Run the complete benchmark gaming experiment.

    Parameters
    ----------
    n_steps : int
        Simulation steps.
    n_models : int
        Number of models.
    dim : int
        Capability dimensionality.
    alpha : float
        Contamination rate.
    eta : float
        Learning rate.
    seed : int
        Random seed.
    output_dir : str
        Output directory.
    verbose : bool
        Print progress.

    Returns
    -------
    dict
        Experiment results.
    """
    os.makedirs(output_dir, exist_ok=True)

    if verbose:
        print("=" * 60)
        print("EXPERIMENT: Benchmark Gaming (Theorem 2)")
        print("=" * 60)

    # ---- Part 1: Static vs Adaptive Benchmark ----
    if verbose:
        print("\n[1/4] Comparing static vs adaptive benchmarks...")

    scenarios = {
        "static_low_pressure": {"gamma": 0.0, "beta": 0.05},
        "static_high_pressure": {"gamma": 0.0, "beta": 0.2},
        "adaptive_low_pressure": {"gamma": 0.08, "beta": 0.05},
        "adaptive_high_pressure": {"gamma": 0.08, "beta": 0.2},
    }

    scenario_results = {}
    for name, params in scenarios.items():
        eco = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=alpha,
            learning_rate=eta,
            benchmark_pressure=params["beta"],
            benchmark_adaptation_rate=params["gamma"],
            seed=seed,
        )
        eco.run(n_steps)
        scenario_results[name] = {
            "diversity": eco.get_diversity_trajectory(),
            "benchmark_score": eco.get_benchmark_score_trajectory(),
            "real_world": eco.get_real_world_performance_trajectory(),
            "brg": eco.get_brg_trajectory(),
            "benchmark_target_norm": np.linalg.norm(eco.benchmark.history, axis=1),
        }

        if verbose:
            final_brg = eco.get_brg_trajectory()[-1]
            final_bench = eco.get_benchmark_score_trajectory()[-1]
            final_rw = eco.get_real_world_performance_trajectory()[-1]
            print(f"  {name}: BRG={final_brg:.4f}, Bench={final_bench:.4f}, RW={final_rw:.4f}")

    # ---- Part 2: Beta scan with adaptive benchmark ----
    if verbose:
        print("\n[2/4] Scanning benchmark pressure with adaptive benchmark...")

    beta_range = np.linspace(0, 0.5, 40)
    scan_result = scan_benchmark_pressure(
        beta_range=beta_range,
        n_steps=n_steps,
        n_models=n_models,
        dim=dim,
        alpha=alpha,
        eta=eta,
        gamma=0.08,
        seed=seed,
    )

    if verbose:
        print(f"  Critical beta (overfitting onset): {scan_result.critical_value}")

    # ---- Part 3: Detailed time evolution of the gaming scenario ----
    if verbose:
        print("\n[3/4] Running detailed gaming scenario...")

    eco_gaming = Ecosystem.create_default(
        n_models=n_models, dim=dim,
        contamination_rate=alpha,
        learning_rate=eta,
        benchmark_pressure=0.15,
        benchmark_adaptation_rate=0.08,
        seed=seed,
    )
    eco_gaming.run(n_steps)

    gaming_data = {
        "diversity": eco_gaming.get_diversity_trajectory(),
        "benchmark_score": eco_gaming.get_benchmark_score_trajectory(),
        "real_world": eco_gaming.get_real_world_performance_trajectory(),
        "brg": eco_gaming.get_brg_trajectory(),
        "benchmark_norm": np.linalg.norm(eco_gaming.benchmark.history, axis=1),
    }

    # ---- Part 4: Generate figures ----
    if verbose:
        print("\n[4/4] Generating figures...")

    fig, axes = plt.subplots(2, 3, figsize=(20, 12))

    # A: Benchmark score vs real-world performance (the paradox)
    ax = axes[0, 0]
    t = np.arange(n_steps + 1)
    ax.plot(t, gaming_data["benchmark_score"], color="#4CAF50", linewidth=2,
            label="Benchmark Score")
    ax.plot(t, -gaming_data["real_world"], color="#F44336", linewidth=2,
            label="Distance to Reality")
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Score / Distance", fontsize=12)
    ax.set_title("The Benchmark Gaming Paradox", fontsize=13, fontweight="bold")
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)

    # B: BRG over time
    ax = axes[0, 1]
    ax.plot(t, gaming_data["brg"], color="#FF9800", linewidth=2)
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.fill_between(t, 0, gaming_data["brg"],
                    where=gaming_data["brg"] > 0, alpha=0.2, color="#FF9800")
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("Benchmark-Reality Gap", fontsize=12)
    ax.set_title("Benchmark-Reality Gap Growth", fontsize=13, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # C: Benchmark target drift
    ax = axes[0, 2]
    ax.plot(t, gaming_data["benchmark_norm"], color="#9C27B0", linewidth=2)
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("||b(t)||", fontsize=12)
    ax.set_title("Benchmark Target Drift", fontsize=13, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # D: Scenario comparison - BRG
    ax = axes[1, 0]
    for name, data in scenario_results.items():
        ax.plot(t, data["brg"], linewidth=1.5, label=name.replace("_", " "))
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.set_xlabel("Time Step", fontsize=12)
    ax.set_ylabel("BRG", fontsize=12)
    ax.set_title("BRG Across Scenarios", fontsize=13, fontweight="bold")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # E: Beta scan - final metrics
    ax = axes[1, 1]
    ax.plot(beta_range, scan_result.benchmark_scores, color="#4CAF50",
            linewidth=2, label="Benchmark Score")
    ax.plot(beta_range, -scan_result.real_world_performance, color="#F44336",
            linewidth=2, label="Distance to Reality")
    if scan_result.critical_value is not None:
        ax.axvline(x=scan_result.critical_value, color="red", linestyle="--",
                   alpha=0.7, label=f"β* = {scan_result.critical_value:.3f}")
    ax.set_xlabel("Benchmark Pressure (β)", fontsize=12)
    ax.set_ylabel("Final Metric", fontsize=12)
    ax.set_title("Effect of Benchmark Pressure", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # F: Beta scan - BRG
    ax = axes[1, 2]
    ax.plot(beta_range, scan_result.brg_values, "o-", color="#FF9800",
            linewidth=2, markersize=3)
    ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
    ax.fill_between(beta_range, 0, scan_result.brg_values,
                    where=scan_result.brg_values > 0, alpha=0.2, color="#FF9800")
    if scan_result.critical_value is not None:
        ax.axvline(x=scan_result.critical_value, color="red", linestyle="--", alpha=0.7)
    ax.set_xlabel("Benchmark Pressure (β)", fontsize=12)
    ax.set_ylabel("Final BRG", fontsize=12)
    ax.set_title("Overfitting Transition", fontsize=13, fontweight="bold")
    ax.grid(True, alpha=0.3)

    fig.suptitle(
        "Theorem 2: Benchmark Overfitting Under Adaptive Benchmarks",
        fontsize=16, fontweight="bold", y=1.02
    )
    fig.tight_layout()
    fig_path = os.path.join(output_dir, "benchmark_gaming.png")
    fig.savefig(fig_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    if verbose:
        print(f"  Saved: {fig_path}")

    # ---- Compile results ----
    results = {
        "theorem": "Benchmark Overfitting (Theorem 2)",
        "parameters": {
            "n_models": n_models, "dim": dim, "alpha": alpha, "eta": eta,
            "n_steps": n_steps, "seed": seed,
        },
        "critical_beta": scan_result.critical_value,
        "scenario_final_brg": {
            name: float(data["brg"][-1]) for name, data in scenario_results.items()
        },
        "figure_path": fig_path,
        "conclusion": (
            f"Benchmark gaming confirmed. With adaptive benchmarks (gamma=0.08) "
            f"and high benchmark pressure (beta=0.15), models achieve high benchmark "
            f"scores while diverging from the natural data distribution. "
            f"Critical beta for overfitting onset: {scan_result.critical_value}. "
            f"This demonstrates that benchmark optimization can be counterproductive "
            f"in a multi-model ecosystem."
        ),
    }

    if verbose:
        print(f"\n{'=' * 60}")
        print(f"CONCLUSION: {results['conclusion']}")
        print(f"{'=' * 60}")

    return results


if __name__ == "__main__":
    results = run_benchmark_gaming_experiment(verbose=True)
