"""
diversity_erosion.py - Reproduce Theorem 1: Diversity Erosion.

Theorem 1 (Diversity Erosion via Variance Compression):
Contaminated data has lower variance, causing SGD to converge faster.
The effective learning rate η_eff(α) = η(1+κα) increases with α,
causing the diversity mode eigenvalue λ_diff(α) = 1 - η_eff(α) - β - σ
to shrink, reducing equilibrium diversity.

This experiment:
1. Scans α from 0 to 1 and measures equilibrium diversity
2. Overlays the exact analytical prediction
3. Shows time evolution at different α values
4. Generates publication-quality figures
"""

import numpy as np
import matplotlib.pyplot as plt
import os

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.theory.formal_proofs import compute_diversity_curve
from llm_eco_sim.theory.equilibria import compute_diversity_erosion_threshold


def run_diversity_erosion_experiment(
    n_alpha: int = 50,
    n_steps: int = 500,
    n_models: int = 5,
    dim: int = 10,
    eta: float = 0.05,
    beta: float = 0.02,
    sigma: float = 0.12,
    kappa: float = 3.0,
    noise_std: float = 0.005,
    seed: int = 42,
    output_dir: str = "./results/diversity_erosion",
    verbose: bool = True,
) -> dict:
    """Run the complete diversity erosion experiment."""
    os.makedirs(output_dir, exist_ok=True)

    if verbose:
        print("=" * 60)
        print("EXPERIMENT: Diversity Erosion (Theorem 1)")
        print("=" * 60)

    # ---- Part 1: Alpha scan (simulation) ----
    if verbose:
        print("\n[1/4] Scanning contamination rate alpha...")

    alpha_range = np.linspace(0, 1, n_alpha)
    final_diversities = []

    for alpha in alpha_range:
        eco = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=alpha,
            learning_rate=eta,
            benchmark_pressure=beta,
            specialization_strength=sigma,
            noise_std=noise_std,
            variance_coupling=kappa,
            seed=seed,
        )
        eco.run(n_steps)
        final_diversities.append(eco.current_state.diversity_index)

    final_diversities = np.array(final_diversities)
    baseline_div = final_diversities[0]

    # Find critical alpha (50% reduction from baseline)
    if baseline_div > 0:
        ratios = final_diversities / baseline_div
        idx_50 = np.where(ratios < 0.5)[0]
        alpha_star_sim = float(alpha_range[idx_50[0]]) if len(idx_50) > 0 else None
        idx_10 = np.where(ratios < 0.1)[0]
        alpha_90_sim = float(alpha_range[idx_10[0]]) if len(idx_10) > 0 else None
    else:
        alpha_star_sim = 0.0
        alpha_90_sim = 0.0

    if verbose:
        print(f"  Baseline diversity (α=0): {baseline_div:.4f}")
        print(f"  Critical α (50% erosion): {alpha_star_sim}")
        print(f"  α for 90% erosion: {alpha_90_sim}")

    # ---- Part 2: Analytical prediction ----
    if verbose:
        print("\n[2/4] Computing analytical prediction...")

    curve = compute_diversity_curve(
        eta=eta, beta=beta, kappa=kappa, sigma=sigma,
        dim=dim, noise_std=noise_std,
    )
    alpha_star_analytical = compute_diversity_erosion_threshold(
        eta, beta, n_models, kappa=kappa, sigma=sigma
    )

    if verbose:
        print(f"  Critical α (analytical, 50%): {alpha_star_analytical:.4f}")
        print(f"  Analytical ratio at α=1: {curve['D_ratio'][-1]:.4f}")
        print(f"  Simulation ratio at α=1: {ratios[-1]:.4f}")

    # ---- Part 3: Time evolution at different alpha values ----
    if verbose:
        print("\n[3/4] Running detailed time evolution...")

    alpha_examples = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    time_evolutions = {}

    for alpha in alpha_examples:
        eco = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=alpha,
            learning_rate=eta,
            benchmark_pressure=beta,
            specialization_strength=sigma,
            noise_std=noise_std,
            variance_coupling=kappa,
            seed=seed,
        )
        eco.run(n_steps)
        time_evolutions[alpha] = eco.get_diversity_trajectory()

    # ---- Part 4: Generate figures ----
    if verbose:
        print("\n[4/4] Generating figures...")

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    # Panel A: Alpha vs equilibrium diversity with analytical overlay
    ax = axes[0]
    ax.plot(alpha_range, ratios, "o", color="#2196F3",
            markersize=4, alpha=0.7, label="Simulation")
    # Analytical curve
    ax.plot(curve['alpha_range'], curve['D_ratio'], "-", color="#F44336",
            linewidth=2.5, label="Analytical (exact)")
    if alpha_star_sim is not None:
        ax.axvline(x=alpha_star_sim, color="blue", linestyle="--",
                   linewidth=1.5, alpha=0.7, label=f"α* sim = {alpha_star_sim:.3f}")
    if alpha_star_analytical is not None:
        ax.axvline(x=alpha_star_analytical, color="red", linestyle=":",
                   linewidth=1.5, alpha=0.7, label=f"α* theory = {alpha_star_analytical:.3f}")
    ax.set_xlabel("Contamination Rate (α)", fontsize=13)
    ax.set_ylabel("$D_{eq}(α) / D_{eq}(0)$", fontsize=13)
    ax.set_title("A. Equilibrium Diversity vs Contamination", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.1)

    # Panel B: Time evolution at different alpha
    ax = axes[1]
    cmap_colors = plt.cm.RdYlGn_r(np.linspace(0.1, 0.9, len(alpha_examples)))
    for i, alpha in enumerate(alpha_examples):
        traj = time_evolutions[alpha]
        traj_norm = np.array(traj) / traj[0] if traj[0] > 0 else traj
        ax.plot(range(len(traj)), traj_norm, color=cmap_colors[i], linewidth=2,
                label=f"α={alpha:.1f}")
    ax.set_xlabel("Time Step", fontsize=13)
    ax.set_ylabel("$D(t) / D(0)$", fontsize=13)
    ax.set_title("B. Diversity Evolution Over Time", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9, ncol=2)
    ax.grid(True, alpha=0.3)
    ax.set_ylim(0, 1.1)

    # Panel C: Eigenvalue analysis
    ax = axes[2]
    alpha_fine = np.linspace(0, 1, 200)
    lambda_diff = [1.0 - eta * (1.0 + kappa * a) - beta - sigma for a in alpha_fine]
    ax.plot(alpha_fine, lambda_diff, 'b-', linewidth=2.5, label=r'$\lambda_{diff}(\alpha)$')
    ax.axhline(y=0, color='red', linestyle='--', alpha=0.5, label=r'$\lambda = 0$ (critical)')
    ax.fill_between(alpha_fine, lambda_diff, 0, where=[l > 0 for l in lambda_diff],
                    alpha=0.1, color='green', label='Stable (non-oscillatory)')
    ax.fill_between(alpha_fine, lambda_diff, 0, where=[l < 0 for l in lambda_diff],
                    alpha=0.1, color='red', label='Oscillatory decay')
    ax.set_xlabel("Contamination Rate (α)", fontsize=13)
    ax.set_ylabel(r"$\lambda_{diff}$", fontsize=13)
    ax.set_title("C. Diversity Mode Eigenvalue", fontsize=13, fontweight="bold")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 1)

    fig.suptitle(
        "Theorem 1: Diversity Erosion Under Data Contamination",
        fontsize=15, fontweight="bold", y=1.02
    )
    fig.tight_layout()
    fig_path = os.path.join(output_dir, "diversity_erosion.png")
    fig.savefig(fig_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    if verbose:
        print(f"  Saved: {fig_path}")

    # ---- Compile results ----
    results = {
        "theorem": "Diversity Erosion (Theorem 1)",
        "parameters": {
            "n_models": n_models, "dim": dim, "eta": eta, "beta": beta,
            "sigma": sigma, "kappa": kappa, "n_steps": n_steps, "seed": seed,
        },
        "baseline_diversity": float(baseline_div),
        "critical_alpha_simulation": alpha_star_sim,
        "critical_alpha_90pct": alpha_90_sim,
        "critical_alpha_analytical": alpha_star_analytical,
        "analytical_ratio_at_1": float(curve['D_ratio'][-1]),
        "simulation_ratio_at_1": float(ratios[-1]),
        "alpha_range": alpha_range.tolist(),
        "final_diversities": final_diversities.tolist(),
        "figure_path": fig_path,
        "conclusion": (
            f"Diversity erosion confirmed. "
            f"Analytical prediction matches simulation to within "
            f"{abs(curve['D_ratio'][-1] - ratios[-1])*100:.1f}pp at α=1. "
            f"50% erosion at α={alpha_star_sim}. "
            f"At α=1, diversity is {ratios[-1]*100:.1f}% of baseline."
        ),
    }

    if verbose:
        print(f"\n{'=' * 60}")
        print(f"CONCLUSION: {results['conclusion']}")
        print(f"{'=' * 60}")

    return results


if __name__ == "__main__":
    results = run_diversity_erosion_experiment(verbose=True)
