"""
Experiment 3: Competitive Externality (Theorem 3)

Demonstrates that when one model strengthens its niche specialization
in a contaminated data ecosystem, it creates negative externalities
for other models by biasing the shared data pool.

Key result: Individual model improvement is NOT Pareto-optimal.
The improved model gains significantly, but all other models degrade.
The externality scales with α (contamination rate) and is specific
to specialization-type improvements that persistently shift the data pool.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os

from llm_eco_sim.core.ecosystem import Ecosystem


def run_paradoxical_intervention_experiment(
    output_dir: str = None,
    verbose: bool = True,
) -> dict:
    """Run the competitive externality experiment."""
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'results', 'paradoxical_intervention')
    os.makedirs(output_dir, exist_ok=True)

    if verbose:
        print("=" * 60)
        print("EXPERIMENT: Competitive Externality (Theorem 3)")
        print("=" * 60)

    np.random.seed(42)

    n_steps = 200
    kappa = 5.0  # Higher than default κ=3.0 to amplify externality signal
    dim = 10

    # — Part 1: Externality vs contamination rate —
    if verbose:
        print("[1/4] Measuring externality vs contamination rate...")

    n_models = 5
    alphas = np.linspace(0.05, 0.95, 19)

    m0_improvements: list[float] = []
    others_degradations: list[float] = []
    externality_ratios: list[float] = []

    for alpha in alphas:
        eco_base: Ecosystem = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=alpha,
            learning_rate=0.05, benchmark_pressure=0.02,
            specialization_strength=0.12, noise_std=0.005,
            variance_coupling=kappa, seed=42,
        )
        eco_base.run(n_steps)

        eco_int: Ecosystem = Ecosystem.create_default(
            n_models=n_models, dim=dim,
            contamination_rate=alpha,
            learning_rate=0.05, benchmark_pressure=0.02,
            specialization_strength=0.12, noise_std=0.005,
            variance_coupling=kappa, seed=42,
        )
        eco_int.models[0].specialization_strength = 0.5
        eco_int.run(n_steps)

        m0_base_dist = np.linalg.norm(eco_base.models[0].capability - eco_base.models[0].specialization_target)
        m0_int_dist = np.linalg.norm(eco_int.models[0].capability - eco_int.models[0].specialization_target)
        m0_improve = m0_base_dist - m0_int_dist

        others_base = np.mean([np.linalg.norm(eco_base.models[i].capability - eco_base.models[i].specialization_target) for i in range(1, n_models)])
        others_int = np.mean([np.linalg.norm(eco_int.models[i].capability - eco_int.models[i].specialization_target) for i in range(1, n_models)])
        others_degrad = others_int - others_base

        m0_improvements.append(m0_improve)
        others_degradations.append(others_degrad)
        ratio = others_degrad * (n_models - 1) / m0_improve if m0_improve > 0 else 0
        externality_ratios.append(ratio)

    if verbose:
        max_degrad = max(others_degradations)
        max_ratio = max(externality_ratios)
        print(f"  Max per-model degradation: {max_degrad:.4f}")
        print(f"  Max externality ratio: {max_ratio:.3f}")

    # — Part 2: Externality vs ecosystem size —
    if verbose:
        print("[2/4] Measuring externality vs ecosystem size...")

    n_values: list[int] = [2, 3, 5, 8, 10, 15, 20]
    alpha_fixed = 0.7
    per_model_degrads: list[float] = []
    total_externalities: list[float] = []
    m0_imps_by_n: list[float] = []

    for n in n_values:
        eco_base: Ecosystem = Ecosystem.create_default(
            n_models=n, dim=dim,
            contamination_rate=alpha_fixed,
            learning_rate=0.05, benchmark_pressure=0.02,
            specialization_strength=0.12, noise_std=0.005,
            variance_coupling=kappa, seed=42,
        )
        eco_base.run(n_steps)

        eco_int: Ecosystem = Ecosystem.create_default(
            n_models=n, dim=dim,
            contamination_rate=alpha_fixed,
            learning_rate=0.05, benchmark_pressure=0.02,
            specialization_strength=0.12, noise_std=0.005,
            variance_coupling=kappa, seed=42,
        )
        eco_int.models[0].specialization_strength = 0.5
        eco_int.run(n_steps)

        m0_imp = np.linalg.norm(eco_base.models[0].capability - eco_base.models[0].specialization_target) - \
                 np.linalg.norm(eco_int.models[0].capability - eco_int.models[0].specialization_target)

        per_degrad = np.mean([
            np.linalg.norm(eco_int.models[i].capability - eco_int.models[i].specialization_target) -
            np.linalg.norm(eco_base.models[i].capability - eco_base.models[i].specialization_target)
            for i in range(1, n)
        ])

        per_model_degrads.append(per_degrad)
        total_externalities.append(per_degrad * (n - 1))
        m0_imps_by_n.append(m0_imp)

    # — Part 3: Time evolution of the externality —
    if verbose:
        print("[3/4] Running detailed trajectory comparison...")

    n_models_traj = 5
    alpha_traj = 0.7

    eco_base_traj: Ecosystem = Ecosystem.create_default(
        n_models=n_models_traj, dim=dim,
        contamination_rate=alpha_traj,
        learning_rate=0.05, benchmark_pressure=0.02,
        specialization_strength=0.12, noise_std=0.005,
        variance_coupling=kappa, seed=42,
    )

    eco_int_traj: Ecosystem = Ecosystem.create_default(
        n_models=n_models_traj, dim=dim,
        contamination_rate=alpha_traj,
        learning_rate=0.05, benchmark_pressure=0.02,
        specialization_strength=0.12, noise_std=0.005,
        variance_coupling=kappa, seed=42,
    )
    eco_int_traj.models[0].specialization_strength = 0.5

    m0_base_traj: list[float] = []
    m0_int_traj: list[float] = []
    others_base_traj: list[float] = []
    others_int_traj: list[float] = []

    for t in range(n_steps):
        m0_base_traj.append(np.linalg.norm(eco_base_traj.models[0].capability - eco_base_traj.models[0].specialization_target))
        m0_int_traj.append(np.linalg.norm(eco_int_traj.models[0].capability - eco_int_traj.models[0].specialization_target))

        others_base_traj.append(np.mean([
            np.linalg.norm(eco_base_traj.models[i].capability - eco_base_traj.models[i].specialization_target)
            for i in range(1, n_models_traj)
        ]))
        others_int_traj.append(np.mean([
            np.linalg.norm(eco_int_traj.models[i].capability - eco_int_traj.models[i].specialization_target)
            for i in range(1, n_models_traj)
        ]))

        eco_base_traj.step()
        eco_int_traj.step()

    if verbose:
        final_degrad = others_int_traj[-1] - others_base_traj[-1]
        final_improve = m0_base_traj[-1] - m0_int_traj[-1]
        print(f"  Model 0 improvement: {final_improve:.4f}")
        print(f"  Others degradation: {final_degrad:.4f}")

    # — Part 4: Intervention type comparison —
    if verbose:
        print("[4/4] Comparing intervention types...")

    intervention_types: dict = {
        'Specialization\n(σ: 0.12→0.50)': lambda eco: setattr(eco.models[0], 'specialization_strength', 0.5),
        'Learning rate\n(η: 0.05→0.15)': lambda eco: setattr(eco.models[0], 'learning_rate', 0.15),
        'Capability\nboost': lambda eco: setattr(eco.models[0], 'capability', eco.models[0].capability + 0.5 * (eco.data_pool.natural_mean - eco.models[0].capability)),
        'Lower noise\n(σ_n→0.001)': lambda eco: setattr(eco.models[0], 'noise_std', 0.001),
    }

    intervention_results: dict = {}
    for name, int_fn in intervention_types.items():
        m0_imps: list[float] = []
        others_degs: list[float] = []
        for alpha in [0.3, 0.5, 0.7, 0.9]:
            eco_b: Ecosystem = Ecosystem.create_default(
                n_models=5, dim=dim, contamination_rate=alpha,
                learning_rate=0.05, benchmark_pressure=0.02,
                specialization_strength=0.12, noise_std=0.005,
                variance_coupling=kappa, seed=42,
            )
            eco_b.run(n_steps)

            eco_i: Ecosystem = Ecosystem.create_default(
                n_models=5, dim=dim, contamination_rate=alpha,
                learning_rate=0.05, benchmark_pressure=0.02,
                specialization_strength=0.12, noise_std=0.005,
                variance_coupling=kappa, seed=42,
            )
            int_fn(eco_i)
            eco_i.run(n_steps)

            m0_b = np.linalg.norm(eco_b.models[0].capability - eco_b.models[0].specialization_target)
            m0_i = np.linalg.norm(eco_i.models[0].capability - eco_i.models[0].specialization_target)

            oth_b = np.mean([np.linalg.norm(eco_b.models[j].capability - eco_b.models[j].specialization_target) for j in range(1, 5)])
            oth_i = np.mean([np.linalg.norm(eco_i.models[j].capability - eco_i.models[j].specialization_target) for j in range(1, 5)])

            m0_imps.append((m0_b - m0_i) / m0_b * 100 if m0_b > 0 else 0)
            others_degs.append((oth_i - oth_b) / oth_b * 100 if oth_b > 0 else 0)

        intervention_results[name] = {
            'alphas': [0.3, 0.5, 0.7, 0.9],
            'm0_improvements': m0_imps,
            'others_degradations': others_degs,
        }

    # — Generate figure —
    if verbose:
        print("Generating figures...")

    fig = plt.figure(figsize=(16, 12))
    gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.3)

    colors: dict[str, str] = {
        'improve': '#2196F3',
        'degrade': '#F44336',
        'ratio': '#9C27B0',
        'baseline': '#757575',
    }

    # Panel A: Externality vs α
    ax1 = fig.add_subplot(gs[0, 0])
    ax1_twin = ax1.twinx()

    ax1.fill_between(alphas, 0, others_degradations, alpha=0.2, color=colors['degrade'])
    l1, = ax1.plot(alphas, others_degradations, color=colors['degrade'], linewidth=2.5,
                   label='Per-model degradation')
    ax1.set_xlabel('Contamination rate α', fontsize=12)
    ax1.set_ylabel('Others\' degradation (distance increase)', fontsize=11, color=colors['degrade'])
    ax1.tick_params(axis='y', labelcolor=colors['degrade'])

    l2, = ax1_twin.plot(alphas, externality_ratios, color=colors['ratio'], linewidth=2.5,
                        linestyle='--', label='Externality ratio')
    ax1_twin.set_ylabel('Total externality / Individual gain', fontsize=11, color=colors['ratio'])
    ax1_twin.tick_params(axis='y', labelcolor=colors['ratio'])

    ax1.set_title('A. Externality Scales with Contamination', fontsize=13, fontweight='bold')
    lines = [l1, l2]
    ax1.legend(lines, [l.get_label() for l in lines], fontsize=9, loc='upper left')
    ax1.grid(True, alpha=0.3)

    # Panel B: Time evolution
    ax2 = fig.add_subplot(gs[0, 1])
    t_range = np.arange(n_steps)

    ax2.plot(t_range, others_base_traj, color=colors['baseline'], linewidth=2,
             label='Others (baseline)', linestyle='-')
    ax2.plot(t_range, others_int_traj, color=colors['degrade'], linewidth=2,
             label='Others (after intervention)', linestyle='-')
    ax2.plot(t_range, m0_base_traj, color=colors['baseline'], linewidth=2,
             label='Model 0 (baseline)', linestyle='--')
    ax2.plot(t_range, m0_int_traj, color=colors['improve'], linewidth=2,
             label='Model 0 (after intervention)', linestyle='--')

    others_base_arr = np.array(others_base_traj)
    others_int_arr = np.array(others_int_traj)
    mask = others_int_arr > others_base_arr
    ax2.fill_between(t_range, others_base_arr, others_int_arr,
                     where=mask, alpha=0.15, color=colors['degrade'],
                     label='Externality (harm to others)')

    ax2.set_xlabel('Time step', fontsize=12)
    ax2.set_ylabel('Distance to specialization target', fontsize=11)
    ax2.set_title('B. Externality Emerges Over Time (α=0.7, N=5)', fontsize=13, fontweight='bold')
    ax2.legend(fontsize=8, loc='upper right')
    ax2.grid(True, alpha=0.3)

    # Panel C: Scaling with N
    ax3 = fig.add_subplot(gs[1, 0])

    bar_x = np.arange(len(n_values))
    ax3.bar(bar_x, per_model_degrads, color=colors['degrade'],
            alpha=0.7, label='Per-model degradation')
    ax3_twin = ax3.twinx()
    ax3_twin.plot(bar_x, total_externalities, color=colors['ratio'],
                  linewidth=2.5, marker='o', markersize=8, label='Total externality')

    ax3.set_xlabel('Number of models N', fontsize=12)
    ax3.set_xticks(bar_x)
    ax3.set_xticklabels([str(n) for n in n_values])
    ax3.set_ylabel('Per-model degradation', fontsize=11, color=colors['degrade'])
    ax3.tick_params(axis='y', labelcolor=colors['degrade'])
    ax3_twin.set_ylabel('Total externality', fontsize=11, color=colors['ratio'])
    ax3_twin.tick_params(axis='y', labelcolor=colors['ratio'])

    ax3.set_title('C. Externality Scaling with Ecosystem Size (α=0.7)', fontsize=13, fontweight='bold')

    from matplotlib.lines import Line2D
    legend_elements = [
        plt.Rectangle((0, 0), 1, 1, facecolor=colors['degrade'], alpha=0.7, label='Per-model'),
        Line2D([0], [0], color=colors['ratio'], linewidth=2.5, marker='o', label='Total'),
    ]
    ax3.legend(handles=legend_elements, fontsize=9, loc='upper right')
    ax3.grid(True, alpha=0.3, axis='y')

    # Panel D: Intervention type comparison
    ax4 = fig.add_subplot(gs[1, 1])

    bar_width = 0.18
    x = np.arange(4)

    for idx, (name, data) in enumerate(intervention_results.items()):
        offset = (idx - 1.5) * bar_width
        bars = ax4.bar(x + offset, data['others_degradations'], bar_width,
                       label=name, alpha=0.8)
        # Add value labels so near-zero bars are visible
        for bar_rect, val in zip(bars, data['others_degradations']):
            if abs(val) < 0.5:  # near-zero values need explicit labels
                ax4.annotate(f'{val:.1f}%',
                             xy=(bar_rect.get_x() + bar_rect.get_width() / 2, 0),
                             xytext=(0, -12), textcoords='offset points',
                             ha='center', va='top', fontsize=6, color='#616161')

    ax4.axhline(0, color='black', linewidth=0.5)
    ax4.set_xlabel('Contamination rate α', fontsize=12)
    ax4.set_ylabel('Others\' degradation (%)', fontsize=11)
    ax4.set_xticks(x)
    ax4.set_xticklabels(['0.3', '0.5', '0.7', '0.9'])
    ax4.set_title('D. Only Specialization Creates Externalities', fontsize=13, fontweight='bold')
    ax4.legend(fontsize=8, loc='upper left', ncol=2)
    ax4.grid(True, alpha=0.3, axis='y')

    fig.suptitle('Theorem 3: Competitive Externality in AI Ecosystems',
                 fontsize=15, fontweight='bold', y=0.98)

    fig_path: str = os.path.join(output_dir, 'paradoxical_intervention.png')
    plt.savefig(fig_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    if verbose:
        print(f"  Saved: {fig_path}")

    # Summary
    max_degrad_pct = max(
        d for data in intervention_results.values()
        for d in data['others_degradations']
    )
    max_ext_ratio = max(externality_ratios)

    conclusion: str = (
        f"Competitive externality confirmed. "
        f"When one model strengthens its specialization, other models degrade by up to {max_degrad_pct:.1f}%. "
        f"The externality ratio (total harm / individual gain) reaches {max_ext_ratio:.2f}. "
        f"Critically, the externality is SPECIFIC to specialization-type improvements: "
        f"increasing learning rate, reducing noise, or direct capability boosts do NOT create "
        f"negative externalities. This demonstrates that the shared data pool creates a coupling "
        f"where persistent asymmetric forces on one model impose costs on all others."
    )

    if verbose:
        print("=" * 60)
        print(f"CONCLUSION: {conclusion}")
        print("=" * 60)

    return {
        'theorem': 'Competitive Externality (Theorem 3)',
        'externality_vs_alpha': {
            'alphas': alphas.tolist(),
            'others_degradations': others_degradations,
            'externality_ratios': externality_ratios,
        },
        'externality_vs_n': {
            'n_values': n_values,
            'per_model_degradations': per_model_degrads,
            'total_externalities': total_externalities,
        },
        'max_degradation_pct': max_degrad_pct,
        'max_externality_ratio': max_ext_ratio,
        'figure_path': fig_path,
        'conclusion': conclusion,
    }


if __name__ == '__main__':
    run_paradoxical_intervention_experiment()
