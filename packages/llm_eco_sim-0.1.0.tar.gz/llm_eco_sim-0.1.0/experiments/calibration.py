"""
calibration.py - Calibrate llm_eco_sim against real-world LLM homogenization data.

This module calibrates the llm_eco_sim dynamical system against empirical
observations from:
1. Artificial Hivemind (Jiang et al., NeurIPS 2025): inter-model cosine
   similarity of 0.71-0.82 across 70+ LMs
2. Stanford AI Index 2025: MMLU gap collapse from 17.5pp to 0.3pp (2023-2024)
3. Web contamination estimates: 30-50% of web text is AI-generated (2025)

HONEST CAVEATS:
- The mapping from cosine similarity to our diversity metric is approximate
- MMLU gap collapse has multiple causes beyond data contamination
- The calibrated α is an EFFECTIVE parameter, not a direct measurement
- Uncertainty ranges are wide and should be reported honestly
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import minimize_scalar
from typing import Dict, List, Tuple, Optional
import json
import os

from llm_eco_sim.core.ecosystem import Ecosystem
from llm_eco_sim.theory.formal_proofs import compute_diversity_curve
from llm_eco_sim.theory.diversity_metrics import pairwise_diversity


# ================================================================
# SECTION 1: EMPIRICAL TARGETS WITH UNCERTAINTY
# ================================================================

EMPIRICAL_TARGETS = {
    'hivemind_inter_model_similarity': {
        'value': 0.76,
        'range': (0.71, 0.82),
        'description': 'Average inter-model cosine similarity across 70+ LMs',
        'year': 2025,
        'caveat': 'Measured on text outputs, not capability vectors directly',
    },
    'mmlu_gap_2023': {
        'value': 17.5,
        'range': (15.0, 20.0),
        'description': 'US-China MMLU gap in 2023 (percentage points)',
        'year': 2023,
        'caveat': 'Gap between top models, not full ecosystem diversity',
    },
    'mmlu_gap_2024': {
        'value': 0.3,
        'range': (0.0, 1.0),
        'description': 'US-China MMLU gap in 2024 (percentage points)',
        'year': 2024,
        'caveat': 'Collapse may reflect catch-up rather than homogenization',
    },
    'synthetic_data_fraction_2025': {
        'value': 0.35,
        'range': (0.30, 0.50),
        'description': 'Fraction of web text that is AI-generated (2025)',
        'year': 2025,
        'caveat': 'Estimates vary widely; not all enters training pipelines',
    },
}


def cosine_similarity_to_diversity_ratio(cos_sim: float) -> Tuple[float, float, float]:
    """
    Convert average cosine similarity to a diversity ratio WITH uncertainty.

    For unit-variance capability vectors in R^d:
        cos_sim = 1 - D / (2 * D_max)
    So: D/D_max = 2 * (1 - cos_sim)

    However, this mapping is approximate because:
    1. Cosine similarity is measured on text outputs, not capability vectors
    2. The relationship is nonlinear for non-unit-norm vectors
    3. High-dimensional effects can distort the mapping

    Returns (estimate, lower_bound, upper_bound).
    """
    estimate = 2.0 * (1.0 - cos_sim)
    # Add ±50% uncertainty to account for mapping approximation
    lower = estimate * 0.5
    upper = min(estimate * 1.5, 1.0)
    return estimate, lower, upper


# ================================================================
# SECTION 2: CALIBRATION PROCEDURE
# ================================================================

def calibrate_alpha_from_simulation(
    target_diversity_ratio: float,
    eta: float = 0.05,
    beta: float = 0.02,
    kappa: float = 3.0,
    sigma: float = 0.12,
    noise_std: float = 0.005,
    n_models: int = 10,
    dim: int = 20,
    n_steps: int = 500,
    seed: int = 42,
) -> Dict:
    """
    Find α that produces a given diversity ratio via simulation.

    Uses the analytical formula for initial estimate, then validates
    with simulation.
    """
    # Analytical estimate using exact equilibrium formula
    def analytical_ratio(alpha):
        lam_0 = 1.0 - eta - beta - sigma
        lam_a = 1.0 - eta * (1.0 + kappa * alpha) - beta - sigma
        if abs(lam_0) >= 1.0 or abs(lam_a) >= 1.0:
            return float('inf')
        D_0 = sigma**2 / (1 - lam_0)**2 + 2 * dim * noise_std**2 / ((1 - lam_0) * (1 + lam_0))
        D_a = sigma**2 / (1 - lam_a)**2 + 2 * dim * noise_std**2 / ((1 - lam_a) * (1 + lam_a))
        return D_a / D_0

    # Find α analytically
    res = minimize_scalar(
        lambda a: (analytical_ratio(a) - target_diversity_ratio)**2,
        bounds=(0.0, 1.0), method='bounded'
    )
    alpha_analytical = res.x
    ratio_analytical = analytical_ratio(alpha_analytical)

    # Validate with simulation
    # Run at α=0 to get D_eq(0)
    eco0 = Ecosystem.create_default(
        n_models=n_models, dim=dim,
        contamination_rate=0.0,
        learning_rate=eta, benchmark_pressure=beta,
        noise_std=noise_std, specialization_strength=sigma,
        variance_coupling=kappa, seed=seed,
    )
    eco0.run(n_steps)
    D_eq_0 = eco0.get_diversity_trajectory()[-1]

    # Run at calibrated α to get D_eq(α)
    eco = Ecosystem.create_default(
        n_models=n_models, dim=dim,
        contamination_rate=alpha_analytical,
        learning_rate=eta, benchmark_pressure=beta,
        noise_std=noise_std, specialization_strength=sigma,
        variance_coupling=kappa, seed=seed,
    )
    eco.run(n_steps)
    D_eq_a = eco.get_diversity_trajectory()[-1]
    ratio_simulation = D_eq_a / D_eq_0 if D_eq_0 > 0 else 0

    return {
        'alpha': alpha_analytical,
        'ratio_analytical': ratio_analytical,
        'ratio_simulation': ratio_simulation,
        'target': target_diversity_ratio,
        'error_analytical': abs(ratio_analytical - target_diversity_ratio),
        'error_simulation': abs(ratio_simulation - target_diversity_ratio),
    }


def full_calibration(
    n_models: int = 10,
    dim: int = 20,
    seed: int = 42,
) -> Dict:
    """
    Full calibration procedure with honest uncertainty reporting.
    """
    results: dict[str, float] = {}

    # Step 1: Map Hivemind similarity to diversity ratio with uncertainty
    hivemind_sim = EMPIRICAL_TARGETS['hivemind_inter_model_similarity']['value']
    div_est, div_lo, div_hi = cosine_similarity_to_diversity_ratio(hivemind_sim)
    results['diversity_ratio_2025'] = div_est
    results['diversity_ratio_range'] = (div_lo, div_hi)
    print(f"Hivemind cos_sim={hivemind_sim} → diversity_ratio={div_est:.4f} [{div_lo:.4f}, {div_hi:.4f}]")

    # Step 2: Calibrate α for the central estimate
    cal = calibrate_alpha_from_simulation(
        target_diversity_ratio=div_est,
        eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
        noise_std=0.005, n_models=n_models, dim=dim, seed=seed,
    )
    results['calibrated_alpha'] = cal['alpha']
    results['calibration_error'] = cal['error_analytical']
    print(f"Calibrated α = {cal['alpha']:.4f}")
    print(f"  Analytical ratio: {cal['ratio_analytical']:.4f}")
    print(f"  Simulation ratio: {cal['ratio_simulation']:.4f}")
    print(f"  Target: {cal['target']:.4f}")

    # Step 3: Calibrate α for uncertainty bounds
    cal_lo = calibrate_alpha_from_simulation(
        target_diversity_ratio=div_hi,  # higher diversity → lower α
        eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
        noise_std=0.005, n_models=n_models, dim=dim, seed=seed,
    )
    cal_hi = calibrate_alpha_from_simulation(
        target_diversity_ratio=div_lo,  # lower diversity → higher α
        eta=0.05, beta=0.02, kappa=3.0, sigma=0.12,
        noise_std=0.005, n_models=n_models, dim=dim, seed=seed,
    )
    results['alpha_range'] = (cal_lo['alpha'], cal_hi['alpha'])
    print(f"  α range: [{cal_lo['alpha']:.4f}, {cal_hi['alpha']:.4f}]")

    # Step 4: Cross-validate with synthetic data fraction
    synthetic_fraction = EMPIRICAL_TARGETS['synthetic_data_fraction_2025']['value']
    results['synthetic_fraction_observed'] = synthetic_fraction
    results['alpha_vs_synthetic_ratio'] = cal['alpha'] / synthetic_fraction
    print(f"\nCross-validation:")
    print(f"  Calibrated α = {cal['alpha']:.4f}")
    print(f"  Observed synthetic fraction = {synthetic_fraction:.2f}")
    print(f"  Ratio α/synthetic = {cal['alpha']/synthetic_fraction:.2f}")
    alpha_synth_ratio = cal['alpha'] / synthetic_fraction
    if alpha_synth_ratio > 1:
        print(f"  NOTE: α > synthetic fraction. The effective coupling is stronger")
        print(f"  than the raw synthetic fraction, likely because models also")
        print(f"  converge through shared benchmarks and architectural choices.")
    else:
        print(f"  NOTE: α < synthetic fraction because not all synthetic data")
        print(f"  enters all training pipelines equally (effective coupling < raw fraction)")

    # Step 5: MMLU gap analysis (separate from calibration)
    mmlu_2023 = EMPIRICAL_TARGETS['mmlu_gap_2023']['value'] / 100.0
    mmlu_2024 = EMPIRICAL_TARGETS['mmlu_gap_2024']['value'] / 100.0
    collapse_rate = 1.0 - mmlu_2024 / mmlu_2023 if mmlu_2023 > 0 else 0
    results['mmlu_collapse_rate'] = collapse_rate
    print(f"\nMMLU gap: {mmlu_2023*100:.1f}pp → {mmlu_2024*100:.1f}pp ({collapse_rate:.1%} collapse)")
    print(f"  CAVEAT: This collapse likely reflects catch-up dynamics,")
    print(f"  not pure homogenization. Used for time-scale estimation only.")

    # Step 6: Estimate time scale
    # Run simulation and find when diversity drops by the MMLU collapse rate
    eco = Ecosystem.create_default(
        n_models=n_models, dim=dim,
        contamination_rate=cal['alpha'],
        learning_rate=0.05, benchmark_pressure=0.02,
        noise_std=0.005, specialization_strength=0.12,
        variance_coupling=3.0, seed=seed,
    )
    eco.run(500)
    div_traj = eco.get_diversity_trajectory()
    div_init = div_traj[0]

    # Find step where diversity ratio matches MMLU collapse
    mmlu_target = 1.0 - collapse_rate
    steps_per_year = None
    for t in range(1, len(div_traj)):
        if div_traj[t] / div_init <= mmlu_target:
            steps_per_year = t
            break
    if steps_per_year is None:
        steps_per_year = 50  # fallback
    results['steps_per_year'] = steps_per_year
    # Use equilibrium-to-equilibrium ratio for consistency with analytical formula
    results['simulation_diversity_ratio'] = cal['ratio_simulation']
    print(f"\nTime mapping: {steps_per_year} simulation steps = 1 year")

    return results


# ================================================================
# SECTION 3: VISUALIZATION
# ================================================================

def plot_calibration_results(
    calibration: Dict,
    save_dir: str = 'results/calibration',
) -> None:
    """Generate calibration figures with honest uncertainty."""
    os.makedirs(save_dir, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Panel A: Analytical diversity curve with calibrated point and uncertainty
    ax = axes[0]
    curve = compute_diversity_curve(
        eta=0.05, beta=0.02, kappa=3.0, sigma=0.12, dim=20, noise_std=0.005
    )
    alpha_range = curve['alpha_range']
    D_ratio = curve['D_ratio']

    ax.plot(alpha_range, D_ratio, 'b-', linewidth=2.5,
            label=r'Analytical $D_{eq}(\alpha)/D_{eq}(0)$')

    # Mark calibrated point with uncertainty
    cal_alpha = calibration['calibrated_alpha']
    div_est = calibration['diversity_ratio_2025']
    div_lo, div_hi = calibration['diversity_ratio_range']
    alpha_lo, alpha_hi = calibration['alpha_range']

    ax.plot(cal_alpha, div_est, 'r*', markersize=15, zorder=5,
            label=f'Calibrated: α={cal_alpha:.3f}')

    # Uncertainty rectangle
    ax.fill_between([alpha_lo, alpha_hi], div_lo, div_hi,
                    alpha=0.2, color='red', label='Uncertainty range')

    # Mark synthetic data fraction
    syn_frac = calibration['synthetic_fraction_observed']
    syn_lo, syn_hi = EMPIRICAL_TARGETS['synthetic_data_fraction_2025']['range']
    ax.axvspan(syn_lo, syn_hi, alpha=0.1, color='orange',
               label=f'Observed synthetic fraction ({syn_lo:.0%}-{syn_hi:.0%})')

    ax.set_xlabel('Effective contamination rate α', fontsize=12)
    ax.set_ylabel('Equilibrium diversity ratio', fontsize=12)
    ax.set_title('A. Calibration Against Empirical Data', fontsize=12)
    ax.legend(fontsize=8, loc='upper right')
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.1)
    ax.grid(True, alpha=0.3)

    # Panel B: Comparison bar chart with error bars
    ax = axes[1]
    categories = ['Analytical\nPrediction', 'Simulation\nValidation', 'Empirical\nTarget']
    values = [
        calibration.get('calibration_error', 0) + div_est,  # analytical at calibrated α
        calibration['simulation_diversity_ratio'] if 'simulation_diversity_ratio' in calibration else div_est,
        div_est,
    ]

    # Recalculate properly
    from llm_eco_sim.theory.formal_proofs import compute_diversity_curve as cdc
    dc = cdc(eta=0.05, beta=0.02, kappa=3.0, sigma=0.12, dim=20, noise_std=0.005)
    # Find analytical value at calibrated alpha
    idx = np.argmin(np.abs(dc['alpha_range'] - cal_alpha))
    analytical_val = dc['D_ratio'][idx]
    sim_val = calibration.get('simulation_diversity_ratio', div_est)

    values = [analytical_val, sim_val, div_est]
    errors = [0, 0, (div_hi - div_lo) / 2]  # only empirical has uncertainty
    colors = ['#2196F3', '#4CAF50', '#F44336']

    bars = ax.bar(categories, values, color=colors, width=0.5,
                  edgecolor='black', linewidth=0.5, yerr=errors,
                  capsize=5, error_kw={'linewidth': 2})

    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                f'{val:.4f}', ha='center', va='bottom', fontsize=11, fontweight='bold')

    ax.set_ylabel('Diversity ratio', fontsize=12)
    ax.set_title('B. Calibration Validation', fontsize=12)
    ax.set_ylim(0, max(values) * 1.5)
    ax.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'calibration.png'), dpi=200, bbox_inches='tight')
    plt.close()
    print(f"Saved calibration figure to {save_dir}/calibration.png")


# ================================================================
# SECTION 4: MAIN ENTRY POINT
# ================================================================

def run_calibration_experiment(save_dir: str = 'results/calibration') -> dict:
    """Run the full calibration pipeline."""
    os.makedirs(save_dir, exist_ok=True)

    print("=" * 60)
    print("LLM-ECO-SIM CALIBRATION AGAINST REAL-WORLD DATA")
    print("=" * 60)
    print()

    # Calibrate
    calibration = full_calibration(n_models=10, dim=20, seed=42)
    print()

    # Visualize
    plot_calibration_results(calibration, save_dir=save_dir)

    # Save results
    summary = {
        'calibration': {
            'calibrated_alpha': float(calibration['calibrated_alpha']),
            'alpha_range': [float(x) for x in calibration['alpha_range']],
            'diversity_ratio_2025': float(calibration['diversity_ratio_2025']),
            'diversity_ratio_range': [float(x) for x in calibration['diversity_ratio_range']],
            'simulation_diversity_ratio': float(calibration.get('simulation_diversity_ratio', 0)),
            'steps_per_year': int(calibration['steps_per_year']),
        },
        'caveats': [
            'Cosine similarity → diversity ratio mapping is approximate (±50%)',
            'Calibrated α is an effective parameter, not a direct measurement',
            'MMLU gap collapse has multiple causes beyond data contamination',
            'Model assumes homogeneous agents; real ecosystem is heterogeneous',
        ],
        'empirical_targets': {
            k: {kk: vv for kk, vv in v.items()}
            for k, v in EMPIRICAL_TARGETS.items()
        },
    }

    with open(os.path.join(save_dir, 'calibration_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2, default=str)
    print(f"Saved summary to {save_dir}/calibration_summary.json")

    print()
    print("=" * 60)
    print("KEY FINDINGS:")
    print(f"  Calibrated α = {calibration['calibrated_alpha']:.4f}")
    print(f"  α range: [{calibration['alpha_range'][0]:.4f}, {calibration['alpha_range'][1]:.4f}]")
    print(f"  Diversity ratio (2025): {calibration['diversity_ratio_2025']:.4f}")
    print(f"  Time mapping: {calibration['steps_per_year']} steps = 1 year")
    print("=" * 60)

    return calibration


if __name__ == '__main__':
    run_calibration_experiment()
