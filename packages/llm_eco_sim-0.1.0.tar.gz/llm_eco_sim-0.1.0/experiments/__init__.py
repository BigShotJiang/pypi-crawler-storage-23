"""Experiment scripts for reproducing theoretical results."""

from llm_eco_sim.experiments.diversity_erosion import run_diversity_erosion_experiment
from llm_eco_sim.experiments.benchmark_gaming import run_benchmark_gaming_experiment
from llm_eco_sim.experiments.paradoxical_intervention import run_paradoxical_intervention_experiment
from llm_eco_sim.experiments.calibration import run_calibration_experiment
from llm_eco_sim.experiments.prediction import run_prediction_experiment
from llm_eco_sim.experiments.scaling import run_scaling_experiments
from llm_eco_sim.experiments.shumailov_comparison import run_shumailov_comparison

__all__: list[str] = [
    "run_diversity_erosion_experiment",
    "run_benchmark_gaming_experiment",
    "run_paradoxical_intervention_experiment",
    "run_calibration_experiment",
    "run_prediction_experiment",
    "run_scaling_experiments",
    "run_shumailov_comparison",
]
