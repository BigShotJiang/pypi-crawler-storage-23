"""Tests for Scenario Generator (D1) — stress test scenario generation.

Uses mocked LLM responses for unit tests. Tests offline mode, prompt
construction, response parsing, category filtering, BYOK configuration,
and integration with real ingester output.
"""

import json
import urllib.error
from pathlib import Path
from typing import Optional
from unittest.mock import MagicMock, patch

import pytest

from mycode.ingester import (
    ClassInfo,
    CouplingPoint,
    DependencyInfo,
    FileAnalysis,
    FunctionFlow,
    FunctionInfo,
    ImportInfo,
    IngestionResult,
    ProjectIngester,
)
from mycode.library import ComponentLibrary, ProfileMatch
from mycode.library.loader import DependencyProfile
from mycode.scenario import (
    ALL_CATEGORIES,
    JAVASCRIPT_CATEGORIES,
    PYTHON_CATEGORIES,
    SHARED_CATEGORIES,
    CouplingBehaviorType,
    LLMBackend,
    LLMConfig,
    LLMError,
    LLMResponse,
    LLMResponseError,
    ScenarioError,
    ScenarioGenerator,
    ScenarioGeneratorResult,
    StressTestScenario,
    _extract_json,
    _file_path_to_module,
    _infer_measurements,
    _infer_priority_from_template,
    _safe_name,
    _serialize_coupling_points,
    _serialize_file_analyses,
    _serialize_function_flows,
    _serialize_profiles,
    classify_coupling_point,
    group_coupling_points_by_behavior,
)


# ── Fixtures ──


def _make_profile(name: str, category: str = "web_framework") -> DependencyProfile:
    """Create a minimal DependencyProfile for testing."""
    raw = {
        "identity": {
            "name": name,
            "pypi_name": name,
            "category": category,
            "description": f"Test profile for {name}",
            "current_stable_version": "1.0.0",
            "min_supported_version": "1.0.0",
            "version_notes": {},
        },
        "scaling_characteristics": {"description": "test", "concurrency_model": "test",
                                    "bottlenecks": [], "scaling_limits": []},
        "memory_behavior": {"baseline_footprint_mb": 10, "growth_pattern": "test",
                           "known_leaks": [], "gc_behavior": "test"},
        "known_failure_modes": [
            {
                "name": "test_failure",
                "description": "A test failure mode",
                "trigger_conditions": "Under load",
                "severity": "high",
                "versions_affected": "all",
                "detection_hint": "Look for errors",
            },
        ],
        "edge_case_sensitivities": [
            {"name": "test_edge", "description": "A test edge case", "test_approach": "test"},
        ],
        "interaction_patterns": {
            "commonly_used_with": [],
            "known_conflicts": [],
            "dependency_chain_risks": [],
        },
        "stress_test_templates": [
            {
                "name": "load_test",
                "category": "concurrent_execution",
                "description": "Test under concurrent load",
                "parameters": {"concurrent": [1, 10, 100]},
                "expected_behavior": "Degrades gracefully",
                "failure_indicators": ["timeout", "crash"],
            },
            {
                "name": "memory_test",
                "category": "memory_profiling",
                "description": "Test memory growth over time",
                "parameters": {"iterations": 1000},
                "expected_behavior": "Memory stable",
                "failure_indicators": ["memory_growth_unbounded"],
            },
        ],
    }
    return DependencyProfile(
        identity=raw["identity"],
        scaling_characteristics=raw["scaling_characteristics"],
        memory_behavior=raw["memory_behavior"],
        known_failure_modes=raw["known_failure_modes"],
        edge_case_sensitivities=raw["edge_case_sensitivities"],
        interaction_patterns=raw["interaction_patterns"],
        stress_test_templates=raw["stress_test_templates"],
        raw=raw,
    )


def _make_browser_only_profile(
    name: str, category: str = "graphics",
) -> DependencyProfile:
    """Create a browser-only DependencyProfile with node_stress_test_templates."""
    raw = {
        "identity": {
            "name": name,
            "npm_name": name,
            "category": category,
            "description": f"Browser-only test profile for {name}",
            "current_stable_version": "1.0.0",
            "min_supported_version": "1.0.0",
            "version_notes": {},
            "browser_only": True,
        },
        "scaling_characteristics": {"description": "test", "concurrency_model": "test",
                                    "bottlenecks": [], "scaling_limits": []},
        "memory_behavior": {"baseline_footprint_mb": 10, "growth_pattern": "test",
                           "known_leaks": [], "gc_behavior": "test"},
        "known_failure_modes": [
            {
                "name": "render_crash",
                "description": "Crash during rendering",
                "trigger_conditions": "Large dataset",
                "severity": "high",
                "versions_affected": "all",
                "detection_hint": "Look for crash",
            },
        ],
        "edge_case_sensitivities": [],
        "interaction_patterns": {
            "commonly_used_with": [],
            "known_conflicts": [],
            "dependency_chain_risks": [],
        },
        "stress_test_templates": [
            {
                "name": "canvas_render",
                "category": "data_volume_scaling",
                "description": "Canvas rendering test (browser-only)",
                "parameters": {"data_sizes": [100, 1000]},
                "expected_behavior": "Renders without errors",
                "failure_indicators": ["render_error"],
            },
        ],
        "node_stress_test_templates": [
            {
                "name": "data_throughput",
                "category": "data_volume_scaling",
                "description": "Data array throughput",
                "harness_body": "node_data_processing",
                "parameters": {"data_sizes": [1000, 10000]},
                "expected_behavior": "Scales linearly",
                "failure_indicators": ["timeout"],
            },
            {
                "name": "lifecycle_test",
                "category": "memory_profiling",
                "description": "Object lifecycle memory",
                "harness_body": "node_object_lifecycle",
                "parameters": {"iterations": 50},
                "expected_behavior": "Memory recovers",
                "failure_indicators": ["memory_growth_unbounded"],
            },
        ],
    }
    return DependencyProfile(
        identity=raw["identity"],
        scaling_characteristics=raw["scaling_characteristics"],
        memory_behavior=raw["memory_behavior"],
        known_failure_modes=raw["known_failure_modes"],
        edge_case_sensitivities=raw["edge_case_sensitivities"],
        interaction_patterns=raw["interaction_patterns"],
        stress_test_templates=raw["stress_test_templates"],
        node_stress_test_templates=raw["node_stress_test_templates"],
        raw=raw,
    )


@pytest.fixture
def sample_ingestion() -> IngestionResult:
    """Create a realistic IngestionResult for testing."""
    return IngestionResult(
        project_path="/tmp/test_project",
        files_analyzed=3,
        files_failed=0,
        total_lines=500,
        file_analyses=[
            FileAnalysis(
                file_path="app.py",
                functions=[
                    FunctionInfo(name="main", file_path="app.py", lineno=1, calls=["create_app"]),
                    FunctionInfo(name="create_app", file_path="app.py", lineno=10, calls=["db.init"]),
                ],
                classes=[],
                imports=[
                    ImportInfo(module="flask", names=["Flask"], is_from_import=True, lineno=1),
                    ImportInfo(module="sqlalchemy", names=[], lineno=2),
                ],
                lines_of_code=200,
            ),
            FileAnalysis(
                file_path="models.py",
                functions=[],
                classes=[ClassInfo(name="User", file_path="models.py", lineno=5,
                                  methods=["save", "delete"], bases=["Model"])],
                imports=[
                    ImportInfo(module="sqlalchemy", names=["Column"], is_from_import=True, lineno=1),
                ],
                lines_of_code=150,
            ),
            FileAnalysis(
                file_path="utils.py",
                functions=[
                    FunctionInfo(name="validate_input", file_path="utils.py", lineno=1, calls=[]),
                ],
                classes=[],
                imports=[],
                lines_of_code=150,
            ),
        ],
        dependencies=[
            DependencyInfo(name="flask", installed_version="3.1.0"),
            DependencyInfo(name="sqlalchemy", installed_version="2.0.30"),
            DependencyInfo(name="gunicorn", installed_version="21.2.0"),
        ],
        function_flows=[
            FunctionFlow(caller="app.main", callee="app.create_app", file_path="app.py", lineno=5),
            FunctionFlow(caller="app.create_app", callee="sqlalchemy.init", file_path="app.py", lineno=15),
        ],
        coupling_points=[
            CouplingPoint(
                source="app.create_app",
                targets=["app.main", "models.User.save", "models.User.delete"],
                coupling_type="high_fan_in",
                description="'app.create_app' is called by 3 functions",
            ),
        ],
    )


@pytest.fixture
def sample_matches() -> list[ProfileMatch]:
    """Create ProfileMatch objects for testing."""
    flask_profile = _make_profile("flask", "web_framework")
    sqla_profile = _make_profile("sqlalchemy", "database")
    return [
        ProfileMatch(
            dependency_name="flask",
            profile=flask_profile,
            installed_version="3.1.0",
            version_match=True,
        ),
        ProfileMatch(
            dependency_name="sqlalchemy",
            profile=sqla_profile,
            installed_version="2.0.30",
            version_match=True,
        ),
        ProfileMatch(
            dependency_name="gunicorn",
            profile=None,
            installed_version="21.2.0",
        ),
    ]


def _make_llm_response_json(
    scenarios: Optional[list[dict]] = None,
    reasoning: str = "Test reasoning",
) -> str:
    """Build a valid LLM response JSON string."""
    if scenarios is None:
        scenarios = [
            {
                "name": "concurrent_requests",
                "category": "concurrent_execution",
                "description": "Test concurrent HTTP requests",
                "target_dependencies": ["flask"],
                "test_config": {
                    "parameters": {"concurrent": [1, 10, 50]},
                    "measurements": ["response_time_ms"],
                    "resource_limits": {"memory_mb": 512},
                },
                "expected_behavior": "Response time increases linearly",
                "failure_indicators": ["timeout", "error_rate > 10%"],
                "priority": "high",
            },
            {
                "name": "data_volume_db",
                "category": "data_volume_scaling",
                "description": "Scale database queries with increasing data",
                "target_dependencies": ["sqlalchemy"],
                "test_config": {
                    "parameters": {"row_counts": [100, 1000, 10000]},
                    "measurements": ["query_time_ms", "memory_mb"],
                    "resource_limits": {"memory_mb": 512},
                },
                "expected_behavior": "Query time scales with index usage",
                "failure_indicators": ["full_table_scan", "timeout"],
                "priority": "medium",
            },
        ]
    return json.dumps({"reasoning": reasoning, "scenarios": scenarios})


# ── Tests: Category Constants ──


class TestCategories:
    """Verify stress test category definitions."""

    def test_shared_categories(self):
        expected = {"data_volume_scaling", "memory_profiling",
                    "edge_case_input", "concurrent_execution"}
        assert SHARED_CATEGORIES == frozenset(expected)

    def test_python_categories_include_shared(self):
        assert SHARED_CATEGORIES.issubset(PYTHON_CATEGORIES)

    def test_python_specific_categories(self):
        python_only = PYTHON_CATEGORIES - SHARED_CATEGORIES
        assert python_only == frozenset({"blocking_io", "gil_contention"})

    def test_javascript_categories_include_shared(self):
        assert SHARED_CATEGORIES.issubset(JAVASCRIPT_CATEGORIES)

    def test_javascript_specific_categories(self):
        js_only = JAVASCRIPT_CATEGORIES - SHARED_CATEGORIES
        assert js_only == frozenset({
            "async_failures", "event_listener_accumulation",
            "state_management_degradation",
        })

    def test_all_categories(self):
        assert ALL_CATEGORIES == PYTHON_CATEGORIES | JAVASCRIPT_CATEGORIES


class TestGetCategories:
    """Test language-specific category selection."""

    def test_python_categories(self):
        gen = ScenarioGenerator(offline=True)
        cats = gen._get_categories("python")
        assert "blocking_io" in cats
        assert "gil_contention" in cats
        assert "async_failures" not in cats

    def test_javascript_categories(self):
        gen = ScenarioGenerator(offline=True)
        cats = gen._get_categories("javascript")
        assert "async_failures" in cats
        assert "event_listener_accumulation" in cats
        assert "blocking_io" not in cats

    def test_case_insensitive(self):
        gen = ScenarioGenerator(offline=True)
        assert gen._get_categories("Python") == PYTHON_CATEGORIES
        assert gen._get_categories("JavaScript") == JAVASCRIPT_CATEGORIES


# ── Tests: LLM Config ──


class TestLLMConfig:
    """Test LLM configuration defaults and BYOK."""

    def test_default_config(self):
        config = LLMConfig()
        assert config.model == "gemini-2.5-flash"
        assert "googleapis.com" in config.base_url
        assert config.api_key is None
        assert config.max_retries == 2

    def test_byok_openai(self):
        config = LLMConfig(
            api_key="sk-test-key",
            base_url="https://api.openai.com/v1",
            model="gpt-4o",
        )
        assert config.api_key == "sk-test-key"
        assert "openai.com" in config.base_url
        assert config.model == "gpt-4o"

    def test_byok_deepseek(self):
        config = LLMConfig(
            api_key="ds-test-key",
            base_url="https://api.deepseek.com/v1",
            model="deepseek-chat",
        )
        assert config.model == "deepseek-chat"

    def test_byok_custom_endpoint(self):
        config = LLMConfig(
            api_key="custom-key",
            base_url="http://localhost:8080/v1",
            model="local-model",
        )
        assert config.base_url == "http://localhost:8080/v1"


# ── Tests: LLM Backend ──


class TestLLMBackend:
    """Test LLM backend initialization and error handling."""

    def test_requires_api_key(self):
        with pytest.raises(LLMError, match="API key required"):
            LLMBackend(LLMConfig())

    def test_creates_with_key(self):
        backend = LLMBackend(LLMConfig(api_key="test-key"))
        assert backend is not None

    def test_retryable_429(self):
        assert LLMBackend._is_retryable(LLMError("LLM API returned HTTP 429: rate limited"))

    def test_retryable_500(self):
        assert LLMBackend._is_retryable(LLMError("LLM API returned HTTP 500: server error"))

    def test_not_retryable_401(self):
        assert not LLMBackend._is_retryable(LLMError("LLM API returned HTTP 401: unauthorized"))

    def test_not_retryable_400(self):
        assert not LLMBackend._is_retryable(LLMError("LLM API returned HTTP 400: bad request"))

    def test_retryable_network_error(self):
        assert LLMBackend._is_retryable(LLMError("LLM API request failed: connection refused"))


# ── Tests: JSON Extraction ──


class TestExtractJson:
    """Test JSON extraction from various LLM response formats."""

    def test_raw_json(self):
        data = _extract_json('{"reasoning": "test", "scenarios": []}')
        assert data["reasoning"] == "test"

    def test_json_in_code_block(self):
        content = '```json\n{"reasoning": "test", "scenarios": []}\n```'
        data = _extract_json(content)
        assert data["reasoning"] == "test"

    def test_json_in_bare_code_block(self):
        content = '```\n{"reasoning": "test", "scenarios": []}\n```'
        data = _extract_json(content)
        assert data["reasoning"] == "test"

    def test_json_with_leading_text(self):
        content = 'Here is the result:\n{"reasoning": "test", "scenarios": []}'
        data = _extract_json(content)
        assert data["reasoning"] == "test"

    def test_json_with_surrounding_text(self):
        content = 'Preamble text\n{"reasoning": "test", "scenarios": []}\nTrailing text'
        data = _extract_json(content)
        assert data["reasoning"] == "test"

    def test_invalid_json_raises(self):
        with pytest.raises(LLMResponseError, match="Could not extract JSON"):
            _extract_json("This is not JSON at all")

    def test_empty_string_raises(self):
        with pytest.raises(LLMResponseError):
            _extract_json("")

    def test_non_object_raises(self):
        with pytest.raises(LLMResponseError):
            _extract_json('"just a string"')


# ── Tests: Offline Generation ──


class TestOfflineGeneration:
    """Test scenario generation without LLM calls."""

    def test_offline_init_no_api_key_needed(self):
        gen = ScenarioGenerator(offline=True)
        assert gen._backend is None

    def test_offline_generates_scenarios(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app for managing users", "python")
        assert isinstance(result, ScenarioGeneratorResult)
        assert len(result.scenarios) > 0
        assert result.model_used == "offline"
        assert result.reasoning == ""

    def test_offline_all_sources_marked(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        for s in result.scenarios:
            assert s.source == "offline"

    def test_offline_generates_profile_template_scenarios(self, sample_ingestion, sample_matches):
        """Recognized deps should produce scenarios from their stress_test_templates."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        template_scenarios = [s for s in result.scenarios
                              if s.name.startswith("flask_") or s.name.startswith("sqlalchemy_")]
        assert len(template_scenarios) >= 4  # 2 templates * 2 recognized deps

    def test_offline_generates_failure_mode_scenarios(self, sample_ingestion, sample_matches):
        """Critical/high failure modes should produce edge_case_input scenarios."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        failure_scenarios = [s for s in result.scenarios if s.name.endswith("_check")]
        assert len(failure_scenarios) >= 2  # 1 high-severity mode per recognized dep

    def test_offline_generates_coupling_scenarios(self, sample_ingestion, sample_matches):
        """Coupling points should produce behavior-classified scenarios."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        coupling_scenarios = [s for s in result.scenarios if s.name.startswith("coupling_")]
        assert len(coupling_scenarios) >= 1

    def test_offline_generates_unrecognized_scenario(self, sample_ingestion, sample_matches):
        """Unrecognized deps should produce a generic stress scenario."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        unrec = [s for s in result.scenarios if s.name == "unrecognized_deps_generic_stress"]
        assert len(unrec) == 1
        assert "gunicorn" in unrec[0].description

    def test_offline_no_unrecognized_when_all_matched(self, sample_ingestion):
        """No unrecognized scenario when all deps have profiles."""
        matches = [
            ProfileMatch(dependency_name="flask", profile=_make_profile("flask"),
                         installed_version="3.1.0", version_match=True),
        ]
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, matches, "A web app", "python")
        unrec = [s for s in result.scenarios if "unrecognized" in s.name]
        assert len(unrec) == 0

    def test_offline_version_discrepancy_scenario(self, sample_ingestion):
        """Outdated deps should produce a version discrepancy scenario."""
        matches = [
            ProfileMatch(
                dependency_name="flask",
                profile=_make_profile("flask"),
                installed_version="2.0.0",
                version_match=False,
                version_notes="Major version behind: installed 2.0.0, current stable 1.0.0",
            ),
        ]
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, matches, "A web app", "python")
        version_scenarios = [s for s in result.scenarios if "version_discrepancy" in s.name]
        assert len(version_scenarios) == 1

    def test_offline_categories_filtered_python(self, sample_ingestion, sample_matches):
        """Python offline scenarios should only use Python-valid categories."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        for s in result.scenarios:
            assert s.category in PYTHON_CATEGORIES, (
                f"Scenario '{s.name}' has non-Python category: {s.category}"
            )

    def test_offline_categories_filtered_javascript(self, sample_ingestion, sample_matches):
        """JavaScript offline scenarios should only use JS-valid categories."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "javascript")
        for s in result.scenarios:
            assert s.category in JAVASCRIPT_CATEGORIES, (
                f"Scenario '{s.name}' has non-JS category: {s.category}"
            )

    def test_offline_empty_matches(self, sample_ingestion):
        """Should produce minimal scenarios with no profile matches."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, [], "A web app", "python")
        # Should still produce coupling point scenarios
        assert len(result.scenarios) >= 1

    def test_offline_empty_ingestion(self):
        """Should handle a near-empty ingestion result gracefully."""
        ingestion = IngestionResult(project_path="/tmp/empty")
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [], "A web app", "python")
        assert isinstance(result, ScenarioGeneratorResult)
        assert len(result.scenarios) == 0

    def test_offline_scenario_has_test_config(self, sample_ingestion, sample_matches):
        """Every offline scenario should have a populated test_config."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        for s in result.scenarios:
            assert isinstance(s.test_config, dict), f"{s.name}: test_config not dict"
            assert len(s.test_config) > 0, f"{s.name}: empty test_config"

    def test_offline_scenario_has_failure_indicators(self, sample_ingestion, sample_matches):
        """Every offline scenario should have failure indicators."""
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")
        for s in result.scenarios:
            assert isinstance(s.failure_indicators, list), f"{s.name}: indicators not list"
            assert len(s.failure_indicators) > 0, f"{s.name}: no failure indicators"


# ── Tests: LLM Response Parsing ──


class TestLLMResponseParsing:
    """Test parsing of LLM JSON responses into scenarios."""

    def test_parse_valid_response(self):
        gen = ScenarioGenerator(offline=True)
        content = _make_llm_response_json()
        scenarios, reasoning = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        assert len(scenarios) == 2
        assert reasoning == "Test reasoning"

    def test_parse_sets_source_llm(self):
        gen = ScenarioGenerator(offline=True)
        content = _make_llm_response_json()
        scenarios, _ = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        for s in scenarios:
            assert s.source == "llm"

    def test_parse_filters_invalid_categories(self):
        """Scenarios with categories not in valid set should be skipped."""
        gen = ScenarioGenerator(offline=True)
        scenarios_data = [
            {"name": "valid", "category": "concurrent_execution",
             "description": "A valid scenario"},
            {"name": "invalid_cat", "category": "nonexistent_category",
             "description": "Should be skipped"},
        ]
        content = _make_llm_response_json(scenarios=scenarios_data)
        scenarios, _ = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        assert len(scenarios) == 1
        assert scenarios[0].name == "valid"

    def test_parse_skips_incomplete_scenarios(self):
        """Scenarios missing required fields should be skipped."""
        gen = ScenarioGenerator(offline=True)
        scenarios_data = [
            {"name": "valid", "category": "concurrent_execution",
             "description": "Complete"},
            {"name": "no_desc", "category": "concurrent_execution"},
            {"category": "concurrent_execution", "description": "No name"},
        ]
        content = _make_llm_response_json(scenarios=scenarios_data)
        scenarios, _ = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        assert len(scenarios) == 1

    def test_parse_empty_scenarios_raises(self):
        """Zero valid scenarios should raise LLMResponseError."""
        gen = ScenarioGenerator(offline=True)
        content = _make_llm_response_json(scenarios=[])
        with pytest.raises(LLMResponseError, match="zero valid scenarios"):
            gen._parse_llm_response(content, PYTHON_CATEGORIES)

    def test_parse_default_priority(self):
        """Missing priority should default to 'medium'."""
        gen = ScenarioGenerator(offline=True)
        scenarios_data = [
            {"name": "no_priority", "category": "concurrent_execution",
             "description": "No priority set"},
        ]
        content = _make_llm_response_json(scenarios=scenarios_data)
        scenarios, _ = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        assert scenarios[0].priority == "medium"

    def test_parse_preserves_test_config(self):
        gen = ScenarioGenerator(offline=True)
        content = _make_llm_response_json()
        scenarios, _ = gen._parse_llm_response(content, PYTHON_CATEGORIES)
        assert "parameters" in scenarios[0].test_config

    def test_parse_js_categories(self):
        """JavaScript-specific categories should be accepted for JS."""
        gen = ScenarioGenerator(offline=True)
        scenarios_data = [
            {"name": "async_test", "category": "async_failures",
             "description": "Test async failures"},
            {"name": "listener_test", "category": "event_listener_accumulation",
             "description": "Test listener leaks"},
        ]
        content = _make_llm_response_json(scenarios=scenarios_data)
        scenarios, _ = gen._parse_llm_response(content, JAVASCRIPT_CATEGORIES)
        assert len(scenarios) == 2


# ── Tests: Prompt Construction ──


class TestPromptConstruction:
    """Test that prompts include all required context."""

    def test_prompt_has_system_and_user(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        messages = gen._build_prompt(
            sample_ingestion,
            [m for m in sample_matches if m.profile],
            ["gunicorn"],
            "A web app for managing users",
            "python",
            PYTHON_CATEGORIES,
        )
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"

    def test_system_prompt_contains_categories(self):
        gen = ScenarioGenerator(offline=True)
        system = gen._build_system_prompt(PYTHON_CATEGORIES)
        assert "concurrent_execution" in system
        assert "blocking_io" in system
        assert "gil_contention" in system
        assert "JSON" in system

    def test_user_prompt_contains_project_info(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, ["gunicorn"],
            "A web app for managing users", "python",
        )
        assert "python" in user.lower()
        assert "500" in user  # total_lines
        assert "A web app for managing users" in user

    def test_user_prompt_contains_dependencies(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, ["gunicorn"],
            "intent", "python",
        )
        assert "flask" in user
        assert "sqlalchemy" in user
        assert "gunicorn" in user
        assert "Unrecognized" in user

    def test_user_prompt_contains_coupling_points(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, [], "intent", "python",
        )
        assert "Coupling Points" in user
        assert "high_fan_in" in user

    def test_user_prompt_contains_function_flows(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, [], "intent", "python",
        )
        assert "Function Call Graph" in user
        assert "app.main" in user

    def test_user_prompt_contains_failure_modes(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, [], "intent", "python",
        )
        assert "failure mode" in user.lower()

    def test_user_prompt_contains_file_structure(self, sample_ingestion, sample_matches):
        gen = ScenarioGenerator(offline=True)
        recognized = [m for m in sample_matches if m.profile]
        user = gen._build_user_prompt(
            sample_ingestion, recognized, [], "intent", "python",
        )
        assert "app.py" in user
        assert "models.py" in user


# ── Tests: LLM Mode with Mocked Backend ──


class TestLLMGeneration:
    """Test LLM-based generation with mocked HTTP calls."""

    def _mock_urlopen(self, response_json: str):
        """Create a mock for urllib.request.urlopen."""
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "choices": [{"message": {"content": response_json}}],
            "usage": {"prompt_tokens": 1000, "completion_tokens": 500},
            "model": "gemini-2.5-flash",
        }).encode("utf-8")
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    @patch("mycode.scenario.urllib.request.urlopen")
    def test_llm_generation_success(self, mock_urlopen, sample_ingestion, sample_matches):
        response_json = _make_llm_response_json()
        mock_urlopen.return_value = self._mock_urlopen(response_json)

        gen = ScenarioGenerator(llm_config=LLMConfig(api_key="test-key"))
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")

        assert len(result.scenarios) == 2
        assert result.model_used == "gemini-2.5-flash"
        assert result.token_usage["input_tokens"] == 1000
        assert result.token_usage["output_tokens"] == 500
        for s in result.scenarios:
            assert s.source == "llm"

    @patch("mycode.scenario.urllib.request.urlopen")
    def test_llm_fallback_on_network_error(self, mock_urlopen, sample_ingestion, sample_matches):
        """LLM failure should fall back to offline generation."""
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")

        gen = ScenarioGenerator(
            llm_config=LLMConfig(api_key="test-key", max_retries=0),
        )
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")

        # Should have offline scenarios
        assert len(result.scenarios) > 0
        assert result.model_used == "offline"
        assert len(result.warnings) > 0
        assert "unavailable" in result.warnings[0].lower()

    @patch("mycode.scenario.urllib.request.urlopen")
    def test_llm_fallback_on_bad_response(self, mock_urlopen, sample_ingestion, sample_matches):
        """Unparseable LLM response should fall back to offline."""
        mock_resp = self._mock_urlopen("not json at all {{{")
        # Override the content in the mock response
        mock_resp.read.return_value = json.dumps({
            "choices": [{"message": {"content": "not json at all {{{"}}],
            "usage": {},
            "model": "test",
        }).encode("utf-8")
        mock_urlopen.return_value = mock_resp

        gen = ScenarioGenerator(
            llm_config=LLMConfig(api_key="test-key", max_retries=0),
        )
        result = gen.generate(sample_ingestion, sample_matches,
                              "A web app", "python")

        assert len(result.scenarios) > 0
        assert len(result.warnings) > 0
        assert "invalid" in result.warnings[0].lower()

    @patch("mycode.scenario.urllib.request.urlopen")
    def test_llm_sends_correct_request(self, mock_urlopen, sample_ingestion, sample_matches):
        """Verify the HTTP request has correct structure."""
        response_json = _make_llm_response_json()
        mock_urlopen.return_value = self._mock_urlopen(response_json)

        gen = ScenarioGenerator(
            llm_config=LLMConfig(api_key="test-key", model="gpt-4o",
                                 base_url="https://api.openai.com/v1"),
        )
        gen.generate(sample_ingestion, sample_matches, "A web app", "python")

        # Verify the request was made
        assert mock_urlopen.called
        req = mock_urlopen.call_args[0][0]
        assert "openai.com" in req.full_url
        assert req.get_header("Authorization") == "Bearer test-key"
        assert req.get_header("Content-type") == "application/json"

        body = json.loads(req.data)
        assert body["model"] == "gpt-4o"
        assert "max_completion_tokens" in body
        assert "max_tokens" not in body
        assert "response_format" not in body
        assert len(body["messages"]) == 2


# ── Tests: Serialization Helpers ──


class TestSerializationHelpers:
    """Test prompt serialization functions."""

    def test_serialize_file_analyses(self):
        analyses = [
            FileAnalysis(
                file_path="app.py",
                functions=[FunctionInfo(name="main", file_path="app.py", lineno=1)],
                classes=[ClassInfo(name="App", file_path="app.py", lineno=10)],
                imports=[],
                lines_of_code=100,
            ),
        ]
        result = _serialize_file_analyses(analyses)
        assert "app.py" in result
        assert "100 lines" in result
        assert "App" in result
        assert "main" in result

    def test_serialize_file_analyses_with_parse_error(self):
        analyses = [
            FileAnalysis(file_path="broken.py", parse_error="Syntax error at line 5"),
        ]
        result = _serialize_file_analyses(analyses)
        assert "PARSE ERROR" in result
        assert "broken.py" in result

    def test_serialize_profiles(self):
        profile = _make_profile("flask")
        matches = [ProfileMatch(dependency_name="flask", profile=profile)]
        result = _serialize_profiles(matches)
        assert "flask" in result
        assert "failure mode" in result.lower()
        assert "test_failure" in result

    def test_serialize_function_flows(self):
        flows = [
            FunctionFlow(caller="a.func1", callee="b.func2", file_path="a.py", lineno=10),
        ]
        result = _serialize_function_flows(flows)
        assert "a.func1" in result
        assert "b.func2" in result

    def test_serialize_function_flows_with_limit(self):
        flows = [
            FunctionFlow(caller=f"f{i}", callee=f"g{i}", file_path="a.py", lineno=i)
            for i in range(50)
        ]
        result = _serialize_function_flows(flows, limit=5)
        assert "+45 more flows" in result

    def test_serialize_coupling_points(self):
        """Backward-compatible: no file_analyses passed."""
        points = [
            CouplingPoint(source="mod.func", targets=["a", "b", "c"],
                         coupling_type="high_fan_in",
                         description="Called by 3 functions"),
        ]
        result = _serialize_coupling_points(points)
        assert "high_fan_in" in result
        assert "3 dependents" in result
        assert "behavior:" not in result

    def test_serialize_coupling_points_with_behavior(self):
        """With file_analyses: includes behavior annotation."""
        fa = FileAnalysis(
            file_path="utils.py",
            functions=[FunctionInfo(name="calc", file_path="utils.py", lineno=1)],
            lines_of_code=10,
        )
        points = [
            CouplingPoint(source="utils.calc", targets=["a", "b"],
                         coupling_type="high_fan_in",
                         description="Called by 2 functions"),
        ]
        result = _serialize_coupling_points(points, [fa], "python")
        assert "behavior: pure_computation" in result


# ── Tests: Utility Functions ──


class TestUtilityFunctions:
    """Test helper functions."""

    def test_infer_measurements_memory(self):
        m = _infer_measurements("memory_profiling")
        assert "memory_mb" in m
        assert "memory_growth_mb" in m

    def test_infer_measurements_concurrent(self):
        m = _infer_measurements("concurrent_execution")
        assert "concurrent_active" in m
        assert "latency_p99_ms" in m

    def test_infer_measurements_data_volume(self):
        m = _infer_measurements("data_volume_scaling")
        assert "throughput" in m

    def test_infer_measurements_async(self):
        m = _infer_measurements("async_failures")
        assert "unhandled_rejections" in m

    def test_infer_measurements_state(self):
        m = _infer_measurements("state_management_degradation")
        assert "state_size_bytes" in m

    def test_infer_priority_high(self):
        template = {"failure_indicators": ["crash", "data_loss"]}
        assert _infer_priority_from_template(template) == "high"

    def test_infer_priority_medium(self):
        template = {"failure_indicators": ["timeout", "memory_growth"]}
        assert _infer_priority_from_template(template) == "medium"

    def test_infer_priority_low(self):
        template = {"failure_indicators": ["slow_response"]}
        assert _infer_priority_from_template(template) == "low"

    def test_safe_name(self):
        assert _safe_name("module.Class.method") == "module_Class_method"

    def test_safe_name_truncates(self):
        long_name = "a" * 100
        assert len(_safe_name(long_name)) <= 60


# ── Tests: Coupling Behavior Classification ──


class TestCouplingBehaviorClassification:
    """Test classification of coupling points by behavior type."""

    def _make_fa(self, file_path, functions=None, imports=None, classes=None):
        """Helper to create a FileAnalysis."""
        return FileAnalysis(
            file_path=file_path,
            functions=functions or [],
            classes=classes or [],
            imports=imports or [],
            lines_of_code=100,
        )

    def test_classify_error_handler_by_name(self):
        """Function named 'handle_error' → ERROR_HANDLER."""
        fa = self._make_fa("app.py", functions=[
            FunctionInfo(name="handle_error", file_path="app.py", lineno=1),
        ])
        cp = CouplingPoint(source="app.handle_error", targets=["a", "b"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.ERROR_HANDLER

    def test_classify_error_handler_by_decorator(self):
        """Function with 'app.errorhandler' decorator → ERROR_HANDLER."""
        fa = self._make_fa("app.py", functions=[
            FunctionInfo(name="not_found", file_path="app.py", lineno=1,
                        decorators=["app.errorhandler(404)"]),
        ])
        cp = CouplingPoint(source="app.not_found", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.ERROR_HANDLER

    def test_classify_dom_render(self):
        """File imports react + function calls useState → DOM_RENDER."""
        fa = self._make_fa("component.js", functions=[
            FunctionInfo(name="Dashboard", file_path="component.js", lineno=1,
                        calls=["useState", "useEffect", "render"]),
        ], imports=[
            ImportInfo(module="react", names=["useState"], is_from_import=True, lineno=1),
        ])
        cp = CouplingPoint(source="component.Dashboard", targets=["a", "b"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "javascript")
        assert result == CouplingBehaviorType.DOM_RENDER

    def test_classify_api_caller(self):
        """File imports requests + function calls get → API_CALLER."""
        fa = self._make_fa("api.py", functions=[
            FunctionInfo(name="fetch_data", file_path="api.py", lineno=1,
                        calls=["get", "json"]),
        ], imports=[
            ImportInfo(module="requests", lineno=1),
        ])
        cp = CouplingPoint(source="api.fetch_data", targets=["a", "b"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.API_CALLER

    def test_classify_state_setter_by_globals(self):
        """Function with globals_accessed → STATE_SETTER."""
        fa = self._make_fa("config.py", functions=[
            FunctionInfo(name="set_config", file_path="config.py", lineno=1,
                        globals_accessed=["CONFIG"]),
        ])
        cp = CouplingPoint(source="config.set_config", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.STATE_SETTER

    def test_classify_state_setter_shared_state(self):
        """CouplingPoint with coupling_type='shared_state' → STATE_SETTER."""
        fa = self._make_fa("store.py", functions=[
            FunctionInfo(name="update", file_path="store.py", lineno=1),
        ])
        cp = CouplingPoint(source="store.update", targets=["a"],
                          coupling_type="shared_state", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.STATE_SETTER

    def test_classify_pure_computation_fallback(self):
        """Function with no special signals → PURE_COMPUTATION."""
        fa = self._make_fa("utils.py", functions=[
            FunctionInfo(name="calculate", file_path="utils.py", lineno=1,
                        calls=["sum", "len"]),
        ])
        cp = CouplingPoint(source="utils.calculate", targets=["a", "b"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.PURE_COMPUTATION

    def test_classify_unresolved_source(self):
        """Source not found in file_analyses → PURE_COMPUTATION (fallback)."""
        fa = self._make_fa("other.py", functions=[
            FunctionInfo(name="other_func", file_path="other.py", lineno=1),
        ])
        cp = CouplingPoint(source="missing.module.func", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.PURE_COMPUTATION

    def test_error_priority_over_api(self):
        """Name 'handle_api_error' with API imports → ERROR_HANDLER (priority)."""
        fa = self._make_fa("api.py", functions=[
            FunctionInfo(name="handle_api_error", file_path="api.py", lineno=1,
                        calls=["get", "post"]),
        ], imports=[
            ImportInfo(module="requests", lineno=1),
        ])
        cp = CouplingPoint(source="api.handle_api_error", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "python")
        assert result == CouplingBehaviorType.ERROR_HANDLER

    def test_classify_react_usestate_setter_with_import(self):
        """setLoading in file importing react → STATE_SETTER (even without FunctionInfo)."""
        fa = self._make_fa("components/App.jsx", functions=[
            # setLoading is NOT a defined function — comes from useState()
            # Only other functions exist in the file
            FunctionInfo(name="App", file_path="components/App.jsx", lineno=1,
                        calls=["useState", "useEffect"]),
        ], imports=[
            ImportInfo(module="react", names=["useState"], is_from_import=True, lineno=1),
        ])
        # setLoading has no FunctionInfo — can't be resolved
        cp = CouplingPoint(source="components/App.setLoading", targets=["a", "b", "c"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [fa], "javascript")
        assert result == CouplingBehaviorType.STATE_SETTER

    def test_classify_react_setter_js_without_file_resolution(self):
        """setError in JS with no matching file → STATE_SETTER by name convention."""
        cp = CouplingPoint(source="unknown.setError", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [], "javascript")
        assert result == CouplingBehaviorType.STATE_SETTER

    def test_classify_set_prefix_not_triggered_for_python(self):
        """setConfig in Python without signals → PURE_COMPUTATION (no React convention)."""
        cp = CouplingPoint(source="unknown.setConfig", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [], "python")
        assert result == CouplingBehaviorType.PURE_COMPUTATION

    def test_classify_set_lowercase_not_triggered(self):
        """setup (lowercase after set) should NOT match set[A-Z] pattern."""
        cp = CouplingPoint(source="unknown.setup", targets=["a"],
                          coupling_type="high_fan_in", description="test")
        result = classify_coupling_point(cp, [], "javascript")
        assert result == CouplingBehaviorType.PURE_COMPUTATION


class TestCouplingPointGrouping:
    """Test grouping coupling points by behavior."""

    def _make_cp(self, source, coupling_type="high_fan_in"):
        return CouplingPoint(
            source=source, targets=["a", "b"],
            coupling_type=coupling_type, description="test",
        )

    def test_group_state_setters(self):
        """5 state setters → one dict entry with 5 items."""
        fas = [FileAnalysis(
            file_path="config.py", functions=[
                FunctionInfo(name=f"set_{i}", file_path="config.py", lineno=i,
                            globals_accessed=["CONFIG"])
                for i in range(5)
            ], lines_of_code=10,
        )]
        cps = [self._make_cp(f"config.set_{i}") for i in range(5)]
        groups = group_coupling_points_by_behavior(cps, fas, "python")
        assert CouplingBehaviorType.STATE_SETTER in groups
        assert len(groups[CouplingBehaviorType.STATE_SETTER]) == 5

    def test_group_mixed_types(self):
        """3 state setters + 2 API callers → correct bucketing."""
        # Each module gets its own file path
        state_fas = [
            FileAnalysis(
                file_path=f"config{i}.py", functions=[
                    FunctionInfo(name="setter", file_path=f"config{i}.py", lineno=1,
                                globals_accessed=["X"]),
                ], lines_of_code=10,
            ) for i in range(3)
        ]
        api_fas = [
            FileAnalysis(
                file_path=f"api{i}.py", functions=[
                    FunctionInfo(name="fetch", file_path=f"api{i}.py", lineno=1,
                                calls=["get"]),
                ], imports=[
                    ImportInfo(module="requests", lineno=1),
                ], lines_of_code=10,
            ) for i in range(2)
        ]
        cps = (
            [self._make_cp(f"config{i}.setter") for i in range(3)]
            + [self._make_cp(f"api{i}.fetch") for i in range(2)]
        )
        groups = group_coupling_points_by_behavior(cps, state_fas + api_fas, "python")
        assert len(groups[CouplingBehaviorType.STATE_SETTER]) == 3
        assert len(groups[CouplingBehaviorType.API_CALLER]) == 2

    def test_group_empty(self):
        """Empty list → empty dict."""
        groups = group_coupling_points_by_behavior([], [], "python")
        assert groups == {}


class TestOfflineCouplingBehavior:
    """Test that offline generation uses behavior-aware coupling scenarios."""

    def test_offline_state_setters_collapsed_python(self):
        """5 state setter CPs (Python globals) → 1 grouped scenario."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=100,
            file_analyses=[FileAnalysis(
                file_path="config.py",
                functions=[
                    FunctionInfo(name=f"set_{i}", file_path="config.py",
                                lineno=i, globals_accessed=["CONFIG"])
                    for i in range(5)
                ],
                lines_of_code=100,
            )],
            coupling_points=[
                CouplingPoint(
                    source=f"config.set_{i}", targets=["a", "b"],
                    coupling_type="shared_state",
                    description=f"State setter {i}",
                )
                for i in range(5)
            ],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [], "A web app", "python")
        coupling_scenarios = [s for s in result.scenarios if s.name.startswith("coupling_")]
        # All 5 state setters should collapse into 1 scenario
        assert len(coupling_scenarios) == 1
        assert "state_setters_group" in coupling_scenarios[0].name

    def test_offline_react_setters_collapsed(self):
        """React useState setters (setLoading, setError, etc.) → 1 grouped scenario."""
        setter_names = ["setLoading", "setError", "setRawScores",
                        "setNormScores", "setClassResult"]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=200,
            file_analyses=[FileAnalysis(
                file_path="components/App.jsx",
                functions=[
                    FunctionInfo(name="App", file_path="components/App.jsx",
                                lineno=1, calls=["useState", "useEffect"]),
                ],
                imports=[
                    ImportInfo(module="react", names=["useState"],
                             is_from_import=True, lineno=1),
                ],
                lines_of_code=200,
            )],
            coupling_points=[
                CouplingPoint(
                    source=f"components/App.{name}", targets=["a", "b", "c"],
                    coupling_type="high_fan_in",
                    description=f"'{name}' is called by 3 functions",
                )
                for name in setter_names
            ],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [], "A React app", "javascript")
        coupling_scenarios = [s for s in result.scenarios if s.name.startswith("coupling_")]
        # All 5 React state setters should collapse into 1 scenario
        assert len(coupling_scenarios) == 1
        assert "state_setters_group" in coupling_scenarios[0].name

    def test_offline_api_callers_individual(self):
        """3 API caller CPs → 3 individual scenarios."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=100,
            file_analyses=[FileAnalysis(
                file_path="api.py",
                functions=[
                    FunctionInfo(name=f"fetch_{i}", file_path="api.py",
                                lineno=i, calls=["get"])
                    for i in range(3)
                ],
                imports=[ImportInfo(module="requests", lineno=1)],
                lines_of_code=100,
            )],
            coupling_points=[
                CouplingPoint(
                    source=f"api.fetch_{i}", targets=["a", "b"],
                    coupling_type="high_fan_in",
                    description=f"API caller {i}",
                )
                for i in range(3)
            ],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [], "A web app", "python")
        coupling_scenarios = [s for s in result.scenarios if s.name.startswith("coupling_")]
        assert len(coupling_scenarios) == 3
        for s in coupling_scenarios:
            assert "coupling_api_" in s.name


class TestFilePathToModule:
    """Test _file_path_to_module helper."""

    def test_python_simple(self):
        assert _file_path_to_module("app.py", "python") == "app"

    def test_python_nested(self):
        assert _file_path_to_module("mypackage/utils.py", "python") == "mypackage.utils"

    def test_python_init(self):
        assert _file_path_to_module("mypackage/__init__.py", "python") == "mypackage"

    def test_js_simple(self):
        assert _file_path_to_module("app.js", "javascript") == "app"

    def test_js_index(self):
        assert _file_path_to_module("components/index.js", "javascript") == "components"

    def test_js_tsx(self):
        assert _file_path_to_module("components/App.tsx", "javascript") == "components/App"


# ── Tests: Integration with Real Profiles ──


class TestRealProfileIntegration:
    """Integration tests using real component library profiles."""

    MYCODE_SRC = Path(__file__).resolve().parent.parent / "src" / "mycode"

    @pytest.fixture
    def real_library(self):
        return ComponentLibrary()

    def test_offline_with_real_flask_profile(self, real_library):
        """Generate scenarios using real Flask profile."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=100,
            file_analyses=[
                FileAnalysis(file_path="app.py", lines_of_code=100,
                             imports=[ImportInfo(module="flask", lineno=1)]),
            ],
            dependencies=[DependencyInfo(name="flask", installed_version="3.1.0")],
        )
        flask_match = ProfileMatch(
            dependency_name="flask",
            profile=real_library.get_profile("python", "flask"),
            installed_version="3.1.0",
            version_match=True,
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [flask_match],
                              "A small web API for internal use", "python")

        assert len(result.scenarios) > 0
        # Flask profile has multiple stress templates and failure modes
        flask_scenarios = [s for s in result.scenarios if "flask" in s.name]
        assert len(flask_scenarios) >= 3

        # Should have concurrent execution scenarios (Flask template)
        categories = {s.category for s in result.scenarios}
        assert "concurrent_execution" in categories

    def test_offline_with_real_express_profile(self, real_library):
        """Generate scenarios using real Express profile for JavaScript."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=80,
            file_analyses=[],
            dependencies=[DependencyInfo(name="express", installed_version="4.21.0")],
        )
        express_match = ProfileMatch(
            dependency_name="express",
            profile=real_library.get_profile("javascript", "express"),
            installed_version="4.21.0",
            version_match=True,
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [express_match],
                              "A REST API for a mobile app", "javascript")

        assert len(result.scenarios) > 0
        # Should only have JS-valid categories
        for s in result.scenarios:
            assert s.category in JAVASCRIPT_CATEGORIES

    def test_offline_with_multiple_real_profiles(self, real_library):
        """Generate scenarios for a multi-dependency project."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=5,
            total_lines=1000,
            file_analyses=[],
            dependencies=[
                DependencyInfo(name="flask", installed_version="3.1.0"),
                DependencyInfo(name="sqlalchemy", installed_version="2.0.30"),
                DependencyInfo(name="requests", installed_version="2.32.3"),
            ],
            coupling_points=[
                CouplingPoint(
                    source="db.session", targets=["routes.get", "routes.post", "routes.delete"],
                    coupling_type="high_fan_in",
                    description="Database session used by 3 route handlers",
                ),
            ],
        )
        matches = [
            ProfileMatch(dependency_name="flask",
                         profile=real_library.get_profile("python", "flask"),
                         installed_version="3.1.0", version_match=True),
            ProfileMatch(dependency_name="sqlalchemy",
                         profile=real_library.get_profile("python", "sqlalchemy"),
                         installed_version="2.0.30", version_match=True),
            ProfileMatch(dependency_name="requests",
                         profile=real_library.get_profile("python", "requests"),
                         installed_version="2.32.3", version_match=True),
        ]
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches,
                              "Internal tool that queries external APIs and stores results in a database",
                              "python")

        assert len(result.scenarios) >= 10  # Multiple templates + failure modes + coupling
        # Should cover multiple categories
        categories = {s.category for s in result.scenarios}
        assert len(categories) >= 3

    def test_offline_with_mycode_own_source(self, real_library):
        """Generate scenarios for myCode's own codebase using real ingester."""
        ingester = ProjectIngester(
            project_path=self.MYCODE_SRC,
            skip_pypi_check=True,
        )
        ingestion = ingester.ingest()

        # Match stdlib imports against profiles
        all_imports = set()
        for analysis in ingestion.file_analyses:
            for imp in analysis.imports:
                top = imp.module.split(".")[0] if imp.module else ""
                if top:
                    all_imports.add(top)

        dep_dicts = [{"name": n} for n in sorted(all_imports)]
        matches = real_library.match_dependencies("python", dep_dicts)

        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches,
                              "A stress-testing CLI tool for AI-generated code", "python")

        assert isinstance(result, ScenarioGeneratorResult)
        # myCode has coupling points, so should generate some scenarios
        assert len(result.scenarios) >= 1


# ── Tests: Browser-Only Dependency Handling ──


class TestBrowserOnlyHandling:
    """Test browser-only deps are skipped entirely with a warning."""

    def test_browser_only_skips_library_tests(self):
        """Browser-only profile → no library-specific scenarios generated, warning emitted."""
        profile = _make_browser_only_profile("chartjs")
        match = ProfileMatch(
            dependency_name="chart.js",
            profile=profile,
            installed_version="4.4.7",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A charting app", "javascript")

        # No library-specific scenarios (templates or failure modes)
        chartjs_scenarios = [s for s in result.scenarios if s.name.startswith("chartjs_")]
        assert len(chartjs_scenarios) == 0

        # Warning should mention browser-rendered libraries
        assert len(result.warnings) >= 1
        assert "chart.js" in result.warnings[0]
        assert "browser-rendered" in result.warnings[0]
        assert "browser environment" in result.warnings[0]

    def test_non_browser_generates_normally(self):
        """Non-browser profile → uses regular stress_test_templates, no warning."""
        profile = _make_profile("express", "web_framework")
        match = ProfileMatch(
            dependency_name="express",
            profile=profile,
            installed_version="4.21.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A web server", "javascript")

        template_scenarios = [s for s in result.scenarios if s.name.startswith("express_")]
        assert len(template_scenarios) >= 1
        # No browser-only warning
        browser_warnings = [w for w in result.warnings if "browser-rendered" in w]
        assert len(browser_warnings) == 0

    def test_browser_only_no_failure_mode_scenarios(self):
        """Browser-only dep should NOT generate failure mode scenarios either."""
        profile = _make_browser_only_profile("chartjs")
        match = ProfileMatch(
            dependency_name="chart.js",
            profile=profile,
            installed_version="4.4.7",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A charting app", "javascript")

        failure_scenarios = [s for s in result.scenarios if s.name.endswith("_check")]
        assert len(failure_scenarios) == 0

    def test_browser_only_warning_lists_all_deps(self):
        """Warning should list all browser-only deps that were skipped."""
        profile1 = _make_browser_only_profile("chartjs")
        profile2 = _make_browser_only_profile("react")
        match1 = ProfileMatch(dependency_name="chart.js", profile=profile1)
        match2 = ProfileMatch(dependency_name="react", profile=profile2)
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match1, match2], "A charting app", "javascript")

        assert len(result.warnings) >= 1
        assert "chart.js" in result.warnings[0]
        assert "react" in result.warnings[0]

    def test_dom_render_coupling_js_skip_imports(self):
        """DOM_RENDER coupling points in JS should get skip_imports."""
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=100,
            file_analyses=[FileAnalysis(
                file_path="components/App.jsx",
                functions=[
                    FunctionInfo(
                        name="Dashboard", file_path="components/App.jsx",
                        lineno=1, calls=["useState", "render"],
                    ),
                ],
                imports=[
                    ImportInfo(module="react", names=["useState"],
                             is_from_import=True, lineno=1),
                ],
                lines_of_code=100,
            )],
            coupling_points=[
                CouplingPoint(
                    source="components/App.Dashboard",
                    targets=["a", "b"],
                    coupling_type="high_fan_in",
                    description="Render component",
                ),
            ],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [], "A React dashboard", "javascript")

        render_scenarios = [
            s for s in result.scenarios if s.name.startswith("coupling_render_")
        ]
        assert len(render_scenarios) >= 1
        for s in render_scenarios:
            assert s.test_config.get("skip_imports") is True


# ── Tests: Server Framework Handling ──


def _make_server_framework_profile(
    name: str, category: str = "web_framework",
) -> DependencyProfile:
    """Create a server_framework DependencyProfile for testing."""
    raw = {
        "identity": {
            "name": name,
            "pypi_name": name,
            "category": category,
            "description": f"Server framework test profile for {name}",
            "current_stable_version": "1.0.0",
            "min_supported_version": "1.0.0",
            "version_notes": {},
            "server_framework": True,
        },
        "scaling_characteristics": {"description": "test", "concurrency_model": "test",
                                    "bottlenecks": [], "scaling_limits": []},
        "memory_behavior": {"baseline_footprint_mb": 10, "growth_pattern": "test",
                           "known_leaks": [], "gc_behavior": "test"},
        "known_failure_modes": [
            {
                "name": "dev_server_in_production",
                "description": "Using dev server in production",
                "trigger_conditions": "Deploying with app.run()",
                "severity": "critical",
                "versions_affected": "all",
                "detection_hint": "app.run() without WSGI server",
            },
        ],
        "edge_case_sensitivities": [],
        "interaction_patterns": {
            "commonly_used_with": [],
            "known_conflicts": [],
            "dependency_chain_risks": [],
        },
        "stress_test_templates": [
            {
                "name": "concurrent_request_load",
                "category": "concurrent_execution",
                "description": "Concurrent requests to server",
                "parameters": {"concurrent": [1, 10, 100]},
                "expected_behavior": "Degrades gracefully",
                "failure_indicators": ["timeout", "crash"],
            },
            {
                "name": "large_payload_response",
                "category": "data_volume_scaling",
                "description": "Large JSON payload test",
                "parameters": {"payload_sizes_kb": [1, 10, 100]},
                "expected_behavior": "Memory proportional to response",
                "failure_indicators": ["MemoryError"],
            },
        ],
    }
    return DependencyProfile(
        identity=raw["identity"],
        scaling_characteristics=raw["scaling_characteristics"],
        memory_behavior=raw["memory_behavior"],
        known_failure_modes=raw["known_failure_modes"],
        edge_case_sensitivities=raw["edge_case_sensitivities"],
        interaction_patterns=raw["interaction_patterns"],
        stress_test_templates=raw["stress_test_templates"],
        raw=raw,
    )


class TestServerFrameworkHandling:
    """Test server framework deps route to standalone bodies with a warning."""

    def test_server_framework_scenarios_have_behavior(self):
        """Flask profile with server_framework=True → scenarios get behavior key."""
        profile = _make_server_framework_profile("flask")
        match = ProfileMatch(
            dependency_name="flask",
            profile=profile,
            installed_version="3.1.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A web app", "python")

        flask_scenarios = [s for s in result.scenarios if s.name.startswith("flask_")]
        assert len(flask_scenarios) >= 2
        for s in flask_scenarios:
            assert s.test_config.get("behavior") == "flask_server_stress", (
                f"Scenario '{s.name}' missing behavior key"
            )

    def test_server_framework_skips_failure_modes(self):
        """Server framework deps should NOT generate failure mode scenarios."""
        profile = _make_server_framework_profile("flask")
        match = ProfileMatch(
            dependency_name="flask",
            profile=profile,
            installed_version="3.1.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A web app", "python")

        failure_scenarios = [s for s in result.scenarios if s.name.endswith("_check")]
        assert len(failure_scenarios) == 0

    def test_non_server_framework_no_behavior(self):
        """Non-server-framework profile (e.g. pandas) should NOT get behavior key."""
        profile = _make_profile("pandas", "data_processing")
        match = ProfileMatch(
            dependency_name="pandas",
            profile=profile,
            installed_version="2.2.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A data app", "python")

        pandas_scenarios = [s for s in result.scenarios if s.name.startswith("pandas_")]
        assert len(pandas_scenarios) >= 1
        for s in pandas_scenarios:
            assert "behavior" not in s.test_config, (
                f"Non-server-framework scenario '{s.name}' should not have behavior"
            )

    def test_server_framework_warning_emitted(self):
        """Server framework deps should produce a warning about synthetic workloads."""
        profile = _make_server_framework_profile("flask")
        match = ProfileMatch(
            dependency_name="flask",
            profile=profile,
            installed_version="3.1.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A web app", "python")

        server_warnings = [w for w in result.warnings if "Server framework" in w]
        assert len(server_warnings) == 1
        assert "flask" in server_warnings[0]
        assert "synthetic workloads" in server_warnings[0]

    def test_server_framework_warning_lists_all_deps(self):
        """Warning should list all server framework deps."""
        flask_profile = _make_server_framework_profile("flask")
        fastapi_profile = _make_server_framework_profile("fastapi")
        matches = [
            ProfileMatch(dependency_name="flask", profile=flask_profile),
            ProfileMatch(dependency_name="fastapi", profile=fastapi_profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "A web app", "python")

        server_warnings = [w for w in result.warnings if "Server framework" in w]
        assert len(server_warnings) == 1
        assert "fastapi" in server_warnings[0]
        assert "flask" in server_warnings[0]

    def test_non_server_framework_no_warning(self):
        """Non-server-framework profile should not produce a server framework warning."""
        profile = _make_profile("pandas", "data_processing")
        match = ProfileMatch(
            dependency_name="pandas",
            profile=profile,
            installed_version="2.2.0",
            version_match=True,
        )
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, [match], "A data app", "python")

        server_warnings = [w for w in result.warnings if "Server framework" in w]
        assert len(server_warnings) == 0

    def test_real_flask_profile_has_server_framework(self):
        """Real Flask profile from disk should have server_framework=True."""
        library = ComponentLibrary()
        flask_profile = library.get_profile("python", "flask")
        assert flask_profile.server_framework is True

    def test_real_fastapi_profile_has_server_framework(self):
        """Real FastAPI profile from disk should have server_framework=True."""
        library = ComponentLibrary()
        fastapi_profile = library.get_profile("python", "fastapi")
        assert fastapi_profile.server_framework is True

    def test_real_streamlit_profile_has_server_framework(self):
        """Real Streamlit profile from disk should have server_framework=True."""
        library = ComponentLibrary()
        streamlit_profile = library.get_profile("python", "streamlit")
        assert streamlit_profile.server_framework is True

    def test_real_pandas_profile_not_server_framework(self):
        """Real Pandas profile should NOT have server_framework=True."""
        library = ComponentLibrary()
        pandas_profile = library.get_profile("python", "pandas")
        assert pandas_profile.server_framework is False


class TestProfileDeduplication:
    """Test that related packages sharing a profile produce one set of scenarios."""

    def test_duplicate_profiles_deduplicated(self):
        """langchain, langchain-core, langchain-community → one set of scenarios."""
        profile = _make_profile("langchain", "ai_framework")
        matches = [
            ProfileMatch(dependency_name="langchain", profile=profile),
            ProfileMatch(dependency_name="langchain-core", profile=profile),
            ProfileMatch(dependency_name="langchain-community", profile=profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An AI app", "python")

        # Only one set of profile-based scenarios, not 3x
        langchain_scenarios = [
            s for s in result.scenarios if s.name.startswith("langchain_")
        ]
        # _make_profile has 2 stress_test_templates + 1 failure mode
        template_scenarios = [
            s for s in langchain_scenarios if not s.name.endswith("_check")
        ]
        failure_scenarios = [
            s for s in langchain_scenarios if s.name.endswith("_check")
        ]
        assert len(template_scenarios) == 2, (
            f"Expected 2 template scenarios, got {len(template_scenarios)}: "
            f"{[s.name for s in template_scenarios]}"
        )
        assert len(failure_scenarios) == 1, (
            f"Expected 1 failure scenario, got {len(failure_scenarios)}: "
            f"{[s.name for s in failure_scenarios]}"
        )

    def test_deduplicated_scenarios_list_all_dep_names(self):
        """Deduplicated scenarios should list all related dep names in target_dependencies."""
        profile = _make_profile("langchain", "ai_framework")
        matches = [
            ProfileMatch(dependency_name="langchain", profile=profile),
            ProfileMatch(dependency_name="langchain-core", profile=profile),
            ProfileMatch(dependency_name="langchain-community", profile=profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An AI app", "python")

        langchain_scenarios = [
            s for s in result.scenarios if s.name.startswith("langchain_")
        ]
        for s in langchain_scenarios:
            assert set(s.target_dependencies) == {
                "langchain", "langchain-core", "langchain-community"
            }, f"Scenario '{s.name}' should list all 3 dep names"

    def test_dedup_warning_emitted(self):
        """When profiles are deduplicated, a warning should be emitted."""
        profile = _make_profile("langchain", "ai_framework")
        matches = [
            ProfileMatch(dependency_name="langchain", profile=profile),
            ProfileMatch(dependency_name="langchain-core", profile=profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An AI app", "python")

        dedup_warnings = [w for w in result.warnings if "deduplicated" in w]
        assert len(dedup_warnings) == 1
        assert "langchain" in dedup_warnings[0]

    def test_no_dedup_warning_for_unique_profiles(self):
        """No dedup warning when each dep has a unique profile."""
        flask_profile = _make_profile("flask", "web_framework")
        pandas_profile = _make_profile("pandas", "data_processing")
        matches = [
            ProfileMatch(dependency_name="flask", profile=flask_profile),
            ProfileMatch(dependency_name="pandas", profile=pandas_profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python")

        dedup_warnings = [w for w in result.warnings if "deduplicated" in w]
        assert len(dedup_warnings) == 0

    def test_unique_profiles_not_affected(self):
        """Unique profiles still generate their own scenarios normally."""
        flask_profile = _make_profile("flask", "web_framework")
        pandas_profile = _make_profile("pandas", "data_processing")
        matches = [
            ProfileMatch(dependency_name="flask", profile=flask_profile),
            ProfileMatch(dependency_name="pandas", profile=pandas_profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=1,
            total_lines=50,
            file_analyses=[],
        )
        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python")

        flask_scenarios = [s for s in result.scenarios if s.name.startswith("flask_")]
        pandas_scenarios = [s for s in result.scenarios if s.name.startswith("pandas_")]
        assert len(flask_scenarios) >= 2
        assert len(pandas_scenarios) >= 2


# ── Constraint-Driven Parameterisation Tests ──


class TestConstraintDrivenScenarios:
    """Tests for constraint-driven parameterisation (E2)."""

    def _make_basic_setup(self):
        """Return (ingestion, matches) for a basic Flask+pandas project."""
        flask_profile = _make_profile("flask", "web_framework")
        pandas_profile = _make_profile("pandas", "data_processing")
        matches = [
            ProfileMatch(dependency_name="flask", profile=flask_profile),
            ProfileMatch(dependency_name="pandas", profile=pandas_profile),
        ]
        ingestion = IngestionResult(
            project_path="/tmp/test",
            files_analyzed=3,
            total_lines=200,
            file_analyses=[],
        )
        return ingestion, matches

    def test_user_scale_overrides_concurrent_levels(self):
        """user_scale of 20 → concurrent levels [20, 30, 40, 60]."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()
        constraints = OperationalConstraints(user_scale=20)

        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python", constraints)

        concurrent_scenarios = [
            s for s in result.scenarios
            if s.category in ("concurrent_execution", "blocking_io", "gil_contention")
        ]
        assert len(concurrent_scenarios) > 0

        for s in concurrent_scenarios:
            params = s.test_config.get("parameters", {})
            if "concurrent" in params:
                levels = params["concurrent"]
                # Should be derived from user_scale=20: [20, 30, 40, 60]
                assert 20 in levels
                assert max(levels) == 60  # 3x stated
                assert all(lev >= 1 for lev in levels)
            # Should have user_stated_capacity
            assert s.test_config.get("user_stated_capacity") == 20

    def test_no_constraints_uses_defaults(self):
        """Without constraints, default ranges are used."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()

        gen = ScenarioGenerator(offline=True)
        result_none = gen.generate(ingestion, matches, "An app", "python")
        result_empty = gen.generate(
            ingestion, matches, "An app", "python",
            constraints=OperationalConstraints(),
        )

        # Without constraints, no constraint_scale should be set
        for s in result_none.scenarios:
            assert "constraint_scale" not in s.test_config
            assert "user_stated_capacity" not in s.test_config

    def test_max_payload_adjusts_data_sizes(self):
        """max_payload_mb sets data_sizes around the stated size."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()
        # Add an unrecognized dep to trigger data_volume_scaling scenario
        matches.append(
            ProfileMatch(dependency_name="customlib", profile=None),
        )
        constraints = OperationalConstraints(max_payload_mb=50.0)

        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python", constraints)

        data_scenarios = [
            s for s in result.scenarios
            if s.category == "data_volume_scaling"
        ]
        assert len(data_scenarios) > 0

        for s in data_scenarios:
            if "constraint_max_payload_mb" in s.test_config:
                assert s.test_config["constraint_max_payload_mb"] == 50.0

    def test_none_parameters_produce_warnings(self):
        """None constraint parameters generate warnings in the result."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()
        constraints = OperationalConstraints()  # All None

        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python", constraints)

        warning_text = " ".join(result.warnings)
        assert "user scale not specified" in warning_text.lower()
        assert "data type not specified" in warning_text.lower()

    def test_different_constraints_produce_different_scenarios(self):
        """Same project with different constraints yields different test configs."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()

        # Small scale
        c1 = OperationalConstraints(user_scale=5, max_payload_mb=1.0)
        gen = ScenarioGenerator(offline=True)
        r1 = gen.generate(ingestion, matches, "An app", "python", c1)

        # Large scale
        c2 = OperationalConstraints(user_scale=1000, max_payload_mb=500.0)
        r2 = gen.generate(ingestion, matches, "An app", "python", c2)

        # Extract concurrent levels from first concurrent scenario
        def get_concurrent(result):
            for s in result.scenarios:
                if "constraint_scale" in s.test_config:
                    return s.test_config["constraint_scale"]
            return None

        levels_small = get_concurrent(r1)
        levels_large = get_concurrent(r2)

        assert levels_small is not None
        assert levels_large is not None
        assert max(levels_small) == 15  # 3x of 5
        assert max(levels_large) == 3000  # 3x of 1000

    def test_constraint_data_type_added_to_config(self):
        """data_type constraint is added to data_volume scenarios."""
        from mycode.constraints import OperationalConstraints

        ingestion, matches = self._make_basic_setup()
        # Add an unrecognized dep to trigger data_volume_scaling scenario
        matches.append(
            ProfileMatch(dependency_name="customlib", profile=None),
        )
        constraints = OperationalConstraints(data_type="tabular")

        gen = ScenarioGenerator(offline=True)
        result = gen.generate(ingestion, matches, "An app", "python", constraints)

        data_scenarios = [
            s for s in result.scenarios
            if s.category == "data_volume_scaling"
        ]
        assert len(data_scenarios) > 0
        assert any(
            s.test_config.get("constraint_data_type") == "tabular"
            for s in data_scenarios
        )
