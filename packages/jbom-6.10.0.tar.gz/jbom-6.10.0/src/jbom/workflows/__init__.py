"""Workflow layer package.

This package provides lightweight workflow orchestration primitives.

At the moment it only includes a simple in-process registry used by the
application/CLI layer.
"""

from __future__ import annotations

__all__ = ["registry"]
