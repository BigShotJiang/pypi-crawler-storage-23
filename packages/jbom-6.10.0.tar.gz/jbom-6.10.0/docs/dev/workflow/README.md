# Workflow

Active work tracking and guidance for development process.

## Contents

- **NEXT.md** - Current priority tasks and next steps
- **QUICK_START.md** - Quick reference guide for getting started
- **WORK_LOG.md** - Session notes and progress tracking
- **GIT_WORKFLOW.md** - Git branching and commit patterns
- **HUMAN_WORKFLOW.md** - Guide for paired development and collaboration
- **planning/** - Phase planning and task breakdowns
- **completed/** - Archive of completed work with references
- **WIP/** - Work-in-progress notes and investigations

This directory contains active, evolving documentation for Phase 1 development.
