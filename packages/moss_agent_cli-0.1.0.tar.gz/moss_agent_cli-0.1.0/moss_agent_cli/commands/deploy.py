"""Deploy command implementation."""

import os
from pathlib import Path
from typing import Optional

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ..core.deployer import deploy_agent_package

console = Console()

# Load .env file from current directory if it exists
load_dotenv()


def deploy_command(
    directory: Optional[Path] = typer.Argument(
        None,
        help="Agent directory to deploy (defaults to current directory)",
    ),
    project_id: Optional[str] = typer.Option(
        None,
        "--project-id",
        "-p",
        help="Moss project ID (or set MOSS_PROJECT_ID env var)",
    ),
    project_key: Optional[str] = typer.Option(
        None,
        "--project-key",
        "-k",
        help="Moss project key (or set MOSS_PROJECT_KEY env var)",
    ),
    voice_agent_id: Optional[str] = typer.Option(
        None,
        "--voice-agent-id",
        "-v",
        help="Voice agent ID (or set MOSS_VOICE_AGENT_ID env var)",
    ),
    api_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help="Moss platform API URL (defaults to production)",
    ),
) -> None:
    """Deploy agent to Moss platform."""

    # Resolve directory
    agent_dir = directory or Path.cwd()
    if not agent_dir.exists():
        console.print(f"[red]Error:[/red] Directory not found: {agent_dir}")
        raise typer.Exit(1)

    # Load credentials from env or arguments
    project_id = project_id or os.getenv("MOSS_PROJECT_ID")
    project_key = project_key or os.getenv("MOSS_PROJECT_KEY")
    voice_agent_id = voice_agent_id or os.getenv("MOSS_VOICE_AGENT_ID")
    api_url = api_url or os.getenv("MOSS_PLATFORM_API_URL", "https://service.usemoss.dev")

    # Validate credentials
    if not project_id or not project_key or not voice_agent_id:
        console.print("[red]Error:[/red] Missing required credentials")
        console.print("\nProvide via options or environment variables:")
        console.print("  --project-id / MOSS_PROJECT_ID")
        console.print("  --project-key / MOSS_PROJECT_KEY")
        console.print("  --voice-agent-id / MOSS_VOICE_AGENT_ID")
        raise typer.Exit(1)

    console.print(f"\n[bold]Deploying agent from:[/bold] {agent_dir}")
    console.print(f"[dim]Project ID:[/dim] {project_id}")
    console.print(f"[dim]Voice Agent ID:[/dim] {voice_agent_id}\n")

    # Deploy with progress indicator
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Deploying agent...", total=None)

        try:
            result = deploy_agent_package(
                agent_dir=agent_dir,
                project_id=project_id,
                project_key=project_key,
                voice_agent_id=voice_agent_id,
                api_url=api_url,
            )

            progress.update(task, completed=True)

            if result.get("ok"):
                console.print("[green]✓[/green] Deployment successful!")
                if result.get("deployment_url"):
                    console.print(f"\n[bold]Deployment URL:[/bold] {result['deployment_url']}")
            else:
                console.print("[red]✗[/red] Deployment failed")
                if result.get("error"):
                    console.print(f"\n[red]Error:[/red] {result['error']}")
                raise typer.Exit(1)

        except Exception as exc:
            progress.update(task, completed=True)
            console.print(f"\n[red]Error:[/red] {exc}")
            raise typer.Exit(1)
