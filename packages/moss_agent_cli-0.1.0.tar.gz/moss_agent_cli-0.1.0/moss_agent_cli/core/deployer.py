"""Agent deployment logic."""

import tarfile
import tempfile
from pathlib import Path
from typing import Dict, Any

import httpx


def validate_agent_structure(agent_dir: Path) -> None:
    """
    Validate that the agent directory has required files.

    Args:
        agent_dir: Path to agent directory

    Raises:
        ValueError: If validation fails
    """
    # Check for either agent.py or main.py (or src/*/main.py pattern)
    agent_py = agent_dir / "agent.py"
    main_py = agent_dir / "main.py"

    # Also check for src/*/main.py pattern (like src/moss_voice_agent/main.py)
    src_main_files = list(agent_dir.glob("src/*/main.py"))

    entry_point = None
    if agent_py.exists():
        entry_point = agent_py
    elif main_py.exists():
        entry_point = main_py
    elif src_main_files:
        entry_point = src_main_files[0]

    if not entry_point:
        raise ValueError(
            "Missing entry point file. Agent directory must contain one of:\n"
            "  - agent.py (at root)\n"
            "  - main.py (at root)\n"
            "  - src/*/main.py (in src subdirectory)"
        )

    # Check that entry point uses moss_voice_agent_manager
    entry_content = entry_point.read_text()
    if "moss_voice_agent_manager" not in entry_content:
        raise ValueError(
            f"{entry_point.name} must import from moss_voice_agent_manager"
        )


def package_agent(agent_dir: Path) -> Path:
    """
    Package agent directory into a tarball.

    Args:
        agent_dir: Path to agent directory

    Returns:
        Path to created tarball

    Raises:
        ValueError: If packaging fails
    """
    # Create temporary tarball
    temp_dir = Path(tempfile.gettempdir())
    tarball_path = temp_dir / f"agent-{agent_dir.name}.tar.gz"

    # Files to exclude
    exclude_patterns = {
        ".env",
        "__pycache__",
        ".git",
        "*.pyc",
        ".venv",
        "venv",
        ".DS_Store",
    }

    def should_exclude(file_path: Path) -> bool:
        """Check if file should be excluded from package."""
        name = file_path.name
        # Check exact matches
        if name in exclude_patterns:
            return True
        # Check pattern matches (*.pyc, etc.)
        for pattern in exclude_patterns:
            if "*" in pattern:
                ext = pattern.replace("*", "")
                if name.endswith(ext):
                    return True
        # Check if in excluded directory
        for part in file_path.parts:
            if part in exclude_patterns:
                return True
        return False

    try:
        with tarfile.open(tarball_path, "w:gz") as tar:
            for item in agent_dir.rglob("*"):
                if item.is_file() and not should_exclude(item):
                    arcname = item.relative_to(agent_dir)
                    tar.add(item, arcname=arcname)

        return tarball_path

    except Exception as exc:
        raise ValueError(f"Failed to package agent: {exc}") from exc


def upload_agent_package(
    tarball_path: Path,
    project_id: str,
    project_key: str,
    voice_agent_id: str,
    api_url: str,
    poll_status: bool = True,
) -> Dict[str, Any]:
    """
    Upload agent package to Moss platform.

    Args:
        tarball_path: Path to agent tarball
        project_id: Moss project ID
        project_key: Moss project key
        voice_agent_id: Voice agent ID
        api_url: API base URL
        poll_status: Whether to poll for deployment status

    Returns:
        Deployment response

    Raises:
        httpx.HTTPError: If upload fails
    """
    endpoint = f"{api_url}/api/voice-agent/upload"
    print(f"DEBUG: Uploading to {endpoint}")

    headers = {
        "X-Project-Id": project_id,
        "X-Project-Key": project_key,
    }

    with open(tarball_path, "rb") as f:
        files = {
            "agent_package": ("agent.tar.gz", f, "application/gzip")
        }
        data = {
            "voice_agent_id": voice_agent_id,
        }

        with httpx.Client(timeout=30.0) as client:  # Quick upload timeout
            response = client.post(
                endpoint,
                headers=headers,
                files=files,
                data=data,
            )
            response.raise_for_status()
            result = response.json()

            # If async deployment (202 status), poll for status
            if response.status_code == 202 and poll_status:
                deployment_id = result.get("deployment_id")
                if deployment_id:
                    print(f"DEBUG: Polling status for deployment {deployment_id}")
                    final_status = poll_deployment_status(
                        deployment_id=deployment_id,
                        project_id=project_id,
                        project_key=project_key,
                        api_url=api_url,
                    )
                    return final_status

            return result


def poll_deployment_status(
    deployment_id: str,
    project_id: str,
    project_key: str,
    api_url: str,
    max_wait: int = 600,  # 10 minutes max
    poll_interval: int = 5,  # Check every 5 seconds
) -> Dict[str, Any]:
    """
    Poll deployment status until completion.

    Args:
        deployment_id: Deployment ID to check
        project_id: Moss project ID
        project_key: Moss project key
        api_url: API base URL
        max_wait: Maximum seconds to wait
        poll_interval: Seconds between polls

    Returns:
        Final deployment status
    """
    import time

    endpoint = f"{api_url}/api/voice-agent/deployment-status/{deployment_id}"
    headers = {
        "X-Project-Id": project_id,
        "X-Project-Key": project_key,
    }

    start_time = time.time()

    with httpx.Client(timeout=10.0) as client:
        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait:
                return {
                    "ok": False,
                    "error": f"Deployment timed out after {max_wait} seconds",
                    "status": "timeout",
                }

            try:
                response = client.get(endpoint, headers=headers)
                response.raise_for_status()
                status_data = response.json()

                status_value = status_data.get("status")
                print(f"DEBUG: Status = {status_value}")

                if status_value == "completed":
                    return {
                        "ok": True,
                        "deployment_url": status_data.get("deployment_url"),
                        "status": "completed",
                    }
                elif status_value == "failed":
                    return {
                        "ok": False,
                        "error": status_data.get("error", "Deployment failed"),
                        "status": "failed",
                    }

                # Still in progress, wait and retry
                time.sleep(poll_interval)

            except httpx.HTTPError as exc:
                print(f"DEBUG: Polling error: {exc}")
                time.sleep(poll_interval)


def deploy_agent_package(
    agent_dir: Path,
    project_id: str,
    project_key: str,
    voice_agent_id: str,
    api_url: str,
) -> Dict[str, Any]:
    """
    Deploy agent package to Moss platform.

    Args:
        agent_dir: Path to agent directory
        project_id: Moss project ID
        project_key: Moss project key
        voice_agent_id: Voice agent ID
        api_url: API base URL

    Returns:
        Deployment response
    """
    print(f"DEBUG: Starting deployment with API URL: {api_url}")

    # Validate agent structure
    validate_agent_structure(agent_dir)
    print("DEBUG: Validation passed")

    # Package agent
    tarball_path = package_agent(agent_dir)
    print(f"DEBUG: Packaged to {tarball_path}")

    try:
        # Upload to platform
        result = upload_agent_package(
            tarball_path=tarball_path,
            project_id=project_id,
            project_key=project_key,
            voice_agent_id=voice_agent_id,
            api_url=api_url,
        )
        return result

    except httpx.HTTPError as exc:
        print(f"DEBUG: HTTP Error: {exc}")
        print(f"DEBUG: Exception type: {type(exc)}")
        error_msg = str(exc)
        if hasattr(exc, "response") and exc.response is not None:
            print(f"DEBUG: Response status: {exc.response.status_code}")
            print(f"DEBUG: Response text: {exc.response.text[:500]}")
            try:
                error_detail = exc.response.json().get("detail", error_msg)
                error_msg = error_detail
            except Exception as e:
                print(f"DEBUG: Could not parse JSON: {e}")
                pass
        return {"ok": False, "error": error_msg}

    except Exception as exc:
        print(f"DEBUG: Unexpected error: {exc}")
        print(f"DEBUG: Exception type: {type(exc)}")
        import traceback
        traceback.print_exc()
        return {"ok": False, "error": str(exc)}

    finally:
        # Clean up tarball
        if tarball_path.exists():
            tarball_path.unlink()
