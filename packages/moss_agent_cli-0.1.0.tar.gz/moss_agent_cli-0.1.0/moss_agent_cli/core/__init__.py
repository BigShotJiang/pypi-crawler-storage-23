"""Core CLI logic."""
