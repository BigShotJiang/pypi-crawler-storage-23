"""Main CLI entry point."""

import typer
from rich.console import Console

from .commands.deploy import deploy_command

app = typer.Typer(
    name="moss-agent",
    help="Moss Agent CLI - Deploy voice agents to Moss platform",
    add_completion=False,
)

console = Console()

# Register commands
app.command(name="deploy")(deploy_command)


if __name__ == "__main__":
    app()
