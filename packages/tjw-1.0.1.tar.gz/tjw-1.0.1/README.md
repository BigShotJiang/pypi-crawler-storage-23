# tjw
一个私人的tjw类库



第一部分：使用频率最高（特别是更新版本）
最常用内容（如：tjw)
    MAC:
        删除旧打包资料      
            MAC:         rm -rf dist/ build/ src.egg-info/
            Windows:     Remove-Item -Recurse -Force dist, build, src.egg-info -ErrorAction SilentlyContinue
        打包              python setup.py sdist bdist_wheel
        上传              twine upload dist/*
        使用：             pip install --upgrade tjw --index-url https://pypi.org/simple/
        




other:

注册pypi账号：           https://pypi.org/account/register/
安装打包工具：           pip install setuptools wheel twine