class tjw:
    def helloworld(self):
        return "hello world!"

tjw = tjw()
