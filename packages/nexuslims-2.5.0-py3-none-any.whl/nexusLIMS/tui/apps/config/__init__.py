"""NexusLIMS Configuration TUI application package."""

from nexusLIMS.tui.apps.config.app import ConfiguratorApp

__all__ = ["ConfiguratorApp"]
