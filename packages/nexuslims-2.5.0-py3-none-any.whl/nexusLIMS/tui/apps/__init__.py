"""NexusLIMS TUI applications."""
