"""Instrument database management TUI application."""

from nexusLIMS.tui.apps.instruments.app import InstrumentManagerApp

__all__ = ["InstrumentManagerApp"]
