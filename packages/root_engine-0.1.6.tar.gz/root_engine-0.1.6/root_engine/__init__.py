"""
root_engine - A lightweight AI agent framework
"""

__version__ = "0.1.6"
__logo__ = "🌲"
