from __future__ import annotations

from enum import IntEnum


class WorkoutStatus(IntEnum):
    INCOMPLETE = 0
    COMPLETE = 1


class WorkoutDifficulty(IntEnum):
    EASY = 0
    MODERATE = 1
    CHALLENGING = 2
