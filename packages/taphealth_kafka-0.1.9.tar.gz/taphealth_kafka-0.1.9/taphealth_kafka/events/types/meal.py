from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

from ...serialization import dataclass_from_dict, dataclass_to_dict


class MealType(str, Enum):
    """Meal type classification."""

    BREAKFAST = "breakfast"
    LUNCH = "lunch"
    DINNER = "dinner"
    SNACK = "snack"


class MealVariation(str, Enum):
    EASY = "EASY"
    MODERATE = "MODERATE"
    CHALLENGING = "CHALLENGING"


@dataclass
class Macros:
    calories: float
    carbs: float
    fat: float
    protein: float
    fibre: float

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Macros:
        return dataclass_from_dict(cls, data)


@dataclass
class MealComponent:
    id: str
    name: str
    type: str
    quantity: str
    unit: str
    macros: Macros
    is_vegetarian: bool
    variation: MealVariation | None = None
    is_cheat: bool | None = None
    alternate_units: dict[str, float] | None = None
    weight_in_grams: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MealComponent:
        return dataclass_from_dict(cls, data)
