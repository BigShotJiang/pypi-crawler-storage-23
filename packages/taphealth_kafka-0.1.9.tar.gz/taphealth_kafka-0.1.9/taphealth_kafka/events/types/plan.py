from enum import Enum


class PlanUpdatedTrigger(str, Enum):
    """Trigger type for plan update events.

    Mirrors the TypeScript enum in kafka/src/types/plan.ts.
    """

    LAB_REPORT = "LabReport"
    SYMPTOM = "Symptom"
    ROUTINE = "Routine"
