from __future__ import annotations

from enum import IntEnum


class MetricType(IntEnum):
    WEIGHT = 0
    HBA1C = 1
    BLOOD_SUGAR = 2
