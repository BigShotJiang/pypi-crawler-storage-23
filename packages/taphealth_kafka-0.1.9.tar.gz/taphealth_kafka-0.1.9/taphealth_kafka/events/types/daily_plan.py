from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any

from ...serialization import dataclass_from_dict, dataclass_to_dict


class DailyTaskType(IntEnum):
    DIET_LOGGING = 0
    STEP_COUNT = 1
    EXERCISE_LOGGING = 2
    GLUCOSE_LOGGING = 3
    CUSTOM = 4


class HabitKey(IntEnum):
    GLUCOSE_LOG_TIMELY = 0
    GLUCOSE_LOG_RANDOM = 1
    GLUCOSE_CHECK_NOW = 2
    GLUCOSE_INTERPRET_RANGE = 3
    DIET_LOG_BREAKFAST = 4
    DIET_LOG_LUNCH = 5
    DIET_LOG_DINNER = 6
    DIET_LOG_SNACK_MORNING = 7
    DIET_LOG_SNACK_EVENING = 8
    DIET_LOG_ANY = 9
    DIET_HEALTHY_CHOICE = 10
    DIET_PLAN_MEALS = 11
    STEPS_MEET_DAILY_TARGET = 12
    STEPS_INCREASE_ACTIVITY = 13
    STEPS_LOG_MANUAL = 14
    EXERCISE_LOG_SESSION = 15
    EXERCISE_COMPLETE_PLANNED = 16
    EXERCISE_START_NOW = 17
    EXERCISE_INCREASE_FREQUENCY = 18
    EXERCISE_SCHEDULE_SESSION = 19
    CUSTOM = 20


@dataclass
class TaskTarget:
    unit: str
    initial: int
    current: int

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskTarget:
        return dataclass_from_dict(cls, data)


@dataclass
class DailyTask:
    type: DailyTaskType
    description: str
    target: TaskTarget
    habit_key: HabitKey
    is_micro_challenge: bool
    current_progress: int

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DailyTask:
        return dataclass_from_dict(cls, data)
