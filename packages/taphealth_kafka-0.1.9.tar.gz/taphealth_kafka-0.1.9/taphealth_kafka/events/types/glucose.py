from __future__ import annotations

from enum import IntEnum


class GlucoseType(IntEnum):
    FASTING = 0
    PRE_LUNCH = 1
    PRE_DINNER = 2
    POST_BREAKFAST = 3
    POST_LUNCH = 4
    POST_DINNER = 5
    RANDOM = 6


class GlucoseRange(IntEnum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    VERY_HIGH = 3
    VERY_LOW = 4
