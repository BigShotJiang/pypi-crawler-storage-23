from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .types.plan import PlanUpdatedTrigger


@dataclass
class PlanUpdatedData:
    """
    Data structure for plan-updated events.

    Represents a plan update triggered by lab reports, symptoms, or routine.
    Used with the PLAN_UPDATED topic.

    Mirrors the TypeScript interface in kafka/src/events/plan-updated.ts.

    Attributes:
        user_id (str): Unique identifier for the user.
        trigger (PlanUpdatedTrigger): What triggered the plan update.
        guidelines (dict): Optional module-to-content mapping of guidelines.

    Examples:
        >>> from taphealth_kafka.events import PlanUpdatedData
        >>> from taphealth_kafka.events.types import PlanUpdatedTrigger
        >>> data = PlanUpdatedData(
        ...     user_id="user-123",
        ...     trigger=PlanUpdatedTrigger.LAB_REPORT,
        ...     guidelines={"NUTRITION": "Reduce sugar intake"},
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    trigger: PlanUpdatedTrigger = PlanUpdatedTrigger.ROUTINE
    guidelines: Optional[Dict[str, str]] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        result: Dict[str, Any] = {
            "userId": self.user_id,
            "trigger": self.trigger.value,
        }
        if self.guidelines:
            result["guidelines"] = self.guidelines
        return result
