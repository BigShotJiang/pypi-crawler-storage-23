from __future__ import annotations

import dataclasses
import json
import logging
from abc import ABC, abstractmethod
from typing import Any

from .client import KafkaClient
from .serialization import dataclass_to_dict
from .topics import Topics

logger = logging.getLogger(__name__)


class KafkaProducer(ABC):
    """
    Abstract base class for Kafka producers.

    This class provides a high-level interface for producing messages to Kafka topics.
    Subclasses must implement the `topic` property to specify which topic to produce to.
    Messages are automatically serialized to JSON with support for dataclasses and datetime objects.

    Note:
        The ``send()`` method is synchronous — it flushes after each message and blocks
        until delivery is confirmed. For high-throughput scenarios consider batching
        at the application level.

    Attributes:
        client: KafkaClient instance managing the connection.

    Examples:
        >>> class UserEventProducer(KafkaProducer):
        ...     @property
        ...     def topic(self) -> Topics:
        ...         return Topics.PROFILE_UPDATED
        ...
        >>> producer = UserEventProducer(kafka_client)
        >>> producer.send({"userId": "123", "field": "email"})
    """

    def __init__(self, client: KafkaClient) -> None:
        """
        Initialize the producer with a KafkaClient instance.

        Args:
            client: KafkaClient instance that manages the Kafka connection.
        """
        self.client = client
        self._producer = client.producer
        self._delivery_error: Exception | None = None

    @property
    @abstractmethod
    def topic(self) -> Topics:
        """
        Abstract property that must return the target topic.

        Returns:
            Topics: The Topics enum value for this producer.

        Examples:
            >>> @property
            ... def topic(self) -> Topics:
            ...     return Topics.GLUCOSE_LOGGED
        """
        pass

    def _delivery_callback(self, err: Any, msg: Any) -> None:
        """
        Internal callback invoked on message delivery success or failure.

        Args:
            err: Error object if delivery failed, None if successful.
            msg: Message object containing delivery metadata.
        """
        if err is not None:
            self._delivery_error = err
            logger.error("Message delivery failed: %s", err)
        else:
            logger.debug("Message delivered to %s [%s]", msg.topic(), msg.partition())

    def send(self, data: dict) -> None:
        """
        Send a message to the configured Kafka topic.

        The message is automatically serialized to JSON and sent synchronously
        with a 10-second timeout. The method blocks until delivery is confirmed
        or fails.

        Args:
            data (dict): Message data to send. Can be a dict, dataclass with to_dict(),
                or any JSON-serializable object. Datetime and dataclass objects are
                automatically handled.

        Raises:
            Exception: If message delivery fails or times out.

        Examples:
            >>> producer.send({"userId": "123", "action": "login"})
            >>>
            >>> from taphealth_kafka.events import GlucoseLoggedData
            >>> glucose_data = GlucoseLoggedData(...)
            >>> producer.send(glucose_data.to_dict())
        """
        try:
            self._delivery_error = None
            serialized_data = json.dumps(data, default=self._json_serializer)

            self._producer.produce(
                topic=self.topic.value,
                value=serialized_data.encode("utf-8"),
                callback=self._delivery_callback,
            )

            # Block until the message is delivered (or timeout)
            remaining = self._producer.flush(timeout=10)

            if remaining > 0:
                raise Exception(f"Failed to deliver {remaining} message(s)")

            if self._delivery_error is not None:
                raise Exception(f"Delivery failed: {self._delivery_error}")

            logger.info("Data sent to Kafka topic %s", self.topic.value)
        except Exception as e:
            logger.error("Error sending data to Kafka: %s", e)
            raise

    def _json_serializer(self, obj: Any) -> Any:
        """
        Custom JSON serializer for objects not natively supported by json.dumps().

        Handles dataclass objects (via ``dataclass_to_dict``) and datetime objects
        (via ``isoformat()``).

        Args:
            obj: Object to serialize.

        Returns:
            Serializable representation of the object.

        Raises:
            TypeError: If the object type cannot be serialized.
        """
        if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
            return dataclass_to_dict(obj)
        if hasattr(obj, "isoformat"):
            return obj.isoformat()
        raise TypeError(f"Type {type(obj)} not serializable")
