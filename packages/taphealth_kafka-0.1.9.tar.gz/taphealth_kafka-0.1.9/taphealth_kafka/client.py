from __future__ import annotations

import logging

from confluent_kafka import Consumer, KafkaException, Producer
from confluent_kafka.admin import AdminClient
from confluent_kafka.cimpl import NewTopic

from .topics import Topics

logger = logging.getLogger(__name__)


class KafkaClient:
    """
    Main client for managing Kafka connections and resources.

    This class handles connections to Kafka brokers and provides access to
    producer, consumer, and admin client instances.

    Supports the context manager protocol for safe resource cleanup::

        with KafkaClient() as client:
            client.connect(["localhost:9092"])
            # ... use client ...
        # disconnect() called automatically

    Examples:
        >>> client = KafkaClient()
        >>> client.connect(["localhost:9092"])
        >>> producer = client.producer
        >>> client.disconnect()
    """

    def __init__(self) -> None:
        """Initialize the Kafka client with default state."""
        self._admin: AdminClient | None = None
        self._producer: Producer | None = None
        self._consumers: list[Consumer] = []
        self._connected: bool = False
        self._bootstrap_servers: list[str] = []

    def __enter__(self) -> KafkaClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.disconnect()

    @property
    def bootstrap_servers(self) -> list[str]:
        """
        Get the list of bootstrap server addresses.

        Returns:
            List[str]: List of Kafka broker addresses in the format "host:port".

        Raises:
            ValueError: If accessed before calling connect().
        """
        if not self._connected:
            raise ValueError("Cannot access bootstrap servers until connected")
        return self._bootstrap_servers

    @property
    def admin(self) -> AdminClient:
        """
        Get the AdminClient instance for cluster operations.

        Returns:
            AdminClient: Confluent-kafka AdminClient instance for managing
                topics and cluster metadata.

        Raises:
            ValueError: If accessed before calling connect().
        """
        if not self._connected:
            raise ValueError("Cannot access admin client until connected")
        return self._admin

    @property
    def producer(self) -> Producer:
        """
        Get or create the Producer instance.

        Lazily initializes a Producer on first access. The producer is
        configured with the bootstrap servers from the connection.

        Returns:
            Producer: Confluent-kafka Producer instance for publishing messages.

        Raises:
            ValueError: If accessed before calling connect().
        """
        if self._producer is None:
            if not self._connected:
                raise ValueError("Cannot access producer until connected")
            self._producer = Producer({"bootstrap.servers": ",".join(self._bootstrap_servers)})
        return self._producer

    def create_consumer(self, group_id: str, **kwargs) -> Consumer:
        """
        Create a Consumer instance with the specified configuration.

        This method creates a Confluent-kafka Consumer with automatic configuration
        mapping from snake_case to dot.notation format. Common configuration options
        are automatically translated for convenience.

        Args:
            group_id (str): Consumer group ID for coordinating consumption across
                multiple consumer instances.
            **kwargs: Additional consumer configuration options. Common options include:
                - auto_offset_reset (str): "earliest" or "latest". Where to start
                    consuming when no committed offset exists.
                - enable_auto_commit (bool): Whether to automatically commit offsets.
                    Default is True.
                - session_timeout_ms (int): Timeout for detecting consumer failures.
                - max_poll_interval_ms (int): Maximum time between poll() calls.

        Returns:
            Consumer: Configured Confluent-kafka Consumer instance.

        Raises:
            ValueError: If called before connect().

        Examples:
            >>> consumer = client.create_consumer(
            ...     group_id="my-group",
            ...     auto_offset_reset="earliest",
            ...     enable_auto_commit=True
            ... )
        """
        if not self._connected:
            raise ValueError("Cannot create consumer until connected")

        # Map kafka-python style kwargs to confluent-kafka config
        config = {
            "bootstrap.servers": ",".join(self._bootstrap_servers),
            "group.id": group_id,
        }

        # Map common config keys from snake_case to dot.notation
        key_mapping = {
            "auto_offset_reset": "auto.offset.reset",
            "enable_auto_commit": "enable.auto.commit",
            "session_timeout_ms": "session.timeout.ms",
            "max_poll_interval_ms": "max.poll.interval.ms",
        }

        for old_key, new_key in key_mapping.items():
            if old_key in kwargs:
                config[new_key] = kwargs.pop(old_key)

        # Remove kafka-python specific kwargs that don't apply
        kwargs.pop("value_deserializer", None)
        kwargs.pop("key_deserializer", None)

        # Add any remaining kwargs directly (already in confluent format)
        config.update(kwargs)

        consumer = Consumer(config)
        self._consumers.append(consumer)
        return consumer

    def connect(
        self,
        bootstrap_servers: list[str],
        *,
        auto_create_topics: bool = True,
    ) -> None:
        """
        Connect to Kafka brokers and initialize admin client.

        Establishes a connection to the specified Kafka brokers. By default,
        automatically creates all topics defined in the Topics enum if they
        don't exist.

        Args:
            bootstrap_servers (List[str]): List of Kafka broker addresses in the
                format ["host1:port1", "host2:port2", ...].
            auto_create_topics (bool): Whether to create all Topics enum values
                on connect. Set False if the client should not manage topics.
                Defaults to True.

        Raises:
            Exception: If connection fails or topics cannot be created.

        Examples:
            >>> client = KafkaClient()
            >>> client.connect(["localhost:9092"])
            >>> client.connect(["broker1:9092"], auto_create_topics=False)
        """
        try:
            self._bootstrap_servers = bootstrap_servers
            self._admin = AdminClient(
                {
                    "bootstrap.servers": ",".join(bootstrap_servers),
                    "client.id": "taphealth-kafka-admin",
                }
            )
            self._connected = True

            if auto_create_topics:
                topics = [topic.value for topic in Topics]
                self.create_topics(topics)

            logger.info("Connected to Kafka cluster at %s", bootstrap_servers)
        except Exception as e:
            logger.error("Error connecting to Kafka cluster: %s", e)
            raise

    def create_topics(
        self,
        topics: list[str],
        *,
        num_partitions: int = 1,
        replication_factor: int = 1,
    ) -> None:
        """
        Create Kafka topics if they don't already exist.

        Args:
            topics (List[str]): List of topic names to create.
            num_partitions (int): Number of partitions per topic. Defaults to 1.
            replication_factor (int): Replication factor per topic. Defaults to 1.
                Set to 3 for production fault tolerance.

        Raises:
            ValueError: If called before connect().
            KafkaException: If topic creation fails for reasons other than
                the topic already existing.

        Examples:
            >>> client.create_topics(["user-events", "order-events"])
            >>> client.create_topics(["events"], num_partitions=3, replication_factor=3)
        """
        if not self._connected or self._admin is None:
            raise ValueError("Cannot create topics: not connected to Kafka")

        try:
            # Get existing topics from cluster metadata
            cluster_metadata = self._admin.list_topics(timeout=10)
            existing_topics = set(cluster_metadata.topics.keys())
            topics_to_create = [topic for topic in topics if topic not in existing_topics]

            if not topics_to_create:
                logger.info("All topics already exist")
                return

            new_topics = [
                NewTopic(
                    topic=topic,
                    num_partitions=num_partitions,
                    replication_factor=replication_factor,
                )
                for topic in topics_to_create
            ]

            # create_topics returns a dict of futures
            futures = self._admin.create_topics(new_topics)

            # Wait for each topic creation to complete
            for topic, future in futures.items():
                try:
                    future.result()  # Block until topic is created
                    logger.info("Created topic: %s", topic)
                except KafkaException as e:
                    if "TOPIC_ALREADY_EXISTS" in str(e):
                        logger.info("Topic %s already exists", topic)
                    else:
                        raise

            logger.info("Created topics: %s", topics_to_create)
        except KafkaException as e:
            if "TOPIC_ALREADY_EXISTS" in str(e):
                logger.info("Topics already exist")
            else:
                logger.error("Error creating topics: %s", e)
                raise
        except Exception as e:
            logger.error("Error creating topics: %s", e)
            raise

    def disconnect(self) -> None:
        """
        Disconnect from Kafka and clean up resources.

        Flushes any pending messages in the producer, closes all consumers,
        and resets the connection state. Should be called when shutting down
        the application or when the Kafka client is no longer needed.

        Examples:
            >>> client.disconnect()
        """
        if self._producer:
            self._producer.flush()  # Ensure all messages are delivered
            self._producer = None

        for consumer in self._consumers:
            consumer.close()
        self._consumers.clear()

        # AdminClient doesn't have a close method in confluent-kafka
        self._admin = None

        self._connected = False
        logger.info("Disconnected from Kafka")
