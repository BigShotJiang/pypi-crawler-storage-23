import os
from . import data_processing as dp
from . import acquisition_parameters as ap
from . import image_processing as ip
import SimpleITK as sitk
from . import feature_extraction as fe
import pandas as pd
from . import dataset_manipulation as dm

def extraction(dicoms, scan_types_dict, scan_types, segmentation_file_path, file_header, file_ender, author, procedure, manual_segmentation_file_path=None, clinical_path=None, clinical_features_list=None,objective=None, num_patients=None, nifti_directory=".\\niftis", features_directory=".\\radiomics", segmentation_dir = '.\\segmentations', filters=None, params=None, labels=[1], batch_size=5, feature_filename="radiomics_features", latex_sections=['Information', 'Paragraphs', 'all_tables', 'Tables']):
    """
    Function to extract features from dicom files given segmentations and clinical data.

    Parameters:

    * parent_file_path (str): path to the parent directory for data
    
    * scan_types_dict (dict): dictionary of terms used to describe the same file type
    
    * scan_types (list[str]): list of scan types to be extracted
    
    * segmentation_file_path (str): file path for directory containing segmentations
    
    * file_header (str): part of file name before patient ID
    
    * file_ender (str): part of file name after patient ID
    
    * manual_segmentation_file_path (str): file path for directory containing manual segmentations; if patient segmentation is present then use that segmentation instead
    
    * clinical_path (str): file path for clinical data
    
    * clinical_features (list): list of clinical features to extract
    
    * objective (str): objective to predict

    * num_patients (int): Number of patients to evaluate. Defaults to None (total number found in getting patients step)
    
    * nifti_directory (str): directory to save niftis to. Default is ".\\niftis" 
    
    * features_directory (str): directory to save features to. Default is ".\\radiomics" 
    
    * segmentation_directory (str): directory to save segmentations to. Default is ".\\segmentations" 
    
    * filters (dict, optional): Dictionary of filters to apply. Defaults to None.

    * params (dict or str, optional): dictionary or name of .yaml file for specifying parameters. Default is None.

    * labels (list): list of segmentation labels to use when extracting features. Default is [1].

    * batch_size (int): Number of patients to process in each batch when extracting features. Default is 5.

    * features_filename (str): Filename to save csv of features to. Default is radiomics_features

    * latex_sections (list[str]): list of sections to include in the latex output. Default is ['Information', 'Paragraphs', 'all_tables', 'Tables']
    """

    patients_list, subdirs_list, segmentations_list, segmentations, auto_segmentations, manual_segmentations, both_patients_list, both_subdirs_list, target, both_target, clinical_features, both_clinical_features = dp.get_patients(dicoms, scan_types_dict, scan_types, segmentation_file_path, file_header, file_ender, author, manual_segmentation_file_path=manual_segmentation_file_path, clinical_path=clinical_path, clinical_features=clinical_features_list,objective=objective, latex_sections=latex_sections)  # Get patients and subdirectories
    #print(dp.get_patients(dicoms, scan_types_dict, scan_types, segmentation_file_path, file_header, file_ender, author, manual_segmentation_file_path=manual_segmentation_file_path, clinical_path=clinical_path, clinical_features=clinical_features_list,objective=objective, latex_sections=latex_sections)  )
    print('got patients and acquisition parameters')
    ids_list = [file_header + patient + file_ender for patient in patients_list] 
    both_ids_list = [file_header + patient + file_ender for patient in both_patients_list]  
    os.makedirs(segmentation_dir, exist_ok=True)
    os.makedirs(nifti_directory, exist_ok=True)
    os.makedirs(features_directory, exist_ok=True)
    os.makedirs(".\\both_niftis", exist_ok=True)
    if num_patients is None:
        num_patients = len(subdirs_list)
    niftis = dp.extract_niftis(subdirs_list[0:num_patients], patients_list[0:num_patients], segmentations_list[0:num_patients], segmentation_file_path, scan_types, nifti_directory=nifti_directory)
    if manual_segmentation_file_path is not None:
        os.chdir("..")
        both_niftis = dp.extract_niftis(both_subdirs_list[0:num_patients], both_patients_list[0:num_patients], auto_segmentations[0:num_patients], manual_segmentation_file_path, scan_types, nifti_directory=".\\both_niftis")
    print('got niftis')
    os.chdir("..")
    os.chdir(nifti_directory)
    segmentations_list.sort()
    manual_segmentations.sort()
    auto_segmentations.sort()
    if len(procedure) > 0:
            # processed_niftis_both, processed_auto_segmentations = ip.process_niftis(niftis[0:num_patients], auto_segmentations, procedure)
    # _, processed_manual_segmentations = ip.process_niftis(niftis[0:num_patients], manual_segmentations, procedure)
        processed_niftis, processed_segmentations = ip.process_niftis(niftis[0:num_patients], segmentations_list[0:num_patients], procedure)
        os.chdir("..")
        os.chdir(".\\both_niftis")
        if manual_segmentation_file_path is not None:
            both_processed_niftis, manual_processed_segmentations = ip.process_niftis(both_niftis[0:num_patients], manual_segmentations[0:num_patients], procedure)
            _, auto_processed_segmentations = ip.process_niftis(both_niftis[0:num_patients], auto_segmentations[0:num_patients], procedure)
        print('processed niftis and segmentations')
    else:
        processed_niftis = niftis
        processed_segmentations = segmentations   
    os.chdir("..")
    fe.extract_features_from_niftis(processed_niftis, processed_segmentations, f"{feature_filename}.csv", scan_types, procedure, author, nifti_directory=nifti_directory, file_directory=features_directory, params=params, filters=filters, labels=labels, info_filename = f"{feature_filename}.txt", target=target, ids_list=ids_list, clinical=clinical_features, batch_size=batch_size)  # Extract features from the NIfTIs and their segmentations
    if manual_segmentation_file_path is not None:
        os.chdir("..")
        fe.extract_features_from_niftis(both_processed_niftis, manual_processed_segmentations, f"manual_{feature_filename}.csv", scan_types, procedure, author, nifti_directory=".\\both_niftis", file_directory=features_directory, params=params, filters=filters, labels=labels, info_filename = f"manual_{feature_filename}.txt", target=both_target, ids_list=ids_list, clinical=both_clinical_features, batch_size=batch_size)  # Extract features from the NIfTIs and their segmentations
        os.chdir("..")
        fe.extract_features_from_niftis(both_processed_niftis, auto_processed_segmentations, f"auto_{feature_filename}.csv", scan_types, procedure, author, nifti_directory=".\\both_niftis", file_directory=features_directory, params=params, filters=filters, labels=labels, info_filename = f"auto_{feature_filename}.txt", target=both_target, ids_list=ids_list, clinical=both_clinical_features, batch_size=batch_size)  # Extract features from the NIfTIs and their segmentations