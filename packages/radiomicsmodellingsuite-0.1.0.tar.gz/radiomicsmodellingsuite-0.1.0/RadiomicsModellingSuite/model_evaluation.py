import pickle
import os
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score, confusion_matrix, roc_curve, precision_recall_curve
from sklearn.base import clone
from sklearn.utils import resample
from sklearn.model_selection import StratifiedKFold, cross_val_score, ParameterGrid
from sklearn.model_selection import GridSearchCV
import pandas as pd
import matplotlib.pyplot as plt
from .model_calibration import pava, create_stepwise_function, get_logits
import numpy as np
import seaborn as sns
from . import latex_reporting as lr
import scipy.stats as stats
from lifelines import CoxPHFitter, WeibullAFTFitter, LogNormalAFTFitter, LogLogisticAFTFitter
from lifelines.statistics import proportional_hazard_test, logrank_test
from lifelines.utils import survival_table_from_events
from MLstatkit import Delong_test

def plot_roc_curve(y_true, y_scores, model_name, train, label=None):
    """
    Plot ROC curve for a given model.

    Parameters:
    
    * y_true (pandas Series): True labels
    
    * y_scores (pandas Series): Predicted probabilities
    
    * model_name (str): Name of the model
    
    * train (bool): If True, this is for training data, otherwise for testing data
    
    * label (str): Label for the ROC curve

    Returns:
    
    * filename (str): Name of the file where the ROC curve is saved

    Output:
    
    * Saves the ROC curve plot to a file.
    """

    filename = 'roc_curve_' + model_name + ('_train' if train else '_test') + '.png'
    fpr, tpr, _ = roc_curve(y_true, y_scores)
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color='blue', label=label if label else 'ROC Curve')
    plt.plot([0, 1], [0, 1], color='red', linestyle='--')  # Diagonal line
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC) Curve for ' + model_name)
    plt.legend()
    plt.grid()
    plt.savefig(filename)
    plt.close()
    return filename

def plot_precision_recall_curve(y_true, y_scores, model_name, train, label=None):
    """
    Plot Precision-Recall curve for a given model.

    Parameters:
    
    * y_true (pandas Series): True labels
    
    * y_scores (pandas Series): Predicted probabilities
    
    * model_name (str): Name of the model
    
    * train (bool): If True, this is for training data, otherwise for testing data
    
    * label (str): Label for the precision recall curve

    Returns:
    
    * filename (str): Name of the file where the precision recall curve is saved

    Output:
    
    * Saves the precision recall curve plot to a file.
    """

    filename = 'precision_recall_curve_' + model_name + ('_train' if train else '_test') + '.png'
    precision, recall, _ = precision_recall_curve(y_true, y_scores)
    plt.figure(figsize=(8, 6))
    plt.plot(precision, recall, color='blue', label=label if label else 'Precision-Recall Curve')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve for ' + model_name)
    plt.legend()
    plt.grid()
    plt.savefig(filename)
    plt.close()   
    return filename

def plot_confusion_matrix(y_true, y_pred, model_name, train):
    """
    Plot confusion matrix for a given model.

    Parameters:
    
    * y_true (pandas Series): True labels
    
    * y_pred (pandas Series): Predicted labels
    
    * model_name (str): Name of the model
    
    * train (bool): If True, this is for training data, otherwise for testing data

    Returns:
    
    * filename (str): Name of the file where the confusion matrix is saved

    Output:
    
    * Saves the confusion matrix plot to a file.
    """
    
    filename = 'confusion_matrix_' + model_name + ('_train' if train else '_test') + '.png'
    cm = confusion_matrix(y_true, y_pred)
    plt.imshow(cm, interpolation='nearest', cmap='Blues')
    plt.title(f'Confusion Matrix for {model_name}')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.colorbar()
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    return filename

def print_model_summary(models, X_train, X_test):
    """
    Print summary of trained models including predictions, coefficients/feature importances, and intercepts.
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X_train (pandas DataFrame): training features
    
    * X_test (pandas DataFrame): testing features
    """
    for model in models:
        print(f"Model: {model.__class__.__name__}")
        print(f"Training Predictions: {model.predict(X_train)}")
        print(f"Testing Predictions: {model.predict(X_test)}")
        print(f"Coefficients/Feature Importances: {getattr(model, 'coef_', getattr(model, 'feature_importances_', None))}")
        print(f"Intercept: {getattr(model, 'intercept_', None)}")

def optimise_threshold(y_true, y_scores, method):
    """
    Calculates the optimal threshold for binary classification.

    Args:
    * y_true (array-like): True binary labels (0 or 1).
        
    * y_scores (array-like): Target scores, can either be probability estimates of the positive class, confidence values, or non-thresholded decision function outputs.
        
    * method (str): Method to use for threshold optimization. Options are:
            - 'youden index': Maximizes the Youden Index (sensitivity + specificity - 1).
            - 'f1': Maximizes the F1 score.
            - 'concordance probability': Maximizes sensitivity * specificity.
            - 'closest to (0, 1)': Finds the threshold closest to the point (0, 1) on the ROC curve.

    Returns:

    * max_score (float): The maximum score found.

    * optimal_threshold (float): The threshold corresponding to the
                                         maximum Youden Index.
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_scores)
    if method.lower() == 'youden index':
        scores = tpr - fpr
        max_score = np.max(scores)
        optimal_threshold_idx = np.argmax(scores)
    elif method.lower() == 'f1':
        precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
        scores = 2 * (precision * recall) / (precision + recall + 1e-10)
        max_score = np.max(scores)
        optimal_threshold_idx = np.argmax(scores)
    elif method.lower() == "concordance probability":
        # Implement the concordance probability method for threshold optimization
        scores = tpr * (1-fpr)
        max_score = np.max(scores)
        optimal_threshold_idx = np.argmax(scores)
    elif method.lower() == "closest to (0, 1)":
        scores = np.sqrt((1-tpr)**2 + fpr**2)
        max_score = np.min(scores)
        optimal_threshold_idx = np.argmin(scores)
    elif method.lower() == 'index of union':
        auc = roc_auc_score(y_true, y_scores)
        scores = np.abs(tpr - auc) + np.abs(1 - fpr - auc)
        max_score = np.min(scores)
        optimal_threshold_idx = np.argmin(scores)   
    optimal_threshold = thresholds[optimal_threshold_idx]
    return max_score, optimal_threshold

def optimise_thresholds(models, X, y, threshold_analysis, author, confidence=0.95, directory=".//threshold_analysis", filename='threshold_optimisation_results'):
    """
    Optimise thresholds for list of models
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X (pandas DataFrame): features
    
    * threshold_analysis (str): Method to use for threshold optimization.
    
    * confidence (float): Confidence level to report for bootstrapping

    * directory (str): Directory to save results and plots.
    
    * filename (str): name of the file to save results (without extension)

    Returns:
    
    * thresholds (list): List of optimal thresholds for each model

    * threshold_df (pandas DataFrame): DataFrame containing threshold optimisation results

    Outputs:

    * CSV of threshold optimisation results

    * PDF and latex report of threshold optimisation results
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    thresholds = []
    for i, (model_name, model) in enumerate(models):
        X_train = X.loc[:, model.feature_names_in_]
        if hasattr(model, 'predict_proba'):
            score = model.predict_proba(X_train)[:, 1]
        else:
            score = model.decision_function(X_train)
        max_score, optimal_threshold = optimise_threshold(y, score, threshold_analysis)
        thresholds.append(optimal_threshold)
        results.append({
            'Model': model_name,
            'Best Score for Threshold': max_score,
            'Optimal Threshold': optimal_threshold
        }) 
    os.chdir(directory)
    threshold_df = pd.DataFrame(results)
    lr.threshold_evaluation_report(author, threshold_df, threshold_analysis, filename=filename)
    threshold_df.set_index('Model', inplace=True)
    threshold_df.to_csv(f'{filename}.csv')
    os.chdir("..")
    return thresholds, threshold_df

def svm_decision_function_threshold(model, X, threshold):
    """
    Custom thresholding function for SVM models using decision function.

    Parameters:
    
    * model (sklearn.svm.SVC): Trained SVM model.
    
    * X (pandas DataFrame): Feature set.
    
    * threshold (float): Decision function threshold.

    Returns:
    
    * numpy array: Decision scores corrected with threshold
    """
    decision_scores = model.decision_function(X)
    return decision_scores - threshold

def test_harm_from_max_tests(max_tests):
    """
    Calculate test harm from maximum number of tests to find one true case.

    Parameters:
    
    * max_tests (int): Maximum number of tests to find one true case.

    Returns:
    
    * float: Test harm value.
    """
    if max_tests is None:
        return 0
    else:
        return 1/max_tests

def calculate_decision_curve_metrics(y_true, y_scores, y_pred, thresh, max_tests):
    """
    Calculate decision curve analysis metrics for a given threshold.

    Parameters:

    * y_true (numpy array): True labels
    
    * y_scores (numpy array): Predicted probabilities/scores
    
    * y_pred (numpy array): Binary predictions
    
    * thresh (float): Threshold for classification
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.

    Returns:
    
    * net_benefit_treated (float): Net benefit for treated

    * net_benefit_untreated (float): Net benefit for untreated

    * net_benefit_overall (float): Net benefit overall

    * net_benefit_treat_all (float): Net benefit for treating all patients

    * net_benefit_treat_none (float): Net benefit for treating no patients

    * adapt (float): ADAPT index

    * adapt_perfect (float): ADAPT index for perfect classifier

    * adapt_null (float): ADAPT index for null classifier
    """ 
    test_harm = test_harm_from_max_tests(max_tests)           
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    specificity = tn/(tn+fp)
    recall = recall_score(y_true, y_pred, average='binary', zero_division=0)
    phi = np.sum(y_true)/len(y_true) #calculate abundance of positive cases
    #Net benefit calculations
    net_benefit_treated = recall * phi - ((1-specificity)*(1-phi)*thresh)/(1-thresh) - test_harm
    net_benefit_untreated = specificity*(1-phi) - ((1-recall)*phi*thresh)/(1-thresh) - test_harm
    net_benefit_overall = net_benefit_treated + net_benefit_untreated + test_harm
    #treat all case - net benefit calculations
    net_benefit_treat_all = np.sum(y_true)/len(y_true) - (1-np.sum(y_true)/len(y_true))*thresh/(1-thresh)
    net_benefit_treat_none = (1-np.sum(y_true)/len(y_true)) - np.sum(y_true)/len(y_true)*thresh/(1-thresh)
    #ADAPT index
    absolute_deviations = np.abs(y_scores - thresh)               
    adapt = np.mean(absolute_deviations)            
    adapt_perfect = (np.sum(y_true)/len(y_true)) * (1 - thresh) + (1 - (np.sum(y_true)/len(y_true))) * thresh
    adapt_null = np.abs((np.sum(y_true)/len(y_true))) - thresh
    if isinstance(adapt_perfect, pd.Series):
        net_benefit_treated = net_benefit_treated.values[0]
        net_benefit_untreated = net_benefit_untreated.values[0]
        net_benefit_overall = net_benefit_overall.values[0]
        net_benefit_treat_all = net_benefit_treat_all.values[0]
        net_benefit_treat_none = net_benefit_treat_none.values[0]
        adapt_perfect = adapt_perfect.values[0]
        adapt_null = adapt_null.values[0]
    if adapt > adapt_perfect:
        print('threshold', thresh)
        print('warning: adapt train is greater than perfect')
        print('absolute deviations train', absolute_deviations)
        print('adapt', adapt)
        print(adapt_perfect)
    elif adapt < adapt_null:
        print('threshold', thresh)
        print('warning: adapt train is less than null')
        print('absolute deviations train', absolute_deviations)
        print('adapt', adapt)
        print(adapt_null)
    return net_benefit_treated, net_benefit_untreated, net_benefit_overall, net_benefit_treat_all, net_benefit_treat_none, adapt, adapt_perfect, adapt_null

def calculate_confidence_intervals_decision_curve(thresholds, boot_score, max_tests, y, boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null, unpack_list=False):
    """
    Calculate confidence intervals.
    
    Parameters:
    
    * thresholds (numpy array): Array of thresholds to use for decision curve analysis
    
    * boot_score (numpy array): model prediction scores  
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * y (numpy array): actual values of target.

    * boot_all_net_benefits_treated (list): List to append bootstrapped net benefits for treated.
    
    * boot_all_net_benefits_untreated (list): List to append bootstrapped net benefits for untreated.
    
    * boot_all_net_benefits_overall (list): List to append bootstrapped net benefits for overall.
    
    * boot_all_net_benefits_treat_all (list): List to append bootstrapped net benefits for treat all.
    
    * boot_all_net_benefits_treat_none (list): List to append bootstrapped net benefits for treat none.

    * boot_all_adapts (list): List to append bootstrapped adapts
    
    * boot_all_adapts_perfect (list): List to append bootstrapped adapts for perfect classifier.
    
    * boot_all_adapts_null (list): List to append bootstrapped adapts for null classifier.

    * unpack_list (bool): If True, unpack and return only the first bootstrap results.

    Returns:
    
    * boot_all_net_benefits_treated (list): List to append bootstrapped net benefits for treated.
    
    * boot_all_net_benefits_untreated (list): List to append bootstrapped net benefits for untreated.
    
    * boot_all_net_benefits_overall (list): List to append bootstrapped net benefits for overall.
    
    * boot_all_net_benefits_treat_all (list): List to append bootstrapped net benefits for treat all.
    
    * boot_all_net_benefits_treat_none (list): List to append bootstrapped net benefits for treat none.

    * boot_all_adapts (list): List to append bootstrapped adapts
    
    * boot_all_adapts_perfect (list): List to append bootstrapped adapts for perfect classifier.
    
    * boot_all_adapts_null (list): List to append bootstrapped adapts for null classifier.

    * unpack_list (bool): If True, unpack and return only the first bootstrap results.
    """
    boot_preds = list((boot_score >= thresholds[:, None]).astype(int))
    boot_net_benefits_treated = []
    boot_net_benefits_untreated = []
    boot_net_benefits_overall = []
    boot_net_benefits_treat_all = []
    boot_net_benefits_treat_none = []
    boot_adapts = []
    boot_adapts_perfect = []
    boot_adapts_null = []
    for thresh, boot_pred in zip(thresholds, boot_preds):
        boot_net_benefit_treated, boot_net_benefit_untreated, boot_net_benefit_overall, boot_net_benefit_treat_all, boot_net_benefit_treat_none, boot_adapt, boot_adapt_perfect, boot_adapt_null = calculate_decision_curve_metrics(y, boot_score, boot_pred, thresh, max_tests)
        boot_net_benefits_treated.append(boot_net_benefit_treated)
        boot_net_benefits_untreated.append(boot_net_benefit_untreated)
        boot_net_benefits_overall.append(boot_net_benefit_overall)
        boot_net_benefits_treat_all.append(boot_net_benefit_treat_all)
        boot_net_benefits_treat_none.append(boot_net_benefit_treat_none)
        boot_adapts.append(boot_adapt)
        boot_adapts_perfect.append(boot_adapt_perfect)
        boot_adapts_null.append(boot_adapt_null)
    boot_all_net_benefits_treated.append(boot_net_benefits_treated)
    boot_all_net_benefits_untreated.append(boot_net_benefits_untreated)
    boot_all_net_benefits_overall.append(boot_net_benefits_overall)
    boot_all_net_benefits_treat_all.append(boot_net_benefits_treat_all)
    boot_all_net_benefits_treat_none.append(boot_net_benefits_treat_none)
    boot_all_adapts.append(boot_adapts)
    boot_all_adapts_perfect.append(boot_adapts_perfect)
    boot_all_adapts_null.append(boot_adapts_null)
    if unpack_list:
        return boot_all_net_benefits_treated[0], boot_all_net_benefits_untreated[0], boot_all_net_benefits_overall[0], boot_all_net_benefits_treat_all[0], boot_all_net_benefits_treat_none[0], boot_all_adapts[0], boot_all_adapts_perfect[0], boot_all_adapts_null[0]
    else:
        return boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null


def bootstrap_confidence_interval_decision_curve(X_train, y_train, X_test, y_test, sample_size, model, thresholds, max_tests, n_bootstraps=100, confidence=0.95, time=None, model_file=None):
    """
    Calculate confidence intervals using bootstrapping for decision curve analysis.
    
    Parameters:
    
    * X_train (pandas DataFrame): training features
    
    * y_train (pandas Series): training target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * sample_size (int): Sample size of each bootstrap 

    * model (sk learn model): model to evaluate  

    * thresholds (numpy array): Array of thresholds to use for decision curve analysis
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * n_bootstraps (int): Number of bootstraps to conduct
    
    * confidence (float): confidence level
    
    * time (float): timepoint evaluated
    
    * model_file (str): name of model file

    Returns:
    
    * df (pandas DataFrame): DataFrame containing evaluation results
    """
    boot_all_net_benefits_treated = []
    boot_all_net_benefits_untreated = []
    boot_all_net_benefits_overall = []
    boot_all_net_benefits_treat_all = []
    boot_all_net_benefits_treat_none = []
    boot_all_adapts = []
    boot_all_adapts_perfect = []
    boot_all_adapts_null = []
    lower_percentile = ((1.0 - confidence) / 2.0) * 100
    upper_percentile = 100 - lower_percentile
    for _ in range(n_bootstraps):
        #run bootstrapping
        Xb_train, yb_train = make_bootstrap(X_train, y_train, sample_size)     
        if model_file is None:
            Xb_train.reset_index(drop=True, inplace=True)
            yb_train.reset_index(drop=True, inplace=True)
            yb_train_ravel = yb_train.values.ravel()
            m = clone(model)
            m.fit(Xb_train, yb_train_ravel)
            boot_score = m.predict_proba(Xb_train)[:, 1]   
            test_score = m.predict_proba(X_test)[:, 1] 
        else:
            yb_train_ravel = ((yb_train['target_survival'] <= time) & (yb_train['target_survival_status'] == 1)).astype(int).values
            with open(model_file, 'rb') as file:
                m = pickle.load(file)            
            df = pd.concat([Xb_train, yb_train], axis=1)
            df.reset_index(drop=True, inplace=True)
            m._scipy_fit_method = "SLSQP"
            m.fit(df, duration_col='target_survival', event_col='target_survival_status')
            boot_surv = m.predict_survival_function(Xb_train, times=[time])
            test_surv = m.predict_survival_function(X_test, times=[time])
            boot_score = 1 - boot_surv.values[0]
            test_score = 1 - test_surv.values[0]
        boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null = calculate_confidence_intervals_decision_curve(thresholds, boot_score, max_tests, yb_train_ravel, boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null)
    boot_all_net_benefits_treated = np.array(boot_all_net_benefits_treated).T
    boot_all_net_benefits_untreated = np.array(boot_all_net_benefits_untreated).T
    boot_all_net_benefits_overall = np.array(boot_all_net_benefits_overall).T
    boot_all_net_benefits_treat_all = np.array(boot_all_net_benefits_treat_all).T
    boot_all_net_benefits_treat_none = np.array(boot_all_net_benefits_treat_none).T
    boot_all_adapts = np.array(boot_all_adapts).T
    boot_all_adapts_perfect = np.array(boot_all_adapts_perfect).T
    boot_all_adapts_null = np.array(boot_all_adapts_null).T
    test_net_benefits_treated, test_all_net_benefits_untreated, test_all_net_benefits_overall, test_all_net_benefits_treat_all, test_all_net_benefits_treat_none, test_all_adapts, test_all_adapts_perfect, test_all_adapts_null = calculate_confidence_intervals_decision_curve(thresholds, boot_score, max_tests, yb_train_ravel, [], [], [], [], [], [], [], [], unpack_list=True)
    res = [thresholds]
    #mean
    for item in [ boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null]:
        res.append(np.mean(item, axis=1))
    #ci lower
    for item in [ boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null]:
        res.append(np.percentile(item, lower_percentile, axis=1))
    #ci upper
    for item in [ boot_all_net_benefits_treated, boot_all_net_benefits_untreated, boot_all_net_benefits_overall, boot_all_net_benefits_treat_all, boot_all_net_benefits_treat_none, boot_all_adapts, boot_all_adapts_perfect, boot_all_adapts_null]:
        res.append(np.percentile(item, upper_percentile, axis=1))    
    #append testing results
    for item in [test_net_benefits_treated, test_all_net_benefits_untreated, test_all_net_benefits_overall, test_all_net_benefits_treat_all, test_all_net_benefits_treat_none, test_all_adapts, test_all_adapts_perfect, test_all_adapts_null]:
        res.append(np.array(item))
    df = pd.DataFrame(np.array(res).T)
    columns = ['Threshold'] + ['train ' + x + ' ' + y for x in ['mean', 'lower', 'upper'] for y in ['net benefit treated', 'net benefit untreated', 'net benefit overall', 'net benefit treat all', 'net benefit treat none', 
    'adapts', 'adapts perfect', 'adapts null']]
    columns += ['test ' + x for x in ['net benefit treated', 'net benefit untreated', 'net benefit overall', 'net benefit treat all', 'net benefit treat none', 
    'adapts', 'adapts perfect', 'adapts null']]
    df = df.set_axis(columns, axis=1)
    return df

def decision_curve_analyse_model(thresh, train_score, test_score, train_pred, test_pred, y_train, y_test, model_name, max_tests=None):
    """
    Conducts decision curve analysis for a single model at a specific threshold.

    Parameters:
    
    * thresh (float): Threshold for classification
    
    * train_score (numpy array): Predicted probabilities/scores for training data
    
    * test_score (numpy array): Predicted probabilities/scores for testing data
    
    * train_pred (numpy array): Binary predictions for training data
    
    * test_pred (numpy array): Binary predictions for testing data
    
    * y_train (numpy array): True labels for training data
    
    * y_test (numpy array): True labels for testing data
    
    * model_name (str): Name of the model
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    Returns:
    
    * Dictionary containing decision curve analysis metrics
    """       
    train_net_benefit_treated, train_net_benefit_untreated, train_net_benefit_overall, train_net_benefit_treat_all, train_net_benefit_treat_none, train_adapt, train_adapt_perfect, train_adapt_null = calculate_decision_curve_metrics(y_train, train_score, train_pred, thresh, max_tests)
    test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null = calculate_decision_curve_metrics(y_test, test_score, test_pred, thresh, max_tests)   
    return {'Model': model_name,
                    'Threshold': thresh,
                    'Train Net Benefit Treated': train_net_benefit_treated,
                    'Test Net Benefit Treated': test_net_benefit_treated,
                    'Train Net Benefit Untreated': train_net_benefit_untreated,
                    'Test Net Benefit Untreated': test_net_benefit_untreated,
                    'Train Net Benefit Overall': train_net_benefit_overall,
                    'Test Net Benefit Overall': test_net_benefit_overall,
                    'Train Net Benefit Treated Treat All': train_net_benefit_treat_all,
                    'Test Net Benefit Treated Treat All': test_net_benefit_treat_all,
                    'Train Net Benefit Untreated Treat None': train_net_benefit_treat_none,
                    'Test Net Benefit Untreated Treat None': test_net_benefit_treat_none,
                    'Train ADAPT Index': train_adapt,
                    'Test ADAPT Index': test_adapt,
                    'Train ADAPT Perfect': train_adapt_perfect,
                    'Test ADAPT Perfect': test_adapt_perfect,
                    'Train ADAPT Null': train_adapt_null,
                    'Test ADAPT Null': test_adapt_null
                }

def cv_decision_curve_analyse_model(model, thresholds, X_train, y_train, max_tests, n_splits=5, n_iterations=3, penalizer=0.01, model_file=None, time=None):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file. Use cross-validation on training data to correct for overfitting.
    
    Parameters:
    
    * model (list): Trained sklearn model to evaluate
    
    * thresholds (numpy array): Array of thresholds to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * max_tests (int): Maximum number of tests to find one true case
    
    * n_splits (int): Number of folds for cross-validation
    
    * n_iterations (int): Number of iterations for cross-validation
    
    * penalizer (float): Penalizer value for lifelines models
    
    * model_file (str, optional): Path to a saved model file. If provided, the model will be loaded from this file instead of being cloned. Defaults to None.

    Returns:
    
    * mean_net_benefits_treated (numpy array): Mean net benefits for treated across thresholds
    
    * mean_net_benefits_untreated (numpy array): Mean net benefits for untreated across thresholds
    
    * mean_net_benefits_overall (numpy array): Mean overall net benefits across thresholds
    
    * mean_net_benefits_treat_all (numpy array): Mean net benefits for treated (treat all) across thresholds
    
    * mean_net_benefits_treat_none (numpy array): Mean net benefits for untreated (treat none) across thresholds
    
    * mean_adapts (numpy array): Mean ADAPT index across thresholds
    
    * mean_adapts_perfect (numpy array): Mean ADAPT index across thresholds for perfect classifier
    
    * mean_adapts_null (numpy array): Mean ADAPT index across thresholds for null classifier
    """
    if time is None:
        y_train_ravel = y_train.values.ravel()
    else:
        y_train_ravel = ((y_train['target_survival'] <= time) & (y_train['target_survival_status'] == 1)).astype(int).values
    test_harm = test_harm_from_max_tests(max_tests)
    all_net_benefits_treated = []
    all_net_benefits_untreated = []
    all_net_benefits_overall = []
    all_net_benefits_treat_all = []
    all_net_benefits_treat_none = []
    all_adapts = []
    all_adapts_perfect = []
    all_adapts_null = []
    for j in range(n_iterations):
        cv = StratifiedKFold(n_splits=n_splits, shuffle=True)
        all_cv_scores = np.zeros(len(y_train_ravel))
        all_cv_preds = np.zeros((len(thresholds), len(y_train_ravel)))
        for i, (train_index, test_index) in enumerate(cv.split(X_train, y_train)):
            X_train_cv, X_test_cv = X_train.iloc[train_index], X_train.iloc[test_index]
            y_train_cv, y_test_cv = y_train.iloc[train_index], y_train.iloc[test_index]
            if model_file is None:
                m = clone(model)
                m.fit(X_train_cv, y_train_cv)
                test_score = m.predict_proba(X_test_cv)[:, 1]   
            else:
                with open(model_file, 'rb') as file:
                    m = pickle.load(file)            
                df = pd.concat([X_train_cv, y_train_cv], axis=1)
                m._scipy_fit_method = "SLSQP"
                m.fit(df, duration_col='target_survival', event_col='target_survival_status')
                test_surv = model.predict_survival_function(X_test_cv, times=[time])
                test_score = 1 - test_surv.values[0]                       
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            all_cv_scores[test_index] = test_score
            all_cv_preds[:, test_index] = test_preds       
        net_benefits_treated = []
        net_benefits_untreated = []
        net_benefits_overall = []
        net_benefits_treat_all = []
        net_benefits_treat_none = []
        adapts = []
        adapts_perfect = []
        adapts_null = []
        for thresh, train_pred in zip(thresholds, all_cv_preds):     
            train_net_benefit_treated, train_net_benefit_untreated, train_net_benefit_overall, train_net_benefit_treat_all, train_net_benefit_treat_none, train_adapt, train_adapt_perfect, train_adapt_null = calculate_decision_curve_metrics(y_train_ravel, all_cv_scores, train_pred, thresh, max_tests=max_tests)                
            net_benefits_treated.append(train_net_benefit_treated)
            net_benefits_untreated.append(train_net_benefit_untreated)
            net_benefits_overall.append(train_net_benefit_overall)
            net_benefits_treat_all.append(train_net_benefit_treat_all)
            net_benefits_treat_none.append(train_net_benefit_treat_none)
            adapts.append(train_adapt)
            adapts_perfect.append(train_adapt_perfect)
            adapts_null.append(train_adapt_null)
        all_net_benefits_treated.append(net_benefits_treated)
        all_net_benefits_untreated.append(net_benefits_untreated)
        all_net_benefits_overall.append(net_benefits_overall)
        all_net_benefits_treat_all.append(net_benefits_treat_all)
        all_net_benefits_treat_none.append(net_benefits_treat_none)
        all_adapts.append(adapts)
        all_adapts_perfect.append(adapts_perfect)
        all_adapts_null.append(adapts_null)
    mean_net_benefits_treated = np.mean(all_net_benefits_treated, axis=0)
    mean_net_benefits_untreated = np.mean(all_net_benefits_untreated, axis=0)
    mean_net_benefits_overall = np.mean(all_net_benefits_overall, axis=0)
    mean_net_benefits_treat_all = np.mean(all_net_benefits_treat_all, axis=0)
    mean_net_benefits_treat_none = np.mean(all_net_benefits_treat_none, axis=0)
    mean_adapts = np.mean(all_adapts, axis=0)
    mean_adapts_perfect = np.mean(all_adapts_perfect, axis=0)
    mean_adapts_null = np.mean(all_adapts_null, axis=0)
    return mean_net_benefits_treated, mean_net_benefits_untreated, mean_net_benefits_overall, mean_net_benefits_treat_all, mean_net_benefits_treat_none, mean_adapts, mean_adapts_perfect, mean_adapts_null 

def bootstrap_decision_curve_analyse_model(model, thresholds, X_train, y_train, sample_size, max_tests, n_bootstraps=100, model_file=None, time=None):
    """
    Perform decision curve analysis for a single model and save results to a CSV file. Bootstrapping is performed to correct for overfitting.
    
    Parameters:
    
    * model (sklearn model): Trained sklearn model to evaluate
    
    * thresholds (numpy array): Array of thresholds to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * sample_size (int): Size of the bootstrap samples
    
    * max_tests (int): Maximum number of tests to find one true case
    
    * n_bootstraps (int): Number of bootstrap iterations

    * model_file (str, optional): Path to a saved model file. If provided, the model will be loaded from this file instead of being cloned. Defaults to None.

    * time (float): timepoint evaluated

    Returns:
    
    * optimism_net_benefits_treated (numpy array): Optimisms for net benefits for treated across thresholds
    
    * optimism_net_benefits_untreated (numpy array): Optimisms for net benefits for untreated across thresholds
    
    * optimism_net_benefits_overall (numpy array): Optimisms for overall net benefits across thresholds
    
    * optimism_net_benefits_treat_all (numpy array): Optimisms for net benefits for treated (treat all) across thresholds
    
    * optimism_net_benefits_treat_none (numpy array): Optimisms for net benefits for untreated (treat none) across thresholds
    
    * optimism_adapts (numpy array): Optimisms for ADAPT index across thresholds
    
    * optimism_adapts_perfect (numpy array): Optimisms for ADAPT index across thresholds for perfect classifier
    
    * optimism_adapts_null (numpy array): Optimisms for ADAPT index across thresholds for null classifier
    """
    all_net_benefits_treated = []
    all_net_benefits_untreated = []
    all_net_benefits_overall = []
    all_net_benefits_treat_all = []
    all_net_benefits_treat_none = []
    all_adapts = []
    all_adapts_perfect = []
    all_adapts_null = []
    boot_all_net_benefits_treated = []
    boot_all_net_benefits_untreated = []
    boot_all_net_benefits_overall = []
    boot_all_net_benefits_treat_all = []
    boot_all_net_benefits_treat_none = []
    boot_all_adapts = []
    boot_all_adapts_perfect = []
    boot_all_adapts_null = []
    # if time is None:
    #     y_train_ravel = y_train.values.ravel()
    # else:
    #     y_train_ravel = ((y_train['target_survival'] <= time) & (y_train['target_survival_status'] == 1)).astype(int).values
    for _ in range(n_bootstraps):
        #run bootstrapping
        Xb_train, yb_train = make_bootstrap(X_train, y_train, sample_size)
        
        if model_file is None:
            Xb_train.reset_index(drop=True, inplace=True)
            yb_train.reset_index(drop=True, inplace=True)
            y_train_ravel = y_train.values.ravel()
            yb_train_ravel = yb_train.values.ravel()
            m = clone(model)
            m.fit(Xb_train, yb_train_ravel)
            train_score = m.predict_proba(X_train)[:, 1]
            boot_score = m.predict_proba(Xb_train)[:, 1]   
        else:
            y_train_ravel = ((y_train['target_survival'] <= time) & (y_train['target_survival_status'] == 1)).astype(int).values
            yb_train_ravel = ((yb_train['target_survival'] <= time) & (yb_train['target_survival_status'] == 1)).astype(int).values
            with open(model_file, 'rb') as file:
                m = pickle.load(file)            
            df = pd.concat([Xb_train, yb_train], axis=1)
            df.reset_index(drop=True, inplace=True)
            m._scipy_fit_method = "SLSQP"
            m.fit(df, duration_col='target_survival', event_col='target_survival_status')
            train_surv = m.predict_survival_function(X_train, times=[time])
            train_score = 1 - train_surv.values[0]
            boot_surv = m.predict_survival_function(Xb_train, times=[time])
            boot_score = 1 - boot_surv.values[0]
        train_preds = list((train_score >= thresholds[:, None]).astype(int))
        boot_preds = list((boot_score >= thresholds[:, None]).astype(int))
        net_benefits_treated = []
        net_benefits_untreated = []
        net_benefits_overall = []
        net_benefits_treat_all = []
        net_benefits_treat_none = []
        adapts = []
        adapts_perfect = []
        adapts_null = []
        boot_net_benefits_treated = []
        boot_net_benefits_untreated = []
        boot_net_benefits_overall = []
        boot_net_benefits_treat_all = []
        boot_net_benefits_treat_none = []
        boot_adapts = []
        boot_adapts_perfect = []
        boot_adapts_null = []
        for thresh, train_pred, boot_pred in zip(thresholds, train_preds, boot_preds):
            train_net_benefit_treated, train_net_benefit_untreated, train_net_benefit_overall, train_net_benefit_treat_all, train_net_benefit_treat_none, train_adapt, train_adapt_perfect, train_adapt_null = calculate_decision_curve_metrics(y_train_ravel, train_score, train_pred, thresh, max_tests)
            boot_net_benefit_treated, boot_net_benefit_untreated, boot_net_benefit_overall, boot_net_benefit_treat_all, boot_net_benefit_treat_none, boot_adapt, boot_adapt_perfect, boot_adapt_null = calculate_decision_curve_metrics(yb_train_ravel, boot_score, boot_pred, thresh, max_tests)
            net_benefits_treated.append(train_net_benefit_treated)
            net_benefits_untreated.append(train_net_benefit_untreated)
            net_benefits_overall.append(train_net_benefit_overall)
            net_benefits_treat_all.append(train_net_benefit_treat_all)
            net_benefits_treat_none.append(train_net_benefit_treat_none)
            adapts.append(train_adapt)
            adapts_perfect.append(train_adapt_perfect)
            adapts_null.append(train_adapt_null)
            boot_net_benefits_treated.append(boot_net_benefit_treated)
            boot_net_benefits_untreated.append(boot_net_benefit_untreated)
            boot_net_benefits_overall.append(boot_net_benefit_overall)
            boot_net_benefits_treat_all.append(boot_net_benefit_treat_all)
            boot_net_benefits_treat_none.append(boot_net_benefit_treat_none)
            boot_adapts.append(boot_adapt)
            boot_adapts_perfect.append(boot_adapt_perfect)
            boot_adapts_null.append(boot_adapt_null)
        all_net_benefits_treated.append(net_benefits_treated)
        all_net_benefits_untreated.append(net_benefits_untreated)
        all_net_benefits_overall.append(net_benefits_overall)
        all_net_benefits_treat_all.append(net_benefits_treat_all)
        all_net_benefits_treat_none.append(net_benefits_treat_none)
        all_adapts.append(adapts)
        all_adapts_perfect.append(adapts_perfect)
        all_adapts_null.append(adapts_null)
        boot_all_net_benefits_treated.append(boot_net_benefits_treated)
        boot_all_net_benefits_untreated.append(boot_net_benefits_untreated)
        boot_all_net_benefits_overall.append(boot_net_benefits_overall)
        boot_all_net_benefits_treat_all.append(boot_net_benefits_treat_all)
        boot_all_net_benefits_treat_none.append(boot_net_benefits_treat_none)
        boot_all_adapts.append(boot_adapts)
        boot_all_adapts_perfect.append(boot_adapts_perfect)
        boot_all_adapts_null.append(boot_adapts_null)
    #calculate differences between bootstrap samples and original sample
    diff_net_benefits_treated = np.array(all_net_benefits_treated) - np.array(boot_all_net_benefits_treated)
    diff_net_benefits_untreated = np.array(all_net_benefits_untreated) - np.array(boot_all_net_benefits_untreated)
    diff_net_benefits_overall = np.array(all_net_benefits_overall) - np.array(boot_all_net_benefits_overall)
    diff_net_benefits_treat_all = np.array(all_net_benefits_treat_all) - np.array(boot_all_net_benefits_treat_all)
    diff_net_benefits_treat_none = np.array(all_net_benefits_treat_none) - np.array(boot_all_net_benefits_treat_none)
    diff_adapts = np.array(all_adapts) - np.array(boot_all_adapts)
    diff_adapts_perfect = np.array(all_adapts_perfect) - np.array(boot_all_adapts_perfect)
    diff_adapts_null = np.array(all_adapts_null) - np.array(boot_all_adapts_null)
    #optimism is the average difference between the bootstrap sample and the original sample
    optimism_net_benefits_treated = np.mean(diff_net_benefits_treated, axis=0)
    optimism_net_benefits_untreated = np.mean(diff_net_benefits_untreated, axis=0)
    optimism_net_benefits_overall = np.mean(diff_net_benefits_overall, axis=0)
    optimism_net_benefits_treat_all = np.mean(diff_net_benefits_treat_all, axis=0)
    optimism_net_benefits_treat_none = np.mean(diff_net_benefits_treat_none, axis=0)
    optimism_adapts = np.mean(diff_adapts, axis=0)
    optimism_adapts_perfect = np.mean(diff_adapts_perfect, axis=0)
    optimism_adapts_null = np.mean(diff_adapts_null, axis=0)
    #obtain results on the training set using the full model
    return optimism_net_benefits_treated, optimism_net_benefits_untreated, optimism_net_benefits_overall, optimism_net_benefits_treat_all, optimism_net_benefits_treat_none, optimism_adapts, optimism_adapts_perfect, optimism_adapts_null

def plot_decision_curves(models, results_df, time="", prefix=""):
    """
    Plot decision curves for the given models and results DataFrame.

    Args:
    
    * models (list): List of model names.
    
    * results_df (pd.DataFrame): DataFrame containing the results.
    
    * time (str, optional): Time period for the analysis. Defaults to "".
    
    * prefix (str, optional): Prefix for the saved plot filenames. Defaults to "".

    Returns:
    
    * list: List of plot filenames.
    """
    plots = []
    if time != "":
        time = f"_{time}"
    for model in models:
        model_df = results_df[results_df['Model'] == model]
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Train Net Benefit Treated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['Train Net Benefit Treated Treat All'], label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_train_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Train Net Benefit Overall'], label='Model', linestyle='--', color='blue')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_train_overall_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Train Net Benefit Untreated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['Train Net Benefit Untreated Treat None'], label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Net Benefit Untreated for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_train_untreated_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Test Net Benefit Treated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['Test Net Benefit Treated Treat All'], label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_test_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Test Net Benefit Overall'], label='Model', linestyle='--', color='blue')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_test_overall_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Test Net Benefit Untreated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['Test Net Benefit Untreated Treat None'], label='Treat None', linestyle='--', color='red')     
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Net Benefit Untreated for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}decision_curve_test_untreated_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['Train ADAPT Index'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['Train ADAPT Perfect'], label='Perfect Classifier', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['Train ADAPT Null'], label='Null Classifier', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('ADAPT Index')
        plt.title(f'ADAPT Index for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}adapt_index_train_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['Test ADAPT Index'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['Test ADAPT Perfect'], label='Perfect Classifier', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['Test ADAPT Null'], label='Null Classifier', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('ADAPT Index')
        plt.title(f'ADAPT Index for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'{prefix}adapt_index_test_{model}{time}.png')
        plt.close()
        plots.append((model, f'{prefix}decision_curve_train_{model}{time}.png', f'{prefix}decision_curve_test_{model}{time}.png', f'{prefix}decision_curve_train_overall_{model}{time}.png', f'{prefix}decision_curve_test_overall_{model}{time}.png', f'{prefix}decision_curve_train_untreated_{model}{time}.png', f'{prefix}decision_curve_test_untreated_{model}{time}.png', f'{prefix}adapt_index_train_{model}{time}.png',f'{prefix}adapt_index_test_{model}{time}.png'))
    return plots

def plot_ci_decision_curves(models, results_df, time="", prefix=""):
    """
    Plot decision curves and confidence intervals for the given models and results DataFrame.

    Args:
    
    * models (list): List of model names.
    
    * results_df (pd.DataFrame): DataFrame containing the results.
    
    * time (str, optional): Time period for the analysis. Defaults to "".
    
    * prefix (str, optional): Prefix for the saved plot filenames. Defaults to "".

    Returns:
    
    * list: List of plot filenames.
    """
    plots = []
    if time != "":
        time = f"_{time}"
    for model in models:
        model_df = results_df[results_df['Model'] == model]
    #     for metric in ['net benefit treated', 'net benefit untreated', 'net benefit overall', 'net benefit treat all', 'net benefit treat none', 
    #  'adapts', 'adapts perfect', 'adapts null']:
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['train mean net benefit treated'], label='Model', linestyle='--', color='blue')
        plt.fill_between(model_df['Threshold'], model_df['train lower net benefit treated'], model_df['train upper net benefit treated'], color='blue', alpha=0.2, label='Confidence Interval')
        plt.plot(model_df['Threshold'], model_df['train mean net benefit treat all'], label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Treated Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_decision_curve_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['test net benefit treated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['test net benefit treat all'], label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Treated Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_test_decision_curve_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['train mean net benefit untreated'], label='Model', linestyle='--', color='blue')
        plt.fill_between(model_df['Threshold'], model_df['train lower net benefit untreated'], model_df['train upper net benefit untreated'], color='blue', alpha=0.2, label='Confidence Interval')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['train mean net benefit treat none'], label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Untreated Net Benefit for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_decision_curve_untreated_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['test net benefit untreated'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], np.zeros_like(model_df['Threshold']), label='Treat All', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['test net benefit treat none'], label='Treat None', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Treated Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_test_decision_curve_untreated_{model}{time}.png')
        plt.close()
        plt.figure(figsize=(10, 6))
        plt.plot(model_df['Threshold'], model_df['train mean net benefit overall'], label='Model', linestyle='--', color='blue')
        plt.fill_between(model_df['Threshold'], model_df['train lower net benefit overall'], model_df['train upper net benefit overall'], color='blue', alpha=0.2, label='Confidence Interval')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Net Benefit')
        plt.title(f'Overall Net Benefit for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_decision_curve_overall_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['test net benefit overall'], label='Model', linestyle='--', color='blue')
        plt.xlabel('Threshold Probability')
        plt.ylabel('Treated Net Benefit')
        plt.title(f'Decision Curve Analysis for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_test_decision_curve_overall_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['train mean adapts'], label='Model', linestyle='--', color='blue')
        plt.fill_between(model_df['Threshold'], model_df['train lower adapts'], model_df['train upper adapts'], color='blue', alpha=0.2, label='Confidence Interval')
        plt.plot(model_df['Threshold'], model_df['train mean adapts perfect'], label='Perfect', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['train mean adapts null'], label='Null', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('ADAPT Index')
        plt.title(f'ADAPT Index for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_adapt_{model}{time}.png')
        plt.close()
        plt.plot(model_df['Threshold'], model_df['test adapts'], label='Model', linestyle='--', color='blue')
        plt.plot(model_df['Threshold'], model_df['test adapts perfect'], label='Perfect', linestyle='--', color='black')
        plt.plot(model_df['Threshold'], model_df['test adapts null'], label='Null', linestyle='--', color='red')
        plt.xlabel('Threshold Probability')
        plt.ylabel('ADAPT Index')
        plt.title(f'ADAPT Index for {model}')
        plt.legend()
        plt.grid()
        plt.ylim(bottom=-0.05)
        plt.savefig(f'ci_test_adapt_{model}{time}.png')
        plt.close()
        plots.append((model, f'ci_decision_curve_{model}{time}.png', f'ci_test_decision_curve_{model}{time}.png', f'ci_decision_curve_overall_{model}{time}.png', f'ci_test_decision_curve_overall_{model}{time}.png', f'ci_decision_curve_untreated_{model}{time}.png', f'ci_test_decision_curve_untreated_{model}{time}.png', f'ci_adapt_{model}{time}.png', f'ci_test_adapt_{model}{time}.png'))
    return plots

def decision_curve_analysis(models, X_train, y_train, X_test, y_test, author, n_thresholds=10, max_tests=None, save_results=True, directory=".//decision_curve_analysis", filename='decision_curve_analysis_results', title="Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of items in form (name, trained sklearn model) to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * author (str): Author of the evaluation
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * save_results (bool, optional): Whether to save the results to a CSV file. and save plots and report. Defaults to True.
    
    * directory (str): Directory to save results and plots.

    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    y_train_ravel = y_train.values.ravel()
    y_test_ravel = y_test.values.ravel()
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)
    for i, (model_name, model) in enumerate(models):
        X_train_new = X_train.loc[:, model.feature_names_in_]
        X_test_new = X_test.loc[:, model.feature_names_in_]
        if hasattr(model, 'predict_proba') and 'decision' not in model_name.lower():
            print(model_name)
            train_score = model.predict_proba(X_train_new)[:, 1]
            test_score = model.predict_proba(X_test_new)[:, 1]
            train_preds = list((train_score >= thresholds[:, None]).astype(int))
            test_preds = list((test_score >= thresholds[:, None]).astype(int))            
            for thresh, train_pred, test_pred in zip(thresholds, train_preds, test_preds):                
                results.append(decision_curve_analyse_model(thresh, train_score, test_score, train_pred, test_pred, y_train_ravel, y_test_ravel, model_name, max_tests=max_tests))
            print()    
    results_df = pd.DataFrame(results)
    # results_df.set_index('Model', inplace=True)
    if save_results:
        os.chdir(directory)
        results_df.to_csv(f'{filename}.csv')
        models_used = list(np.unique(results_df['Model']))
        plots = plot_decision_curves(models_used, results_df)
        lr.decision_curve_report(author, results_df, plots, title=title, filename=filename)
        os.chdir("..")
    return results_df

def ci_decision_curve_analysis(models, X_train, y_train, X_test, y_test, author, n_thresholds=10, sample_size=None, n_bootstraps=100, confidence=0.95, max_tests=None, directory=".//ci_decision_curve_analysis", filename='ci_decision_curve_analysis_results', title="Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of items in form (name, trained sklearn model) to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * author (str): Author of the evaluation
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * sample_size (int): Sample size of each bootstrap
    
    * n_bootstraps (int): Number of bootstraps to conduct
    
    * confidence (float): confidence level of intervals.
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * directory (str): Directory to save results and plots.

    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    y_train_ravel = y_train.values.ravel()
    y_test_ravel = y_test.values.ravel()
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)
    if sample_size is None:
        sample_size = len(y_train_ravel)
    for i, (model_name, model) in enumerate(models):
        X_train_new = X_train.loc[:, model.feature_names_in_]
        X_test_new = X_test.loc[:, model.feature_names_in_]
        if hasattr(model, 'predict_proba') and 'decision' not in model_name.lower():
            print(model_name)
            df = bootstrap_confidence_interval_decision_curve(X_train_new, y_train, X_test_new, y_test, sample_size, model, thresholds, max_tests, n_bootstraps=n_bootstraps)
            df['Model'] = model_name
            results.append(df)
    os.chdir(directory)
    results = pd.concat(results, axis=0)
    results.to_csv(f'{filename}.csv')
    models_used = list(np.unique(results['Model']))
    plots = plot_ci_decision_curves(models_used, results, time="", prefix="ci_")
    lr.decision_curve_report(author, results, plots, title=title, filename=filename, confidence=confidence, n_bootstraps=n_bootstraps)
    os.chdir("..")
    return results

def cv_decision_curve_analysis(models, X_train, y_train, X_test, y_test, author, n_thresholds=10, n_splits=5, n_iterations=3, max_tests=None, directory=".//cv_decision_curve_analysis", filename='cv_decision_curve_analysis_results', title="Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file. Use cross-validation on training data to correct for overfitting.
    
    Parameters:
    
    * models (list): List of items in form (name, trained sklearn model) to evaluate
    
    * X_train (pandas DataFrame): features in training set
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features in test set
    
    * y_test (pandas Series): target
    
    * author (str): Author of the evaluation
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * n_splits (int): Number of folds for cross-validation
    
    * n_iterations (int): Number of iterations for cross-validation
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * directory (str): Directory to save results and plots.

    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    y_train_ravel = y_train.values.ravel()
    y_test_ravel = y_test.values.ravel()
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)   
    for i, (model_name, model) in enumerate(models):
        X_train_new = X_train.loc[:, model.feature_names_in_]
        X_test_new = X_test.loc[:, model.feature_names_in_]
        if hasattr(model, 'predict_proba') and 'decision' not in model_name.lower():
            print(model_name)
            test_score = model.predict_proba(X_test_new)[:, 1]
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            test_net_benefits_treated = []
            test_net_benefits_untreated = []
            test_net_benefits_overall = []
            test_net_benefits_treat_all = []
            test_net_benefits_treat_none = []
            test_adapts = []
            test_adapts_perfect = []
            test_adapts_null = []
            for thresh, test_pred in zip(thresholds, test_preds):
                test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null = calculate_decision_curve_metrics(y_test, test_score, test_pred, thresh, max_tests)
                test_net_benefits_treated.append(test_net_benefit_treated)
                test_net_benefits_untreated.append(test_net_benefit_untreated)
                test_net_benefits_overall.append(test_net_benefit_overall)
                test_net_benefits_treat_all.append(test_net_benefit_treat_all)
                test_net_benefits_treat_none.append(test_net_benefit_treat_none)
                test_adapts.append(test_adapt)
                test_adapts_perfect.append(test_adapt_perfect)
                test_adapts_null.append(test_adapt_null)           
            test_score = model.predict_proba(X_test_new)[:, 1]
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            mean_net_benefits_treated, mean_net_benefits_untreated, mean_net_benefits_overall, mean_net_benefits_treat_all, mean_net_benefits_treat_none, mean_adapts, mean_adapts_perfect, mean_adapts_null = cv_decision_curve_analyse_model(model, thresholds, X_train_new, y_train, max_tests, n_splits=n_splits, n_iterations=n_iterations) 
            for thresh, mean_net_benefit_treated, mean_net_benefit_untreated, mean_net_benefit_overall, mean_net_benefit_treat_all, mean_net_benefit_treat_none, mean_adapt, mean_adapt_perfect, mean_adapt_null, test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null in zip(thresholds, mean_net_benefits_treated, mean_net_benefits_untreated, mean_net_benefits_overall, mean_net_benefits_treat_all, mean_net_benefits_treat_none, mean_adapts, mean_adapts_perfect, mean_adapts_null, test_net_benefits_treated, test_net_benefits_untreated, test_net_benefits_overall, test_net_benefits_treat_all, test_net_benefits_treat_none, test_adapts, test_adapts_perfect, test_adapts_null):
                results.append({'Model': model_name,
                                'Threshold': thresh,
                                'Train Net Benefit Treated': mean_net_benefit_treated,
                                'Test Net Benefit Treated': test_net_benefit_treated,
                                'Train Net Benefit Untreated': mean_net_benefit_untreated,
                                'Test Net Benefit Untreated': test_net_benefit_untreated,
                                'Train Net Benefit Overall': mean_net_benefit_overall,
                                'Test Net Benefit Overall': test_net_benefit_overall,
                                'Train Net Benefit Treated Treat All': mean_net_benefit_treat_all,
                                'Test Net Benefit Treated Treat All': test_net_benefit_treat_all,
                                'Train Net Benefit Untreated Treat None': mean_net_benefit_treat_none,
                                'Test Net Benefit Untreated Treat None': test_net_benefit_treat_none,
                                'Train ADAPT Index': mean_adapt,
                                'Test ADAPT Index': test_adapt,
                                'Train ADAPT Perfect': mean_adapt_perfect,
                                'Test ADAPT Perfect': test_adapt_perfect,
                                'Train ADAPT Null': mean_adapt_null,
                                'Test ADAPT Null': test_adapt_null
                            })
    os.chdir(directory)
    results_df = pd.DataFrame(results)
    # # results_df.set_index('Model', inplace=True)
    results_df.to_csv(f'{filename}.csv')
    models_used = list(np.unique(results_df['Model']))
    plots = plot_decision_curves(models_used, results_df, prefix="cv_")
    lr.decision_curve_report(author, results_df, plots, title=title, filename=filename, n_splits=n_splits, n_iterations=n_iterations)
    os.chdir("..")
    return results_df

def make_bootstrap(X, y, n_samples, random_state=None, stratify=True):

    """
    Function to make bootstraps
    
    Parameters:

    * X (pandas DataFrame or numpy array): features

    * y (pandas Series or numpy array): target

    * n_samples (int): bootstrapped sample size

    * random_state (int, optional): Random state for reproducibility

    * stratify (bool, optional): Whether to stratify the bootstrap samples according to the target variable. Defaults to True.

    Returns:

    * Xb (pandas DataFrame or numpy array): bootstrapped features

    * yb (pandas Series or numpy array): bootstrapped target
    """

    rng = np.random.RandomState(random_state)

    if stratify:
        Xb, yb = resample(X, y, n_samples=n_samples, stratify=y, random_state=random_state)
    else:
        idx_train = rng.randint(0, len(y), size=n_samples)
        is_pandas = hasattr(X, 'iloc') and hasattr(y, 'iloc')
        if is_pandas:
            Xb = X.iloc[idx_train]
            yb = y.iloc[idx_train]
        else:
            Xb = X[idx_train]
            yb = y[idx_train]
    return Xb, yb

def bootstrap_decision_curve_analysis(models, X_train, y_train, X_test, y_test, author, n_thresholds=10, n_bootstraps=100, sample_size=None, max_tests=None, directory=".//bootstrap_decision_curve_analysis", filename='bootstrap_decision_curve_analysis_results', title="Bootstrap Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file. Bootstrapping is performed to correct for overfitting.
    
    Parameters:
    
    * models (list): List of items in form (name, trained sklearn model) to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * author (str): Author of the evaluation
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * n_bootstraps (int): Number of bootstrap iterations
    
    * sample_size (int): Size of the bootstrap samples
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * directory (str): Directory to save results and plots.
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    y_train_ravel = y_train.values.ravel()
    y_test_ravel = y_test.values.ravel()
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)  
    if sample_size is None:
        sample_size = len(y_train_ravel)
    for i, (model_name, model) in enumerate(models):
        X_train_new = X_train.loc[:, model.feature_names_in_]
        X_test_new = X_test.loc[:, model.feature_names_in_]
        if hasattr(model, 'predict_proba') and 'decision' not in model_name.lower():
            print(model_name)
            #evaluate model on the test set
            test_score = model.predict_proba(X_test_new)[:, 1]
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            test_net_benefits_treated = []
            test_net_benefits_untreated = []
            test_net_benefits_overall = []
            test_net_benefits_treat_all = []
            test_net_benefits_treat_none = []
            test_adapts = []
            test_adapts_perfect = []
            test_adapts_null = []
            for thresh, test_pred in zip(thresholds, test_preds):
                test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null = calculate_decision_curve_metrics(y_test, test_score, test_pred, thresh, max_tests)
                test_net_benefits_treated.append(test_net_benefit_treated)
                test_net_benefits_untreated.append(test_net_benefit_untreated)
                test_net_benefits_overall.append(test_net_benefit_overall)
                test_net_benefits_treat_all.append(test_net_benefit_treat_all)
                test_net_benefits_treat_none.append(test_net_benefit_treat_none)
                test_adapts.append(test_adapt)
                test_adapts_perfect.append(test_adapt_perfect)
                test_adapts_null.append(test_adapt_null)           
            optimism_net_benefits_treated, optimism_net_benefits_untreated, optimism_net_benefits_overall, optimism_net_benefits_treat_all, optimism_net_benefits_treat_none, optimism_adapts, optimism_adapts_perfect, optimism_adapts_null = bootstrap_decision_curve_analyse_model(model, thresholds, X_train_new, y_train, sample_size, max_tests, n_bootstraps=n_bootstraps)
            #obtain results on the training set using the full model
            raw_results = decision_curve_analysis([(model_name, model)], X_train_new, y_train, X_test_new, y_test, author, n_thresholds=n_thresholds, filename='decision_curve_analysis_results', title="Decision Curve Evaluation Report", max_tests=max_tests, save_results=False)
            raw_net_benefits_treated = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Treated'].values
            raw_net_benefits_untreated = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Untreated'].values
            raw_net_benefits_overall = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Overall'].values
            raw_net_benefits_treat_all = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Treated Treat All'].values
            raw_net_benefits_treat_none = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Untreated Treat None'].values
            raw_adapts = raw_results[raw_results['Model'] == model_name]['Train ADAPT Index'].values
            raw_adapts_perfect = raw_results[raw_results['Model'] == model_name]['Train ADAPT Perfect'].values
            raw_adapts_null = raw_results[raw_results['Model'] == model_name]['Train ADAPT Null'].values
            #correct the training results for optimism
            corrected_net_benefits_treated = raw_net_benefits_treated - optimism_net_benefits_treated
            corrected_net_benefits_untreated = raw_net_benefits_untreated - optimism_net_benefits_untreated
            corrected_net_benefits_overall = raw_net_benefits_overall - optimism_net_benefits_overall
            corrected_net_benefits_treat_all = raw_net_benefits_treat_all - optimism_net_benefits_treat_all
            corrected_net_benefits_treat_none = raw_net_benefits_treat_none - optimism_net_benefits_treat_none
            corrected_adapts = raw_adapts - optimism_adapts
            corrected_adapts_perfect = raw_adapts_perfect - optimism_adapts_perfect
            corrected_adapts_null = raw_adapts_null - optimism_adapts_null
            for thresh, corrected_net_benefit_treated, corrected_net_benefit_untreated, corrected_net_benefit_overall, corrected_net_benefit_treat_all, corrected_net_benefit_treat_none, corrected_adapt, corrected_adapt_perfect, corrected_adapt_null, test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null in zip(thresholds, corrected_net_benefits_treated, corrected_net_benefits_untreated, corrected_net_benefits_overall, corrected_net_benefits_treat_all, corrected_net_benefits_treat_none, corrected_adapts, corrected_adapts_perfect, corrected_adapts_null, test_net_benefits_treated, test_net_benefits_untreated, test_net_benefits_overall, test_net_benefits_treat_all, test_net_benefits_treat_none, test_adapts, test_adapts_perfect, test_adapts_null):
                results.append({'Model': model_name,
                                'Threshold': thresh,
                                'Train Net Benefit Treated': corrected_net_benefit_treated,
                                'Test Net Benefit Treated': test_net_benefit_treated,
                                'Train Net Benefit Untreated': corrected_net_benefit_untreated,
                                'Test Net Benefit Untreated': test_net_benefit_untreated,
                                'Train Net Benefit Overall': corrected_net_benefit_overall,
                                'Test Net Benefit Overall': test_net_benefit_overall,
                                'Train Net Benefit Treated Treat All': corrected_net_benefit_treat_all,
                                'Test Net Benefit Treated Treat All': test_net_benefit_treat_all,
                                'Train Net Benefit Untreated Treat None': corrected_net_benefit_treat_none,
                                'Test Net Benefit Untreated Treat None': test_net_benefit_treat_none,
                                'Train ADAPT Index': corrected_adapt,
                                'Test ADAPT Index': test_adapt,
                                'Train ADAPT Perfect': corrected_adapt_perfect,
                                'Test ADAPT Perfect': test_adapt_perfect,
                                'Train ADAPT Null': corrected_adapt_null,
                                'Test ADAPT Null': test_adapt_null
                            })
    os.chdir(directory)
    results_df = pd.DataFrame(results)
    results_df.to_csv(f'{filename}.csv')
    models_used = list(np.unique(results_df['Model']))
    plots = plot_decision_curves(models_used, results_df, prefix="bootstrap_")
    lr.decision_curve_report(author, results_df, plots, title=title, filename=filename, n_bootstraps=n_bootstraps)
    os.chdir("..")
    return results_df

def survival_decision_curve_analysis(models, X_train, y_train, X_test, y_test, times, author, n_thresholds=10, max_tests=None, save_results=True, filename='survival_decision_curve_analysis_results', title="Survival Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for survival models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained lifelines models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas DataFrame): target with 'time' and 'event' columns
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas DataFrame): target with 'time' and 'event' columns
    
    * times (list): List of time points for survival analysis
    
    * author (str): Author of the evaluation   
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)  
    for time in times:
        results = []
        y_train_ravel = ((y_train['target_survival'] <= time) & (y_train['target_survival_status'] == 1)).astype(int).values
        y_test_ravel = ((y_test['target_survival'] <= time) & (y_test['target_survival_status'] == 1)).astype(int).values
        for i, (model_name, model, file) in enumerate(models):     
            print(f"Model: {model_name}, Time: {time}")
            train_surv = model.predict_survival_function(X_train, times=[time])
            test_surv = model.predict_survival_function(X_test, times=[time])
            train_score = 1 - train_surv.values[0]
            test_score = 1 - test_surv.values[0]
            train_preds = list((train_score >= thresholds[:, None]).astype(int))
            test_preds = list((test_score >= thresholds[:, None]).astype(int))           
            for thresh, train_pred, test_pred in zip(thresholds, train_preds, test_preds):                
                results.append(decision_curve_analyse_model(thresh, train_score, test_score, train_pred, test_pred, y_train_ravel, y_test_ravel, model_name, max_tests=max_tests))
        results_df = pd.DataFrame(results)
        if save_results:
            results_df.to_csv(f'{filename}_{time}.csv')
            models_used = list(np.unique(results_df['Model']))
            plots = plot_decision_curves(models_used, results_df, time=time)
            lr.decision_curve_report(author, results_df, plots, title=title, filename=filename, time=time)
        return results_df

def ci_survival_decision_curve_analysis(models, X_train, y_train, X_test, y_test, times, author, n_thresholds=10, sample_size=None, n_bootstraps=100, confidence=0.95, max_tests=None, filename='ci_survival_decision_curve_analysis_results', title="Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for multiple models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of items in form (name, trained sklearn model) to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * times (list): list of times to evaluate model
    
    * author (str): Author of the evaluation
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * sample_size (int): Sample size of each bootstrap
    
    * n_bootstraps (int): Number of bootstraps to conduct
    
    * confidence (float): confidence level of intervals.
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)
    for time in times:
        results = []
        y_train_ravel = ((y_train['target_survival'] <= time) & (y_train['target_survival_status'] == 1)).astype(int).values
        y_test_ravel = ((y_test['target_survival'] <= time) & (y_test['target_survival_status'] == 1)).astype(int).values
        if sample_size is None:
            sample_size = len(y_train_ravel)
        for i, (model_name, model, file) in enumerate(models):
            print(model_name)
            df = bootstrap_confidence_interval_decision_curve(X_train, y_train, X_test, y_test, sample_size, model, thresholds, max_tests, n_bootstraps=n_bootstraps, time=time, model_file=file)
            df['Model'] = model_name
            results.append(df)
        results = pd.concat(results, axis=0)
        results.to_csv(f'{filename}_{time}.csv')
        models_used = list(np.unique(results['Model']))
        plots = plot_ci_decision_curves(models_used, results, time=time)
        lr.decision_curve_report(author, results, plots, title=title, filename=filename, time=time, confidence=confidence, n_bootstraps=n_bootstraps)
    return results

def cv_survival_decision_curve_analysis(models, X_train, y_train, X_test, y_test, times, author, n_thresholds=10, n_splits=5, n_iterations=3, max_tests=None, filename='cv_survival_decision_curve_analysis_results', title="Survival Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for survival models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained lifelines models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas DataFrame): target with 'time' and 'event' columns
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas DataFrame): target with 'time' and 'event' columns
    
    * times (list): List of time points for survival analysis
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * n_splits (int): Number of folds for cross-validation
    
    * n_iterations (int): Number of iterations for cross-validation
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * author (str): Author of the evaluation   
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)   
    for time in times:
        results = []
        y_test_ravel = ((y_test['target_survival'] <= time) & (y_test['target_survival_status'] == 1)).astype(int).values
        for i, (model_name, model, file) in enumerate(models):  
            print(f"Model: {model_name}, Time: {time}")
            train_surv = model.predict_survival_function(X_train, times=[time])
            test_surv = model.predict_survival_function(X_test, times=[time])
            train_score = 1 - train_surv.values[0]
            test_score = 1 - test_surv.values[0]
            train_preds = list((train_score >= thresholds[:, None]).astype(int))
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            test_net_benefits_treated = []
            test_net_benefits_untreated = []
            test_net_benefits_overall = []
            test_net_benefits_treat_all = []
            test_net_benefits_treat_none = []
            test_adapts = []
            test_adapts_perfect = []
            test_adapts_null = []
            for thresh, test_pred in zip(thresholds, test_preds):
                test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null = calculate_decision_curve_metrics(y_test_ravel, test_score, test_pred, thresh, max_tests)
                test_net_benefits_treated.append(test_net_benefit_treated)
                test_net_benefits_untreated.append(test_net_benefit_untreated)
                test_net_benefits_overall.append(test_net_benefit_overall)
                test_net_benefits_treat_all.append(test_net_benefit_treat_all)
                test_net_benefits_treat_none.append(test_net_benefit_treat_none)
                test_adapts.append(test_adapt)
                test_adapts_perfect.append(test_adapt_perfect)
                test_adapts_null.append(test_adapt_null)           
            mean_net_benefits_treated, mean_net_benefits_untreated, mean_net_benefits_overall, mean_net_benefits_treat_all, mean_net_benefits_treat_none, mean_adapts, mean_adapts_perfect, mean_adapts_null = cv_decision_curve_analyse_model(model, thresholds, X_train, y_train, max_tests, n_splits=n_splits, n_iterations=n_iterations, model_file=file, time=time)            
            for thresh, mean_net_benefit_treated, mean_net_benefit_untreated, mean_net_benefit_overall, mean_net_benefit_treat_all, mean_net_benefit_treat_none, mean_adapt, mean_adapt_perfect, mean_adapt_null, test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null in zip(thresholds, mean_net_benefits_treated, mean_net_benefits_untreated, mean_net_benefits_overall, mean_net_benefits_treat_all, mean_net_benefits_treat_none, mean_adapts, mean_adapts_perfect, mean_adapts_null, test_net_benefits_treated, test_net_benefits_untreated, test_net_benefits_overall, test_net_benefits_treat_all, test_net_benefits_treat_none, test_adapts, test_adapts_perfect, test_adapts_null):
                results.append({'Model': model_name,
                                'Threshold': thresh,
                                'Train Net Benefit Treated': mean_net_benefit_treated,
                                'Test Net Benefit Treated': test_net_benefit_treated,
                                'Train Net Benefit Untreated': mean_net_benefit_untreated,
                                'Test Net Benefit Untreated': test_net_benefit_untreated,
                                'Train Net Benefit Overall': mean_net_benefit_overall,
                                'Test Net Benefit Overall': test_net_benefit_overall,
                                'Train Net Benefit Treated Treat All': mean_net_benefit_treat_all,
                                'Test Net Benefit Treated Treat All': test_net_benefit_treat_all,
                                'Train Net Benefit Untreated Treat None': mean_net_benefit_treat_none,
                                'Test Net Benefit Untreated Treat None': test_net_benefit_treat_none,
                                'Train ADAPT Index': mean_adapt,
                                'Test ADAPT Index': test_adapt,
                                'Train ADAPT Perfect': mean_adapt_perfect,
                                'Test ADAPT Perfect': test_adapt_perfect,
                                'Train ADAPT Null': mean_adapt_null,
                                'Test ADAPT Null': test_adapt_null
                            })
        results_df = pd.DataFrame(results)
        results_df.to_csv(f'{filename}_{time}.csv')
        models_used = list(np.unique(results_df['Model']))
        plots = plot_decision_curves(models_used, results_df, time=time)
        lr.decision_curve_report(author, results_df, plots, title=title, filename=filename, time=time)
        return results_df

def bootstrap_survival_decision_curve_analysis(models, X_train, y_train, X_test, y_test, times, author, n_thresholds=10, n_bootstraps=3, sample_size=None, max_tests=None, filename='cv_survival_decision_curve_analysis_results', title="Survival Decision Curve Evaluation Report"):
    """
    Perform decision curve analysis for survival models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained lifelines models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas DataFrame): target with 'time' and 'event' columns
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas DataFrame): target with 'time' and 'event' columns
    
    * times (list): List of time points for survival analysis
    
    * n_thresholds (int): Number of thresholds to use for decision curve analysis
    
    * n_bootstraps (int): Number of bootstrap iterations
    
    * sample_size (int): Size of the bootstrap samples
    
    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.
    
    * author (str): Author of the evaluation   
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    Returns:
    results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    thresholds = np.linspace(0,1,num=n_thresholds, endpoint=False)   
    y_test_ravel = (y_test).astype(int).values
    if sample_size is None:
        sample_size = len(y_test_ravel)
    for time in times:
        results = []
        y_test_ravel = ((y_test['target_survival'] <= time) & (y_test['target_survival_status'] == 1)).astype(int).values
        for i, (model_name, model, file) in enumerate(models):  
            print(f"Model: {model_name}, Time: {time}")
            train_surv = model.predict_survival_function(X_train, times=[time])
            test_surv = model.predict_survival_function(X_test, times=[time])
            train_score = 1 - train_surv.values[0]
            test_score = 1 - test_surv.values[0]
            train_preds = list((train_score >= thresholds[:, None]).astype(int))
            test_preds = list((test_score >= thresholds[:, None]).astype(int))
            test_net_benefits_treated = []
            test_net_benefits_untreated = []
            test_net_benefits_overall = []
            test_net_benefits_treat_all = []
            test_net_benefits_treat_none = []
            test_adapts = []
            test_adapts_perfect = []
            test_adapts_null = []
            for thresh, test_pred in zip(thresholds, test_preds):
                test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null = calculate_decision_curve_metrics(y_test_ravel, test_score, test_pred, thresh, max_tests)
                test_net_benefits_treated.append(test_net_benefit_treated)
                test_net_benefits_untreated.append(test_net_benefit_untreated)
                test_net_benefits_overall.append(test_net_benefit_overall)
                test_net_benefits_treat_all.append(test_net_benefit_treat_all)
                test_net_benefits_treat_none.append(test_net_benefit_treat_none)
                test_adapts.append(test_adapt)
                test_adapts_perfect.append(test_adapt_perfect)
                test_adapts_null.append(test_adapt_null)           
            optimism_net_benefits_treated, optimism_net_benefits_untreated, optimism_net_benefits_overall, optimism_net_benefits_treat_all, optimism_net_benefits_treat_none, optimism_adapts, optimism_adapts_perfect, optimism_adapts_null = bootstrap_decision_curve_analyse_model(model, thresholds, X_train, y_train, sample_size, max_tests, n_bootstraps=n_bootstraps, model_file=file, time=time)
            #obtain results on the training set using the full model
            raw_results = survival_decision_curve_analysis([(model_name, model, file)], X_train, y_train, X_test, y_test, times, author, n_thresholds=n_thresholds, max_tests=max_tests, save_results=False, filename='survival_decision_curve_analysis_results', title="Survival Decision Curve Evaluation Report")
            raw_net_benefits_treated = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Treated'].values
            raw_net_benefits_untreated = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Untreated'].values
            raw_net_benefits_overall = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Overall'].values
            raw_net_benefits_treat_all = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Treated Treat All'].values
            raw_net_benefits_treat_none = raw_results[raw_results['Model'] == model_name]['Train Net Benefit Untreated Treat None'].values
            raw_adapts = raw_results[raw_results['Model'] == model_name]['Train ADAPT Index'].values
            raw_adapts_perfect = raw_results[raw_results['Model'] == model_name]['Train ADAPT Perfect'].values
            raw_adapts_null = raw_results[raw_results['Model'] == model_name]['Train ADAPT Null'].values
            #correct the training results for optimism
            corrected_net_benefits_treated = raw_net_benefits_treated - optimism_net_benefits_treated
            corrected_net_benefits_untreated = raw_net_benefits_untreated - optimism_net_benefits_untreated
            corrected_net_benefits_overall = raw_net_benefits_overall - optimism_net_benefits_overall
            corrected_net_benefits_treat_all = raw_net_benefits_treat_all - optimism_net_benefits_treat_all
            corrected_net_benefits_treat_none = raw_net_benefits_treat_none - optimism_net_benefits_treat_none
            corrected_adapts = raw_adapts - optimism_adapts
            corrected_adapts_perfect = raw_adapts_perfect - optimism_adapts_perfect
            corrected_adapts_null = raw_adapts_null - optimism_adapts_null
            for thresh, corrected_net_benefit_treated, corrected_net_benefit_untreated, corrected_net_benefit_overall, corrected_net_benefit_treat_all, corrected_net_benefit_treat_none, corrected_adapt, corrected_adapt_perfect, corrected_adapt_null, test_net_benefit_treated, test_net_benefit_untreated, test_net_benefit_overall, test_net_benefit_treat_all, test_net_benefit_treat_none, test_adapt, test_adapt_perfect, test_adapt_null in zip(thresholds, corrected_net_benefits_treated, corrected_net_benefits_untreated, corrected_net_benefits_overall, corrected_net_benefits_treat_all, corrected_net_benefits_treat_none, corrected_adapts, corrected_adapts_perfect, corrected_adapts_null, test_net_benefits_treated, test_net_benefits_untreated, test_net_benefits_overall, test_net_benefits_treat_all, test_net_benefits_treat_none, test_adapts, test_adapts_perfect, test_adapts_null):
                results.append({'Model': model_name,
                                'Threshold': thresh,
                                'Train Net Benefit Treated': corrected_net_benefit_treated,
                                'Test Net Benefit Treated': test_net_benefit_treated,
                                'Train Net Benefit Untreated': corrected_net_benefit_untreated,
                                'Test Net Benefit Untreated': test_net_benefit_untreated,
                                'Train Net Benefit Overall': corrected_net_benefit_overall,
                                'Test Net Benefit Overall': test_net_benefit_overall,
                                'Train Net Benefit Treated Treat All': corrected_net_benefit_treat_all,
                                'Test Net Benefit Treated Treat All': test_net_benefit_treat_all,
                                'Train Net Benefit Untreated Treat None': corrected_net_benefit_treat_none,
                                'Test Net Benefit Untreated Treat None': test_net_benefit_treat_none,
                                'Train ADAPT Index': corrected_adapt,
                                'Test ADAPT Index': test_adapt,
                                'Train ADAPT Perfect': corrected_adapt_perfect,
                                'Test ADAPT Perfect': test_adapt_perfect,
                                'Train ADAPT Null': corrected_adapt_null,
                                'Test ADAPT Null': test_adapt_null
                            })
        results_df = pd.DataFrame(results)
        results_df.to_csv(f'{filename}_{time}.csv')
        models_used = list(np.unique(results_df['Model']))
        plots = plot_decision_curves(models_used, results_df, time=time)
        lr.decision_curve_report(author, results_df, plots, title=title, filename=filename, time=time)

def km_decision_curve_analysis(models, X_train, y_train, X_test, y_test, times, author, n_thresholds=10, filename='km_decision_curve_analysis_results', title="Kaplan-Meier Decision Curve Evaluation Report", max_tests=None):
    """
    Perform decision curve analysis for survival models and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained lifelines models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas DataFrame): target with 'time' and 'event' columns
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas DataFrame): target with 'time' and 'event' columns
    
    * times (list): List of time points for survival analysis
    
    * author (str): Author of the evaluation   
    
    * filename (str): name of the file to save results, no extension
    
    * title (str): Title for the evaluation report

    * max_tests (int, optional): Maximum number of tests to obtain data that a clinician would conduct to find one true case. Defaults to None.

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:
    
    * Evaluation report as PDF file and latex
    """
    thresholds = np.linspace(0, 1, num=n_thresholds, endpoint=False)
    results = []
    test_harm = test_harm_from_max_tests(max_tests)
    for time_horizon in times:
        plots = {}
        
        for model_name, kmfs in models.items():
            plots[model_name] = []
            
            for j, kmf in enumerate(kmfs):
                survival_probability = kmf.predict(time_horizon)
                
                # Calculate the number of events and non-events
                train_events = np.sum((y_train['target_survival_status'] == 1) & (y_train['target_survival'] <= time_horizon))
                train_non_events = len(y_train) - train_events
                test_events = np.sum((y_test['target_survival_status'] == 1) & (y_test['target_survival'] <= time_horizon))
                test_non_events = len(y_test) - test_events
                
                # Calculate net benefits
                sample_size_train = len(y_train)
                sample_size_test = len(y_test)
                test_net_benefits = []
                train_net_benefits = []
                for threshold in thresholds:
                    train_true_positives = np.sum((survival_probability < threshold) & (y_train['target_survival_status'] == 1) & (y_train['target_survival'] <= time_horizon))
                    train_false_positives = np.sum((survival_probability < threshold) & (y_train['target_survival_status'] == 0) | (y_train['target_survival'] > time_horizon))
                    train_net_benefit = (train_true_positives / sample_size_train) - (train_false_positives / sample_size_train) * (threshold / (1 - threshold)) - test_harm
                    train_net_benefits.append(train_net_benefit)
                    test_true_positives = np.sum((survival_probability < threshold) & (y_test['target_survival_status'] == 1) & (y_test['target_survival'] <= time_horizon))
                    test_false_positives = np.sum((survival_probability < threshold) & (y_test['target_survival_status'] == 0) | (y_test['target_survival'] > time_horizon))
                    test_net_benefit = (test_true_positives / sample_size_test) - (test_false_positives / sample_size_test) * (threshold / (1 - threshold)) - test_harm
                    test_net_benefits.append(test_net_benefit)
                    results.append({
                    'Model': model_name,
                    'Time Horizon': time_horizon,
                    'Threshold': threshold,
                    'Train Net Benefit': train_net_benefit,
                    'Test Net Benefit': test_net_benefit
                    })
                # Plot net benefits
                plt.plot(thresholds, train_net_benefits)
                plt.xlabel('Threshold Probability')
                plt.ylabel('Net Benefit')
                plt.title('Decision Curve Analysis')
                if j == 0:
                    plt.savefig(f'km_dca_{model_name}_low_{time_horizon}_train.png')
                    plots[model_name].append(f'km_dca_{model_name}_low_{time_horizon}_train.png')
                else:
                    plt.savefig(f'km_dca_{model_name}_high_{time_horizon}_train.png')
                    plots[model_name].append(f'km_dca_{model_name}_high_{time_horizon}_train.png')
                plt.close()
                
                plt.plot(thresholds, test_net_benefits)
                plt.xlabel('Threshold Probability')
                plt.ylabel('Net Benefit')
                plt.title('Decision Curve Analysis')
                if j == 0:
                    plt.savefig(f'km_dca_{model_name}_low_{time_horizon}_test.png')
                    plots[model_name].append(f'km_dca_{model_name}_low_{time_horizon}_test.png')
                else:
                    plt.savefig(f'km_dca_{model_name}_high_{time_horizon}_test.png')
                    plots[model_name].append(f'km_dca_{model_name}_high_{time_horizon}_test.png')
                plt.close()                
                # Append results                
        results_df = pd.DataFrame(results)
        results_df.to_csv(f'{filename}_{time_horizon}.csv')
        # Generate report      
        lr.km_decision_curve_report(author, plots, time_horizon, title=title, filename=filename) 
    # Return results
    return results_df

def get_predictions(model_name, model, X, threshold, calibrated, xgb_model):
    """
    Function to get model predictions.

    Parameters:
    
    * model_name (str): name of model
    
    * model (trained model): trained model
    
    * X (pandas dataframe): features
    
    * threshold (float): decision function threshold
    
    * xgb_model (xgboost model): trained xgboost model
    
    * calibrated (boolean): If True, this is evaluating a calibrated model. Defaults to False.

    Returns:
    
    * score (numpy array): array of decision function/probability scores
    
    * preds (numpy array): model predictions
    """
    if calibrated and 'xgb' in model_name.lower():       
        #XGBoost calibrated model
        X = xgb_model.predict_proba(X)[:, 1]
        X = np.log(X/(1-X)).reshape(-1, 1)
    if hasattr(model, 'predict_proba'):
        score = model.predict_proba(X)[:, 1]
        
    elif hasattr(model, 'decision_function'):
        score = model.decision_function(X)
    else:
        print('using direct model output as score')
        score = [model(x) for x in X]
        score = np.array([x if isinstance(x, np.ndarray) else np.array([x]) for x in score])
    preds = (score >= threshold).astype(int)
    return score, preds

def calculate_basic_binary_metrics(model_name, model, X, y, threshold, xgb_model, calibrated=False):
    """
    Function to calculate the binary metrics accuracy, precision, recall, F1 score, and AUC

    Parameters:
    
    * model_name (str): name of model
    
    * model (trained model): trained model
    
    * X (pandas dataframe): features
    
    * y (numpy array): labels
    
    * threshold (float): decision function threshold
    
    * xgb_model (xgboost model): trained xgboost model
    
    * calibrated (boolean): If True, this is evaluating a calibrated model. Defaults to False.

    Returns:
    
    * score (numpy array): array of decision function/probability scores
    
    * preds (numpy array): model predictions
    
    * accuracy (float): model accuracy
    
    * f1 (float): model f1 score
    
    * precision (float): model precision
    
    * recall (float): model recall
    
    * auc (float): model AUC
    
    * specificity (float): model specificity
    """
    score, preds = get_predictions(model_name, model, X, threshold, calibrated, xgb_model)
    accuracy = accuracy_score(y, preds)
    f1 = f1_score(y, preds, average='binary')
    precision = precision_score(y, preds, average='binary', zero_division=0)
    recall = recall_score(y, preds, average='binary', zero_division=0)
    auc = roc_auc_score(y, score)
    tn, fp, fn, tp = confusion_matrix(y, preds).ravel()
    specificity = tn/(tn+fp)
    return score, preds, accuracy, f1, precision, recall, auc, specificity

def evaluate_models(models, X_train, y_train, X_test, y_test, thresholds, xgb_model, author, n_splits=5, n_bootstraps=1000, confidence=0.95, evaluate_on_test=True, calibrated=False, isotonic=False, generate_pdf=True, original_models=None, directory=".//model_evaluation", filename='model_evaluation_results', title="Model Evaluation Report"):
    """
    Evaluate multiple models on training and testing data and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): features
    
    * y_test (pandas Series): target
    
    * thresholds (list): List of thresholds for model predictions
    
    * xgb_model: Trained XGBoost model
    
    * author (str): Author of the evaluation
    
    * n_splits (int): Number of cross-validation splits.
    
    * n_bootstraps (int): Number of bootstraps
    
    * confidence (float): Confidence level to report for bootstrapping
    
    * evaluate_on_test (boolean): If True, evaluate models on the test set.
    
    * calibrated (bool): If True, model has been calibrated.
    
    * isotonic (bool): If True, model is isotonic calibrated.
    
    * generate_pdf (bool): If True, pdf is generated
    
    * original_models (list): list of original models

    * directory (str): directory to save results
    
    * filename (str): name of the file to save results, no extension

    Returns:
    
    * results_df (pandas DataFrame): DataFrame containing evaluation results

    Outputs:

    * Evaluation report as PDF file and latex

    * CSV of results
    """
    os.makedirs(directory, exist_ok=True)
    results = []
    roc_train = []
    roc_test = []
    precision_recall_train = []
    precision_recall_test = []
    confusion_matrix_train = []
    confusion_matrix_test = []
    coefficient_plots = []
    metrics = ['Accuracy', 'F1 Score', 'Precision', 'Recall', 'AUC']
    y_train_ravel = y_train.values.ravel()
    y_test_ravel = y_test.values.ravel()
    X_train_original = X_train.copy()
    X_test_original = X_test.copy()
    num_coefficients = []
    X_train_selected = {}
    X_test_selected = {}
    os.chdir(directory)
    for i, (model_name, model) in enumerate(models):
        print('evaluating model:', model_name)
        if calibrated and 'xgb' in model_name.lower():
            X_train_new = X_train.loc[:, xgb_model.feature_names_in_]
            X_test_new = X_test.loc[:, xgb_model.feature_names_in_]    
            # probs = xgb_model.predict_proba(X_train_new)
            # X_train_new = get_logits(probs)
        else:
            X_train_new = X_train.loc[:, model.feature_names_in_]
            X_test_new = X_test.loc[:, model.feature_names_in_]
        phi = np.sum(y_train_ravel)/len(y_train_ravel) #calculate abundance of positive cases
        optimal_threshold = thresholds[i]
        train_score, train_preds, train_accuracy, train_f1, train_precision, train_recall, train_auc, train_specificity = calculate_basic_binary_metrics(model_name, model, X_train_new, y_train_ravel, optimal_threshold, xgb_model, calibrated=calibrated)      
        roc_train.append((model_name, plot_roc_curve(y_train_ravel, train_score, model_name, True)))
        if evaluate_on_test:
            test_score, test_preds, test_accuracy, test_f1, test_precision, test_recall, test_auc, test_specificity = calculate_basic_binary_metrics(model_name, model, X_test_new, y_test_ravel, optimal_threshold, xgb_model, calibrated=calibrated)       
            roc_test.append((model_name, plot_roc_curve(y_test_ravel, test_score, model_name, False)))
        if hasattr(model, 'predict_proba') and "decision" not in model_name.lower():
            #Net benefit calculations
            train_net_benefit_treated = train_recall * phi - ((1-train_specificity)*(1-phi)*optimal_threshold)/(1-optimal_threshold)
            train_net_benefit_untreated = train_specificity*(1-phi) - ((1-train_recall)*phi*optimal_threshold)/(1-optimal_threshold)
            train_net_benefit_overall = train_net_benefit_treated + train_net_benefit_untreated
            absolute_deviations_train = np.abs(train_score - optimal_threshold)
            adapt_train = np.mean(absolute_deviations_train)
            train_delong_z, train_delong_p = delong_auc(y_train_ravel, train_score.ravel())
            train_nri = net_reclassification_index(y_train_ravel, train_score.ravel())
            if evaluate_on_test:
                test_net_benefit_treated = test_recall * phi - ((1-test_specificity)*(1-phi)*optimal_threshold)/(1-optimal_threshold)                
                test_net_benefit_untreated = test_specificity*(1-phi) - ((1-test_recall)*phi*optimal_threshold)/(1-optimal_threshold)            
                test_net_benefit_overall = test_net_benefit_treated + test_net_benefit_untreated
                #average deviation about the probability threshold (ADAPT) index               
                absolute_deviations_test = np.abs(test_score - optimal_threshold)
                adapt_test = np.mean(absolute_deviations_test) 
                #DeLong test and NRI compared to random classifier               
                test_delong_z, test_delong_p = delong_auc(y_test_ravel, test_score.ravel())                
                test_nri = net_reclassification_index(y_test_ravel, test_score.ravel())
        else:
            train_net_benefit_treated = "N/A"
            train_net_benefit_untreated = "N/A"
            train_net_benefit_overall = "N/A"
            adapt_train = "N/A"
            train_delong_z = "N/A"
            train_delong_p = "N/A"
            train_nri = "N/A"
            if evaluate_on_test:
                test_net_benefit_treated = "N/A"                
                test_net_benefit_untreated = "N/A"                
                test_net_benefit_overall = "N/A"               
                adapt_test = "N/A"               
                test_delong_z = "N/A"               
                test_delong_p = "N/A"              
                test_nri = "N/A"
         
        if hasattr(model, 'coef_'):
            #visualise coefficients if available
            plt.figure(figsize=(10,6))
            if not calibrated:
                plt.bar(list(X_train_new.columns) + ['Intercept'], list(model.coef_[0]) + list(model.intercept_), color='blue')
            else:
                plt.bar(['Feature'] + ['Intercept'], list(model.coef_[0]) + list(model.intercept_), color='blue')
            plt.xticks(rotation=90)
            plt.xlabel('Features')
            plt.ylabel('Coefficient Value')
            plt.title(f'Coefficients for {model_name}')
            plt.tight_layout()
            plt.savefig(f'{model_name}_coefficients.png')
            coefficient_plots.append((model_name, f'{model_name}_coefficients.png'))
            plt.close()
            num_coefficients.append(len([x for x in model.coef_[0] if np.abs(x) > 10**-10]))
        elif hasattr(model, 'dual_coef_'):
            #visualise coefficients if available
            plt.figure(figsize=(10,6))
            plt.bar([str(x) for x in range(1, len(model.dual_coef_[0]) + 1)] + ['Intercept'], list(model.dual_coef_[0]) + list(model.intercept_), color='blue')
            plt.xticks(rotation=90)
            plt.xlabel('Features')
            plt.ylabel('Dual Coefficient Value')
            plt.title(f'Dual Coefficients for {model_name}')
            plt.tight_layout()
            plt.savefig(f'{model_name}_dual_coefficients.png')
            coefficient_plots.append((model_name, f'{model_name}_dual_coefficients.png'))
            plt.close()
            num_coefficients.append(len([x for x in model.dual_coef_[0] if np.abs(x) > 10**-10]))
        elif hasattr(model, 'feature_importances_'):
            #otherwise visualise feature importances if available
            plt.figure(figsize=(10,6))
            plt.bar(X_train_new.columns, model.feature_importances_, color='blue')
            plt.xticks(rotation=90)
            plt.xlabel('Features')
            plt.ylabel('Feature Importance')
            plt.title(f'Feature Importances for {model_name}')
            plt.tight_layout()
            plt.savefig(f'{model_name}_feature_importances.png')
            coefficient_plots.append((model_name, f'{model_name}_feature_importances.png'))
            plt.close()
            num_coefficients.append(len([x for x in model.feature_importances_ if np.abs(x) > 10**-10]))
        precision_recall_train.append((model_name, plot_precision_recall_curve(y_train_ravel, train_score, model_name, True)))       
        confusion_matrix_train.append((model_name, plot_confusion_matrix(y_train_ravel, train_preds, model_name, True)))
        if evaluate_on_test:
            precision_recall_test.append((model_name, plot_precision_recall_curve(y_test_ravel, test_score, model_name, False)))
            confusion_matrix_test.append((model_name, plot_confusion_matrix(y_test_ravel, test_preds, model_name, False)))
        X_train = X_train_original
        #X_train_selected[model_name] = (X_train.iloc[:, [i for i in range(len(model.coef_[0])) if model.coef_[0][i] != 0]] if (hasattr(model, 'coef_') and not calibrated) else X_train)
        X_train_selected[model_name] = X_train.loc[:, [col for col in model.feature_names_in_]] if not calibrated else X_train
        X_test = X_test_original
        X_test_selected[model_name] = (X_test.loc[:, X_train_selected[model_name].columns])
        if evaluate_on_test:
            results.append({
                'Model': model_name,
                'Train Accuracy': train_accuracy,
                'Test Accuracy': test_accuracy,
                'Train F1 Score': train_f1,
                'Test F1 Score': test_f1,
                'Train Precision': train_precision,
                'Test Precision': test_precision,
                'Train Recall': train_recall,
                'Test Recall': test_recall,
                'Train Specificity': train_specificity,
                'Test Specificity': test_specificity,
                'Train AUC': train_auc,
                'DeLong Test Train Z-Score to Random Classifier': train_delong_z,
                'DeLong Test Train p-Value to Random Classifier': train_delong_p,
                'Test AUC': test_auc,
                'DeLong Test Test Z-Score to Random Classifier': test_delong_z,
                'DeLong Test Test p-Value to Random Classifier': test_delong_p,
                'Train Net Reclassification Index to Random Classifier': train_nri,
                'Test Net Reclassification Index to Random Classifier': test_nri,
                'Train Net Benefit Treated': train_net_benefit_treated,
                'Test Net Benefit Treated': test_net_benefit_treated,
                'Train Net Benefit Untreated': train_net_benefit_untreated,
                'Test Net Benefit Untreated': test_net_benefit_untreated,
                'Train Net Benefit Overall': train_net_benefit_overall,
                'Test Net Benefit Overall': test_net_benefit_overall,
                'Train ADAPT Index': adapt_train,
                'Test ADAPT Index': adapt_test
            })             
        else:
            results.append({
                'Model': model_name,
                'Train Accuracy': train_accuracy,
                'Train F1 Score': train_f1,
                'Train Precision': train_precision,
                'Train Recall': train_recall,
                'Train Specificity': train_specificity,
                'Train AUC': train_auc,
                'DeLong Test Train Z-Score to Random Classifier': train_delong_z,
                'DeLong Test Train p-Value to Random Classifier': train_delong_p,
                'Train Net Reclassification Index to Random Classifier': train_nri,
                'Train Net Benefit Treated': train_net_benefit_treated,
                'Train Net Benefit Untreated': train_net_benefit_untreated,
                'Train Net Benefit Overall': train_net_benefit_overall,
                'Train ADAPT Index': adapt_train,
            }) 
    results_df = pd.DataFrame(results)
    results_df.set_index('Model', inplace=True)
    results_df.to_csv(f'{filename}.csv')
    cv_results_df = cross_validate_binary_models(models, X_train, y_train, thresholds, xgb_model, calibrated=calibrated, isotonic=isotonic, n_splits=n_splits)
    print('x train selected')
    print(X_train_selected)
    bootstrapped_df, bootstrap_plots = bootstrap_ci_metrics(models, results_df, X_train_selected, y_train, X_test_selected, y_test, thresholds, n_bootstraps=n_bootstraps, evaluate_on_test=evaluate_on_test, calibrated=calibrated, sample_size=None, isotonic=isotonic, original_models=original_models, xgb_model=xgb_model, confidence=confidence, filename='model_bootstrap_results.csv')
    optimisms_df = optimism_corrected_bootstraps(models, results_df, X_train_selected, y_train, thresholds, xgb_model, calibrated=calibrated, original_models=original_models, isotonic=isotonic, n_bootstraps=n_bootstraps)
    lr.binary_model_evaluation_report(author, results_df, cv_results_df, bootstrapped_df, bootstrap_plots, optimisms_df, metrics, num_coefficients, roc_train, roc_test, precision_recall_train, precision_recall_test, confusion_matrix_train, confusion_matrix_test, coefficient_plots, evaluate_on_test=evaluate_on_test, generate_pdf=generate_pdf, n_splits=n_splits, confidence=confidence, filename=filename, title=title)   
    os.chdir("..")
    return results_df

def cross_validate_binary_models(model_list, X, y, thresholds, xgb_model, calibrated=False, isotonic=False, n_splits=5, filename='cv_evaluation_binary.csv'):
    """
    Function to cross-validate the binary models to evaluate their performance.

    Parameters:
    
    * model_list (list): List of trained sklearn models to evaluate
    
    * X (pandas dataframe): features
    
    * y (numpy array): labels
    
    * thresholds (list): list of decision function thresholds
    
    * xgb_model (xgboost model): trained xgboost model
    
    * calibrated (boolean): If True, this is evaluating a calibrated model. Defaults to False.
    
    * isotonic (boolean): If True, evaluating a calibrated isotonic model.
    
    * n_splits (int): number of cross-validation splits. Defaults to 5.
    
    * filename (str): filename to save csv to.

    Returns:
    
    * cv_metrics (pandas DataFrame): dataframe of cross-validation metrics.
    """
    cv_metrics = []
    train_accuracies = train_f1s = train_precisions = train_recalls = train_aucs = []
    test_accuracies = test_f1s = test_precisions = test_recalls = test_aucs = []
    for i, (model_name, model) in enumerate(model_list):
        if calibrated and 'xgb' in model_name.lower():
            X_new = X.loc[:, xgb_model.feature_names_in_]
        else:
            X_new = X.loc[:, model.feature_names_in_]
        model_cv_metrics = []
      # 2. Initialize the KFold splitter
# shuffle=True is often recommended for randomizing the data order before splitting
        kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
        
        # 3. Iterate through the splits
        for j, (train_index, test_index) in enumerate(kf.split(X_new, y)):
            # Get the training and testing data for the current fold
            X_train, X_test = X_new.iloc[train_index], X_new.iloc[test_index]
            y_train, y_test = y.iloc[train_index].values.ravel(), y.iloc[test_index].values.ravel()
            if calibrated and 'xgb' in model_name.lower():
                if isotonic:
                    probs = xgb_model.predict_proba(X_train)[:, 1]
                    data = pd.concat((pd.Series(probs, name='Probability'), pd.Series(y_train, name='Labels')), axis=1)
                    data = data.sort_values(by="Probability", ascending=True)
                    res = pava(data['Probability'], data['Labels'])
                    calibrated_model = create_stepwise_function(data['Probability'], res)
                else:
                    probs = xgb_model.predict_proba(X_train)
                    logits = get_logits(probs)
                    model.fit(logits, y_train)
            else:
                model.fit(X_train, y_train)
            optimal_threshold = thresholds[i]
            train_score, train_preds, train_accuracy, train_f1, train_precision, train_recall, train_auc, train_specificity = calculate_basic_binary_metrics(model_name, model, X_train, y_train, optimal_threshold, xgb_model, calibrated=calibrated)
            test_score, test_preds, test_accuracy, test_f1, test_precision, test_recall, test_auc, test_specificity = calculate_basic_binary_metrics(model_name, model, X_test, y_test, optimal_threshold, xgb_model, calibrated=calibrated)
            model_cv_metrics.append({
            'Model': model_name,
            'Fold Number': j+1,
            'Train Accuracy': train_accuracy,
            'Test Accuracy': test_accuracy,
            'Train F1 Score': train_f1,
            'Test F1 Score': test_f1,
            'Train Precision': train_precision,
            'Test Precision': test_precision,
            'Train Recall': train_recall,
            'Test Recall': test_recall,
            'Train Specificity': train_specificity,
            'Test Specificity': test_specificity,
            'Train AUC': train_auc,
            'Test AUC': test_auc})
        model_cv_metrics = pd.DataFrame(model_cv_metrics)
        train_accuracy = np.mean(model_cv_metrics['Train Accuracy'])
        test_accuracy = np.mean(model_cv_metrics['Test Accuracy'])
        train_f1 = np.mean(model_cv_metrics['Train F1 Score'])
        test_f1 = np.mean(model_cv_metrics['Test F1 Score'])
        train_precision = np.mean(model_cv_metrics['Train Precision'])
        test_precision = np.mean(model_cv_metrics['Test Precision'])  
        train_recall = np.mean(model_cv_metrics['Train Recall'])
        test_recall = np.mean(model_cv_metrics['Test Recall'])   
        train_specificity = np.mean(model_cv_metrics['Train Specificity'])
        test_specificity = np.mean(model_cv_metrics['Test Specificity'])
        train_auc = np.mean(model_cv_metrics['Train AUC'])
        test_auc = np.mean(model_cv_metrics['Test AUC'])
        cv_metrics.append({
            'Model': model_name,
            'Train Accuracy': train_accuracy,
            'Test Accuracy': test_accuracy,
            'Train F1 Score': train_f1,
            'Test F1 Score': test_f1,
            'Train Precision': train_precision,
            'Test Precision': test_precision,
            'Train Recall': train_recall,
            'Test Recall': test_recall,
            'Train Specificity': train_specificity,
            'Test Specificity': test_specificity,
            'Train AUC': train_auc,
            'Test AUC': test_auc
        })                   
    cv_metrics = pd.DataFrame(cv_metrics)
    cv_metrics.to_csv(filename)
    return cv_metrics

def bootstrap_plot(arr, rows, res, model_name, split, metric_name, n_bootstraps, lower_bound, upper_bound):
    """
    Function to plot bootstrapped metric.

    Parameters:
    
    * arr (numpy array): array of bootstrapped metric values obtained.
    
    * rows (list): list of rows for dataframe
    
    * res (pandas DataFrame): dataframe of values from full model
    
    * model_name (str): name of model
    
    * split (str): either 'Train' or 'Test'
    
    * metric_name (str): name of metric
    
    * n_bootstraps (int): number of bootstraps performed
    
    * lower_bound (float): lower bound of confidence interval
    
    * upper_bound (float): upper bound of confidence interval

    Returns:
    
    * rows (list): updated list of rows for dataframe
    
    * str: filename of plot
    """
    mean_estimate = np.mean(arr)
    std_estimate = np.std(arr)
    cv = std_estimate / mean_estimate
    se = std_estimate / np.sqrt(len(arr))
    ciw = np.percentile(arr, upper_bound) - np.percentile(arr, lower_bound)
    rse = se / mean_estimate
    # Calculate the lower and upper bounds of the tolerance range
    si_lower_bound = res[f'Train {metric_name}'] * 0.9
    si_upper_bound = res[f'Train {metric_name}'] * 1.1

    # Calculate the number of bootstrapped estimates within the tolerance range
    num_within_tolerance = np.sum((arr >= si_lower_bound) & (arr <= si_upper_bound))

    # Calculate the Stability Index (SI)
    stability_index = num_within_tolerance / n_bootstraps
    rows[-1]['CV'] = cv
    rows[-1]['SE'] = se
    rows[-1]['CI Width'] = ciw
    rows[-1]['RSE'] = rse
    rows[-1]['SI'] = stability_index
    df = pd.DataFrame({metric_name: arr})
    fig, ax = plt.subplots(figsize=(6, 4))
    df.plot(kind="hist", density=True, ax=ax, alpha=0.5)
    if len(np.unique(arr)) > 1:
        df.plot(kind='kde', ax=ax)
    else:
        print("Skipping KDE plot due to insufficient variability in data")
    # Calculate percentiles
    quant_lower, quant_upper = np.percentile(arr, lower_bound), np.percentile(arr, upper_bound)

    # [quantile, opacity, length]
    quants = [('Lower Bound', quant_lower), ('Upper Bound', quant_upper)]

    # Plot the lines with a loop
    for label, quant in quants:
        ax.axvline(quant, alpha = 0.6, linestyle = ":", color='red', label=label)
    ax.axvline(res[f'{split} {metric_name}'], color='black', label='Full Training Data Value')
    ax.legend()
    ax.set_xlabel(metric_name)
    ax.set_yticks([])
    ax.set_ylabel("")
    ax.set_title(f'{metric_name} obtained using {n_bootstraps} bootstraps on \n {model_name}')
    plt.savefig(f'{split}_{model_name}_{metric_name}_bootstrap_plot.png')
    plt.close()
    return rows, f'{split}_{model_name}_{metric_name}_bootstrap_plot.png'

def train_bootstrap_model(model_name, model, X, y, xgb_model, calibrated=False, isotonic=False):
    """
    Function to retrain a model on bootstrapped data.

    Parameters:
    
    * model_name (str): name of model
    
    * model: trained model
    
    * X (pandas DataFrame): feature matrix
    
    * y (pandas Series): True labels.
    
    * xgb_model (xgboost model): trained xgboost model
    
    * calibrated (boolean): If True, this is evaluating a calibrated model. Defaults to False.
    
    * isotonic (boolean): If True, evaluating a calibrated isotonic model.

    Returns:
    
    * m (xgboost model): xgboost model trained on bootstrapped data
    
    * boot_model (sklearn model): model trained on bootstrapped data
    
    * data (pandas DataFrame): dataframe of model predicted probability and labels
    """
    if calibrated and 'xgb' in model_name.lower():
        m = clone(xgb_model)
        m.fit(X, y.values.ravel())
        probs = m.predict_proba(X)[:, 1]
        if isotonic:
            data = pd.concat((pd.Series(probs, name='Probability').reset_index(drop=True), y.reset_index(drop=True)), axis=1)
            data.columns = ['Probability', 'Labels']
            data = data.sort_values(by="Probability", ascending=True)
            res = pava(data['Probability'], data['Labels'])
            boot_model = create_stepwise_function(data['Probability'], res)
            return m, boot_model, data
        else:
            probs = m.predict_proba(X)
            boot_model = clone(model)            
            logits = get_logits(probs)
            boot_model.fit(logits, y.values.ravel())
            return m, boot_model, None
    else:
        boot_model = clone(model)
        if 'logistic' in model_name.lower() and not calibrated:
            if boot_model.penalty == 'l1':
                boot_model.penalty = None
                boot_model.set_params(max_iter=2000)
        print(X)
        print(y)
        boot_model.fit(X, y.values.ravel())
        return None, boot_model, None

def bootstrap_ci_metrics(models, results, X_train, y_train, X_test, y_test, thresholds, n_bootstraps=1000, evaluate_on_test=True, calibrated=False, isotonic=False, xgb_model=None,
    sample_size: int = None,
    confidence: float = 0.95,
    metrics = None,
    original_models = None,
    random_state: int = None, filename='model_bootstrap_results.csv'
) -> pd.DataFrame:
    """
    Perform bootstrap resampling to estimate the distribution
    of classification metrics for multiple models and compute
    confidence intervals.

    Parameters
    
    * models : list of (name, estimator). A list of tuples with a string name and an unfitted sklearn style estimator.
    
    * results (pandas DataFrame): dataframe of results from each model
    
    * X_train : dictionary of form (str: array like, shape (n_samples, n_features)). Dictionary of training feature matrices for each model.
    
    * y_train : array like, shape (n_samples,). True labels.
    
    * X_train : dictionary of form (str: array like, shape (n_samples, n_features)). Dictionary of testing feature matrices for each model.
    
    * y_test : array like, shape (n_samples,).True labels for testing.
    
    * n_bootstraps : int, default=1000. Number of bootstrap samples.
    
    * evaluate_on_test (boolean): If True, evaluate models on the test set.
    
    * calibrated : bool, default=False. Whether model is a calibrated model.    
    
    * isotonic : bool, default=False. Whether model has been calibrated with isotonic regression.
    
    * xgb_model (xgboost model): trained xgboost model
    
    * sample_size : int, optional. Size of each bootstrap sample. If None, uses len(y).
    
    * confidence : float, default=0.95. Confidence level for the intervals.
    
    * metrics : dict, optional. Mapping metric name → (callable, kwargs). Defaults to calculating accuracy, f1_weighted, precision, recall, and auc
    
    * random_state : int, optional. Seed for reproducibility.
    
    * filename : str, default='model_bootstrap_results.csv'. Name of the output CSV file to save results.
    
    Returns
    
    * pd.DataFrame: MultiIndexed by (model_name, metric), with columns ['mean', '2.5%', '97.5%'].
    
    * plots (dictionary): Dictionary of form {model_name: [[list of train boot plot filenames], [list of test boot plot filenames]]}

    Outputs:

    * CSV file of bootstrapped results.

    * Plots of bootstrapped metrics.

    """
    # default metrics
    if metrics is None:
        metrics = {
            'Accuracy':    (accuracy_score,       {}),
            'F1 Score': (f1_score,             {'average': 'weighted'}),
            'Precision':   (precision_score,      {'average': 'binary', 'zero_division': 0}),
            'Recall':      (recall_score,         {'average': 'binary', 'zero_division': 0}),
            'AUC':         (roc_auc_score,        {})
        }

    n_samples = len(y_train) if sample_size is None else sample_size

    # initialize storage: {model_name: {metric_name: []}}
    boot_results_train = {
        model_name: {m_name: [] for m_name in metrics}
        for model_name, _ in models
    }
    boot_results_test = {
        model_name: {m_name: [] for m_name in metrics}
        for model_name, _ in models
    }
    # bootstrap loop
    for _ in range(n_bootstraps):

        for i, (model_name, model) in enumerate(models):
            if calibrated and 'xgb' in model_name.lower():
                cols = [col for col in X_train[model_name].columns if col in xgb_model.feature_names_in_]
            else:
                cols = [col for col in X_train[model_name].columns if col in model.feature_names_in_]
            print(model.feature_names_in_)
            print('cols')
            print(cols)
            
            # X_train_new = X_train[model_name]
            if isotonic:
                X_train_new = X_train[model_name]
                X_train_new = X_train_new.loc[:, original_models[i][1].feature_names_in_]
            else:
                X_train_new = X_train[model_name]
                print(X_train_new)
                X_train_new = X_train_new.loc[:, cols]
            #X_test_new = X_test[model_name].loc[:, cols] 
            X_test_new = X_test[model_name].loc[:, cols]
                        # draw sample indices with replacement
            threshold = thresholds[i]
            Xb_train, yb_train = make_bootstrap(X_train_new, y_train, n_samples, random_state=random_state)
            if evaluate_on_test:
                Xb_test, yb_test = make_bootstrap(X_test_new, y_test, n_samples, random_state=random_state)
            # clone to reset parameters
            xg_bootstrap, m, data = train_bootstrap_model(model_name, model, Xb_train, yb_train, xgb_model, calibrated=calibrated, isotonic=isotonic)
            if calibrated and 'xgb' in model_name.lower():
                if isotonic:                
                    score = [m(x) for x in data['Probability']]
                    score = np.array([x if isinstance(x, np.ndarray) else np.array([x]) for x in score])
                    train_preds = (score >= threshold).astype(int)
                    if evaluate_on_test:
                        probs = xg_bootstrap.predict_proba(Xb_test)[:, 1]
                        score = [m(x) for x in probs]               
                        score = np.array([x if isinstance(x, np.ndarray) else np.array([x]) for x in score])
                        test_preds = (score >= threshold).astype(int)
                else:
                    train_probs = xg_bootstrap.predict_proba(Xb_train)
                    train_logits = get_logits(train_probs)
                    train_preds = m.predict(train_logits)
                    if evaluate_on_test:
                        test_probs = xg_bootstrap.predict_proba(Xb_test)
                        test_logits = get_logits(test_probs)
                        test_preds = m.predict(test_logits)                       
            else:
                train_preds = m.predict(Xb_train)
                if evaluate_on_test:
                    test_preds = m.predict(Xb_test)
            # prepare scores for AUC if needed
            if 'AUC' in metrics:
                if hasattr(m, 'predict_proba'):
                    if calibrated and 'xgb' in model_name.lower():
                        train_scores = m.predict_proba(train_logits)[:, 1]
                        if evaluate_on_test:
                            test_scores = m.predict_proba(test_logits)[:, 1]
                    else:
                        train_scores = m.predict_proba(Xb_train)[:, 1]
                        if evaluate_on_test:
                            test_scores = m.predict_proba(Xb_test)[:, 1]
                else:
                    if isotonic and 'xgb' in model_name.lower():
                        train_scores = [m(x) for x in np.transpose(Xb_train.values)[0]]
                        train_scores = np.array([x if isinstance(x, np.ndarray) else np.array([x]) for x in train_scores])
                        if evaluate_on_test:
                            test_scores = [m(x) for x in np.transpose(Xb_test.values)[0]]
                            test_scores = np.array([x if isinstance(x, np.ndarray) else np.array([x]) for x in test_scores])                            
                    else:
                        train_scores = m.decision_function(Xb_train)
                        if evaluate_on_test:
                            test_scores = m.decision_function(Xb_test)
            else:
                train_scores = None
            # compute each metric
            for m_name, (fn, kwargs) in metrics.items():
                if m_name == 'AUC':
                    val_train = fn(yb_train, train_scores, **kwargs)
                    if evaluate_on_test:
                        val_test = fn(yb_test, test_scores, **kwargs)
                else:
                    val_train = fn(yb_train, train_preds, **kwargs)
                    if evaluate_on_test:
                        val_test = fn(yb_test, test_preds, **kwargs)
                boot_results_train[model_name][m_name].append(val_train)
                if evaluate_on_test:
                    boot_results_test[model_name][m_name].append(val_test)
    # build summary DataFrame
    rows = []  
    plots = {}
    for model_name, metric_dict in boot_results_train.items():
        plots[model_name] = [[],[]]
        res = results.loc[model_name]
        for m_name, vals in metric_dict.items():
            arr = np.array(vals)
            lower_bound = (1 - confidence) / 2 * 100
            upper_bound = (1 + confidence) / 2 * 100
            if confidence not in [0.9, 0.95, 0.99]:           
                rows.append({
                    'model': model_name,
                    'metric': m_name,
                    'set': 'train',
                    'mean':       arr.mean(),
                    '0.5%':         np.percentile(arr, 0.5),
                    '2.5%':       np.percentile(arr, 2.5),
                    '5.0%':         np.percentile(arr, 5),
                    '95.0%':         np.percentile(arr, 95),
                    '97.5%':      np.percentile(arr, 97.5),
                    '99.5%':      np.percentile(arr, 99.5),
                    f'{lower_bound:.1f}%': np.percentile(arr, (1 - confidence) / 2 * 100),
                    f'{upper_bound:.1f}%': np.percentile(arr, (1 + confidence) / 2 * 100)
                })
            else:
                rows.append({
                    'model': model_name,
                    'metric': m_name,
                    'set': 'train',
                    'mean':       arr.mean(),
                    '0.5%':         np.percentile(arr, 0.5),
                    '2.5%':       np.percentile(arr, 2.5),
                    '5%':         np.percentile(arr, 5),
                    '95%':         np.percentile(arr, 95),
                    '97.5%':      np.percentile(arr, 97.5),
                    '99.5%':      np.percentile(arr, 99.5)
                })
            rows, file = bootstrap_plot(arr, rows, res, model_name, 'Train', m_name, n_bootstraps, lower_bound, upper_bound)
            plots[model_name][0].append(file)
    if evaluate_on_test:
        for model_name, metric_dict in boot_results_test.items():
            for m_name, vals in metric_dict.items():
                arr = np.array(vals)
                if confidence not in [0.9, 0.95, 0.99]:
                    lower_bound = (1 - confidence) / 2 * 100
                    upper_bound = (1 + confidence) / 2 * 100
                
                    rows.append({
                        'model': model_name,
                        'metric': m_name,
                        'set': 'test',
                        'mean':       arr.mean(),
                        '0.5%':         np.percentile(arr, 0.5),
                        '2.5%':       np.percentile(arr, 2.5),
                        '5.0%':         np.percentile(arr, 5),
                        '95.0%':         np.percentile(arr, 95),
                        '97.5%':      np.percentile(arr, 97.5),
                        '99.5%':      np.percentile(arr, 99.5),
                        f'{lower_bound:.1f}%': np.percentile(arr, (1 - confidence) / 2 * 100),
                        f'{upper_bound:.1f}%': np.percentile(arr, (1 + confidence) / 2 * 100)
                    })
                else:
                    rows.append({
                        'model': model_name,
                        'metric': m_name,
                        'set': 'test',
                        'mean':       arr.mean(),
                        '0.5%':         np.percentile(arr, 0.5),
                        '2.5%':       np.percentile(arr, 2.5),
                        '5%':         np.percentile(arr, 5),
                        '95%':         np.percentile(arr, 95),
                        '97.5%':      np.percentile(arr, 97.5),
                        '99.5%':      np.percentile(arr, 99.5)
                    })
                rows, file = bootstrap_plot(arr, rows, res, model_name, 'Test', m_name, n_bootstraps, lower_bound, upper_bound)
                plots[model_name][1].append(file)
    df = pd.DataFrame(rows)
    df.to_csv(filename, index=False)
    return df, plots

def optimism_corrected_bootstraps(models, results, X_dict, y, thresholds, xgb_model, calibrated=False, isotonic=False, random_state=42, n_bootstraps=10, original_models=None, filename='optimism_corrected_bootstraps.csv'):
    """
    Function to calculate the optimism corrected bootstrap metrics.

    Parameters:
    
    * models : list of (name, estimator)
        A list of tuples with a string name and an unfitted
        sklearn‐style estimator.
    
    * results (pandas DataFrame): dataframe of results from each model
    
    * X_dict (pandas DataFrame): dictionary of form (str: array‐like, shape (n_samples, n_features))
        Dictionary of training feature matrices for each model.
    
    * y (pandas Series): True labels.
    
    * thresholds (list): List of thresholds for each model.
    
    * xgb_model (xgboost model): trained xgboost model
    
    * calibrated (boolean): If True, this is evaluating a calibrated model. Defaults to False.
    
    * isotonic (boolean): If True, evaluating a calibrated isotonic model.
    
    * random_state (int): Random state.
    
    * n_bootstraps (int): Number of bootstraps

    * original_models (list): List of original models before calibration.

    * filename (str): filename to save csv to.

    Returns:
    
    * optimisms_df (pandas DataFrame): dataframe of optimism corrected metrics and optimisms

    Outputs:

    * CSV file of optimism corrected metrics and optimisms
    """
    
    results = results.loc[:, [col for col in results.columns if 'train' in col.lower()]]
    optimisms = []
    for i, (model_name, model) in enumerate(models):
        res = results.loc[model_name]
        X = X_dict[model_name]
        threshold = thresholds[i]
        optimism_accuracy = []
        optimism_f1 = []
        optimism_precision = []
        optimism_recall = []
        optimism_auc = []
        optimism_specificity = []
        if calibrated and 'xgb' in model_name.lower():
            cols = [col for col in X.columns if col in xgb_model.feature_names_in_]
            #X_new = X.loc[:, xgb_model.feature_names_in_]
        else:
            cols = [col for col in X.columns if col in model.feature_names_in_]
            #X_new = X.loc[:, model.feature_names_in_]       
        if isotonic:
            X = X_dict[model_name]
            X = X.loc[:, original_models[i][1].feature_names_in_]
        else:
            X = X_dict[model_name].loc[:, cols]
        for _ in range(n_bootstraps):         
            Xb, yb = make_bootstrap(X, y, len(y), random_state=random_state)
            xg_bootstrap, m, data = train_bootstrap_model(model_name, model, Xb, yb, xgb_model, calibrated=calibrated, isotonic=isotonic)
            boot_score, boot_preds, boot_accuracy, boot_f1, boot_precision, boot_recall, boot_auc, boot_specificity = calculate_basic_binary_metrics(model_name, m, Xb, yb, threshold, xgb_model, calibrated=calibrated)
            full_score, full_preds, full_accuracy, full_f1, full_precision, full_recall, full_auc, full_specificity = calculate_basic_binary_metrics(model_name, m, X, y, threshold, xgb_model, calibrated=calibrated)
            optimism_accuracy.append(boot_accuracy - full_accuracy)
            optimism_f1.append(boot_f1 - full_f1)
            optimism_precision.append(boot_precision - full_precision)
            optimism_recall.append(boot_recall - full_recall)
            optimism_auc.append(boot_auc - full_auc)
            optimism_specificity.append(boot_specificity - full_specificity)
        mean_optimism_accuracy = np.mean(np.array(optimism_accuracy))
        mean_optimism_f1 = np.mean(np.array(optimism_f1))
        mean_optimism_precision = np.mean(np.array(optimism_precision))
        mean_optimism_recall = np.mean(np.array(optimism_recall))
        mean_optimism_auc = np.mean(np.array(optimism_auc))
        mean_optimism_specificity = np.mean(np.array(optimism_specificity))
        accuracy_new = res["Train Accuracy"] - mean_optimism_accuracy
        f1_new = res["Train F1 Score"] - mean_optimism_f1
        precision_new = res["Train Precision"] - mean_optimism_precision
        recall_new = res["Train Recall"] - mean_optimism_recall
        auc_new = res["Train AUC"] - mean_optimism_auc
        specificity_new = res["Train Specificity"] - mean_optimism_specificity
        optimisms.append({
            'Model': model_name,
            'Optimism Accuracy': mean_optimism_accuracy,
            'Optimism F1': mean_optimism_f1,
            'Optimism Precision': mean_optimism_precision,
            'Optimism Recall': mean_optimism_recall,
            'Optimism AUC': mean_optimism_auc,
            'Optimism Specificity': mean_optimism_specificity,            
            'Optimism Corrected Accuracy': accuracy_new,
            'Optimism Corrected F1': f1_new,
            'Optimism Corrected Precision': precision_new,
            'Optimism Corrected Recall': recall_new,
            'Optimism Corrected AUC': auc_new,
            'Optimism Corrected Specificity': specificity_new,
        })
    results_df = pd.DataFrame(optimisms)
    results_df.to_csv(filename)
    return results_df

def delong_auc(y_true, y_prob1, y_prob2=None):
    """
    Conduct the DeLong test for AUC comparison

    Parameters:
    
    * y_true (Pandas Series): True labels for each instance
    
    * y_prob1 (numpy array): Probability of each instance being in positive class from first model
    
    * y_prob2 (numpy array): Probability of each instance being in positive class from second model. If None, compare model to random classifier (AUC = 0.5)

    Returns:

    * z_score (float): z-score from DeLong test

    * p_value (float): p_value from DeLong test
    """
    if y_prob2 is None:
        y_prob2 = np.repeat(np.mean(y_true), len(y_true)) #generate probabilities assuming random classifier
    z_score, p_value = Delong_test(y_true, y_prob1, y_prob2) #run delong test and get z-score and p-value
    return z_score, p_value

def net_reclassification_index(y_true, y_prob1, y_prob2=None):
    """
    Conduct the Net Reclassification Index (NRI) test for AUC comparison

    Parameters:
    
    * y_true (Pandas Series): True labels for each instance
    
    * y_prob1 (numpy array): Probability of each instance being in positive class from first model
    
    * y_prob2 (numpy array): Probability of each instance being in positive class from second model. If None, compare model to random classifier (AUC = 0.5)

    Returns:

    * nri (float): Net Reclassification Index
    """ 
    #y_true = y_true.values
    if y_prob2 is None:
        y_prob2 = np.repeat(np.mean(y_true), len(y_true)) #generate probabilities assuming random classifier
    NH = 0
    NL = 0
    PH = 0
    PL = 0
    for i, y in enumerate(y_true): #loop through each prediction
        if y == 0: #negative class
        
            if y_prob1[i] < y_prob2[i]:
                NL += 1 #desire for probability to be smaller for negative class
            else:
                NH += 1
        else:
            if y_prob1[i] > y_prob2[i]:
                PH += 1 #desire for probability to be higher for positive class
            else:
                PL += 1
    return (NL - NH)/(NL + NH) + (PH - PL)/(PH + PL)

def predict_models(models, X, thresholds, xgb_model, calibrated=False, save_results=True, directory=".//model_predictions", filename='model_predictions.csv'):
    """
    Evaluate multiple models on training and testing data and save results to a CSV file.
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X (pandas DataFrame or list[DataFrame]): features
    
    * thresholds (list): List of thresholds for model predictions
    
    * xgb_model: Trained XGBoost model
    
    * calibrated (bool): If True, model has been calibrated.

    * save_results (bool): If True, save results to a CSV file.

    * directory (str): directory to save results to
    
    * filename (str): name of the file to save results, no extension

    Returns:
    
    * predictions_df (pandas DataFrame): DataFrame containing model predictions
    
    * scores_df (pandas DataFrame): DataFrame containing model scores
    """
    os.makedirs(directory, exist_ok=True)
    predictions = {}
    scores = {}
    if isinstance(X, pd.DataFrame):
        X = [X] * len(models)
    for i, (model_name, model) in enumerate(models):
        X_train = X[i].loc[:, model.feature_names_in_]
        threshold = thresholds[i]
        score, preds = get_predictions(model_name, model, X_train, threshold, calibrated, xgb_model)
        predictions[model_name] = preds
        scores[model_name] = score
    predictions_df = pd.DataFrame(predictions)
    scores_df = pd.DataFrame(scores)
    if save_results:
        os.chdir(directory)
        predictions_df.to_csv(filename, index=False)
        scores_df.to_csv(f'{filename[:-4]}_scores.csv', index=False)
        os.chdir("..")
    return predictions_df, scores_df

def compare_models(models, X, y, thresholds, xgb_model, directory=".//model_comparison", calibrated=False):
    """
    Compare performances between each model in a list
    
    Parameters:
    
    * models (list): List of trained sklearn models to evaluate
    
    * X (pandas DataFrame or list[DataFrame]): features
    
    * y: labels
    
    * thresholds (list): List of thresholds for model predictions
    
    * xgb_model: Trained XGBoost model

    * directory (str): directory to save results to
    
    * calibrated (bool): If True, model has been calibrated.

    Returns:
    
    * z_grid (pandas DataFrame): DataFrame containing z-scores for DeLong's AUC test
    
    * p_grid (pandas DataFrame): DataFrame containing p-values for DeLong's AUC test
    
    * nri_grid (pandas DataFrame): DataFrame containing Net Reclassification Indexes
    """
    os.makedirs(directory, exist_ok=True)
    if isinstance(X, pd.DataFrame):
        X = [X] * len(models)
    predictions, scores = predict_models(models, X, thresholds, xgb_model, calibrated=calibrated, save_results=False)
    model_grid = [(model1, model2) for model1 in models for model2 in models]
    p_grid = np.zeros((len(models),len(models)))
    z_grid = np.zeros((len(models),len(models)))
    nri_grid = np.zeros((len(models),len(models)))
    for i, model1 in enumerate(models):
        score1 = scores[model1[0]]
        for j, model2 in enumerate(models):
            if i == j:
                continue
            else:
                score2 = scores[model2[0]]          
                z, p = delong_auc(y.values.ravel(), score1.values.ravel(), score2.values.ravel())
                nri = net_reclassification_index(y.values.ravel(), score1.values.ravel(), score2.values.ravel())
                z_grid[i,j] = z
                p_grid[i,j] = p
                nri_grid[i,j] = nri
    z_grid = pd.DataFrame(z_grid)
    z_grid.columns = [model[0] for model in models]
    z_grid.index = [model[0] for model in models]
    p_grid = pd.DataFrame(p_grid)
    p_grid.columns = [model[0] for model in models]
    p_grid.index = [model[0] for model in models]
    nri_grid = pd.DataFrame(nri_grid)
    nri_grid.columns = [model[0] for model in models]
    nri_grid.index = [model[0] for model in models]
    os.chdir(directory)
    z_grid.to_csv('delong_z.csv')
    p_grid.to_csv('delong_p.csv')
    nri_grid.to_csv('net_reclassification_index.csv')
    sns.heatmap(z_grid)
    plt.savefig('delong_z.png')
    plt.close()
    sns.heatmap(p_grid)
    plt.savefig('delong_p.png')
    plt.close()
    sns.heatmap(nri_grid)
    plt.savefig('net_reclassification_index.png')
    plt.close()
    os.chdir("..")
    return z_grid, p_grid, nri_grid

def evaluate_kaplan_meier(X_train, y_train, kaplan_meier_models, kmf_full, author, filename="kaplan_meier_evaluation"):
    """
    Perform bootstrap resampling to estimate the distribution
    of classification metrics for multiple models and compute
    confidence intervals.

    Parameters:
    
    * X_train : array‐like, shape (n_samples, n_features)
        Feature matrix.
    
    * y_train (pandas DataFrame): dataframe with censor status and survival times
    
    * kaplan_meier_models (dict): A dictionary containing Kaplan-Meier fit results.
    
    * kmf_full (lifelines Kaplan Meier Model): model trained on full dataset
    
    * author (str): author name
    
    * filename (str, default='kaplan_meier_evaluation.csv'): Name of the output CSV file to save results.
    
    Returns:

    * pd.DataFrame

    Outputs:

    * CSV file of evaluation results

    * PDF and latex report of evaluation results
    """
    evaluation_results = []
    data = pd.concat([X_train, y_train],axis=1)
    km_plots = {}
    for col, (kmf_low, kmf_high) in kaplan_meier_models.items():
        # Create a new figure and axis
        fig, ax = plt.subplots()

        # Plot both survival functions on the same axis
        kmf_low.plot_survival_function(ax=ax, label=f'< Median')
        kmf_high.plot_survival_function(ax=ax, label=f'> Median')

        # Customize the plot
        ax.set_title(f"Kaplan-Meier Survival Function for {col}")
        ax.set_xlabel("Time (x 100 days)")
        ax.set_ylabel("Survival Probability")
        ax.legend()

        # Save and close the figure
        plt.savefig(f'kaplan_meier_{col}.png')
        km_plots[col] = f'kaplan_meier_{col}.png'
        plt.close(fig)
        median = X_train[col].median()
        data_low = data[data[col] <= median]        
        data_high = data[data[col] > median] 
        logrank_results = logrank_test(data_low['target_survival'], data_high['target_survival'], event_observed_A=data_low['target_survival_status'], event_observed_B=data_high['target_survival_status'])
        logrank_results_low_full = logrank_test(data_low['target_survival'], data['target_survival'], event_observed_A=data_low['target_survival_status'], event_observed_B=data['target_survival_status'])
        logrank_results_high_full = logrank_test(data_high['target_survival'], data['target_survival'], event_observed_A=data_high['target_survival_status'], event_observed_B=data['target_survival_status'])
        evaluation_results.append({
            'Feature': f'{col}',
            'Median Feature Value': median,
            'Median Survival Feature < Median': kmf_low.median_survival_time_,
            'Median Survival Feature > Median': kmf_high.median_survival_time_,
            'p-Value between Groups': logrank_results.p_value,
            'p-Value comparing Feature < Median to Training Data': logrank_results_low_full.p_value,
            'p-Value comparing Feature > Median to Training Data': logrank_results_high_full.p_value
        }) 
        #survival tables
        survival_table_low = survival_table_from_events(data_low['target_survival'], data_low['target_survival_status'])
        survival_table_low.to_csv(f'{col}_low_survival_table.csv')
        survival_table_high = survival_table_from_events(data_high['target_survival'], data_high['target_survival_status'])
        survival_table_high.to_csv(f'{col}_high_survival_table.csv')
    fig, ax = plt.subplots()
    kmf_full.plot_survival_function(ax=ax, label=f'< Median')
    # Customize the plot
    ax.set_title(f"Kaplan-Meier Survival Function on Entire Training Dataset")
    ax.set_xlabel("Time (x 100 days)")
    ax.set_ylabel("Survival Probability")
    ax.legend()
    # Save and close the figure
    plt.savefig(f'kaplan_meier_full.png')
    km_plots['Full Training Data'] = f'kaplan_meier_full.png'
    plt.close(fig)
    #survival table for full dataset
    survival_table_full =  survival_table_from_events(data['target_survival'], data['target_survival_status'])
    survival_table_full.to_csv('train_survival_table.csv')
    df = pd.DataFrame(evaluation_results)
    df.to_csv(f'{filename}.csv', index=False)
    lr.kaplan_meier_model_report(author, km_plots, df)
    #return df.set_index(['model', 'metric']).sort_index()
    return df

def evaluate_survival_models(X_train, y_train, X_test, y_test, LP_train, LP_test, models, author, cox=True, filename="cox_proportional_hazards_evaluation", confidence=0.95):  
    """
    Code to evaluate survival model

    Parameters

    * X_train : array‐like, shape (n_samples, n_features)
        Feature matrix.
    
    * y_train : array‐like, shape (n_samples,)
        Survival times.
    
    * X_test : array‐like, shape (n_samples, n_features)
        Feature matrix for testing.
    
    * y_test : array‐like, shape (n_samples,)
        Survival times for testing.
    
    * LP_train : array‐like, shape (n_samples,)
        Linear predictor for training data.
    
    * LP_test : array‐like, shape (n_samples,)
        Linear predictor for testing data.
    
    * models : list of (name, estimator)
        A list of tuples with a string name and fitted model
    
    * author (str): author name
    
    * filename (str, default='cox_proportional_hazards_evaluation'):
        Name of the output CSV file to save results.
    
    * confidence (float, default=0.95):
    
    * confidence level for calculating confidence interval for hazard ratios
    
    Returns

    * pd.DataFrame of evaluation results

    Outputs:

    * CSV file of evaluation results

    * PDF and latex report of evaluation results
    """
    for model_name, model, file in models:
        partial_effects_plots = {}
        print(model)
        for col in X_train.columns:
            plt.close()
            model.plot_partial_effects_on_outcome(covariates = col, values = [X_train[col].quantile(x/4) for x in range(4)], cmap = 'coolwarm')
            plt.savefig(f'{model_name}_partial_effects_{col}.png')
            partial_effects_plots[col] = f'{model_name}_partial_effects_{col}.png'
        plt.close()
        LPs = pd.Series(LP_train[model_name].values, name='Linear Predictor Value')
        plt.hist(LPs, bins=30, edgecolor='black')
        plt.title(f'Distribution of Linear Predictor Values for {model_name}')
        plt.xlabel('Linear Predictor Value')
        plt.ylabel('Frequency')
        plt.savefig(f'{model_name}_LP_distribution.png')
        plt.close()
        lp_values = np.array([LPs.quantile(x/4) for x in range(4)])
        if 'cox' in model_name.lower():
                        # Calculate the cumulative hazard function for each LP value
            cumulative_hazard = np.transpose(np.outer(model.baseline_cumulative_hazard_.values, np.exp(lp_values)))
            cumulative_hazard = np.concatenate((cumulative_hazard, np.transpose(np.array(model.baseline_cumulative_hazard_.values))), axis=0)
            # Calculate the survival function for each LP value
            survival_function = np.transpose(np.exp(-cumulative_hazard))
            plt.plot(np.unique(model.durations.values), survival_function)
            plt.title(f'Variation of Survival Functions with \n Linear Predictor Values for {model_name}')
            plt.xlabel('Time')
            plt.ylabel('Survival Probability')
            plt.legend([f'LP Quartile {i+1}: {lp_values[i]:.2f}' for i in range(4)] + ['baseline'])
            plt.savefig(f'{model_name}_survival_functions_LP.png')
            plt.close()
        # model.plot_partial_effects_on_outcome(covariates = 'Linear Predictor Value', values = [LPs.quantile(x/4) for x in range(4)], cmap = 'coolwarm')
        # plt.savefig(f'{model_name}_partial_effects_LP.png')
        # plt.close()
            partial_effects_plots['Linear Predictor Value'] = f'{model_name}_survival_functions_LP.png'
        elif 'aft' in model_name.lower():
            times = np.linspace(0, np.max(model.durations.values), 100)
            if 'weibull' in model_name.lower():
                survival_function = np.exp(-1*(np.outer(times, 1/np.exp(lp_values)))**model.params_.values[-1])
            elif 'lognormal' in model_name.lower():
                survival_function = 1 - stats.norm.cdf(-1*(np.log(times[:, np.newaxis]) - lp_values[np.newaxis, :]) / model.params_.values[-1])
            elif 'loglogistic' in model_name.lower():
                survival_function = (1 + (times[:, np.newaxis] / np.exp(lp_values[np.newaxis, :]))**(model.params_.values[-1]))**(-1)
            # Calculate the survival function for each LP value
            plt.plot(times, survival_function)
            plt.title(f'Variation of Survival Functions with \n Linear Predictor Values for {model_name}')
            plt.xlabel('Time')
            plt.ylabel('Survival Probability')
            plt.legend([f'LP Quartile {i+1}: {lp_values[i]:.2f}' for i in range(4)])
            plt.savefig(f'{model_name}_survival_functions_LP.png')
            plt.close()
        # Extract summary
        summary = model.summary
        summary = summary.reset_index()
        variables = summary['covariate']
        log_hr = summary['coef']
        if confidence == 0.95:
            ci_lower = summary['coef lower 95%']
            ci_upper = summary['coef upper 95%']
        else:
            z_score = stats.norm.ppf((1 + confidence) / 2)
            summary[f'coef lower {confidence*100}%'] = summary['coef'] - z_score*summary['se(coef)']
            summary[f'coef upper {confidence*100}%'] = summary['coef'] + z_score*summary['se(coef)']
            summary[f'exp(coef) lower {confidence*100}%'] = np.exp(summary[f'coef lower {confidence*100}%'])
            summary[f'exp(coef) upper {confidence*100}%'] = np.exp(summary[f'coef upper {confidence*100}%'])
            ci_lower = summary[f'coef lower {confidence*100}%']
            ci_upper = summary[f'coef upper {confidence*100}%']
        summary.to_csv(f"{model_name}_evaluation.csv", index=False)
        # Forest plot
        bootstrapped_df = bootstrap_cox(model_name, X_train, y_train)
        bootstrapped_df.to_csv(f'confidence_intervals_{model_name}.csv')
        if "cox" in model_name.lower():

            plt.figure(figsize=(8, 4))
            plt.errorbar(log_hr, variables, xerr=[log_hr - ci_lower, ci_upper - log_hr],
                        fmt='s', color='black', ecolor='gray', capsize=4)
            plt.axvline(x=0, color='gray', linestyle='--')
            plt.xlabel(f'log(HR) ({confidence*100}% CI)')
            plt.title('Feature Hazard Ratios')
            plt.grid(True, axis='x', linestyle='--', linewidth=0.5)
            plt.tight_layout()
            plt.savefig(f'{model_name}_coefficients.png')
            plt.close()
            rank_test = proportional_hazard_test(model, pd.concat([X_train, y_train], axis=1), time_transform='rank')
            km_test = proportional_hazard_test(model, pd.concat([X_train, y_train], axis=1), time_transform='km')
            rank_test.summary.to_csv('rank_test_proportional_hazards_assumption.csv')
            km_test.summary.to_csv('km_test_proportional_hazards_assumption.csv')
        else:
            plt.figure(figsize=(8, 4))
            plt.errorbar(log_hr, variables, xerr=[log_hr - ci_lower, ci_upper - log_hr],
                        fmt='s', color='black', ecolor='gray', capsize=4)
            plt.axvline(x=0, color='gray', linestyle='--')
            plt.xlabel(f'log(accelerated failure rate) ({confidence*100}% CI)')
            plt.title('Feature Accelerated Failure Rates')
            plt.grid(True, axis='x', linestyle='--', linewidth=0.5)
            plt.tight_layout()
            plt.savefig(f'{model_name}_coefficients.png')
            plt.close()
        lr.survival_model_report(author, model, model_name, X_train, y_train, X_test, y_test, partial_effects_plots, summary, bootstrapped_df, confidence, f"{model_name}_evaluation")
    
def bootstrap_cox(model, X_train, y_train,
    n_bootstraps: int = 100,
    sample_size: int = None,
    confidence: float = 0.95,
    metrics = None,
    random_state: int = None, filename='cox_model_bootstrap_results.csv'
) -> pd.DataFrame:
    """
    Perform bootstrap resampling to estimate the distribution
    of classification metrics for multiple models and compute
    confidence intervals.

    Parameters:

    * model_name : Name of model
    
    * X_train : array‐like, shape (n_samples, n_features)
        Feature matrix.
    
    * y_train : array‐like, shape (n_samples,)
        True labels.
    
    * n_bootstraps : int, default=1000
        Number of bootstrap samples.
    
    * sample_size : int, optional
        Size of each bootstrap sample. If None, uses len(y).
    
    * confidence : float, default=0.95
        Confidence level for the intervals.
    
    * random_state : int, optional
        Seed for reproducibility.
    
    * filename : str, default='model_bootstrap_results.csv'
        Name of the output CSV file to save results.
    
    Returns:

    * pd.DataFrame
        MultiIndexed by (model_name, metric), with columns
        ['mean', '2.5%', '97.5%'].

    Outputs:

    * CSV of bootstrap results
    """

    rng = np.random.RandomState(random_state)
    n_samples = len(y_train) if sample_size is None else sample_size
    boot_results_train = {'log likelihood': [], 'AIC index': [], 'C index': []}
    is_pandas = hasattr(X_train, 'iloc') and hasattr(y_train, 'iloc')
    # bootstrap loop
    for _ in range(n_bootstraps):
        # draw sample indices with replacement
        Xb_train, yb_train = make_bootstrap(X_train, y_train, n_samples, random_state=random_state)
        models = {'CoxProportionalHazards':CoxPHFitter(), 'WeibullAFTFitter': WeibullAFTFitter(), 
                  'LogNormalAFTFitter':LogNormalAFTFitter(), 'LogLogisticAFTFitter': LogLogisticAFTFitter()}
        # clone to reset parameters
        m = models[model]
        Xb_train = Xb_train.reset_index(drop=True)
        yb_train = yb_train.reset_index(drop=True)
        m.fit(pd.concat([Xb_train, yb_train], axis=1), duration_col = 'target_survival', event_col = 'target_survival_status')
        # compute each metric
        
        boot_results_train['log likelihood'].append(m.score(pd.concat([Xb_train, yb_train], axis=1)))
        if 'cox' in model.lower():
            boot_results_train['AIC index'].append(m.AIC_partial_)
        else:
            boot_results_train['AIC index'].append(m.AIC_)
        boot_results_train['C index'].append(m.score(pd.concat([Xb_train, yb_train], axis=1), scoring_method="concordance_index"))

    # build summary DataFrame
    rows = []
    for metric_name, metrics in boot_results_train.items():
        arr = np.array(metrics)
        if confidence not in [0.9, 0.95, 0.99]:
            lower_bound = (1 - confidence) / 2 * 100
            upper_bound = (1 + confidence) / 2 * 100
        
            rows.append({
                'metric': metric_name,
                'mean':       arr.mean(),
                '0.5%':         np.percentile(arr, 0.5),
                '2.5%':       np.percentile(arr, 2.5),
                '5.0%':         np.percentile(arr, 5),
                '95.0%':         np.percentile(arr, 95),
                '97.5%':      np.percentile(arr, 97.5),
                '99.5%':      np.percentile(arr, 99.5),
                f'{lower_bound:.1f}%': np.percentile(arr, (1 - confidence) / 2 * 100),
                f'{upper_bound:.1f}%': np.percentile(arr, (1 + confidence) / 2 * 100)
            })
        else:
            rows.append({
                'metric': metric_name,
                'mean':       arr.mean(),
                '0.5%':         np.percentile(arr, 0.5),
                '2.5%':       np.percentile(arr, 2.5),
                '5%':         np.percentile(arr, 5),
                '95%':         np.percentile(arr, 95),
                '97.5%':      np.percentile(arr, 97.5),
                '99.5%':      np.percentile(arr, 99.5)
            })
    
    df = pd.DataFrame(rows)
    df.to_csv(filename, index=False)
    return df