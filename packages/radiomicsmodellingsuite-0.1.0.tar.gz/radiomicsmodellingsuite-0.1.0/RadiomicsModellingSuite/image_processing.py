import nibabel as nib
import numpy as np
from math import ceil
from scipy.ndimage import zoom
from . import latex_reporting as lr
import gc
import SimpleITK as sitk
from pathlib import Path
def normalise_image(img, z_score=False, desired_min=0, desired_max=1):
    """
    Normalize a NIfTI image to a specified range.
    
    Parameters:
    
    * img (nib.Nifti1Image): image to process
    
    * z_score (boolean): if True, normalise images by z-score
    
    * desired_min (float): The minimum value of the normalized image, default 0.
    
    * desired_max (float): The maximum value of the normalized image, default 1.
    
    Returns:
    
    * normalized_image (nib.Nifti1Image): The normalized NIfTI image.
    """
    print("Normalizing image...")
    # Get the data from the image
    data = img.get_fdata()
    if z_score:
        mean = np.nanmean(data)
        sd = np.nanstd(data)
        normalized_data = (data - mean)/sd
        normalized_img = nib.Nifti1Image(normalized_data, img.affine, img.header)
    else:
        # Normalize the data to be between desired_min and desired_max
        data_min = np.min(data)
        data_max = np.max(data)
        # Scale to the desired range
        normalized_data = ( (data - data_min) / (data_max - data_min) )* (desired_max - desired_min) + desired_min
        # Create a new NIfTI image with the normalized data
        normalized_img = nib.Nifti1Image(normalized_data, img.affine, img.header)
    
    return normalized_img

def discretise_image(img, **kwargs):
    """
    Discretize a NIfTI image into a specified number of bins. Default: 64 bins.
    Uses direct calculation instead of np.digitize for efficiency.
    
    Parameters:
    
    * img (NIfTI): NIfTI image
    
    * num_bins (int): Number of bins (default 64)
    
    * bin_width (float): Optional fixed bin width
    
    Returns:
    
    * discretized_img (NIfTI): The discretized NIfTI image
    """
    print("Discretizing image...")
    data = img.get_fdata()  # use float32 to save memory
    dmin, dmax = np.min(data), np.max(data)

    bin_width = kwargs.get('bin_width', None)
    if bin_width is None:
        num_bins = kwargs.get('num_bins', 64)
        width = (dmax - dmin) / (num_bins - 1)
    else:
        num_bins = ceil((dmax - dmin) / bin_width) + 1
        width = (dmax - dmin) / (num_bins - 1)

    # Compute bin index and map to left edge
    indices = np.floor((data - dmin) / width).astype(np.int32)
    indices = np.clip(indices, 0, num_bins - 1)
    discretized_data = dmin + indices * width

    discretized_img = nib.Nifti1Image(discretized_data.astype(np.float32), img.affine, img.header)
    return discretized_img


def resample_nifti(img, new_voxel_size, discrete=False):
    """
    Resample a NIfTI image to a new voxel size.
    
    Parameters:
    
    * img (nib.Nifti1Image): The NIfTI image to resample.
    
    * new_voxel_size (numpy.ndarray): The desired voxel size.
    
    * discrete (Boolean): If true, the image contains only discrete values and nearest neighbour interpolation should be used. Default is False

    Returns:
    
    * resampled_img (nib.Nifti1Image): The resampled NIfTI image.
    """
    print("Resampling image...")
    # Load the NIfTI file
    data = img.get_fdata()
    affine = img.affine
    header = img.header

    # Get current voxel size from the header
    current_voxel_size = header.get_zooms()[:3]
    # Compute the zoom factors for each dimension
    zoom_factors = [current / new for current, new in zip(current_voxel_size, new_voxel_size)]
    order = 0 if discrete else 1 #use nearest neighbour if image has discrete pixel values
    # Resample the image data
    resampled_data = zoom(data, zoom_factors, order=order)  # Linear interpolation

    # Update the affine matrix to reflect new voxel size
    new_affine = affine.copy()
    for i in range(3):
        new_affine[i, i] = affine[i, i] * (current_voxel_size[i] / new_voxel_size[i])

    # Create a new NIfTI image
    resampled_img = nib.Nifti1Image(resampled_data, new_affine)

    return resampled_img
import os
def process_niftis(nifti_list, segmentation_list, procedure, batch_size=10, output_dir = ".//processed_niftis"):
    """
    Process a list of NIfTI images and their corresponding segmentations.
    
    Parameters:
    
    * nifti_list (list[list[NIfTI]]): List of list of NIfTI images for each patient to process.
    
    * segmentation_list (list[NIfTI]): List of corresponding segmentation images.
    
    * procedure (list[tuple]): List of processing steps to apply, each step is a tuple with the function name and its arguments.
    
    * batch_size (int): Number of patients to process in each batch. Default is 10.

    * output_dir (str): Directory to save processed images. Default is ".//processed_niftis".
    
    Returns:
    
    * processed_niftis (list[list[str]]): List of filenames of processed NIfTI images.

    * processed_segmentations (list[str]): List of filenames of processed segmentation images.
    """
    preprocessing_functions = {'normalise': normalise_image, 'discretise': discretise_image, 'resample': resample_nifti}
    processed_niftis = [] #list of lists of niftis for each patient
    processed_segmentations = []
    directory_path = Path(output_dir)
    # parents=True creates any missing parent directories
    # exist_ok=True prevents an error if the directory is already there
    directory_path.mkdir(parents=True, exist_ok=True)
    for batch_start in range(0, min(len(segmentation_list),len(nifti_list)), batch_size): #loop through each batch of 10 patients
        batch_end = min(batch_start + batch_size, min(len(segmentation_list),len(nifti_list))) #end of batch
        raw_niftis_list = nifti_list[batch_start:batch_end]
        for i, raw_segmentation_path in enumerate(segmentation_list[batch_start:batch_end]): #loop through each segmentation (correspond to each patient)
            raw_niftis = raw_niftis_list[i]
            processed_niftis_list = [] #list of niftis for a given patient
            for raw_nifti_path in raw_niftis: #loop through each nifti for each patient
                nifti = nib.load(raw_nifti_path)             
                segmentation = nib.load(raw_segmentation_path)
                for step in procedure: #loop through each step in procedure
                    process, *args = step
                    if len(args) > 0 and isinstance(args[0], dict):
                        args = args[0]           
                    if process == 'resample':
                        affine = nifti.affine
                        voxel_size = np.sqrt((affine[:3, :3] ** 2).sum(axis=0))
                        if not np.allclose(voxel_size, args[0]):
                            #check if current voxel size is different from desired voxel size
                            # If the voxel size is not the desired one, resample
                            nifti = resample_nifti(nifti, args[0])
                            segmentation = resample_nifti(segmentation, args[0], discrete=True)
                        else:
                            # If the voxel size is already the desired one, keep the original
                            nifti = nib.load(raw_nifti_path)
                            segmentation = nib.load(raw_segmentation_path)
                    else:
                        if isinstance(args, dict): #check if keyword arguments have been specified
                            nifti = preprocessing_functions[process](nifti, **args)
                        else:
                            nifti = preprocessing_functions[process](nifti, *args)
                        #segmentation = nib.load(raw_segmentation_path)
                nifti_filename = f"{os.path.basename(raw_nifti_path).split('.')[0]}_processed.nii.gz"
                seg_filename = f"{os.path.basename(raw_segmentation_path).split('.')[0]}_processed.nii.gz"
                nifti_path = os.path.join(output_dir, f"processed_{raw_nifti_path}")
                seg_path = os.path.join(output_dir, f"processed_{raw_segmentation_path}")
                nib.save(nifti, nifti_filename)
                nib.save(segmentation, seg_filename)
                processed_niftis_list.append(nifti_filename)
                del nifti
                del segmentation
                gc.collect()
            processed_niftis.append(processed_niftis_list)
            processed_segmentations.append(seg_filename)
    gc.collect()
    return processed_niftis, processed_segmentations


class AdditiveGaussianNoiseFilter:
    """
    Custom AdditiveGaussianNoiseFilter where mean and standard deviation can be specified.

    """
    def __init__(self, mean=0, std=1):
        """
        Initialises filter with mean and standard deviation.

        Parameters:

        * mean (float): Mean of the Gaussian noise to be added. Default is 0.\
        
        * std (float): Standard deviation of the Gaussian noise to be added. Default is 1.
        """
        self.mean = mean
        self.std = std

    def Execute(self, image):
        """
        Executes filter on image.

        Parameters:

        * image (SimpleITK.Image): The input SimpleITK image to which noise will be added.

        Returns:

        * noisy_image (SimpleITK.Image): The noisy image.
        """
        image_np = sitk.GetArrayFromImage(image)
        noise = np.random.normal(self.mean, self.std, image_np.shape)
        noisy_np = image_np + noise
        noisy_image = sitk.GetImageFromArray(noisy_np)
        noisy_image.CopyInformation(image)
        return noisy_image



def report_processing_steps(nifti_list, procedure, author, filename='image_preprocessing'):
    """
    Report the processing steps applied to the NIfTI images and segmentations.
    
    Parameters:
    
    * nifti_list (list[list[NIfTI]]): List of list of NIfTI images for each patient.
    
    * procedure (list[tuple]): List of processing steps applied with arguments.

    * author (str): Name of the author for the report.

    * filename (str): Base filename for report files (without extension). Default is image_preprocessing.
    
    Output:

    * A text file summarising processing steps.

    * A LaTeX report of the processing steps.
    """

    #define the arguments for each function
    arguments_dictionary = {
        'normalise': 'Range: ',
        'discretise': 'Number of bins: ',
        'resample': 'New voxel size: '
    }

    #define the default arguments
    default_arguments = {
        'normalise': [0, 1],
    }
    
    niftis = nifti_list
    #niftis_flattened = [item.get_fdata() for sublist in niftis for item in sublist] #extract patient data 
    #max_vals = np.array([np.max(nifti) for nifti in niftis_flattened])
    #min_vals = np.array([np.min(nifti) for nifti in niftis_flattened])
    #ranges = max_vals - min_vals
    with open(filename + ".txt", "w") as report_file:
        report_file.write("Processing Steps:\n")
        for step in procedure:
            process, *args = step
            if process in default_arguments and not args:
                args = default_arguments[process]
            if process == 'normalise' and len(args) == 1:
                report_file.write(f"{process.capitalize()} - Z-score normalisation \n") #checks if Z-score normalisation was performed and reports that
            elif process == 'discretise' and isinstance(args[0], dict):
                report_file.write(f"{process.capitalize()}\n")
                args = args[0]
                if "num_bins" in args.keys():
                    num_bins = args['num_bins']
                    report_file.write(f"Number of bins: {num_bins}\n")
                    #report_file.write(f"Mean Bin Width: {np.nanmean(ranges/(num_bins-1)):.3f}")
                elif "bin_count" in args.keys():
                    bin_count = args['bin_count']
                    report_file.write(f"Bin count: {bin_count}\n")
                else:
                    bin_width = args['bin_width']
                    report_file.write(f"Bin width: {bin_width}\n")
                    #num_bins = np.ceil(ranges / bin_width).astype(int) + 1
                    #report_file.write(f"Mean number of bins: {np.nanmean(num_bins):.3f}\n")                          
            else:    
                report_file.write(f"{process.capitalize()} - {arguments_dictionary[process]}{args}\n") #writes the function applied and argumentss
            report_file.write("\n") #blank line for better readability
    lr.processing_latex(author, procedure, default_arguments, arguments_dictionary, filename=filename)  # Generate LaTeX report