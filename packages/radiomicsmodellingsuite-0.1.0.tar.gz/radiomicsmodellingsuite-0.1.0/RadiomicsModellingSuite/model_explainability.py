import lime
from lime import lime_tabular
import numpy as np
import matplotlib.pyplot as plt
import shap
from .model_evaluation import svm_decision_function_threshold
from . import latex_reporting as lr
import pandas as pd
from scipy.special import expit  # Sigmoid function
import cvxpy as cp
from sklearn.metrics import pairwise_distances
# from survshap import SurvivalModelExplainer, ModelSurvSHAP
from scipy.integrate import trapezoid
# from survshap.predict_explanations.object import PredictSurvSHAP
# from survshap.predict_explanations.utils import prepare_result_df
# from survshap.model_explanations.utils import aggregate_change
from shap.utils._legacy import DenseData, SparseData, convert_to_data
import warnings
import os

def explain_model_lime(model_list, X_train, X_test, author, id=0, directory=".//lime_explanations", filename="lime_explainability_report"):
    """Generate LIME explanation for a given model and test instance.
    
    Args:
    
    * model_list (list): List of trained machine learning models with a predict_proba method.
    
    * X_train (pandas DataFrame): Training feature set.
    
    * X_test (pandas DataFrame): Test feature set .
    
    * author (str): Author name for the report.
    
    * id (int): Index of the test instance to explain.

    * directory (str): directory to save results
    
    * filename (str): Filename for the report.
    
    Returns:
    
    * explanations (list): List of (str, explanation) tuples for each model.

    Outputs:

    * PDF and latex report with LIME explanations and plots.

    * CSV file of results
    """
    explanations = []
    # Ensure X_test is a DataFrame with column names
    #instance = X_test.iloc[id]  # This is fine if X_test is a DataFrame
    os.makedirs(directory, exist_ok=True)
    plots = []
    os.chdir(directory)
    for model_name, model in model_list:
        X_train_new = X_train.loc[:, model.feature_names_in_]
        X_test_new = X_test.loc[:, model.feature_names_in_]
    # Create the explainer
        if hasattr(model, 'predict_proba'):
            
            explainer = lime_tabular.LimeTabularExplainer(
                training_data=X_train_new.values,  # Use .values to pass as array
                feature_names=X_train_new.columns.tolist(),
                mode='classification'
            )
            explanation_lists = []
            for i in range(X_test_new.shape[0]):
                instance = X_test_new.iloc[i]
            # Explain the instance
                explanation = explainer.explain_instance(
                    data_row=instance.values,  # Use .values to pass as array
                    predict_fn=model.predict_proba,
                    num_features=len(X_train_new.columns.tolist())
                )              
                explanation_lists.append(dict(explanation.as_list()))
                if i == id:
                    fig = explanation.as_pyplot_figure()
                    fig.tight_layout()
                    fig.savefig(f"{model_name}_lime_explanation.png", bbox_inches='tight')
                    plots.append((model_name, f"{model_name}_lime_explanation.png"))
                    plt.close()
                    explanation.save_to_file(f"{model_name}_lime_explanation.html")
                    explanations.append((model_name, explanation))
            explanation_df = pd.DataFrame(explanation_lists)
            explanation_df.to_csv(f"{model_name}_lime_explanations.csv", index=False)
            
    lr.model_explainability_lime_report(author, plots, filename=filename)
    os.chdir("..")
    return explanations

def get_kernel_width(X):
    """
    Function to get kernel width

    Parameters:
   
    * X (numpy array): array of features

    Returns:
    
    * kernel_width (float): kernel width
    """
    num_individuals = X.shape[0]
    num_features = X.shape[1]
    num_sigma_opt = 4
    den_sigma_opt = num_individuals * (num_features + 2)
    pow_sigma_opt = 1 / (num_features + 4)
    kernel_width = (num_sigma_opt / den_sigma_opt) ** pow_sigma_opt  
    return kernel_width

def generate_neighbours(X_train, data_row, num_samples, kernel_width) -> np.ndarray:
    """Generates a neighborhood around a prediction.

    Args:
    
    * X_train (pandas DataFrame): array of feature values
    
    * data_row (numpy array): row to generate neighbours
    
    * num_samples (int): number of neighbours to generate.

    * kernel_width (float): kernel width
    
    Returns:
    
    * neighbours (np.ndarray): original data point and neighbours with shape (num_samples x features).
    """
    # Generate neighbours
    num_individuals = X_train.shape[0]
    num_features = X_train.shape[1]
    sd_vector = np.std(
        X_train, axis=0
    )
    sd_matrix = kernel_width * np.diag(sd_vector)

    normal_standard = np.random.normal(
        loc=0,
        scale=1,
        size=(num_samples, num_features),
    )
    neighbours = np.matmul(normal_standard, sd_matrix) + data_row
    return neighbours

def predict_neighbours(model, neighbours, num_samples, m):
    """
    Predict value of cumulative hazard for the neighbours

    Args:

    * model (lifelines model): trained lifelines model

    * neighbours (np.ndarray): original data point and neighbours with shape (num_samples x features).

    * num_samples (int): number of neighbours to generate.

    * m (int): number of unique time to event values

    Returns:

    * prediction (np.ndarray): predicted cumulative hazard for each neighbour at each unique time to event with shape (num_samples x m).
    """
    prediction = model.predict_cumulative_hazard(neighbours)
    prediction = np.reshape(np.array(prediction), newshape=(num_samples, m))
    return prediction

def weighted_euclidean_distance(x, y, sd_sq) -> np.ndarray:
    """Compute the weighted Euclidean distance.

    Args:
    
    * x (np.ndarray): the first array.
    
    * y (np.ndarray): the second array.
    
    * sd_sq (numpy array): array of squared standard deviations of each feature

    Returns:
    
    * distance (np.ndarray): the distance between the two arrays.
    """
    diff = x - y
    diff_sq = np.square(diff)
    div = np.divide(diff_sq, sd_sq)
    distance = np.sqrt(np.sum(div))
    return distance

def kernel_fn(kernel_width, d):
    """Compute the kernel function.

    Args:
    
    * d (np.ndarray): the distance.

    Returns:
        
    * weight (np.ndarray): the kernel weight.
    """
    num = -(d**2)
    den = 2 * (kernel_width**2)
    weight = np.exp(num / den)
    return weight

def get_weights(data_point, neighbours, sd_sq, num_samples, kernel_width):
    """Compute the weights of each individual.

    Args:
    
    * neighbours (numpy array): array of features for the neighbours

    Returns:
    
    * w (np.ndarray): the weights for each individual.
    """
    # Compute weights.
    distances = pairwise_distances(
        neighbours, data_point.reshape(1, -1), metric=lambda u, v: weighted_euclidean_distance(u, v, sd_sq)
    ).ravel()
    weights = kernel_fn(kernel_width, distances)
    w = np.reshape(weights, newshape=(num_samples, 1))
    return w

def get_delta_t(unique_times, m, epsilon):
    """Compute the vector of delta times.

    Args:
    
    * unique_times (numpy array): array of unique time to event values
        
    * m (int):
        
    * epsilon (float): small value to add to last unique time

    Returns:
        
    * delta_t (np.ndarray): the vector of delta times.
    """
    t = np.empty(shape=(m + 1, 1))
    t[: m, 0] = unique_times
    t[m, 0] = t[m - 1, 0] + epsilon
    delta_t = [t[i + 1, 0] - t[i, 0] for i in range(m)]
    delta_t = np.reshape(np.array(delta_t), newshape=(m, 1))
    return delta_t

def survlime_explanation(model, training_features, training_times, data_point, neighbours, num_samples, kernel_width):
    """
    Generates explanations for a prediction.

    Args:
    
    * model (lifelines model): trained lifelines model
    
    * training_features (pandas DataFrame): dataframe with training features
    
    * data_point (Union[List[float], np.ndarray, pd.Series]): data point to be explained.
    
    * neighbours (numpy array): array of features of the neighbours
    
    * num_samples (int): number of neighbours to use.
    
    * kernel_width (float): kernel width

    Returns:
    
    * cox_values (np.ndarray): obtained weights from the convex problem.
    """
    
    unique_times = np.sort(np.unique(training_times))
    m = unique_times.shape[0]
    if 'baseline_survival_' in dir(model):
        H0 = model.baseline_survival_
    elif 'predict_survival_function' in dir(model):
        H0 = model.predict_survival_function(training_features.mean())
    H0 = H0.to_numpy()
    epsilon = 10 ** (-6)
    sd_features = np.std(
        training_features, axis=0
    )
    sd_sq = np.square(sd_features)
    num_features = neighbours.shape[1]
    cox_coefficients = np.full(shape=num_features, fill_value=np.nan)
    b = cp.Variable((num_features, 1))

    # Get predictions
    H = predict_neighbours(model, neighbours, num_samples, m)
    LnH = np.log(H + epsilon)

    # Compute the log correction
    log_correction = np.divide(H, LnH)

    # Log of baseline cumulative hazard
    LnH0 = np.log(H0 + epsilon)

    # Weights of individuals
    w = get_weights(data_point, neighbours, sd_sq, num_samples, kernel_width)

    # Time differences
    delta_t = get_delta_t(unique_times, m, epsilon)

    # Matrices to produce the proper sizes
    ones_N = np.ones(shape=(num_samples, 1))
    ones_m_1 = np.ones(shape=(m, 1))
    B = np.dot(ones_N, LnH0.T)
    C = LnH - B
    Z = neighbours.values @ b
    D = Z @ ones_m_1.T
    E = C - D
    E_prod = cp.multiply(E, log_correction)
    E_abs = cp.abs(E_prod)
    E_pow = cp.power(E_abs, 2)
    E_result = E_pow @ delta_t
    funct = E_result.T @ w
    #define objective and the problem
    objective = cp.Minimize(funct)
    prob = cp.Problem(objective)
    #solve the problem
    prob.solve(solver="OSQP", eps_abs=1e-3, eps_rel=1e-3)
    return b.value[:, 0]

def plot_survlime_explanation(weights, feature_names, id, model_name):
    """
    Plot feature importances for survival lime explanations

    Parameters:
    
    * weights (numpy array): array of feature importances
    
    * feature_names (list): list of feature names
    
    * id (int): id of patient explained
    
    * model_name (str): name of model

    Returns:
    
    * filename for plot (str)
    """
    _, ax = plt.subplots(figsize=(10,10))
    sign = [-1 if w < 0 else 1 for w in weights]
    # sort weights in descending order
    idx_sort = np.argsort(weights)[::-1]
    sorted_weights = weights[idx_sort]
    sign = np.reshape(np.array(sign), newshape=sorted_weights.shape)
    sorted_signs = sign[idx_sort]

    # sort feature names so that they match the sorted weights
    sorted_feature_names = [feature_names[i] for i in idx_sort]

    # divide the sorted weights and sorted feature names into positive and negative
    pos_weights = [w for w, s in zip(sorted_weights, sorted_signs) if s > 0]
    pos_feature_names = [
        f for f, s in zip(sorted_feature_names, sorted_signs) if s > 0
    ]
    neg_weights = [w for w, s in zip(sorted_weights, sorted_signs) if s < 0]
    neg_feature_names = [
        f for f, s in zip(sorted_feature_names, sorted_signs) if s < 0
    ]
    all_data = []
    for label, weights_separated in zip(
            [pos_feature_names, neg_feature_names],
            [pos_weights, neg_weights]
        ):
            data = pd.DataFrame({"features": label, "weights": weights_separated})
            all_data.append(data)
    data = pd.concat(all_data)
    data = data.sort_values(by="weights", axis=0, ascending=False)
    ax.bar("features", "weights", data=data, label="label")
    ax.set_xlabel("Features", fontsize=14)
    ax.set_ylabel("SurvLIME value", fontsize=14)
    ax.set_title('Feature Importance', fontsize=16, fontweight="bold")

    ax.tick_params(axis="x", labelsize=14, rotation=90)
    ax.tick_params(axis="y", labelsize=14)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    plt.tight_layout()
    plt.savefig(f'{model_name}_feature_importance_{id}.png')
    plt.close()

    data['weights'] = data['weights'].abs()
    data = data.sort_values(by="weights", axis=0, ascending=False)
    _, ax = plt.subplots(figsize=(10,10))
    ax.bar("features", "weights", data=data, label="label")
    ax.set_xlabel("Features", fontsize=14)
    ax.set_ylabel("SurvLIME value", fontsize=14)
    ax.set_title('Absolute Feature Importance', fontsize=16, fontweight="bold")

    ax.tick_params(axis="x", labelsize=14, rotation=90)
    ax.tick_params(axis="y", labelsize=14)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.yaxis.grid(True)
    ax.xaxis.grid(True)
    plt.tight_layout()
    plt.savefig(f'{model_name}_absolute_feature_importance_{id}.png')
    plt.close()
    return f'{model_name}_absolute_feature_importance_{id}.png'

def explain_model_survlime(model_list, X_train, y_train, X_test, num_samples, ids_to_explain, author, filename='survlime_model_explainability'):
    """Generate LIME explanation for a given model and list of test instances.

    Args:

    * model_list (list): List of trained machine learning models with a predict_proba method.
    
    * X_train (pandas DataFrame): Training feature set.
    
    * y_train (pandas DataFrame): Survival data 
    
    * X_test (pandas DataFrame): Test feature set .
    
    * num_samples (int): number of neighbours to generate
    
    * ids_to_explain (list): list of indices of the test set to explain
    
    * author (str): Author name for report
    
    * filename (str): Filename to save report.
    
    Returns:
    
    * explanations (list): List of (str, explanation) tuples for each model.

    Outputs:

    * PDF and latex report with SurvLIME explanations and plots.
    """
    training_features = X_train
    training_events = y_train['target_survival_status']
    training_times = y_train['target_survival'] 
    kernel_width = get_kernel_width(X_train)
    plots = {}
    explanations = []
    for name, model, file in model_list:
        plots[name] = []
        for id in ids_to_explain:
            neighbours = generate_neighbours(X_train, X_test.iloc[id].values, num_samples, kernel_width)
            neighbours = pd.DataFrame(neighbours, columns = X_train.columns)
            explanation = survlime_explanation(model, training_features, training_times, X_test.iloc[id].values, neighbours, num_samples, kernel_width)
            plot_name = plot_survlime_explanation(explanation, X_train.columns, id, name)
            plots[name].append((id, plot_name))
            explanations.append((name, id, plot_name))
    lr.model_explainability_survlime_report(author, plots, filename)
    return explanations

def explain_model_shap(model_list, X_train_old, X_test_old, threshold, author, id=0, directory=".//shap_explanations",filename="shap_explainability_report"):
    """Generate SHAP explanation for a given model and test instance.

    Args:

    * model_list (list): List of trained machine learning models with a predict_proba method.
    
    * X_train_old (pandas DataFrame): Training feature set.
    
    * X_test_old (pandas DataFrame): Test feature set .
    
    * threshold (float): threshold for SVM decision model
    
    * author (str): Author name for report
    
    * id (int): Index of the test instance to explain.

    * directory (str): directory to save results

    * filename (str): Filename to save report
    
    Returns:
    
    * explanations (list): List of (str, explanation) tuples for each model.
    
    Outputs:

    * PDF and latex report with SurvLIME explanations and plots.
    """
    os.makedirs(directory, exist_ok=True)
    explanations = []
    interaction_plots = []
    interaction_heatmaps = []
    heatmaps = []
    partial_dependence_plots = []
    waterfall_plots = []
    beeswarm_plots = []
    decision_plots = []
    force_plots = []
    embedding_plots = []
    os.chdir(directory)
    for model_name, model in model_list:
        print('model', model_name)
        X_train= X_train_old.loc[:, model.feature_names_in_]
        X_test = X_test_old.loc[:, model.feature_names_in_]        
        if 'svm' in model_name.lower() and hasattr(model, 'support_'):
            explainer = shap.KernelExplainer(lambda x: svm_decision_function_threshold(model, x, threshold), X_train)        
        elif 'tree' in model_name.lower() or 'forest' in model_name.lower() or 'xgboost' in model_name.lower() or 'lightgbm' in model_name.lower() or 'catboost' in model_name.lower():
            explainer = shap.TreeExplainer(model, X_train)
        else:
            explainer = shap.Explainer(model, X_train)
        #shap_values = explainer.shap_values(X_test, check_additivity=False)
        shap_values = explainer.shap_values(X_test)
        #explanation = explainer(X_test, check_additivity=False)
        explanation = explainer(X_test)
        #print(f'shap values {shap_values.shape}', shap_values)
        #for row in range(X_test.shape[0]):
        #if isinstance(explainer, shap.TreeExplainer):
        if 'tree' in model_name.lower() or 'forest' in model_name.lower() or 'xgboost' in model_name.lower() or 'lightgbm' in model_name.lower() or 'catboost' in model_name.lower():
            shap_interaction_values = explainer.shap_interaction_values(X_test)
            #print(f'interaction {shap_interaction_values.shape}', shap_interaction_values)
            if len(shap_values.shape) == 3:
                for i in range(shap_values.shape[2]):
                    #plot for each class
                    shap.summary_plot(shap_values[:, :, i], X_test, show=False)
                    plt.tight_layout()
                    plt.savefig(f"{model_name}_{i}_shap_summary_plot.png")
                    plt.close()
                    shap.summary_plot(shap_interaction_values[:, :, :, i], X_test, show=False)
                    plt.tight_layout()
                    plt.savefig(f"{model_name}_{i}_shap_interaction_plot.png")
                    plt.close()
                    interaction_plots.append((model_name, i, f"{model_name}_{i}_shap_interaction_plot.png"))

                    interaction_matrix = np.abs(shap_interaction_values[:, :, :, i]).sum(0)
                    for i in range(interaction_matrix.shape[0]):
                        interaction_matrix[i, i] = 0
                    inds = np.argsort(-interaction_matrix.sum(0))[:20]
                    sorted_ia_matrix = interaction_matrix[inds, :][:, inds]
                    plt.figure(figsize=(12, 12))
                    plt.imshow(sorted_ia_matrix)
                    plt.yticks(
                        range(sorted_ia_matrix.shape[0]),
                        X_test.columns[inds],
                        rotation=50.4,
                        horizontalalignment="right",
                    )
                    plt.xticks(
                        range(sorted_ia_matrix.shape[0]),
                        X_test.columns[inds],
                        rotation=50.4,
                        horizontalalignment="left",
                    )
                    plt.gca().xaxis.tick_top()
                    plt.savefig(f"{model_name}_{i}_shap_interaction_heatmap.png")
                    plt.close()
                    interaction_heatmaps.append((model_name, i, f"{model_name}_{i}_shap_interaction_heatmap.png"))
                shap.multioutput_decision_plot(explainer.expected_value, [shap_values[:, :, i] for i in range(shap_values.shape[-1])], row_index=id, feature_names=X_test.columns.tolist(), link="logit", show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_decision_plot.png")
                plt.close()
                explanation_single = explanation[id]
                shap.plots.waterfall(explanation_single[:,1], show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_waterfall_plot.png")
                plt.close()
                waterfall_plots.append((model_name, f"{model_name}_shap_waterfall_plot.png"))
                shap.force_plot(explainer.expected_value[1], explainer.shap_values(X_test.iloc[[id], :], check_additivity=False)[:,:,1],
                    feature_names=X_test.columns.tolist(), matplotlib=True, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_force_plot.png")
                plt.close()
                force_plots.append((model_name, f"{model_name}_shap_force_plot.png"))

                shap.plots.heatmap(explanation[:,:,1], show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_heatmap.png")
                plt.close()
                heatmaps.append((model_name, f"{model_name}_shap_heatmap.png"))

                shap.plots.beeswarm(explanation[:,:,1], show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_beeswarm_plot.png")
                plt.close()
                beeswarm_plots.append((model_name, f"{model_name}_shap_beeswarm_plot.png"))
                # Assuming binary classification and using class 1 SHAP values
                shap_sum = np.array([explainer.expected_value[1] + np.sum(shap_values[i,:, 1]) for i in range(len(X_test))])
                model_output = model.predict(X_test)

                # Difference between SHAP sum and model output
                differences = np.abs(shap_sum - model_output)

                # Flag samples with large discrepancy
                additivity_threshold = 0.1
                non_additive_samples = np.where(differences > additivity_threshold)[0]
                print(f"Samples with non-additivity > {additivity_threshold}: {non_additive_samples}")            
                plt.plot(model_output, label='Model Output', marker='o')
                plt.plot(shap_sum, label='SHAP Sum + Expected Value', marker='x')
                plt.title('SHAP Additivity Check')
                plt.xlabel('Sample Index')
                plt.ylabel('Probability')
                plt.legend()
                plt.grid(True)
                plt.savefig(f'{model_name}_additivity_check.png')
                plt.close()
            else:
                shap.summary_plot(shap_values, X_test, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_summary_plot.png")
                plt.close()
                shap.summary_plot(shap_interaction_values, X_test, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_interaction_plot.png")
                plt.close()
                #interaction_plots.append((model_name, i, f"{model_name}_shap_interaction_plot.png"))

                interaction_matrix = np.abs(shap_interaction_values).sum(0)
                for i in range(interaction_matrix.shape[0]):
                    interaction_matrix[i, i] = 0
                inds = np.argsort(-interaction_matrix.sum(0))[:20]
                sorted_ia_matrix = interaction_matrix[inds, :][:, inds]
                plt.figure(figsize=(12, 12))
                plt.imshow(sorted_ia_matrix)
                plt.yticks(
                    range(sorted_ia_matrix.shape[0]),
                    X_test.columns[inds],
                    rotation=50.4,
                    horizontalalignment="right",
                )
                plt.xticks(
                    range(sorted_ia_matrix.shape[0]),
                    X_test.columns[inds],
                    rotation=50.4,
                    horizontalalignment="left",
                )
                plt.gca().xaxis.tick_top()
                plt.savefig(f"{model_name}_shap_interaction_heatmap.png")
                plt.close()
                interaction_heatmaps.append((model_name, i, f"{model_name}_shap_interaction_heatmap.png"))

                shap.decision_plot(explainer.expected_value, shap_values, X_test, link="logit", show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_decision_plot.png")
                plt.close()

                #explanation_single = explainer(X_test.iloc[[id], :], check_additivity=False)
                #explanation_single = explainer(X_test.iloc[[id], :])
                #print(f'{model_name}, explainer shape: {explainer.shape}')
                explanation_single = explanation[id]
                print(explanation.shape)
                print(explanation_single.shape)
                # shap.plots.waterfall(explanation_single[0], show=False)
                shap.plots.waterfall(explanation_single, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_waterfall_plot.png")
                plt.close()
                waterfall_plots.append((model_name, f"{model_name}_shap_waterfall_plot.png"))

                shap.force_plot(explainer.expected_value,
                    explainer.shap_values(X_test.iloc[[id], :]),
                    feature_names=X_test.columns.tolist(), matplotlib=True, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_force_plot.png")
                plt.close()
                force_plots.append((model_name, f"{model_name}_shap_force_plot.png"))

                shap.plots.heatmap(explanation, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_heatmap.png")
                plt.close()
                heatmaps.append((model_name, f"{model_name}_shap_heatmap.png"))

                shap.plots.beeswarm(explanation, show=False)
                plt.tight_layout()
                plt.savefig(f"{model_name}_shap_beeswarm_plot.png")
                plt.close()
                # Assuming binary classification and using class 1 SHAP values
                shap_sum = np.array([explainer.expected_value + np.sum(shap_values[i]) for i in range(len(X_test))])
                
                

                shap_prob = expit(shap_sum)

                model_output = model.predict(X_test)

                # Difference between SHAP sum and model output
                differences = np.abs(shap_prob - model_output)

                # Flag samples with large discrepancy
                additivity_threshold = 0.1
                non_additive_samples = np.where(differences > additivity_threshold)[0]
                print(f"Samples with non-additivity > {additivity_threshold}: {non_additive_samples}")            
                plt.plot(model_output, label='Model Output', marker='o')
                plt.plot(shap_prob, label='SHAP Sum + Expected Value', marker='x')
                plt.title('SHAP Additivity Check')
                plt.xlabel('Sample Index')
                plt.ylabel('Probability')
                plt.legend()
                plt.grid(True)
                plt.savefig(f'{model_name}_additivity_check.png')
                plt.close()
               
        else:
            # For binary classification, shap_values is a 2D array
            shap.summary_plot(shap_values, X_test, show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_summary_plot.png")
            plt.close()
            interaction_plots.append((model_name, f"{model_name}_shap_summary_plot.png"))

            shap.decision_plot(explainer.expected_value, shap_values, X_test, link="logit")
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_decision_plot.png")
            plt.close()

            explanation = explainer(X_test.iloc[[id], :])
            shap.plots.waterfall(explanation[0], show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_waterfall_plot.png")
            plt.close()
            waterfall_plots.append((model_name, f"{model_name}_shap_waterfall_plot.png"))

            shap.force_plot(explainer.expected_value,
                    explainer.shap_values(X_test.iloc[[id], :]),
                    feature_names=X_test.columns.tolist(), matplotlib=True, show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_force_plot.png")
            plt.close()
            force_plots.append((model_name, f"{model_name}_shap_force_plot.png"))
            for col in X_test.columns:
                shap.embedding_plot(col,
                        shap_values,
                        feature_names=X_test.columns.tolist())
                plt.tight_layout()
                plt.savefig(f"{model_name}_{col}_shap_embedding_plot.png")
                plt.close()
                embedding_plots.append((model_name, col, f"{model_name}_{col}_shap_embedding_plot.png"))            
            shap.plots.heatmap(explainer(X_test), show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_heatmap.png")
            plt.close()
            heatmaps.append((model_name, f"{model_name}_shap_heatmap.png"))
            #explanation = explainer(X_test, check_additivity=False)
            explanation = explainer(X_test)
            shap.plots.beeswarm(explanation, show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_shap_beeswarm_plot.png")
            plt.close()
        beeswarm_plots.append((model_name, f"{model_name}_shap_beeswarm_plot.png"))

        decision_plots.append((model_name, f"{model_name}_shap_decision_plot.png"))
        if 'sv' not in model_name.lower():
            explainer = shap.Explainer(model.predict_proba, X_train)
        explanation = explainer(X_test)
        if len(explanation.values.shape) == 3:
            explanation_class1 = shap.Explanation(
                values=explanation.values[:, :, 1],         # SHAP values for class 1
                base_values=explanation.base_values[:, 1],  # Base values for class 1
                data=explanation.data,
                feature_names=explanation.feature_names
            )
        else:
            explanation_class1 = shap.Explanation(
                values=explanation.values,         # SHAP values for class 1
                base_values=explanation.base_values,  # Base values for class 1
                data=explanation.data,
                feature_names=explanation.feature_names)
        for i, col in enumerate(X_test.columns):
            shap.partial_dependence_plot(col, model.predict, X_test, ice=True,
    model_expected_value=True,
    feature_expected_value=True, show=False)
            plt.tight_layout()
            plt.savefig(f"{model_name}_{col}_shap_partial_dependence_plot.png")
            plt.close()
            partial_dependence_plots.append((model_name, col, f"{model_name}_{col}_shap_partial_dependence_plot.png"))
            shap.plots.scatter(explanation_class1[:, i], color=explanation_class1)
            plt.tight_layout()
            plt.savefig(f"{model_name}_{col}_shap_dependence_plot.png")
            plt.close()
        #if isinstance(explainer, shap.Explainer)
        explanations.append(explainer)
        
    lr.model_explainability_shap_report(author, interaction_plots, interaction_heatmaps, partial_dependence_plots, waterfall_plots, beeswarm_plots, decision_plots, force_plots, embedding_plots, heatmaps, filename=filename)
    os.chdir("..")
    return explanations

def explain_decision_tree(tree, X, sample_ids, author, filename='decision_tree_predictions'):
    """
    Code to explain decision tree predictions

    Parameters:
    
    * tree (sklearn DecisionTreeClassifier): trained decision tree
    
    * X (pandas DataFrame): feature data
    
    * sample_ids (list): list of ids to explain
    
    * author (str): name of author

    * filename (str): filename to save report

    Outputs:

    * PDF and latex report with SurvLIME explanations and plots.
    """
    feature = tree.tree_.feature
    threshold = tree.tree_.threshold
    node_indicator = tree.decision_path(X)
    leaf_id = tree.apply(X)
    predictions = tree.predict(X)
    n_nodes = tree.tree_.node_count
    lr.explain_tree_predictions_report(author, X, sample_ids, predictions, n_nodes, node_indicator, leaf_id, feature, threshold, filename=filename)
