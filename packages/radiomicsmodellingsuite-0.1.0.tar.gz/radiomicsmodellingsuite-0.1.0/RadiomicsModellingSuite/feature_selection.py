import pandas as pd
import numpy as np
from . import latex_reporting as lr
from . import dataset_manipulation as dm
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from scipy.spatial.distance import squareform
from scipy.stats import mannwhitneyu, wilcoxon, kruskal
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import ols
from patsy import dmatrices
from sklearn.feature_selection import SelectKBest, chi2, f_classif
from sklearn.decomposition import PCA
from sklearn.feature_selection import RFE
import os

def num_features(n, method, train_ratio=0.8):
    """
    Calculate the number of features to select based on the sample size and method.
    
    Parameters:
    
    * n (int): The size of the sample. If method is curse of dimensionality, n is number of elements in majority class
    
    * method (str): The method used for feature selection.
    
    Returns:
    
    * int: The number of features to select.
    """
    if method.upper() == "LDA":
        return int(n ** 0.5)  # LDA selects sqrt(n) features
    elif method.upper() == "CURSE OF DIMENSIONALITY":
        print(f"Note: Assuming {n} is the number of elements in majority class")
        return int((2*train_ratio*n)**0.5) #curse of dimensionality selects sqrt(2 train_ratio * n) features
    
def remove_constant_columns(data):
    """
    Remove feature columns where every value is the same
    
    Parameters:
    
    * data (pandas DataFrame): data to remove redundant columns
    
    Returns:
    
    * modified dataframe with columns where every value is the same has been removed
    """
    return data.loc[:, ~np.isclose(data.std(), 0) | data.columns.str.contains('target_')]

def drop_columns_by_name(X, columns_to_drop):
    """
    Drop columns by names specified by user.

    Parameters:

    * X (pandas DataFrame): dataframe

    * columns_to_drop (list[str]): list of column names to drop

    Returns:

    * X_selected (pandas DataFrame): dataframe with specified columns dropped
    """
    X_selected = X.copy()
    for col_name in columns_to_drop:
        # if col_name in X_selected.columns:
        X_selected = X_selected.drop(columns=[col for col in X_selected.columns if col_name in col])
    return X_selected

def get_correlations(X, y=None, target_name="target", feature_correlation='pearson', target_correlation='pearson', save_correlations=True):
    """
    Get correlations between features and between features and target
    
    Parameters:
    
    * X (pandas DataFrame): features
    
    * y (pandas Series): target
    
    * target_name (str): name of target
    
    * feature_correlation (str): correlation to compute between features, default is Pearson
    
    * target_correlation (str): correlation to compute between feature and target, default is Pearson
    
    * save_correlations (Boolean): if True, save correlations to a csv file
    
    Returns:
    
    * feature_correlations (pandas DataFrame): dataframe with inter feature correlations
    
    * target_correlations (pandas Series): series with feature correlations to target

    Output:

    * if save_correlations is True, saves feature_correlations to 'feature_correlations.csv' and target_correlations to 'target_correlations.csv'
    """
    feature_correlations = X.corr(method=feature_correlation, min_periods=2)
    if save_correlations:
        feature_correlations.to_csv("feature_correlations.csv")
    if y is not None:
        target_correlations = X.corrwith(y.iloc[:, 0], method=target_correlation)
        if save_correlations:
            target_correlations.to_frame(name=target_name).to_csv('target_correlations.csv')
    else:
        target_correlations = None

    return feature_correlations, target_correlations

def get_correlated_features(feature_correlations, feature_correlation_threshold, target_correlations):
    """
    Determine which features are correlated with each other above a certain threshold and which of the correlated features to drop based on correlation with target variable.
    
    Parameters:
    
    * feature_correlations (pandas DataFrame): dataframe with inter feature correlations
    
    * feature_correlation_threshold (float): maximum inter feature correlation where both features are retained
    
    * target_correlations (pandas Series): series with feature correlations to target

    Returns:

    * features_to_drop (set): set of feature names to drop based on high inter feature correlation and lower correlation with target variable
    """
    correlated_features =  []
    for i in range(len(feature_correlations.columns)):
        for j in range(i):
            if abs(feature_correlations.iloc[i, j]) > feature_correlation_threshold:
                colname = feature_correlations.columns[i]
                rowname = feature_correlations.columns[j]
                correlated_features.append((colname,rowname))
    features_to_drop = set()
    for feature1, feature2 in correlated_features:
        if feature1 in features_to_drop or feature2 in features_to_drop:
            continue
        corr_1 = target_correlations[feature1]
        corr_2 = target_correlations[feature2]
        if np.abs(corr_1) > np.abs(corr_2):
            features_to_drop.add(feature2)
        else:
            features_to_drop.add(feature1)
    return features_to_drop

def filter_by_correlations(author, X, y, target_correlation_threshold, feature_correlation_threshold, report=False, num_features=None, feature_correlation='pearson', target_correlation='pearson', filename='feature_selection'):
    """
    Filter features by correlations with each other and target variable
    
    Parameters:  

    * author (str): author name

    * X (pandas DataFrame): features

    * y (pandas Series): target
    
    * target_correlation_threshold (float): minimum absolute correlation with target value
    
    * feature_correlation_threshold (float): maximum inter feature correlation where both features are retained
    
    * report (Boolean): whether to report pipeline.
    
    * feature_correlation (str): correlation to compute between features, default is Pearson
    
    * target_correlation (str): correlation to compute between feature and target, default is Pearson
    
    * filename (str): filename for report

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    if num_features is not None: #if number of features are specified, filter features by top num_features target_correlations
        feature_correlations, target_correlations = get_correlations(X, y, feature_correlation=feature_correlation, target_correlation=target_correlation, save_correlations=False)
        X_selected = X.loc[:, np.abs(target_correlations) > np.abs(target_correlation_threshold)] #filter by minimum target correlation threshold
        feature_correlations, target_correlations = get_correlations(X_selected, y, feature_correlation=feature_correlation, target_correlation=target_correlation, save_correlations=False)
        features_to_drop = get_correlated_features(feature_correlations, feature_correlation_threshold, target_correlations)
        X_selected = X_selected.drop(columns=features_to_drop)
        if len(X_selected.columns) < num_features:
            print(f"Warning: only {len(X_selected.columns)} features remain after applying correlation thresholds, which is less than the specified number of features to select ({num_features}). Consider adjusting the correlation thresholds or number of features to select.")
            print("Meeting the correlation thresholds was prioritised over meeting the specified number of features to select.")
            return X_selected
        # Get the top n features with highest absolute correlation values
        feature_correlations, target_correlations = get_correlations(X_selected, y, feature_correlation=feature_correlation, target_correlation=target_correlation, save_correlations=False)
        top_features = target_correlations.abs().nlargest(num_features).index

        # Select those features from X_selected
        X_selected = X[top_features]
        args = {'method': f'a maximum threshold was used for inter feature correlation and a minimum threshold was used for target correlation. The number of features selected was {num_features}.',
        'target correlation threshold':target_correlation_threshold, 
            'feature correlation threshold':feature_correlation_threshold, 
            'feature correlation method': feature_correlation, 
            'target correlation method': target_correlation}
    else:
        feature_correlations, target_correlations = get_correlations(X, y, feature_correlation=feature_correlation, target_correlation=target_correlation, save_correlations=False)
        X_selected = X.loc[:, np.abs(target_correlations) > np.abs(target_correlation_threshold)] #filter by minimum target correlation threshold
        feature_correlations, target_correlations = get_correlations(X_selected, y, feature_correlation=feature_correlation, target_correlation=target_correlation, save_correlations=False)
        features_to_drop = get_correlated_features(feature_correlations, feature_correlation_threshold, target_correlations)
        X_selected = X_selected.drop(columns=features_to_drop)
        args = {'method': 'a maximum threshold was used for inter feature correlation and a minimum threshold was used for target correlation.',
        'target correlation threshold':target_correlation_threshold, 
            'feature correlation threshold':feature_correlation_threshold, 
            'feature correlation method': feature_correlation, 
            'target correlation method': target_correlation}
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Minimum absolute {target_correlation} correlation with target value: {target_correlation_threshold}\n")
            f.write(f"maximum inter feature {feature_correlation} correlation where both features are retained: {feature_correlation_threshold}\n")
            if num_features is not None:
                f.write(f"Fixed number of features (n={num_features}) were selected.")
            f.write(f"Number of features remaining: {len(X_selected.columns)}\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n")
        
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_correlation_clustering(author, X, y, threshold, report=False, num_features=None, target_correlation_threshold=0, linkage_method='single', feature_correlation='pearson', target_correlation='pearson', filename='feature_selection'):
    """
    Filter features by hierarchical clustering using correlation as a distance matrix.
    
    Parameters:  
    * author (str): author name
    
    * X (pandas DataFrame): features
    
    * y (pandas Series): target   
    
    * report (Boolean): whether to report pipeline.
    
    * threshold (float): Maximum inter feature correlation where both features are retained.
    
    * target_correlation_threshold (float): minimum absolute correlation with target value
    
    * feature_correlation (str): correlation to compute between features, default is Pearson
    
    * target_correlation (str): correlation to compute between feature and target, default is Pearson
    
    * filename (str): location to report feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    threshold = 1-threshold #convert threshold from maximum inter feature correlation to minimum dissimilarity for clustering
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    correlations, target_correlations = get_correlations(X, y, feature_correlation=feature_correlation, target_correlation=target_correlation)
    X_selected = X.loc[:,  X.columns[np.abs(target_correlations.values) > np.abs(target_correlation_threshold)]]  
    correlations = correlations.clip(-1, 1)
    plt.figure(figsize=(12,5))
    dissimilarity = 1 - abs(correlations)
    dissimilarity = dissimilarity.values
    dissimilarity = (dissimilarity + dissimilarity.T) / 2  # Ensure the matrix is symmetric
    dissimilarity = np.clip(dissimilarity, 0, 1)
    np.fill_diagonal(dissimilarity, 0) 
    Z = linkage(squareform(dissimilarity), linkage_method)
    dendrogram(Z, labels=X.columns, orientation='top', leaf_rotation=90)
    plt.savefig('dendrogram.png')
    plt.close()
    if num_features is not None:
        criterion='maxclust'
        labels = fcluster(Z, num_features, criterion=criterion)
    else:
        criterion='distance'
        labels = fcluster(Z, threshold, criterion=criterion)
    # Create a DataFrame with target correlations and cluster labels
    feature_cluster_df = pd.DataFrame({
        'target_correlation': target_correlations,
        'cluster_label': labels,
        'absolute_correlation': np.abs(target_correlations)
    })
    columns_to_drop = []
    for label in list(np.unique(labels)):
        cluster_df = feature_cluster_df[feature_cluster_df['cluster_label'] == label] #df with features in that cluster
        max_correlation = cluster_df['absolute_correlation'].max() #obtain maximum correlation coefficient
        if len(cluster_df) > 1:
            column_retained = False #checks if features with correlation equal to max correlation have been dropped
            for index, row in cluster_df.iterrows():
                if row['absolute_correlation'] < max_correlation or (row['absolute_correlation'] == max_correlation and column_retained):
                    columns_to_drop.append(index)
                elif row['absolute_correlation'] == max_correlation and not column_retained:
                    column_retained = True #record that column has been retained if it is equal to max correlation and column has not already been retained
    
    X_selected = X_selected.drop(columns = columns_to_drop)
    if report:
        with open(f"{filename}.txt", "w") as f: #report feature extraction to txt
            f.write("Selection performed using hierarchical clustering.\n")     
            if isinstance(threshold, float):
                f.write(f"maximum inter feature {feature_correlation} correlation where both features are retained: {threshold}")
                args = {'method': 'hierarchical clustering using 1 - correlation as a distance metric.',
                'linkage method': linkage_method,
                'target correlation threshold':target_correlation_threshold, 
                'feature correlation threshold':threshold, 
                'feature correlation method': feature_correlation, 
                'target correlation method': target_correlation}
            else:
                f.write("Fixed number of features to be extracted.\n")
                args = {'method': 'hierarchical clustering using 1 - correlation as a distance metric. Fixed number of features to be extracted.',
                'linkage method': linkage_method,
                'target correlation threshold':target_correlation_threshold, 
                'feature correlation method': feature_correlation, 
                'target correlation method': target_correlation}
            f.write(f"Minimum absolute {target_correlation} correlation with target value: {target_correlation_threshold}")
            f.write(f"Number of features remaining: {len(X_selected.columns)}\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n")
        
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_mann_whitney_u(author, X, y, alpha, report=False, num_features=None, filename='feature_selection'):
    """
    Filter features using a Mann-Whitney U test
    
    Parameters:  
    * author (str): author name

    * X (pandas DataFrame): features
    
    * y (pandas Series): target   
    
    * alpha (float): significance level
    
    * report (Boolean): whether to report pipeline.
    
    * num_features (int): Number of features to retain. If None, all features with p > alpha are retained.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    df = pd.concat([X, y], axis=1)
    #separate out negative and positive cases
    negatives = df[df[df.columns[-1]] == 0].copy()
    negatives.drop(columns=[df.columns[-1]], inplace=True)
    positives = df[df[df.columns[-1]] == 1].copy()
    positives.drop(columns=[df.columns[-1]], inplace=True)
    stats, ps = mannwhitneyu(negatives,positives)
    columns_to_drop = []
    if num_features is not None:
        # Get indices of the top num_features significant features (smallest p-value)
        top_indices = np.argsort(ps)[:num_features]
        # Select columns from X using those indices
        X_selected = X.iloc[:, top_indices]
        args = {'method': f'Mann-Whitney U-test used to perform feature selection. The {num_features} most significant were selected.',
        'significance level': alpha}
    else:
        args = {'method': 'Mann-Whitney U-test used to perform feature selection',
        'significance level': alpha}
        for i, p in enumerate(list(ps)): #filter out non robust features (small p value)
            if p >= alpha:
                columns_to_drop.append(df.columns[i])
        X_selected = X.drop(columns=columns_to_drop)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Mann-Whitney U-test with significance level {alpha} used to perform feature selection.\n")
            f.write(f"Number of features remaining: {len(X_selected.columns)}\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n")   
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_kruskal_wallis(author, X, y, alpha, report=False, num_features=None, filename='feature_selection'):
    """
    Filter features using a Kruskal Wallis test
    
    Parameters:  
    * author (str): author name

    * X (pandas DataFrame): features
    
    * y (pandas Series): target   
    
    * alpha (float): significance level
    
    * report (Boolean): whether to report pipeline.
    
    * num_features (int): Number of features to retain. If None, all features with p > alpha are retained.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    df = pd.concat([X, y], axis=1)
    
    # Group data by each unique target value
    groups = []
    target_col = df.columns[-1]
    for value in df[target_col].unique():
        group = df[df[target_col] == value].copy()
        group.drop(columns=[target_col], inplace=True)
        groups.append(group)

    # Perform Kruskal-Wallis test across all groups
    stats, ps = kruskal(*groups)

    columns_to_drop = []
    if num_features is not None:
        # Get indices of the top num_features significant features (smallest p-value)
        top_indices = np.argsort(ps)[:num_features]
        # Select columns from X using those indices
        X_selected = X.iloc[:, top_indices]
        args = {'method': f'Kruskal-Wallis test used to perform feature selection. The {num_features} most significant were selected.',
        'significance level': alpha}
    else:
        args = {'method': 'Kruskal-Wallis test  used to perform feature selection',
        'significance level': alpha}
        for i, p in enumerate(list(ps)): #filter out non robust features (small p value)
            if p >= alpha:
                columns_to_drop.append(df.columns[i])
        X_selected = X.drop(columns=columns_to_drop)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Kruskal-Wallis test with significance level {alpha} used to perform feature selection.\n")
            f.write(f"Number of features remaining: {len(X_selected.columns)}\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n")   
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_wilcoxon(author, X, y, alpha, num_features=None, report=False, filename='feature_selection'):
    """
    Filter features using a Wilcoxon Signed Rank Test
    
    Parameters:  
        
    * author (str): author name

    * X (pandas DataFrame): features
    
    * y (pandas Series): target   
    
    * alpha (float): significance level
    
    * num_features (int): Number of features to retain. If None, all features with p > alpha are retained.
    
    * report (Boolean): whether to report pipeline.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    df = pd.concat([X, y], axis=1)
    #separate out negative and positive cases
    negatives = df[df[df.columns[-1]] == 0].copy()
    negatives.drop(columns=[df.columns[-1]], inplace=True)
    positives = df[df[df.columns[-1]] == 1].copy()
    positives.drop(columns=[df.columns[-1]], inplace=True)
    #calculate wilcoxon stat and p values
    stats, ps = mannwhitneyu(negatives,positives)
    columns_to_drop = []
    
    if num_features is not None:
        # Get indices of the top num_features significant features (smallest p-value)
        top_indices = np.argsort(ps)[:num_features]
        # Select columns from X using those indices
        X_selected = X.iloc[:, top_indices]
        args = {'method': f'Wilcoxon Signed Rank test used to perform feature selection. The {num_features} most significant features were selected.',
        'significance level': alpha}
    else:
        for i, p in enumerate(list(ps)): #filter out features without significant difference between positive and negative (large p value)
            if p >= alpha:
                columns_to_drop.append(df.columns[i])
        X_selected = X.drop(columns=columns_to_drop)
        args = {'method': 'Wilcoxon Signed Rank test used to perform feature selection',
        'significance level': alpha}
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Wilcoxon Signed Rank test with significance level {alpha} used to perform feature selection.\n")
            f.write(f"Number of features remaining: {len(X_selected.columns)}\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n")   
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_f_anova(author, X, y, num_features=10, report=False, filename="feature_selection"):
    """
    Filter features using f anova
    
    Parameters:  
        
    * author (str): author name

    * X (pandas DataFrame): numerical features
    
    * y (pandas Series): target   
    
    * num_features (int): Number of features to retain.

    * report (Boolean): whether to report pipeline.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    selector = SelectKBest(score_func=f_classif, k=num_features)
    X_new = selector.fit_transform(X, y)
    
    # Get the selected column names
    selected_columns = X.columns[selector.get_support()]
    
    # Convert the result back to a DataFrame with column names
    X_selected = pd.DataFrame(X_new, columns=selected_columns, index=X.index)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"f-score ANOVA used for feature selection. The {len(X_selected.columns)} best features were selected.\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n") 
        args = {'method': f'f-score ANOVA test was used for feature selection. The {num_features} best features were selected.'}  
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def filter_chisq(author, X, y, num_features=10, report=False, filename="feature_selection"):
    """
    Filter features using chi square
    
    Parameters:  
        
    * author (str): author name

    * X (pandas DataFrame): categorical features
    
    * y (pandas Series): target   
    
    * num_features (int): Number of features to retain.
 
    * report (Boolean): whether to report pipeline.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * X_selected (pandas DataFrame): features selected

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    X = X.drop(columns=X.columns[np.isclose(X.std(), 0)])
    selector = SelectKBest(score_func=chi2, k=num_features)
    X_new = selector.fit_transform(X, y)
    
    # Get the selected column names
    selected_columns = X.columns[selector.get_support()]
    
    # Convert the result back to a DataFrame with column names
    X_selected = pd.DataFrame(X_new, columns=selected_columns, index=X.index)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Chi-square used for feature selection. The {len(X_selected.columns)} best features were selected.\n")
            f.write("Features selected:\n")
            for col in X_selected.columns:
                f.write(f"{col}\n") 
        args = {'method': f'Chi-square test was used for feature selection. The {num_features} best features were selected.'}  
        lr.selection_report(author, X_selected, args, filename=filename)
    return X_selected

def compute_iccs(X1, X2, threshold, report=False, filename="feature_selection_robustness"):
    """
    Filter features using ICC
    
    Parameters:  
    
    * X1 (pandas DataFrame): features from first segmentation
    
    * X2 (pandas DataFrame): features from second segmentation
    
    * threshold (float): minimum ICC for feature to be retained
    
    * report (Boolean): whether to report pipeline.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * iccs (list[float]): list of ICC values
    
    * cols_to_drop (list[str]): list of columns to drop

    Outputs:

    * txt report saved to filename if report is True
    """
    df = dm.combine_dataframes([X1, X2])
    
    iccs = []
    cols_to_drop = []
    features = [col for col in df.columns if col not in ['patient_id', 'segmentation']]
    for feature in features:
        valid_values = df[feature].dropna().unique()
        if len(valid_values) <= 1:
            print(f"{feature}: skipped (only one unique non-NaN value)")
            continue
        elif feature == 'ID':
            continue
        model = ols(f'Q("{feature}") ~ C(patient_id) + C(segmentation)', data=df).fit()
        
        rank = np.linalg.matrix_rank(model.model.exog)
        cols = model.model.exog.shape[1]
        if rank < cols:
            print(f"Skipping feature {feature} due to rank deficiency")
            continue

        anova_table = sm.stats.anova_lm(model, typ=2)
        MS_subject = anova_table.loc['C(patient_id)', 'sum_sq'] / anova_table.loc['C(patient_id)', 'df']
        MS_rater = anova_table.loc['C(segmentation)', 'sum_sq'] / anova_table.loc['C(segmentation)', 'df']
        MS_residual = anova_table.loc['Residual', 'sum_sq'] / anova_table.loc['Residual', 'df']

        k = df['segmentation'].nunique()
        n = df['patient_id'].nunique()

        icc = (MS_subject - MS_residual) / (MS_subject + (k - 1) * MS_residual + (k * (MS_rater - MS_residual) / n))
        iccs.append(icc)
        if np.abs(icc) < threshold:
            cols_to_drop.append(feature)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Features filtered using a minimum ICC(2,1) of {threshold} used to perform feature selection.\n")
            f.write(f"Number of features remaining: {len(features) - len(cols_to_drop)}\n")
            f.write("Features selected:\n")
            for column in [col for col in features if col not in cols_to_drop]:
                f.write(f"{column}\n")
    return iccs, cols_to_drop

def concordance_correlation_coefficient(X1, X2, threshold, report=False, filename='feature_selection_robustness'):
    """
    Concordance correlation coefficient.

    Parameters:      
    
    * X1 (pandas DataFrame): features from first segmentation
    
    * X2 (pandas DataFrame): features from second segmentation
    
    * threshold (float): minimum ICC for feature to be retained
    
    * report (Boolean): whether to report pipeline.
    
    * filename (str): filename to save feature selection results

    Returns:
    
    * cccs (list[float]): list of ICC values
    
    * cols_to_drop (list[str]): list of columns to drop

    Outputs:

    * PDF and latex report saved to filename if report is True
    """
    #drop NaNs
    X1 = X1.dropna()
    X2 = X2.dropna()
    cccs = []
    cols_to_drop = []
    features = [col for col in X1.columns if col not in ['patient_id', 'segmentation']]
    for feature in features:
        feature1 = X1[feature]
        feature2= X2[feature]
        # Pearson product-moment correlation coefficients
        cor = np.corrcoef(feature1, feature2)[0][1]
        # Means
        mean_1 = np.mean(feature1)
        mean_2 = np.mean(feature2)
        # Population variances
        var_1 = np.var(feature1)
        var_2 = np.var(feature2)
        # Population standard deviations
        sd_1 = np.std(feature1)
        sd_2 = np.std(feature2)
        # Calculate CCC
        numerator = 2 * cor * sd_1 * sd_2
        denominator = var_1 + var_2 + (mean_1 - mean_2)**2
        ccc = numerator/denominator
        cccs.append(ccc)
        if np.abs(ccc) < threshold:
            cols_to_drop.append(feature)
    if report:
        with open(f"{filename}.txt", "w") as f:
            f.write(f"Features filtered using a minimum CCC of {threshold} used to perform feature selection.\n")
            f.write(f"Number of features remaining: {len(features) - len(cols_to_drop)}\n")
            f.write("Features selected:\n")
            for column in [col for col in features if col not in cols_to_drop]:
                f.write(f"{column}\n")
    return cccs, cols_to_drop

def select_features(X, y, pipeline, author, num_features=None, X1=None, X2=None, directory = ".//feature_selection", filename='feature_selection_pipeline'):
    """
    Select features using a pipeline

    Parameters:
     
    * X (pandas DataFrame): numerical features

    * y (pandas Series): target 
    
    * pipeline (dict): description of pipeline in format: {type: (function, {'args': (tuple of args), 'kwargs': {dict of kwargs}}))  
    
    * author (str): author name   
    
    * num_features (int): number of features to retain at the end of the pipeline. If None, all features from the last step are retained.

    * X1 (pandas DataFrame): features from first segmentation
    
    * X2 (pandas DataFrame): features from second segmentation

    * directory (str): name of directory to save feature extraction results to.

    * filename (str): filename to save feature selection results

    Returns:
    
    * X (pandas DataFrame): numerical features selected
    """
    if num_features is not None:
            #if func == pipeline[key][-1][0]:
        pipeline['redundancy'][-1][-1]['kwargs']['num_features'] = num_features
    else:
        num_features = pipeline['redundancy'][-1][-1]['kwargs']['num_features']  
    if 'columns_to_keep' in pipeline:
        X_keep = X.loc[:, [col for col in X.columns if any(name.lower() in col.lower() for name in pipeline['columns_to_keep'])]]
        if num_features is not None:
            if len(X_keep.columns) < num_features:
                X = X.drop(columns=X_keep.columns) 
                num_features = num_features - len(X_keep.columns)
                pipeline['redundancy'][-1][-1]['kwargs']['num_features'] = num_features
            elif len(X_keep.columns) == num_features:
                return X_keep
            else:
                X = X_keep
        else:
            X = X_keep
    else:
        X_keep = None
    pipeline_original = pipeline.copy()
    pipeline = {key: pipeline[key] for key in pipeline if key.lower() != 'columns_to_keep'}
    for key in pipeline:
        for func, params in pipeline[key]:
            args = params.get('args', ())
            kwargs = params.get('kwargs', {})
            print(f"Running {func.__name__} with args={args} and kwargs={kwargs}")           
            if key.lower() == 'robustness':
                corrs, cols_to_drop = func(X1, X2, *args, **kwargs)
                X.drop(columns=cols_to_drop, inplace=True)
            elif key.lower() == 'redundancy':          
                X = func(author, X, y, *args, **kwargs)
                if len(X.columns) == num_features:
                    break #break if required number of features already obtained
    if X_keep is not None and num_features is not None and len(X_keep.columns) < num_features:
        X = pd.concat([X, X_keep], axis=1)
    lr.selection_pipeline_report(author, X, pipeline_original, directory=directory, filename=filename)
    os.chdir("..")
    return X

def pca(X_train, author, X_test=None, components=None, directory = ".//feature_selection"):
    """
    Conducts PCA to reduce dimensionality

    Parameters:
    
    * X_train (pandas DataFrame): features from training set

    * author (str): author name

    * X_test (pandas DataFrame): features from testing set. If None, no transformation is applied to test set.
    
    * components (int or float): if int, number of components to retain. If float, proportion of explained variance to retain

    * directory (str): directory to save PCA report
    
    Returns:

    * pca_model (sklearn PCA object): fitted PCA model

    * X_train_pca (pandas DataFrame): transformed training features

    * X_test_pca (pandas DataFrame): transformed testing features

    Outputs:

    * PDF and latex report reporting PCA results
    """
    os.makedirs(directory, exist_ok=True)
    pca_model = PCA(n_components=components)
    pca_model.fit(X_train)
    pca_full = PCA(n_components=None)  # Fit PCA to full data for reporting
    pca_full.fit(X_train)
    X_train_pca = pca_model.transform(X_train)
    X_train_pca = pd.DataFrame(X_train_pca)
    if X_test is not None:
        X_test_pca = pca_model.transform(X_test)
        X_test_pca = pd.DataFrame(X_test_pca)
    else:
        X_test_pca = None
    lr.pca_report(author, pca_full, components, directory=directory)
    os.chdir("..")
    return pca_model, X_train_pca, X_test_pca

def recursive_feature_elimination(model, X, y, num_features, author, step=1, directory = ".//feature_selection", filename='rfe_report'):
    """
    Perform Recursive Feature Elimination (RFE) to select features

    Parameters:
    
    * model (sk learn model): machine learning model with ``feature_importances_`` or ``coef_`` attribute
    
    * X (pandas DataFrame): features
    
    * y (pandas Series): target
    
    * num_features (list): list of number of features to select
    
    * author (str): author name
    
    * step (int): number of features to remove at each iteration

    * directory (str): directory to save RFE report
    
    * filename (str): filename to save RFE report  

    Returns:
    
    * X_selecteds (list of pandas DataFrame): list of selected features for each number of features specified

    Outputs:

    * PDF and latex report saved to filename
    """
    rfe = RFE(estimator=model, n_features_to_select=1, step=step)
    rfe.fit(X, y)
    ranks = rfe.ranking_
    X_selecteds = []
    for n in num_features:
        indices = np.argsort(ranks)[:n]
        X_selected = X.iloc[:, indices]
        X_selecteds.append(X_selected)
    lr.rfe_report(author, X.columns, ranks, directory=directory, filename=filename)
    os.chdir("..")
    return X_selecteds