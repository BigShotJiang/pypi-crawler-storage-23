import pydicom as dicom
import numpy as np
import os
import pandas as pd
import dicom2nifti
from copy import deepcopy
dicom2nifti.settings.disable_validate_slice_increment()
from . import latex_reporting as lr
from . import string_formatting as sf

def obtain_acquisition_parameters(directory_list, scan_types, author, filename="acquisition_parameters.csv", max_string_length = 3, latex_sections=['Information', 'Paragraphs', 'all_tables', 'Tables']):
  """
    Function to obtain acquisition parameters from the dicom files in the directory_list

    Parameters:
        
        * directory_list (list[str]) - list of directories containing the dicom slices
        
        * scan_types (list[str]) - list of scan types studied
        
        * author (str) - author name for latex report
        
        * filename (str) - filename to save acquisition parameters to
        
        * max_string_length (int) - maximum number of count values to write in a paragraph, if bigger than this maximum, 
                                 the paragraph will be written as a table instead
        
        * latex_sections (list[str]) - list of sections to include in latex report
    
    Outputs:
        
        * csv file with acquisition parameters from each scan

        * pdf and latex file with acquisition parameters
    """
  mri_acquisition_dict = {'Manufacturer': [], 'SeriesDescription': [], 'ManufacturerModelName': [], 'ContrastBolusAgent': [], 'ScanningSequence': [], 
                      'SequenceVariant': [], 'ScanOptions': [], 'SliceThickness': [], 'ImagingFrequency': [], 'RepetitionTime': [], 'EchoTime': [], 'InversionTime': [], 
                      'MagneticFieldStrength': [], 'NumberOfPhaseEncodingSteps': [], 'EchoTrainLength': [], 'ContrastBolusVolume': [], 'InPlanePhaseEncodingDirection': [], 
                      'FlipAngle': [], 'PixelSpacing': [], 'SpacingBetweenSlices': [], 'dBdt': [], 'ImageDimensions': []} #dictionary to store acquisition parameters for MRI images
  mri_numerical_keys = [key for key in mri_acquisition_dict.keys() if key not in ['Manufacturer', 'SeriesDescription', 'ManufacturerModelName', 'ContrastBolusAgent', 'ScanningSequence',
                      'SequenceVariant', 'ScanOptions', 'InPlanePhaseEncodingDirection', 'PixelSpacing', 'ImageDimensions']] #list of keys which contain numerical values in MRI acquisition parameters
  mri_paragraphs = [['Manufacturer', 'ManufacturerModelName', 'ContrastBolusAgent', 'ContrastBolusVolume'], ['ScanningSequence', 'ScanOptions', 'SequenceVariant'],
                    ['ImagingFrequency', 'RepetitionTime', 'EchoTime', 'InversionTime', 
                       'NumberOfPhaseEncodingSteps', 'EchoTrainLength', 'InPlanePhaseEncodingDirection', 
                      'FlipAngle',], ['MagneticFieldStrength', 'dBdt'], 
                       ['SliceThickness', 'SpacingBetweenSlices', 'PixelSpacing', 'ImageDimensions']]
  pet_acquisition_dict = {'Manufacturer': [], 'SeriesDescription': [], 'ManufacturerModelName': [], 'SliceThickness': [], 
                          'SoftwareVersions': [], 'TriggerTime': [], 'FrameTime': [], 'IntervalsAcquired': [], 'IntervalsRejected': [],
                          'Reconstruction​Diameter': [], 'EnergyWindowLowerLimit': [], 'EnergyWindowUpperLimit': [], 'CorrectedImage': [],
                          'RadiopharmaceuticalInformationSequence':[],'Radiopharmaceutical': [],'RadiopharmaceuticalVolume': [], 'RadionuclideTotalDose': [], 'RadionuclideHalfLife': [], 'RadionuclidePositronFraction': [],
                          'SamplesPerPixel': [], 'RandomsCorrected': [], 'RandomsCorrectionMethod':[], 'AttenuationCorrectionMethod': [], 'DecayCorrection': [], 'ReconstructionMethod': [], 'SliceSensitivityFactor': [],
                          'DecayFactor': [], 'DoseCalibrationFactor': [], 'ScatterFractionFactor': [], 'DeadTimeFactor': [],  'CoincidenceWindowWidth':[],
                          'CollimatorType': [], 'GantryDetectorTilt': [],
                       'PixelSpacing': [], 'SpacingBetweenSlices': [],  'ImageDimensions': []} #dictionary to store acquisition parameters for PET images
  pet_paragraphs = [['Manufacturer', 'ManufacturerModelName', 'SoftwareVersions', 'ReconstructionMethod'], ['TriggerTime', 'FrameTime', 'IntervalsAcquired', 'IntervalsRejected',
                          'Reconstruction​Diameter', 'EnergyWindowLowerLimit', 'EnergyWindowUpperLimit', 'CorrectedImage'],
                          ['RadiopharmaceuticalInformationSequence', 'Radiopharmaceutical','RadiopharmaceuticalVolume', 'RadionuclideTotalDose', 'RadionuclideHalfLife', 'RadionuclidePositronFraction'],
                          ['SamplesPerPixel','RandomsCorrected', 'RandomsCorrectionMethod', 'AttenuationCorrectionMethod', 'DecayCorrection', 'SliceSensitivityFactor',
                          'DecayFactor', 'DoseCalibrationFactor', 'ScatterFractionFactor', 'DeadTimeFactor', 'CoincidenceWindowWidth'],
                          ['CollimatorType', 'GantryDetectorTilt'],
                          ['SliceThickness', 'SpacingBetweenSlices', 'PixelSpacing', 'ImageDimensions']]
  pet_numerical_keys = [key for key in pet_acquisition_dict.keys() if key not in ['Manufacturer', 'SeriesDescription', 'ManufacturerModelName', 'SoftwareVersions', 
                                                                                  'PixelSpacing', 'ImageDimensions', 'CorrectedImage', 'RadiopharmaceuticalInformationSequence', 'Radiopharmaceutical', 'ReconstructionMethod', 
                                                                                  'AttenuationCorrectionMethod', 'RandomsCorrectionMethod', 'DecayCorrection',
                                                                                  'CollimatorType']] #list of keys which contain numerical values in PET acquisition parameters
  ct_acquisition_dict = {'Manufacturer': [], 'SeriesDescription': [], 'ManufacturerModelName': [], 'SliceThickness': [], 'ScanOptions': [],
                          'KVP': [], 'SoftwareVersions': [], 'DataCollectionDiameter': [], 'Reconstruction​Diameter': [], 'ReconstructionMethod': [], 'DistanceSourceToDetector': [],
                          'DistanceSourceToPatient': [], 'RotationDirection': [], 'ExposureTime': [], 'XRayTubeCurrent': [], 'Exposure': [], 'FilterType': [],
                          'GeneratorPower': [], 'FocalSpots': [], 'ConvolutionKernel': [], 'RevolutionTime': [],
                          'SingleCollimationWidth': [], 'TotalCollimationWidth': [], 'TableSpeed': [], 'TableFeedPerRotation': [], 'SpiralPitchFactor': [],
                       'PixelSpacing': [], 'SpacingBetweenSlices': [],  'ImageDimensions': []} #dictionary to store acquisition parameters for CT images
  ct_paragraphs = [['Manufacturer', 'ManufacturerModelName', 'SoftwareVersions', 'ReconstructionMethod', 'ScanOptions'], 
                          ['DataCollectionDiameter', 'Reconstruction​Diameter', 'DistanceSourceToDetector',
                          'DistanceSourceToPatient', 'ConvolutionKernel'], ['RevolutionTime', 'RotationDirection',
                          'SingleCollimationWidth', 'TotalCollimationWidth', 'TableSpeed', 'TableFeedPerRotation', 'SpiralPitchFactor'],
                          ['KVP','ExposureTime', 'XRayTubeCurrent', 'Exposure', 'FilterType', 'GeneratorPower', 'FocalSpots'],
                          ['SliceThickness', 'SpacingBetweenSlices', 'PixelSpacing', 'ImageDimensions']]
  ct_numerical_keys = [key for key in ct_acquisition_dict.keys() if key not in ['Manufacturer', 'SeriesDescription', 'ManufacturerModelName', 'ScanOptions', 
                                                                                'ReconstructionMethod', 'SoftwareVersions', 'RotationDirection', 'FilterType', 'ConvolutionKernel', 'PixelSpacing', 'ImageDimensions', 'CorrectedImage']] #list of keys which contain numerical values in CT acquisition parameters
  directories_list = list(np.transpose(np.array(directory_list))) 
  directories_list = [list(item) for item in directories_list]
  for i, directories in enumerate(directories_list):
      scan_type = scan_types[i]
      
# Initialize a fresh acquisition_dict for each scan_type
      acquisition_dict = {}
      numerical_keys = []

      for j, directory in enumerate(directories):
        dicom_path = os.path.join(directory, os.listdir(directory)[0]) #get the first dicom file in the folder path
        ds = dicom.dcmread(dicom_path) #extract the dicom dataset from the dicom file
        if ds['Modality'].value == 'MR' and j == 0: #check modality of dicom images and define acquisition dictionary and numerical keys appropriately
          acquisition_dict = deepcopy(mri_acquisition_dict)
          numerical_keys = mri_numerical_keys
          paragraphs = mri_paragraphs
        elif ds['Modality'].value == 'PT' and j == 0:
          acquisition_dict = deepcopy(pet_acquisition_dict)
          numerical_keys = pet_numerical_keys
          paragraphs = pet_paragraphs
        elif ds['Modality'].value == 'CT' and j == 0:
          acquisition_dict = deepcopy(ct_acquisition_dict)
          numerical_keys = ct_numerical_keys
          paragraphs = ct_paragraphs       
        keys_list = [elem.keyword for elem in ds] #get the list of keys which are present in the dicom dataset
        missing_keys = [key for key in acquisition_dict.keys() if key not in keys_list + ['ImageDimensions']] #check which keys are missing from the dicom dataset
        for elem in ds:
          if elem.keyword in acquisition_dict.keys():
            acquisition_dict[elem.keyword].append(elem.value)
        if missing_keys != []:
          #if there are missing keys, append None to the dictionary
          for key in missing_keys:
            if key in numerical_keys:
              acquisition_dict[key].append(np.nan)
            else:
              acquisition_dict[key].append(None) #append empty string for missing keys
        shape = list(ds.pixel_array.shape) #get the shape of the pixel array for each slice
        shape = [len(os.listdir(directory))] + shape #append the number of slices to the shape
        acquisition_dict['ImageDimensions'].append(tuple(shape)) #append the shape to the dictionary
      df = pd.DataFrame.from_dict(acquisition_dict) #convert the dictionary to a dataframe
      for label, content in df.items():
        if content.value_counts().to_string(name=False) != "Series([], )" and label not in numerical_keys:
          df.loc[:, label] = content.replace(r'^\s*$', pd.NA, regex=True).fillna("Unspecified") #fill in missing categorical values
      df.to_csv(scan_type + "_" + filename, index=False) #save the dataframe to a csv file
      df = sf.clean_string_columns(df, numerical_keys)     
# Apply to the entire column
      if 'ContrastBolusAgent' in df.columns:
        df['ContrastBolusAgent'] = df['ContrastBolusAgent'].apply(sf.format_contrast_label)
      get_acquisition_text(df, scan_type, numerical_keys) #get the unique acquisition parameters and save it as a text file
      lr.acquisition_latex(author, df, paragraphs, numerical_keys, sections=latex_sections, max_string_length=max_string_length, filename=scan_type+'_acquisition')
      
def write_acquisition_text(acquisition_df, numerical_keys, series_description = True, verbose = True):
   """
    Extracts text of acquisition parameters from the dataframe

    Parameters:
        
        * acquisition_df (pandas.DataFrame): dataframe with acquisition parameters
        
        * numerical_keys (list): list of keys containing numerical values
        
        * series_description (boolean): if True, write SeriesDescription to file
        
        * verbose (boolean): if True, write text with unique acquisition parameters and counts, otherwise summary statistics only are provided for numerical parameters

    Returns:
        
        * acquisition_text (str): text with unique acquisition parameters and counts
    """ 
   acquisition_text = "" #initialise text string
   for label, content in acquisition_df.items(): #loop through each scan in dataframe
      if label == 'SeriesDescription' and not series_description: #skip SeriesDescription if series_description is False
         continue
      if content.value_counts().to_string(name=False) != "Series([], )":
         acquisition_text += (str(label) + ':\n')  # Write the label of the acquisition parameter
         if str(label) in numerical_keys and not verbose: #check if current label is numerical and verbose is False
            content = content.apply(lambda x: str(x) if isinstance(x, dicom.sequence.Sequence) else x)
            unique_values = content.dropna().unique()
            if len(unique_values) == 1:
              acquisition_text += (str(unique_values[0]) + '\n')  # If there is only one unique value, write it 
            else:
              #calculate mean, std, min and max for numerical values
              mean = np.nanmean(content)
              median = np.nanmedian(content)
              std = np.nanstd(content)
              min = np.nanmin(content)
              max = np.nanmax(content)
              #write mean, std, and range to the text
              acquisition_text += ('Mean: ' + str(mean) + '\n')
              acquisition_text += ('Median: ' + str(median) + '\n')
              acquisition_text += ('Standard Deviation: ' + str(std) + '\n')
              acquisition_text += ('Range: [' + str(min) + ' - ' + str(max) + ']\n')
         else:
            acquisition_text += (content.value_counts().to_string(name=False) + '\n')  # Write the unique values and their counts
         acquisition_text += '\n' # Add a newline for better readability
   return acquisition_text     

def get_acquisition_text(acquisition_df, scan_type, numerical_keys):
  """
    Saves acquisition parameters from the dataframe to text files - both as a whole dataset and divided into scan types

    Parameters:
        
        * acquisition_df (pandas.DataFrame): dataframe with acquisition parameters
        
        * scan_type (str): scan type to extract acquisition parameters for
        
        * numerical_keys (list): list of keys containing numerical values

    Output:
        
        * text file detailing acquisition parameters from entire dataset, as well as a text file for each series description present
    """  
  descriptors = acquisition_df["SeriesDescription"].unique() #obtain list of unique series descriptions
  for descriptor in descriptors: #loop through each descriptor
    filtered_descriptor = descriptor.replace(":", "")
    verbose_filename = sf.clean_filename(filtered_descriptor.replace(" ", "_") + "_verbose_acquisition_parameters.txt")
    acquisition_filename = sf.clean_filename(filtered_descriptor.replace(" ", "_") + "_acquisition_parameters.txt")
    df = acquisition_df[acquisition_df['SeriesDescription'] == descriptor] #filter dataframe to just have elements with that description
    verbose_acquisition_text = ("Scan Type: " + str(descriptor) + ':\n')  # Write the scan type
    acquisition_text = ("Scan Type: " + str(descriptor) + ':\n')  # Write the scan type
    verbose_acquisition_text += write_acquisition_text(df, numerical_keys, series_description = False)
    acquisition_text += write_acquisition_text(df, numerical_keys, series_description = False, verbose=False)
    with open(verbose_filename, 'w') as f:  # Save the verbose acquisition text to a file
      f.write(verbose_acquisition_text)  # Write the verbose acquisition text to the file
    with open(acquisition_filename, 'w') as f:  # Save the acquisition text to a file
      f.write(acquisition_text)  # Write the acquisition text to the file
  #get text for entire dataset and save it
  full_verbose_acquisition = write_acquisition_text(acquisition_df, numerical_keys)
  full_acquisition = write_acquisition_text(acquisition_df, numerical_keys, verbose=False)
  with open(scan_type + "_verbose_acquisition_parameters.txt", "w") as f:
     f.write(full_verbose_acquisition)
  with open(scan_type + "_acquisition_parameters.txt", "w") as f:
     f.write(full_acquisition)