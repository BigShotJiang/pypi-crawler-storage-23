from neurocombat_sklearn import CombatModel
import pandas as pd
import numpy as np

def combat_harmonise(dataframes_list, categorical_cols=None, continuous_cols=None):
    """
    Harmonise list of dataframes using neurocombat_sklearn (reusable).
    
    Parameters:  
    
    * dataframes_list (list): list of dataframes to harmonise
    
    * categorical_cols (list): list of categorical columns. Default is None.
    
    * continuous_cols (list): list of continuous columns. Default is None.

    Returns:
    
    * harmonized_dataframes_list (list): list of harmonized dataframes
    
    * combat_model (Combat): fitted Combat model for reuse
    """

    # Combine segmentations side-by-side (columns = samples)
    combined_df = pd.concat(dataframes_list, axis=0)  # shape: (features, samples)
    # Create batch covariate: one value per sample
    num_patients = dataframes_list[0].shape[0]
    batch = []
    for i in range(len(dataframes_list)):
        batch.extend([i + 1] * num_patients)  # segmentation index

    # Build covariate dictionary
    covars_dict = {'batch': np.array(batch)}
    if categorical_cols is None: #form list of categorical columns
        categorical = []
    else:
        categorical = categorical_cols
    if continuous_cols is None: #form list of continuous columns
        continuous = []
    else:
        continuous = continuous_cols
    for col in categorical + continuous:
        covars_dict[col] = pd.concat([df.loc[:,col] for df in dataframes_list], ignore_index=True).values
    covars_dict['batch'] = np.array([covars_dict['batch']]).reshape(-1,1)
    #covars = pd.DataFrame(covars_dict)
    # Fit Combat model
    combat_model = CombatModel()
    df_no_covariates = combined_df.drop(columns=categorical + continuous)
    if categorical_cols is not None and continuous_cols is not None:
        combat_model.fit(
            df_no_covariates,
            covars_dict['batch'],
            discrete_covariates=combined_df.loc[:,categorical],
            continuous_covariates=combined_df.loc[:,continuous]
        )
        harmonized_data = combat_model.transform(df_no_covariates, covars_dict['batch'],
            discrete_covariates=combined_df.loc[:,categorical],
            continuous_covariates=combined_df.loc[:,continuous]) #harmonise the data
    elif categorical_cols is None and continuous_cols is not None:
        combat_model.fit(
            df_no_covariates,
            covars_dict['batch'],
            continuous_covariates=combined_df.loc[:,continuous]
        )
        harmonized_data = combat_model.transform(df_no_covariates, covars_dict['batch'],
            continuous_covariates=combined_df.loc[:,continuous]) #harmonise the data
    elif categorical_cols is not None and continuous_cols is None:
        combat_model.fit(
            df_no_covariates,
            covars_dict['batch'],
            discrete_covariates=combined_df.loc[:,categorical]
        )
        harmonized_data = combat_model.transform(df_no_covariates, covars_dict['batch'],
            discrete_covariates=combined_df.loc[:,categorical]) #harmonise the data
    else:
        combat_model.fit(
            df_no_covariates,
            covars_dict['batch']
        )
        harmonized_data = combat_model.transform(df_no_covariates, covars_dict['batch']) #harmonise the data
    # Step 1: Create DataFrame for harmonized continuous features
    harmonized_continuous_df = pd.DataFrame(
        harmonized_data,
        index=combined_df.index,
        columns=df_no_covariates.columns  # these are the continuous columns
    )

    # Step 2: Recombine with covariates
    recombined_df = pd.concat([
        harmonized_continuous_df,
        combined_df[categorical],  # or covariates you want to keep
    ], axis=1)

    # Step 3: Split back into original segmentations
    harmonized_dataframes_list = []
    end = 0
    for df in dataframes_list:
        harmonized_df = recombined_df.iloc[end:end + df.shape[0], :]
        harmonized_dataframes_list.append(harmonized_df)
        end += df.shape[0]

    return harmonized_dataframes_list, combat_model

def apply_combat_transform(combat_model, new_data, batch_labels, categorical_cols=None, continuous_cols=None):
    """
    Apply a fitted neurocombat_sklearn Combat model to a new dataset.

    Parameters:

    * combat_model: fitted Combat object
    
    * new_data: pandas DataFrame of shape (n_samples, n_features)
    
    * batch_labels: array-like of shape (n_samples,) or (n_samples, 1)
    
    * categorical_cols: pandas DataFrame or array-like of shape (n_samples, n_discrete_covariates). Default is None.
    
    * continuous_cols: pandas DataFrame or array-like of shape (n_samples, n_continuous_covariates). Default is None.

    Returns:
    
    * harmonized_data: dataframe of harmonised features with shape (n_samples, n_features)
    """
    # Ensure batch_labels is a 2D array
    batch_labels = np.array(batch_labels).reshape(-1, 1)
    categorical_covariates = None
    continuous_covariates = None

    if categorical_cols is not None:
        categorical = categorical_cols
        categorical_covariates = new_data.loc[:,categorical_cols]
        if categorical_covariates.ndim == 1:
            categorical_covariates = categorical_covariates.reshape(-1, 1)
    else:
        categorical = []

    if continuous_cols is not None:
        continuous = continuous_cols
        continuous_covariates = new_data.loc[:,continuous_cols]
        if continuous_covariates.ndim == 1:
            continuous_covariates = continuous_covariates.reshape(-1, 1)
    else:
        continuous = []

    # Drop covariate columns from new_data if they are included
    covariate_columns = []
    if isinstance(categorical_covariates, pd.DataFrame):
        covariate_columns += list(categorical_covariates.columns)
    if isinstance(continuous_covariates, pd.DataFrame):
        covariate_columns += list(continuous_covariates.columns) 
    no_covariates_df = new_data.drop(columns=covariate_columns)
    # Apply transformation
    harmonized_data = combat_model.transform(
        no_covariates_df.values,
        batch_labels,
        discrete_covariates=categorical_covariates,
        continuous_covariates=continuous_covariates
    )
    # Step 1: Create DataFrame for harmonized continuous features
    harmonized_continuous_df = pd.DataFrame(
        harmonized_data,
        index=no_covariates_df.index,
        columns=no_covariates_df.columns  # these are the continuous columns
    )

    # Step 2: Recombine with covariates
    harmonized_data = pd.concat([
        harmonized_continuous_df,
        new_data[categorical],
          new_data[continuous]  # or covariates you want to keep
        ], axis=1)

    return harmonized_data

def HarMSTD(dataframes_list, reference_index, categorical_cols=None, continuous_cols=None):
    """
    Harmonise list of dataframes with HarMSTD. 
    
    Parameters:  
    
    * dataframes_list (list): list of dataframes to harmonise
    
    * reference_index (int): index of reference dataset
    
    * categorical_cols (list): list of categorical columns. Default is None.
    
    * continuous_cols (list): list of continuous columns. Default is None.

    Returns:
    
    * harmonized_dataframes_list (list): list of harmonized dataframes
    """
    reference_df = dataframes_list[reference_index]
    reference_df_dropped = reference_df.drop(columns=categorical_cols + continuous_cols)
    means = reference_df_dropped.mean()
    std = reference_df_dropped.std()
    harmonised_dfs = []
    for i, df in enumerate(dataframes_list):
        if i == reference_index: #do not harmonise reference image
            harmonised_dfs.append(reference_df)
        else:
            df_dropped = df.drop(columns=categorical_cols + continuous_cols)
            harmonised_df = (df_dropped - df_dropped.mean()) / df_dropped.std() * std + means
            harmonised_dfs.append(pd.concat([harmonised_df, df[categorical_cols + continuous_cols]], axis=1))
    return harmonised_dfs
