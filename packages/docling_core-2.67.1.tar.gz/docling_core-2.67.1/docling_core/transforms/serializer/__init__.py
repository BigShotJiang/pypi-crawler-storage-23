"""Define the serializer types."""
