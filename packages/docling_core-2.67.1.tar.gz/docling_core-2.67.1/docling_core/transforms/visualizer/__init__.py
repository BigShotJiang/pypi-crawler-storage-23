"""Define the visualizer types."""
