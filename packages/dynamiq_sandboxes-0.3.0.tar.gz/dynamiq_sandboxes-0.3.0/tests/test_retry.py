"""Tests for Platform SDK retry functionality."""
from __future__ import annotations

import time
from unittest.mock import patch

import httpx
import pytest

from dynamiq_sandboxes.client.retry import (
    DEFAULT_RETRY_CONFIG,
    RetryConfig,
    calculate_delay,
    is_retryable_error,
    is_retryable_status,
    sleep_with_backoff,
)


class TestRetryConfig:
    """Tests for RetryConfig dataclass."""

    def test_default_values(self):
        """RetryConfig should have sensible defaults."""
        config = RetryConfig()
        assert config.max_attempts == 3
        assert config.base_delay == 1.0
        assert config.max_delay == 30.0
        assert config.exponential_base == 2.0
        assert config.jitter is True
        assert 429 in config.retryable_status_codes
        assert 500 in config.retryable_status_codes

    def test_custom_values(self):
        """RetryConfig should accept custom values."""
        config = RetryConfig(
            max_attempts=5,
            base_delay=0.5,
            max_delay=60.0,
            exponential_base=3.0,
            jitter=False,
            retryable_status_codes=(429, 503),
        )
        assert config.max_attempts == 5
        assert config.base_delay == 0.5
        assert config.max_delay == 60.0
        assert config.exponential_base == 3.0
        assert config.jitter is False
        assert config.retryable_status_codes == (429, 503)

    def test_default_retry_config_singleton(self):
        """DEFAULT_RETRY_CONFIG should be a valid RetryConfig."""
        assert isinstance(DEFAULT_RETRY_CONFIG, RetryConfig)
        assert DEFAULT_RETRY_CONFIG.max_attempts == 3

    def test_retryable_exceptions_default(self):
        """Default config should include httpx exceptions."""
        config = RetryConfig()
        assert httpx.RequestError in config.retryable_exceptions
        assert httpx.TimeoutException in config.retryable_exceptions


class TestCalculateDelay:
    """Tests for calculate_delay function."""

    def test_first_attempt_delay(self):
        """First attempt should use base delay."""
        config = RetryConfig(base_delay=1.0, jitter=False)
        delay = calculate_delay(0, config)
        assert delay == 1.0

    def test_exponential_backoff(self):
        """Delays should increase exponentially."""
        config = RetryConfig(
            base_delay=1.0,
            exponential_base=2.0,
            max_delay=100.0,
            jitter=False,
        )
        assert calculate_delay(0, config) == 1.0
        assert calculate_delay(1, config) == 2.0
        assert calculate_delay(2, config) == 4.0
        assert calculate_delay(3, config) == 8.0

    def test_max_delay_cap(self):
        """Delay should be capped at max_delay."""
        config = RetryConfig(
            base_delay=1.0,
            exponential_base=2.0,
            max_delay=5.0,
            jitter=False,
        )
        # Attempt 10 would be 1024 without cap
        delay = calculate_delay(10, config)
        assert delay == 5.0

    def test_jitter_adds_randomness(self):
        """Jitter should add up to 25% randomness."""
        config = RetryConfig(
            base_delay=1.0,
            exponential_base=2.0,
            max_delay=100.0,
            jitter=True,
        )
        
        # Run multiple times to verify jitter adds randomness
        delays = [calculate_delay(0, config) for _ in range(100)]
        
        # All delays should be between base (1.0) and base * 1.25
        assert all(1.0 <= d <= 1.25 for d in delays)
        
        # With 100 samples, there should be variation
        unique_delays = set(delays)
        assert len(unique_delays) > 1

    def test_custom_exponential_base(self):
        """Custom exponential base should work."""
        config = RetryConfig(
            base_delay=1.0,
            exponential_base=3.0,
            max_delay=100.0,
            jitter=False,
        )
        assert calculate_delay(0, config) == 1.0
        assert calculate_delay(1, config) == 3.0
        assert calculate_delay(2, config) == 9.0


class TestIsRetryableError:
    """Tests for is_retryable_error function."""

    def test_httpx_request_error(self):
        """httpx.RequestError should be retryable by default."""
        config = RetryConfig()
        error = httpx.RequestError("connection failed")
        assert is_retryable_error(error, config) is True

    def test_httpx_timeout_exception(self):
        """httpx.TimeoutException should be retryable by default."""
        config = RetryConfig()
        error = httpx.TimeoutException("request timed out")
        assert is_retryable_error(error, config) is True

    def test_non_retryable_error(self):
        """Non-retryable errors should return False."""
        config = RetryConfig()
        error = ValueError("invalid value")
        assert is_retryable_error(error, config) is False

    def test_custom_retryable_exceptions(self):
        """Custom retryable exceptions should work."""
        config = RetryConfig(
            retryable_exceptions=(ValueError, KeyError),
        )
        assert is_retryable_error(ValueError("test"), config) is True
        assert is_retryable_error(KeyError("test"), config) is True
        assert is_retryable_error(TypeError("test"), config) is False


class TestIsRetryableStatus:
    """Tests for is_retryable_status function."""

    def test_default_retryable_codes(self):
        """Default retryable status codes should return True."""
        config = RetryConfig()
        assert is_retryable_status(429, config) is True
        assert is_retryable_status(500, config) is True
        assert is_retryable_status(502, config) is True
        assert is_retryable_status(503, config) is True
        assert is_retryable_status(504, config) is True

    def test_non_retryable_codes(self):
        """Non-retryable status codes should return False."""
        config = RetryConfig()
        assert is_retryable_status(200, config) is False
        assert is_retryable_status(400, config) is False
        assert is_retryable_status(401, config) is False
        assert is_retryable_status(403, config) is False
        assert is_retryable_status(404, config) is False
        assert is_retryable_status(422, config) is False

    def test_custom_retryable_codes(self):
        """Custom retryable status codes should work."""
        config = RetryConfig(retryable_status_codes=(503, 504))
        assert is_retryable_status(503, config) is True
        assert is_retryable_status(504, config) is True
        assert is_retryable_status(500, config) is False
        assert is_retryable_status(429, config) is False


class TestSleepWithBackoff:
    """Tests for sleep_with_backoff function."""

    def test_sleep_duration(self):
        """sleep_with_backoff should sleep for calculated delay."""
        config = RetryConfig(base_delay=0.1, jitter=False, max_delay=10.0)
        
        start = time.time()
        sleep_with_backoff(0, config)
        elapsed = time.time() - start
        
        # Allow some tolerance for timing
        assert 0.08 <= elapsed <= 0.15

    def test_sleep_with_exponential_backoff(self):
        """Sleep duration should follow exponential backoff."""
        config = RetryConfig(
            base_delay=0.05,
            exponential_base=2.0,
            jitter=False,
            max_delay=10.0,
        )
        
        # First attempt: 0.05s
        start = time.time()
        sleep_with_backoff(0, config)
        elapsed = time.time() - start
        assert 0.03 <= elapsed <= 0.1

        # Second attempt: 0.1s
        start = time.time()
        sleep_with_backoff(1, config)
        elapsed = time.time() - start
        assert 0.08 <= elapsed <= 0.15

    @patch("time.sleep")
    def test_sleep_called_with_correct_delay(self, mock_sleep):
        """time.sleep should be called with calculated delay."""
        config = RetryConfig(base_delay=1.0, jitter=False, max_delay=30.0)
        
        sleep_with_backoff(0, config)
        mock_sleep.assert_called_once_with(1.0)
        
        mock_sleep.reset_mock()
        sleep_with_backoff(1, config)
        mock_sleep.assert_called_once_with(2.0)
        
        mock_sleep.reset_mock()
        sleep_with_backoff(2, config)
        mock_sleep.assert_called_once_with(4.0)


class TestRetryConfigIntegration:
    """Integration tests for retry configuration."""

    def test_no_jitter_deterministic(self):
        """Without jitter, delays should be deterministic."""
        config = RetryConfig(
            base_delay=1.0,
            exponential_base=2.0,
            max_delay=100.0,
            jitter=False,
        )
        
        for attempt in range(5):
            delays = [calculate_delay(attempt, config) for _ in range(10)]
            assert len(set(delays)) == 1  # All delays should be identical

    def test_zero_base_delay(self):
        """Zero base delay should work (no sleep)."""
        config = RetryConfig(base_delay=0.0, jitter=False, max_delay=10.0)
        assert calculate_delay(0, config) == 0.0
        assert calculate_delay(1, config) == 0.0

    def test_very_small_delays(self):
        """Very small delays should work correctly."""
        config = RetryConfig(
            base_delay=0.001,  # 1ms
            exponential_base=2.0,
            max_delay=0.01,  # 10ms
            jitter=False,
        )
        
        assert calculate_delay(0, config) == 0.001
        assert calculate_delay(1, config) == 0.002
        assert calculate_delay(2, config) == 0.004
        assert calculate_delay(3, config) == 0.008
        assert calculate_delay(4, config) == 0.01  # Capped
