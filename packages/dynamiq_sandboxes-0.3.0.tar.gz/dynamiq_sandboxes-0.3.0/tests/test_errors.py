"""Tests for Platform SDK exceptions."""
from __future__ import annotations

import pytest

from dynamiq_sandboxes.exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    PlatformSDKError,
    RateLimitError,
    TimeoutError,
)


class TestPlatformSDKError:
    """Tests for PlatformSDKError base class."""

    def test_is_runtime_error(self):
        """PlatformSDKError should be a RuntimeError."""
        error = PlatformSDKError("test error")
        assert isinstance(error, RuntimeError)

    def test_message(self):
        """Error message should be accessible."""
        error = PlatformSDKError("test message")
        assert str(error) == "test message"


class TestAPIError:
    """Tests for APIError class."""

    def test_basic_error(self):
        """APIError should store message."""
        error = APIError("Request failed")
        assert str(error) == "Request failed"
        assert error.status_code is None
        assert error.error_code is None
        assert error.request_id is None

    def test_with_status_code(self):
        """APIError should store status code."""
        error = APIError("Request failed", status_code=500)
        assert error.status_code == 500

    def test_with_error_code(self):
        """APIError should store error code."""
        error = APIError("Request failed", error_code="INTERNAL_ERROR")
        assert error.error_code == "INTERNAL_ERROR"

    def test_with_request_id(self):
        """APIError should store request ID."""
        error = APIError("Request failed", request_id="req-123")
        assert error.request_id == "req-123"

    def test_with_all_fields(self):
        """APIError should store all fields."""
        error = APIError(
            "Request failed",
            status_code=500,
            error_code="INTERNAL_ERROR",
            request_id="req-123",
        )
        assert str(error) == "Request failed"
        assert error.status_code == 500
        assert error.error_code == "INTERNAL_ERROR"
        assert error.request_id == "req-123"

    def test_is_dynamiq_sandboxes_error(self):
        """APIError should be a PlatformSDKError."""
        error = APIError("test")
        assert isinstance(error, PlatformSDKError)


class TestAuthenticationError:
    """Tests for AuthenticationError class."""

    def test_inheritance(self):
        """AuthenticationError should inherit from APIError."""
        error = AuthenticationError("Invalid credentials")
        assert isinstance(error, APIError)
        assert isinstance(error, PlatformSDKError)

    def test_with_status_code(self):
        """AuthenticationError typically has 401 or 403 status."""
        error = AuthenticationError("Invalid API key", status_code=401)
        assert error.status_code == 401

    def test_with_403(self):
        """AuthenticationError can have 403 status."""
        error = AuthenticationError("Access denied", status_code=403)
        assert error.status_code == 403


class TestNotFoundError:
    """Tests for NotFoundError class."""

    def test_inheritance(self):
        """NotFoundError should inherit from APIError."""
        error = NotFoundError("Resource not found")
        assert isinstance(error, APIError)
        assert isinstance(error, PlatformSDKError)

    def test_with_status_code(self):
        """NotFoundError typically has 404 status."""
        error = NotFoundError("Sandbox not found", status_code=404)
        assert error.status_code == 404

    def test_with_error_code(self):
        """NotFoundError can have specific error codes."""
        error = NotFoundError(
            "Sandbox not found",
            status_code=404,
            error_code="SANDBOX_NOT_FOUND",
        )
        assert error.error_code == "SANDBOX_NOT_FOUND"


class TestRateLimitError:
    """Tests for RateLimitError class."""

    def test_inheritance(self):
        """RateLimitError should inherit from APIError."""
        error = RateLimitError("Rate limit exceeded")
        assert isinstance(error, APIError)
        assert isinstance(error, PlatformSDKError)

    def test_with_status_code(self):
        """RateLimitError typically has 429 status."""
        error = RateLimitError("Too many requests", status_code=429)
        assert error.status_code == 429


class TestConflictError:
    """Tests for ConflictError class."""

    def test_inheritance(self):
        """ConflictError should inherit from APIError."""
        error = ConflictError("Resource conflict")
        assert isinstance(error, APIError)
        assert isinstance(error, PlatformSDKError)

    def test_with_status_code(self):
        """ConflictError typically has 409 status."""
        error = ConflictError("Name already exists", status_code=409)
        assert error.status_code == 409


class TestTimeoutError:
    """Tests for TimeoutError class."""

    def test_inheritance(self):
        """TimeoutError should inherit from PlatformSDKError."""
        error = TimeoutError("Request timed out")
        assert isinstance(error, PlatformSDKError)
        # Note: TimeoutError does not inherit from APIError
        assert not isinstance(error, APIError)

    def test_message(self):
        """TimeoutError should store message."""
        error = TimeoutError("Request timed out after 30s")
        assert str(error) == "Request timed out after 30s"


class TestErrorHierarchy:
    """Tests for error type hierarchy and exception handling."""

    def test_catch_all_sdk_errors(self):
        """All SDK errors should be catchable with PlatformSDKError."""
        errors = [
            PlatformSDKError("base"),
            APIError("api"),
            AuthenticationError("auth"),
            NotFoundError("not found"),
            RateLimitError("rate limit"),
            ConflictError("conflict"),
            TimeoutError("timeout"),
        ]
        
        for error in errors:
            try:
                raise error
            except PlatformSDKError as caught:
                assert caught is error

    def test_catch_api_errors(self):
        """API-specific errors should be catchable with APIError."""
        errors = [
            APIError("api"),
            AuthenticationError("auth"),
            NotFoundError("not found"),
            RateLimitError("rate limit"),
            ConflictError("conflict"),
        ]
        
        for error in errors:
            try:
                raise error
            except APIError as caught:
                assert caught is error

    def test_timeout_not_api_error(self):
        """TimeoutError should not be caught by APIError handler."""
        error = TimeoutError("timeout")
        with pytest.raises(TimeoutError):
            try:
                raise error
            except APIError:
                pytest.fail("TimeoutError should not be caught by APIError")

    def test_specific_error_types(self):
        """Specific error types should be distinguishable."""
        with pytest.raises(AuthenticationError):
            raise AuthenticationError("auth failed")

        with pytest.raises(NotFoundError):
            raise NotFoundError("not found")

        with pytest.raises(RateLimitError):
            raise RateLimitError("rate limited")

        with pytest.raises(ConflictError):
            raise ConflictError("conflict")
