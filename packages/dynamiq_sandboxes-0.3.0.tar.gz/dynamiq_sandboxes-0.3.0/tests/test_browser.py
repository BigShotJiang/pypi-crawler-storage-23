"""Tests for Platform SDK Browser class."""
from __future__ import annotations

from typing import Any, Dict

import httpx
import pytest
import respx

from dynamiq_sandboxes.client.http import APIClient
from dynamiq_sandboxes.browser import Browser


class TestBrowserCreate:
    """Tests for Browser.create() method."""

    @respx.mock
    def test_create_minimal(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser with minimal parameters."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(api_key=api_key, base_url=base_url)
        
        assert browser.id == "sbx-123456"
        assert browser.data["sandbox_type"] == "browser"
        browser._client.close()

    @respx.mock
    def test_create_with_options(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser with all options."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            template="browser-firefox",
            timeout=7200,
            idle_timeout=600,
            name="my-browser",
            vcpu=4,
            memory_mb=8192,
            browser_config={
                "browser_type": "firefox",
                "dimensions": {"width": 1920, "height": 1080},
                "stealth": True,
                "block_ads": True,
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        assert browser.id == "sbx-123456"
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["sandbox_type"] == "browser"
        browser._client.close()

    @respx.mock
    def test_create_uses_browser_defaults(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Browser.create() should use browser-specific defaults."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(api_key=api_key, base_url=base_url)
        
        import json
        body = json.loads(route.calls.last.request.content)
        # Default template for browser
        assert body["template_id"] == "browser-chromium"
        # Browser gets idle_timeout by default
        assert body["idle_timeout"] == 300
        browser._client.close()

    @respx.mock
    def test_create_with_stealth_mode(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser with stealth mode enabled."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "stealth": True,
                "block_ads": True,
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body.get("browser_config", {}).get("stealth") is True
        browser._client.close()

    @respx.mock
    def test_create_with_proxy(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser with proxy configuration."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "proxy_url": "http://proxy.example.com:8080",
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body.get("browser_config", {}).get("proxy_url") == "http://proxy.example.com:8080"
        browser._client.close()


class TestBrowserGet:
    """Tests for Browser.get() method."""

    @respx.mock
    def test_get_by_id(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Get browser by ID."""
        respx.get(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(200, json=browser_response)
        )
        
        browser = Browser.get("sbx-123456", api_key=api_key, base_url=base_url)
        
        assert browser.id == "sbx-123456"
        assert browser.data["sandbox_type"] == "browser"
        browser._client.close()


class TestBrowserProperties:
    """Tests for Browser properties."""

    @respx.mock
    def test_cdp_websocket_url(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """cdp_websocket_url should return URL from response."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(client=client)
        
        assert browser.cdp_websocket_url == "wss://cdp.test.io/sbx-123456"

    @respx.mock
    def test_live_view_url(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """live_view_url should return URL from response."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(client=client)
        
        assert browser.live_view_url == "https://live.test.io/sbx-123456"

    @respx.mock
    def test_debugger_url(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """debugger_url should return URL from response."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(client=client)
        
        assert browser.debugger_url == "https://debug.test.io/sbx-123456"

    @respx.mock
    def test_urls_none_when_not_present(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Browser URLs should be None when not in response."""
        # Use basic sandbox response without browser URLs
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        browser = Browser.create(client=client)
        
        assert browser.cdp_websocket_url is None
        assert browser.debugger_url is None


class TestBrowserInheritance:
    """Tests to verify Browser inherits from Sandbox."""

    @respx.mock
    def test_inherits_sandbox_methods(
        self,
        client: APIClient,
        base_url: str,
        browser_response: Dict[str, Any],
        run_code_response: Dict[str, Any],
    ):
        """Browser should have all Sandbox methods."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/run").mock(
            return_value=httpx.Response(200, json=run_code_response)
        )
        
        browser = Browser.create(client=client)
        
        # Should be able to run code (inherited from Sandbox)
        result = browser.run_code('console.log("hello")', language="javascript")
        assert result["exit_code"] == 0

    @respx.mock
    def test_inherits_file_operations(
        self,
        client: APIClient,
        base_url: str,
        browser_response: Dict[str, Any],
        file_response: Dict[str, Any],
    ):
        """Browser should have file operations from Sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/files/test.txt").mock(
            return_value=httpx.Response(200, json=file_response)
        )
        
        browser = Browser.create(client=client)
        
        # Should be able to read files (inherited from Sandbox)
        result = browser.read_file("test.txt")
        assert result["content"] == "file contents here"

    @respx.mock
    def test_inherits_context_manager(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """Browser should work as context manager."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        respx.delete(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(204)
        )
        
        with Browser.create(client=client) as browser:
            assert browser.id == "sbx-123456"

    @respx.mock
    def test_inherits_refresh(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """Browser should have refresh method from Sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        updated_response = {**browser_response, "state": "paused"}
        respx.get(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(200, json=updated_response)
        )
        
        browser = Browser.create(client=client)
        assert browser.data["state"] == "running"
        
        browser.refresh()
        assert browser.data["state"] == "paused"

    @respx.mock
    def test_inherits_pause_resume(
        self, client: APIClient, base_url: str, browser_response: Dict[str, Any]
    ):
        """Browser should have pause/resume methods from Sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/pause").mock(
            return_value=httpx.Response(200, json={"state": "paused"})
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/resume").mock(
            return_value=httpx.Response(200, json={"state": "running"})
        )
        
        browser = Browser.create(client=client)
        
        result = browser.pause()
        assert result["state"] == "paused"
        
        result = browser.resume(timeout=300)
        assert result["state"] == "running"

    @respx.mock
    def test_inherits_metrics(
        self,
        client: APIClient,
        base_url: str,
        browser_response: Dict[str, Any],
        metrics_response: Dict[str, Any],
    ):
        """Browser should have metrics methods from Sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/metrics").mock(
            return_value=httpx.Response(200, json=metrics_response)
        )
        
        browser = Browser.create(client=client)
        
        result = browser.metrics()
        assert result["cpu_percent"] == 25.5


class TestBrowserUseCases:
    """Tests for common Browser use cases."""

    @respx.mock
    def test_web_scraping_setup(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser configured for web scraping."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "stealth": True,
                "block_ads": True,
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0",
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        # Browser should be ready for scraping
        assert browser.cdp_websocket_url is not None
        browser._client.close()

    @respx.mock
    def test_automated_testing_setup(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser configured for automated testing."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "dimensions": {"width": 1920, "height": 1080},
                "record_session": True,
            },
            timeout=1800,  # 30 minutes for test suite
            api_key=api_key,
            base_url=base_url,
        )
        
        # Browser should be configured for testing
        assert browser.live_view_url is not None
        browser._client.close()

    @respx.mock
    def test_browser_with_extensions(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser with extensions."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "extensions": ["ublock-origin", "lastpass"],
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        extensions = body.get("browser_config", {}).get("extensions", [])
        assert "ublock-origin" in extensions
        browser._client.close()

    @respx.mock
    def test_browser_with_context_import(
        self, api_key: str, base_url: str, browser_response: Dict[str, Any]
    ):
        """Create browser importing existing context."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=browser_response)
        )
        
        browser = Browser.create(
            browser_config={
                "context_id": "ctx-existing-session",
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        context_id = body.get("browser_config", {}).get("context_id")
        assert context_id == "ctx-existing-session"
        browser._client.close()
