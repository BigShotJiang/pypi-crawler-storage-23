"""Tests for Platform SDK Sandbox class."""
from __future__ import annotations

from typing import Any, Dict

import httpx
import pytest
import respx

from dynamiq_sandboxes.client.http import APIClient
from dynamiq_sandboxes.client.retry import RetryConfig
from dynamiq_sandboxes.sandbox import NetworkConfig, Sandbox


class TestNetworkConfig:
    """Tests for NetworkConfig dataclass."""

    def test_default_values(self):
        """NetworkConfig should have sensible defaults."""
        config = NetworkConfig()
        assert config.allow_internet_access is True
        assert config.allow_public_traffic is True
        assert config.allow_out is None
        assert config.deny_out is None
        assert config.mask_request_host is None

    def test_custom_values(self):
        """NetworkConfig should accept custom values."""
        config = NetworkConfig(
            allow_internet_access=False,
            allow_public_traffic=False,
            allow_out=["*.example.com"],
            deny_out=["*.internal.io"],
            mask_request_host="proxy.example.com",
        )
        assert config.allow_internet_access is False
        assert config.allow_public_traffic is False
        assert config.allow_out == ["*.example.com"]
        assert config.deny_out == ["*.internal.io"]
        assert config.mask_request_host == "proxy.example.com"

    def test_to_payload(self):
        """to_payload should return dict without None values."""
        config = NetworkConfig(
            allow_internet_access=True,
            allow_out=["*.example.com"],
        )
        payload = config.to_payload()
        
        assert payload["allow_internet_access"] is True
        assert payload["allow_out"] == ["*.example.com"]
        assert "mask_request_host" not in payload or payload["mask_request_host"] is None

    def test_to_payload_minimal(self):
        """to_payload with defaults should return all non-None values."""
        config = NetworkConfig()
        payload = config.to_payload()
        
        assert payload["allow_internet_access"] is True
        assert payload["allow_public_traffic"] is True


class TestSandboxCreate:
    """Tests for Sandbox.create() method."""

    @respx.mock
    def test_create_minimal(self, api_key: str, base_url: str, sandbox_response: Dict[str, Any]):
        """Create sandbox with minimal parameters."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(
            template="python",
            api_key=api_key,
            base_url=base_url,
        )
        
        assert sandbox.id == "sbx-123456"
        assert sandbox.data["state"] == "running"
        sandbox._client.close()

    @respx.mock
    def test_create_with_all_options(
        self, api_key: str, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Create sandbox with all options."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(
            template="python",
            timeout=600,
            idle_timeout=120,
            name="my-sandbox",
            tags={"env": "test"},
            vcpu=4,
            memory_mb=4096,
            disk_mb=20480,
            env_vars={"DEBUG": "true"},
            metadata={"version": "1.0"},
            network=NetworkConfig(allow_internet_access=False),
            api_key=api_key,
            base_url=base_url,
        )
        
        assert sandbox.id == "sbx-123456"
        
        # Verify request payload
        request = route.calls.last.request
        payload = httpx.Request(
            method=request.method,
            url=request.url,
            content=request.content,
        )
        import json
        body = json.loads(request.content)
        
        assert body["template_id"] == "python"
        assert body["timeout"] == 600
        assert body["idle_timeout"] == 120
        assert body["name"] == "my-sandbox"
        assert body["resources"]["vcpu"] == 4
        assert body["resources"]["memory_mb"] == 4096
        assert body["resources"]["disk_mb"] == 20480
        sandbox._client.close()

    @respx.mock
    def test_create_with_client(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Create sandbox with existing client."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        
        assert sandbox.id == "sbx-123456"
        # Don't close client since it's managed by fixture


class TestSandboxGet:
    """Tests for Sandbox.get() method."""

    @respx.mock
    def test_get_by_id(self, api_key: str, base_url: str, sandbox_response: Dict[str, Any]):
        """Get sandbox by ID."""
        respx.get(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(200, json=sandbox_response)
        )
        
        sandbox = Sandbox.get(
            "sbx-123456",
            api_key=api_key,
            base_url=base_url,
        )
        
        assert sandbox.id == "sbx-123456"
        assert sandbox.data["state"] == "running"
        sandbox._client.close()


class TestSandboxFromName:
    """Tests for Sandbox.from_name() method."""

    @respx.mock
    def test_from_name(self, api_key: str, base_url: str, sandbox_response: Dict[str, Any]):
        """Get sandbox by name."""
        sandbox_response["name"] = "my-sandbox"
        respx.get(f"{base_url}/sandboxes/by-name/my-sandbox").mock(
            return_value=httpx.Response(200, json=sandbox_response)
        )
        
        sandbox = Sandbox.from_name(
            "my-sandbox",
            api_key=api_key,
            base_url=base_url,
        )
        
        assert sandbox.id == "sbx-123456"
        assert sandbox.data["name"] == "my-sandbox"
        sandbox._client.close()

    @respx.mock
    def test_from_name_with_special_chars(
        self, api_key: str, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Get sandbox by name with special characters."""
        sandbox_response["name"] = "my sandbox"
        # URL should be encoded
        respx.get(f"{base_url}/sandboxes/by-name/my%20sandbox").mock(
            return_value=httpx.Response(200, json=sandbox_response)
        )
        
        sandbox = Sandbox.from_name(
            "my sandbox",
            api_key=api_key,
            base_url=base_url,
        )
        
        assert sandbox.id == "sbx-123456"
        sandbox._client.close()


class TestSandboxList:
    """Tests for Sandbox.list() method."""

    @respx.mock
    def test_list_all(
        self, api_key: str, base_url: str, sandbox_list_response: Dict[str, Any]
    ):
        """List all sandboxes."""
        respx.get(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(200, json=sandbox_list_response)
        )
        
        result = Sandbox.list(api_key=api_key, base_url=base_url)
        
        assert "data" in result
        assert len(result["data"]) == 1

    @respx.mock
    def test_list_with_filters(
        self, api_key: str, base_url: str, sandbox_list_response: Dict[str, Any]
    ):
        """List sandboxes with filters."""
        route = respx.get(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(200, json=sandbox_list_response)
        )
        
        result = Sandbox.list(
            api_key=api_key,
            base_url=base_url,
            state="running",
            template_id="python",
            sandbox_type="code",
            limit=10,
            offset=0,
        )
        
        # Verify query params
        url = str(route.calls.last.request.url)
        assert "state=running" in url
        assert "template_id=python" in url
        assert "sandbox_type=code" in url
        assert "limit=10" in url

    @respx.mock
    def test_list_with_tags(
        self, api_key: str, base_url: str, sandbox_list_response: Dict[str, Any]
    ):
        """List sandboxes with tag filters."""
        route = respx.get(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(200, json=sandbox_list_response)
        )
        
        Sandbox.list(
            api_key=api_key,
            base_url=base_url,
            tags={"env": "production", "team": "backend"},
        )
        
        url = str(route.calls.last.request.url)
        assert "tags%5Benv%5D=production" in url or "tags[env]=production" in url


class TestSandboxProperties:
    """Tests for Sandbox properties."""

    @respx.mock
    def test_id_property(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """id property should return sandbox ID."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        assert sandbox.id == "sbx-123456"

    @respx.mock
    def test_data_property(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """data property should return sandbox data."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        assert sandbox.data["sandbox_id"] == "sbx-123456"
        assert sandbox.data["state"] == "running"

    @respx.mock
    def test_browser_urls_none_for_code_sandbox(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Browser URLs should be None for code sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        assert sandbox.cdp_websocket_url is None
        assert sandbox.live_view_url is None
        assert sandbox.debugger_url is None


class TestSandboxMethods:
    """Tests for Sandbox instance methods."""

    @respx.mock
    def test_refresh(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """refresh() should update sandbox data."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        
        updated_response = {**sandbox_response, "state": "paused"}
        respx.get(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(200, json=updated_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        assert sandbox.data["state"] == "running"
        
        sandbox.refresh()
        assert sandbox.data["state"] == "paused"

    @respx.mock
    def test_close(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """close() should delete the sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.delete(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(204)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.close()  # Should not raise

    @respx.mock
    def test_extend_timeout(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """extend_timeout() should extend sandbox timeout."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/timeout").mock(
            return_value=httpx.Response(200, json={"timeout": 600})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.extend_timeout(600)
        assert result["timeout"] == 600

    @respx.mock
    def test_pause(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """pause() should pause the sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/pause").mock(
            return_value=httpx.Response(200, json={"state": "paused"})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.pause()
        assert result["state"] == "paused"

    @respx.mock
    def test_resume(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """resume() should resume a paused sandbox."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/resume").mock(
            return_value=httpx.Response(200, json={"state": "running"})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.resume(timeout=300)
        assert result["state"] == "running"

    @respx.mock
    def test_get_host(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """get_host() should return host for port."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/host/8080").mock(
            return_value=httpx.Response(200, json={"host": "sbx-123456.host.io", "url": "https://sbx-123456.host.io"})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.get_host(8080)
        assert "host" in result

    @respx.mock
    def test_get_env(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """get_env() should return environment variables."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/env").mock(
            return_value=httpx.Response(200, json={"env_vars": {"PATH": "/usr/bin"}})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.get_env()
        assert "env_vars" in result

    @respx.mock
    def test_connect(self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]):
        """connect() should establish connection."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/connect").mock(
            return_value=httpx.Response(200, json={"connected": True})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.connect()
        assert result["connected"] is True


class TestSandboxCodeExecution:
    """Tests for Sandbox code execution methods."""

    @respx.mock
    def test_run_code(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        run_code_response: Dict[str, Any],
    ):
        """run_code() should execute code."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/run").mock(
            return_value=httpx.Response(200, json=run_code_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.run_code('print("Hello")', language="python")
        
        assert result["stdout"] == "Hello, World!"
        assert result["exit_code"] == 0

    @respx.mock
    def test_run_code_with_timeout(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        run_code_response: Dict[str, Any],
    ):
        """run_code() should support timeout."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/run").mock(
            return_value=httpx.Response(200, json=run_code_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.run_code('print("Hello")', language="python", timeout=60)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["timeout"] == 60

    @respx.mock
    def test_execute_command(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        execute_command_response: Dict[str, Any],
    ):
        """execute_command() should run shell command."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/commands").mock(
            return_value=httpx.Response(200, json=execute_command_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.execute_command("ls", args=["-la"])
        
        assert "stdout" in result
        assert result["exit_code"] == 0

    @respx.mock
    def test_execute_command_with_options(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        execute_command_response: Dict[str, Any],
    ):
        """execute_command() should support all options."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/commands").mock(
            return_value=httpx.Response(200, json=execute_command_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.execute_command(
            "ls",
            args=["-la"],
            working_dir="/home/user",
            timeout=30,
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["command"] == "ls"
        assert body["args"] == ["-la"]
        assert body["working_dir"] == "/home/user"
        assert body["timeout"] == 30


class TestSandboxFileOperations:
    """Tests for Sandbox file operations."""

    @respx.mock
    def test_read_file(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        file_response: Dict[str, Any],
    ):
        """read_file() should read file content."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/files/path/to/file.txt").mock(
            return_value=httpx.Response(200, json=file_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.read_file("path/to/file.txt")
        
        assert result["content"] == "file contents here"

    @respx.mock
    def test_read_directory(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """read_file() should support directory listing."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.get(f"{base_url}/sandboxes/sbx-123456/files/path/to/dir").mock(
            return_value=httpx.Response(200, json={"entries": []})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.read_file("path/to/dir", file_type="directory")
        
        assert "type=directory" in str(route.calls.last.request.url)

    @respx.mock
    def test_write_file(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """write_file() should write file content."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.put(f"{base_url}/sandboxes/sbx-123456/files/path/to/file.txt").mock(
            return_value=httpx.Response(200, json={"size": 12})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.write_file("path/to/file.txt", "new content")
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["content"] == "new content"

    @respx.mock
    def test_write_file_with_encoding(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """write_file() should support encoding option."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.put(f"{base_url}/sandboxes/sbx-123456/files/path/to/file.txt").mock(
            return_value=httpx.Response(200, json={"size": 12})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.write_file("path/to/file.txt", "base64content", encoding="base64")
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["encoding"] == "base64"


class TestSandboxMetrics:
    """Tests for Sandbox metrics methods."""

    @respx.mock
    def test_metrics(
        self,
        client: APIClient,
        base_url: str,
        sandbox_response: Dict[str, Any],
        metrics_response: Dict[str, Any],
    ):
        """metrics() should return current metrics."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/metrics").mock(
            return_value=httpx.Response(200, json=metrics_response)
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        result = sandbox.metrics()
        
        assert result["cpu_percent"] == 25.5
        assert result["memory_used_mb"] == 512

    @respx.mock
    def test_metrics_history(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """metrics_history() should return historical metrics."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        route = respx.get(f"{base_url}/sandboxes/sbx-123456/metrics/history").mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        
        sandbox = Sandbox.create(template="python", client=client)
        sandbox.metrics_history(
            start="2024-01-01T00:00:00Z",
            end="2024-01-02T00:00:00Z",
            interval="1h",
        )
        
        url = str(route.calls.last.request.url)
        assert "start=" in url
        assert "end=" in url
        assert "interval=1h" in url


class TestSandboxContextManager:
    """Tests for Sandbox context manager functionality."""

    @respx.mock
    def test_context_manager(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Sandbox should work as context manager."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        delete_route = respx.delete(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(204)
        )
        
        with Sandbox.create(template="python", client=client) as sandbox:
            assert sandbox.id == "sbx-123456"
        
        # close() should have been called
        assert delete_route.called

    @respx.mock
    def test_context_manager_on_exception(
        self, client: APIClient, base_url: str, sandbox_response: Dict[str, Any]
    ):
        """Context manager should close sandbox on exception."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=sandbox_response)
        )
        delete_route = respx.delete(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(204)
        )
        
        with pytest.raises(ValueError):
            with Sandbox.create(template="python", client=client) as sandbox:
                raise ValueError("test error")
        
        # close() should have been called even on exception
        assert delete_route.called
