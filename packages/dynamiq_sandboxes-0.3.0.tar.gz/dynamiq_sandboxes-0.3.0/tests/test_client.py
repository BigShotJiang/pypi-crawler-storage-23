"""Tests for Platform SDK APIClient."""
from __future__ import annotations

import os
from typing import Any, Dict
from unittest.mock import patch

import httpx
import pytest
import respx

from dynamiq_sandboxes.client.http import APIClient
from dynamiq_sandboxes.client.retry import RetryConfig
from dynamiq_sandboxes.client.timeout import TimeoutConfig
from dynamiq_sandboxes.exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
)


class TestAPIClientInitialization:
    """Tests for APIClient initialization."""

    def test_init_with_api_key(self, base_url: str):
        """Client should initialize with API key."""
        client = APIClient(api_key="test-key", base_url=base_url)
        assert client is not None
        client.close()

    def test_init_with_bearer_token(self, base_url: str):
        """Client should initialize with bearer token."""
        client = APIClient(bearer_token="test-token", base_url=base_url)
        assert client is not None
        client.close()

    def test_init_with_both_keys(self, base_url: str):
        """Client should accept both API key and bearer token."""
        client = APIClient(
            api_key="test-key",
            bearer_token="test-token",
            base_url=base_url,
        )
        assert client is not None
        client.close()

    def test_init_from_env_api_key(self, mock_env_api_key, base_url: str):
        """Client should read API key from environment."""
        client = APIClient(base_url=base_url)
        assert client is not None
        client.close()

    def test_init_from_env_bearer_token(self, mock_env_bearer_token, base_url: str):
        """Client should read bearer token from environment."""
        client = APIClient(base_url=base_url)
        assert client is not None
        client.close()

    def test_init_requires_auth(self, base_url: str):
        """Client should require authentication."""
        with patch.dict(os.environ, {}, clear=True):
            # Clear any existing env vars
            os.environ.pop("PLATFORM_API_KEY", None)
            os.environ.pop("PLATFORM_BEARER_TOKEN", None)
            
            with pytest.raises(AuthenticationError, match="API key or bearer token required"):
                APIClient(base_url=base_url)

    def test_init_with_custom_retry_config(self, api_key: str, base_url: str):
        """Client should accept custom retry config."""
        retry_config = RetryConfig(max_attempts=5)
        client = APIClient(
            api_key=api_key,
            base_url=base_url,
            retry_config=retry_config,
        )
        assert client.retry_config.max_attempts == 5
        client.close()

    def test_init_with_custom_timeout_config(self, api_key: str, base_url: str):
        """Client should accept custom timeout config."""
        timeout_config = TimeoutConfig(connect=15.0)
        client = APIClient(
            api_key=api_key,
            base_url=base_url,
            timeout_config=timeout_config,
        )
        assert client.timeout_config.connect == 15.0
        client.close()

    def test_init_with_custom_headers(self, api_key: str, base_url: str):
        """Client should accept custom headers."""
        client = APIClient(
            api_key=api_key,
            base_url=base_url,
            headers={"X-Custom-Header": "custom-value"},
        )
        assert client is not None
        client.close()

    def test_base_url_trailing_slash_stripped(self, api_key: str):
        """Base URL trailing slash should be stripped."""
        client = APIClient(api_key=api_key, base_url="https://api.test.io/v1/")
        # The internal _base_url should not have trailing slash
        assert client._base_url == "https://api.test.io/v1"
        client.close()


class TestAPIClientProperties:
    """Tests for APIClient properties."""

    def test_timeout_config_property(self, client: APIClient):
        """timeout_config property should return config."""
        assert isinstance(client.timeout_config, TimeoutConfig)

    def test_retry_config_property(self, client: APIClient):
        """retry_config property should return config."""
        assert isinstance(client.retry_config, RetryConfig)


class TestAPIClientRequests:
    """Tests for APIClient HTTP requests."""

    @respx.mock
    def test_get_request(self, client: APIClient, base_url: str):
        """GET request should work correctly."""
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={"key": "value"})
        )
        
        result = client.get("/test")
        assert result == {"key": "value"}

    @respx.mock
    def test_post_request(self, client: APIClient, base_url: str):
        """POST request should work correctly."""
        respx.post(f"{base_url}/test").mock(
            return_value=httpx.Response(201, json={"id": "123"})
        )
        
        result = client.post("/test", json={"name": "test"})
        assert result == {"id": "123"}

    @respx.mock
    def test_put_request(self, client: APIClient, base_url: str):
        """PUT request should work correctly."""
        respx.put(f"{base_url}/test/123").mock(
            return_value=httpx.Response(200, json={"id": "123", "updated": True})
        )
        
        result = client.put("/test/123", json={"name": "updated"})
        assert result == {"id": "123", "updated": True}

    @respx.mock
    def test_delete_request(self, client: APIClient, base_url: str):
        """DELETE request should return None on 204."""
        respx.delete(f"{base_url}/test/123").mock(
            return_value=httpx.Response(204)
        )
        
        result = client.delete("/test/123")
        assert result is None

    @respx.mock
    def test_request_with_params(self, client: APIClient, base_url: str):
        """Request should include query parameters."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={"results": []})
        )
        
        client.get("/test", params={"limit": 10, "offset": 0})
        
        assert route.called
        assert "limit=10" in str(route.calls.last.request.url)
        assert "offset=0" in str(route.calls.last.request.url)

    @respx.mock
    def test_request_with_custom_headers(self, client: APIClient, base_url: str):
        """Request should include custom headers."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={})
        )
        
        client.request("GET", "/test", headers={"X-Custom": "value"})
        
        assert route.calls.last.request.headers.get("X-Custom") == "value"

    @respx.mock
    def test_request_includes_auth_headers(self, api_key: str, base_url: str):
        """Request should include authentication headers."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={})
        )
        
        client = APIClient(api_key=api_key, base_url=base_url)
        client.get("/test")
        
        assert route.calls.last.request.headers.get("X-API-Key") == api_key
        client.close()

    @respx.mock
    def test_request_includes_bearer_token(self, bearer_token: str, base_url: str):
        """Request should include bearer token when provided."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={})
        )
        
        client = APIClient(bearer_token=bearer_token, base_url=base_url)
        client.get("/test")
        
        auth_header = route.calls.last.request.headers.get("Authorization")
        assert auth_header == f"Bearer {bearer_token}"
        client.close()

    @respx.mock
    def test_request_includes_user_agent(self, client: APIClient, base_url: str):
        """Request should include User-Agent header."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(200, json={})
        )
        
        client.get("/test")
        
        user_agent = route.calls.last.request.headers.get("User-Agent")
        assert "platform-sdk-python" in user_agent

    @respx.mock
    def test_text_response(self, client: APIClient, base_url: str):
        """Non-JSON response should return text."""
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(
                200,
                content=b"plain text response",
                headers={"Content-Type": "text/plain"},
            )
        )
        
        result = client.get("/test")
        assert result == "plain text response"


class TestAPIClientErrorHandling:
    """Tests for APIClient error handling."""

    @respx.mock
    def test_401_raises_authentication_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """401 response should raise AuthenticationError."""
        error_response["error"]["message"] = "Invalid API key"
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(401, json=error_response)
        )
        
        with pytest.raises(AuthenticationError) as exc_info:
            client.get("/test")
        
        assert exc_info.value.status_code == 401

    @respx.mock
    def test_403_raises_authentication_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """403 response should raise AuthenticationError."""
        error_response["error"]["message"] = "Access denied"
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(403, json=error_response)
        )
        
        with pytest.raises(AuthenticationError) as exc_info:
            client.get("/test")
        
        assert exc_info.value.status_code == 403

    @respx.mock
    def test_404_raises_not_found_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """404 response should raise NotFoundError."""
        respx.get(f"{base_url}/test/missing").mock(
            return_value=httpx.Response(404, json=error_response)
        )
        
        with pytest.raises(NotFoundError) as exc_info:
            client.get("/test/missing")
        
        assert exc_info.value.status_code == 404
        assert exc_info.value.error_code == "SANDBOX_NOT_FOUND"
        assert exc_info.value.request_id == "req-123456"

    @respx.mock
    def test_409_raises_conflict_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """409 response should raise ConflictError."""
        error_response["error"]["message"] = "Name already exists"
        respx.post(f"{base_url}/test").mock(
            return_value=httpx.Response(409, json=error_response)
        )
        
        with pytest.raises(ConflictError) as exc_info:
            client.post("/test", json={"name": "duplicate"})
        
        assert exc_info.value.status_code == 409

    @respx.mock
    def test_429_raises_rate_limit_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """429 response should raise RateLimitError after retries."""
        error_response["error"]["message"] = "Rate limit exceeded"
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(429, json=error_response)
        )
        
        # Use fast retry config for tests
        fast_client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=2, base_delay=0.01, jitter=False),
        )
        
        with pytest.raises(RateLimitError) as exc_info:
            fast_client.get("/test")
        
        assert exc_info.value.status_code == 429
        fast_client.close()

    @respx.mock
    def test_500_raises_api_error(
        self, client: APIClient, base_url: str, error_response: Dict[str, Any]
    ):
        """500 response should raise APIError after retries."""
        error_response["error"]["message"] = "Internal server error"
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(500, json=error_response)
        )
        
        # Use fast retry config for tests
        fast_client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=2, base_delay=0.01, jitter=False),
        )
        
        with pytest.raises(APIError) as exc_info:
            fast_client.get("/test")
        
        assert exc_info.value.status_code == 500
        fast_client.close()

    @respx.mock
    def test_error_without_json_body(self, client: APIClient, base_url: str):
        """Error response without JSON should still work."""
        respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(500, content=b"Internal Server Error")
        )
        
        fast_client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=1),
        )
        
        with pytest.raises(APIError) as exc_info:
            fast_client.get("/test")
        
        assert exc_info.value.status_code == 500
        fast_client.close()


class TestAPIClientRetryBehavior:
    """Tests for APIClient retry behavior."""

    @respx.mock
    def test_retry_on_429(self, base_url: str):
        """Client should retry on 429 status."""
        route = respx.get(f"{base_url}/test")
        route.side_effect = [
            httpx.Response(429, json={"error": {"message": "Rate limited"}}),
            httpx.Response(200, json={"success": True}),
        ]
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=3, base_delay=0.01, jitter=False),
        )
        
        result = client.get("/test")
        
        assert result == {"success": True}
        assert route.call_count == 2
        client.close()

    @respx.mock
    def test_retry_on_500(self, base_url: str):
        """Client should retry on 500 status."""
        route = respx.get(f"{base_url}/test")
        route.side_effect = [
            httpx.Response(500, json={"error": {"message": "Server error"}}),
            httpx.Response(500, json={"error": {"message": "Server error"}}),
            httpx.Response(200, json={"success": True}),
        ]
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=3, base_delay=0.01, jitter=False),
        )
        
        result = client.get("/test")
        
        assert result == {"success": True}
        assert route.call_count == 3
        client.close()

    @respx.mock
    def test_no_retry_on_400(self, base_url: str):
        """Client should not retry on 400 status."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(400, json={"error": {"message": "Bad request"}})
        )
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=3, base_delay=0.01, jitter=False),
        )
        
        with pytest.raises(APIError):
            client.get("/test")
        
        assert route.call_count == 1
        client.close()

    @respx.mock
    def test_no_retry_on_404(self, base_url: str):
        """Client should not retry on 404 status."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(404, json={"error": {"message": "Not found"}})
        )
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=3, base_delay=0.01, jitter=False),
        )
        
        with pytest.raises(NotFoundError):
            client.get("/test")
        
        assert route.call_count == 1
        client.close()

    @respx.mock
    def test_max_retries_exhausted(self, base_url: str):
        """Client should raise after max retries."""
        route = respx.get(f"{base_url}/test").mock(
            return_value=httpx.Response(500, json={"error": {"message": "Server error"}})
        )
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=3, base_delay=0.01, jitter=False),
        )
        
        with pytest.raises(APIError):
            client.get("/test")
        
        assert route.call_count == 3
        client.close()


class TestAPIClientTimeout:
    """Tests for APIClient timeout behavior."""

    @respx.mock
    def test_timeout_raises_error(self, base_url: str):
        """Request timeout should raise TimeoutError."""
        def timeout_side_effect(request):
            raise httpx.TimeoutException("Request timed out")
        
        respx.get(f"{base_url}/test").mock(side_effect=timeout_side_effect)
        
        client = APIClient(
            api_key="test",
            base_url=base_url,
            retry_config=RetryConfig(max_attempts=1),
        )
        
        with pytest.raises(TimeoutError):
            client.get("/test")
        
        client.close()


class TestEncodePath:
    """Tests for encode_path static method."""

    def test_simple_path(self):
        """Simple path should be unchanged."""
        assert APIClient.encode_path("file.txt") == "file.txt"

    def test_path_with_slashes(self):
        """Slashes should be preserved."""
        assert APIClient.encode_path("path/to/file.txt") == "path/to/file.txt"

    def test_path_with_spaces(self):
        """Spaces should be encoded."""
        encoded = APIClient.encode_path("my file.txt")
        assert "my%20file.txt" == encoded

    def test_path_with_special_chars(self):
        """Special characters should be encoded."""
        encoded = APIClient.encode_path("file#name.txt")
        assert "%23" in encoded

    def test_empty_path(self):
        """Empty path should be handled."""
        assert APIClient.encode_path("") == ""
