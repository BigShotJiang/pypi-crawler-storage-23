"""Tests for Platform SDK Desktop class."""
from __future__ import annotations

from typing import Any, Dict

import httpx
import pytest
import respx

from dynamiq_sandboxes.client.http import APIClient
from dynamiq_sandboxes.desktop import Desktop


class TestDesktopCreate:
    """Tests for Desktop.create() method."""

    @respx.mock
    def test_create_minimal(
        self, api_key: str, base_url: str, desktop_response: Dict[str, Any]
    ):
        """Create desktop with minimal parameters."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        
        desktop = Desktop.create(api_key=api_key, base_url=base_url)
        
        assert desktop.id == "sbx-123456"
        assert desktop.data["sandbox_type"] == "desktop"
        desktop._client.close()

    @respx.mock
    def test_create_with_options(
        self, api_key: str, base_url: str, desktop_response: Dict[str, Any]
    ):
        """Create desktop with all options."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        
        desktop = Desktop.create(
            template="desktop-kde",
            timeout=7200,
            name="my-desktop",
            vcpu=4,
            memory_mb=8192,
            desktop_config={
                "resolution": "2560x1440",
                "color_depth": 32,
                "enable_audio": True,
            },
            api_key=api_key,
            base_url=base_url,
        )
        
        assert desktop.id == "sbx-123456"
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["sandbox_type"] == "desktop"
        assert body["template_id"] == "desktop-kde"
        desktop._client.close()

    @respx.mock
    def test_create_uses_desktop_defaults(
        self, api_key: str, base_url: str, desktop_response: Dict[str, Any]
    ):
        """Desktop.create() should use desktop-specific defaults."""
        route = respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        
        desktop = Desktop.create(api_key=api_key, base_url=base_url)
        
        import json
        body = json.loads(route.calls.last.request.content)
        # Default template for desktop
        assert body["template_id"] == "desktop-xfce"
        # Desktop gets more memory by default
        assert body["resources"]["memory_mb"] == 4096
        desktop._client.close()


class TestDesktopGet:
    """Tests for Desktop.get() method."""

    @respx.mock
    def test_get_by_id(
        self, api_key: str, base_url: str, desktop_response: Dict[str, Any]
    ):
        """Get desktop by ID."""
        respx.get(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(200, json=desktop_response)
        )
        
        desktop = Desktop.get("sbx-123456", api_key=api_key, base_url=base_url)
        
        assert desktop.id == "sbx-123456"
        assert desktop.data["sandbox_type"] == "desktop"
        desktop._client.close()


class TestDesktopProperties:
    """Tests for Desktop properties."""

    @respx.mock
    def test_live_view_url(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """live_view_url should return URL from response."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        
        desktop = Desktop.create(client=client)
        
        assert desktop.live_view_url == "https://live.test.io/sbx-123456"


class TestDesktopScreenshot:
    """Tests for Desktop screenshot method."""

    @respx.mock
    def test_screenshot_default(
        self,
        client: APIClient,
        base_url: str,
        desktop_response: Dict[str, Any],
        screenshot_response: Dict[str, Any],
    ):
        """screenshot() with defaults."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/screenshot").mock(
            return_value=httpx.Response(200, json=screenshot_response)
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.screenshot()
        
        assert result["format"] == "png"
        assert result["width"] == 1920
        assert result["height"] == 1080

    @respx.mock
    def test_screenshot_with_options(
        self,
        client: APIClient,
        base_url: str,
        desktop_response: Dict[str, Any],
        screenshot_response: Dict[str, Any],
    ):
        """screenshot() with all options."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/screenshot").mock(
            return_value=httpx.Response(200, json=screenshot_response)
        )
        
        desktop = Desktop.create(client=client)
        desktop.screenshot(format="jpeg", quality=85, window_id=123)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["format"] == "jpeg"
        assert body["quality"] == 85
        assert body["window_id"] == 123


class TestDesktopStreaming:
    """Tests for Desktop streaming methods."""

    @respx.mock
    def test_stream_start(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """stream_start() should start VNC stream."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/stream/start").mock(
            return_value=httpx.Response(200, json={
                "url": "https://stream.test.io/sbx-123456",
                "auth_token": "stream-token",
                "websocket_url": "wss://stream.test.io/sbx-123456",
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.stream_start()
        
        assert "url" in result
        assert "auth_token" in result

    @respx.mock
    def test_stream_start_with_options(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """stream_start() with all options."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/stream/start").mock(
            return_value=httpx.Response(200, json={"url": "https://stream.test.io"})
        )
        
        desktop = Desktop.create(client=client)
        desktop.stream_start(
            quality="high",
            frame_rate=30,
            auto_connect=True,
            view_only=False,
            resize="scale",
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["quality"] == "high"
        assert body["frame_rate"] == 30
        assert body["auto_connect"] is True

    @respx.mock
    def test_stream_stop(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """stream_stop() should stop VNC stream."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/stream/stop").mock(
            return_value=httpx.Response(204)
        )
        
        desktop = Desktop.create(client=client)
        desktop.stream_stop()  # Should not raise

    @respx.mock
    def test_stream_info(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """stream_info() should return stream information."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/desktop/stream").mock(
            return_value=httpx.Response(200, json={
                "url": "https://stream.test.io",
                "active": True,
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.stream_info()
        
        assert result["active"] is True


class TestDesktopMouseOperations:
    """Tests for Desktop mouse operations."""

    @respx.mock
    def test_mouse_click(
        self,
        client: APIClient,
        base_url: str,
        desktop_response: Dict[str, Any],
        screenshot_response: Dict[str, Any],
    ):
        """mouse_click() should click at coordinates."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/mouse/click").mock(
            return_value=httpx.Response(200, json={"screenshot": screenshot_response})
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.mouse_click(x=100, y=200, screenshot=True)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["x"] == 100
        assert body["y"] == 200
        assert "screenshot" in result

    @respx.mock
    def test_mouse_click_with_options(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """mouse_click() with all options."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/mouse/click").mock(
            return_value=httpx.Response(200, json={})
        )
        
        desktop = Desktop.create(client=client)
        desktop.mouse_click(
            x=100,
            y=200,
            button="right",
            double_click=True,
            modifiers=["ctrl", "shift"],
        )
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["button"] == "right"
        assert body["double_click"] is True
        assert body["modifiers"] == ["ctrl", "shift"]

    @respx.mock
    def test_mouse_move(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """mouse_move() should move cursor."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/mouse/move").mock(
            return_value=httpx.Response(204)
        )
        
        desktop = Desktop.create(client=client)
        desktop.mouse_move(x=500, y=300)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["x"] == 500
        assert body["y"] == 300

    @respx.mock
    def test_mouse_scroll(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """mouse_scroll() should scroll at coordinates."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/mouse/scroll").mock(
            return_value=httpx.Response(204)
        )
        
        desktop = Desktop.create(client=client)
        desktop.mouse_scroll(x=500, y=300, delta_x=0, delta_y=-100)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["delta_y"] == -100

    @respx.mock
    def test_mouse_drag(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """mouse_drag() should drag from start to end."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/mouse/drag").mock(
            return_value=httpx.Response(204)
        )
        
        desktop = Desktop.create(client=client)
        desktop.mouse_drag(start_x=100, start_y=100, end_x=200, end_y=200)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["start_x"] == 100
        assert body["end_x"] == 200


class TestDesktopKeyboardOperations:
    """Tests for Desktop keyboard operations."""

    @respx.mock
    def test_keyboard_type(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """keyboard_type() should type text."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/keyboard/type").mock(
            return_value=httpx.Response(200, json={})
        )
        
        desktop = Desktop.create(client=client)
        desktop.keyboard_type(text="Hello, World!")
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["text"] == "Hello, World!"

    @respx.mock
    def test_keyboard_press(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """keyboard_press() should press key combination."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/keyboard/press").mock(
            return_value=httpx.Response(200, json={})
        )
        
        desktop = Desktop.create(client=client)
        desktop.keyboard_press(keys=["ctrl", "c"])
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["keys"] == ["ctrl", "c"]

    @respx.mock
    def test_keyboard_press_with_duration(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """keyboard_press() with duration."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/keyboard/press").mock(
            return_value=httpx.Response(200, json={})
        )
        
        desktop = Desktop.create(client=client)
        desktop.keyboard_press(keys=["Enter"], duration_ms=100)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["duration_ms"] == 100


class TestDesktopCursor:
    """Tests for Desktop cursor method."""

    @respx.mock
    def test_cursor(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """cursor() should return cursor position."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/desktop/cursor").mock(
            return_value=httpx.Response(200, json={
                "x": 500,
                "y": 300,
                "visible": True,
                "shape": "default",
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.cursor()
        
        assert result["x"] == 500
        assert result["y"] == 300
        assert result["visible"] is True


class TestDesktopWait:
    """Tests for Desktop wait method."""

    @respx.mock
    def test_wait(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """wait() should pause for duration."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/wait").mock(
            return_value=httpx.Response(200, json={})
        )
        
        desktop = Desktop.create(client=client)
        desktop.wait(duration_ms=1000)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["duration_ms"] == 1000


class TestDesktopWindows:
    """Tests for Desktop window management."""

    @respx.mock
    def test_list_windows(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """list_windows() should return window list."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/desktop/windows").mock(
            return_value=httpx.Response(200, json={
                "windows": [
                    {"id": 1, "title": "Terminal", "visible": True},
                    {"id": 2, "title": "Browser", "visible": True},
                ]
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.list_windows()
        
        assert "windows" in result
        assert len(result["windows"]) == 2

    @respx.mock
    def test_list_windows_visible_only(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """list_windows() with visible_only filter."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.get(f"{base_url}/sandboxes/sbx-123456/desktop/windows").mock(
            return_value=httpx.Response(200, json={"windows": []})
        )
        
        desktop = Desktop.create(client=client)
        desktop.list_windows(visible_only=True)
        
        assert "visible_only=true" in str(route.calls.last.request.url).lower() or "visible_only=True" in str(route.calls.last.request.url)

    @respx.mock
    def test_current_window(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """current_window() should return focused window."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.get(f"{base_url}/sandboxes/sbx-123456/desktop/windows/current").mock(
            return_value=httpx.Response(200, json={
                "id": 1,
                "title": "Terminal",
                "focused": True,
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.current_window()
        
        assert result["id"] == 1
        assert result["focused"] is True

    @respx.mock
    def test_focus_window(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """focus_window() should focus a window."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/windows/123/focus").mock(
            return_value=httpx.Response(204)
        )
        
        desktop = Desktop.create(client=client)
        desktop.focus_window(123)  # Should not raise


class TestDesktopApplications:
    """Tests for Desktop application operations."""

    @respx.mock
    def test_launch(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """launch() should launch application."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/launch").mock(
            return_value=httpx.Response(200, json={
                "pid": 1234,
                "window_id": 5,
            })
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.launch(application="firefox", args=["https://example.com"])
        
        assert result["pid"] == 1234
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["application"] == "firefox"
        assert body["args"] == ["https://example.com"]

    @respx.mock
    def test_launch_with_wait(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """launch() with wait_for_window option."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/launch").mock(
            return_value=httpx.Response(200, json={"pid": 1234})
        )
        
        desktop = Desktop.create(client=client)
        desktop.launch(application="gedit", wait_for_window=True, timeout=30)
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["wait_for_window"] is True
        assert body["timeout"] == 30

    @respx.mock
    def test_open(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """open() should open path with default app."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        route = respx.post(f"{base_url}/sandboxes/sbx-123456/desktop/open").mock(
            return_value=httpx.Response(200, json={"pid": 5678})
        )
        
        desktop = Desktop.create(client=client)
        result = desktop.open(path="/home/user/document.pdf")
        
        assert result["pid"] == 5678
        
        import json
        body = json.loads(route.calls.last.request.content)
        assert body["path"] == "/home/user/document.pdf"


class TestDesktopInheritance:
    """Tests to verify Desktop inherits from Sandbox."""

    @respx.mock
    def test_inherits_sandbox_methods(
        self,
        client: APIClient,
        base_url: str,
        desktop_response: Dict[str, Any],
        run_code_response: Dict[str, Any],
    ):
        """Desktop should have all Sandbox methods."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.post(f"{base_url}/sandboxes/sbx-123456/run").mock(
            return_value=httpx.Response(200, json=run_code_response)
        )
        
        desktop = Desktop.create(client=client)
        
        # Should be able to run code (inherited from Sandbox)
        result = desktop.run_code('print("hello")', language="python")
        assert result["exit_code"] == 0

    @respx.mock
    def test_inherits_context_manager(
        self, client: APIClient, base_url: str, desktop_response: Dict[str, Any]
    ):
        """Desktop should work as context manager."""
        respx.post(f"{base_url}/sandboxes").mock(
            return_value=httpx.Response(201, json=desktop_response)
        )
        respx.delete(f"{base_url}/sandboxes/sbx-123456").mock(
            return_value=httpx.Response(204)
        )
        
        with Desktop.create(client=client) as desktop:
            assert desktop.id == "sbx-123456"
