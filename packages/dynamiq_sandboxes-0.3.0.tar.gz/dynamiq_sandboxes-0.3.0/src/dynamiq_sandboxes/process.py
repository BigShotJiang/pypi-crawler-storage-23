from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import APIClient
    from .stream import ProcessStream

try:
    import websocket
    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False


@dataclass
class ProcessResult:
    """Result of a process execution."""

    exit_code: int
    stdout: str
    stderr: str
    execution_time_ms: int

    @classmethod
    def from_response(cls, response: Dict[str, Any]) -> "ProcessResult":
        """Create ProcessResult from API response."""
        return cls(
            exit_code=response.get("exit_code", -1),
            stdout=response.get("stdout", ""),
            stderr=response.get("stderr", ""),
            execution_time_ms=response.get("execution_time_ms", 0),
        )


class Process:
    """Represents a running process in a sandbox.

    This class provides process management, allowing you to
    interact with long-running processes via WebSocket streaming.
    """

    def __init__(
        self,
        process_id: str,
        sandbox_id: str,
        client: "APIClient",
        *,
        ws_connection: Optional[Any] = None,
        on_stdout: Optional[Callable[[str], None]] = None,
        on_stderr: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._process_id = process_id
        self._sandbox_id = sandbox_id
        self._client = client
        self._ws = ws_connection
        self._on_stdout = on_stdout
        self._on_stderr = on_stderr
        self._exit_code: Optional[int] = None
        self._stdout_data: List[str] = []
        self._stderr_data: List[str] = []
        self._start_time = time.time()
        self._end_time: Optional[float] = None
        self._finished = threading.Event()
        self._listener_thread: Optional[threading.Thread] = None

        if self._ws is not None:
            self._start_listener()

    @property
    def pid(self) -> str:
        """Return the process ID."""
        return self._process_id

    @property
    def finished(self) -> bool:
        """Check if the process has finished."""
        return self._finished.is_set()

    @property
    def exit_code(self) -> Optional[int]:
        """Return the exit code if the process has finished."""
        return self._exit_code

    def _start_listener(self) -> None:
        """Start a background thread to listen for process output."""
        def listener():
            import base64
            try:
                while not self._finished.is_set():
                    try:
                        raw_msg = self._ws.recv()
                        if not raw_msg:
                            break
                        msg = json.loads(raw_msg)
                        msg_type = msg.get("type", "")

                        if msg_type == "stdout":
                            data = base64.b64decode(
                                msg.get("data", "")
                            ).decode("utf-8", errors="replace")
                            self._stdout_data.append(data)
                            if self._on_stdout:
                                self._on_stdout(data)
                        elif msg_type == "stderr":
                            data = base64.b64decode(
                                msg.get("data", "")
                            ).decode("utf-8", errors="replace")
                            self._stderr_data.append(data)
                            if self._on_stderr:
                                self._on_stderr(data)
                        elif msg_type == "exit":
                            self._exit_code = msg.get("code", -1)
                            self._end_time = time.time()
                            self._finished.set()
                            break
                    except Exception:
                        break
            finally:
                self._finished.set()

        self._listener_thread = threading.Thread(target=listener, daemon=True)
        self._listener_thread.start()

    def wait(self, timeout: Optional[int] = None) -> ProcessResult:
        """Wait for the process to complete and return the result.

        Args:
            timeout: Maximum time to wait in seconds. None means wait
                indefinitely.

        Returns:
            ProcessResult with exit_code, stdout, stderr, and
            execution_time_ms.

        Raises:
            TimeoutError: If the process doesn't complete within the timeout.
        """
        if not self._finished.wait(timeout=timeout):
            raise TimeoutError(
                f"Process {self._process_id} did not complete "
                f"within {timeout} seconds"
            )

        end = self._end_time or time.time()
        execution_time_ms = int((end - self._start_time) * 1000)

        return ProcessResult(
            exit_code=self._exit_code if self._exit_code is not None else -1,
            stdout="".join(self._stdout_data),
            stderr="".join(self._stderr_data),
            execution_time_ms=execution_time_ms,
        )

    def kill(self, signal: str = "SIGTERM") -> None:
        """Send a signal to kill the process.

        Args:
            signal: The signal to send (e.g., "SIGTERM", "SIGKILL", "SIGINT").
        """
        if self._ws is None:
            return

        # Map signal names to numbers
        signal_map = {
            "SIGTERM": 15,
            "SIGKILL": 9,
            "SIGINT": 2,
            "SIGHUP": 1,
            "SIGQUIT": 3,
        }
        sig_num = signal_map.get(signal.upper(), 15)

        try:
            self._ws.send(json.dumps({
                "type": "signal",
                "signal": sig_num,
            }))
        except Exception:
            pass  # Connection may already be closed

    def send_stdin(self, data: str) -> None:
        """Send data to the process's standard input.

        Args:
            data: The string data to send to stdin.
        """
        if self._ws is None:
            raise RuntimeError("Cannot send stdin to a non-streaming process")

        import base64
        encoded_data = base64.b64encode(data.encode("utf-8")).decode("ascii")

        self._ws.send(json.dumps({
            "type": "stdin",
            "data": encoded_data,
        }))

    def resize(self, rows: int, cols: int) -> None:
        """Resize the terminal (only for TTY processes).

        Args:
            rows: Number of rows.
            cols: Number of columns.
        """
        if self._ws is None:
            return

        self._ws.send(json.dumps({
            "type": "resize",
            "rows": rows,
            "cols": cols,
        }))

    def __enter__(self) -> "Process":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if not self._finished.is_set():
            self.kill()
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass


class ProcessManager:
    """Process manager API.

    Provides methods for starting, running, and managing processes in a
    sandbox. Supports both synchronous execution and streaming with callbacks.

    Example:
        >>> sandbox = Sandbox.create(template="python")
        >>> result = sandbox.process.run("python", args=["--version"])
        >>> print(result.stdout)
        Python 3.11.0

        >>> # With streaming callbacks
        >>> def on_stdout(data):
        ...     print("OUT:", data)
        >>> process = sandbox.process.start("python", args=["long_script.py"],
        ...                                  on_stdout=on_stdout)
        >>> result = process.wait()
    """

    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        self._sandbox_id = sandbox_id
        self._client = client

    def start(
        self,
        cmd: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        on_stdout: Optional[Callable[[str], None]] = None,
        on_stderr: Optional[Callable[[str], None]] = None,
        tty: bool = False,
        rows: int = 24,
        cols: int = 80,
    ) -> Process:
        """Start a process with streaming output.

        This method starts a process and returns immediately, allowing you to
        interact with it via the returned Process object. Output is streamed
        via WebSocket and can be handled through callbacks.

        Args:
            cmd: The command to execute.
            args: Optional list of command arguments.
            env: Optional environment variables.
            cwd: Optional working directory.
            on_stdout: Callback for stdout data.
            on_stderr: Callback for stderr data.
            tty: Whether to allocate a pseudo-terminal.
            rows: Terminal rows (only used if tty=True).
            cols: Terminal columns (only used if tty=True).

        Returns:
            A Process object for interacting with the running process.

        Raises:
            ImportError: If the websocket-client package is not installed.
            RuntimeError: If unable to connect to the process stream.
        """
        if not HAS_WEBSOCKET:
            raise ImportError(
                "The websocket-client package is required for streaming. "
                "Install it with: pip install websocket-client"
            )

        # Build WebSocket URL
        base_url = self._client._base_url
        ws_scheme = "wss" if base_url.startswith("https") else "ws"
        ws_host = base_url.split("://", 1)[1]
        ws_url = (
            f"{ws_scheme}://{ws_host}/sandboxes/"
            f"{self._sandbox_id}/process/stream"
        )

        # Connect with authentication headers
        headers = {}
        for key, value in self._client._client.headers.items():
            if key.lower() in ("x-api-key", "authorization"):
                headers[key] = value

        ws = websocket.create_connection(ws_url, header=headers)

        # Send start message
        start_msg: Dict[str, Any] = {
            "type": "start",
            "command": cmd,
        }
        if args:
            start_msg["args"] = args
        if env:
            start_msg["env"] = env
        if cwd:
            start_msg["working_dir"] = cwd
        if tty:
            start_msg["tty"] = True
            start_msg["rows"] = rows
            start_msg["cols"] = cols

        ws.send(json.dumps(start_msg))

        # Wait for "started" message with PID
        raw_response = ws.recv()
        response = json.loads(raw_response)

        if response.get("type") == "error":
            ws.close()
            raise RuntimeError(
                f"Failed to start process: "
                f"{response.get('message', 'unknown error')}"
            )

        process_id = str(response.get("pid", "unknown"))

        return Process(
            process_id=process_id,
            sandbox_id=self._sandbox_id,
            client=self._client,
            ws_connection=ws,
            on_stdout=on_stdout,
            on_stderr=on_stderr,
        )

    def run(
        self,
        cmd: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
        background: bool = False,
    ) -> ProcessResult:
        """Execute a command and wait for it to complete.

        This is a convenience method that combines start() and wait().
        For simple command execution, this is the recommended approach.

        Args:
            cmd: The command to execute.
            args: Optional list of command arguments.
            env: Optional environment variables for this command.
            cwd: Optional working directory.
            timeout: Optional timeout in seconds.
            background: If True, start in background and return immediately.

        Returns:
            ProcessResult with exit_code, stdout, stderr, and
            execution_time_ms.
        """
        payload: Dict[str, Any] = {"command": cmd}
        if args:
            payload["args"] = args
        if env:
            payload["env"] = env
        if cwd:
            payload["working_dir"] = cwd
        if timeout:
            payload["timeout"] = timeout
        if background:
            payload["background"] = True

        http_timeout = self._client.timeout_config.process_execution
        if timeout is not None:
            http_timeout = float(timeout + 5)

        response = self._client.post(
            f"sandboxes/{self._sandbox_id}/commands",
            json=payload,
            timeout=http_timeout,
        )

        return ProcessResult.from_response(response)

    def run_code(
        self,
        code: str,
        language: str,
        timeout: Optional[int] = None,
    ) -> ProcessResult:
        """Execute code in a specific language.

        Args:
            code: The code to execute.
            language: The programming language (e.g., "python", "javascript").
            timeout: Optional timeout in seconds.

        Returns:
            ProcessResult with exit_code, stdout, stderr, and
            execution_time_ms.
        """
        payload: Dict[str, Any] = {
            "code": code,
            "language": language,
        }
        if timeout:
            payload["timeout"] = timeout

        http_timeout = self._client.timeout_config.process_execution
        if timeout is not None:
            http_timeout = float(timeout + 5)

        response = self._client.post(
            f"sandboxes/{self._sandbox_id}/run",
            json=payload,
            timeout=http_timeout,
        )

        return ProcessResult.from_response(response)

    def list(self) -> List[Dict[str, Any]]:
        """List running processes in the sandbox.

        Returns:
            List of process information dictionaries.

        Note:
            This method requires backend support for process listing.
            If not supported, it returns an empty list.
        """
        try:
            response = self._client.get(
                f"sandboxes/{self._sandbox_id}/processes"
            )
            if isinstance(response, list):
                return response
            return response.get("processes", [])
        except Exception:
            # Process listing may not be supported by all backends
            return []

    def stream(self) -> "ProcessStream":
        """Get a ProcessStream for direct streaming control.

        Returns a ProcessStream instance for lower-level control over
        process streaming. This is useful when you need more control
        than the Process wrapper provides, such as:
        - Multiple processes over a single connection
        - Direct access to the WebSocket
        - More granular callback control

        Returns:
            ProcessStream instance for streaming process I/O.

        Example:
            >>> with sandbox.process.stream() as stream:
            ...     stream.on_stdout(print)
            ...     stream.on_exit(lambda code: print(f"Exited: {code}"))
            ...     stream.start_process("bash", tty=True)
            ...     stream.send_stdin("ls -la\\n")
            ...     stream.wait_for_exit()
        """
        # Lazy import to avoid circular dependency
        from .stream import ProcessStream
        return ProcessStream(self._sandbox_id, self._client)
