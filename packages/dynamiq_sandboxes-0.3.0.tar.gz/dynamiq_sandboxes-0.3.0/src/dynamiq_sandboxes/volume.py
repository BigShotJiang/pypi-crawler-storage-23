"""Persistent volume management for sandboxes."""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .client import APIClient


@dataclass
class VolumeInfo:
    """Information about a persistent volume."""

    id: str
    name: str
    size_gb: int
    state: str  # "available", "attached", "deleting"
    attached_to: Optional[str]  # sandbox_id
    mount_path: Optional[str]
    created_at: str

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "VolumeInfo":
        """Create VolumeInfo from API response."""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            size_gb=data.get("size_gb", 0),
            state=data.get("state", "unknown"),
            attached_to=data.get("attached_to"),
            mount_path=data.get("mount_path"),
            created_at=data.get("created_at", ""),
        )


class Volume:
    """Persistent volume that can be attached to sandboxes.

    Volumes provide persistent storage that survives sandbox restarts
    and can be shared between sandboxes (one at a time).

    Example:
        >>> # Create and attach a volume
        >>> volume = Volume.create(name="my-data", size_gb=20)
        >>> volume.attach(sandbox_id, mount_path="/mnt/data")
        >>>
        >>> # Later, detach and reattach to another sandbox
        >>> volume.detach(sandbox_id)
        >>> volume.attach(another_sandbox_id, mount_path="/mnt/data")
        >>>
        >>> # Get existing volume
        >>> volume = Volume.get(volume_id)
        >>>
        >>> # Get or create by name
        >>> volume = Volume.get_or_create(name="my-data", size_gb=20)
    """

    def __init__(
        self,
        volume_id: str,
        client: "APIClient",
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize a Volume instance.

        Args:
            volume_id: The unique identifier of the volume.
            client: The API client for making requests.
            data: Optional initial data from API response.
        """
        self._id = volume_id
        self._client = client
        self._data: Dict[str, Any] = data or {}

    def __repr__(self) -> str:
        return (
            f"Volume(id={self._id!r}, name={self.name!r}, state={self.state!r})"
        )

    @property
    def id(self) -> str:
        """The unique identifier of the volume."""
        return self._id

    @property
    def name(self) -> str:
        """The name of the volume."""
        return self._data.get("name", "")

    @property
    def size_gb(self) -> int:
        """The size of the volume in gigabytes."""
        return self._data.get("size_gb", 0)

    @property
    def state(self) -> str:
        """The current state of the volume.

        Possible values: "available", "attached", "deleting"
        """
        return self._data.get("state", "unknown")

    @property
    def is_attached(self) -> bool:
        """Whether the volume is currently attached to a sandbox."""
        return self.state == "attached"

    @property
    def attached_to(self) -> Optional[str]:
        """The sandbox ID this volume is attached to, if any."""
        return self._data.get("attached_to")

    @property
    def mount_path(self) -> Optional[str]:
        """The mount path in the sandbox, if attached."""
        return self._data.get("mount_path")

    @property
    def created_at(self) -> str:
        """The timestamp when the volume was created."""
        return self._data.get("created_at", "")

    @property
    def data(self) -> Dict[str, Any]:
        """The raw data dictionary from the API."""
        return self._data

    def info(self) -> VolumeInfo:
        """Get a VolumeInfo snapshot of the current volume state.

        Returns:
            VolumeInfo dataclass with current volume information.
        """
        return VolumeInfo.from_api_response(self._data)

    @classmethod
    def create(
        cls,
        name: str,
        size_gb: int = 10,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        client: Optional["APIClient"] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Volume":
        """Create a new persistent volume.

        Args:
            name: A unique name for the volume.
            size_gb: Size of the volume in gigabytes (default: 10).
            metadata: Optional metadata to attach to the volume.
            client: Optional API client instance.
            api_key: Optional API key (uses PLATFORM_API_KEY env var if not
                provided).
            base_url: Base URL for the API.

        Returns:
            A new Volume instance.

        Raises:
            APIError: If volume creation fails.
            ConflictError: If a volume with the same name already exists.

        Example:
            >>> volume = Volume.create(name="my-data", size_gb=50)
            >>> print(f"Created volume: {volume.id}")
        """
        from .client import APIClient as ClientClass

        client = client or ClientClass(api_key=api_key, base_url=base_url)

        payload: Dict[str, Any] = {
            "name": name,
            "size_gb": size_gb,
        }
        if metadata:
            payload["metadata"] = metadata

        response = client.post("volumes", json=payload)
        volume_id = response.get("id", response.get("volume_id", ""))
        return cls(volume_id=volume_id, client=client, data=response)

    @classmethod
    def get(
        cls,
        volume_id: str,
        *,
        client: Optional["APIClient"] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Volume":
        """Get an existing volume by ID.

        Args:
            volume_id: The unique identifier of the volume.
            client: Optional API client instance.
            api_key: Optional API key (uses PLATFORM_API_KEY env var if not
                provided).
            base_url: Base URL for the API.

        Returns:
            The Volume instance.

        Raises:
            NotFoundError: If the volume doesn't exist.

        Example:
            >>> volume = Volume.get("vol-abc123")
            >>> print(f"Volume state: {volume.state}")
        """
        from .client import APIClient as ClientClass

        client = client or ClientClass(api_key=api_key, base_url=base_url)
        response = client.get(f"volumes/{volume_id}")
        return cls(volume_id=volume_id, client=client, data=response)

    @classmethod
    def get_or_create(
        cls,
        name: str,
        size_gb: int = 10,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        client: Optional["APIClient"] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Volume":
        """Get an existing volume by name, or create if it doesn't exist.

        This is useful for idempotent volume provisioning where you want to
        ensure a volume exists without duplicating if called multiple times.

        Args:
            name: The name of the volume to get or create.
            size_gb: Size for new volume in gigabytes (default: 10).
                Ignored if volume already exists.
            metadata: Optional metadata for new volume. Ignored if exists.
            client: Optional API client instance.
            api_key: Optional API key (uses PLATFORM_API_KEY env var if not
                provided).
            base_url: Base URL for the API.

        Returns:
            The existing or newly created Volume instance.

        Example:
            >>> # First call creates the volume
            >>> volume = Volume.get_or_create(name="shared-data", size_gb=100)
            >>>
            >>> # Subsequent calls return the existing volume
            >>> same_volume = Volume.get_or_create(name="shared-data")
            >>> assert volume.id == same_volume.id
        """
        from .client import APIClient as ClientClass

        client = client or ClientClass(api_key=api_key, base_url=base_url)

        # First, try to find an existing volume with this name
        try:
            volumes_response = client.get("volumes", params={"name": name})
            volumes = volumes_response.get(
                "volumes", volumes_response.get("items", [])
            )

            for vol_data in volumes:
                if vol_data.get("name") == name:
                    volume_id = vol_data.get(
                        "id", vol_data.get("volume_id", "")
                    )
                    return cls(
                        volume_id=volume_id, client=client, data=vol_data
                    )
        except Exception:
            # If listing fails, try to create
            pass

        # Volume doesn't exist, create it
        return cls.create(
            name=name,
            size_gb=size_gb,
            metadata=metadata,
            client=client,
        )

    @classmethod
    def list(
        cls,
        *,
        state: Optional[str] = None,
        name: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        client: Optional["APIClient"] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> List["Volume"]:
        """List all volumes.

        Args:
            state: Filter by state ("available", "attached", "deleting").
            name: Filter by name (exact match).
            limit: Maximum number of volumes to return.
            offset: Number of volumes to skip (for pagination).
            client: Optional API client instance.
            api_key: Optional API key (uses PLATFORM_API_KEY env var if not
                provided).
            base_url: Base URL for the API.

        Returns:
            List of Volume instances.

        Example:
            >>> # List all available volumes
            >>> volumes = Volume.list(state="available")
            >>> for vol in volumes:
            ...     print(f"{vol.name}: {vol.size_gb}GB")
        """
        from .client import APIClient as ClientClass

        client = client or ClientClass(api_key=api_key, base_url=base_url)

        params: Dict[str, Any] = {}
        if state:
            params["state"] = state
        if name:
            params["name"] = name
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        response = client.get("volumes", params=params)
        volumes_data = response.get("volumes", response.get("items", []))

        return [
            cls(
                volume_id=vol_data.get("id", vol_data.get("volume_id", "")),
                client=client,
                data=vol_data,
            )
            for vol_data in volumes_data
        ]

    def refresh(self) -> None:
        """Refresh the volume data from the API.

        Updates the local state with the latest information from the server.

        Example:
            >>> volume.attach(sandbox_id, "/mnt/data")
            >>> volume.refresh()
            >>> print(volume.state)  # "attached"
        """
        self._data = self._client.get(f"volumes/{self._id}")

    def attach(
        self,
        sandbox_id: str,
        mount_path: str = "/mnt/data",
    ) -> None:
        """Attach this volume to a sandbox.

        The volume must be in "available" state to be attached.
        A volume can only be attached to one sandbox at a time.

        Args:
            sandbox_id: The ID of the sandbox to attach to.
            mount_path: The path where the volume will be mounted
                (default: "/mnt/data").

        Raises:
            APIError: If attachment fails.
            ConflictError: If the volume is already attached.

        Example:
            >>> volume = Volume.get("vol-abc123")
            >>> volume.attach(sandbox.id, mount_path="/workspace/data")
        """
        payload: Dict[str, Any] = {
            "sandbox_id": sandbox_id,
            "mount_path": mount_path,
        }
        response = self._client.post(
            f"volumes/{self._id}/attach", json=payload
        )

        # Update local state
        if response:
            self._data.update(response)
        else:
            # If no response body, update what we know
            self._data["state"] = "attached"
            self._data["attached_to"] = sandbox_id
            self._data["mount_path"] = mount_path

    def detach(self, sandbox_id: Optional[str] = None) -> None:
        """Detach this volume from a sandbox.

        The volume must be in "attached" state to be detached.

        Args:
            sandbox_id: The ID of the sandbox to detach from.
                If not provided, uses the currently attached sandbox.

        Raises:
            APIError: If detachment fails.
            ValueError: If sandbox_id not provided and volume is not attached.

        Example:
            >>> volume.detach(sandbox.id)
            >>> # or simply:
            >>> volume.detach()  # detaches from current sandbox
        """
        target_sandbox = sandbox_id or self.attached_to
        if not target_sandbox:
            raise ValueError(
                "sandbox_id must be provided when volume is not attached"
            )

        payload: Dict[str, Any] = {
            "sandbox_id": target_sandbox,
        }
        response = self._client.post(
            f"volumes/{self._id}/detach", json=payload
        )

        # Update local state
        if response:
            self._data.update(response)
        else:
            # If no response body, update what we know
            self._data["state"] = "available"
            self._data["attached_to"] = None
            self._data["mount_path"] = None

    def delete(self) -> None:
        """Delete this volume.

        The volume must be in "available" state (not attached) to be deleted.
        This action is irreversible and all data on the volume will be lost.

        Raises:
            APIError: If deletion fails.
            ConflictError: If the volume is currently attached.

        Example:
            >>> volume.detach(sandbox_id)
            >>> volume.delete()
        """
        self._client.delete(f"volumes/{self._id}")
        self._data["state"] = "deleting"


class VolumeManager:
    """Convenience manager for volume operations related to a specific sandbox.

    Provides methods to list, attach, and detach volumes for a sandbox.
    Accessed via `sandbox.volumes`.

    Example:
        >>> sandbox = Sandbox.create(template="base")
        >>>
        >>> # Attach a volume
        >>> volume = Volume.get_or_create("my-data", size_gb=10)
        >>> sandbox.volumes.attach(volume, mount_path="/mnt/data")
        >>>
        >>> # List attached volumes
        >>> attached = sandbox.volumes.list_attached()
        >>> for vol in attached:
        ...     print(f"{vol.name} mounted at {vol.mount_path}")
        >>>
        >>> # Detach all volumes
        >>> sandbox.volumes.detach_all()
    """

    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        """Initialize the VolumeManager.

        Args:
            sandbox_id: The ID of the sandbox to manage volumes for.
            client: The API client for making requests.
        """
        self._sandbox_id = sandbox_id
        self._client = client

    def list_attached(self) -> List[Volume]:
        """List all volumes attached to this sandbox.

        Returns:
            List of Volume instances attached to this sandbox.

        Example:
            >>> attached = sandbox.volumes.list_attached()
            >>> print(f"Sandbox has {len(attached)} volumes attached")
        """
        all_volumes = Volume.list(client=self._client)
        return [
            vol for vol in all_volumes if vol.attached_to == self._sandbox_id
        ]

    def attach(
        self,
        volume: Volume,
        mount_path: str = "/mnt/data",
    ) -> None:
        """Attach a volume to this sandbox.

        Args:
            volume: The Volume instance to attach.
            mount_path: The path where the volume will be mounted.

        Example:
            >>> volume = Volume.get("vol-abc123")
            >>> sandbox.volumes.attach(volume, "/workspace/data")
        """
        volume.attach(self._sandbox_id, mount_path=mount_path)

    def detach(self, volume: Volume) -> None:
        """Detach a volume from this sandbox.

        Args:
            volume: The Volume instance to detach.

        Example:
            >>> sandbox.volumes.detach(volume)
        """
        volume.detach(self._sandbox_id)

    def detach_all(self) -> None:
        """Detach all volumes from this sandbox.

        Example:
            >>> sandbox.volumes.detach_all()
        """
        attached = self.list_attached()
        for volume in attached:
            volume.detach(self._sandbox_id)
