from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

from .client import APIClient
from .stream import FileWatcher, ProcessStream

if TYPE_CHECKING:
    from .filesystem import Filesystem
    from .interpreter import CodeInterpreter
    from .pty import PTYManager
    from .volume import VolumeManager


ALL_TRAFFIC = "0.0.0.0/0"


@dataclass
class NetworkConfig:
    allow_internet_access: bool = True
    allow_public_traffic: bool = True
    allow_out: Optional[List[str]] = None
    deny_out: Optional[List[str]] = None
    mask_request_host: Optional[str] = None

    def to_payload(self) -> Dict[str, Any]:
        payload = asdict(self)
        return {
            key: value
            for key, value in payload.items()
            if value is not None
        }


class Sandbox:
    """Sandbox convenience wrapper for the Platform API."""

    def __init__(
        self,
        sandbox_id: str,
        client: APIClient,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._id = sandbox_id
        self._client = client
        self._data: Dict[str, Any] = data or {}

    def __enter__(self) -> "Sandbox":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()

    @property
    def id(self) -> str:
        return self._id

    @property
    def data(self) -> Dict[str, Any]:
        return self._data

    @property
    def cdp_websocket_url(self) -> Optional[str]:
        return self._data.get("cdp_websocket_url")

    @property
    def live_view_url(self) -> Optional[str]:
        return self._data.get("live_view_url")

    @property
    def debugger_url(self) -> Optional[str]:
        return self._data.get("debugger_url")

    @property
    def state(self) -> Optional[str]:
        return self._data.get("state")

    @property
    def traffic_access_token(self) -> Optional[str]:
        return self._data.get("traffic_access_token")

    @property
    def filesystem(self) -> "Filesystem":
        """Get the Filesystem interface for this sandbox.
        
        Returns:
            Filesystem instance for file operations.
            
        Example:
            >>> sandbox = Sandbox.create(template="base")
            >>> sandbox.filesystem.write("/workspace/test.txt", "Hello!")
            >>> content = sandbox.filesystem.read("/workspace/test.txt")
        """
        # Lazy import to avoid circular dependencies
        from .filesystem import Filesystem
        
        if not hasattr(self, "_filesystem"):
            self._filesystem = Filesystem(self._id, self._client)
        return self._filesystem

    @property
    def process(self) -> "ProcessManager":
        """Get the ProcessManager interface for this sandbox.
        
        Returns:
            ProcessManager instance for process operations.
            
        Example:
            >>> sandbox = Sandbox.create(template="python")
            >>> # Simple command execution
            >>> result = sandbox.process.run("python", args=["--version"])
            >>> print(result.stdout)
            
            >>> # With streaming callbacks
            >>> def on_stdout(data):
            ...     print("OUT:", data)
            >>> process = sandbox.process.start("python", args=["script.py"],
            ...                                  on_stdout=on_stdout)
            >>> result = process.wait()
        """
        # Lazy import to avoid circular dependencies
        from .process import ProcessManager
        
        if not hasattr(self, "_process_manager"):
            self._process_manager = ProcessManager(self._id, self._client)
        return self._process_manager

    @property
    def pty(self) -> "PTYManager":
        """Get the PTYManager interface for this sandbox.
        
        Returns:
            PTYManager instance for interactive terminal sessions.
            
        Example:
            >>> sandbox = Sandbox.create(template="base")
            >>> 
            >>> # Create an interactive PTY session
            >>> with sandbox.pty.create() as pty:
            ...     pty.send_line("echo Hello World")
            ...     output = pty.wait_for("Hello World", timeout=5)
            ...     print(output)
            
            >>> # With custom terminal size
            >>> pty = sandbox.pty.create(rows=40, cols=120)
            >>> pty.on_data(lambda data: print(data, end=""))
            >>> pty.send_line("ls -la")
            
            >>> # Spawn a specific command in PTY
            >>> pty = sandbox.pty.spawn("python", ["-i"])
            >>> pty.send_line("print('Hello from Python')")
        """
        # Lazy import to avoid circular dependencies
        from .pty import PTYManager
        
        if not hasattr(self, "_pty_manager"):
            self._pty_manager = PTYManager(self._id, self._client)
        return self._pty_manager

    @property
    def volumes(self) -> "VolumeManager":
        """Get the VolumeManager interface for this sandbox.
        
        Returns:
            VolumeManager instance for volume operations.
            
        Example:
            >>> sandbox = Sandbox.create(template="base")
            >>> 
            >>> # Attach a volume to this sandbox
            >>> from platform_sdk import Volume
            >>> volume = Volume.get_or_create("my-data", size_gb=10)
            >>> sandbox.volumes.attach(volume, mount_path="/mnt/data")
            >>> 
            >>> # List attached volumes
            >>> attached = sandbox.volumes.list_attached()
            >>> for vol in attached:
            ...     print(f"{vol.name} at {vol.mount_path}")
            >>> 
            >>> # Detach all volumes before closing
            >>> sandbox.volumes.detach_all()
        """
        # Lazy import to avoid circular dependencies
        from .volume import VolumeManager
        
        if not hasattr(self, "_volume_manager"):
            self._volume_manager = VolumeManager(self._id, self._client)
        return self._volume_manager

    def code_interpreter(
        self,
        language: str = "python",
        *,
        working_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
    ) -> "CodeInterpreter":
        """Create a stateful code interpreter for this sandbox.
        
        Unlike run_code() which starts a fresh process each time,
        CodeInterpreter keeps a REPL running so variables persist
        between executions.
        
        Args:
            language: Programming language ("python", "javascript", or "node").
            working_dir: Working directory for the interpreter process.
            env: Additional environment variables.
        
        Returns:
            A new CodeInterpreter instance (not started).
            Call start() or use as context manager to begin.
        
        Example:
            >>> # Using as context manager (recommended)
            >>> with sandbox.code_interpreter(language="python") as interp:
            ...     interp.run("x = 5")
            ...     interp.run("y = 10")
            ...     result = interp.run("print(x + y)")  # prints 15
            ...     print(result.output)
            
            >>> # Manual lifecycle management
            >>> interp = sandbox.code_interpreter(language="python")
            >>> interp.start()
            >>> try:
            ...     interp.run("data = [1, 2, 3]")
            ...     result = interp.run("print(sum(data))")  # prints 6
            ... finally:
            ...     interp.stop()
        """
        # Lazy import to avoid circular dependencies
        from .interpreter import CodeInterpreter
        
        return CodeInterpreter(
            self,
            language=language,
            working_dir=working_dir,
            env=env,
        )

    @classmethod
    def create(
        cls,
        *,
        template: str,
        timeout: int = 300,
        idle_timeout: Optional[int] = None,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 2048,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        network: Optional[Union[NetworkConfig, Dict[str, Any]]] = None,
        sandbox_type: str = "code",
        is_desktop: Optional[bool] = None,
        desktop_config: Optional[Dict[str, Any]] = None,
        browser_config: Optional[Dict[str, Any]] = None,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Sandbox":
        client = client or APIClient(api_key=api_key, base_url=base_url)
        payload: Dict[str, Any] = {
            "template_id": template,
            "timeout": timeout,
            "sandbox_type": sandbox_type,
            "resources": {
                "vcpu": vcpu,
                "memory_mb": memory_mb,
            },
        }
        if disk_mb is not None:
            payload["resources"]["disk_mb"] = disk_mb
        if idle_timeout is not None:
            payload["idle_timeout"] = idle_timeout
        if name is not None:
            payload["name"] = name
        if tags:
            payload["tags"] = tags
        if env_vars:
            payload["env_vars"] = env_vars
        if metadata:
            payload["metadata"] = metadata
        if network:
            if isinstance(network, NetworkConfig):
                payload["network"] = network.to_payload()
            else:
                payload["network"] = network
        if is_desktop is not None:
            payload["is_desktop"] = is_desktop
        if desktop_config:
            payload["desktop_config"] = desktop_config
        if browser_config:
            payload["browser_config"] = browser_config

        response = client.post(
            "sandboxes",
            json=payload,
            timeout=client.timeout_config.create_sandbox,
        )
        sandbox_id = response["sandbox_id"]
        return cls(sandbox_id=sandbox_id, client=client, data=response)

    @classmethod
    def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Sandbox":
        client = client or APIClient(api_key=api_key, base_url=base_url)
        response = client.get(f"sandboxes/{sandbox_id}")
        return cls(sandbox_id=sandbox_id, client=client, data=response)

    @classmethod
    def from_name(
        cls,
        name: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Sandbox":
        client = client or APIClient(api_key=api_key, base_url=base_url)
        response = client.get(
            f"sandboxes/by-name/{APIClient.encode_path(name)}"
        )
        return cls(
            sandbox_id=response["sandbox_id"],
            client=client,
            data=response,
        )

    @classmethod
    def connect(
        cls,
        sandbox_id: str,
        *,
        timeout: int = 300,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Sandbox":
        """Connect to an existing sandbox, automatically resuming if paused.

        This mirrors E2B's Sandbox.connect() pattern: if the sandbox is
        paused, it will be automatically resumed before returning.

        Args:
            sandbox_id: The ID of the sandbox to connect to.
            timeout: Timeout in seconds (used when resuming a paused sandbox).
            client: Optional pre-configured APIClient.
            api_key: API key (alternative to client).
            base_url: API base URL (alternative to client).

        Returns:
            A connected Sandbox instance.
        """
        client = client or APIClient(api_key=api_key, base_url=base_url)
        response = client.get(f"sandboxes/{sandbox_id}")
        sandbox = cls(sandbox_id=sandbox_id, client=client, data=response)

        if sandbox.state == "paused":
            sandbox.resume(timeout=timeout)
            sandbox.refresh()

        return sandbox

    @classmethod
    def list(
        cls,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        state: Optional[str] = None,
        template_id: Optional[str] = None,
        name: Optional[str] = None,
        sandbox_type: Optional[str] = None,
        is_desktop: Optional[bool] = None,
        tags: Optional[Dict[str, str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        client = client or APIClient(api_key=api_key, base_url=base_url)
        params: Dict[str, Any] = {}
        if state:
            params["state"] = state
        if template_id:
            params["template_id"] = template_id
        if name:
            params["name"] = name
        if sandbox_type:
            params["sandbox_type"] = sandbox_type
        if is_desktop is not None:
            params["is_desktop"] = is_desktop
        if tags:
            for key, value in tags.items():
                params[f"tags[{key}]"] = value
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        return client.get("sandboxes", params=params)

    def refresh(self) -> Dict[str, Any]:
        self._data = self._client.get(f"sandboxes/{self._id}")
        return self._data

    def close(self) -> None:
        self._client.delete(f"sandboxes/{self._id}")

    def extend_timeout(self, timeout: int) -> Dict[str, Any]:
        return self._client.post(
            f"sandboxes/{self._id}/timeout",
            json={"timeout": timeout},
        )

    def set_timeout(self, timeout: int) -> Dict[str, Any]:
        """Reset the sandbox timeout from now. Alias for extend_timeout().

        This mirrors E2B's set_timeout() pattern: the timeout is reset
        to the specified number of seconds from the current time.

        Args:
            timeout: New timeout in seconds from now.
        """
        return self.extend_timeout(timeout)

    def pause(self) -> Dict[str, Any]:
        return self._client.post(f"sandboxes/{self._id}/pause")

    def resume(self, timeout: int) -> Dict[str, Any]:
        return self._client.post(
            f"sandboxes/{self._id}/resume",
            json={"timeout": timeout},
        )

    def get_host(self, port: int) -> Dict[str, Any]:
        return self._client.get(f"sandboxes/{self._id}/host/{port}")

    def get_env(self) -> Dict[str, Any]:
        return self._client.get(f"sandboxes/{self._id}/env")

    def connect(self) -> Dict[str, Any]:
        return self._client.post(f"sandboxes/{self._id}/connect")

    def run_code(
        self,
        code: str,
        *,
        language: str,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload = {"code": code, "language": language}
        if timeout is not None:
            payload["timeout"] = timeout
        return self._client.post(
            f"sandboxes/{self._id}/run",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    def execute_command(
        self,
        command: str,
        *,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        timeout: Optional[int] = None,
        background: bool = False,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"command": command}
        if args is not None:
            payload["args"] = args
        if env is not None:
            payload["env"] = env
        if working_dir is not None:
            payload["working_dir"] = working_dir
        if timeout is not None:
            payload["timeout"] = timeout
        if background:
            payload["background"] = True
        return self._client.post(
            f"sandboxes/{self._id}/commands",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    def read_file(
        self,
        path: str,
        *,
        file_type: str = "file",
    ) -> Dict[str, Any]:
        clean_path = path.lstrip("/")
        encoded_path = APIClient.encode_file_path(clean_path)
        return self._client.get(
            f"sandboxes/{self._id}/files/{encoded_path}",
            params={"type": file_type},
            timeout=self._client.timeout_config.file_download,
        )

    def write_file(
        self,
        path: str,
        content: str,
        *,
        encoding: Optional[str] = None,
    ) -> Dict[str, Any]:
        clean_path = path.lstrip("/")
        encoded_path = APIClient.encode_file_path(clean_path)
        payload: Dict[str, Any] = {"content": content}
        if encoding:
            payload["encoding"] = encoding
        return self._client.put(
            f"sandboxes/{self._id}/files/{encoded_path}",
            json=payload,
            timeout=self._client.timeout_config.file_upload,
        )

    def metrics(self) -> Dict[str, Any]:
        return self._client.get(f"sandboxes/{self._id}/metrics")

    def metrics_history(
        self,
        *,
        start: Optional[str] = None,
        end: Optional[str] = None,
        interval: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if interval:
            params["interval"] = interval
        return self._client.get(
            f"sandboxes/{self._id}/metrics/history",
            params=params,
        )

    # -------------------------------------------------------------------------
    # Streaming API (WebSocket-based)
    # -------------------------------------------------------------------------

    def process_stream(self) -> ProcessStream:
        """Create a ProcessStream for real-time process I/O.
        
        Returns a WebSocket client for streaming stdin/stdout/stderr
        with processes running in this sandbox.
        
        Returns:
            ProcessStream instance for streaming process I/O.
        
        Example:
            >>> with sandbox.process_stream() as stream:
            ...     stream.on_stdout(lambda data: print(data, end=""))
            ...     stream.on_exit(lambda code: print(f"Exit: {code}"))
            ...     stream.start_process("python", ["-c", "print('Hello')"])
            ...     stream.wait_for_exit()
        """
        return ProcessStream(self._id, self._client)

    def file_watcher(self) -> FileWatcher:
        """Create a FileWatcher for monitoring file changes.
        
        Returns a WebSocket client for watching file create/modify/delete
        events in this sandbox.
        
        Returns:
            FileWatcher instance for watching file changes.
        
        Example:
            >>> with sandbox.file_watcher() as watcher:
            ...     watcher.watch("/workspace", lambda event, path: print(f"{event}: {path}"))
            ...     time.sleep(60)  # Watch for changes
        """
        return FileWatcher(self._id, self._client)

    def execute_streaming(
        self,
        command: str,
        *,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        tty: bool = False,
        on_stdout: Optional[Callable[[str], None]] = None,
        on_stderr: Optional[Callable[[str], None]] = None,
        on_exit: Optional[Callable[[int], None]] = None,
        timeout: Optional[float] = None,
    ) -> int:
        """Execute a command with real-time streaming output.
        
        This is a convenience method that creates a ProcessStream,
        executes the command, and waits for completion while streaming
        output through the provided callbacks.
        
        Args:
            command: The command to execute.
            args: Command arguments.
            env: Environment variables.
            working_dir: Working directory for the process.
            tty: Whether to allocate a PTY.
            on_stdout: Callback for stdout data.
            on_stderr: Callback for stderr data.
            on_exit: Callback when process exits.
            timeout: Maximum time to wait for process (seconds).
        
        Returns:
            The process exit code.
        
        Example:
            >>> exit_code = sandbox.execute_streaming(
            ...     "python",
            ...     args=["-c", "import time; print('start'); time.sleep(1); print('done')"],
            ...     on_stdout=lambda s: print(s, end=""),
            ...     timeout=30,
            ... )
        """
        with ProcessStream(self._id, self._client) as stream:
            if on_stdout:
                stream.on_stdout(on_stdout)
            if on_stderr:
                stream.on_stderr(on_stderr)
            if on_exit:
                stream.on_exit(on_exit)
            
            stream.start_process(
                command,
                args=args,
                env=env,
                working_dir=working_dir,
                tty=tty,
            )
            
            exit_code = stream.wait_for_exit(timeout=timeout)
            return exit_code if exit_code is not None else -1
