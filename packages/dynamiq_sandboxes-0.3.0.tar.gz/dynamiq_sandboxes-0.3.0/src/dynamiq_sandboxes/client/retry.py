from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Iterable, Tuple, Type

import httpx


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""

    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 30.0
    exponential_base: float = 2.0
    jitter: bool = True
    retryable_status_codes: Tuple[int, ...] = (429, 500, 502, 503, 504)
    retryable_exceptions: Tuple[Type[BaseException], ...] = (
        httpx.RequestError,
        httpx.TimeoutException,
    )


DEFAULT_RETRY_CONFIG = RetryConfig()


def calculate_delay(attempt: int, config: RetryConfig) -> float:
    """Calculate delay with exponential backoff and optional jitter."""
    delay = config.base_delay * (config.exponential_base ** attempt)
    delay = min(delay, config.max_delay)
    if config.jitter:
        delay += delay * random.uniform(0, 0.25)
    return delay


def is_retryable_error(error: BaseException, config: RetryConfig) -> bool:
    """Check if an exception should be retried."""
    return isinstance(error, config.retryable_exceptions)


def is_retryable_status(status_code: int, config: RetryConfig) -> bool:
    """Check if a status code should be retried."""
    return status_code in config.retryable_status_codes


def sleep_with_backoff(attempt: int, config: RetryConfig) -> None:
    """Sleep for a backoff delay."""
    time.sleep(calculate_delay(attempt, config))
