from __future__ import annotations

import os
from typing import Any, Dict, Optional
from urllib.parse import quote

import httpx

from ..exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
)
from .retry import (
    DEFAULT_RETRY_CONFIG,
    RetryConfig,
    is_retryable_error,
    is_retryable_status,
    sleep_with_backoff,
)
from .timeout import DEFAULT_TIMEOUT_CONFIG, TimeoutConfig


class APIClient:
    """HTTP client with retries and timeouts."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        bearer_token: Optional[str] = None,
        base_url: Optional[str] = None,
        retry_config: Optional[RetryConfig] = None,
        timeout_config: Optional[TimeoutConfig] = None,
        headers: Optional[Dict[str, str]] = None,
        verify: Optional[bool] = None,
    ) -> None:
        # Support DYNAMIQ_API_URL environment variable (with fallbacks)
        base_url = (
            base_url 
            or os.environ.get("DYNAMIQ_API_URL")
            or os.environ.get("DYNAMIQ_BASE_URL")
            or os.environ.get("PLATFORM_BASE_URL")
            or "https://api.sandboxes.getdynamiq.ai/v1"
        )
        
        # Support DYNAMIQ_VERIFY_SSL environment variable (default: false)
        if verify is None:
            verify_env = os.environ.get("DYNAMIQ_VERIFY_SSL", os.environ.get("PLATFORM_VERIFY_SSL", "false")).lower()
            verify = verify_env in ("true", "1", "yes")
        
        api_key = api_key or os.environ.get("DYNAMIQ_API_KEY") or os.environ.get("PLATFORM_API_KEY")
        bearer_token = bearer_token or os.environ.get("DYNAMIQ_BEARER_TOKEN") or os.environ.get("PLATFORM_BEARER_TOKEN")
        if not api_key and not bearer_token:
            raise AuthenticationError("API key or bearer token required. Set DYNAMIQ_API_KEY environment variable.")

        self._retry_config = retry_config or DEFAULT_RETRY_CONFIG
        self._timeout_config = timeout_config or DEFAULT_TIMEOUT_CONFIG
        self._base_url = base_url.rstrip("/")

        merged_headers = {
            "User-Agent": "dynamiq-sandboxes-python/0.1.0",
        }
        if api_key:
            merged_headers["X-API-Key"] = api_key
        if bearer_token:
            merged_headers["Authorization"] = f"Bearer {bearer_token}"
        if headers:
            merged_headers.update(headers)

        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=self._timeout_config.to_httpx_timeout(),
            headers=merged_headers,
            verify=verify,
        )

    @property
    def timeout_config(self) -> TimeoutConfig:
        return self._timeout_config

    @property
    def retry_config(self) -> RetryConfig:
        return self._retry_config

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        normalized_path = path.lstrip("/")
        last_error: Optional[BaseException] = None

        for attempt in range(self._retry_config.max_attempts):
            try:
                response = self._client.request(
                    method,
                    normalized_path,
                    params=params,
                    json=json,
                    timeout=timeout,
                    headers=headers,
                )

                if response.status_code >= 400:
                    if is_retryable_status(response.status_code, self._retry_config) and (
                        attempt < self._retry_config.max_attempts - 1
                    ):
                        response.read()
                        sleep_with_backoff(attempt, self._retry_config)
                        continue
                    self._raise_for_error(response)

                if response.status_code == 204:
                    return None

                # Always try JSON first -- some proxy responses may
                # not set Content-Type: application/json correctly
                try:
                    return response.json()
                except Exception:
                    return response.text
            except httpx.TimeoutException as exc:
                last_error = exc
                if attempt < self._retry_config.max_attempts - 1:
                    sleep_with_backoff(attempt, self._retry_config)
                    continue
                raise TimeoutError("Request timed out") from exc
            except BaseException as exc:
                last_error = exc
                if is_retryable_error(exc, self._retry_config) and (
                    attempt < self._retry_config.max_attempts - 1
                ):
                    sleep_with_backoff(attempt, self._retry_config)
                    continue
                raise

        if last_error:
            raise last_error
        raise APIError("Request failed without response")

    def get(self, path: str, *, params: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None) -> Any:
        return self.request("GET", path, params=params, timeout=timeout)

    def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        return self.request("POST", path, params=params, json=json, timeout=timeout)

    def put(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        return self.request("PUT", path, params=params, json=json, timeout=timeout)

    def delete(self, path: str, *, timeout: Optional[float] = None) -> Any:
        return self.request("DELETE", path, timeout=timeout)

    @staticmethod
    def encode_path(path: str) -> str:
        """URL-encode a path parameter while preserving slashes."""
        return quote(path, safe="/")

    @staticmethod
    def encode_file_path(path: str) -> str:
        """URL-encode a file path for use in URL path segments.
        
        Preserves forward slashes so the path routes correctly through
        the API server's wildcard handler (chi router's * pattern).
        Special characters in file/directory names are percent-encoded.
        """
        return quote(path, safe="/")

    def _raise_for_error(self, response: httpx.Response) -> None:
        status = response.status_code
        error_code = None
        request_id = None
        message = f"Request failed with status {status}"

        try:
            payload = response.json()
            if isinstance(payload, dict):
                err = payload.get("error", {})
                if isinstance(err, dict):
                    error_code = err.get("code")
                    request_id = err.get("request_id")
                    message = err.get("message", message)
                elif isinstance(err, str):
                    # Agent returns {"error": "NAVIGATION_FAILED", "message": "..."}
                    error_code = err
                    message = payload.get("message", message)
        except (ValueError, AttributeError):
            pass

        error_cls: type[APIError] = APIError
        if status == 401 or status == 403:
            error_cls = AuthenticationError
        elif status == 404:
            error_cls = NotFoundError
        elif status == 409:
            error_cls = ConflictError
        elif status == 429:
            error_cls = RateLimitError

        raise error_cls(message, status_code=status, error_code=error_code, request_id=request_id)
