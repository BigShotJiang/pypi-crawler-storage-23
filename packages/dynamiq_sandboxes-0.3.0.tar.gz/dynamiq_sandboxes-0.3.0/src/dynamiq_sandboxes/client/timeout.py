from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass
class TimeoutConfig:
    """Timeout configuration for SDK operations."""

    connect: float = 10.0
    read: float = 30.0
    write: float = 30.0
    pool: float = 10.0

    create_sandbox: float = 60.0
    process_execution: float = 300.0
    file_upload: float = 120.0
    file_download: float = 120.0
    stream_connect: float = 30.0

    def to_httpx_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(
            connect=self.connect,
            read=self.read,
            write=self.write,
            pool=self.pool,
        )


DEFAULT_TIMEOUT_CONFIG = TimeoutConfig()
