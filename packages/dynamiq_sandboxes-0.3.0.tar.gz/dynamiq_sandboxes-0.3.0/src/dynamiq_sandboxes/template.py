from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from .client import APIClient


@dataclass
class TemplateInfo:
    """Information about a template."""

    template_id: str
    name: str
    status: str
    is_public: bool = False
    description: str = ""
    base_image: str = ""
    created_at: Optional[str] = None
    ready_at: Optional[str] = None

    @classmethod
    def from_response(cls, data: Dict[str, Any]) -> "TemplateInfo":
        return cls(
            template_id=data.get("id", data.get("template_id", "")),
            name=data.get("name", data.get("alias", "")),
            status=data.get("status", data.get("phase", "")),
            is_public=data.get("isPublic", data.get("is_public", False)),
            description=data.get("description", ""),
            base_image=data.get("baseImage", data.get("base_image", "")),
            created_at=data.get("createdAt", data.get("created_at")),
            ready_at=data.get("readyAt", data.get("ready_at")),
        )


class TemplateBuilder:
    """Fluent builder for constructing template definitions.

    Mirrors E2B's Template builder pattern for ergonomic template creation.

    Example::

        template = (
            TemplateBuilder()
            .from_base_image("python:3.11-slim")
            .set_envs({"LANG": "C.UTF-8"})
            .run_cmd("pip install numpy pandas")
            .set_start_cmd("python -m http.server 8080")
        )
        info = template.build("my-template", api_key="...")
    """

    def __init__(self) -> None:
        self._base_image: str = ""
        self._dockerfile: Optional[str] = None
        self._envs: Dict[str, str] = {}
        self._setup_commands: List[str] = []
        self._copy_entries: List[tuple] = []
        self._start_cmd: Optional[str] = None
        self._description: str = ""
        self._is_public: bool = False

    def from_base_image(
        self, image: str = "ubuntu:22.04",
    ) -> "TemplateBuilder":
        """Set the base Docker image for the template."""
        self._base_image = image
        return self

    def from_dockerfile(
        self, dockerfile: str,
    ) -> "TemplateBuilder":
        """Set a custom Dockerfile for the template."""
        self._dockerfile = dockerfile
        return self

    def set_envs(self, envs: Dict[str, str]) -> "TemplateBuilder":
        """Set environment variables available inside the sandbox."""
        self._envs.update(envs)
        return self

    def run_cmd(self, command: str) -> "TemplateBuilder":
        """Add a setup command to run during template build."""
        self._setup_commands.append(command)
        return self

    def copy_files(self, entries: List[tuple]) -> "TemplateBuilder":
        """Add files to copy into the template. Each entry is (src, dst)."""
        self._copy_entries.extend(entries)
        return self

    def set_start_cmd(self, command: str) -> "TemplateBuilder":
        """Set the command that runs on sandbox startup."""
        self._start_cmd = command
        return self

    def set_description(self, description: str) -> "TemplateBuilder":
        """Set a human-readable description for the template."""
        self._description = description
        return self

    def set_public(self, is_public: bool = True) -> "TemplateBuilder":
        """Make the template publicly available."""
        self._is_public = is_public
        return self

    def to_dockerfile(self) -> str:
        """Convert the builder configuration to a Dockerfile string."""
        if self._dockerfile:
            return self._dockerfile

        lines = [f"FROM {self._base_image or 'ubuntu:22.04'}"]

        for key, value in self._envs.items():
            lines.append(f"ENV {key}={value}")

        for src, dst in self._copy_entries:
            lines.append(f"COPY {src} {dst}")

        for cmd in self._setup_commands:
            lines.append(f"RUN {cmd}")

        if self._start_cmd:
            lines.append(f'CMD ["/bin/bash", "-c", "{self._start_cmd}"]')

        return "\n".join(lines)

    def build(
        self,
        name: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        on_build_logs: Optional[Callable[[str], None]] = None,
    ) -> TemplateInfo:
        """Build the template and return its info.

        Args:
            name: Unique name/tag for the template.
            client: Optional pre-configured APIClient.
            api_key: API key (alternative to client).
            base_url: API base URL (alternative to client).
            on_build_logs: Optional callback for build log lines.

        Returns:
            TemplateInfo with the template's ID, status, etc.
        """
        client = client or APIClient(api_key=api_key, base_url=base_url)

        payload: Dict[str, Any] = {
            "name": name,
            "baseImage": self._base_image or "ubuntu:22.04",
        }

        dockerfile = self.to_dockerfile()
        if dockerfile:
            payload["dockerfile"] = dockerfile

        if self._setup_commands:
            payload["setupCommands"] = self._setup_commands
        if self._description:
            payload["description"] = self._description

        response = client.post("templates", json=payload, timeout=120.0)
        return TemplateInfo.from_response(response)


class Template:
    """Static methods for template management.

    Example:
        >>> templates = Template.list(api_key="...")
        >>> for t in templates:
        ...     print(f"{t.name}: {t.status}")
        >>>
        >>> info = Template.get("my-template", api_key="...")
        >>> Template.delete("my-template", api_key="...")
    """

    @staticmethod
    def list(
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> List[TemplateInfo]:
        """List all available templates."""
        client = client or APIClient(api_key=api_key, base_url=base_url)
        response = client.get("templates")
        if isinstance(response, list):
            data = response
        else:
            data = response.get(
                "data", response.get("templates", []),
            )
        return [TemplateInfo.from_response(t) for t in data]

    @staticmethod
    def get(
        template_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> TemplateInfo:
        """Get a specific template by ID or name."""
        client = client or APIClient(api_key=api_key, base_url=base_url)
        response = client.get(f"templates/{template_id}")
        return TemplateInfo.from_response(response)

    @staticmethod
    def delete(
        template_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        """Delete a template."""
        client = client or APIClient(api_key=api_key, base_url=base_url)
        client.delete(f"templates/{template_id}")

    @staticmethod
    def build_status(
        template_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Check the build status of a template."""
        client = client or APIClient(api_key=api_key, base_url=base_url)
        return client.get(f"templates/{template_id}/status")
