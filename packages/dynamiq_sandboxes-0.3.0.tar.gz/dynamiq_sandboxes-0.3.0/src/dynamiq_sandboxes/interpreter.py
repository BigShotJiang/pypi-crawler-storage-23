"""Stateful code interpreter that maintains variables between executions.

Unlike sandbox.run_code() which starts a fresh process each time,
CodeInterpreter keeps a REPL running so variables persist across calls.
"""

from __future__ import annotations

import base64
import json
import threading
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .exceptions import PlatformSDKError

if TYPE_CHECKING:
    from .sandbox import Sandbox

try:
    import websocket
    HAS_WEBSOCKET = True
except ImportError:
    websocket = None  # type: ignore
    HAS_WEBSOCKET = False


class InterpreterError(PlatformSDKError):
    """Error during interpreter operation."""


@dataclass
class InterpreterResult:
    """Result of a code execution in the interpreter.
    
    Attributes:
        output: The captured stdout/output from the code execution.
        error: Any error message or stderr output, or None if no error.
        execution_time_ms: Time taken to execute the code in milliseconds.
    """
    output: str
    error: Optional[str]
    execution_time_ms: int
    
    @property
    def success(self) -> bool:
        """Whether the execution was successful (no error)."""
        return self.error is None or self.error == ""


class CodeInterpreter:
    """Stateful code interpreter that maintains variables between executions.
    
    Unlike sandbox.run_code() which starts a fresh process each time,
    CodeInterpreter keeps a REPL running so variables persist.
    
    Supports Python and JavaScript/Node.js interpreters.
    
    Example:
        >>> interp = CodeInterpreter(sandbox, language="python")
        >>> interp.start()
        >>> interp.run("x = 5")
        >>> interp.run("y = 10")
        >>> result = interp.run("print(x + y)")  # prints 15
        >>> interp.stop()
        
        # Or use as context manager:
        >>> with sandbox.code_interpreter(language="python") as interp:
        ...     interp.run("x = 5")
        ...     result = interp.run("print(x + 2)")  # prints 7
    """
    
    # Unique markers for detecting output boundaries
    _START_MARKER = "__INTERP_START_9a8b7c6d__"
    _END_MARKER = "__INTERP_END_9a8b7c6d__"
    _ERROR_MARKER = "__INTERP_ERROR_9a8b7c6d__"
    
    # Language configurations
    _LANGUAGE_CONFIG: Dict[str, Dict[str, Any]] = {
        "python": {
            "command": "python3",
            "args": ["-u", "-i"],  # -u for unbuffered, -i for interactive
            "env": {
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONUNBUFFERED": "1",
            },
            # Python code to wrap execution with markers
            "wrapper_template": '''
import sys as __sys
import traceback as __tb
__output_buffer = []
__original_stdout = __sys.stdout
__original_stderr = __sys.stderr

class __CaptureStream:
    def __init__(self):
        self.data = []
    def write(self, s):
        self.data.append(s)
        __original_stdout.write(s)
    def flush(self):
        __original_stdout.flush()
    def getvalue(self):
        return "".join(self.data)

try:
    print("{start_marker}")
    __capture = __CaptureStream()
    __sys.stdout = __capture
    __sys.stderr = __capture
    try:
        __result = None
        exec("""{code}""")
    except Exception as __e:
        print("{error_marker}" + str(__e))
        __tb.print_exc()
    finally:
        __sys.stdout = __original_stdout
        __sys.stderr = __original_stderr
    print("{end_marker}")
except Exception as __outer_e:
    print("{error_marker}" + str(__outer_e))
    print("{end_marker}")
''',
            # Simpler single-expression eval for REPL-like behavior
            "eval_template": '''
try:
    print("{start_marker}")
    __result = eval("""{code}""")
    if __result is not None:
        print(repr(__result))
    print("{end_marker}")
except SyntaxError:
    try:
        exec("""{code}""")
        print("{end_marker}")
    except Exception as __e:
        print("{error_marker}" + str(__e))
        print("{end_marker}")
except Exception as __e:
    print("{error_marker}" + str(__e))
    print("{end_marker}")
''',
            # Simple exec that handles both expressions and statements
            "simple_template": '''
print("{start_marker}")
try:
    __code = """{code}"""
    try:
        __result = eval(__code)
        if __result is not None:
            print(repr(__result))
    except SyntaxError:
        exec(__code)
except Exception as __e:
    import traceback
    print("{error_marker}" + str(__e))
print("{end_marker}")
''',
        },
        "javascript": {
            "command": "node",
            "args": ["-i"],
            "env": {},
            "wrapper_template": '''
console.log("{start_marker}");
try {{
    {code}
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
            "eval_template": '''
console.log("{start_marker}");
try {{
    const __result = eval(`{code}`);
    if (__result !== undefined) console.log(__result);
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
            "simple_template": '''
console.log("{start_marker}");
try {{
    const __result = eval(`{code}`);
    if (__result !== undefined) console.log(__result);
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
        },
        "node": {
            # Alias for javascript
            "command": "node",
            "args": ["-i"],
            "env": {},
            "wrapper_template": '''
console.log("{start_marker}");
try {{
    {code}
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
            "eval_template": '''
console.log("{start_marker}");
try {{
    const __result = eval(`{code}`);
    if (__result !== undefined) console.log(__result);
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
            "simple_template": '''
console.log("{start_marker}");
try {{
    const __result = eval(`{code}`);
    if (__result !== undefined) console.log(__result);
}} catch (e) {{
    console.log("{error_marker}" + e.message);
}}
console.log("{end_marker}");
''',
        },
    }
    
    def __init__(
        self,
        sandbox: "Sandbox",
        language: str = "python",
        *,
        working_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize the code interpreter.
        
        Args:
            sandbox: The Sandbox instance to run code in.
            language: Programming language ("python", "javascript", or "node").
            working_dir: Working directory for the interpreter process.
            env: Additional environment variables.
        
        Raises:
            ValueError: If the language is not supported.
            ImportError: If websocket-client is not installed.
        """
        if not HAS_WEBSOCKET:
            raise ImportError(
                "websocket-client is required for CodeInterpreter. "
                "Install it with: pip install websocket-client"
            )
        
        language = language.lower()
        if language not in self._LANGUAGE_CONFIG:
            supported = ", ".join(self._LANGUAGE_CONFIG.keys())
            raise ValueError(
                f"Unsupported language: {language}. "
                f"Supported languages: {supported}"
            )
        
        self._sandbox = sandbox
        self._language = language
        self._working_dir = working_dir
        self._env = env or {}
        self._config = self._LANGUAGE_CONFIG[language]
        
        # WebSocket connection state
        self._ws: Optional[Any] = None
        self._connected = False
        self._started = False
        self._pid: Optional[int] = None
        
        # Output collection
        self._output_buffer: List[str] = []
        self._output_lock = threading.Lock()
        self._output_event = threading.Event()
        
        # Reader thread
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
    
    @property
    def language(self) -> str:
        """The interpreter language."""
        return self._language
    
    @property
    def is_running(self) -> bool:
        """Whether the interpreter is currently running."""
        return self._started and self._connected
    
    @property
    def pid(self) -> Optional[int]:
        """Process ID of the interpreter, if running."""
        return self._pid
    
    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for process streaming."""
        client = self._sandbox._client
        base_url = client._base_url
        
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url
        
        url = f"{ws_base}/sandboxes/{self._sandbox.id}/process/stream"
        
        # Add API key as query parameter
        headers = client._client.headers
        api_key = headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"
        
        return url
    
    def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise InterpreterError("Interpreter not connected")
        
        self._ws.send(json.dumps(msg))
    
    def _send_stdin(self, data: str) -> None:
        """Send data to the interpreter's stdin."""
        encoded = base64.b64encode(data.encode("utf-8")).decode("ascii")
        self._send_message({
            "type": "stdin",
            "data": encoded,
        })
    
    def _read_loop(self) -> None:
        """Background thread that reads messages from the WebSocket."""
        while not self._stop_event.is_set() and self._ws:
            try:
                self._ws.settimeout(0.5)
                data = self._ws.recv()
                
                if not data:
                    continue
                
                msg = json.loads(data)
                self._handle_message(msg)
                
            except websocket.WebSocketTimeoutException:
                continue
            except websocket.WebSocketConnectionClosedException:
                self._connected = False
                self._started = False
                break
            except Exception:
                break
    
    def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming WebSocket message."""
        msg_type = msg.get("type")
        
        if msg_type == "started":
            self._pid = msg.get("pid")
            self._started = True
        
        elif msg_type in ("stdout", "stderr"):
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            
            with self._output_lock:
                self._output_buffer.append(data)
                # Check if we have the end marker
                combined = "".join(self._output_buffer)
                if self._END_MARKER in combined:
                    self._output_event.set()
        
        elif msg_type == "exit":
            self._started = False
            self._output_event.set()  # Unblock any waiting
    
    def start(self) -> None:
        """Start the interpreter REPL process.
        
        Raises:
            InterpreterError: If already started or connection fails.
        """
        if self._started:
            raise InterpreterError("Interpreter already started")
        
        try:
            url = self._get_ws_url()
            self._ws = websocket.create_connection(
                url,
                timeout=30,
                skip_utf8_validation=True,
            )
            self._connected = True
            self._stop_event.clear()
            
            # Start reader thread
            self._reader_thread = threading.Thread(
                target=self._read_loop,
                daemon=True,
            )
            self._reader_thread.start()
            
            # Merge environment variables
            env = {**self._config.get("env", {}), **self._env}
            
            # Send start message to launch the interpreter
            start_msg: Dict[str, Any] = {
                "type": "start",
                "command": self._config["command"],
                "args": self._config["args"],
            }
            if env:
                start_msg["env"] = env
            if self._working_dir:
                start_msg["working_dir"] = self._working_dir
            
            self._send_message(start_msg)
            
            # Wait for the process to start
            timeout = 10.0
            start_time = time.time()
            while not self._started and (time.time() - start_time) < timeout:
                time.sleep(0.1)
            
            if not self._started:
                self.stop()
                raise InterpreterError("Timeout waiting for interpreter to start")
            
            # Give the REPL a moment to initialize
            time.sleep(0.3)
            
            # Clear any startup output
            with self._output_lock:
                self._output_buffer.clear()
                self._output_event.clear()
            
        except InterpreterError:
            raise
        except Exception as e:
            self._connected = False
            self._started = False
            raise InterpreterError(f"Failed to start interpreter: {e}") from e
    
    def run(
        self,
        code: str,
        timeout: float = 30.0,
    ) -> InterpreterResult:
        """Execute code in the interpreter and return the result.
        
        Variables and state persist between calls to run().
        
        Args:
            code: The code to execute.
            timeout: Maximum time to wait for execution in seconds.
        
        Returns:
            InterpreterResult with output, error, and execution time.
        
        Raises:
            InterpreterError: If interpreter is not running or execution fails.
        """
        if not self._started:
            raise InterpreterError(
                "Interpreter not started. Call start() first."
            )
        
        start_time = time.time()
        
        # Clear output buffer
        with self._output_lock:
            self._output_buffer.clear()
            self._output_event.clear()
        
        # Prepare the code with markers
        # Escape the code for embedding in the template
        if self._language == "python":
            # Escape triple quotes in the code
            escaped_code = code.replace('"""', '\\"\\"\\"')
        else:
            # For JavaScript, escape backticks
            escaped_code = code.replace('`', '\\`').replace('$', '\\$')
        
        # Use the simple template for cleaner execution
        template = self._config["simple_template"]
        wrapped_code = template.format(
            code=escaped_code,
            start_marker=self._START_MARKER,
            end_marker=self._END_MARKER,
            error_marker=self._ERROR_MARKER,
        )
        
        # Send the code to stdin
        self._send_stdin(wrapped_code + "\n")
        
        # Wait for execution to complete (end marker)
        deadline = start_time + timeout
        while time.time() < deadline:
            if self._output_event.wait(timeout=0.1):
                break
            if not self._started:
                raise InterpreterError("Interpreter process terminated")
        
        execution_time_ms = int((time.time() - start_time) * 1000)
        
        # Collect output
        with self._output_lock:
            raw_output = "".join(self._output_buffer)
        
        # Parse output
        output, error = self._parse_output(raw_output)
        
        return InterpreterResult(
            output=output,
            error=error if error else None,
            execution_time_ms=execution_time_ms,
        )
    
    def _parse_output(self, raw_output: str) -> tuple:
        """Parse the raw output to extract the actual output and any errors.
        
        Returns:
            Tuple of (output, error)
        """
        output = ""
        error = None
        
        # Find content between markers
        start_idx = raw_output.find(self._START_MARKER)
        end_idx = raw_output.find(self._END_MARKER)
        
        if start_idx != -1 and end_idx != -1:
            # Extract content between markers
            content = raw_output[start_idx + len(self._START_MARKER):end_idx]
            
            # Check for error marker
            error_idx = content.find(self._ERROR_MARKER)
            if error_idx != -1:
                output = content[:error_idx].strip()
                error = content[error_idx + len(self._ERROR_MARKER):].strip()
            else:
                output = content.strip()
        else:
            # No markers found, return raw output
            # Clean up REPL prompts
            lines = raw_output.split('\n')
            cleaned_lines = []
            for line in lines:
                # Skip Python prompts and Node prompts
                stripped = line.lstrip()
                if stripped.startswith('>>> ') or stripped.startswith('... '):
                    line = stripped[4:]
                elif stripped.startswith('> '):
                    line = stripped[2:]
                cleaned_lines.append(line)
            output = '\n'.join(cleaned_lines).strip()
        
        # Clean up the output
        # Remove echo of the wrapped code if present
        if self._START_MARKER in output:
            output = output.split(self._START_MARKER)[-1]
        
        # Clean up common REPL artifacts
        output = self._clean_repl_output(output)
        
        return output, error
    
    def _clean_repl_output(self, output: str) -> str:
        """Clean up REPL-specific artifacts from output."""
        lines = []
        for line in output.split('\n'):
            # Skip empty lines that are just prompts
            stripped = line.strip()
            if stripped in ('>>>', '>', '...', ''):
                continue
            # Remove prompt prefixes
            if line.startswith('>>> '):
                line = line[4:]
            elif line.startswith('... '):
                line = line[4:]
            elif line.startswith('> '):
                line = line[2:]
            lines.append(line)
        
        return '\n'.join(lines).strip()
    
    def reset(self) -> None:
        """Reset the interpreter state by restarting the REPL.
        
        This clears all variables and imports.
        """
        self.stop()
        self.start()
    
    def stop(self) -> None:
        """Stop the interpreter and clean up resources."""
        self._stop_event.set()
        self._started = False
        
        if self._ws:
            try:
                # Try to kill the process gracefully
                self._send_message({
                    "type": "signal",
                    "signal": 15,  # SIGTERM
                })
            except Exception:
                pass
            
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        
        self._connected = False
        
        # Wait for reader thread to finish
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
        
        # Clear state
        with self._output_lock:
            self._output_buffer.clear()
        self._pid = None
    
    def __enter__(self) -> "CodeInterpreter":
        """Context manager entry - starts the interpreter."""
        self.start()
        return self
    
    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Context manager exit - stops the interpreter."""
        self.stop()


def create_code_interpreter(
    sandbox: "Sandbox",
    language: str = "python",
    **kwargs,
) -> CodeInterpreter:
    """Factory function to create a CodeInterpreter.
    
    Args:
        sandbox: The Sandbox instance.
        language: Programming language ("python", "javascript", or "node").
        **kwargs: Additional arguments passed to CodeInterpreter.
    
    Returns:
        A new CodeInterpreter instance.
    """
    return CodeInterpreter(sandbox, language=language, **kwargs)
