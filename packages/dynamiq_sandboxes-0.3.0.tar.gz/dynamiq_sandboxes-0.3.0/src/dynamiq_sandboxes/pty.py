"""Interactive pseudo-terminal (PTY) support for sandbox sessions.

Provides a PTY API for interactive terminal sessions
using WebSocket connections.
"""

from __future__ import annotations

import base64
import json
import re
import threading
import time
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

try:
    import websocket
except ImportError:
    websocket = None  # type: ignore

from .exceptions import PlatformSDKError

if TYPE_CHECKING:
    from .client import APIClient


class PTYError(PlatformSDKError):
    """PTY-specific error."""


class PTY:
    """Interactive pseudo-terminal session in a sandbox.
    
    Provides a PTY interface for interactive terminal sessions.
    Supports real-time input/output, terminal resizing, and pattern matching.
    
    Example:
        >>> with sandbox.pty.create() as pty:
        ...     pty.send_line("echo Hello World")
        ...     output = pty.wait_for("Hello World", timeout=5)
        ...     print(output)
        
        >>> # With callback-based output
        >>> pty = sandbox.pty.create()
        >>> pty.on_data(lambda data: print(data, end=""))
        >>> pty.connect()
        >>> pty.send_line("ls -la")
        >>> time.sleep(2)
        >>> pty.disconnect()
    """
    
    def __init__(
        self,
        sandbox_id: str,
        client: "APIClient",
        rows: int = 24,
        cols: int = 80,
        shell: str = "/bin/bash",
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
    ) -> None:
        """Initialize PTY session.
        
        Args:
            sandbox_id: The sandbox ID to connect to.
            client: The API client with authentication credentials.
            rows: Terminal height in rows (default: 24).
            cols: Terminal width in columns (default: 80).
            shell: Shell to use (default: /bin/bash).
            env: Environment variables for the shell.
            working_dir: Working directory for the shell.
        """
        if websocket is None:
            raise ImportError(
                "websocket-client is required for PTY. "
                "Install it with: pip install websocket-client"
            )
        
        self._sandbox_id = sandbox_id
        self._client = client
        self._rows = rows
        self._cols = cols
        self._shell = shell
        self._env = env
        self._working_dir = working_dir
        
        self._ws: Optional[websocket.WebSocket] = None
        self._connected = False
        self._pid: Optional[int] = None
        self._exit_code: Optional[int] = None
        
        # Output buffer for read/wait_for operations
        self._buffer: List[str] = []
        self._buffer_lock = threading.Lock()
        
        # Callbacks
        self._on_data: Optional[Callable[[str], None]] = None
        self._on_exit: Optional[Callable[[int], None]] = None
        self._on_error: Optional[Callable[[str], None]] = None
        
        # Reader thread
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._send_lock = threading.Lock()
    
    @property
    def connected(self) -> bool:
        """Whether the PTY is connected."""
        return self._connected
    
    @property
    def pid(self) -> Optional[int]:
        """The shell process ID, if connected."""
        return self._pid
    
    @property
    def exit_code(self) -> Optional[int]:
        """The shell exit code, if the shell has exited."""
        return self._exit_code
    
    @property
    def rows(self) -> int:
        """Current terminal height."""
        return self._rows
    
    @property
    def cols(self) -> int:
        """Current terminal width."""
        return self._cols
    
    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for PTY streaming."""
        base_url = self._client._base_url
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url
        
        url = f"{ws_base}/sandboxes/{self._sandbox_id}/process/stream"
        
        # Add API key as query parameter for WebSocket auth
        headers = self._client._client.headers
        api_key = headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"
        
        return url
    
    def connect(self) -> None:
        """Connect to the PTY WebSocket and start the shell.
        
        Raises:
            PTYError: If connection fails or shell fails to start.
        """
        if self._connected:
            return
        
        try:
            url = self._get_ws_url()
            self._ws = websocket.create_connection(
                url,
                timeout=30,
                skip_utf8_validation=True,
            )
            self._connected = True
            self._stop_event.clear()
            
            # Start reader thread before starting the process
            self._reader_thread = threading.Thread(
                target=self._read_loop,
                daemon=True,
            )
            self._reader_thread.start()
            
            # Start the shell with PTY
            self._start_shell()
            
        except Exception as e:
            self._connected = False
            if self._ws:
                try:
                    self._ws.close()
                except Exception:
                    pass
                self._ws = None
            raise PTYError(f"Failed to connect PTY: {e}") from e
    
    def disconnect(self) -> None:
        """Disconnect from the PTY WebSocket."""
        self._stop_event.set()
        
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        
        self._connected = False
        
        # Wait for reader thread to finish
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
    
    def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise PTYError("PTY not connected")
        
        with self._send_lock:
            self._ws.send(json.dumps(msg))
    
    def _start_shell(self) -> None:
        """Start the shell process with TTY enabled."""
        msg: Dict[str, Any] = {
            "type": "start",
            "command": self._shell,
            "tty": True,
            "rows": self._rows,
            "cols": self._cols,
        }
        
        if self._env:
            msg["env"] = self._env
        if self._working_dir:
            msg["working_dir"] = self._working_dir
        
        self._send_message(msg)
    
    def _read_loop(self) -> None:
        """Background thread that reads messages from the WebSocket."""
        while not self._stop_event.is_set() and self._ws:
            try:
                self._ws.settimeout(1.0)
                data = self._ws.recv()
                
                if not data:
                    continue
                
                msg = json.loads(data)
                self._handle_message(msg)
                
            except websocket.WebSocketTimeoutException:
                continue
            except websocket.WebSocketConnectionClosedException:
                self._connected = False
                break
            except Exception as e:
                if self._on_error:
                    self._on_error(str(e))
                break
    
    def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming WebSocket message."""
        msg_type = msg.get("type")
        
        if msg_type == "started":
            self._pid = msg.get("pid")
        
        elif msg_type == "stdout":
            # PTY combines stdout and stderr
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            
            # Add to buffer for read/wait_for
            with self._buffer_lock:
                self._buffer.append(data)
            
            # Call callback if registered
            if self._on_data:
                try:
                    self._on_data(data)
                except Exception:
                    pass
        
        elif msg_type == "exit":
            self._exit_code = msg.get("code", -1)
            if self._on_exit:
                try:
                    self._on_exit(self._exit_code)
                except Exception:
                    pass
        
        elif msg_type == "error":
            error_msg = msg.get("data", "Unknown error")
            try:
                decoded = base64.b64decode(error_msg)
                error_msg = decoded.decode("utf-8", errors="replace")
            except Exception:
                pass
            if self._on_error:
                try:
                    self._on_error(error_msg)
                except Exception:
                    pass
    
    def send(self, data: str) -> None:
        """Send input data to the terminal.
        
        Args:
            data: The string data to send to the terminal.
        
        Raises:
            PTYError: If PTY is not connected.
        
        Example:
            >>> pty.send("echo hello")  # Note: no newline
        """
        if not self._connected:
            raise PTYError("PTY not connected")
        
        encoded = base64.b64encode(data.encode("utf-8")).decode("ascii")
        self._send_message({
            "type": "stdin",
            "data": encoded,
        })
    
    def send_line(self, line: str) -> None:
        """Send a line to the terminal with newline appended.
        
        Args:
            line: The line to send (newline will be added).
        
        Raises:
            PTYError: If PTY is not connected.
        
        Example:
            >>> pty.send_line("echo hello")  # Sends "echo hello\n"
        """
        self.send(line + "\n")
    
    def send_bytes(self, data: bytes) -> None:
        """Send raw bytes to the terminal.
        
        Args:
            data: The bytes to send.
        
        Raises:
            PTYError: If PTY is not connected.
        """
        if not self._connected:
            raise PTYError("PTY not connected")
        
        encoded = base64.b64encode(data).decode("ascii")
        self._send_message({
            "type": "stdin",
            "data": encoded,
        })
    
    def resize(self, rows: int, cols: int) -> None:
        """Resize the terminal dimensions.
        
        Args:
            rows: New number of rows.
            cols: New number of columns.
        
        Raises:
            PTYError: If PTY is not connected.
        
        Example:
            >>> pty.resize(40, 120)  # Resize to 40 rows, 120 columns
        """
        if not self._connected:
            raise PTYError("PTY not connected")
        
        self._rows = rows
        self._cols = cols
        
        self._send_message({
            "type": "resize",
            "rows": rows,
            "cols": cols,
        })
    
    def on_data(self, callback: Callable[[str], None]) -> None:
        """Register a callback for terminal output data.
        
        The callback receives decoded string data from the terminal.
        This is called for all output including command output and prompts.
        
        Args:
            callback: Function called with each chunk of terminal output.
        
        Example:
            >>> def handle_output(data):
            ...     print(data, end="", flush=True)
            >>> pty.on_data(handle_output)
        """
        self._on_data = callback
    
    def on_exit(self, callback: Callable[[int], None]) -> None:
        """Register a callback for when the shell exits.
        
        Args:
            callback: Function called with the exit code.
        """
        self._on_exit = callback
    
    def on_error(self, callback: Callable[[str], None]) -> None:
        """Register a callback for errors.
        
        Args:
            callback: Function called with error message.
        """
        self._on_error = callback
    
    def read(self, timeout: float = 1.0) -> str:
        """Read available data from terminal buffer.
        
        Returns all data that has been received since the last read,
        waiting up to timeout seconds for data if buffer is empty.
        
        Args:
            timeout: Maximum time to wait for data in seconds.
        
        Returns:
            String containing all buffered terminal output.
        
        Example:
            >>> pty.send_line("echo hello")
            >>> time.sleep(0.5)
            >>> output = pty.read(timeout=1.0)
            >>> print(output)  # "echo hello\nhello\n$ "
        """
        start = time.time()
        
        # Wait for data if buffer is empty
        while True:
            with self._buffer_lock:
                if self._buffer:
                    data = "".join(self._buffer)
                    self._buffer.clear()
                    return data
            
            if (time.time() - start) >= timeout:
                return ""
            
            time.sleep(0.05)
    
    def read_all(self) -> str:
        """Read all buffered data without waiting.
        
        Returns:
            String containing all buffered terminal output.
        """
        with self._buffer_lock:
            data = "".join(self._buffer)
            self._buffer.clear()
            return data
    
    def wait_for(
        self,
        pattern: str,
        timeout: float = 30.0,
        *,
        regex: bool = False,
    ) -> str:
        """Wait for a pattern to appear in terminal output.
        
        Accumulates output until the pattern is found or timeout occurs.
        
        Args:
            pattern: String or regex pattern to wait for.
            timeout: Maximum time to wait in seconds.
            regex: If True, treat pattern as a regular expression.
        
        Returns:
            All accumulated output up to and including the pattern match.
        
        Raises:
            PTYError: If timeout occurs before pattern is found.
        
        Example:
            >>> pty.send_line("python --version")
            >>> output = pty.wait_for("Python", timeout=5)
            >>> print(output)
            
            >>> # Using regex
            >>> pty.send_line("echo $USER")
            >>> output = pty.wait_for(r"\\$ $", timeout=5, regex=True)
        """
        start = time.time()
        accumulated = ""
        
        if regex:
            compiled = re.compile(pattern)
        
        while (time.time() - start) < timeout:
            # Read any available data
            with self._buffer_lock:
                if self._buffer:
                    chunk = "".join(self._buffer)
                    self._buffer.clear()
                    accumulated += chunk
            
            # Check for pattern
            if regex:
                if compiled.search(accumulated):
                    return accumulated
            else:
                if pattern in accumulated:
                    return accumulated
            
            # Check if shell has exited
            if self._exit_code is not None:
                if regex:
                    if compiled.search(accumulated):
                        return accumulated
                else:
                    if pattern in accumulated:
                        return accumulated
                raise PTYError(
                    f"Shell exited (code {self._exit_code}) "
                    "before pattern found"
                )
            
            time.sleep(0.05)
        
        raise PTYError(
            f"Timeout waiting for pattern '{pattern}'. "
            f"Accumulated output: {accumulated[:500]}"
        )
    
    def wait_for_prompt(
        self,
        prompt: str = "$ ",
        timeout: float = 30.0,
    ) -> str:
        """Wait for the shell prompt to appear.
        
        Convenience method for waiting for a specific prompt pattern.
        
        Args:
            prompt: The prompt string to wait for (default: "$ ").
            timeout: Maximum time to wait in seconds.
        
        Returns:
            All accumulated output up to and including the prompt.
        
        Example:
            >>> pty.send_line("cd /tmp")
            >>> pty.wait_for_prompt()
        """
        return self.wait_for(prompt, timeout=timeout)
    
    def execute(
        self,
        command: str,
        *,
        timeout: float = 30.0,
        wait_for_prompt: bool = True,
        prompt: str = "$ ",
    ) -> str:
        """Execute a command and return its output.
        
        Sends the command, optionally waits for the prompt, and returns
        the accumulated output.
        
        Args:
            command: The command to execute.
            timeout: Maximum time to wait for completion.
            wait_for_prompt: Whether to wait for prompt after command.
            prompt: The prompt pattern to wait for.
        
        Returns:
            The command output (may include the prompt).
        
        Example:
            >>> output = pty.execute("ls -la")
            >>> print(output)
        """
        self.send_line(command)
        
        if wait_for_prompt:
            return self.wait_for(prompt, timeout=timeout)
        else:
            time.sleep(0.5)  # Brief delay to collect output
            return self.read(timeout=timeout)
    
    def clear_buffer(self) -> None:
        """Clear the output buffer.
        
        Useful for discarding old output before waiting for new patterns.
        """
        with self._buffer_lock:
            self._buffer.clear()
    
    def kill(self) -> None:
        """Send SIGKILL to the shell process.
        
        Forcefully terminates the shell. The PTY will disconnect.
        """
        if not self._connected:
            return
        
        try:
            import signal
            self._send_message({
                "type": "signal",
                "signal": signal.SIGKILL,
            })
        except Exception:
            pass
    
    def interrupt(self) -> None:
        """Send Ctrl+C (SIGINT) to the shell.
        
        Useful for interrupting running commands.
        """
        # Send Ctrl+C character
        self.send("\x03")
    
    def __enter__(self) -> "PTY":
        """Context manager entry - connects to the PTY."""
        self.connect()
        return self
    
    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Context manager exit - disconnects from the PTY."""
        self.disconnect()


class PTYManager:
    """Manager for PTY sessions on a sandbox.
    
    Factory class for creating PTY sessions. Accessible via the `pty`
    property on a Sandbox instance.
    
    Example:
        >>> sandbox = Sandbox.create(template="base")
        >>> with sandbox.pty.create() as pty:
        ...     pty.send_line("echo Hello")
        ...     output = pty.wait_for("Hello", timeout=5)
        ...     print(output)
    """
    
    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        """Initialize PTYManager.
        
        Args:
            sandbox_id: The sandbox ID.
            client: The API client with authentication credentials.
        """
        self._sandbox_id = sandbox_id
        self._client = client
    
    def create(
        self,
        rows: int = 24,
        cols: int = 80,
        shell: str = "/bin/bash",
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        *,
        connect: bool = True,
    ) -> PTY:
        """Create a new PTY session.
        
        Args:
            rows: Terminal height in rows (default: 24).
            cols: Terminal width in columns (default: 80).
            shell: Shell to use (default: /bin/bash).
            env: Environment variables for the shell.
            working_dir: Working directory for the shell.
            connect: Whether to immediately connect (default: True).
        
        Returns:
            A new PTY instance.
        
        Example:
            >>> # Auto-connect (default)
            >>> pty = sandbox.pty.create()
            >>> pty.send_line("pwd")
            
            >>> # Manual connect
            >>> pty = sandbox.pty.create(connect=False)
            >>> pty.on_data(print)
            >>> pty.connect()
            
            >>> # Custom terminal size
            >>> pty = sandbox.pty.create(rows=40, cols=120)
            
            >>> # Different shell
            >>> pty = sandbox.pty.create(shell="/bin/zsh")
        """
        pty = PTY(
            sandbox_id=self._sandbox_id,
            client=self._client,
            rows=rows,
            cols=cols,
            shell=shell,
            env=env,
            working_dir=working_dir,
        )
        
        if connect:
            pty.connect()
        
        return pty
    
    def spawn(
        self,
        command: str,
        args: Optional[List[str]] = None,
        *,
        rows: int = 24,
        cols: int = 80,
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
    ) -> PTY:
        """Spawn a command in a PTY (alternative to shell).
        
        Creates a PTY running a specific command instead of an
        interactive shell.
        
        Args:
            command: The command to run.
            args: Command arguments (will be appended to command).
            rows: Terminal height in rows.
            cols: Terminal width in columns.
            env: Environment variables.
            working_dir: Working directory.
        
        Returns:
            A new PTY instance running the command.
        
        Example:
            >>> # Run Python in interactive mode
            >>> pty = sandbox.pty.spawn("python", ["-i"])
            >>> pty.send_line("print('Hello')")
            
            >>> # Run a script
            >>> pty = sandbox.pty.spawn("python", ["script.py"])
        """
        # Build full command with args
        if args:
            full_command = f"{command} {' '.join(args)}"
        else:
            full_command = command
        
        pty = PTY(
            sandbox_id=self._sandbox_id,
            client=self._client,
            rows=rows,
            cols=cols,
            shell=full_command,
            env=env,
            working_dir=working_dir,
        )
        
        pty.connect()
        return pty
