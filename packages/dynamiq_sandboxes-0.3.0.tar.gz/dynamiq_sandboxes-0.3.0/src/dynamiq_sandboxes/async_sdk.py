"""Async variants of SDK classes using httpx.AsyncClient and websockets."""

from __future__ import annotations

import asyncio
import base64
import json
import os
from typing import Any, Callable, Dict, List, Optional, Union

import httpx

from .client.retry import (
    DEFAULT_RETRY_CONFIG,
    RetryConfig,
    calculate_delay,
    is_retryable_error,
    is_retryable_status,
)
from .client.timeout import DEFAULT_TIMEOUT_CONFIG, TimeoutConfig
from .exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
)
from .filesystem import FileInfo
from .process import ProcessResult
from .sandbox import NetworkConfig

# Optional websockets import for async streaming
try:
    import websockets
    from websockets.client import WebSocketClientProtocol
    HAS_WEBSOCKETS = True
except ImportError:
    websockets = None  # type: ignore
    WebSocketClientProtocol = None  # type: ignore
    HAS_WEBSOCKETS = False


class AsyncAPIClient:
    """Async HTTP client using httpx.AsyncClient with retries and timeouts."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        bearer_token: Optional[str] = None,
        base_url: Optional[str] = None,
        retry_config: Optional[RetryConfig] = None,
        timeout_config: Optional[TimeoutConfig] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """Initialize the async API client.

        Args:
            api_key: API key for authentication.
                Falls back to PLATFORM_API_KEY env var.
            bearer_token: Bearer token for authentication.
                Falls back to PLATFORM_BEARER_TOKEN env var.
            base_url: Base URL for the API.
            retry_config: Configuration for retry behavior.
            timeout_config: Configuration for timeouts.
            headers: Additional headers to include in requests.
        """
        api_key = api_key or os.environ.get("PLATFORM_API_KEY")
        bearer_token = bearer_token or os.environ.get("PLATFORM_BEARER_TOKEN")
        if not api_key and not bearer_token:
            raise AuthenticationError("API key or bearer token required")

        self._retry_config = retry_config or DEFAULT_RETRY_CONFIG
        self._timeout_config = timeout_config or DEFAULT_TIMEOUT_CONFIG
        self._base_url = base_url.rstrip("/")

        merged_headers = {
            "User-Agent": "platform-sdk-python/0.1.0 (async)",
        }
        if api_key:
            merged_headers["X-API-Key"] = api_key
        if bearer_token:
            merged_headers["Authorization"] = f"Bearer {bearer_token}"
        if headers:
            merged_headers.update(headers)

        self._headers = merged_headers
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def timeout_config(self) -> TimeoutConfig:
        """Get the timeout configuration."""
        return self._timeout_config

    @property
    def retry_config(self) -> RetryConfig:
        """Get the retry configuration."""
        return self._retry_config

    async def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure the async client is initialized."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=self._timeout_config.to_httpx_timeout(),
                headers=self._headers,
                http2=True,
            )
        return self._client

    async def close(self) -> None:
        """Close the async client connection."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Make an async HTTP request with retries.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            path: API endpoint path.
            params: Query parameters.
            json: JSON body payload.
            timeout: Request timeout in seconds.
            headers: Additional headers for this request.

        Returns:
            Parsed JSON response or text content.

        Raises:
            APIError: If the request fails.
            TimeoutError: If the request times out.
        """
        client = await self._ensure_client()
        normalized_path = path.lstrip("/")
        last_error: Optional[BaseException] = None

        for attempt in range(self._retry_config.max_attempts):
            try:
                response = await client.request(
                    method,
                    normalized_path,
                    params=params,
                    json=json,
                    timeout=timeout,
                    headers=headers,
                )

                if response.status_code >= 400:
                    is_retryable = is_retryable_status(
                        response.status_code, self._retry_config
                    )
                    has_attempts = attempt < self._retry_config.max_attempts - 1
                    if is_retryable and has_attempts:
                        await response.aread()
                        delay = calculate_delay(attempt, self._retry_config)
                        await asyncio.sleep(delay)
                        continue
                    self._raise_for_error(response)

                if response.status_code == 204:
                    return None

                content_type = response.headers.get("content-type", "")
                if "application/json" in content_type:
                    return response.json()
                return response.text
            except httpx.TimeoutException as exc:
                last_error = exc
                if attempt < self._retry_config.max_attempts - 1:
                    delay = calculate_delay(attempt, self._retry_config)
                    await asyncio.sleep(delay)
                    continue
                raise TimeoutError("Request timed out") from exc
            except BaseException as exc:
                last_error = exc
                is_retryable = is_retryable_error(exc, self._retry_config)
                has_attempts = attempt < self._retry_config.max_attempts - 1
                if is_retryable and has_attempts:
                    delay = calculate_delay(attempt, self._retry_config)
                    await asyncio.sleep(delay)
                    continue
                raise

        if last_error:
            raise last_error
        raise APIError("Request failed without response")

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """Make an async GET request."""
        return await self.request("GET", path, params=params, timeout=timeout)

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """Make an async POST request."""
        return await self.request(
            "POST", path, params=params, json=json, timeout=timeout
        )

    async def put(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """Make an async PUT request."""
        return await self.request(
            "PUT", path, params=params, json=json, timeout=timeout
        )

    async def delete(
        self,
        path: str,
        *,
        timeout: Optional[float] = None,
    ) -> Any:
        """Make an async DELETE request."""
        return await self.request("DELETE", path, timeout=timeout)

    @staticmethod
    def encode_path(path: str) -> str:
        """URL-encode a path parameter while preserving slashes."""
        from urllib.parse import quote
        return quote(path, safe="/")

    @staticmethod
    def encode_file_path(path: str) -> str:
        """Double URL-encode a file path for use in URL path segments."""
        from urllib.parse import quote
        encoded = quote(path, safe="")
        return quote(encoded, safe="")

    def _raise_for_error(self, response: httpx.Response) -> None:
        """Raise an appropriate exception for an error response."""
        status = response.status_code
        error_code = None
        request_id = None
        message = f"Request failed with status {status}"

        try:
            payload = response.json()
            err = payload.get("error", {}) if isinstance(payload, dict) else {}
            error_code = err.get("code")
            request_id = err.get("request_id")
            message = err.get("message", message)
        except ValueError:
            pass

        error_cls: type[APIError] = APIError
        if status == 401 or status == 403:
            error_cls = AuthenticationError
        elif status == 404:
            error_cls = NotFoundError
        elif status == 409:
            error_cls = ConflictError
        elif status == 429:
            error_cls = RateLimitError

        raise error_cls(
            message,
            status_code=status,
            error_code=error_code,
            request_id=request_id,
        )

    async def __aenter__(self) -> "AsyncAPIClient":
        """Async context manager entry."""
        await self._ensure_client()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Async context manager exit."""
        await self.close()


class AsyncFilesystem:
    """Async filesystem operations for sandbox file management."""

    def __init__(self, sandbox_id: str, client: AsyncAPIClient) -> None:
        """Initialize the async filesystem interface.

        Args:
            sandbox_id: The ID of the sandbox to operate on.
            client: The async API client for making requests.
        """
        self._sandbox_id = sandbox_id
        self._client = client

    def _encode_path(self, path: str) -> str:
        """Encode a file path for use in API requests."""
        clean_path = path.lstrip("/")
        return AsyncAPIClient.encode_file_path(clean_path)

    async def _execute_command(
        self,
        command: str,
        args: Optional[List[str]] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """Execute a shell command in the sandbox."""
        payload: dict = {"command": command}
        if args is not None:
            payload["args"] = args
        if timeout is not None:
            payload["timeout"] = timeout
        return await self._client.post(
            f"sandboxes/{self._sandbox_id}/commands",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    async def read(self, path: str) -> str:
        """Read a file and return its contents as a string.

        Args:
            path: Absolute path to the file in the sandbox.

        Returns:
            The file contents as a UTF-8 string.
        """
        response = await self._read_file_raw(path)
        content = response.get("content", "")
        encoding = response.get("encoding", "")

        if encoding == "base64":
            return base64.b64decode(content).decode("utf-8")
        return content

    async def read_bytes(self, path: str) -> bytes:
        """Read a file and return its contents as bytes.

        Args:
            path: Absolute path to the file in the sandbox.

        Returns:
            The file contents as bytes.
        """
        response = await self._read_file_raw(path)
        content = response.get("content", "")
        encoding = response.get("encoding", "")

        if encoding == "base64":
            return base64.b64decode(content)
        return content.encode("utf-8")

    async def _read_file_raw(self, path: str) -> dict:
        """Read a file and return the raw API response."""
        encoded_path = self._encode_path(path)
        return await self._client.get(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            params={"type": "file"},
            timeout=self._client.timeout_config.file_download,
        )

    async def write(self, path: str, content: Union[str, bytes]) -> None:
        """Write content to a file.

        Args:
            path: Absolute path to the file in the sandbox.
            content: Content to write (string or bytes).
        """
        encoded_path = self._encode_path(path)

        if isinstance(content, bytes):
            payload = {
                "content": base64.b64encode(content).decode("ascii"),
                "encoding": "base64",
            }
        else:
            payload = {"content": content}

        await self._client.put(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            json=payload,
            timeout=self._client.timeout_config.file_upload,
        )

    async def list(self, path: str = "/") -> List[FileInfo]:
        """List contents of a directory.

        Args:
            path: Absolute path to the directory in the sandbox.

        Returns:
            List of FileInfo objects for each entry in the directory.
        """
        encoded_path = self._encode_path(path)
        response = await self._client.get(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            params={"type": "directory"},
            timeout=self._client.timeout_config.file_download,
        )

        entries = response.get("entries", [])
        return [FileInfo.from_api_response(entry, path) for entry in entries]

    async def mkdir(self, path: str, mode: str = "755") -> None:
        """Create a directory (creates parents as needed).

        Args:
            path: Absolute path for the new directory.
            mode: Permission mode (default "755").
        """
        result = await self._execute_command("mkdir", args=["-p", path])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            raise APIError(
                f"Failed to create directory '{path}': {stderr}",
                status_code=500,
                error_code="MKDIR_FAILED",
            )

    async def remove(self, path: str, recursive: bool = False) -> None:
        """Remove a file or directory.

        Args:
            path: Absolute path to the file or directory to remove.
            recursive: If True, remove directories and contents recursively.
        """
        args = ["-f", path] if not recursive else ["-rf", path]
        result = await self._execute_command("rm", args=args)
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            raise APIError(
                f"Failed to remove '{path}': {stderr}",
                status_code=500,
                error_code="REMOVE_FAILED",
            )

    async def exists(self, path: str) -> bool:
        """Check if a file or directory exists.

        Args:
            path: Absolute path to check.

        Returns:
            True if the path exists, False otherwise.
        """
        result = await self._execute_command("test", args=["-e", path])
        return result.get("exit_code", -1) == 0

    async def stat(self, path: str) -> FileInfo:
        """Get information about a file or directory.

        Args:
            path: Absolute path to the file or directory.

        Returns:
            FileInfo object with file/directory metadata.
        """
        result = await self._execute_command(
            "stat",
            args=["-c", "%F|%s|%Y", path],
        )

        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            raise NotFoundError(f"Path not found: {path}")

        stdout = result.get("stdout", "").strip()
        parts = stdout.split("|")

        if len(parts) >= 3:
            file_type_raw = parts[0]
            size = int(parts[1]) if parts[1].isdigit() else 0
            mtime = parts[2]

            if "directory" in file_type_raw.lower():
                file_type = "directory"
            else:
                file_type = "file"

            return FileInfo(
                name=os.path.basename(path) or path,
                path=path,
                type=file_type,
                size=size,
                modified_at=mtime,
            )

        return FileInfo(
            name=os.path.basename(path) or path,
            path=path,
            type="file",
            size=0,
            modified_at=None,
        )

    async def copy(self, src: str, dst: str) -> None:
        """Copy a file or directory within the sandbox.

        Args:
            src: Source path.
            dst: Destination path.
        """
        result = await self._execute_command("cp", args=["-r", src, dst])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            raise APIError(
                f"Failed to copy '{src}' to '{dst}': {stderr}",
                status_code=500,
                error_code="COPY_FAILED",
            )

    async def move(self, src: str, dst: str) -> None:
        """Move/rename a file or directory within the sandbox.

        Args:
            src: Source path.
            dst: Destination path.
        """
        result = await self._execute_command("mv", args=[src, dst])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            raise APIError(
                f"Failed to move '{src}' to '{dst}': {stderr}",
                status_code=500,
                error_code="MOVE_FAILED",
            )


class AsyncProcessManager:
    """Async process management for sandbox command execution."""

    def __init__(self, sandbox_id: str, client: AsyncAPIClient) -> None:
        """Initialize the async process manager.

        Args:
            sandbox_id: The ID of the sandbox to operate on.
            client: The async API client for making requests.
        """
        self._sandbox_id = sandbox_id
        self._client = client

    async def run(
        self,
        cmd: str,
        args: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> ProcessResult:
        """Execute a command and wait for it to complete.

        Args:
            cmd: The command to execute.
            args: Optional list of command arguments.
            env: Optional environment variables (not used in HTTP API).
            cwd: Optional working directory.
            timeout: Optional timeout in seconds.

        Returns:
            ProcessResult with exit_code, stdout, stderr, and execution_time_ms.
        """
        full_command = cmd
        args_list = args if args else []

        payload: Dict[str, Any] = {"command": full_command}
        if args_list:
            payload["args"] = args_list
        if cwd:
            payload["working_dir"] = cwd
        if timeout:
            payload["timeout"] = timeout

        http_timeout = self._client.timeout_config.process_execution
        if timeout is not None:
            http_timeout = float(timeout + 5)

        response = await self._client.post(
            f"sandboxes/{self._sandbox_id}/commands",
            json=payload,
            timeout=http_timeout,
        )

        return ProcessResult.from_response(response)

    async def run_code(
        self,
        code: str,
        language: str,
        timeout: Optional[int] = None,
    ) -> ProcessResult:
        """Execute code in a specific language.

        Args:
            code: The code to execute.
            language: The programming language (e.g., "python", "javascript").
            timeout: Optional timeout in seconds.

        Returns:
            ProcessResult with exit_code, stdout, stderr, and execution_time_ms.
        """
        payload: Dict[str, Any] = {
            "code": code,
            "language": language,
        }
        if timeout:
            payload["timeout"] = timeout

        http_timeout = self._client.timeout_config.process_execution
        if timeout is not None:
            http_timeout = float(timeout + 5)

        response = await self._client.post(
            f"sandboxes/{self._sandbox_id}/run",
            json=payload,
            timeout=http_timeout,
        )

        return ProcessResult.from_response(response)

    async def list(self) -> List[Dict[str, Any]]:
        """List running processes in the sandbox.

        Returns:
            List of process information dictionaries.
        """
        try:
            response = await self._client.get(
                f"sandboxes/{self._sandbox_id}/processes"
            )
            if isinstance(response, list):
                return response
            return response.get("processes", [])
        except Exception:
            return []


class AsyncSandbox:
    """Async sandbox operations using httpx.AsyncClient."""

    def __init__(
        self,
        sandbox_id: str,
        client: AsyncAPIClient,
        data: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize the async sandbox.

        Args:
            sandbox_id: The sandbox ID.
            client: The async API client.
            data: Optional sandbox data from the API response.
        """
        self._id = sandbox_id
        self._client = client
        self._data: Dict[str, Any] = data or {}
        self._filesystem: Optional[AsyncFilesystem] = None
        self._process_manager: Optional[AsyncProcessManager] = None

    @property
    def id(self) -> str:
        """Get the sandbox ID."""
        return self._id

    @property
    def data(self) -> Dict[str, Any]:
        """Get the sandbox data."""
        return self._data

    @property
    def cdp_websocket_url(self) -> Optional[str]:
        """Get the CDP WebSocket URL if available."""
        return self._data.get("cdp_websocket_url")

    @property
    def live_view_url(self) -> Optional[str]:
        """Get the live view URL if available."""
        return self._data.get("live_view_url")

    @property
    def debugger_url(self) -> Optional[str]:
        """Get the debugger URL if available."""
        return self._data.get("debugger_url")

    @property
    def filesystem(self) -> AsyncFilesystem:
        """Get the async Filesystem interface for this sandbox."""
        if self._filesystem is None:
            self._filesystem = AsyncFilesystem(self._id, self._client)
        return self._filesystem

    @property
    def process(self) -> AsyncProcessManager:
        """Get the async ProcessManager interface for this sandbox."""
        if self._process_manager is None:
            self._process_manager = AsyncProcessManager(self._id, self._client)
        return self._process_manager

    @classmethod
    async def create(
        cls,
        *,
        template: str = "base",
        timeout: int = 300,
        idle_timeout: Optional[int] = None,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 2048,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        network: Optional[Union[NetworkConfig, Dict[str, Any]]] = None,
        sandbox_type: str = "code",
        is_desktop: Optional[bool] = None,
        desktop_config: Optional[Dict[str, Any]] = None,
        browser_config: Optional[Dict[str, Any]] = None,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncSandbox":
        """Create a new async sandbox.

        Args:
            template: Sandbox template ID.
            timeout: Sandbox timeout in seconds.
            idle_timeout: Idle timeout in seconds.
            name: Optional sandbox name.
            tags: Optional tags for the sandbox.
            vcpu: Number of virtual CPUs.
            memory_mb: Memory allocation in MB.
            disk_mb: Disk allocation in MB.
            env_vars: Environment variables.
            metadata: Additional metadata.
            network: Network configuration.
            sandbox_type: Type of sandbox ("code", "browser", "desktop").
            is_desktop: Whether this is a desktop sandbox.
            desktop_config: Desktop-specific configuration.
            browser_config: Browser-specific configuration.
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.

        Returns:
            A new AsyncSandbox instance.
        """
        client = client or AsyncAPIClient(api_key=api_key, base_url=base_url)
        payload: Dict[str, Any] = {
            "template_id": template,
            "timeout": timeout,
            "sandbox_type": sandbox_type,
            "resources": {
                "vcpu": vcpu,
                "memory_mb": memory_mb,
            },
        }
        if disk_mb is not None:
            payload["resources"]["disk_mb"] = disk_mb
        if idle_timeout is not None:
            payload["idle_timeout"] = idle_timeout
        if name is not None:
            payload["name"] = name
        if tags:
            payload["tags"] = tags
        if env_vars:
            payload["env_vars"] = env_vars
        if metadata:
            payload["metadata"] = metadata
        if network:
            if isinstance(network, NetworkConfig):
                payload["network"] = network.to_payload()
            else:
                payload["network"] = network
        if is_desktop is not None:
            payload["is_desktop"] = is_desktop
        if desktop_config:
            payload["desktop_config"] = desktop_config
        if browser_config:
            payload["browser_config"] = browser_config

        response = await client.post(
            "sandboxes",
            json=payload,
            timeout=client.timeout_config.create_sandbox,
        )
        sandbox_id = response["sandbox_id"]
        return cls(sandbox_id=sandbox_id, client=client, data=response)

    @classmethod
    async def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncSandbox":
        """Get an existing async sandbox by ID.

        Args:
            sandbox_id: The sandbox ID.
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.

        Returns:
            An AsyncSandbox instance.
        """
        client = client or AsyncAPIClient(api_key=api_key, base_url=base_url)
        response = await client.get(f"sandboxes/{sandbox_id}")
        return cls(sandbox_id=sandbox_id, client=client, data=response)

    @classmethod
    async def from_name(
        cls,
        name: str,
        *,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncSandbox":
        """Get an existing async sandbox by name.

        Args:
            name: The sandbox name.
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.

        Returns:
            An AsyncSandbox instance.
        """
        client = client or AsyncAPIClient(api_key=api_key, base_url=base_url)
        response = await client.get(
            f"sandboxes/by-name/{AsyncAPIClient.encode_path(name)}"
        )
        return cls(
            sandbox_id=response["sandbox_id"],
            client=client,
            data=response,
        )

    @classmethod
    async def list(
        cls,
        *,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        state: Optional[str] = None,
        template_id: Optional[str] = None,
        name: Optional[str] = None,
        sandbox_type: Optional[str] = None,
        is_desktop: Optional[bool] = None,
        tags: Optional[Dict[str, str]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """List sandboxes with optional filters.

        Args:
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.
            state: Filter by sandbox state.
            template_id: Filter by template ID.
            name: Filter by sandbox name.
            sandbox_type: Filter by sandbox type.
            is_desktop: Filter by desktop flag.
            tags: Filter by tags.
            limit: Maximum number of results.
            offset: Offset for pagination.

        Returns:
            A dictionary containing the list of sandboxes.
        """
        client = client or AsyncAPIClient(api_key=api_key, base_url=base_url)
        params: Dict[str, Any] = {}
        if state:
            params["state"] = state
        if template_id:
            params["template_id"] = template_id
        if name:
            params["name"] = name
        if sandbox_type:
            params["sandbox_type"] = sandbox_type
        if is_desktop is not None:
            params["is_desktop"] = is_desktop
        if tags:
            for key, value in tags.items():
                params[f"tags[{key}]"] = value
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        return await client.get("sandboxes", params=params)

    async def refresh(self) -> Dict[str, Any]:
        """Refresh the sandbox data from the API."""
        self._data = await self._client.get(f"sandboxes/{self._id}")
        return self._data

    async def close(self) -> None:
        """Close/terminate the sandbox."""
        await self._client.delete(f"sandboxes/{self._id}")

    async def extend_timeout(self, timeout: int) -> Dict[str, Any]:
        """Extend the sandbox timeout.

        Args:
            timeout: New timeout in seconds.

        Returns:
            API response.
        """
        return await self._client.post(
            f"sandboxes/{self._id}/timeout",
            json={"timeout": timeout},
        )

    async def pause(self) -> Dict[str, Any]:
        """Pause the sandbox."""
        return await self._client.post(f"sandboxes/{self._id}/pause")

    async def resume(self, timeout: int) -> Dict[str, Any]:
        """Resume a paused sandbox.

        Args:
            timeout: Timeout for the resumed sandbox.

        Returns:
            API response.
        """
        return await self._client.post(
            f"sandboxes/{self._id}/resume",
            json={"timeout": timeout},
        )

    async def get_host(self, port: int) -> Dict[str, Any]:
        """Get the host URL for a port.

        Args:
            port: The port number.

        Returns:
            Host information.
        """
        return await self._client.get(f"sandboxes/{self._id}/host/{port}")

    async def get_env(self) -> Dict[str, Any]:
        """Get the sandbox environment variables."""
        return await self._client.get(f"sandboxes/{self._id}/env")

    async def connect(self) -> Dict[str, Any]:
        """Connect to the sandbox."""
        return await self._client.post(f"sandboxes/{self._id}/connect")

    async def run_code(
        self,
        code: str,
        *,
        language: str = "python",
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Run code in the sandbox.

        Args:
            code: The code to execute.
            language: Programming language.
            timeout: Execution timeout.

        Returns:
            Execution result.
        """
        payload: Dict[str, Any] = {"code": code, "language": language}
        if timeout is not None:
            payload["timeout"] = timeout
        return await self._client.post(
            f"sandboxes/{self._id}/run",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    async def execute_command(
        self,
        command: str,
        *,
        args: Optional[List[str]] = None,
        working_dir: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Execute a command in the sandbox.

        Args:
            command: The command to execute.
            args: Command arguments.
            working_dir: Working directory.
            timeout: Execution timeout.

        Returns:
            Execution result.
        """
        payload: Dict[str, Any] = {"command": command}
        if args is not None:
            payload["args"] = args
        if working_dir is not None:
            payload["working_dir"] = working_dir
        if timeout is not None:
            payload["timeout"] = timeout
        return await self._client.post(
            f"sandboxes/{self._id}/commands",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    async def read_file(
        self,
        path: str,
        *,
        file_type: str = "file",
    ) -> Dict[str, Any]:
        """Read a file from the sandbox.

        Args:
            path: File path in the sandbox.
            file_type: Type of file to read.

        Returns:
            File content and metadata.
        """
        clean_path = path.lstrip("/")
        encoded_path = AsyncAPIClient.encode_file_path(clean_path)
        return await self._client.get(
            f"sandboxes/{self._id}/files/{encoded_path}",
            params={"type": file_type},
            timeout=self._client.timeout_config.file_download,
        )

    async def write_file(
        self,
        path: str,
        content: str,
        *,
        encoding: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Write a file to the sandbox.

        Args:
            path: File path in the sandbox.
            content: File content.
            encoding: Content encoding.

        Returns:
            API response.
        """
        clean_path = path.lstrip("/")
        encoded_path = AsyncAPIClient.encode_file_path(clean_path)
        payload: Dict[str, Any] = {"content": content}
        if encoding:
            payload["encoding"] = encoding
        return await self._client.put(
            f"sandboxes/{self._id}/files/{encoded_path}",
            json=payload,
            timeout=self._client.timeout_config.file_upload,
        )

    async def metrics(self) -> Dict[str, Any]:
        """Get sandbox metrics."""
        return await self._client.get(f"sandboxes/{self._id}/metrics")

    async def metrics_history(
        self,
        *,
        start: Optional[str] = None,
        end: Optional[str] = None,
        interval: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get sandbox metrics history.

        Args:
            start: Start timestamp.
            end: End timestamp.
            interval: Metrics interval.

        Returns:
            Metrics history data.
        """
        params: Dict[str, Any] = {}
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if interval:
            params["interval"] = interval
        return await self._client.get(
            f"sandboxes/{self._id}/metrics/history",
            params=params,
        )

    async def __aenter__(self) -> "AsyncSandbox":
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Async context manager exit - closes the sandbox."""
        await self.close()


class AsyncBrowser(AsyncSandbox):
    """Async browser sandbox with full automation support."""

    @classmethod
    async def create(
        cls,
        *,
        template: str = "browser-chromium",
        timeout: int = 3600,
        idle_timeout: Optional[int] = 300,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 4096,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        browser_config: Optional[Dict[str, Any]] = None,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncBrowser":
        """Create a new async browser sandbox.

        Args:
            template: Browser template ID.
            timeout: Sandbox timeout in seconds.
            idle_timeout: Idle timeout in seconds.
            name: Optional sandbox name.
            tags: Optional tags.
            vcpu: Number of virtual CPUs.
            memory_mb: Memory allocation in MB.
            disk_mb: Disk allocation in MB.
            env_vars: Environment variables.
            metadata: Additional metadata.
            browser_config: Browser-specific configuration.
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.

        Returns:
            A new AsyncBrowser instance.
        """
        sandbox = await AsyncSandbox.create(
            template=template,
            timeout=timeout,
            idle_timeout=idle_timeout,
            name=name,
            tags=tags,
            vcpu=vcpu,
            memory_mb=memory_mb,
            disk_mb=disk_mb,
            env_vars=env_vars,
            metadata=metadata,
            sandbox_type="browser",
            browser_config=browser_config,
            client=client,
            api_key=api_key,
            base_url=base_url,
        )
        return cls(
            sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data
        )

    @classmethod
    async def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncBrowser":
        """Get an existing async browser sandbox by ID."""
        sandbox = await AsyncSandbox.get(
            sandbox_id, client=client, api_key=api_key, base_url=base_url
        )
        return cls(
            sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data
        )

    def _browser_path(self, endpoint: str) -> str:
        """Construct browser session API path."""
        return f"browser/sessions/{self._id}/{endpoint}"

    async def screenshot(
        self,
        *,
        format: str = "png",
        full_page: bool = False,
        quality: Optional[int] = None,
        selector: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Capture a screenshot of the browser viewport or element.

        Args:
            format: Image format - "png", "jpeg", or "webp".
            full_page: If True, captures the entire scrollable page.
            quality: Image quality (1-100) for jpeg/webp formats.
            selector: CSS selector to screenshot a specific element.

        Returns:
            Dict containing image data and metadata.
        """
        payload: Dict[str, Any] = {"format": format}
        if full_page:
            payload["full_page"] = full_page
        if quality is not None:
            payload["quality"] = quality
        if selector is not None:
            payload["selector"] = selector
        return await self._client.post(
            self._browser_path("screenshot"), json=payload
        )

    async def scrape(
        self,
        *,
        format: str = "text",
        wait_for: Optional[str] = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Scrape page content as text or HTML.

        Args:
            format: Content format - "text" or "html".
            wait_for: CSS selector to wait for before scraping.
            timeout: Maximum time to wait in seconds.

        Returns:
            Dict containing scraped content.
        """
        payload: Dict[str, Any] = {"format": format, "timeout": timeout}
        if wait_for is not None:
            payload["wait_for"] = wait_for
        return await self._client.post(
            self._browser_path("scrape"),
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    async def pdf(
        self,
        *,
        format: str = "A4",
        landscape: bool = False,
        print_background: bool = True,
        margin: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Generate a PDF of the current page.

        Args:
            format: Paper size - "A4", "Letter", etc.
            landscape: If True, use landscape orientation.
            print_background: If True, include background graphics.
            margin: Page margins.

        Returns:
            Dict containing PDF data.
        """
        payload: Dict[str, Any] = {
            "format": format,
            "landscape": landscape,
            "print_background": print_background,
        }
        if margin is not None:
            payload["margin"] = margin
        return await self._client.post(self._browser_path("pdf"), json=payload)

    async def get_context(self) -> Dict[str, Any]:
        """Get the browser context including cookies and storage."""
        return await self._client.get(self._browser_path("context"))

    async def set_context(
        self,
        context: Dict[str, Any],
        *,
        merge: bool = True,
    ) -> Dict[str, Any]:
        """Set or update the browser context.

        Args:
            context: Context data (cookies, storage).
            merge: If True, merge with existing context.

        Returns:
            API response.
        """
        payload = {**context, "merge": merge}
        return await self._client.put(self._browser_path("context"), json=payload)

    async def get_live_view(self, *, interactive: bool = True) -> Dict[str, Any]:
        """Get live view streaming information.

        Args:
            interactive: If True, enables interactive mode.

        Returns:
            Live view connection info.
        """
        params: Dict[str, Any] = {"interactive": interactive}
        return await self._client.get(self._browser_path("live"), params=params)

    async def get_logs(
        self,
        *,
        level: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get browser console logs.

        Args:
            level: Filter by log level.
            since: ISO 8601 timestamp to get logs after.
            limit: Maximum number of logs.

        Returns:
            List of log entries.
        """
        params: Dict[str, Any] = {"limit": limit}
        if level is not None:
            params["level"] = level
        if since is not None:
            params["since"] = since
        response = await self._client.get(self._browser_path("logs"), params=params)
        if isinstance(response, dict):
            return response.get("logs", [])
        return response

    async def get_network_requests(
        self,
        *,
        status: Optional[int] = None,
        method: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get captured network requests.

        Args:
            status: Filter by HTTP status code.
            method: Filter by HTTP method.
            limit: Maximum number of requests.

        Returns:
            List of network request entries.
        """
        params: Dict[str, Any] = {"limit": limit}
        if status is not None:
            params["status"] = str(status)
        if method is not None:
            params["method"] = method
        response = await self._client.get(
            self._browser_path("network"), params=params
        )
        if isinstance(response, dict):
            return response.get("requests", [])
        return response

    async def export_har(self) -> Dict[str, Any]:
        """Export browser network activity as HAR format."""
        return await self._client.get(self._browser_path("har"))

    async def list_downloads(self) -> List[Dict[str, Any]]:
        """List all files downloaded during the browser session."""
        response = await self._client.get(self._browser_path("downloads"))
        if isinstance(response, dict):
            return response.get("downloads", [])
        return response

    async def get_download(self, download_id: str) -> Dict[str, Any]:
        """Get details about a specific download."""
        return await self._client.get(
            self._browser_path(f"downloads/{download_id}")
        )

    async def upload_file(
        self,
        file_path: str,
        *,
        filename: Optional[str] = None,
        content: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """Upload a file to the browser session.

        Args:
            file_path: Path to the local file or target filename.
            filename: Override filename for the upload.
            content: File content as bytes (if not reading from local file).

        Returns:
            Upload response with file information.
        """
        if content is None:
            with open(file_path, "rb") as f:
                content = f.read()
            if filename is None:
                filename = os.path.basename(file_path)
        else:
            if filename is None:
                if file_path:
                    filename = os.path.basename(file_path)
                else:
                    filename = "upload.bin"

        payload = {
            "filename": filename,
            "content": base64.b64encode(content).decode("utf-8"),
        }
        return await self._client.post(
            self._browser_path("uploads/base64"), json=payload
        )


class AsyncDesktop(AsyncSandbox):
    """Async desktop sandbox with GUI automation support."""

    @classmethod
    async def create(
        cls,
        *,
        template: str = "desktop-xfce",
        timeout: int = 3600,
        idle_timeout: Optional[int] = None,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 4096,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        desktop_config: Optional[Dict[str, Any]] = None,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncDesktop":
        """Create a new async desktop sandbox.

        Args:
            template: Desktop template ID.
            timeout: Sandbox timeout in seconds.
            idle_timeout: Idle timeout in seconds.
            name: Optional sandbox name.
            tags: Optional tags.
            vcpu: Number of virtual CPUs.
            memory_mb: Memory allocation in MB.
            disk_mb: Disk allocation in MB.
            env_vars: Environment variables.
            metadata: Additional metadata.
            desktop_config: Desktop-specific configuration.
            client: Optional async API client.
            api_key: API key for authentication.
            base_url: Base URL for the API.

        Returns:
            A new AsyncDesktop instance.
        """
        sandbox = await AsyncSandbox.create(
            template=template,
            timeout=timeout,
            idle_timeout=idle_timeout,
            name=name,
            tags=tags,
            vcpu=vcpu,
            memory_mb=memory_mb,
            disk_mb=disk_mb,
            env_vars=env_vars,
            metadata=metadata,
            sandbox_type="desktop",
            desktop_config=desktop_config,
            client=client,
            api_key=api_key,
            base_url=base_url,
        )
        return cls(sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data)

    @classmethod
    async def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[AsyncAPIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "AsyncDesktop":
        """Get an existing async desktop sandbox by ID."""
        sandbox = await AsyncSandbox.get(
            sandbox_id, client=client, api_key=api_key, base_url=base_url
        )
        return cls(sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data)

    async def screenshot(
        self,
        *,
        format: Optional[str] = None,
        quality: Optional[int] = None,
        window_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Capture a screenshot of the desktop.

        Args:
            format: Image format.
            quality: Image quality.
            window_id: Specific window to capture.

        Returns:
            Screenshot data.
        """
        payload: Dict[str, Any] = {}
        if format:
            payload["format"] = format
        if quality is not None:
            payload["quality"] = quality
        if window_id is not None:
            payload["window_id"] = window_id
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/screenshot",
            json=payload,
        )

    async def stream_start(
        self,
        *,
        window_id: Optional[int] = None,
        require_auth: Optional[bool] = None,
        quality: Optional[str] = None,
        frame_rate: Optional[int] = None,
        auto_connect: Optional[bool] = None,
        view_only: Optional[bool] = None,
        resize: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Start desktop streaming.

        Args:
            window_id: Specific window to stream.
            require_auth: Whether authentication is required.
            quality: Stream quality.
            frame_rate: Stream frame rate.
            auto_connect: Auto-connect option.
            view_only: View-only mode.
            resize: Resize mode.

        Returns:
            Stream connection info.
        """
        payload: Dict[str, Any] = {}
        if window_id is not None:
            payload["window_id"] = window_id
        if require_auth is not None:
            payload["require_auth"] = require_auth
        if quality is not None:
            payload["quality"] = quality
        if frame_rate is not None:
            payload["frame_rate"] = frame_rate
        if auto_connect is not None:
            payload["auto_connect"] = auto_connect
        if view_only is not None:
            payload["view_only"] = view_only
        if resize is not None:
            payload["resize"] = resize
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/stream/start",
            json=payload,
            timeout=self._client.timeout_config.stream_connect,
        )

    async def stream_stop(self) -> None:
        """Stop desktop streaming."""
        await self._client.post(
            f"sandboxes/{self._id}/desktop/stream/stop",
            timeout=self._client.timeout_config.stream_connect,
        )

    async def stream_info(
        self,
        *,
        auto_connect: Optional[bool] = None,
        view_only: Optional[bool] = None,
        resize: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get desktop stream information.

        Args:
            auto_connect: Auto-connect option.
            view_only: View-only mode.
            resize: Resize mode.

        Returns:
            Stream info.
        """
        params: Dict[str, Any] = {}
        if auto_connect is not None:
            params["auto_connect"] = auto_connect
        if view_only is not None:
            params["view_only"] = view_only
        if resize is not None:
            params["resize"] = resize
        return await self._client.get(
            f"sandboxes/{self._id}/desktop/stream",
            params=params,
            timeout=self._client.timeout_config.stream_connect,
        )

    async def mouse_click(
        self,
        x: int,
        y: int,
        *,
        button: Optional[str] = None,
        double_click: Optional[bool] = None,
        modifiers: Optional[List[str]] = None,
        screenshot: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Perform a mouse click.

        Args:
            x: X coordinate.
            y: Y coordinate.
            button: Mouse button ("left", "right", "middle").
            double_click: Whether to double-click.
            modifiers: Keyboard modifiers.
            screenshot: Whether to capture a screenshot after.

        Returns:
            Click result (may include screenshot).
        """
        payload: Dict[str, Any] = {"x": x, "y": y}
        if button is not None:
            payload["button"] = button
        if double_click is not None:
            payload["double_click"] = double_click
        if modifiers is not None:
            payload["modifiers"] = modifiers
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/click", json=payload
        )

    async def mouse_move(self, x: int, y: int) -> None:
        """Move the mouse cursor.

        Args:
            x: X coordinate.
            y: Y coordinate.
        """
        await self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/move",
            json={"x": x, "y": y},
        )

    async def mouse_scroll(
        self, x: int, y: int, delta_x: int, delta_y: int
    ) -> None:
        """Scroll at a position.

        Args:
            x: X coordinate.
            y: Y coordinate.
            delta_x: Horizontal scroll delta.
            delta_y: Vertical scroll delta.
        """
        await self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/scroll",
            json={"x": x, "y": y, "delta_x": delta_x, "delta_y": delta_y},
        )

    async def mouse_drag(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int,
        *,
        button: Optional[str] = None,
    ) -> None:
        """Perform a mouse drag.

        Args:
            start_x: Start X coordinate.
            start_y: Start Y coordinate.
            end_x: End X coordinate.
            end_y: End Y coordinate.
            button: Mouse button.
        """
        payload: Dict[str, Any] = {
            "start_x": start_x,
            "start_y": start_y,
            "end_x": end_x,
            "end_y": end_y,
        }
        if button is not None:
            payload["button"] = button
        await self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/drag", json=payload
        )

    async def keyboard_type(
        self, text: str, *, screenshot: Optional[bool] = None
    ) -> Dict[str, Any]:
        """Type text using the keyboard.

        Args:
            text: Text to type.
            screenshot: Whether to capture a screenshot after.

        Returns:
            Result (may include screenshot).
        """
        payload: Dict[str, Any] = {"text": text}
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/keyboard/type", json=payload
        )

    async def keyboard_press(
        self,
        keys: List[str],
        *,
        duration_ms: Optional[int] = None,
        screenshot: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Press keyboard keys.

        Args:
            keys: List of keys to press.
            duration_ms: Key press duration.
            screenshot: Whether to capture a screenshot after.

        Returns:
            Result (may include screenshot).
        """
        payload: Dict[str, Any] = {"keys": keys}
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/keyboard/press", json=payload
        )

    async def cursor(self) -> Dict[str, Any]:
        """Get the current cursor position and state."""
        return await self._client.get(f"sandboxes/{self._id}/desktop/cursor")

    async def wait(
        self, duration_ms: int, *, screenshot: Optional[bool] = None
    ) -> Dict[str, Any]:
        """Wait for a duration.

        Args:
            duration_ms: Duration to wait in milliseconds.
            screenshot: Whether to capture a screenshot after.

        Returns:
            Result (may include screenshot).
        """
        payload: Dict[str, Any] = {"duration_ms": duration_ms}
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/wait", json=payload
        )

    async def list_windows(
        self, *, visible_only: Optional[bool] = None
    ) -> Dict[str, Any]:
        """List desktop windows.

        Args:
            visible_only: Whether to list only visible windows.

        Returns:
            List of windows.
        """
        params: Dict[str, Any] = {}
        if visible_only is not None:
            params["visible_only"] = visible_only
        return await self._client.get(
            f"sandboxes/{self._id}/desktop/windows", params=params
        )

    async def current_window(self) -> Dict[str, Any]:
        """Get the current active window."""
        return await self._client.get(
            f"sandboxes/{self._id}/desktop/windows/current"
        )

    async def focus_window(self, window_id: int) -> None:
        """Focus a specific window.

        Args:
            window_id: The window ID to focus.
        """
        await self._client.post(
            f"sandboxes/{self._id}/desktop/windows/{window_id}/focus"
        )

    async def launch(
        self,
        application: str,
        *,
        args: Optional[List[str]] = None,
        wait_for_window: Optional[bool] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Launch an application.

        Args:
            application: Application to launch.
            args: Application arguments.
            wait_for_window: Whether to wait for a window to appear.
            timeout: Launch timeout.

        Returns:
            Launch result.
        """
        payload: Dict[str, Any] = {"application": application}
        if args is not None:
            payload["args"] = args
        if wait_for_window is not None:
            payload["wait_for_window"] = wait_for_window
        if timeout is not None:
            payload["timeout"] = timeout
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/launch", json=payload
        )

    async def open(self, path: str) -> Dict[str, Any]:
        """Open a file or URL with the default application.

        Args:
            path: File path or URL to open.

        Returns:
            Open result.
        """
        return await self._client.post(
            f"sandboxes/{self._id}/desktop/open", json={"path": path}
        )


# -------------------------------------------------------------------------
# Async WebSocket Streaming Classes
# -------------------------------------------------------------------------


class AsyncProcessStream:
    """Async WebSocket client for streaming process I/O using websockets library.

    Provides real-time stdin/stdout/stderr streaming for processes running
    in a sandbox. Supports PTY mode for interactive terminal sessions.

    Example:
        async with AsyncProcessStream(sandbox_id, client) as stream:
            stream.on_stdout(lambda data: print(data, end=""))
            await stream.start_process("bash", tty=True)
            await stream.send_stdin("ls -la\\n")
            await stream.wait_for_exit()
    """

    def __init__(self, sandbox_id: str, client: AsyncAPIClient) -> None:
        """Initialize AsyncProcessStream.

        Args:
            sandbox_id: The sandbox ID to connect to.
            client: The async API client with authentication credentials.
        """
        if not HAS_WEBSOCKETS:
            raise ImportError(
                "websockets is required for async streaming. "
                "Install it with: pip install websockets"
            )

        self._sandbox_id = sandbox_id
        self._client = client
        self._ws: Optional[WebSocketClientProtocol] = None
        self._connected = False
        self._pid: Optional[int] = None
        self._exit_code: Optional[int] = None

        # Callbacks
        self._on_stdout: Optional[Callable[[str], None]] = None
        self._on_stderr: Optional[Callable[[str], None]] = None
        self._on_exit: Optional[Callable[[int], None]] = None
        self._on_error: Optional[Callable[[str], None]] = None
        self._on_started: Optional[Callable[[int], None]] = None

        # Reader task
        self._reader_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()

    @property
    def connected(self) -> bool:
        """Whether the WebSocket is connected."""
        return self._connected

    @property
    def pid(self) -> Optional[int]:
        """The process ID, if a process has been started."""
        return self._pid

    @property
    def exit_code(self) -> Optional[int]:
        """The process exit code, if the process has exited."""
        return self._exit_code

    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for process streaming."""
        base_url = self._client._base_url
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url

        url = f"{ws_base}/sandboxes/{self._sandbox_id}/process/stream"

        # Add API key as query parameter
        api_key = self._client._headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"

        return url

    async def connect(self) -> None:
        """Connect to the WebSocket endpoint.

        Raises:
            RuntimeError: If connection fails.
        """
        if self._connected:
            return

        try:
            url = self._get_ws_url()
            self._ws = await websockets.connect(url, close_timeout=5)
            self._connected = True
            self._stop_event.clear()

            # Start reader task
            self._reader_task = asyncio.create_task(self._read_loop())
        except Exception as e:
            self._connected = False
            raise RuntimeError(f"Failed to connect: {e}") from e

    async def disconnect(self) -> None:
        """Disconnect from the WebSocket endpoint."""
        self._stop_event.set()

        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
        self._reader_task = None

        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

        self._connected = False

    async def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")

        await self._ws.send(json.dumps(msg))

    async def _read_loop(self) -> None:
        """Background task that reads messages from the WebSocket."""
        try:
            while not self._stop_event.is_set() and self._ws:
                try:
                    data = await asyncio.wait_for(
                        self._ws.recv(),
                        timeout=1.0
                    )

                    if not data:
                        continue

                    msg = json.loads(data)
                    await self._handle_message(msg)

                except asyncio.TimeoutError:
                    continue
                except websockets.exceptions.ConnectionClosed:
                    self._connected = False
                    break
                except Exception as e:
                    if self._on_error:
                        self._on_error(str(e))
                    break
        except asyncio.CancelledError:
            pass

    async def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming WebSocket message."""
        msg_type = msg.get("type")

        if msg_type == "started":
            self._pid = msg.get("pid")
            if self._on_started:
                self._on_started(self._pid)

        elif msg_type == "stdout":
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            if self._on_stdout:
                self._on_stdout(data)

        elif msg_type == "stderr":
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            if self._on_stderr:
                self._on_stderr(data)

        elif msg_type == "exit":
            self._exit_code = msg.get("code", -1)
            if self._on_exit:
                self._on_exit(self._exit_code)

        elif msg_type == "error":
            error_msg = msg.get("data", "Unknown error")
            try:
                decoded = base64.b64decode(error_msg)
                error_msg = decoded.decode("utf-8", errors="replace")
            except Exception:
                pass
            if self._on_error:
                self._on_error(error_msg)

    async def start_process(
        self,
        cmd: str,
        args: Optional[List[str]] = None,
        *,
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        tty: bool = False,
        rows: int = 24,
        cols: int = 80,
    ) -> str:
        """Start a process and stream its I/O.

        Args:
            cmd: The command to execute.
            args: Command arguments.
            env: Environment variables.
            working_dir: Working directory for the process.
            tty: Whether to allocate a PTY.
            rows: Terminal rows (only used if tty=True).
            cols: Terminal columns (only used if tty=True).

        Returns:
            A request ID.
        """
        if not self._connected:
            await self.connect()

        msg: Dict[str, Any] = {
            "type": "start",
            "command": cmd,
        }

        if args:
            msg["args"] = args
        if env:
            msg["env"] = env
        if working_dir:
            msg["working_dir"] = working_dir
        if tty:
            msg["tty"] = True
            msg["rows"] = rows
            msg["cols"] = cols

        await self._send_message(msg)
        return f"process-{self._sandbox_id}"

    async def send_stdin(self, data: str) -> None:
        """Send data to the process's stdin.

        Args:
            data: The string data to send.
        """
        encoded = base64.b64encode(data.encode("utf-8")).decode("ascii")
        await self._send_message({
            "type": "stdin",
            "data": encoded,
        })

    async def send_stdin_bytes(self, data: bytes) -> None:
        """Send raw bytes to the process's stdin.

        Args:
            data: The bytes to send.
        """
        encoded = base64.b64encode(data).decode("ascii")
        await self._send_message({
            "type": "stdin",
            "data": encoded,
        })

    async def resize_terminal(self, rows: int, cols: int) -> None:
        """Resize the terminal (only valid for PTY processes).

        Args:
            rows: New number of rows.
            cols: New number of columns.
        """
        await self._send_message({
            "type": "resize",
            "rows": rows,
            "cols": cols,
        })

    async def kill_process(self, sig: str = "SIGTERM") -> None:
        """Send a signal to the process.

        Args:
            sig: Signal name (e.g., "SIGTERM", "SIGKILL", "SIGINT").
        """
        import signal as signal_module

        signal_map = {
            "SIGHUP": signal_module.SIGHUP,
            "SIGINT": signal_module.SIGINT,
            "SIGQUIT": signal_module.SIGQUIT,
            "SIGTERM": signal_module.SIGTERM,
            "SIGKILL": signal_module.SIGKILL,
            "SIGUSR1": signal_module.SIGUSR1,
            "SIGUSR2": signal_module.SIGUSR2,
        }

        sig_num = signal_map.get(sig.upper())
        if sig_num is None:
            raise ValueError(f"Unknown signal: {sig}")

        await self._send_message({
            "type": "signal",
            "signal": sig_num,
        })

    def on_stdout(self, callback: Callable[[str], None]) -> None:
        """Register a callback for stdout data."""
        self._on_stdout = callback

    def on_stderr(self, callback: Callable[[str], None]) -> None:
        """Register a callback for stderr data."""
        self._on_stderr = callback

    def on_exit(self, callback: Callable[[int], None]) -> None:
        """Register a callback for process exit."""
        self._on_exit = callback

    def on_error(self, callback: Callable[[str], None]) -> None:
        """Register a callback for errors."""
        self._on_error = callback

    def on_started(self, callback: Callable[[int], None]) -> None:
        """Register a callback for when the process starts."""
        self._on_started = callback

    async def wait_for_exit(self, timeout: Optional[float] = None) -> Optional[int]:
        """Wait for the process to exit.

        Args:
            timeout: Maximum time to wait in seconds. None means wait forever.

        Returns:
            The exit code, or None if timeout occurred.
        """
        start = asyncio.get_event_loop().time()
        while self._exit_code is None:
            if timeout is not None and (asyncio.get_event_loop().time() - start) >= timeout:
                return None
            await asyncio.sleep(0.1)

        return self._exit_code

    async def __aenter__(self) -> "AsyncProcessStream":
        """Async context manager entry - connects to the WebSocket."""
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Async context manager exit - disconnects from the WebSocket."""
        await self.disconnect()


class AsyncFileWatcher:
    """Async WebSocket client for watching file changes in a sandbox.

    Example:
        async def on_change(event_type: str, path: str):
            print(f"{event_type}: {path}")

        async with AsyncFileWatcher(sandbox_id, client) as watcher:
            await watcher.watch("/workspace", on_change)
            await asyncio.sleep(60)  # Watch for 60 seconds
    """

    def __init__(self, sandbox_id: str, client: AsyncAPIClient) -> None:
        """Initialize AsyncFileWatcher.

        Args:
            sandbox_id: The sandbox ID to connect to.
            client: The async API client with authentication credentials.
        """
        if not HAS_WEBSOCKETS:
            raise ImportError(
                "websockets is required for async file watching. "
                "Install it with: pip install websockets"
            )

        self._sandbox_id = sandbox_id
        self._client = client
        self._ws: Optional[WebSocketClientProtocol] = None
        self._connected = False

        # Callbacks by path
        self._callbacks: Dict[str, Callable[[str, str], None]] = {}
        self._global_callback: Optional[Callable[[str, str], None]] = None

        # Reader task
        self._reader_task: Optional[asyncio.Task] = None
        self._stop_event = asyncio.Event()

    @property
    def connected(self) -> bool:
        """Whether the WebSocket is connected."""
        return self._connected

    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for file watching."""
        base_url = self._client._base_url
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url

        url = f"{ws_base}/sandboxes/{self._sandbox_id}/files/watch"

        api_key = self._client._headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"

        return url

    async def connect(self) -> None:
        """Connect to the WebSocket endpoint."""
        if self._connected:
            return

        try:
            url = self._get_ws_url()
            self._ws = await websockets.connect(url, close_timeout=5)
            self._connected = True
            self._stop_event.clear()

            # Start reader task
            self._reader_task = asyncio.create_task(self._read_loop())
        except Exception as e:
            self._connected = False
            raise RuntimeError(f"Failed to connect: {e}") from e

    async def disconnect(self) -> None:
        """Disconnect from the WebSocket endpoint."""
        self._stop_event.set()

        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
        self._reader_task = None

        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

        self._connected = False

    async def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise RuntimeError("Not connected")

        await self._ws.send(json.dumps(msg))

    async def _read_loop(self) -> None:
        """Background task that reads messages from the WebSocket."""
        try:
            while not self._stop_event.is_set() and self._ws:
                try:
                    data = await asyncio.wait_for(
                        self._ws.recv(),
                        timeout=1.0
                    )

                    if not data:
                        continue

                    msg = json.loads(data)
                    self._handle_message(msg)

                except asyncio.TimeoutError:
                    continue
                except websockets.exceptions.ConnectionClosed:
                    self._connected = False
                    break
                except Exception:
                    break
        except asyncio.CancelledError:
            pass

    def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming file event message."""
        event_type = msg.get("type")  # "created", "modified", "deleted"
        path = msg.get("path", "")

        if not event_type or event_type in ("watch", "unwatch", "error"):
            return

        # Call global callback
        if self._global_callback:
            try:
                self._global_callback(event_type, path)
            except Exception:
                pass

        # Call path-specific callbacks
        for watch_path, callback in self._callbacks.items():
            if path.startswith(watch_path):
                try:
                    callback(event_type, path)
                except Exception:
                    pass

    async def watch(
        self,
        path: str,
        on_change: Callable[[str, str], None],
        *,
        recursive: bool = True,
    ) -> None:
        """Start watching a path for changes.

        Args:
            path: The path to watch (file or directory).
            on_change: Callback function(event_type, file_path) for changes.
            recursive: Whether to watch subdirectories recursively.
        """
        if not self._connected:
            await self.connect()

        self._callbacks[path] = on_change

        await self._send_message({
            "type": "watch",
            "path": path,
            "recursive": recursive,
        })

    async def unwatch(self, path: str) -> None:
        """Stop watching a path.

        Args:
            path: The path to stop watching.
        """
        self._callbacks.pop(path, None)

        if self._connected:
            await self._send_message({
                "type": "unwatch",
                "path": path,
            })

    def on_any_change(self, callback: Callable[[str, str], None]) -> None:
        """Register a callback for all file changes.

        Args:
            callback: Function called with (event_type, path) for any change.
        """
        self._global_callback = callback

    async def __aenter__(self) -> "AsyncFileWatcher":
        """Async context manager entry - connects to the WebSocket."""
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Async context manager exit - disconnects from the WebSocket."""
        await self.disconnect()
