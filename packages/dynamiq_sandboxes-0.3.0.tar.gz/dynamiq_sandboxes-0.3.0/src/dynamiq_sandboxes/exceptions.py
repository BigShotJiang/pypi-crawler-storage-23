"""
Dynamiq Sandboxes SDK Exceptions

All exceptions that can be raised by the SDK.
"""

from __future__ import annotations

from typing import Optional


class SandboxError(Exception):
    """Base exception for all Dynamiq Sandboxes errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class APIError(SandboxError):
    """API request failed.
    
    Attributes:
        message: Error message
        status_code: HTTP status code (if applicable)
        error_code: API error code (if returned)
        request_id: Request ID for debugging
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.request_id = request_id

    def __repr__(self) -> str:
        parts = [f"APIError({self.message!r}"]
        if self.status_code:
            parts.append(f", status_code={self.status_code}")
        if self.error_code:
            parts.append(f", error_code={self.error_code!r}")
        if self.request_id:
            parts.append(f", request_id={self.request_id!r}")
        parts.append(")")
        return "".join(parts)


class AuthenticationError(APIError):
    """Authentication failed.
    
    Raised when API key is invalid or missing.
    """


class NotFoundError(APIError):
    """Resource not found.
    
    Raised when a sandbox, volume, or other resource doesn't exist.
    """


class RateLimitError(APIError):
    """Rate limit exceeded.
    
    Raised when too many requests are made. Check headers for retry-after.
    """


class ConflictError(APIError):
    """Conflict error.
    
    Raised on duplicate names or conflicting operations.
    """


class ValidationError(APIError):
    """Validation error.
    
    Raised when request parameters are invalid.
    """


class TimeoutError(SandboxError):
    """Request timed out.
    
    Raised when an operation takes too long.
    """


class WebSocketError(SandboxError):
    """WebSocket connection error.
    
    Raised when WebSocket connection fails.
    """


class ProcessError(SandboxError):
    """Process execution error.
    
    Raised when a command fails to execute.
    """

    def __init__(
        self,
        message: str,
        *,
        exit_code: Optional[int] = None,
        stdout: Optional[str] = None,
        stderr: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr


# Backward compatibility aliases
PlatformSDKError = SandboxError
