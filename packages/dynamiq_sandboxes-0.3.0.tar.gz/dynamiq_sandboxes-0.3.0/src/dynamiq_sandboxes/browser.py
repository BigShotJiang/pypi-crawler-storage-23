from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import APIClient
from .sandbox import Sandbox


class ProxyConfig:
    """Proxy configuration for browser sessions.
    
    Supports HTTP, HTTPS, and SOCKS5 proxies with optional authentication.
    
    Example:
        >>> proxy = ProxyConfig(
        ...     server="http://proxy.example.com:8080",
        ...     username="user",
        ...     password="pass"
        ... )
        >>> browser = Browser.create(proxy=proxy)
    """
    
    def __init__(
        self,
        server: str,
        *,
        username: Optional[str] = None,
        password: Optional[str] = None,
        bypass: Optional[List[str]] = None,
    ) -> None:
        """
        Args:
            server: Proxy server URL (e.g., "http://proxy:8080", "socks5://proxy:1080")
            username: Proxy authentication username (optional)
            password: Proxy authentication password (optional)
            bypass: List of domains to bypass proxy (optional)
        """
        self.server = server
        self.username = username
        self.password = password
        self.bypass = bypass or []
    
    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {"server": self.server}
        if self.username:
            result["username"] = self.username
        if self.password:
            result["password"] = self.password
        if self.bypass:
            result["bypass"] = self.bypass
        return result


class ExtensionConfig:
    """Browser extension configuration.
    
    Supports loading extensions from URLs (CRX files) or local paths.
    
    Example:
        >>> ext = ExtensionConfig(
        ...     url="https://example.com/extension.crx",
        ...     enabled=True
        ... )
        >>> browser = Browser.create(extensions=[ext])
    """
    
    def __init__(
        self,
        *,
        url: Optional[str] = None,
        path: Optional[str] = None,
        id: Optional[str] = None,
        enabled: bool = True,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Args:
            url: URL to download extension CRX file
            path: Local path to unpacked extension directory
            id: Extension ID (for managing existing extensions)
            enabled: Whether the extension is enabled (default: True)
            config: Extension-specific configuration (optional)
        """
        if not url and not path and not id:
            raise ValueError("Must provide url, path, or id for extension")
        self.url = url
        self.path = path
        self.id = id
        self.enabled = enabled
        self.config = config or {}
    
    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {"enabled": self.enabled}
        if self.url:
            result["url"] = self.url
        if self.path:
            result["path"] = self.path
        if self.id:
            result["id"] = self.id
        if self.config:
            result["config"] = self.config
        return result


class CaptchaSolverConfig:
    """Captcha solver configuration.
    
    Integrate with captcha solving services like 2Captcha, Anti-Captcha, etc.
    
    Example:
        >>> solver = CaptchaSolverConfig(
        ...     provider="2captcha",
        ...     api_key="your-api-key"
        ... )
        >>> browser = Browser.create(captcha_solver=solver)
    """
    
    def __init__(
        self,
        provider: str,
        api_key: str,
        *,
        endpoint: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Args:
            provider: Captcha solver provider ("2captcha", "anticaptcha", "capmonster", "capsolver")
            api_key: API key for the captcha solving service
            endpoint: Custom API endpoint (optional, for self-hosted solutions)
            config: Provider-specific configuration (optional)
        """
        self.provider = provider
        self.api_key = api_key
        self.endpoint = endpoint
        self.config = config or {}
    
    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "provider": self.provider,
            "api_key": self.api_key,
        }
        if self.endpoint:
            result["endpoint"] = self.endpoint
        if self.config:
            result["config"] = self.config
        return result


class Browser(Sandbox):
    """Browser sandbox with full automation support.

    Extends Sandbox with browser-specific functionality including:
    - Screenshot capture
    - Page scraping
    - PDF generation
    - Context management (cookies, localStorage, sessionStorage)
    - Live view streaming
    - Console logs and network request monitoring
    - HAR export
    - File downloads and uploads
    - Custom proxy support (bring your own proxy)
    - Browser extensions
    - Captcha solver integration
    
    Example:
        >>> from dynamiq_sandboxes import Browser, ProxyConfig
        >>> 
        >>> # Simple browser session
        >>> browser = Browser.create()
        >>> browser.navigate("https://example.com")
        >>> screenshot = browser.screenshot()
        >>> browser.close()
        >>> 
        >>> # With proxy
        >>> browser = Browser.create(
        ...     proxy=ProxyConfig(
        ...         server="http://proxy.example.com:8080",
        ...         username="user",
        ...         password="pass"
        ...     )
        ... )
    """

    @classmethod
    def create(
        cls,
        *,
        template: str = "browser",
        timeout: int = 3600,
        idle_timeout: Optional[int] = 300,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 4096,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        # Proxy configuration (bring your own proxy)
        proxy: Optional[ProxyConfig | Dict[str, Any]] = None,
        # Browser extensions
        extensions: Optional[List[ExtensionConfig | Dict[str, Any]]] = None,
        # Captcha solver
        captcha_solver: Optional[CaptchaSolverConfig | Dict[str, Any]] = None,
        # Stealth mode
        stealth: bool = True,
        # Ad blocking
        block_ads: bool = False,
        # Session recording
        record_session: bool = False,
        # Viewport dimensions
        viewport_width: int = 1920,
        viewport_height: int = 1080,
        # User agent
        user_agent: Optional[str] = None,
        # Legacy browser_config (deprecated, use individual params)
        browser_config: Optional[Dict[str, Any]] = None,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Browser":
        """Create a new browser session.
        
        Args:
            template: Browser template to use (default: "browser-chromium")
            timeout: Session timeout in seconds (default: 3600)
            idle_timeout: Idle timeout in seconds (default: 300)
            name: Optional session name
            tags: Optional tags for the session
            vcpu: Number of vCPUs (default: 2)
            memory_mb: Memory in MB (default: 4096)
            disk_mb: Disk size in MB (optional)
            env_vars: Environment variables
            metadata: Custom metadata
            proxy: Proxy configuration (ProxyConfig or dict)
            extensions: List of browser extensions (ExtensionConfig or dict)
            captcha_solver: Captcha solver configuration
            stealth: Enable stealth mode to avoid detection (default: True)
            block_ads: Enable ad blocking (default: False)
            record_session: Enable session recording with rrweb (default: False)
            viewport_width: Browser viewport width (default: 1920)
            viewport_height: Browser viewport height (default: 1080)
            user_agent: Custom user agent string
            browser_config: Legacy browser config dict (deprecated)
            client: API client instance
            api_key: API key
            base_url: API base URL
            
        Returns:
            Browser instance
        """
        # Build browser config from individual parameters
        config: Dict[str, Any] = browser_config.copy() if browser_config else {}
        
        # Proxy
        if proxy:
            config["proxy"] = proxy.to_dict() if isinstance(proxy, ProxyConfig) else proxy
        
        # Extensions
        if extensions:
            config["extensions"] = [
                ext.to_dict() if isinstance(ext, ExtensionConfig) else ext
                for ext in extensions
            ]
        
        # Captcha solver
        if captcha_solver:
            config["captcha_solver"] = (
                captcha_solver.to_dict() 
                if isinstance(captcha_solver, CaptchaSolverConfig) 
                else captcha_solver
            )
        
        # Other options
        config["stealth"] = stealth
        config["block_ads"] = block_ads
        config["record_session"] = record_session
        config["dimensions"] = {
            "width": viewport_width,
            "height": viewport_height,
        }
        if user_agent:
            config["user_agent"] = user_agent
        
        sandbox = Sandbox.create(
            template=template,
            timeout=timeout,
            idle_timeout=idle_timeout,
            name=name,
            tags=tags,
            vcpu=vcpu,
            memory_mb=memory_mb,
            disk_mb=disk_mb,
            env_vars=env_vars,
            metadata=metadata,
            sandbox_type="browser",
            browser_config=config,
            client=client,
            api_key=api_key,
            base_url=base_url,
        )
        return cls(
            sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data
        )

    @classmethod
    def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Browser":
        sandbox = Sandbox.get(
            sandbox_id, client=client, api_key=api_key, base_url=base_url
        )
        return cls(
            sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data
        )

    def _browser_path(self, endpoint: str) -> str:
        """Construct browser session API path."""
        return f"browser/sessions/{self._id}/{endpoint}"

    # =========================================================================
    # Screenshot, Scrape, and PDF
    # =========================================================================

    def screenshot(
        self,
        *,
        format: str = "png",
        full_page: bool = False,
        quality: Optional[int] = None,
        selector: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Capture a screenshot of the browser viewport or element.

        Args:
            format: Image format - "png", "jpeg", or "webp".
                Defaults to "png".
            full_page: If True, captures the entire scrollable page.
                Defaults to False.
            quality: Image quality (1-100) for jpeg/webp formats.
                Optional.
            selector: CSS selector to screenshot a specific element,
                or URL to navigate to before capturing. Optional.

        Returns:
            Dict containing:
                - image: Base64-encoded image data with data URI prefix
                - width: Image width in pixels
                - height: Image height in pixels
                - format: Image format used
        """
        payload: Dict[str, Any] = {"format": format}
        if full_page:
            payload["full_page"] = full_page
        if quality is not None:
            payload["quality"] = quality
        if selector is not None:
            payload["selector"] = selector
        return self._client.post(
            self._browser_path("screenshot"), json=payload
        )

    def scrape(
        self,
        *,
        format: str = "text",
        wait_for: Optional[str] = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Scrape page content as text or HTML.

        Args:
            format: Content format - "text" or "html". Defaults to "text".
            wait_for: CSS selector to wait for before scraping, or URL
                to navigate to. Optional.
            timeout: Maximum time to wait in seconds. Defaults to 30.

        Returns:
            Dict containing:
                - content: Scraped page content (text or HTML)
                - url: Current page URL
                - title: Page title
        """
        payload: Dict[str, Any] = {"format": format, "timeout": timeout}
        if wait_for is not None:
            payload["wait_for"] = wait_for
        return self._client.post(
            self._browser_path("scrape"),
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    def pdf(
        self,
        *,
        format: str = "A4",
        landscape: bool = False,
        print_background: bool = True,
        margin: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Generate a PDF of the current page.

        Args:
            format: Paper size - "A4", "Letter", etc. Defaults to "A4".
            landscape: If True, use landscape orientation.
                Defaults to False.
            print_background: If True, include background graphics.
                Defaults to True.
            margin: Page margins with keys "top", "bottom", "left", "right".
                Values should be CSS length strings (e.g., "1cm", "0.5in").

        Returns:
            Dict containing the PDF data or binary PDF content.
        """
        payload: Dict[str, Any] = {
            "format": format,
            "landscape": landscape,
            "print_background": print_background,
        }
        if margin is not None:
            payload["margin"] = margin
        return self._client.post(self._browser_path("pdf"), json=payload)

    # =========================================================================
    # Context Management (cookies, localStorage, sessionStorage)
    # =========================================================================

    def get_context(self) -> Dict[str, Any]:
        """Get the browser context including cookies and storage.

        Returns:
            Dict containing:
                - cookies: List of cookie objects with name, value,
                    and other attributes
                - local_storage: Dict mapping origins to their
                    localStorage key-value pairs
                - session_storage: Dict mapping origins to their
                    sessionStorage key-value pairs
        """
        return self._client.get(self._browser_path("context"))

    def set_context(
        self,
        context: Dict[str, Any],
        *,
        merge: bool = True,
    ) -> Dict[str, Any]:
        """Set or update the browser context (cookies, storage).

        Args:
            context: Dict containing any of:
                - cookies: List of cookie objects with name, value,
                    and optional attributes
                - local_storage: Dict mapping origins to their
                    localStorage key-value pairs
                - session_storage: Dict mapping origins to their
                    sessionStorage key-value pairs
            merge: If True, merge with existing context. If False,
                replace entirely. Defaults to True.

        Returns:
            Dict containing:
                - success: Boolean indicating if the update succeeded
        """
        payload = {**context, "merge": merge}
        return self._client.put(self._browser_path("context"), json=payload)

    # =========================================================================
    # Live View
    # =========================================================================

    def get_live_view(self, *, interactive: bool = True) -> Dict[str, Any]:
        """Get live view streaming information for the browser session.

        Args:
            interactive: If True, enables interactive mode
                (mouse/keyboard input). Defaults to True.

        Returns:
            Dict containing:
                - session_id: Browser session ID
                - stream_url: WebSocket URL for live streaming
                - running: Boolean indicating if browser is running
                - interactive: Boolean if interactive mode is enabled
                - dimensions: Dict with width and height of the viewport
                - pages: List of open browser pages/tabs
        """
        params: Dict[str, Any] = {"interactive": interactive}
        return self._client.get(self._browser_path("live"), params=params)

    # =========================================================================
    # Logs and Network Monitoring
    # =========================================================================

    def get_logs(
        self,
        *,
        level: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get browser console logs.

        Args:
            level: Filter by log level - "info", "warn", "error", etc.
                Optional.
            since: ISO 8601 timestamp to get logs after. Optional.
            limit: Maximum number of logs to return. Defaults to 100.

        Returns:
            List of log entries, each containing:
                - timestamp: ISO 8601 timestamp
                - level: Log level (info, warn, error, etc.)
                - message: Log message text
                - source: Source URL (if available)
                - line: Line number (if available)
                - column: Column number (if available)
        """
        params: Dict[str, Any] = {"limit": limit}
        if level is not None:
            params["level"] = level
        if since is not None:
            params["since"] = since
        response = self._client.get(self._browser_path("logs"), params=params)
        if isinstance(response, dict):
            return response.get("logs", [])
        return response

    def get_network_requests(
        self,
        *,
        status: Optional[int] = None,
        method: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get captured network requests from the browser session.

        Args:
            status: Filter by HTTP status code. Optional.
            method: Filter by HTTP method (GET, POST, etc.). Optional.
            limit: Maximum number of requests to return. Defaults to 100.

        Returns:
            List of network request entries, each containing:
                - request_id: Unique request identifier
                - timestamp: ISO 8601 timestamp
                - method: HTTP method
                - url: Request URL
                - status: HTTP response status code
                - Additional request/response details
        """
        params: Dict[str, Any] = {"limit": limit}
        if status is not None:
            params["status"] = str(status)
        if method is not None:
            params["method"] = method
        response = self._client.get(
            self._browser_path("network"), params=params
        )
        if isinstance(response, dict):
            return response.get("requests", [])
        return response

    # =========================================================================
    # HAR Export
    # =========================================================================

    def export_har(self) -> Dict[str, Any]:
        """Export browser network activity as HAR (HTTP Archive) format.

        Returns:
            Dict containing:
                - log: HAR log object with version, creator, entries,
                    and other HAR fields
        """
        return self._client.get(self._browser_path("har"))

    # =========================================================================
    # Downloads
    # =========================================================================

    def list_downloads(self) -> List[Dict[str, Any]]:
        """List all files downloaded during the browser session.

        Returns:
            List of download entries, each containing:
                - id: Download identifier
                - filename: Downloaded file name
                - size_bytes: File size in bytes
                - status: Download status (e.g., "complete")
                - url: URL to retrieve the file
                - created_at: ISO 8601 timestamp
        """
        response = self._client.get(self._browser_path("downloads"))
        if isinstance(response, dict):
            return response.get("downloads", [])
        return response

    def get_download(self, download_id: str) -> Dict[str, Any]:
        """Get details about a specific download.

        Args:
            download_id: Download identifier or filename.

        Returns:
            Dict containing download details:
                - id: Download identifier
                - filename: Downloaded file name
                - size_bytes: File size in bytes
                - status: Download status
                - url: URL to retrieve the file
                - created_at: ISO 8601 timestamp
        """
        return self._client.get(
            self._browser_path(f"downloads/{download_id}")
        )

    # =========================================================================
    # File Upload
    # =========================================================================

    def upload_file(
        self,
        file_path: str,
        *,
        filename: Optional[str] = None,
        content: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """Upload a file to the browser session for use with file inputs.

        This method supports two modes:
        1. Read from local file: Provide file_path pointing to a local file
        2. Provide content directly: Pass content as bytes

        Args:
            file_path: Path to the local file to upload, or desired path
                in the session.
            filename: Override filename for the upload. Optional.
            content: File content as bytes. If provided, file_path is used
                as the target filename only. Optional.

        Returns:
            Dict containing:
                - local_path: Path where file is stored in browser session
                - filename: Uploaded filename
                - size_bytes: File size in bytes
        """
        import base64
        import os

        if content is None:
            # Read from local file
            with open(file_path, "rb") as f:
                content = f.read()
            if filename is None:
                filename = os.path.basename(file_path)
        else:
            if filename is None:
                if file_path:
                    filename = os.path.basename(file_path)
                else:
                    filename = "upload.bin"

        # Use base64 upload endpoint for simpler handling
        payload = {
            "filename": filename,
            "content": base64.b64encode(content).decode("utf-8"),
        }
        return self._client.post(
            self._browser_path("uploads/base64"), json=payload
        )

    # =========================================================================
    # Session Recording (rrweb)
    # =========================================================================
    #
    # Recording is enabled by passing `record_session=True` in browser_config
    # when creating a browser session via Browser.create().
    #
    # Example:
    #     browser = Browser.create(
    #         browser_config={"record_session": True}
    #     )

    def get_recording(self) -> Dict[str, Any]:
        """Get the current session recording status and metadata.

        Note: Recording must be enabled when creating the browser session
        by passing `record_session=True` in the browser_config.

        Returns:
            Dict containing:
                - recording_id: Unique recording identifier
                - session_id: Browser session ID
                - status: Recording status ("idle", "recording", "ready", etc.)
                - duration_ms: Recording duration in milliseconds
                - event_count: Number of recorded events
                - size_bytes: Recording size in bytes
                - download_url: URL to download the recording (if available)
                - replay_url: URL to replay the recording (if available)
                - created_at: When the recording was created
                - finished_at: When the recording finished (if applicable)
        """
        return self._client.get(self._browser_path("recording"))

    def get_recording_events(
        self,
        *,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Get recorded rrweb events for session replay.

        Note: Recording must be enabled when creating the browser session
        by passing `record_session=True` in the browser_config.

        Args:
            start_time: Filter events after this timestamp (milliseconds).
                Optional.
            end_time: Filter events before this timestamp (milliseconds).
                Optional.

        Returns:
            Dict containing:
                - events: List of rrweb event objects, each with:
                    - type: Event type (0-5 for different rrweb event types)
                    - data: Event-specific data
                    - timestamp: Event timestamp in milliseconds
        """
        params: Dict[str, Any] = {}
        if start_time is not None:
            params["start_time"] = start_time
        if end_time is not None:
            params["end_time"] = end_time
        return self._client.get(
            self._browser_path("recording/events"), params=params
        )

    # =========================================================================
    # Navigation
    # =========================================================================

    def navigate(
        self,
        url: str,
        *,
        wait_until: str = "load",
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Navigate the browser to a URL.

        Args:
            url: URL to navigate to.
            wait_until: Navigation wait condition - "load", "domcontentloaded",
                "networkidle". Defaults to "load".
            timeout: Maximum time to wait in seconds. Defaults to 30.

        Returns:
            Dict containing:
                - url: Final URL after any redirects
                - status: HTTP status code
                - title: Page title
        """
        payload: Dict[str, Any] = {
            "action": "navigate",
            "url": url,
            "options": {"wait_until": wait_until, "timeout": timeout},
        }
        try:
            result = self._client.post(
                self._browser_path("navigate"),
                json=payload,
                timeout=timeout + 5,
            )
            if isinstance(result, dict):
                return result.get("result", result)
            return {"url": url, "final_url": url}
        except Exception:
            # Navigation may succeed at the browser level even if the agent's
            # internal wait times out. Return the URL so callers can proceed.
            return {"url": url, "final_url": url}

    def go_back(self) -> Dict[str, Any]:
        """Navigate back in browser history."""
        result = self._client.post(
            self._browser_path("navigate"),
            json={"action": "back"},
        )
        return result if isinstance(result, dict) else {}

    def go_forward(self) -> Dict[str, Any]:
        """Navigate forward in browser history."""
        result = self._client.post(
            self._browser_path("navigate"),
            json={"action": "forward"},
        )
        return result if isinstance(result, dict) else {}

    def reload(self) -> Dict[str, Any]:
        """Reload the current page."""
        result = self._client.post(
            self._browser_path("navigate"),
            json={"action": "reload"},
        )
        return result if isinstance(result, dict) else {}

    def get_current_url(self) -> str:
        """Get the current page URL.
        
        Uses JavaScript execution to retrieve the URL since there's
        no dedicated endpoint for this.
        """
        result = self.execute_script("() => window.location.href")
        return result if isinstance(result, str) else ""

    # =========================================================================
    # Script Execution
    # =========================================================================

    def execute_script(
        self,
        script: str,
        *,
        args: Optional[List[Any]] = None,
    ) -> Any:
        """Execute JavaScript in the browser context.

        Args:
            script: JavaScript code to execute.
            args: Optional arguments to pass to the script.

        Returns:
            The return value of the script.
        """
        payload: Dict[str, Any] = {"script": script}
        if args:
            payload["args"] = args
        response = self._client.post(
            self._browser_path("execute"), json=payload
        )
        return response.get("result")

    # =========================================================================
    # Extensions Management
    # =========================================================================

    def list_extensions(self) -> List[Dict[str, Any]]:
        """List installed browser extensions.

        Returns:
            List of extension info dicts, each containing:
                - id: Extension ID
                - name: Extension name
                - version: Extension version
                - enabled: Whether extension is enabled
                - permissions: List of permissions
        """
        response = self._client.get(self._browser_path("extensions"))
        if isinstance(response, dict):
            return response.get("extensions", [])
        return response

    def install_extension(
        self,
        *,
        url: Optional[str] = None,
        path: Optional[str] = None,
        crx_data: Optional[bytes] = None,
    ) -> Dict[str, Any]:
        """Install a browser extension.

        Provide one of: url, path, or crx_data.

        Args:
            url: URL to download CRX file from.
            path: Path to unpacked extension directory.
            crx_data: Raw CRX file content as bytes.

        Returns:
            Dict containing:
                - id: Installed extension ID
                - name: Extension name
                - version: Extension version
        """
        import base64

        payload: Dict[str, Any] = {}
        if url:
            payload["url"] = url
        elif path:
            payload["path"] = path
        elif crx_data:
            payload["crx_data"] = base64.b64encode(crx_data).decode("utf-8")
        else:
            raise ValueError("Must provide url, path, or crx_data")

        return self._client.post(
            self._browser_path("extensions"), json=payload
        )

    def uninstall_extension(self, extension_id: str) -> Dict[str, Any]:
        """Uninstall a browser extension.

        Args:
            extension_id: ID of the extension to uninstall.

        Returns:
            Dict containing success status.
        """
        return self._client.delete(
            self._browser_path(f"extensions/{extension_id}")
        )

    def enable_extension(self, extension_id: str) -> Dict[str, Any]:
        """Enable a browser extension.

        Args:
            extension_id: ID of the extension to enable.

        Returns:
            Dict containing updated extension info.
        """
        return self._client.post(
            self._browser_path(f"extensions/{extension_id}/enable")
        )

    def disable_extension(self, extension_id: str) -> Dict[str, Any]:
        """Disable a browser extension.

        Args:
            extension_id: ID of the extension to disable.

        Returns:
            Dict containing updated extension info.
        """
        return self._client.post(
            self._browser_path(f"extensions/{extension_id}/disable")
        )

    # =========================================================================
    # Proxy Management
    # =========================================================================

    def get_proxy(self) -> Optional[Dict[str, Any]]:
        """Get the current proxy configuration.

        Returns:
            Dict containing proxy config or None if no proxy is set.
        """
        response = self._client.get(self._browser_path("proxy"))
        return response.get("proxy")

    def set_proxy(
        self,
        proxy: ProxyConfig | Dict[str, Any],
    ) -> Dict[str, Any]:
        """Set or update the proxy configuration.

        Args:
            proxy: ProxyConfig instance or dict with proxy settings.

        Returns:
            Dict containing success status.
        """
        payload = proxy.to_dict() if isinstance(proxy, ProxyConfig) else proxy
        return self._client.put(
            self._browser_path("proxy"), json=payload
        )

    def clear_proxy(self) -> Dict[str, Any]:
        """Clear the proxy configuration (use direct connection).

        Returns:
            Dict containing success status.
        """
        return self._client.delete(self._browser_path("proxy"))

    # =========================================================================
    # Captcha Solving
    # =========================================================================

    def solve_captcha(
        self,
        *,
        captcha_type: str = "auto",
        selector: Optional[str] = None,
        timeout: int = 120,
    ) -> Dict[str, Any]:
        """Solve a captcha on the current page.

        Requires captcha_solver to be configured when creating the browser.

        Args:
            captcha_type: Type of captcha - "auto", "recaptcha_v2",
                "recaptcha_v3", "hcaptcha", "funcaptcha", "turnstile".
                Defaults to "auto" (auto-detect).
            selector: CSS selector for the captcha element. Optional.
            timeout: Maximum time to wait for solution in seconds.
                Defaults to 120.

        Returns:
            Dict containing:
                - success: Whether captcha was solved
                - captcha_type: Detected captcha type
                - token: Solution token (if applicable)
                - cost_credits: Credits used for solving
        """
        payload: Dict[str, Any] = {
            "captcha_type": captcha_type,
            "timeout": timeout,
        }
        if selector:
            payload["selector"] = selector

        return self._client.post(
            self._browser_path("captcha/solve"),
            json=payload,
            timeout=timeout + 10,
        )

    # =========================================================================
    # Live Streaming (LiveKit WebRTC)
    # =========================================================================

    def start_stream(self, *, recording: bool = True) -> Dict[str, Any]:
        """Start live streaming for this browser session.

        Starts the GStreamer capture pipeline and LiveKit WebRTC publishing.

        Args:
            recording: Whether to also record the session (default True).

        Returns:
            Dict with stream info: streaming, recording, livekit, room_name, etc.
        """
        return self._client.post(
            self._browser_path("stream"),
            json={"recording": recording},
        )

    def stop_stream(self) -> Dict[str, Any]:
        """Stop live streaming for this browser session.

        Returns:
            Dict with status.
        """
        return self._client.delete(self._browser_path("stream"))

    def get_stream_info(self) -> Dict[str, Any]:
        """Get current stream information.

        Returns:
            Dict with streaming status, LiveKit room info, dimensions.
        """
        return self._client.get(self._browser_path("stream"))

    # =========================================================================
    # Input Events
    # =========================================================================

    def send_input(
        self,
        *,
        type: str,
        x: Optional[float] = None,
        y: Optional[float] = None,
        button: Optional[str] = None,
        key: Optional[str] = None,
        text: Optional[str] = None,
        selector: Optional[str] = None,
        coordinate_space: str = "native",
        scroll_delta: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send an input event to the browser session.

        Args:
            type: Event type - "click", "mousemove", "keypress", "type",
                "scroll", "element_click", "mousedown", "mouseup".
            x: X coordinate (for mouse events).
            y: Y coordinate (for mouse events).
            button: Mouse button - "left", "right", "middle".
            key: Key name (for keyboard events, e.g., "Enter", "a").
            text: Text to type (for "type" events).
            selector: CSS selector (for "element_click" events).
            coordinate_space: "native" or "client" (default "native").
            scroll_delta: Scroll amount (positive=up, negative=down).

        Returns:
            Dict with status.
        """
        payload: Dict[str, Any] = {"type": type, "coordinate_space": coordinate_space, "source": "agent"}
        if x is not None:
            payload["x"] = x
        if y is not None:
            payload["y"] = y
        if button:
            payload["button"] = button
        if key:
            payload["key"] = key
        if text:
            payload["text"] = text
        if selector:
            payload["selector"] = selector
        if scroll_delta is not None:
            payload["scroll_delta"] = scroll_delta

        return self._client.post(self._browser_path("input"), json=payload)

    # =========================================================================
    # Control Mode
    # =========================================================================

    def get_control_mode(self) -> Dict[str, Any]:
        """Get the current control mode for the session.

        Returns:
            Dict with mode ("idle", "agent_only", "user_only", "shared")
            and activity info.
        """
        return self._client.get(self._browser_path("control-mode"))

    def set_control_mode(self, mode: str) -> Dict[str, Any]:
        """Set the control mode for the session.

        Args:
            mode: "agent_only", "user_only", "shared", or "idle".

        Returns:
            Dict with updated mode info.
        """
        return self._client.put(
            self._browser_path("control-mode"),
            json={"mode": mode},
        )
