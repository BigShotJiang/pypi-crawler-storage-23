from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import APIClient
from .sandbox import Sandbox


class Desktop(Sandbox):
    """Desktop sandbox convenience wrapper."""

    @classmethod
    def create(
        cls,
        *,
        template: str = "desktop-xfce",
        timeout: int = 3600,
        idle_timeout: Optional[int] = None,
        name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        vcpu: int = 2,
        memory_mb: int = 4096,
        disk_mb: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        desktop_config: Optional[Dict[str, Any]] = None,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Desktop":
        sandbox = Sandbox.create(
            template=template,
            timeout=timeout,
            idle_timeout=idle_timeout,
            name=name,
            tags=tags,
            vcpu=vcpu,
            memory_mb=memory_mb,
            disk_mb=disk_mb,
            env_vars=env_vars,
            metadata=metadata,
            sandbox_type="desktop",
            desktop_config=desktop_config,
            client=client,
            api_key=api_key,
            base_url=base_url,
        )
        return cls(sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data)

    @classmethod
    def get(
        cls,
        sandbox_id: str,
        *,
        client: Optional[APIClient] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "Desktop":
        sandbox = Sandbox.get(sandbox_id, client=client, api_key=api_key, base_url=base_url)
        return cls(sandbox_id=sandbox.id, client=sandbox._client, data=sandbox.data)

    def screenshot(
        self,
        *,
        format: Optional[str] = None,
        quality: Optional[int] = None,
        window_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if format:
            payload["format"] = format
        if quality is not None:
            payload["quality"] = quality
        if window_id is not None:
            payload["window_id"] = window_id
        return self._client.post(
            f"sandboxes/{self._id}/desktop/screenshot",
            json=payload,
        )

    def stream_start(
        self,
        *,
        window_id: Optional[int] = None,
        require_auth: Optional[bool] = None,
        quality: Optional[str] = None,
        frame_rate: Optional[int] = None,
        auto_connect: Optional[bool] = None,
        view_only: Optional[bool] = None,
        resize: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if window_id is not None:
            payload["window_id"] = window_id
        if require_auth is not None:
            payload["require_auth"] = require_auth
        if quality is not None:
            payload["quality"] = quality
        if frame_rate is not None:
            payload["frame_rate"] = frame_rate
        if auto_connect is not None:
            payload["auto_connect"] = auto_connect
        if view_only is not None:
            payload["view_only"] = view_only
        if resize is not None:
            payload["resize"] = resize
        return self._client.post(
            f"sandboxes/{self._id}/desktop/stream/start",
            json=payload,
            timeout=self._client.timeout_config.stream_connect,
        )

    def stream_stop(self) -> None:
        self._client.post(
            f"sandboxes/{self._id}/desktop/stream/stop",
            timeout=self._client.timeout_config.stream_connect,
        )

    def stream_info(
        self,
        *,
        auto_connect: Optional[bool] = None,
        view_only: Optional[bool] = None,
        resize: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if auto_connect is not None:
            params["auto_connect"] = auto_connect
        if view_only is not None:
            params["view_only"] = view_only
        if resize is not None:
            params["resize"] = resize
        return self._client.get(
            f"sandboxes/{self._id}/desktop/stream",
            params=params,
            timeout=self._client.timeout_config.stream_connect,
        )

    def mouse_click(
        self,
        *,
        x: int,
        y: int,
        button: Optional[str] = None,
        double_click: Optional[bool] = None,
        modifiers: Optional[List[str]] = None,
        screenshot: Optional[bool] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"x": x, "y": y}
        if button is not None:
            payload["button"] = button
        if double_click is not None:
            payload["double_click"] = double_click
        if modifiers is not None:
            payload["modifiers"] = modifiers
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return self._client.post(f"sandboxes/{self._id}/desktop/mouse/click", json=payload)

    def mouse_move(self, *, x: int, y: int) -> None:
        self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/move",
            json={"x": x, "y": y},
        )

    def mouse_scroll(self, *, x: int, y: int, delta_x: int, delta_y: int) -> None:
        self._client.post(
            f"sandboxes/{self._id}/desktop/mouse/scroll",
            json={"x": x, "y": y, "delta_x": delta_x, "delta_y": delta_y},
        )

    def mouse_drag(
        self,
        *,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int,
        button: Optional[str] = None,
    ) -> None:
        payload: Dict[str, Any] = {
            "start_x": start_x,
            "start_y": start_y,
            "end_x": end_x,
            "end_y": end_y,
        }
        if button is not None:
            payload["button"] = button
        self._client.post(f"sandboxes/{self._id}/desktop/mouse/drag", json=payload)

    def keyboard_type(self, *, text: str, screenshot: Optional[bool] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"text": text}
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return self._client.post(f"sandboxes/{self._id}/desktop/keyboard/type", json=payload)

    def keyboard_press(
        self,
        *,
        keys: List[str],
        duration_ms: Optional[int] = None,
        screenshot: Optional[bool] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"keys": keys}
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return self._client.post(f"sandboxes/{self._id}/desktop/keyboard/press", json=payload)

    def cursor(self) -> Dict[str, Any]:
        return self._client.get(f"sandboxes/{self._id}/desktop/cursor")

    def wait(self, *, duration_ms: int, screenshot: Optional[bool] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"duration_ms": duration_ms}
        if screenshot is not None:
            payload["screenshot"] = screenshot
        return self._client.post(f"sandboxes/{self._id}/desktop/wait", json=payload)

    def list_windows(self, *, visible_only: Optional[bool] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if visible_only is not None:
            params["visible_only"] = visible_only
        return self._client.get(f"sandboxes/{self._id}/desktop/windows", params=params)

    def current_window(self) -> Dict[str, Any]:
        return self._client.get(f"sandboxes/{self._id}/desktop/windows/current")

    def focus_window(self, window_id: int) -> None:
        self._client.post(f"sandboxes/{self._id}/desktop/windows/{window_id}/focus")

    def launch(
        self,
        *,
        application: str,
        args: Optional[List[str]] = None,
        wait_for_window: Optional[bool] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"application": application}
        if args is not None:
            payload["args"] = args
        if wait_for_window is not None:
            payload["wait_for_window"] = wait_for_window
        if timeout is not None:
            payload["timeout"] = timeout
        return self._client.post(f"sandboxes/{self._id}/desktop/launch", json=payload)

    def open(self, *, path: str) -> Dict[str, Any]:
        return self._client.post(f"sandboxes/{self._id}/desktop/open", json={"path": path})
