"""Sandbox snapshot management for saving and restoring sandbox state."""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .client import APIClient


@dataclass
class SnapshotInfo:
    """Information about a sandbox snapshot."""

    id: str
    name: str
    sandbox_id: str
    team_id: str
    state: str  # "pending", "creating", "ready", "restoring", "failed", "deleting"
    size_bytes: int
    description: Optional[str]
    created_at: str
    template_id: Optional[str]

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "SnapshotInfo":
        """Create SnapshotInfo from API response."""
        return cls(
            id=data.get("snapshot_id", data.get("id", "")),
            name=data.get("name", ""),
            sandbox_id=data.get("sandbox_id", ""),
            team_id=data.get("team_id", ""),
            state=data.get("state", data.get("status", "unknown")),
            size_bytes=data.get("size_bytes", 0),
            description=data.get("description"),
            created_at=data.get("created_at", ""),
            template_id=data.get("template_id"),
        )


class Snapshot:
    """Represents a sandbox snapshot for saving and restoring state.

    Snapshots capture the full state of a sandbox (VM memory, disk, configuration)
    and can be used to restore a sandbox to that exact state later.

    Example:
        >>> # Create a snapshot from a running sandbox
        >>> snapshot = Snapshot.create(
        ...     sandbox_id="sb_abc123",
        ...     name="my-checkpoint",
        ...     description="After installing dependencies"
        ... )
        >>>
        >>> # List snapshots
        >>> snapshots = Snapshot.list()
        >>> for s in snapshots:
        ...     print(s.name, s.state)
        >>>
        >>> # Restore a sandbox from a snapshot
        >>> snapshot.restore()
        >>>
        >>> # Delete a snapshot
        >>> snapshot.delete()
    """

    def __init__(
        self,
        snapshot_id: str,
        client: "APIClient",
        team_id: str = "",
        _data: Optional[Dict[str, Any]] = None,
    ):
        self._id = snapshot_id
        self._client = client
        self._team_id = team_id
        self._data = _data or {}

    @property
    def id(self) -> str:
        """Get the snapshot ID."""
        return self._id

    @property
    def name(self) -> str:
        """Get the snapshot name."""
        return self._data.get("name", "")

    @property
    def state(self) -> str:
        """Get the snapshot state."""
        return self._data.get("state", self._data.get("status", "unknown"))

    @property
    def sandbox_id(self) -> str:
        """Get the source sandbox ID."""
        return self._data.get("sandbox_id", "")

    @property
    def size_bytes(self) -> int:
        """Get the snapshot size in bytes."""
        return self._data.get("size_bytes", 0)

    @property
    def created_at(self) -> str:
        """Get the creation timestamp."""
        return self._data.get("created_at", "")

    @property
    def description(self) -> Optional[str]:
        """Get the snapshot description."""
        return self._data.get("description")

    # --- Class methods for CRUD operations ---

    @classmethod
    def create(
        cls,
        sandbox_id: str,
        name: str,
        description: Optional[str] = None,
        client: Optional["APIClient"] = None,
        team_id: Optional[str] = None,
    ) -> "Snapshot":
        """Create a new snapshot from a running sandbox.

        Args:
            sandbox_id: The sandbox ID to snapshot.
            name: A name for the snapshot.
            description: Optional description.
            client: API client (uses default if not provided).
            team_id: Team/organization ID.

        Returns:
            The created Snapshot object.
        """
        if client is None:
            from .client import APIClient
            client = APIClient()

        team = team_id or ""
        payload: Dict[str, Any] = {
            "sandbox_id": sandbox_id,
            "name": name,
        }
        if description:
            payload["description"] = description

        data = client.post(
            f"/organizations/{team}/snapshots",
            json=payload,
        )
        return cls(
            snapshot_id=data.get("snapshot_id", data.get("id", "")),
            client=client,
            team_id=team,
            _data=data,
        )

    @classmethod
    def get(
        cls,
        snapshot_id: str,
        client: Optional["APIClient"] = None,
        team_id: Optional[str] = None,
    ) -> "Snapshot":
        """Get a snapshot by ID.

        Args:
            snapshot_id: The snapshot ID.
            client: API client (uses default if not provided).
            team_id: Team/organization ID.

        Returns:
            The Snapshot object.
        """
        if client is None:
            from .client import APIClient
            client = APIClient()

        team = team_id or ""
        data = client.get(f"/organizations/{team}/snapshots/{snapshot_id}")
        return cls(
            snapshot_id=snapshot_id,
            client=client,
            team_id=team,
            _data=data,
        )

    @classmethod
    def list(
        cls,
        client: Optional["APIClient"] = None,
        team_id: Optional[str] = None,
    ) -> List["Snapshot"]:
        """List all snapshots.

        Args:
            client: API client (uses default if not provided).
            team_id: Team/organization ID.

        Returns:
            List of Snapshot objects.
        """
        if client is None:
            from .client import APIClient
            client = APIClient()

        team = team_id or ""
        data = client.get(f"/organizations/{team}/snapshots")
        snapshots_data = data.get("data", data) if isinstance(data, dict) else data
        if not isinstance(snapshots_data, list):
            snapshots_data = []

        return [
            cls(
                snapshot_id=s.get("snapshot_id", s.get("id", "")),
                client=client,
                team_id=team,
                _data=s,
            )
            for s in snapshots_data
        ]

    def refresh(self) -> "Snapshot":
        """Refresh snapshot data from the API."""
        self._data = self._client.get(
            f"/organizations/{self._team_id}/snapshots/{self._id}"
        )
        return self

    def delete(self) -> None:
        """Delete this snapshot."""
        self._client.delete(
            f"/organizations/{self._team_id}/snapshots/{self._id}"
        )

    def restore(self, target_sandbox_id: Optional[str] = None) -> Dict[str, Any]:
        """Restore a sandbox from this snapshot.

        Args:
            target_sandbox_id: Optional sandbox ID to restore into.
                If not provided, creates a new sandbox.

        Returns:
            The restored sandbox data.
        """
        payload: Dict[str, Any] = {}
        if target_sandbox_id:
            payload["sandbox_id"] = target_sandbox_id

        return self._client.post(
            f"/organizations/{self._team_id}/snapshots/{self._id}/restore",
            json=payload,
        )

    def info(self) -> SnapshotInfo:
        """Get snapshot information as a dataclass."""
        return SnapshotInfo.from_api_response(self._data)

    def __repr__(self) -> str:
        return f"Snapshot(id={self._id!r}, name={self.name!r}, state={self.state!r})"
