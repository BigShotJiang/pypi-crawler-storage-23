"""WebSocket streaming support for real-time process I/O and file watching."""

from __future__ import annotations

import base64
import json
import signal
import threading
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

try:
    import websocket
except ImportError:
    websocket = None  # type: ignore

from .exceptions import PlatformSDKError

if TYPE_CHECKING:
    from .client import APIClient


# Signal name to number mapping
SIGNAL_MAP: Dict[str, int] = {
    "SIGHUP": signal.SIGHUP,
    "SIGINT": signal.SIGINT,
    "SIGQUIT": signal.SIGQUIT,
    "SIGTERM": signal.SIGTERM,
    "SIGKILL": signal.SIGKILL,
    "SIGUSR1": signal.SIGUSR1,
    "SIGUSR2": signal.SIGUSR2,
}


class WebSocketError(PlatformSDKError):
    """WebSocket connection or communication error."""


class ProcessStream:
    """WebSocket client for streaming process I/O.
    
    Provides real-time stdin/stdout/stderr streaming for processes running
    in a sandbox. Supports PTY mode for interactive terminal sessions.
    
    Example:
        with ProcessStream(sandbox_id, client) as stream:
            stream.on_stdout(lambda data: print(data, end=""))
            stream.on_stderr(lambda data: print(data, end="", file=sys.stderr))
            stream.on_exit(lambda code: print(f"Exited: {code}"))
            
            pid = stream.start_process("bash", tty=True)
            stream.send_stdin("ls -la\\n")
    """
    
    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        """Initialize ProcessStream.
        
        Args:
            sandbox_id: The sandbox ID to connect to.
            client: The API client with authentication credentials.
        """
        if websocket is None:
            raise ImportError(
                "websocket-client is required for streaming. "
                "Install it with: pip install websocket-client"
            )
        
        self._sandbox_id = sandbox_id
        self._client = client
        self._ws: Optional[websocket.WebSocket] = None
        self._connected = False
        self._pid: Optional[int] = None
        self._exit_code: Optional[int] = None
        
        # Callbacks
        self._on_stdout: Optional[Callable[[str], None]] = None
        self._on_stderr: Optional[Callable[[str], None]] = None
        self._on_exit: Optional[Callable[[int], None]] = None
        self._on_error: Optional[Callable[[str], None]] = None
        self._on_started: Optional[Callable[[int], None]] = None
        
        # Reader thread
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
    
    @property
    def connected(self) -> bool:
        """Whether the WebSocket is connected."""
        return self._connected
    
    @property
    def pid(self) -> Optional[int]:
        """The process ID, if a process has been started."""
        return self._pid
    
    @property
    def exit_code(self) -> Optional[int]:
        """The process exit code, if the process has exited."""
        return self._exit_code
    
    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for process streaming."""
        # Convert HTTP base URL to WebSocket URL
        base_url = self._client._base_url
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url
        
        # Build the endpoint URL with authentication
        url = f"{ws_base}/sandboxes/{self._sandbox_id}/process/stream"
        
        # Add API key as query parameter (common for WebSocket)
        headers = self._client._client.headers
        api_key = headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"
        
        return url
    
    def connect(self) -> None:
        """Connect to the WebSocket endpoint.
        
        Raises:
            WebSocketError: If connection fails.
        """
        if self._connected:
            return
        
        try:
            url = self._get_ws_url()
            self._ws = websocket.create_connection(
                url,
                timeout=30,
                skip_utf8_validation=True,
            )
            self._connected = True
            self._stop_event.clear()
            
            # Start reader thread
            self._reader_thread = threading.Thread(
                target=self._read_loop,
                daemon=True,
            )
            self._reader_thread.start()
        except Exception as e:
            self._connected = False
            raise WebSocketError(f"Failed to connect: {e}") from e
    
    def disconnect(self) -> None:
        """Disconnect from the WebSocket endpoint."""
        self._stop_event.set()
        
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        
        self._connected = False
        
        # Wait for reader thread to finish
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
    
    def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise WebSocketError("Not connected")
        
        with self._lock:
            self._ws.send(json.dumps(msg))
    
    def _read_loop(self) -> None:
        """Background thread that reads messages from the WebSocket."""
        while not self._stop_event.is_set() and self._ws:
            try:
                # Set a short timeout so we can check stop_event
                self._ws.settimeout(1.0)
                data = self._ws.recv()
                
                if not data:
                    continue
                
                msg = json.loads(data)
                self._handle_message(msg)
                
            except websocket.WebSocketTimeoutException:
                continue
            except websocket.WebSocketConnectionClosedException:
                self._connected = False
                break
            except Exception as e:
                if self._on_error:
                    self._on_error(str(e))
                break
    
    def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming WebSocket message."""
        msg_type = msg.get("type")
        
        if msg_type == "started":
            self._pid = msg.get("pid")
            if self._on_started:
                self._on_started(self._pid)
        
        elif msg_type == "stdout":
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            if self._on_stdout:
                self._on_stdout(data)
        
        elif msg_type == "stderr":
            data_b64 = msg.get("data", "")
            try:
                decoded = base64.b64decode(data_b64)
                data = decoded.decode("utf-8", errors="replace")
            except Exception:
                data = data_b64
            if self._on_stderr:
                self._on_stderr(data)
        
        elif msg_type == "exit":
            self._exit_code = msg.get("code", -1)
            if self._on_exit:
                self._on_exit(self._exit_code)
        
        elif msg_type == "error":
            error_msg = msg.get("data", "Unknown error")
            try:
                decoded = base64.b64decode(error_msg)
                error_msg = decoded.decode("utf-8", errors="replace")
            except Exception:
                pass
            if self._on_error:
                self._on_error(error_msg)
    
    def start_process(
        self,
        cmd: str,
        args: Optional[List[str]] = None,
        *,
        env: Optional[Dict[str, str]] = None,
        working_dir: Optional[str] = None,
        tty: bool = False,
        rows: int = 24,
        cols: int = 80,
    ) -> str:
        """Start a process and stream its I/O.
        
        Args:
            cmd: The command to execute.
            args: Command arguments.
            env: Environment variables.
            working_dir: Working directory for the process.
            tty: Whether to allocate a PTY.
            rows: Terminal rows (only used if tty=True).
            cols: Terminal columns (only used if tty=True).
        
        Returns:
            A request ID (the PID will be returned via on_started callback).
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        if not self._connected:
            self.connect()
        
        msg: Dict[str, Any] = {
            "type": "start",
            "command": cmd,
        }
        
        if args:
            msg["args"] = args
        if env:
            msg["env"] = env
        if working_dir:
            msg["working_dir"] = working_dir
        if tty:
            msg["tty"] = True
            msg["rows"] = rows
            msg["cols"] = cols
        
        self._send_message(msg)
        return f"process-{self._sandbox_id}"
    
    def send_stdin(self, data: str) -> None:
        """Send data to the process's stdin.
        
        Args:
            data: The string data to send.
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        encoded = base64.b64encode(data.encode("utf-8")).decode("ascii")
        self._send_message({
            "type": "stdin",
            "data": encoded,
        })
    
    def send_stdin_bytes(self, data: bytes) -> None:
        """Send raw bytes to the process's stdin.
        
        Args:
            data: The bytes to send.
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        encoded = base64.b64encode(data).decode("ascii")
        self._send_message({
            "type": "stdin",
            "data": encoded,
        })
    
    def resize_terminal(self, rows: int, cols: int) -> None:
        """Resize the terminal (only valid for PTY processes).
        
        Args:
            rows: New number of rows.
            cols: New number of columns.
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        self._send_message({
            "type": "resize",
            "rows": rows,
            "cols": cols,
        })
    
    def kill_process(self, sig: str = "SIGTERM") -> None:
        """Send a signal to the process.
        
        Args:
            sig: Signal name (e.g., "SIGTERM", "SIGKILL", "SIGINT").
        
        Raises:
            WebSocketError: If not connected or send fails.
            ValueError: If signal name is invalid.
        """
        sig_num = SIGNAL_MAP.get(sig.upper())
        if sig_num is None:
            raise ValueError(f"Unknown signal: {sig}")
        
        self._send_message({
            "type": "signal",
            "signal": sig_num,
        })
    
    def on_stdout(self, callback: Callable[[str], None]) -> None:
        """Register a callback for stdout data.
        
        Args:
            callback: Function called with decoded stdout string.
        """
        self._on_stdout = callback
    
    def on_stderr(self, callback: Callable[[str], None]) -> None:
        """Register a callback for stderr data.
        
        Args:
            callback: Function called with decoded stderr string.
        """
        self._on_stderr = callback
    
    def on_exit(self, callback: Callable[[int], None]) -> None:
        """Register a callback for process exit.
        
        Args:
            callback: Function called with exit code.
        """
        self._on_exit = callback
    
    def on_error(self, callback: Callable[[str], None]) -> None:
        """Register a callback for errors.
        
        Args:
            callback: Function called with error message.
        """
        self._on_error = callback
    
    def on_started(self, callback: Callable[[int], None]) -> None:
        """Register a callback for when the process starts.
        
        Args:
            callback: Function called with the process ID.
        """
        self._on_started = callback
    
    def wait_for_exit(self, timeout: Optional[float] = None) -> Optional[int]:
        """Wait for the process to exit.
        
        Args:
            timeout: Maximum time to wait in seconds. None means wait forever.
        
        Returns:
            The exit code, or None if timeout occurred.
        """
        import time
        
        start = time.time()
        while self._exit_code is None:
            if timeout is not None and (time.time() - start) >= timeout:
                return None
            time.sleep(0.1)
        
        return self._exit_code
    
    def __enter__(self) -> "ProcessStream":
        """Context manager entry - connects to the WebSocket."""
        self.connect()
        return self
    
    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Context manager exit - disconnects from the WebSocket."""
        self.disconnect()


class FileWatcher:
    """WebSocket client for watching file changes in a sandbox.
    
    Monitors files and directories for create, modify, and delete events.
    
    Example:
        def on_change(event_type: str, path: str):
            print(f"{event_type}: {path}")
        
        with FileWatcher(sandbox_id, client) as watcher:
            watcher.watch("/workspace", on_change)
            time.sleep(60)  # Watch for 60 seconds
    """
    
    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        """Initialize FileWatcher.
        
        Args:
            sandbox_id: The sandbox ID to connect to.
            client: The API client with authentication credentials.
        """
        if websocket is None:
            raise ImportError(
                "websocket-client is required for file watching. "
                "Install it with: pip install websocket-client"
            )
        
        self._sandbox_id = sandbox_id
        self._client = client
        self._ws: Optional[websocket.WebSocket] = None
        self._connected = False
        
        # Callbacks by path
        self._callbacks: Dict[str, Callable[[str, str], None]] = {}
        self._global_callback: Optional[Callable[[str, str], None]] = None
        
        # Reader thread
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
    
    @property
    def connected(self) -> bool:
        """Whether the WebSocket is connected."""
        return self._connected
    
    def _get_ws_url(self) -> str:
        """Build the WebSocket URL for file watching."""
        base_url = self._client._base_url
        if base_url.startswith("https://"):
            ws_base = "wss://" + base_url[8:]
        elif base_url.startswith("http://"):
            ws_base = "ws://" + base_url[7:]
        else:
            ws_base = base_url
        
        url = f"{ws_base}/sandboxes/{self._sandbox_id}/files/watch"
        
        headers = self._client._client.headers
        api_key = headers.get("X-API-Key")
        if api_key:
            url += f"?api_key={api_key}"
        
        return url
    
    def connect(self) -> None:
        """Connect to the WebSocket endpoint.
        
        Raises:
            WebSocketError: If connection fails.
        """
        if self._connected:
            return
        
        try:
            url = self._get_ws_url()
            self._ws = websocket.create_connection(
                url,
                timeout=30,
                skip_utf8_validation=True,
            )
            self._connected = True
            self._stop_event.clear()
            
            # Start reader thread
            self._reader_thread = threading.Thread(
                target=self._read_loop,
                daemon=True,
            )
            self._reader_thread.start()
        except Exception as e:
            self._connected = False
            raise WebSocketError(f"Failed to connect: {e}") from e
    
    def disconnect(self) -> None:
        """Disconnect from the WebSocket endpoint."""
        self._stop_event.set()
        
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        
        self._connected = False
        
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
    
    def _send_message(self, msg: Dict[str, Any]) -> None:
        """Send a JSON message through the WebSocket."""
        if not self._ws or not self._connected:
            raise WebSocketError("Not connected")
        
        with self._lock:
            self._ws.send(json.dumps(msg))
    
    def _read_loop(self) -> None:
        """Background thread that reads messages from the WebSocket."""
        while not self._stop_event.is_set() and self._ws:
            try:
                self._ws.settimeout(1.0)
                data = self._ws.recv()
                
                if not data:
                    continue
                
                msg = json.loads(data)
                self._handle_message(msg)
                
            except websocket.WebSocketTimeoutException:
                continue
            except websocket.WebSocketConnectionClosedException:
                self._connected = False
                break
            except Exception:
                break
    
    def _handle_message(self, msg: Dict[str, Any]) -> None:
        """Handle an incoming file event message."""
        event_type = msg.get("type")  # "created", "modified", "deleted"
        path = msg.get("path", "")
        
        if not event_type or event_type in ("watch", "unwatch", "error"):
            return
        
        # Call global callback
        if self._global_callback:
            try:
                self._global_callback(event_type, path)
            except Exception:
                pass
        
        # Call path-specific callbacks
        for watch_path, callback in self._callbacks.items():
            if path.startswith(watch_path):
                try:
                    callback(event_type, path)
                except Exception:
                    pass
    
    def watch(
        self,
        path: str,
        on_change: Callable[[str, str], None],
        *,
        recursive: bool = True,
    ) -> None:
        """Start watching a path for changes.
        
        Args:
            path: The path to watch (file or directory).
            on_change: Callback function(event_type, file_path) for changes.
                event_type is "created", "modified", or "deleted".
            recursive: Whether to watch subdirectories recursively.
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        if not self._connected:
            self.connect()
        
        self._callbacks[path] = on_change
        
        self._send_message({
            "type": "watch",
            "path": path,
            "recursive": recursive,
        })
    
    def unwatch(self, path: str) -> None:
        """Stop watching a path.
        
        Args:
            path: The path to stop watching.
        
        Raises:
            WebSocketError: If not connected or send fails.
        """
        self._callbacks.pop(path, None)
        
        if self._connected:
            self._send_message({
                "type": "unwatch",
                "path": path,
            })
    
    def on_any_change(self, callback: Callable[[str, str], None]) -> None:
        """Register a callback for all file changes.
        
        Args:
            callback: Function called with (event_type, path) for any change.
        """
        self._global_callback = callback
    
    def __enter__(self) -> "FileWatcher":
        """Context manager entry - connects to the WebSocket."""
        self.connect()
        return self
    
    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        """Context manager exit - disconnects from the WebSocket."""
        self.disconnect()
