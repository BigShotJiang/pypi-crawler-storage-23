"""
Dynamiq Sandboxes - Python SDK

Secure code execution, browser automation, and virtual desktops.

Example:
    >>> from dynamiq_sandboxes import Sandbox
    >>> sandbox = Sandbox.create(template="python")
    >>> result = sandbox.execute("print('Hello!')")
    >>> print(result.stdout)
    Hello!
    >>> sandbox.close()

For browser automation:
    >>> from dynamiq_sandboxes import Browser
    >>> browser = Browser.create()
    >>> browser.navigate("https://example.com")
    >>> screenshot = browser.screenshot()
    >>> browser.close()

For virtual desktops:
    >>> from dynamiq_sandboxes import Desktop
    >>> desktop = Desktop.create()
    >>> desktop.launch("firefox")
    >>> desktop.write("Hello World")
    >>> desktop.close()
"""

__version__ = "0.3.0"

from .browser import Browser
from .desktop import Desktop
from .exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    SandboxError,
    TimeoutError,
    ValidationError,
)
from .filesystem import FileInfo, Filesystem
from .interpreter import CodeInterpreter, InterpreterError, InterpreterResult
from .process import Process, ProcessManager, ProcessResult
from .pty import PTY, PTYError, PTYManager
from .sandbox import ALL_TRAFFIC, NetworkConfig, Sandbox
from .stream import FileWatcher, ProcessStream, WebSocketError
from .snapshot import Snapshot, SnapshotInfo
from .template import Template, TemplateBuilder, TemplateInfo
from .volume import Volume, VolumeInfo, VolumeManager

# Async variants
from .async_sdk import (
    AsyncAPIClient,
    AsyncBrowser,
    AsyncDesktop,
    AsyncFileWatcher,
    AsyncFilesystem,
    AsyncProcessManager,
    AsyncProcessStream,
    AsyncSandbox,
)

__all__ = [
    # Version
    "__version__",
    # Constants
    "ALL_TRAFFIC",
    # Sync classes
    "Browser",
    "CodeInterpreter",
    "Desktop",
    "FileInfo",
    "FileWatcher",
    "Filesystem",
    "InterpreterError",
    "InterpreterResult",
    "NetworkConfig",
    "Process",
    "ProcessManager",
    "ProcessResult",
    "ProcessStream",
    "PTY",
    "PTYError",
    "PTYManager",
    "Sandbox",
    "Snapshot",
    "SnapshotInfo",
    "Template",
    "TemplateBuilder",
    "TemplateInfo",
    "Volume",
    "VolumeInfo",
    "VolumeManager",
    "WebSocketError",
    # Exceptions
    "APIError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "SandboxError",
    "TimeoutError",
    "ValidationError",
    # Async classes
    "AsyncAPIClient",
    "AsyncBrowser",
    "AsyncDesktop",
    "AsyncFileWatcher",
    "AsyncFilesystem",
    "AsyncProcessManager",
    "AsyncProcessStream",
    "AsyncSandbox",
]
