"""Filesystem API for sandbox file operations."""
from __future__ import annotations

import base64
import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, List, Optional, Union

if TYPE_CHECKING:
    from .client import APIClient


@dataclass
class FileInfo:
    """Information about a file or directory entry."""

    name: str
    path: str
    type: str  # "file" or "directory"
    size: int
    modified_at: Optional[str] = None

    @classmethod
    def from_api_response(cls, entry: dict, parent_path: str) -> "FileInfo":
        """Create FileInfo from API response entry."""
        name = entry.get("name", "")
        entry_type = entry.get("type", "file")
        size = entry.get("size", 0) if entry_type == "file" else 0
        modified_at = entry.get("modified_at")

        # Construct full path
        if parent_path == "/":
            path = f"/{name}"
        else:
            path = f"{parent_path.rstrip('/')}/{name}"

        return cls(
            name=name,
            path=path,
            type=entry_type,
            size=size,
            modified_at=modified_at,
        )


class Filesystem:
    """Filesystem API for sandbox file operations.

    Provides methods for reading, writing, listing, and managing files
    within a sandbox environment.

    Example:
        >>> sandbox = Sandbox.create(template="base")
        >>> fs = sandbox.filesystem
        >>> fs.write("/workspace/hello.txt", "Hello, World!")
        >>> content = fs.read("/workspace/hello.txt")
        >>> print(content)
        Hello, World!
    """

    def __init__(self, sandbox_id: str, client: "APIClient") -> None:
        """Initialize the Filesystem interface.

        Args:
            sandbox_id: The ID of the sandbox to operate on.
            client: The API client for making requests.
        """
        self._sandbox_id = sandbox_id
        self._client = client

    def _encode_path(self, path: str) -> str:
        """Encode a file path for use in API requests.

        Strips leading slash and double-encodes for nginx compatibility.
        """
        from .client import APIClient
        clean_path = path.lstrip("/")
        return APIClient.encode_file_path(clean_path)

    def _execute_command(
        self,
        command: str,
        args: Optional[List[str]] = None,
        timeout: Optional[int] = None,
    ) -> dict:
        """Execute a shell command in the sandbox.

        Args:
            command: The command to execute.
            args: Optional list of arguments.
            timeout: Optional timeout in seconds.

        Returns:
            Command execution result dictionary.
        """
        payload: dict = {"command": command}
        if args is not None:
            payload["args"] = args
        if timeout is not None:
            payload["timeout"] = timeout
        return self._client.post(
            f"sandboxes/{self._sandbox_id}/commands",
            json=payload,
            timeout=self._client.timeout_config.process_execution,
        )

    def read(self, path: str) -> str:
        """Read a file and return its contents as a string.

        Args:
            path: Absolute path to the file in the sandbox.

        Returns:
            The file contents as a UTF-8 string.

        Raises:
            APIError: If the file cannot be read.
        """
        response = self._read_file_raw(path)
        content = response.get("content", "")
        encoding = response.get("encoding", "")

        # If the content is base64 encoded, decode it
        if encoding == "base64":
            return base64.b64decode(content).decode("utf-8")
        return content

    def read_bytes(self, path: str) -> bytes:
        """Read a file and return its contents as bytes.

        Args:
            path: Absolute path to the file in the sandbox.

        Returns:
            The file contents as bytes.

        Raises:
            APIError: If the file cannot be read.
        """
        response = self._read_file_raw(path)
        content = response.get("content", "")
        encoding = response.get("encoding", "")

        # If the content is base64 encoded, decode it
        if encoding == "base64":
            return base64.b64decode(content)
        return content.encode("utf-8")

    def _read_file_raw(self, path: str) -> dict:
        """Read a file and return the raw API response.

        Args:
            path: Absolute path to the file in the sandbox.

        Returns:
            Raw API response dictionary.
        """
        encoded_path = self._encode_path(path)
        return self._client.get(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            params={"type": "file"},
            timeout=self._client.timeout_config.file_download,
        )

    def write(self, path: str, content: Union[str, bytes]) -> None:
        """Write content to a file.

        Creates the file if it doesn't exist, overwrites if it does.
        Parent directories are created automatically by the sandbox agent.

        Args:
            path: Absolute path to the file in the sandbox.
            content: Content to write (string or bytes).

        Raises:
            APIError: If the file cannot be written.
        """
        encoded_path = self._encode_path(path)

        # Determine if we need base64 encoding
        if isinstance(content, bytes):
            payload = {
                "content": base64.b64encode(content).decode("ascii"),
                "encoding": "base64",
            }
        else:
            payload = {"content": content}

        self._client.put(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            json=payload,
            timeout=self._client.timeout_config.file_upload,
        )

    def list(self, path: str = "/") -> List[FileInfo]:
        """List contents of a directory.

        Args:
            path: Absolute path to the directory in the sandbox.
                  Defaults to root "/".

        Returns:
            List of FileInfo objects for each entry in the directory.

        Raises:
            APIError: If the directory cannot be listed.
        """
        encoded_path = self._encode_path(path)
        response = self._client.get(
            f"sandboxes/{self._sandbox_id}/files/{encoded_path}",
            params={"type": "directory"},
            timeout=self._client.timeout_config.file_download,
        )

        entries = response.get("entries", [])
        return [FileInfo.from_api_response(entry, path) for entry in entries]

    def mkdir(self, path: str, mode: str = "755") -> None:
        """Create a directory.

        Creates parent directories as needed (like mkdir -p).

        Args:
            path: Absolute path for the new directory.
            mode: Permission mode (default "755"). Currently informational.

        Raises:
            APIError: If the directory cannot be created.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        result = self._execute_command("mkdir", args=["-p", path])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            from .exceptions import APIError
            raise APIError(
                f"Failed to create directory '{path}': {stderr}",
                status_code=500,
                error_code="MKDIR_FAILED",
            )

    def remove(self, path: str, recursive: bool = False) -> None:
        """Remove a file or directory.

        Args:
            path: Absolute path to the file or directory to remove.
            recursive: If True, remove directories and contents recursively.
                      Required for non-empty directories.

        Raises:
            APIError: If the file/directory cannot be removed.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        args = ["-f", path] if not recursive else ["-rf", path]
        result = self._execute_command("rm", args=args)
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            from .exceptions import APIError
            raise APIError(
                f"Failed to remove '{path}': {stderr}",
                status_code=500,
                error_code="REMOVE_FAILED",
            )

    def exists(self, path: str) -> bool:
        """Check if a file or directory exists.

        Args:
            path: Absolute path to check.

        Returns:
            True if the path exists, False otherwise.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        result = self._execute_command("test", args=["-e", path])
        return result.get("exit_code", -1) == 0

    def upload(self, local_path: str, remote_path: str) -> None:
        """Upload a local file to the sandbox.

        Args:
            local_path: Path to the local file to upload.
            remote_path: Destination path in the sandbox.

        Raises:
            FileNotFoundError: If the local file doesn't exist.
            APIError: If the upload fails.
        """
        if not os.path.exists(local_path):
            raise FileNotFoundError(f"Local file not found: {local_path}")

        with open(local_path, "rb") as f:
            content = f.read()

        self.write(remote_path, content)

    def download(self, remote_path: str, local_path: str) -> None:
        """Download a file from the sandbox to the local filesystem.

        Args:
            remote_path: Path to the file in the sandbox.
            local_path: Destination path on the local filesystem.

        Raises:
            APIError: If the download fails.
        """
        content = self.read_bytes(remote_path)

        # Ensure parent directory exists locally
        local_dir = os.path.dirname(local_path)
        if local_dir:
            os.makedirs(local_dir, exist_ok=True)

        with open(local_path, "wb") as f:
            f.write(content)

    def stat(self, path: str) -> FileInfo:
        """Get information about a file or directory.

        Args:
            path: Absolute path to the file or directory.

        Returns:
            FileInfo object with file/directory metadata.

        Raises:
            APIError: If the path doesn't exist or cannot be accessed.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        # Use stat command to get file info
        result = self._execute_command(
            "stat",
            args=["-c", "%F|%s|%Y", path],
        )

        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            from .exceptions import NotFoundError
            raise NotFoundError(f"Path not found: {path}")

        stdout = result.get("stdout", "").strip()
        parts = stdout.split("|")

        if len(parts) >= 3:
            file_type_raw = parts[0]
            size = int(parts[1]) if parts[1].isdigit() else 0
            mtime = parts[2]

            # Convert stat output to our type
            if "directory" in file_type_raw.lower():
                file_type = "directory"
            else:
                file_type = "file"

            return FileInfo(
                name=os.path.basename(path) or path,
                path=path,
                type=file_type,
                size=size,
                modified_at=mtime,
            )

        # Fallback if stat output is unexpected
        return FileInfo(
            name=os.path.basename(path) or path,
            path=path,
            type="file",
            size=0,
            modified_at=None,
        )

    def copy(self, src: str, dst: str) -> None:
        """Copy a file or directory within the sandbox.

        Args:
            src: Source path.
            dst: Destination path.

        Raises:
            APIError: If the copy operation fails.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        result = self._execute_command("cp", args=["-r", src, dst])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            from .exceptions import APIError
            raise APIError(
                f"Failed to copy '{src}' to '{dst}': {stderr}",
                status_code=500,
                error_code="COPY_FAILED",
            )

    def move(self, src: str, dst: str) -> None:
        """Move/rename a file or directory within the sandbox.

        Args:
            src: Source path.
            dst: Destination path.

        Raises:
            APIError: If the move operation fails.

        Note:
            Uses shell commands as there is no dedicated API endpoint.
        """
        result = self._execute_command("mv", args=[src, dst])
        exit_code = result.get("exit_code", -1)
        if exit_code != 0:
            stderr = result.get("stderr", "")
            from .exceptions import APIError
            raise APIError(
                f"Failed to move '{src}' to '{dst}': {stderr}",
                status_code=500,
                error_code="MOVE_FAILED",
            )
