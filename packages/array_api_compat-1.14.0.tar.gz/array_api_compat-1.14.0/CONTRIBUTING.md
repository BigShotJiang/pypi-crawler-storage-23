Contributions to array-api-compat are welcome, so long as they are [in
scope](https://data-apis.org/array-api-compat/index.html#scope).

Contributors are encouraged to read through the [development
notes](https://data-apis.org/array-api-compat/dev/index.html) for the package
to get full context on some of the design decisions and implementation
details used in the codebase.
