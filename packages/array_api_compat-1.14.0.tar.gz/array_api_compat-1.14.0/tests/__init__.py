"""
Basic tests for the compat library

This only tests basic things like that vendoring works. The extensive tests
are done by the array API test suite https://github.com/data-apis/array-api-tests

"""
