# Development Notes

This is internal documentation related to the development of array-api-compat.
It is recommended that contributors read through this documentation.

```{toctree}
:titlesonly:

special-considerations.md
implementation-notes.md
tests.md
releasing.md
```
