# emdash-web-tools-mcp

MCP server providing web search and fetch tools for the emdash CLI, powered by [Firecrawl](https://firecrawl.dev).

## Tools

### web_search

Search the web using Firecrawl's search API. Returns titles, URLs, and snippets. Optionally scrapes full markdown content from each result in a single call.

### web_fetch

Fetch URL content and convert to clean markdown using Firecrawl's scrape API. Handles:
- JavaScript-rendered pages
- Automatic HTTPS upgrade
- Redirect following
- Content truncation for large pages
- Link extraction

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `FIRECRAWL_API_KEY` | - | API key for Firecrawl (required) |
| `WEB_TOOLS_TIMEOUT` | 30 | Request timeout in seconds |
| `WEB_TOOLS_MAX_CONTENT` | 50000 | Max content length for fetch |

Get a Firecrawl API key at [firecrawl.dev](https://firecrawl.dev).

## Usage

The server runs over stdio and is typically started by the emdash CLI:

```bash
FIRECRAWL_API_KEY=fc-your-key emdash-web-tools-mcp
```

## Development

```bash
# Install with dev dependencies
uv pip install -e ".[dev]"

# Run tests
pytest
```
