"""Tests for the Items service client."""

from typing import Any
from unittest.mock import MagicMock

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.items import (
    # Schemas
    AlternateCode,
    Attribute,
    AttributeCreateParams,
    AttributeGroup,
    # Resources
    AttributeGroupAttributesResource,
    AttributeGroupCreateParams,
    AttributeGroupListParams,
    AttributeGroupsResource,
    AttributeGroupUpdateParams,
    AttributeListParams,
    AttributesResource,
    AttributeUpdateParams,
    AttributeValue,
    AttributeValueCreateParams,
    AttributeValueListParams,
    AttributeValuesResource,
    AttributeValueUpdateParams,
    AttributeXAttributeGroup,
    AttributeXAttributeGroupCreateParams,
    AttributeXAttributeGroupListParams,
    AttributeXAttributeGroupUpdateParams,
    Brands,
    BrandsCreateParams,
    BrandsItemsResource,
    BrandsListParams,
    BrandsResource,
    BrandsUpdateParams,
    BrandsXItems,
    BrandsXItemsCreateParams,
    BrandsXItemsListParams,
    BrandsXItemsUpdateParams,
    CategoriesResource,
    Category,
    CategoryAttribute,
    CategoryImage,
    CategoryItem,
    CategoryItemsParams,
    CategoryListParams,
    CategoryLookupParams,
    ContractsAttribute,
    ContractsItem,
    ContractsItemsListParams,
    ContractsResource,
    HealthCheckData,
    InternalResource,
    InvAccessory,
    InvBin,
    InvBinListParams,
    InvLoc,
    InvLocListParams,
    InvLocResource,
    InvMast,
    InvMastAttributesResource,
    InvMastAttributeValuesResource,
    InvMastBinsResource,
    InvMastDoc,
    InvMastFaq,
    InvMastFaqCreateParams,
    InvMastFaqListParams,
    InvMastFaqResource,
    InvMastFaqUpdateParams,
    InvMastLinks,
    InvMastLinksResource,
    InvMastListParams,
    InvMastLocationsResource,
    InvMastLookupParams,
    InvMastResource,
    InvMastSimilar,
    InvMastSubParts,
    InvMastSubPartsResource,
    InvMastUd,
    InvMastUdListParams,
    InvMastUdResource,
    InvSub,
    ItemAttribute,
    ItemAttributeCreateParams,
    ItemAttributeListParams,
    ItemAttributeValue,
    ItemAttributeValueCreateParams,
    ItemAttributeValueListParams,
    ItemAttributeValueUpdateParams,
    ItemCategory,
    ItemCategoryDoc,
    ItemCategoryListParams,
    ItemCategoryLookupParams,
    ItemCategoryResource,
    ItemFavorite,
    ItemFavoriteCreateParams,
    ItemFavoritesListParams,
    ItemFavoritesResource,
    ItemFavoriteUpdateParams,
    # Client
    ItemUom,
    ItemUomListParams,
    ItemUomResource,
    ItemWishlist,
    ItemWishlistCreateParams,
    ItemWishlistLine,
    ItemWishlistLineCreateParams,
    ItemWishlistLineListParams,
    ItemWishlistLinesResource,
    ItemWishlistListParams,
    ItemWishlistResource,
    ItemWishlistUpdateParams,
    LocationBin,
    LocationBinsResource,
    LocationsResource,
    P21InvMast,
    P21InvMastListParams,
    P21InvMastResource,
    PdfCreateParams,
    PdfResult,
    StockParams,
    StockSummary,
    Variant,
    VariantAttribute,
    VariantAttributeCreateParams,
    VariantAttributeListParams,
    VariantAttributesResource,
    VariantAttributeUpdateParams,
    VariantCreateParams,
    VariantLine,
    VariantLineCreateParams,
    VariantLineListParams,
    VariantLinesResource,
    VariantLineUpdateParams,
    VariantsListParams,
    VariantsResource,
    VariantUpdateParams,
)


def mock_response(data: Any) -> dict[str, Any]:
    """Create a mock API response with all required fields."""
    return {
        "count": 1 if not isinstance(data, list) else len(data),
        "data": data,
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1 if not isinstance(data, list) else len(data),
        "totalResults": 1 if not isinstance(data, list) else len(data),
    }


# =============================================================================
# Schema Tests
# =============================================================================


class TestHealthCheckDataSchema:
    """Tests for HealthCheckData schema."""

    def test_with_all_fields(self) -> None:
        """Test with all fields."""
        data = HealthCheckData(site_hash="abc123", site_id="SITE1")
        assert data.site_hash == "abc123"
        assert data.site_id == "SITE1"

    def test_with_none_values(self) -> None:
        """Test with None values."""
        data = HealthCheckData()
        assert data.site_hash is None
        assert data.site_id is None


class TestAttributeSchemas:
    """Tests for attribute schemas."""

    def test_attribute_list_params(self) -> None:
        """Test AttributeListParams."""
        params = AttributeListParams(limit=10, offset=20)
        assert params.limit == 10
        assert params.offset == 20

    def test_attribute_model(self) -> None:
        """Test Attribute model."""
        data = {"attributeUid": 1, "attributeName": "Color"}
        attr = Attribute.model_validate(data)
        assert attr.attribute_uid == 1

    def test_attribute_create_params(self) -> None:
        """Test AttributeCreateParams with extra fields."""
        params = AttributeCreateParams(attribute_name="Size", data_type="string")
        assert params.attribute_name == "Size"

    def test_attribute_update_params(self) -> None:
        """Test AttributeUpdateParams."""
        params = AttributeUpdateParams(attribute_name="Updated")
        assert params.attribute_name == "Updated"


class TestAttributeValueSchemas:
    """Tests for attribute value schemas."""

    def test_attribute_value_list_params(self) -> None:
        """Test AttributeValueListParams."""
        params = AttributeValueListParams(limit=5)
        assert params.limit == 5

    def test_attribute_value_model(self) -> None:
        """Test AttributeValue model."""
        data = {"attributeValueUid": 1, "value": "Red"}
        val = AttributeValue.model_validate(data)
        assert val.attribute_value_uid == 1

    def test_attribute_value_create_params(self) -> None:
        """Test AttributeValueCreateParams."""
        params = AttributeValueCreateParams(value="Blue")
        assert params.value == "Blue"

    def test_attribute_value_update_params(self) -> None:
        """Test AttributeValueUpdateParams."""
        params = AttributeValueUpdateParams(value="Green")
        assert params.value == "Green"


class TestAttributeGroupSchemas:
    """Tests for attribute group schemas."""

    def test_attribute_group_list_params(self) -> None:
        """Test AttributeGroupListParams."""
        params = AttributeGroupListParams(limit=10, offset=0)
        assert params.limit == 10

    def test_attribute_group_model(self) -> None:
        """Test AttributeGroup model."""
        data = {"attributeGroupUid": 1, "groupName": "Dimensions"}
        group = AttributeGroup.model_validate(data)
        assert group.attribute_group_uid == 1

    def test_attribute_group_create_params(self) -> None:
        """Test AttributeGroupCreateParams."""
        params = AttributeGroupCreateParams(group_name="Size")
        assert params.group_name == "Size"

    def test_attribute_group_update_params(self) -> None:
        """Test AttributeGroupUpdateParams."""
        params = AttributeGroupUpdateParams(group_name="Updated")
        assert params.group_name == "Updated"


class TestAttributeXAttributeGroupSchemas:
    """Tests for attribute x attribute group schemas."""

    def test_list_params(self) -> None:
        """Test list params."""
        params = AttributeXAttributeGroupListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test model."""
        data = {"attributeXAttributeGroupUid": 1}
        obj = AttributeXAttributeGroup.model_validate(data)
        assert obj.attribute_x_attribute_group_uid == 1

    def test_create_params(self) -> None:
        """Test create params."""
        params = AttributeXAttributeGroupCreateParams(attribute_uid=1)
        assert params.attribute_uid == 1

    def test_update_params(self) -> None:
        """Test update params."""
        params = AttributeXAttributeGroupUpdateParams(display_order=5)
        assert params.display_order == 5


class TestBrandsSchemas:
    """Tests for brands schemas."""

    def test_brands_list_params(self) -> None:
        """Test BrandsListParams."""
        params = BrandsListParams(limit=20, offset=10)
        assert params.limit == 20

    def test_brands_model(self) -> None:
        """Test Brands model."""
        data = {"brandsUid": 1, "brandName": "Acme"}
        brand = Brands.model_validate(data)
        assert brand.brands_uid == 1

    def test_brands_create_params(self) -> None:
        """Test BrandsCreateParams."""
        params = BrandsCreateParams(brand_name="NewBrand")
        assert params.brand_name == "NewBrand"

    def test_brands_update_params(self) -> None:
        """Test BrandsUpdateParams."""
        params = BrandsUpdateParams(brand_name="Updated")
        assert params.brand_name == "Updated"


class TestBrandsXItemsSchemas:
    """Tests for brands x items schemas."""

    def test_list_params(self) -> None:
        """Test list params."""
        params = BrandsXItemsListParams(limit=10)
        assert params.limit == 10

    def test_list_params_variant_filter(self) -> None:
        """Test list params with variant_filter."""
        params = BrandsXItemsListParams(variant_filter="active")
        assert params.variant_filter == "active"

    def test_model(self) -> None:
        """Test model."""
        data = {"brandsXItemsUid": 1}
        obj = BrandsXItems.model_validate(data)
        assert obj.brands_x_items_uid == 1

    def test_create_params(self) -> None:
        """Test create params."""
        params = BrandsXItemsCreateParams(inv_mast_uid=100)
        assert params.inv_mast_uid == 100

    def test_update_params(self) -> None:
        """Test update params."""
        params = BrandsXItemsUpdateParams(primary_flag="Y")
        assert params.primary_flag == "Y"


class TestCategorySchemas:
    """Tests for category schemas."""

    def test_category_list_params(self) -> None:
        """Test CategoryListParams."""
        params = CategoryListParams(limit=10, offset=0)
        assert params.limit == 10

    def test_category_items_params_variant_filter(self) -> None:
        """Test CategoryItemsParams with variant_filter."""
        params = CategoryItemsParams(variant_filter="active")
        assert params.variant_filter == "active"

    def test_category_lookup_params(self) -> None:
        """Test CategoryLookupParams."""
        params = CategoryLookupParams(cache_ttl=300, path="/path", root_item_category_id="CAT001")
        assert params.cache_ttl == 300
        assert params.path == "/path"
        assert params.root_item_category_id == "CAT001"

    def test_category_model(self) -> None:
        """Test Category model."""
        data = {"itemCategoryUid": 1, "categoryName": "Electronics"}
        cat = Category.model_validate(data)
        assert cat.item_category_uid == 1

    def test_category_attribute_model(self) -> None:
        """Test CategoryAttribute model (passthrough)."""
        data = {"attributeUid": 1}
        obj = CategoryAttribute.model_validate(data)
        assert obj is not None

    def test_category_image_model(self) -> None:
        """Test CategoryImage model (passthrough)."""
        data = {"imageUrl": "http://example.com/img.jpg"}
        obj = CategoryImage.model_validate(data)
        assert obj is not None

    def test_category_item_model(self) -> None:
        """Test CategoryItem model (passthrough)."""
        data = {"invMastUid": 1}
        obj = CategoryItem.model_validate(data)
        assert obj is not None


class TestContractsSchemas:
    """Tests for contracts schemas."""

    def test_contracts_items_list_params(self) -> None:
        """Test ContractsItemsListParams."""
        params = ContractsItemsListParams(limit=10)
        assert params.limit == 10

    def test_contracts_items_list_params_variant_filter(self) -> None:
        """Test ContractsItemsListParams with variant_filter."""
        params = ContractsItemsListParams(variant_filter="active")
        assert params.variant_filter == "active"

    def test_contracts_item_model(self) -> None:
        """Test ContractsItem model (passthrough)."""
        data = {"invMastUid": 1, "jobNo": "JOB001"}
        obj = ContractsItem.model_validate(data)
        assert obj is not None

    def test_contracts_attribute_model(self) -> None:
        """Test ContractsAttribute model (passthrough)."""
        data = {"attributeUid": 1}
        obj = ContractsAttribute.model_validate(data)
        assert obj is not None


class TestInvBinSchemas:
    """Tests for inventory bin schemas."""

    def test_inv_bin_list_params(self) -> None:
        """Test InvBinListParams."""
        params = InvBinListParams(limit=10)
        assert params.limit == 10

    def test_inv_bin_model(self) -> None:
        """Test InvBin model."""
        data = {"bin": "A1", "locationId": 100}
        obj = InvBin.model_validate(data)
        assert obj.bin == "A1"


class TestInvLocSchemas:
    """Tests for inventory location schemas."""

    def test_inv_loc_list_params(self) -> None:
        """Test InvLocListParams."""
        params = InvLocListParams(limit=10, inv_mast_uid=100)
        assert params.inv_mast_uid == 100
        assert params.limit == 10

    def test_inv_loc_model(self) -> None:
        """Test InvLoc model (passthrough)."""
        data = {"locationId": 100, "qtyOnHand": 50}
        obj = InvLoc.model_validate(data)
        assert obj is not None


class TestInvMastSchemas:
    """Tests for inventory master schemas."""

    def test_inv_mast_list_params(self) -> None:
        """Should create params with all fields."""
        params = InvMastListParams(
            limit=10,
            offset=20,
            q="search",
            item_category_uid=5,
            online_cd=1,
            prefix="ITEM",
            status_cd=1,
        )
        assert params.limit == 10
        assert params.offset == 20
        assert params.q == "search"
        assert params.item_category_uid == 5
        assert params.online_cd == 1
        assert params.prefix == "ITEM"
        assert params.status_cd == 1

    def test_inv_mast_list_params_defaults(self) -> None:
        """Should have None defaults."""
        params = InvMastListParams()
        assert params.limit is None
        assert params.offset is None
        assert params.q is None

    def test_inv_mast_lookup_params(self) -> None:
        """Should create lookup params."""
        params = InvMastLookupParams(q="search", online_cd=1, order_by="item_id")
        assert params.q == "search"
        assert params.online_cd == 1
        assert params.order_by == "item_id"

    def test_stock_params(self) -> None:
        """Should create stock params (no query params per API spec)."""
        params = StockParams()
        assert params is not None

    def test_inv_mast_model(self) -> None:
        """Should parse inventory master data."""
        data = {
            "invMastUid": 1,
            "itemId": "ITEM001",
            "itemDesc": "Test Item",
            "extendedDesc": "Extended description",
        }
        item = InvMast.model_validate(data)
        assert item.inv_mast_uid == 1

    def test_inv_mast_doc_model(self) -> None:
        """Test InvMastDoc model."""
        data = {"invMastUid": 1, "document": "doc"}
        obj = InvMastDoc.model_validate(data)
        assert obj.document == "doc"

    def test_stock_summary_model(self) -> None:
        """Should parse stock summary data (passthrough)."""
        data = {
            "invMastUid": 1,
            "locationId": 100,
            "qtyOnHand": 50.0,
            "qtyAvailable": 45.0,
        }
        stock = StockSummary.model_validate(data)
        assert stock is not None

    def test_alternate_code_model(self) -> None:
        """Should parse alternate code data (passthrough)."""
        data = {
            "alternateCodeUid": 1,
            "invMastUid": 100,
            "alternateCode": "ALT001",
            "codeType": "UPC",
        }
        code = AlternateCode.model_validate(data)
        assert code is not None

    def test_inv_accessory_model(self) -> None:
        """Test InvAccessory model (passthrough)."""
        data = {"accessoryInvMastUid": 1}
        obj = InvAccessory.model_validate(data)
        assert obj is not None

    def test_inv_sub_model(self) -> None:
        """Test InvSub model (passthrough)."""
        data = {"substituteInvMastUid": 1}
        obj = InvSub.model_validate(data)
        assert obj is not None

    def test_inv_mast_similar_model(self) -> None:
        """Test InvMastSimilar model (passthrough)."""
        data = {"similarInvMastUid": 1}
        obj = InvMastSimilar.model_validate(data)
        assert obj is not None

    def test_inv_mast_links_model(self) -> None:
        """Test InvMastLinks model (passthrough)."""
        data = {"linkUrl": "http://example.com"}
        obj = InvMastLinks.model_validate(data)
        assert obj is not None

    def test_inv_mast_sub_parts_model(self) -> None:
        """Test InvMastSubParts model (passthrough)."""
        data = {"subPartInvMastUid": 1}
        obj = InvMastSubParts.model_validate(data)
        assert obj is not None


class TestInvMastFaqSchemas:
    """Tests for inventory master FAQ schemas."""

    def test_faq_list_params(self) -> None:
        """Test InvMastFaqListParams."""
        params = InvMastFaqListParams(limit=10)
        assert params.limit == 10

    def test_faq_model(self) -> None:
        """Test InvMastFaq model."""
        data = {"invMastFaqUid": 1, "question": "Q?", "answer": "A"}
        faq = InvMastFaq.model_validate(data)
        assert faq.inv_mast_faq_uid == 1

    def test_faq_create_params(self) -> None:
        """Test InvMastFaqCreateParams."""
        params = InvMastFaqCreateParams(question="Q?", answer="A")
        assert params.question == "Q?"

    def test_faq_update_params(self) -> None:
        """Test InvMastFaqUpdateParams."""
        params = InvMastFaqUpdateParams(answer="Updated")
        assert params.answer == "Updated"


class TestInvMastUdSchemas:
    """Tests for inventory master UD schemas."""

    def test_ud_list_params(self) -> None:
        """Test InvMastUdListParams."""
        params = InvMastUdListParams(limit=10)
        assert params.limit == 10

    def test_ud_model(self) -> None:
        """Test InvMastUd model (passthrough)."""
        data = {"invMastUid": 1, "customField": "value"}
        ud = InvMastUd.model_validate(data)
        assert ud is not None


class TestItemAttributeValueSchemas:
    """Tests for item attribute value schemas."""

    def test_list_params(self) -> None:
        """Test ItemAttributeValueListParams."""
        params = ItemAttributeValueListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemAttributeValue model (passthrough)."""
        data = {"attributeValue": "Red"}
        obj = ItemAttributeValue.model_validate(data)
        assert obj is not None

    def test_create_params(self) -> None:
        """Test ItemAttributeValueCreateParams."""
        params = ItemAttributeValueCreateParams(attribute_value="Blue")
        assert params.attribute_value == "Blue"

    def test_update_params(self) -> None:
        """Test ItemAttributeValueUpdateParams."""
        params = ItemAttributeValueUpdateParams(attribute_value="Green")
        assert params.attribute_value == "Green"


class TestItemAttributeSchemas:
    """Tests for item attribute schemas."""

    def test_list_params(self) -> None:
        """Test ItemAttributeListParams."""
        params = ItemAttributeListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemAttribute model (passthrough)."""
        data = {"attributeUid": 1}
        obj = ItemAttribute.model_validate(data)
        assert obj is not None

    def test_create_params(self) -> None:
        """Test ItemAttributeCreateParams."""
        params = ItemAttributeCreateParams(attribute_uid=1)
        assert params.attribute_uid == 1


class TestItemCategorySchemas:
    """Tests for item category schemas."""

    def test_list_params(self) -> None:
        """Test ItemCategoryListParams."""
        params = ItemCategoryListParams(limit=10)
        assert params.limit == 10

    def test_lookup_params(self) -> None:
        """Test ItemCategoryLookupParams."""
        params = ItemCategoryLookupParams(path="/path", root_item_category_id="CAT001")
        assert params.path == "/path"
        assert params.root_item_category_id == "CAT001"

    def test_model(self) -> None:
        """Test ItemCategory model."""
        data = {"itemCategoryUid": 1}
        obj = ItemCategory.model_validate(data)
        assert obj.item_category_uid == 1

    def test_doc_model(self) -> None:
        """Test ItemCategoryDoc model."""
        data = {"document": "doc"}
        obj = ItemCategoryDoc.model_validate(data)
        assert obj.document == "doc"


class TestItemFavoriteSchemas:
    """Tests for item favorites schemas."""

    def test_list_params(self) -> None:
        """Test ItemFavoritesListParams."""
        params = ItemFavoritesListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemFavorite model (passthrough)."""
        data = {"invMastUid": 1, "usersId": "user1"}
        obj = ItemFavorite.model_validate(data)
        assert obj is not None

    def test_create_params(self) -> None:
        """Test ItemFavoriteCreateParams."""
        params = ItemFavoriteCreateParams(inv_mast_uid=1)
        assert params.inv_mast_uid == 1

    def test_update_params(self) -> None:
        """Test ItemFavoriteUpdateParams."""
        params = ItemFavoriteUpdateParams(notes="Updated")
        assert params.notes == "Updated"


class TestItemUomSchemas:
    """Tests for item UOM schemas."""

    def test_list_params(self) -> None:
        """Test ItemUomListParams."""
        params = ItemUomListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemUom model."""
        data = {"itemUomUid": 1, "uom": "EA"}
        obj = ItemUom.model_validate(data)
        assert obj.item_uom_uid == 1


class TestVariantSchemas:
    """Tests for variant schemas."""

    def test_list_params(self) -> None:
        """Test VariantsListParams."""
        params = VariantsListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test Variant model."""
        data = {"itemVariantHdrUid": 1}
        obj = Variant.model_validate(data)
        assert obj.item_variant_hdr_uid == 1

    def test_create_params(self) -> None:
        """Test VariantCreateParams."""
        params = VariantCreateParams(name="Variant 1")
        assert params.name == "Variant 1"

    def test_update_params(self) -> None:
        """Test VariantUpdateParams."""
        params = VariantUpdateParams(name="Updated")
        assert params.name == "Updated"


class TestVariantLineSchemas:
    """Tests for variant line schemas."""

    def test_list_params(self) -> None:
        """Test VariantLineListParams."""
        params = VariantLineListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test VariantLine model."""
        data = {"itemVariantLineUid": 1}
        obj = VariantLine.model_validate(data)
        assert obj.item_variant_line_uid == 1

    def test_create_params(self) -> None:
        """Test VariantLineCreateParams."""
        params = VariantLineCreateParams(inv_mast_uid=100)
        assert params.inv_mast_uid == 100

    def test_update_params(self) -> None:
        """Test VariantLineUpdateParams."""
        params = VariantLineUpdateParams(display_order=5)
        assert params.display_order == 5


class TestItemWishlistSchemas:
    """Tests for item wishlist schemas."""

    def test_list_params(self) -> None:
        """Test ItemWishlistListParams."""
        params = ItemWishlistListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemWishlist model."""
        data = {"itemWishlistHdrUid": 1, "name": "My Wishlist"}
        obj = ItemWishlist.model_validate(data)
        assert obj.item_wishlist_hdr_uid == 1

    def test_create_params(self) -> None:
        """Test ItemWishlistCreateParams."""
        params = ItemWishlistCreateParams(name="New Wishlist")
        assert params.name == "New Wishlist"

    def test_update_params(self) -> None:
        """Test ItemWishlistUpdateParams."""
        params = ItemWishlistUpdateParams(name="Updated")
        assert params.name == "Updated"


class TestItemWishlistLineSchemas:
    """Tests for item wishlist line schemas."""

    def test_list_params(self) -> None:
        """Test ItemWishlistLineListParams."""
        params = ItemWishlistLineListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test ItemWishlistLine model."""
        data = {"itemWishlistLineUid": 1, "invMastUid": 100}
        obj = ItemWishlistLine.model_validate(data)
        assert obj.item_wishlist_line_uid == 1

    def test_create_params(self) -> None:
        """Test ItemWishlistLineCreateParams."""
        params = ItemWishlistLineCreateParams(inv_mast_uid=100)
        assert params.inv_mast_uid == 100


class TestLocationBinSchema:
    """Tests for location bin schema."""

    def test_model(self) -> None:
        """Test LocationBin model."""
        data = {"bin": "A1", "locationId": 100}
        obj = LocationBin.model_validate(data)
        assert obj.bin == "A1"


class TestP21InvMastSchemas:
    """Tests for P21 inv mast schemas."""

    def test_list_params(self) -> None:
        """Test P21InvMastListParams."""
        params = P21InvMastListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test P21InvMast model (passthrough)."""
        data = {"invMastUid": 1}
        obj = P21InvMast.model_validate(data)
        assert obj is not None


class TestInternalSchemas:
    """Tests for internal schemas."""

    def test_pdf_create_params(self) -> None:
        """Test PdfCreateParams."""
        params = PdfCreateParams(template="invoice", data={"id": 1})
        assert params.template == "invoice"

    def test_pdf_result_model(self) -> None:
        """Test PdfResult model (passthrough)."""
        data = {"pdfUrl": "http://example.com/doc.pdf"}
        obj = PdfResult.model_validate(data)
        assert obj is not None


# =============================================================================
# Client Tests
# =============================================================================


class TestItemsClient:
    """Tests for ItemsClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.items.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.items.ping()
        assert response.data == "pong"

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        httpx_mock.add_response(
            url="https://items.augur-api.com/whoami",
            json=mock_response({"user_id": "test-user", "email": "test@example.com"}),
        )
        response = api.items.whoami()
        assert response.data["user_id"] == "test-user"


class TestItemsClientProperties:
    """Tests for ItemsClient property accessors."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_attributes_property_returns_same_instance(self, api: AugurAPI) -> None:
        """attributes property should return same instance."""
        r1 = api.items.attributes
        r2 = api.items.attributes
        assert r1 is r2

    def test_attribute_groups_property_returns_same_instance(self, api: AugurAPI) -> None:
        """attribute_groups property should return same instance."""
        r1 = api.items.attribute_groups
        r2 = api.items.attribute_groups
        assert r1 is r2

    def test_brands_property_returns_same_instance(self, api: AugurAPI) -> None:
        """brands property should return same instance."""
        r1 = api.items.brands
        r2 = api.items.brands
        assert r1 is r2

    def test_categories_property_returns_same_instance(self, api: AugurAPI) -> None:
        """categories property should return same instance."""
        r1 = api.items.categories
        r2 = api.items.categories
        assert r1 is r2

    def test_contracts_property_returns_same_instance(self, api: AugurAPI) -> None:
        """contracts property should return same instance."""
        r1 = api.items.contracts
        r2 = api.items.contracts
        assert r1 is r2

    def test_inv_loc_property_returns_same_instance(self, api: AugurAPI) -> None:
        """inv_loc property should return same instance."""
        r1 = api.items.inv_loc
        r2 = api.items.inv_loc
        assert r1 is r2

    def test_inv_mast_property_returns_same_instance(self, api: AugurAPI) -> None:
        """inv_mast property should return same instance."""
        r1 = api.items.inv_mast
        r2 = api.items.inv_mast
        assert r1 is r2

    def test_inv_mast_links_property_returns_same_instance(self, api: AugurAPI) -> None:
        """inv_mast_links property should return same instance."""
        r1 = api.items.inv_mast_links
        r2 = api.items.inv_mast_links
        assert r1 is r2

    def test_inv_mast_sub_parts_property_returns_same_instance(self, api: AugurAPI) -> None:
        """inv_mast_sub_parts property should return same instance."""
        r1 = api.items.inv_mast_sub_parts
        r2 = api.items.inv_mast_sub_parts
        assert r1 is r2

    def test_inv_mast_ud_property_returns_same_instance(self, api: AugurAPI) -> None:
        """inv_mast_ud property should return same instance."""
        r1 = api.items.inv_mast_ud
        r2 = api.items.inv_mast_ud
        assert r1 is r2

    def test_item_category_property_returns_same_instance(self, api: AugurAPI) -> None:
        """item_category property should return same instance."""
        r1 = api.items.item_category
        r2 = api.items.item_category
        assert r1 is r2

    def test_item_favorites_property_returns_same_instance(self, api: AugurAPI) -> None:
        """item_favorites property should return same instance."""
        r1 = api.items.item_favorites
        r2 = api.items.item_favorites
        assert r1 is r2

    def test_item_uom_property_returns_same_instance(self, api: AugurAPI) -> None:
        """item_uom property should return same instance."""
        r1 = api.items.item_uom
        r2 = api.items.item_uom
        assert r1 is r2

    def test_variants_property_returns_same_instance(self, api: AugurAPI) -> None:
        """variants property should return same instance."""
        r1 = api.items.variants
        r2 = api.items.variants
        assert r1 is r2

    def test_item_wishlist_property_returns_same_instance(self, api: AugurAPI) -> None:
        """item_wishlist property should return same instance."""
        r1 = api.items.item_wishlist
        r2 = api.items.item_wishlist
        assert r1 is r2

    def test_locations_property_returns_same_instance(self, api: AugurAPI) -> None:
        """locations property should return same instance."""
        r1 = api.items.locations
        r2 = api.items.locations
        assert r1 is r2

    def test_p21_inv_mast_property_returns_same_instance(self, api: AugurAPI) -> None:
        """p21_inv_mast property should return same instance."""
        r1 = api.items.p21_inv_mast
        r2 = api.items.p21_inv_mast
        assert r1 is r2

    def test_internal_property_returns_same_instance(self, api: AugurAPI) -> None:
        """internal property should return same instance."""
        r1 = api.items.internal
        r2 = api.items.internal
        assert r1 is r2


# =============================================================================
# Resource Tests
# =============================================================================


class TestAttributesResource:
    """Tests for AttributesResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> AttributesResource:
        """Create resource with mock HTTP."""
        return AttributesResource(mock_http)

    def test_list(self, resource: AttributesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeUid": 1}])
        result = resource.list()
        assert result.data[0].attribute_uid == 1
        mock_http.get.assert_called_once()

    def test_get(self, resource: AttributesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"attributeUid": 1})
        result = resource.get(1)
        assert result.data.attribute_uid == 1

    def test_create(self, resource: AttributesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeUid": 1})
        result = resource.create(AttributeCreateParams(attribute_name="Test"))
        assert result.data.attribute_uid == 1

    def test_update(self, resource: AttributesResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeUid": 1})
        result = resource.update(1, AttributeUpdateParams(attribute_name="Updated"))
        assert result.data.attribute_uid == 1

    def test_delete(self, resource: AttributesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_values_factory(self, resource: AttributesResource) -> None:
        """Test values factory method."""
        values_resource = resource.values(1)
        assert isinstance(values_resource, AttributeValuesResource)


class TestAttributeValuesResource:
    """Tests for AttributeValuesResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> AttributeValuesResource:
        """Create resource with mock HTTP."""
        return AttributeValuesResource(mock_http, attribute_uid=1)

    def test_list(self, resource: AttributeValuesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeValueUid": 1}])
        result = resource.list()
        assert result.data[0].attribute_value_uid == 1

    def test_get(self, resource: AttributeValuesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"attributeValueUid": 1})
        result = resource.get(1)
        assert result.data.attribute_value_uid == 1

    def test_create(self, resource: AttributeValuesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeValueUid": 1})
        result = resource.create(AttributeValueCreateParams(value="Test"))
        assert result.data.attribute_value_uid == 1

    def test_update(self, resource: AttributeValuesResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeValueUid": 1})
        result = resource.update(1, AttributeValueUpdateParams(value="Updated"))
        assert result.data.attribute_value_uid == 1

    def test_delete(self, resource: AttributeValuesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestAttributeGroupsResource:
    """Tests for AttributeGroupsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> AttributeGroupsResource:
        """Create resource with mock HTTP."""
        return AttributeGroupsResource(mock_http)

    def test_list(self, resource: AttributeGroupsResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeGroupUid": 1}])
        result = resource.list()
        assert result.data[0].attribute_group_uid == 1

    def test_get(self, resource: AttributeGroupsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"attributeGroupUid": 1})
        result = resource.get(1)
        assert result.data.attribute_group_uid == 1

    def test_create(self, resource: AttributeGroupsResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeGroupUid": 1})
        result = resource.create(AttributeGroupCreateParams(group_name="Test"))
        assert result.data.attribute_group_uid == 1

    def test_update(self, resource: AttributeGroupsResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeGroupUid": 1})
        result = resource.update(1, AttributeGroupUpdateParams(group_name="Updated"))
        assert result.data.attribute_group_uid == 1

    def test_delete(self, resource: AttributeGroupsResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_attributes_factory(self, resource: AttributeGroupsResource) -> None:
        """Test attributes factory method."""
        attrs_resource = resource.attributes(1)
        assert isinstance(attrs_resource, AttributeGroupAttributesResource)


class TestBrandsResource:
    """Tests for BrandsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> BrandsResource:
        """Create resource with mock HTTP."""
        return BrandsResource(mock_http)

    def test_list(self, resource: BrandsResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"brandsUid": 1}])
        result = resource.list()
        assert result.data[0].brands_uid == 1

    def test_get(self, resource: BrandsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"brandsUid": 1})
        result = resource.get(1)
        assert result.data.brands_uid == 1

    def test_create(self, resource: BrandsResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"brandsUid": 1})
        result = resource.create(BrandsCreateParams(brand_name="Test"))
        assert result.data.brands_uid == 1

    def test_update(self, resource: BrandsResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"brandsUid": 1})
        result = resource.update(1, BrandsUpdateParams(brand_name="Updated"))
        assert result.data.brands_uid == 1

    def test_delete(self, resource: BrandsResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_items_factory(self, resource: BrandsResource) -> None:
        """Test items factory method."""
        items_resource = resource.items(1)
        assert isinstance(items_resource, BrandsItemsResource)


class TestCategoriesResource:
    """Tests for CategoriesResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> CategoriesResource:
        """Create resource with mock HTTP."""
        return CategoriesResource(mock_http)

    def test_get(self, resource: CategoriesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"itemCategoryUid": 1})
        result = resource.get(1)
        assert result.data.item_category_uid == 1

    def test_lookup(self, resource: CategoriesResource, mock_http: MagicMock) -> None:
        """Test lookup method."""
        mock_http.get.return_value = mock_response([{"itemCategoryUid": 1}])
        result = resource.lookup(CategoryLookupParams(q="test"))
        assert len(result.data) == 1

    def test_get_attributes(self, resource: CategoriesResource, mock_http: MagicMock) -> None:
        """Test get_attributes method."""
        # API returns nested structure: { data: { attributes: [...] } }
        mock_http.get.return_value = mock_response({"attributes": [{"attributeUid": 1}]})
        result = resource.get_attributes(1)
        assert len(result.data.attributes) == 1

    def test_get_images(self, resource: CategoriesResource, mock_http: MagicMock) -> None:
        """Test get_images method."""
        mock_http.get.return_value = mock_response([{"imageUrl": "http://example.com"}])
        result = resource.get_images(1)
        assert len(result.data) == 1

    def test_get_items(self, resource: CategoriesResource, mock_http: MagicMock) -> None:
        """Test get_items method."""
        # API returns nested structure: { data: { itemCategoryUid, took, total, items: [...] } }
        mock_http.get.return_value = mock_response(
            {"itemCategoryUid": 1, "took": 10, "total": 1, "items": [{"invMastUid": 1}]}
        )
        result = resource.get_items(1)
        assert result.data.total == 1
        assert len(result.data.items) == 1


class TestContractsResource:
    """Tests for ContractsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ContractsResource:
        """Create resource with mock HTTP."""
        return ContractsResource(mock_http)

    def test_get_items(self, resource: ContractsResource, mock_http: MagicMock) -> None:
        """Test get_items method."""
        mock_http.get.return_value = mock_response([{"invMastUid": 1}])
        result = resource.get_items("JOB001")
        assert len(result.data) == 1

    def test_get_attributes(self, resource: ContractsResource, mock_http: MagicMock) -> None:
        """Test get_attributes method."""
        mock_http.get.return_value = mock_response([{"attributeUid": 1}])
        result = resource.get_attributes("JOB001")
        assert len(result.data) == 1


class TestInvMastResource:
    """Tests for InvMastResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastResource:
        """Create resource with mock HTTP."""
        return InvMastResource(mock_http)

    def test_list(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invMastUid": 1}])
        result = resource.list()
        assert result.data[0].inv_mast_uid == 1

    def test_get(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"invMastUid": 1})
        result = resource.get(1)
        assert result.data.inv_mast_uid == 1

    def test_lookup(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test lookup method."""
        mock_http.get.return_value = mock_response([{"invMastUid": 1}])
        result = resource.lookup(InvMastLookupParams(q="test"))
        assert len(result.data) == 1

    def test_get_doc(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_doc method."""
        mock_http.get.return_value = mock_response({"document": "doc"})
        result = resource.get_doc(1)
        assert result.data.document == "doc"

    def test_get_stock(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_stock method."""
        mock_http.get.return_value = mock_response([{"qtyOnHand": 50}])
        result = resource.get_stock(1)
        assert len(result.data) == 1

    def test_get_alternate_codes(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_alternate_codes method."""
        mock_http.get.return_value = mock_response([{"alternateCode": "ALT"}])
        result = resource.get_alternate_codes(1)
        assert len(result.data) == 1

    def test_get_accessories(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_accessories method."""
        mock_http.get.return_value = mock_response([{"accessoryInvMastUid": 1}])
        result = resource.get_accessories(1)
        assert len(result.data) == 1

    def test_get_substitutes(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_substitutes method."""
        mock_http.get.return_value = mock_response([{"substituteInvMastUid": 1}])
        result = resource.get_substitutes(1)
        assert len(result.data) == 1

    def test_get_similar(self, resource: InvMastResource, mock_http: MagicMock) -> None:
        """Test get_similar method."""
        mock_http.get.return_value = mock_response([{"similarInvMastUid": 1}])
        result = resource.get_similar(1)
        assert len(result.data) == 1

    def test_faq_factory(self, resource: InvMastResource) -> None:
        """Test faq factory method."""
        faq_resource = resource.faq(1)
        assert isinstance(faq_resource, InvMastFaqResource)

    def test_attributes_factory(self, resource: InvMastResource) -> None:
        """Test attributes factory method."""
        attrs_resource = resource.attributes(1)
        assert isinstance(attrs_resource, InvMastAttributesResource)

    def test_locations_factory(self, resource: InvMastResource) -> None:
        """Test locations factory method."""
        locs_resource = resource.locations(1)
        assert isinstance(locs_resource, InvMastLocationsResource)


class TestInvMastFaqResource:
    """Tests for InvMastFaqResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastFaqResource:
        """Create resource with mock HTTP."""
        return InvMastFaqResource(mock_http, inv_mast_uid=1)

    def test_list(self, resource: InvMastFaqResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invMastFaqUid": 1}])
        result = resource.list()
        assert result.data[0].inv_mast_faq_uid == 1

    def test_get(self, resource: InvMastFaqResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"invMastFaqUid": 1})
        result = resource.get(1)
        assert result.data.inv_mast_faq_uid == 1

    def test_create(self, resource: InvMastFaqResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"invMastFaqUid": 1})
        result = resource.create(InvMastFaqCreateParams(question="Q?"))
        assert result.data.inv_mast_faq_uid == 1

    def test_update(self, resource: InvMastFaqResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"invMastFaqUid": 1})
        result = resource.update(1, InvMastFaqUpdateParams(answer="A"))
        assert result.data.inv_mast_faq_uid == 1

    def test_delete(self, resource: InvMastFaqResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestVariantsResource:
    """Tests for VariantsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> VariantsResource:
        """Create resource with mock HTTP."""
        return VariantsResource(mock_http)

    def test_list(self, resource: VariantsResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemVariantHdrUid": 1}])
        result = resource.list()
        assert result.data[0].item_variant_hdr_uid == 1

    def test_get(self, resource: VariantsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"itemVariantHdrUid": 1})
        result = resource.get(1)
        assert result.data.item_variant_hdr_uid == 1

    def test_create(self, resource: VariantsResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"itemVariantHdrUid": 1})
        result = resource.create(VariantCreateParams(name="Test"))
        assert result.data.item_variant_hdr_uid == 1

    def test_update(self, resource: VariantsResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"itemVariantHdrUid": 1})
        result = resource.update(1, VariantUpdateParams(name="Updated"))
        assert result.data.item_variant_hdr_uid == 1

    def test_delete(self, resource: VariantsResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True

    def test_lines_factory(self, resource: VariantsResource) -> None:
        """Test lines factory method."""
        lines_resource = resource.lines(1)
        assert isinstance(lines_resource, VariantLinesResource)

    def test_attributes_factory(self, resource: VariantsResource) -> None:
        """Test attributes factory method."""
        attrs_resource = resource.attributes(1)
        assert isinstance(attrs_resource, VariantAttributesResource)


class TestVariantAttributesResource:
    """Tests for VariantAttributesResource (nested under VariantsResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> VariantAttributesResource:
        """Create resource with mock HTTP."""
        return VariantAttributesResource(mock_http, 1)

    def test_list(self, resource: VariantAttributesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource: VariantAttributesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"attributeUid": 1})
        result = resource.get(1)
        assert result.data is not None

    def test_create(self, resource: VariantAttributesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeUid": 1})
        result = resource.create(VariantAttributeCreateParams())
        assert result.data is not None

    def test_update(self, resource: VariantAttributesResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeUid": 1})
        result = resource.update(1, VariantAttributeUpdateParams())
        assert result.data is not None

    def test_delete(self, resource: VariantAttributesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestVariantAttributeSchemas:
    """Tests for variant attribute schemas."""

    def test_list_params(self) -> None:
        """Test VariantAttributeListParams."""
        params = VariantAttributeListParams(limit=10)
        assert params.limit == 10

    def test_model(self) -> None:
        """Test VariantAttribute model."""
        data = {"attributeUid": 1}
        obj = VariantAttribute.model_validate(data)
        assert obj is not None

    def test_create_params(self) -> None:
        """Test VariantAttributeCreateParams."""
        params = VariantAttributeCreateParams(attribute_uid=1)
        assert params.attribute_uid == 1

    def test_update_params(self) -> None:
        """Test VariantAttributeUpdateParams."""
        params = VariantAttributeUpdateParams(attribute_uid=2)
        assert params.attribute_uid == 2


class TestItemWishlistResource:
    """Tests for ItemWishlistResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ItemWishlistResource:
        """Create resource with mock HTTP."""
        return ItemWishlistResource(mock_http)

    def test_list(self, resource: ItemWishlistResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemWishlistHdrUid": 1}])
        result = resource.list("user1")
        assert result.data[0].item_wishlist_hdr_uid == 1

    def test_create(self, resource: ItemWishlistResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"itemWishlistHdrUid": 1})
        result = resource.create("user1", ItemWishlistCreateParams(name="My List"))
        assert result.data.item_wishlist_hdr_uid == 1

    def test_update(self, resource: ItemWishlistResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"itemWishlistHdrUid": 1})
        result = resource.update("user1", 1, ItemWishlistUpdateParams(name="Updated"))
        assert result.data.item_wishlist_hdr_uid == 1

    def test_delete(self, resource: ItemWishlistResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response({"itemWishlistHdrUid": 1})
        result = resource.delete("user1", 1)
        assert result.data.item_wishlist_hdr_uid == 1

    def test_lines_factory(self, resource: ItemWishlistResource) -> None:
        """Test lines factory method."""
        lines_resource = resource.lines("user1", 1)
        assert isinstance(lines_resource, ItemWishlistLinesResource)


class TestItemFavoritesResource:
    """Tests for ItemFavoritesResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ItemFavoritesResource:
        """Create resource with mock HTTP."""
        return ItemFavoritesResource(mock_http)

    def test_list(self, resource: ItemFavoritesResource, mock_http: MagicMock) -> None:
        """Test list method - API returns array of invMastUid numbers."""
        mock_http.get.return_value = mock_response([86491, 12345, 67890])
        result = resource.list(123)
        assert len(result.data) == 3
        assert result.data[0] == 86491
        mock_http.get.assert_called_once()
        call_args = mock_http.get.call_args
        assert "/123/items" in str(call_args)

    def test_get(self, resource: ItemFavoritesResource, mock_http: MagicMock) -> None:
        """Test get method - returns single item favorite."""
        mock_http.get.return_value = mock_response({"inv_mast_uid": 86491})
        result = resource.get(123, 86491)
        assert result.status == 200
        mock_http.get.assert_called_once()
        call_args = mock_http.get.call_args
        assert "/123/items/86491" in str(call_args)

    def test_create(self, resource: ItemFavoritesResource, mock_http: MagicMock) -> None:
        """Test create method - accepts array of invMastUid numbers."""
        mock_http.post.return_value = mock_response(None)
        result = resource.create(123, [86491])
        assert result.status == 200
        mock_http.post.assert_called_once()
        call_args = mock_http.post.call_args
        assert "/123/items" in str(call_args)

    def test_update(self, resource: ItemFavoritesResource, mock_http: MagicMock) -> None:
        """Test update method - accepts any data (no validation)."""
        mock_http.put.return_value = mock_response(None)
        result = resource.update(123, 86491, {})
        assert result.status == 200
        mock_http.put.assert_called_once()
        call_args = mock_http.put.call_args
        assert "/123/items/86491" in str(call_args)

    def test_delete(self, resource: ItemFavoritesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(123, 1)
        assert result.data is True
        mock_http.delete.assert_called_once()
        call_args = mock_http.delete.call_args
        assert "/123/items/1" in str(call_args)


class TestLocationsResource:
    """Tests for LocationsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> LocationsResource:
        """Create resource with mock HTTP."""
        return LocationsResource(mock_http)

    def test_bins_factory(self, resource: LocationsResource) -> None:
        """Test bins factory method."""
        bins_resource = resource.bins(100)
        assert isinstance(bins_resource, LocationBinsResource)


class TestLocationBinsResource:
    """Tests for LocationBinsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> LocationBinsResource:
        """Create resource with mock HTTP."""
        return LocationBinsResource(mock_http, location_id=100)

    def test_list(self, resource: LocationBinsResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"bin": "A1"}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource: LocationBinsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response([{"bin": "A1"}])
        result = resource.get("A1")
        assert len(result.data) == 1


class TestInternalResource:
    """Tests for InternalResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InternalResource:
        """Create resource with mock HTTP."""
        return InternalResource(mock_http)

    def test_create_pdf(self, resource: InternalResource, mock_http: MagicMock) -> None:
        """Test create_pdf method."""
        mock_http.post.return_value = mock_response({"pdfUrl": "http://example.com/doc.pdf"})
        result = resource.create_pdf(PdfCreateParams(template="invoice"))
        assert result.data is not None


class TestP21InvMastResource:
    """Tests for P21InvMastResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> P21InvMastResource:
        """Create resource with mock HTTP."""
        return P21InvMastResource(mock_http)

    def test_list(self, resource: P21InvMastResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invMastUid": 1}])
        result = resource.list()
        assert len(result.data) == 1


class TestItemUomResource:
    """Tests for ItemUomResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ItemUomResource:
        """Create resource with mock HTTP."""
        return ItemUomResource(mock_http)

    def test_list(self, resource: ItemUomResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemUomUid": 1}])
        result = resource.list()
        assert result.data[0].item_uom_uid == 1

    def test_get(self, resource: ItemUomResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"itemUomUid": 1})
        result = resource.get(1)
        assert result.data.item_uom_uid == 1


class TestItemCategoryResource:
    """Tests for ItemCategoryResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ItemCategoryResource:
        """Create resource with mock HTTP."""
        return ItemCategoryResource(mock_http)

    def test_list(self, resource: ItemCategoryResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemCategoryUid": 1}])
        result = resource.list()
        assert result.data[0].item_category_uid == 1

    def test_get(self, resource: ItemCategoryResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"itemCategoryUid": 1})
        result = resource.get(1)
        assert result.data.item_category_uid == 1

    def test_lookup(self, resource: ItemCategoryResource, mock_http: MagicMock) -> None:
        """Test lookup method."""
        mock_http.get.return_value = mock_response([{"itemCategoryUid": 1}])
        result = resource.lookup(ItemCategoryLookupParams(q="test"))
        assert len(result.data) == 1

    def test_get_doc(self, resource: ItemCategoryResource, mock_http: MagicMock) -> None:
        """Test get_doc method."""
        mock_http.get.return_value = mock_response({"document": "doc"})
        result = resource.get_doc(1)
        assert result.data.document == "doc"


class TestInvLocResource:
    """Tests for InvLocResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvLocResource:
        """Create resource with mock HTTP."""
        return InvLocResource(mock_http)

    def test_list(self, resource: InvLocResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"locationId": 100}])
        result = resource.list()
        assert len(result.data) == 1


class TestInvMastLinksResource:
    """Tests for InvMastLinksResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastLinksResource:
        """Create resource with mock HTTP."""
        return InvMastLinksResource(mock_http)

    def test_get(self, resource: InvMastLinksResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response([{"linkUrl": "http://example.com"}])
        result = resource.get(1)
        assert len(result.data) == 1


class TestInvMastSubPartsResource:
    """Tests for InvMastSubPartsResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastSubPartsResource:
        """Create resource with mock HTTP."""
        return InvMastSubPartsResource(mock_http)

    def test_get(self, resource: InvMastSubPartsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response([{"subPartInvMastUid": 1}])
        result = resource.get(1)
        assert len(result.data) == 1


class TestInvMastUdResource:
    """Tests for InvMastUdResource."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastUdResource:
        """Create resource with mock HTTP."""
        return InvMastUdResource(mock_http)

    def test_list(self, resource: InvMastUdResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"invMastUid": 1}])
        result = resource.list()
        assert len(result.data) == 1


class TestAttributeGroupAttributesResource:
    """Tests for AttributeGroupAttributesResource (nested under AttributeGroupsResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> AttributeGroupAttributesResource:
        """Create resource with mock HTTP."""
        return AttributeGroupAttributesResource(mock_http, 1)

    def test_list(self, resource: AttributeGroupAttributesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeXAttributeGroupUid": 1}])
        result = resource.list()
        assert result.data[0].attribute_x_attribute_group_uid == 1

    def test_get(self, resource: AttributeGroupAttributesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"attributeXAttributeGroupUid": 1})
        result = resource.get(1)
        assert result.data.attribute_x_attribute_group_uid == 1

    def test_create(self, resource: AttributeGroupAttributesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeXAttributeGroupUid": 1})
        result = resource.create(
            AttributeXAttributeGroupCreateParams(attribute_uid=1, sort_order=1)
        )
        assert result.data.attribute_x_attribute_group_uid == 1

    def test_update(self, resource: AttributeGroupAttributesResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeXAttributeGroupUid": 1})
        result = resource.update(1, AttributeXAttributeGroupUpdateParams(sort_order=2))
        assert result.data.attribute_x_attribute_group_uid == 1

    def test_delete(self, resource: AttributeGroupAttributesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestBrandsItemsResource:
    """Tests for BrandsItemsResource (nested under BrandsResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> BrandsItemsResource:
        """Create resource with mock HTTP."""
        return BrandsItemsResource(mock_http, 1)

    def test_list(self, resource: BrandsItemsResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"brandsXItemsUid": 1}])
        result = resource.list()
        assert result.data[0].brands_x_items_uid == 1

    def test_get(self, resource: BrandsItemsResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"brandsXItemsUid": 1})
        result = resource.get(1)
        assert result.data.brands_x_items_uid == 1

    def test_create(self, resource: BrandsItemsResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"brandsXItemsUid": 1})
        result = resource.create(BrandsXItemsCreateParams(inv_mast_uid=1))
        assert result.data.brands_x_items_uid == 1

    def test_update(self, resource: BrandsItemsResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"brandsXItemsUid": 1})
        result = resource.update(1, BrandsXItemsUpdateParams(inv_mast_uid=2))
        assert result.data.brands_x_items_uid == 1

    def test_delete(self, resource: BrandsItemsResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestInvMastAttributesResource:
    """Tests for InvMastAttributesResource (nested under InvMastResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastAttributesResource:
        """Create resource with mock HTTP."""
        return InvMastAttributesResource(mock_http, 1)

    def test_list(self, resource: InvMastAttributesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_create(self, resource: InvMastAttributesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeUid": 1})
        result = resource.create(ItemAttributeCreateParams())
        assert result.data is not None

    def test_values_factory(self, resource: InvMastAttributesResource) -> None:
        """Test values factory method."""
        values_resource = resource.values(1)
        assert isinstance(values_resource, InvMastAttributeValuesResource)


class TestInvMastAttributeValuesResource:
    """Tests for InvMastAttributeValuesResource (nested under InvMastAttributesResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastAttributeValuesResource:
        """Create resource with mock HTTP."""
        return InvMastAttributeValuesResource(mock_http, 1, 1)

    def test_list(self, resource: Any, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"attributeValueUid": 1}])
        result = resource.list()
        assert len(result.data) == 1

    def test_create(self, resource: Any, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"attributeValueUid": 1})
        result = resource.create(ItemAttributeValueCreateParams())
        assert result.data is not None

    def test_update(self, resource: Any, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"attributeValueUid": 1})
        result = resource.update(1, ItemAttributeValueUpdateParams())
        assert result.data is not None

    def test_delete(self, resource: Any, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestInvMastBinsResource:
    """Tests for InvMastBinsResource (nested under InvMastLocationsResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastBinsResource:
        """Create resource with mock HTTP."""
        return InvMastBinsResource(mock_http, 1, 1)

    def test_list(self, resource: Any, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"bin": "A1"}])
        result = resource.list()
        assert len(result.data) == 1

    def test_get(self, resource: Any, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"bin": "A1"})
        result = resource.get("A1")
        assert result.data is not None


class TestInvMastLocationsResourceBins:
    """Tests for InvMastLocationsResource bins factory (nested under InvMastResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> InvMastLocationsResource:
        """Create resource with mock HTTP."""
        return InvMastLocationsResource(mock_http, 1)

    def test_bins_factory(self, resource: InvMastLocationsResource) -> None:
        """Test bins factory method."""
        bins_resource = resource.bins(1)
        assert isinstance(bins_resource, InvMastBinsResource)


class TestVariantLinesResource:
    """Tests for VariantLinesResource (nested under VariantsResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> VariantLinesResource:
        """Create resource with mock HTTP."""
        return VariantLinesResource(mock_http, 1)

    def test_list(self, resource: VariantLinesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemVariantLineUid": 1}])
        result = resource.list()
        assert result.data[0].item_variant_line_uid == 1

    def test_get(self, resource: VariantLinesResource, mock_http: MagicMock) -> None:
        """Test get method."""
        mock_http.get.return_value = mock_response({"itemVariantLineUid": 1})
        result = resource.get(1)
        assert result.data.item_variant_line_uid == 1

    def test_create(self, resource: VariantLinesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"itemVariantLineUid": 1})
        result = resource.create(VariantLineCreateParams(inv_mast_uid=1))
        assert result.data.item_variant_line_uid == 1

    def test_update(self, resource: VariantLinesResource, mock_http: MagicMock) -> None:
        """Test update method."""
        mock_http.put.return_value = mock_response({"itemVariantLineUid": 1})
        result = resource.update(1, VariantLineUpdateParams(inv_mast_uid=2))
        assert result.data.item_variant_line_uid == 1

    def test_delete(self, resource: VariantLinesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response(True)
        result = resource.delete(1)
        assert result.data is True


class TestItemWishlistLinesResource:
    """Tests for ItemWishlistLinesResource (nested under ItemWishlistResource)."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def resource(self, mock_http: MagicMock) -> ItemWishlistLinesResource:
        """Create resource with mock HTTP."""
        return ItemWishlistLinesResource(mock_http, 1, 1)

    def test_list(self, resource: ItemWishlistLinesResource, mock_http: MagicMock) -> None:
        """Test list method."""
        mock_http.get.return_value = mock_response([{"itemWishlistLineUid": 1}])
        result = resource.list()
        assert result.data[0].item_wishlist_line_uid == 1

    def test_create(self, resource: ItemWishlistLinesResource, mock_http: MagicMock) -> None:
        """Test create method."""
        mock_http.post.return_value = mock_response({"itemWishlistLineUid": 1})
        result = resource.create(ItemWishlistLineCreateParams(inv_mast_uid=1))
        assert result.data.item_wishlist_line_uid == 1

    def test_delete(self, resource: ItemWishlistLinesResource, mock_http: MagicMock) -> None:
        """Test delete method."""
        mock_http.delete.return_value = mock_response({"itemWishlistLineUid": 1})
        result = resource.delete(1)
        assert result.data.item_wishlist_line_uid == 1
