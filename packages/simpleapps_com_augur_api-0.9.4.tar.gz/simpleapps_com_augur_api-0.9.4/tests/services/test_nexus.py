"""Tests for the Nexus service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.nexus.schemas import (
    BinTransfer,
    BinTransferCreateParams,
    BinTransferListParams,
    BinTransferUpdateParams,
    HealthCheckData,
    PurchaseOrderReceipt,
    PurchaseOrderReceiptCreateParams,
    PurchaseOrderReceiptListParams,
    PurchaseOrderReceiptUpdateParams,
    Receiving,
    ReceivingCreateParams,
    ReceivingListParams,
    ReceivingUpdateParams,
    Transfer,
    TransferCreateParams,
    TransferListParams,
    TransferReceipt,
    TransferReceiptCreateParams,
    TransferReceiptListParams,
    TransferReceiptUpdateParams,
    TransferShipping,
    TransferShippingCreateParams,
    TransferShippingListParams,
    TransferShippingUpdateParams,
    TransferUpdateParams,
    User,
    UserListParams,
)


class TestNexusSchemas:
    """Tests for Nexus schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    # Bin Transfer schemas
    def test_bin_transfer_list_params(self) -> None:
        """Should create bin transfer list params."""
        params = BinTransferListParams(limit=10, offset=5, status_cd=1)
        assert params.limit == 10
        assert params.offset == 5
        assert params.status_cd == 1

    def test_bin_transfer_model(self) -> None:
        """Should parse bin transfer data (passthrough)."""
        data = {"binTransferHdrUid": 1, "someField": "value"}
        result = BinTransfer.model_validate(data)
        assert result.bin_transfer_hdr_uid == 1

    def test_bin_transfer_create_params(self) -> None:
        """Should create bin transfer create params (passthrough)."""
        params = BinTransferCreateParams(item_id="ABC123", quantity=10)
        assert params is not None

    def test_bin_transfer_update_params(self) -> None:
        """Should create bin transfer update params (passthrough)."""
        params = BinTransferUpdateParams(quantity=20)
        assert params is not None

    # User schemas
    def test_user_list_params(self) -> None:
        """Should create user list params."""
        params = UserListParams(limit=10, active=True)
        assert params.active is True

    def test_user_model(self) -> None:
        """Should parse user data (passthrough)."""
        data = {"usersUid": 1, "username": "jdoe"}
        result = User.model_validate(data)
        assert result.users_uid == 1

    # Receiving schemas
    def test_receiving_list_params(self) -> None:
        """Should create receiving list params."""
        params = ReceivingListParams(limit=10, po_no=12345, status_cd=1)
        assert params.po_no == 12345
        assert params.status_cd == 1

    def test_receiving_model(self) -> None:
        """Should parse receiving data (passthrough)."""
        data = {"receivingUid": 1, "poNumber": "PO001"}
        result = Receiving.model_validate(data)
        assert result.receiving_uid == 1

    def test_receiving_create_params(self) -> None:
        """Should create receiving create params (passthrough)."""
        params = ReceivingCreateParams(po_no=12345)
        assert params is not None

    def test_receiving_update_params(self) -> None:
        """Should create receiving update params (passthrough)."""
        params = ReceivingUpdateParams(status_cd=2)
        assert params is not None

    # Transfer schemas
    def test_transfer_list_params(self) -> None:
        """Should create transfer list params."""
        params = TransferListParams(limit=10, reference_no="REF123", status_cd=1)
        assert params.reference_no == "REF123"
        assert params.status_cd == 1

    def test_transfer_model(self) -> None:
        """Should parse transfer data (passthrough)."""
        data = {"transferUid": 1, "referenceNo": "REF123"}
        result = Transfer.model_validate(data)
        assert result.transfer_uid == 1

    def test_transfer_create_params(self) -> None:
        """Should create transfer create params (passthrough)."""
        params = TransferCreateParams(reference_no="REF123")
        assert params is not None

    def test_transfer_update_params(self) -> None:
        """Should create transfer update params (passthrough)."""
        params = TransferUpdateParams(status_cd=2)
        assert params is not None

    # Purchase Order Receipt schemas
    def test_purchase_order_receipt_list_params(self) -> None:
        """Should create purchase order receipt list params."""
        params = PurchaseOrderReceiptListParams(limit=10, reference_no="REF123")
        assert params.reference_no == "REF123"

    def test_purchase_order_receipt_model(self) -> None:
        """Should parse purchase order receipt data (passthrough)."""
        data = {"purchaseOrderReceiptUid": 1}
        result = PurchaseOrderReceipt.model_validate(data)
        assert result.purchase_order_receipt_uid == 1

    def test_purchase_order_receipt_create_params(self) -> None:
        """Should create purchase order receipt create params (passthrough)."""
        params = PurchaseOrderReceiptCreateParams(reference_no="REF123")
        assert params is not None

    def test_purchase_order_receipt_update_params(self) -> None:
        """Should create purchase order receipt update params (passthrough)."""
        params = PurchaseOrderReceiptUpdateParams(status_cd=2)
        assert params is not None

    # Transfer Receipt schemas
    def test_transfer_receipt_list_params(self) -> None:
        """Should create transfer receipt list params."""
        params = TransferReceiptListParams(limit=10, reference_no="REF123")
        assert params.reference_no == "REF123"

    def test_transfer_receipt_model(self) -> None:
        """Should parse transfer receipt data (passthrough)."""
        data = {"transferReceiptUid": 1}
        result = TransferReceipt.model_validate(data)
        assert result.transfer_receipt_uid == 1

    def test_transfer_receipt_create_params(self) -> None:
        """Should create transfer receipt create params (passthrough)."""
        params = TransferReceiptCreateParams(reference_no="REF123")
        assert params is not None

    def test_transfer_receipt_update_params(self) -> None:
        """Should create transfer receipt update params (passthrough)."""
        params = TransferReceiptUpdateParams(status_cd=2)
        assert params is not None

    # Transfer Shipping schemas
    def test_transfer_shipping_list_params(self) -> None:
        """Should create transfer shipping list params."""
        params = TransferShippingListParams(limit=10, reference_no="REF123")
        assert params.reference_no == "REF123"

    def test_transfer_shipping_model(self) -> None:
        """Should parse transfer shipping data (passthrough)."""
        data = {"transferReceiptUid": 1}
        result = TransferShipping.model_validate(data)
        assert result.transfer_receipt_uid == 1

    def test_transfer_shipping_create_params(self) -> None:
        """Should create transfer shipping create params (passthrough)."""
        params = TransferShippingCreateParams(reference_no="REF123")
        assert params is not None

    def test_transfer_shipping_update_params(self) -> None:
        """Should create transfer shipping update params (passthrough)."""
        params = TransferShippingUpdateParams(status_cd=2)
        assert params is not None


class TestNexusClient:
    """Tests for NexusClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    @pytest.fixture
    def mock_list_response(self) -> dict:
        """Standard list response."""
        return {
            "count": 1,
            "data": [],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }

    @pytest.fixture
    def mock_single_response(self) -> dict:
        """Standard single item response."""
        return {
            "count": 1,
            "data": {},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.nexus.health_check()
        assert response.data.site_id == "test-site"

    # Bin Transfer client tests
    def test_bin_transfer_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list bin transfers."""
        mock_list_response["data"] = [{"binTransferHdrUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer",
            json=mock_list_response,
        )
        response = api.nexus.bin_transfer.list()
        assert len(response.data) == 1

    def test_bin_transfer_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get bin transfer by UID."""
        mock_single_response["data"] = {"binTransferHdrUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer/1",
            json=mock_single_response,
        )
        response = api.nexus.bin_transfer.get(1)
        assert response.data.bin_transfer_hdr_uid == 1

    def test_bin_transfer_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create bin transfer."""
        mock_single_response["data"] = {"binTransferHdrUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.bin_transfer.create(BinTransferCreateParams())
        assert response.data.bin_transfer_hdr_uid == 1

    def test_bin_transfer_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update bin transfer."""
        mock_single_response["data"] = {"binTransferHdrUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.bin_transfer.update(1, BinTransferUpdateParams())
        assert response.data.bin_transfer_hdr_uid == 1

    def test_bin_transfer_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete bin transfer."""
        mock_single_response["data"] = {"binTransferHdrUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.bin_transfer.delete(1)
        assert response.data.bin_transfer_hdr_uid == 1

    def test_bin_transfer_status(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get bin transfer status."""
        mock_single_response["data"] = {"binTransferHdrUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/bin-transfer/1/status",
            json=mock_single_response,
        )
        response = api.nexus.bin_transfer.status(1)
        assert response.data.bin_transfer_hdr_uid == 1

    # Users client tests
    def test_users_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list users."""
        mock_list_response["data"] = [{"usersUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/users",
            json=mock_list_response,
        )
        response = api.nexus.users.list()
        assert len(response.data) == 1

    def test_users_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get user by UID."""
        mock_single_response["data"] = {"usersUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/users/1",
            json=mock_single_response,
        )
        response = api.nexus.users.get(1)
        assert response.data.users_uid == 1

    # Receiving client tests
    def test_receiving_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list receiving records."""
        mock_list_response["data"] = [{"receivingUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/receiving",
            json=mock_list_response,
        )
        response = api.nexus.receiving.list()
        assert len(response.data) == 1

    def test_receiving_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get receiving record by UID."""
        mock_single_response["data"] = {"receivingUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/receiving/1",
            json=mock_single_response,
        )
        response = api.nexus.receiving.get(1)
        assert response.data.receiving_uid == 1

    def test_receiving_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create receiving record."""
        mock_single_response["data"] = {"receivingUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/receiving",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.receiving.create(ReceivingCreateParams())
        assert response.data.receiving_uid == 1

    def test_receiving_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update receiving record."""
        mock_single_response["data"] = {"receivingUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/receiving/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.receiving.update(1, ReceivingUpdateParams())
        assert response.data.receiving_uid == 1

    def test_receiving_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete receiving record."""
        mock_single_response["data"] = {"receivingUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/receiving/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.receiving.delete(1)
        assert response.data.receiving_uid == 1

    # Transfer client tests
    def test_transfer_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list transfers."""
        mock_list_response["data"] = [{"transferUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer",
            json=mock_list_response,
        )
        response = api.nexus.transfer.list()
        assert len(response.data) == 1

    def test_transfer_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get transfer by UID."""
        mock_single_response["data"] = {"transferUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer/1",
            json=mock_single_response,
        )
        response = api.nexus.transfer.get(1)
        assert response.data.transfer_uid == 1

    def test_transfer_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create transfer."""
        mock_single_response["data"] = {"transferUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.transfer.create(TransferCreateParams())
        assert response.data.transfer_uid == 1

    def test_transfer_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update transfer."""
        mock_single_response["data"] = {"transferUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.transfer.update(1, TransferUpdateParams())
        assert response.data.transfer_uid == 1

    def test_transfer_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete transfer."""
        mock_single_response["data"] = {"transferUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.transfer.delete(1)
        assert response.data.transfer_uid == 1

    # Purchase Order Receipt client tests
    def test_purchase_order_receipt_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list purchase order receipts."""
        mock_list_response["data"] = [{"purchaseOrderReceiptUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/purchase-order-receipt",
            json=mock_list_response,
        )
        response = api.nexus.purchase_order_receipt.list()
        assert len(response.data) == 1

    def test_purchase_order_receipt_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get purchase order receipt by UID."""
        mock_single_response["data"] = {"purchaseOrderReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/purchase-order-receipt/1",
            json=mock_single_response,
        )
        response = api.nexus.purchase_order_receipt.get(1)
        assert response.data.purchase_order_receipt_uid == 1

    def test_purchase_order_receipt_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create purchase order receipt."""
        mock_single_response["data"] = {"purchaseOrderReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/purchase-order-receipt",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.purchase_order_receipt.create(PurchaseOrderReceiptCreateParams())
        assert response.data.purchase_order_receipt_uid == 1

    def test_purchase_order_receipt_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update purchase order receipt."""
        mock_single_response["data"] = {"purchaseOrderReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/purchase-order-receipt/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.purchase_order_receipt.update(1, PurchaseOrderReceiptUpdateParams())
        assert response.data.purchase_order_receipt_uid == 1

    def test_purchase_order_receipt_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete purchase order receipt."""
        mock_single_response["data"] = {"purchaseOrderReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/purchase-order-receipt/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.purchase_order_receipt.delete(1)
        assert response.data.purchase_order_receipt_uid == 1

    # Transfer Receipt client tests
    def test_transfer_receipt_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list transfer receipts."""
        mock_list_response["data"] = [{"transferReceiptUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-receipt",
            json=mock_list_response,
        )
        response = api.nexus.transfer_receipt.list()
        assert len(response.data) == 1

    def test_transfer_receipt_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get transfer receipt by UID."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-receipt/1",
            json=mock_single_response,
        )
        response = api.nexus.transfer_receipt.get(1)
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_receipt_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create transfer receipt."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-receipt",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.transfer_receipt.create(TransferReceiptCreateParams())
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_receipt_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update transfer receipt."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-receipt/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.transfer_receipt.update(1, TransferReceiptUpdateParams())
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_receipt_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete transfer receipt."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-receipt/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.transfer_receipt.delete(1)
        assert response.data.transfer_receipt_uid == 1

    # Transfer Shipping client tests
    def test_transfer_shipping_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_list_response: dict
    ) -> None:
        """Should list transfer shipping documents."""
        mock_list_response["data"] = [{"transferReceiptUid": 1}]
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-shipping",
            json=mock_list_response,
        )
        response = api.nexus.transfer_shipping.list()
        assert len(response.data) == 1

    def test_transfer_shipping_get(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should get transfer shipping document by UID."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-shipping/1",
            json=mock_single_response,
        )
        response = api.nexus.transfer_shipping.get(1)
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_shipping_create(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should create transfer shipping document."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-shipping",
            json=mock_single_response,
            method="POST",
        )
        response = api.nexus.transfer_shipping.create(TransferShippingCreateParams())
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_shipping_update(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should update transfer shipping document."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-shipping/1",
            json=mock_single_response,
            method="PUT",
        )
        response = api.nexus.transfer_shipping.update(1, TransferShippingUpdateParams())
        assert response.data.transfer_receipt_uid == 1

    def test_transfer_shipping_delete(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_single_response: dict
    ) -> None:
        """Should delete transfer shipping document."""
        mock_single_response["data"] = {"transferReceiptUid": 1}
        httpx_mock.add_response(
            url="https://nexus.augur-api.com/transfer-shipping/1",
            json=mock_single_response,
            method="DELETE",
        )
        response = api.nexus.transfer_shipping.delete(1)
        assert response.data.transfer_receipt_uid == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.nexus
        assert client.bin_transfer is client.bin_transfer
        assert client.users is client.users
        assert client.receiving is client.receiving
        assert client.transfer is client.transfer
        assert client.purchase_order_receipt is client.purchase_order_receipt
        assert client.transfer_receipt is client.transfer_receipt
        assert client.transfer_shipping is client.transfer_shipping
