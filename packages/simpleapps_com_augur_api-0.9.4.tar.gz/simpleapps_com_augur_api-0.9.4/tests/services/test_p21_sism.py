"""Tests for the P21 SISM service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.p21_sism import (
    HealthCheckData,
    ImpOeHdr,
    ImpOeHdrResource,
    ImpOeHdrSalesrep,
    ImpOeHdrSalesrepResource,
    ImpOeHdrSalesrepUpdateParams,
    ImpOeHdrUpdateParams,
    ImpOeHdrWeb,
    ImpOeHdrWebResource,
    ImpOeLine,
    ImpOeLineListParams,
    ImpOeLineResource,
    ImpOeLineUpdateParams,
    Import,
    ImportListParams,
    ImportResource,
    ImportUpdateParams,
    P21SismClient,
    ScheduledImportMetadataResource,
    ScheduledImportSftpMetadata,
    ScheduledImportSftpMetadataCreateParams,
)


class TestP21SismSchemas:
    """Tests for P21 SISM schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_health_check_data_passthrough(self) -> None:
        """Should allow unknown fields in health check data."""
        data = {"siteHash": "abc", "siteId": "test", "extraField": "value"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test"

    def test_import_list_params(self) -> None:
        """Should create import list params."""
        params = ImportListParams(limit=10, status="pending", transaction_set="OE")
        assert params.limit == 10
        assert params.status == "pending"
        assert params.transaction_set == "OE"

    def test_import_model(self) -> None:
        """Should parse import data."""
        data = {
            "importUid": 1,
            "transactionSet": "OE",
            "status": "completed",
        }
        result = Import.model_validate(data)
        assert result.import_uid == 1
        assert result.transaction_set == "OE"
        assert result.status == "completed"

    def test_import_model_passthrough(self) -> None:
        """Should allow unknown fields in import data."""
        data = {
            "importUid": 1,
            "transactionSet": "OE",
            "status": "completed",
            "totalRecords": 100,
            "extraField": "value",
        }
        result = Import.model_validate(data)
        assert result.import_uid == 1

    def test_import_update_params(self) -> None:
        """Should create import update params."""
        params = ImportUpdateParams(status="processing")
        # Passthrough model accepts any fields
        assert params.model_dump() == {"status": "processing"}

    def test_imp_oe_hdr(self) -> None:
        """Should parse imp_oe_hdr data."""
        data = {"importUid": 123, "orderNumber": "ORD-001"}
        result = ImpOeHdr.model_validate(data)
        assert result.import_uid == 123

    def test_imp_oe_hdr_update_params(self) -> None:
        """Should create imp_oe_hdr update params."""
        params = ImpOeHdrUpdateParams(customer_id="CUST001")
        assert params.model_dump() == {"customer_id": "CUST001"}

    def test_imp_oe_hdr_salesrep(self) -> None:
        """Should parse imp_oe_hdr_salesrep data."""
        data = {"importUid": 456, "salesrepId": "REP001"}
        result = ImpOeHdrSalesrep.model_validate(data)
        assert result.import_uid == 456

    def test_imp_oe_hdr_salesrep_update_params(self) -> None:
        """Should create imp_oe_hdr_salesrep update params."""
        params = ImpOeHdrSalesrepUpdateParams(salesrep_id="REP002")
        assert params.model_dump() == {"salesrep_id": "REP002"}

    def test_imp_oe_hdr_web(self) -> None:
        """Should parse imp_oe_hdr_web data."""
        data = {"importUid": 789, "webOrderId": "WEB001"}
        result = ImpOeHdrWeb.model_validate(data)
        assert result.import_uid == 789

    def test_imp_oe_line_list_params(self) -> None:
        """Should create imp_oe_line list params."""
        params = ImpOeLineListParams(limit=50, offset=10)
        assert params.limit == 50
        assert params.offset == 10

    def test_imp_oe_line(self) -> None:
        """Should parse imp_oe_line data."""
        data = {"importUid": 100, "lineNo": 1, "itemId": "ITEM001"}
        result = ImpOeLine.model_validate(data)
        assert result.import_uid == 100
        assert result.line_no == 1

    def test_imp_oe_line_update_params(self) -> None:
        """Should create imp_oe_line update params."""
        params = ImpOeLineUpdateParams(quantity=10)
        assert params.model_dump() == {"quantity": 10}

    def test_scheduled_import_sftp_metadata_create_params(self) -> None:
        """Should create SFTP metadata params."""
        params = ScheduledImportSftpMetadataCreateParams(host="sftp.example.com", username="user")
        assert params.model_dump() == {"host": "sftp.example.com", "username": "user"}

    def test_scheduled_import_sftp_metadata(self) -> None:
        """Should parse SFTP metadata."""
        data = {"host": "sftp.example.com", "port": 22, "username": "user"}
        result = ScheduledImportSftpMetadata.model_validate(data)
        assert result.model_dump()["host"] == "sftp.example.com"


class TestP21SismClient:
    """Tests for P21SismClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.p21_sism.health_check()
        assert response.data.site_id == "test-site"


class TestImportResource:
    """Tests for ImportResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list imports."""
        mock_response = {
            "count": 1,
            "data": [{"importUid": 1, "transactionSet": "OE", "status": "completed"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import",
            json=mock_response,
        )
        response = api.p21_sism.import_.list()
        assert len(response.data) == 1
        assert response.data[0].import_uid == 1

    def test_list_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list imports with params."""
        mock_response = {
            "count": 1,
            "data": [{"importUid": 2, "transactionSet": "OE", "status": "pending"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import?limit=10&status=pending",
            json=mock_response,
        )
        params = ImportListParams(limit=10, status="pending")
        response = api.p21_sism.import_.list(params)
        assert len(response.data) == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert "limit=10" in str(request.url)

    def test_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get import by UID."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "transactionSet": "OE", "status": "completed"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1",
            json=mock_response,
        )
        response = api.p21_sism.import_.get(1)
        assert response.data.import_uid == 1

    def test_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update import."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "transactionSet": "OE", "status": "processing"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_sism.import_.update(1, ImportUpdateParams(status="processing"))
        assert response.data.import_uid == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "PUT"

    def test_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete (clean pending_import) for an import."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.p21_sism.import_.delete(1)
        assert response.data is True
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "DELETE"

    def test_recent(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get recent imports."""
        mock_response = {
            "count": 2,
            "data": [
                {"importUid": 10, "transactionSet": "OE", "status": "completed"},
                {"importUid": 9, "transactionSet": "OE", "status": "completed"},
            ],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/recent",
            json=mock_response,
        )
        response = api.p21_sism.import_.recent()
        assert len(response.data) == 2
        assert response.data[0].import_uid == 10

    def test_stuck(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get stuck imports."""
        mock_response = {
            "count": 1,
            "data": [{"importUid": 5, "transactionSet": "OE", "status": "stuck"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/stuck",
            json=mock_response,
        )
        response = api.p21_sism.import_.stuck()
        assert len(response.data) == 1
        assert response.data[0].status == "stuck"


class TestImpOeHdrResource:
    """Tests for ImpOeHdrResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get imp_oe_hdr for an import."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "customerId": "CUST001"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1/imp-oe-hdr",
            json=mock_response,
        )
        response = api.p21_sism.imp_oe_hdr.get(1)
        assert response.data.import_uid == 1

    def test_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update imp_oe_hdr."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "customerId": "CUST002"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1/imp-oe-hdr",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_sism.imp_oe_hdr.update(1, ImpOeHdrUpdateParams(customer_id="CUST002"))
        assert response.data.import_uid == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "PUT"


class TestImpOeHdrSalesrepResource:
    """Tests for ImpOeHdrSalesrepResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get imp_oe_hdr_salesrep for an import."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "salesrepId": "REP001"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1/imp-oe-hdr-salesrep",
            json=mock_response,
        )
        response = api.p21_sism.imp_oe_hdr_salesrep.get(1)
        assert response.data.import_uid == 1

    def test_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update imp_oe_hdr_salesrep."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "salesrepId": "REP002"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1/imp-oe-hdr-salesrep",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_sism.imp_oe_hdr_salesrep.update(
            1, ImpOeHdrSalesrepUpdateParams(salesrep_id="REP002")
        )
        assert response.data.import_uid == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "PUT"


class TestImpOeHdrWebResource:
    """Tests for ImpOeHdrWebResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get imp_oe_hdr_web for an import."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "webOrderId": "WEB001"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/import/1/imp-oe-hdr-web",
            json=mock_response,
        )
        response = api.p21_sism.imp_oe_hdr_web.get(1)
        assert response.data.import_uid == 1


class TestImpOeLineResource:
    """Tests for ImpOeLineResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list imp_oe_line records."""
        mock_response = {
            "count": 2,
            "data": [
                {"importUid": 1, "lineNo": 1, "itemId": "ITEM001"},
                {"importUid": 1, "lineNo": 2, "itemId": "ITEM002"},
            ],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/imp_oe_line",
            json=mock_response,
        )
        response = api.p21_sism.imp_oe_line.list()
        assert len(response.data) == 2
        assert response.data[0].line_no == 1

    def test_list_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list imp_oe_line records with params."""
        mock_response = {
            "count": 1,
            "data": [{"importUid": 1, "lineNo": 1, "itemId": "ITEM001"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/imp_oe_line?limit=10&offset=5",
            json=mock_response,
        )
        params = ImpOeLineListParams(limit=10, offset=5)
        response = api.p21_sism.imp_oe_line.list(params)
        assert len(response.data) == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert "limit=10" in str(request.url)

    def test_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get imp_oe_line by import_uid and line_no."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "lineNo": 1, "itemId": "ITEM001", "quantity": 10},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/imp_oe_line/1/1",
            json=mock_response,
        )
        response = api.p21_sism.imp_oe_line.get(1, 1)
        assert response.data.import_uid == 1
        assert response.data.line_no == 1

    def test_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update imp_oe_line."""
        mock_response = {
            "count": 1,
            "data": {"importUid": 1, "lineNo": 1, "itemId": "ITEM001", "quantity": 20},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/imp_oe_line/1/1",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_sism.imp_oe_line.update(1, 1, ImpOeLineUpdateParams(quantity=20))
        assert response.data.import_uid == 1
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "PUT"


class TestScheduledImportMetadataResource:
    """Tests for ScheduledImportMetadataResource."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_create_sftp(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create SFTP metadata for scheduled import master."""
        mock_response = {
            "count": 1,
            "data": {
                "host": "sftp.example.com",
                "port": 22,
                "username": "user",
            },
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-sism.augur-api.com/scheduled-import-master/1/metadata/sftp",
            json=mock_response,
            method="POST",
        )
        response = api.p21_sism.scheduled_import_metadata.create_sftp(
            1, ScheduledImportSftpMetadataCreateParams(host="sftp.example.com", username="user")
        )
        assert response.data is not None
        request = httpx_mock.get_request()
        assert request is not None
        assert request.method == "POST"


class TestResourceProperties:
    """Tests for resource property accessors."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_import_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same import_ resource instance."""
        client = api.p21_sism
        assert client.import_ is client.import_

    def test_imp_oe_hdr_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same imp_oe_hdr resource instance."""
        client = api.p21_sism
        assert client.imp_oe_hdr is client.imp_oe_hdr

    def test_imp_oe_hdr_salesrep_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same imp_oe_hdr_salesrep resource instance."""
        client = api.p21_sism
        assert client.imp_oe_hdr_salesrep is client.imp_oe_hdr_salesrep

    def test_imp_oe_hdr_web_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same imp_oe_hdr_web resource instance."""
        client = api.p21_sism
        assert client.imp_oe_hdr_web is client.imp_oe_hdr_web

    def test_imp_oe_line_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same imp_oe_line resource instance."""
        client = api.p21_sism
        assert client.imp_oe_line is client.imp_oe_line

    def test_scheduled_import_metadata_resource_same_instance(self, api: AugurAPI) -> None:
        """Should return same scheduled_import_metadata resource instance."""
        client = api.p21_sism
        assert client.scheduled_import_metadata is client.scheduled_import_metadata

    def test_import_resource_type(self, api: AugurAPI) -> None:
        """Should return ImportResource."""
        assert isinstance(api.p21_sism.import_, ImportResource)

    def test_imp_oe_hdr_resource_type(self, api: AugurAPI) -> None:
        """Should return ImpOeHdrResource."""
        assert isinstance(api.p21_sism.imp_oe_hdr, ImpOeHdrResource)

    def test_imp_oe_hdr_salesrep_resource_type(self, api: AugurAPI) -> None:
        """Should return ImpOeHdrSalesrepResource."""
        assert isinstance(api.p21_sism.imp_oe_hdr_salesrep, ImpOeHdrSalesrepResource)

    def test_imp_oe_hdr_web_resource_type(self, api: AugurAPI) -> None:
        """Should return ImpOeHdrWebResource."""
        assert isinstance(api.p21_sism.imp_oe_hdr_web, ImpOeHdrWebResource)

    def test_imp_oe_line_resource_type(self, api: AugurAPI) -> None:
        """Should return ImpOeLineResource."""
        assert isinstance(api.p21_sism.imp_oe_line, ImpOeLineResource)

    def test_scheduled_import_metadata_resource_type(self, api: AugurAPI) -> None:
        """Should return ScheduledImportMetadataResource."""
        assert isinstance(api.p21_sism.scheduled_import_metadata, ScheduledImportMetadataResource)

    def test_client_type(self, api: AugurAPI) -> None:
        """Should return P21SismClient."""
        assert isinstance(api.p21_sism, P21SismClient)
