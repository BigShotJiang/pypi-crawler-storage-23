"""Tests for the Shipping service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.shipping.schemas import (
    HealthCheckData,
    RateQuote,
    RatesParams,
)


class TestShippingSchemas:
    """Tests for Shipping schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_rates_params(self) -> None:
        """Should create rates params."""
        params = RatesParams(
            origin_zip="90210",
            destination_zip="10001",
            weight=5.0,
            length=10.0,
            width=8.0,
            height=6.0,
            carrier="UPS",
        )
        assert params.origin_zip == "90210"
        assert params.destination_zip == "10001"
        assert params.weight == 5.0
        assert params.carrier == "UPS"

    def test_rate_quote_model(self) -> None:
        """Should parse rate quote data."""
        data = {
            "carrier": "UPS",
            "serviceType": "ground",
            "serviceName": "UPS Ground",
            "rate": 12.99,
            "currency": "USD",
            "transitDays": 5,
            "guaranteed": False,
        }
        result = RateQuote.model_validate(data)
        assert result.carrier == "UPS"
        assert result.service_name == "UPS Ground"
        assert result.rate == 12.99
        assert result.transit_days == 5


class TestShippingClient:
    """Tests for ShippingClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://shipping.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.shipping.health_check()
        assert response.data.site_id == "test-site"

    def test_rates_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should calculate shipping rates."""
        mock_response = {
            "count": 2,
            "data": [
                {"carrier": "UPS", "serviceName": "Ground", "rate": 12.99},
                {"carrier": "UPS", "serviceName": "Express", "rate": 24.99},
            ],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 2,
            "totalResults": 2,
        }
        httpx_mock.add_response(
            method="POST",
            url="https://shipping.augur-api.com/rates",
            json=mock_response,
        )
        response = api.shipping.rates.create(
            RatesParams(origin_zip="90210", destination_zip="10001", weight=5.0)
        )
        assert len(response.data) == 2

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.shipping
        assert client.rates is client.rates
