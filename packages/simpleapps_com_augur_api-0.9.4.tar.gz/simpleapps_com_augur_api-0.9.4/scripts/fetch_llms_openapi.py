#!/usr/bin/env python3
"""
Fetch llms.txt, endpoints.jsonl, and OpenAPI specs to check sync status.

Data Sources (all generated from same code, should be in sync):
  - llms.txt:        Hint - endpoint list, human readable
  - endpoints.jsonl: Detail - structured params per endpoint
  - openapi.json:    Source of Truth - authoritative spec

Client directories checked:
  - TypeScript: packages/typescript/src/services/
  - Python:     packages/python/src/augur_api/services/

Usage:
  uv run python scripts/fetch_llms_openapi.py                    # Check all services
  uv run python scripts/fetch_llms_openapi.py items              # Check specific service
  uv run python scripts/fetch_llms_openapi.py --fetch            # Fetch and save all 3 specs
  uv run python scripts/fetch_llms_openapi.py --discover         # Discover new services
  uv run python scripts/fetch_llms_openapi.py --sync-todos items # Per-endpoint sync check
  uv run python scripts/fetch_llms_openapi.py --audit items      # Full audit (endpoints + params)
  uv run python scripts/fetch_llms_openapi.py --params items     # Detailed parameter audit
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

# Directory paths (relative to this script)
SCRIPT_DIR = Path(__file__).parent
PACKAGES_DIR = SCRIPT_DIR.parent.parent  # packages/
SHARED_DIR = PACKAGES_DIR.parent / "shared"
OPENAPI_DIR = SHARED_DIR / "openapi"
LLMS_DIR = SHARED_DIR / "llms-txt"
ENDPOINTS_JSONL_DIR = SHARED_DIR / "endpoints-jsonl"
DISCOVERED_SERVICES_FILE = SHARED_DIR / "discovered-services.json"

# Client directories
TS_SERVICES_DIR = PACKAGES_DIR / "typescript" / "src" / "services"
PY_SERVICES_DIR = PACKAGES_DIR / "python" / "src" / "augur_api" / "services"
PHP_SERVICES_DIR = PACKAGES_DIR / "php" / "src" / "AugurApi" / "Services"

# Known services (fallback if discovery fails)
KNOWN_SERVICES = [
    "agr-info",
    "agr-site",
    "agr-work",
    "avalara",
    "basecamp2",
    "brand-folder",
    "commerce",
    "customers",
    "gregorovich",
    "items",
    "joomla",
    "legacy",
    "logistics",
    "nexus",
    "open-search",
    "orders",
    "p21-apis",
    "p21-core",
    "p21-pim",
    "p21-sism",
    "payments",
    "pricing",
    "shipping",
    "slack",
    "smarty-streets",
    "ups",
    "vmi",
]

DISCOVERY_SEED_SERVICE = "items"


@dataclass
class ServiceStatus:
    """Status of a service's sync state."""

    service: str
    llms_exists: bool = False
    llms_endpoints: int = 0
    llms_endpoint_list: list[str] = field(default_factory=list)
    llms_generated: str | None = None
    openapi_endpoints: int = 0
    openapi_endpoint_list: list[str] = field(default_factory=list)
    ts_client_endpoints: int = 0
    py_client_endpoints: int = 0
    php_client_endpoints: int = 0
    local_openapi_exists: bool = False
    status: str = ""
    diff_in_llms_not_openapi: list[str] = field(default_factory=list)
    diff_in_openapi_not_llms: list[str] = field(default_factory=list)


@dataclass
class EndpointTodo:
    """Per-endpoint sync status."""

    method: str
    path: str
    in_llms: bool = False
    in_openapi: bool = False
    in_ts_client: bool = False
    in_py_client: bool = False
    in_php_client: bool = False
    status: str = "unknown"


@dataclass
class DiscoveredService:
    """Information about a discovered service."""

    name: str
    first_seen: str
    last_seen: str
    llms_generated: str | None
    source: str
    has_ts_client: bool
    has_py_client: bool
    has_php_client: bool


def fetch_url(url: str, timeout: float = 30.0) -> str | None:
    """Fetch content from a URL."""
    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.get(url)
            if response.status_code == 200:
                return response.text
    except httpx.HTTPError:
        pass
    return None


def parse_generated_timestamp(content: str) -> str | None:
    """Parse the Generated timestamp from llms.txt content."""
    match = re.search(r"^Generated:\s*(\d{4}-\d{2}-\d{2}T[\d:]+Z?)\s*$", content, re.MULTILINE)
    return match.group(1) if match else None


def parse_endpoints_from_llms(content: str) -> list[str]:
    """Parse endpoint lines from llms.txt content."""
    endpoints = []
    for line in content.split("\n"):
        trimmed = line.strip()
        if re.match(r"^(GET|POST|PUT|DELETE|PATCH)\s+/", trimmed):
            endpoints.append(trimmed)
    return sorted(endpoints)


def parse_endpoints_from_openapi(content: str) -> list[str]:
    """Parse endpoints from OpenAPI JSON content."""
    endpoints = []
    try:
        data = json.loads(content)
        paths = data.get("paths", {})
        for path_str, methods in paths.items():
            for method in methods:
                if method.lower() in ["get", "post", "put", "delete", "patch"]:
                    endpoints.append(f"{method.upper()} {path_str}")
    except json.JSONDecodeError:
        pass
    return sorted(endpoints)


# =============================================================================
# endpoints.jsonl Support
# =============================================================================


@dataclass
class EndpointParams:
    """Structured endpoint with parameters from endpoints.jsonl."""

    method: str
    path: str
    query_params: list[dict[str, Any]] = field(default_factory=list)
    path_params: list[dict[str, Any]] = field(default_factory=list)
    header_params: list[dict[str, Any]] = field(default_factory=list)


def fetch_endpoints_jsonl(service: str, save: bool = False) -> list[EndpointParams]:
    """Fetch and parse endpoints.jsonl for a service."""
    url = f"https://{service}.augur-api.com/endpoints.jsonl"
    content = fetch_url(url)
    if not content:
        return []

    if save:
        ENDPOINTS_JSONL_DIR.mkdir(parents=True, exist_ok=True)
        (ENDPOINTS_JSONL_DIR / f"{service}.jsonl").write_text(content)

    return parse_endpoints_jsonl(content)


def parse_endpoints_jsonl(content: str) -> list[EndpointParams]:
    """Parse endpoints.jsonl content into structured objects."""
    endpoints = []
    for line in content.strip().split("\n"):
        if not line.strip():
            continue
        try:
            data = json.loads(line)
            ep = EndpointParams(
                method=data.get("method", ""),
                path=data.get("path", ""),
                query_params=data.get("queryParams", []),
                path_params=data.get("pathParams", []),
                header_params=data.get("headerParams", []),
            )
            endpoints.append(ep)
        except json.JSONDecodeError:
            continue
    return endpoints


def snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def extract_ts_schema_params(service: str) -> dict[str, set[str]]:
    """Extract query params from TypeScript *Params* schemas only."""
    schemas_dir = TS_SERVICES_DIR / service / "schemas"
    if not schemas_dir.exists():
        return {}

    all_params: set[str] = set()
    for schema_file in schemas_dir.glob("*.ts"):
        if schema_file.name == "index.ts":
            continue
        content = schema_file.read_text()
        # Only extract from *ParamsSchema definitions
        # Match: export const SomethingParamsSchema = z.object({ ... })
        # Also handles multi-line: z\n  .object({...})
        for block_match in re.finditer(
            r"export const \w*Params\w*Schema\s*=\s*(?:z\s*\.object\(|"
            r"z\.object\(|"
            r"\w+\.extend\()\s*\{([^}]+)\}",
            content,
            re.DOTALL,
        ):
            block = block_match.group(1)
            # Extract field names from the block
            for field_match in re.finditer(r"['\"]?([\w-]+)['\"]?\s*:", block):
                param = field_match.group(1)
                if param not in {"data", "response", "error", "message"}:
                    all_params.add(param)

    return {"all": all_params}


def extract_py_schema_params(service: str) -> dict[str, set[str]]:
    """Extract query params from Python *Params classes only."""
    py_service = service.replace("-", "_")
    schemas_dir = PY_SERVICES_DIR / py_service / "schemas"
    schemas_file = PY_SERVICES_DIR / py_service / "schemas.py"

    all_params: set[str] = set()
    schema_files: list[Path] = []

    # Check for schemas directory (TypeScript pattern)
    if schemas_dir.exists():
        schema_files = [f for f in schemas_dir.glob("*.py") if f.name != "__init__.py"]
    # Check for single schemas.py file (Python pattern)
    elif schemas_file.exists():
        schema_files = [schemas_file]
    else:
        return {}

    for schema_file in schema_files:
        content = schema_file.read_text()
        lines = content.split("\n")

        # Find *Params classes and extract their fields
        in_params_class = False
        for line in lines:
            # Check for start of a Params class
            if re.match(r"class \w*Params\w*\(", line):
                in_params_class = True
                continue
            # Check for end of class (new class or non-indented line)
            is_unindented = line and not line.startswith(" ") and not line.startswith("\t")
            ends_class = line.startswith("class ") or not line.startswith("#")
            if in_params_class and is_unindented and ends_class:
                in_params_class = False
                continue
            # Extract field if in a Params class
            if in_params_class:
                field_match = re.match(r"\s+([\w_]+)\s*:", line)
                if field_match:
                    param = field_match.group(1)
                    if not param.startswith("_") and param not in {"model_config"}:
                        all_params.add(param)
                # Also check for serialization_alias
                alias_match = re.search(r'serialization_alias\s*=\s*["\']([^"\']+)["\']', line)
                if alias_match:
                    all_params.add(alias_match.group(1))

    return {"all": all_params}


def _print_missing_params(
    label: str, missing: list[tuple[str, str, list[str]]], limit: int = 10
) -> set[str]:
    """Print missing params for a client, return all unique missing params."""
    if not missing:
        return set()
    print(f"\n❌ {label} missing params ({len(missing)} endpoints affected):")
    for endpoint, _, params in missing[:limit]:
        print(f"   {endpoint}")
        print(f"      Missing: {', '.join(params)}")
    if len(missing) > limit:
        print(f"   ... and {len(missing) - limit} more")
    # Collect all unique missing
    all_missing: set[str] = set()
    for _, _, params in missing:
        all_missing.update(params)
    return all_missing


def _analyze_endpoint_params(
    jsonl_endpoints: list[EndpointParams], ts_all: set[str], py_all: set[str]
) -> tuple[list[tuple[str, str, list[str]]], list[tuple[str, str, list[str]]], set[str]]:
    """Analyze params for all endpoints, return (ts_missing, py_missing, all_api_params)."""
    missing_ts: list[tuple[str, str, list[str]]] = []
    missing_py: list[tuple[str, str, list[str]]] = []
    all_api_params: set[str] = set()

    for ep in sorted(jsonl_endpoints, key=lambda x: (x.path, x.method)):
        if not ep.query_params:
            continue
        endpoint_key = f"{ep.method} {ep.path}"
        # endpoints.jsonl uses camelCase names (e.g., orderBy, statusCd)
        param_names_camel = [p["name"] for p in ep.query_params]
        param_names_snake = [camel_to_snake(p) for p in param_names_camel]
        all_api_params.update(param_names_camel)

        ts_missing = [p for p in param_names_camel if p not in ts_all]
        py_missing_snake = [p for p in param_names_snake if p not in py_all]

        if ts_missing:
            missing_ts.append((endpoint_key, ep.path, ts_missing))
        if py_missing_snake:
            missing_py.append((endpoint_key, ep.path, py_missing_snake))

    return missing_ts, missing_py, all_api_params


def run_params_audit(service: str) -> None:  # noqa: PLR0912, PLR0915
    """Audit query parameters using all three data sources."""
    print(f"\n🔍 PARAMETER AUDIT: {service}")
    print("=" * 90)
    print("\n📥 Fetching data sources...")

    # Fetch all three sources
    llms_exists, llms_endpoints, llms_generated = fetch_llms_endpoints(service, save=False)
    gen_info = f" [{llms_generated[:10]}]" if llms_generated else ""
    llms_icon = "✅" if llms_exists else "❌"
    print(f"   {llms_icon} llms.txt: {len(llms_endpoints)} endpoints{gen_info} (hint)")

    jsonl_endpoints = fetch_endpoints_jsonl(service, save=False)
    jsonl_icon = "✅" if jsonl_endpoints else "❌"
    print(f"   {jsonl_icon} endpoints.jsonl: {len(jsonl_endpoints)} endpoints (detail)")

    openapi_content = fetch_url(f"https://{service}.augur-api.com/openapi.json")
    if not openapi_content:
        print("   ❌ openapi.json: Could not fetch")
        return
    openapi_endpoints = parse_endpoints_from_openapi(openapi_content)
    print(f"   ✅ openapi.json: {len(openapi_endpoints)} endpoints (SOURCE OF TRUTH)")

    if not jsonl_endpoints:
        print("\n❌ Cannot audit params without endpoints.jsonl")
        return

    # Get client schema params and analyze
    ts_all = extract_ts_schema_params(service).get("all", set())
    py_all = extract_py_schema_params(service).get("all", set())

    print("\n" + "─" * 90)
    print("PARAMETER ANALYSIS")
    print("─" * 90)

    missing_ts, missing_py, all_api_params = _analyze_endpoint_params(
        jsonl_endpoints, ts_all, py_all
    )

    # Print summary
    print("\n" + "=" * 90)
    print("📊 PARAMETER AUDIT SUMMARY")
    print("=" * 90)
    print(f"\nAPI has {len(all_api_params)} unique query parameters")
    print(f"TypeScript schemas have {len(ts_all)} params defined")
    print(f"Python schemas have {len(py_all)} params defined")

    all_missing_ts = _print_missing_params("TypeScript", missing_ts)
    all_missing_py = _print_missing_params("Python", missing_py)

    if not missing_ts and not missing_py:
        print("\n🎉 All API query parameters are defined in both clients!")

    if all_missing_ts:
        print(f"\n📋 All missing TypeScript params: {', '.join(sorted(all_missing_ts))}")
    if all_missing_py:
        print(f"📋 All missing Python params: {', '.join(sorted(all_missing_py))}")

    # Compare client params against API spec (source of truth)
    # Normalize all to snake_case for comparison
    api_normalized = {camel_to_snake(p) for p in all_api_params}
    ts_normalized = {camel_to_snake(p) for p in ts_all}
    py_normalized = {camel_to_snake(p) for p in py_all}

    # Params in clients but NOT in API (shouldn't exist)
    ts_extra = ts_normalized - api_normalized
    py_extra = py_normalized - api_normalized

    # Params in API but missing from clients
    ts_missing_api = api_normalized - ts_normalized
    py_missing_api = api_normalized - py_normalized

    print("\n" + "─" * 90)
    print("CLIENT PARITY CHECK (vs API Spec)")
    print("─" * 90)
    print(f"\nAPI defines {len(api_normalized)} unique query params")
    print(f"TypeScript has {len(ts_normalized)} params, Python has {len(py_normalized)} params")

    has_issues = False

    if ts_extra:
        has_issues = True
        print(f"\n❌ TypeScript has {len(ts_extra)} params NOT in API (remove these):")
        for p in sorted(ts_extra)[:15]:
            print(f"   - {p}")
        if len(ts_extra) > 15:
            print(f"   ... and {len(ts_extra) - 15} more")

    if py_extra:
        has_issues = True
        print(f"\n❌ Python has {len(py_extra)} params NOT in API (remove these):")
        for p in sorted(py_extra):
            print(f"   - {p}")

    if ts_missing_api:
        has_issues = True
        print(f"\n❌ TypeScript missing {len(ts_missing_api)} API params (add these):")
        for p in sorted(ts_missing_api):
            print(f"   - {p}")

    if py_missing_api:
        has_issues = True
        print(f"\n❌ Python missing {len(py_missing_api)} API params (add these):")
        for p in sorted(py_missing_api):
            print(f"   - {p}")

    if not has_issues:
        print(f"\n✅ Both clients match API spec exactly ({len(api_normalized)} params)")
    print("")


def parse_services_from_llms(content: str) -> list[str]:
    """Parse service names from the 'Other Services' section of llms.txt."""
    services = []
    lines = content.split("\n")
    in_other_services = False

    for line in lines:
        trimmed = line.strip()

        # Check for "Other Services" header
        if re.match(r"^#+\s*other\s*services", trimmed, re.IGNORECASE):
            in_other_services = True
            continue

        # Check for other section headers (stop parsing)
        if (
            in_other_services
            and re.match(r"^#+\s", trimmed)
            and not re.match(r"^#+\s*other\s*services", trimmed, re.IGNORECASE)
        ):
            break

        if in_other_services and trimmed:
            # Try markdown link format: "- [service-name](url)"
            link_match = re.match(r"^-?\s*\[([^\]]+)\]", trimmed)
            if link_match:
                services.append(link_match.group(1))
                continue

            # Try bullet format: "- service-name"
            bullet_match = re.match(r"^-\s+(.+)", trimmed)
            if bullet_match:
                services.append(bullet_match.group(1))
                continue

            # Plain service name
            if re.match(r"^[a-z][a-z0-9-]*$", trimmed, re.IGNORECASE):
                services.append(trimmed)

    return sorted(services)


def has_ts_client(service: str) -> bool:
    """Check if TypeScript client exists for a service."""
    client_path = TS_SERVICES_DIR / service / "client.ts"
    return client_path.exists()


def has_py_client(service: str) -> bool:
    """Check if Python client exists for a service."""
    # Python uses underscores instead of hyphens
    py_service = service.replace("-", "_")
    client_path = PY_SERVICES_DIR / py_service / "client.py"
    return client_path.exists()


def has_php_client(service: str) -> bool:
    """Check if PHP client exists for a service."""
    # PHP uses PascalCase
    php_service = service_to_php_name(service)
    client_path = PHP_SERVICES_DIR / php_service / f"{php_service}Client.php"
    return client_path.exists()


def count_ts_client_endpoints(service: str) -> int:
    """Count endpoints in TypeScript client resources."""
    resource_dir = TS_SERVICES_DIR / service / "resources"
    if not resource_dir.exists():
        return 0

    count = 0
    for file_path in resource_dir.glob("*.ts"):
        if file_path.name == "index.ts":
            continue
        content = file_path.read_text()
        method_pattern = r"method:\s*['\"](?:GET|POST|PUT|DELETE|PATCH)['\"]"
        matches = re.findall(method_pattern, content, re.IGNORECASE)
        count += len(matches)

    return count


def count_py_client_endpoints(service: str) -> int:
    """Count endpoints in Python client."""
    py_service = service.replace("-", "_")
    client_path = PY_SERVICES_DIR / py_service / "client.py"
    if not client_path.exists():
        return 0

    content = client_path.read_text()
    # Count method patterns: self._get, self._post, self._put, self._delete
    matches = re.findall(r"self\._(?:get|post|put|delete)\s*\(", content, re.IGNORECASE)
    return len(matches)


def service_to_php_name(service: str) -> str:
    """Convert service name (kebab-case) to PHP PascalCase directory name."""
    # Split by hyphens and capitalize each part
    parts = service.split("-")
    return "".join(p.capitalize() for p in parts)


def count_php_client_endpoints(service: str) -> int:
    """Count endpoints in PHP client resources.

    PHP services have:
    - 3 common endpoints in BaseServiceClient (healthCheck, ping, whoami)
    - Resource files in Resources/ subdirectory
    """
    php_service = service_to_php_name(service)
    service_dir = PHP_SERVICES_DIR / php_service
    if not service_dir.exists():
        return 0

    # Start with 3 for BaseServiceClient methods (healthCheck, ping, whoami)
    # These are defined in BaseServiceClient.php and inherited by all services
    count = 3

    # Count methods in Resource files
    resources_dir = service_dir / "Resources"
    if resources_dir.exists():
        for file_path in resources_dir.glob("*Resource.php"):
            content = file_path.read_text()
            # Count public function declarations (excluding __construct)
            matches = re.findall(
                r"public\s+function\s+(?!__construct)\w+\s*\(",
                content,
                re.IGNORECASE,
            )
            count += len(matches)

    return count


def check_endpoint_in_php_client(method: str, api_path: str, service: str) -> bool:
    """Check if an endpoint is implemented in PHP client."""
    # Common endpoints handled by BaseServiceClient
    if api_path in ("/health-check", "/ping", "/whoami") and method.upper() == "GET":
        return True

    php_service = service_to_php_name(service)
    resources_dir = PHP_SERVICES_DIR / php_service / "Resources"
    if not resources_dir.exists():
        return False

    # Normalize path for comparison
    def normalize_path(path: str) -> str:
        return re.sub(r"\{[^}]+\}", "{PARAM}", path)

    api_path_normalized = normalize_path(api_path)

    # Map HTTP methods to PHP client method names
    method_map = {
        "GET": "get",
        "POST": "post",
        "PUT": "put",
        "DELETE": "delete",
        "PATCH": "patch",
    }
    php_method = method_map.get(method.upper(), "get")

    for file_path in resources_dir.glob("*Resource.php"):
        content = file_path.read_text()
        # Look for the path in client calls: $this->client->get($this->baseUrl, '/path', ...)
        path_pattern = api_path_normalized.replace("{PARAM}", r"\{[^}]+\}")
        if re.search(
            rf"\$this->client->{php_method}\s*\([^,]+,\s*['\"]/?{path_pattern}['\"]", content
        ):
            return True

    return False


def check_endpoint_in_ts_client(method: str, api_path: str, service: str) -> bool:
    """Check if an endpoint is implemented in TypeScript client."""
    service_dir = TS_SERVICES_DIR / service
    resource_dir = service_dir / "resources"

    # Create two path patterns:
    # 1. Path template pattern: matches {id}, {productsUid}
    # 2. Template literal pattern: matches ${id}, ${productsUid}
    temp_path = re.sub(r"\{[^}]+\}", "__PARAM__", api_path.lstrip("/"))
    temp_path = re.escape(temp_path)
    # Pattern for path templates like '/products/{id}'
    path_pattern_template = temp_path.replace("__PARAM__", r"\{[^}]+\}")
    # Pattern for template literals like `/products/${id}`
    path_pattern_literal = temp_path.replace("__PARAM__", r"\$\{[^}]+\}")

    # Map of helper method patterns to HTTP methods
    helper_method_map = {
        "GET": ["createListMethod", "createGetMethod", "createHealthCheckMethod"],
        "POST": ["createCreateMethod"],
        "PUT": ["createUpdateMethod"],
        "DELETE": ["createDeleteMethod"],
    }

    def check_file_content(content: str) -> bool:
        """Check if file content has matching path and method."""
        # First, check for standard executeRequest pattern with method: and path:
        method_pat = rf"method:\s*['\"]?{method}['\"]?"
        path_pat_template = rf"path:\s*['\"`]/?{path_pattern_template}['\"`]"
        path_pat_literal = rf"path:\s*`/?{path_pattern_literal}`"

        has_standard_method = re.search(method_pat, content, re.IGNORECASE)
        has_standard_path = re.search(path_pat_template, content, re.IGNORECASE) or re.search(
            path_pat_literal, content, re.IGNORECASE
        )
        if has_standard_method and has_standard_path:
            return True

        # Check for helper method patterns like createListMethod('/path', ...)
        helper_methods = helper_method_map.get(method.upper(), [])
        for helper in helper_methods:
            # Pattern: createListMethod('/path', ...) or createHealthCheckMethod(...)
            if helper == "createHealthCheckMethod" and api_path == "/health-check":
                if re.search(rf"{helper}\s*\(", content):
                    return True
            else:
                # Match createListMethod('/legacy/state', ...) etc.
                helper_pat = rf"{helper}\s*\(\s*['\"]/?{path_pattern_template}['\"]"
                if re.search(helper_pat, content, re.IGNORECASE):
                    return True

        return False

    # Check resources directory
    if resource_dir.exists():
        for file_path in resource_dir.glob("*.ts"):
            if file_path.name == "index.ts":
                continue
            content = file_path.read_text()
            if check_file_content(content):
                return True

    # Check client.ts
    client_file = service_dir / "client.ts"
    if client_file.exists():
        content = client_file.read_text()
        if check_file_content(content):
            return True

    return False


def check_endpoint_in_py_client(method: str, api_path: str, service: str) -> bool:  # noqa: PLR0911, PLR0912
    """Check if an endpoint is implemented in Python client."""
    py_service = service.replace("-", "_")
    client_path = PY_SERVICES_DIR / py_service / "client.py"
    if not client_path.exists():
        return False

    # Check for common endpoints that are in BaseServiceClient
    # These are inherited by all service clients
    if api_path in ("/health-check", "/ping", "/whoami") and method.upper() == "GET":
        return True

    content = client_path.read_text()

    # Map HTTP methods to Python method patterns
    method_map = {
        "GET": "_get",
        "POST": "_post",
        "PUT": "_put",
        "DELETE": "_delete",
        "PATCH": "_patch",
    }
    py_method = method_map.get(method.upper(), "_get")

    # Map HTTP methods to direct http client method names
    http_method = method.lower()

    # Find all base paths from super().__init__(http, "/path")
    # Also match f-string base paths like f"/inv-profile-hdr/{inv_profile_hdr_uid}/inv-profile-line"
    base_pattern = r'super\(\).__init__\s*\([^,]+,\s*f?["\']([^"\']+)["\']'
    base_paths = re.findall(base_pattern, content)

    # Check if the method type exists in the file (either self._post or self._http.post)
    has_resource_method = re.search(rf"self\.{py_method}\s*\(", content) is not None
    has_http_method = re.search(rf"self\._http\.{http_method}\s*\(", content) is not None
    if not has_resource_method and not has_http_method:
        return False

    def normalize_path(path: str) -> str:
        """Normalize path by replacing params with a placeholder."""
        return re.sub(r"\{[^}]+\}", "{PARAM}", path)

    api_path_normalized = normalize_path(api_path)

    # Check each base path
    for base_path in base_paths:
        base_path_normalized = normalize_path(base_path)
        if not api_path_normalized.startswith(base_path_normalized):
            continue

        # Get relative path (using normalized lengths)
        relative_path = api_path_normalized[len(base_path_normalized) :]

        # Case 1: api_path exactly matches base_path (e.g., /rates)
        if relative_path in {"", "/"}:
            # Method with no path arg or data/params: self._post(data=...)
            if re.search(rf"self\.{py_method}\s*\(\s*(?:data|params)\s*=", content):
                return True
            # Method with empty call: self._get()
            if re.search(rf"self\.{py_method}\s*\(\s*\)", content):
                return True

        # Case 2: relative path is just a param like /{id}
        elif re.match(r"^/\{[^}]+\}$", relative_path):
            # Look for f"/{var}" pattern
            if re.search(rf'self\.{py_method}\s*\(f?["\']/?{{', content):
                return True
            # Also check for f"/{something}"
            if re.search(rf'self\.{py_method}\s*\(f["\']/', content):
                return True

        # Case 3: relative path is a fixed sub-path (e.g., /refresh, /lookup)
        elif "{" not in relative_path:
            # Look for exact relative path
            rel_escaped = re.escape(relative_path)
            if re.search(rf'self\.{py_method}\s*\([^)]*["\']/?{rel_escaped}["\']', content):
                return True

        # Case 4: complex path with params (e.g., /{id}/comments)
        else:
            # Convert params to flexible pattern
            rel_pattern = re.escape(relative_path)
            rel_pattern = re.sub(r"\\{[^}]+\\}", r"[^/]+", rel_pattern)
            if re.search(rf"self\.{py_method}\s*\([^)]*{rel_pattern}", content):
                return True

    # Fallback: check for full path anywhere in file
    path_pattern = re.escape(api_path)
    path_pattern = re.sub(r"\\{[^}]+\\}", r"[^/]+", path_pattern)
    if re.search(rf'["\']/?{path_pattern}["\']', content, re.IGNORECASE):
        return True

    # Check for self._http.{method} patterns with f-string paths
    # Pattern like: self._http.post(f"{self._path}/{var}/add", ...)
    for base_path in base_paths:
        base_path_normalized = normalize_path(base_path)
        if not api_path_normalized.startswith(base_path_normalized):
            continue
        relative_path = api_path_normalized[len(base_path_normalized) :]
        if relative_path:
            # Convert path params to flexible pattern
            rel_pattern = re.sub(r"\{[^}]+\}", r"[^/\"']+", relative_path)
            rel_escaped = (
                re.escape(rel_pattern)
                .replace(r"\[", "[")
                .replace(r"\]", "]")
                .replace(r"\^", "^")
                .replace(r"\+", "+")
            )
            # Match f"{self._path}/{var}/add" style
            fstring_pattern = rf'self\._http\.{http_method}\s*\(\s*f["\'][^"\']*{rel_escaped}'
            if re.search(fstring_pattern, content, re.IGNORECASE):
                return True

    return False


def fetch_llms_endpoints(service: str, save: bool = False) -> tuple[bool, list[str], str | None]:
    """Fetch llms.txt endpoints for a service."""
    url = f"https://{service}.augur-api.com/llms.txt"
    content = fetch_url(url)

    if content is None:
        return False, [], None

    if save:
        LLMS_DIR.mkdir(parents=True, exist_ok=True)
        (LLMS_DIR / f"{service}.txt").write_text(content)

    return True, parse_endpoints_from_llms(content), parse_generated_timestamp(content)


def fetch_openapi_endpoints(service: str, save: bool = False) -> list[str]:
    """Fetch OpenAPI endpoints for a service."""
    local_path = OPENAPI_DIR / f"{service}.json"

    # Try local first if not saving
    if not save and local_path.exists():
        content = local_path.read_text()
        return parse_endpoints_from_openapi(content)

    # Fetch from remote
    url = f"https://{service}.augur-api.com/openapi.json"
    content = fetch_url(url)

    if content is None:
        # Fall back to local if exists
        if local_path.exists():
            return parse_endpoints_from_openapi(local_path.read_text())
        return []

    if save:
        OPENAPI_DIR.mkdir(parents=True, exist_ok=True)
        local_path.write_text(content)

    return parse_endpoints_from_openapi(content)


def determine_status(result: ServiceStatus) -> str:
    """Determine sync status string."""
    if not result.llms_exists:
        return "❌ No llms.txt"
    if result.llms_endpoints == 0:
        return "⚠️ llms.txt empty/old format"
    if result.llms_endpoints == result.openapi_endpoints and not result.diff_in_llms_not_openapi:
        return "✅ Synced"
    if result.diff_in_llms_not_openapi:
        return f"⚠️ OpenAPI missing {len(result.diff_in_llms_not_openapi)}"
    if result.diff_in_openapi_not_llms:
        return f"⚠️ llms.txt missing {len(result.diff_in_openapi_not_llms)}"
    return "⚠️ Mismatch"


def check_service(service: str, fetch_and_save: bool = False) -> ServiceStatus:
    """Check sync status for a service."""
    local_openapi_exists = (OPENAPI_DIR / f"{service}.json").exists()

    llms_exists, llms_endpoints, llms_generated = fetch_llms_endpoints(service, fetch_and_save)
    openapi_endpoints = fetch_openapi_endpoints(service, fetch_and_save)

    # Also fetch and optionally save endpoints.jsonl
    fetch_endpoints_jsonl(service, save=fetch_and_save)

    llms_set = set(llms_endpoints)
    openapi_set = set(openapi_endpoints)

    result = ServiceStatus(
        service=service,
        llms_exists=llms_exists,
        llms_endpoints=len(llms_endpoints),
        llms_endpoint_list=llms_endpoints,
        llms_generated=llms_generated,
        openapi_endpoints=len(openapi_endpoints),
        openapi_endpoint_list=openapi_endpoints,
        ts_client_endpoints=count_ts_client_endpoints(service),
        py_client_endpoints=count_py_client_endpoints(service),
        php_client_endpoints=count_php_client_endpoints(service),
        local_openapi_exists=local_openapi_exists,
        diff_in_llms_not_openapi=[e for e in llms_endpoints if e not in openapi_set],
        diff_in_openapi_not_llms=[e for e in openapi_endpoints if e not in llms_set],
    )

    result.status = determine_status(result)
    return result


def load_discovered_services() -> dict[str, Any]:
    """Load discovered services from JSON file."""
    if DISCOVERED_SERVICES_FILE.exists():
        try:
            return json.loads(DISCOVERED_SERVICES_FILE.read_text())
        except json.JSONDecodeError:
            pass
    return {"lastUpdated": datetime.now(tz=UTC).isoformat(), "discoveredFrom": [], "services": {}}


def save_discovered_services(data: dict[str, Any]) -> None:
    """Save discovered services to JSON file."""
    data["lastUpdated"] = datetime.now(tz=UTC).isoformat()
    DISCOVERED_SERVICES_FILE.parent.mkdir(parents=True, exist_ok=True)
    DISCOVERED_SERVICES_FILE.write_text(json.dumps(data, indent=2))


def discover_services() -> tuple[list[str], list[str], dict[str, Any]]:
    """Discover all services from llms.txt cross-references."""
    previous_data = load_discovered_services()
    now = datetime.now(tz=UTC).isoformat()
    discovered_services: set[str] = set()
    sources_used: list[str] = []

    # Services to check for discovery
    services_with_llms = list(previous_data.get("services", {}).keys())
    to_check = list({DISCOVERY_SEED_SERVICE, *services_with_llms, *KNOWN_SERVICES})

    print("\n🔍 Service Discovery")
    print("=" * 50)
    print(f"Checking {len(to_check)} potential sources...\n")

    for service in to_check:
        url = f"https://{service}.augur-api.com/llms.txt"
        content = fetch_url(url)
        if content:
            found_services = parse_services_from_llms(content)
            if found_services:
                sources_used.append(service)
                print(f"  ✓ {service}: found {len(found_services)} services")
                discovered_services.update(found_services)
            discovered_services.add(service)

    # Update discovered services data
    all_services = sorted(discovered_services)
    new_services = []

    for service in all_services:
        if service not in previous_data.get("services", {}):
            new_services.append(service)
            previous_data.setdefault("services", {})[service] = {
                "name": service,
                "firstSeen": now,
                "lastSeen": now,
                "llmsGenerated": None,
                "source": sources_used[0] if sources_used else "direct",
                "hasTsClient": has_ts_client(service),
                "hasPyClient": has_py_client(service),
                "hasPhpClient": has_php_client(service),
            }
        else:
            previous_data["services"][service]["lastSeen"] = now
            previous_data["services"][service]["hasTsClient"] = has_ts_client(service)
            previous_data["services"][service]["hasPyClient"] = has_py_client(service)
            previous_data["services"][service]["hasPhpClient"] = has_php_client(service)

    previous_data["discoveredFrom"] = sources_used
    return all_services, new_services, previous_data


def print_discovery_results(
    all_services: list[str], new_services: list[str], data: dict[str, Any]
) -> None:
    """Print discovery results."""
    print("\n" + "=" * 70)
    print("DISCOVERY RESULTS")
    print("=" * 70)

    if new_services:
        print("\n🚨 NEW SERVICES DISCOVERED:")
        for service in new_services:
            print(f"   🆕 {service}")

    print("\n" + "-" * 80)
    print(f"{'Service':<20} {'First Seen':<12} {'TS':<4} {'PY':<4} {'PHP':<4} Source")
    print("-" * 80)

    for service in all_services:
        info = data["services"].get(service, {})
        first_seen = info.get("firstSeen", "")[:10]
        has_ts = "✅" if info.get("hasTsClient") else "❌"
        has_py = "✅" if info.get("hasPyClient") else "❌"
        has_php = "✅" if info.get("hasPhpClient") else "❌"
        source = info.get("source", "unknown")
        print(f"{service:<20} {first_seen:<12} {has_ts:<4} {has_py:<4} {has_php:<4} {source}")

    with_ts = sum(1 for s in all_services if data["services"].get(s, {}).get("hasTsClient"))
    with_py = sum(1 for s in all_services if data["services"].get(s, {}).get("hasPyClient"))
    with_php = sum(1 for s in all_services if data["services"].get(s, {}).get("hasPhpClient"))

    print("\n" + "=" * 80)
    total = len(all_services)
    new = len(new_services)
    print(f"Total: {total} services | TS: {with_ts} | PY: {with_py} | PHP: {with_php} | New: {new}")
    print("")


def print_summary_table(results: list[ServiceStatus]) -> None:
    """Print summary table of all services."""
    print("\n" + "=" * 100)
    print("SUMMARY (TS = TypeScript, PY = Python, PHP = PHP)")
    print("=" * 100)
    cols = [f"{'Service':<16}", f"{'llms':>5}", f"{'API':>5}", f"{'TS':>4}"]
    cols.extend([f"{'PY':>4}", f"{'PHP':>4}", f"{'Generated':>12}", f"{'Status':>20}"])
    hdr = " ".join(cols)
    print(hdr)
    print("-" * 100)

    for r in results:
        llms = str(r.llms_endpoints) if r.llms_exists else "-"
        openapi = str(r.openapi_endpoints) or "-"
        ts_client = str(r.ts_client_endpoints) or "-"
        py_client = str(r.py_client_endpoints) or "-"
        php_client = str(r.php_client_endpoints) or "-"
        generated = r.llms_generated[:12] if r.llms_generated else "-"
        row = (
            f"{r.service:<16} {llms:>5} {openapi:>5} {ts_client:>4} {py_client:>4} {php_client:>4}"
        )
        row += f" {generated:>12} {r.status:>20}"
        print(row)


def print_differences(results: list[ServiceStatus]) -> None:
    """Print endpoint differences."""
    mismatched = [r for r in results if r.diff_in_llms_not_openapi or r.diff_in_openapi_not_llms]

    if not mismatched:
        return

    print("\n" + "=" * 70)
    print("DIFFERENCES")
    print("=" * 70)

    for r in mismatched:
        print(f"\n{r.service}:")
        if r.diff_in_llms_not_openapi:
            print("  In llms.txt but NOT in OpenAPI:")
            for e in r.diff_in_llms_not_openapi:
                print(f"    {e}")
        if r.diff_in_openapi_not_llms:
            print("  In OpenAPI but NOT in llms.txt:")
            for e in r.diff_in_openapi_not_llms:
                print(f"    {e}")


def _determine_endpoint_status(
    in_openapi: bool, in_ts: bool, in_py: bool, in_php: bool = True
) -> str:
    """Determine status string for an endpoint."""
    if not in_openapi:
        return "missing-openapi"
    if in_ts and in_py and in_php:
        return "complete"
    if not in_ts and not in_py and not in_php:
        return "missing-clients"
    if not in_ts:
        return "missing-ts"
    if not in_py:
        return "missing-py"
    if not in_php:
        return "missing-php"
    return "partial"


def _print_sync_todo_table(todos: list[EndpointTodo]) -> None:
    """Print the sync todo results table."""
    print(f"\n{'Method':<8} {'Path':<40} {'API':<6} {'TS':<6} {'PY':<6} {'PHP':<6} Status")
    print("-" * 100)

    sorted_todos = sorted(todos, key=lambda t: (t.status == "complete", t.path))
    status_map = {
        "complete": "✅",
        "missing-all": "🔴 All",
        "missing-openapi": "⚠️ No API",
        "missing-clients": "⚠️ No Clients",
        "missing-ts": "⚠️ No TS",
        "missing-py": "⚠️ No PY",
        "missing-php": "⚠️ No PHP",
        "partial": "⚠️",
    }

    for t in sorted_todos:
        api_icon = "✅" if t.in_openapi else "❌"
        ts_icon = "✅" if t.in_ts_client else "❌"
        py_icon = "✅" if t.in_py_client else "❌"
        php_icon = "✅" if t.in_php_client else "❌"
        status_icon = status_map.get(t.status, "❓")
        print(
            f"{t.method:<8} {t.path:<40} {api_icon:<6} {ts_icon:<6} {py_icon:<6} {php_icon:<6} {status_icon}"
        )


def _print_sync_summary(service: str, todos: list[EndpointTodo]) -> None:
    """Print sync summary."""
    complete = sum(1 for t in todos if t.status == "complete")
    missing_ts = sum(1 for t in todos if not t.in_ts_client)
    missing_py = sum(1 for t in todos if not t.in_py_client)
    missing_php = sum(1 for t in todos if not t.in_php_client)

    print("\n" + "=" * 90)
    print(f"📊 Summary for {service}:")
    print(f"   ✅ Complete: {complete}/{len(todos)}")
    if missing_ts > 0:
        print(f"   ⚠️  Missing from TypeScript: {missing_ts}")
    if missing_py > 0:
        print(f"   ⚠️  Missing from Python: {missing_py}")
    if missing_php > 0:
        print(f"   ⚠️  Missing from PHP: {missing_php}")
    print("")


def _fetch_sync_data(service: str) -> tuple[list[str], dict[str, Any]] | None:
    """Fetch llms and openapi data, return None if failed."""
    url = f"https://{service}.augur-api.com/llms.txt"
    llms_content = fetch_url(url)
    if not llms_content:
        print(f"❌ Could not fetch llms.txt for {service}")
        return None

    openapi_url = f"https://{service}.augur-api.com/openapi.json"
    openapi_content = fetch_url(openapi_url)
    if not openapi_content:
        print(f"❌ Could not fetch OpenAPI for {service}")
        return None

    try:
        openapi_data = json.loads(openapi_content)
    except json.JSONDecodeError:
        print(f"❌ Invalid OpenAPI JSON for {service}")
        return None

    return parse_endpoints_from_llms(llms_content), openapi_data


def run_sync_todos(service: str) -> None:
    """Run per-endpoint sync check for a service."""
    print(f"\n📋 SYNC TODOS: {service}")
    print("=" * 90)

    result = _fetch_sync_data(service)
    if result is None:
        return

    llms_endpoints, openapi_data = result
    openapi_paths = openapi_data.get("paths", {})
    todos: list[EndpointTodo] = []

    for endpoint in llms_endpoints:
        match = re.match(r"^(GET|POST|PUT|DELETE|PATCH)\s+(\S+)", endpoint)
        if not match:
            continue

        method, api_path = match.groups()
        in_openapi = api_path in openapi_paths and method.lower() in openapi_paths.get(api_path, {})
        in_ts = check_endpoint_in_ts_client(method, api_path, service)
        in_py = check_endpoint_in_py_client(method, api_path, service)
        in_php = check_endpoint_in_php_client(method, api_path, service)
        status = _determine_endpoint_status(in_openapi, in_ts, in_py, in_php)

        todos.append(
            EndpointTodo(
                method=method,
                path=api_path,
                in_llms=True,
                in_openapi=in_openapi,
                in_ts_client=in_ts,
                in_py_client=in_py,
                in_php_client=in_php,
                status=status,
            )
        )

    _print_sync_todo_table(todos)
    _print_sync_summary(service, todos)


def _print_source_mismatches(llms_eps: list[str], openapi_eps: list[str]) -> None:
    """Print source mismatches between llms.txt and OpenAPI."""
    llms_set = set(llms_eps)
    openapi_set = set(openapi_eps)
    in_llms_not_openapi = [e for e in llms_eps if e not in openapi_set]
    in_openapi_not_llms = [e for e in openapi_eps if e not in llms_set]

    if not in_llms_not_openapi and not in_openapi_not_llms:
        return

    print("\n" + "─" * 90)
    print("⚠️  SOURCE MISMATCHES (API team action needed)")
    print("─" * 90)
    if in_llms_not_openapi:
        print(f"\n   In llms.txt but NOT in OpenAPI ({len(in_llms_not_openapi)}):")
        for ep in in_llms_not_openapi:
            print(f"      ❌ {ep}")
    if in_openapi_not_llms:
        print(f"\n   In OpenAPI but NOT in llms.txt ({len(in_openapi_not_llms)}):")
        for ep in in_openapi_not_llms:
            print(f"      ❌ {ep}")


def _audit_endpoints(openapi_endpoints: list[str], service: str) -> tuple[int, int, int, int]:
    """Audit endpoints and print details, return (complete, missing_ts, missing_py, missing_php)."""
    print("\n" + "─" * 100)
    print("ENDPOINT DETAILS (OpenAPI vs Clients)")
    print("─" * 100)

    complete, missing_ts, missing_py, missing_php = 0, 0, 0, 0

    for endpoint in openapi_endpoints:
        match = re.match(r"^(GET|POST|PUT|DELETE|PATCH)\s+(\S+)", endpoint)
        if not match:
            continue

        method, api_path = match.groups()
        in_ts = check_endpoint_in_ts_client(method, api_path, service)
        in_py = check_endpoint_in_py_client(method, api_path, service)
        in_php = check_endpoint_in_php_client(method, api_path, service)

        if in_ts and in_py and in_php:
            status_icon, complete = "✅", complete + 1
        else:
            status_icon = "⚠️"
            missing_ts += 0 if in_ts else 1
            missing_py += 0 if in_py else 1
            missing_php += 0 if in_php else 1

        ts_icon = "✅" if in_ts else "❌"
        py_icon = "✅" if in_py else "❌"
        php_icon = "✅" if in_php else "❌"
        print(f"\n{status_icon} {method} {api_path}")
        print(f"   TypeScript: {ts_icon}  Python: {py_icon}  PHP: {php_icon}")

    return complete, missing_ts, missing_py, missing_php


def _print_audit_summary(
    service: str,
    llms_count: int,
    openapi_count: int,
    complete: int,
    missing_ts: int,
    missing_py: int,
    missing_php: int = 0,
) -> None:
    """Print audit summary."""
    print("\n" + "=" * 100)
    print("📊 AUDIT SUMMARY")
    print("=" * 100)
    print(f"\nService: {service}")
    print("\nSources:")
    print(f"   llms.txt:     {llms_count} endpoints (hint)")
    print(f"   openapi.json: {openapi_count} endpoints (SOURCE OF TRUTH)")
    print("\nClient Implementation:")
    print(f"   Total in OpenAPI: {openapi_count}")
    print(f"   ✅ Complete (all): {complete}")
    if missing_ts > 0:
        print(f"   ❌ Missing TS:      {missing_ts}")
    if missing_py > 0:
        print(f"   ❌ Missing PY:      {missing_py}")
    if missing_php > 0:
        print(f"   ❌ Missing PHP:     {missing_php}")

    pct = round((complete / openapi_count) * 100) if openapi_count else 0
    print(f"\nOverall: {pct}% complete")
    if pct == 100:
        print("🎉 All endpoints implemented in all clients!")
    else:
        print("⚠️  Action required - see details above")
    print("")


def _audit_parameters(
    jsonl_endpoints: list[EndpointParams], service: str
) -> tuple[int, int, set[str], set[str]]:
    """Audit query parameters, return (ts_missing_count, py_missing_count, ts_params, py_params)."""
    ts_params = extract_ts_schema_params(service).get("all", set())
    py_params = extract_py_schema_params(service).get("all", set())

    ts_missing: set[str] = set()
    py_missing: set[str] = set()

    for ep in jsonl_endpoints:
        if not ep.query_params:
            continue
        for p in ep.query_params:
            # endpoints.jsonl uses camelCase names (e.g., orderBy, statusCd)
            camel = p["name"]
            snake = camel_to_snake(camel)
            if camel not in ts_params:
                ts_missing.add(camel)
            if snake not in py_params:
                py_missing.add(snake)

    return len(ts_missing), len(py_missing), ts_missing, py_missing


def run_full_audit(service: str) -> None:
    """Run full audit for a service using all three data sources."""
    print(f"\n🔍 FULL AUDIT: {service}")
    print("=" * 90)

    # Fetch all three sources
    print("\n📥 Fetching all data sources...")

    # 1. llms.txt (hint)
    llms_exists, llms_endpoints, llms_generated = fetch_llms_endpoints(service, save=False)
    llms_icon = "✅" if llms_exists else "❌"
    gen_info = f" [{llms_generated[:10]}]" if llms_generated else ""
    print(f"   {llms_icon} llms.txt: {len(llms_endpoints)} endpoints{gen_info} (hint)")

    # 2. endpoints.jsonl (detail - for params)
    jsonl_endpoints = fetch_endpoints_jsonl(service, save=False)
    jsonl_icon = "✅" if jsonl_endpoints else "❌"
    print(f"   {jsonl_icon} endpoints.jsonl: {len(jsonl_endpoints)} endpoints (detail)")

    # 3. openapi.json (source of truth)
    openapi_content = fetch_url(f"https://{service}.augur-api.com/openapi.json")
    if not openapi_content:
        print("   ❌ openapi.json: Could not fetch")
        return

    try:
        json.loads(openapi_content)
    except json.JSONDecodeError:
        print("   ❌ openapi.json: Invalid JSON")
        return

    openapi_endpoints = parse_endpoints_from_openapi(openapi_content)
    print(f"   ✅ openapi.json: {len(openapi_endpoints)} endpoints (SOURCE OF TRUTH)")

    # Endpoint coverage audit
    _print_source_mismatches(llms_endpoints, openapi_endpoints)
    complete, missing_ts, missing_py, missing_php = _audit_endpoints(openapi_endpoints, service)

    # Parameter coverage audit (if endpoints.jsonl available)
    ts_param_missing = 0
    py_param_missing = 0
    ts_missing_params: set[str] = set()
    py_missing_params: set[str] = set()
    if jsonl_endpoints:
        ts_param_missing, py_param_missing, ts_missing_params, py_missing_params = (
            _audit_parameters(jsonl_endpoints, service)
        )

    # Print summary
    _print_audit_summary(
        service,
        len(llms_endpoints),
        len(openapi_endpoints),
        complete,
        missing_ts,
        missing_py,
        missing_php,
    )

    # Parameter summary (new)
    if jsonl_endpoints:
        print("─" * 90)
        print("PARAMETER COVERAGE")
        print("─" * 90)
        if ts_param_missing == 0 and py_param_missing == 0:
            print("   ✅ All query parameters implemented in both clients")
        else:
            if ts_param_missing > 0:
                sample = ", ".join(sorted(ts_missing_params)[:5])
                suffix = "..." if ts_param_missing > 5 else ""
                print(f"   ❌ TypeScript missing {ts_param_missing} params: {sample}{suffix}")
            if py_param_missing > 0:
                sample = ", ".join(sorted(py_missing_params)[:5])
                suffix = "..." if py_param_missing > 5 else ""
                print(f"   ❌ Python missing {py_param_missing} params: {sample}{suffix}")
            print(f"\n   Run --params {service} for full parameter details")
        print("")


def get_services_to_check(specific_service: str | None) -> list[str]:
    """Get list of services to check."""
    if specific_service:
        return [specific_service]
    discovered_data = load_discovered_services()
    discovered_list = list(discovered_data.get("services", {}).keys())
    return discovered_list if discovered_list else KNOWN_SERVICES


def main() -> None:  # noqa: PLR0911, PLR0915
    """Main entry point."""
    args = sys.argv[1:]

    fetch_and_save = "--fetch" in args
    discover_mode = "--discover" in args
    sync_todos_mode = "--sync-todos" in args
    audit_mode = "--audit" in args
    params_mode = "--params" in args
    specific_service = next((a for a in args if not a.startswith("--")), None)

    print("")

    # Ensure directories exist
    OPENAPI_DIR.mkdir(parents=True, exist_ok=True)
    LLMS_DIR.mkdir(parents=True, exist_ok=True)
    ENDPOINTS_JSONL_DIR.mkdir(parents=True, exist_ok=True)

    # Full audit mode
    if audit_mode:
        if not specific_service:
            print("❌ --audit requires a service name")
            print("Usage: uv run python scripts/fetch_llms_openapi.py --audit <service>\n")
            return
        run_full_audit(specific_service)
        return

    # Parameter audit mode (uses all 3 sources: llms.txt, endpoints.jsonl, openapi.json)
    if params_mode:
        if not specific_service:
            print("❌ --params requires a service name")
            print("Usage: uv run python scripts/fetch_llms_openapi.py --params <service>\n")
            return
        run_params_audit(specific_service)
        return

    # Sync-todos mode
    if sync_todos_mode:
        if not specific_service:
            print("❌ --sync-todos requires a service name")
            print("Usage: uv run python scripts/fetch_llms_openapi.py --sync-todos <service>\n")
            return
        run_sync_todos(specific_service)
        return

    # Discovery mode
    if discover_mode:
        all_services, new_services, previous_data = discover_services()
        print_discovery_results(all_services, new_services, previous_data)
        save_discovered_services(previous_data)
        if new_services:
            print("⚠️  ACTION REQUIRED: New services need client implementations!\n")
        return

    # Standard mode: check services
    services_to_check = get_services_to_check(specific_service)
    if fetch_and_save:
        print("Mode: Fetch and save OpenAPI specs + llms.txt\n")

    results = []
    for service in services_to_check:
        print(f"Checking {service}...", end="")
        result = check_service(service, fetch_and_save)
        results.append(result)
        print(f" {result.status}")

    print_summary_table(results)
    print_differences(results)

    # Stats
    synced = sum(1 for r in results if "✅" in r.status)
    no_llms = sum(1 for r in results if "No llms.txt" in r.status)
    issues = sum(1 for r in results if "⚠️" in r.status)

    print("\n" + "=" * 70)
    print(f"Total: {synced} synced, {no_llms} missing llms.txt, {issues} with issues")

    discovered_data = load_discovered_services()
    if not discovered_data.get("services"):
        print("\n💡 Tip: Run with --discover to find all services automatically")
    print("")


if __name__ == "__main__":
    main()
