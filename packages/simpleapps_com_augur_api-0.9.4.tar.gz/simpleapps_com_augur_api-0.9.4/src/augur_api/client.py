"""Main Augur API client."""

from typing import Any

from augur_api.core.config import AugurAPIConfig, AugurContext, ContextCreationError
from augur_api.core.http_client import HTTPClient
from augur_api.services.agr_info import AgrInfoClient
from augur_api.services.agr_site import AgrSiteClient
from augur_api.services.agr_work import AgrWorkClient
from augur_api.services.avalara import AvalaraClient
from augur_api.services.basecamp2 import Basecamp2Client
from augur_api.services.brand_folder import BrandFolderClient
from augur_api.services.commerce import CommerceClient
from augur_api.services.customers import CustomersClient
from augur_api.services.gregorovich import GregorovichClient
from augur_api.services.items import ItemsClient
from augur_api.services.joomla import JoomlaClient
from augur_api.services.legacy import LegacyClient
from augur_api.services.logistics import LogisticsClient
from augur_api.services.nexus import NexusClient
from augur_api.services.open_search import OpenSearchClient
from augur_api.services.orders import OrdersClient
from augur_api.services.p21_apis import P21ApisClient
from augur_api.services.p21_core import P21CoreClient
from augur_api.services.p21_pim import P21PimClient
from augur_api.services.p21_sism import P21SismClient
from augur_api.services.payments import PaymentsClient
from augur_api.services.pricing import PricingClient
from augur_api.services.shipping import ShippingClient
from augur_api.services.slack import SlackClient
from augur_api.services.smarty_streets import SmartyStreetsClient
from augur_api.services.ups import UpsClient
from augur_api.services.vmi import VMIClient


class AugurAPI:
    """Main client factory for accessing Augur microservices.

    Provides property-based access to all 27 Augur API services with lazy
    initialization for efficiency.

    Example:
        >>> # Initialize with token and site_id
        >>> api = AugurAPI(token="your-jwt-token", site_id="your-site-id")
        >>>
        >>> # Check service health
        >>> health = api.items.health_check.get()
        >>> print(health.data.site_id)
        >>>
        >>> # List items with pagination
        >>> from augur_api.services.items import InvMastListParams
        >>> response = api.items.inv_mast.list(InvMastListParams(limit=10))
        >>> for item in response.data:
        ...     print(item.item_id)
        >>>
        >>> # Access P21 Core service
        >>> from augur_api.services.p21_core import CashDrawerListParams
        >>> drawers = api.p21_core.cash_drawer.list(CashDrawerListParams(drawer_open="Y"))

    Attributes:
        config: The API configuration.
    """

    def __init__(
        self,
        token: str,
        site_id: str,
        timeout: float = 30.0,
        retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        """Initialize the Augur API client.

        Args:
            token: JWT bearer token for authentication.
            site_id: Site identifier for the x-site-id header.
            timeout: Request timeout in seconds. Defaults to 30.0.
            retries: Number of retry attempts for failed requests. Defaults to 3.
            retry_delay: Base delay between retries in seconds. Defaults to 1.0.
        """
        self.config = AugurAPIConfig(
            token=token,
            site_id=site_id,
            timeout=timeout,
            retries=retries,
            retry_delay=retry_delay,
        )
        # Service client caches (lazy initialization)
        self._agr_info: AgrInfoClient | None = None
        self._agr_site: AgrSiteClient | None = None
        self._agr_work: AgrWorkClient | None = None
        self._avalara: AvalaraClient | None = None
        self._basecamp2: Basecamp2Client | None = None
        self._brand_folder: BrandFolderClient | None = None
        self._commerce: CommerceClient | None = None
        self._customers: CustomersClient | None = None
        self._gregorovich: GregorovichClient | None = None
        self._items: ItemsClient | None = None
        self._joomla: JoomlaClient | None = None
        self._legacy: LegacyClient | None = None
        self._logistics: LogisticsClient | None = None
        self._nexus: NexusClient | None = None
        self._open_search: OpenSearchClient | None = None
        self._orders: OrdersClient | None = None
        self._p21_apis: P21ApisClient | None = None
        self._p21_core: P21CoreClient | None = None
        self._p21_pim: P21PimClient | None = None
        self._p21_sism: P21SismClient | None = None
        self._payments: PaymentsClient | None = None
        self._pricing: PricingClient | None = None
        self._shipping: ShippingClient | None = None
        self._slack: SlackClient | None = None
        self._smarty_streets: SmartyStreetsClient | None = None
        self._ups: UpsClient | None = None
        self._vmi: VMIClient | None = None

    @classmethod
    def from_config(cls, config: AugurAPIConfig) -> "AugurAPI":
        """Create an AugurAPI instance from a configuration object.

        Args:
            config: The API configuration.

        Returns:
            AugurAPI instance.
        """
        return cls(
            token=config.token,
            site_id=config.site_id,
            timeout=config.timeout,
            retries=config.retries,
            retry_delay=config.retry_delay,
        )

    @classmethod
    def from_context(cls, context: AugurContext, **options: Any) -> "AugurAPI":
        """Create an AugurAPI instance from a context object.

        Automatically extracts site_id and authentication token from context,
        eliminating the need for manual configuration boilerplate.

        Args:
            context: Context object containing site_id and authentication.
            **options: Optional configuration overrides (timeout, retries, retry_delay).

        Returns:
            AugurAPI instance configured from context.

        Raises:
            ContextCreationError: When context is invalid or missing required fields.

        Example:
            >>> # Instead of manual configuration:
            >>> api = AugurAPI(token=context.jwt, site_id=context.site_id)
            >>>
            >>> # Simply use:
            >>> api = AugurAPI.from_context(context)
            >>>
            >>> # With optional overrides:
            >>> api = AugurAPI.from_context(context, timeout=10.0)
        """
        # Validate context
        if context is None:
            raise ContextCreationError("Context is required", "context")

        if not context.site_id:
            raise ContextCreationError("Context must contain site_id", "site_id")

        # Extract bearer token from jwt or bearer_token field
        token = context.jwt or context.bearer_token
        if not token:
            raise ContextCreationError(
                "Context must contain jwt or bearer_token for authentication",
                "bearer_token",
            )

        return cls(
            token=token,
            site_id=context.site_id,
            timeout=options.get("timeout", 30.0),
            retries=options.get("retries", 3),
            retry_delay=options.get("retry_delay", 1.0),
        )

    def _reset_clients(self) -> None:
        """Reset all cached service clients."""
        self._agr_info = None
        self._agr_site = None
        self._agr_work = None
        self._avalara = None
        self._basecamp2 = None
        self._brand_folder = None
        self._commerce = None
        self._customers = None
        self._gregorovich = None
        self._items = None
        self._joomla = None
        self._legacy = None
        self._logistics = None
        self._nexus = None
        self._open_search = None
        self._orders = None
        self._p21_apis = None
        self._p21_core = None
        self._p21_pim = None
        self._p21_sism = None
        self._payments = None
        self._pricing = None
        self._shipping = None
        self._slack = None
        self._smarty_streets = None
        self._ups = None
        self._vmi = None

    # Service properties (alphabetical order)

    @property
    def agr_info(self) -> AgrInfoClient:
        """Access AGR Info service endpoints."""
        if self._agr_info is None:
            http_client = HTTPClient("agr-info", self.config)
            self._agr_info = AgrInfoClient(http_client)
        return self._agr_info

    @property
    def agr_site(self) -> AgrSiteClient:
        """Access AGR Site service endpoints."""
        if self._agr_site is None:
            http_client = HTTPClient("agr-site", self.config)
            self._agr_site = AgrSiteClient(http_client)
        return self._agr_site

    @property
    def agr_work(self) -> AgrWorkClient:
        """Access AGR Work service endpoints."""
        if self._agr_work is None:
            http_client = HTTPClient("agr-work", self.config)
            self._agr_work = AgrWorkClient(http_client)
        return self._agr_work

    @property
    def avalara(self) -> AvalaraClient:
        """Access Avalara tax service endpoints."""
        if self._avalara is None:
            http_client = HTTPClient("avalara", self.config)
            self._avalara = AvalaraClient(http_client)
        return self._avalara

    @property
    def basecamp2(self) -> Basecamp2Client:
        """Access Basecamp2 service endpoints."""
        if self._basecamp2 is None:
            http_client = HTTPClient("basecamp2", self.config)
            self._basecamp2 = Basecamp2Client(http_client)
        return self._basecamp2

    @property
    def brand_folder(self) -> BrandFolderClient:
        """Access Brand Folder service endpoints."""
        if self._brand_folder is None:
            http_client = HTTPClient("brand-folder", self.config)
            self._brand_folder = BrandFolderClient(http_client)
        return self._brand_folder

    @property
    def commerce(self) -> CommerceClient:
        """Access Commerce service endpoints."""
        if self._commerce is None:
            http_client = HTTPClient("commerce", self.config)
            self._commerce = CommerceClient(http_client)
        return self._commerce

    @property
    def customers(self) -> CustomersClient:
        """Access Customers service endpoints."""
        if self._customers is None:
            http_client = HTTPClient("customers", self.config)
            self._customers = CustomersClient(http_client)
        return self._customers

    @property
    def gregorovich(self) -> GregorovichClient:
        """Access Gregorovich AI service endpoints."""
        if self._gregorovich is None:
            http_client = HTTPClient("gregorovich", self.config)
            self._gregorovich = GregorovichClient(http_client)
        return self._gregorovich

    @property
    def items(self) -> ItemsClient:
        """Access Items service endpoints."""
        if self._items is None:
            http_client = HTTPClient("items", self.config)
            self._items = ItemsClient(http_client)
        return self._items

    @property
    def joomla(self) -> JoomlaClient:
        """Access Joomla CMS service endpoints."""
        if self._joomla is None:
            http_client = HTTPClient("joomla", self.config)
            self._joomla = JoomlaClient(http_client)
        return self._joomla

    @property
    def legacy(self) -> LegacyClient:
        """Access Legacy service endpoints."""
        if self._legacy is None:
            http_client = HTTPClient("legacy", self.config)
            self._legacy = LegacyClient(http_client)
        return self._legacy

    @property
    def logistics(self) -> LogisticsClient:
        """Access Logistics service endpoints."""
        if self._logistics is None:
            http_client = HTTPClient("logistics", self.config)
            self._logistics = LogisticsClient(http_client)
        return self._logistics

    @property
    def nexus(self) -> NexusClient:
        """Access Nexus service endpoints."""
        if self._nexus is None:
            http_client = HTTPClient("nexus", self.config)
            self._nexus = NexusClient(http_client)
        return self._nexus

    @property
    def open_search(self) -> OpenSearchClient:
        """Access Open Search service endpoints."""
        if self._open_search is None:
            http_client = HTTPClient("open-search", self.config)
            self._open_search = OpenSearchClient(http_client)
        return self._open_search

    @property
    def orders(self) -> OrdersClient:
        """Access Orders service endpoints."""
        if self._orders is None:
            http_client = HTTPClient("orders", self.config)
            self._orders = OrdersClient(http_client)
        return self._orders

    @property
    def p21_apis(self) -> P21ApisClient:
        """Access P21 APIs service endpoints."""
        if self._p21_apis is None:
            http_client = HTTPClient("p21-apis", self.config)
            self._p21_apis = P21ApisClient(http_client)
        return self._p21_apis

    @property
    def p21_core(self) -> P21CoreClient:
        """Access P21 Core service endpoints."""
        if self._p21_core is None:
            http_client = HTTPClient("p21-core", self.config)
            self._p21_core = P21CoreClient(http_client)
        return self._p21_core

    @property
    def p21_pim(self) -> P21PimClient:
        """Access P21 PIM service endpoints."""
        if self._p21_pim is None:
            http_client = HTTPClient("p21-pim", self.config)
            self._p21_pim = P21PimClient(http_client)
        return self._p21_pim

    @property
    def p21_sism(self) -> P21SismClient:
        """Access P21 SISM service endpoints."""
        if self._p21_sism is None:
            http_client = HTTPClient("p21-sism", self.config)
            self._p21_sism = P21SismClient(http_client)
        return self._p21_sism

    @property
    def payments(self) -> PaymentsClient:
        """Access Payments service endpoints."""
        if self._payments is None:
            http_client = HTTPClient("payments", self.config)
            self._payments = PaymentsClient(http_client)
        return self._payments

    @property
    def pricing(self) -> PricingClient:
        """Access Pricing service endpoints."""
        if self._pricing is None:
            http_client = HTTPClient("pricing", self.config)
            self._pricing = PricingClient(http_client)
        return self._pricing

    @property
    def shipping(self) -> ShippingClient:
        """Access Shipping service endpoints."""
        if self._shipping is None:
            http_client = HTTPClient("shipping", self.config)
            self._shipping = ShippingClient(http_client)
        return self._shipping

    @property
    def slack(self) -> SlackClient:
        """Access Slack service endpoints."""
        if self._slack is None:
            http_client = HTTPClient("slack", self.config)
            self._slack = SlackClient(http_client)
        return self._slack

    @property
    def smarty_streets(self) -> SmartyStreetsClient:
        """Access SmartyStreets address validation service endpoints."""
        if self._smarty_streets is None:
            http_client = HTTPClient("smarty-streets", self.config)
            self._smarty_streets = SmartyStreetsClient(http_client)
        return self._smarty_streets

    @property
    def ups(self) -> UpsClient:
        """Access UPS service endpoints."""
        if self._ups is None:
            http_client = HTTPClient("ups", self.config)
            self._ups = UpsClient(http_client)
        return self._ups

    @property
    def vmi(self) -> VMIClient:
        """Access VMI (Vendor Managed Inventory) service endpoints."""
        if self._vmi is None:
            http_client = HTTPClient("vmi", self.config)
            self._vmi = VMIClient(http_client)
        return self._vmi

    def set_token(self, token: str) -> None:
        """Update the authentication token.

        This will reset all service clients to use the new token.

        Args:
            token: New JWT bearer token.
        """
        self.config.token = token
        self._reset_clients()

    def set_site_id(self, site_id: str) -> None:
        """Update the site ID.

        This will reset all service clients to use the new site ID.

        Args:
            site_id: New site identifier.
        """
        self.config.site_id = site_id
        self._reset_clients()
