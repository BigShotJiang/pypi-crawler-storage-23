"""Schemas for the Items service."""

from pydantic import BaseModel, Field

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Attribute
class AttributeListParams(EdgeCacheParams):
    """Parameters for listing attributes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class Attribute(CamelCaseModel, extra="allow"):
    """Attribute entity (passthrough)."""

    attribute_uid: int | None = None


class AttributeCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an attribute (passthrough)."""


class AttributeUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an attribute (passthrough)."""


# Attribute Group
class AttributeGroupListParams(EdgeCacheParams):
    """Parameters for listing attribute groups."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class AttributeGroup(CamelCaseModel, extra="allow"):
    """Attribute group entity (passthrough)."""

    attribute_group_uid: int | None = None


class AttributeGroupCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an attribute group (passthrough)."""


class AttributeGroupUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an attribute group (passthrough)."""


# Attribute Value (nested under Attribute)
class AttributeValueListParams(EdgeCacheParams):
    """Parameters for listing attribute values."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class AttributeValue(CamelCaseModel, extra="allow"):
    """Attribute value entity (passthrough)."""

    attribute_value_uid: int | None = None


class AttributeValueCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an attribute value (passthrough)."""


class AttributeValueUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an attribute value (passthrough)."""


# Attribute X Attribute Group (nested under Attribute Group)
class AttributeXAttributeGroupListParams(EdgeCacheParams):
    """Parameters for listing attribute x attribute group mappings."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class AttributeXAttributeGroup(CamelCaseModel, extra="allow"):
    """Attribute x attribute group mapping (passthrough)."""

    attribute_x_attribute_group_uid: int | None = None


class AttributeXAttributeGroupCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a mapping (passthrough)."""


class AttributeXAttributeGroupUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a mapping (passthrough)."""


# Brands
class BrandsListParams(EdgeCacheParams):
    """Parameters for listing brands."""

    limit: int | None = None
    offset: int | None = None


class BrandsGetParams(EdgeCacheParams):
    """Parameters for getting a specific brand."""

    brands_id: str | None = None


class Brands(CamelCaseModel, extra="allow"):
    """Brands entity (passthrough)."""

    brands_uid: int | None = None


class BrandsCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a brand (passthrough)."""


class BrandsUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a brand (passthrough)."""


# Brands X Items (nested under Brands)
class BrandsXItemsListParams(EdgeCacheParams):
    """Parameters for listing brand items."""

    limit: int | None = None
    offset: int | None = None
    variant_filter: str | None = None


class BrandsXItems(CamelCaseModel, extra="allow"):
    """Brand item mapping (passthrough)."""

    brands_x_items_uid: int | None = None


class BrandsXItemsCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a brand item (passthrough)."""


class BrandsXItemsUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a brand item (passthrough)."""


# Categories
class CategoryListParams(EdgeCacheParams):
    """Parameters for listing categories."""

    limit: int | None = None
    offset: int | None = None


class CategoryLookupParams(EdgeCacheParams):
    """Parameters for category lookup."""

    cache_ttl: int | None = None
    path: str | None = None
    root_item_category_id: str | None = None


class CategoryGetParams(EdgeCacheParams):
    """Parameters for getting category details."""

    cache_ttl: int | None = None
    children_filter: str | None = None
    children_limit: int | None = None
    children_offset: int | None = None
    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    filters: str | None = None
    include_ud: str | None = None
    order_by: str | None = None
    path: str | None = None
    product_collection: str | None = None
    root_item_category_id: str | None = None


class CategoryAttributesParams(EdgeCacheParams):
    """Parameters for listing category attributes."""

    cache_ttl: int | None = None
    include_sub_categories: str | None = None
    product_collection: str | None = None


class CategoryImagesParams(EdgeCacheParams):
    """Parameters for listing category images."""

    cache_ttl: int | None = None


class CategoryItemsParams(EdgeCacheParams):
    """Parameters for listing category items."""

    cache_ttl: int | None = None
    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    display_on_web_flag: str | None = None
    fields: str | None = None
    filters: str | None = None
    include_stock: str | None = None
    job_numbers: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    sort_by: str | None = None
    stock_status: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


class Category(CamelCaseModel, extra="allow"):
    """Category entity (passthrough)."""

    item_category_uid: int | None = None


class CategoryAttribute(CamelCaseModel, extra="allow"):
    """Category attribute (passthrough)."""


class CategoryImage(CamelCaseModel, extra="allow"):
    """Category image (passthrough)."""


class CategoryItem(CamelCaseModel, extra="allow"):
    """Category item (passthrough)."""

    inv_mast_uid: int | None = None


class CategoryItemsData(CamelCaseModel, extra="allow"):
    """Category items data - nested structure returned by GET /categories/{itemCategoryUid}/items.

    API returns: { data: { itemCategoryUid, took, total, items: [...] } }
    NOT: { data: [...] }
    """

    item_category_uid: int
    item_category_id: str | None = None
    item_category_desc: str | None = None
    took: int
    total: int
    items: list[CategoryItem]


class CategoryAttributesData(CamelCaseModel, extra="allow"):
    """Category attributes data - nested structure from categories attributes endpoint.

    API returns: { data: { attributes: [...] } }
    NOT: { data: [...] }
    """

    attributes: list[CategoryAttribute]


# Contracts
class ContractsItemsListParams(EdgeCacheParams):
    """Parameters for listing contract items."""

    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    display_on_web_flag: str | None = None
    fields: str | None = None
    filters: str | None = None
    include_stock: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    sort_by: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


class ContractsItem(CamelCaseModel, extra="allow"):
    """Contract item (passthrough)."""


class ContractsAttribute(CamelCaseModel, extra="allow"):
    """Contract attribute (passthrough)."""


# Inv Bin
class InvBinListParams(EdgeCacheParams):
    """Parameters for listing bins."""

    bin: str | None = None
    exclude_zero: str | None = None
    limit: int | None = None
    offset: int | None = None


class InvBin(CamelCaseModel, extra="allow"):
    """Inventory bin (passthrough)."""


# Inv Loc
class InvLocListParams(EdgeCacheParams):
    """Parameters for listing inv loc."""

    inv_mast_uid: int | None = None
    limit: int | None = None
    offset: int | None = None


class InvLoc(CamelCaseModel, extra="allow"):
    """Inventory location (passthrough)."""


# Inv Mast
class InvMastListParams(EdgeCacheParams):
    """Parameters for listing inventory master items."""

    item_category_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    online_cd: int | None = None
    prefix: str | None = None
    q: str | None = None
    status_cd: int | None = None


class InvMastLookupParams(EdgeCacheParams):
    """Parameters for inventory master lookup."""

    limit: int | None = None
    offset: int | None = None
    online_cd: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class InvMastDocParams(EdgeCacheParams):
    """Parameters for inventory master document."""

    include_pricing: str | None = None
    item_id: str | None = None


class InvMast(CamelCaseModel, extra="allow"):
    """Inventory master item (passthrough)."""

    inv_mast_uid: int | None = None


class InvMastDoc(CamelCaseModel, extra="allow"):
    """Inventory master document (passthrough)."""


class P21InvMastListParams(EdgeCacheParams):
    """Parameters for listing P21 inv mast."""

    created_since: str | None = None
    limit: int | None = None
    modified_since: str | None = None
    offset: int | None = None
    online_cd: int | None = None
    order_by: str | None = None
    status_cd: int | None = None


class P21InvMast(CamelCaseModel, extra="allow"):
    """P21 inventory master (passthrough)."""


# Inv Mast Stock
class StockParams(EdgeCacheParams):
    """Parameters for stock queries."""


class StockSummary(CamelCaseModel, extra="allow"):
    """Stock summary for an inventory item (passthrough)."""


# Alternate Code
class AlternateCodeListParams(EdgeCacheParams):
    """Parameters for listing alternate codes."""

    limit: int | None = None
    offset: int | None = None


class AlternateCode(CamelCaseModel, extra="allow"):
    """Alternate code for an inventory item (passthrough)."""


# Inv Accessory
class InvAccessoryListParams(EdgeCacheParams):
    """Parameters for listing inv accessories."""

    limit: int | None = None
    offset: int | None = None


class InvAccessory(CamelCaseModel, extra="allow"):
    """Inventory accessory (passthrough)."""


# Inv Sub
class InvSubListParams(EdgeCacheParams):
    """Parameters for listing inv substitutes."""

    limit: int | None = None
    offset: int | None = None


class InvSub(CamelCaseModel, extra="allow"):
    """Inventory substitute (passthrough)."""


# Inv Mast FAQ
class InvMastFaqListParams(EdgeCacheParams):
    """Parameters for listing inv mast FAQs."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class InvMastFaq(CamelCaseModel, extra="allow"):
    """Inventory master FAQ (passthrough)."""

    inv_mast_faq_uid: int | None = None


class InvMastFaqCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an FAQ (passthrough)."""


class InvMastFaqUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an FAQ (passthrough)."""


# Inv Mast Links
class InvMastLinks(CamelCaseModel, extra="allow"):
    """Inventory master links (passthrough)."""


# Inv Mast Similarity
class InvMastSimilar(CamelCaseModel, extra="allow"):
    """Similar inventory item (passthrough)."""


# Inv Mast Sub Parts
class InvMastSubParts(CamelCaseModel, extra="allow"):
    """Inventory sub parts (passthrough)."""


class InvMastSubPartsParams(EdgeCacheParams):
    """Parameters for listing inv mast sub parts."""

    inv_mast_links_uid: int | None = None


# Inv Mast UD
class InvMastUdListParams(EdgeCacheParams):
    """Parameters for listing inv mast ud."""

    created_since: str | None = None
    inv_mast_ud_uid: int | None = None
    inv_mast_uid: int | None = None
    limit: int | None = None
    modified_since: str | None = None
    offset: int | None = None
    order_by: str | None = None
    status_cd: int | None = None


class InvMastUd(CamelCaseModel, extra="allow"):
    """Inventory master user defined (passthrough)."""


# Item Attribute Value (nested under Inv Mast)
class ItemAttributeValueListParams(EdgeCacheParams):
    """Parameters for listing item attribute values."""

    attribute_value_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class ItemAttributeValue(CamelCaseModel, extra="allow"):
    """Item attribute value (passthrough)."""


class ItemAttributeValueCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an item attribute value (passthrough)."""


class ItemAttributeValueUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an item attribute value (passthrough)."""


class ItemAttributeListParams(EdgeCacheParams):
    """Parameters for listing item attributes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class ItemAttribute(CamelCaseModel, extra="allow"):
    """Item attribute (passthrough)."""


class ItemAttributeCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an item attribute (passthrough)."""


# Item Category
class ItemCategoryListParams(EdgeCacheParams):
    """Parameters for listing item categories."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None


class ItemCategoryLookupParams(EdgeCacheParams):
    """Parameters for item category lookup."""

    path: str | None = None
    root_item_category_id: str | None = None


class ItemCategory(CamelCaseModel, extra="allow"):
    """Item category (passthrough)."""

    item_category_uid: int | None = None


class ItemCategoryDoc(CamelCaseModel, extra="allow"):
    """Item category document (passthrough)."""


# Item Favorites
class ItemFavoritesListParams(EdgeCacheParams):
    """Parameters for listing item favorites."""

    limit: int | None = None
    offset: int | None = None
    use_item_doc: str | None = Field(default=None, serialization_alias="useItemDoc")


class ItemFavorite(CamelCaseModel, extra="allow"):
    """Item favorite (passthrough)."""


class ItemFavoriteCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an item favorite (passthrough)."""


class ItemFavoriteUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an item favorite (passthrough)."""


# Item UOM
class ItemUomListParams(EdgeCacheParams):
    """Parameters for listing item UOMs."""

    # Note: API uses camelCase for these date params
    created_since: str | None = Field(default=None, serialization_alias="createdSince")
    delete_flag: str | None = None
    inv_mast_uid: int | None = None
    limit: int | None = None
    modified_since: str | None = Field(default=None, serialization_alias="modifiedSince")
    offset: int | None = None
    order_by: str | None = None
    unit_of_measure: str | None = None


class ItemUom(CamelCaseModel, extra="allow"):
    """Item unit of measure (passthrough)."""

    item_uom_uid: int | None = None


# Variants (Item Variant Hdr)
class VariantsListParams(EdgeCacheParams):
    """Parameters for listing variants."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


class Variant(CamelCaseModel, extra="allow"):
    """Item variant header (passthrough)."""

    item_variant_hdr_uid: int | None = None


class VariantCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a variant (passthrough)."""


class VariantUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a variant (passthrough)."""


# Variant Lines (Item Variant Line)
class VariantLineListParams(EdgeCacheParams):
    """Parameters for listing variant lines."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


class VariantLine(CamelCaseModel, extra="allow"):
    """Item variant line (passthrough)."""

    item_variant_line_uid: int | None = None


class VariantLineCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a variant line (passthrough)."""


class VariantLineUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a variant line (passthrough)."""


# Variant Attributes
class VariantAttributeListParams(EdgeCacheParams):
    """Parameters for listing variant attributes."""

    limit: int | None = None
    offset: int | None = None


class VariantAttribute(CamelCaseModel, extra="allow"):
    """Variant attribute (passthrough)."""

    attribute_uid: int | None = None


class VariantAttributeCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a variant attribute (passthrough)."""


class VariantAttributeUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a variant attribute (passthrough)."""


# Item Wishlist Hdr
class ItemWishlistListParams(EdgeCacheParams):
    """Parameters for listing wishlists."""

    limit: int | None = None
    offset: int | None = None


class ItemWishlist(CamelCaseModel, extra="allow"):
    """Item wishlist header (passthrough)."""

    item_wishlist_hdr_uid: int | None = None


class ItemWishlistCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a wishlist (passthrough)."""


class ItemWishlistUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a wishlist (passthrough)."""


# Item Wishlist Line
class ItemWishlistLineListParams(EdgeCacheParams):
    """Parameters for listing wishlist lines."""

    limit: int | None = None
    offset: int | None = None


class ItemWishlistLine(CamelCaseModel, extra="allow"):
    """Item wishlist line (passthrough)."""

    item_wishlist_line_uid: int | None = None


class ItemWishlistLineCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a wishlist line (passthrough)."""


# Locations (for bins)
class LocationBin(CamelCaseModel, extra="allow"):
    """Location bin (passthrough)."""


# Internal
class PdfCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a PDF (passthrough)."""


class PdfResult(CamelCaseModel, extra="allow"):
    """PDF generation result (passthrough)."""
