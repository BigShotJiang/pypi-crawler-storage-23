"""AGR Work service client."""

from __future__ import annotations

from typing import TYPE_CHECKING

from augur_api.services.base import BaseServiceClient

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class AgrWorkClient(BaseServiceClient):
    """Client for the AGR Work service.

    Provides access to work/task management endpoints.
    Inherits health_check() method from BaseServiceClient.

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> health = api.agr_work.health_check()
        >>> print(health.status)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the AGR Work client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
