"""P21 SISM service client for data import operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import builtins

    from augur_api.core.http_client import HTTPClient

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.p21_sism.schemas import (
    ImpOeHdr,
    ImpOeHdrSalesrep,
    ImpOeHdrWeb,
    ImpOeLine,
    ImpOeLineListParams,
    Import,
    ImportListParams,
    ScheduledImportSftpMetadata,
)
from augur_api.services.resource import BaseResource


class ImportResource(BaseResource):
    """Resource for /import endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/import")

    def list(self, params: ImportListParams | None = None) -> BaseResponse[list[Import]]:
        """List imports.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Import items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Import]].model_validate(response)

    def get(self, import_uid: int) -> BaseResponse[Import]:
        """Get import by UID.

        Args:
            import_uid: The import UID.

        Returns:
            BaseResponse containing the Import.
        """
        response = self._get(f"/{import_uid}")
        return BaseResponse[Import].model_validate(response)

    def update(self, import_uid: int, data: Any) -> BaseResponse[Import]:
        """Update an import.

        Args:
            import_uid: The import UID.
            data: Import data to update.

        Returns:
            BaseResponse containing updated import.
        """
        response = self._put(f"/{import_uid}", data=data)
        return BaseResponse[Import].model_validate(response)

    def delete(self, import_uid: int) -> BaseResponse[bool]:
        """Clean pending_import for an import.

        Args:
            import_uid: The import UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{import_uid}")
        return BaseResponse[bool].model_validate(response)

    def recent(self) -> BaseResponse[builtins.list[Import]]:
        """Get a list of the most recent imports.

        Returns:
            BaseResponse containing a list of recent Import items.
        """
        response = self._get("/recent")
        return BaseResponse[list[Import]].model_validate(response)

    def stuck(self) -> BaseResponse[builtins.list[Import]]:
        """Get a list of stuck imports.

        Returns:
            BaseResponse containing a list of stuck Import items.
        """
        response = self._get("/stuck")
        return BaseResponse[list[Import]].model_validate(response)


class ImpOeHdrResource(BaseResource):
    """Resource for /import/{import_uid}/imp-oe-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/import")

    def get(self, import_uid: int) -> BaseResponse[ImpOeHdr]:
        """Get imp_oe_hdr details for an import.

        Args:
            import_uid: The import UID.

        Returns:
            BaseResponse containing the ImpOeHdr.
        """
        response = self._get(f"/{import_uid}/imp-oe-hdr")
        return BaseResponse[ImpOeHdr].model_validate(response)

    def update(self, import_uid: int, data: Any) -> BaseResponse[ImpOeHdr]:
        """Update imp_oe_hdr for an import.

        Args:
            import_uid: The import UID.
            data: Data to update.

        Returns:
            BaseResponse containing updated ImpOeHdr.
        """
        response = self._put(f"/{import_uid}/imp-oe-hdr", data=data)
        return BaseResponse[ImpOeHdr].model_validate(response)


class ImpOeHdrSalesrepResource(BaseResource):
    """Resource for /import/{import_uid}/imp-oe-hdr-salesrep endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/import")

    def get(self, import_uid: int) -> BaseResponse[ImpOeHdrSalesrep]:
        """Get imp_oe_hdr_salesrep details for an import.

        Args:
            import_uid: The import UID.

        Returns:
            BaseResponse containing the ImpOeHdrSalesrep.
        """
        response = self._get(f"/{import_uid}/imp-oe-hdr-salesrep")
        return BaseResponse[ImpOeHdrSalesrep].model_validate(response)

    def update(self, import_uid: int, data: Any) -> BaseResponse[ImpOeHdrSalesrep]:
        """Update imp_oe_hdr_salesrep for an import.

        Args:
            import_uid: The import UID.
            data: Data to update.

        Returns:
            BaseResponse containing updated ImpOeHdrSalesrep.
        """
        response = self._put(f"/{import_uid}/imp-oe-hdr-salesrep", data=data)
        return BaseResponse[ImpOeHdrSalesrep].model_validate(response)


class ImpOeHdrWebResource(BaseResource):
    """Resource for /import/{import_uid}/imp-oe-hdr-web endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/import")

    def get(self, import_uid: int) -> BaseResponse[ImpOeHdrWeb]:
        """Get imp_oe_hdr_web details for an import.

        Args:
            import_uid: The import UID.

        Returns:
            BaseResponse containing the ImpOeHdrWeb.
        """
        response = self._get(f"/{import_uid}/imp-oe-hdr-web")
        return BaseResponse[ImpOeHdrWeb].model_validate(response)


class ImpOeLineResource(BaseResource):
    """Resource for /imp_oe_line endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/imp_oe_line")

    def list(self, params: ImpOeLineListParams | None = None) -> BaseResponse[list[ImpOeLine]]:
        """List imp_oe_line records.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of ImpOeLine items.
        """
        response = self._get(params=params)
        return BaseResponse[list[ImpOeLine]].model_validate(response)

    def get(self, import_uid: int, line_no: int) -> BaseResponse[ImpOeLine]:
        """Get imp_oe_line details.

        Args:
            import_uid: The import UID.
            line_no: The line number.

        Returns:
            BaseResponse containing the ImpOeLine.
        """
        response = self._get(f"/{import_uid}/{line_no}")
        return BaseResponse[ImpOeLine].model_validate(response)

    def update(self, import_uid: int, line_no: int, data: Any) -> BaseResponse[ImpOeLine]:
        """Update imp_oe_line.

        Args:
            import_uid: The import UID.
            line_no: The line number.
            data: Data to update.

        Returns:
            BaseResponse containing updated ImpOeLine.
        """
        response = self._put(f"/{import_uid}/{line_no}", data=data)
        return BaseResponse[ImpOeLine].model_validate(response)


class ScheduledImportMetadataResource(BaseResource):
    """Resource for scheduled import metadata endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/scheduled-import-master")

    def create_sftp(
        self,
        scheduled_import_master_uid: int,
        data: Any,
    ) -> BaseResponse[ScheduledImportSftpMetadata]:
        """Create SFTP metadata for a scheduled import master.

        Args:
            scheduled_import_master_uid: The scheduled import master UID.
            data: SFTP metadata to create.

        Returns:
            BaseResponse containing created metadata.
        """
        response = self._post(f"/{scheduled_import_master_uid}/metadata/sftp", data=data)
        return BaseResponse[ScheduledImportSftpMetadata].model_validate(response)


class P21SismClient(BaseServiceClient):
    """Client for the P21 SISM service.

    Provides access to data import operation endpoints including:
    - Health check (health_check) - inherited from BaseServiceClient
    - Import (import_)
    - Imp OE Hdr (imp_oe_hdr)
    - Imp OE Hdr Salesrep (imp_oe_hdr_salesrep)
    - Imp OE Hdr Web (imp_oe_hdr_web)
    - Imp OE Line (imp_oe_line)
    - Scheduled Import Metadata (scheduled_import_metadata)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> imports = api.p21_sism.import_.list()
        >>> for imp in imports.data:
        ...     print(imp.status)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the P21 SISM client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._import: ImportResource | None = None
        self._imp_oe_hdr: ImpOeHdrResource | None = None
        self._imp_oe_hdr_salesrep: ImpOeHdrSalesrepResource | None = None
        self._imp_oe_hdr_web: ImpOeHdrWebResource | None = None
        self._imp_oe_line: ImpOeLineResource | None = None
        self._scheduled_import_metadata: ScheduledImportMetadataResource | None = None

    @property
    def import_(self) -> ImportResource:
        """Access import endpoints."""
        if self._import is None:
            self._import = ImportResource(self._http)
        return self._import

    @property
    def imp_oe_hdr(self) -> ImpOeHdrResource:
        """Access imp_oe_hdr endpoints."""
        if self._imp_oe_hdr is None:
            self._imp_oe_hdr = ImpOeHdrResource(self._http)
        return self._imp_oe_hdr

    @property
    def imp_oe_hdr_salesrep(self) -> ImpOeHdrSalesrepResource:
        """Access imp_oe_hdr_salesrep endpoints."""
        if self._imp_oe_hdr_salesrep is None:
            self._imp_oe_hdr_salesrep = ImpOeHdrSalesrepResource(self._http)
        return self._imp_oe_hdr_salesrep

    @property
    def imp_oe_hdr_web(self) -> ImpOeHdrWebResource:
        """Access imp_oe_hdr_web endpoints."""
        if self._imp_oe_hdr_web is None:
            self._imp_oe_hdr_web = ImpOeHdrWebResource(self._http)
        return self._imp_oe_hdr_web

    @property
    def imp_oe_line(self) -> ImpOeLineResource:
        """Access imp_oe_line endpoints."""
        if self._imp_oe_line is None:
            self._imp_oe_line = ImpOeLineResource(self._http)
        return self._imp_oe_line

    @property
    def scheduled_import_metadata(self) -> ScheduledImportMetadataResource:
        """Access scheduled import metadata endpoints."""
        if self._scheduled_import_metadata is None:
            self._scheduled_import_metadata = ScheduledImportMetadataResource(self._http)
        return self._scheduled_import_metadata
