"""Schemas for the Nexus service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Bin Transfers
class BinTransferListParams(EdgeCacheParams):
    """Parameters for listing bin transfers."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


class BinTransfer(CamelCaseModel, extra="allow"):
    """Bin transfer entity (passthrough)."""

    bin_transfer_hdr_uid: int | None = None


class BinTransferCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a bin transfer (passthrough)."""


class BinTransferUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a bin transfer (passthrough)."""


# Users
class UserListParams(EdgeCacheParams):
    """Parameters for listing users."""

    limit: int | None = None
    offset: int | None = None
    active: bool | None = None


class User(CamelCaseModel, extra="allow"):
    """Nexus user entity (passthrough)."""

    users_uid: int | None = None


# Receiving
class ReceivingListParams(EdgeCacheParams):
    """Parameters for listing receiving records."""

    limit: int | None = None
    offset: int | None = None
    po_no: int | None = None
    status_cd: int | None = None


class Receiving(CamelCaseModel, extra="allow"):
    """Receiving record entity (passthrough)."""

    receiving_uid: int | None = None


class ReceivingCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a receiving record (passthrough)."""


class ReceivingUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a receiving record (passthrough)."""


# Transfer
class TransferListParams(EdgeCacheParams):
    """Parameters for listing transfers."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class Transfer(CamelCaseModel, extra="allow"):
    """Transfer entity (passthrough)."""

    transfer_uid: int | None = None


class TransferCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a transfer (passthrough)."""


class TransferUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a transfer (passthrough)."""


# Purchase Order Receipt
class PurchaseOrderReceiptListParams(EdgeCacheParams):
    """Parameters for listing purchase order receipts."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class PurchaseOrderReceipt(CamelCaseModel, extra="allow"):
    """Purchase order receipt entity (passthrough)."""

    purchase_order_receipt_uid: int | None = None


class PurchaseOrderReceiptCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a purchase order receipt (passthrough)."""


class PurchaseOrderReceiptUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a purchase order receipt (passthrough)."""


# Transfer Receipt
class TransferReceiptListParams(EdgeCacheParams):
    """Parameters for listing transfer receipts."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class TransferReceipt(CamelCaseModel, extra="allow"):
    """Transfer receipt entity (passthrough)."""

    transfer_receipt_uid: int | None = None


class TransferReceiptCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a transfer receipt (passthrough)."""


class TransferReceiptUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a transfer receipt (passthrough)."""


# Transfer Shipping
class TransferShippingListParams(EdgeCacheParams):
    """Parameters for listing transfer shipping documents."""

    limit: int | None = None
    offset: int | None = None
    reference_no: str | None = None
    status_cd: int | None = None


class TransferShipping(CamelCaseModel, extra="allow"):
    """Transfer shipping entity (passthrough)."""

    transfer_receipt_uid: int | None = None


class TransferShippingCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a transfer shipping document (passthrough)."""


class TransferShippingUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a transfer shipping document (passthrough)."""
