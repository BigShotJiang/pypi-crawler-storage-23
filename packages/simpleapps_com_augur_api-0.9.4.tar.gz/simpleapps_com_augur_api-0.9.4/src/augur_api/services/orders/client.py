"""Orders service client for order management."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.orders.schemas import (
    InvoiceReprintResponse,
    OeHdr,
    OeHdrDoc,
    OeHdrDocParams,
    OeHdrLookupParams,
    PickTicket,
    PickTicketLine,
    PickTicketLinesParams,
    PickTicketsListParams,
    PoHdr,
    PoHdrDoc,
    PoHdrListParams,
    PoHdrScanParams,
    SalesRepOeHdr,
)
from augur_api.services.resource import BaseResource


class InvoiceHdrResource(BaseResource):
    """Resource for /invoice-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/invoice-hdr")

    def reprint(self, invoice_no: int) -> BaseResponse[InvoiceReprintResponse]:
        """Reprint an existing invoice.

        Args:
            invoice_no: The invoice number to reprint.

        Returns:
            BaseResponse containing the reprint response.
        """
        response = self._get(f"/{invoice_no}/reprint")
        return BaseResponse[InvoiceReprintResponse].model_validate(response)


class OeHdrResource(BaseResource):
    """Resource for /oe-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-hdr")

    def lookup(self, params: OeHdrLookupParams | None = None) -> BaseResponse[list[OeHdr]]:
        """Search and list order headers.

        Args:
            params: Optional query parameters for filtering.

        Returns:
            BaseResponse containing a list of OeHdr items.
        """
        response = self._get("/lookup", params=params)
        return BaseResponse[list[OeHdr]].model_validate(response)

    def get_doc(
        self, order_no: int, params: OeHdrDocParams | None = None
    ) -> BaseResponse[OeHdrDoc]:
        """Get complete order document.

        Args:
            order_no: The order number.
            params: Optional document parameters.

        Returns:
            BaseResponse containing the OeHdrDoc.
        """
        response = self._get(f"/{order_no}/doc", params=params)
        return BaseResponse[OeHdrDoc].model_validate(response)


class OeHdrSalesrepResource(BaseResource):
    """Resource for /oe-hdr-salesrep endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-hdr-salesrep")

    def list_orders(self, salesrep_id: int) -> BaseResponse[list[SalesRepOeHdr]]:
        """Get orders for a specific sales representative.

        Args:
            salesrep_id: The sales representative ID.

        Returns:
            BaseResponse containing a list of SalesRepOeHdr items.
        """
        response = self._get(f"/{salesrep_id}/oe-hdr")
        return BaseResponse[list[SalesRepOeHdr]].model_validate(response)

    def get_order_doc(self, salesrep_id: int, order_no: int) -> BaseResponse[OeHdrDoc]:
        """Get specific order document for sales representative.

        Args:
            salesrep_id: The sales representative ID.
            order_no: The order number.

        Returns:
            BaseResponse containing the OeHdrDoc.
        """
        response = self._get(f"/{salesrep_id}/oe-hdr/{order_no}/doc")
        return BaseResponse[OeHdrDoc].model_validate(response)


class PickTicketsResource(BaseResource):
    """Resource for /pick-tickets endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/pick-tickets")

    def list(self, params: PickTicketsListParams | None = None) -> BaseResponse[List[PickTicket]]:
        """List pick tickets.

        Args:
            params: Optional query parameters for filtering.

        Returns:
            BaseResponse containing a list of PickTicket items.
        """
        response = self._get(params=params)
        return BaseResponse[List[PickTicket]].model_validate(response)

    def get(self, pick_ticket_no: int) -> BaseResponse[PickTicket]:
        """Get pick ticket by number.

        Args:
            pick_ticket_no: The pick ticket number.

        Returns:
            BaseResponse containing the PickTicket.
        """
        response = self._get(f"/{pick_ticket_no}")
        return BaseResponse[PickTicket].model_validate(response)

    def list_lines(
        self, pick_ticket_no: int, params: PickTicketLinesParams | None = None
    ) -> BaseResponse[List[PickTicketLine]]:
        """List pick ticket lines.

        Args:
            pick_ticket_no: The pick ticket number.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of PickTicketLine items.
        """
        response = self._get(f"/{pick_ticket_no}/lines", params=params)
        return BaseResponse[List[PickTicketLine]].model_validate(response)

    def get_line(self, pick_ticket_no: int, line_number: int) -> BaseResponse[PickTicketLine]:
        """Get specific pick ticket line.

        Args:
            pick_ticket_no: The pick ticket number.
            line_number: The line number.

        Returns:
            BaseResponse containing the PickTicketLine.
        """
        response = self._get(f"/{pick_ticket_no}/lines/{line_number}")
        return BaseResponse[PickTicketLine].model_validate(response)


class PoHdrResource(BaseResource):
    """Resource for /po-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/po-hdr")

    def list(self, params: PoHdrListParams | None = None) -> BaseResponse[List[PoHdr]]:
        """List purchase orders.

        Args:
            params: Optional query parameters for filtering.

        Returns:
            BaseResponse containing a list of PoHdr items.
        """
        response = self._get(params=params)
        return BaseResponse[List[PoHdr]].model_validate(response)

    def get(self, po_no: int) -> BaseResponse[PoHdr]:
        """Get purchase order by number.

        Args:
            po_no: The purchase order number.

        Returns:
            BaseResponse containing the PoHdr.
        """
        response = self._get(f"/{po_no}")
        return BaseResponse[PoHdr].model_validate(response)

    def get_doc(self, po_no: int) -> BaseResponse[PoHdrDoc]:
        """Get complete purchase order document.

        Args:
            po_no: The purchase order number.

        Returns:
            BaseResponse containing the PoHdrDoc.
        """
        response = self._get(f"/{po_no}/doc")
        return BaseResponse[PoHdrDoc].model_validate(response)

    def scan(self, params: PoHdrScanParams | None = None) -> BaseResponse[List[PoHdr]]:
        """Scan for similar purchase orders.

        Args:
            params: Optional scan criteria.

        Returns:
            BaseResponse containing matching PoHdr items.
        """
        response = self._post("/scan", data=params)
        return BaseResponse[List[PoHdr]].model_validate(response)


class OrdersClient(BaseServiceClient):
    """Client for the Orders service.

    Provides access to order management endpoints including:
    - Health check (health_check) - inherited from BaseServiceClient
    - Invoice headers (invoice_hdr)
    - Order headers (oe_hdr)
    - Sales rep orders (oe_hdr_salesrep)
    - Pick tickets (pick_tickets)
    - Purchase orders (po_hdr)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> orders = api.orders.oe_hdr.lookup(OeHdrLookupParams(limit=10))
        >>> for order in orders.data:
        ...     print(order.order_no, order.total_amount)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Orders client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._invoice_hdr: InvoiceHdrResource | None = None
        self._oe_hdr: OeHdrResource | None = None
        self._oe_hdr_salesrep: OeHdrSalesrepResource | None = None
        self._pick_tickets: PickTicketsResource | None = None
        self._po_hdr: PoHdrResource | None = None

    @property
    def invoice_hdr(self) -> InvoiceHdrResource:
        """Access invoice header endpoints."""
        if self._invoice_hdr is None:
            self._invoice_hdr = InvoiceHdrResource(self._http)
        return self._invoice_hdr

    @property
    def oe_hdr(self) -> OeHdrResource:
        """Access order header endpoints."""
        if self._oe_hdr is None:
            self._oe_hdr = OeHdrResource(self._http)
        return self._oe_hdr

    @property
    def oe_hdr_salesrep(self) -> OeHdrSalesrepResource:
        """Access sales rep order header endpoints."""
        if self._oe_hdr_salesrep is None:
            self._oe_hdr_salesrep = OeHdrSalesrepResource(self._http)
        return self._oe_hdr_salesrep

    @property
    def pick_tickets(self) -> PickTicketsResource:
        """Access pick tickets endpoints."""
        if self._pick_tickets is None:
            self._pick_tickets = PickTicketsResource(self._http)
        return self._pick_tickets

    @property
    def po_hdr(self) -> PoHdrResource:
        """Access purchase order header endpoints."""
        if self._po_hdr is None:
            self._po_hdr = PoHdrResource(self._http)
        return self._po_hdr
