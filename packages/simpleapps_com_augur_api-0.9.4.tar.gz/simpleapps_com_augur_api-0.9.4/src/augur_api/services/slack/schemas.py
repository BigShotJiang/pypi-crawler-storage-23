"""Schemas for the Slack service."""

from typing import Any

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Web Hook
class WebHookMessage(BaseModel):
    """Parameters for sending a web hook message."""

    text: str
    channel: str | None = None
    username: str | None = None
    icon_emoji: str | None = None
    icon_url: str | None = None
    attachments: list[dict[str, Any]] | None = None
    blocks: list[dict[str, Any]] | None = None


class WebHookResponse(CamelCaseModel, extra="allow"):
    """Web hook response."""

    ok: bool | None = None
    error: str | None = None
