"""Legacy service client for backward compatibility."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.legacy.schemas import (
    AlsoBoughtItem,
    AlsoBoughtListParams,
    InvMastTag,
    InvMastTagsListParams,
    InvMastWebDesc,
    InvMastWebDescListParams,
    ItemCategory,
    OrderResetResponse,
    State,
    StateListParams,
)
from augur_api.services.resource import BaseResource


class StateResource(BaseResource):
    """Resource for /legacy/state endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/legacy/state")

    def list(self, params: StateListParams | None = None) -> BaseResponse[list[State]]:
        """List states.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of State items.
        """
        response = self._get(params=params)
        return BaseResponse[list[State]].model_validate(response)

    def get(self, state_uid: int) -> BaseResponse[State]:
        """Get state by UID.

        Args:
            state_uid: The state UID.

        Returns:
            BaseResponse containing the State.
        """
        response = self._get(f"/{state_uid}")
        return BaseResponse[State].model_validate(response)

    def create(self, data: Any) -> BaseResponse[State]:
        """Create a new state.

        Args:
            data: State data to create.

        Returns:
            BaseResponse containing created state.
        """
        response = self._post(data=data)
        return BaseResponse[State].model_validate(response)

    def update(self, state_uid: int, data: Any) -> BaseResponse[State]:
        """Update a state.

        Args:
            state_uid: The state UID.
            data: State data to update.

        Returns:
            BaseResponse containing updated state.
        """
        response = self._put(f"/{state_uid}", data=data)
        return BaseResponse[State].model_validate(response)

    def delete(self, state_uid: int) -> BaseResponse[bool]:
        """Delete a state.

        Args:
            state_uid: The state UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{state_uid}")
        return BaseResponse[bool].model_validate(response)


class AlsoBoughtResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/also-bought endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list(
        self, inv_mast_uid: int, params: AlsoBoughtListParams | None = None
    ) -> BaseResponse[list[AlsoBoughtItem]]:
        """List also bought items for an inventory item.

        Args:
            inv_mast_uid: The inventory master UID.
            params: Optional query parameters for pagination.

        Returns:
            BaseResponse containing a list of AlsoBoughtItem items.
        """
        response = self._get(f"/{inv_mast_uid}/also-bought", params=params)
        return BaseResponse[list[AlsoBoughtItem]].model_validate(response)


class InvMastTagsResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/tags endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list(
        self, inv_mast_uid: int, params: InvMastTagsListParams | None = None
    ) -> BaseResponse[list[InvMastTag]]:
        """List tags for an inventory item.

        Args:
            inv_mast_uid: The inventory master UID.
            params: Optional query parameters for pagination.

        Returns:
            BaseResponse containing a list of InvMastTag items.
        """
        response = self._get(f"/{inv_mast_uid}/tags", params=params)
        return BaseResponse[list[InvMastTag]].model_validate(response)

    def get(self, inv_mast_uid: int, inv_mast_tags_uid: int) -> BaseResponse[InvMastTag]:
        """Get tag details.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_tags_uid: The tag UID.

        Returns:
            BaseResponse containing the InvMastTag.
        """
        response = self._get(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}")
        return BaseResponse[InvMastTag].model_validate(response)

    def create(self, inv_mast_uid: int, data: Any) -> BaseResponse[InvMastTag]:
        """Create a new tag for an inventory item.

        Args:
            inv_mast_uid: The inventory master UID.
            data: Tag data to create.

        Returns:
            BaseResponse containing created tag.
        """
        response = self._post(f"/{inv_mast_uid}/tags", data=data)
        return BaseResponse[InvMastTag].model_validate(response)

    def update(
        self, inv_mast_uid: int, inv_mast_tags_uid: int, data: Any
    ) -> BaseResponse[InvMastTag]:
        """Update a tag.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_tags_uid: The tag UID.
            data: Tag data to update.

        Returns:
            BaseResponse containing updated tag.
        """
        response = self._put(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}", data=data)
        return BaseResponse[InvMastTag].model_validate(response)

    def delete(self, inv_mast_uid: int, inv_mast_tags_uid: int) -> BaseResponse[bool]:
        """Delete a tag.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_tags_uid: The tag UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}")
        return BaseResponse[bool].model_validate(response)


class InvMastWebDescResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/web-desc endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list(
        self, inv_mast_uid: int, params: InvMastWebDescListParams | None = None
    ) -> BaseResponse[list[InvMastWebDesc]]:
        """List web descriptions for an inventory item.

        Args:
            inv_mast_uid: The inventory master UID.
            params: Optional query parameters for pagination.

        Returns:
            BaseResponse containing a list of InvMastWebDesc items.
        """
        response = self._get(f"/{inv_mast_uid}/web-desc", params=params)
        return BaseResponse[list[InvMastWebDesc]].model_validate(response)

    def get(self, inv_mast_uid: int, inv_mast_web_desc_uid: int) -> BaseResponse[InvMastWebDesc]:
        """Get web description details.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_web_desc_uid: The web description UID.

        Returns:
            BaseResponse containing the InvMastWebDesc.
        """
        response = self._get(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}")
        return BaseResponse[InvMastWebDesc].model_validate(response)

    def create(self, inv_mast_uid: int, data: Any) -> BaseResponse[InvMastWebDesc]:
        """Create a new web description for an inventory item.

        Args:
            inv_mast_uid: The inventory master UID.
            data: Web description data to create.

        Returns:
            BaseResponse containing created web description.
        """
        response = self._post(f"/{inv_mast_uid}/web-desc", data=data)
        return BaseResponse[InvMastWebDesc].model_validate(response)

    def update(
        self,
        inv_mast_uid: int,
        inv_mast_web_desc_uid: int,
        data: Any,
    ) -> BaseResponse[InvMastWebDesc]:
        """Update a web description.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_web_desc_uid: The web description UID.
            data: Web description data to update.

        Returns:
            BaseResponse containing updated web description.
        """
        response = self._put(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}", data=data)
        return BaseResponse[InvMastWebDesc].model_validate(response)

    def delete(self, inv_mast_uid: int, inv_mast_web_desc_uid: int) -> BaseResponse[bool]:
        """Delete a web description.

        Args:
            inv_mast_uid: The inventory master UID.
            inv_mast_web_desc_uid: The web description UID.

        Returns:
            BaseResponse with deletion status.
        """
        response = self._delete(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}")
        return BaseResponse[bool].model_validate(response)


class ItemCategoryResource(BaseResource):
    """Resource for /item-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-category")

    def get(self, item_category_uid: int) -> BaseResponse[ItemCategory]:
        """Get item category details.

        Args:
            item_category_uid: The item category UID.

        Returns:
            BaseResponse containing the ItemCategory.
        """
        response = self._get(f"/{item_category_uid}")
        return BaseResponse[ItemCategory].model_validate(response)


class OrdersResource(BaseResource):
    """Resource for /orders endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/orders")

    def reset(self, order_id: int) -> BaseResponse[OrderResetResponse]:
        """Reset order for processing.

        Args:
            order_id: The order ID.

        Returns:
            BaseResponse containing the reset result.
        """
        response = self._get(f"/{order_id}/reset")
        return BaseResponse[OrderResetResponse].model_validate(response)


class LegacyClient(BaseServiceClient):
    """Client for the Legacy service.

    Provides access to legacy API endpoints including:
    - Health check (health_check) - inherited from BaseServiceClient
    - States (state)
    - Also Bought (also_bought)
    - Inv Mast Tags (inv_mast_tags)
    - Inv Mast Web Desc (inv_mast_web_desc)
    - Item Category (item_category)
    - Orders (orders)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> states = api.legacy.state.list()
        >>> for state in states.data:
        ...     print(state.state_name)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Legacy client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._state: StateResource | None = None
        self._also_bought: AlsoBoughtResource | None = None
        self._inv_mast_tags: InvMastTagsResource | None = None
        self._inv_mast_web_desc: InvMastWebDescResource | None = None
        self._item_category: ItemCategoryResource | None = None
        self._orders: OrdersResource | None = None

    @property
    def state(self) -> StateResource:
        """Access state endpoints."""
        if self._state is None:
            self._state = StateResource(self._http)
        return self._state

    @property
    def also_bought(self) -> AlsoBoughtResource:
        """Access also bought endpoints."""
        if self._also_bought is None:
            self._also_bought = AlsoBoughtResource(self._http)
        return self._also_bought

    @property
    def inv_mast_tags(self) -> InvMastTagsResource:
        """Access inv mast tags endpoints."""
        if self._inv_mast_tags is None:
            self._inv_mast_tags = InvMastTagsResource(self._http)
        return self._inv_mast_tags

    @property
    def inv_mast_web_desc(self) -> InvMastWebDescResource:
        """Access inv mast web desc endpoints."""
        if self._inv_mast_web_desc is None:
            self._inv_mast_web_desc = InvMastWebDescResource(self._http)
        return self._inv_mast_web_desc

    @property
    def item_category(self) -> ItemCategoryResource:
        """Access item category endpoints."""
        if self._item_category is None:
            self._item_category = ItemCategoryResource(self._http)
        return self._item_category

    @property
    def orders(self) -> OrdersResource:
        """Access orders endpoints."""
        if self._orders is None:
            self._orders = OrdersResource(self._http)
        return self._orders
