"""Open Search service exports."""

from augur_api.services.open_search.client import (
    ItemSearchResource,
    ItemsResource,
    OpenSearchClient,
    QueryStringResource,
    SuggestionsResource,
)
from augur_api.services.open_search.schemas import (
    HealthCheckData,
    ItemDocument,
    ItemRefreshResponse,
    ItemSearchAttribute,
    ItemSearchAttributesData,
    ItemSearchAttributesParams,
    ItemSearchData,
    ItemSearchParams,
    ItemSearchResult,
    ItemsListParams,
    ItemUpdateParams,
    QueryString,
    QueryStringListParams,
    Suggestion,
    SuggestionListParams,
    SuggestionParams,
)

__all__ = [
    # Client
    "OpenSearchClient",
    # Resources
    "ItemSearchResource",
    "ItemsResource",
    "QueryStringResource",
    "SuggestionsResource",
    # Health check
    "HealthCheckData",
    # Item search schemas
    "ItemSearchParams",
    "ItemSearchData",
    "ItemSearchResult",
    "ItemSearchAttributesParams",
    "ItemSearchAttributesData",
    "ItemSearchAttribute",
    # Items schemas
    "ItemsListParams",
    "ItemDocument",
    "ItemUpdateParams",
    "ItemRefreshResponse",
    # Suggestions schemas
    "SuggestionParams",
    "SuggestionListParams",
    "Suggestion",
    # Query string schemas
    "QueryStringListParams",
    "QueryString",
]
