"""Joomla service client for Joomla CMS integration."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.joomla.schemas import (
    Category,
    CategoryListParams,
    Content,
    ContentListParams,
    Extension,
    ExtensionListParams,
    Menu,
    MenuListParams,
    Tag,
    TagListParams,
    TrinityUser,
    User,
    UserDocParams,
    UserGroup,
    Usergroup,
    UserGroupListParams,
    UsergroupsListParams,
    UserListParams,
    VerifyPasswordResult,
)
from augur_api.services.resource import BaseResource


class UsersResource(BaseResource):
    """Resource for /users endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/users")

    def list(self, params: UserListParams | None = None) -> BaseResponse[List[User]]:
        """List users."""
        response = self._get(params=params)
        return BaseResponse[List[User]].model_validate(response)

    def get(self, user_id: int) -> BaseResponse[User]:
        """Get user by ID."""
        response = self._get(f"/{user_id}")
        return BaseResponse[User].model_validate(response)

    def create(self, data: Any) -> BaseResponse[User]:
        """Create a new user."""
        response = self._post(data=data)
        return BaseResponse[User].model_validate(response)

    def update(self, user_id: int, data: Any) -> BaseResponse[User]:
        """Update a user."""
        response = self._put(f"/{user_id}", data=data)
        return BaseResponse[User].model_validate(response)

    def delete(self, user_id: int) -> BaseResponse[bool]:
        """Delete a user."""
        response = self._delete(f"/{user_id}")
        return BaseResponse[bool].model_validate(response)

    def get_doc(self, user_id: int, params: UserDocParams | None = None) -> BaseResponse[User]:
        """Get user document with optional ship-to information."""
        response = self._get(f"/{user_id}/doc", params=params)
        return BaseResponse[User].model_validate(response)

    def verify_password(self, data: Any) -> BaseResponse[VerifyPasswordResult]:
        """Verify the password for a user.

        Args:
            data: Username and password to verify.

        Returns:
            BaseResponse containing the verification result.
        """
        response = self._post("/verify-password", data=data)
        return BaseResponse[VerifyPasswordResult].model_validate(response)

    def get_trinity(self, user_id: int) -> BaseResponse[TrinityUser]:
        """Get Trinity user document.

        Args:
            user_id: The user ID.

        Returns:
            BaseResponse containing the Trinity user document.
        """
        response = self._get(f"/{user_id}/trinity")
        return BaseResponse[TrinityUser].model_validate(response)

    def list_groups(
        self, user_id: int, params: UserGroupListParams | None = None
    ) -> BaseResponse[List[UserGroup]]:
        """List user groups.

        Args:
            user_id: The user ID.
            params: Optional query parameters.

        Returns:
            BaseResponse containing a list of user groups.
        """
        response = self._get(f"/{user_id}/groups", params=params)
        return BaseResponse[List[UserGroup]].model_validate(response)

    def create_group(self, user_id: int, data: Any) -> BaseResponse[UserGroup]:
        """Create/update user group mapping.

        Args:
            user_id: The user ID.
            data: Group mapping data.

        Returns:
            BaseResponse containing the created/updated user group.
        """
        response = self._post(f"/{user_id}/groups", data=data)
        return BaseResponse[UserGroup].model_validate(response)

    def get_group(self, user_id: int, group_id: int) -> BaseResponse[UserGroup]:
        """Get user group.

        Args:
            user_id: The user ID.
            group_id: The group ID.

        Returns:
            BaseResponse containing the user group.
        """
        response = self._get(f"/{user_id}/groups/{group_id}")
        return BaseResponse[UserGroup].model_validate(response)


class ContentResource(BaseResource):
    """Resource for /content endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/content")

    def list(self, params: ContentListParams | None = None) -> BaseResponse[List[Content]]:
        """List content articles."""
        response = self._get(params=params)
        return BaseResponse[List[Content]].model_validate(response)

    def get(self, content_id: int) -> BaseResponse[Content]:
        """Get content by ID."""
        response = self._get(f"/{content_id}")
        return BaseResponse[Content].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Content]:
        """Create new content."""
        response = self._post(data=data)
        return BaseResponse[Content].model_validate(response)

    def update(self, content_id: int, data: Any) -> BaseResponse[Content]:
        """Update content."""
        response = self._put(f"/{content_id}", data=data)
        return BaseResponse[Content].model_validate(response)

    def delete(self, content_id: int) -> BaseResponse[bool]:
        """Delete content."""
        response = self._delete(f"/{content_id}")
        return BaseResponse[bool].model_validate(response)


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")

    def list(self, params: CategoryListParams | None = None) -> BaseResponse[List[Category]]:
        """List categories."""
        response = self._get(params=params)
        return BaseResponse[List[Category]].model_validate(response)

    def get(self, category_id: int) -> BaseResponse[Category]:
        """Get category by ID."""
        response = self._get(f"/{category_id}")
        return BaseResponse[Category].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Category]:
        """Create a new category."""
        response = self._post(data=data)
        return BaseResponse[Category].model_validate(response)


class ExtensionsResource(BaseResource):
    """Resource for /extensions endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/extensions")

    def list(self, params: ExtensionListParams | None = None) -> BaseResponse[List[Extension]]:
        """List extensions."""
        response = self._get(params=params)
        return BaseResponse[List[Extension]].model_validate(response)

    def get(self, extension_id: int) -> BaseResponse[Extension]:
        """Get extension by ID."""
        response = self._get(f"/{extension_id}")
        return BaseResponse[Extension].model_validate(response)


class TagsResource(BaseResource):
    """Resource for /tags endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/tags")

    def list(self, params: TagListParams | None = None) -> BaseResponse[List[Tag]]:
        """List tags."""
        response = self._get(params=params)
        return BaseResponse[List[Tag]].model_validate(response)

    def get(self, tag_id: int) -> BaseResponse[Tag]:
        """Get tag by ID."""
        response = self._get(f"/{tag_id}")
        return BaseResponse[Tag].model_validate(response)


class UsergroupsResource(BaseResource):
    """Resource for /usergroups endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/usergroups")

    def list(self, params: UsergroupsListParams | None = None) -> BaseResponse[List[Usergroup]]:
        """List usergroups."""
        response = self._get(params=params)
        return BaseResponse[List[Usergroup]].model_validate(response)


class MenuResource(BaseResource):
    """Resource for /menu endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/menu")

    def list(self, params: MenuListParams | None = None) -> BaseResponse[List[Menu]]:
        """List menu items."""
        response = self._get(params=params)
        return BaseResponse[List[Menu]].model_validate(response)

    def get(self, menu_id: int) -> BaseResponse[Menu]:
        """Get menu item by ID."""
        response = self._get(f"/{menu_id}")
        return BaseResponse[Menu].model_validate(response)


class JoomlaClient(BaseServiceClient):
    """Client for the Joomla service.

    Provides access to Joomla CMS endpoints including:
    - Health check (health_check)
    - Users (users)
    - Usergroups (usergroups)
    - Content (content)
    - Categories (categories)
    - Extensions (extensions)
    - Tags (tags)
    - Menu (menu)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Joomla client."""
        super().__init__(http_client)
        self._users: UsersResource | None = None
        self._content: ContentResource | None = None
        self._categories: CategoriesResource | None = None
        self._extensions: ExtensionsResource | None = None
        self._tags: TagsResource | None = None
        self._menu: MenuResource | None = None
        self._usergroups: UsergroupsResource | None = None

    @property
    def users(self) -> UsersResource:
        """Access users endpoints."""
        if self._users is None:
            self._users = UsersResource(self._http)
        return self._users

    @property
    def content(self) -> ContentResource:
        """Access content endpoints."""
        if self._content is None:
            self._content = ContentResource(self._http)
        return self._content

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories

    @property
    def extensions(self) -> ExtensionsResource:
        """Access extensions endpoints."""
        if self._extensions is None:
            self._extensions = ExtensionsResource(self._http)
        return self._extensions

    @property
    def tags(self) -> TagsResource:
        """Access tags endpoints."""
        if self._tags is None:
            self._tags = TagsResource(self._http)
        return self._tags

    @property
    def menu(self) -> MenuResource:
        """Access menu endpoints."""
        if self._menu is None:
            self._menu = MenuResource(self._http)
        return self._menu

    @property
    def usergroups(self) -> UsergroupsResource:
        """Access usergroups endpoints."""
        if self._usergroups is None:
            self._usergroups = UsergroupsResource(self._http)
        return self._usergroups
