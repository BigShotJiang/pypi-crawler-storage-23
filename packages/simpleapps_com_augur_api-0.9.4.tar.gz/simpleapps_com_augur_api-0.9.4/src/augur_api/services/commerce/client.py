"""Commerce service client for e-commerce cart and checkout operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.commerce.schemas import (
    AlsoBoughtItem,
    AlsoBoughtParams,
    CartHdr,
    CartHdrListParams,
    CartHdrLookupParams,
    CartLine,
    CartLineDeleteResponse,
    Checkout,
    CheckoutDoc,
    CheckoutDocParams,
    Prophet21Hdr,
    Prophet21Line,
)
from augur_api.services.resource import BaseResource


class CartHdrResource(BaseResource):
    """Resource for /cart-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cart-hdr")

    def list(self, params: CartHdrListParams) -> BaseResponse[List[CartHdr]]:
        """List cart headers for a user.

        Args:
            params: Query parameters including user_id (required).

        Returns:
            BaseResponse containing a list of CartHdr items.
        """
        response = self._get("/list", params=params)
        return BaseResponse[List[CartHdr]].model_validate(response)

    def lookup(self, params: CartHdrLookupParams) -> BaseResponse[CartHdr]:
        """Lookup existing cart or create new one.

        Args:
            params: Lookup parameters including user_id, customer_id, contact_id.

        Returns:
            BaseResponse containing the CartHdr.
        """
        response = self._get("/lookup", params=params)
        return BaseResponse[CartHdr].model_validate(response)

    def get_also_bought(
        self, cart_hdr_uid: int, params: AlsoBoughtParams | None = None
    ) -> BaseResponse[List[AlsoBoughtItem]]:
        """Get product recommendations based on cart contents.

        Args:
            cart_hdr_uid: The cart header UID.
            params: Optional pagination parameters.

        Returns:
            BaseResponse containing a list of recommended items.
        """
        response = self._get(f"/{cart_hdr_uid}/also-bought", params=params)
        return BaseResponse[List[AlsoBoughtItem]].model_validate(response)


class CartLineResource(BaseResource):
    """Resource for /cart-line endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/cart-line")

    def get(self, cart_hdr_uid: int) -> BaseResponse[List[CartLine]]:
        """Get all line items for a cart.

        Args:
            cart_hdr_uid: The cart header UID.

        Returns:
            BaseResponse containing a list of CartLine items.
        """
        response = self._get(f"/{cart_hdr_uid}")
        return BaseResponse[List[CartLine]].model_validate(response)

    def delete_all(self, cart_hdr_uid: int) -> BaseResponse[CartLineDeleteResponse]:
        """Remove all line items from a cart.

        Args:
            cart_hdr_uid: The cart header UID.

        Returns:
            BaseResponse containing deletion status.
        """
        response = self._delete(f"/{cart_hdr_uid}")
        return BaseResponse[CartLineDeleteResponse].model_validate(response)

    def add(self, cart_hdr_uid: int, items: Any) -> BaseResponse[bool]:
        """Add items to cart.

        Args:
            cart_hdr_uid: The cart header UID.
            items: List of items to add.

        Returns:
            BaseResponse containing success status.
        """
        response = self._http.post(
            f"{self._path}/{cart_hdr_uid}/add",
            data=items,
        )
        return BaseResponse[bool].model_validate(response)

    def delete_line(self, cart_hdr_uid: int, line_no: int) -> BaseResponse[CartLineDeleteResponse]:
        """Remove a specific line item from cart.

        Args:
            cart_hdr_uid: The cart header UID.
            line_no: The line number to delete.

        Returns:
            BaseResponse containing deletion status.
        """
        response = self._delete(f"/{cart_hdr_uid}/lines/{line_no}")
        return BaseResponse[CartLineDeleteResponse].model_validate(response)

    def update(self, cart_hdr_uid: int, items: Any) -> BaseResponse[bool]:
        """Update cart line items.

        Args:
            cart_hdr_uid: The cart header UID.
            items: List of items to update.

        Returns:
            BaseResponse containing success status.
        """
        response = self._http.post(
            f"{self._path}/{cart_hdr_uid}/update",
            data=items,
        )
        return BaseResponse[bool].model_validate(response)


class CheckoutResource(BaseResource):
    """Resource for /checkout endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/checkout")

    def create(self, data: Any) -> BaseResponse[Checkout]:
        """Create a new checkout session.

        Args:
            data: Checkout creation parameters.

        Returns:
            BaseResponse containing the created Checkout.
        """
        response = self._post(data=data)
        return BaseResponse[Checkout].model_validate(response)

    def get(self, checkout_uid: int) -> BaseResponse[Checkout]:
        """Get checkout by UID.

        Args:
            checkout_uid: The checkout UID.

        Returns:
            BaseResponse containing the Checkout.
        """
        response = self._get(f"/{checkout_uid}")
        return BaseResponse[Checkout].model_validate(response)

    def activate(self, checkout_uid: int) -> BaseResponse[Checkout]:
        """Activate and process checkout.

        Args:
            checkout_uid: The checkout UID.

        Returns:
            BaseResponse containing the activated Checkout.
        """
        response = self._put(f"/{checkout_uid}/activate")
        return BaseResponse[Checkout].model_validate(response)

    def get_doc(
        self, checkout_uid: int, params: CheckoutDocParams | None = None
    ) -> BaseResponse[CheckoutDoc]:
        """Get formatted checkout document.

        Args:
            checkout_uid: The checkout UID.
            params: Optional document parameters.

        Returns:
            BaseResponse containing the CheckoutDoc.
        """
        response = self._get(f"/{checkout_uid}/doc", params=params)
        return BaseResponse[CheckoutDoc].model_validate(response)

    def validate(self, checkout_uid: int) -> BaseResponse[Checkout]:
        """Validate checkout data.

        Args:
            checkout_uid: The checkout UID.

        Returns:
            BaseResponse containing the validated Checkout.
        """
        response = self._put(f"/{checkout_uid}/validate")
        return BaseResponse[Checkout].model_validate(response)

    def create_prophet21_hdr(self, checkout_uid: int) -> BaseResponse[Prophet21Hdr]:
        """Create Prophet21 checkout header.

        Args:
            checkout_uid: The checkout UID.

        Returns:
            BaseResponse containing the Prophet21Hdr.
        """
        response = self._post(f"/{checkout_uid}/prophet21-hdr")
        return BaseResponse[Prophet21Hdr].model_validate(response)

    def create_prophet21_line(
        self, checkout_uid: int, prophet21_hdr_uid: int
    ) -> BaseResponse[List[Prophet21Line]]:
        """Add Prophet21 checkout lines.

        Args:
            checkout_uid: The checkout UID.
            prophet21_hdr_uid: The Prophet21 header UID.

        Returns:
            BaseResponse containing the Prophet21Line items.
        """
        response = self._post(f"/{checkout_uid}/prophet21-hdr/{prophet21_hdr_uid}/prophet21-line")
        return BaseResponse[List[Prophet21Line]].model_validate(response)


class CommerceClient(BaseServiceClient):
    """Client for the Commerce service.

    Provides access to e-commerce cart and checkout endpoints including:
    - Health check (health_check)
    - Cart headers (cart_hdr)
    - Cart lines (cart_line)
    - Checkout (checkout)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> cart = api.commerce.cart_hdr.lookup(CartHdrLookupParams(
        ...     user_id=1, customer_id=100, contact_id=50
        ... ))
        >>> print(cart.data.cart_hdr_uid)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Commerce client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._cart_hdr: CartHdrResource | None = None
        self._cart_line: CartLineResource | None = None
        self._checkout: CheckoutResource | None = None

    @property
    def cart_hdr(self) -> CartHdrResource:
        """Access cart header endpoints."""
        if self._cart_hdr is None:
            self._cart_hdr = CartHdrResource(self._http)
        return self._cart_hdr

    @property
    def cart_line(self) -> CartLineResource:
        """Access cart line endpoints."""
        if self._cart_line is None:
            self._cart_line = CartLineResource(self._http)
        return self._cart_line

    @property
    def checkout(self) -> CheckoutResource:
        """Access checkout endpoints."""
        if self._checkout is None:
            self._checkout = CheckoutResource(self._http)
        return self._checkout
