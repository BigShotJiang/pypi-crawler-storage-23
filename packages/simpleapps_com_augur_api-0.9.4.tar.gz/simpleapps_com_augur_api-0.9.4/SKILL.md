---
name: augur-api-python-client
description: |
  Guide for AI agents helping developers use simpleapps-com-augur-api (Python).
  Shows the unified API pattern and points to live documentation for discovery.
---

# Augur API Python Client - Agent Guide

Python client library for 27 Augur microservices via a unified API.

## Ecosystem Entry Point

```
augur-api.info → items.augur-api.com/llms.txt → Any service llms.txt
       ↓                    ↓                           ↓
    (seed)           (canonical example)         (same pattern)
```

Start at **https://augur-api.info** - it seeds the pattern and points to documentation.

## The One Pattern (Learn Once, Use Everywhere)

```
┌─────────────────────────────────────────────────────────────────────┐
│  llms.txt endpoint    →    Client code                              │
├─────────────────────────────────────────────────────────────────────┤
│  GET /inv-mast        →    api.items.inv_mast.list()                │
│  GET /inv-mast/{id}   →    api.items.inv_mast.get(id)               │
│  GET /inv-mast/lookup →    api.items.inv_mast.lookup()              │
│  POST /inv-mast       →    api.items.inv_mast.create(data)          │
└─────────────────────────────────────────────────────────────────────┘

THE RULE: Path segments become nested properties (kebab-case → snake_case)
          HTTP methods become terminal functions (GET→list/get, POST→create)
```

## Quick Start

```python
from augur_api import AugurAPI

api = AugurAPI(
    token="your-bearer-token",
    site_id="your-site-id",
)

# Pattern: api.{service}.{path_segment}.{method}()
items = api.items.inv_mast.list(limit=10)
item = api.items.inv_mast.get(12345)
```

## Complete Example: From llms.txt to Code

```
1. FETCH llms.txt
   https://items.augur-api.com/llms.txt

   Shows endpoints:
   GET /inv-mast
   GET /inv-mast/{invMastUid}
   GET /inv-mast/lookup
   GET /inv-mast/{invMastUid}/faq
   POST /inv-mast/{invMastUid}/faq
   ...

2. CONVERT path to code (kebab-case → snake_case)
   /inv-mast           → .inv_mast
   /inv-mast/lookup    → .inv_mast.lookup
   /inv-mast/{id}/faq  → .inv_mast.faq

3. ADD service prefix
   items service → api.items.inv_mast

4. ADD method based on HTTP verb
   GET (list)    → .list(params)
   GET (by id)   → .get(id)
   POST          → .create(data)
   PUT           → .update(id, data)
   DELETE        → .delete(id)

5. RESULT
   GET /inv-mast                    → api.items.inv_mast.list()
   GET /inv-mast/{id}               → api.items.inv_mast.get(id)
   GET /inv-mast/lookup             → api.items.inv_mast.lookup()
   GET /inv-mast/{id}/faq           → api.items.inv_mast.list_faq(id)
   POST /inv-mast/{id}/faq          → api.items.inv_mast.create_faq(id, data)
```

## Service Discovery

**Every llms.txt has an "Other Services" section listing all 27 services:**

```
Fetch: https://items.augur-api.com/llms.txt
                    ↓
Find "Other Services" section:
  - agr-info     → api.agr_info
  - basecamp2    → api.basecamp2
  - customers    → api.customers
  - orders       → api.orders
  - pricing      → api.pricing
  ... (all 27 services)
                    ↓
Apply same pattern to any service:
  https://orders.augur-api.com/llms.txt → api.orders.{resource}
```

## Documentation Resources (Per Service)

| Resource | URL Pattern | Use When |
|----------|-------------|----------|
| **llms.txt** | `https://{service}.augur-api.com/llms.txt` | Discover endpoints |
| **endpoints.jsonl** | `https://{service}.augur-api.com/endpoints.jsonl` | Get parameters |
| **openapi.json** | `https://{service}.augur-api.com/openapi.json` | Full schemas |

**Central Reference:** https://augur-api.info

## Service Name Conversions

```
URL Service Name     →  API Property
─────────────────────────────────────
items                →  api.items
customers            →  api.customers
brand-folder         →  api.brand_folder
p21-pim              →  api.p21_pim
open-search          →  api.open_search
agr-site             →  api.agr_site
```

**Rule:** kebab-case → snake_case (replace hyphens with underscores)

## Client Code Structure

```
src/augur_api/services/{service}/
├── __init__.py        # Public exports
├── client.py          # {Service}Client class with all resources
└── schemas.py         # Pydantic validation schemas
```

**To verify exact property names:** Read `src/augur_api/services/{service}/client.py`

## Strategy for Agents

1. **Start** - `AugurAPI(token=..., site_id=...)`
2. **Discover** - Fetch any `llms.txt`, find "Other Services"
3. **Find endpoints** - Fetch target service's `llms.txt`
4. **Get parameters** - Fetch `endpoints.jsonl` for method signatures
5. **Convert to code** - Apply the path→property pattern (use snake_case)
6. **Verify** - Check `src/augur_api/services/{service}/client.py` if unsure

## Authentication

All endpoints require:
- `token` - Bearer authentication token
- `site_id` - Site identifier

The client handles headers automatically.

## Edge Caching

Enable Cloudflare edge caching on any GET request:

```python
# Sub-hour: "30s", "1m", "5m"
items = api.items.inv_mast.list(edge_cache="5m")

# Hours: 1, 2, 3, 4, 5, or 8 (hours)
items = api.items.inv_mast.list(edge_cache=1)  # 1 hour
```

| Value | Duration |
|-------|----------|
| `"30s"` | 30 seconds |
| `"1m"` | 1 minute |
| `"5m"` | 5 minutes |
| `1`, `2`, `3`, `4`, `5`, `8` | Hours |

The client transforms `edge_cache` to Cloudflare's `cacheSiteId{N}=<site_id>` format automatically.

## Response Pattern

All methods return `BaseResponse[T]` containing:

```python
response = api.items.inv_mast.list()
response.data      # The actual data (list or single item)
response.count     # Number of items returned
response.total     # Total items available
response.message   # Status message
response.status    # HTTP status code
```

## Pydantic Models

All request params and response data use Pydantic models:

```python
from augur_api.services.items import InvMastListParams, InvMast

# Type-safe params
params = InvMastListParams(limit=10, offset=0)
response = api.items.inv_mast.list(params)

# Type-safe response
for item in response.data:
    print(item.item_id)  # IDE autocomplete works
```

## Key Differences from TypeScript Client

| Aspect | TypeScript | Python |
|--------|------------|--------|
| Naming | camelCase | snake_case |
| Service: brand-folder | api.brandFolder | api.brand_folder |
| Resource: inv-mast | .invMast | .inv_mast |
| Method: invMastUid | inv_mast_uid | inv_mast_uid |
| Validation | Zod | Pydantic v2 |
