Review this code change.

Task: ${TASK_ID} - ${TASK_NAME}

Changed files:
${CHANGED_FILES}

Diff summary:
${GIT_DIFF}

Check for:
- Bugs
- Security issues
- Missing tests

End your response with one word:
- REVIEW_PASSED (if code is good)
- REVIEW_FIXED (if you fixed issues)
- REVIEW_FAILED (if issues remain)
