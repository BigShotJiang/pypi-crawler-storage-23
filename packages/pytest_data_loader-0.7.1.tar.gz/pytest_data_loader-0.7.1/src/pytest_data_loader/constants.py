from pathlib import Path

DEFAULT_LOADER_DIR_NAME = "data"
PYTEST_DATA_LOADER_ATTR = "_pytest_data_loader"
ROOT_DIR = Path(".").resolve().anchor
