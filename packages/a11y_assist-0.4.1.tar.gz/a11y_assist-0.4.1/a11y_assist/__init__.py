"""a11y-assist: Low-vision-first assistant for CLI failures."""

__version__ = "0.4.1"
