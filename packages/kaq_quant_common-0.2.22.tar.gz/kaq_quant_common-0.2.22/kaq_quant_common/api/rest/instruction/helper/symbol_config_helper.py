import json
from kaq_quant_common.resources.kaq_redis_resources import KaqQuantRedisRepository


class SymbolConfigHelper:
    def __init__(self, ins_server, is_mock: bool = False):
        self._server = ins_server
        # 组装key
        self._redis_key = f"kaq_futures_exchange_symbol_config{'_mock' if is_mock else ''}:{self._server._exchange.upper()}"

    def get_config(self, symbol):
        redis = self._server._redis
        # 获取hash
        hash_value = redis.client.hget(self._redis_key, symbol)
        try:
            if hash_value is None:
                return None
            return json.loads(hash_value)
        except Exception as e:
            return None

    def set_config(self, symbol, config):
        redis = self._server._redis
        redis.client.hset(self._redis_key, symbol, json.dumps(config))

    def set_leverage(self, symbol, leverage):
        config = self.get_config(symbol)
        if config is None:
            config = {}
        config["leverage"] = leverage
        self.set_config(symbol, config)

    def get_leverage(self, symbol):
        config = self.get_config(symbol)
        if config is None:
            return None
        if "leverage" in config:
            return config["leverage"]
        return None
