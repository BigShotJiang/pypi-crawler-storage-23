from typing import Optional

from kaq_quant_common.api.rest.instruction.models import (
    InstructionRequestBase,
    InstructionResponseBase,
)

# -----------------------------借贷-------------------


# ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 活期借币
class QueryFlexibleLoanAssetRequest(InstructionRequestBase):
    # 币种代码
    coin: str


class QueryFlexibleLoanAssetResponse(InstructionResponseBase):
    # 币种代码
    coin: str
    # 系统可借充足情况下用户账户当前最大可借额度
    amount: Optional[float] = None
    # 平台限制的用户当前等级可以借的额度
    borrow_limit: Optional[float] = None
