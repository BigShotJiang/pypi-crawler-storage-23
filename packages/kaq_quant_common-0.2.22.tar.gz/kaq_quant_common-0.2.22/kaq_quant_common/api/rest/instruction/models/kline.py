from enum import Enum
from typing import Optional

from . import InstructionRequestBase, InstructionResponseBase
from pydantic import BaseModel


# k线数据
class KlineData(BaseModel):
    # 时间戳-秒
    time: int
    # 开盘价
    open: float
    # 最高价
    high: float
    # 最低价
    low: float
    # 收盘价
    close: float
    # 成交量
    volume: float


# 间隔枚举
class KlineInterval(str, Enum):
    ONE_MINUTE = "1m"
    THREE_MINUTE = "3m"
    FIVE_MINUTE = "5m"
    FIFTEEN_MINUTE = "15m"
    THIRTY_MINUTE = "30m"
    ONE_HOUR = "1h"
    TWO_HOUR = "2h"
    FOUR_HOUR = "4h"
    SIX_HOUR = "6h"
    EIGHT_HOUR = "8h"
    TWELVE_HOUR = "12h"
    ONE_DAY = "1d"
    THREE_DAY = "3d"
    ONE_WEEK = "1w"
    ONE_MONTH = "1M"


class KlineRequest(InstructionRequestBase):
    # 交易对
    symbol: str
    # 间隔
    interval: KlineInterval
    # 开始时间-毫秒
    start_time: Optional[int] = None
    # 结束时间-毫秒
    end_time: Optional[int] = None
    # 返回数量
    limit: Optional[int] = None
    # 是否现货
    spot: Optional[bool] = None


class KlineResponse(InstructionResponseBase):
    # k线数据
    data: list[KlineData]
