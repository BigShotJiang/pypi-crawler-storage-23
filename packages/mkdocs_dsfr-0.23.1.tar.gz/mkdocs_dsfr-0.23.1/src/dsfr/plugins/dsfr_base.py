import sys

import jinja2
from mkdocs.config.defaults import MkDocsConfig
from mkdocs.plugins import BasePlugin
from mkdocs.structure.files import Files
from mkdocs.structure.pages import Page


class DsfrBasePlugin(BasePlugin):
    def __init__(self) -> None:
        self.files_tree = {}
        super().__init__()

    def on_config(self, config: MkDocsConfig) -> MkDocsConfig | None:
        self._add_site_url(config)
        return config

    # def on_files(self, files: Files, /, *, config: MkDocsConfig) -> Files | None:
    #     for file in files.documentation_pages():
    #         path = file.src_uri.split("/")
    #         if len(path) <= 1:
    #             continue
    #         cur_dict = self.files_tree
    #         for dir in path[:-1]:
    #             cur_dict = cur_dict.setdefault(dir, {})
    #         cur_dict[path[-1]] = file.src_uri

    #     print("Src_URI : " + str(self.files_tree), file=sys.stderr)
    #     return files

    def on_page_content(
        self, html: str, /, *, page: Page, config: MkDocsConfig, files: Files
    ) -> str | None:
        title = page.title
        path = page.url.split("/")
        if len(path) > 1:
            cur_dict = self.files_tree
            for dir in path[:-1]:
                cur_dict = cur_dict.setdefault(dir, {})
            cur_dict[path[-1]] = title
        return html

    def on_env(
        self, env: jinja2.Environment, /, *, config: MkDocsConfig, files: Files
    ) -> jinja2.Environment | None:
        print("Files tree : \n" + str(self.files_tree), file=sys.stderr)
        env.globals["folder_toc"] = self.files_tree
        env.globals["subtree_list"] = subtree_list
        return env

    def _add_site_url(self, config: MkDocsConfig) -> None:
        self._set_extension_config(config, "dsfr_base_enabled", True)
        site_url = config.get("site_url", "")
        if site_url:
            self._set_extension_config(config, "site_url", site_url)

    def _set_extension_config(self, config, key, value):
        if "dsfr_structure.extension.all_extensions" in config["markdown_extensions"]:
            mdx_config = config["mdx_configs"].setdefault(
                "dsfr_structure.extension.all_extensions", {}
            )
            mdx_config.setdefault(key, value)


def list_from_dict_rec(src_dict, base=""):
    result = []
    base_title = ""
    for key, value in sorted(src_dict.items()):
        if isinstance(value, dict):
            sub_base_title, sub_result = list_from_dict_rec(value, base + key + "/")
            result.append(
                {
                    "title": sub_base_title if sub_base_title else format_title(key),
                    "url": base + key if sub_base_title else "",
                    "children": sub_result,
                }
            )
        elif key == "":
            base_title = value
        else:
            result.append(value)
    return base_title, result


def subtree_list(src_dict, url):
    if not url:
        url = "/"
    path = url.strip("/").split("/")
    if len(path) == 1 and path[0] == "":
        return []
    if len(list(filter(lambda k: k != "", src_dict[path[0]].keys()))) == 0:
        return []
    new_base = path[0] + "/"
    root, tree_list = list_from_dict_rec(src_dict[path[0]], base=new_base)
    return [{"title": root, "url": new_base, "children": tree_list}]


def format_title(dir_or_filename: str) -> str:
    return (
        dir_or_filename.replace(".md", "").replace("-", " ").replace("_", " ").title()
    )


def str_tree(tree, indent=0):
    result = ""
    for item in tree:
        result += " " * indent + f"[{item['label']}]({item['url']})\n"
        if isinstance(item["children"], list):
            result += str_tree(item["children"], indent + 2)
    return result
