"""Module with default configurations or constants"""

__all__ = [
    "FIGSIZE_WIDE",
    "FIGSIZE",
    "DPI",
    "MOTOR_STEP_SIZE",
    "COV_FORMAT",
    "COEF_FORMAT",
    "N_CHANNELS_MINION",
    "VOLTAGE_FIELD_NAME",
    "CURRENT_FIELD_NAME",
    "CONDUCTANCE_FIELD_NAME",
    "STATE_FIELD_NAME",
    "Y_LABELS",
    "START_IDX_COL",
    "END_IDX_COL",
    "N_PTS_COL",
    "START_TIME_COL",
    "END_TIME_COL",
    "DURATION_COL",
    "IOS_COL",
    "STEP_RATE_COL",
    "CHANNEL_COL",
    "IOS_COLOR",
    "RAW_PLOT_TARGET_POINTS",
    "MEAN_COL",
    "STD_COL",
    "DWELL_TIME_COL",
    "EVENT_COL",
    "POREFLOW_GROUP",
    "EVENTS_DATASET",
    "IOS_FIT_DATASET",
    "STEPS_DATASET",
    "STEP_IDX_COL",
    "QUALITY_COL",
    "LABEL_COL",
]

FIGSIZE_WIDE = (8, 3)
FIGSIZE = (4, 3)
DPI = 150
MOTOR_STEP_SIZE = 0.55  # Step size in nucleotides for motor enzyme. In this case for Hel308. Exact size

COV_FORMAT = "cov_{},{}"
COEF_FORMAT = "coef_{}"

N_CHANNELS_MINION = 512
VOLTAGE_FIELD_NAME = "v"
CURRENT_FIELD_NAME = "i"
CONDUCTANCE_FIELD_NAME = "g"
STATE_FIELD_NAME = "state"
Y_LABELS = {"v": "$V$ (mV)", "i": "$I$ (pA)"}


### EVENTS ###
START_IDX_COL = "start_idx"
END_IDX_COL = "end_idx"
N_PTS_COL = "n_pts"
START_TIME_COL = "start_time"
END_TIME_COL = "end_time"
DURATION_COL = "duration"
IOS_COL = "ios"
STEP_RATE_COL = "step_rate"
CHANNEL_COL = "channel"
STEP_IDX_COL = "step_idx"
QUALITY_COL = "quality"
LABEL_COL = "label"

## COLORS
IOS_COLOR = ".25"

RAW_PLOT_TARGET_POINTS = 100000

## STEPS ###
MEAN_COL = "mean"
STD_COL = "std"
DWELL_TIME_COL = "dwell_time"
EVENT_COL = "event"

POREFLOW_GROUP = "PoreFlowData"
EVENTS_DATASET = "Events"
IOS_FIT_DATASET = "IOS"
STEPS_DATASET = "Steps"
