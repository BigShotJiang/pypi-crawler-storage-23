import numpy as np
import pandas as pd

import poreflow as pf
from poreflow import utils


class StepsDataFrame(pd.DataFrame):
    """Steps data frame

    Data frame must contain the following columns:
    - start_idx (integers): The start index of the step in the event
    - end_idx (integers): The end index of the step in the event
    - std (float): The standard deviation of the current during the step
    - mean (float): The mean of the current during the step
    - n_pts (int): The number of points in the step

    Other optional columns are:
    - start_time (float): The start time of the step
    - end_time (float): The end time of the step
    - dwell_time (float): The dwell time of the step
    - event (int): The event number of the step. Useful when concatenating
      multiple step dataframes
    - step_idx (int): The index of the step in the event


    """

    _metadata = [
        "sfreq",
    ]

    def __init__(self, data=None, *args, sfreq=None, **kwargs):
        super().__init__(data, *args, **kwargs)
        self.sfreq = sfreq

    @property
    def has_times(self):
        return (
            pf.START_TIME_COL in self.columns
            and pf.END_TIME_COL in self.columns
            and pf.DWELL_TIME_COL in self.columns
        )

    def calculate_times(self):
        utils.calculate_times(self, self.sfreq, duration_col=pf.DWELL_TIME_COL)

    @property
    def _constructor(self):
        return StepsDataFrame

    def as_dataframe(self):
        return pd.DataFrame(self)

    def add_channel(self, channel: int = 1):
        self[pf.CHANNEL_COL] = channel

    def add_event(self, event: int = 1):
        self[pf.EVENT_COL] = event

    def add_step_idx(self):
        self[pf.STEP_IDX_COL] = np.arange(len(self), dtype=int)
