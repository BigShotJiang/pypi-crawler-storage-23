import os
import typing

import numpy as np
import seaborn as sns
from matplotlib import pyplot as plt

import poreflow as pf
from poreflow import BaseDataFrame, utils


class RawDataFrame(BaseDataFrame):
    @property
    def _constructor(self):
        return RawDataFrame

    def plot(
        self,
        y="i",
        ax=None,
        edgecolor=None,
        s=1,
        **kwargs,
    ):
        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        if len(self) > pf.RAW_PLOT_TARGET_POINTS:
            plot_obj = self.decimate(pf.RAW_PLOT_TARGET_POINTS)
        else:
            plot_obj = self

        x = kwargs.pop("x", plot_obj.t)

        sns.scatterplot(
            data=plot_obj, x=x, y=y, ax=ax, edgecolor=edgecolor, s=s, **kwargs
        )

        if y == "i" and self.ios is not None:
            self.plot_ios(ax)

        self._add_plot_labels(ax, y)

        return ax

    def _add_plot_labels(self, ax, y):
        ax.set_xlabel("$t$ (s)")
        ax.set_ylabel(pf.Y_LABELS.get(y, "Value"))
        ax.set_title(getattr(self, "name", ""), fontsize=7)

    def plot_ios(self, ax):
        if self.ios is None:
            text = "No open state found"
        elif callable(self.ios):
            x_line = (np.linspace(0, len(self)) + self.start_idx) / self.sfreq
            ax.plot(x_line, self.ios(x_line), color=pf.IOS_COLOR, linestyle="--")
            text = _poly_text(self.ios, decimals=4)
        else:
            ax.axhline(self.ios, color=pf.IOS_COLOR, linestyle="--")
            text = r"$I_\text{OS}=" + f" {self.ios:.0f}$"
        ax.text(
            0.99,
            0.99,
            text,
            ha="right",
            va="top",
            transform=ax.transAxes,
            color=pf.IOS_COLOR,
        )
        return ax

    def has_state(self):
        return pf.STATE_FIELD_NAME in self

    def reset_states(self):
        self[pf.STATE_FIELD_NAME] = pf.GOOD_STATE

    @classmethod
    def from_labview(
        cls,
        filename: os.PathLike,
        sfreq: typing.Optional[float] = 5000,
        bfreq: float = None,
        bamp: float = None,
        verbose: bool = False,
    ) -> "RawDataFrame":
        """
        Reads measurement data from a LabView .dat file and creates a Raw data object.

        Args:
            verbose:
            filename (os.PathLike): Path to the measurement data file to be loaded.
            sfreq (typing.Optional[float]): Target frequency for optional downsampling. Defaults to 5000 Hz.
            bfreq (typing.Optional[float]): Bias voltage frequency in Hz. Defaults to None, which corresponds to a constant
                voltage measurement.
            bamp (typing.Optional[float]): Bias voltage amplitude in mV. Defaults to None, which corresponds to a constant
                voltage measurement.

        Returns:
            poreflow.base.RawDataFrame: A RawDataFrame object containing the processed voltage and current data.
        """

        from poreflow.io import labview

        return labview.read_measurement_dat(
            filename, verbose=verbose, downsample_to_freq=sfreq, bfreq=bfreq, bamp=bamp
        )

    @property
    def i_loc(self):
        """Get column number, usefol for iloc"""
        return self.columns.get_loc(pf.CURRENT_FIELD_NAME)

    @property
    def v_loc(self):
        """Get column number, usefol for iloc"""
        return self.columns.get_loc(pf.VOLTAGE_FIELD_NAME)

    def decimate(self, target_size: int) -> "RawDataFrame":
        factor = len(self) / target_size
        i, v = utils.decimate(
            self[pf.CURRENT_FIELD_NAME], self[pf.VOLTAGE_FIELD_NAME], factor, 1
        )

        sfreq = self.sfreq * len(i) / len(self)  # Caculate true new sampling rate

        new = self.iloc[: len(i)]

        new.loc[:, pf.CURRENT_FIELD_NAME] = i
        new.loc[:, pf.VOLTAGE_FIELD_NAME] = v.astype(self.dtypes[pf.VOLTAGE_FIELD_NAME])

        new.sfreq = sfreq

        return new

    def find_events(self, **kwargs) -> pf.EventsDataFrame:
        from poreflow.events import detection

        return detection.find_events(self, **kwargs)

    def add_event_number_to_raw(self, events: pf.EventsDataFrame):
        raw = self.copy()
        raw.loc[:, pf.EVENT_COL] = 0

        ratio = raw.sfreq / events.sfreq  # Raw might be downsampled

        idxs = events[[pf.START_IDX_COL, pf.END_IDX_COL]]
        idxs = (idxs * ratio).astype(np.int32)

        for j, (start, end) in idxs.iterrows():
            raw.loc[start:end, pf.EVENT_COL] = j + 1

        return raw

    def plot_with_events(
        self,
        events: pf.EventsDataFrame,
        ax=None,
        edgecolor=None,
        s=1,
        legend=False,
        **kwargs,
    ) -> plt.Axes:
        if len(self) > pf.RAW_PLOT_TARGET_POINTS:
            raw = self.decimate(pf.RAW_PLOT_TARGET_POINTS)
        else:
            raw = self

        raw = raw.add_event_number_to_raw(events)

        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        mask = raw[pf.EVENT_COL] != 0

        kwargs["edgecolor"] = edgecolor
        kwargs["s"] = s
        kwargs["y"] = "i"
        kwargs["ax"] = ax
        kwargs["legend"] = legend

        if mask.any():
            sns.scatterplot(data=raw[mask], x=raw.t[mask], hue=pf.EVENT_COL, **kwargs)

        mask = ~mask  # Invert mask
        alpha = kwargs.pop("alpha", 1)
        kwargs.pop("palette", None)

        sns.scatterplot(
            data=raw[mask], x=raw.t[mask], alpha=0.25 * alpha, color=".5", **kwargs
        )

        self._add_plot_labels(ax, "i")

        return ax


def _poly_text(poly: np.polynomial.Polynomial, decimals: int = 0) -> str:
    poly = np.polynomial.Polynomial(poly.coef.round(decimals))
    return r"$I_\text{OS}=" + f"{poly:ascii}$".replace("x", "t")
