import copy
import warnings

import scipy

import poreflow as pf
from poreflow.steps import changepoint
from poreflow.structures.base import BaseDataFrame


class EventDataFrame(BaseDataFrame):
    """Data frame storing events in a nanopore read

    Data frame must contain the following columns:
    - i (floats): The current of an event
       "sfreq",
        "name",
        "bdc",
        "bamp",
        "bfreq",
        "ios",
        "channel",
        "start_idx",

    Attributes:
        sfreq (float): The sampling frequency
        name (str): The name of the event
        bdc (float): The bias voltage DC value in mV
        bamp (float): The bias voltage amplitude value in mV.
          0 for constant-voltage measurements
        bfreq (float): The bias voltage frequency in Hz. 0 for constant-voltage measurements
        ios (float): The local open-state current around the event.
        channel (int): The channel number in which the event occurs.
        start_idx (int): The start index in the measurement in which the event occurs.


    """

    _metadata = [
        "quality",
        "label",
    ]

    def __init__(self, data=None, *args, quality=None, label=None, **kwargs):
        super().__init__(data, *args, **kwargs)
        self.quality = quality
        self.label = label

    @property
    def _constructor(self):
        return EventDataFrame

    def find_steps(
        self,
        **kwargs,
    ) -> pf.StepsDataFrame:
        return changepoint.get_steps(self[pf.CURRENT_FIELD_NAME], self.sfreq, **kwargs)

    def get_bv_period(self) -> int:
        return int(self.sfreq / self.bfreq)

    @property
    def start_time(self) -> float:
        """The time at which the event started"""
        return self.start_time / self.ios

    def resample_data(self, sfreq: float = 500, method="fft", inplace=False):
        if sfreq > self.sfreq:
            warnings.warn(
                f"Tried to resample Event with sampling rate of {self.sfreq} "
                f"to {sfreq} Hz. Skipping."
            )

            return self

        if inplace:
            eve = self
        else:
            eve = copy.deepcopy(self)

        if method != "fft":
            raise NotImplementedError("Method must be 'fft'")

        n_after = int(len(self) * sfreq / self.sfreq)

        v = eve.v.values if hasattr(eve.v, "values") else eve.v
        i = eve.i.values if hasattr(eve.i, "values") else eve.i
        # Using .values for numpy array, assuming i/v columns exist

        # Truncate
        eve = eve.iloc[:n_after]  # Truncate dataframe length

        # Resample columns
        eve["v"] = scipy.signal.resample(v, n_after)
        eve["i"] = scipy.signal.resample(i, n_after)

        eve.sfreq = sfreq

        return eve
