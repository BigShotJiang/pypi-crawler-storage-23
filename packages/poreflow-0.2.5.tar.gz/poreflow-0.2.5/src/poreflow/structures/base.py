#
#      Copyright (C) 2024 Thijn Hoekstra
#
#      This program is free software: you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation, either version 3 of the License, or
#      (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
#
import pathlib
import typing

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

import poreflow as pf


class BaseDataFrame(pd.DataFrame):
    # normal properties
    _metadata = [
        "sfreq",
        "name",
        "bdc",
        "bamp",
        "bfreq",
        "ios",
        "channel",
        "start_idx",
    ]

    def __init__(
        self,
        data=None,
        *args,
        sfreq=None,
        name=None,
        bdc: float = None,
        bamp: float = None,
        bfreq: float = None,
        ios: float | np.polynomial.Polynomial = None,
        channel: int = 1,
        start_idx: int = 0,
        **kwargs,
    ):
        super().__init__(data, *args, **kwargs)
        self.sfreq = sfreq
        self.name = name
        self.bdc = bdc
        self.bamp = bamp
        self.bfreq = bfreq
        self.ios = ios
        self.channel = channel
        self.start_idx = start_idx

    @property
    def _constructor(self):
        return BaseDataFrame

    @property
    def duration(self):
        return len(self) / self.sfreq

    def get_nyquist(self):
        return self.sfreq / 2

    @property
    def t(self):
        return np.arange(len(self)) / self.sfreq

    def get_t(self, absolute=False) -> np.ndarray:
        t = self.t
        if absolute:
            t += self.start_idx / self.sfreq
        return t

    @property
    def t_ms(self):
        return self.t * 1000

    def plot(
        self,
        y="i",
        ax=None,
        ms=False,
        **kwargs,
    ):
        if ax is None:
            fig, ax = plt.subplots(figsize=pf.FIGSIZE_WIDE, dpi=150)

        x = kwargs.pop("x", self.t_ms if ms else self.t)

        sns.lineplot(data=self, x=x, y=y, ax=ax, **kwargs)

        if self.ios is not None:
            ax.axhline(self.ios, color=".5", linestyle="--")

        ax.set_xlabel("$t$ (s)")
        ax.set_ylabel(pf.Y_LABELS.get(y, "Value"))
        ax.set_title(getattr(self, "name", ""))

        return ax

    def reset_indices(self):
        """Resets indices of data"""
        self.start_idx = self.index[0]
        self.reset_index(inplace=True, drop=True)

    def save(self, path: typing.Union[str, pathlib.Path]):
        """Save data to an HDF5 file.

        Args:
            path (str or pathlib.Path): Path to save the file to.
        """
        with pd.HDFStore(path, "w") as store:
            store.put("data", self)
            metadata = {
                key: getattr(self, key)
                for key in self._metadata
                if hasattr(self, key) and getattr(self, key) is not None
            }
            store.get_storer("data").attrs.metadata = metadata

    @classmethod
    def load(cls, path: typing.Union[str, pathlib.Path]):
        """Load data from an HDF5 file.

        Args:
            path (str or pathlib.Path): Path to load the file from.

        Returns:
            BaseData: The loaded data.
        """
        with pd.HDFStore(path, "r") as store:
            data = store.get("data")
            metadata = store.get_storer("data").attrs.metadata
            sfreq = metadata.pop("sfreq", None)
            return cls(data, sfreq=sfreq, **metadata)

    def is_varv(self):
        return self.bfreq is not None

    def as_dataframe(self):
        return pd.DataFrame(self)
