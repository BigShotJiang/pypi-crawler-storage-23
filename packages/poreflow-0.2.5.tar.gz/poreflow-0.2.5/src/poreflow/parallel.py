import collections
import multiprocessing
import os
import threading
import time

from multiprocessing.pool import Pool
from multiprocessing import Manager


import numpy as np
import psutil

from tqdm.auto import tqdm


def imap_worker_wrapper(args):
    """Generic wrapper to unpack arguments for any function in imap"""
    func, func_args, kwargs = args
    return func(*func_args, **kwargs)


def monitor_progress_and_memory(pool: Pool, pbar, stop_event, update_interval=10):
    """Monitor and update progress bar at fixed time intervals"""
    processes = pool._processes
    cpu_count = multiprocessing.cpu_count()
    while not stop_event.is_set():
        try:
            # Calculate memory usage
            total_memory = psutil.Process().memory_info().rss / 1024 / 1024
            for proc in pool._pool:
                if proc.is_alive():
                    try:
                        total_memory += (
                            psutil.Process(proc.pid).memory_info().rss / 1024 / 1024
                        )
                    except psutil.NoSuchProcess:
                        pass

            # Update progress bar description with current stats
            pbar.set_description(
                f"{processes}/{cpu_count} Processes | RAM: {total_memory:.1f} MB | Time: {time.strftime('%H:%M:%S')}"
            )

            # Force refresh the display
            pbar.refresh()

            # Wait for the specified interval
            time.sleep(update_interval)
        except Exception as e:
            print(f"Monitor error: {e}")
            break


class MemoryMonitor:
    def __init__(self, n_tasks: int, pool, update_interval=10):
        self.n_tasks = n_tasks
        self.pool = pool
        self.update_interval = update_interval
        self.stop_event = threading.Event()

        self.pbar = None
        self.thread = None

    def __enter__(self):
        # Create progress bar (tqdm.auto works better in Jupyter)
        self.pbar = tqdm(
            total=self.n_tasks,
            desc="Starting...",
            ncols=None,  # Auto-adjust width in Jupyter
            leave=True,  # Keep progress bar after completion
        )

        # Start monitoring thread with 10-second updates
        self.thread = threading.Thread(
            target=monitor_progress_and_memory,
            args=(self.pool, self.pbar, self.stop_event, 10),  # Update every 10 seconds
            daemon=True,
        )
        self.thread.start()

        return self.pbar

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_event.set()
        self.thread.join(timeout=1)

        # Final update
        memory = psutil.Process().memory_info().rss / 1024 / 1024
        for proc in self.pool._pool:
            if proc.is_alive():
                try:
                    memory += psutil.Process(proc.pid).memory_info().rss / 1024 / 1024
                except Exception:
                    pass

        self.pbar.set_description(
            f"Completed: {self.pbar.n} / {self.n_tasks} tasks | Final RAM: {memory:.1f} MB"
        )
        self.pbar.close()


class MonitoredPool(Pool):
    def __init__(self, n_tasks, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.n_tasks = n_tasks
        self.pbar = None
        self._monitor = None

    def __enter__(self):
        super().__enter__()
        self._monitor = MemoryMonitor(self.n_tasks, self)
        self.pbar = self._monitor.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._monitor:
            self._monitor.__exit__(exc_type, exc_val, exc_tb)
        super().__exit__(exc_type, exc_val, exc_tb)


def mapper(
    worker_func: collections.abc.Callable,
    fname: os.PathLike | str,
    mappable: list | np.ndarray,
    callback: collections.abc.Callable = None,
    processes: int = None,
    verbose: int = 0,
    kwargs: dict = None,
):
    if kwargs is None:
        kwargs = {}

    with Manager() as manager:
        lock = manager.Lock()

        args = [
            (
                worker_func,
                (fname, item),
                dict(lock=lock, **kwargs),
            )
            for item in mappable
        ]

        results = []

        pool_type = (
            MonitoredPool(len(args), processes)
            if verbose > 1
            else Pool(processes=processes)
        )

        with pool_type as pool:
            if verbose > 0:
                print(f"Starting {pool._processes} workers for {len(mappable)} items")

            for result in pool.imap(imap_worker_wrapper, args, chunksize=1):
                if callback:
                    try:
                        callback(result, lock=lock)
                    except TypeError:
                        callback(result)

                results.append(result)

                if verbose > 1:
                    if hasattr(pool, "pbar"):
                        pool.pbar.update(1)
    return results
