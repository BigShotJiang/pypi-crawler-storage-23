# Created by Cees Dekker Lab at the Delft University of Technology
# Refactored by Thijn Hoekstra
import json
import os
import pathlib
import re
import typing
import warnings

import fast5_research
import numpy as np

import poreflow as pf
import poreflow.structures.raw
from poreflow.utils import decimate
from poreflow.io.ont import (
    META_GROUP_NAME,
    META_SFREQ_ATTR_NAME,
    META_DURATION_ATTR_NAME,
)


def load(
    filename: os.PathLike,
    downsample_to_freq: typing.Optional[float] = 5000,
    verbose: bool = False,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Loads data from nanopore LabView .dat files

    Loads _events from the nanopore setup that were saved as a `.dat` file.
    Expects a file that starts with an utf-8 encoded text header with
    measurements parameters (e.g., sample rate). This _events is then followed by
    binary _events of the samples.

    After reading the data, it is downsampled by default. This behaviour can
    be turned off.

    Args:
        filename (str): Path to the `.dat` file
        downsample_to_freq (:obj:`float`, optional): Rate to downsample the
            data to. Defaults to 5000 Hz. Set to None for no downsampling.

    Returns:
        v_data (np.ndarray): An array containing the voltage data in mV.
        i_data (np.ndarray): An array containing the current data in pA.
        sfreq (float): (Downsampled) sample rate in Hz
        bdc (float): Bias voltage DC value
    """
    _, ext = os.path.splitext(filename)
    if ext.lower() != ".dat":
        warnings.warn(
            f"File has extension {ext}, expecting .dat. Are you using the correct file?"
        )

    raw_i, raw_v, meta = read_digital(filename, verbose)

    if verbose:
        print("Calibrating...")

    i_data, v_data = calibrate(raw_i, raw_v, meta)

    if downsample_to_freq:
        if verbose:
            print("Downsampling... ")

        i_data, v_data = decimate(i_data, v_data, meta["sfreq"], downsample_to_freq)
        meta["sfreq"] = downsample_to_freq

    if verbose:
        print("Done!")
    return i_data, v_data, meta


def calibrate(raw_i, raw_v, meta):
    c0 = meta["c0"]
    c1 = meta["c1"]
    c2 = meta["c2"]
    alpha = meta["alpha"]
    beta = meta["beta"]

    i_data = (c0 + c1 * raw_i + c2 * raw_i**2) * 1000 / (alpha * beta)
    v_data = (c0 + c1 * raw_v + c2 * raw_v**2) * 1000 / (alpha * beta)

    return i_data, v_data


def read_digital(
    filename: str | os.PathLike, verbose: bool = False
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Returns raw data as integers"""
    with open(filename, "rb") as f:
        header = read_header(f)
        d = metadata_from_header(header)
        d = relabel_metadata(d)

        # Locate start position
        start_pos = f.tell()
        f.seek(0, 2)
        l = (f.tell() - start_pos) // 2
        n_mb = l * 2 / 1048576

        if verbose:
            print(filename)
            print("Reading... ")
            print(f"{n_mb:.3f} MB")
            print(f"Raw at {d.get('sfreq'):,.0f} Hz")

        f.seek(start_pos)
        total_read = 0
        raw_data = np.zeros(l, dtype=np.int16)
        while total_read < l:
            # printstring = f"{total_read / l * 100:.2f}%"
            # print(printstring, end="")
            read_this_time = min(10000000, l - total_read)
            raw_data[total_read : total_read + read_this_time] = np.fromfile(
                f, dtype=np.int16, count=read_this_time
            )
            # print("\b" * (len(printstring) - 1))
            total_read += read_this_time

        raw_v = raw_data[1::2]
        raw_i = raw_data[::2]

    return raw_i, raw_v, d


def read_measurement_dat(
    filename: os.PathLike,
    downsample_to_freq: typing.Optional[float] = 5000,
    bfreq: float = None,
    bamp: float = None,
    verbose: bool = False,
) -> poreflow.structures.raw.RawDataFrame:
    """
    Reads measurement data the UTube setup and creates a raw data object. The function allows for
    optional downsampling of the signal to a specified frequency. It adds bias rate metadata to the raw data if
    parameters `bfreq` and `bamp` are specified.

    Args:
        filename (os.PathLike): Path to the measurement data file to be loaded.
        downsample_to_freq (typing.Optional[float]): Target frequency for optional downsampling. Defaults to 5000 Hz.
        bfreq (typing.Optional[float]): Bias voltage frequency in Hz. Defaults to None, which corresponds to a constant
            voltage measurement.
        bamp (typing.Optional[float]): Bias voltage amplitude in mV. Defaults to None, which corresponds to a constant

    Returns:
        poreflow.base.Raw: A Raw object containing the processed voltage and current data.
    """
    name = pathlib.Path(filename).stem
    v_data, i_data, meta = load(filename, downsample_to_freq, verbose=verbose)

    return poreflow.structures.raw.RawDataFrame(
        {
            "i": i_data,
            "v": v_data,
        },
        sfreq=meta["sfreq"],
        name=name,
        bdc=meta["bdc"],
        bamp=bamp,
        bfreq=bfreq,
    )


def read_header(f: typing.BinaryIO) -> str:
    """Reads header.

    Reads header of the `.dat` file. Expects the last entry in the header to
    be "filenum=0;"

    Args:
        f: A file to read from.

    Returns:
        A string containing the header.

    """
    s = ""
    while True:
        try:
            line = f.readline().decode("utf-8").strip()
            s += line
            if line.startswith("filenum"):
                break
        except UnicodeDecodeError:
            break

    return s


def metadata_from_header(s: str) -> dict:
    """Converts header to a dictionary.

    Converts a header with _events stored as lines "param_name=param_value;" into
    a dictionary with param_name as keys and param_value as values.

    Args:
        s (str): A string containing the header text.

    Returns:
        A dictionary of the values in the header text.

    """

    s = re.sub(r"([A-z]\w+)", r'"\1"', s)
    s = re.sub("=", ": ", s)
    s = re.sub(";", ", ", s)
    s = s.replace("\n", "")
    s = s.rstrip(", ")
    s = "{" + s + "}"

    return json.loads(s)


def relabel_metadata(d: dict) -> dict:
    d["alpha"] = d.pop("ALPHA")
    d["beta"] = d.pop("BETA")
    d["station"] = d.pop("STATION")
    d["bdc"] = d.pop("voltage")
    d["c0"] = d.pop("Coeff0")
    d["c1"] = d.pop("Coeff1")
    d["c2"] = d.pop("Coeff2")
    d["c3"] = d.pop("Coeff3")
    d["sfreq"] = d.pop("fSamp")
    d["f_3dB"] = d.pop("f3dB")
    d["filenum"] = d.pop("filenum")

    return d


def convert_to_fast5(
    filename: str | os.PathLike, out: str | os.PathLike = None, verbose: bool = False
):
    filename = pathlib.Path(filename)
    if out is None:
        out = filename.with_suffix(".fast5")

    raw_i, raw_v, meta = read_digital(filename, verbose)

    if meta["c2"] != 0 or meta["c3"] != 0:
        # Todo-calibration can be done non-analytically
        raise ValueError(
            f"Second-order calibration coefficient is non-zero. Cannot "
            f"convert to ONT digitization metadata. Coefficients: "
            f"c2={meta['c2']} and c3={meta['c3']}."
        )

    meta_ont = calculate_ont_digitization(meta)

    context_tags = {
        "department": "research",
        "experiment_type": "inhouse_sequencing",
        "filename": filename.stem,
        "sample_frequency": meta["sfreq"],
    }

    tracking_id = {"device_id": pf.UTUBE}

    empty_event = np.array(
        [(0, 1, 1.0, 1.0)],
        dtype=[
            ("start", "<u4"),
            ("length", "<u4"),
            ("mean", "<f4"),
            ("stdv", "<f4"),
        ],
    )

    channel = 1
    with fast5_research.BulkFast5.New(
        out, tracking_id=tracking_id, context_tags=context_tags
    ) as f:
        # Only one channel.
        # Need an event to instantiate a valid fast5 file
        # Both current and voltage are still integers, conversion
        # passed via set events
        f.set_events(empty_event, meta_ont, channel)
        f.set_raw(raw_i, channel, meta_ont)
        # Voltage has same conversion as current
        f.set_voltage(raw_v, meta_ont)

        # Add Meta group
        g = f.create_group(META_GROUP_NAME)
        g.attrs[META_DURATION_ATTR_NAME] = len(raw_i)
        g.attrs[META_SFREQ_ATTR_NAME] = meta["sfreq"]


def calculate_ont_digitization(meta: dict, description="Grouper"):
    return {
        "description": description,
        "offset": meta["c0"] / meta["c1"],
        "range": 1000 * meta["c1"],
        "digitisation": meta["alpha"] * meta["beta"],
        "sample_rate": meta["sfreq"],
    }
