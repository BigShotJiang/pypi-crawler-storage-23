#
#  Copyright (C) 2024 Thijn Hoekstra
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
import pathlib
import typing
import warnings
import functools

import numpy as np
import pandas as pd
import scipy.signal
from fast5_research.fast5_bulk import BulkFast5

import poreflow as pf
from poreflow.events import detection
from poreflow.steps import changepoint
from poreflow.parallel import mapper

META_DURATION_ATTR_NAME = "duration_samples"
META_SFREQ_ATTR_NAME = "sample_rate"
META_GROUP_NAME = "Meta"


def _validate_file(filename, verbose, force_conversion: bool = False):
    """
    Validates the file path and converts .dat to .fast5 if necessary.
    """

    p = pathlib.Path(filename)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {filename}")

    if p.suffix == ".fast5":
        return filename
    elif p.suffix == ".dat":
        from poreflow.io import labview

        fast5_path = p.with_suffix(".fast5")
        if not force_conversion and fast5_path.exists():
            return fast5_path
        else:
            warning_message = (
                f"Converting {filename} to {fast5_path}. This may take a moment..."
            )
            if verbose == 2:
                warnings.warn(warning_message)
            elif verbose == 1:
                print(warning_message)

            labview.convert_to_fast5(filename, fast5_path)
            return fast5_path
    else:
        raise ValueError("File must be a .fast5 or .dat file")


def _remove_index(df):
    if "index" in df.columns:
        df = df.set_index("index")
        df.index.name = None
    return df


class File(BulkFast5):
    """
    An extended interface for easy data handling of bulk fast5 files.

    This class extends `fast5_research.bulk_fast5.BulkFast5` to provide
    more convenient methods for data retrieval and interaction, returning
    data as `poreflow` objects.

    Attributes:
        tracking_meta (dict): Tracking metadata from the file.
        context_meta (dict): Context metadata from the file.
    """

    def __init__(self, filename, mode="r", verbose=2, force_conversion=False):
        """
        Initializes the File object.

        Args:
            filename (str or pathlib.Path): Path to the .fast5 or .dat file.
            mode (str): The mode to open the file in. Defaults to 'r'.
            verbose (int): Controls warning messages for file conversion.
                           2 (default): Use warnings.warn.
                           1: Use print().
                           0: Suppress messages.
            force_conversion (bool): Force re-conversion of .dat file to .fast5
        """
        filename = _validate_file(filename, verbose, force_conversion)
        super().__init__(str(filename), mode)

        if mode != "r" and pf.POREFLOW_GROUP not in self:
            import platform

            g = self.create_group(pf.POREFLOW_GROUP)
            g_meta = g.create_group(META_GROUP_NAME)
            g_meta.attrs["poreflow_version"] = pf.__version__
            g_meta.attrs["python_version"] = platform.python_version()

        self._name = None

    @property
    def poreflow_group(self):
        return self[pf.POREFLOW_GROUP]

    @property
    def has_poreflow_data(self):
        return pf.POREFLOW_GROUP in self

    @property
    def name(self) -> str:
        """Pretty name, defaults to filename."""
        return (
            self._name if self._name is not None else pathlib.Path(self.filename).stem
        )

    @name.setter
    def name(self, value: str):
        """Set a pretty name"""
        self._name = value

    @property
    def device(self):
        if self.tracking_meta["device_id"] == pf.UTUBE:
            return pf.UTUBE
        else:
            return pf.ONT

    @property
    def n_events(self) -> int:
        return len(self.poreflow_group[pf.EVENTS_DATASET])

    @property
    def n_steps(self) -> int:
        return len(self.poreflow_group[pf.STEPS_DATASET])

    def get_channels(self):
        """Tries getting channels even when in write mode.

        Returns:
            list: List of channel numbers in file. Starts from 0.

        Note:
            ONT stores channels in Fast5 files starting from 1. Channels
            in poreFlow are indexed from 0. So 0 --> Channel 1, etc.
        """
        data = self[self.__intermediate_data__]
        return sorted([int(name.strip("Channel_")) - 1 for name in data.keys()])

    def _get_channel_data(
        self,
        channel: int = 0,
        times: typing.Optional[typing.Tuple[float, float]] = None,
        index: typing.Optional[typing.Tuple[int, int]] = None,
        downsample: typing.Optional[float] = None,
        read_voltage: bool = True,
        verbose: bool = False,
    ) -> tuple:
        """
        Private helper to retrieve, slice, and downsample channel data.

        Args:
            channel (int): The channel number to retrieve data from.
            times (tuple[float, float], optional): A tuple of (start_time, end_time)
                in seconds to slice the data.
            index (tuple[int, int], optional): A tuple of (start_index, end_index)
                to slice the data.
            downsample (float, optional): The new sampling frequency to downsample to.
            read_voltage (bool, optional): Whether to read the voltage channel data.

        Returns:
            A tuple containing:
                - np.ndarray: The current data.
                - np.ndarray: The voltage data (if read_voltage is True).
                - float: The (downsampled) sample rate
        """
        if times and index:
            raise ValueError("Provide either 'times' or 'index', not both.")

        raw_indices = (None, None)
        if times:
            raw_indices = self._time_interval_to_index(channel, times)
        elif index:
            raw_indices = index

        # ONT stores channels starting from 1
        out = [super().get_raw(channel + 1, times, raw_indices)]

        if read_voltage:
            out.append(super().get_voltage(times, raw_indices))

        sfreq = self.sfreq
        if downsample:
            if downsample >= sfreq:
                if verbose:
                    warnings.warn(
                        f"Downsample frequency ({downsample} Hz) is greater than or "
                        f"equal to the original sampling frequency ({sfreq} Hz). "
                        "No downsampling will be performed."
                    )
            else:
                q = int(sfreq / downsample)
                if q > 1:
                    for j, arr in enumerate(out):
                        out[j] = scipy.signal.decimate(arr, q)

                    sfreq = sfreq / q

        out.append(sfreq)

        return tuple(out)

    def get_data(
        self,
        channel: int = 0,
        times: typing.Optional[typing.Tuple[float, float]] = None,
        index: typing.Optional[typing.Tuple[int, int]] = None,
        downsample: typing.Optional[float] = None,
    ) -> pd.DataFrame:
        """
        Get data from a channel as a poreflow.BaseData object.

        This method retrieves the raw current data from a specified channel,
        allows for slicing and downsampling, and returns it packaged as a
        BaseData object.

        Args:
            channel (int): The channel number to retrieve data from. Defaults to 1.
            times (tuple[float, float], optional): A tuple of (start_time, end_time)
                in seconds to slice the data. Defaults to None (all data).
            index (tuple[int, int], optional): A tuple of (start_index, end_index)
                to slice the data. Defaults to None (all data).
            downsample (float, optional): The new sampling frequency to downsample
                to. If None, no downsampling is performed. Defaults to None.

        Returns:
            poreflow.base.BaseData: An object containing the current data and metadata.
        """
        current_data, sfreq = self._get_channel_data(
            channel, times, index, downsample, read_voltage=False
        )

        return pf.BaseDataFrame(
            {pf.CURRENT_FIELD_NAME: current_data},
            sfreq=sfreq,
            channel=channel,
            name=self.name,
        )

    def get_raw(
        self,
        channel: int = 0,
        times: tuple[float, float] = None,
        index: tuple[int, int] = None,
        downsample: float = None,
    ) -> pf.RawDataFrame:
        """
        Get data from a channel as a poreflow.Raw object.

        This method retrieves the raw current and voltage data from a specified
        channel, allows for slicing and downsampling, and returns it packaged
        as a Raw object.

        Args:
            channel (int): The channel number to retrieve data from. Defaults to 1.
            times (tuple[float, float], optional): A tuple of (start_time, end_time)
                in seconds to slice the data. Defaults to None (all data).
            index (tuple[int, int], optional): A tuple of (start_index, end_index)
                to slice the data. Defaults to None (all data).
            downsample (float, optional): The new sampling frequency to downsample
                to. If None, no downsampling is performed. Defaults to None.

        Returns:
            poreflow.base.Raw: An object containing the current and voltage
            data and metadata.
        """
        current_data, voltage_data, sfreq = self._get_channel_data(
            channel, times, index, downsample
        )

        return pf.RawDataFrame(
            {pf.CURRENT_FIELD_NAME: current_data, pf.VOLTAGE_FIELD_NAME: voltage_data},
            sfreq=sfreq,
            channel=channel,
            name=f"Channel {channel} of {self.name}",
            ios=self.get_ios(channel),
        )

    def get_event(
        self, item: int, downsample: typing.Optional[float] = None
    ) -> pf.EventDataFrame:

        dset = self.poreflow_group[pf.EVENTS_DATASET]
        row = dset[item]

        start = row[pf.START_IDX_COL]
        end = row[pf.END_IDX_COL]
        channel = row[pf.CHANNEL_COL]

        current_data, sfreq = self._get_channel_data(
            channel, index=(start, end), downsample=downsample, read_voltage=False
        )

        return pf.EventDataFrame(
            {pf.CURRENT_FIELD_NAME: current_data},
            sfreq=sfreq,
            channel=channel,
            start_idx=int(
                start * sfreq / self.sfreq
            ),  # Scale start_idx if downsample was used
            ios=row[pf.IOS_COL],
            name=f"Event {item} in channel {channel} of {self.name}",
            quality=row[pf.QUALITY_COL],
            label=row[pf.LABEL_COL],
        )

    def get_event_current(
        self,
        df_events: pd.DataFrame,
        idx: int,
    ) -> np.ndarray:
        """Method for quickly getting just the event current
        as an array"""

        start = df_events.loc[idx, pf.START_IDX_COL]
        end = df_events.loc[idx, pf.END_IDX_COL]
        channel = df_events.loc[idx, pf.CHANNEL_COL]
        current_data, _ = self._get_channel_data(
            channel, index=(start, end), downsample=False, read_voltage=False
        )
        return current_data

    @property
    def tracking_meta(self) -> dict:
        """Get tracking meta data."""
        return self.get_tracking_meta()

    @property
    def context_meta(self) -> dict:
        """Get context meta."""
        return self.get_context_meta()

    @property
    def sfreq(self) -> float:
        if hasattr(self, "sample_rate"):
            return self.sample_rate
        else:  # In write mode, the sample rate is not read out at first
            try:
                return float(self[META_GROUP_NAME].attrs[META_SFREQ_ATTR_NAME])
            except Exception:
                return float(self.get_metadata(self.channels[0])[META_SFREQ_ATTR_NAME])

    def __len__(self) -> int:
        """Returns length as number of samples"""
        return int(self[META_GROUP_NAME].attrs[META_DURATION_ATTR_NAME])

    def _dataset_setter(self, df: pd.DataFrame | None, dataset: str, mode):
        if df is None:
            if dataset in self.poreflow_group:
                del self.poreflow_group[dataset]
            return None

        if df is None and mode != "w":
            raise ValueError(
                "Cannot delete events in append (a) mode, set to write (w)."
            )
        # Convert to records
        rec = df.to_records(index=True)
        if mode not in ("w", "a"):
            raise ValueError(f"Mode {mode} not recognized. Use 'w' or 'a'.")
        if (mode == "a") and (dataset in self.poreflow_group):
            dset = self.poreflow_group[dataset]

            n = dset.shape[0]
            rec["index"] += n  # Update index of inserted table

            dset.resize((n + rec.shape[0],))
            dset[-rec.shape[0] :] = rec
            return None

        elif (mode == "w") and (dataset in self.poreflow_group):
            del self.poreflow_group[dataset]  # Overwrite later

        self.poreflow_group.create_dataset(
            dataset, data=rec, maxshape=(None,), chunks=True
        )

    def _dataset_getter(self, dataset):
        if dataset not in self.poreflow_group:
            raise KeyError(
                f"{pf.POREFLOW_GROUP}/{dataset} not found in {self.filename}"
            )
        dset = self.poreflow_group[dataset]
        data = dset[:]

        return pd.DataFrame.from_records(data)

    @property
    def has_events(self) -> bool:
        return pf.EVENTS_DATASET in self.poreflow_group

    @property
    def events(self) -> pf.EventsDataFrame:
        return self.get_events()

    @property
    def steps(self) -> pf.StepsDataFrame:
        return self.get_steps()

    @events.setter
    def events(self, events: pf.EventsDataFrame):
        self.set_events(events)

    @steps.setter
    def steps(self, steps: pf.StepsDataFrame):
        self.set_steps(steps)

    def set_events(self, df_events: pf.EventsDataFrame | None, mode: str = "w") -> None:
        """
        Saves the EventsDataFrame to the file in a group 'PoreFlowData' and dataset 'Events'.
        """

        self._dataset_setter(df_events, pf.EVENTS_DATASET, mode)

    def get_events(self, channel: int = None) -> pf.EventsDataFrame:
        """
        Reads the EventsDataFrame from the 'PoreFlowData/Events' dataset.

        Args:
            channel (int): Channel
        """

        df = self._dataset_getter(pf.EVENTS_DATASET)

        if channel is not None:
            df = df.query(f"channel == {channel}")

        df = _remove_index(df)

        return pf.EventsDataFrame(df, sfreq=self.sfreq)

    @property
    def has_steps(self) -> bool:
        return pf.STEPS_DATASET in self.poreflow_group

    def set_steps(self, df_steps: pf.StepsDataFrame | None, mode: str = "w") -> None:
        self._dataset_setter(df_steps, pf.STEPS_DATASET, mode)

    def get_steps(self, event: int = None) -> pf.StepsDataFrame:
        df = self._dataset_getter(pf.STEPS_DATASET)
        df = _remove_index(df)
        if event is not None:
            if event not in df[pf.EVENT_COL].values:
                raise IndexError(f"Event {event} not found in {self.filename}")
            df = df.query(f"{pf.EVENT_COL}=={event}")
        return pf.StepsDataFrame(df, sfreq=self.sfreq)

    def _create_ios_fit_dataset(self, degree: int):
        g = self.poreflow_group

        if pf.IOS_FIT_DATASET in g:
            del g[pf.IOS_FIT_DATASET]
        columns = [f"c{j}" for j in range(degree + 1)]
        df = pd.DataFrame(0, columns=columns, index=self.get_channels(), dtype=float)
        rec = df.to_records()

        return g.create_dataset(
            pf.IOS_FIT_DATASET,
            rec.shape,
            data=rec,
        )

    def set_ios(self, p: np.polynomial.Polynomial, channel: int = 0):

        if pf.IOS_FIT_DATASET not in self.poreflow_group:
            self._create_ios_fit_dataset(p.degree())

        dset = self.poreflow_group[pf.IOS_FIT_DATASET]

        if p is None:
            n_coef = len(dset[0]) - 1
            coef = np.full(n_coef, np.nan)
        else:
            coef = p.coef

        index = np.argmax(dset["index"] == channel)
        dset[index] = [tuple([channel] + coef.tolist())]

    def get_ios_table(self) -> pd.DataFrame:

        dset = self.poreflow_group[pf.IOS_FIT_DATASET]

        df = pd.DataFrame.from_records(dset[:])

        return _remove_index(df)

    def get_ios(self, channel: int = 0) -> np.polynomial.Polynomial | None:

        if not self.has_poreflow_data or (
            pf.IOS_FIT_DATASET not in self.poreflow_group
        ):
            return None

        df = self.get_ios_table()
        coef = df.loc[channel]

        if np.isnan(coef).all() or (coef == 0).all():
            return None

        return np.polynomial.Polynomial(coef)

    def map(
        self,
        worker_func: typing.Callable,
        mappable: list,
        processes: int = None,
        verbose: int = 0,
        callback: typing.Callable = None,
        **kwargs,
    ):
        """
        Run a worker function in parallel over channels.

        Args:
            worker_func: Function to run. Must accept (fname, channel, lock, **kwargs).
            processes: Number of workers.
            verbose: Verbosity level.
            channels: List of channels to process. Defaults to all channels.
            callback: Function to call with each result.
            **kwargs: Keyword arguments to pass to the worker function.

        Returns:
            list: List of results from the worker function.
        """
        fname = self.filename
        mode = self.mode

        self.close()

        results = mapper(
            worker_func, fname, mappable, callback, processes, verbose, kwargs
        )

        # Reset to an open handle
        self.__init__(fname, mode=mode)

        return results

    def find_events(self, processes=None, verbose=0, channels: list = None, **kwargs):
        """
        Find events in the file using parallel processing.

        Args:
            processes: Number of workers.
            verbose: Verbosity level.
            channels: specific channels to search.
            **kwargs: Additional arguments for event detection.

        Note:
            Closes file, does processing, and then opens it again by calling
            __init__.
        """

        if self.mode != "r+":
            raise IOError("Must set mode to read and write (r+)")

        self.set_events(None)
        degree = kwargs.get("degree", detection.DEFAULT_DEGREE)
        self._create_ios_fit_dataset(degree)

        if channels is None:
            channels = self.get_channels()

        results = self.map(
            detection.event_detection_worker,
            channels,
            processes=processes,
            verbose=verbose,
            callback=functools.partial(
                detection.save_events_to_file,
                fname=self.filename,
                verbose=verbose,
            ),
            **kwargs,
        )

        if verbose > 0:
            detection.summarize_events(results)

    def iter_events(self, **kwargs):
        for j in range(self.n_events):
            yield self.get_event(j, **kwargs)

    def find_steps(self, processes=None, verbose=0, events: list = None, **kwargs):

        if self.mode != "r+":
            raise IOError("Must set mode to read and write (r+)")

        self.set_steps(None)

        if events is None:
            events = range(len(self.get_events()))

        results = self.map(
            changepoint.step_finding_worker,
            events,
            processes=processes,
            verbose=verbose,
            callback=functools.partial(
                changepoint.save_steps_to_file,
                fname=self.filename,
            ),
            **kwargs,
        )

        if verbose > 0:
            changepoint.summarize_steps(results)

    def filter_events(self, mask: pd.Series) -> None:
        """Remove events using a mask

        Also removes steps if present

        Will reset the index of the events and steps

        Args:
            mask:

        Returns:

        """

        events_filtered = self.events[mask]

        if self.has_steps:
            steps_filtered = self.steps[
                self.steps[pf.EVENT_COL].isin(events_filtered.index)
            ]

            # Replace event index in steps table
            to_replace = events_filtered.index
            values = np.arange(len(events_filtered), dtype=int)

            steps_filtered.loc[:, pf.EVENT_COL] = steps_filtered[pf.EVENT_COL].replace(
                to_replace, values
            )
            steps_filtered = steps_filtered.reset_index(drop=True)

            self.steps = steps_filtered

        # Reset index of events
        events_filtered = events_filtered.reset_index(drop=True)

        self.events = events_filtered
