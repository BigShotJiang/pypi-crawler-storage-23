import importlib as _importlib

submodules = [
    "changepoint",
    "cpic",
    "metrics",
    "predict",
    "sequence",
]

__all__ = submodules


def __getattr__(name):
    if name in submodules:
        return _importlib.import_module(f"poreflow.steps.{name}")
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(f"Module 'poreflow.steps' has no attribute '{name}'")
