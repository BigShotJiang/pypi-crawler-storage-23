function ld = logdet(A)
%computes the log determinant of a symmetric, positive definite matrix A
if any(isnan(A(:)))
    ld = nan;
    return
end

if ~issymmetric(A)
    error('A is not symmetric');
end

[R,p] = chol(A);

if p
    error('A is not positive definite');
end

ld = 2*sum(log(diag(R)));

end