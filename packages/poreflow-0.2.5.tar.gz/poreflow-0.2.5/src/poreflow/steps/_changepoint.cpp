#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <Eigen/Dense>
#include <vector>
#include <cmath>
#include <iostream>
#include <algorithm>

// Constants for CPIC
namespace cpic_constants {
    // > 1000
    const double a_gt = 2.456;
    const double b_gt = 1.187;
    const double c_gt = 2.73;

    // < 1000
    const double a_lt = 1.239;
    const double b_lt = 0.9872;
    const double c_lt = 1.999;
    const double p3_lt = 5.913e-10;
    const double p4_lt = -1.876e-06;
    const double p5_lt = 0.004354;
    const double ph_lt = -0.1906;
}

double get_cpic_penalty(double N_T) {
    if (N_T > 1000) {
        if (N_T >= 1e6) {
            N_T = 1e6;
        }
        return cpic_constants::a_gt * std::log(std::log(N_T)) + 
               cpic_constants::b_gt * std::log(std::log(std::log(N_T))) + 
               cpic_constants::c_gt;
    } else {
        return cpic_constants::a_lt * std::log(std::log(N_T)) +
               cpic_constants::b_lt * std::log(N_T) +
               cpic_constants::p3_lt * std::pow(N_T, 3) +
               cpic_constants::p4_lt * std::pow(N_T, 2) +
               cpic_constants::p5_lt * N_T +
               cpic_constants::ph_lt * std::pow(std::abs(N_T), 0.5) +
               cpic_constants::c_lt;
    }
}

// Data structures to hold cumulative sums
struct CumulativeData {
    // BB: n_bf x n_bf matrix for each time point
    std::vector<Eigen::MatrixXd> BB;
    // XB: n_bf vector for each time point
    std::vector<Eigen::VectorXd> XB;
    // xsq: scalar for each time point
    std::vector<double> xsq;
    
    int n_bf;
    int n_points;

    CumulativeData(int n_basis, int n) : n_bf(n_basis), n_points(n) {
        BB.resize(n + 1, Eigen::MatrixXd::Zero(n_bf, n_bf));
        XB.resize(n + 1, Eigen::VectorXd::Zero(n_bf));
        xsq.resize(n + 1, 0.0);
    }
};

// Main class logic
class BasisFunctionStepFinder {
public:
    Eigen::MatrixXd bf;
    double cpic_multiplier;
    int n_basis_functions;
    int period;
    
    CumulativeData* cum_data = nullptr;

    BasisFunctionStepFinder(Eigen::MatrixXd bf_, double cpic_mult) 
        : bf(bf_), cpic_multiplier(cpic_mult) {
        n_basis_functions = bf.rows();
        period = bf.cols();
    }

    ~BasisFunctionStepFinder() {
        if (cum_data) delete cum_data;
    }

    void compute_cumulative_sums(const Eigen::VectorXd& x, const Eigen::MatrixXd& bf_tiled) {
        int n = x.size();
        if (cum_data) delete cum_data;
        cum_data = new CumulativeData(n_basis_functions, n);

        Eigen::MatrixXd curr_BB = Eigen::MatrixXd::Zero(n_basis_functions, n_basis_functions);
        Eigen::VectorXd curr_XB = Eigen::VectorXd::Zero(n_basis_functions);
        double curr_xsq = 0.0;

        cum_data->BB[0] = curr_BB;
        cum_data->XB[0] = curr_XB;
        cum_data->xsq[0] = curr_xsq;

        for (int i = 0; i < n; ++i) {
            double xi = x[i];
            Eigen::VectorXd bi = bf_tiled.col(i); // Assuming bf_tiled is n_bf x N

            // Update X cumulate
            curr_xsq += xi * xi;

            // Update X * B cumulate
            curr_XB += xi * bi;

            // Update B * B cumulate
            curr_BB.noalias() += bi * bi.transpose();

            cum_data->BB[i+1] = curr_BB;
            cum_data->XB[i+1] = curr_XB;
            cum_data->xsq[i+1] = curr_xsq;
        }
    }

    double get_var(int left, int right, int n) {
        // Get the variance in some interval
        
        double xsq_sum = cum_data->xsq[right] - cum_data->xsq[left];
        Eigen::VectorXd XB_sum = cum_data->XB[right] - cum_data->XB[left];
        Eigen::MatrixXd BB_sum = cum_data->BB[right] - cum_data->BB[left];

        // Solve BB * beta = XB
        // BB is SPD.
        Eigen::LLT<Eigen::MatrixXd> llt(BB_sum);
        Eigen::VectorXd beta;
        if (llt.info() != Eigen::Success) {
            Eigen::LDLT<Eigen::MatrixXd> ldlt(BB_sum);
            beta = ldlt.solve(XB_sum);
        } else {
            beta = llt.solve(XB_sum);
        }
        double term = XB_sum.dot(beta);
        double var = (xsq_sum - term) / n;
        return var;
    }
    
    // Calculate CPIC score
    double calculate_score(double var_l, double var_r, double var_t, int n_l, int n_r, int n_t, double p_cpic) {
         if (var_l <= 0) var_l = 1e-15;
         if (var_r <= 0) var_r = 1e-15;
         if (var_t <= 0) var_t = 1e-15;
         
         double score = 0.5 * (n_l * std::log(var_l) + n_r * std::log(var_r) - n_t * std::log(var_t))
                        + n_basis_functions + cpic_multiplier * p_cpic;
         return score;
    }

    std::vector<int> find_transitions_local(int left, int right) {
        std::vector<int> transitions;
        int n_t = right - left;

        // Stop if range is smaller than min step size
        if (n_t < 2 * period) {
             return transitions;
        }
        
        // Get variance for the whole region
        double var_t = get_var(left, right, n_t);
        double p_cpic = get_cpic_penalty(n_t);
        
        double min_score = 1e30; // Infinity
        int best_split_idx = -1;

        int start_nl = period;
        int end_nl = n_t - period; 

        // Coarse search
        int best_coarse_nl = -1;
        for (int nl = start_nl; nl <= end_nl; nl += period) {
             int split = left + nl;
             int nr = n_t - nl;
             
             double var_l = get_var(left, split, nl);
             double var_r = get_var(split, right, nr);
             
             double score = calculate_score(var_l, var_r, var_t, nl, nr, n_t, p_cpic);
             if (score < min_score) {
                 min_score = score;
                 best_coarse_nl = nl;
             }
        }

        if (best_coarse_nl == -1) return transitions; // Early exit. Should not happen

        // Refine search around best point in coarse search
        int refine_start = std::max(start_nl, best_coarse_nl - period);
        int refine_end = std::min(end_nl, best_coarse_nl + period);

        min_score = 1e30;
        int best_nl = -1;
        
        for (int nl = refine_start; nl <= refine_end; ++nl) {
             int split = left + nl;
             int nr = n_t - nl;
             
             double var_l = get_var(left, split, nl);
             double var_r = get_var(split, right, nr);
             
             double score = calculate_score(var_l, var_r, var_t, nl, nr, n_t, p_cpic);
             if (score < min_score) {
                 min_score = score;
                 best_nl = nl;
             }
        }

        if (min_score < 0) {
             // Add a transition if found a point with a good score
             int split_idx = left + best_nl;
             
             std::vector<int> left_trans = find_transitions_local(left, split_idx);
             std::vector<int> right_trans = find_transitions_local(split_idx, right);
             
             transitions.insert(transitions.end(), left_trans.begin(), left_trans.end());
             transitions.push_back(split_idx);
             transitions.insert(transitions.end(), right_trans.begin(), right_trans.end());
        }
        return transitions;
    }
};

// Python Wrapper

typedef struct {
    PyObject_HEAD
    BasisFunctionStepFinder* finder;
} PyBasisFunctionStepFinder;

static void PyBasisFunctionStepFinder_dealloc(PyBasisFunctionStepFinder* self) {
    if (self->finder) delete self->finder;
    Py_TYPE(self)->tp_free((PyObject*)self);
}

static int PyBasisFunctionStepFinder_init(PyBasisFunctionStepFinder* self, PyObject* args, PyObject* kwds) {
    PyObject* bf_obj;
    double cpic_multiplier = 4.0;
    static char* kwlist[] = {(char*)"bf", (char*)"cpic_multiplier", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "O|d", kwlist, &bf_obj, &cpic_multiplier)) {
        return -1;
    }

    PyArrayObject* bf_arr = (PyArrayObject*)PyArray_FromAny(bf_obj, PyArray_DescrFromType(NPY_DOUBLE), 2, 2, NPY_ARRAY_C_CONTIGUOUS | NPY_ARRAY_FORCECAST, NULL);
    if (!bf_arr) return -1;

    int rows = PyArray_DIM(bf_arr, 0);
    int cols = PyArray_DIM(bf_arr, 1);

    // Copy data to Eigen Matrix
    Eigen::MatrixXd bf(rows, cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            bf(i, j) = *(double*)PyArray_GETPTR2(bf_arr, i, j);
        }
    }

    Py_DECREF(bf_arr);

    self->finder = new BasisFunctionStepFinder(bf, cpic_multiplier);
    return 0;
}

static PyObject* PyBasisFunctionStepFinder_fit(PyBasisFunctionStepFinder* self, PyObject* args) {
    PyObject* data_obj;
    if (!PyArg_ParseTuple(args, "O", &data_obj)) return NULL;

    PyArrayObject* data_arr = (PyArrayObject*)PyArray_FromAny(data_obj, PyArray_DescrFromType(NPY_DOUBLE), 1, 1, NPY_ARRAY_C_CONTIGUOUS | NPY_ARRAY_FORCECAST, NULL);
    if (!data_arr) return NULL;

    int n = PyArray_DIM(data_arr, 0);
    double* data_ptr = (double*)PyArray_DATA(data_arr);

    // Copy data to Eigen Vector
    Eigen::VectorXd x(n);
    for (int i = 0; i < n; ++i) x[i] = data_ptr[i];

    // Tile Basis function horizontally to cover length n.
    int period = self->finder->period;
    int n_bf = self->finder->n_basis_functions;
    
    // Calculate required tiles
    int reps = (n / n_bf) + 1;

    // Construct tiled BF
    Eigen::MatrixXd bf_tiled(n_bf, reps * period);
    for (int r = 0; r < reps; ++r) {
        bf_tiled.block(0, r * period, n_bf, period) = self->finder->bf;
    }
    
    // Slice to n
    Eigen::MatrixXd bf_final = bf_tiled.block(0, 0, n_bf, n);

    self->finder->compute_cumulative_sums(x, bf_final);
    
    std::vector<int> transitions = self->finder->find_transitions_local(0, n);
    
    // Sort and unique
    std::sort(transitions.begin(), transitions.end());
    auto last = std::unique(transitions.begin(), transitions.end());
    transitions.erase(last, transitions.end());

    npy_intp dims[1] = { (npy_intp)(transitions.size() + 2) };
    PyObject* res_arr = PyArray_SimpleNew(1, dims, NPY_INT32);
    int32_t* res_ptr = (int32_t*)PyArray_DATA((PyArrayObject*)res_arr);
    
    res_ptr[0] = 0;
    for (size_t i = 0; i < transitions.size(); ++i) {
        res_ptr[i+1] = (int32_t)transitions[i];
    }
    res_ptr[transitions.size()+1] = (int32_t)n;

    Py_DECREF(data_arr);
    return res_arr;
}

static PyMethodDef PyBasisFunctionStepFinder_methods[] = {
    {"fit", (PyCFunction)PyBasisFunctionStepFinder_fit, METH_VARARGS, "Fit the model to data."},
    {NULL, NULL, 0, NULL}
};

static PyTypeObject PyBasisFunctionStepFinderType = {
    PyVarObject_HEAD_INIT(NULL, 0)
};

static void _init_type(void) {
    PyBasisFunctionStepFinderType.tp_name = "poreflow.feature_extraction.changepoint.BasisFunctionStepFinder";
    PyBasisFunctionStepFinderType.tp_basicsize = sizeof(PyBasisFunctionStepFinder);
    PyBasisFunctionStepFinderType.tp_itemsize = 0;
    PyBasisFunctionStepFinderType.tp_dealloc = (destructor)PyBasisFunctionStepFinder_dealloc;
    PyBasisFunctionStepFinderType.tp_flags = Py_TPFLAGS_DEFAULT;
    PyBasisFunctionStepFinderType.tp_doc = "BasisFunctionStepFinder object";
    PyBasisFunctionStepFinderType.tp_methods = PyBasisFunctionStepFinder_methods;
    PyBasisFunctionStepFinderType.tp_init = (initproc)PyBasisFunctionStepFinder_init;
    PyBasisFunctionStepFinderType.tp_new = PyType_GenericNew;
}

// Module definition
static PyModuleDef changepointmodule = {
    PyModuleDef_HEAD_INIT,
    "_changepoint",
    "C++ implementation of changepoint detection.",
    -1,
    NULL, NULL, NULL, NULL, NULL
};

PyMODINIT_FUNC PyInit__changepoint(void) {
    PyObject* m;
    _init_type();
    if (PyType_Ready(&PyBasisFunctionStepFinderType) < 0) return NULL;

    m = PyModule_Create(&changepointmodule);
    if (m == NULL) return NULL;

    import_array();

    Py_INCREF(&PyBasisFunctionStepFinderType);
    if (PyModule_AddObject(m, "BasisFunctionStepFinder", (PyObject*)&PyBasisFunctionStepFinderType) < 0) {
        Py_DECREF(&PyBasisFunctionStepFinderType);
        Py_DECREF(m);
        return NULL;
    }

    return m;
}
