import numpy as np


def dynamic_complexity(sequence):
    arr = np.array(sequence)
    # Calculate first-order differences
    differences = np.diff(arr)
    hist, _ = np.histogram(differences, bins="auto")
    probabilities = hist / len(differences)
    # Remove zero probabilities to avoid log(0)
    probabilities = probabilities[probabilities > 0]
    # Calculate entropy of differences
    entropy = -np.sum(probabilities * np.log2(probabilities))
    # Calculate mean absolute change
    means_abs_change = np.mean(np.abs(differences))
    return entropy, means_abs_change


def binned_entropy(values, bin_range=(0, 250), num_bins=50):
    # Convert to numpy array if not already
    values = np.array(values)
    # Create histogram with specified range
    hist, _ = np.histogram(values, bins=num_bins, range=bin_range)
    # Calculate probabilities
    probabilities = hist / len(values)
    # Remove zero probabilities to avoid log(0)
    probabilities = probabilities[probabilities > 0]
    # Calculate entropy
    if len(probabilities) > 0:
        entropy = -np.sum(probabilities * np.log2(probabilities))
    else:
        entropy = 0  # All values are outside the specified range
    return entropy
