import pathlib
from dataclasses import dataclass
from importlib import resources as impresources
import numpy as np
import pandas as pd

from poreflow.steps import assets

MAP_FILE = impresources.files(assets) / "pore_model_6mer_constant_voltage.csv"
TRANSITION_INFO_FILE = impresources.files(assets) / "transition_info_hel308_6mer.npz"


def get_map(fname: pathlib.Path = None) -> pd.DataFrame:
    if fname is None:
        fname = MAP_FILE

    return pd.read_csv(fname)


def get_map_kmers_as_array(df: pd.DataFrame, drop_half_steps=False) -> np.ndarray:
    ids = {"A": 0, "G": 1, "C": 2, "T": 3}

    s = df["name"]

    if drop_half_steps:
        s = s[::2]  # Drop half steps

    x = s.apply(lambda s: [ids[x] for x in s]).to_list()
    return np.array(x, dtype=np.int8)


def get_transition_info(fname: pathlib.Path = None):
    if fname is None:
        fname = TRANSITION_INFO_FILE

    d = np.load(fname, allow_pickle=False)

    return TransitionInfo(d["perms_matrix"], d["p_combos"], d["step_size_matrix"])


def calculate_step_size_matrix(pore_map: pd.DataFrame) -> np.ndarray:

    kmers = get_map_kmers_as_array(pore_map, drop_half_steps=True)

    n_kmers, k = kmers.shape

    dist_matrix = np.full((n_kmers, n_kmers), k, dtype=np.int8)

    for overlap in range(1, k):
        steps = k - overlap

        # Suffixes: Take all rows, last 'overlap' columns
        suffixes = kmers[:, -overlap:]

        # Prefixes: Take all rows, first 'overlap' columns
        prefixes = kmers[:, :overlap]

        # Broadcasting comparison
        match_matrix = suffixes[None, :, :] == prefixes[:, None, :]

        # Check if ALL bases in the overlap match
        valid_transitions = np.all(match_matrix, axis=2)

        dist_matrix[valid_transitions] = steps

    return add_half_steps_to_step_size_matrix(dist_matrix)


@dataclass
class TransitionInfo:
    perms_matrix: np.ndarray
    p_combos: np.ndarray
    step_size_matrix: np.ndarray

    @classmethod
    def from_map(cls, pore_map):
        step_size_matrix = calculate_step_size_matrix(pore_map)
        p_combos = None  # Calculate, or change calculate_step_size_matrix
        perms_matrix = None  # Calculate, or change calculate_step_size_matrix

        return cls(perms_matrix, p_combos, step_size_matrix)


def add_half_steps_to_step_size_matrix(dist_matrix: np.ndarray) -> np.ndarray:

    k_mer_size = np.max(dist_matrix)

    # Double and repeat matrix
    dist_matrix = dist_matrix.repeat(2, 1).repeat(2, 0)
    dist_matrix *= 2

    # Create corrector
    left = np.zeros(len(dist_matrix), dtype=np.int8)
    left[1::2] = 1
    right = left.copy() * -1
    corr = left.reshape(-1, 1) + right
    corr = corr.astype(np.int8)

    # Add correct
    dist_matrix = np.add(dist_matrix, corr, dtype=np.int8)

    # Transtions from pre to post are one step
    mask = np.eye(len(dist_matrix), k=-1, dtype=bool)
    mask[:, 1::2] = False
    dist_matrix[mask] = 1

    # Clip to max size
    dist_matrix = np.clip(dist_matrix, a_min=0, a_max=k_mer_size * 2)
    return dist_matrix


def _logdet(A):
    """
    Computes the log determinant of a symmetric, positive definite matrix A.

    Args:
        A: numpy array of shape (..., d, d) or (..., d) or scalar.

    Returns:
        Log determinant.
    """
    if np.isscalar(A):
        return np.log(A)

    # If A is an array
    A = np.asarray(A)

    # Case d=1 handled as scalar/vector log
    if A.shape[-1] != A.shape[-2]:
        # Assuming shape (..., 1, 1) or flattened
        if A.shape[-1] == 1:
            return np.log(A.squeeze(-1).squeeze(-1))
        # if 1D array, assume diagonals or scalars?
        # The MATLAB code assumes dxd matrices.
        # If passed 1D array of shape (N,), treat as N 1x1 matrices.
        if A.ndim == 1:
            return np.log(A)

    # General Case using Cholesky
    # We want log(det(A)) = 2 * sum(log(diag(L))) where A = L L^T
    try:
        # np.linalg.cholesky supports batches since numpy 1.8
        L = np.linalg.cholesky(A)
        return 2 * np.sum(np.log(np.diagonal(L, axis1=-2, axis2=-1)), axis=-1)
    except np.linalg.LinAlgError:
        return np.nan


def _smatrix_ac_par(x1, K1, x2, K2):
    """
    Calculates score matrix between vector data sets x1 and x2 with
    stiffnesses K1 and K2.

    Args:
        x1: (d, N1)
        K1: (N1, d, d) or (N1,) for d=1
        x2: (d, N2)
        K2: (N2, d, d) or (N2,) for d=1

    Returns:
        s: (N1, N2) score matrix
    """
    if x1.ndim == 1:
        x1 = x1.reshape(1, -1)
    if x2.ndim == 1:
        x2 = x2.reshape(1, -1)

    d = x1.shape[0]
    n1 = x1.shape[1]
    n2 = x2.shape[1]

    # Standardize K shapes to (N, d, d)
    if K1.ndim == 1:
        # Assume d=1
        K1 = K1.reshape(-1, 1, 1)
    if K2.ndim == 1:
        K2 = K2.reshape(-1, 1, 1)

    # Constant factor
    # -0.5 * d * log(2*pi)
    pi_factor = -0.5 * d * np.log(2 * np.pi)

    # Precompute terms for x1
    # K1: (N1, d, d)
    # x1: (d, N1) -> (N1, d, 1)
    x1_t = x1.T[..., np.newaxis]  # (N1, d, 1)

    # K1 * x1 -> (N1, d, 1)
    K1x1 = K1 @ x1_t
    # x1' * K1 * x1 -> (N1, 1, 1) -> (N1,)
    x1K1x1 = (x1_t.transpose(0, 2, 1) @ K1x1).reshape(n1)

    # Precompute terms for x2
    x2_t = x2.T[..., np.newaxis]  # (N2, d, 1)
    K2x2 = K2 @ x2_t
    x2K2x2 = (x2_t.transpose(0, 2, 1) @ K2x2).reshape(n2)

    # Log determinants
    # logdet(K1) -> (N1,)
    ld_K1 = _logdet(K1)
    # logdet(K2) -> (N2,)
    ld_K2 = _logdet(K2)

    # Now we need pairwise combinations.
    # We can use broadcasting.
    # Shape target: (N1, N2)

    # K1 + K2
    # (N1, 1, d, d) + (1, N2, d, d) -> (N1, N2, d, d)
    K1_exp = K1[:, np.newaxis, :, :]
    K2_exp = K2[np.newaxis, :, :, :]
    K1K2 = K1_exp + K2_exp

    # logdet(K1 + K2) -> (N1, N2)
    ld_K1K2 = _logdet(K1K2)

    # K1x1 + K2x2
    # (N1, 1, d, 1) + (1, N2, d, 1) -> (N1, N2, d, 1)
    Kx = K1x1[:, np.newaxis, :, :] + K2x2[np.newaxis, :, :, :]

    # Term: Kx' * inv(K1K2) * Kx
    # (N1, N2, 1, d) @ (N1, N2, d, d) @ (N1, N2, d, 1) -> (N1, N2, 1, 1)

    # Solve linear system K1K2 * y = Kx -> y = inv(K1K2) * Kx
    # np.linalg.solve can handle batches
    try:
        y = np.linalg.solve(K1K2, Kx)
        quad_term = np.matmul(Kx.transpose(0, 1, 3, 2), y).squeeze(-1).squeeze(-1)
    except np.linalg.LinAlgError:
        # Fallback or NaN
        quad_term = np.full((n1, n2), np.nan)

    # Combine
    # s = pi_factor + 0.5 * (ld_K1 + ld_K2 - ld_K1K2 - x1K1x1 - x2K2x2 + quad_term)

    # Broadcast 1D terms
    ld_K1_b = ld_K1[:, np.newaxis]
    ld_K2_b = ld_K2[np.newaxis, :]
    x1K1x1_b = x1K1x1[:, np.newaxis]
    x2K2x2_b = x2K2x2[np.newaxis, :]

    s = pi_factor + 0.5 * (
        ld_K1_b + ld_K2_b - ld_K1K2 - x1K1x1_b - x2K2x2_b + quad_term
    )

    return s


class Sequencer:
    def __init__(self, map_file=None, transition_info_file=None):

        self.map_data = get_map(map_file)
        # Parse map data
        self.map_names = self.map_data["name"].values
        self.map_mean = self.map_data["mean"].values  # (M,)
        self.map_stiffness = self.map_data["stiffness"].values  # (M,)

        # Load transition info
        self.transition_info = get_transition_info(transition_info_file)
        self.perms_matrix = self.transition_info.perms_matrix  # (M, M)
        self.p_combos = self.transition_info.p_combos  # (58, 12)
        self.step_size_matrix = self.transition_info.step_size_matrix  # (M, M)

    def calculateSequenceVV(
        self, x, K, p, p_bad, score_cutoff=-10, verbose=False, **kwargs
    ):
        """
        Calculates the maximum likelihood sequence.

        Args:
            x: (d, n) or (n,) array of feature vectors
            K: (n, d, d) or (n,) array of stiffness matrices
            p: (n, b+1, 3) or (n, b+1, 12) array of step probabilities
            p_bad: (n,) or (n, 1) array of bad level probabilities
            score_cutoff: threshold for pruning
            verbose: print progress
            **kwargs: optional overrides (not fully implemented as in MATLAB varargin)

        Returns:
            sequence: The max likelihood sequence string
        """
        # Ensure input shapes
        x = np.array(x)
        if x.ndim == 1:
            x = x.reshape(1, -1)
        d, n_levels = x.shape

        # Fix p_bad shape
        p_bad = np.array(p_bad).flatten()

        # Default parameters
        p_ind_given_backstep = 0.975
        p_backstep = 0.025

        # Backstep priors (Simplified from MATLAB logic)
        did_backstep = kwargs.get("backsteps", np.zeros(n_levels, dtype=bool))

        p_ind_given_nobackstep = 0.5 - (p_ind_given_backstep * p_backstep)

        # Priors (1, M)
        # M is number of map states (8192)
        M = len(self.map_mean)

        pat_back = np.array([p_ind_given_backstep, 1.0 - p_ind_given_backstep])
        prior_given_backstep = np.tile(pat_back, M // 2)

        pat_noback = np.array([p_ind_given_nobackstep, 1.0 - p_ind_given_nobackstep])
        prior_given_nobackstep = np.tile(pat_noback, M // 2)

        # Prepare p_vals
        max_sequential_bad = p.shape[1] - 1

        if p.shape[2] == 3:
            # v1 conversion logic (implement if needed, but test uses v2)
            raise NotImplementedError(
                "v1 p matrix (shape ending in 3) not implemented yet"
            )
        elif p.shape[2] == 12:
            p_vals = p.copy()
            # Normalize
            total_prob = np.sum(p_vals, axis=2, keepdims=True)
            p_vals = p_vals / total_prob
        else:
            raise ValueError(f"Dimension of P is incorrect: {p.shape}")

        # Apply p_combos
        # (N, B, 12) dot (12, 58) -> (N, B, 58)
        # Transpose p_combos to (12, 58)
        p_combos_t = self.p_combos.T
        p_vals_transformed = np.tensordot(p_vals, p_combos_t, axes=([2], [0]))

        # Log of p_vals
        with np.errstate(divide="ignore"):
            p_vals_log = np.log(p_vals_transformed)

        # Penalties
        p_good_log = np.log(1.0 - p_bad)
        p_bad_log = np.log(p_bad)

        # Calculate score matrix
        # map_mean: (M,) -> (1, M) (assuming d=1)
        map_mean_in = self.map_mean.reshape(1, -1)
        map_stiffness_in = self.map_stiffness  # (M,) -> will be handled in smatrix

        alignment_matrix = _smatrix_ac_par(x, K, map_mean_in, map_stiffness_in)

        # Add priors
        # did_backstep is (N,) -> (N, 1)
        db = did_backstep[:, np.newaxis]
        alignment_matrix += prior_given_backstep[np.newaxis, :] * db
        alignment_matrix += prior_given_nobackstep[np.newaxis, :] * (~db)

        # Pruning
        max_scores = np.max(alignment_matrix, axis=1, keepdims=True)
        candidate_matches = alignment_matrix > (max_scores + score_cutoff)
        num_candidate_matches = np.sum(candidate_matches, axis=1)

        # Set non-candidates to -inf
        alignment_matrix[~candidate_matches] = -np.inf

        # Traceback matrices
        traceback_matrix_rows = np.zeros(alignment_matrix.shape, dtype=int)
        traceback_matrix_cols = np.zeros(alignment_matrix.shape, dtype=int)

        if verbose:
            print("Performing traceback")

        for cl in range(1, n_levels):
            if verbose and cl % 10 == 0:
                print(cl)

            this_row_best_scores = np.full(num_candidate_matches[cl], -np.inf)
            this_row_best_row_from = np.zeros(num_candidate_matches[cl], dtype=int)
            this_row_best_col_from = np.zeros(num_candidate_matches[cl], dtype=int)

            # Target indices in the current row
            target_indices = np.where(candidate_matches[cl])[0]

            for cfrom in range(0, min(max_sequential_bad, cl - 1) + 1):
                prev_row_idx = cl - cfrom - 1

                # Source indices in the previous row
                source_mask = candidate_matches[prev_row_idx]
                source_indices = np.where(source_mask)[0]

                if len(source_indices) == 0:
                    continue

                # Extract submatrix of perms
                perms_sub = self.perms_matrix[np.ix_(source_indices, target_indices)]

                # p_vals_log index: (cl, cfrom, perms_sub - 1)
                # assuming 1-based indices in perms_matrix
                t_penalties = p_vals_log[cl, cfrom, perms_sub - 1]

                # Add bad level penalties
                bad_pen = np.sum(p_bad_log[cl - cfrom : cl])

                t_matrix = t_penalties + bad_pen + p_good_log[prev_row_idx]

                # Add previous alignment scores
                prev_scores = alignment_matrix[prev_row_idx, source_indices][
                    :, np.newaxis
                ]

                # Total score for each transition
                total_trans_scores = t_matrix + prev_scores

                # Find best "from" for each "to"
                # max over source (axis 0)
                best_scores_from_prev = np.max(total_trans_scores, axis=0)
                best_where_from_prev = np.argmax(total_trans_scores, axis=0)

                # Update best for this row
                # Compare with current bests
                better = best_scores_from_prev > this_row_best_scores

                this_row_best_scores[better] = best_scores_from_prev[better]
                this_row_best_row_from[better] = prev_row_idx
                # Store the actual column index of the source
                this_row_best_col_from[better] = source_indices[
                    best_where_from_prev[better]
                ]

            # Update matrices
            alignment_matrix[cl, target_indices] += this_row_best_scores
            traceback_matrix_rows[cl, target_indices] = this_row_best_row_from
            traceback_matrix_cols[cl, target_indices] = this_row_best_col_from

        # Traceback start
        last_row_scores = alignment_matrix[-1, :]
        kmer_idx = np.argmax(last_row_scores)

        # Start traceback
        cl = n_levels - 1
        curr_kmer = kmer_idx

        reconstructed_kmers = []  # list of kmer indices

        while cl > 0:
            last_kmer = curr_kmer

            prev_col = traceback_matrix_cols[cl, last_kmer]
            prev_row = traceback_matrix_rows[cl, last_kmer]

            ss = self.step_size_matrix[prev_col, last_kmer]

            # Step back
            cl = prev_row
            curr_kmer = prev_col

            reconstructed_kmers.append(last_kmer)
            # Add NaNs
            if ss > 1:
                reconstructed_kmers.extend([np.nan] * int(ss - 1))

        # Add the final (first) kmer
        reconstructed_kmers.append(curr_kmer)

        # Reverse to get chronological order
        reconstructed_kmers = reconstructed_kmers[::-1]

        # Convert to float array for nan handling
        seq_arr = np.array(reconstructed_kmers, dtype=float)

        # Crop
        valid_indices = np.where(~np.isnan(seq_arr))[0]
        if len(valid_indices) > 0:
            first = valid_indices[0]
            last = valid_indices[-1]
            seq_arr = seq_arr[first : last + 1]
        else:
            return ""

        # Parity Check (Even/Odd)
        n_gap = 11
        i = 0
        while i <= len(seq_arr) - n_gap:
            window = seq_arr[i : i + n_gap]
            if np.all(np.isnan(window)):
                if i > 0 and i + n_gap < len(seq_arr):
                    prev_val = seq_arr[i - 1]
                    next_val = seq_arr[i + n_gap]

                    if not np.isnan(prev_val) and not np.isnan(next_val):
                        # Python Even is MATLAB Odd.
                        # We want to check parity.
                        # Using 0-based values directly.
                        # parity = (prev + next + gap_len) % 2
                        parity = int((prev_val + next_val + n_gap) % 2)

                        if parity == 1:
                            # Insert NaN
                            seq_arr = np.insert(seq_arr, i, np.nan)
                            # Skip ahead
                            i += n_gap + 1
                            continue
            i += 1

        # Find first Even value (Corresponding to MATLAB Odd)
        even_mask = seq_arr % 2 == 0
        even_indices = np.where(even_mask)[0]

        start_idx = 0
        if len(even_indices) > 0:
            first_idx = even_indices[0]
            start_idx = first_idx % 2

        # Go two by two
        for ii in range(start_idx, len(seq_arr), 2):
            if ii < len(seq_arr):
                val = seq_arr[ii]
                if not np.isnan(val):
                    # Convert Even to Odd (0->1)
                    new_val = val + 1
                    seq_arr[ii] = new_val
                    if ii + 1 < len(seq_arr):
                        seq_arr[ii + 1] = new_val
                elif ii + 1 < len(seq_arr):
                    val_next = seq_arr[ii + 1]
                    if not np.isnan(val_next):
                        seq_arr[ii] = val_next
                        seq_arr[ii + 1] = val_next

        # Subsample
        seq_final = seq_arr[0::2]

        # Assembly string
        total_len = len(seq_final) + 5
        char_matrix = np.full((len(seq_final), total_len), " ", dtype="U1")

        write_pos = 0
        for ii, k_val in enumerate(seq_final):
            if not np.isnan(k_val):
                name = self.map_names[int(k_val)]
                for c_i, char in enumerate(name):
                    if write_pos + c_i < total_len:
                        char_matrix[ii, write_pos + c_i] = char

            write_pos += 1

        final_seq_chars = np.max(char_matrix.view(np.int32), axis=0).view("U1")
        sequence = "".join(final_seq_chars).replace(" ", "")

        return sequence
