import re

import pandas as pd

import poreflow as pf

from poreflow.steps import metrics


def get_step_finding_stats(f: pf.File) -> pf.EventsDataFrame:
    if not f.has_events:
        raise RuntimeError("File must have events. Please run event detection first.")

    if not f.has_events:
        raise RuntimeError("File must have steps. Please run step detection first.")

    steps = f.get_steps()
    events = f.get_events()

    events["std_of_step_means"] = get_std_of_step_means(steps)
    events["n_steps"] = get_n_steps(steps)

    events[pf.STEP_RATE_COL] = events["n_steps"] / events[pf.DURATION_COL]

    events["binned_entropy_of_means"] = get_binned_entropies(events, steps)

    return events


def get_binned_entropies(
    events: pf.EventsDataFrame, steps: pf.StepsDataFrame
) -> pd.Series:
    s = pd.Series(index=events.index, dtype=float)
    for j, mean in steps.groupby(pf.EVENT_COL)[pf.MEAN_COL]:
        s[j] = metrics.binned_entropy(mean)
    return s


def get_n_steps(steps: pf.StepsDataFrame) -> pd.Series:
    return steps[pf.EVENT_COL].value_counts()


def get_std_of_step_means(steps: pf.StepsDataFrame) -> pd.Series:
    return steps.groupby(pf.EVENT_COL)[pf.MEAN_COL].std()


def filter_from_config(events: pf.EventsDataFrame, conditions: dict) -> pd.DataFrame:
    """Filter using a dictionary of conditions

    Filter using a dictionary of conditions formatted as:
    {"min_[col]": value, ...} or {"max_[col]": value, ...}

    Where [col] is a column of a feature in an EventsDataFrame such as
    step_rate, duration, etc.

    An example dictionary would look like:
    {'min_duration': 1,
     'min_n_steps': 45,
     'max_n_steps': 800,
     'min_binned_entropy_of_means': 2.5,
     'min_step_rate': 12,
     'min_ios': 200,
     'max_ios': 300}

    These conditions can easily be loaded from a TOML configuration file.

    Returns:
        pd.DataFrame: A truth table whether events meet the specified conditions.
            The columns contain the conditions. Also contains a column "all",
            which is the boolean mask of all the events that meet each condition.
    """
    n_conditions = len(conditions)

    targets = pd.DataFrame(
        index=range(n_conditions), columns=["col", "comparison", "value"], dtype=object
    )
    for j, (condition, value) in enumerate(conditions.items()):
        results = re.findall(r"(min|max)_(\w+)", condition)

        if not results:
            raise KeyError(
                f'Condition "{condition}" could not be interpreted. '
                'Please format as "min_[col]" or "max_[col]" in dict/TOML, '
                "where [col] is a column available in the event dataframe."
            )
        prefix, col = results[0]

        if col not in events.columns:
            raise KeyError(
                f'Column {col} specified in condition "{condition}" not present in EventsDataFrame'
            )

        if prefix == "min":
            comparison = ">"
        elif prefix == "max":
            comparison = "<"
        else:
            raise KeyError(f"Unknown prefix {prefix}")

        targets.iloc[j, :] = col, comparison, value

    truth_table = pd.DataFrame(
        index=events.index,
        columns=targets.astype(str).agg("".join, axis=1),
        dtype=bool,
    )
    truth_table.index.name = "event"
    truth_table.columns.name = "condition"
    for tup in targets.itertuples():
        if tup.comparison == "<":
            truth_table.iloc[:, tup.Index] = events[tup.col] < tup.value
        else:
            truth_table.iloc[:, tup.Index] = events[tup.col] > tup.value

    truth_table["all"] = truth_table.all(axis=1)
    return truth_table
