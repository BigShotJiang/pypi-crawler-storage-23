"""Open state estimator"""

import numpy as np
import pandas as pd
import scipy
import sklearn

from scipy.stats import norm

import poreflow as pf


class OpenStateNotFoundError(Exception):
    pass


def find_open_state(
    df: pd.DataFrame,
    open_state_range: tuple[float, float],
    n_components: int = 3,
    strict=True,
) -> list | None:
    lower_bound, upper_bound = open_state_range

    i_clipped = df.loc[
        (df.i > lower_bound) & (df.i < upper_bound), pf.CURRENT_FIELD_NAME
    ].to_numpy()

    if len(i_clipped) == 0:
        if strict:
            raise ValueError(
                f"Could not find any current in the range {open_state_range}"
            )
        else:
            return None

    mean, std, weight = select_component(i_clipped, open_state_range, n_components)

    return [mean, std, weight]


def select_component(
    i: np.ndarray,
    open_state_range: tuple,
    n_components: int = 3,
    max_size: int = 100000,
):
    max_size = int(max_size)

    lower_bound, upper_bound = open_state_range

    # Downsample for GMM fitting if data is large
    if len(i) > max_size:
        i = scipy.signal.decimate(i, int(len(i) / max_size))

    # Fit GMM on sample
    gm = sklearn.mixture.GaussianMixture(n_components=n_components, random_state=0).fit(
        i.reshape(-1, 1)
    )
    means = gm.means_.flatten()
    stds = np.sqrt(gm.covariances_.flatten())
    weights = gm.weights_

    valid_components = np.where((means > lower_bound) & (means < upper_bound))[0]
    if len(valid_components) == 0:
        return None, None, None

    sele = valid_components[np.argmax(weights[valid_components])]

    return (
        means[sele],
        stds[sele],
        weights[sele],
    )


def get_open_state_mask(df: pd.DataFrame, component: list) -> pd.Series:
    """

    Args:
        df:
        component:
    """
    mean, sigma, _ = component

    # Get quantiles
    q_low = norm.ppf(0.00001, loc=mean, scale=sigma)
    q_high = norm.ppf(0.99999, loc=mean, scale=sigma)

    return (df.i >= q_low) & (df.i <= q_high)


def get_open_state_fit(df: pd.DataFrame, mask, degree: int = 1):
    if not np.sum(mask):
        raise ValueError("No samples marked as open state.")

    y = df.loc[mask, pf.CURRENT_FIELD_NAME]
    x = df.t[mask]

    poly = np.polynomial.Polynomial.fit(x, y, deg=degree, symbol="t")

    return poly.convert()
