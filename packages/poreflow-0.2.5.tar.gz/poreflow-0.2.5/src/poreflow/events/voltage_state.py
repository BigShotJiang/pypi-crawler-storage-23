import pandas as pd


def get_voltage_state_mask(
    raw: pd.DataFrame, voltage_range: tuple[float, float]
) -> pd.Series:
    """Get mask of out-of-range votlages"""
    voltage_low, voltage_high = voltage_range

    return (raw.v < voltage_low) & (raw.v > voltage_high)
