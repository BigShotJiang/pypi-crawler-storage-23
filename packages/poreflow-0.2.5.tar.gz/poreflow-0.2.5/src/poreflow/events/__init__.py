import importlib as _importlib

submodules = [
    "detection",
    "open_state",
    "voltage_state",
    "selection",
]

__all__ = submodules


def __getattr__(name):
    if name in submodules:
        return _importlib.import_module(f"poreflow.events.{name}")
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(f"Module 'poreflow.events' has no attribute '{name}'")
