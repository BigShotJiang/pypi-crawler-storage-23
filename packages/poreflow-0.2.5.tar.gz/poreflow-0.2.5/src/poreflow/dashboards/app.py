"""Main Dash App for Poreflow."""

import os
import dash
import dash_bootstrap_components as dbc
from dash import dcc, html, Input, Output

app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True,
    use_pages=True,
    pages_folder="pages",
)

app.title = "poreFlow Dashboard"

# Sidebar style
SIDEBAR_STYLE = {
    "position": "fixed",
    "top": 0,
    "left": 0,
    "bottom": 0,
    "width": "16rem",
    "padding": "2rem 1rem",
    "background-color": "#f8f9fa",
}

# Content style
CONTENT_STYLE = {
    "margin-left": "18rem",
    "margin-right": "2rem",
    "padding": "2rem 1rem",
}

content = html.Div(dash.page_container, style=CONTENT_STYLE)


def create_sidebar():
    return html.Div(
        [
            html.H2("poreFlow", className="display-4"),
            html.Hr(),
            dbc.Nav(
                [
                    dbc.NavLink(
                        page["name"], href=page["relative_path"], active="exact"
                    )
                    for page in dash.page_registry.values()
                ],
                vertical=True,
                pills=True,
            ),
        ],
        style=SIDEBAR_STYLE,
    )


def get_layout():
    # Note: initial_path is now handled by the run_app function setting app.layout
    initial_config = {
        "path": None,
        "status": None,
        "message": None,
        "info": "No path loaded.",
    }

    return html.Div(
        [
            dcc.Store(
                id="file-config-store", data=initial_config, storage_type="session"
            ),
            dcc.Store(id="current-idx-store", data=0, storage_type="session"),
            create_sidebar(),
            content,
        ]
    )


app.layout = get_layout


@app.callback(
    Output("file-config-store", "data"),
    [Input("file-config-store", "data")],
)
def validate_config(config):
    """Validate the path in the config store and update status."""
    if not config or not config.get("path"):
        return {
            "path": None,
            "status": None,
            "message": None,
            "info": "No path loaded.",
        }

    path = config["path"]

    if os.path.exists(path):
        path_type = "Directory" if os.path.isdir(path) else "File"
        new_status = "success"
        new_message = f"Path successfully verified: {path}"
        new_info = {"path": path, "type": path_type}
    else:
        new_status = "danger"
        new_message = f"Path does not exist: {path}"
        new_info = "Path invalid or inaccessible."

    # Only update if something actually changed to avoid circular callback issues
    if (
        config.get("status") == new_status
        and config.get("message") == new_message
        and config.get("info") == new_info
    ):
        return dash.no_update

    return {
        "path": path,
        "status": new_status,
        "message": new_message,
        "info": new_info,
    }


def run_app(port=8050, debug=False, initial_path=None):
    """Run the Dash app."""
    if initial_path:

        def dynamic_layout():
            initial_config = {
                "path": initial_path,
                "status": None,
                "message": None,
                "info": "No path loaded.",
            }
            return html.Div(
                [
                    dcc.Store(
                        id="file-config-store",
                        data=initial_config,
                        storage_type="session",
                    ),
                    dcc.Store(id="current-idx-store", data=0, storage_type="session"),
                    create_sidebar(),
                    content,
                ]
            )

        app.layout = dynamic_layout
    else:
        app.layout = get_layout
    app.run(port=port, debug=debug)


if __name__ == "__main__":
    run_app(debug=True)
