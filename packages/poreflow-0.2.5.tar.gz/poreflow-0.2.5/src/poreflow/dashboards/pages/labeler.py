"""Labeler page for Poreflow dashboard."""

import json

import dash
from dash import (
    dcc,
    html,
    Input,
    Output,
    State,
    callback,
    clientside_callback,
    ctx,
    Patch,
)
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash.exceptions import PreventUpdate

import poreflow as pf
from poreflow.dashboards.utils import get_file_handle
from poreflow.dashboards.components import (
    create_navigation_panel,
    create_modal,
    handle_navigation,
    DEFAULT_LABELS,
    BASE_LABEL_BTN_STYLE,
    DOWNSAMPLE_INPUT_STYLE,
    QUALITY_BAR_STYLE,
)

dash.register_page(__name__, path="/labeler", title="Event Labeler")

# --- Constants & Data Structures ---

# --- Layout Components ---


def create_top_controls():
    """Create the top row of controls: Steps toggle, Downsampling, and Quality."""
    return dbc.Row(
        [
            dbc.Col(
                [
                    html.Label("Steps:", className="me-2 mb-0"),
                    dbc.Checkbox(id="show-steps-check", value=False),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    html.Label("Downsample (Hz):", className="me-2 mb-0"),
                    dbc.Input(
                        id="downsample-hz",
                        type="number",
                        min=1,
                        step="any",
                        list="downsample-list",
                        placeholder="Original",
                        style=DOWNSAMPLE_INPUT_STYLE,
                    ),
                    html.Datalist(id="downsample-list"),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    html.Label("Quality", className="me-2"),
                    dbc.Progress(id="quality-bar", value=0, style=QUALITY_BAR_STYLE),
                    html.Small(id="quality-text", className="ms-2"),
                ],
                width="auto",
                className="d-flex align-items-center",
            ),
        ],
        className="mb-3 align-items-center justify-content-between",
    )


def create_labeling_buttons():
    """Create the row of labeling buttons."""
    return html.Div(
        [
            dbc.Button(
                f"{j} ({label.name})",
                id={"type": "label-btn", "index": j},
                style={**BASE_LABEL_BTN_STYLE, "background-color": label.color},
            )
            for j, label in enumerate(DEFAULT_LABELS)
        ],
        id="label-buttons-container",
        className="mt-4 d-flex justify-content-center flex-wrap",
    )


def create_settings_modal():
    """Create the plot settings modal."""
    return create_modal(
        id="event-settings-modal",
        title="Plot Settings",
        children=[
            html.Label("Y-Axis Scaling", className="fw-bold mb-2"),
            dbc.RadioItems(
                id="yaxis-scaling-type",
                options=[
                    {"label": "Auto", "value": "auto"},
                    {"label": "Fixed", "value": "fixed"},
                ],
                value="fixed",
                className="mb-3",
            ),
            dbc.Row(
                [
                    dbc.Col(
                        [
                            html.Label("Min"),
                            dbc.Input(id="yaxis-min", type="number", value=0),
                        ]
                    ),
                    dbc.Col(
                        [
                            html.Label("Max"),
                            dbc.Input(id="yaxis-max", type="number", value=200),
                        ]
                    ),
                ],
                id="yaxis-fixed-inputs",
                className="g-2",
            ),
        ],
    )


layout = html.Div(
    [
        dbc.Row(
            dbc.Col(
                [
                    create_top_controls(),
                    dcc.Graph(id="graph", config={"displayModeBar": True}),
                    create_navigation_panel(
                        prefix="event",
                        show_save=True,
                        show_settings=True,
                        show_info=True,
                    ),
                    create_labeling_buttons(),
                    html.P(
                        "Shortcuts: Left/Right Arrow for navigation, 1-7 for labels, Space for Next.",
                        className="text-muted text-center mt-3",
                    ),
                ],
                width=12,
            )
        ),
        # Stores
        dcc.Store(id="keyboard-store"),
        dcc.Store(id="label-store"),
        dcc.Store(id="next-event-label"),
        dcc.Store(id="new-label-assignment"),
        dcc.Store(id="show-steps-store", data=False, storage_type="session"),
        dcc.Store(id="pending-changes-store", data={}, storage_type="session"),
        dcc.Store(id="properties-store", data={}, storage_type="session"),
        dcc.Store(id="event-idx-store", data=0, storage_type="session"),
        dcc.Interval(id="status-clear-interval", interval=3000, disabled=True),
        dcc.Store(
            id="plot-settings-store",
            data={"yaxis": "fixed", "fixed_min": 0, "fixed_max": 200},
            storage_type="session",
        ),
        create_settings_modal(),
        create_modal(
            id="event-info-modal", title="Event Info", body_id="event-info-modal-body"
        ),
    ]
)


def get_title(idx: int, label: int, pending: bool = False):
    return f"Event {idx} (Label: {label}{'*' if pending else ''})"


# --- Plotting Logic ---


def create_event_figure(
    event, idx, label, has_steps, show_steps, plot_settings, pending_changes, f=None
):
    """Generate the Plotly figure for a specific event."""
    t = event.t
    i = event[pf.CURRENT_FIELD_NAME].values
    color = DEFAULT_LABELS[min(label, len(DEFAULT_LABELS) - 1)].color

    fig = go.Figure()

    # Raw Data Trace
    opacity = 0.3 if show_steps and has_steps else 1.0
    fig.add_trace(
        go.Scatter(
            x=t,
            y=i,
            mode="lines",
            line=dict(color=color, width=1),
            opacity=opacity,
            showlegend=False,
            name="Raw Data",
        )
    )

    # Steps Trace
    if show_steps and has_steps and f is not None:
        try:
            steps = f.get_steps(event=idx)
            if not steps.empty:
                if not steps.has_times:
                    steps.calculate_times()
                fig.add_trace(
                    go.Scatter(
                        x=steps[pf.START_TIME_COL],
                        y=steps[pf.MEAN_COL],
                        line=dict(color="black", width=2),
                        name="Steps",
                        showlegend=False,
                        mode="lines",
                        line_shape="hv",
                    )
                )
        except Exception:
            pass

    # IOS Line
    ios = getattr(event, "ios", 1.0) or 1.0
    if not isinstance(ios, (int, float)):
        ios = 1.0  # Fallback for polynomial if needed, though get_hline expects float

    fig.add_hline(
        y=ios,
        line_dash="dash",
        line_color="gray",
        annotation_text="IOS",
        annotation_position="top right",
    )

    # Layout
    title = get_title(idx, label, pending=str(idx) in pending_changes)
    fig.update_layout(
        title=title,
        xaxis_title="Time (s)",
        yaxis_title="I (pA)",
        template="plotly_white",
        margin=dict(l=40, r=40, t=60, b=40),
        hovermode="closest",
    )

    if plot_settings.get("yaxis") == "fixed":
        fig.update_yaxes(
            range=[plot_settings.get("fixed_min"), plot_settings.get("fixed_max")]
        )

    return fig


# --- Callbacks ---


@callback(
    Output("graph", "figure"),
    Output("properties-store", "data"),
    Input("event-idx-store", "data"),
    Input("downsample-hz", "value"),
    Input("plot-settings-store", "data"),
    Input("show-steps-store", "data"),
    State("file-config-store", "data"),
    State("pending-changes-store", "data"),
)
def update_plot(idx, downsample, plot_settings, show_steps, config, pending_changes):
    if not config or not config.get("path"):
        return go.Figure(), {}

    try:
        f = get_file_handle(config["path"])
        if not f or not f.has_events:
            return go.Figure(), {}

        num_events = len(f.get_events())
        if idx >= num_events:
            return go.Figure(), {}

        event = f.get_event(idx, downsample=downsample)
        label = pending_changes.get(str(idx), event.label)

        fig = create_event_figure(
            event,
            idx,
            label,
            f.has_steps,
            show_steps,
            plot_settings,
            pending_changes,
            f=f,
        )

        quality = getattr(event, "quality", 0)

        # Prepare properties
        ios = getattr(event, "ios", "N/A")
        if not isinstance(ios, (int, float, str)):
            ios = str(ios)

        properties = {
            "quality": quality,
            "label": label,
            "has_steps": f.has_steps,
            "channel": getattr(event, "channel", "N/A"),
            "ios": ios,
            "n_samples": len(event),
            "duration": getattr(event, "duration", len(event) / event.sfreq),
            "start_time": event.start_idx / event.sfreq,
        }

        return fig, properties

    except Exception as e:
        fig = go.Figure()
        fig.add_annotation(text=f"Error: {str(e)}", x=0.5, y=0.5, showarrow=False)
        return fig, {}


@callback(
    Output("quality-bar", "value"),
    Output("quality-text", "children"),
    Output("next-event-label", "data"),
    Output("show-steps-check", "disabled"),
    Output("event-info-modal-body", "children"),
    Input("properties-store", "data"),
)
def update_ui_from_properties(props):
    """Update UI components when properties store changes."""
    if not props:
        return 0, "No data", None, True, "No data available."

    quality = props.get("quality", 0)
    label = props.get("label", None)
    has_steps = props.get("has_steps", False)

    # Info panel content
    info_items = [
        ("Channel", props.get("channel")),
        (
            "Open State Current (pA)",
            f"{props.get('ios'):.1f}"
            if isinstance(props.get("ios"), (int, float))
            else props.get("ios"),
        ),
        ("Samples", props.get("n_samples")),
        (
            "Duration (s)",
            f"{props.get('duration'):.2f}"
            if isinstance(props.get("duration"), float)
            else props.get("duration"),
        ),
        (
            "Start Time (s)",
            f"{props.get('start_time'):.2f}"
            if isinstance(props.get("start_time"), float)
            else props.get("start_time"),
        ),
    ]

    info_body = html.Table(
        [
            html.Tr([html.Th(k, style={"padding-right": "20px"}), html.Td(str(v))])
            for k, v in info_items
        ],
        className="table table-sm table-borderless",
    )

    return quality * 100, f"{quality:.2f}", label, not has_steps, info_body


@callback(
    Output("show-steps-store", "data"),
    Output("show-steps-check", "value"),
    Input("show-steps-check", "value"),
    Input("show-steps-store", "data"),
)
def sync_steps(check_value, store_data):
    trigger_id = ctx.triggered_id
    if trigger_id == "show-steps-check":
        return check_value, dash.no_update
    return dash.no_update, store_data


@callback(
    Output("event-idx-store", "data"),
    Output("event-idx-input", "value"),
    Input("event-prev-btn", "n_clicks"),
    Input("event-next-btn", "n_clicks"),
    Input("event-idx-input", "value"),
    Input("keyboard-store", "data"),
    State("event-idx-store", "data"),
)
def process_navigation(prev, next_btn, manual, key_data, current):
    new_idx = handle_navigation(ctx.triggered_id, current, manual, key_data, "event")
    if new_idx is None:
        raise PreventUpdate
    return new_idx, new_idx


@callback(
    Output("label-store", "data"),
    Output("pending-changes-store", "data"),
    Input("next-event-label", "data"),
    Input("new-label-assignment", "data"),
    State("event-idx-store", "data"),
    State("pending-changes-store", "data"),
)
def update_label_state(
    label_from_event, label_from_button, current_idx, pending_changes
):
    if ctx.triggered_id == "next-event-label":
        return label_from_event, pending_changes
    if ctx.triggered_id == "new-label-assignment" and label_from_button is not None:
        new_pending = pending_changes.copy()
        new_pending[str(current_idx)] = label_from_button
        return label_from_button, new_pending
    raise PreventUpdate


@callback(
    Output("event-status", "children"),
    Output("pending-changes-store", "data", allow_duplicate=True),
    Output("status-clear-interval", "disabled"),
    Input("event-save-btn", "n_clicks"),
    State("file-config-store", "data"),
    State("pending-changes-store", "data"),
    prevent_initial_call=True,
)
def save_labels(n_clicks, config, pending_changes):
    if not n_clicks or not pending_changes:
        return dash.no_update, dash.no_update, True
    try:
        f = get_file_handle(config.get("path"), mode="r+")
        events = f.get_events()
        for idx_str, label in pending_changes.items():
            events.loc[int(idx_str), pf.LABEL_COL] = label
        f.set_events(events)
        return "Saved!", {}, False
    except Exception as e:
        return f"Error: {str(e)}", pending_changes, False


@callback(
    Output("new-label-assignment", "data"),
    Input({"type": "label-btn", "index": dash.ALL}, "n_clicks"),
    Input("keyboard-store", "data"),
)
def label_trigger(btn_clicks, key_data):
    if not ctx.triggered:
        raise PreventUpdate
    trigger_id_str = ctx.triggered[0]["prop_id"].split(".")[0]
    if trigger_id_str.startswith("{"):
        return json.loads(trigger_id_str)["index"]
    if trigger_id_str == "keyboard-store" and key_data:
        key = key_data.get("key")
        if key.isdigit():
            return int(key)
    raise PreventUpdate


# --- Simple Utilities & Styling ---


@callback(
    Output({"type": "label-btn", "index": dash.ALL}, "style"),
    Input("label-store", "data"),
)
def update_button_styles(selected_label):
    styles = []
    for j, label in enumerate(DEFAULT_LABELS):
        style = {**BASE_LABEL_BTN_STYLE, "background-color": label.color}
        if j == selected_label:
            style["transform"] = "scale(1.15)"
            style["z-index"] = "10"
        else:
            style["opacity"] = "0.7"
        styles.append(style)
    return styles


@callback(
    Output("downsample-hz", "placeholder"),
    Output("downsample-hz", "max"),
    Output("downsample-list", "children"),
    Input("file-config-store", "data"),
)
def update_downsample_options(config):
    if not config or not config.get("path"):
        return "Original", None, []
    try:
        f = get_file_handle(config["path"])
        sfreq = f.sfreq
        options = [html.Option(value=str(int(sfreq / d))) for d in [1, 10, 100]]
        return f"Original ({int(sfreq)} Hz)", sfreq, options
    except Exception:
        return "Original", None, []


@callback(
    Output("event-settings-modal", "is_open"),
    [
        Input("event-settings-btn", "n_clicks"),
        Input("close-event-settings-modal", "n_clicks"),
    ],
    State("event-settings-modal", "is_open"),
)
def toggle_settings_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("event-info-modal", "is_open"),
    [Input("event-info-btn", "n_clicks"), Input("close-event-info-modal", "n_clicks")],
    State("event-info-modal", "is_open"),
)
def toggle_info_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("plot-settings-store", "data"),
    Input("yaxis-scaling-type", "value"),
    Input("yaxis-min", "value"),
    Input("yaxis-max", "value"),
    State("plot-settings-store", "data"),
)
def update_settings(scaling, ymin, ymax, current):
    return {
        "yaxis": scaling,
        "fixed_min": ymin if ymin is not None else current.get("fixed_min", 0),
        "fixed_max": ymax if ymax is not None else current.get("fixed_max", 200),
    }


@callback(Output("yaxis-fixed-inputs", "style"), Input("yaxis-scaling-type", "value"))
def toggle_yaxis_inputs(scaling):
    return {"display": "flex"} if scaling == "fixed" else {"display": "none"}


@callback(
    Output("event-status", "children", allow_duplicate=True),
    Output("status-clear-interval", "disabled", allow_duplicate=True),
    Input("status-clear-interval", "n_intervals"),
    prevent_initial_call=True,
)
def clear_status(_):
    return "", True


@callback(
    Output("graph", "figure", allow_duplicate=True),
    Input("new-label-assignment", "data"),
    State("event-idx-store", "data"),
    prevent_initial_call=True,
)
def fast_color_update(label_idx, event_idx):
    if label_idx is None:
        raise PreventUpdate
    patch = Patch()
    patch["data"][0]["line"]["color"] = DEFAULT_LABELS[label_idx].color
    patch["layout"]["title"]["text"] = get_title(event_idx, label_idx, pending=True)

    return patch


@callback(
    Output("graph", "figure", allow_duplicate=True),
    Input("event-status", "children"),
    State("label-store", "data"),
    State("event-idx-store", "data"),
    prevent_initial_call=True,
)
def remove_asterisk(status, label_idx, event_idx):
    if "Error" in status:
        raise PreventUpdate
    patch = Patch()
    patch["layout"]["title"]["text"] = get_title(event_idx, label_idx, pending=False)
    return patch


clientside_callback(
    """
    function(id) {
        if (!window.keyListenerAttached) {
            document.addEventListener('keydown', function(e) {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
                const keys = ['ArrowRight', 'ArrowLeft', ' ', '1', '2', '3', '4', '5', '6', '7'];
                if (keys.includes(e.key)) {
                    e.preventDefault();
                    dash_clientside.set_props(id, {data: {key: e.key, ts: Date.now()}});
                }
            });
            window.keyListenerAttached = true;
        }
        return window.dash_clientside.no_update;
    }
    """,
    Output("keyboard-store", "id"),
    Input("keyboard-store", "id"),
)
