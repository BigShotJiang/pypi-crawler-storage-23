"""File management page for Poreflow dashboard."""

import dash
from dash import html, Input, Output, State, callback
import dash_bootstrap_components as dbc
import traceback
from poreflow.dashboards.utils import get_file_handle

dash.register_page(__name__, path="/", title="File Manager")

layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.H1("File Manager"),
                        html.P(
                            "Enter the local file system path to your dataset.",
                            className="text-muted",
                        ),
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H5("Load Local Dataset"),
                                    dbc.InputGroup(
                                        [
                                            dbc.Input(
                                                id="file-path-input",
                                                placeholder="e.g., /Users/name/data/experiment_01",
                                                type="text",
                                                persistence=True,
                                                persistence_type="session",
                                            ),
                                            dbc.Button(
                                                "Load Path",
                                                id="load-btn",
                                                color="primary",
                                            ),
                                        ],
                                        className="mb-3",
                                    ),
                                    html.Div(id="load-status-message"),
                                ]
                            )
                        ),
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H5("Current Dataset Information"),
                                    html.Div(
                                        id="dataset-info-content",
                                        children="No path loaded.",
                                    ),
                                ]
                            ),
                            className="mt-3",
                        ),
                    ],
                    width=12,
                )
            ]
        )
    ]
)


@callback(
    Output("file-config-store", "data", allow_duplicate=True),
    Input("load-btn", "n_clicks"),
    [State("file-path-input", "value"), State("file-config-store", "data")],
    prevent_initial_call=True,
)
def update_config_path(n_clicks, new_path, current_config):
    """Update the path in the global config store."""
    if current_config is None:
        current_config = {}

    updated_config = current_config.copy()
    updated_config["path"] = new_path
    # Clear status to trigger re-validation in app.py
    updated_config["status"] = None
    return updated_config


@callback(
    [
        Output("file-path-input", "value"),
        Output("load-status-message", "children"),
        Output("dataset-info-content", "children"),
    ],
    [Input("file-config-store", "data")],
)
def sync_ui_with_config(config):
    """Update UI components based on the global config state."""
    if not config:
        return "", None, "No path loaded."

    path = config.get("path", "")
    status = config.get("status")
    message = config.get("message")

    if not path:
        return "", None, "No path loaded."

    status_msg = None
    if status and message:
        status_msg = dbc.Alert(message, color=status, dismissable=True)

    info_content = "No path loaded."
    try:
        f = get_file_handle(path)
        if f:
            device = f.device
            has_events = f.has_events
            has_steps = f.has_steps

            info_content = html.Div(
                [
                    html.P([html.Strong("Path: "), path]),
                    html.P([html.Strong("Type: "), device]),
                    html.P([html.Strong("Has Events: "), str(has_events)]),
                    html.P([html.Strong("Has Steps: "), str(has_steps)]),
                ]
            )
    except Exception as e:
        status_msg = html.Div(
            [
                dbc.Alert(f"Error opening file: {str(e)}", color="danger"),
                dbc.Accordion(
                    [
                        dbc.AccordionItem(
                            html.Pre(traceback.format_exc()), title="Error Details"
                        )
                    ],
                    start_collapsed=True,
                ),
            ]
        )
        info_content = "Error loading dataset info."

    return path, status_msg, info_content
