"""Channels page for Poreflow dashboard."""

import dash
import numpy as np
import scipy
import scipy.signal
from dash import dcc, html, Input, Output, State, callback, ctx
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
from dash.exceptions import PreventUpdate

import poreflow as pf
from poreflow.dashboards.utils import get_file_handle
from poreflow.dashboards.components import (
    create_navigation_panel,
    create_modal,
    handle_navigation,
    DEFAULT_LABELS,
)

dash.register_page(__name__, path="/channels", title="Channels")

DEFAULT_MAX_POINTS = 100000
# --- Layout ---


def create_settings_modal():
    """Create the channel plot settings modal."""
    return create_modal(
        id="channel-settings-modal",
        title="Channel Plot Settings",
        children=[
            html.Label("Max. samples displayed", className="fw-bold mb-2"),
            dbc.Input(
                id="channel-max-samples",
                type="number",
                value=DEFAULT_MAX_POINTS,
                min=1000,
                step=1000,
            ),
            html.Small(
                "Lowering this value improves performance for long measurements.",
                className="text-muted d-block mt-1",
            ),
            html.Hr(),
            html.Label("Event Downsample Factor", className="fw-bold mb-2"),
            dbc.Input(
                id="event-downsample-factor",
                type="number",
                value=10,
                min=1,
                step=1,
            ),
            html.Small(
                "Downsample events by this factor (default 10) when showing them.",
                className="text-muted d-block mt-1",
            ),
        ],
    )


layout = html.Div(
    [
        dbc.Row(
            dbc.Col(
                [
                    html.H1("Channel Viewer"),
                    dbc.Row(
                        [
                            dbc.Col(
                                [
                                    html.Label("Show Events:", className="me-2 mb-0"),
                                    dbc.Checkbox(id="show-events-check", value=False),
                                ],
                                width="auto",
                                className="d-flex align-items-center",
                            ),
                        ],
                        className="mb-2",
                    ),
                    dcc.Graph(id="channel-graph", config={"displayModeBar": True}),
                    create_navigation_panel(
                        prefix="channel", show_settings=True, show_info=True
                    ),
                ],
                width=12,
            )
        ),
        # Stores
        dcc.Store(id="channel-idx-store", data=0, storage_type="session"),
        dcc.Store(
            id="channel-settings-store",
            data={"max_samples": DEFAULT_MAX_POINTS, "event_downsample": 10},
            storage_type="session",
        ),
        dcc.Store(id="keyboard-store"),  # Placeholder for shared keyboard listener
        create_settings_modal(),
        create_modal(
            id="channel-info-modal",
            title="Channel Info",
            body_id="channel-info-modal-body",
        ),
    ]
)

# --- Callbacks ---


@callback(
    Output("channel-graph", "figure"),
    Output("channel-info-modal-body", "children"),
    Input("channel-idx-store", "data"),
    Input("channel-settings-store", "data"),
    Input("show-events-check", "value"),
    State("file-config-store", "data"),
)
def update_channel_plot(channel_idx, settings, show_events, config):
    if not config or not config.get("path"):
        return go.Figure(), "No file loaded."

    try:
        f = get_file_handle(config["path"])
        if not f:
            return go.Figure(), "Could not open file."

        # Get available channels
        channels = f.get_channels()
        if not channels:
            return go.Figure(), "No channels found in file."

        # channel_idx is 0-based index into the channels list
        if channel_idx >= len(channels):
            channel_idx = 0

        channel_num = channels[channel_idx]

        max_samples = settings.get("max_samples", DEFAULT_MAX_POINTS)
        if show_events:
            max_samples = max_samples // 10

        i_raw = f.get_raw(channel=channel_num).i.to_numpy()
        duration = len(i_raw) / f.sfreq

        # Iteratively downsample by factor 10 with second order filter (fast)
        i = i_raw.astype(np.float32)
        while len(i) > max_samples:
            i = scipy.signal.decimate(i, 10, 2)

        t = np.linspace(0, duration, len(i), dtype=np.float32)

        fig = go.Figure()

        opacity = 0.25 if show_events else 1.0
        fig.add_trace(
            go.Scattergl(
                x=t,
                y=i,
                mode="lines",
                line=dict(color="#808080", width=2),
                opacity=opacity,
                name="Channel Data",
                showlegend=False,
            )
        )

        if show_events and f.has_events:
            events = f.get_events(channel=channel_num)

            downsample_factor = settings.get("event_downsample", 10)
            target_sfreq = f.sfreq / downsample_factor

            for idx, row in events.iterrows():
                try:
                    event_df = f.get_event(idx, downsample=target_sfreq)

                    label_idx = int(row.get(pf.LABEL_COL, 0))
                    color = DEFAULT_LABELS[
                        min(label_idx, len(DEFAULT_LABELS) - 1)
                    ].color

                    fig.add_trace(
                        go.Scattergl(
                            x=event_df.get_t(absolute=True),
                            y=event_df.i,
                            mode="lines",
                            line=dict(color=color, width=2),
                            name=f"Event {idx}",
                            showlegend=False,
                        )
                    )
                except Exception:
                    continue

        fig.update_layout(
            title=f"Channel {channel_num}",
            xaxis_title="Time (s)",
            yaxis_title="I (pA)",
            template="plotly_white",
            margin=dict(l=40, r=40, t=60, b=40),
            legend=dict(
                orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1
            ),
        )
        # Info body
        info_items = [
            ("Channel Number", channel_num),
            ("Sampling Frequency (Hz)", f"{f.sfreq:.1f}"),
            ("Total Samples", len(i_raw)),
            ("Displayed Samples", len(i)),
            ("Duration (s)", f"{duration:.2f}"),
        ]

        info_body = html.Table(
            [
                html.Tr([html.Th(k, style={"padding-right": "20px"}), html.Td(str(v))])
                for k, v in info_items
            ],
            className="table table-sm table-borderless",
        )

        return fig, info_body

    except Exception as e:
        import traceback

        fig = go.Figure()
        fig.add_annotation(text=f"Error: {str(e)}", x=0.5, y=0.5, showarrow=False)
        return fig, html.Pre(traceback.format_exc())


@callback(
    Output("channel-idx-store", "data"),
    Output("channel-idx-input", "value"),
    Input("channel-prev-btn", "n_clicks"),
    Input("channel-next-btn", "n_clicks"),
    Input("channel-idx-input", "value"),
    Input("keyboard-store", "data"),
    State("channel-idx-store", "data"),
)
def process_channel_navigation(prev, next_btn, manual, key_data, current):
    new_idx = handle_navigation(ctx.triggered_id, current, manual, key_data, "channel")
    if new_idx is None:
        raise PreventUpdate
    return new_idx, new_idx


@callback(
    Output("channel-settings-modal", "is_open"),
    [
        Input("channel-settings-btn", "n_clicks"),
        Input("close-channel-settings-modal", "n_clicks"),
    ],
    State("channel-settings-modal", "is_open"),
)
def toggle_channel_settings_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("channel-info-modal", "is_open"),
    [
        Input("channel-info-btn", "n_clicks"),
        Input("close-channel-info-modal", "n_clicks"),
    ],
    State("channel-info-modal", "is_open"),
)
def toggle_channel_info_modal(n1, n2, is_open):
    return not is_open if n1 or n2 else is_open


@callback(
    Output("channel-settings-store", "data"),
    Input("channel-max-samples", "value"),
    Input("event-downsample-factor", "value"),
    State("channel-settings-store", "data"),
)
def update_channel_settings(max_samples, event_downsample, current):
    if max_samples is None:
        raise PreventUpdate
    return {
        "max_samples": max_samples,
        "event_downsample": event_downsample if event_downsample is not None else 10,
    }
