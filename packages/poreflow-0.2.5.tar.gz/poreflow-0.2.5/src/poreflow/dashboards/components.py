"""Shared components for Poreflow dashboard."""

from dash import dcc, html
import dash_bootstrap_components as dbc
from dataclasses import dataclass


@dataclass
class Label:
    name: str
    color: str


DEFAULT_LABELS = [
    Label("none", "#808080"),
    Label("clogged", "#EC6842"),
    Label("dna", "#FFB81C"),
    Label("poc", "#0076C2"),
    Label("poc_reread", "#6CC24A"),
    Label("peptide_reread", "#EF60A3"),
    Label("other", "#bd47c9"),
]

BASE_LABEL_BTN_STYLE = {
    "margin": "5px",
    "color": "white",
    "border": "1px solid #ccc",
    "transition": "all 0.2s ease-in-out",
}

CONTROL_INPUT_STYLE = {"width": "100px"}
DOWNSAMPLE_INPUT_STYLE = {"width": "260px"}
QUALITY_BAR_STYLE = {"width": "200px", "height": "20px"}


def create_navigation_panel(
    prefix, show_save=False, show_settings=False, show_info=False
):
    """Create a generalized navigation panel."""
    buttons = []
    if show_save:
        buttons.append(
            dbc.Button(
                "\U0001f4be",
                id=f"{prefix}-save-btn",
                color="light",
                style={"margin": "5px", "color": "white", "border": "1px solid #ccc"},
                title="Save Changes",
            )
        )
    if show_settings:
        buttons.append(
            dbc.Button(
                "\u2699\ufe0f",
                id=f"{prefix}-settings-btn",
                color="light",
                className="ms-2",
                style={"margin": "5px", "color": "white", "border": "1px solid #ccc"},
                title="Settings",
            )
        )
    if show_info:
        buttons.append(
            dbc.Button(
                "\u2139\ufe0f",
                id=f"{prefix}-info-btn",
                color="light",
                className="ms-2",
                style={"margin": "5px", "color": "white", "border": "1px solid #ccc"},
                title="Info",
            )
        )

    status_span = html.Span(id=f"{prefix}-status", className="ms-2 text-success")

    return dbc.Row(
        [
            dbc.Col(
                buttons + [status_span],
                width=3,
                className="d-flex align-items-center",
            ),
            dbc.Col(
                [
                    dbc.Row(
                        [
                            dbc.Col(
                                dbc.Button(
                                    "<", id=f"{prefix}-prev-btn", color="primary"
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                dcc.Input(
                                    id=f"{prefix}-idx-input",
                                    type="number",
                                    value=0,
                                    min=0,
                                    step=1,
                                    style={"width": "100px"},
                                ),
                                width="auto",
                            ),
                            dbc.Col(
                                dbc.Button(
                                    ">", id=f"{prefix}-next-btn", color="primary"
                                ),
                                width="auto",
                            ),
                        ],
                        justify="center",
                        className="align-items-center",
                    ),
                ],
                width=6,
            ),
            dbc.Col(width=3),
        ],
        className="mt-3 align-items-center",
    )


def create_modal(id, title, children=None, body_id=None):
    """Create a generalized modal."""
    body_content = children if children else html.Div(id=body_id)
    return dbc.Modal(
        [
            dbc.ModalHeader(dbc.ModalTitle(title)),
            dbc.ModalBody(body_content),
            dbc.ModalFooter(
                dbc.Button("Close", id=f"close-{id}", className="ms-auto", n_clicks=0)
            ),
        ],
        id=id,
        is_open=False,
    )


def handle_navigation(trigger_id, current_idx, manual_idx, key_data, prefix):
    """Generalized navigation logic."""
    if not trigger_id:
        return None

    new_idx = current_idx

    if trigger_id == f"{prefix}-prev-btn":
        new_idx = max(0, current_idx - 1)
    elif trigger_id == f"{prefix}-next-btn":
        new_idx = current_idx + 1
    elif trigger_id == f"{prefix}-idx-input":
        new_idx = manual_idx if manual_idx is not None else current_idx
    elif trigger_id == "keyboard-store" and key_data:
        key = key_data.get("key")
        if key in ["ArrowRight", " "]:
            new_idx = current_idx + 1
        elif key == "ArrowLeft":
            new_idx = max(0, current_idx - 1)
        else:
            return None

    if new_idx == current_idx and trigger_id != f"{prefix}-idx-input":
        return None

    return new_idx
