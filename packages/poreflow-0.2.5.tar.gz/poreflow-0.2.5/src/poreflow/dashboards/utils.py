"""Utility functions for Poreflow dashboards."""

import functools
import poreflow as pf


@functools.lru_cache(maxsize=1)
def get_file_handle(path, mode="r+") -> pf.File:
    """
    Get a cached poreflow.io.File handle for the given path.

    Args:
        path (str): Path to the file.
        mode (str): Mode to open the file in.

    Returns:
        poreflow.io.File: The open file handle.
    """
    if not path:
        return None
    return pf.File(path, mode=mode)
