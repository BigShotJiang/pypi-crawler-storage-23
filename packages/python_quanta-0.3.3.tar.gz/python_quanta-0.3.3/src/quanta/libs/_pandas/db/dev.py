# -*- coding: utf-8 -*-
"""
Created on Wed Feb  4 21:30:58 2026

@author: Porco Rosso
"""

