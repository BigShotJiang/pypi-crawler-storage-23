import asyncio
import sys
import os
from datetime import datetime
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.layout import Layout
from rich.table import Table

from omnishield_vibe.core.fuzzer import OmniScanner
from omnishield_vibe.core.protector import Protector
from omnishield_vibe.core.reporter import Reporter

console = Console()

class OmniShieldUI:
    def __init__(self):
        self.layout = Layout()
        self.scanner_logs = []
        self.alert_logs = []
        self.setup_layout()

    def setup_layout(self):
        self.layout.split(
            Layout(name="header", size=3),
            Layout(name="body"),
            Layout(name="footer", size=3)
        )
        self.layout["body"].split_row(
            Layout(name="scanner_view", ratio=2),
            Layout(name="alert_view", ratio=1)
        )

    def generate_header(self, target="None"):
        return Panel(f"[bold green]OMNISHIELD-VIBE v1.0[/bold green] | Target: [cyan]{target}[/cyan]", style="green")

    def add_log(self, event, level="INFO"):
        time_str = datetime.now().strftime("%H:%M:%S")
        log_entry = {"time": time_str, "event": event, "level": level}
        
        self.scanner_logs.append(log_entry)
        # Otomatis masukkan ke panel Alert jika levelnya tinggi
        if level in ["CRITICAL", "ALERT", "WARNING"]:
            self.alert_logs.append(log_entry)

    def make_table(self, logs, title, color):
        table = Table(title=title, style=color, expand=True)
        table.add_column("Time", style="dim", width=10)
        table.add_column("Event", style="bold")
        table.add_column("Lv", width=10)
        for log in logs[-12:]: # Tampilkan 12 log terakhir
            table.add_row(log['time'], log['event'], log['level'])
        return table

ui = OmniShieldUI()

async def run_shield_session():
    while True:
        console.clear()
        console.print(Panel("[bold green]OMNISHIELD MATRIX TERMINAL[/bold green]\n[dim]Ready for System Audit & Protection[/dim]", expand=False))
        
        # 1. Input Target (Dilakukan sebelum Live agar stabil)
        target = console.input("\n[bold yellow]>[/bold yellow] Enter Target Domain/IP (or 'exit'): ")
        
        if target.lower() == 'exit':
            break

        # 2. Inisialisasi Modul
        reporter = Reporter(target)
        fuzzer = OmniScanner(ui.add_log)
        protector = Protector(ui.add_log)
        
        ui.add_log(f"Session started for {target}", "SYSTEM")

        # 3. Live Display & Processing
        with Live(ui.layout, refresh_per_second=4, screen=True):
            ui.layout["header"].update(ui.generate_header(target))
            
            # Jalankan scan sebagai background task
            scan_task = asyncio.create_task(fuzzer.scan_target(target))
            
            while not scan_task.done():
                ui.layout["scanner_view"].update(ui.make_table(ui.scanner_logs, "📡 Network Traffic", "green"))
                ui.layout["alert_view"].update(ui.make_table(ui.alert_logs, "⚠️ Security Alerts", "red"))
                ui.layout["footer"].update(Panel("[blink]SCANNING FOR VULNERABILITIES...[/blink]", style="green"))
                await asyncio.sleep(0.2)
            
            ui.layout["footer"].update(Panel("Scan Complete. Reviewing findings...", style="bold cyan"))
            await asyncio.sleep(1.5)

        # 4. Tahap Tindakan (Setelah UI Live ditutup)
        if ui.alert_logs:
            console.print(f"\n[bold red]DETECTION ALERT:[/bold red] Found {len(ui.alert_logs)} issues on {target}.")
            protector.send_alert_popup("Action Required", f"Vulnerabilities found on {target}")
            
            confirm = console.input("[bold yellow]Execute global protection (Kill Process & Block IP)? (y/n): [/bold yellow]")
            if confirm.lower() == 'y':
                # Mematikan semua port web standar (80, 8080, 3000, 5000, 8000)
                protector.kill_vulnerable_process("ALL")
                ui.add_log("Global lockdown executed.", "SUCCESS")
            else:
                ui.add_log("Action skipped by user.", "WARNING")
        
        console.print(f"\n[green]Audit complete. Report saved in /reports/ folder.[/green]")
        console.input("\nPress Enter to return to main menu...")

if __name__ == "__main__":
    try:
        # Cek hak akses Administrator (Wajib untuk Windows Firewall & Raw Sockets)
        if os.name == 'nt':
            import ctypes
            if not ctypes.windll.shell32.IsUserAnAdmin():
                console.print("[bold red]ERROR: Please run this tool as ADMINISTRATOR.[/bold red]")
                sys.exit()
                
        asyncio.run(run_shield_session())
    except KeyboardInterrupt:
        console.print("\n[bold red]Program terminated.[/bold red]")