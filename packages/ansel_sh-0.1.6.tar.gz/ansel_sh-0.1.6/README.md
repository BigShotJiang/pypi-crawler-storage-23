# Ansel

Demand forecasting API for AIs.

Auditable demand forecasts from raw data for operational planning.

## Install

```bash
uv add ansel-sh
```

## Quick start

```python
from ansel_sh import forecasts

# User-provided data files are auto-discovered
result = forecasts()
```
