"""Storage helpers for file discovery, staging, and materialization."""

from __future__ import annotations

import os
import shutil
from collections.abc import Iterable
from pathlib import Path
from typing import TypeVar

from typing_extensions import override

from pydantic import BaseModel

from .events import Event, event, publish
from .file_definitions import FileDefinition
from .models import File
from .runs import get_current_run_context
from .sandbox import resolve_sandbox_path


@event
class FilesDiscovered(Event, frozen=True):
    """Emitted when files are discovered from a local directory."""

    files: list[File]
    directory: str

    @override
    def message(self) -> str:
        lines = [f"Found {len(self.files)} files in {self.directory}"]
        for file in self.files:
            lines.append(f"  {file.relative_path}")
        return "\n".join(lines)


_DEFAULT_DATA_SUBDIR = "data"


def _resolve_data_dir(data_dir: Path | None) -> Path:
    """Resolve the directory to scan for files.

    When data_dir is given, uses it if it exists and is a directory,
    otherwise falls back to cwd. When None, tries cwd/data first,
    then falls back to cwd.
    """
    resolved_base = (
        Path(data_dir).resolve(strict=False)
        if data_dir is not None
        else Path.cwd() / _DEFAULT_DATA_SUBDIR
    )
    if not resolved_base.exists() or not resolved_base.is_dir():
        resolved_base = Path.cwd()
    return resolved_base


_DATA_EXTENSIONS = {".csv"}


def _is_hidden(path: Path, root: Path) -> bool:
    """Return True if any component of the path relative to root starts with a dot."""
    for part in path.relative_to(root).parts:
        if part.startswith("."):
            return True
    return False


def discover_files(data_dir: Path | None = None) -> list[File]:
    """
    Discover data files from a local directory.

    Scans data_dir (or cwd/data, falling back to cwd) recursively.
    Only includes files with supported data extensions (.csv) and
    skips hidden files/directories (dotfiles).
    Publishes a single FilesDiscovered event with all found files.
    """
    root = _resolve_data_dir(data_dir)

    # Compute display directory relative to cwd
    try:
        rel = root.resolve().relative_to(Path.cwd().resolve())
        directory = f"./{rel}" if str(rel) != "." else "."
    except ValueError:
        directory = str(root)

    collected: list[File] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if _is_hidden(path, root):
            continue
        if path.suffix.lower() not in _DATA_EXTENSIONS:
            continue
        file_obj = File(
            uri=path.resolve().as_uri(),
            name=path.name,
            created_by="user",
            relative_path=str(path.relative_to(root)),
        )
        collected.append(file_obj)
    publish(FilesDiscovered(files=collected, directory=directory))
    return collected


def stage_files_to_sandbox(
    files: Iterable[File],
    sandbox_dir: Path,
    base_root: Path | None = None,
    /,
) -> list[File]:
    """
    Stage files into the sandbox dir for agent execution.

    Copies files into sandbox_dir, preserving their relative directory
    structure. Returns new File objects pointing to the staged paths.

    Args:
        base_root: Directory that relative paths are computed from.
            When None, infers the common ancestor of all file paths.
            For a single file, uses the file's parent directory.

    If a file's description is None, falls back to the stringified
    relative path within the sandbox.
    """
    files_list = list(files)
    resolved_paths = [file_obj.local_path.resolve() for file_obj in files_list]
    if base_root is None:
        base_root = Path(os.path.commonpath([str(path) for path in resolved_paths]))
        if len(resolved_paths) == 1 and base_root == resolved_paths[0]:
            base_root = base_root.parent

    staged_files: list[File] = []
    for file_obj, resolved_path in zip(files_list, resolved_paths, strict=False):
        relative_path = resolved_path.relative_to(base_root)

        staged_path = sandbox_dir / relative_path
        staged_path.parent.mkdir(parents=True, exist_ok=True)
        _ = shutil.copy2(resolved_path, staged_path)
        staged_files.append(
            file_obj.model_copy(
                update={
                    "uri": staged_path.as_uri(),
                    "name": staged_path.name,
                    "description": file_obj.description or str(relative_path),
                }
            )
        )

    return staged_files


_M = TypeVar("_M", bound="BaseModel")


def materialize(
    file_def: FileDefinition[_M],
    sandbox_dir: Path,
    /,
    *,
    agent_name: str | None = None,
) -> File:
    """
    Copy a single agent output file from the sandbox into a durable directory.

    When ``agent_name`` is provided, the file is persisted under
    ``.ansel/<run_id>/<agent_name>/``, making it clear which agent
    produced the artifact. Without it, the file goes directly into
    ``.ansel/<run_id>/``.

    Only agent-modified files should be materialized — read-only context
    files (e.g. a files manifest seeded for a downstream agent) should not.

    Raises FileNotFoundError if the file does not exist in the sandbox.
    """
    target_dir = get_current_run_context().output_dir
    if agent_name:
        target_dir = target_dir / agent_name
    target_dir.mkdir(parents=True, exist_ok=True)
    resolved_sandbox = sandbox_dir.resolve()

    source_path = resolve_sandbox_path(file_def.filename, resolved_sandbox)
    relative_path = source_path.relative_to(resolved_sandbox)

    if not source_path.exists():
        raise FileNotFoundError(f"Output file not found: {source_path}")

    dest_path = target_dir / relative_path
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    _ = shutil.copy2(source_path, dest_path)

    try:
        rel_to_cwd = str(dest_path.resolve().relative_to(Path.cwd().resolve()))
    except ValueError:
        rel_to_cwd = str(dest_path)

    return File(
        uri=dest_path.resolve().as_uri(),
        name=dest_path.name,
        created_by="agent",
        description=file_def.description,
        relative_path=rel_to_cwd,
    )
