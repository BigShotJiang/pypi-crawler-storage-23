"""
Agent: Series Analyst
    Responsible for determining most likely aggregation level from provided files.
    Input: FilesManifest
    Output: FileAggregation

Agent: Series Extractor
    Responsible for populating a series manifest from provided files.
    Input: FilesManifest + empty SeriesManifest (headers only)
    Output: SeriesManifest (filled in)
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..file_schemas import FILES_MANIFEST, SERIES_MANIFEST
from ..models import FileAggregation
from .base import Agent, StructuredAgent


class SeriesAnalystInput(BaseModel):
    """Input for SeriesAnalyst."""

    files_manifest_path: str = FILES_MANIFEST.filename
    target: str = "demand"
    target_description: str = """
        "Consumer demand in ecommerce. "
        "Lagging indicators of realized demand: revenue, units sold. "
        "Demand drivers: price, offers, campaigns, spend, traffic. "
        "Context for understanding unmet demand: inventory levels."
    """


class SeriesAnalystOutput(BaseModel):
    """Output of SeriesAnalyst."""

    aggregation: FileAggregation
    evidence: str


def _format_definitions(definitions: dict[str, str]) -> str:
    return "\n".join(f"- {key}: {value}" for key, value in definitions.items())


_AGGREGATION_DEFS = _format_definitions(
    FileAggregation.value_descriptions(),
)

_ANALYST_SYSTEM_PROMPT = f"""
You are a csv file analyst, tasked with determining the most likely aggregation level for forecasting a target variable based on available data files. An updated files manifest {FILES_MANIFEST.filename} is provided. Read it to know what files to analyze.

Carefully inspect the contents of each file, then consider holistically the aggregation level for forecasting the target variable that has the highest likelihood of being comprehensive and successful. Valid aggregation levels and their definitions provided below:

{_AGGREGATION_DEFS}

Remember in addition to the most likely aggregation level, you must also provide evidence to support your conclusion that is grounded in your analysis of the file contents.
"""

_ANALYST_QUERY_TEMPLATE = """
Determine the most likely aggregation level for forecasting {target} - {target_description}. Use the files manifest at: {files_manifest_path}.
"""


class SeriesAnalyst(StructuredAgent[SeriesAnalystInput, SeriesAnalystOutput]):
    """Agent that infers the likely series aggregation level from files."""

    system_prompt: str = _ANALYST_SYSTEM_PROMPT
    query_template: str = _ANALYST_QUERY_TEMPLATE
    output_model: type[BaseModel] | None = SeriesAnalystOutput


SERIES_ANALYST = SeriesAnalyst()


class SeriesExtractorInput(BaseModel):
    """Input schema for the SeriesExtractor agent."""

    files_manifest_path: str = FILES_MANIFEST.filename
    series_manifest_path: str = SERIES_MANIFEST.filename
    aggregation: FileAggregation
    limit: int | None = Field(default=1, ge=1)


_EXTRACTOR_SYSTEM_PROMPT = f"""
You are a csv file analyst, tasked with extracting series names and identifiers from provided data files. An updated files manifest {FILES_MANIFEST.filename} is provided. Read it to know what files to analyze.

Carefully inspect the contents of each file, then identify the distinct series present at the requested aggregation level. A series manifest {SERIES_MANIFEST.filename} has been prepared with headers: {", ".join(SERIES_MANIFEST.headers)}. It may already contain rows for previously extracted series — do not modify or duplicate those rows. Add new rows for each additional series you discover. Do not modify column headers. The columns are defined as follows:

{_format_definitions(SERIES_MANIFEST.column_descriptions)}
"""

_EXTRACTOR_QUERY_TEMPLATE = """
Extract series names and identifiers at aggregation level: {aggregation}. Limit: {limit}. Use the files manifest at: {files_manifest_path}. Fill in the series manifest at: {series_manifest_path}. Do not duplicate any series already present in the manifest.
"""


class SeriesExtractor(Agent[SeriesExtractorInput]):
    """Agent that populates a series manifest from files."""

    system_prompt: str = _EXTRACTOR_SYSTEM_PROMPT
    query_template: str = _EXTRACTOR_QUERY_TEMPLATE


SERIES_EXTRACTOR = SeriesExtractor()
