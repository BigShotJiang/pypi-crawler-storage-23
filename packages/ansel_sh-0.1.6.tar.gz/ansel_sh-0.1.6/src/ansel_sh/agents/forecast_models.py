"""
Agent: Forecast Model Analyst
    Analyzes user files and produces training + testing time series snapshots.
    Input: Series, forecast settings, FilesManifest, user files,
           empty training + testing snapshot files
    Output: Populated training_snapshot.csv and testing_snapshot.csv (time series)

Agent: Forecast Model Trainer
    Creates model instructions from training data and base instructions.
    Input: Training snapshot, base instruction
    Output: model_instructions.md (written to sandbox)
"""

from __future__ import annotations

from pydantic import BaseModel

from ..file_schemas import (
    BASE_INSTRUCTION,
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TESTING_SNAPSHOT,
    TRAINING_SNAPSHOT,
)
from ..models import FileAggregation
from .base import Agent

# ============================================
# BASE INSTRUCTION
# ============================================

BASE_INSTRUCTION_ENTRY = BASE_INSTRUCTION.row_model(
    name="base-instruction",
    description="Baseline forecast model trainer instruction.",
    content="""\
# Forecast Training Instruction

Create a naive forecast that imitates patterns you can see in the training data.

""",
)

# ============================================
# FORECAST MODEL ANALYST
# ============================================


class ForecastModelAnalystInput(BaseModel):
    """Input for the Forecast Model Analyst agent."""

    # Series context
    series_name: str
    series_aggregation: FileAggregation

    # Forecast settings
    target: str
    interval: str
    horizon: int

    # File references (sandbox-relative paths)
    files_manifest_path: str
    training_snapshot_path: str
    testing_snapshot_path: str
    base_instruction_path: str


_ANALYST_SYSTEM_PROMPT = f"""
You are a data preparation agent. Given a series and user-provided data files,
produce training and testing time series snapshots suitable for forecasting.

{BASE_INSTRUCTION.filename} includes the baseline forecast instructions.

Read the files manifest at {FILES_MANIFEST.filename} to discover available data
files. Analyze and transform the data into clean, consolidated time series
datasets for the specified series.

Write training data to {TRAINING_SNAPSHOT.filename} and holdout/testing data to
{TESTING_SNAPSHOT.filename}. Always use sufficient training data given the desired forecast interval and horizon. Only prepare testing data to be held out if you think there is enough data. Both files have been created with headers already in
place — read the existing headers first, then append rows using those exact
columns. Do not modify or replace the headers.
"""

_ANALYST_QUERY_TEMPLATE = """
Read the base instruction at: {base_instruction_path}

Prepare training and testing data for series: {series_name} (aggregation: {series_aggregation}).
Target: {target}. Interval: {interval}. Horizon: {horizon}.
Use the files manifest at: {files_manifest_path}.
Populate the training snapshot at: {training_snapshot_path}.
Populate the testing snapshot at: {testing_snapshot_path}.
"""


class ForecastModelAnalyst(Agent[ForecastModelAnalystInput]):
    """Agent that analyzes user files and produces training + testing snapshots."""

    system_prompt: str = _ANALYST_SYSTEM_PROMPT
    query_template: str = _ANALYST_QUERY_TEMPLATE


FORECAST_MODEL_ANALYST = ForecastModelAnalyst()


# ============================================
# FORECAST MODEL TRAINER
# ============================================


class ForecastModelTrainerInput(BaseModel):
    """Input for the Forecast Model Trainer agent."""

    # Series context
    series_name: str
    series_aggregation: FileAggregation

    # Forecast settings
    target: str
    interval: str
    horizon: int

    # File references (sandbox-relative paths)
    training_snapshot_path: str = TRAINING_SNAPSHOT.filename
    base_instruction_path: str = BASE_INSTRUCTION.filename


_TRAINER_SYSTEM_PROMPT = f"""
You are a model training agent. Given training data and a base instruction,
create improved forecasting instructions that incorporate patterns learned
from the training data.

Read the base instruction at {BASE_INSTRUCTION.filename} for the baseline approach.
Read the training snapshot to understand data characteristics and patterns.

Edit the existing file at {MODEL_INSTRUCTIONS.filename} — do NOT modify
the YAML frontmatter between `---` delimiters. Write your improved instructions
below the closing `---` delimiter.
"""

_TRAINER_QUERY_TEMPLATE = f"""
Create forecasting instructions for series: {{series_name}} (aggregation: {{series_aggregation}}).
Target: {{target}}. Interval: {{interval}}. Horizon: {{horizon}}.
Read the base instruction at: {{base_instruction_path}}.
Read the training snapshot at: {{training_snapshot_path}}.
Edit the existing file at {MODEL_INSTRUCTIONS.filename} — do not modify the YAML frontmatter
between `---` delimiters, write your instructions below it.
"""


class ForecastModelTrainer(Agent[ForecastModelTrainerInput]):
    """Agent that creates model instructions from training data and base instructions."""

    system_prompt: str = _TRAINER_SYSTEM_PROMPT
    query_template: str = _TRAINER_QUERY_TEMPLATE


FORECAST_MODEL_TRAINER = ForecastModelTrainer()
