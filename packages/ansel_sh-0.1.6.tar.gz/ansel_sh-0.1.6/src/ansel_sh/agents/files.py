"""
Agent: Files Classifier
    Responsible for tagging a provided files with structured metadata.
    Input: FilesManifest (partial)
    Output: FilesManifest (complete)
"""

from __future__ import annotations

from pydantic import BaseModel

from ..file_schemas import FILES_MANIFEST
from .base import Agent


class FilesClassifierInput(BaseModel):
    """
    Input for FilesClassifier.

    Upstream should stage files and provide references for prompting.
    """

    files_manifest_path: str = FILES_MANIFEST.filename


def _format_definitions(definitions: dict[str, str]) -> str:
    return "\n".join(f"- {key}: {value}" for key, value in definitions.items())


def _format_enum_value_definitions(enum_defs: dict[str, dict[str, str]]) -> str:
    return "\n\n".join(
        f"{field}:\n{_format_definitions(values)}" for field, values in enum_defs.items()
    )


_SYSTEM_PROMPT = f"""
You are a csv file analyst, tasked with classifying files based on their content. An updated files manifest {FILES_MANIFEST.filename} is provided. You must read and update it with valid tags for each file.

Each row in {FILES_MANIFEST.filename} is a file to classify. Do not add or remove rows. The columns are: {", ".join(FILES_MANIFEST.headers)}. Do not modify column headers or non-empty cells. The required columns are: {", ".join(FILES_MANIFEST.mutable_fields)}. You must fill in every required column for each file. The columns are defined as follows:

{_format_definitions(FILES_MANIFEST.column_descriptions)}

Carefully inspect the contents of each file to determine the most relevant tags based on the value definitions provided below:

{_format_enum_value_definitions(FILES_MANIFEST.enum_value_definitions)}
"""

_QUERY_TEMPLATE = """
Analyze the files and update each row with valid tags. Use the files manifest at: {files_manifest_path}
"""


class FilesClassifier(Agent[FilesClassifierInput]):
    """Agent that tags provided files."""

    system_prompt: str = _SYSTEM_PROMPT
    query_template: str = _QUERY_TEMPLATE


FILES_CLASSIFIER = FilesClassifier()
