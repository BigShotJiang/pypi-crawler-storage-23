"""
File schema definitions for structured data exchange.

All FileDefinition constants and their row models live here — manifests
(dimension data: series, file metadata) and snapshots (fact data: time
series) alike.  The generic ``FileDefinition`` and CSV adapter machinery
lives in ``file_definitions``; this module defines schema-specific row
models and constants.
"""

from __future__ import annotations

import calendar
from collections.abc import Callable
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Annotated

from pydantic import BaseModel, BeforeValidator, Field, create_model, field_validator

from .file_definitions import FileDefinition, FileFormat
from .models import (
    DateRange,
    File,
    FileAggregation,
    FileFrequency,
    FileRecord,
    Series,
    SeriesIdentifier,
)
from .utils import ForecastInterval

# ============================================
# 1. ROW MODELS
# ============================================


class FilesManifestEntry(BaseModel):
    """Row model for staged files (format-agnostic)."""

    id: str = Field(description="Unique file identifier.")
    name: str = Field(description="File name.")
    path: str = Field(description="File path relative to sandbox.")
    records: list[FileRecord] = Field(
        default_factory=list,
        description="What's been recorded. Use comma-separated values for multiple tags.",
    )
    aggregations: list[FileAggregation] = Field(
        default_factory=list,
        description="At what level data is aggregated. Use comma-separated values for multiple tags.",
    )
    frequencies: list[FileFrequency] = Field(
        default_factory=list,
        description="How often data is recorded. Use comma-separated values for multiple tags.",
    )
    date_min: datetime | None = Field(
        default=None, description="Start of time range covered, in YYYY-MM-DD format."
    )
    date_max: datetime | None = Field(
        default=None, description="End of time range covered, in YYYY-MM-DD format."
    )

    @classmethod
    def from_model(cls, file: File, sandbox_dir: Path) -> FilesManifestEntry:
        """Create an entry from a File domain object.

        Extracts identity and classification fields. The sandbox_dir is
        needed to compute the relative path stored in the manifest.
        """
        relative_path = file.local_path.resolve().relative_to(sandbox_dir.resolve())
        return cls(
            id=file.id,
            name=file.name,
            path=str(relative_path),
            records=file.records,
            aggregations=file.aggregations,
            frequencies=file.frequencies,
            date_min=file.date_range.min if file.date_range else None,
            date_max=file.date_range.max if file.date_range else None,
        )

    def to_model(self, original: File) -> File:
        """Return a File with classification metadata from this entry.

        Requires the original File because the entry is a partial view —
        it carries classification fields (records, aggregations, frequencies,
        dates) but not identity fields like uri, created_by, or sources.
        """
        return File(
            id=original.id,
            uri=original.uri,
            name=original.name,
            created_by=original.created_by,
            description=original.description,
            sources=original.sources,
            created_at=original.created_at,
            records=self.records or [],
            aggregations=self.aggregations or [],
            frequencies=self.frequencies or [],
            date_range=(
                DateRange(min=self.date_min, max=self.date_max)
                if self.date_min and self.date_max
                else None
            ),
        )


class SeriesManifestEntry(BaseModel):
    """Row model for extracted series (format-agnostic)."""

    name: str = Field(description="Human-readable series name (e.g., 'iPhone 16 Pro Max').")
    aggregation: FileAggregation = Field(
        description="Use the aggregation level provided in the query for every row."
    )
    sku: list[str] = Field(
        default_factory=list,
        description="Comma-separated SKU identifiers. Leave blank if unknown.",
    )
    upc: list[str] = Field(
        default_factory=list,
        description="Comma-separated UPC identifiers. Leave blank if unknown.",
    )
    id: list[str] = Field(
        default_factory=list,
        description="Comma-separated internal identifiers. Leave blank if unknown.",
    )
    preferences: list[str] = Field(default_factory=list, description="Leave blank if unknown.")

    @classmethod
    def from_model(cls, series: Series) -> SeriesManifestEntry:
        """Create an entry from a Series domain object.

        Flattens identifiers into typed columns (sku, upc, id).
        """
        return cls(
            name=series.name,
            aggregation=series.aggregation,
            sku=[i.value for i in series.identifiers if i.type == "sku"],
            upc=[i.value for i in series.identifiers if i.type == "upc"],
            id=[i.value for i in series.identifiers if i.type == "id"],
        )

    def to_model(self) -> Series:
        """Return a Series constructed from this entry.

        No original required — the entry contains all fields needed
        to construct a complete Series.
        """
        identifiers = (
            [SeriesIdentifier(type="sku", value=v) for v in self.sku]
            + [SeriesIdentifier(type="upc", value=v) for v in self.upc]
            + [SeriesIdentifier(type="id", value=v) for v in self.id]
        )
        return Series(
            name=self.name,
            aggregation=self.aggregation,
            identifiers=identifiers,
        )


class SnapshotEntry(BaseModel):
    """Row model for time series snapshot data."""

    date: str
    # TODO: Parameterize data columns (orders, inventory) similar to
    # create_forecast_entry — currently hardcoded for initial use cases.
    orders: int | None = None
    inventory: int | None = None

    @field_validator("date")
    @classmethod
    def _validate_iso_date(cls, v: str) -> str:
        try:
            _ = date.fromisoformat(v)
        except (ValueError, TypeError) as e:
            raise ValueError(f"date must be YYYY-MM-DD format, got '{v}'") from e
        return v


class BaseInstructionEntry(BaseModel):
    """Row model for the base instruction markdown file (agent skills format)."""

    name: str
    description: str
    content: str = ""


class ModelInstructionsEntry(BaseModel):
    """Row model for model instructions markdown files."""

    series_id: str
    series_name: str
    content: str = ""


# ============================================
# 2. FILE DEFINITIONS
# ============================================


FILES_MANIFEST = FileDefinition(
    stem="files_manifest",
    description=(
        "System-generated manifest of staged files. Paths are relative to the sandbox_dir."
    ),
    row_model=FilesManifestEntry,
    row_key="id",
    mutable_fields=("records", "aggregations", "frequencies", "date_min", "date_max"),
)

SERIES_MANIFEST = FileDefinition(
    stem="series_manifest",
    description="System-generated manifest of extracted series.",
    row_model=SeriesManifestEntry,
    row_key="name",
    mutable_fields=("name", "aggregation", "sku", "upc", "id", "preferences"),
)

TRAINING_SNAPSHOT = FileDefinition(
    stem="training_snapshot",
    description="Training data time series snapshot.",
    row_model=SnapshotEntry,
    row_key="date",
)

TESTING_SNAPSHOT = FileDefinition(
    stem="testing_snapshot",
    description="Testing/holdout data time series snapshot.",
    row_model=SnapshotEntry,
    row_key="date",
)

BASE_INSTRUCTION = FileDefinition(
    stem="base_instruction",
    description="Base instruction for identifying and splitting training and testing data.",
    row_model=BaseInstructionEntry,
    row_key="name",
    format=FileFormat.markdown,
)

MODEL_INSTRUCTIONS = FileDefinition(
    stem="model_instructions",
    description="Model instructions for the forecaster agent.",
    row_model=ModelInstructionsEntry,
    row_key="series_id",
    format=FileFormat.markdown,
    mutable_fields=("content",),
)

TARGET_SNAPSHOT = FileDefinition(
    stem="target_snapshot",
    description="Target data time series snapshot for forecasting.",
    row_model=SnapshotEntry,
    row_key="date",
)


# ============================================
# 3. SNAPSHOT FACTORY
# ============================================


def _make_interval_date_validator(interval: ForecastInterval) -> Callable[[str], str]:
    """Create a date validator that enforces format constraints per interval.

    - week: any valid YYYY-MM-DD
    - month: YYYY-MM-DD where day is 1st of month
    - quarter: YYYY-MM-DD where day is 1st and month is a quarter start (1, 4, 7, 10)
    """

    def validate(v: str) -> str:
        try:
            d = date.fromisoformat(v)
        except (ValueError, TypeError) as e:
            raise ValueError(f"date must be YYYY-MM-DD format, got '{v}'") from e
        if interval == "month" and d.day != 1:
            raise ValueError(f"monthly date must be 1st of month, got '{v}'")
        if interval == "quarter" and (d.day != 1 or d.month not in (1, 4, 7, 10)):
            raise ValueError(f"quarterly date must be 1st of quarter, got '{v}'")
        return v

    return validate


def create_snapshot(
    interval: ForecastInterval,
    stem: str,
    description: str,
) -> FileDefinition[BaseModel]:
    """Create an interval-aware snapshot FileDefinition.

    Uses the same columns as SnapshotEntry but with a date validator
    parameterized by the forecast interval.
    """
    validator = _make_interval_date_validator(interval)
    IntervalDate = Annotated[str, BeforeValidator(validator)]

    entry_model = create_model(
        "SnapshotEntry",
        date=(IntervalDate, ...),  # pyright: ignore[reportAny]
        orders=(int | None, None),  # pyright: ignore[reportAny]
        inventory=(int | None, None),  # pyright: ignore[reportAny]
    )
    return FileDefinition(
        stem=stem,
        description=description,
        row_model=entry_model,
        row_key="date",
    )


# ============================================
# 4. FORECAST FACTORIES & HELPERS
# ============================================


def create_forecast_entry(target: str, interval: ForecastInterval) -> type[BaseModel]:
    """Create a row model for forecast results parameterized by target column.

    When target="demand", produces a model with fields: date, demand.
    When target="orders", produces a model with fields: date, orders.

    Date validation enforces format constraints per interval (see
    ``_make_interval_date_validator``).
    """
    validator = _make_interval_date_validator(interval)
    IntervalDate = Annotated[str, BeforeValidator(validator)]

    field_definitions = {
        "date": (IntervalDate, ...),
        target: (int | None, None),
    }
    return create_model(  # pyright: ignore[reportCallIssue,reportUnknownVariableType]
        "ForecastEntry",
        **field_definitions,  # pyright: ignore[reportArgumentType]
    )


def create_forecast_result(target: str, interval: ForecastInterval) -> FileDefinition[BaseModel]:
    """Create a FileDefinition for forecast results parameterized by target.

    The target column is the only mutable field — dates are pre-filled
    and immutable.
    """
    entry_model = create_forecast_entry(target, interval)
    return FileDefinition(
        stem="forecast_result",
        description="Forecast result with predicted values.",
        row_model=entry_model,
        row_key="date",
        mutable_fields=(target,),
    )


def generate_forecast_dates(
    last_date: str,
    interval: ForecastInterval,
    horizon: int,
) -> list[str]:
    """Generate future date strings from the last observed date.

    Args:
        last_date: Last observed date as YYYY-MM-DD string.
        interval: Forecast interval (week, month, quarter).
        horizon: Number of periods to generate.

    Returns:
        List of YYYY-MM-DD date strings.
    """
    d = date.fromisoformat(last_date)
    dates: list[str] = []

    for _ in range(horizon):
        if interval == "week":
            d = date(d.year, d.month, d.day) + timedelta(weeks=1)
        elif interval == "month":
            # Advance by one month, clamping to last day of month
            if d.month == 12:
                year, month = d.year + 1, 1
            else:
                year, month = d.year, d.month + 1
            last_day = calendar.monthrange(year, month)[1]
            d = date(year, month, min(d.day, last_day))
        elif interval == "quarter":
            # Advance by 3 months
            month = d.month + 3
            year = d.year
            while month > 12:
                month -= 12
                year += 1
            last_day = calendar.monthrange(year, month)[1]
            d = date(year, month, min(d.day, last_day))
        dates.append(d.isoformat())

    return dates
