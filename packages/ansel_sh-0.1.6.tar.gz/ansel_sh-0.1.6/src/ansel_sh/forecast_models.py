"""
ForecastModel domain module.

Sections:
1. ForecastModel
2. Domain Events
3. Agent Runners
4. Public Entrypoint
5. Resolution
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Protocol

from typing_extensions import override

from claude_agent_sdk import ResultMessage
from pydantic import BaseModel, Field

from .agents import run_agent
from .agents.forecast_models import (
    BASE_INSTRUCTION_ENTRY,
    FORECAST_MODEL_ANALYST,
    FORECAST_MODEL_TRAINER,
    ForecastModelAnalystInput,
    ForecastModelTrainerInput,
)
from .agents.observability import observe
from .events import Event, event, log_events, publish
from .file_schemas import (
    BASE_INSTRUCTION,
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TESTING_SNAPSHOT,
    TRAINING_SNAPSHOT,
    FilesManifestEntry,
    ModelInstructionsEntry,
    create_snapshot,
)
from .files import FileResult, resolve_files
from .models import File, ForecastSettings, Series
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .series import resolve_series, resolve_series_preview
from .storage import materialize, stage_files_to_sandbox
from .utils import generate_id, pool, utc_now

# ============================================
# 1. FORECAST MODEL
# ============================================


class ForecastModel(BaseModel):
    """
    Trained forecasting model.

    Created by running the model trainer agent in two steps:
    1. Data preparation — populates training + testing time series snapshots.
    2. Model configuration — produces an instructions file and evidence.

    Attributes:
        id: Unique identifier (mdl_xxx).
        series_id: ID of the series this model is trained for.
        settings: Forecast settings used for training.
        instructions: Model instructions file produced by step 2.
        trained: Training data snapshot (time series CSV).
        tested: Testing/holdout data snapshot (time series CSV).
        status: Current model status.
        created_at: When this model was created.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("mdl"))

    # Series reference
    series_id: str

    settings: ForecastSettings

    # Outputs
    instructions: File
    trained: File
    tested: File

    status: Literal["training", "ready"] = "training"

    # Time
    created_at: datetime = Field(default_factory=utc_now)


# ============================================
# 2. DOMAIN EVENTS
# ============================================


@event
class ModelAnalysisStarted(Event, frozen=True):
    files: list[File]
    series: list[Series]

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Finding training data for {self.series[0].name}"
        agg = self.series[0].aggregation
        return f"Finding training data for {len(self.series)} {agg}s"


@event
class ModelAnalysisCompleted(Event, frozen=True):
    files: list[File]
    series: list[Series]

    @override
    def message(self) -> str:
        return ""


@event
class ModelAnalysisFailed(Event, frozen=True):
    files: list[File]
    series: list[Series]
    error: str

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Failed to find training data for {self.series[0].name}: {self.error}"
        return f"Training data preparation failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


@event
class ModelTrainingStarted(Event, frozen=True):
    series: list[Series]

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Training model for {self.series[0].name}"
        agg = self.series[0].aggregation
        return f"Training models for {len(self.series)} {agg}s"


@event
class ModelTrainingCompleted(Event, frozen=True):
    models: list[ForecastModel]
    series: list[Series]
    preview: bool = False

    @override
    def message(self) -> str:
        if self.preview:
            return ""
        return f"Trained {len(self.models)} models"


@event
class ModelTrainingFailed(Event, frozen=True):
    series: list[Series]
    error: str

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Model training failed for {self.series[0].name}: {self.error}"
        return f"Model training failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 3. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class ForecastModelAnalystResult:
    """Output from a forecast model analyst run."""

    training: FileResult
    testing: FileResult
    result: ResultMessage


@dataclass(frozen=True)
class ForecastModelTrainerResult:
    """Output from a forecast model trainer run."""

    instructions: FileResult
    result: ResultMessage


class ForecastModelAnalystRunner(Protocol):
    def __call__(
        self,
        series: Series,
        files: list[File],
        settings: ForecastSettings,
        /,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[ForecastModelAnalystResult]: ...


class ForecastModelTrainerRunner(Protocol):
    def __call__(
        self,
        series: Series,
        training_file: File,
        settings: ForecastSettings,
        /,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[ForecastModelTrainerResult]: ...


@observe(name="forecast_model_analyst")
async def _run_forecast_model_analyst(
    series: Series,
    files: list[File],
    settings: ForecastSettings,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> ForecastModelAnalystResult:
    """Run step 1: populate training + testing snapshots from user files.

    The agent receives the files manifest, user files, the base instruction,
    and empty training/testing snapshot CSVs in the sandbox. It reads the
    base instruction for context on how to split data, then populates both
    snapshot files.
    """
    if not files:
        raise ValueError("files required")

    # Create interval-aware snapshot definitions for date format validation.
    training_snapshot = create_snapshot(
        settings.interval, TRAINING_SNAPSHOT.stem, TRAINING_SNAPSHOT.description
    )
    testing_snapshot = create_snapshot(
        settings.interval, TESTING_SNAPSHOT.stem, TESTING_SNAPSHOT.description
    )

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        manifest_entries = [FilesManifestEntry.from_model(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, manifest_entries)

        # Write empty snapshot files (headers only) for the agent to populate.
        training_snapshot_path = training_snapshot.dump(sandbox_dir, [])
        testing_snapshot_path = testing_snapshot.dump(sandbox_dir, [])

        # Write the base instruction so the agent can reference it.
        base_instruction_path = BASE_INSTRUCTION.dump(sandbox_dir, [BASE_INSTRUCTION_ENTRY])

        agent_input = ForecastModelAnalystInput(
            series_name=series.name,
            series_aggregation=series.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            files_manifest_path=files_manifest_path,
            training_snapshot_path=training_snapshot_path,
            testing_snapshot_path=testing_snapshot_path,
            base_instruction_path=base_instruction_path,
        )

        result_message = await run_agent(
            FORECAST_MODEL_ANALYST, agent_input, sandbox_dir, model=model, trace=trace
        )

        # Validate agent output in sandbox before materialization
        training_validation_result = training_snapshot.validate_file(sandbox_dir)
        testing_validation_result = testing_snapshot.validate_file(sandbox_dir)

        # Materialize agent outputs
        training_file = materialize(
            training_snapshot, sandbox_dir, agent_name="forecast_model_analyst"
        )
        testing_file = materialize(
            testing_snapshot, sandbox_dir, agent_name="forecast_model_analyst"
        )

        return ForecastModelAnalystResult(
            training=FileResult(file=training_file, issues=training_validation_result.issues),
            testing=FileResult(file=testing_file, issues=testing_validation_result.issues),
            result=result_message,
        )


@observe(name="forecast_model_trainer")
async def _run_forecast_model_trainer(
    series: Series,
    training_file: File,
    settings: ForecastSettings,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> ForecastModelTrainerResult:
    """Run step 2: create model instructions from training data and base instruction.

    The agent receives the training snapshot (read-only context), the base
    instruction, and an instructions template (mutable). It writes improved
    instructions based on patterns learned from the training data.
    """
    # Load training entries from the materialized analyst output.
    training_entries = TRAINING_SNAPSHOT.load(training_file.local_path.parent)

    with create_agent_sandbox_dir() as sandbox_dir:
        # Dump training snapshot into sandbox (read-only context).
        training_snapshot_path = TRAINING_SNAPSHOT.dump(sandbox_dir, training_entries)

        # Write the base instruction so the agent can reference it.
        base_instruction_path = BASE_INSTRUCTION.dump(sandbox_dir, [BASE_INSTRUCTION_ENTRY])

        # Dump a template instructions file with immutable frontmatter.
        template_entry = ModelInstructionsEntry(
            series_id=series.id,
            series_name=series.name,
        )
        _ = MODEL_INSTRUCTIONS.dump(sandbox_dir, [template_entry])
        immutable_values = MODEL_INSTRUCTIONS.immutable_row_values([template_entry])

        agent_input = ForecastModelTrainerInput(
            series_name=series.name,
            series_aggregation=series.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            training_snapshot_path=training_snapshot_path,
            base_instruction_path=base_instruction_path,
        )

        result_message = await run_agent(
            FORECAST_MODEL_TRAINER, agent_input, sandbox_dir, model=model, trace=trace
        )

        # Validate the instructions file the agent wrote.
        instructions_validation_result = MODEL_INSTRUCTIONS.validate_file(
            sandbox_dir, immutable_values=immutable_values
        )

        # Materialize the instructions file.
        instructions_file = materialize(
            MODEL_INSTRUCTIONS, sandbox_dir, agent_name="forecast_model_trainer"
        )

        return ForecastModelTrainerResult(
            instructions=FileResult(
                file=instructions_file, issues=instructions_validation_result.issues
            ),
            result=result_message,
        )


# ============================================
# 4. PUBLIC ENTRYPOINT
# ============================================


@log_events
async def forecast_models(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
    *,
    model: str | None = None,
    trace: bool = True,
) -> list[ForecastModel]:
    """
    Public entrypoint: train forecast models from files and series.

    Files are auto-discovered and classified when omitted. Series
    are auto-extracted when omitted (with confirmation of the first
    series before continuing). Each series produces one trained model
    via a two-step pipeline: data preparation → model configuration.

    Two dispatch paths:
    - Preview (no series): extract 1 → confirm → parallel preview
      model training + remaining extraction → train remaining.
    - Direct (series provided): resolve all series → train all
      models in parallel.

    .. note::
        Currently batch — all models are returned together when the
        slowest series finishes. TODO: yield models as each completes
        via ``asyncio.as_completed`` + ``AsyncIterator`` so callers
        can start downstream work immediately.

    Args:
        files: Input data files. Accepts a single File, a list, or None
            to auto-discover from the default data directory.
        series: Seed series. Accepts a single Series, a list, or None
            to auto-extract from files.
        model: LLM model override for agent calls.
        trace: Whether to enable tracing for agent calls.

    Returns:
        Trained forecast models (failures are published, not raised).
    """
    with with_run_context():
        # Discover (if None) and classify (if unclassified)
        input_files = [files] if isinstance(files, File) else files
        classified_files = await resolve_files(input_files, model=model, trace=trace)

        # Normalize series
        input_series = [series] if isinstance(series, Series) else series

        # Direct: series provided → resolve all, then train all in parallel
        if input_series is not None:
            resolved = await resolve_series(
                classified_files, input_series, model=model, trace=trace
            )
            return await resolve_forecast_models(
                classified_files, resolved, model=model, trace=trace
            )

        # Preview: extract 1 series, confirm, then overlap preview training + remaining extraction
        preview = await resolve_series_preview(classified_files, model=model, trace=trace)
        if not preview:
            return []

        preview_series = preview[0]

        # Overlap: train preview model while extracting remaining series
        preview_model, all_series = await asyncio.gather(
            resolve_forecast_model(classified_files, preview_series, model=model, trace=trace),
            resolve_series(classified_files, preview, model=model, trace=trace),
        )

        remaining = [s for s in all_series if s.id != preview_series.id]
        if not remaining:
            return [preview_model]

        remaining_models = await resolve_forecast_models(
            classified_files, remaining, model=model, trace=trace
        )
        return [preview_model] + remaining_models


# ============================================
# 5. RESOLUTION
# ============================================


async def resolve_forecast_models(
    files: list[File],
    series: list[Series],
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> list[ForecastModel]:
    """Orchestrate model training for multiple series with bounded concurrency.

    Runs ``resolve_forecast_model`` for each series via ``pool``, collecting
    partial successes. Emits batch-level bookend events
    (``ModelTrainingStarted``/``Completed``) and publishes
    ``ModelTrainingFailed`` for individual failures. Per-series events
    from ``resolve_forecast_model`` are suppressed.

    Args:
        files: Classified files to use for training.
        series: Series to train models for.

    Returns:
        Successfully trained models (failures are published, not raised).
    """
    publish(ModelTrainingStarted(series=series))

    results = await pool(
        series,
        lambda s: resolve_forecast_model(files, s, emit_events=False, model=model, trace=trace),
    )

    models: list[ForecastModel] = []
    for s, result in zip(series, results):
        if isinstance(result, BaseException):
            publish(ModelTrainingFailed(series=[s], error=str(result)))
        else:
            models.append(result)

    publish(ModelTrainingCompleted(models=models, series=series))
    return models


async def resolve_forecast_model(
    files: list[File],
    series: Series,
    analyst_runner: ForecastModelAnalystRunner = _run_forecast_model_analyst,
    trainer_runner: ForecastModelTrainerRunner = _run_forecast_model_trainer,
    /,
    *,
    emit_events: bool = True,
    model: str | None = None,
    trace: bool = True,
) -> ForecastModel:
    """Train a single forecast model by running two agents sequentially.

    Step 1 (analyst): prepares training + testing data snapshots from files.
    Step 2 (trainer): produces model instructions from the training data.

    Runner arguments allow test doubles without live agent calls.

    Args:
        files: Classified files to use for training.
        series: The series to train a model for.
        analyst_runner: Runs step 1 — data preparation.
        trainer_runner: Runs step 2 — model configuration.

    Returns:
        Trained ForecastModel.

    Raises:
        ValueError: If files is empty.
    """
    # TODO: accept optional ForecastSettings param so callers can configure
    # target, interval, horizon instead of using defaults.
    settings = ForecastSettings()

    if not files:
        raise ValueError("files required")

    if emit_events:
        publish(ModelAnalysisStarted(files=files, series=[series]))

    # Analyst: data preparation — training + testing snapshots
    analyst_result = await analyst_runner(series, files, settings, model=model, trace=trace)
    training_file = analyst_result.training.file
    # TODO: testing snapshot is produced but unused — decide if it should be
    # used for backtesting/evaluation, passed to a separate scoring agent,
    # or removed from the analyst output entirely.
    testing_file = analyst_result.testing.file
    if emit_events:
        publish(ModelAnalysisCompleted(files=files, series=[series]))

    # Trainer: model configuration — instructions from training data + base instruction
    if emit_events:
        publish(ModelTrainingStarted(series=[series]))
    trainer_result = await trainer_runner(series, training_file, settings, model=model, trace=trace)
    forecast_model = ForecastModel(
        series_id=series.id,
        settings=settings,
        instructions=trainer_result.instructions.file,
        trained=training_file,
        tested=testing_file,
        status="ready",
    )

    if emit_events:
        publish(ModelTrainingCompleted(models=[forecast_model], series=[series]))
    return forecast_model
