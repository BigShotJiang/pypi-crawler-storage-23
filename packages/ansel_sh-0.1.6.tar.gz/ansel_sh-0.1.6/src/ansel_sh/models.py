"""
Shared value objects and domain models.

Currently holds the base File and Series models and related types so storage
and higher-level modules can depend on them without circular imports.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Literal
from urllib.parse import unquote, urlparse

from typing_extensions import override

from pydantic import BaseModel, Field

from .utils import (
    DEFAULT_FORECAST_INTERVAL,
    DEFAULT_HORIZON,
    DEFAULT_TARGET,
    ForecastInterval,
    generate_id,
    utc_now,
)


class DescribedStrEnum(str, Enum):
    """str/Enum hybrid where each member carries a human-readable description.

    Use this instead of plain Enum when valid values need to be
    explained to agents or end users (e.g. in prompt construction).
    ``FileDefinition.enum_value_definitions`` automatically discovers
    fields typed with a ``DescribedStrEnum`` subclass and exposes their
    descriptions — plain enums are ignored.

    Define members as ``(value, description)`` tuples::

        class FileRecord(DescribedStrEnum):
            orders = ("orders", "Purchase orders representing requested demand.")
            sales = ("sales", "Completed sales transactions.")
    """

    description: str

    def __new__(cls, value: str, description: str) -> DescribedStrEnum:
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj

    @override
    def __str__(self) -> str:
        return str(self._value_)  # pyright: ignore[reportAny]

    @classmethod
    def value_descriptions(cls) -> dict[str, str]:
        """Return ``{value: description}`` for every member."""
        return {str(m._value_): m.description for m in cls}  # pyright: ignore[reportAny]


class FileRecord(DescribedStrEnum):
    orders = ("orders", "Purchase orders / order-intent records representing requested demand.")
    sales = ("sales", "Completed sales transactions representing realized demand.")
    inventory = ("inventory", "Stock position snapshots describing supply availability.")
    products = ("products", "Product catalog or data describing item attributes.")


class FileAggregation(DescribedStrEnum):
    variant = ("variant", "SKU-level grain (color/size/capacity, etc.).")
    product = ("product", "Product-model grain (SKUs combined).")
    family = ("family", "Product-family grain (related models grouped).")
    store = ("store", "Location/channel dimension (store, region, channel).")


class FileFrequency(DescribedStrEnum):
    day = ("day", "One record per day.")
    week = ("week", "One record per week.")
    month = ("month", "One record per month.")
    quarter = ("quarter", "One record per quarter.")


class DateRange(BaseModel, frozen=True):
    """Time range covered by file data."""

    min: datetime
    max: datetime


# ============================================
# FILE DOMAIN MODEL
# ============================================


class File(BaseModel):
    """
    User provided data and AI-generated snapshots.

    Files are the medium through which agents communicate.
    User uploads become files. Agent outputs become files.
    Every file tracks its origin for lineage.

    Attributes:
            id: Unique identifier (fil_xxx).
            uri: Resource identifier (file://, s3://, https://).
            name: File name including extension.
            created_by: Who created the file (user upload or agent output).
            description: Human-readable description for prompts.
            sources: Parent file IDs if this file was derived from others.
            created_at: When this file was registered.

            Classification (discovered by Files Classifier agent):
            records: What's been recorded (orders, sales, inventory).
            aggregations: At what level data is aggregated (variant, product, family, store).
            frequencies: How often data is recorded (day, week, month, quarter).
            date_range: Time range covered by file data.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("fil"))
    uri: str
    name: str
    created_by: Literal["user", "agent", "system"]
    description: str | None = None
    relative_path: str | None = None

    # Lineage
    sources: list[str] = Field(default_factory=list)

    # Classification (optional, set by Files Classifier agent)
    records: list[FileRecord] = Field(default_factory=list)
    aggregations: list[FileAggregation] = Field(default_factory=list)
    frequencies: list[FileFrequency] = Field(default_factory=list)
    date_range: DateRange | None = None

    # Time
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @property
    def local_path(self) -> Path:
        """Parse a file:// URI into a local filesystem Path.

        Raises ValueError for non-file:// URIs.
        """
        parsed = urlparse(self.uri)
        if parsed.scheme != "file":
            raise ValueError(f"Cannot resolve non-local URI to path: {self.uri}")
        return Path(unquote(parsed.path))

    @property
    def is_classified(self) -> bool:
        """Return True when any classification metadata is present."""
        return bool(
            self.records or self.aggregations or self.frequencies or self.date_range is not None
        )


# ============================================
# SERIES DOMAIN MODEL
# ============================================

IdentifierType = Literal["sku", "upc", "id"]


class SeriesIdentifier(BaseModel, frozen=True):
    """
    Machine-readable identifier for a series.

    Attributes:
            type: Kind of identifier (sku, upc, internal, external).
            value: The actual identifier string.
    """

    type: IdentifierType
    value: str


class Series(BaseModel):
    """
    The thing you forecast — a product, variant, family, or store.

    Series are discovered by agents from file metadata, or created manually.
    Each series belongs to one aggregation level and can have multiple
    machine-readable identifiers for cross-system references.

    Attributes:
            id: Unique identifier (ser_xxx).
            name: Human-readable name (e.g., "iPhone 16 Pro Max").
            aggregation: Granularity level (variant, product, family, store).
            identifiers: Machine-readable IDs (SKU, UPC, etc.).
            created_at: When this series was created.
            updated_at: When this series was last modified.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("ser"))
    name: str
    aggregation: FileAggregation

    # References
    identifiers: list[SeriesIdentifier] = Field(default_factory=list)

    @property
    def identifiers_summary(self) -> str:
        """Flat display of all identifiers, e.g. 'sku: ABC, upc: 123'."""
        return ", ".join(f"{i.type}: {i.value}" for i in self.identifiers)

    # Lineage
    # TODO: Revisit lineage design — not sure if IDs are the right approach
    # source_file_ids: list[str] = Field(default_factory=list)

    # Time
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


# ============================================
# FORECAST SETTINGS
# ============================================


class ForecastSettings(BaseModel, frozen=True):
    """Immutable forecast configuration shared across model and forecast domains."""

    target: str = DEFAULT_TARGET
    interval: ForecastInterval = DEFAULT_FORECAST_INTERVAL
    horizon: int = Field(default=DEFAULT_HORIZON, ge=1, le=60)
