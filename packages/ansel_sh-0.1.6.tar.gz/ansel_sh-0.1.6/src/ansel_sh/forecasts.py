"""
Forecast domain module.

Sections:
1. Forecast
2. Domain Events
3. Agent Runners
4. Public Entrypoint
5. Resolution
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from datetime import date, datetime
from typing import Protocol

from typing_extensions import override

from claude_agent_sdk import ResultMessage
from pydantic import BaseModel, Field

from .agents import run_agent
from .agents.forecasts import (
    FORECAST_TARGET_ANALYST,
    FORECASTER,
    ForecasterInput,
    ForecastTargetAnalystInput,
)
from .agents.observability import observe
from .events import Event, event, log_events, publish
from .file_schemas import (
    FILES_MANIFEST,
    MODEL_INSTRUCTIONS,
    TARGET_SNAPSHOT,
    FilesManifestEntry,
    create_forecast_result,
    create_snapshot,
    generate_forecast_dates,
)
from .files import FileResult, resolve_files
from .forecast_models import ForecastModel, resolve_forecast_model
from .models import File, ForecastSettings, Series
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .series import resolve_series, resolve_series_preview
from .storage import materialize, stage_files_to_sandbox
from .ui import require_confirmation
from .utils import generate_id, pool, utc_now

# ============================================
# 1. FORECAST
# ============================================


class ForecastItem(BaseModel, frozen=True):
    """Individual forecast data point."""

    date: str
    value: int


class Forecast(BaseModel):
    """
    Generated forecast.

    Created by running a two-agent pipeline:
    1. Target analyst — extracts recent target data from user files.
    2. Forecaster — fills in predicted values using model instructions.

    Attributes:
        id: Unique identifier (fct_xxx).
        series_id: ID of the series being forecasted.
        model_id: ID of the model used for forecasting.
        settings: Forecast settings used for generation.
        target_data: Target data snapshot file produced by step 1.
        result: Forecast result file produced by step 2.
        items: Individual forecast data points.
        created_at: When this forecast was created.
    """

    # Identity
    id: str = Field(default_factory=lambda: generate_id("fct"))

    # References
    series_id: str
    model_id: str

    settings: ForecastSettings

    # Outputs
    target_data: File
    result: File
    items: list[ForecastItem] = Field(default_factory=list)

    # Time
    created_at: datetime = Field(default_factory=utc_now)


# ============================================
# 2. DOMAIN EVENTS
# ============================================


@event
class ForecastStarted(Event, frozen=True):
    series: list[Series]

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Forecasting {self.series[0].name}"
        agg = self.series[0].aggregation
        return f"Forecasting {len(self.series)} {agg}s"


@event
class ForecastCompleted(Event, frozen=True):
    forecasts: list[Forecast]
    series: list[Series]
    preview: bool = False

    @override
    def message(self) -> str:
        if self.preview:
            return ""
        return f"Generated {len(self.forecasts)} forecasts"


@event
class ForecastFailed(Event, frozen=True):
    series: list[Series]
    error: str

    @override
    def message(self) -> str:
        if len(self.series) == 1:
            return f"Forecast failed for {self.series[0].name}: {self.error}"
        return f"Forecast failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 3. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class ForecastTargetAnalystResult:
    """Output from a forecast target analyst run."""

    target_data: FileResult
    result: ResultMessage


@dataclass(frozen=True)
class ForecasterResult:
    """Output from a forecaster run."""

    forecast: FileResult
    items: list[ForecastItem]
    result: ResultMessage


class ForecastTargetAnalystRunner(Protocol):
    def __call__(
        self,
        series: Series,
        files: list[File],
        settings: ForecastSettings,
        /,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[ForecastTargetAnalystResult]: ...


class ForecasterRunner(Protocol):
    def __call__(
        self,
        series: Series,
        forecast_model: ForecastModel,
        target_data_file: File,
        settings: ForecastSettings,
        /,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[ForecasterResult]: ...


@observe(name="forecast_target_analyst")
async def _run_forecast_target_analyst(
    series: Series,
    files: list[File],
    settings: ForecastSettings,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> ForecastTargetAnalystResult:
    """Run step 1: extract target data from user files.

    The agent receives the files manifest, user files, and an empty target
    snapshot CSV in the sandbox. It reads the files and populates the target
    snapshot with all available data (no holdout).
    """
    if not files:
        raise ValueError("files required")

    # Create interval-aware snapshot definition for date format validation.
    target_snapshot = create_snapshot(
        settings.interval, TARGET_SNAPSHOT.stem, TARGET_SNAPSHOT.description
    )

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        manifest_entries = [FilesManifestEntry.from_model(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, manifest_entries)

        # Write empty target snapshot (headers only) for the agent to populate.
        target_snapshot_path = target_snapshot.dump(sandbox_dir, [])

        agent_input = ForecastTargetAnalystInput(
            series_name=series.name,
            series_aggregation=series.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            files_manifest_path=files_manifest_path,
            target_snapshot_path=target_snapshot_path,
        )

        result_message = await run_agent(
            FORECAST_TARGET_ANALYST, agent_input, sandbox_dir, model=model, trace=trace
        )

        # Validate agent output in sandbox before materialization
        target_validation_result = target_snapshot.validate_file(sandbox_dir)

        # Materialize agent output
        target_data_file = materialize(
            target_snapshot, sandbox_dir, agent_name="forecast_target_analyst"
        )

        return ForecastTargetAnalystResult(
            target_data=FileResult(file=target_data_file, issues=target_validation_result.issues),
            result=result_message,
        )


@observe(name="forecaster")
async def _run_forecaster(
    series: Series,
    forecast_model: ForecastModel,
    target_data_file: File,
    settings: ForecastSettings,
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> ForecasterResult:
    """Run step 2: fill in forecast values from model instructions + target data.

    The agent receives the target snapshot (read-only context), model
    instructions (read-only context), and a pre-staged forecast template with
    dates pre-filled and target column set to None. It fills in the target
    column values.
    """
    # Load target entries from the materialized analyst output.
    target_entries = TARGET_SNAPSHOT.load(target_data_file.local_path.parent)
    if not target_entries:
        raise ValueError("target snapshot is empty")

    # Find last date and generate forecast dates.
    last_date = target_entries[-1].date
    forecast_dates = generate_forecast_dates(last_date, settings.interval, settings.horizon)

    # Create the parameterized forecast result definition.
    forecast_result_def = create_forecast_result(settings.target, settings.interval)
    forecast_entry_model = forecast_result_def.row_model

    # Load model instructions from materialized trainer output.
    model_instructions_entries = MODEL_INSTRUCTIONS.load(
        forecast_model.instructions.local_path.parent
    )

    with create_agent_sandbox_dir() as sandbox_dir:
        # Dump target snapshot into sandbox (read-only context).
        target_snapshot_path = TARGET_SNAPSHOT.dump(sandbox_dir, target_entries)

        # Dump model instructions into sandbox (read-only context).
        _ = MODEL_INSTRUCTIONS.dump(sandbox_dir, model_instructions_entries)

        # Dump pre-filled forecast template (dates filled, target=None).
        template_rows = [
            forecast_entry_model.model_validate({"date": d, settings.target: None})
            for d in forecast_dates
        ]
        forecast_result_path = forecast_result_def.dump(sandbox_dir, template_rows)

        # Capture immutable date values for validation.
        immutable_values = forecast_result_def.immutable_row_values(template_rows)

        agent_input = ForecasterInput(
            series_name=series.name,
            series_aggregation=series.aggregation,
            target=settings.target,
            interval=settings.interval,
            horizon=settings.horizon,
            target_snapshot_path=target_snapshot_path,
            model_instructions_path=MODEL_INSTRUCTIONS.filename,
            forecast_result_path=forecast_result_path,
        )

        result_message = await run_agent(
            FORECASTER, agent_input, sandbox_dir, model=model, trace=trace
        )

        # Validate the forecast result file.
        forecast_validation_result = forecast_result_def.validate_file(
            sandbox_dir, immutable_values=immutable_values
        )

        # Materialize the forecast result file.
        forecast_file = materialize(forecast_result_def, sandbox_dir, agent_name="forecaster")

        # Parse entries and convert to ForecastItems.
        result_entries = forecast_result_def.load(sandbox_dir)
        items: list[ForecastItem] = []
        for entry in result_entries:
            data: dict[str, object] = dict(entry.model_dump())
            target_value = data.get(settings.target)
            if isinstance(target_value, (int, float)):
                items.append(ForecastItem(date=str(data["date"]), value=int(target_value)))

        return ForecasterResult(
            forecast=FileResult(file=forecast_file, issues=forecast_validation_result.issues),
            items=items,
            result=result_message,
        )


# ============================================
# 4. PUBLIC ENTRYPOINT
# ============================================


@log_events
async def forecasts(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
    *,
    data_dir: str | None = None,
    model: str | None = None,
    trace: bool = True,
) -> list[Forecast]:
    """
    Public entrypoint: generate forecasts from files and/or series.

    Files are auto-discovered and classified when omitted. Series
    are auto-extracted when omitted (with confirmation of the first
    series before continuing). Each series flows through model
    training → forecasting to produce the final result.

    Two dispatch paths:
    - Preview (no series): extract 1 → confirm series → parallel
      preview model training + remaining extraction → preview
      forecast → confirm forecast → train + forecast remaining.
    - Direct (series provided): resolve all series → per-series
      pipelines in parallel.

    .. note::
        TODO: accept optional ``models`` parameter (pre-trained
        ForecastModels) to skip model training, and optional
        ``settings`` (ForecastSettings) to configure target,
        interval, and horizon.

    Args:
        files: Input data files. Accepts a single File, a list, or None
            to auto-discover from the default data directory.
        series: Seed series. Accepts a single Series, a list, or None
            to auto-extract from files.
        data_dir: Directory to scan for files during auto-discovery.
        model: LLM model override for agent calls.
        trace: Whether to enable tracing for agent calls.

    Returns:
        Generated forecasts (failures are published, not raised).
    """
    from pathlib import Path

    resolved_dir = Path(data_dir) if data_dir is not None else None
    with with_run_context():
        # Normalize inputs
        input_files = [files] if isinstance(files, File) else files
        input_series = [series] if isinstance(series, Series) else series

        # Discover (if None) and classify (if unclassified)
        classified_files = await resolve_files(
            input_files, data_dir=resolved_dir, model=model, trace=trace
        )

        # Direct: series provided → resolve all, then per-series pipelines
        if input_series is not None:
            resolved = await resolve_series(
                classified_files, input_series, model=model, trace=trace
            )
            return await resolve_models_and_forecasts(
                classified_files, resolved, model=model, trace=trace
            )

        # Preview: extract 1 series, confirm, then overlap preview training + remaining extraction
        preview = await resolve_series_preview(classified_files, model=model, trace=trace)
        if not preview:
            return []

        preview_series = preview[0]

        # Overlap: train preview model while extracting remaining series
        preview_model, all_series = await asyncio.gather(
            resolve_forecast_model(classified_files, preview_series, model=model, trace=trace),
            resolve_series(classified_files, preview, model=model, trace=trace),
        )

        # Preview forecast (needs preview_model)
        preview_forecast = await resolve_forecast(
            classified_files, preview_series, preview_model, model=model, trace=trace
        )

        # Gate 2: confirm forecast
        require_confirmation(
            _preview_forecast_message(preview_series, preview_forecast, preview_model.settings)
        )

        remaining = [s for s in all_series if s.id != preview_series.id]
        if not remaining:
            return [preview_forecast]

        # Each remaining series: train → forecast independently (faster series finish first)
        remaining_forecasts = await resolve_models_and_forecasts(
            classified_files, remaining, model=model, trace=trace
        )
        return [preview_forecast] + remaining_forecasts


# ============================================
# 5. RESOLUTION
# ============================================


async def resolve_forecast(
    files: list[File],
    series: Series,
    forecast_model: ForecastModel,
    target_analyst_runner: ForecastTargetAnalystRunner = _run_forecast_target_analyst,
    forecaster_runner: ForecasterRunner = _run_forecaster,
    /,
    *,
    emit_events: bool = True,
    model: str | None = None,
    trace: bool = True,
) -> Forecast:
    """Generate a single forecast by running two agents sequentially.

    Step 1 (target analyst): extracts recent target data from files.
    Step 2 (forecaster): fills in predicted values using model instructions.

    Runner arguments allow test doubles without live agent calls.

    Args:
        series: The series to forecast for.
        files: Classified files to use for target data extraction.
        forecast_model: Trained forecast model with instructions.
        target_analyst_runner: Runs step 1 — target data extraction.
        forecaster_runner: Runs step 2 — forecast generation.
        model: LLM model override for agent calls.
        trace: Whether to enable tracing for agent calls.

    Returns:
        Generated Forecast.

    Raises:
        ValueError: If files is empty.
    """
    if not files:
        raise ValueError("files required")

    settings = forecast_model.settings

    if emit_events:
        publish(ForecastStarted(series=[series]))

    try:
        # Target analyst: extract recent target data from user files
        target_analyst_result = await target_analyst_runner(
            series, files, settings, model=model, trace=trace
        )
        target_data_file = target_analyst_result.target_data.file

        # Forecaster: fill in predicted values
        forecaster_result = await forecaster_runner(
            series, forecast_model, target_data_file, settings, model=model, trace=trace
        )

        forecast_obj = Forecast(
            series_id=series.id,
            model_id=forecast_model.id,
            settings=settings,
            target_data=target_data_file,
            result=forecaster_result.forecast.file,
            items=forecaster_result.items,
        )

        if emit_events:
            publish(ForecastCompleted(forecasts=[forecast_obj], series=[series]))
        return forecast_obj
    except Exception as exc:
        if emit_events:
            publish(ForecastFailed(series=[series], error=str(exc)))
        raise


async def resolve_models_and_forecasts(
    files: list[File],
    series: list[Series],
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> list[Forecast]:
    """Orchestrate the full train → forecast pipeline for multiple series.

    Each series flows through ``resolve_forecast_model`` →
    ``resolve_forecast`` as a single pipeline item with bounded
    concurrency, so fast series complete without waiting for slow ones.
    Publishes ``ForecastFailed`` for individual failures and a summary
    ``ForecastCompleted`` when the pool finishes.
    """

    async def _train_and_forecast(s: Series) -> Forecast:
        fm = await resolve_forecast_model(files, s, emit_events=True, model=model, trace=trace)
        return await resolve_forecast(files, s, fm, emit_events=True, model=model, trace=trace)

    results = await pool(series, _train_and_forecast)

    all_forecasts: list[Forecast] = []
    for s, result in zip(series, results):
        if isinstance(result, BaseException):
            publish(ForecastFailed(series=[s], error=str(result)))
        else:
            all_forecasts.append(result)

    publish(ForecastCompleted(forecasts=all_forecasts, series=series))
    return all_forecasts


def _preview_forecast_message(
    series: Series, forecast_obj: Forecast, settings: ForecastSettings
) -> str:
    """Format a single series' forecast for CLI preview.

    Shows series name, date range description, and a table of
    date/value rows with year shown on the left only when it changes.
    """
    items = forecast_obj.items
    if not items:
        return f"{series.name}\nNo forecast data"

    lines: list[str] = [series.name]

    first_date = date.fromisoformat(items[0].date)
    last_date = date.fromisoformat(items[-1].date)
    lines.append(
        f"{settings.target.capitalize()} forecast"
        + f" ({first_date.year} {first_date.strftime('%b')}"
        + f" → {last_date.year} {last_date.strftime('%b')})"
    )
    lines.append("")

    # Find max value width for right-alignment
    max_width = max(len(f"{item.value:,}") for item in items)

    prev_year: int | None = None
    for item in items:
        d = date.fromisoformat(item.date)
        if d.year != prev_year:
            year_str = str(d.year)
            prev_year = d.year
        else:
            year_str = "    "
        value_str = f"{item.value:,}".rjust(max_width)
        lines.append(f"  {year_str} {d.strftime('%b')}  {value_str}")

    return "\n".join(lines)
