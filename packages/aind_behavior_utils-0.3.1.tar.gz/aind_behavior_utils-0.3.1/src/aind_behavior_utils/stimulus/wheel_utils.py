"""Wheel QC image and metric calculation utilities.

This module provides high-level functions for quality control analysis of
wheel rotation data from stimulus pickle files. These are convenience wrappers
around the CamstimDataset class (data parsing and metrics) and the plotting
module (visualization).

The module focuses on wheel encoder data, which is typically stored in the
stimulus pickle file under items.foraging or items.behavior. Functions here
combine multiple core utilities to produce either visual plots or numerical
metrics suitable for QC assessment.
"""

from typing import Any, Dict, Union


import aind_behavior_utils.plotting.plots as plots
from aind_behavior_utils.stimulus.camstim_dataset import CamstimDataset


def _resolve_pkl(
    pkl_input: Union[str, Dict[str, Any], CamstimDataset],
) -> CamstimDataset:
    """Resolve pickle input to a CamstimDataset instance.

    Parameters
    ----------
    pkl_input : Union[str, Dict[str, Any], CamstimDataset]
        A file path, an already-loaded dictionary, or an existing
        CamstimDataset instance.

    Returns
    -------
    CamstimDataset
        A CamstimDataset instance.
    """
    if isinstance(pkl_input, CamstimDataset):
        return pkl_input
    if isinstance(pkl_input, str):
        return CamstimDataset.from_file(pkl_input)
    return CamstimDataset(pkl_input)


def calculate_qc_images(
    pkl_input: Union[str, Dict[str, Any], CamstimDataset],
) -> dict:
    """Calculate quality control images from stimulus pickle data.

    This is a high-level wrapper that combines core utilities from
    CamstimDataset and the plotting module to generate visual QC plots
    for wheel rotation data.

    Parameters
    ----------
    pkl_input : Union[str, Dict[str, Any], CamstimDataset]
        Path to a stimulus pickle file, an already-loaded pickle data
        dictionary, or an existing CamstimDataset instance.

    Returns
    -------
    dict
        Dictionary containing two matplotlib Figure objects:
        - 'wheel_speed_plot': Line plot of instantaneous wheel
          speed in cm/s across all stimulus frames.
        - 'wheel_traveled_distance_plot': Line plot of cumulative
          wheel traveled distance in meters.

    Notes
    -----
    Uses the following utilities:
    - CamstimDataset.running_speed_array: Converts encoder data to speed (cm/s)
    - CamstimDataset.fps: Retrieves frame rate from stimulus metadata
    - plotting.plot_array: Creates matplotlib figures
    """
    dset = _resolve_pkl(pkl_input)
    running_speed_array = dset.running_speed_array
    wheel_speed_plot = plots.plot_array(
        running_speed_array,
        xlabel="Frame #",
        ylabel="Wheel Speed (cm/s)",
        title="wheel_speed_plot",
    )

    wheel_travel_plot = plots.plot_array(
        running_speed_array.cumsum() / (100 * dset.fps),
        xlabel="Frame #",
        ylabel="Traveled Distance (m)",
        title="wheel_traveled_distance_plot",
    )
    return {
        "wheel_speed_plot": wheel_speed_plot,
        "wheel_traveled_distance_plot": wheel_travel_plot,
    }


def calculate_qc_metrics(
    pkl_input: Union[str, Dict[str, Any], CamstimDataset],
) -> dict:
    """Calculate quality control metrics from stimulus pickle data.

    This is a high-level wrapper that combines core utilities from
    CamstimDataset to compute numerical QC metrics for wheel rotation
    data.

    Parameters
    ----------
    pkl_input : Union[str, Dict[str, Any], CamstimDataset]
        Path to a stimulus pickle file, an already-loaded pickle data
        dictionary, or an existing CamstimDataset instance.

    Returns
    -------
    dict
        Dictionary containing QC metrics:
        - 'wheel_artifacts': Count of abnormal speed values
          (absolute value exceeding 100 cm/s), which may
          indicate encoder glitches or physical wheel slips.

    Notes
    -----
    Uses the following utilities:
    - CamstimDataset.running_speed_array: Converts encoder data to speed (cm/s)
    - CamstimDataset.get_nb_wheel_artifacts: Counts speed outliers

    See Also
    --------
    calculate_qc_images : Generate visual QC plots
    """
    dset = _resolve_pkl(pkl_input)
    metrics = {"wheel_artifacts": dset.get_nb_wheel_artifacts()}
    return metrics
