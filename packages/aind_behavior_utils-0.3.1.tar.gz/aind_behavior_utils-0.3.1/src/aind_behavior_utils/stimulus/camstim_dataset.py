"""Stimulus pickle file parsing utilities.

Provides utilities for loading and parsing Camstim stimulus pickle files,
extracting frame timing, wheel encoder data, and quality control metrics.

The primary interface is the :class:`CamstimDataset` class, which wraps
a loaded stimulus pickle dictionary and resolves its internal structure
(foraging vs behavior item groups) once at construction.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

# Wheel encoder calibration constant (radius in cm)
WHEEL_RADIUS = 5.5036

# Default fallback frame rate (Hz) when not explicitly specified or computed
DEFAULT_FPS = 60.0

# Conversion factor from milliseconds to seconds
MS_TO_S = 0.001


class CamstimDataset:
    """Wrapper around a camstim stimulus pickle file dictionary.

    Resolves the internal data layout (``foraging`` vs ``behavior``
    item groups) once at construction so that downstream accessors
    never need to repeat the lookup.

    Parameters
    ----------
    data : Dict[str, Any]
        The loaded stimulus pickle file dictionary.

    Examples
    --------
    >>> dset = CamstimDataset(pkl_data)
    >>> print(dset.fps)
    60.0
    >>> print(dset.stim_frame_count)
    120
    >>> speed = dset.running_speed_array
    >>> artifacts = dset.get_nb_wheel_artifacts()
    """

    def __init__(self, data: Dict[str, Any]) -> None:
        """Initialize CamstimDataset."""
        self.data = data
        self._items: Optional[Dict[str, Any]] = self._resolve_items()

    @classmethod
    def from_file(cls, path: str) -> CamstimDataset:
        """Load a pickle file and return a CamstimDataset instance.

        Parameters
        ----------
        path : str
            The path to the pickle file.

        Returns
        -------
        CamstimDataset
            A new instance wrapping the loaded data.
        """
        with open(path, "rb") as f:
            data = pd.read_pickle(f)
        return cls(data)

    def _resolve_items(self) -> Optional[Dict[str, Any]]:
        """Return the inner item-group dict (foraging or behavior).

        Returns
        -------
        Optional[Dict[str, Any]]
            The resolved item group dictionary, or None if not found.
        """
        items = self.data.get("items", {})
        for group in ("foraging", "behavior"):
            if group in items:
                return items[group]
        return None

    @property
    def fps(self) -> float:
        """Frames per second.

        Reads from the top-level ``"fps"`` key when available,
        otherwise computes from ``intervalsms``. Falls back to
        :data:`DEFAULT_FPS`.

        Returns
        -------
        float
            The frames per second.
        """
        try:
            return float(self.data["fps"])
        except KeyError:
            if self._items is not None:
                try:
                    mean_interval_ms = np.mean(self._items["intervalsms"])
                    return round(1 / (mean_interval_ms * MS_TO_S), 1)
                except KeyError:
                    return DEFAULT_FPS
            return DEFAULT_FPS

    @property
    def stage(self) -> Optional[str]:
        """Stimulus stage name.

        Returns
        -------
        Optional[str]
            The stage name from ``data["params"]["stage"]``, or
            ``None`` if absent.
        """
        try:
            return self.data["params"]["stage"]
        except (KeyError, TypeError):
            return None

    @property
    def intervals_ms(self) -> list:
        """Inter-frame intervals in milliseconds.

        Returns
        -------
        list
            The inter-frame intervals in milliseconds.

        Raises
        ------
        KeyError
            If no ``intervalsms`` data is found.
        """
        if self._items is not None and "intervalsms" in self._items:
            return self._items["intervalsms"]
        raise KeyError("Could not find intervalsms in pickle file.")

    @property
    def stim_frame_count(self) -> int:
        """Number of stimulus frames.

        The frame count is the length of the ``intervalsms`` array plus one,
        since each interval sits between two frames.

        Returns
        -------
        int
            The number of stimulus frames.

        Raises
        ------
        KeyError
            If no ``intervalsms`` data is found.
        """
        return len(self.intervals_ms) + 1

    @property
    def running_speed_array(self) -> np.ndarray:
        """Running speed in cm/s derived from wheel encoder data.

        Locates the wheel encoder ``dx`` array, scales it by FPS and
        wheel radius to compute instantaneous speed.

        Returns
        -------
        numpy.ndarray
            Array of running speed values in cm/s.

        Raises
        ------
        KeyError
            If no encoder ``dx`` data is found in the pickle file.
        NotImplementedError
            If the pickle file format is unrecognised.
        """
        speed_dtheta = self._resolve_encoder_dx()
        return speed_dtheta * self.fps * (2 * np.pi * WHEEL_RADIUS / 360)

    def _resolve_encoder_dx(self) -> np.ndarray:
        """Locate the encoder ``dx`` array.

        Searches under the resolved item group (foraging or behavior)
        encoders, or at the top level.

        Returns
        -------
        numpy.ndarray
            The encoder ``dx`` array.

        Raises
        ------
        KeyError
            If no encoder ``dx`` data is found.
        NotImplementedError
            If the pickle file format is unrecognised.
        """
        if self._items is not None:
            try:
                return np.array(self._items["encoders"][0]["dx"])
            except (KeyError, IndexError, TypeError):
                raise KeyError(
                    "Could not find running speed data in pickle file."
                )
        if "dx" in self.data:
            return np.array(self.data["dx"])
        raise NotImplementedError(
            "Encountered unknown format for stimulus pickle file."
        )

    def get_nb_wheel_artifacts(self, threshold: float = 100) -> int:
        """Count speed values exceeding threshold.

        Artifacts are defined as absolute speed values that exceed
        the given threshold, typically indicating encoder glitches or
        physical wheel slips.

        Parameters
        ----------
        threshold : float, optional
            Speed threshold in cm/s. Default is 100.

        Returns
        -------
        int
            The number of points exceeding the threshold.
        """
        return int(np.sum(np.abs(self.running_speed_array) > threshold))


def load_pkl_file(path: str) -> Dict[str, Any]:
    """Load a stimulus pickle file and return the raw data dictionary.

    Parameters
    ----------
    path : str
        The path to the pickle file.

    Returns
    -------
    Dict[str, Any]
        The raw data dictionary from the pickle file.
    """
    with open(path, "rb") as f:
        return pd.read_pickle(f)


def get_stim_frame_count(pkl_data: Dict[str, Any]) -> int:
    """Get stimulus frame count from a raw pickle data dictionary.

    Parameters
    ----------
    pkl_data : Dict[str, Any]
        The raw stimulus pickle data dictionary.

    Returns
    -------
    int
        The number of stimulus frames.
    """
    return CamstimDataset(pkl_data).stim_frame_count
