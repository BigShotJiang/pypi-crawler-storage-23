"""Plotting utilities for behavior data."""

from typing import Optional, Tuple, Union

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure


def plot_array(
    data_array: np.ndarray,
    ylim: Optional[Tuple[float, float]] = None,
    xlim: Optional[Tuple[float, float]] = None,
    ylabel: str = "",
    xlabel: str = "",
    title: str = "",
    aspect: Optional[Union[str, float]] = None,
) -> Figure:
    """Plot data, return the figure.

    Parameters
    ----------
    data_array : numpy.ndarray
        An array of data to plot.
    ylim : Optional[Tuple[float, float]]
        The y-axis limits as a tuple (lower, upper).
    xlim : Optional[Tuple[float, float]]
        The x-axis limits as a tuple (lower, upper).
    ylabel : str
        The y-axis label.
    xlabel : str
        The x-axis label.
    title : str
        The plot title.
    aspect : Optional[Union[str, float]]
        The aspect ratio of the plot.

    Returns
    -------
    matplotlib.figure.Figure
        A matplotlib figure.
    """
    fig, ax = plt.subplots()

    if ylim:
        ax.set_ylim(*ylim)
    if xlim:
        ax.set_xlim(*xlim)

    ax.set_ylabel(ylabel)
    ax.set_xlabel(xlabel)
    ax.set_title(title)

    ax.plot(data_array)

    if aspect:
        ax.set_aspect(aspect)

    fig.tight_layout()
    return fig
