"""Plotting utilities for behavior data visualization."""
