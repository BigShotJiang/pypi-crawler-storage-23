"""Sync HDF5 dataset parsing and analysis utilities."""
