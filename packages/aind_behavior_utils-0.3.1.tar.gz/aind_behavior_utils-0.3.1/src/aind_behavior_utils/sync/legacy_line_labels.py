"""Utilities for resolving legacy sync line label variants.

Different experimental setups use different names for the same signal
(e.g. ``"stim_vsync"`` vs ``"vsync_stim"``).  This module maps
canonical signal names to their known variants so that downstream code
can refer to signals by a single, stable name.
"""

from typing import Dict, List, Optional

LINE_LABEL_VARIANTS: Dict[str, List[str]] = {
    "behavior_monitoring": [
        "behavior_monitoring",
        "cam1_exposure",
        "cam1",
        "beh_cam_frame_readout",
    ],
    "eye_tracking": [
        "eye_tracking",
        "cam2_exposure",
        "cam2",
        "eye_cam_frame_readout",
    ],
    "face_tracking": ["face_tracking", "face_cam_frame_readout"],
    "photodiode": ["photodiode", "stim_photodiode"],
    "physio": ["2p_vsync", "vsync_2p"],
    "visual_stim": ["stim_vsync", "vsync_stim"],
}


def build_line_label_map(
    line_labels: List[str],
    variants: Optional[Dict[str, List[str]]] = None,
) -> Dict[str, str]:
    """Build a mapping from canonical names to actual file labels.

    For each canonical name, the first matching variant found in
    ``line_labels`` is used.

    Parameters
    ----------
    line_labels : List[str]
        Line labels present in a sync file.
    variants : Optional[Dict[str, List[str]]]
        Canonical-name-to-variant-list mapping.  Defaults to
        ``LINE_LABEL_VARIANTS``.

    Returns
    -------
    Dict[str, str]
        Canonical name to the actual label found in ``line_labels``.
    """
    if variants is None:
        variants = LINE_LABEL_VARIANTS
    result: Dict[str, str] = {}
    for canonical, variant_list in variants.items():
        for variant in variant_list:
            if variant in line_labels:
                result[canonical] = variant
                break
    return result


def resolve_line_label(
    line: str,
    label_map: Dict[str, str],
    line_labels: List[str],
) -> str:
    """Resolve a line name to the actual label in a sync file.

    Accepts either a canonical name (looked up via ``label_map``) or a
    direct label that exists in ``line_labels``.

    Parameters
    ----------
    line : str
        Canonical name or direct line label.
    label_map : Dict[str, str]
        Mapping from canonical names to actual labels, as returned by
        :func:`build_line_label_map`.
    line_labels : List[str]
        Line labels present in the sync file.

    Returns
    -------
    str
        The actual line label found in ``line_labels``.

    Raises
    ------
    ValueError
        If ``line`` cannot be resolved to a label in ``line_labels``.
    """
    resolved = label_map.get(line, line)
    if resolved in line_labels:
        return resolved
    raise ValueError(f"'{line}' not found in line labels or label map.")
