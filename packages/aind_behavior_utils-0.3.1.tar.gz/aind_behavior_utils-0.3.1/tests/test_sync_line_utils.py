"""Tests for sync_line_utils module."""

import unittest

import numpy as np

from aind_behavior_utils.sync.sync_dataset import (
    SyncDataset,
    _filter_spurious_photodiode_events,
    _measure_photodiode_delays,
    _resolve_delay,
)


class TestFilterSpuriousPhotodiodeEvents(unittest.TestCase):
    """Tests for _filter_spurious_photodiode_events."""

    def test_removes_close_events(self):
        """Test that events closer than min_spacing are removed."""
        timestamps = np.array([0.0, 0.5, 2.5, 2.6, 5.0])
        result = _filter_spurious_photodiode_events(
            timestamps, min_spacing=1.8
        )
        np.testing.assert_array_equal(result, [0.0, 2.5, 5.0])

    def test_keeps_all_when_spaced(self):
        """Test that well-spaced events are all kept."""
        timestamps = np.array([0.0, 2.0, 4.0, 6.0])
        result = _filter_spurious_photodiode_events(
            timestamps, min_spacing=1.8
        )
        np.testing.assert_array_equal(result, timestamps)

    def test_single_event(self):
        """Test with a single event."""
        timestamps = np.array([1.0])
        result = _filter_spurious_photodiode_events(
            timestamps, min_spacing=1.8
        )
        np.testing.assert_array_equal(result, [1.0])


class TestMeasurePhotodiodeDelays(unittest.TestCase):
    """Tests for _measure_photodiode_delays."""

    def test_basic_delay_measurement(self):
        """Test delay measurement with known offsets."""
        vsync_fall = np.arange(0, 240, 1.0)
        photodiode_rise = np.array([60.05, 180.05])
        result = _measure_photodiode_delays(
            vsync_fall,
            photodiode_rise,
            num_samples=2,
            vsyncs_per_photodiode=60,
            total_vsyncs=120,
        )
        np.testing.assert_array_almost_equal(result, [0.05, 0.05])

    def test_truncates_when_vsync_too_short(self):
        """Test truncation when vsync array is shorter than expected."""
        vsync_fall = np.arange(0, 100, 1.0)
        photodiode_rise = np.array([60.05, 180.05])
        result = _measure_photodiode_delays(
            vsync_fall,
            photodiode_rise,
            num_samples=2,
            vsyncs_per_photodiode=60,
            total_vsyncs=120,
        )
        self.assertEqual(len(result), 1)


class TestResolveDelay(unittest.TestCase):
    """Tests for _resolve_delay."""

    def test_returns_mean_when_stable(self):
        """Test that mean delay is returned for stable signals."""
        delays = np.array([0.035, 0.036, 0.035, 0.036])
        result = _resolve_delay(
            delays, assumed_delay=0.0356, delay_threshold=0.002
        )
        self.assertAlmostEqual(result, np.mean(delays))

    def test_returns_assumed_when_noisy(self):
        """Test fallback to assumed delay for noisy signals."""
        delays = np.array([0.01, 0.05, 0.10, 0.20])
        result = _resolve_delay(
            delays, assumed_delay=0.0356, delay_threshold=0.002
        )
        self.assertEqual(result, 0.0356)

    def test_returns_assumed_when_nan(self):
        """Test fallback to assumed delay when mean is NaN."""
        delays = np.array([np.nan, np.nan])
        result = _resolve_delay(
            delays, assumed_delay=0.0356, delay_threshold=0.002
        )
        self.assertEqual(result, 0.0356)

    def test_one_second_wraparound_correction(self):
        """Test correction for 1-second wraparound artifacts."""
        delays = np.array([1.034, 1.036, 1.038, 1.033])
        result = _resolve_delay(
            delays, assumed_delay=0.0356, delay_threshold=0.001
        )
        self.assertAlmostEqual(result, np.mean(delays) - 1, places=4)


class TestCalculateDisplayDelay(unittest.TestCase):
    """Tests for SyncDataset.calculate_display_delay."""

    def test_returns_assumed_delay_when_no_events(self):
        """Test fallback when photodiode array is empty."""
        vsync_fall = np.arange(0, 240, 1.0)
        photodiode_rise = np.array([])
        result = SyncDataset.calculate_display_delay(
            vsync_fall, photodiode_rise
        )
        self.assertEqual(result, 0.0356)

    def test_correct_delay_with_clean_signal(self):
        """Test delay measurement with a clean synthetic signal."""
        expected_delay = 0.035
        vsyncs_per_pd = 60
        total_vsyncs = vsyncs_per_pd * 2
        num_flashes = 5

        vsync_fall = np.arange(0, num_flashes * total_vsyncs, dtype=float)
        photodiode_rise = np.array(
            [
                i * total_vsyncs + vsyncs_per_pd + expected_delay
                for i in range(num_flashes)
            ]
        )

        result = SyncDataset.calculate_display_delay(
            vsync_fall, photodiode_rise
        )
        self.assertAlmostEqual(result, expected_delay, places=5)

    def test_filters_spurious_events(self):
        """Test that close photodiode events are filtered out."""
        expected_delay = 0.035
        vsyncs_per_pd = 60
        total_vsyncs = vsyncs_per_pd * 2

        vsync_fall = np.arange(0, 3 * total_vsyncs, dtype=float)
        clean_rise = np.array(
            [
                i * total_vsyncs + vsyncs_per_pd + expected_delay
                for i in range(3)
            ]
        )
        spurious = np.array([clean_rise[0] + 0.1])
        photodiode_rise = np.sort(np.concatenate([clean_rise, spurious]))

        result = SyncDataset.calculate_display_delay(
            vsync_fall, photodiode_rise
        )
        self.assertAlmostEqual(result, expected_delay, places=3)


if __name__ == "__main__":
    unittest.main()
