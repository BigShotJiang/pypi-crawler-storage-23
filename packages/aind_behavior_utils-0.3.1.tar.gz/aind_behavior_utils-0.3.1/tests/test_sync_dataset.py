"""Tests for the SyncDataset class using unittest framework."""

import tempfile
import unittest
from pathlib import Path

import h5py
import numpy as np

from aind_behavior_utils.sync.sync_dataset import SyncDataset


class TestSyncDataset(unittest.TestCase):
    """Test class for SyncDataset."""

    def setUp(self):
        """Set up test fixtures before each test method."""
        # Create a temporary directory and file for testing
        self.temp_dir = tempfile.mkdtemp()
        self.h5_path = Path(self.temp_dir) / "test_sync.h5"

        # Create sample HDF5 file
        with h5py.File(self.h5_path, "w") as f:
            # Create meta data
            meta_data = {
                "ni_daq": {
                    "sample_freq": 10000.0,
                    "counter_output_freq": 10000.0,
                    "counter_bits": 32,
                },
                "line_labels": [
                    "line1",
                    "line2",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                ],
                "start_time": "2024-03-27 12:00:00",
            }
            f.create_dataset("meta", data=str(meta_data))

            # Create sample data
            # Create 1000 samples with some events
            data = np.zeros((1000, 2), dtype=np.uint32)
            data[:, 1] = np.random.randint(
                0, 2**32, size=1000, dtype=np.uint32
            )
            f.create_dataset("data", data=data)

    def tearDown(self):
        """Clean up after each test method."""
        # Remove temporary files
        import shutil

        shutil.rmtree(self.temp_dir)

    def test_load_dataset(self):
        """Test loading a dataset."""
        dataset = SyncDataset(self.h5_path)
        self.assertIsNotNone(dataset)
        self.assertEqual(dataset.sample_freq, 10000.0)
        self.assertEqual(dataset.start_time, "2024-03-27 12:00:00")
        dataset.close()

    def test_load_metadata(self):
        """Test that metadata is correctly loaded."""
        dataset = SyncDataset(self.h5_path)
        self.assertIsNotNone(dataset.meta_data)
        self.assertIsInstance(dataset.meta_data, dict)
        self.assertIn("ni_daq", dataset.meta_data)
        self.assertIn("line_labels", dataset.meta_data)
        self.assertEqual(dataset.meta_data["ni_daq"]["sample_freq"], 10000.0)
        self.assertEqual(
            dataset.meta_data["start_time"], "2024-03-27 12:00:00"
        )
        dataset.close()

    def test_get_bit(self):
        """Test getting bit values."""
        dataset = SyncDataset(self.h5_path)
        bit_values = dataset.get_bit(0)  # Get first bit
        self.assertEqual(len(bit_values), 1000)
        self.assertEqual(bit_values.dtype, np.uint8)
        dataset.close()

    def test_get_line(self):
        """Test getting line values."""
        dataset = SyncDataset(self.h5_path)
        line_values = dataset.get_line("line1")
        self.assertEqual(len(line_values), 1000)
        self.assertEqual(line_values.dtype, np.uint8)
        dataset.close()

    def test_get_rising_edges(self):
        """Test getting rising edges."""
        dataset = SyncDataset(self.h5_path)
        rising_edges = dataset.get_rising_edges("line1")
        self.assertIsInstance(rising_edges, np.ndarray)
        dataset.close()

    def test_get_falling_edges(self):
        """Test getting falling edges."""
        dataset = SyncDataset(self.h5_path)
        falling_edges = dataset.get_falling_edges("line1")
        self.assertIsInstance(falling_edges, np.ndarray)
        dataset.close()

    def test_line_stats(self):
        """Test getting line statistics (duty_cycle not implemented)."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(NotImplementedError):
            dataset.line_stats("line1", print_results=False)
        dataset.close()

    def test_period(self):
        """Test calculating period."""
        dataset = SyncDataset(self.h5_path)
        period = dataset.period("line1")
        self.assertIsInstance(period, dict)
        self.assertIn("avg", period)
        self.assertIn("max", period)
        self.assertIn("min", period)
        self.assertIn("sd", period)
        dataset.close()

    def test_frequency(self):
        """Test calculating frequency."""
        dataset = SyncDataset(self.h5_path)
        freq = dataset.frequency("line1")
        self.assertIsInstance(freq, float)
        dataset.close()

    def test_context_manager(self):
        """Test using the dataset as a context manager."""
        with SyncDataset(self.h5_path) as dataset:
            self.assertIsNotNone(dataset)
            self.assertEqual(dataset.sample_freq, 10000.0)

    def test_invalid_line(self):
        """Test handling of invalid line names."""
        with self.assertRaises(ValueError):
            dataset = SyncDataset(self.h5_path)
            dataset.get_line("invalid_line")
            dataset.close()

    def test_get_all_times(self):
        """Test getting all times in different units."""
        dataset = SyncDataset(self.h5_path)
        times_samples = dataset.get_all_times(units="samples")
        times_seconds = dataset.get_all_times(units="seconds")
        self.assertEqual(len(times_samples), 1000)
        self.assertEqual(len(times_seconds), 1000)
        np.testing.assert_allclose(
            times_seconds, times_samples / dataset.sample_freq
        )
        dataset.close()

    def test_get_all_times_units(self):
        """Test get_all_times with different units."""
        dataset = SyncDataset(self.h5_path)
        times_samples = dataset.get_all_times(units="samples")
        times_seconds = dataset.get_all_times(units="seconds")
        self.assertEqual(len(times_samples), 1000)
        self.assertEqual(len(times_seconds), 1000)
        np.testing.assert_allclose(
            times_seconds, times_samples / dataset.sample_freq
        )

        with self.assertRaises(ValueError):
            dataset.get_all_times(units="invalid_unit")
        dataset.close()

    def test_get_bit_cache(self):
        """Test caching behavior of get_bit."""
        dataset = SyncDataset(self.h5_path)
        bit_values_first_call = dataset.get_bit(0)
        bit_values_second_call = dataset.get_bit(0)
        np.testing.assert_array_equal(
            bit_values_first_call, bit_values_second_call
        )
        dataset.close()

    def test_get_line_cache(self):
        """Test caching behavior of get_line."""
        dataset = SyncDataset(self.h5_path)
        line_values_first_call = dataset.get_line("line1")
        line_values_second_call = dataset.get_line("line1")
        np.testing.assert_array_equal(
            line_values_first_call, line_values_second_call
        )
        dataset.close()

    def test_get_line_invalid_line(self):
        """Test get_line with an invalid line name."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(ValueError):
            dataset.get_line("nonexistent_line")
        dataset.close()

    def test_empty_dataset(self):
        """Test behavior with an empty dataset."""
        empty_h5_path = Path(self.temp_dir) / "empty_test_sync.h5"
        with h5py.File(empty_h5_path, "w") as f:
            f.create_dataset("meta", data=str({}))
            f.create_dataset("data", data=np.zeros((0, 2), dtype=np.uint32))

        with self.assertRaises(KeyError):
            SyncDataset(empty_h5_path)

    def test_get_events_by_line(self):
        """Test get_events_by_line for a valid line."""
        dataset = SyncDataset(self.h5_path)
        events = dataset.get_events_by_line("line1", units="samples")
        self.assertIsInstance(events, np.ndarray)
        dataset.close()

    def test_get_line_changes(self):
        """Test get_line_changes for a valid line."""
        dataset = SyncDataset(self.h5_path)
        line_changes = dataset.get_line_changes("line1")
        self.assertIsInstance(line_changes, np.ndarray)
        self.assertEqual(line_changes.dtype, np.uint8)
        dataset.close()

    def test_get_line_changes_invalid_line(self):
        """Test get_line_changes with an invalid line name."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(ValueError):
            dataset.get_line_changes("nonexistent_line")
        dataset.close()

    def test_get_all_bits(self):
        """Test get_all_bits method."""
        dataset = SyncDataset(self.h5_path)
        all_bits = dataset.get_all_bits()
        self.assertIsInstance(all_bits, np.ndarray)
        self.assertEqual(
            all_bits.shape[0], 1000
        )  # Ensure it matches the number of samples
        dataset.close()

    def test_get_all_events(self):
        """Test get_all_events method."""
        dataset = SyncDataset(self.h5_path)
        all_events = dataset.get_all_events()
        self.assertIsInstance(all_events, np.ndarray)
        self.assertEqual(
            all_events.shape[1], 2
        )  # Ensure it has two columns (counter values and IO state)
        self.assertEqual(
            all_events.shape[0], 1000
        )  # Ensure it matches the number of samples
        dataset.close()

    def test_get_events_by_bit(self):
        """Test get_events_by_bit for a valid bit."""
        dataset = SyncDataset(self.h5_path)
        events = dataset.get_events_by_bit(0, units="samples")
        self.assertIsInstance(events, np.ndarray)
        self.assertEqual(events.ndim, 1)  # Ensure it's a 1D array
        dataset.close()

    def test_get_events_by_bit_invalid_units(self):
        """Test get_events_by_bit with invalid units."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(ValueError):
            dataset.get_events_by_bit(0, units="invalid_unit")
        dataset.close()

    def test_line_to_bit_valid_line_name(self):
        """Test _line_to_bit with a valid line name."""
        dataset = SyncDataset(self.h5_path)
        bit = dataset._line_to_bit("line1")
        self.assertEqual(bit, 0)  # Assuming "line1" corresponds to bit 0
        dataset.close()

    def test_line_to_bit_valid_line_number(self):
        """Test _line_to_bit with a valid line number."""
        dataset = SyncDataset(self.h5_path)
        bit = dataset._line_to_bit(0)
        self.assertEqual(bit, 0)  # Line number 0 should return bit 0
        dataset.close()

    def test_line_to_bit_invalid_line_name(self):
        """Test _line_to_bit with an invalid line name."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(ValueError):
            dataset._line_to_bit("nonexistent_line")
        dataset.close()

    def test_line_to_bit_invalid_line_type(self):
        """Test _line_to_bit with an invalid line type."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(TypeError):
            dataset._line_to_bit(3.14)  # Invalid type (float)
        dataset.close()

    def test_bit_to_line_valid_bit(self):
        """Test _bit_to_line with a valid bit index."""
        dataset = SyncDataset(self.h5_path)
        line_name = dataset._bit_to_line(
            0
        )  # Assuming bit 0 corresponds to "line1"
        self.assertEqual(line_name, "line1")
        dataset.close()

    def test_bit_to_line_invalid_bit(self):
        """Test _bit_to_line with an invalid bit index."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(IndexError):
            dataset._bit_to_line(33)  # Assuming 33 is out of range
        dataset.close()

    def test_get_analog_channel_valid_channel(self):
        """Test get_analog_channel with a valid channel."""
        # Add analog data and metadata to the HDF5 file
        with h5py.File(self.h5_path, "a") as f:
            analog_meta = {
                "analog_labels": ["channel1", "channel2"],
                "analog_channels": [0, 1],
                "analog_sample_rate": 1000.0,
            }
            f.create_dataset("analog_meta", data=str(analog_meta))
            analog_data = np.random.rand(1000, 2)  # 1000 samples, 2 channels
            f.create_dataset("analog_data", data=analog_data)

        # Reload the dataset to include the new data
        dataset = SyncDataset(self.h5_path)

        # Test retrieving data for a valid channel
        channel_data = dataset.get_analog_channel(
            "channel1", start_time=0.0, stop_time=0.5
        )
        self.assertIsInstance(channel_data, np.ndarray)
        self.assertEqual(
            len(channel_data), int(0.5 * 1000)
        )  # 0.5 seconds of data at 1000 Hz

        dataset.close()

    def test_get_analog_channel_invalid_channel(self):
        """Test get_analog_channel with an invalid channel."""
        # Add analog data and metadata to the HDF5 file
        with h5py.File(self.h5_path, "a") as f:
            analog_meta = {
                "analog_labels": ["channel1", "channel2"],
                "analog_channels": [0, 1],
                "analog_sample_rate": 1000.0,
            }
            f.create_dataset("analog_meta", data=str(analog_meta))
            analog_data = np.random.rand(1000, 2)  # 1000 samples, 2 channels
            f.create_dataset("analog_data", data=analog_data)

        # Reload the dataset to include the new data
        dataset = SyncDataset(self.h5_path)

        # Test retrieving data for an invalid channel
        with self.assertRaises(ValueError):
            dataset.get_analog_channel("invalid_channel")

        dataset.close()

    def test_get_analog_channel_no_analog_data(self):
        """Test get_analog_channel when no analog data is present."""
        # Ensure no analog data exists in the file
        with h5py.File(self.h5_path, "a") as f:
            if "analog_data" in f.keys():
                del f["analog_data"]
        dataset = SyncDataset(self.h5_path)
        # Test retrieving data when no analog data is present
        with self.assertRaises(KeyError):
            dataset.get_analog_channel("channel1")

        dataset.close()

    def test_get_analog_channel_downsample(self):
        """Test get_analog_channel with downsampling."""
        # Add analog data and metadata to the HDF5 file
        with h5py.File(self.h5_path, "a") as f:
            analog_meta = {
                "analog_labels": ["channel1", "channel2"],
                "analog_channels": [0, 1],
                "analog_sample_rate": 1000.0,
            }
            f.create_dataset("analog_meta", data=str(analog_meta))
            analog_data = np.random.rand(1000, 2)  # 1000 samples, 2 channels
            f.create_dataset("analog_data", data=analog_data)

        # Reload the dataset to include the new data
        dataset = SyncDataset(self.h5_path)

        # Test retrieving data with downsampling
        channel_data = dataset.get_analog_channel(
            "channel1", start_time=0.0, stop_time=1.0, downsample=2
        )
        self.assertIsInstance(channel_data, np.ndarray)
        self.assertEqual(
            len(channel_data), 500
        )  # Downsampled by a factor of 2

        dataset.close()

    def test_get_analog_meta_valid_metadata(self):
        """Test get_analog_meta with valid metadata."""
        # Add analog metadata to the HDF5 file
        with h5py.File(self.h5_path, "a") as f:
            analog_meta = {
                "analog_labels": ["channel1", "channel2"],
                "analog_channels": [0, 1],
                "analog_sample_rate": 1000.0,
            }
            f.create_dataset("analog_meta", data=str(analog_meta))

        # Reload the dataset to include the new metadata
        dataset = SyncDataset(self.h5_path)

        # Test retrieving the analog metadata
        meta = dataset.get_analog_meta()
        self.assertIsInstance(meta, dict)
        self.assertIn("analog_labels", meta)
        self.assertIn("analog_channels", meta)
        self.assertIn("analog_sample_rate", meta)
        self.assertEqual(meta["analog_sample_rate"], 1000.0)

        dataset.close()

    def test_get_analog_meta_no_metadata(self):
        """Test get_analog_meta when no metadata is present."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(KeyError):
            dataset.get_analog_meta()
        dataset.close()

    def test_get_edges_rising(self):
        """Test get_edges with rising slope."""
        dataset = SyncDataset(self.h5_path)
        edges = dataset.get_edges("line1", slope="rising", units="seconds")
        self.assertIsInstance(edges, np.ndarray)
        dataset.close()

    def test_get_edges_falling(self):
        """Test get_edges with falling slope."""
        dataset = SyncDataset(self.h5_path)
        edges = dataset.get_edges("line1", slope="falling", units="seconds")
        self.assertIsInstance(edges, np.ndarray)
        dataset.close()

    def test_get_edges_both(self):
        """Test get_edges with both slopes."""
        dataset = SyncDataset(self.h5_path)
        edges = dataset.get_edges("line1", slope="both", units="seconds")
        self.assertIsInstance(edges, np.ndarray)
        dataset.close()

    def test_get_edges_invalid_slope(self):
        """Test get_edges with invalid slope."""
        dataset = SyncDataset(self.h5_path)
        with self.assertRaises(ValueError):
            dataset.get_edges("line1", slope="invalid")
        dataset.close()

    def test_get_edges_no_changes(self):
        """Test get_edges raises when line has no state changes."""
        # Create a file where bit 0 has no transitions (all zeros)
        no_change_path = Path(self.temp_dir) / "no_change.h5"
        with h5py.File(no_change_path, "w") as f:
            meta = {
                "ni_daq": {
                    "sample_freq": 10000.0,
                    "counter_output_freq": 10000.0,
                    "counter_bits": 32,
                },
                "line_labels": ["line1"] + [""] * 31,
                "start_time": "2024-01-01 00:00:00",
            }
            f.create_dataset("meta", data=str(meta))
            data = np.zeros((100, 2), dtype=np.uint32)
            f.create_dataset("data", data=data)
        dataset = SyncDataset(no_change_path)
        with self.assertRaises(ValueError):
            dataset.get_edges("line1", slope="rising")
        dataset.close()

    def test_get_edge_diff(self):
        """Test get_edge_diff returns intervals between edges."""
        dataset = SyncDataset(self.h5_path)
        diffs = dataset.get_edge_diff("line1", slope="rising")
        self.assertIsInstance(diffs, np.ndarray)
        dataset.close()

    def test_get_duration(self):
        """Test get_duration returns duration in minutes."""
        dataset = SyncDataset(self.h5_path)
        duration = dataset.get_duration("line1", slope="rising")
        self.assertIsInstance(duration, float)
        dataset.close()

    def test_get_dropped_events(self):
        """Test get_dropped_events counts intervals above threshold."""
        dataset = SyncDataset(self.h5_path)
        dropped = dataset.get_dropped_events("line1", slope="rising")
        self.assertIsInstance(dropped, int)
        dataset.close()


if __name__ == "__main__":
    """Run the tests."""
    unittest.main()
