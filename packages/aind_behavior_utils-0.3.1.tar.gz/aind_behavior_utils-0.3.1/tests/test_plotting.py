"""Tests for plotting module."""

import unittest
from unittest.mock import MagicMock, patch

import numpy as np

import aind_behavior_utils.plotting.plots as plots


class TestPlotting(unittest.TestCase):
    """Test class for plotting functions."""

    @patch("matplotlib.pyplot.subplots")
    def test_plot_array_basic(self, mock_subplots):
        """Test plot_array with basic parameters."""
        # Setup mock
        mock_fig = MagicMock()
        mock_ax = MagicMock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        data = np.array([1, 2, 3, 4, 5])

        result = plots.plot_array(data)

        # Verify plot was called
        mock_ax.plot.assert_called_once_with(data)
        mock_fig.tight_layout.assert_called_once()
        self.assertEqual(result, mock_fig)

    @patch("matplotlib.pyplot.subplots")
    def test_plot_array_with_limits_and_labels(self, mock_subplots):
        """Test plot_array with limits and labels."""
        mock_fig = MagicMock()
        mock_ax = MagicMock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        data = np.array([1, 2, 3, 4, 5])

        plots.plot_array(
            data,
            ylim=(0, 10),
            xlim=(0, 5),
            ylabel="Y Axis",
            xlabel="X Axis",
            title="Test Plot",
            aspect="equal",
        )

        mock_ax.set_ylim.assert_called_once_with(0, 10)
        mock_ax.set_xlim.assert_called_once_with(0, 5)
        mock_ax.set_ylabel.assert_called_once_with("Y Axis")
        mock_ax.set_xlabel.assert_called_once_with("X Axis")
        mock_ax.set_title.assert_called_once_with("Test Plot")
        mock_ax.set_aspect.assert_called_once_with("equal")

    @patch("matplotlib.pyplot.subplots")
    def test_plot_array_no_optional_params(self, mock_subplots):
        """Test plot_array with no optional parameters."""
        mock_fig = MagicMock()
        mock_ax = MagicMock()
        mock_subplots.return_value = (mock_fig, mock_ax)

        data = np.array([1, 2, 3, 4, 5])

        plots.plot_array(data)

        # Verify optional methods were not called
        mock_ax.set_ylim.assert_not_called()
        mock_ax.set_xlim.assert_not_called()
        mock_ax.set_aspect.assert_not_called()

        # Verify required methods were called with empty strings
        mock_ax.set_ylabel.assert_called_once_with("")
        mock_ax.set_xlabel.assert_called_once_with("")
        mock_ax.set_title.assert_called_once_with("")


if __name__ == "__main__":
    unittest.main()
