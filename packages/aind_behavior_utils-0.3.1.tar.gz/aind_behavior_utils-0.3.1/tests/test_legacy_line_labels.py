"""Tests for legacy line label resolution utilities."""

import unittest

from aind_behavior_utils.sync.legacy_line_labels import (
    build_line_label_map,
    resolve_line_label,
)


class TestBuildLineLabelMap(unittest.TestCase):
    """Tests for build_line_label_map."""

    def test_finds_variant(self):
        """Correct variant is matched from line_labels."""
        line_labels = ["cam1_exposure", "stim_vsync", "photodiode"]
        result = build_line_label_map(line_labels)
        self.assertEqual(result["behavior_monitoring"], "cam1_exposure")
        self.assertEqual(result["visual_stim"], "stim_vsync")
        self.assertEqual(result["photodiode"], "photodiode")

    def test_no_match(self):
        """Canonical key absent when no variant matches."""
        line_labels = ["unrelated_signal"]
        result = build_line_label_map(line_labels)
        self.assertNotIn("behavior_monitoring", result)
        self.assertNotIn("visual_stim", result)

    def test_first_match_wins(self):
        """When multiple variants are present, first in list wins."""
        line_labels = ["behavior_monitoring", "cam1_exposure"]
        result = build_line_label_map(line_labels)
        self.assertEqual(result["behavior_monitoring"], "behavior_monitoring")

    def test_custom_variants(self):
        """Passing a custom variants dict works."""
        custom = {"my_signal": ["alias_a", "alias_b"]}
        line_labels = ["alias_b"]
        result = build_line_label_map(line_labels, variants=custom)
        self.assertEqual(result["my_signal"], "alias_b")
        self.assertEqual(len(result), 1)

    def test_default_uses_line_label_variants(self):
        """Default variants parameter uses LINE_LABEL_VARIANTS."""
        line_labels = ["vsync_2p"]
        result = build_line_label_map(line_labels)
        self.assertEqual(result["physio"], "vsync_2p")


class TestResolveLineLabel(unittest.TestCase):
    """Tests for resolve_line_label."""

    def setUp(self):
        """Set up common test fixtures."""
        self.line_labels = ["stim_photodiode", "stim_vsync", "cam1_exposure"]
        self.label_map = build_line_label_map(self.line_labels)

    def test_canonical_name(self):
        """Resolves canonical name via label_map."""
        result = resolve_line_label(
            "photodiode", self.label_map, self.line_labels
        )
        self.assertEqual(result, "stim_photodiode")

    def test_direct_label(self):
        """Resolves direct label that exists in line_labels."""
        result = resolve_line_label(
            "stim_vsync", self.label_map, self.line_labels
        )
        self.assertEqual(result, "stim_vsync")

    def test_not_found(self):
        """Raises ValueError for unknown name."""
        with self.assertRaises(ValueError):
            resolve_line_label("nonexistent", self.label_map, self.line_labels)

    def test_canonical_and_direct_converge(self):
        """Canonical name and direct label resolve to the same string."""
        via_canonical = resolve_line_label(
            "visual_stim", self.label_map, self.line_labels
        )
        via_direct = resolve_line_label(
            "stim_vsync", self.label_map, self.line_labels
        )
        self.assertEqual(via_canonical, via_direct)


if __name__ == "__main__":
    unittest.main()
