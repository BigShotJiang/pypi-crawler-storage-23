"""Tests for CamstimDataset class."""

import os
import pickle
import tempfile
import unittest

import matplotlib.pyplot as plt
import numpy as np

import aind_behavior_utils.plotting.plots as plots
from aind_behavior_utils.stimulus.camstim_dataset import CamstimDataset


class TestCamstimDataset(unittest.TestCase):
    """Test class for CamstimDataset."""

    def setUp(self):
        """Set up test fixtures."""
        self.sample_pkl_foraging = {
            "fps": 60,
            "items": {
                "foraging": {
                    "intervalsms": [16.67, 16.67, 16.67],
                    "encoders": [{"dx": [1, 2, 3, 4, 5]}],
                }
            },
            "params": {"stage": "foraging_stage"},
        }

        self.sample_pkl_behavior = {
            "items": {
                "behavior": {
                    "intervalsms": [20.0, 20.0, 20.0],
                    "encoders": [{"dx": [2, 4, 6, 8, 10]}],
                }
            },
            "params": {"stage": "behavior_stage"},
        }

        self.sample_pkl_dx_format = {
            "dx": [1.5, 2.5, 3.5, 4.5],
            "fps": 50,
            "params": {"stage": "dx_stage"},
        }

    def test_fps_with_fps_key(self):
        """Test fps property when fps key is present."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        self.assertEqual(dset.fps, 60)

        """Test fps property when fps key is present."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        self.assertEqual(dset.fps, 60)

    def test_fps_from_foraging_intervals(self):
        """Test fps calculated from foraging intervals."""
        pkl_data = {
            "items": {"foraging": {"intervalsms": [16.67, 16.67, 16.67]}}
        }
        dset = CamstimDataset(pkl_data)
        self.assertAlmostEqual(dset.fps, 60.0, places=1)

    def test_fps_from_behavior_intervals(self):
        """Test fps calculated from behavior intervals."""
        pkl_data = {"items": {"behavior": {"intervalsms": [20.0, 20.0, 20.0]}}}
        dset = CamstimDataset(pkl_data)
        self.assertAlmostEqual(dset.fps, 50.0, places=1)

    def test_fps_default_fallback(self):
        """Test fps returns default 60 when no intervals found."""
        pkl_data = {"items": {"other": {"data": [1, 2, 3]}}}
        dset = CamstimDataset(pkl_data)
        self.assertEqual(dset.fps, 60)

    def test_fps_no_items_fallback(self):
        """Test fps returns default 60 when no items key."""
        pkl_data = {"other_data": [1, 2, 3]}
        dset = CamstimDataset(pkl_data)
        self.assertEqual(dset.fps, 60)

    def test_intervals_ms_foraging(self):
        """Test intervals_ms property from foraging items."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        self.assertEqual(dset.intervals_ms, [16.67, 16.67, 16.67])

    def test_intervals_ms_behavior(self):
        """Test intervals_ms property from behavior items."""
        dset = CamstimDataset(self.sample_pkl_behavior)
        self.assertEqual(dset.intervals_ms, [20.0, 20.0, 20.0])

    def test_intervals_ms_missing(self):
        """Test intervals_ms raises KeyError when not found."""
        pkl_data = {"items": {"other": {}}}
        dset = CamstimDataset(pkl_data)
        with self.assertRaises(KeyError):
            _ = dset.intervals_ms

    def test_stim_frame_count_foraging(self):
        """Test stim_frame_count with foraging data."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        self.assertEqual(dset.stim_frame_count, 4)

    def test_stim_frame_count_behavior(self):
        """Test stim_frame_count with behavior data."""
        dset = CamstimDataset(self.sample_pkl_behavior)
        self.assertEqual(dset.stim_frame_count, 4)

    def test_stim_frame_count_missing(self):
        """Test stim_frame_count raises KeyError when missing."""
        pkl_data = {"other": "data"}
        dset = CamstimDataset(pkl_data)
        with self.assertRaises(KeyError):
            _ = dset.stim_frame_count

    def test_running_speed_array_foraging(self):
        """Test running_speed_array property with foraging data."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        result = dset.running_speed_array

        # Expected calculation: dx * fps * (2 * π * radius / 360)
        dx = np.array([1, 2, 3, 4, 5])
        fps = 60
        from aind_behavior_utils.stimulus.camstim_dataset import WHEEL_RADIUS
        expected = dx * fps * (2 * np.pi * WHEEL_RADIUS / 360)

        np.testing.assert_array_almost_equal(result, expected)

    def test_running_speed_array_behavior(self):
        """Test running_speed_array property with behavior data."""
        dset = CamstimDataset(self.sample_pkl_behavior)
        result = dset.running_speed_array

        # Expected calculation with behavior data
        dx = np.array([2, 4, 6, 8, 10])
        fps = 50  # Calculated from intervalsms
        from aind_behavior_utils.stimulus.camstim_dataset import WHEEL_RADIUS
        expected = dx * fps * (2 * np.pi * WHEEL_RADIUS / 360)

        np.testing.assert_array_almost_equal(result, expected)

    def test_running_speed_array_dx_format(self):
        """Test running_speed_array property with dx format."""
        dset = CamstimDataset(self.sample_pkl_dx_format)
        result = dset.running_speed_array

        # Expected calculation with dx format
        dx = np.array([1.5, 2.5, 3.5, 4.5])
        fps = 50
        from aind_behavior_utils.stimulus.camstim_dataset import WHEEL_RADIUS
        expected = dx * fps * (2 * np.pi * WHEEL_RADIUS / 360)

        np.testing.assert_array_almost_equal(result, expected)

    def test_running_speed_array_no_encoders(self):
        """Test running_speed_array raises error when no encoders found."""
        pkl_data = {"items": {"foraging": {"other": "data"}}}
        dset = CamstimDataset(pkl_data)

        with self.assertRaises(KeyError):
            _ = dset.running_speed_array

    def test_get_nb_wheel_artifacts_custom_threshold(self):
        """Test get_nb_wheel_artifacts method with custom threshold."""
        dset = CamstimDataset(
            {
                "dx": [50, 150, -120, 80, 200, -150, 30],
                "fps": 60,
            }
        )
        result = dset.get_nb_wheel_artifacts(threshold=500)

        # Speed values above 500 cm/s: 4 artifacts
        self.assertEqual(result, 4)

    def test_get_nb_wheel_artifacts_no_artifacts(self):
        """Test get_nb_wheel_artifacts when no artifacts exist."""
        dset = CamstimDataset(
            {
                "dx": [50, 60, -70, 80, 90, -50, 30],
                "fps": 60,
            }
        )
        result = dset.get_nb_wheel_artifacts(threshold=1000)

        self.assertEqual(result, 0)

    def test_get_nb_wheel_artifacts_one_artifact(self):
        """Test get_nb_wheel_artifacts when all values are artifacts."""
        dset = CamstimDataset({"dx": [-150], "fps": 60})
        result = dset.get_nb_wheel_artifacts(threshold=100)

        self.assertEqual(result, 1)

    def test_stage_property_present(self):
        """Test stage property when present."""
        dset = CamstimDataset(self.sample_pkl_foraging)
        self.assertEqual(dset.stage, "foraging_stage")

    def test_stage_property_missing(self):
        """Test stage property returns None when missing."""
        pkl_data = {"items": {"foraging": {"intervalsms": [16.67]}}}
        dset = CamstimDataset(pkl_data)
        self.assertIsNone(dset.stage)

    def test_wheel_radius_constant(self):
        """Test that WHEEL_RADIUS constant has expected value."""
        from aind_behavior_utils.stimulus.camstim_dataset import WHEEL_RADIUS
        self.assertEqual(WHEEL_RADIUS, 5.5036)


class TestCamstimDatasetFromFile(unittest.TestCase):
    """Integration tests for CamstimDataset.from_file method."""

    def setUp(self):
        """Set up integration test fixtures."""
        # Create a real pickle file for integration testing
        self.test_data = {
            "fps": 60,
            "items": {
                "foraging": {
                    "intervalsms": [16.67, 16.67, 16.67],
                    "encoders": [{"dx": [1, 2, 3, 4, 5, 150, -120]}],
                }
            },
            "params": {"stage": "integration_test"},
        }

        # Create temporary file
        self.temp_file = tempfile.NamedTemporaryFile(
            suffix=".pkl", delete=False
        )
        self.temp_file_path = self.temp_file.name
        # Close the temporary file handle before reopening the path (avoids
        # file locking issues on platforms like Windows).
        self.temp_file.close()

        # Write test data to file
        with open(self.temp_file_path, "wb") as f:
            pickle.dump(self.test_data, f)

    def tearDown(self):
        """Clean up test fixtures."""
        # Remove temporary file
        if os.path.exists(self.temp_file_path):
            os.unlink(self.temp_file_path)

    def test_full_workflow_from_file(self):
        """Test full workflow from loading pkl to analyzing artifacts."""
        # Load the pkl file
        dset = CamstimDataset.from_file(self.temp_file_path)
        self.assertEqual(dset.fps, 60)

        # Access running speed
        speed_array = dset.running_speed_array
        self.assertEqual(len(speed_array), 7)

        # Count artifacts
        artifacts = dset.get_nb_wheel_artifacts(threshold=100)

        # Verify we found some artifacts (the large values we put in)
        self.assertGreater(artifacts, 0)

        # Create a plot (just verify it doesn't crash)
        fig = plots.plot_array(
            speed_array, ylabel="Speed (cm/s)", xlabel="Frame"
        )
        self.assertIsNotNone(fig)
        plt.close(fig)  # Clean up


if __name__ == "__main__":
    unittest.main()
