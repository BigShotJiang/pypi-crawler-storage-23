from dataclasses import dataclass
from .....utils import DictUtils
import os

DEVICE_CODE_COLLECTION = os.environ.get('DEVICE_CODE_COLLECTION', 'device_codes')


@dataclass
class DeviceCodeFields:
    id = "id"
    device_code = "device_code"
    user_code = "user_code"
    client_id = "client_id"
    scope = "scope"
    user_uid = "user_uid"
    status = "status"
    interval = "interval"
    expires_at = "expires_at"
    last_polled_at = "last_polled_at"
    created_at = "created_at"

    @staticmethod
    def keys():
        return DictUtils.get_keys(DeviceCodeFieldsProps)

    @staticmethod
    def filtered_keys(field, condition=True):
        mutable = DictUtils.filter(DeviceCodeFieldsProps, DictUtils.get_keys(DeviceCodeFieldsProps), field, condition)
        return DictUtils.get_keys(mutable)


DeviceCodeFieldsProps = {
    DeviceCodeFields.id: {
        "type": str,
        "required": True,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.device_code: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.user_code: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.client_id: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.scope: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.user_uid: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.status: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "pending",
        "pickable": True
    },
    DeviceCodeFields.interval: {
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": 5,
        "pickable": True
    },
    DeviceCodeFields.expires_at: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.last_polled_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    DeviceCodeFields.created_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
}

STANDARD_FIELDS = DeviceCodeFields.filtered_keys('pickable', True)
