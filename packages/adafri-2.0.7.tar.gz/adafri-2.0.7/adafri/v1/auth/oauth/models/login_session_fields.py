from dataclasses import dataclass
from .....utils import DictUtils
import os

LOGIN_SESSION_COLLECTION = os.environ.get('LOGIN_SESSION_COLLECTION', 'login_sessions')


@dataclass
class LoginSessionFields:
    id = "id"
    user_uid = "user_uid"
    session_token = "session_token"
    device_name = "device_name"
    device_type = "device_type"
    ip_address = "ip_address"
    user_agent = "user_agent"
    is_active = "is_active"
    mfa_verified = "mfa_verified"
    created_at = "created_at"
    last_seen_at = "last_seen_at"
    revoked_at = "revoked_at"

    @staticmethod
    def keys():
        return DictUtils.get_keys(LoginSessionFieldsProps)

    @staticmethod
    def filtered_keys(field, condition=True):
        mutable = DictUtils.filter(LoginSessionFieldsProps, DictUtils.get_keys(LoginSessionFieldsProps), field, condition)
        return DictUtils.get_keys(mutable)


LoginSessionFieldsProps = {
    LoginSessionFields.id: {
        "type": str,
        "required": True,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.user_uid: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.session_token: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.device_name: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.device_type: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.ip_address: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.user_agent: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.is_active: {
        "type": bool,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": True,
        "pickable": True
    },
    LoginSessionFields.mfa_verified: {
        "type": bool,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": False,
        "pickable": True
    },
    LoginSessionFields.created_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.last_seen_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    LoginSessionFields.revoked_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
}

STANDARD_FIELDS = LoginSessionFields.filtered_keys('pickable', True)
