from dataclasses import dataclass
from .....utils import DictUtils
import os

AUDIT_LOG_COLLECTION = os.environ.get('AUDIT_LOG_COLLECTION', 'audit_logs')


@dataclass
class AuditLogFields:
    id = "id"
    event_type = "event_type"
    user_uid = "user_uid"
    client_id = "client_id"
    ip_address = "ip_address"
    user_agent = "user_agent"
    metadata = "metadata"
    created_at = "created_at"

    @staticmethod
    def keys():
        return DictUtils.get_keys(AuditLogFieldsProps)

    @staticmethod
    def filtered_keys(field, condition=True):
        mutable = DictUtils.filter(AuditLogFieldsProps, DictUtils.get_keys(AuditLogFieldsProps), field, condition)
        return DictUtils.get_keys(mutable)


AuditLogFieldsProps = {
    AuditLogFields.id: {
        "type": str,
        "required": True,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.event_type: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.user_uid: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.client_id: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.ip_address: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.user_agent: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    AuditLogFields.metadata: {
        "type": dict,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": {},
        "pickable": True
    },
    AuditLogFields.created_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
}

STANDARD_FIELDS = AuditLogFields.filtered_keys('pickable', True)
