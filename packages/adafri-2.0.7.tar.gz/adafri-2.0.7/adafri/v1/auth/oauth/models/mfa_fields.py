from dataclasses import dataclass
from .....utils import DictUtils
import os

MFA_COLLECTION = os.environ.get('MFA_COLLECTION', 'mfa_credentials')


@dataclass
class MFAFields:
    id = "id"
    user_uid = "user_uid"
    method = "method"
    totp_secret = "totp_secret"
    phone = "phone"
    backup_codes = "backup_codes"
    is_enabled = "is_enabled"
    enrolled_at = "enrolled_at"
    last_used_at = "last_used_at"

    @staticmethod
    def keys():
        return DictUtils.get_keys(MFAFieldsProps)

    @staticmethod
    def filtered_keys(field, condition=True):
        mutable = DictUtils.filter(MFAFieldsProps, DictUtils.get_keys(MFAFieldsProps), field, condition)
        return DictUtils.get_keys(mutable)


MFAFieldsProps = {
    MFAFields.id: {
        "type": str,
        "required": True,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    MFAFields.user_uid: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    MFAFields.method: {
        "type": str,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "totp",
        "pickable": True
    },
    MFAFields.totp_secret: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    MFAFields.phone: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    MFAFields.backup_codes: {
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": [],
        "pickable": True
    },
    MFAFields.is_enabled: {
        "type": bool,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": False,
        "pickable": True
    },
    MFAFields.enrolled_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
    MFAFields.last_used_at: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "default_value": "",
        "pickable": True
    },
}

STANDARD_FIELDS = MFAFields.filtered_keys('pickable', True)
