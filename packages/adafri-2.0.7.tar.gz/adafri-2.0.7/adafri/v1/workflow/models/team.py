import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from adafri.v1.base.firebase_collection import FirebaseCollectionBase

TEAM_COLLECTION = 'workflow_teams'

TEAM_PICKABLE_FIELDS = [
    'id', 'workspaceId', 'name', 'description', 'slug',
    'color', 'icon', 'memberUids', 'createdBy', 'createdAt',
]

TEAM_MUTABLE_FIELDS = ['name', 'description', 'slug', 'color', 'icon', 'memberUids']


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


class WorkflowTeamFields:
    @staticmethod
    def check_create_fields(data: dict) -> dict:
        if not data:
            return {'error': 'Missing data'}
        if not data.get('name', '').strip():
            return {'error': 'name is required'}
        if not data.get('workspaceId', '').strip():
            return {'error': 'workspaceId is required'}
        return data

    @staticmethod
    def mutable_keys() -> list:
        return TEAM_MUTABLE_FIELDS


@dataclass(init=False)
class WorkflowTeam(FirebaseCollectionBase):
    id: str
    workspaceId: str
    name: str
    description: str
    slug: str
    color: Optional[str]
    icon: Optional[str]
    memberUids: list
    createdBy: str
    createdAt: str

    def __init__(self, data=None, **kwargs):
        super().__init__(collection_name=TEAM_COLLECTION, **kwargs)
        d = data or {}
        name = d.get('name', '')
        self.id = d.get('id') or _new_id()
        self.workspaceId = d.get('workspaceId', '')
        self.name = name
        self.description = d.get('description', '')
        self.slug = d.get('slug') or name.lower().replace(' ', '-')
        self.color = d.get('color')
        self.icon = d.get('icon')
        self.memberUids = list(d.get('memberUids') or [])
        self.createdBy = d.get('createdBy', '')
        self.createdAt = d.get('createdAt') or _now()

    @classmethod
    def from_dict(cls, obj: Any, **kwargs) -> 'WorkflowTeam':
        return cls(obj, **kwargs)

    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'workspaceId': self.workspaceId,
            'name': self.name,
            'description': self.description,
            'slug': self.slug,
            'color': self.color,
            'icon': self.icon,
            'memberUids': self.memberUids,
            'createdBy': self.createdBy,
            'createdAt': self.createdAt,
        }

    @staticmethod
    def toListDict(items: list, fields=None) -> list:
        return [item.to_dict() for item in items]

    @classmethod
    def find(cls, team_id: str) -> 'Optional[WorkflowTeam]':
        inst = cls()
        doc = inst.collection().document(team_id).get()
        if not doc.exists:
            return None
        return cls({**doc.to_dict(), 'id': doc.id})

    @classmethod
    def listByWorkspace(cls, workspace_id: str) -> 'list[WorkflowTeam]':
        inst = cls()
        docs = (
            inst.collection()
            .where('workspaceId', '==', workspace_id)
            .order_by('createdAt')
            .stream()
        )
        return [cls({**d.to_dict(), 'id': d.id}) for d in docs]

    def save(self) -> 'WorkflowTeam':
        self.collection().document(self.id).set(self.to_dict())
        return self

    def update(self, data: dict) -> 'WorkflowTeam':
        filtered = {k: v for k, v in data.items() if k in TEAM_MUTABLE_FIELDS}
        self.collection().document(self.id).update(filtered)
        for k, v in filtered.items():
            setattr(self, k, v)
        return self

    def delete(self) -> None:
        self.collection().document(self.id).delete()
