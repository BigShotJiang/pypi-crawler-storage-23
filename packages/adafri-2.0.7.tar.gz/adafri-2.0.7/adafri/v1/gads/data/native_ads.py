NATIVE_ADS_REQUIREMENTS = [
    # Marketing Images
    {
        "type": "marketing_image",
        "name": "Marketing Image 1.91:1",
        "minWidth": 600,
        "minHeight": 314,
        # "maxWidth": 600,
        # "maxHeight": 314,
        "maxWidth": 1200,
        "maxHeight": 628,
        "ratio": "1.91:1",
        "maxFileSize": 5120,  # 5MB in KB
        # "maxFileSize": 0.5,  # 1MB in KB
        "formats": ["JPG", "PNG"],
        "description": "Landscape marketing image for responsive display ads"
    },    
    # Square Marketing Images
    {
        "type": "square_marketing_image",
        "name": "Square Marketing Image",
        "minWidth": 300,
        "minHeight": 300,
        # "maxWidth": 600,
        # "maxHeight": 600,
        "maxWidth": 1200,
        "maxHeight": 1200,
        "ratio": "1:1",
        "maxFileSize": 5120,
        # "maxFileSize": 0.5,  # 1MB in KB
        "formats": ["JPG", "PNG"],
        "description": "Square marketing image (same as marketing image 1:1)"
    },
    # Logos
    {
        "type": "logo",
        "name": "Logo 1:1",
        "minWidth": 128,
        "minHeight": 128,
        "maxWidth": 512,
        "maxHeight": 512,
        "ratio": "1:1",
        "maxFileSize": 5120,
        # "maxFileSize": 0.5,
        "formats": ["JPG", "PNG"],
        "description": "Square logo for responsive display ads"
    },
    {
        "type": "logo_landscape",
        "name": "Logo 4:1",
        "minWidth": 512,
        "minHeight": 128,
        "maxWidth": 2048,
        "maxHeight": 512,
        "ratio": "4:1",
        "maxFileSize": 5120,
        # "maxFileSize": 0.5,
        "formats": ["JPG", "PNG"],
        "description": "Landscape logo for responsive display ads"
    }
]

# MARKETING_IMAGES_RATIO = [
#     # Marketing Images
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 1.91:1",
#         "minWidth": 600,
#         "minHeight": 314,
#         "maxWidth": 1200,
#         "maxHeight": 628,
#         "ratio": "1.91:1",
#         "maxFileSize": 5120,  # 5MB in KB
#         "formats": ["JPG", "PNG"],
#         "description": "Landscape marketing image for responsive display ads"
#     },
#     {
#         "type": "marketing_image", 
#         "name": "Marketing Image 1:1",
#         "minWidth": 300,
#         "minHeight": 300,
#         "maxWidth": 1200,
#         "maxHeight": 1200,
#         "ratio": "1:1",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Square marketing image for responsive display ads"
#     },
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 4:3",
#         "minWidth": 600,
#         "minHeight": 450,
#         "maxWidth": 1200,
#         "maxHeight": 900,
#         "ratio": "4:3",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Standard marketing image for responsive display ads"
#     },
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 16:9",
#         "minWidth": 600,
#         "minHeight": 338,
#         "maxWidth": 1200,
#         "maxHeight": 675,
#         "ratio": "16:9",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Widescreen marketing image for responsive display ads"
#     },
    
#     # Square Marketing Images
#     {
#         "type": "square_marketing_image",
#         "name": "Square Marketing Image",
#         "minWidth": 300,
#         "minHeight": 300,
#         "maxWidth": 1200,
#         "maxHeight": 1200,
#         "ratio": "1:1",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Square marketing image (same as marketing image 1:1)"
#     },
    
#     # Logos
#     {
#         "type": "logo",
#         "name": "Logo 1:1",
#         "minWidth": 128,
#         "minHeight": 128,
#         "maxWidth": 512,
#         "maxHeight": 512,
#         "ratio": "1:1",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Square logo for responsive display ads"
#     },
#     {
#         "type": "logo",
#         "name": "Logo 4:1",
#         "minWidth": 512,
#         "minHeight": 128,
#         "maxWidth": 2048,
#         "maxHeight": 512,
#         "ratio": "4:1",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Landscape logo for responsive display ads"
#     },
    
#     # Additional Marketing Image Ratios (Optional)
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 3:2",
#         "minWidth": 600,
#         "minHeight": 400,
#         "maxWidth": 1200,
#         "maxHeight": 800,
#         "ratio": "3:2",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Classic marketing image ratio"
#     },
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 2:1",
#         "minWidth": 600,
#         "minHeight": 300,
#         "maxWidth": 1200,
#         "maxHeight": 600,
#         "ratio": "2:1",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Wide marketing image ratio"
#     },
#     {
#         "type": "marketing_image",
#         "name": "Marketing Image 5:4",
#         "minWidth": 600,
#         "minHeight": 480,
#         "maxWidth": 1200,
#         "maxHeight": 960,
#         "ratio": "5:4",
#         "maxFileSize": 5120,
#         "formats": ["JPG", "PNG"],
#         "description": "Portrait marketing image ratio"
#     }
# ]