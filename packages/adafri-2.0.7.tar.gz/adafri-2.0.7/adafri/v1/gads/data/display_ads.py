DISPLAY_ADS_REQUIREMENTS = [
  {
    "name": 'Rectangle (300x250)',
    "id": 'MediumRectangle',
    "isSpecial": True,
    "img": 'https://dummyimage.com/300x250/000/fff',
    "width": 300,
    "height": 250
  },
  {
    "name": 'Rectangle Large (336x280)',
    "id": 'LargeRectangle',
    "isSpecial": True,
    "img": 'https://dummyimage.com/336x280/000/fff',
    "width": 336,
    "height": 280
  },
  {
    "name": 'Carré (250x250)',
    "width": 250,
    "height": 250,
    "id": 'Square',
    "isSpecial": True,
    "img": 'https://dummyimage.com/250x250/000/fff'
  },
  {
    "name": 'Vertical Medium (160x600)',
    "width": 160,
    "height": 600,
    "id": 'Wideskyscraper',
    "isSpecial": True,
    "img": 'https://dummyimage.com/160x600/000/fff'
  },
  {
    "name": 'Demi page (300x600)',
    "width": 300,
    "height": 600,
    "id": 'LargeSkyscraper',
    "isSpecial": True,
    "img": 'https://dummyimage.com/300x600/000/fff'
  },
  {
    "name": 'Horizontal Medium (728x90)',
    "width": 728,
    "height": 90,
    "id": 'Leaderboard',
    "isSpecial": True,
    "img": 'https://dummyimage.com/728x90/000/fff'
  },
  {
    "name": 'Horizontal (468x60)',
    "width": 468,
    "height": 60,
    "id": 'Banner',
    "isSpecial": False,
    "img": 'https://dummyimage.com/468x60/000/fff'
  },
  {
    "name": 'Vertical (120x600)',
    "width": 120,
    "height": 600,
    "id": 'Skyscraper',
    "isSpecial": False,
    "img": 'https://dummyimage.com/120x600/000/fff'
  },
  {
    "name": 'Rectangle Vertical (240x400)',
    "width": 240,
    "height": 400,
    "id": 'RV',
    "isSpecial": False,
    "img": 'https://dummyimage.com/120x600/000/fff'
  },
  {
    "name": 'Horizontal Large (970x90)',
    "width": 970,
    "height": 90,
    "id": 'LargerLeaderboard',
    "isSpecial": False,
    "img": 'https://dummyimage.com/970x90/000/fff'
  },
  {
    "name": 'Big Panneau (970x250)',
    "width": 970,
    "height": 250,
    "id": 'BigPanneau',
    "isSpecial": False,
    "img": 'https://dummyimage.com/970x250/000/fff'
  },
  {
    "name": 'Petit carré (200x200)',
    "width": 200,
    "height": 200,
    "id": 'Smallsquare',
    "isSpecial": False,
    "img": 'https://dummyimage.com/200x100/000/fff'
  },
  {
    "name": 'Not allowed (1280x720)',
    "width": 1280,
    "height": 720,
    "id": 'Smallsquare',
    "isSpecial": False,
    "img": 'https://dummyimage.com/1280x720/000/fff'
  }
];

