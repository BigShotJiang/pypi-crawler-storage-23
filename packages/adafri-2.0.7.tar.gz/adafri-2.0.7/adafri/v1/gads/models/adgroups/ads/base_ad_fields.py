from dataclasses import dataclass 
from  ......utils.utils import  BaseFieldsClass
import os
from google.cloud.firestore_v1.document import Timestamp
from google.api_core.datetime_helpers import DatetimeWithNanoseconds

DISPLAY_ADS_COLLECTION = os.environ.get('GADS_ADS_DISPLAY_COLLECTION');

@dataclass
class BaseAdFields(BaseFieldsClass):
    id = "id"
    ad_group_id = "ad_group_id"
    ad_id = "ad_id"
    name = "name"
    owner = "owner"
    status = "status"
    accountId = "accountId"
    clientCustomerId = "clientCustomerId"
    createdAt = "createdAt"
    createdBy = "createdBy"
    is_removed = "is_removed"
    adgroup_id_parent = "adgroup_id_parent"
    api_version = "api_version"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

BaseAdFieldsProps = {
    BaseAdFields.id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": ""
    },
    BaseAdFields.name: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.ad_id: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.ad_group_id: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.status: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.adgroup_id_parent: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.accountId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.clientCustomerId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.is_removed: {
        "internal": True,
        "type": bool,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": False
    },
    BaseAdFields.createdBy: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    BaseAdFields.createdAt: {
        "type": [int, str, Timestamp, DatetimeWithNanoseconds],
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdFields.api_version: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": "v0"
    }
}

STANDARD_FIELDS = BaseAdFields(fields_props=BaseAdFieldsProps).filtered_keys('pickable', True)
BASE_AD_PICKABLE_FIELDS = BaseAdFields(fields_props=BaseAdFieldsProps).filtered_keys('pickable', True)
