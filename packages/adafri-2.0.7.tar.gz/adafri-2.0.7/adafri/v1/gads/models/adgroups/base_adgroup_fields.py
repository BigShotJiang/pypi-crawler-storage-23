from dataclasses import dataclass
from typing import Any
from  .....utils.utils import  BaseFieldsClass
from google.cloud.firestore_v1.document import Timestamp
from google.api_core.datetime_helpers import DatetimeWithNanoseconds

@dataclass
class BaseAdGroupFields(BaseFieldsClass):
    id = "id"
    name = "name"
    campaign_id = "campaign_id"
    ad_group_id = "ad_group_id"
    campaign_id_parent = "campaign_id_parent"
    status = "status"
    ages = "ages"
    genders = "genders"
    clientCustomerId = "clientCustomerId"
    servingStatus = "servingStatus"
    owner = "owner"
    accountId = "accountId"
    createdAt = "createdAt"
    createdBy = "createdBy"
    devicesTargeted = "devicesTargeted"
    devicesExcluded = "devicesExcluded"
    is_removed = "is_removed"
    provider = "provider"
    bid = "bid"
    strategie = "strategie"
    api_version = "api_version"
    google_ads_ad_group = "google_ads_ad_group"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)



BaseAdGroupFieldsProps = {
    BaseAdGroupFields.id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": ""
    },
    BaseAdGroupFields.name: {
        "internal": True,
        "type": str,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": ""
    },
    BaseAdGroupFields.status: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": "ENABLED"
    },
    BaseAdGroupFields.owner: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdGroupFields.provider: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": "https://adafri.app"
    },
    BaseAdGroupFields.accountId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdGroupFields.campaign_id: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": 0
    },
    BaseAdGroupFields.campaign_id_parent: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdGroupFields.ad_group_id: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": 0
    },
    BaseAdGroupFields.ages: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    BaseAdGroupFields.genders: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    BaseAdGroupFields.clientCustomerId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdGroupFields.createdBy: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    BaseAdGroupFields.createdAt: {
        "type": [int, str, Timestamp, DatetimeWithNanoseconds],
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    BaseAdGroupFields.is_removed: {
        "internal": True,
        "type": bool,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": False
    },
    BaseAdGroupFields.devicesTargeted: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    BaseAdGroupFields.devicesExcluded: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    BaseAdGroupFields.strategie: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": "CPM"
    },
    BaseAdGroupFields.bid: {
        "internal": True,
        "type": float,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": 0.1
    },
    BaseAdGroupFields.api_version: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": "v0"
    },
    BaseAdGroupFields.google_ads_ad_group: {
        "internal": True,
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    }
}


STANDARD_FIELDS = BaseAdGroupFields(fields_props=BaseAdGroupFieldsProps).filtered_keys('pickable', True)
BASE_ADGROUP_PICKABLE_FIELDS = BaseAdGroupFields(fields_props=BaseAdGroupFieldsProps).filtered_keys('pickable', True)
