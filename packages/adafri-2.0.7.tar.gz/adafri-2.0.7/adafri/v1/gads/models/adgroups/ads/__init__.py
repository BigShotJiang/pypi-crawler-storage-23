from .base import BaseAd
from .base_ad_fields import BaseAdFields, BaseAdFieldsProps, BASE_AD_PICKABLE_FIELDS