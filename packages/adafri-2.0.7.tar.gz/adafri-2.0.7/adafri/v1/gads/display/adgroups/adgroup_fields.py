from dataclasses import dataclass 
from ...models.adgroups.base_adgroup_fields import BaseAdGroupFields, BaseAdGroupFieldsProps
import os

DISPLAY_ADGROUPS_COLLECTION = os.environ.get('GADS_ADGROUPS_DISPLAY_COLLECTION');

@dataclass
class AdGroupDisplayFields(BaseAdGroupFields):
    targetedPlacements = "targetedPlacements"
    excludedPlacements = "excludedPlacements"
    websites = "websites"
    youtubeChannels = "youtubeChannels"
    youtubeVideos = "youtubeVideos"
    images = "images"
    imagesNative = "imagesNative"
    user_interest = "user_interest"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = AdGroupDisplayFieldsProps



AdGroupDisplayFieldsProps = {
    **BaseAdGroupFieldsProps,
    AdGroupDisplayFields.targetedPlacements: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.excludedPlacements: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.websites: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.youtubeChannels: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.youtubeVideos: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.user_interest: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.images: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    AdGroupDisplayFields.imagesNative: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    }
}


STANDARD_FIELDS = AdGroupDisplayFields(fields_props=AdGroupDisplayFieldsProps).filtered_keys('pickable', True)
ADGROUP_DISPLAY_PICKABLE_FIELDS = AdGroupDisplayFields(fields_props=AdGroupDisplayFieldsProps).filtered_keys('pickable', True)
