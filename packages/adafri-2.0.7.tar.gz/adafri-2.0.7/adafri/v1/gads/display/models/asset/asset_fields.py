import os
from dataclasses import dataclass

from ......utils.utils import BaseClass, BaseFieldsClass, DictUtils

ASSETS_COLLECTION = os.environ.get('GADS_ASSETS_COLLECTION');


@dataclass
class AssetCropFields(BaseFieldsClass):
    x = "x"
    y = "y"
    xPosition = "xPosition"
    yPosition = "yPosition"
    crop_based_width = "crop_based_width"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = AssetCropFieldsProps
@dataclass
class AssetFullSizeInfoFields(BaseFieldsClass):
    imageWidth = "imageWidth"
    imageHeight = "imageHeight"
    imageUrl = "imageUrl"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = AssetsFieldsProps
@dataclass
class AssetsFields(BaseFieldsClass):
    id = "id"
    accountId = "accountId"
    name = "name"
    assetId = "assetId"
    owner = "owner"
    clientCustomerId = "clientCustomerId"
    imageMimeType = "imageMimeType"
    imageFileSize = "imageFileSize"
    assetName = "assetName"
    assetSubType = "assetSubType"
    fullSizeInfo = "fullSizeInfo"
    size = "size"
    file_url = "file_url"
    type = "type"
    data = "data"
    owner = "owner"
    usage = "usage"
    useFor = "useFor"
    width = "width"
    height = "height"
    imageUrl = "imageUrl"
    originalImageInfo = "originalImageInfo"
    crop = "crop"
    crop_state = "crop_state"
    content_type = "content_type"
    url = "url"
    hash = "hash"
    state = "state"
    account = "account"
    customer = "customer"
    adgroup = "adgroup"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = AssetsFieldsProps

AssetCropFieldsProps = {
    AssetCropFields.x: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetCropFields.y: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetCropFields.xPosition: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetCropFields.yPosition: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetCropFields.crop_based_width: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
}
AssetFullSizeInfoFieldsProps = {
    AssetFullSizeInfoFields.imageWidth: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetFullSizeInfoFields.imageHeight: {
        "internal": True,
        "type": int,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetFullSizeInfoFields.imageUrl: {
        "internal": True,
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    }
}

AssetsFieldsProps = {
    AssetsFields.id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.hash: {
        "internal": True,
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.size: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.accountId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.name: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.assetId: {
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.owner: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.clientCustomerId: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.imageMimeType: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.usage: {
        "type": list,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.useFor: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.width: {
        "type": [int, str],
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.height: {
        "type": [int, str],
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.imageUrl: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.originalImageInfo: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.assetName: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.assetSubType: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.imageFileSize: {
        "type": [int, str],
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.fullSizeInfo: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.crop: {
        "type": dict,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.data: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.crop_state: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.content_type: {
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.url: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.state: {
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    AssetsFields.account: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    AssetsFields.customer: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    AssetsFields.adgroup: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },

}

STANDARD_FIELDS = AssetsFields(fields_props=AssetsFieldsProps).filtered_keys('pickable', True)
ASSET_CROP_FIELDS = AssetCropFields(fields_props=AssetCropFieldsProps).filtered_keys('pickable', True)
FULL_SIZE_INFO_FIELDS = AssetFullSizeInfoFields(fields_props=AssetFullSizeInfoFieldsProps).filtered_keys('pickable', True)
ASSETS_PICKABLE_FIELDS = AssetsFields(fields_props=AssetsFieldsProps).filtered_keys('pickable', True)
ASSETS_NOT_PICKABLE_FIELDS = AssetsFields(fields_props=AssetsFieldsProps).filtered_keys('pickable', False)
