import os
from dataclasses import dataclass
from typing import Any

from google.cloud.firestore_v1.document import Timestamp

from .....utils.utils import (
    BaseClass,
    BaseFieldsClass,
    DictUtils,
    get_object_model_class,
    init_class_kwargs,
)
from ...models.adgroups.ads.base_ad_fields import BaseAdFields, BaseAdFieldsProps

DISPLAY_ADS_COLLECTION = os.environ.get('GADS_ADS_IMAGE_AD_COLLECTION');

@dataclass(init=False)
class ImageAdToPublishFields(BaseFieldsClass):
    id = "id"
    name = "name"
    mediaId = "mediaId"
    type = "type"
    width = "width"
    height = "height"
    urls = "urls"
    assetId = "assetId"
    url = "url"
    hash = "hash"
    previewUrl = "previewUrl"
    resourceName = "resourceName"
    sourceUrl = "sourceUrl"
    referenceId = "referenceId"
    type = "type"
    mimeType = "mimeType"
    owner = "owner"
    fileSize = "fileSize"
    clientCustomerId = "clientCustomerId"

@dataclass
class ImageAdBaseFields(BaseAdFields):
    mediaId = "mediaId"
    assetId = "assetId"
    url = "url"
    hash = "hash"
    mimeType = "mimeType"
    fileSize = "fileSize"
    previewUrl = "previewUrl"
    referenceId = "referenceId"
    type = "type"
    sourceUrl = "sourceUrl"
    urls = "urls"
    usedForRectangle = "usedForRectangle"
    usedForSquare = "usedForSquare"
    width = "width"
    height = "height"
    state = "state"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
@dataclass
class ImageAdFields(ImageAdBaseFields):
    ad_name = "ad_name"
    ad_type = "ad_type"
    url_image = "url_image"
    displayUrl = "displayUrl"
    finalAppUrls = "finalAppUrls"
    finalMobileUrls = "finalMobileUrls"
    finalUrls = "finalUrls"
    account = "account"
    adgroup = "adgroup"
    customer = "customer"
    google_ads_image_ad = "google_ads_image_ad"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = ImageAdFieldsProps

BaseImageAdFieldsProps = {
    **BaseAdFieldsProps,
    ImageAdFields.mediaId: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.assetId: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.mimeType: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.fileSize: {
        "internal": True,
        "type": [int, str],
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.previewUrl: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.referenceId: {
        "internal": True,
        "type": [str, int],
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.type: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": "IMAGE"
    },
    ImageAdFields.sourceUrl: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.state: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.urls: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.url: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.hash: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.usedForRectangle: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": False
    },
    ImageAdFields.usedForSquare: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": False
    },
    ImageAdFields.width: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.height: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.account: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    ImageAdFields.customer: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
    ImageAdFields.adgroup: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": False,
        "default_value": None
    },
}


ImageAdFieldsProps = {
    **BaseImageAdFieldsProps,
    ImageAdFields.ad_name: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.ad_type: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.url_image: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.displayUrl: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ImageAdFields.finalAppUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ImageAdFields.finalMobileUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ImageAdFields.finalUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ImageAdFields.google_ads_image_ad: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
}

STANDARD_FIELDS = ImageAdFields(fields_props=ImageAdFieldsProps).filtered_keys('pickable', True)
IMAGE_AD_PICKABLE_FIELDS = ImageAdFields(fields_props=ImageAdFieldsProps).filtered_keys('pickable', True)
