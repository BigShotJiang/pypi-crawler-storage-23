import os
from dataclasses import dataclass

from google.cloud.firestore_v1.document import Timestamp

from ....models.adgroups.ads.base_ad_fields import BaseAdFields, BaseAdFieldsProps

RESPONSIVE_DISPLAY_ADS_COLLECTION = os.environ.get('GADS_RESPONSIVE_DISPLAY_AD_COLLECTION');


@dataclass
class NativeAdToPublishFields(BaseAdFields):
    id = "id"
    titles = "titles"
    descriptions = "descriptions"
    brand = "brand"
    longHeadline = "longHeadline"
    marketingImages = "marketingImages"
    squareMarketingImages = "squareMarketingImages"
    logoImages = "logoImages"
    landscapeLogoImages = "landscapeLogoImages"
    videosAssets = "videosAssets"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

NativeAdToPublishFieldsProps = {
    NativeAdToPublishFields.id: {
        "internal": True,
        "type": str,
        "required": True,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.brand: {
        "internal": True,
        "type": str,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.titles: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.descriptions: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.videosAssets: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.marketingImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.squareMarketingImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.logoImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.landscapeLogoImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    NativeAdToPublishFields.longHeadline: {
        "internal": True,
        "type": [str, dict],
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
}
@dataclass
class ResponsiveDisplayAdBaseFields(BaseAdFields):
    headlines = "headlines"
    descriptions = "descriptions"
    longHeadline = "longHeadline"
    businessName = "businessName"
    marketingImages = "marketingImages"
    squareMarketingImages = "squareMarketingImages"
    logoImages = "logoImages"
    squareLogoImages = "squareLogoImages"
    youtubeVideos = "youtubeVideos"
    resourceName = "resourceName"
    adData = "adData"
    displayUrl = "displayUrl"
    finalAppUrls = "finalAppUrls"
    finalMobileUrls = "finalMobileUrls"
    finalUrls = "finalUrls"
    is_published = "is_published"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
@dataclass
class ResponsiveDisplayAdFields(ResponsiveDisplayAdBaseFields):
    responsive_display_ad = "responsive_display_ad"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = ResponsiveDisplayAdFieldsProps



ResponsiveDisplayAdFieldsProps = {
    **BaseAdFieldsProps,
    ResponsiveDisplayAdFields.businessName: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": "Adafri"
    },
    ResponsiveDisplayAdFields.headlines: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.longHeadline: {
        "internal": True,
        "type": [str, dict],
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.descriptions: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.marketingImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.squareMarketingImages: {
        "internal": True,
        "type": list,
        "required": True,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.logoImages: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.squareLogoImages: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.youtubeVideos: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.adData: {
        "internal": True,
        "type": dict,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.displayUrl: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.finalAppUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ResponsiveDisplayAdFields.finalMobileUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ResponsiveDisplayAdFields.finalUrls: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": []
    },
    ResponsiveDisplayAdFields.responsive_display_ad: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    ResponsiveDisplayAdFields.is_published: {
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": False
    }
}

STANDARD_FIELDS = ResponsiveDisplayAdFields(fields_props=ResponsiveDisplayAdFieldsProps).filtered_keys('pickable', True)
RESPONSIVE_DISPLAY_AD_PICKABLE_FIELDS = ResponsiveDisplayAdFields(fields_props=ResponsiveDisplayAdFieldsProps).filtered_keys('pickable', True)
