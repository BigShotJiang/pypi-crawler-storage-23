import os
from dataclasses import dataclass

from google.api_core.datetime_helpers import DatetimeWithNanoseconds
from google.cloud.firestore_v1.document import Timestamp

from ....utils.utils import BaseFieldsClass


@dataclass
class FileFields(BaseFieldsClass):
    id = "id"
    hash = 'hash'
    _id = '_id'
    accountId = 'accountId'
    blob_id = 'blob_id'
    blob_name = 'blob_name'
    bucket_name = 'bucket_name'
    colors = 'colors'
    content_type = 'content_type'
    created_time = 'created_time'
    directory_path = 'directory_path'
    extension = 'extension'
    file_source = 'file_source'
    file_url = 'file_url'
    url = "url"
    filename = 'filename'
    height = 'height'
    mime_type = 'mime_type'
    mode = 'mode'
    size = 'size'
    width = 'width'
    type = 'type'
    crop = "crop"
    crop_state = "crop_state"
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.class_fields_props = FileFieldProps

FileFieldProps = {
    FileFields.id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.hash: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields._id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.accountId: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.blob_id: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.blob_name: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.bucket_name: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.colors: {
        "internal": True,
        "type": list,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.content_type: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.created_time: {
        "internal": True,
        "type": [int, str, Timestamp, DatetimeWithNanoseconds],
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.directory_path: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.extension: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.file_source: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.file_url: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.filename: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.height: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.mime_type: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.mode: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.size: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.type: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": True,
        "editable": True,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.width: {
        "internal": True,
        "type": int,
        "required": False,
        "mutable": True,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.url: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.crop: {
        "internal": True,
        "type": dict,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
    FileFields.crop_state: {
        "internal": True,
        "type": str,
        "required": False,
        "mutable": False,
        "editable": False,
        "interactive": True,
        "pickable": True,
        "default_value": None
    },
}

FILE_FIELDS = FileFields(fields_props=FileFieldProps).filtered_keys('pickable', True)
