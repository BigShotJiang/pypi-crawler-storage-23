from user_agents import parse as user_agents_parse
def get_request_data(_request):
    data = None;
    if _request is None:
        return data
    if 'data' in _request.json:
        data = _request.json['data']
    elif 'data' in _request.form:
        data = _request.form['data']
    return data
def get_request_operation(_request):
    operation = None;
    allowed_operations = ['create', 'update', 'remove']
    if _request is None:
        return operation
    if 'operation' in _request.json:
        operation = _request.json['operation']
    elif 'operation' in _request.form:
        operation = _request.form['operation']
    print('opt', operation)
    if operation not in allowed_operations:
        operation = None
    return operation

def to_camel_case(s: str, separator="-") -> str:
    """
    Convert a string to camel case.

    Args:
        s (str): The input string to convert.

    Returns:
        str: The camel case version of the input string.
    """
    # Split the string into words
    words = s.split(separator)
    
    # Capitalize the first letter of each word except the first one
    # and join them together
    if not words:
        return ""
    
    # Convert the first word to lowercase and the rest to title case
    camel_case_string = words[0].lower() + ''.join(word.capitalize() for word in words[1:])
    
    return camel_case_string
def parse_request_headers(request) -> dict:
    """
    Parse the request headers and return them as a dictionary.
    
    Returns:
        dict: A dictionary containing the request headers.
    """
    headers_dict = {}
    for header, value in request.headers.items():
        headers_dict[to_camel_case(header)] = value
    return headers_dict
def get_request_infos(request):
    headers = parse_request_headers()
    user_agent_string = request.headers.get('User-Agent')
    
    # Parse the user agent string
    user_agent = user_agents_parse(user_agent_string)
    # user_agent.browse
    # Create a dictionary with relevant user agent information
    user_agent_info = {
        **headers,
        'browser': {
            'family': user_agent.browser.family,
            'version': user_agent.browser.version_string,
        },
        'os': {
            'family': user_agent.os.family,
            'version': user_agent.os.version_string,
        },
        'device': {
            'family': user_agent.device.family,
            'is_mobile': user_agent.is_mobile,
            'is_tablet': user_agent.is_tablet,
            'is_pc': user_agent.is_pc,
        },
        'user_agent_string': user_agent_string
    }
    return user_agent_info