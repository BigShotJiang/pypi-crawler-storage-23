def cloud_firestore_query_formatter(key: str, value: str | bool | int | float | list, comp: str = "=="):
    return {key: {"value": value, "comp": comp}}

def cloud_firestore_query_builder(object: dict):
    query = []
    for key in object:
        data_value = object.get(key)
        comp = "=="
        value = None
        if isinstance(data_value, dict):
            value = data_value.get("value", None)
            comp = data_value.get("comp", "==")
        else:
            value = data_value
        if value is None:
            continue
        query.append({"key": key, "value": value, "comp": comp})
    return query
