# Substr8 MCP Examples

> **LangGraph runs agents. Substr8 proves what they did.**

These examples show how any agent framework can plug into Substr8's governance layer to get:

- ✅ **Policy enforcement** — What the agent is allowed to do
- ✅ **Audit trail** — What the agent actually did
- ✅ **Tamper detection** — Proof the trail wasn't modified

## Quick Start (5 minutes)

### 1. Install Substr8

```bash
pip install substr8
```

### 2. Start the MCP Server

```bash
substr8 mcp start --local
```

You'll see:
```
MCP Server started
  Endpoint:  http://127.0.0.1:3456
  Mode:      local
```

### 3. Run an Example Agent

In another terminal:

```bash
# LangGraph
cd examples/langgraph
pip install -r requirements.txt
python agent.py
```

Output:
```
Results: [{'title': 'Result for: AI governance', 'url': '...'}]
Run ID: run-abc123

Audit: http://127.0.0.1:3456/tools/ledger/timeline?run_id=run-abc123
```

### 4. View the Audit Trail

```bash
curl -s http://127.0.0.1:3456/tools/ledger/timeline \
  -X POST -H "Content-Type: application/json" \
  -d '{"run_id": "run-abc123"}' | jq
```

You'll see a **hash-chained audit trail**:

```json
{
  "run_id": "run-abc123",
  "agent_ref": "langgraph:researcher",
  "entries": [
    {
      "sequence": 0,
      "type": "policy_check",
      "action": "web_search",
      "allowed": true,
      "hash": "sha256:903a858c..."
    },
    {
      "sequence": 1,
      "type": "tool_call",
      "tool": "web_search",
      "prev_hash": "sha256:903a858c...",
      "hash": "sha256:607b011a..."
    }
  ],
  "chain_valid": true
}
```

Each entry references the previous hash — **any tampering breaks the chain**.

---

## What This Proves

| What | How |
|------|-----|
| **Which agent version ran** | `agent_ref` in run context |
| **What it was allowed to do** | `policy_check` entries with allow/deny |
| **What it actually did** | `tool_call` entries with inputs/outputs |
| **That the log wasn't modified** | `prev_hash` chain + `chain_valid` |

---

## Examples

### LangGraph

```bash
cd langgraph/
python agent.py
```

Shows: State graph agent with governed web search.

### AutoGen

```bash
cd autogen/
python agent.py
```

Shows: Multi-agent system with governed function calls.

---

## MCP Tools Available

| Tool | Description |
|------|-------------|
| `substr8.run.start` | Create governed run context |
| `substr8.run.end` | Close run, verify chain |
| `substr8.policy.check` | Check if action is allowed |
| `substr8.tools.web_search` | Governed web search |
| `substr8.memory.write` | Write memory with provenance |
| `substr8.ledger.timeline` | Get audit trail |

---

## Architecture

```
Your Agent Framework (LangGraph, AutoGen, etc.)
         │
         ▼
    Substr8 MCP Server
         │
         ├── ACC (Policy Enforcement)
         ├── DCT (Audit Ledger)
         ├── GAM (Memory Provenance)
         └── Tools (Governed Execution)
```

**Key insight:** Your agent framework handles execution logic. Substr8 handles governance. You don't change your runtime — you add a trust layer.

---

## Next Steps

- [CLI Documentation](../README.md)
- [RFC: MCP Governance Plane](../docs/rfcs/RFC-0001-mcp-governance-plane.md)
- [Substr8 Website](https://substr8labs.com)

---

## License

MIT
