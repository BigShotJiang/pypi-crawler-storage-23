"""
MCP Server - Substr8 Governance Plane

Exposes Substr8 governance tools (ACC, DCT, GAM) via the Model Context Protocol,
allowing any compatible agent framework to connect.
"""

import asyncio
import json
import hashlib
import os
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict
import uuid

# FastAPI for HTTP transport (MCP can use stdio or HTTP)
try:
    from fastapi import FastAPI, HTTPException, Depends, Header
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False


@dataclass
class Run:
    """A governed execution run."""
    run_id: str
    project_id: str
    agent_ref: str
    agent_hash: Optional[str]
    policy_ref: str
    policy_hash: str
    metadata: Dict[str, Any]
    created_at: str
    ended_at: Optional[str] = None
    entries: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class MCPServerConfig:
    """MCP Server configuration."""
    host: str = "127.0.0.1"
    port: int = 3456
    api_key: Optional[str] = None
    project_id: Optional[str] = None
    policy_path: Optional[str] = None
    local_mode: bool = False
    control_plane_url: str = "https://mcp.substr8labs.com"


class Substr8MCPServer:
    """
    MCP Server that bridges external agent frameworks to Substr8 governance.
    """
    
    def __init__(self, config: MCPServerConfig):
        self.config = config
        self.runs: Dict[str, Run] = {}
        self.policies: Dict[str, Dict[str, Any]] = {}
        self._load_default_policy()
        
        if HAS_FASTAPI:
            self.app = self._create_app()
        else:
            self.app = None
    
    def _load_default_policy(self):
        """Load default ACC policy."""
        default_policy = {
            "version": "1.0",
            "capabilities": {
                "allow": [
                    "web_search",
                    "memory_read",
                    "memory_write",
                    "send_message"
                ],
                "deny": [
                    "shell_exec",
                    "file_delete",
                    "system_admin"
                ]
            }
        }
        policy_hash = hashlib.sha256(
            json.dumps(default_policy, sort_keys=True).encode()
        ).hexdigest()
        self.policies["default"] = {
            "policy": default_policy,
            "hash": f"sha256:{policy_hash[:16]}..."
        }
    
    def _create_app(self) -> FastAPI:
        """Create FastAPI app for MCP server."""
        app = FastAPI(
            title="Substr8 MCP Server",
            description="Governance plane for AI agents",
            version="1.0.0"
        )
        
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # Tool endpoints
        @app.post("/tools/run/start")
        async def start_run(payload: Dict[str, Any]):
            return self.tool_run_start(payload)
        
        @app.post("/tools/run/end")
        async def end_run(payload: Dict[str, Any]):
            return self.tool_run_end(payload)
        
        @app.post("/tools/policy/check")
        async def policy_check(payload: Dict[str, Any]):
            return self.tool_policy_check(payload)
        
        @app.post("/tools/ledger/append")
        async def ledger_append(payload: Dict[str, Any]):
            return self.tool_ledger_append(payload)
        
        @app.post("/tools/ledger/timeline")
        async def ledger_timeline(payload: Dict[str, Any]):
            return self.tool_audit_timeline(payload)
        
        @app.post("/tools/audit/timeline")
        async def audit_timeline(payload: Dict[str, Any]):
            return self.tool_audit_timeline(payload)
        
        @app.post("/tools/tool/invoke")
        async def tool_invoke(payload: Dict[str, Any]):
            return self.tool_invoke(payload)
        
        @app.post("/tools/verify/run")
        async def verify_run(payload: Dict[str, Any]):
            return self.tool_verify_run(payload)
        
        @app.post("/tools/memory/write")
        async def memory_write(payload: Dict[str, Any]):
            return self.tool_memory_write(payload)
        
        @app.post("/tools/memory/search")
        async def memory_search(payload: Dict[str, Any]):
            return self.tool_memory_search(payload)
        
        @app.post("/tools/web_search")
        async def web_search(payload: Dict[str, Any]):
            return self.tool_web_search(payload)
        
        # MCP discovery
        @app.get("/mcp/tools")
        async def list_tools():
            return self.get_tool_definitions()
        
        # Health check
        @app.get("/health")
        async def health():
            return {
                "status": "healthy",
                "version": "1.0.0",
                "runs_active": len([r for r in self.runs.values() if not r.ended_at])
            }
        
        return app
    
    # === Tool Implementations ===
    
    def tool_run_start(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Create a governed run context."""
        run_id = f"run-{uuid.uuid4().hex[:12]}"
        policy_ref = payload.get("policy_ref", "default")
        policy_data = self.policies.get(policy_ref, self.policies["default"])
        
        run = Run(
            run_id=run_id,
            project_id=payload.get("project_id", self.config.project_id or "default"),
            agent_ref=payload.get("agent_ref", "unknown"),
            agent_hash=payload.get("agent_hash"),
            policy_ref=policy_ref,
            policy_hash=policy_data["hash"],
            metadata=payload.get("metadata", {}),
            created_at=datetime.now(timezone.utc).isoformat()
        )
        self.runs[run_id] = run
        
        return {
            "run_id": run_id,
            "policy_hash": policy_data["hash"],
            "created_at": run.created_at
        }
    
    def tool_run_end(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """End a run and finalize ledger."""
        run_id = payload.get("run_id")
        if run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        
        run = self.runs[run_id]
        run.ended_at = datetime.now(timezone.utc).isoformat()
        
        # Verify chain
        chain_valid = self._verify_chain(run)
        
        return {
            "run_id": run_id,
            "ended_at": run.ended_at,
            "entries": len(run.entries),
            "chain_valid": chain_valid
        }
    
    def tool_policy_check(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Check ACC policy for an action."""
        run_id = payload.get("run_id")
        action = payload.get("action")
        
        if run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        
        run = self.runs[run_id]
        policy_data = self.policies.get(run.policy_ref, self.policies["default"])
        policy = policy_data["policy"]
        
        # Check policy
        allow_list = policy.get("capabilities", {}).get("allow", [])
        deny_list = policy.get("capabilities", {}).get("deny", [])
        
        if action in deny_list:
            allowed = False
            reason = f"action '{action}' in deny list"
        elif action in allow_list:
            allowed = True
            reason = f"action '{action}' in allow list"
        else:
            # Default: allow with warning
            allowed = True
            reason = f"action '{action}' not in policy (unverified)"
        
        # Log the check
        self._append_entry(run, {
            "type": "policy_check",
            "action": action,
            "allowed": allowed,
            "reason": reason
        })
        
        return {
            "allow": allowed,
            "reason": reason,
            "policy_hash": policy_data["hash"]
        }
    
    def tool_ledger_append(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Append entry to DCT ledger."""
        run_id = payload.get("run_id")
        if run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        
        run = self.runs[run_id]
        entry = self._append_entry(run, payload.get("entry", {}))
        
        return {
            "entry_id": entry["entry_id"],
            "entry_hash": entry["hash"],
            "sequence": entry["sequence"]
        }
    
    def tool_audit_timeline(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Returns the human-debuggable audit trail for a run (DCT-derived).
        
        "Show me the receipts. Show me what happened."
        """
        run_id = payload.get("run_id")
        if not run_id or run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        
        run = self.runs[run_id]
        
        # Format entries for human readability
        formatted_entries = []
        for entry in run.entries:
            formatted = {
                "seq": entry["sequence"],
                "type": entry.get("type"),
                "hash": entry["hash"],
                "prev_hash": entry["prev_hash"]
            }
            # Add type-specific fields
            if entry.get("type") == "policy_check":
                formatted["action"] = entry.get("action")
                formatted["allowed"] = entry.get("allowed")
            elif entry.get("type") in ("tool_call", "tool_denied"):
                formatted["tool"] = entry.get("tool")
                if entry.get("type") == "tool_denied":
                    formatted["allowed"] = False
                    formatted["reason"] = entry.get("reason")
            elif entry.get("type") == "memory_write":
                formatted["memory_id"] = entry.get("memory_id")
                formatted["linked_to"] = entry.get("linked_ledger_hash")
            formatted_entries.append(formatted)
        
        return {
            "run_id": run_id,
            "agent_ref": run.agent_ref,
            "policy_hash": run.policy_hash,
            "started_at": run.created_at,
            "ended_at": run.ended_at,
            "entries": formatted_entries,
            "chain_valid": self._verify_chain(run)
        }
    
    def tool_memory_write(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Write memory with provenance.
        
        Requires run_id. Strongly encourages ledger_entry_hash for provenance linking.
        """
        run_id = payload.get("run_id")
        if not run_id or run_id not in self.runs:
            raise ValueError(f"Unknown or missing run_id: {run_id}")
        
        run = self.runs[run_id]
        content = payload.get("content", "")
        memory_type = payload.get("type", "general")
        tags = payload.get("tags", [])
        linked_ledger_hash = payload.get("ledger_entry_hash")  # Provenance link
        
        # Generate memory ID
        memory_id = f"mem-{uuid.uuid4().hex[:12]}"
        commit_hash = hashlib.sha256(content.encode()).hexdigest()[:12]
        
        # Log to ledger with provenance link
        entry = self._append_entry(run, {
            "type": "memory_write",
            "memory_id": memory_id,
            "memory_type": memory_type,
            "content_hash": f"sha256:{commit_hash}",
            "tags": tags,
            "linked_ledger_hash": linked_ledger_hash  # Links back to source action
        })
        
        return {
            "memory_id": memory_id,
            "commit": commit_hash,
            "stored_at": datetime.now(timezone.utc).isoformat(),
            "file_path": f"memory/{memory_type}/{tags[0] if tags else 'general'}.md",
            "ledger_entry_hash": entry["hash"],
            "provenance_linked": linked_ledger_hash is not None
        }
    
    def tool_memory_search(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Search memory with provenance output."""
        # Stub - would integrate with GAM
        return {
            "results": [],
            "query": payload.get("query", ""),
            "provenance": {
                "search_at": datetime.now(timezone.utc).isoformat()
            }
        }
    
    def tool_invoke(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Unified governed tool gateway.
        
        One entry point for any tool: ACC check → DCT log → execute → DCT log result.
        """
        run_id = payload.get("run_id")
        tool = payload.get("tool")
        args = payload.get("args", {})
        
        if not run_id or run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        if not tool:
            raise ValueError("Tool name required")
        
        run = self.runs[run_id]
        
        # Step 1: ACC check
        policy_check = self.tool_policy_check({
            "run_id": run_id,
            "action": tool
        })
        
        if not policy_check["allow"]:
            # Log the denial
            entry = self._append_entry(run, {
                "type": "tool_denied",
                "tool": tool,
                "args": args,
                "reason": policy_check["reason"]
            })
            return {
                "allowed": False,
                "reason": policy_check["reason"],
                "ledger_entry_hash": entry["hash"],
                "policy_decision_hash": policy_check["policy_hash"]
            }
        
        # Step 2: Execute tool
        result = self._execute_tool(tool, args)
        
        # Step 3: Log execution with result
        entry = self._append_entry(run, {
            "type": "tool_call",
            "tool": tool,
            "input": args,
            "output": result,
            "output_hash": hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()[:16]
        })
        
        return {
            "allowed": True,
            "result": result,
            "ledger_entry_hash": entry["hash"],
            "policy_decision_hash": policy_check["policy_hash"]
        }
    
    def _execute_tool(self, tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool and return result. Stub implementations."""
        if tool == "web_search":
            query = args.get("query", "")
            return {
                "items": [
                    {"title": f"Result for: {query}", "url": "https://example.com", "snippet": "..."}
                ]
            }
        elif tool == "send_message":
            return {"status": "sent", "message_id": f"msg-{uuid.uuid4().hex[:8]}"}
        elif tool == "db_query":
            return {"rows": [], "count": 0}
        else:
            return {"status": "executed", "tool": tool}
    
    def tool_verify_run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        One-shot verifier: checks chain integrity and provenance links.
        
        This is the "auditor tool" — makes claims cryptographic, not vibes.
        """
        run_id = payload.get("run_id")
        check_provenance = payload.get("check_provenance", True)
        
        if not run_id or run_id not in self.runs:
            raise ValueError(f"Unknown run: {run_id}")
        
        run = self.runs[run_id]
        errors = []
        
        # Check 1: Ledger chain integrity
        chain_valid = True
        prev_hash = "sha256:" + "0" * 64
        for i, entry in enumerate(run.entries):
            if entry["prev_hash"] != prev_hash:
                chain_valid = False
                errors.append(f"Entry {i}: prev_hash mismatch")
            prev_hash = entry["hash"]
        
        # Check 2: Provenance links (memory writes reference valid ledger entries)
        provenance_valid = True
        if check_provenance:
            ledger_hashes = {e["hash"] for e in run.entries}
            memory_writes = [e for e in run.entries if e.get("type") == "memory_write"]
            for mw in memory_writes:
                linked_hash = mw.get("linked_ledger_hash")
                if linked_hash and linked_hash not in ledger_hashes:
                    provenance_valid = False
                    errors.append(f"Memory {mw.get('memory_id')}: invalid ledger link")
        
        return {
            "run_id": run_id,
            "ledger_chain_valid": chain_valid,
            "checked_entries": len(run.entries),
            "provenance_valid": provenance_valid,
            "errors": errors
        }
    
    def tool_web_search(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Governed web search (ACC + DCT). Wrapper around tool_invoke."""
        return self.tool_invoke({
            "run_id": payload.get("run_id"),
            "tool": "web_search",
            "args": {"query": payload.get("query", "")}
        })
    
    # === Helper Methods ===
    
    def _append_entry(self, run: Run, data: Dict[str, Any]) -> Dict[str, Any]:
        """Append entry to run's ledger with hash chain."""
        prev_hash = run.entries[-1]["hash"] if run.entries else "sha256:" + "0" * 64
        
        entry = {
            "entry_id": f"e-{uuid.uuid4().hex[:12]}",
            "sequence": len(run.entries),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "prev_hash": prev_hash,
            **data
        }
        
        # Compute hash
        entry_bytes = json.dumps(entry, sort_keys=True).encode()
        entry["hash"] = f"sha256:{hashlib.sha256(entry_bytes).hexdigest()}"
        
        run.entries.append(entry)
        return entry
    
    def _verify_chain(self, run: Run) -> bool:
        """Verify hash chain integrity."""
        prev_hash = "sha256:" + "0" * 64
        for entry in run.entries:
            if entry["prev_hash"] != prev_hash:
                return False
            prev_hash = entry["hash"]
        return True
    
    def get_tool_definitions(self) -> List[Dict[str, Any]]:
        """Get MCP tool definitions - the 5 killer tools."""
        return [
            # 1) Run lifecycle
            {
                "name": "substr8.run.start",
                "description": "Create run context + bind identity + policy snapshot",
                "parameters": {
                    "project_id": {"type": "string", "required": True},
                    "agent_ref": {"type": "string", "required": True},
                    "agent_hash": {"type": "string", "optional": True},
                    "policy_ref": {"type": "string", "default": "default"},
                    "metadata": {"type": "object", "optional": True}
                }
            },
            {
                "name": "substr8.run.end",
                "description": "Close run and finalize ledger",
                "parameters": {
                    "run_id": {"type": "string", "required": True}
                }
            },
            # 2) The unified governed tool gateway
            {
                "name": "substr8.tool.invoke",
                "description": "Governed tool gateway: ACC check → DCT log → execute → log result",
                "parameters": {
                    "run_id": {"type": "string", "required": True},
                    "tool": {"type": "string", "required": True},
                    "args": {"type": "object", "optional": True}
                }
            },
            # 3) Memory with provenance
            {
                "name": "substr8.memory.write",
                "description": "Write memory with provenance link to ledger entry",
                "parameters": {
                    "run_id": {"type": "string", "required": True},
                    "type": {"type": "string"},
                    "content": {"type": "string", "required": True},
                    "tags": {"type": "array", "items": {"type": "string"}},
                    "ledger_entry_hash": {"type": "string", "description": "Link to source action"}
                }
            },
            # 4) Audit timeline
            {
                "name": "substr8.audit.timeline",
                "description": "Get human-debuggable audit trail for a run",
                "parameters": {
                    "run_id": {"type": "string", "required": True}
                }
            },
            # 5) One-shot verifier
            {
                "name": "substr8.verify.run",
                "description": "Verify chain integrity and provenance links",
                "parameters": {
                    "run_id": {"type": "string", "required": True},
                    "check_provenance": {"type": "boolean", "default": True}
                }
            },
            # Bonus: Policy explain
            {
                "name": "substr8.policy.check",
                "description": "Check ACC policy for an action (with reason)",
                "parameters": {
                    "run_id": {"type": "string", "required": True},
                    "action": {"type": "string", "required": True}
                }
            },
            # Convenience wrappers
            {
                "name": "substr8.memory.search",
                "description": "Search memory with provenance output",
                "parameters": {
                    "query": {"type": "string", "required": True}
                }
            }
        ]
    
    def run(self):
        """Run the MCP server."""
        if not HAS_FASTAPI:
            raise RuntimeError("FastAPI not installed. Run: pip install fastapi uvicorn")
        
        uvicorn.run(
            self.app,
            host=self.config.host,
            port=self.config.port,
            log_level="info"
        )


def create_server(
    host: str = "127.0.0.1",
    port: int = 3456,
    api_key: Optional[str] = None,
    project_id: Optional[str] = None,
    local_mode: bool = False
) -> Substr8MCPServer:
    """Create and return an MCP server instance."""
    config = MCPServerConfig(
        host=host,
        port=port,
        api_key=api_key,
        project_id=project_id,
        local_mode=local_mode
    )
    return Substr8MCPServer(config)
