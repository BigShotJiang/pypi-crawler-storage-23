"""
Substr8 CLI - Unified command-line interface

Usage:
    substr8 gam <command>      Git-Native Agent Memory
    substr8 fdaa <command>     File-Driven Agent Architecture (planned)
    substr8 acc <command>      Agent Capability Control (planned)
"""

import click
from rich.console import Console

console = Console()


@click.group()
@click.version_option(version="1.2.0", prog_name="substr8")
def main():
    """Substr8 Platform CLI - Verifiable AI Infrastructure"""
    pass


# === GAM Integration ===

from substr8.gam.cli import main as gam_main

# Register GAM as a subcommand group
main.add_command(gam_main, name="gam")


# === FDAA Integration ===

from substr8.fdaa.cli import main as fdaa_main

# Register FDAA as a subcommand group
main.add_command(fdaa_main, name="fdaa")


# === ACC (Agent Capability Control) ===

@main.group()
def acc():
    """Agent Capability Control - Runtime capability enforcement"""
    pass


@acc.command("check")
@click.argument("agent_id")
@click.argument("tool")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def acc_check(agent_id: str, tool: str, as_json: bool):
    """Check if an agent is allowed to use a tool.
    
    Example:
        substr8 acc check analyst web_search
        substr8 acc check analyst shell_exec --json
    """
    from substr8.acc import check
    
    result = check(agent_id, tool)
    
    if as_json:
        import json
        console.print(json.dumps(result.to_dict(), indent=2))
    else:
        if result.allowed:
            console.print(f"[green]✓ ALLOWED[/green] {tool}")
        else:
            console.print(f"[red]✗ DENIED[/red] {tool}")
        console.print(f"  [dim]Reason:[/dim] {result.reason}")
        console.print(f"  [dim]Agent:[/dim] {result.agent_ref}")
        if result.policy_hash:
            console.print(f"  [dim]Policy:[/dim] {result.policy_hash[:20]}...")


@acc.command("batch")
@click.argument("agent_id")
@click.argument("tools", nargs=-1, required=True)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def acc_batch(agent_id: str, tools: tuple, as_json: bool):
    """Check multiple tools at once.
    
    Example:
        substr8 acc batch analyst web_search memory_read shell_exec
    """
    from substr8.acc import check_batch
    
    results = check_batch(agent_id, list(tools))
    
    if as_json:
        import json
        console.print(json.dumps({k: v.to_dict() for k, v in results.items()}, indent=2))
    else:
        for tool_name, result in results.items():
            if result.allowed:
                console.print(f"[green]✓[/green] {tool_name}")
            else:
                console.print(f"[red]✗[/red] {tool_name} [dim]({result.reason})[/dim]")


@acc.command("policy")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def acc_policy(agent_id: str, as_json: bool):
    """Show the ACC policy for an agent.
    
    Example:
        substr8 acc policy analyst
    """
    from substr8.acc import load_policy_from_config
    
    policy = load_policy_from_config(agent_id)
    
    if policy is None:
        console.print(f"[yellow]No ACC policy found for agent '{agent_id}'[/yellow]")
        return
    
    if as_json:
        console.print(policy.to_json())
    else:
        console.print(f"[bold]Policy for {policy.agent_ref} v{policy.version}[/bold]")
        console.print(f"[dim]Hash:[/dim] {policy.policy_hash}")
        console.print()
        console.print("[bold]Rules:[/bold]")
        for i, rule in enumerate(policy.rules):
            action = "[green]allow[/green]" if rule.action.value == "allow" else "[red]deny[/red]"
            console.print(f"  {i+1}. {action} [cyan]{rule.tool}[/cyan]")


# === DCT Integration (Audit Ledger) ===

from substr8.dct.cli import main as dct_main

# Register DCT as a subcommand group
main.add_command(dct_main, name="dct")


# === Gateway (Docker Swarm Orchestration) ===

from substr8.gateway.cli import main as gateway_main

# Register Gateway as a subcommand group
main.add_command(gateway_main, name="gateway")


# === RIL (Runtime Integrity Layer) ===

from substr8.ril.cli import main as ril_main

# Register RIL as a subcommand group
main.add_command(ril_main, name="ril")


# === MCP Server ===

from substr8.mcp.cli import mcp as mcp_main

# Register MCP as a subcommand group
main.add_command(mcp_main, name="mcp")


# === Developer Tools ===

from substr8.dev.cli import dev as dev_main

# Register dev as a subcommand group
main.add_command(dev_main, name="dev")


# === Info Commands ===

@main.command()
def info():
    """Show Substr8 platform information."""
    import platform
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich import box
    
    # Header
    console.print()
    console.print("[bold cyan]  ███████╗██╗   ██╗██████╗ ███████╗████████╗██████╗  █████╗ [/bold cyan]")
    console.print("[bold cyan]  ██╔════╝██║   ██║██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗[/bold cyan]")
    console.print("[bold cyan]  ███████╗██║   ██║██████╔╝███████╗   ██║   ██████╔╝╚█████╔╝[/bold cyan]")
    console.print("[bold cyan]  ╚════██║██║   ██║██╔══██╗╚════██║   ██║   ██╔══██╗██╔══██╗[/bold cyan]")
    console.print("[bold cyan]  ███████║╚██████╔╝██████╔╝███████║   ██║   ██║  ██║╚█████╔╝[/bold cyan]")
    console.print("[bold cyan]  ╚══════╝ ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚════╝ [/bold cyan]")
    console.print()
    console.print("[dim]  Verifiable AI Infrastructure[/dim]")
    console.print()
    
    # Components table
    table = Table(show_header=True, box=box.ROUNDED, title="[bold]Components[/bold]")
    table.add_column("Module", style="cyan", width=8)
    table.add_column("Status", width=10)
    table.add_column("Description", style="dim")
    
    table.add_row("fdaa", "[green]✓ ready[/green]", "File-Driven Agent Architecture")
    table.add_row("gam", "[green]✓ ready[/green]", "Git-Native Agent Memory")
    table.add_row("acc", "[green]✓ ready[/green]", "Agent Capability Control")
    table.add_row("dct", "[green]✓ ready[/green]", "Deterministic Capability Tokens")
    table.add_row("ril", "[green]✓ ready[/green]", "Runtime Integrity Layer")
    table.add_row("mcp", "[green]✓ ready[/green]", "MCP Server - Universal framework bridge")
    table.add_row("gateway", "[green]✓ ready[/green]", "Docker Swarm orchestration")
    
    console.print(table)
    console.print()
    
    # Quick start
    console.print("[bold]Quick Start[/bold]")
    console.print("  [cyan]substr8 fdaa init my-agent[/cyan]    Create an agent workspace")
    console.print("  [cyan]substr8 gam init[/cyan]              Initialize memory in current repo")
    console.print("  [cyan]substr8 mcp start[/cyan]             Start MCP server for any framework")
    console.print("  [cyan]substr8 dev init[/cyan]              Scaffold LangGraph/AutoGen examples")
    console.print()
    
    # Links
    console.print("[bold]Links[/bold]")
    console.print("  [dim]Docs:[/dim]      https://substr8labs.com/docs")
    console.print("  [dim]GitHub:[/dim]    https://github.com/Substr8-Labs")
    console.print("  [dim]PyPI:[/dim]      https://pypi.org/project/substr8")
    console.print()
    
    # Version & system
    console.print(f"[dim]v0.9.0 • Python {platform.python_version()} • {platform.system()} {platform.machine()}[/dim]")
    console.print()


if __name__ == "__main__":
    main()
