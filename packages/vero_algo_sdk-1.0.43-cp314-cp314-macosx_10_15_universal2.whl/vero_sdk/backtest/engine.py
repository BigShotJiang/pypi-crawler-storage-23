"""
Backtest simulation engine for Vero Algo SDK.

Runs strategy against historical data and produces performance report.
"""

import asyncio
from typing import List, Optional, Any, TYPE_CHECKING, Callable
from datetime import datetime, timedelta

from ..models import StrategyMetrics, PerformanceReport, ClosedPosition, PositionSide
from ..metrics import calculate_metrics
from ..report import build_report
from ..strategy.symbol import Bar, Bars
from ..strategy.context import TradingContext
from ..utils.logging_config import VeroLogger, get_logger
from ..utils.defaults import DEFAULT_MICRO_API_SERVER, DEFAULT_COMMISSION_PCT, DEFAULT_SLIPPAGE_TICKS
from ..config import TimeResolution

if TYPE_CHECKING:
    from ..strategy.base import Strategy

logger = VeroLogger("backtest")


class BacktestEngine:
    """
    Backtesting simulation engine.
    
    Runs a strategy against historical bar data and produces
    performance metrics and trade history.
    """
    
    def __init__(
        self,
        strategy: "Strategy",
        symbols: List[str],
        start_date: int,
        end_date: int,
        initial_capital: float = 100000,
        resolution: int = TimeResolution.DAY_1,
        commission_pct: float = DEFAULT_COMMISSION_PCT,
        slippage_ticks: int = DEFAULT_SLIPPAGE_TICKS,
        fill_ratio: float = 1.0,
        warmup_bars: int = 100,
        benchmark_symbol: str = "",
        risk_free_rate: float = 0.02,
        jwt_token: str = "",
        account_id: str = "user",
        max_nav_usage_pct: float = 100.0,
    ):
        """
        Initialize BacktestEngine.
        
        Args:
            strategy: Strategy instance to test
            symbols: List of symbols to load
            start_date: Start date as Unix timestamp in milliseconds
            end_date: End date as Unix timestamp in milliseconds
            initial_capital: Starting capital
            resolution: Bar resolution in seconds
            commission_pct: Commission percentage per trade
            slippage_ticks: Slippage in ticks per trade
            fill_ratio: Order fill ratio (0.0-1.0)
            warmup_bars: Number of warmup bars for indicators
            benchmark_symbol: Benchmark symbol for comparison
            risk_free_rate: Annual risk-free rate for Sharpe ratio
            jwt_token: JWT token for API data fetching
            account_id: Account ID for the simulation
        """
        self.strategy = strategy
        self.symbols = symbols
        self.start_date = start_date  # Unix ms
        self.end_date = end_date  # Unix ms
        self.initial_capital = initial_capital
        self.resolution = resolution
        self.commission_pct = commission_pct
        self.slippage_ticks = slippage_ticks
        self.fill_ratio = fill_ratio
        self.warmup_bars = warmup_bars
        self.benchmark_symbol = benchmark_symbol
        self.risk_free_rate = risk_free_rate
        self.jwt_token = jwt_token
        self.account_id = account_id
        self.max_nav_usage_pct = max_nav_usage_pct
        
        # Historical data
        self._bars_data: dict = {}  # symbol -> list of Bar
        self._current_bar_index = 0
        self._market_data = None  # MarketDataService, set during run()
        
        # Results tracking
        self._equity_curve: List[float] = []
        self._equity_dates: List[int] = []  # Unix timestamps in milliseconds
        self._closed_positions: List[ClosedPosition] = []
    

    async def run(self, on_progress: Optional[Callable[[float], None]] = None) -> PerformanceReport:
        """
        Execute the backtest.
        
        Args:
            on_progress: Optional callback(float) for progress percentage (0.0 to 100.0)
            
        Returns:
            PerformanceReport with all metrics, equity curve, and trade history
        """
        from ..features.market_data import MarketDataService
        from ..config import VeroConfig, DEFAULT_MICRO_API_SERVER
        
        _start_dt = datetime.utcfromtimestamp(self.start_date / 1000)
        _end_dt = datetime.utcfromtimestamp(self.end_date / 1000)
        logger.info(f"Starting backtest from {_start_dt.date()} to {_end_dt.date()}")
        logger.info(f"Initial capital: {self.initial_capital:,.0f}")
        logger.info(f"Symbols: {', '.join(self.symbols)}")
        
        # Initialize Services
        from ..utils.defaults import DEFAULT_AUTH_SERVER
        
        config = VeroConfig(
            micro_api_server=DEFAULT_MICRO_API_SERVER,
            auth_server=DEFAULT_AUTH_SERVER
        )
        
        # Authenticate if token provided
        if self.jwt_token:
            logger.info("Setting up auth for backtest data...")
            config.jwt_token = self.jwt_token
        
        market_data = MarketDataService(config)
        self._market_data = market_data

        # Initialize context with strategy
        self.strategy._context = TradingContext(initial_capital=self.initial_capital, max_nav_usage_pct=self.max_nav_usage_pct)
        
        # Register centralized trade-closed listeners on the new context
        self.strategy._setup_trade_listeners()
        
        # Load Symbol Data (Master + Margin)
        for symbol in self.symbols:
            logger.info(f"Fetching Product Info for {symbol}...")
            sym_obj = self.strategy._context.add_symbol(symbol)
            
            # Fetch Master
            try:
                master = market_data.get_product_master(symbol)
                if master:
                    sym_obj.update_from_master(master)
                    logger.debug(f"Updated {symbol} master data: Tick={sym_obj.tick_size}, Lot={sym_obj.lot_size}")
            except Exception as e:
                logger.warning(f"Failed to fetch master for {symbol}: {e}")
                
            # Fetch Margin
            try:
                mr = market_data.get_margin_rate(symbol)
                sym_obj.margin_rate = mr
                logger.debug(f"Updated {symbol} Margin Rate: {mr}")
            except Exception:
                pass
                
            logger.debug(f"Symbol {symbol}: tick_size={sym_obj.tick_size}, lot_size={sym_obj.lot_size}, point_value={sym_obj.point_value}, margin_rate={sym_obj.margin_rate}")
        
        # Load historical data
        self._load_historical_data(market_data)
        
        if not self._bars_data:
            logger.error("No historical data loaded")
            return PerformanceReport()
            
        # ... (rest of function)

        
        # Record initial equity
        self._equity_curve.append(self.initial_capital)
        self._equity_dates.append(self.start_date)
        
        # Call strategy on_start
        self.strategy._running = True
        if asyncio.iscoroutinefunction(self.strategy.on_start):
            await self.strategy.on_start()
        else:
            self.strategy.on_start()
        
        # Get the primary symbol for bar iteration
        primary_symbol = self.symbols[0]
        bars = self._bars_data.get(primary_symbol, [])
        
        if not bars:
            logger.error(f"No bars for primary symbol {primary_symbol}")
            return PerformanceReport()
        
        logger.info(f"Processing {len(bars)} bars...")
        
        # Iterate through bars
        for i, bar in enumerate(bars):
            self._current_bar_index = i
            
            # Progress update
            if on_progress and i % 100 == 0:
                progress = (i / len(bars)) * 100.0
                if asyncio.iscoroutinefunction(on_progress):
                     await on_progress(progress)
                else:
                    on_progress(progress)
            
            # Update context time (convert datetime to Unix ms if needed)
            bar_time_ms = int(bar.time.timestamp() * 1000) if isinstance(bar.time, datetime) else bar.time
            self.strategy._context.set_time(bar_time_ms)
            
            # Update all symbol bars from historical data
            for symbol_name in self.symbols:
                symbol = self.strategy._context.get_symbol(symbol_name)
                if symbol and symbol_name in self._bars_data:
                    symbol_bars = self._bars_data[symbol_name]
                    if i < len(symbol_bars):
                        sym_bar = symbol_bars[i]
                        symbol.bars.add(sym_bar)
            
            # Update position prices
            self.strategy._context.update_prices()
            
            # Check risk limits and close positions if needed
            if self.strategy._risk_manager:
                positions_to_close = self.strategy._risk_manager.check_positions()
                for pos_id in positions_to_close:
                    pos = self.strategy._context.positions.get(pos_id)
                    if pos:
                        reason = self._get_close_reason(pos)
                        closed = self._close_position(pos, close_reason=reason)
                        if closed:
                            self._closed_positions.append(closed)
            else:
                # Direct SL/TP check when no risk manager is configured
                for pos_id, pos in list(self.strategy._context.positions.items()):
                    if pos.should_stop_loss() or pos.should_take_profit():
                        if pos.should_stop_loss():
                            if pos.trailing_stop:
                                reason = "trailing"
                            else:
                                reason = "sl"
                        else:
                            reason = "tp"
                        logger.info(f"[Backtest] {reason.upper()} triggered for {pos.symbol}")
                        closed = self._close_position(pos, close_reason=reason)
                        if closed:
                            self._closed_positions.append(closed)
            
            # Call strategy on_bar for primary symbol
            if asyncio.iscoroutinefunction(self.strategy.on_bar):
                await self.strategy.on_bar(bar)
            else:
                self.strategy.on_bar(bar)
            
            # Record equity
            self._equity_curve.append(self.strategy._context.equity)
            self._equity_dates.append(bar_time_ms)
        
        # Close any remaining positions at final price
        if on_progress:
            if asyncio.iscoroutinefunction(on_progress):
                await on_progress(100.0)
            else:
                on_progress(100.0)

        for pos in list(self.strategy._context.positions.values()):
            closed = self._close_position(pos)
            if closed:
                self._closed_positions.append(closed)
        
        # Call strategy on_stop
        self.strategy.on_stop()
        self.strategy._running = False
        
        # Calculate final metrics
        logger.info("Calculating metrics...")
        
        # Use history from context as it contains all closed positions (manual + risk + end of test)
        all_trades = self.strategy._context.history
        
        metrics = calculate_metrics(
            trades=all_trades,
            equity_curve=self._equity_curve,
            initial_capital=self.initial_capital,
            start_date=self.start_date,
            end_date=self.end_date,
        )
        
        # Generate report
        report = build_report(
            strategy_name=self.strategy.name,
            start_date=self.start_date,
            end_date=self.end_date,
            metrics=metrics,
            equity_curve=self._equity_curve,
            equity_dates=self._equity_dates,
        )
        report.trades = all_trades
        
        logger.info(f"Backtest complete. Net profit: {metrics.net_profit:,.2f} ({metrics.net_profit_pct:.2f}%)")
        logger.info(f"Total trades: {metrics.total_trades}, Win rate: {metrics.win_rate:.1f}%")
        
        # Update strategy metrics property
        metrics.current_nav = self.strategy._context.available_nav
        self.strategy._metrics = metrics
        
        # Fire callback events for metrics and report
        if hasattr(self.strategy, '_callback') and self.strategy._callback:
            from ..callback import CallbackEventType
            # Strategy metrics callback
            self.strategy._callback.send_event(
                CallbackEventType.STRATEGY_METRICS,
                data=metrics.to_dict(),
                strategy_name=self.strategy.name,
            )
            # Report callback
            self.strategy._callback.send_event(
                CallbackEventType.REPORT,
                data=report.to_dict(),
                strategy_name=self.strategy.name,
            )
            # Flush pending callbacks before returning
            self.strategy._callback.flush()
        
        return report
    
    def _load_historical_data(self, market_data) -> None:
        """Load historical bar data for all symbols."""
        # Reuse service
        
        start_ts = self.start_date
        end_ts = self.end_date
        
        for symbol in self.symbols:
            logger.info(f"Loading historical data for {symbol}...")
            
            try:
                candles = market_data.fetch_candles(
                    symbol=symbol,
                    resolution=self.resolution,
                    from_ts=start_ts,
                    to_ts=end_ts,
                )
                
                bars = [Bar.from_candle(c, symbol) for c in candles]
                self._bars_data[symbol] = bars
                
                logger.info(f"Loaded {len(bars)} bars for {symbol}")
                
                if not bars:
                    raise Exception(f"No historical data loaded for {symbol} within the specified date range.")
                
            except Exception as e:
                logger.error(f"Failed to load data for {symbol}: {e}")
                raise
    
    def _get_close_reason(self, position) -> str:
        """Determine why a position is being closed."""
        if position.trailing_stop and position.should_stop_loss():
            return "trailing"
        if position.should_stop_loss():
            return "sl"
        if position.should_take_profit():
            return "tp"
        return "manual"

    def _find_intraday_fill(self, position, symbol_obj, bar_time_ms: int, close_reason: str = "manual"):
        """
        Fetch 1-min candles for the current daily bar and find a realistic
        fill price by locating the first minute bar that meets the close
        condition, then using the *next* bar's open + slippage.

        When 1-min data is unavailable for the current day (holidays/weekends),
        tries subsequent days up to MAX_INTRADAY_LOOKAHEAD days.

        Args:
            position: The Position being closed
            symbol_obj: Symbol object for tick_size / normalize
            bar_time_ms: Timestamp (ms) of the current daily bar
            close_reason: "sl", "tp", "trailing", or "manual"

        Returns:
            (exit_price, exit_time_ms) or None if intraday data unavailable
        """
        if not self._market_data:
            return None

        # Manual close: no intraday enhancement
        if close_reason not in ("sl", "tp", "trailing"):
            return None

        MAX_INTRADAY_LOOKAHEAD = 30
        from ..config import TimeResolution

        candles = None
        for day_offset in range(MAX_INTRADAY_LOOKAHEAD):
            day_start = bar_time_ms + day_offset * 86400 * 1000
            day_end = day_start + 86400 * 1000

            try:
                fetched = self._market_data.fetch_candles(
                    symbol=position.symbol,
                    resolution=TimeResolution.MINUTE_1,
                    from_ts=day_start,
                    to_ts=day_end,
                )
            except Exception as e:
                logger.warning(f"Failed to fetch 1-min candles for {position.symbol} (offset +{day_offset}d): {e}")
                continue

            if fetched and len(fetched) >= 2:
                candles = fetched
                if day_offset > 0:
                    logger.debug(
                        f"[Backtest] No 1-min data on bar day, found data +{day_offset}d ahead "
                        f"for {position.symbol}"
                    )
                break

        if not candles or len(candles) < 2:
            logger.debug(
                f"[Backtest] No intraday data within {MAX_INTRADAY_LOOKAHEAD} days "
                f"for {position.symbol}, falling back to bar close"
            )
            return None

        logger.debug(f"[Backtest] Fetched {len(candles)} intraday candles for {position.symbol}")

        # Scan minute bars to find the first one that triggers the condition
        trigger_index = None
        for idx, c in enumerate(candles):
            triggered = False

            if close_reason == "sl":
                if position.stop_loss is not None:
                    if position.is_long and c.low <= position.stop_loss:
                        triggered = True
                    elif position.is_short and c.high >= position.stop_loss:
                        triggered = True
            elif close_reason == "tp":
                if position.take_profit is not None:
                    if position.is_long and c.high >= position.take_profit:
                        triggered = True
                    elif position.is_short and c.low <= position.take_profit:
                        triggered = True
            elif close_reason == "trailing":
                if position.is_long:
                    if c.high > position.highest_price:
                        position.highest_price = c.high
                    dynamic_stop = position.highest_price - position.trailing_stop_distance
                    if c.low <= dynamic_stop:
                        triggered = True
                else:
                    if c.low < position.lowest_price:
                        position.lowest_price = c.low
                    dynamic_stop = position.lowest_price + position.trailing_stop_distance
                    if c.high >= dynamic_stop:
                        triggered = True

            if triggered:
                trigger_index = idx
                break

        if trigger_index is None:
            return None

        # Use next bar's open as fill price; if trigger is last bar, use trigger bar's close
        if trigger_index + 1 < len(candles):
            fill_candle = candles[trigger_index + 1]
            raw_price = fill_candle.open
            fill_time = fill_candle.time
        else:
            fill_candle = candles[trigger_index]
            raw_price = fill_candle.close
            fill_time = fill_candle.time

        # Apply slippage
        if position.is_long:
            raw_price -= self.slippage_ticks * symbol_obj.tick_size
        else:
            raw_price += self.slippage_ticks * symbol_obj.tick_size

        exit_price = symbol_obj.normalize_price(raw_price)
        return exit_price, fill_time

    def _close_position(self, position, close_reason: str = "manual") -> Optional[ClosedPosition]:
        """
        Close a position with realistic intraday fill simulation.

        Fetches 1-min candles for the current daily bar, finds the first
        minute bar that meets the close condition, and fills at the next
        bar's open price + slippage.

        Falls back to daily close + slippage when intraday data is
        unavailable.

        Args:
            position: Position to close
            close_reason: "sl", "tp", "trailing", or "manual"
        """
        if not self.strategy._context:
            return None
        symbol = self.strategy._context.get_symbol(position.symbol)
        if not symbol:
            return None

        bar_time_ms = self.strategy._context.current_time

        # Try intraday fill
        intraday = self._find_intraday_fill(position, symbol, bar_time_ms, close_reason)

        if intraday:
            exit_price, exit_time_ms = intraday
            logger.debug(
                f"[Backtest] Intraday fill for {position.symbol}: "
                f"reason={close_reason}, price={exit_price}, time={datetime.utcfromtimestamp(exit_time_ms / 1000)}"
            )
        else:
            # Fallback: use current bar's close price + slippage
            current_bar = symbol.bars.current
            exit_price = current_bar.close if current_bar else 0.0
            if position.is_long:
                exit_price -= self.slippage_ticks * symbol.tick_size
            else:
                exit_price += self.slippage_ticks * symbol.tick_size
            exit_price = symbol.normalize_price(exit_price)
            exit_time_ms = bar_time_ms
            logger.debug(
                f"[Backtest] Daily fill for {position.symbol}: "
                f"reason={close_reason}, price={exit_price} (slippage={self.slippage_ticks} ticks)"
            )

        # Close in context (handles PnL, commission, account, margin, NAV, equity, listeners)
        closed = self.strategy._context.close_position(
            position.id, exit_price, exit_time=exit_time_ms, commission_pct=self.commission_pct
        )

        if closed:
            pnl_pct = closed.pnl_percent if hasattr(closed, 'pnl_percent') else 0
            logger.info(
                f"[Backtest] Position closed: {position.symbol} {position.side.value} "
                f"reason={close_reason} entry={position.entry_price:.4f} exit={exit_price:.4f} "
                f"PnL={closed.pnl:+,.2f} ({pnl_pct:+.2f}%)"
            )

        return closed
