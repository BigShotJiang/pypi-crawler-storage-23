# Changelog

## 2.0.1

### What's Changed

#### Architecture
* Hexagonal architecture (ports & adapters) — domain, application, infrastructure, presentation layers by @AlanLatte in #2

#### Testing
* 289 unit + integration tests with 100% code coverage
* mypy strict, pylint 10.00/10, ruff clean on both `migchain/` and `tests/`
* Pre-commit hooks: trailing-whitespace, ruff, mypy, pylint, gitleaks

#### Features
* `--optimize` — transitive reduction of dependency graph with schema verification via testcontainers
* `PlainPresenter` — logging-based output when `rich` is not installed
* `RichPresenter` — colored tables, progress bars, Mermaid syntax highlighting
* Batch tracking in `public._yoyo_migration_batches` for `--rollback-latest`
* Interactive operation picker via InquirerPy
* Mermaid dependency graph export with domain grouping and inserter/schema coloring

#### Documentation
* Comprehensive README with migration structure examples, dependency graph visualization, and CLI reference by @AlanLatte in #1, #3
* MIT License
* Example migrations across 4 domains (auth, billing, notifications, analytics)

**Full Changelog**: `c8c533c...399526b`
