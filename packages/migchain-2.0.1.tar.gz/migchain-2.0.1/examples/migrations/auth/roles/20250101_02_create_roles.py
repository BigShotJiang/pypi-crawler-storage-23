"""Create roles and user_roles tables."""

from yoyo import step

__depends__ = {"20250101_01_create_users"}

steps = [
    step(
        """
        create table if not exists auth.roles (
            id serial primary key,
            uuid uuid not null default gen_random_uuid() unique,
            name varchar(100) not null unique,
            description text,
            created_at timestamp not null default current_timestamp
        )
        """,
        """
        drop table if exists auth.roles
        """,
    ),
    step(
        """
        create table if not exists auth.user_roles (
            user_id integer not null references auth.users(id) on delete cascade,
            role_id integer not null references auth.roles(id) on delete cascade,
            assigned_at timestamp not null default current_timestamp,

            primary key (user_id, role_id)
        )
        """,
        """
        drop table if exists auth.user_roles
        """,
    ),
]
