# ag402-mcp

MCP gateway adapter for Ag402.
