import random
from datetime import datetime
from pathlib import Path

import click
import requests
from rich import box
from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


console = Console()


BUILT_IN_QUOTES = [
    (
        "The best time to plant a tree was 20 years ago. "
        "The second best time is now."
    ),
    "Ships are safest in the harbor, but that’s not what ships are built for.",
    "You don’t have to be great to start, but you have to start to be great.",
    "One small focused hour today can save you ten scattered hours tomorrow.",
    "Your future self is quietly cheering for every tiny step you take today.",
    "Done is a thousand times more inspiring than perfect.",
    "Every bug you fix is a love letter to your future self.",
    "Courage is just action that happens before confidence arrives.",
]


DEFAULT_QUOTES_FILE = Path.home() / ".devlife_quotes.txt"


STORIES = [
    (
        "The 10-Minute Rule",
        (
            "A tired developer promised herself she would code for just 10 minutes.\n"
            "She opened her editor, fixed one tiny bug, and felt a spark.\n"
            "An hour later, the feature was done.\n\n"
            "Big progress is often just a small promise you actually keep."
        ),
    ),
    (
        "The Comment in the Dark",
        (
            "A junior dev left a kind comment in a pull request, thanking a teammate\n"
            "for a clear function name. Months later, on a rough day, that teammate\n"
            "re-read the comment and decided not to quit.\n\n"
            "Your small kindness might be someone else’s turning point."
        ),
    ),
    (
        "The Quiet Launch",
        (
            "A lone creator shipped a tiny, imperfect tool that felt almost\n"
            "embarrassing. Only three people used it the first week.\n"
            "One of them loved it, shared it, and everything changed.\n\n"
            "The world can’t be moved by the ideas you never release."
        ),
    ),
]


def _ensure_quotes_file(path: Path) -> None:
    """Create a starter quotes file if it doesn't exist yet."""
    if path.exists():
        return

    starter = [
        "# Add your own quotes here – one per line.",
        "# Lines starting with # are ignored.",
        "",
        "Discipline is choosing what you want most over what you want now.",
        "You are one deep breath away from starting.",
        "Make it so simple that future you sends a thank‑you email.",
        "If it scares you a little, it probably matters.",
        "Small progress is still progress – zoom out.",
    ]
    try:
        path.write_text("\n".join(starter), encoding="utf-8")
    except OSError:
        # Silently ignore if we can't write; built-in quotes will still work.
        return


def _load_user_quotes(path: Path) -> list[str]:
    _ensure_quotes_file(path)
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []

    quotes = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith("#")]
    return quotes


def _fetch_online_quote() -> str | None:
    """Try to fetch a quote from a public quotes API."""
    try:
        resp = requests.get("https://api.quotable.io/random", timeout=5)
        resp.raise_for_status()
        data = resp.json()
        content = data.get("content")
        author = data.get("author")
        if not content:
            return None
        if author:
            return f"{content} — {author}"
        return content
    except Exception:
        return None


def _pick_quote(path: Path | None, *, online: bool) -> str:
    if online:
        quote = _fetch_online_quote()
        if quote:
            return quote

    candidates = list(BUILT_IN_QUOTES)
    if path is not None:
        candidates.extend(_load_user_quotes(path))
    return random.choice(candidates) if candidates else "Your story isn't written yet. Start the next line today."


def _render_banner() -> None:
    text = Text(" devlife ", justify="center")
    text.stylize("bold white on magenta", 0, 3)
    text.stylize("bold white on blue", 3, 7)
    panel = Panel(
        Align.center(text, vertical="middle"),
        border_style="bright_cyan",
        box=box.HEAVY,
        padding=(0, 2),
    )
    console.print(panel)


def _render_header(title: str) -> None:
    now = datetime.now().strftime("%Y-%m-%d · %H:%M")
    subtitle = f"[bold magenta]breathe · build · repeat[/bold magenta]\n[dim]{now}[/dim]"
    header_table = Table.grid(expand=True)
    header_table.add_column(justify="left")
    header_table.add_column(justify="right")
    header_table.add_row(f"[bold cyan]{title}[/bold cyan]", subtitle)
    console.print(header_table)


def _render_quote(quote: str) -> None:
    panel = Panel.fit(
        Align.center(f"[bold white]{quote}[/bold white]", vertical="middle"),
        title="[yellow]✨ Quote[/yellow]",
        border_style="bright_blue",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(panel)


def _render_story(title: str, body: str) -> None:
    panel = Panel(
        f"[bold white]{body}[/bold white]",
        title=f"[green]📖 {title}[/green]",
        border_style="bright_magenta",
        box=box.DOUBLE_EDGE,
        padding=(1, 2),
    )
    console.print(panel)


def _render_footer() -> None:
    tip = random.choice(
        [
            "Tiny steps today, legendary momentum tomorrow.",
            "Close one tab, open one possibility.",
            "Future you is already proud of you.",
            "Water, stretch, breathe — then build something cool.",
        ]
    )
    console.print(f"[dim]{tip}[/dim]\n")


@click.command()
@click.option(
    "--stories/--no-stories",
    default=False,
    help="Show a short inspiring story instead of only a quote.",
)
@click.option(
    "-n",
    "--count",
    type=click.IntRange(1, 20),
    default=1,
    show_default=True,
    help="How many inspirational drops you want today.",
)
@click.option(
    "--quotes-file",
    type=click.Path(path_type=Path),
    default=str(DEFAULT_QUOTES_FILE),
    show_default=False,
    help="Optional text file with your own quotes (one per line).",
)
@click.option(
    "--online/--offline",
    "online",
    default=True,
    help="Use an online quotes API when available (falls back to local quotes on error).",
)
def main(stories: bool, count: int, quotes_file: Path, online: bool) -> None:
    """Fun, aesthetic CLI that sprinkles your day with inspiration."""
    console.clear()
    _render_banner()

    for i in range(count):
        console.print()
        _render_header("A tiny spark for you" + (f" #{i + 1}" if count > 1 else ""))

        if stories:
            title, body = random.choice(STORIES)
            _render_story(title, body)
        else:
            quote = _pick_quote(quotes_file, online=online)
            _render_quote(quote)

        _render_footer()


if __name__ == "__main__":
    main()

