"""Safety guardrails: audit journal, pre-mutation snapshots, dependency checks."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from preset_py.client import PresetWorkspace

_log = logging.getLogger("preset-mcp")

# ---------------------------------------------------------------------------
# Audit directory (env-configurable)
# ---------------------------------------------------------------------------

AUDIT_DIR = Path(
    os.environ.get("PRESET_MCP_AUDIT_DIR", "~/.preset-mcp/audit/")
).expanduser()

# ---------------------------------------------------------------------------
# MutationEntry model
# ---------------------------------------------------------------------------


class MutationEntry(BaseModel):
    """Single entry in the mutation audit journal."""

    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    tool_name: str
    resource_type: str  # "dashboard", "chart", "dataset"
    resource_id: int | None = None
    action: Literal["create", "update", "delete", "restore"]
    fields_changed: list[str] = Field(default_factory=list)
    before_snapshot: dict[str, Any] | None = None
    after_summary: dict[str, Any] | None = None
    dry_run: bool = False


# ---------------------------------------------------------------------------
# Audit journal
# ---------------------------------------------------------------------------


def record_mutation(entry: MutationEntry) -> None:
    """Append a JSONL line to the audit journal. Fire-and-forget."""
    try:
        AUDIT_DIR.mkdir(parents=True, exist_ok=True)
        journal = AUDIT_DIR / "mutations.jsonl"
        line = entry.model_dump_json() + "\n"
        with journal.open("a") as f:
            f.write(line)
    except Exception as exc:
        _log.warning("audit journal write failed: %s", exc)


# ---------------------------------------------------------------------------
# Pre-mutation snapshots
# ---------------------------------------------------------------------------


def capture_before(
    ws: PresetWorkspace,
    resource_type: str,
    resource_id: int,
) -> dict[str, Any]:
    """Fetch the current state of a resource before mutation.

    Also writes a snapshot file for manual recovery.
    Returns the full dict; on failure returns ``{"_snapshot_error": ...}``.
    """
    try:
        data = ws.get_resource(resource_type, resource_id)

        # Write individual snapshot file
        try:
            snap_dir = AUDIT_DIR / "snapshots"
            snap_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            snap_file = snap_dir / f"{resource_type}_{resource_id}_{ts}.json"
            snap_file.write_text(json.dumps(data, indent=2, default=str) + "\n")
        except Exception as exc:
            _log.warning("snapshot file write failed: %s", exc)

        return data
    except Exception as exc:
        _log.warning("capture_before failed for %s/%d: %s", resource_type, resource_id, exc)
        return {"_snapshot_error": str(exc)}


# ---------------------------------------------------------------------------
# Dependency checks
# ---------------------------------------------------------------------------


def check_dataset_dependents(
    ws: PresetWorkspace,
    dataset_id: int,
) -> dict[str, Any]:
    """Find charts that depend on a given dataset.

    Returns advisory info — never blocks the mutation.
    """
    try:
        all_charts = ws.charts()
        affected = [
            {"id": ch.get("id"), "name": ch.get("slice_name")}
            for ch in all_charts
            if ch.get("datasource_id") == dataset_id
        ]
        return {
            "dataset_id": dataset_id,
            "affected_charts": affected,
            "chart_count": len(affected),
            "warning": (
                f"{len(affected)} chart(s) use this dataset and will be affected."
                if affected
                else "No charts depend on this dataset."
            ),
        }
    except Exception as exc:
        _log.warning("dependency check failed for dataset %d: %s", dataset_id, exc)
        return {
            "dataset_id": dataset_id,
            "affected_charts": [],
            "chart_count": 0,
            "warning": f"Could not check dependents: {exc}",
        }


# ---------------------------------------------------------------------------
# Params validation
# ---------------------------------------------------------------------------

_FORBIDDEN_PARAM_KEYS = frozenset({
    "datasource_id",
    "datasource_type",
    "database_id",
    "viz_type",
})

_VIZ_DIMENSION_KEYS = (
    "groupby",
    "columns",
    "x_axis",
    "xAxis",
    "y_axis",
    "left_axis",
    "right_axis",
    "series",
    "time_column",
    "granularity_sqla",
)

def _metric_column_name(metric: dict[str, Any]) -> str | None:
    """Extract a metric's referenced column name, if present."""
    column = metric.get("column")
    if isinstance(column, str):
        return column
    if isinstance(column, dict):
        name = column.get("column_name") or column.get("name")
        if isinstance(name, str):
            return name
    return None


def _metric_label(metric: Any) -> str | None:
    """Derive the effective metric label Superset uses for display/orderby."""
    if isinstance(metric, str):
        return metric
    if not isinstance(metric, dict):
        return None

    for key in ("label", "label_short", "metric_name", "name"):
        value = metric.get(key)
        if isinstance(value, str) and value:
            return value

    if metric.get("expressionType") == "SQL":
        sql_expr = metric.get("sqlExpression")
        if isinstance(sql_expr, str) and sql_expr.strip():
            return sql_expr.strip()

    col_name = _metric_column_name(metric)
    aggregate = metric.get("aggregate")
    if isinstance(aggregate, str) and aggregate and col_name:
        return f"{aggregate}({col_name})"
    return col_name


def _validate_metric_object(metric: dict[str, Any], index: int) -> str | None:
    """Validate a metric object and return an optional referenced column."""
    expression_type = metric.get("expressionType")
    if expression_type is not None and not isinstance(expression_type, str):
        raise ValueError(
            f"metrics[{index}].expressionType must be a string when provided."
        )

    if expression_type == "SIMPLE":
        if not metric.get("aggregate"):
            raise ValueError(
                f"metrics[{index}] uses SIMPLE expressionType but has no aggregate."
            )
        col_name = _metric_column_name(metric)
        if not col_name:
            raise ValueError(
                f"metrics[{index}] uses SIMPLE expressionType but has no valid column."
            )
        return col_name

    if expression_type == "SQL":
        sql_expr = metric.get("sqlExpression")
        if not isinstance(sql_expr, str) or not sql_expr.strip():
            raise ValueError(
                f"metrics[{index}] uses SQL expressionType but sqlExpression is missing."
            )
        return None

    # Be permissive for legacy-style metric dicts so we don't reject valid
    # Superset payloads that omit expressionType.
    if expression_type is None:
        if metric.get("sqlExpression"):
            return None
        if metric.get("aggregate") and _metric_column_name(metric):
            return _metric_column_name(metric)
        if metric.get("metric_name") or metric.get("label") or metric.get("optionName"):
            return None
        raise ValueError(
            f"metrics[{index}] is a dict but missing metric structure. "
            "Expected saved metric reference or SIMPLE/SQL metric object."
        )

    raise ValueError(
        f"metrics[{index}] has unsupported expressionType={expression_type!r}."
    )


def _extract_filter_columns(filters: Any) -> set[str]:
    """Extract column references from filters/adhoc_filters payloads."""
    refs: set[str] = set()
    if not isinstance(filters, list):
        return refs
    for item in filters:
        if not isinstance(item, dict):
            continue
        for key in ("col", "subject", "column"):
            value = item.get(key)
            if isinstance(value, str) and value:
                refs.add(value)
        if isinstance(item.get("column"), dict):
            col_name = item["column"].get("column_name")
            if isinstance(col_name, str) and col_name:
                refs.add(col_name)
    return refs


def _extract_named_columns(value: Any) -> set[str]:
    """Extract string column names from scalar/list/dict-like values."""
    refs: set[str] = set()
    if isinstance(value, str):
        if value:
            refs.add(value)
        return refs
    if isinstance(value, dict):
        # Common field payload shapes: {"column_name": "x"}, {"column": "x"}
        for key in ("column_name", "name", "col", "column"):
            item = value.get(key)
            if isinstance(item, str) and item:
                refs.add(item)
        if isinstance(value.get("column"), dict):
            nested = value["column"]
            col_name = nested.get("column_name") or nested.get("name")
            if isinstance(col_name, str) and col_name:
                refs.add(col_name)
        return refs
    if not isinstance(value, list | tuple | set):
        return refs
    for item in value:
        refs.update(_extract_named_columns(item))
    return refs


def _dimension_label_sources(parsed: dict[str, Any]) -> dict[str, set[str]]:
    """Return label -> set(fields) for dimension-like chart fields."""
    sources: dict[str, set[str]] = {}
    for field in _VIZ_DIMENSION_KEYS:
        labels = _extract_named_columns(parsed.get(field))
        for label in labels:
            sources.setdefault(label, set()).add(field)
    return sources


def validate_params_payload(
    params_json: str,
    *,
    dataset_columns: set[str] | None = None,
    dataset_metrics: set[str] | None = None,
    viz_type: str | None = None,
    fallback_fields: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Parse + validate params_json and return advisory warnings.

    Raises ``ValueError`` on malformed JSON, forbidden keys, or invalid
    metric structures. Returns ``(parsed_params, warnings)`` on success.
    """
    try:
        parsed = json.loads(params_json)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ValueError(
            f"params_json is not valid JSON: {exc}. "
            "Pass a JSON object string, e.g. '{\"metrics\": [\"count\"]}'"
        ) from exc

    if not isinstance(parsed, dict):
        raise ValueError(
            f"params_json must be a JSON object (dict), got {type(parsed).__name__}. "
            "Example: '{\"metrics\": [\"count\"]}'"
        )

    forbidden_found = _FORBIDDEN_PARAM_KEYS & set(parsed.keys())
    if forbidden_found:
        raise ValueError(
            f"params_json must not contain datasource-rebinding keys: "
            f"{sorted(forbidden_found)}. Use the dedicated tool parameters instead."
        )

    warnings: list[str] = []
    dataset_columns = dataset_columns or set()
    dataset_metrics = dataset_metrics or set()
    fallback_fields = fallback_fields or {}
    resolved_viz_type = viz_type
    if not resolved_viz_type:
        raw_viz_type = parsed.get("viz_type")
        if isinstance(raw_viz_type, str) and raw_viz_type:
            resolved_viz_type = raw_viz_type

    metrics = parsed.get("metrics")
    metric_column_refs: set[str] = set()
    metric_labels: set[str] = set()
    if metrics is not None:
        if not isinstance(metrics, list):
            raise ValueError("params_json.metrics must be a list.")
        for idx, metric in enumerate(metrics):
            if isinstance(metric, str):
                metric_labels.add(metric)
                if (
                    dataset_columns
                    and dataset_metrics
                    and metric not in dataset_metrics
                    and metric not in dataset_columns
                ):
                    warnings.append(
                        f"metrics[{idx}] references unknown metric/column {metric!r}."
                    )
                continue
            if isinstance(metric, dict):
                ref = _validate_metric_object(metric, idx)
                if ref:
                    metric_column_refs.add(ref)
                label = _metric_label(metric)
                if label:
                    metric_labels.add(label)
                continue
            raise ValueError(
                f"metrics[{idx}] must be a string or metric object dict."
            )

    referenced_columns: set[str] = set()
    label_sources = _dimension_label_sources(parsed)
    referenced_columns.update(label_sources.keys())
    referenced_columns.update(_extract_filter_columns(parsed.get("filters")))
    referenced_columns.update(_extract_filter_columns(parsed.get("adhoc_filters")))
    referenced_columns.update(metric_column_refs)

    duplicate_dimensions = sorted(
        label for label, fields in label_sources.items() if len(fields) > 1
    )
    if duplicate_dimensions:
        details = ", ".join(
            f"{label!r} in {sorted(label_sources[label])}"
            for label in duplicate_dimensions
        )
        raise ValueError(
            "params_json has duplicate dimension labels across chart fields: "
            f"{details}."
        )

    metric_dimension_collisions = sorted(metric_labels & set(label_sources.keys()))
    if metric_dimension_collisions:
        raise ValueError(
            "params_json metric labels collide with dimension labels: "
            f"{metric_dimension_collisions}."
        )

    def _is_missing(value: Any) -> bool:
        if value is None:
            return True
        if isinstance(value, str):
            return not value.strip()
        if isinstance(value, (list, tuple, set, dict)):
            return len(value) == 0
        return False

    def _value(key: str) -> Any:
        if key in parsed:
            return parsed.get(key)
        return fallback_fields.get(key)

    if resolved_viz_type == "pie":
        if _is_missing(_value("metrics")):
            raise ValueError("Pie charts require params_json.metrics.")
        # Backward-compat: ensure singular ``metric`` is present so
        # Superset backends that derive orderby from it never get null
        # (see GitHub issue #26).
        pie_metrics = _value("metrics")
        if isinstance(pie_metrics, list) and pie_metrics and "metric" not in parsed:
            parsed["metric"] = pie_metrics[0]
            warnings.append(
                "Auto-set params_json.metric from first metrics entry "
                "for pie chart backward compatibility."
            )
        has_dimension = not _is_missing(_value("groupby")) or not _is_missing(_value("columns"))
        if not has_dimension:
            raise ValueError("Pie charts require params_json.groupby (or columns).")

    if resolved_viz_type in {
        "echarts_timeseries_bar",
        "echarts_timeseries_line",
        "echarts_timeseries_area",
    }:
        if _is_missing(_value("metrics")):
            raise ValueError(f"{resolved_viz_type} requires params_json.metrics.")
        has_time = not _is_missing(_value("granularity_sqla")) or not _is_missing(_value("time_column"))
        if not has_time:
            raise ValueError(
                f"{resolved_viz_type} requires a time column "
                "(granularity_sqla or time_column)."
            )

    if resolved_viz_type == "big_number_total" and _is_missing(_value("metrics")):
        raise ValueError("big_number_total requires params_json.metrics.")

    if dataset_columns and referenced_columns:
        missing = sorted(
            col
            for col in referenced_columns
            if col not in dataset_columns and col not in dataset_metrics
        )
        if missing:
            raise ValueError(
                "params_json references unknown dataset columns: "
                f"{missing}. Use get_dataset(..., response_mode='standard') "
                "to inspect valid columns/metrics."
            )

    return parsed, warnings


def validate_params_json(params_json: str) -> dict[str, Any]:
    """Backward-compatible validator returning only parsed params."""
    parsed, _ = validate_params_payload(params_json)
    return parsed


# ---------------------------------------------------------------------------
# Pre-delete export (mandatory, blocking)
# ---------------------------------------------------------------------------


def export_before_delete(
    ws: PresetWorkspace,
    resource_type: str,
    resource_id: int,
) -> Path:
    """Export a full ZIP backup before deletion. BLOCKING — raises on failure."""
    exports_dir = AUDIT_DIR / "exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    export_path = exports_dir / f"{resource_type}_{resource_id}_{ts}.zip"

    zip_bytes = ws.export_resource_zip(resource_type, [resource_id])
    export_path.write_bytes(zip_bytes)

    _log.info("pre-delete export saved: %s (%d bytes)", export_path, len(zip_bytes))
    return export_path
