"""Risk context builder helpers.

Convenience functions for constructing typed RiskContext objects
for common action categories.
"""

from __future__ import annotations

from typing import Optional

from mnemom_types import CoordinationMode, RiskContext


def financial_context(
    amount: float,
    counterparty_id: Optional[str] = None,
) -> RiskContext:
    """Build a risk context for a financial transaction.

    Args:
        amount: Transaction amount.
        counterparty_id: Optional counterparty agent ID.

    Returns:
        A RiskContext configured for financial transactions.
    """
    return RiskContext(
        action_type="financial_transaction",
        amount=amount,
        counterparty_id=counterparty_id,
    )


def delegation_context(
    task: str,
    coordination_mode: Optional[CoordinationMode] = None,
) -> RiskContext:
    """Build a risk context for task delegation.

    Args:
        task: Description of the delegated task.
        coordination_mode: Optional coordination mode between agents.

    Returns:
        A RiskContext configured for task delegation.
    """
    return RiskContext(
        action_type="task_delegation",
        team_task=task,
        coordination_mode=coordination_mode,
    )


def data_access_context(use_case: str) -> RiskContext:
    """Build a risk context for data access.

    Args:
        use_case: Description of the data access use case.

    Returns:
        A RiskContext configured for data access.
    """
    return RiskContext(
        action_type="data_access",
        use_case=use_case,
    )


def tool_invocation_context() -> RiskContext:
    """Build a risk context for tool invocation.

    Returns:
        A RiskContext configured for tool invocation.
    """
    return RiskContext(action_type="tool_invocation")
