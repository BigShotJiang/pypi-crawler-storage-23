from typing import TypedDict, List, Optional, Any, Generic, TypeVar, TYPE_CHECKING
from typing_extensions import TypedDict

if TYPE_CHECKING:
    from . import *

class PlantsUpdatePlantMergeRequest(TypedDict, total=False):
    MergeDate: str
    SourcePlantGroupLabel: str
    TargetPlantGroupLabel: str
