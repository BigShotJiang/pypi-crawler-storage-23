"""
StatCan MCP Server

A FastMCP-based server that provides tools for accessing the Statistics Canada API
and storing/querying results in a SQLite database.
"""

__version__ = "0.1.0"