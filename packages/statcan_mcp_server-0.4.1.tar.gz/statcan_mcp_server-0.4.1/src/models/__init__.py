"""
Data Models

Pydantic models for API request/response validation and database representation
of Statistics Canada data structures.
"""
