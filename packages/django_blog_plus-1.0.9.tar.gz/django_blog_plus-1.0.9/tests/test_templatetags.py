"""
Tests for django_blog_plus template tags.
"""
from django.test import TestCase
from django.template import Template, Context

from django_blog_plus.models import (
    ArticleCoverStyle,
    BlogCallToAction,
    ArticleCallToAction,
    ArticleViewCount,
)
from django_blog_plus.templatetags.django_blog_plus import (
    reading_time,
    demote_headings,
    unescape_html,
)


class ReadingTimeTests(TestCase):
    """Tests for reading_time template tag."""

    def test_reading_time_short_content(self):
        """Test reading time for short content."""
        content = "Hello world. " * 50  # ~100 words
        result = reading_time(content)
        self.assertEqual(result, 1)  # Minimum 1 minute

    def test_reading_time_medium_content(self):
        """Test reading time for medium content."""
        content = "Hello world. " * 200  # ~400 words
        result = reading_time(content)
        self.assertEqual(result, 2)  # 400/200 = 2 minutes

    def test_reading_time_long_content(self):
        """Test reading time for long content."""
        content = "Hello world. " * 500  # ~1000 words
        result = reading_time(content)
        self.assertEqual(result, 5)  # 1000/200 = 5 minutes

    def test_reading_time_with_html(self):
        """Test that HTML tags are stripped before counting."""
        content = "<p>Hello world.</p>" * 100
        result = reading_time(content)
        self.assertEqual(result, 1)

    def test_reading_time_empty_content(self):
        """Test reading time for empty content."""
        result = reading_time("")
        self.assertEqual(result, 1)

    def test_reading_time_none_content(self):
        """Test reading time for None content."""
        result = reading_time(None)
        self.assertEqual(result, 1)


class DemoteHeadingsTests(TestCase):
    """Tests for demote_headings filter."""

    def test_demote_h1_to_h2(self):
        """Test that H1 tags are converted to H2."""
        content = "<h1>Title</h1><p>Content</p>"
        result = demote_headings(content)
        self.assertEqual(result, "<h2>Title</h2><p>Content</p>")

    def test_demote_h1_with_attributes(self):
        """Test that H1 tags with attributes are converted."""
        content = '<h1 class="title" id="main">Title</h1>'
        result = demote_headings(content)
        self.assertEqual(result, '<h2 class="title" id="main">Title</h2>')

    def test_multiple_h1_tags(self):
        """Test that multiple H1 tags are all converted."""
        content = "<h1>First</h1><h1>Second</h1>"
        result = demote_headings(content)
        self.assertEqual(result, "<h2>First</h2><h2>Second</h2>")

    def test_no_h1_tags(self):
        """Test content without H1 tags is unchanged."""
        content = "<h2>Title</h2><p>Content</p>"
        result = demote_headings(content)
        self.assertEqual(result, content)

    def test_empty_content(self):
        """Test empty content returns empty."""
        result = demote_headings("")
        self.assertEqual(result, "")


class UnescapeHtmlTests(TestCase):
    """Tests for unescape_html filter."""

    def test_unescape_amp(self):
        """Test unescaping &amp;."""
        result = unescape_html("Tom &amp; Jerry")
        self.assertEqual(result, "Tom & Jerry")

    def test_unescape_quotes(self):
        """Test unescaping quote entities."""
        result = unescape_html("He said &quot;Hello&quot;")
        self.assertEqual(result, 'He said "Hello"')

    def test_unescape_special_chars(self):
        """Test unescaping special characters."""
        result = unescape_html("&rsquo; &lsquo; &rdquo; &ldquo;")
        self.assertEqual(result, "' ' " "", )

    def test_empty_content(self):
        """Test empty content returns empty."""
        result = unescape_html("")
        self.assertEqual(result, "")

    def test_none_content(self):
        """Test None content returns None."""
        result = unescape_html(None)
        self.assertIsNone(result)


class ArticleCoverBgFilterTests(TestCase):
    """Tests for article_cover_bg filter."""

    def test_get_cover_bg_with_style(self):
        """Test getting background color for article with style."""
        ArticleCoverStyle.objects.create(
            article_id=1,
            background_color='#5DBEA3',
        )
        
        # Create a mock article object
        class MockArticle:
            id = 1
        
        from django_blog_plus.templatetags.django_blog_plus import article_cover_bg
        result = article_cover_bg(MockArticle())
        self.assertEqual(result, '#5DBEA3')

    def test_get_cover_bg_without_style(self):
        """Test getting default color for article without style."""
        class MockArticle:
            id = 999  # No style exists
        
        from django_blog_plus.templatetags.django_blog_plus import article_cover_bg
        result = article_cover_bg(MockArticle())
        self.assertEqual(result, '#f8f9fa')  # Default color


class GetArticleCtaTests(TestCase):
    """Tests for get_article_cta template tag."""

    def test_get_cta_for_article(self):
        """Test getting CTA for an article."""
        cta = BlogCallToAction.objects.create(
            title='Test CTA',
            text='<p>Content</p>',
            is_active=True,
        )
        ArticleCallToAction.objects.create(
            article_id=1,
            cta=cta,
        )
        
        from django_blog_plus.templatetags.django_blog_plus import get_article_cta
        result = get_article_cta(1)
        self.assertEqual(result, cta)

    def test_get_cta_inactive(self):
        """Test that inactive CTAs are not returned."""
        cta = BlogCallToAction.objects.create(
            title='Inactive CTA',
            text='<p>Content</p>',
            is_active=False,
        )
        ArticleCallToAction.objects.create(
            article_id=2,
            cta=cta,
        )
        
        from django_blog_plus.templatetags.django_blog_plus import get_article_cta
        result = get_article_cta(2)
        self.assertIsNone(result)

    def test_get_cta_no_assignment(self):
        """Test getting CTA for article without assignment."""
        from django_blog_plus.templatetags.django_blog_plus import get_article_cta
        result = get_article_cta(999)
        self.assertIsNone(result)
