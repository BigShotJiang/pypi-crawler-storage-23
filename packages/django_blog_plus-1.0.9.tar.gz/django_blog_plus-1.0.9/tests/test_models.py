"""
Tests for django_blog_plus models.
"""
import pytest
from django.test import TestCase

from django_blog_plus.models import (
    ArticleCoverStyle,
    BlogCallToAction,
    ArticleCallToAction,
    ArticleViewCount,
)


class ArticleCoverStyleTests(TestCase):
    """Tests for ArticleCoverStyle model."""

    def test_create_cover_style(self):
        """Test creating an article cover style."""
        style = ArticleCoverStyle.objects.create(
            article_id=1,
            background_color='#5DBEA3',
        )
        self.assertEqual(style.article_id, 1)
        self.assertEqual(style.background_color, '#5DBEA3')
        self.assertEqual(style.get_background_color(), '#5DBEA3')

    def test_custom_color_overrides_preset(self):
        """Test that custom_color overrides background_color."""
        style = ArticleCoverStyle.objects.create(
            article_id=2,
            background_color='#f8f9fa',
            custom_color='#FF5733',
        )
        self.assertEqual(style.get_background_color(), '#FF5733')

    def test_str_representation(self):
        """Test string representation."""
        style = ArticleCoverStyle.objects.create(article_id=3)
        self.assertEqual(str(style), 'Cover Style for Article #3')


class BlogCallToActionTests(TestCase):
    """Tests for BlogCallToAction model."""

    def test_create_cta(self):
        """Test creating a CTA."""
        cta = BlogCallToAction.objects.create(
            title='Get Started',
            text='<p>Sign up today!</p>',
            button_text='Sign Up',
            button_url='https://example.com/signup',
            is_active=True,
        )
        self.assertEqual(cta.title, 'Get Started')
        self.assertTrue(cta.is_active)

    def test_str_representation_active(self):
        """Test string representation for active CTA."""
        cta = BlogCallToAction.objects.create(
            title='Active CTA',
            text='<p>Content</p>',
            is_active=True,
        )
        self.assertIn('✓', str(cta))
        self.assertIn('Active CTA', str(cta))

    def test_str_representation_inactive(self):
        """Test string representation for inactive CTA."""
        cta = BlogCallToAction.objects.create(
            title='Inactive CTA',
            text='<p>Content</p>',
            is_active=False,
        )
        self.assertIn('✗', str(cta))


class ArticleCallToActionTests(TestCase):
    """Tests for ArticleCallToAction model."""

    def test_create_assignment(self):
        """Test creating a CTA assignment."""
        cta = BlogCallToAction.objects.create(
            title='Test CTA',
            text='<p>Content</p>',
        )
        assignment = ArticleCallToAction.objects.create(
            article_id=1,
            cta=cta,
        )
        self.assertEqual(assignment.article_id, 1)
        self.assertEqual(assignment.cta, cta)

    def test_unique_article_id(self):
        """Test that article_id is unique."""
        cta = BlogCallToAction.objects.create(
            title='Test CTA',
            text='<p>Content</p>',
        )
        ArticleCallToAction.objects.create(article_id=1, cta=cta)
        
        # Trying to create another assignment for the same article should fail
        with self.assertRaises(Exception):
            ArticleCallToAction.objects.create(article_id=1, cta=cta)


class ArticleViewCountTests(TestCase):
    """Tests for ArticleViewCount model."""

    def test_create_view_count(self):
        """Test creating a view count record."""
        view_count = ArticleViewCount.objects.create(
            article_id=1,
            view_count=100,
        )
        self.assertEqual(view_count.article_id, 1)
        self.assertEqual(view_count.view_count, 100)

    def test_increment_view(self):
        """Test incrementing view count."""
        # First increment creates the record
        result = ArticleViewCount.increment_view(1)
        self.assertEqual(result.view_count, 1)
        
        # Second increment updates it
        result = ArticleViewCount.increment_view(1)
        self.assertEqual(result.view_count, 2)

    def test_str_representation(self):
        """Test string representation."""
        view_count = ArticleViewCount.objects.create(
            article_id=1,
            view_count=50,
        )
        self.assertEqual(str(view_count), 'Article #1: 50 views')
