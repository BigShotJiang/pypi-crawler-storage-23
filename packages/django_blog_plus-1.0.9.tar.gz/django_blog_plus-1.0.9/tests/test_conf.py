"""
Tests for django_blog_plus configuration system.
"""
from django.test import TestCase, override_settings

from django_blog_plus.conf import DjangoBlogPlusSettings, django_blog_plus_settings


class DjangoBlogPlusSettingsTests(TestCase):
    """Tests for DjangoBlogPlusSettings configuration."""

    def test_default_values(self):
        """Test that default values are returned when not configured."""
        settings = DjangoBlogPlusSettings()
        self.assertEqual(settings.SITE_NAME, 'Blog')
        self.assertEqual(settings.SITE_DESCRIPTION, '')
        self.assertEqual(settings.DEFAULT_COVER_BG_COLOR, '#f8f9fa')

    @override_settings(DJANGO_BLOG_PLUS={
        'SITE_NAME': 'Custom Blog',
        'SITE_DESCRIPTION': 'A custom description',
    })
    def test_custom_values(self):
        """Test that custom values from settings are returned."""
        settings = DjangoBlogPlusSettings()
        self.assertEqual(settings.SITE_NAME, 'Custom Blog')
        self.assertEqual(settings.SITE_DESCRIPTION, 'A custom description')

    @override_settings(DJANGO_BLOG_PLUS={'WEBHOOK_SECRET': 'my-secret'})
    def test_get_webhook_secret(self):
        """Test getting webhook secret from DJANGO_BLOG_PLUS."""
        settings = DjangoBlogPlusSettings()
        self.assertEqual(settings.get_webhook_secret(), 'my-secret')

    @override_settings(BLOG_WEBHOOK_SECRET='fallback-secret')
    def test_get_webhook_secret_fallback(self):
        """Test fallback to BLOG_WEBHOOK_SECRET."""
        settings = DjangoBlogPlusSettings()
        self.assertEqual(settings.get_webhook_secret(), 'fallback-secret')

    @override_settings(LANGUAGE_CODE='en-us')
    def test_get_language_code(self):
        """Test getting language code from Django settings."""
        settings = DjangoBlogPlusSettings()
        self.assertEqual(settings.get_language_code(), 'en-us')

    def test_invalid_setting_raises_error(self):
        """Test that invalid settings raise AttributeError."""
        settings = DjangoBlogPlusSettings()
        with self.assertRaises(AttributeError):
            _ = settings.INVALID_SETTING

    def test_get_cover_bg_colors(self):
        """Test getting cover background color choices."""
        settings = DjangoBlogPlusSettings()
        colors = settings.get_cover_bg_colors()
        self.assertIsInstance(colors, list)
        self.assertTrue(len(colors) > 0)
        # Each color should be a tuple of (hex, label)
        self.assertEqual(len(colors[0]), 2)
