"""
Configuration system for Django Blog Plus.

Settings can be customized via the DJANGO_BLOG_PLUS dict in Django settings.
LOTUS_EXTRAS is also supported for backward compatibility.
"""

from django.conf import settings
from django.utils.translation import gettext_lazy as _


# Default cover background color choices
DEFAULT_COVER_BG_COLORS = [
    ('#f8f9fa', _('Light Gray (Default)')),
    ('#ffffff', _('White')),
    ('#000000', _('Black')),
    ('#1a1a2e', _('Dark Navy')),
    ('#16213e', _('Deep Blue')),
    ('#0f3460', _('Ocean Blue')),
    ('#5DBEA3', _('Teal Green')),
    ('#30BE93', _('Green')),
    ('#e8f5e9', _('Light Green')),
    ('#fff3e0', _('Light Orange')),
    ('#fce4ec', _('Light Pink')),
    ('#e3f2fd', _('Light Blue')),
    ('#f3e5f5', _('Light Purple')),
    ('#fffde7', _('Light Yellow')),
    ('#263238', _('Charcoal')),
    ('#37474f', _('Blue Gray')),
]


class DjangoBlogPlusSettings:
    """
    Settings wrapper that provides defaults and allows override via DJANGO_BLOG_PLUS.
    LOTUS_EXTRAS is also supported for backward compatibility.

    Usage:
        from django_blog_plus.conf import django_blog_plus_settings
        site_name = django_blog_plus_settings.SITE_NAME
    """

    # Default values
    DEFAULTS = {
        'SITE_NAME': 'Blog',
        'SITE_DESCRIPTION': '',
        'WEBHOOK_SECRET': None,
        'ARTICLE_PUBLISHED_WEBHOOK_URL': '',
        # Used by lotus base template override via context processor (django_blog_plus_base_template).
        'BASE_TEMPLATE': 'base.html',
        'DEFAULT_COVER_BG_COLOR': '#f8f9fa',
        'COVER_BG_COLORS': DEFAULT_COVER_BG_COLORS,
        'LANGUAGE_CODE': 'en-gb',
    }

    def __init__(self):
        self._cached_settings = None

    @property
    def user_settings(self):
        """Get user-defined settings from Django settings."""
        if self._cached_settings is None:
            self._cached_settings = getattr(settings, 'DJANGO_BLOG_PLUS', None) or getattr(
                settings, 'LOTUS_EXTRAS', {}
            )
        return self._cached_settings

    def __getattr__(self, name):
        """Get a setting value, falling back to defaults."""
        if name in self.DEFAULTS:
            return self.user_settings.get(name, self.DEFAULTS[name])

        # Also check Django settings for backward compatibility
        if hasattr(settings, name):
            return getattr(settings, name)

        raise AttributeError(f"Invalid django_blog_plus setting: {name}")

    def get_language_code(self):
        """Get the language code, preferring Django's LANGUAGE_CODE."""
        if hasattr(settings, 'LANGUAGE_CODE'):
            return settings.LANGUAGE_CODE
        return self.LANGUAGE_CODE

    def get_cover_bg_colors(self):
        """Get cover background color choices."""
        return self.user_settings.get('COVER_BG_COLORS', DEFAULT_COVER_BG_COLORS)

    def get_webhook_secret(self):
        """Get webhook secret, checking DJANGO_BLOG_PLUS/LOTUS_EXTRAS and direct setting."""
        secret = self.user_settings.get('WEBHOOK_SECRET')
        if secret:
            return secret

        # Fall back to BLOG_WEBHOOK_SECRET for backward compatibility
        return getattr(settings, 'BLOG_WEBHOOK_SECRET', None)

    def get_article_published_webhook_url(self):
        """Get the webhook URL for article published notifications."""
        url = self.user_settings.get('ARTICLE_PUBLISHED_WEBHOOK_URL')
        if url:
            return url

        # Fall back to ZAPIER_BLOG_ARTICLE_PUBLISHED_WEBHOOK_URL
        return getattr(settings, 'ZAPIER_BLOG_ARTICLE_PUBLISHED_WEBHOOK_URL', '')


# Singleton instance
django_blog_plus_settings = DjangoBlogPlusSettings()
