# Migrations for django_blog_plus
