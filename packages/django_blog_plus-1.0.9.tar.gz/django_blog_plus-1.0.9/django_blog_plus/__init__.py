"""
Django Lotus Extras - Enhanced features for django-blog-lotus.

Provides CTAs, cover styling, webhooks, view tracking, and more.
"""

__version__ = "0.1.0"
__author__ = "MobileAPI.dev"

default_app_config = "django_blog_plus.apps.DjangoBlogPlusConfig"
