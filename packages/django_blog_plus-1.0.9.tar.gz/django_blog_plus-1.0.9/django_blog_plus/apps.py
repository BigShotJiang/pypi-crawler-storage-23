from django.apps import AppConfig
from django.conf import settings as django_settings


class DjangoBlogPlusConfig(AppConfig):
    """App configuration for Django Blog Plus."""

    name = "django_blog_plus"
    verbose_name = "Django Blog Plus"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        """Called when the app is ready."""
        # Sync template-relevant DJANGO_BLOG_PLUS values to Django settings so code
        # that reads from settings (e.g. getattr(settings, 'LOTUS_BASE_TEMPLATE')) sees them.
        # Only set if not already set so project settings take precedence.
        from .conf import django_blog_plus_settings

        if getattr(django_settings, "LOTUS_BASE_TEMPLATE", None) is None:
            setattr(django_settings, "LOTUS_BASE_TEMPLATE", django_blog_plus_settings.BASE_TEMPLATE)
        if getattr(django_settings, "LOTUS_DEFAULT_COVER_BG_COLOR", None) is None:
            setattr(
                django_settings,
                "LOTUS_DEFAULT_COVER_BG_COLOR",
                django_blog_plus_settings.DEFAULT_COVER_BG_COLOR,
            )
