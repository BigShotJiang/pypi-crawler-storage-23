"""
Context processors for Django Blog Plus.

Add these to your TEMPLATES settings:

    TEMPLATES = [
        {
            ...
            'OPTIONS': {
                'context_processors': [
                    ...
                    'django_blog_plus.context_processors.blog_categories',
                    'django_blog_plus.context_processors.django_blog_plus_config',
                ],
            },
        },
    ]
"""
from .conf import django_blog_plus_settings


def blog_categories(request):
    """
    Provide blog categories to all templates for navigation.

    Template usage:
        {% for category in blog_categories %}
            <a href="{{ category.get_absolute_url }}">{{ category.title }}</a>
        {% endfor %}
    """
    try:
        from lotus.models import Category

        language = django_blog_plus_settings.get_language_code()
        categories = Category.objects.filter(
            language=language
        ).order_by('title')[:10]  # Limit to 10 categories

        return {'blog_categories': categories}
    except ImportError:
        return {'blog_categories': []}
    except Exception:
        return {'blog_categories': []}


def django_blog_plus_config(request):
    """
    Provide django_blog_plus settings to templates (lotus blog and others).

    Template usage:
        {{ django_blog_plus_site_name }}
        {{ django_blog_plus_site_description }}
        {{ django_blog_plus_base_template }}
        {{ django_blog_plus_primary_color }}
        {{ django_blog_plus_default_cover_bg_color }}
        {{ django_blog_plus_cover_bg_colors }}
        {{ django_blog_plus_language_code }}
    """
    return {
        'django_blog_plus_site_name': django_blog_plus_settings.SITE_NAME,
        'django_blog_plus_site_description': django_blog_plus_settings.SITE_DESCRIPTION,
        'django_blog_plus_base_template': django_blog_plus_settings.BASE_TEMPLATE,
        'django_blog_plus_primary_color': getattr(django_blog_plus_settings, 'PRIMARY_COLOR', '#5DBEA3'),
        'django_blog_plus_default_cover_bg_color': django_blog_plus_settings.DEFAULT_COVER_BG_COLOR,
        'django_blog_plus_cover_bg_colors': django_blog_plus_settings.get_cover_bg_colors(),
        'django_blog_plus_language_code': django_blog_plus_settings.get_language_code(),
    }
