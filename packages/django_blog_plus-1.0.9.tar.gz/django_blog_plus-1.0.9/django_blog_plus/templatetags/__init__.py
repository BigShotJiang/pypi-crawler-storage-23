# Template tags for django_blog_plus
