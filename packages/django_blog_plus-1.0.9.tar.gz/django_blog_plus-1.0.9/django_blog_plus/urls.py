"""
URL patterns for Django Blog Plus.

Include these in your project's urls.py:

    from django.urls import path, include

    urlpatterns = [
        path('api/blog/', include('django_blog_plus.urls')),
        ...
    ]
"""
from django.urls import path

from .webhook import blog_webhook, blog_webhook_update, blog_webhook_get, blog_webhook_info
from .feeds import LatestArticlesFeed, LatestArticlesAtomFeed, CategoryFeed

app_name = 'django_blog_plus'

urlpatterns = [
    # Webhook API endpoints
    path('webhook/', blog_webhook, name='webhook-create'),
    path('webhook/update/', blog_webhook_update, name='webhook-update'),
    path('webhook/article/', blog_webhook_get, name='webhook-get'),
    path('webhook/info/', blog_webhook_info, name='webhook-info'),
    
    # RSS/Atom feeds
    path('feed/', LatestArticlesFeed(), name='feed-rss'),
    path('feed/rss/', LatestArticlesFeed(), name='feed-rss-alt'),
    path('feed/atom/', LatestArticlesAtomFeed(), name='feed-atom'),
    path('feed/category/<slug:slug>/', CategoryFeed(), name='feed-category'),
]

# Alternative URL names for backward compatibility
# Some projects may use these names
urlpatterns += [
    path('feed/rss.xml', LatestArticlesFeed(), name='blog-feed-rss'),
    path('feed/atom.xml', LatestArticlesAtomFeed(), name='blog-feed-atom'),
]
