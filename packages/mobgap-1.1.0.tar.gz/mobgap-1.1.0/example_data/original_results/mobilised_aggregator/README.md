Note that this example data is a randomly perturbed version of an actual dataset. 
Consequently, the data and derived DMOs are not physically meaningful.
