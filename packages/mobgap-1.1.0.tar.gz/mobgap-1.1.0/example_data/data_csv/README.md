# CSV Example Files

Some example IMU data that is use in examples to show how to create a custom dataset.
This data is directly generated from the normal example data using the `scripts/prepare_csv_example_data.py` script.

Note, that the acc data is converted to `g` so that we can show a simple unit conversion as part of the example.