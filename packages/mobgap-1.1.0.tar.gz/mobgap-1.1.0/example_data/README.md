# Example Data

This folder contains some example data to test the algorithms with and reference results from the original algorithm 
implementations.