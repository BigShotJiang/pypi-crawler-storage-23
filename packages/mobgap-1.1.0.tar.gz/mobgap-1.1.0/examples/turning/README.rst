.. _example-td:

Detecting Turns
---------------
