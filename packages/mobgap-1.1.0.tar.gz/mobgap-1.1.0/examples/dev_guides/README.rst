.. _dev_guides:

Development Guides
------------------

Some recipies that should help during development of mobgap and might also be helpful, if you want to extend mobgap
using new algorithms.