.. _examples-gsd:

Gait Sequence Detection
-----------------------
