.. _examples-icd:

Initial Contact Detection
-------------------------
