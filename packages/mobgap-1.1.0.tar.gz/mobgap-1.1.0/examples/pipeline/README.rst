.. _examples-pipelines:

Full Pipelines and Pipeline Helper
----------------------------------
