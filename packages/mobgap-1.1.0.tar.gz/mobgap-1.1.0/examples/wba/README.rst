.. _example-wba:

Creating final Walking Bouts
----------------------------
