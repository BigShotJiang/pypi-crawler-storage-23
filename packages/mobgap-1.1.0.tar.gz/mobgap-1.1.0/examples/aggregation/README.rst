.. _examples-aggregation:

DMO Aggregation
---------------
