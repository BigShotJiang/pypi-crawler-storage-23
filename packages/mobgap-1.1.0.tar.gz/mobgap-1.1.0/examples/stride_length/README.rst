.. _examples-stride_length:

Stride Length Calculation
-------------------------
