Stride Length
-------------
