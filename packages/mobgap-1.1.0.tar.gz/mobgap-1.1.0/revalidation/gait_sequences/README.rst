Gait Sequences
--------------
