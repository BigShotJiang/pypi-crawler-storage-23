Initial Contacts
----------------
