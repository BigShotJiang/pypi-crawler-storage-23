"""This is a dummy test to ensure that the test-setup works as expected."""


def test_import():
    """Test that the package can be imported."""
    import mobgap

    assert mobgap is not None
