import matplotlib

# This is needed to avoid plots to open
matplotlib.use("Agg")
