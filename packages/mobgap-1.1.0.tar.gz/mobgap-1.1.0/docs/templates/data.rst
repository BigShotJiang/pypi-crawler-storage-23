{{objname}}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autodata:: {{ objname }}

.. include:: /modules/generated/backreferences/{{module}}.{{objname}}.examples
