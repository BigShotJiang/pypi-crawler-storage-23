{{objname}}
{{ underline }}====================

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. include:: /modules/generated/backreferences/{{module}}.{{objname}}.examples
