{{objname}}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
    :no-members:
    :show-inheritance:


.. include:: /modules/generated/backreferences/{{module}}.{{objname}}.examples
