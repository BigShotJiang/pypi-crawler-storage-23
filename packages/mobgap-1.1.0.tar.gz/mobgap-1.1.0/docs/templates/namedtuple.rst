{{objname}}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
    :no-inherited-members:
    :no-members:
    :show-inheritance:


.. include:: /modules/generated/backreferences/{{module}}.{{objname}}.examples
