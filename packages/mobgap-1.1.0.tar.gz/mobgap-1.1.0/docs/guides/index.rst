===========
User Guides
===========


.. toctree::
    :maxdepth: 1


    Q&A <q_and_a.md>
    Common Datatypes <common_datatypes.md>
    Coordinate Systems <coordinate_system.md>
    Contribution Guide <contribution.md>
    Scope and Project Structure <project_structure.md>
    Developer Guide <developer_guide.md>
