.. _api_ref_utils:

Utility functions
=================

.. toctree::
    :maxdepth: 1

    dtypes
    df_operations
    array_handling
    rotations
    conversions
    evaluation
    tables
