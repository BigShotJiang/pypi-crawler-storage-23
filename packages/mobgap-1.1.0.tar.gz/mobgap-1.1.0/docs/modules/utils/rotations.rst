Handling Rotations
==================

.. automodule:: mobgap.utils.rotations
    :no-members:
    :no-inherited-members:

Functions
---------

.. currentmodule:: mobgap.utils.rotations

.. autosummary::
   :toctree: ../generated/utils/rotations
   :template: function.rst

    rotate_dataset_series
