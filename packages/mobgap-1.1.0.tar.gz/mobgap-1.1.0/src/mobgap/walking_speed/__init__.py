"""Methods to calculate walking speed."""

__all__ = ["WsNaive"]

from mobgap.walking_speed._naive_walking_speed import WsNaive
