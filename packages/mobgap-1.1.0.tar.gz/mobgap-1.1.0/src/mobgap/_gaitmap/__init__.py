"""Vendored version of some gaitmap functions.

We keep the same folder structure as in gaitmap to make it as easy as possible to update the vendored code and update
import paths.

"""
