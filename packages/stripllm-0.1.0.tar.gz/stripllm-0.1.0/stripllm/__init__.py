"""
StripLLM — LLM sanitization SDK.
DOMPurify, but for LLM context windows.
"""

from .core import StripLLM, InjectionDetectedError, OutputValidationError
from .audit import AuditReport, Finding
from .injection import InjectionResult
from .pii import RedactionResult
from .output import ValidationResult

__version__ = "0.1.0"
__all__ = [
    "StripLLM",
    "InjectionDetectedError",
    "OutputValidationError",
    "AuditReport",
    "Finding",
    "InjectionResult",
    "RedactionResult",
    "ValidationResult",
]
