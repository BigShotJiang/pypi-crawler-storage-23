"""Trace builder for constructing complete trace hierarchies."""

from datetime import datetime, timedelta
import random
from typing import Any

from lumenova_beacon.tracing.span import Span
from lumenova_beacon.utils import generate_trace_id

from generators.timestamps import HistoricalTimestampGenerator
from generators.spans import SimulatedSpanBuilder
from config.scenarios import ScenarioTemplate
from config.models import AGENT_NAMES, ENVIRONMENTS


class TraceBuilder:
    """Builds complete trace hierarchies from scenario templates."""

    def __init__(
        self,
        span_builder: SimulatedSpanBuilder | None = None,
        agent_names: list[str] | None = None,
        environments: list[str] | None = None,
    ):
        """Initialize the trace builder.

        Args:
            span_builder: SpanBuilder instance to use
            agent_names: List of agent names
            environments: List of environments
        """
        self.agent_names = agent_names or AGENT_NAMES
        self.environments = environments or ENVIRONMENTS
        self.span_builder = span_builder or SimulatedSpanBuilder(
            agent_names=self.agent_names,
            environments=self.environments,
        )

    def build_trace(
        self,
        scenario: ScenarioTemplate,
        start_time: datetime,
    ) -> list[Span]:
        """Build a complete trace from a scenario template.

        Args:
            scenario: The scenario template to build from
            start_time: When the trace should start

        Returns:
            List of spans that make up the trace.
        """
        # Select random configuration for this trace
        model_id = random.choice(scenario.models) if scenario.models else None
        environment = random.choice(
            [e for e in scenario.environments if e in self.environments]
            or scenario.environments
        )
        agent_name = random.choice(self.agent_names)
        should_error = random.random() < scenario.error_rate

        trace_id = generate_trace_id()
        session_id = f"session-{trace_id[:8]}"
        spans: list[Span] = []

        # Build trace recursively
        self._build_span_tree(
            structure=scenario.trace_structure["root"],
            start_time=start_time,
            trace_id=trace_id,
            session_id=session_id,
            parent_span=None,
            model_id=model_id,
            environment=environment,
            agent_name=agent_name,
            should_error=should_error,
            error_assigned=False,
            spans=spans,
        )

        return spans

    def _build_span_tree(
        self,
        structure: dict[str, Any],
        start_time: datetime,
        trace_id: str,
        session_id: str,
        parent_span: Span | None,
        model_id: str | None,
        environment: str,
        agent_name: str,
        should_error: bool,
        error_assigned: bool,
        spans: list[Span],
    ) -> datetime:
        """Recursively build span tree, returning end time.

        Args:
            structure: Span structure definition
            start_time: When this span starts
            trace_id: Trace ID for all spans
            session_id: Session ID for all spans
            parent_span: Parent span (None for root)
            model_id: Model ID for generation spans
            environment: Deployment environment
            agent_name: Agent name
            should_error: Whether this trace should have an error
            error_assigned: Whether error has been assigned to a span
            spans: List to append spans to

        Returns:
            End time of this span (including children).
        """
        span_type_str = structure["type"]
        span_name = structure.get("name", span_type_str)
        children = structure.get("children", [])

        # Determine if this span should error
        # Only error on leaf spans (no children) if error hasn't been assigned yet
        error_on_this_span = should_error and not error_assigned and not children

        # Build span
        span, span_end_time = self.span_builder.build_span(
            span_type_str=span_type_str,
            span_name=span_name,
            start_time=start_time,
            parent_span=parent_span,
            trace_id=trace_id,
            model_id=model_id if span_type_str == "generation" else None,
            environment=environment,
            agent_name=agent_name if span_type_str == "agent" else None,
            error=error_on_this_span,
            session_id=session_id,
        )
        spans.append(span)

        # Track if error was assigned
        error_assigned = error_assigned or error_on_this_span

        # Build children sequentially
        if children:
            child_start_time = start_time + timedelta(milliseconds=10)  # Small offset

            for child_structure in children:
                child_end_time = self._build_span_tree(
                    structure=child_structure,
                    start_time=child_start_time,
                    trace_id=trace_id,
                    session_id=session_id,
                    parent_span=span,
                    model_id=model_id,
                    environment=environment,
                    agent_name=agent_name,
                    should_error=should_error,
                    error_assigned=error_assigned,
                    spans=spans,
                )
                # Next child starts after previous child ends
                child_start_time = child_end_time + timedelta(milliseconds=5)

                # If a child had an error, mark it as assigned
                if should_error and not error_assigned:
                    # Check if any child span had an error
                    for s in spans:
                        if s.status_code.value == "ERROR":
                            error_assigned = True
                            break

            # Adjust parent end time to encompass all children
            final_child_end = child_start_time - timedelta(milliseconds=5)
            if final_child_end > span_end_time:
                span.end_time = HistoricalTimestampGenerator.to_iso8601(
                    final_child_end + timedelta(milliseconds=5)
                )
                span_end_time = final_child_end + timedelta(milliseconds=5)

        return span_end_time

    def build_multiple_traces(
        self,
        scenarios: list[ScenarioTemplate],
        timestamps: list[datetime],
    ) -> list[Span]:
        """Build multiple traces from scenarios and timestamps.

        Args:
            scenarios: List of scenario templates (will be selected by weight)
            timestamps: List of start times for each trace

        Returns:
            List of all spans across all traces.
        """
        all_spans: list[Span] = []

        # Pre-compute weights
        weights = [s.weight for s in scenarios]

        for ts in timestamps:
            # Select scenario based on weight
            scenario = random.choices(scenarios, weights=weights, k=1)[0]

            # Build trace
            trace_spans = self.build_trace(scenario, ts)
            all_spans.extend(trace_spans)

        return all_spans
