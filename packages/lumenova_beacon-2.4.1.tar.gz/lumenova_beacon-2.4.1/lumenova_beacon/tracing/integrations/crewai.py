"""CrewAI integration using Beacon SDK Spans (event listener approach).

This module provides an event listener that traces CrewAI Crew executions
using SDK Span objects, which are exported via OTLP.

Usage:
    from lumenova_beacon import BeaconClient
    from lumenova_beacon.tracing.integrations.crewai import BeaconCrewAIListener
    from crewai import Agent, Crew, Task

    # Initialize BeaconClient first
    client = BeaconClient()

    # Instantiate the listener — it auto-registers with the CrewAI event bus
    listener = BeaconCrewAIListener(
        session_id="my-session",
        crew_name="My Research Crew",
    )

    # Define and run your Crew as normal
    crew = Crew(agents=[...], tasks=[...])
    result = crew.kickoff()
    print(listener.trace_id)  # Link to Beacon trace

Span hierarchy produced:
    crew_span   (SpanType.AGENT)
    └── task_span   (SpanType.TASK)         - one per task
        └── agent_span  (SpanType.AGENT)    - one per agent execution
            ├── llm_span   (SpanType.GENERATION) - each LLM call
            └── tool_span  (SpanType.TOOL)  - each tool usage

Environment Variables:
    BEACON_ENDPOINT  - Beacon API endpoint (for OTLP export)
    BEACON_API_KEY   - Beacon API key (for OTLP export)
    BEACON_SESSION_ID - Default session ID (optional)
"""

import logging
from typing import Any

from lumenova_beacon.core.client import get_client
from lumenova_beacon.tracing.span import Span
from lumenova_beacon.tracing.trace import set_current_span, clear_context
from lumenova_beacon.types import SpanType, SpanKind, StatusCode

try:
    from crewai.events import BaseEventListener, crewai_event_bus  # noqa: F401
except ImportError:
    raise ImportError(
        "crewai is required for the CrewAI integration. "
        "Install it with: pip install 'lumenova-beacon[crewai]'"
    )

logger = logging.getLogger(__name__)


class BeaconCrewAIListener(BaseEventListener):
    """Beacon event listener for CrewAI Crews.

    Instantiate this class before running your Crew. It automatically
    registers with the CrewAI event bus and creates Beacon spans covering
    the full crew lifecycle.

    Args:
        session_id: Override session ID for all spans (defaults to
            ``BeaconClient.config.session_id``).
        environment: Deployment environment tag stored as span metadata.
        crew_name: Human-readable name for the root crew span. If not
            provided, falls back to the crew name from the kickoff event.
        metadata: Additional key-value pairs stored as ``beacon.metadata.*``
            attributes on the crew span.
    """

    # OTEL GenAI semantic convention attributes
    ATTR_GEN_AI_AGENT_NAME = "gen_ai.agent.name"
    ATTR_GEN_AI_AGENT_FRAMEWORK = "gen_ai.agent.framework"
    ATTR_GEN_AI_CONVERSATION_ID = "gen_ai.conversation.id"
    ATTR_GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
    ATTR_GEN_AI_TOOL_NAME = "gen_ai.tool.name"

    # OTEL GenAI agent attributes
    ATTR_GEN_AI_AGENT_DESCRIPTION = "gen_ai.agent.description"

    # CrewAI-specific attributes
    ATTR_CREWAI_TASK_ID = "crewai.task.id"
    ATTR_CREWAI_TASK_DESCRIPTION = "crewai.task.description"
    ATTR_CREWAI_AGENT_BACKSTORY = "crewai.agent.backstory"

    # OTEL GenAI operation / provider
    ATTR_GEN_AI_OPERATION_NAME = "gen_ai.operation.name"
    ATTR_GEN_AI_PROVIDER_NAME = "gen_ai.provider.name"

    def __init__(
        self,
        session_id: str | None = None,
        environment: str | None = None,
        crew_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        super().__init__()
        self._client = get_client()
        self._session_id = session_id or self._client.config.session_id
        self._environment = environment
        self._crew_name = crew_name
        self._metadata = metadata or {}

        # Root span state
        self._crew_span: Span | None = None
        self._trace_id: str | None = None

        # Span tracking keyed by Python object identity (id(obj)).
        # id() is unique for concurrent objects and safe while objects
        # remain referenced throughout the event lifecycle.
        self._task_spans: dict[int, Span] = {}
        self._agent_spans: dict[int, Span] = {}
        self._llm_spans: dict[int, Span] = {}
        self._tool_spans: dict[tuple[int, str], Span] = {}

    @property
    def trace_id(self) -> str | None:
        """The trace ID for the current (or most recent) crew kickoff."""
        return self._trace_id

    # ------------------------------------------------------------------
    # BaseEventListener protocol
    # ------------------------------------------------------------------

    def setup_listeners(self, crewai_event_bus: Any) -> None:  # type: ignore[override]
        """Register all event handlers on the CrewAI event bus."""
        from crewai.events.types.crew_events import (
            CrewKickoffStartedEvent,
            CrewKickoffCompletedEvent,
            CrewKickoffFailedEvent,
        )
        from crewai.events.types.task_events import (
            TaskStartedEvent,
            TaskCompletedEvent,
            TaskFailedEvent,
        )
        from crewai.events.types.agent_events import (
            AgentExecutionStartedEvent,
            AgentExecutionCompletedEvent,
            AgentExecutionErrorEvent,
        )
        from crewai.events.types.tool_usage_events import (
            ToolUsageStartedEvent,
            ToolUsageFinishedEvent,
            ToolUsageErrorEvent,
        )
        from crewai.events.types.llm_events import (
            LLMCallStartedEvent,
            LLMCallCompletedEvent,
            LLMCallFailedEvent,
        )

        @crewai_event_bus.on(CrewKickoffStartedEvent)
        def on_crew_started(source: Any, event: Any) -> None:
            self._on_crew_started(source, event)

        @crewai_event_bus.on(CrewKickoffCompletedEvent)
        def on_crew_completed(source: Any, event: Any) -> None:
            self._on_crew_completed(source, event)

        @crewai_event_bus.on(CrewKickoffFailedEvent)
        def on_crew_failed(source: Any, event: Any) -> None:
            self._on_crew_failed(source, event)

        @crewai_event_bus.on(TaskStartedEvent)
        def on_task_started(source: Any, event: Any) -> None:
            self._on_task_started(source, event)

        @crewai_event_bus.on(TaskCompletedEvent)
        def on_task_completed(source: Any, event: Any) -> None:
            self._on_task_completed(source, event)

        @crewai_event_bus.on(TaskFailedEvent)
        def on_task_failed(source: Any, event: Any) -> None:
            self._on_task_failed(source, event)

        @crewai_event_bus.on(AgentExecutionStartedEvent)
        def on_agent_started(source: Any, event: Any) -> None:
            self._on_agent_started(source, event)

        @crewai_event_bus.on(AgentExecutionCompletedEvent)
        def on_agent_completed(source: Any, event: Any) -> None:
            self._on_agent_completed(source, event)

        @crewai_event_bus.on(AgentExecutionErrorEvent)
        def on_agent_error(source: Any, event: Any) -> None:
            self._on_agent_error(source, event)

        @crewai_event_bus.on(ToolUsageStartedEvent)
        def on_tool_started(source: Any, event: Any) -> None:
            self._on_tool_started(source, event)

        @crewai_event_bus.on(ToolUsageFinishedEvent)
        def on_tool_finished(source: Any, event: Any) -> None:
            self._on_tool_finished(source, event)

        @crewai_event_bus.on(ToolUsageErrorEvent)
        def on_tool_error(source: Any, event: Any) -> None:
            self._on_tool_error(source, event)

        @crewai_event_bus.on(LLMCallStartedEvent)
        def on_llm_started(source: Any, event: Any) -> None:
            self._on_llm_started(source, event)

        @crewai_event_bus.on(LLMCallCompletedEvent)
        def on_llm_completed(source: Any, event: Any) -> None:
            self._on_llm_completed(source, event)

        @crewai_event_bus.on(LLMCallFailedEvent)
        def on_llm_failed(source: Any, event: Any) -> None:
            self._on_llm_failed(source, event)

    # ------------------------------------------------------------------
    # Crew lifecycle
    # ------------------------------------------------------------------

    def _on_crew_started(self, source: Any, event: Any) -> None:
        try:
            name = self._crew_name or getattr(event, "crew_name", None) or "crewai"
            span = Span(
                name=name,
                span_type=SpanType.AGENT,
                kind=SpanKind.INTERNAL,
                session_id=self._session_id,
            )
            span.start()
            self._crew_span = span
            self._trace_id = span.trace_id

            span.set_attribute(self.ATTR_GEN_AI_AGENT_NAME, name)
            span.set_attribute(self.ATTR_GEN_AI_AGENT_FRAMEWORK, "crewai")
            span.set_attribute(self.ATTR_GEN_AI_OPERATION_NAME, "invoke_agent")
            span.set_attribute(self.ATTR_GEN_AI_PROVIDER_NAME, "crewai")
            if self._session_id:
                span.set_attribute(self.ATTR_GEN_AI_CONVERSATION_ID, self._session_id)
            if self._environment:
                span.set_attribute("deployment.environment.name", self._environment)
            for key, value in self._metadata.items():
                span.set_attribute(f"beacon.metadata.{key}", str(value))

            set_current_span(span)
            self._client.export_eager_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_crew_started", exc_info=True)

    def _on_crew_completed(self, source: Any, event: Any) -> None:
        try:
            if not self._crew_span:
                return
            output = getattr(event, "output", None)
            if output is not None:
                self._crew_span.set_output(str(output))
            self._crew_span.set_status(StatusCode.OK)
            self._crew_span.end()
            self._client.export_span(self._crew_span)
            self._crew_span = None
            clear_context()
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_crew_completed", exc_info=True)

    def _on_crew_failed(self, source: Any, event: Any) -> None:
        try:
            if not self._crew_span:
                return
            error = getattr(event, "error", None)
            exc = error if isinstance(error, BaseException) else Exception(str(error) if error else "Crew failed")
            self._crew_span.set_attribute("error.type", type(exc).__qualname__)
            self._crew_span.record_exception(exc)
            self._crew_span.set_status(StatusCode.ERROR, str(error) if error else "Crew failed")
            self._crew_span.end()
            self._client.export_span(self._crew_span)
            self._crew_span = None
            clear_context()
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_crew_failed", exc_info=True)

    # ------------------------------------------------------------------
    # Task lifecycle
    # ------------------------------------------------------------------

    def _on_task_started(self, source: Any, event: Any) -> None:
        try:
            task = getattr(event, "task", None)
            if task is None:
                return

            task_key = id(task)
            task_name = (
                getattr(task, "name", None)
                or (getattr(task, "description", None) or "task")[:60]
            )
            parent_span = self._crew_span
            parent_id = parent_span.span_id if parent_span else None

            span = Span(
                name=task_name,
                trace_id=self._trace_id,
                parent_id=parent_id,
                span_type=SpanType.TASK,
                kind=SpanKind.INTERNAL,
                session_id=self._session_id,
            )
            span.start()

            span.set_attribute(self.ATTR_GEN_AI_AGENT_FRAMEWORK, "crewai")
            span.set_attribute(self.ATTR_GEN_AI_OPERATION_NAME, "invoke_agent")
            span.set_attribute(self.ATTR_GEN_AI_PROVIDER_NAME, "crewai")
            task_id = str(getattr(task, "id", ""))
            if task_id:
                span.set_attribute(self.ATTR_CREWAI_TASK_ID, task_id)
            description = getattr(task, "description", None)
            if description:
                span.set_attribute(self.ATTR_CREWAI_TASK_DESCRIPTION, str(description))

            self._task_spans[task_key] = span
            self._client.export_eager_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_task_started", exc_info=True)

    def _on_task_completed(self, source: Any, event: Any) -> None:
        try:
            task = getattr(event, "task", None)
            span = self._task_spans.pop(id(task), None) if task is not None else None
            if not span:
                return
            output = getattr(event, "output", None)
            if output is not None:
                span.set_output(str(output))
            span.set_status(StatusCode.OK)
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_task_completed", exc_info=True)

    def _on_task_failed(self, source: Any, event: Any) -> None:
        try:
            task = getattr(event, "task", None)
            span = self._task_spans.pop(id(task), None) if task is not None else None
            if not span:
                return
            error = getattr(event, "error", None)
            exc = error if isinstance(error, BaseException) else Exception(str(error) if error else "Task failed")
            span.set_attribute("error.type", type(exc).__qualname__)
            span.record_exception(exc)
            span.set_status(StatusCode.ERROR, str(error) if error else "Task failed")
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_task_failed", exc_info=True)

    # ------------------------------------------------------------------
    # Agent execution lifecycle
    # ------------------------------------------------------------------

    def _on_agent_started(self, source: Any, event: Any) -> None:
        try:
            agent = getattr(event, "agent", None)
            if agent is None:
                return

            agent_key = id(agent)
            role = getattr(agent, "role", None) or "agent"

            # Parent: task_span if we can find it, otherwise crew_span
            task = getattr(event, "task", None)
            parent_span = (
                self._task_spans.get(id(task)) if task is not None else None
            ) or self._crew_span
            parent_id = parent_span.span_id if parent_span else None

            span = Span(
                name=role,
                trace_id=self._trace_id,
                parent_id=parent_id,
                span_type=SpanType.AGENT,
                kind=SpanKind.INTERNAL,
                session_id=self._session_id,
            )
            span.start()
            span.set_attribute(self.ATTR_GEN_AI_AGENT_NAME, role)
            span.set_attribute(self.ATTR_GEN_AI_AGENT_FRAMEWORK, "crewai")
            span.set_attribute(self.ATTR_GEN_AI_OPERATION_NAME, "invoke_agent")
            span.set_attribute(self.ATTR_GEN_AI_PROVIDER_NAME, "crewai")

            goal = getattr(agent, "goal", None)
            if goal:
                span.set_attribute(self.ATTR_GEN_AI_AGENT_DESCRIPTION, str(goal))
            backstory = getattr(agent, "backstory", None)
            if backstory:
                span.set_attribute(self.ATTR_CREWAI_AGENT_BACKSTORY, str(backstory))

            self._agent_spans[agent_key] = span
            self._client.export_eager_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_agent_started", exc_info=True)

    def _on_agent_completed(self, source: Any, event: Any) -> None:
        try:
            agent = getattr(event, "agent", None)
            span = self._agent_spans.pop(id(agent), None) if agent is not None else None
            if not span:
                return
            output = getattr(event, "output", None)
            if output is not None:
                span.set_output(str(output))
            span.set_status(StatusCode.OK)
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_agent_completed", exc_info=True)

    def _on_agent_error(self, source: Any, event: Any) -> None:
        try:
            agent = getattr(event, "agent", None)
            span = self._agent_spans.pop(id(agent), None) if agent is not None else None
            if not span:
                return
            error = getattr(event, "error", None)
            exc = error if isinstance(error, BaseException) else Exception(str(error) if error else "Agent error")
            span.set_attribute("error.type", type(exc).__qualname__)
            span.record_exception(exc)
            span.set_status(StatusCode.ERROR, str(error) if error else "Agent error")
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_agent_error", exc_info=True)

    # ------------------------------------------------------------------
    # LLM call lifecycle
    # ------------------------------------------------------------------

    def _on_llm_started(self, source: Any, event: Any) -> None:
        try:
            # source is the agent making the LLM call
            agent_key = id(source)
            parent_span = self._agent_spans.get(agent_key) or self._crew_span
            parent_id = parent_span.span_id if parent_span else None

            model = getattr(event, "model", None) or ""
            span = Span(
                name=f"llm-call{': ' + model if model else ''}",
                trace_id=self._trace_id,
                parent_id=parent_id,
                span_type=SpanType.GENERATION,
                kind=SpanKind.CLIENT,
                session_id=self._session_id,
            )
            span.start()
            span.set_attribute(self.ATTR_GEN_AI_AGENT_FRAMEWORK, "crewai")
            span.set_attribute(self.ATTR_GEN_AI_OPERATION_NAME, "chat")
            span.set_attribute(self.ATTR_GEN_AI_PROVIDER_NAME, "crewai")

            if model:
                span.set_attribute(self.ATTR_GEN_AI_REQUEST_MODEL, model)
            messages = getattr(event, "messages", None)
            if messages is not None:
                span.set_input(messages)

            self._llm_spans[agent_key] = span
            self._client.export_eager_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_llm_started", exc_info=True)

    def _on_llm_completed(self, source: Any, event: Any) -> None:
        try:
            span = self._llm_spans.pop(id(source), None)
            if not span:
                return
            response = getattr(event, "response", None)
            if response is not None:
                span.set_output(str(response))
            span.set_status(StatusCode.OK)
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_llm_completed", exc_info=True)

    def _on_llm_failed(self, source: Any, event: Any) -> None:
        try:
            span = self._llm_spans.pop(id(source), None)
            if not span:
                return
            error = getattr(event, "error", None)
            exc = error if isinstance(error, BaseException) else Exception(str(error) if error else "LLM call failed")
            span.set_attribute("error.type", type(exc).__qualname__)
            span.record_exception(exc)
            span.set_status(StatusCode.ERROR, str(error) if error else "LLM call failed")
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_llm_failed", exc_info=True)

    # ------------------------------------------------------------------
    # Tool usage lifecycle
    # ------------------------------------------------------------------

    def _on_tool_started(self, source: Any, event: Any) -> None:
        try:
            tool_name = getattr(event, "tool_name", None) or "tool"
            tool_key = (id(source), tool_name)

            parent_span = self._agent_spans.get(id(source)) or self._crew_span
            parent_id = parent_span.span_id if parent_span else None

            span = Span(
                name=tool_name,
                trace_id=self._trace_id,
                parent_id=parent_id,
                span_type=SpanType.TOOL,
                kind=SpanKind.INTERNAL,
                session_id=self._session_id,
            )
            span.start()
            span.set_attribute(self.ATTR_GEN_AI_TOOL_NAME, tool_name)
            span.set_attribute(self.ATTR_GEN_AI_AGENT_FRAMEWORK, "crewai")
            span.set_attribute(self.ATTR_GEN_AI_OPERATION_NAME, "execute_tool")
            span.set_attribute(self.ATTR_GEN_AI_PROVIDER_NAME, "crewai")

            tool_input = getattr(event, "tool_args", None)
            if tool_input is not None:
                span.set_input(tool_input)

            self._tool_spans[tool_key] = span
            self._client.export_eager_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_tool_started", exc_info=True)

    def _on_tool_finished(self, source: Any, event: Any) -> None:
        try:
            tool_name = getattr(event, "tool_name", None) or "tool"
            span = self._tool_spans.pop((id(source), tool_name), None)
            if not span:
                return
            output = getattr(event, "output", None)
            if output is not None:
                span.set_output(str(output))
            span.set_status(StatusCode.OK)
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_tool_finished", exc_info=True)

    def _on_tool_error(self, source: Any, event: Any) -> None:
        try:
            tool_name = getattr(event, "tool_name", None) or "tool"
            span = self._tool_spans.pop((id(source), tool_name), None)
            if not span:
                return
            error = getattr(event, "error", None)
            exc = error if isinstance(error, BaseException) else Exception(str(error) if error else "Tool error")
            span.set_attribute("error.type", type(exc).__qualname__)
            span.record_exception(exc)
            span.set_status(StatusCode.ERROR, str(error) if error else "Tool error")
            span.end()
            self._client.export_span(span)
        except Exception:
            logger.warning("BeaconCrewAIListener: error in _on_tool_error", exc_info=True)
