import argparse
import json
from .evaluator import MarODEEvaluator, EvaluatorConfig, get_device


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--gpu", type=int, default=-1)
    args = parser.parse_args()

    device = get_device(args.gpu)
    config = EvaluatorConfig()
    evaluator = MarODEEvaluator(config, device)

    with open(args.input, "r") as f:
        entries = json.load(f)

    scored = [evaluator.score_entry(e) for e in entries]

    with open(args.output, "w") as f:
        json.dump(scored, f, indent=2)

    print("MarODE scoring complete.")


if __name__ == "__main__":
    main()