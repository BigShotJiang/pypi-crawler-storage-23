from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCallRequest:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class LLMResponse:
    """LLM Response"""

    content: str | None
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    finish_reason: str = "stop"
    usage: dict[str, int] = field(default_factory=dict)
    reasoning_content: str | None = None

    @property
    def has_tool_calls(self) -> bool:
        return len(self.tool_calls) > 0


class LLMProvider(ABC):
    """
    LLM Provider 抽象类。
    针对不同模型供应商的API做不同的处理，同时保持接口一致性。
    """

    def __init__(self, api_key: str | None = None, api_base: str | None = None):
        self.api_key = api_key
        self.api_base = api_base

    @abstractmethod
    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.1,
    ) -> LLMResponse:
        """
        大模型调用
        Args:
            messages: 消息列表[{'role':'user',content:'xxxxx'},{'role':'assistant','content':'yyyyy'}]
            tools:
            model: 模型id（provider-spec）
            max_tokens:
            temperature:

        Returns:
            LLMResponse 或者 工具调用（tool calls）
        """
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        """从provider中获取模型"""
        pass
