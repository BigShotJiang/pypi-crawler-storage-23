from abc import ABC, abstractmethod
from typing import Any

from loguru import logger

from sentrybot.bus import InboundMessage, MessageBus, OutboundMessage


class BaseChannel(ABC):
    name: str = "base"

    def __init__(self, config: Any, bus: MessageBus):
        self.config = config
        self.bus = bus
        self._running = False

    @abstractmethod
    async def start(self) -> None:
        """
        Start Channel and begin listening for messages
        This should be long-running async task that:
        1. Connects to the chat platform.
        2. Listens from incoming messages.
        3. Forwards messages to the bus via _handle_message()
        """
        pass

    @abstractmethod
    async def stop(self) -> None:
        """Stop the channel and clean up the resources"""
        pass

    @abstractmethod
    async def send(self, msg: OutboundMessage) -> None:
        """Send message through this channel"""
        pass

    def is_allowed(self, sender_id: str) -> bool:
        allow_list = getattr(self.config, "allow_from", [])
        if not allow_list:
            return True

        sender_str = str(sender_id)
        if sender_str in allow_list:
            return True
        return False

    async def _handle_message(
        self,
        sender_id: str,
        chat_id,
        content: str,
        media: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Handle an incoming message from the chat platform
        This method checks permissions and forwards to the bus.
        """
        if not self.is_allowed(sender_id):
            logger.warning(f"Access denied from sender {sender_id} on channel {self.name}")
            return
        msg = InboundMessage(
            channel=self.name,
            sender_id=sender_id,
            chat_id=chat_id,
            content=content,
            media=media or [],
            metadata=metadata or {},
        )

        await self.bus.publish_inbound(msg)

    @property
    def is_running(self) -> bool:
        return self._running
