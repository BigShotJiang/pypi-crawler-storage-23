"""Channel Manager"""

import asyncio
from typing import Any

from loguru import logger

from sentrybot.bus import MessageBus
from sentrybot.channels.base import BaseChannel
from sentrybot.config import Config


class ChannelManager:
    def __init__(self, config: Config, bus: MessageBus):
        self.config = config
        self.bus = bus
        self.channels: dict[str, BaseChannel] = {}
        self._dispatch_task: asyncio.Task | None = None

        self._init_channels()

    def _init_channels(self) -> None:
        # Feishu Channel
        if self.config.channels.feishu.enabled:
            try:
                from sentrybot.channels.feishu import FeishuChannel

                self.channels["feishu"] = FeishuChannel(self.config.channels.feishu, self.bus)
                logger.info("Feishu channel enabled.")
            except ImportError as e:
                logger.error(f"Feishu channel not available {e}")

    async def _start_channel(self, name: str, channel: BaseChannel) -> None:
        """Start a channel"""
        try:
            await channel.start()
        except Exception as e:
            logger.error(f"Failed to start channel {name}: {e}")

    async def start_all(self) -> None:
        """Start all channels"""
        if not self.channels:
            logger.warning("No channels enabled.")
            return

        # Start outbound dispatcher
        self._dispatch_task = asyncio.create_task(self._dispatch_outbound())

        tasks = []
        for name, channel in self.channels.items():
            logger.info(f"Starting {name} channel.")
            tasks.append(asyncio.create_task(self._start_channel(name, channel)))

        # Wait for all to complete (run forever)
        await asyncio.gather(*tasks, return_exceptions=True)

    async def stop_all(self) -> None:
        logger.info("Stopping all channels.")
        # Stop dispatcher

        if self._dispatch_task:
            self._dispatch_task.cancel()
            try:
                await self._dispatch_task
            except asyncio.CancelledError:
                pass

        # Stop all channels
        for name, channel in self.channels.items():
            try:
                await channel.stop()
                logger.info(f"Stopped {name} channel")
            except Exception as e:
                logger.error(f"Error stopping {name}: {e}")

    async def _dispatch_outbound(self) -> None:
        """接收Bus Outbound消息,将消息向外发布
        Agent处理逻辑 → 消息总线 → _dispatch_task → 具体通道 → 外部平台
          ↓                ↓           ↓           ↓          ↓
        生成回复     发布OutboundMessage  路由消息   发送消息   Telegram/WhatsApp等
        """
        logger.info("Outbound dispatcher started.")
        while True:
            try:
                msg = await asyncio.wait_for(self.bus.consume_outbound(), timeout=1.0)
                channel = self.channels.get(msg.channel)
                if channel:
                    try:
                        await channel.send(msg)
                    except Exception as e:
                        logger.error(f"Error sending to {msg.channel}: {e}")
                else:
                    logger.warning(f"Unknow channel: {msg.channel}")
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

    def get_channel(self, name: str) -> BaseChannel | None:
        return self.channels.get(name)

    def get_status(self) -> dict[str, Any]:
        return {
            name: {"enabled": True, "running": channel.is_running} for name, channel in self.channels.items()
        }

    @property
    def enabled_channels(self) -> list[str]:
        return list(self.channels.keys())
