"""
sentrybot - A lightweight AI agent framework
"""

__version__ = "0.1.0"
__logo__ = "🤖"
