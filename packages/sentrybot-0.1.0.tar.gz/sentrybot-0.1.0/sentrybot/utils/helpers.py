from datetime import datetime
from pathlib import Path


def ensure_dir(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary."""
    path.mkdir(parents=True, exist_ok=True)
    return path

#
# def today_date() -> str:
#     """Get today's date in YYYY-MM-DD format."""
#     return datetime.now().strftime("%Y-%m-%d")


def get_workspace_path(workspace: str | None = None) -> Path:

    if workspace:
        path = Path(workspace).expanduser()
    else:
        path = Path.home() / ".sentrybot" / "workspace"
    return ensure_dir(path)


def get_data_path() -> Path:
    """Get the sentrybot data directory (~/.sentrybot)."""
    return ensure_dir(Path.home() / ".sentrybot")


def get_sessions_path() -> Path:
    """Get the sessions storage directory."""
    return ensure_dir(get_data_path() / "sessions")


def get_skills_path(workspace: Path | None = None) -> Path:
    """Get the skills directory within the workspace."""
    ws = workspace or get_workspace_path()
    return ensure_dir(ws / "skills")


def safe_filename(name: str) -> str:
    """Convert a string to a safe filename."""
    # Replace unsafe characters
    unsafe = '<>:"/\\|?*'
    for char in unsafe:
        name = name.replace(char, "_")
    return name.strip()
