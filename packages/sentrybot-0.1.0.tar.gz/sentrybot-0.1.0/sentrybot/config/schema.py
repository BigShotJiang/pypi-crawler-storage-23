from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel
from pydantic_settings import BaseSettings, SettingsConfigDict

from sentrybot.providers.registry import PROVIDERS, find_by_name


class Base(BaseModel):
    """Base model that accepts both camelCase and snake_case keys."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


# CHANNEL


class FeishuConfig(Base):
    enabled: bool = False
    app_id: str = ""
    app_secret: str = ""
    encrypt_key: str = ""
    verification_token: str = ""
    allow_from: list[str] = Field(default_factory=list)


class EmailConfig(Base):
    """Email channel configuration (IMAP inbound + SMTP outbound)."""

    enabled: bool = False
    consent_granted: bool = False  # Explicit owner permission to access mailbox data

    # IMAP (receive)
    imap_host: str = ""
    imap_port: int = 993
    imap_username: str = ""
    imap_password: str = ""
    imap_mailbox: str = "INBOX"
    imap_use_ssl: bool = True

    # SMTP (send)
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True
    smtp_use_ssl: bool = False
    from_address: str = ""

    # Behavior
    auto_reply_enabled: bool = True  # If false, inbound email is read but no automatic reply is sent
    poll_interval_seconds: int = 15
    mark_seen: bool = True
    max_body_chars: int = 12000
    subject_prefix: str = "Re: "
    allow_from: list[str] = Field(default_factory=list)  # Allowed sender email addresses


class ChannelsConfig(Base):
    feishu: FeishuConfig = Field(default_factory=FeishuConfig)
    email: EmailConfig = Field(default_factory=EmailConfig)


# LLM PROVIDER


class ProviderConfig(Base):
    """LLM provider"""

    api_key: str = ""
    api_base: str | None = None
    extra_headers: dict[str, str] | None = None


class ProvidersConfig(Base):
    """LLM providers"""

    deepseek: ProviderConfig = Field(default_factory=ProviderConfig)
    dashscope: ProviderConfig = Field(default_factory=ProviderConfig)  # 阿里云通义千问


# AGENT


class AgentDefaults(Base):
    workspace: str = "~/.sentrybot/workspace"
    model: str = "deepseek/deepseek-chat"
    max_tokens: int = 8192
    temperature: float = 0.1
    max_tool_iterations: int = 20
    memory_window: int = 50


class AgentsConfig(Base):
    defaults: AgentDefaults = Field(default_factory=AgentDefaults)


# TOOL


class WebSearchConfig(Base):
    api_key: str = ""
    max_result: int = 5


class WebToolsConfig(Base):
    search: WebSearchConfig = Field(default_factory=WebSearchConfig)


class ExecToolConfig(Base):
    timeout: int = 60


class ToolsConfig(Base):
    web: WebToolsConfig = Field(default_factory=WebToolsConfig)
    exec: ExecToolConfig = Field(default_factory=ExecToolConfig)
    restrict_to_workspace: bool = False


# MCP


class MCPServerConfig(Base):
    """MCP server connection configuration (stdio or HTTP)."""

    command: str = ""  # Stdio: command to run (e.g. "npx")
    args: list[str] = Field(default_factory=list)  # Stdio: command arguments
    env: dict[str, str] = Field(default_factory=dict)  # Stdio: extra env vars
    url: str = ""  # HTTP: streamable HTTP endpoint URL


# GATEWAY


class GatewayConfig(Base):
    """Gateway config"""

    host: str = "0.0.0.0"
    port: int = 18790


# ROOT


class Config(BaseSettings):
    """Root Config"""

    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)

    @property
    def workspace_path(self) -> Path:
        return Path(self.agents.defaults.workspace).expanduser()

    def _match_provider(self, model: str | None = None) -> tuple[ProviderConfig | None, str | None]:
        """Match provider config and its registry name. Returns (config, spec_name)."""

        model_lower = (model or self.agents.defaults.model).lower()
        # 通过关键字匹配 provider 配置 和 provider 注册名
        for spec in PROVIDERS:
            p: ProviderConfig | None = getattr(self.providers, spec.name, None)
            # print(f"provider_cfg>>> {p}")
            if p and any(kw in model_lower for kw in spec.keywords) and p.api_key:
                return p, spec.name
        # 回退机制，gateway类型优先
        for spec in PROVIDERS:
            p: ProviderConfig | None = getattr(self.providers, spec.name, None)
            if p and p.api_key:
                return p, spec.name
        return None, None

    def get_provider(self, model: str | None = None) -> ProviderConfig | None:
        """
        获取模型provider配置（api_key,api_base,extra_headers）
        """
        p, _ = self._match_provider(model)
        return p

    def get_provider_name(self, model: str | None = None) -> str | None:
        """获取provider的注册名称（e.g. deepseek, openrouter）"""
        _, name = self._match_provider(model)
        return name

    def get_api_key(self, model: str | None = None):
        """获取模型API_KEY"""
        p = self.get_provider(model)
        return p.api_key if p else None

    def get_api_base(self, model: str | None = None) -> str | None:
        """获取模型BASE_URL, 如果没有则从provider注册表中获取默认值"""

        p, name = self._match_provider(model)
        if p and p.api_base:
            return p.api_base

        # 这里只返回gateway类型的BASE_URL
        # 标准的模型provider（deepseek,dashscope）通过环境变量配置base_url
        # 避免与litellm.api_base干扰
        if name:
            spec = find_by_name(model)
            if spec and spec.is_gateway and spec.default_api_base:
                return spec.default_api_base
        return None

    model_config = SettingsConfigDict(env_prefix="SENTRYBOT_", env_nested_delimiter="__")
