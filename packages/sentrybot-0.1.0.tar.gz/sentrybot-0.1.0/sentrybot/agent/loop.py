"""Agent loop: 核心处理引擎."""

import asyncio
import json
from pathlib import Path

from loguru import logger

from sentrybot.agent.context import ContextBuilder
from sentrybot.agent.memory import MemoryStore
from sentrybot.agent.tools import ToolRegistry
from sentrybot.agent.tools.filesystem import EditFileTool, ListDirTool, ReadFileTool, WriteFileTool
from sentrybot.agent.tools.message import MessageTool
from sentrybot.agent.tools.web import WebFetchTool, WebSearchTool
from sentrybot.bus import InboundMessage, MessageBus, OutboundMessage
from sentrybot.config.schema import ExecToolConfig
from sentrybot.providers import LLMProvider
from sentrybot.session.manager import Session, SessionManager


class AgentLoop:
    """
    任务：
    1. 从消息总线（MessageBus）中接收消息
    2. 创建上下文（context），包含：history，memory,skills
    3. LLM调用
    4. 工具执行
    5. 回复消息
    """

    def __init__(
        self,
        bus: MessageBus,
        provider: LLMProvider,
        workspace: Path,
        model: str | None = None,
        max_iterations: int = 20,
        temperature: float = 0.1,
        max_tokens: int = 4096,
        memory_window: int = 50,
        tavily_api_key: str | None = None,
        exec_config: ExecToolConfig | None = None,
        cron_service=None,
        restrict_to_workspace: bool = False,
        session_manager: SessionManager | None = None,
    ):
        self.bus = bus
        self.provider = provider
        self.workspace = workspace
        self.model = model or provider.get_default_model()
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_iterations = max_iterations
        self.memory_window = memory_window

        self.tavily_api_key = tavily_api_key
        self.exec_config = exec_config
        self.cron_service = cron_service
        self.restrict_to_workspace = restrict_to_workspace

        self.context = ContextBuilder(workspace)
        self.sessions = session_manager or SessionManager(workspace)
        self.tools = ToolRegistry()

        self.subagents = []
        self._running = False
        self._register_default_tools()

    def _register_default_tools(self):
        allowed_dir = self.workspace if self.restrict_to_workspace else None
        self.tools.register(ReadFileTool(allowed_dir=allowed_dir))
        self.tools.register(WriteFileTool(allowed_dir=allowed_dir))
        self.tools.register(EditFileTool(allowed_dir=allowed_dir))
        self.tools.register(ListDirTool(allowed_dir=allowed_dir))
        ## web tools
        self.tools.register(WebSearchTool(api_key=self.tavily_api_key))
        self.tools.register(WebFetchTool())
        ## message tool
        ## spawn tool
        ## cron tool

    def _set_tool_context(self, channel: str, chat_id: str) -> None:
        """Update context for all tools that need routing info."""
        # 配置 MessageTool的context
        if message_tool := self.tools.get("message"):
            if isinstance(message_tool, MessageTool):
                message_tool.set_context(channel, chat_id)

    async def _run_agent_loop(self, initial_messages: list[dict]) -> tuple[str | None, list[str]]:
        """
        Run the agent iteration loop.

        Args:
            initial_messages:

        Returns:
            Tuple of (final_content, list_of_tools_used).
        """
        messages = initial_messages
        iteration = 0
        final_content = None
        tools_used: list[str] = []
        while iteration < self.max_iterations:
            iteration += 1
            response = await self.provider.chat(
                messages=messages,
                tools=self.tools.get_definitions(),
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            if response.has_tool_calls:
                tool_call_dicts = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)},
                    }
                    for tc in response.tool_calls
                ]
                messages = self.context.add_assistant_message(
                    messages=messages,
                    content=response.content,
                    tool_calls=tool_call_dicts,
                    reasoning_content=response.reasoning_content,
                )
                for tool_call in response.tool_calls:
                    tools_used.append(tool_call.name)
                    args_str = json.dumps(tool_call.arguments, ensure_ascii=False)
                    logger.info(f"Tool call : {tool_call.name}({args_str[:200]})")
                    result = await self.tools.execute(tool_call.name, tool_call.arguments)
                    messages = self.context.add_tool_result(messages, tool_call.id, tool_call.name, result)
                # messages.append({"role": "user", "content": "Reflect on the results and decide next steps"})
            else:
                final_content = response.content
                break
        return final_content, tools_used

    async def run(self) -> None:
        """
        agent主循环，接收/处理MessageBus消息
        """
        self._running = True
        logger.info("Agent loop started.")
        while self._running:
            try:
                # 1. 等待下一条消息到达
                msg = await asyncio.wait_for(self.bus.consume_inbound(), timeout=1.0)
                # 2. 处理消息
                try:
                    response: OutboundMessage = await self._process_message(msg)
                    if response:
                        await self.bus.publish_outbound(response)
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    # 错误消息回复
                    await self.bus.publish_outbound(
                        OutboundMessage(
                            channel=msg.channel,
                            chat_id=msg.chat_id,
                            content=f"Sorry, I encountered an error : {str(e)}",
                        )
                    )
            except asyncio.TimeoutError:
                continue

    def stop(self):
        self._running = False
        logger.info("Agent loop stopping.")

    async def _process_message(
        self, msg: InboundMessage, session_key: str | None = None
    ) -> OutboundMessage | None:
        """
        消息前置处理
        """
        # 系统消息? 什么是系统消息？
        if msg.channel == "system":
            return await self._process_system_message(msg)

        preview = msg.content[:80] + "..." if len(msg.content) >= 80 else msg.content
        logger.info(f"Processing message from {msg.channel}:{msg.sender_id}:{preview}")

        # 获取/创建会话
        key = session_key or msg.session_key
        session = self.sessions.get_or_create(key)

        # 处理命令
        cmd = msg.content.strip().lower()
        if cmd == "/clear":
            # 只清理，不记录/摘要历史
            session.clear()
            self.sessions.save(session)
            self.sessions.invalidate(session.key)
            return OutboundMessage(
                channel=msg.channel, chat_id=msg.chat_id, content="Session cleared.New Session started."
            )
        if cmd == "/new":
            # 清理缓存,session历史摘要
            # Capture messages before cleaning (avoid race condition with background task)
            message_to_archive = session.messages.copy()
            session.clear()
            self.sessions.save(session)
            self.sessions.invalidate(session.key)

            async def _consolidate_and_cleanup():
                """对历史会话进行总结并写入MEMORY和HISTORY"""
                temp_session = Session(key=session.key)
                temp_session.messages = message_to_archive
                await self._consolidate_memory(temp_session, archive_all=True)

            asyncio.create_task(_consolidate_and_cleanup())
            return OutboundMessage(
                msg.channel, msg.chat_id, content="New Session started. Memory consolidate in progress."
            )
        # 帮助命令
        if cmd == "/help":
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id, content="help ...")
        # 未知命令
        if cmd.startswith("/"):
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id, content="unknow command.")

        # # 根据memory_windows做consolidation
        # if len(session.messages) >= self.memory_window:
        #     asyncio.create_task(self._consolidate_memory(session))

        # 工具上下文配置
        self._set_tool_context(msg.channel, msg.chat_id)

        initial_messages = self.context.build_messages(
            history=session.get_history(max_messages=self.memory_window),
            current_message=msg.content,
            media=msg.media if msg.media else None,
            channel=msg.channel,
            chat_id=msg.chat_id,
        )

        final_content, tools_used = await self._run_agent_loop(initial_messages)
        if final_content is None:
            final_content = "I've completed processing but have no response to give."
        # 保存会话内容
        session.add_message("user", msg.content)
        session.add_message("assistant", final_content, tools_used=tools_used if tools_used else None)
        self.sessions.save(session)
        # 返回
        return OutboundMessage(
            channel=msg.channel,
            chat_id=msg.chat_id,
            content=final_content,
            metadata=msg.metadata or {},
        )

    async def _process_system_message(self, msg: InboundMessage) -> OutboundMessage | None:
        """
        Process a system message (e.g. subagent announce)

        The chat_id field contains "original_channel:original_chat_id" to route
        the response back to the correct destination.

        """
        logger.info(f"Processing system message from  {msg.sender_id}")
        if ":" in msg.chat_id:
            parts = msg.chat_id.split(":")
            origin_channel = parts[0]
            origin_chat_id = parts[1]
        else:
            # Fallback
            origin_channel = "cli"
            origin_chat_id = msg.chat_id

        session_key = f"{origin_channel}:{origin_chat_id}"
        session = self.sessions.get_or_create(session_key)
        self._set_tool_context(origin_channel, origin_chat_id)
        initial_messages = self.context.build_messages(
            history=session.get_history(max_messages=self.memory_window),
            current_message=msg.content,
            channel=origin_channel,
            chat_id=origin_chat_id,
        )
        final_content, _ = await self._run_agent_loop(initial_messages)

    async def process_direct(
        self, content: str, session_key: str = "cli:direct", channel: str = "cli", chat_id: str = "direct"
    ):
        """
        Process message directly from cli (for CLI or cron usage.)
        Args:
            content:
            session_key:
            channel:
            chat_id:

        Returns:
            agent's response
        """
        msg = InboundMessage(channel=channel, sender_id="user", chat_id=chat_id, content=content)
        response = await self._process_message(msg, session_key=session_key)
        return response.content if response else ""

    async def _consolidate_memory(self, session, archive_all: bool = False) -> None:
        """Consolidate old messages into MEMORY.md + HISTORY.md

        Args:
            archive_all: If True, clean all messages and reset session (for /new command)
                        If False, only write to files without modifying session.
        """
        memory = MemoryStore(self.workspace)
        if archive_all:
            old_messages = session.messages
            keep_count = 0
            logger.info(
                f"Memory consolidation (archive_all): {len(session.messages)} total messages archived"
            )
        else:
            keep_count = self.memory_window // 2
            if len(session.messages) <= keep_count:
                logger.debug(
                    f"Session {session.key}: No consolidation needed (messages={len(session.messages)}, keep={keep_count})"
                )
                return
            message_to_process = len(session.messages) - session.last_consolidated
            if message_to_process <= 0:
                logger.debug(
                    f"Session {session.key}: No new messages to consolidate (last_consolidated={session.last_consolidated}, total={len(session.messages)})"
                )
                return
            old_messages = session.messages[session.last_consolidated : -keep_count]
            if not old_messages:
                return
            logger.info(
                f"Memory consolidation started: {len(session.messages)} total, {len(old_messages)} new to consolidate, {keep_count} keep"
            )
        lines = []
        for m in old_messages:
            if not m.get("content"):
                continue
            tools = f"[tools: {', '.join(m['tools_used'])}]" if m.get("tools_used") else ""
            lines.append(f"[{m.get('timestamp', '?')[:16]}] {m['role'].upper()}{tools}: {m['content']}")
        conversation = "\n".join(lines)
        current_memory = memory.read_long_term()
        prompt = f"""You are memory consolidation agent. Process this conversion and return a JSON object with exactly two keys:
1. "history_entry": A paragraph (2-5 sentences) summarizing the key events/decisions/topics. Start with a timestamp like [YYYY-MM-DD HH:MM]. Include enough detail to be useful when found by grep search later.

2. "memory_update": The updated long-term memory content. Add any new facts: user location, preferences, personal info, habits, project context, technical decisions, tools/services used. If nothing new, return the existing content unchanged.

## Current Long-term Memory
{current_memory or "(empty)"}

## Conversation to Process
{conversation}

Response with ONLY valid JSON, not markdown fences."""
        try:
            response = await self.provider.chat(
                messages=[
                    {
                        "role": "system",
                        "content": "You are a summary consolidation agent. Respond only with valid JSON.",
                    },
                    {"role": "user", "content": prompt},
                ],
                model=self.model,
            )
            text = (response.content or "").strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
            result = json.loads(text)
            if entry := result.get("history_entry"):
                memory.append_history(entry)
            if update := result.get("memory_update"):
                if update != current_memory:
                    memory.write_long_term(update)
            if archive_all:
                session.last_consolidated = 0
            else:
                session.last_consolidated = len(session.messages) - keep_count
            logger.info(
                f"Memory consolidation done:{len(session.messages)} messages, last_consolidated={session.last_consolidated}."
            )
        except Exception as e:
            logger.error(f"Memory consolidation failed: {e}")
