"""上下文创建器"""

import base64
import datetime
import mimetypes
import platform
from pathlib import Path
from typing import Any

from sentrybot.agent.memory import MemoryStore
from sentrybot.agent.skills import SkillsLoader

# ----------------------------------------------------------------------
# PROMPT_TEMPLATES
# ----------------------------------------------------------------------

_PROMPT_TEMPLATE = """# Sentrybot 🤖
You are a helpful AI assistant. You have access to tools that allow you to:
- Read, write, and edit files
- Execute shell commands
- Search the web and fetch web pages
- Send messages to users on chat channels
- Spawn subagents for complex background tasks

## Current Time
{now}

## Runtime
{runtime}

## Workspace
Your workspace is at: {workspace_path}
- Memory files: {workspace_path}\\memory\\MEMORY.md
- Custom skills: {workspace_path}\\skills\\{{skill-name}}\\SKILL.md

IMPORTANT: When responding to direct questions or conversations, reply directly with your text response.
Only use the 'message' tool when you need to send a message to a specific chat channel (like WhatsApp).
For normal conversation, just respond with text - do not call the message tool.

Always be helpful, accurate, and concise. When using tools, explain what you're doing.
When remembering something, write to {workspace_path}\\memory\\MEMORY.md"""


_AVAILABLE_SKILLS_TEMPLATE = """# Skills

The following skills extend your capabilities. To use a skill, read its SKILL.md file using the read_file tool.
Skills with available="false" need dependencies installed first - you can try installing them with apt/brew.

{skills_summary}"""

# ----------------------------------------------------------------------
# ContextBuilder
# ----------------------------------------------------------------------


class ContextBuilder:
    """
    创建Agent Context(system prompt + messages)
    组装 启动文件（bootstrap files），记忆（memory），技能（skills）和历史对话（history） 成一个合理的系统提示词（prompt）
    """

    BOOTSTRAP_FILES = ["AGENTS.md", "SOUL.md", "USER.md", "TOOLS.md", "IDENTITY.md"]

    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.memory = MemoryStore(workspace)
        self.skills = SkillsLoader(workspace)

    def build_system_prompt(self, skill_names: list[str] | None = None) -> str:
        """
        build system prompt
        """
        parts = list()
        # 核心标识
        parts.append(self._get_identity())

        # 启动文件
        bootstrap = self._load_bootstrap_files()
        if bootstrap:
            parts.append(bootstrap)

        # 记忆上下文

        memory = self.memory.get_memory_context()
        if memory:
            parts.append(f"# Memory\n\n{memory}")

        # Skills
        # 1. always-loaded skills: 必要skills，skill全部内容
        always_skills = self.skills.get_always_skills()
        if always_skills:
            always_content = self.skills.load_skills_for_context(always_skills)
            if always_content:
                parts.append(f"# Active Skills\n\n{always_content}")

        # 2. 可用skills,紧紧在需要时加载内容
        skills_summary = self.skills.build_skills_summary()
        if skills_summary:
            parts.append(_AVAILABLE_SKILLS_TEMPLATE.format(skills_summary=skills_summary))

        return "\n\n---\n\n".join(parts)

    def _get_identity(self) -> str:
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M (%A)")
        workspace_path = str(self.workspace.expanduser().resolve())
        system = platform.system()
        runtime = f"{'macOS' if system == 'Darwin' else system} {platform.machine()}, Python {platform.python_version()}"
        return _PROMPT_TEMPLATE.format(now=now, runtime=runtime, workspace_path=workspace_path)

    def _load_bootstrap_files(self) -> str:
        """从workspace中加载文件"""
        parts = []
        for filename in self.BOOTSTRAP_FILES:
            file_path = self.workspace / filename
            if file_path.exists():
                content = file_path.read_text(encoding="utf-8")
                parts.append(f"{filename}\n\n{content}")
        return "\n\n".join(parts) if parts else ""

    def build_messages(
        self,
        history: list[dict[str, Any]],
        current_message: str,
        skill_names: list[str] | None = None,
        media: list[str] | None = None,
        channel: str | None = None,
        chat_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Build complete messages for LLM call
        Args:
            history:
            current_message:
            skill_names:
            media:
            channel:
            chat_id:

        Returns:
            List of messages including system prompt.
        """
        messages = []
        # System prompt
        system_prompt = self.build_system_prompt()
        if channel and chat_id:
            system_prompt += f"\n\n## Current Session\nChannel: {channel}\nChat ID:{chat_id}"
        messages.append({"role": "system", "content": system_prompt})

        # History
        messages.extend(history)

        # Current message (with optional image attachments)
        user_content = self._build_user_content(current_message, media)
        messages.append({"role": "user", "content": user_content})
        return messages

    def _build_user_content(self, text: str, media: list[str] | None) -> str | list[dict[str, Any]]:
        if not media:
            return text
        images = []
        for path in media:
            p = Path(path)
            mime, _ = mimetypes.guess_type(path)
            if not p.is_file() or not mime or not mime.startswith("image/"):
                continue
            b64 = base64.b64encode(p.read_bytes()).decode()
            images.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}})

        if not images:
            return text
        return images + [{"type": "text", "text": text}]

    def add_tool_result(
        self, messages: list[dict[str, Any]], too_call_id: str, tool_name: str, result: str
    ) -> list[dict[str, Any]]:
        """Add tool result to message list"""
        messages.append({"role": "tool", "tool_call_id": too_call_id, "name": tool_name, "content": result})
        return messages

    def add_assistant_message(
        self,
        messages: list[dict[str, Any]],
        content: str | None,
        tool_calls: list[dict[str, Any]] | None = None,
        reasoning_content: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Add assistant message to the message list
        Args:
            messages:
            content:
            tool_calls:
            reasoning_content:

        Returns:
            Updated message list
        """
        msg: dict[str, Any] = {"role": "assistant", "content": content or ""}
        if tool_calls:
            msg["tool_calls"] = tool_calls

        if reasoning_content:
            msg["reasoning_content"] = reasoning_content

        messages.append(msg)
        return messages
