""" """

from typing import Any

from sentrybot.agent.tools.base import Tool


class SpawnTool(Tool):
    def __ini__(self, manager):
        self._manager = manager
        self._origin_channel = "cli"
        self._origin_chat_id = "direct"

    def set_context(self, channel: str, chat_id: str) -> None:
        self._origin_channel = channel
        self._origin_chat_id = chat_id

    @property
    def name(self) -> str:
        return "spawn"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "The task for the subagent to complete."},
                "label": {"type": "string", "description": "Optional short label for the task (display use.)"},
            },
            "required": ["task"],
        }

    @property
    async def execute(self, **kwargs: Any) -> str:
        return ""
