"""
Async 消息队列
"""

import asyncio
from typing import Callable, Awaitable
from sentrybot.bus.events import InboundMessage, OutboundMessage
from loguru import logger


class MessageBus:
    """
    channel -> inbound_queue -> agent -> outbound_queue
    """

    def __init__(self):
        self.inbound: asyncio.Queue[InboundMessage] = asyncio.Queue()
        self.outbound: asyncio.Queue[OutboundMessage] = asyncio.Queue()
        # outbound_subscribers 存储的一系列处理消息的方法，
        # 例如：日志，通知，转发等
        # e.g. [log(msg)，notify(msg),forward(msg)...]
        self._outbound_subscribers: dict[str, list[Callable[[OutboundMessage], Awaitable[None]]]] = {}
        self._running = False

    async def publish_inbound(self, msg: InboundMessage) -> None:
        """channel -> agent"""
        await self.inbound.put(msg)

    async def consume_inbound(self) -> InboundMessage:
        """agent消费队列，阻塞直到有新消息到达"""
        return await self.inbound.get()

    async def publish_outbound(self, msg: OutboundMessage) -> None:
        """agent -> channel, 智能体消息发送给channel"""
        await self.outbound.put(msg)

    async def consume_outbound(self) -> OutboundMessage:
        """channel消费队列，阻塞直到有新消息"""
        return await self.outbound.get()

    async def subscribe_outbound(self, channel: str, callback: Callable[[OutboundMessage], Awaitable[None]]) -> None:
        """channel订阅出队列"""
        if channel not in self._outbound_subscribers:
            self._outbound_subscribers[channel] = []
        self._outbound_subscribers[channel].append(callback)

    async def dispatch_outbound(self) -> None:
        """
        后台运行，使用channel注册的回调函数（callback）处理outbound消息，
        """
        self._running = True
        while self._running:
            try:
                msg: OutboundMessage = await asyncio.wait_for(self.outbound.get(), timeout=1.0)
                subscribers = self._outbound_subscribers.get(msg.channel, [])
                # 注册的方法消费消息， e.g. log, notify, forward
                for cb in subscribers:
                    try:
                        await cb(msg)
                    except Exception as e:
                        logger.error(f"Error dispatching to {msg.channel}:{e}")
            except asyncio.TimeoutError:
                continue

    def stop(self) -> None:
        self._running = False

    @property
    def inbound_size(self):
        return self.inbound.qsize()

    @property
    def outbound_size(self):
        return self.outbound.qsize()
