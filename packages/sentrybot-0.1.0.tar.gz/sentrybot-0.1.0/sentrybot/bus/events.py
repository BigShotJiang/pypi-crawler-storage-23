from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class InboundMessage:
    """channel->agent 入方向消息"""

    channel: str  # feishu, whatsapp, slack...
    sender_id: str  # 用户id
    chat_id: str  # chat/channel id
    content: str  # 消息内容
    timestamp: datetime = field(default_factory=datetime.now)
    media: list[str] = field(default_factory=list)  # 媒体URLs
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def session_key(self) -> str:
        """会话id"""
        return f"{self.channel}:{self.chat_id}"


@dataclass
class OutboundMessage:
    """agent->channel 消息出方向"""

    channel: str
    chat_id: str
    content: str
    reply_to: str | None = None
    media: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
