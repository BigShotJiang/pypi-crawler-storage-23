"""
消息总线模块，分离Channel-Agent通信
"""

from sentrybot.bus.events import InboundMessage, OutboundMessage
from sentrybot.bus.queue import MessageBus


__all__ = ["MessageBus", "InboundMessage", "OutboundMessage"]
