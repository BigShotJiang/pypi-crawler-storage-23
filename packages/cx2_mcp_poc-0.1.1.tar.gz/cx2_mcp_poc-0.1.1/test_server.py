"""
Quick integration test for cx2-mcp using small-network.valid.cx2.
Starts the HTTP server, loads the file, and exercises all tools.
"""

import asyncio
import json
import sys
import time
import urllib.request
from pathlib import Path

# Make sure the local package is importable
sys.path.insert(0, str(Path(__file__).parent))

import cx2_mcp.server as srv

FILE = Path(__file__).parent / "cx2/valid/small-network.valid.cx2"
FN = FILE.name
PORT = 18888  # use a non-default port to avoid conflicts

# ── helpers ───────────────────────────────────────────────────────────────────

PASS = "\033[32mPASS\033[0m"
FAIL = "\033[31mFAIL\033[0m"

def check(label: str, condition: bool, detail: str = ""):
    status = PASS if condition else FAIL
    suffix = f"  ({detail})" if detail else ""
    print(f"  [{status}] {label}{suffix}")
    if not condition:
        sys.exit(1)

async def tool(name: str, **kwargs):
    results = await srv.call_tool(name, kwargs)
    text = results[0].text
    return json.loads(text)

# ── tests ─────────────────────────────────────────────────────────────────────

async def run():
    srv._server_port = PORT
    srv._ensure_http_server(PORT)
    time.sleep(0.5)  # let uvicorn bind

    print("\n── serve_file ──────────────────────────────────────────────────")
    r = await tool("serve_file", path=str(FILE))
    check("no error", "error" not in r, str(r))
    check("filename", r["loaded"] == FN)
    check("local_url", f"localhost:{PORT}" in r["local_url"])
    check("cyw_url", "web.cytoscape.org" in r["cytoscape_web_url"])

    print("\n── HTTP endpoint ───────────────────────────────────────────────")
    url = f"http://localhost:{PORT}/{FN}"
    with urllib.request.urlopen(url) as resp:
        body = json.loads(resp.read())
    check("200 response", isinstance(body, list))
    check("has nodes aspect", any("nodes" in x for x in body if isinstance(x, dict)))
    check("has edges aspect", any("edges" in x for x in body if isinstance(x, dict)))

    print("\n── get_network_summary ─────────────────────────────────────────")
    r = await tool("get_network_summary", filename=FN)
    check("node_count == 20", r["node_count"] == 20, str(r["node_count"]))
    check("edge_count == 30", r["edge_count"] == 30, str(r["edge_count"]))
    check("node attrs present", "n" in r["node_attributes"])

    print("\n── get_nodes (unfiltered) ──────────────────────────────────────")
    r = await tool("get_nodes", filename=FN)
    check("all 20 nodes", r["count"] == 20)

    print("\n── get_nodes (filtered) ────────────────────────────────────────")
    r = await tool("get_nodes", filename=FN, attribute="type", operator="eq", value="protein")
    proteins = r["nodes"]
    check("10 protein nodes", r["count"] == 10, str(r["count"]))

    print("\n── get_edges (filtered) ────────────────────────────────────────")
    r = await tool("get_edges", filename=FN, attribute="interaction", operator="eq", value="binds")
    check("'binds' edges > 0", r["count"] > 0, str(r["count"]))

    print("\n── set_node_attribute ──────────────────────────────────────────")
    r = await tool("set_node_attribute", filename=FN, node_id=0, attribute="score", value=0.99)
    check("updated node 0", r["updated_node_id"] == 0)
    # verify it stuck
    r = await tool("get_nodes", filename=FN, attribute="score", operator="eq", value=0.99)
    check("value persisted", r["count"] == 1)

    print("\n── add_node ────────────────────────────────────────────────────")
    r = await tool("add_node", filename=FN, attributes={"n": "new_node", "type": "rna"})
    new_node_id = r["added_node_id"]
    check("new node id == 20", new_node_id == 20, str(new_node_id))
    r = await tool("get_network_summary", filename=FN)
    check("node count now 21", r["node_count"] == 21)

    print("\n── add_edge ────────────────────────────────────────────────────")
    r = await tool("add_edge", filename=FN, source=0, target=new_node_id, attributes={"interaction": "test"})
    new_edge_id = r["added_edge_id"]
    check("new edge id == 30", new_edge_id == 30, str(new_edge_id))
    r = await tool("get_network_summary", filename=FN)
    check("edge count now 31", r["edge_count"] == 31)

    print("\n── delete_nodes ────────────────────────────────────────────────")
    r = await tool("delete_nodes", filename=FN, node_ids=[new_node_id])
    check("deleted 1 node", r["deleted_node_count"] == 1)
    check("deleted 1 edge (cascade)", r["deleted_edge_count"] == 1)
    r = await tool("get_network_summary", filename=FN)
    check("back to 20 nodes", r["node_count"] == 20)
    check("back to 30 edges", r["edge_count"] == 30)

    print("\n── filter_network ──────────────────────────────────────────────")
    r = await tool(
        "filter_network",
        filename=FN,
        attribute="type",
        operator="eq",
        value="gene",
        output_filename="genes.cx2",
    )
    check("output stored", r["output_filename"] == "genes.cx2")
    check("10 gene nodes", r["node_count"] == 10, str(r["node_count"]))
    check("genes.cx2 in memory", "genes.cx2" in srv._networks)

    print("\n── list_served_files ───────────────────────────────────────────")
    r = await tool("list_served_files")
    names = [f["filename"] for f in r["served_files"]]
    check("original file listed", FN in names)
    check("filtered file listed", "genes.cx2" in names)

    print("\n── get_url ─────────────────────────────────────────────────────")
    r = await tool("get_url", filename=FN)
    check("local_url correct", f"/{FN}" in r["local_url"])

    print("\n── save_to_disk ────────────────────────────────────────────────")
    out = Path("/tmp/test_output.cx2")
    r = await tool("save_to_disk", filename=FN, output_path=str(out))
    # resolve() handles macOS /tmp → /private/tmp symlink
    check("saved", r["path"] == str(out.resolve()))
    check("file exists", out.exists())
    saved = json.loads(out.read_text())
    check("saved data is valid CX2", isinstance(saved, list))

    print("\n── reload_file ─────────────────────────────────────────────────")
    # Point network back to original file path so reload works
    srv._networks[FN]["path"] = FILE
    r = await tool("reload_file", filename=FN)
    check("reloaded", r["reloaded"] == FN)
    # After reload the score edit should be gone (original file unchanged)
    r = await tool("get_nodes", filename=FN, attribute="score", operator="eq", value=0.99)
    check("edit reverted after reload", r["count"] == 0)

    print("\n── error cases ─────────────────────────────────────────────────")
    r = await tool("get_network_summary", filename="nonexistent.cx2")
    check("missing file → error", "error" in r)
    r = await tool("add_edge", filename=FN, source=999, target=0)
    check("bad source → error", "error" in r)

    print(f"\n\033[32mAll tests passed.\033[0m\n")


if __name__ == "__main__":
    asyncio.run(run())
