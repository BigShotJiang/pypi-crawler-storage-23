# Publishing cx2-mcp to PyPI

---

## Full workflow

### 1. Build
```bash
cd ~/src/cw/cx-mcp
uv build
# creates dist/cx2_mcp-0.1.0.tar.gz and dist/cx2_mcp-0.1.0-py3-none-any.whl
```

### 2. Get a PyPI token
1. Create account at pypi.org
2. Account Settings → API tokens → "Add API token"
3. Scope: "All projects" (for first publish; scope to `cx2-mcp` after first upload)

### 3. Publish
```bash
export UV_PUBLISH_TOKEN="pypi-AgEI..."
uv publish
```

### 4. Verify it works
```bash
uvx cx2-mcp --help
```

### 5. Test in Claude Code
```bash
claude mcp add --scope user cx2-mcp -- uvx cx2-mcp --port 8888
```

---

## For a temporary/exploratory publish — your options

### Option A: TestPyPI (recommended for now)
Completely separate namespace from production PyPI. Safe to publish, experiment, and forget.
```bash
uv publish \
  --publish-url https://test.pypi.org/legacy/ \
  --token "pypi-test-AgEI..."
```
- Free, public, but clearly marked as test
- Users install with: `uvx --index-url https://test.pypi.org/simple/ cx2-mcp`
- **Downside:** `uvx cx2-mcp` won't work without the extra flag — not the clean install story

### Option B: Publish to PyPI, yank if needed
PyPI has a **yank** mechanism (PEP 592):
- Yanked releases are hidden from `pip install cx2-mcp` (resolver skips them)
- But `pip install cx2-mcp==0.1.0` still works (explicit pin)
- **You can yank and un-yank at any time** — non-destructive
- Go to: pypi.org/manage/project/cx2-mcp/releases/ → "Yank release"

**Deletion:** PyPI allows deletion within 72 hours of upload. After 72 hours deletion is locked (PEP 763). Deletion is permanent and breaks pinned installs — yank is almost always better.

### Option C: GitHub Package Registry (private)
Keep it private until ready:
```bash
# publish to GitHub's package registry instead
uv publish --publish-url https://maven.pkg.github.com/...
```
- Requires authentication to install — not the `uvx` one-liner experience

---

## Recommendation for tomorrow's presentation

**Publish to real PyPI before the presentation.** Here's why:
- The install story (`uvx cx2-mcp`) is a key demo moment — it needs to work cleanly
- TestPyPI breaks the one-liner
- If anything goes wrong after, use **yank** — it hides the release without breaking existing users
- Version it `0.1.0` with a clear "experimental" marker in the README/description

Quick checklist before publishing:
- [ ] `uv build` succeeds cleanly
- [ ] `pyproject.toml` has correct name, version, description, and `readme` field
- [ ] Add `license = "MIT"` (or your preferred license) to `pyproject.toml`
- [ ] `uv run cx2-mcp --port 8888` works end-to-end
- [ ] Test `uvx cx2-mcp --help` from a clean shell
