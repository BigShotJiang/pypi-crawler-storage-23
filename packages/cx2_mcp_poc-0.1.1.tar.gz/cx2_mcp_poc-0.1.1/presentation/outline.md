# cx2-mcp Presentation Outline

---

## Title
**File Over App: AI-Native Network Analysis with cx2-mcp**

---

## 1. File Over App (3 min)

*Steph Ango's principle, applied to bioinformatics:*

> "If you want your writing to be readable on computers from the 2060s or 2160s, it's important that your notes can be read on computers from the 1960s."
> — Steph Ango, stephango.com/file-over-app

### The core idea
- Software is **temporary**. Files are **permanent**.
- Ancient artifacts — hieroglyphs, manuscripts, paintings — outlasted the tools that made them because they existed in accessible, open mediums.
- Most digital work today is trapped in cloud services, proprietary formats, and locked databases the user doesn't control.
- **The file is the unit of truth.** The app is just a lens.

### Applied to network biology
- CX2 is an open, portable, JSON-based network format — it's already built on this principle.
- But the tools to work with CX2 have been app-centric: Cytoscape owns the workflow, the user adapts.
- **What if the AI was the app, and the .cx2 file was the citizen?**

---

## 2. The Application Monopoly Problem (2 min)

> *"This application is the only place that can give me what I want — but it means I have to express what I want in Cytoscape's ecosystem. I have to find what I want through the pile of all features. I have to invest time and energy learning a UI. And because there are so many features, there is necessary complexity that cannot be avoided."*

### Why apps accumulate power
- The barrier to managing data + functions was too high for individuals.
- Apps like Cytoscape overcame that barrier by centralizing everything — and in doing so gained leverage over users.
- The game: capture as many users as possible, add as many features as possible, centralize everything.

### The cost
- You learn *their* UI, not your problem.
- Your data is increasingly entangled with their format.
- When the app dies or pivots, your work is at risk.

### The shift happening now
- AI collapses the barrier to entry. You no longer need a centralized app to make data manageable.
- **UI is now generative** — it shows only what you need, right now, expressed in plain language.
- The user manages their own artifacts. The interface is transient. The file persists.

---

## 3. What is cx2-mcp? (3 min)

A thin MCP server that puts the CX2 file back in the user's hands:

1. Loads `.cx2` files into memory, serves them over HTTP with CORS
2. Exposes AI-callable tools for reading and editing the network in place
3. Returns a live Cytoscape Web URL — browser refresh = instant preview
4. Explicit save-to-disk — the file is yours, writes only happen when you ask

**No proprietary lock-in. No cloud dependency. The file stays local.**

**Show diagram: System Overview**

### Install — one command
```bash
claude mcp add --scope user cx2-mcp -- uvx cx2-mcp --port 8888
```
- `uvx` fetches from PyPI — no manual install, no environment setup
- Works in Claude Code, Cursor, any MCP-compatible AI client

---

## 4. Live Demo (5 min)

*A fresh user workflow, start to finish.*

**Step 1 — Load a file**
> "Load ~/Downloads/network.cx2"
→ AI calls `serve_file` → returns Cytoscape Web URL → open in browser

**Step 2 — Inspect**
> "Summarize this network"
→ AI calls `get_network_summary` → node/edge counts, attribute names

**Step 3 — Edit**
> "Set the score of all protein nodes to 1.0"
→ AI calls `get_nodes(type=protein)` → `set_node_attribute` × N

**Step 4 — Preview**
> Refresh browser → edits visible instantly (no save needed)

**Step 5 — Save**
> "Save it back to the original file"
→ AI calls `save_to_disk` → file on disk updated

**Show diagram: Data Flow sequence diagram**

---

## 5. Render Target Routing (3 min)

Not all networks are equal. The AI can route to the right tool:

| Network size | Render target | Mechanism |
|---|---|---|
| Small / medium | Cytoscape Web | `?import=localhost:8888/file.cx2` |
| Large | Cytoscape Desktop | Open file directly / future Desktop MCP |
| Embedded | Cytoscape.js | WebMCP (future) |

### Cytoscape Desktop discussion
- Browsers have memory/rendering limits (~5k–10k nodes practical ceiling)
- For large networks: AI detects size from `get_network_summary` → directs user to Cytoscape Desktop
- **Future — Cytoscape Desktop MCP:** AI issues tool calls directly into the Desktop app
- **Future — WebMCP:** AI calls tools directly into a running Cytoscape.js instance in the browser

**Show diagram: Network Size Routing**

This is exploratory — the key point is the *pattern*:
> **Same AI, same intent, different render targets chosen automatically.**

---

## 6. The Bigger Picture (2 min)

**Show diagram: Full Ecosystem Vision**

| MCP Server | Role |
|---|---|
| **cx2-mcp** (this) | Local file layer — load, edit, serve |
| **NDEx MCP** | Cloud layer — download/upload CX, auth |
| **Cytoscape Desktop MCP** | Desktop render target (future) |
| **WebMCP** | Browser render target (future) |

The AI orchestrates across all of them:
- Fetch from NDEx → edit locally → preview in Web → save back to NDEx
- All expressible in plain language, all reproducible as tool call logs

---

## 7. Why This Matters (1 min)

Returning to **file over app**:

- The `.cx2` file outlasts any tool in this stack — Cytoscape Web, Claude Code, even cx2-mcp itself.
- Every edit is a logged MCP tool call — auditable, reproducible, scriptable.
- No vendor lock-in: swap the AI, swap the render target, the file stays the same.
- Any researcher can manipulate networks with plain English today, with no Cytoscape expertise.

> *"If the app dies tomorrow, the file survives."*

---

## Discussion Points

1. What's the right size threshold for Web vs Desktop routing?
2. Should cx2-mcp validate CX2 on load and reject invalid files with clear errors?
3. NDEx MCP integration: fetch by UUID directly into the local server?
4. WebMCP: what would direct tool calls into a live Cytoscape.js instance look like?
5. Cytoscape Desktop MCP: what's the minimal viable interface?
6. Multi-user / collaborative editing — shared HTTP server + concurrent AI edits?
7. **Multi-session port conflict (known limitation)**

MCP uses a `stdio` transport model: each Claude Code terminal session spawns its own cx2-mcp subprocess. This means:

- **1 session = 1 process = 1 in-memory `_networks` store**
- Networks loaded in session A are invisible to session B
- Both sessions try to bind the HTTP server to the same port (e.g. 8888)
- The second process silently fails to serve files over HTTP — its MCP tools work, but the Cytoscape Web URLs it returns are broken

**Current mitigation:** auto-increment the port at startup (8888 → 8889 → …) so each session gets its own self-contained HTTP server. Networks remain session-scoped and ephemeral.

**Longer-term question:** If cross-session sharing or persistence matters, a shared external HTTP server (separate from the MCP process) would be needed — but that significantly increases operational complexity. For a local research tool, session-scoped ephemerality is probably acceptable.

### ⚠️ Funding / Metrics tension (important)

Cytoscape Web and Cytoscape Desktop justify funding in part through **user metrics** — active users, sessions, downloads. This approach could work against that:

- If users interact with CX2 files via AI + cx2-mcp rather than opening Cytoscape directly, **direct usage metrics drop** — even if the underlying tools (Cytoscape Web for rendering, NDEx for storage) are still being used
- A successful adoption of this workflow may look like *declining engagement* to a grant reviewer looking at Cytoscape Web session counts
- This is a **real incentive misalignment** that needs to be surfaced, not buried

**Possible framings to discuss:**
- Redefine the metric: count MCP tool calls, NDEx API calls, CX2 files touched — not just browser sessions
- Position cx2-mcp as an *extension* of the Cytoscape ecosystem, not a replacement — the render targets are still Cytoscape Web/Desktop
- Consider whether this is better positioned as a research prototype / exploratory tool that doesn't compete with core funding metrics
- Explore whether funding bodies would respond positively to "AI-accessible bioinformatics infrastructure" as a new category
- Acknowledge the tension openly in the presentation — it signals maturity and builds trust with the audience

---

## Appendix: Excalidraw Diagram Cleanup Notes

Your existing diagram has two strong conceptual layers — separate them into distinct slides:

**Layer 1 — Cytoscape Web internals**
(NDEx API → CX2 → Models → IndexedDB → Cytoscape.js → React)
→ Use as "what Cytoscape Web already does" — background/context slide

**Layer 2 — AI orchestration layer**
(User → AI → MCP servers → render targets)
→ This is the new thing — give it a dedicated full-width diagram

**Philosophy text** ("Data is King", "Application Monopoly")
→ Move these to the opening slides — they are the *why*, not the *what*

Suggested cleanup:
- Split into 3 focused diagrams (Web internals / AI layer / size routing)
- Remove duplicate Cytoscape Web block (appears twice in current file)
- Make size-based routing more visually prominent
- Add explicit `cx2-mcp` label to the AI layer diagram
- Add "file over app" as a framing caption on the overall architecture diagram
