# CX2 as the File in "File Over App"

---

## The argument

The "file over app" principle asks: *what is the durable unit?*

For network biology, I argue that unit is **CX2** — and that most of the complexity users
encounter in Cytoscape Desktop, Cytoscape Web, and NDEx is the result of each app
independently reinventing a solution to a problem that a good file format already solves.

---

## 1. The fragmentation: each app invented its own abstraction

Every tool in the ecosystem built its own layer for managing networks:

**Cytoscape Desktop**
- **Session** (`.cys`) — a binary archive of your entire workspace: all open networks,
  visual styles, table data, layout, window state, plugin state. Monolithic and opaque.
- **Collection** — a grouping of related networks linked by a shared node attribute
  (`shared name`). Exists only inside a live Cytoscape session; has no file form of its own.
- **Network** — the individual unit, but only meaningful inside a session or collection.

**Cytoscape Web**
- **Local browser cache** — networks stored in IndexedDB inside the browser.
  Ephemeral: clearing your browser wipes your work.
- **NDEx account** — 10 GB of personal cloud storage; networks are private by default,
  shareable on demand. Tied to an account, not a file.
- **NDEx groups** — a collaboration layer for sharing networks across users.

These are all attempts to answer the same question: *how does a user hold onto and
organize their networks?* But they answer it at the **app layer**, so the abstractions
don't transfer. A Cytoscape session means nothing in Cytoscape Web. Your NDEx account is
tied to a login. Your browser cache belongs to the browser. None of it is a file you can
put in a folder, back up, version-control, or hand to a colleague.

### The version control problem

None of these abstractions have a credible answer to version control:

- A `.cys` session is a binary blob — `git diff` is useless on it.
- A browser IndexedDB cache has no history at all.
- NDEx has no native versioning; overwriting a network is destructive by default.
- Collections have no snapshot or diff mechanism.

CX2 is a plain JSON file. That means `git` works on it out of the box:

```bash
git init networks/
git add my-network.cx2
git commit -m "add TP53 node, update edge weights"
git diff HEAD~1 my-network.cx2   # see exactly what changed
```

You get full history, branching, diffing, and collaboration for free — using tools
researchers already know. No app supports this. The file format does, inherently.

---

## 2. The honest criticism — up front

CX2 has a real weakness as a user-facing file format: **it's not designed to be edited
by hand.** The format was built for streaming and high-performance network transfer, and
it shows:

- Attributes live inside nested `"v"` dicts with shorthand keys (`"n"` for name, `"i"` for interaction)
- Node and edge IDs must stay consistent across aspects — break one reference and the
  network is silently invalid
- Visual style is a deeply nested structure with non-obvious defaults
- Attribute type declarations in `attributeDeclarations` are implicit contracts; violate
  them and renderers behave unpredictably

Manually editing CX2 requires implicit format knowledge that took time to acquire.
**This is a real barrier — and it's worth naming directly.**

---

## 3. The reframe: the AI is the format proxy

The criticism dissolves when the user never touches the raw JSON.

```
User:  "Set all protein node colors to blue and increase their size to 60"

AI:    → get_nodes(type=protein)
       → set_node_attribute(id, color, #0000FF) × 10
       → set_node_attribute(id, size, 60) × 10
```

The AI carries the implicit format knowledge. The user expresses intent. The file stays
valid. This is not a workaround — it's the intended interface.

**The CX2 format's opacity becomes irrelevant when you have a competent proxy.**

### CX2 is also a file users can script directly

Beyond AI, CX2 is a plain JSON file — which means a researcher who knows a little Python
can write scripts against it today, without any app running. This is already more than
`.cys` sessions or IndexedDB caches offer.

But there's a gap: **no clean, purpose-built Python library for local CX2 manipulation.**

Two existing packages partially address this but from a different architectural starting point:

**py4cytoscape** — scripts Cytoscape Desktop via a local REST API (CyREST):
```python
import py4cytoscape as cy
cy.add_nodes(['TP53', 'MDM2'])
cy.set_node_color_default('#FF0000')
```
*Requires Cytoscape Desktop to be actively running on your machine.*
This is not file manipulation — it's **remote-controlling an app**. If Cytoscape isn't
open, none of it works. The file is a side effect of the app; the app is the primary citizen.

**ndex2** — primarily a client for the NDEx server, with local CX2 manipulation as a
secondary capability:
```python
from ndex2.cx2 import CX2Network
net = CX2Network()
node_id = net.add_node(attributes={'name': 'TP53'})
net.add_edge(source=node_id, target=other_id, attributes={'interaction': 'inhibits'})
```
ndex2 does have a `CX2Network` class with `add_node()` / `add_edge()`. But it exists
primarily to shuttle networks to and from the NDEx cloud — local manipulation is
incidental to its design. The server is the assumed destination; the file is a transfer vehicle.

**What's missing: a library where the file is the primary citizen**

```python
import cxpy

cx = cxpy.load('my-network.cx2')

cx.add_node('TP53', type='protein', score=0.9)
cx.add_edge('TP53', 'MDM2', interaction='inhibits')
cx.set_default_style('nodeColor', 'blue')
cx.set_default_style('nodeSize', 60)
cx.filter_nodes(lambda n: n['score'] > 0.5)

cx.save('my-network.cx2')
```

No Cytoscape running. No NDEx account. No server. Just:
**open file → manipulate → save file.**

This would complete a three-tier access stack:

| User type | Interface |
|---|---|
| Researcher | Natural language via AI (cx2-mcp) |
| Power user / scripter | Python library (`cx.add_node(...)`) |
| Pipeline / system | Raw CX2 JSON directly |

The key architectural contrast:

| | py4cytoscape | ndex2 | hypothetical cxpy |
|---|---|---|---|
| Primary citizen | Cytoscape Desktop app | NDEx server | The file |
| Requires running app | ✅ always | ❌ | ❌ |
| Requires server/account | ❌ | for most workflows | ❌ |
| Works offline | ❌ | partially | ✅ |
| File stays yours | side effect | upload target | first-class output |
| Aligns with "file over app" | ❌ | partially | ✅ |

---

## 4. Concrete contrast

**The raw CX2 you'd have to edit manually:**
```json
{
  "nodes": [
    {
      "id": 0,
      "v": {
        "n": "TP53",
        "type": "protein",
        "score": 0.42
      }
    }
  ]
}
```
*...plus a matching entry in `attributeDeclarations`, ensuring type consistency, keeping
the `idCounter` in `metaData` in sync, not breaking any edge references.*

**What the user actually says:**
> "Add a protein node called TP53 with a score of 0.42"

The gap between those two is the entire value proposition.

---

## 5. CX2 was not designed for this — and that's fine

CX2 was designed for **streaming**: efficiently transferring large networks between
systems (Cytoscape Desktop ↔ NDEx ↔ Cytoscape Web) without loading the entire graph
into memory at once. The aspect-array format reflects that — each aspect is a
self-contained chunk that can be streamed and processed independently.

The "file as citizen" use case — a local, user-owned, AI-manipulable file — was not the
original intent. The format was designed for systems talking to systems.

But the structure happens to fit. It's JSON (AI-readable), it's open (no proprietary
encoding), it's already the common interchange format across the entire ecosystem.
**We are repurposing a well-designed technical format for a new purpose it happens to
accommodate — and we should say so explicitly.**

This framing pre-empts the obvious pushback from anyone who knows CX2's history:
*"Yes, we know. That's exactly why this is interesting."*

---

## Summary: why CX2 is the right file

| Property | CX2 | Session (.cys) | Browser cache | NDEx account |
|---|---|---|---|---|
| Open format | ✅ | ❌ binary | ❌ IndexedDB | ❌ cloud/login |
| Portable | ✅ | partial | ❌ | ❌ |
| AI-readable | ✅ | ❌ | ❌ | via API |
| Works in CyDesktop | ✅ | ✅ | ❌ | via plugin |
| Works in CyWeb | ✅ | ❌ | ❌ | ✅ |
| Works offline | ✅ | ✅ | partial | ❌ |
| User-owned | ✅ | ✅ | ❌ | ❌ |
| Human-editable | ⚠️ hard | ❌ | ❌ | ❌ |

CX2 wins on every axis that matters for longevity and ownership.
Its one weakness — manual editability — is exactly what AI solves.
