# cx2-mcp Architecture Diagrams

---

## 1. System Overview

```mermaid
graph TD
    User["👤 User"]
    CC["Claude Code\n(AI session)"]
    MCP["cx2-mcp\nMCP Server"]
    HTTP["HTTP Server\nlocalhost:8888"]
    MEM["In-Memory Store\n_networks dict"]
    DISK["Local Disk\n.cx2 files"]
    CYW["Cytoscape Web\nweb.cytoscape.org"]
    Browser["🌐 Browser"]

    User -->|"natural language"| CC
    CC -->|"MCP tool calls"| MCP
    MCP -->|"reads on load\nwrites on save"| DISK
    MCP -->|"mutates"| MEM
    MEM -->|"serves JSON"| HTTP
    HTTP -->|"?import=localhost:8888/file.cx2"| CYW
    CYW --> Browser
    Browser -->|"refresh = live update"| CYW
    User --> Browser
```

---

## 2. Data Flow: Load → Edit → View → Save

```mermaid
sequenceDiagram
    participant U as User
    participant AI as Claude Code
    participant MCP as cx2-mcp
    participant HTTP as HTTP :8888
    participant CYW as Cytoscape Web
    participant Disk as Local Disk

    U->>AI: "load ~/network.cx2"
    AI->>MCP: serve_file(path)
    MCP->>Disk: read file
    Disk-->>MCP: CX2 JSON
    MCP-->>AI: local_url + cytoscape_web_url
    AI-->>U: "Open https://web.cytoscape.org/?import=..."
    U->>CYW: opens URL in browser
    CYW->>HTTP: GET /network.cx2
    HTTP-->>CYW: CX2 JSON (from memory)

    U->>AI: "set all protein node scores to 1.0"
    AI->>MCP: get_nodes(filter type=protein)
    MCP-->>AI: [node list]
    AI->>MCP: set_node_attribute(id, score, 1.0) × N
    MCP-->>AI: updated

    U->>CYW: refresh browser
    CYW->>HTTP: GET /network.cx2
    HTTP-->>CYW: updated CX2 (edits visible)

    U->>AI: "save it"
    AI->>MCP: save_to_disk(filename)
    MCP->>Disk: write file
    MCP-->>AI: saved
```

---

## 3. MCP Tools Map

```mermaid
graph LR
    subgraph Serving
        serve_file
        get_url
        list_served_files
        reload_file
    end

    subgraph Inspection
        get_network_summary
        get_nodes
        get_edges
        get_visual_properties
    end

    subgraph Editing
        set_node_attribute
        set_edge_attribute
        add_node
        add_edge
        delete_nodes
        filter_network
        apply_visual_style
    end

    subgraph Persistence
        save_to_disk
    end
```

---

## 4. Full Ecosystem Vision (from Excalidraw)

```mermaid
graph TD
    User["👤 User"]
    AI["AI Agent\nClaude Code / Gemini / ChatGPT"]

    subgraph MCP Servers
        NDExMCP["NDEx MCP\ndownload/upload CX, auth"]
        LocalCX["Local CX Server\ncx2-mcp"]
        CyDeskMCP["Cytoscape Desktop MCP\n(future)"]
        WebMCP["WebMCP\n(future)"]
    end

    subgraph Render Targets
        CYW["Cytoscape Web\n✅ medium networks"]
        CyDesk["Cytoscape Desktop\n✅ large networks"]
        CyJS["Cytoscape.js\n(embedded)"]
    end

    NDEx["NDEx Server"]
    Scripts["User Scripts\n& Research"]

    User -->|"intention"| AI
    AI --> NDExMCP --> NDEx
    AI --> LocalCX -->|"import URL"| CYW
    AI --> CyDeskMCP --> CyDesk
    AI --> WebMCP --> CyJS
    Scripts --> LocalCX
    NDExMCP -->|"fetch CX"| LocalCX
```

---

## 5. Network Size Routing

```mermaid
flowchart TD
    Load["Load CX2 file"]
    Size{Network size?}
    Small["Small / Medium\n< ~5k nodes"]
    Large["Large\n> ~5k nodes"]
    CYW["→ Cytoscape Web\nimport URL"]
    CyDesk["→ Cytoscape Desktop\n(open locally)"]
    Note["Future: WebMCP\ndirect tool calls\ninto browser"]

    Load --> Size
    Size -->|browser-friendly| Small --> CYW
    Size -->|too large for browser| Large --> CyDesk
    CYW -.->|roadmap| Note
```
