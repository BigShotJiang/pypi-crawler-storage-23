# cx2-mcp

MCP server for AI-powered CX2 network manipulation with live [Cytoscape Web](https://web.cytoscape.org) preview.

Load local `.cx2` files, manipulate them with natural language via Claude Code or any MCP-compatible AI, and preview changes instantly in your browser.

## Install

```bash
claude mcp add --scope user cx2-mcp -- uvx --from cx2-mcp-poc cx2-mcp --port 8888
```

Then start a new Claude Code session and say: *"Load ~/my-network.cx2"*

## What it does

- Serves local CX2 files over HTTP with CORS — browser-accessible instantly
- Exposes 16 MCP tools for reading, editing, filtering, and saving networks
- Returns a Cytoscape Web import URL; refresh your browser to see AI edits live
- Writes to disk only when explicitly asked — your file stays yours

## Tools

| Category | Tools |
|---|---|
| Serving | `serve_file`, `get_url`, `list_served_files`, `reload_file` |
| Inspection | `get_network_summary`, `get_nodes`, `get_edges`, `get_visual_properties` |
| Editing | `set_node_attribute`, `set_edge_attribute`, `add_node`, `add_edge`, `delete_nodes`, `filter_network`, `apply_visual_style` |
| Persistence | `save_to_disk` |

## Requirements

- Python 3.11+
- `uv` or `uvx` ([install](https://docs.astral.sh/uv/getting-started/installation/))
- Claude Code or any MCP-compatible AI client
