"""
CX2 MCP Server
Serves local CX2 files over HTTP (CORS-enabled) and exposes MCP tools
for loading, inspecting, editing, and previewing networks in Cytoscape Web.
"""

import argparse
import asyncio
import copy
import json
import socket
import threading
from pathlib import Path
from typing import Any, Optional

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from mcp import types
from mcp.server import Server
from mcp.server.stdio import stdio_server

# ── Configuration ─────────────────────────────────────────────────────────────

DEFAULT_PORT = 8888
CYTOSCAPE_WEB_BASE = "https://web.cytoscape.org"

# ── In-memory store ───────────────────────────────────────────────────────────
# Maps filename → { "path": original Path | None, "data": parsed CX2 list }

_networks: dict[str, dict] = {}
_server_port: int = DEFAULT_PORT
_http_thread: Optional[threading.Thread] = None

# ── FastAPI HTTP server (CORS-enabled) ────────────────────────────────────────

app = FastAPI(title="CX2 Local File Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/")
def index():
    return {"served_files": list(_networks.keys())}


@app.get("/{filename}")
def serve_cx2(filename: str):
    if filename not in _networks:
        return JSONResponse(status_code=404, content={"error": f"'{filename}' not found"})
    return JSONResponse(content=_networks[filename]["data"])


def _find_free_port(start: int, max_tries: int = 20) -> int:
    """Return the first free TCP port starting from `start`."""
    for port in range(start, start + max_tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("", port))
                return port
            except OSError:
                continue
    raise RuntimeError(
        f"Could not find a free port in range {start}–{start + max_tries - 1}. "
        "Use --port to specify a different base port."
    )


def _start_http_server(port: int):
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")


def _ensure_http_server(port: int = DEFAULT_PORT):
    global _http_thread, _server_port
    if _http_thread and _http_thread.is_alive():
        return
    actual_port = _find_free_port(port)
    if actual_port != port:
        import sys
        print(
            f"[cx2-mcp] Port {port} in use — binding to {actual_port} instead.",
            file=sys.stderr,
        )
    _server_port = actual_port
    _http_thread = threading.Thread(target=_start_http_server, args=(actual_port,), daemon=True)
    _http_thread.start()


# ── CX2 helpers ───────────────────────────────────────────────────────────────

def _load_cx2(path: Path) -> list:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _get_aspect(cx2: list, aspect_name: str) -> Optional[list]:
    for item in cx2:
        if isinstance(item, dict) and aspect_name in item:
            return item[aspect_name]
    return None


def _set_aspect(cx2: list, aspect_name: str, value: list) -> None:
    """Replace or append an aspect in a CX2 list."""
    for item in cx2:
        if isinstance(item, dict) and aspect_name in item:
            item[aspect_name] = value
            return
    cx2.append({aspect_name: value})


def _summarize(cx2: list, filename: str) -> dict:
    nodes = _get_aspect(cx2, "nodes") or []
    edges = _get_aspect(cx2, "edges") or []
    net_attrs = _get_aspect(cx2, "networkAttributes") or []
    node_attr_keys: set[str] = set()
    for n in nodes:
        node_attr_keys.update((n.get("v") or {}).keys())
    edge_attr_keys: set[str] = set()
    for e in edges:
        edge_attr_keys.update((e.get("v") or {}).keys())
    return {
        "filename": filename,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "node_attributes": sorted(node_attr_keys),
        "edge_attributes": sorted(edge_attr_keys),
        "network_attributes": {a["n"]: a["v"] for a in net_attrs if "n" in a and "v" in a},
    }


def _next_id(items: list[dict]) -> int:
    """Return max existing id + 1, or 0 if the list is empty."""
    if not items:
        return 0
    return max(item.get("id", 0) for item in items) + 1


def _deep_merge(base: Any, patch: Any) -> Any:
    """Recursively merge patch into base (dicts merged, other types replaced)."""
    if isinstance(base, dict) and isinstance(patch, dict):
        result = dict(base)
        for k, v in patch.items():
            result[k] = _deep_merge(base.get(k), v)
        return result
    return patch


def _match_filter(value: Any, operator: str, target: Any) -> bool:
    ops = {
        "eq": lambda a, b: a == b,
        "ne": lambda a, b: a != b,
        "gt": lambda a, b: a > b,
        "gte": lambda a, b: a >= b,
        "lt": lambda a, b: a < b,
        "lte": lambda a, b: a <= b,
        "contains": lambda a, b: b in str(a),
    }
    fn = ops.get(operator)
    if fn is None:
        raise ValueError(f"Unknown operator '{operator}'. Use: {list(ops)}")
    try:
        return fn(value, target)
    except TypeError:
        return False


# ── MCP Server ────────────────────────────────────────────────────────────────

mcp = Server("cx2-mcp")


# ── Tool definitions ──────────────────────────────────────────────────────────

_TOOLS: list[types.Tool] = [
    # Phase 1 — serving & inspection
    types.Tool(
        name="serve_file",
        description=(
            "Load a local CX2 file into memory and serve it over HTTP. "
            "Returns the localhost URL and a Cytoscape Web import URL you can open in a browser."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute or relative path to the .cx2 file"},
            },
            "required": ["path"],
        },
    ),
    types.Tool(
        name="get_url",
        description="Get the localhost URL and Cytoscape Web import URL for a loaded file.",
        inputSchema={
            "type": "object",
            "properties": {"filename": {"type": "string"}},
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="list_served_files",
        description="List all CX2 files currently loaded in memory.",
        inputSchema={"type": "object", "properties": {}},
    ),
    types.Tool(
        name="get_network_summary",
        description="Return node/edge counts, attribute names, and network metadata for a loaded file.",
        inputSchema={
            "type": "object",
            "properties": {"filename": {"type": "string"}},
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="reload_file",
        description="Re-read a CX2 file from disk, refreshing the in-memory copy.",
        inputSchema={
            "type": "object",
            "properties": {"filename": {"type": "string"}},
            "required": ["filename"],
        },
    ),
    # Phase 2 — editing
    types.Tool(
        name="get_nodes",
        description=(
            "Return nodes from a loaded network, optionally filtered by an attribute value. "
            "operator: eq | ne | gt | gte | lt | lte | contains"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "attribute": {"type": "string", "description": "Attribute name to filter on (optional)"},
                "operator": {"type": "string", "description": "Comparison operator (default: eq)"},
                "value": {"description": "Value to compare against"},
            },
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="get_edges",
        description=(
            "Return edges from a loaded network, optionally filtered by an attribute value. "
            "operator: eq | ne | gt | gte | lt | lte | contains"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "attribute": {"type": "string", "description": "Attribute name to filter on (optional)"},
                "operator": {"type": "string", "description": "Comparison operator (default: eq)"},
                "value": {"description": "Value to compare against"},
            },
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="set_node_attribute",
        description="Set or update a single attribute on a node by its integer ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "node_id": {"type": "integer"},
                "attribute": {"type": "string"},
                "value": {},
            },
            "required": ["filename", "node_id", "attribute", "value"],
        },
    ),
    types.Tool(
        name="set_edge_attribute",
        description="Set or update a single attribute on an edge by its integer ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "edge_id": {"type": "integer"},
                "attribute": {"type": "string"},
                "value": {},
            },
            "required": ["filename", "edge_id", "attribute", "value"],
        },
    ),
    types.Tool(
        name="add_node",
        description="Add a new node to a loaded network. Returns the new node's ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "attributes": {
                    "type": "object",
                    "description": "Key-value pairs for the node's 'v' dict",
                },
            },
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="add_edge",
        description="Add a new edge between two existing node IDs. Returns the new edge's ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "source": {"type": "integer", "description": "Source node ID"},
                "target": {"type": "integer", "description": "Target node ID"},
                "attributes": {
                    "type": "object",
                    "description": "Key-value pairs for the edge's 'v' dict",
                },
            },
            "required": ["filename", "source", "target"],
        },
    ),
    types.Tool(
        name="delete_nodes",
        description="Remove nodes by ID and all edges that connect to them.",
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "node_ids": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["filename", "node_ids"],
        },
    ),
    types.Tool(
        name="filter_network",
        description=(
            "Create a new in-memory network containing only nodes whose attribute passes the filter. "
            "Edges between surviving nodes are preserved. "
            "operator: eq | ne | gt | gte | lt | lte | contains"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "attribute": {"type": "string"},
                "operator": {"type": "string"},
                "value": {},
                "output_filename": {
                    "type": "string",
                    "description": "Name for the new in-memory entry (e.g. 'filtered.cx2')",
                },
            },
            "required": ["filename", "attribute", "operator", "value", "output_filename"],
        },
    ),
    types.Tool(
        name="apply_visual_style",
        description=(
            "Deep-merge a style patch into the visualProperties aspect. "
            "Only the keys present in style_patch are modified; everything else is preserved."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "style_patch": {
                    "type": "object",
                    "description": "Partial visualProperties object to merge in",
                },
            },
            "required": ["filename", "style_patch"],
        },
    ),
    types.Tool(
        name="get_visual_properties",
        description="Return the current visualProperties aspect for a loaded network.",
        inputSchema={
            "type": "object",
            "properties": {"filename": {"type": "string"}},
            "required": ["filename"],
        },
    ),
    types.Tool(
        name="save_to_disk",
        description=(
            "Write the in-memory CX2 network to disk. "
            "If output_path is omitted the file is written back to its original source path."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "filename": {"type": "string"},
                "output_path": {
                    "type": "string",
                    "description": "Optional destination path; defaults to the original source path",
                },
            },
            "required": ["filename"],
        },
    ),
]


@mcp.list_tools()
async def list_tools() -> list[types.Tool]:
    return _TOOLS


# ── Tool dispatch ─────────────────────────────────────────────────────────────

@mcp.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    def ok(data: Any) -> list[types.TextContent]:
        return [types.TextContent(type="text", text=json.dumps(data, indent=2))]

    def err(msg: str) -> list[types.TextContent]:
        return [types.TextContent(type="text", text=json.dumps({"error": msg}))]

    # ── Phase 1 tools ─────────────────────────────────────────────────────────

    if name == "serve_file":
        path = Path(arguments["path"]).expanduser().resolve()
        if not path.exists():
            return err(f"File not found: {path}")
        if path.suffix.lower() not in (".cx2", ".json"):
            return err("File must be .cx2 or .json")
        try:
            data = _load_cx2(path)
        except json.JSONDecodeError as e:
            return err(f"Invalid JSON: {e}")
        filename = path.name
        _networks[filename] = {"path": path, "data": data}
        local_url = f"http://localhost:{_server_port}/{filename}"
        cyw_url = f"{CYTOSCAPE_WEB_BASE}/?import={local_url}"
        return ok({"loaded": filename, "local_url": local_url, "cytoscape_web_url": cyw_url})

    elif name == "get_url":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded. Use serve_file first.")
        local_url = f"http://localhost:{_server_port}/{fn}"
        return ok({"local_url": local_url, "cytoscape_web_url": f"{CYTOSCAPE_WEB_BASE}/?import={local_url}"})

    elif name == "list_served_files":
        return ok({
            "served_files": [
                {
                    "filename": fn,
                    "source_path": str(m["path"]) if m["path"] else None,
                    "local_url": f"http://localhost:{_server_port}/{fn}",
                }
                for fn, m in _networks.items()
            ],
            "port": _server_port,
        })

    elif name == "get_network_summary":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        return ok(_summarize(_networks[fn]["data"], fn))

    elif name == "reload_file":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        src = _networks[fn]["path"]
        if src is None:
            return err(f"'{fn}' has no source path (it was created in-memory).")
        try:
            _networks[fn]["data"] = _load_cx2(src)
        except json.JSONDecodeError as e:
            return err(f"Invalid JSON after reload: {e}")
        return ok({"reloaded": fn})

    # ── Phase 2 tools ─────────────────────────────────────────────────────────

    elif name == "get_nodes":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        nodes = list(_get_aspect(_networks[fn]["data"], "nodes") or [])
        attribute = arguments.get("attribute")
        if attribute is not None:
            operator = arguments.get("operator", "eq")
            target = arguments.get("value")
            try:
                nodes = [n for n in nodes if _match_filter((n.get("v") or {}).get(attribute), operator, target)]
            except ValueError as e:
                return err(str(e))
        return ok({"filename": fn, "count": len(nodes), "nodes": nodes})

    elif name == "get_edges":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        edges = list(_get_aspect(_networks[fn]["data"], "edges") or [])
        attribute = arguments.get("attribute")
        if attribute is not None:
            operator = arguments.get("operator", "eq")
            target = arguments.get("value")
            try:
                edges = [e for e in edges if _match_filter((e.get("v") or {}).get(attribute), operator, target)]
            except ValueError as e:
                return err(str(e))
        return ok({"filename": fn, "count": len(edges), "edges": edges})

    elif name == "set_node_attribute":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        node_id = arguments["node_id"]
        attr = arguments["attribute"]
        value = arguments["value"]
        nodes = _get_aspect(_networks[fn]["data"], "nodes") or []
        for node in nodes:
            if node.get("id") == node_id:
                if "v" not in node or node["v"] is None:
                    node["v"] = {}
                node["v"][attr] = value
                return ok({"updated_node_id": node_id, "attribute": attr, "value": value})
        return err(f"Node {node_id} not found in '{fn}'.")

    elif name == "set_edge_attribute":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        edge_id = arguments["edge_id"]
        attr = arguments["attribute"]
        value = arguments["value"]
        edges = _get_aspect(_networks[fn]["data"], "edges") or []
        for edge in edges:
            if edge.get("id") == edge_id:
                if "v" not in edge or edge["v"] is None:
                    edge["v"] = {}
                edge["v"][attr] = value
                return ok({"updated_edge_id": edge_id, "attribute": attr, "value": value})
        return err(f"Edge {edge_id} not found in '{fn}'.")

    elif name == "add_node":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        cx2 = _networks[fn]["data"]
        nodes = _get_aspect(cx2, "nodes")
        if nodes is None:
            nodes = []
            _set_aspect(cx2, "nodes", nodes)
        new_id = _next_id(nodes)
        new_node: dict[str, Any] = {"id": new_id}
        attrs = arguments.get("attributes") or {}
        if attrs:
            new_node["v"] = attrs
        nodes.append(new_node)
        return ok({"added_node_id": new_id, "node": new_node})

    elif name == "add_edge":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        cx2 = _networks[fn]["data"]
        source = arguments["source"]
        target = arguments["target"]
        # Validate source/target exist
        node_ids = {n.get("id") for n in (_get_aspect(cx2, "nodes") or [])}
        if source not in node_ids:
            return err(f"Source node {source} does not exist in '{fn}'.")
        if target not in node_ids:
            return err(f"Target node {target} does not exist in '{fn}'.")
        edges = _get_aspect(cx2, "edges")
        if edges is None:
            edges = []
            _set_aspect(cx2, "edges", edges)
        new_id = _next_id(edges)
        new_edge: dict[str, Any] = {"id": new_id, "s": source, "t": target}
        attrs = arguments.get("attributes") or {}
        if attrs:
            new_edge["v"] = attrs
        edges.append(new_edge)
        return ok({"added_edge_id": new_id, "edge": new_edge})

    elif name == "delete_nodes":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        cx2 = _networks[fn]["data"]
        ids_to_delete = set(arguments["node_ids"])
        nodes = _get_aspect(cx2, "nodes") or []
        edges = _get_aspect(cx2, "edges") or []
        surviving_nodes = [n for n in nodes if n.get("id") not in ids_to_delete]
        surviving_edges = [e for e in edges if e.get("s") not in ids_to_delete and e.get("t") not in ids_to_delete]
        _set_aspect(cx2, "nodes", surviving_nodes)
        _set_aspect(cx2, "edges", surviving_edges)
        return ok({
            "deleted_node_count": len(nodes) - len(surviving_nodes),
            "deleted_edge_count": len(edges) - len(surviving_edges),
            "remaining_nodes": len(surviving_nodes),
            "remaining_edges": len(surviving_edges),
        })

    elif name == "filter_network":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        attribute = arguments["attribute"]
        operator = arguments["operator"]
        target = arguments["value"]
        output_fn = arguments["output_filename"]
        cx2 = _networks[fn]["data"]
        try:
            surviving_nodes = [
                n for n in (_get_aspect(cx2, "nodes") or [])
                if _match_filter((n.get("v") or {}).get(attribute), operator, target)
            ]
        except ValueError as e:
            return err(str(e))
        surviving_ids = {n.get("id") for n in surviving_nodes}
        surviving_edges = [
            e for e in (_get_aspect(cx2, "edges") or [])
            if e.get("s") in surviving_ids and e.get("t") in surviving_ids
        ]
        # Build new CX2 — copy all non-node/edge aspects, replace nodes/edges
        new_cx2 = []
        for item in cx2:
            if not isinstance(item, dict):
                new_cx2.append(item)
                continue
            key = next(iter(item))
            if key == "nodes":
                new_cx2.append({"nodes": copy.deepcopy(surviving_nodes)})
            elif key == "edges":
                new_cx2.append({"edges": copy.deepcopy(surviving_edges)})
            else:
                new_cx2.append(copy.deepcopy(item))
        _networks[output_fn] = {"path": None, "data": new_cx2}
        local_url = f"http://localhost:{_server_port}/{output_fn}"
        return ok({
            "output_filename": output_fn,
            "node_count": len(surviving_nodes),
            "edge_count": len(surviving_edges),
            "local_url": local_url,
            "cytoscape_web_url": f"{CYTOSCAPE_WEB_BASE}/?import={local_url}",
        })

    elif name == "get_visual_properties":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        vp = _get_aspect(_networks[fn]["data"], "visualProperties")
        return ok({"filename": fn, "visualProperties": vp})

    elif name == "apply_visual_style":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        cx2 = _networks[fn]["data"]
        patch = arguments["style_patch"]
        vp = _get_aspect(cx2, "visualProperties")
        if vp is None:
            # No existing visualProperties; create from patch
            _set_aspect(cx2, "visualProperties", [patch] if not isinstance(patch, list) else patch)
        else:
            # vp is a list of style objects; merge patch into first element
            if len(vp) == 0:
                vp.append(patch)
            else:
                vp[0] = _deep_merge(vp[0], patch)
        return ok({"filename": fn, "applied_patch": patch})

    elif name == "save_to_disk":
        fn = arguments["filename"]
        if fn not in _networks:
            return err(f"'{fn}' not loaded.")
        raw_output = arguments.get("output_path")
        if raw_output:
            dest = Path(raw_output).expanduser().resolve()
        else:
            src = _networks[fn]["path"]
            if src is None:
                return err(f"'{fn}' has no source path. Provide output_path explicitly.")
            dest = src
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "w", encoding="utf-8") as f:
            json.dump(_networks[fn]["data"], f, indent=2)
        # Update stored path if writing to a new location
        _networks[fn]["path"] = dest
        return ok({"saved": fn, "path": str(dest)})

    return err(f"Unknown tool: {name}")


# ── Entrypoints ───────────────────────────────────────────────────────────────

async def main(port: int = DEFAULT_PORT):
    global _server_port
    _server_port = port
    _ensure_http_server(port)  # start HTTP server before MCP handshake
    async with stdio_server() as (r, w):
        await mcp.run(r, w, mcp.create_initialization_options())


def cli_main():
    parser = argparse.ArgumentParser(description="CX2 MCP Server")
    parser.add_argument(
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"HTTP port for the local CX2 file server (default: {DEFAULT_PORT})",
    )
    args = parser.parse_args()
    asyncio.run(main(port=args.port))


if __name__ == "__main__":
    cli_main()
