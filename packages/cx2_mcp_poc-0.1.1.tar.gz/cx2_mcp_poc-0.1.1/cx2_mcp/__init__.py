"""cx2-mcp: MCP server for manipulating CX2 network files with live Cytoscape Web preview."""

__version__ = "0.1.0"
