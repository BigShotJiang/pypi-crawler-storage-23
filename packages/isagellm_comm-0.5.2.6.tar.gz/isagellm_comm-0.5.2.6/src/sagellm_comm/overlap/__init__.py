"""Stream/Event abstraction for compute-communication overlap.

This module provides abstractions for managing communication streams and events
to enable overlapping communication with computation.
"""

from __future__ import annotations

from sagellm_comm.overlap.cpu_stream import CPUEventHandle, CPUStreamHandle, create_cpu_stream
from sagellm_comm.overlap.stream import EventHandle, EventState, StreamHandle

__all__ = [
    "StreamHandle",
    "EventHandle",
    "EventState",
    "CPUStreamHandle",
    "CPUEventHandle",
    "create_cpu_stream",
]
