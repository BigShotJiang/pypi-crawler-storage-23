# this function is useful as an alternative for the optimizer when you dont know which generator is best

def zeroes(number_of_parameters):
	return [0]*number_of_parameters
