"""Utility functions for the jmstate package."""

from ._surv import build_buckets

__all__ = ["build_buckets"]
