"""Multistate joint modeling package."""

from ._base import MultiStateJointModel

__all__ = ["MultiStateJointModel"]
