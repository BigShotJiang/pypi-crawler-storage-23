"""
This module contains the MoaT-Link nodes used as codecs.
"""

from __future__ import annotations

from logging import getLogger

from attrs import define, field

from moat.util import make_proc

from . import Node

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from moat.lib.path import Path
    from moat.link.meta import MsgMeta

    from typing import Any

logger = getLogger(__name__)


@define
class CodecNode(Node):
    """
    This node type is used as a codec.
    """

    _enc = field(init=False, default=None)
    _dec = field(init=False, default=None)

    def enc_value(self, value, entry=None, **kv):  # noqa: D102
        if self._enc is not None:
            value = self._enc(value=value, entry=entry, data=self._data, **kv)
        return value

    def dec_value(self, value, entry=None, **kv):  # noqa: D102
        if self._dec is not None:
            value = self._dec(value=value, entry=entry, data=self._data, **kv)
        return value

    def set_(self, path: Path, data: Any, meta: MsgMeta):  # noqa: D102
        super().set_(path, data, meta)

        enc = None
        dec = None
        if data is not None and data.get("decode", None) is not None:
            dec = make_proc(data["decode"], ("value",), path)

        if data is not None and data.get("encode", None) is not None:
            enc = make_proc(data["encode"], ("value",), path)

        self._enc = enc
        self._dec = dec
