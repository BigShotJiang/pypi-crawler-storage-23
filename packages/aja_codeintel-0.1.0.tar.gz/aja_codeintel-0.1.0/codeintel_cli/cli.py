﻿from __future__ import annotations

import typer

from .errors import CodeIntelError, wrap_unexpected_error
from .core.timing import start_timer, end_timer

from .commands.graph import register_graph_commands
from .commands.nav import register_nav_commands
from .commands.project import register_project_commands




app = typer.Typer(
    help="CodeIntel: codebase intelligence CLI.",
    no_args_is_help=True,
)

register_project_commands(app)
register_nav_commands(app)
register_graph_commands(app)


def main() -> None:
    t0 = start_timer()
    try:
        app()
    except CodeIntelError as e:
        typer.echo(f"Error: {e}")
        raise SystemExit(e.exit_code)
    except Exception as e:
        ce = wrap_unexpected_error(e, context="Unexpected failure")
        typer.echo(f"Error: {ce}")
        raise SystemExit(ce.exit_code)
    finally:
        end_timer(t0)


if __name__ == "__main__":
    main()
