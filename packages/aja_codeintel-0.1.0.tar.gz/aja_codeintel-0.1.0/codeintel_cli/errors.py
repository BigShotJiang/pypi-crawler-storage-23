from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class CodeIntelError(Exception):
    """
    Base exception for all expected (user-facing) errors.
    The CLI catches these and prints clean messages.
    """
    message: str
    hint: Optional[str] = None
    exit_code: int = 1

    def __str__(self) -> str:
        if self.hint:
            return f"{self.message}\nHint: {self.hint}"
        return self.message


@dataclass
class InvalidPathError(CodeIntelError):
    path: Path = Path(".")
    exit_code: int = 2

    def __post_init__(self) -> None:
        if not self.message:
            self.message = f"Path must be an existing folder: {self.path}"
            self.hint = "Pass a directory path like '.' or 'src/'."


@dataclass
class PermissionDeniedError(CodeIntelError):
    path: Path = Path(".")
    exit_code: int = 3

    def __post_init__(self) -> None:
        if not self.message:
            self.message = f"Permission denied while reading: {self.path}"
            self.hint = "Check folder permissions or run terminal with appropriate access."


@dataclass
class ScanFailedError(CodeIntelError):
    root: Path = Path(".")
    exit_code: int = 4

    def __post_init__(self) -> None:
        if not self.message:
            self.message = f"Scan failed under: {self.root}"
            self.hint = "Try scanning a smaller folder or enable --verbose for details."


@dataclass
class NoPythonFilesFoundError(CodeIntelError):
    root: Path = Path(".")
    exit_code: int = 5

    def __post_init__(self) -> None:
        if not self.message:
            self.message = f"No Python files found under: {self.root}"
            self.hint = "Confirm you are scanning the correct folder."


def wrap_unexpected_error(err: Exception, context: str = "") -> CodeIntelError:
    """
    Convert unknown exceptions into a user-facing CodeIntelError.
    Use in CLI as a last-resort catch.
    """
    prefix = f"{context}: " if context else ""
    return CodeIntelError(
        message=f"{prefix}{err.__class__.__name__}: {err}",
        hint="Re-run with --verbose. If it persists, share the command + folder path.",
        exit_code=1,
    )
