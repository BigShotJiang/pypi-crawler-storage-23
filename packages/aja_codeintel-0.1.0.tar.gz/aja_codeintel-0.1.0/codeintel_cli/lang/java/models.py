from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re


@dataclass(frozen=True)
class ModelField:
    name: str
    type: str


@dataclass(frozen=True)
class ModelDef:
    name: str
    file: str
    kind: str
    bases: list[str]
    fields: list[ModelField]


TYPE_RE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
RECORD_RE = re.compile(r"\brecord\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)")
FIELD_RE = re.compile(
    r"^\s*(?:@\w+(?:\([^)]*\))?\s*)*"
    r"(?:(?:public|protected|private)\s+)?"
    r"(?:(?:static|final)\s+)*"
    r"([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=.*)?;"
)

_DENY_TYPES = {"return", "throw", "new", "super", "this", "break", "continue"}
_DENY_NAMES = {"return", "throw", "new", "super", "this", "true", "false", "null"}


def _split_record_params(sig: str) -> list[tuple[str, str]]:
    s = sig.strip()
    if not s:
        return []
    parts: list[str] = []
    cur = []
    depth = 0
    for ch in s:
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())

    out: list[tuple[str, str]] = []
    for p in parts:
        toks = p.split()
        if len(toks) >= 2:
            t = " ".join(toks[:-1]).strip()
            n = toks[-1].strip()
            if t and n:
                out.append((n, t))
    return out


def extract_java_models(path: Path, project_root: Path) -> list[ModelDef]:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    rel = str(path.relative_to(project_root))

    mrec = RECORD_RE.search(text)
    if mrec:
        name = mrec.group(1)
        params = mrec.group(2)
        fields = [ModelField(n, t) for (n, t) in _split_record_params(params)]
        return [ModelDef(name, rel, "java", [], fields)]

    mtype = TYPE_RE.search(text)
    if not mtype:
        return []

    name = mtype.group(2)

    fields: list[ModelField] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("return ") or s.startswith("throw "):
            continue
        fm = FIELD_RE.match(line)
        if fm:
            ftype = fm.group(1).strip()
            fname = fm.group(2).strip()
            if not ftype or not fname:
                continue
            if ftype.lower() in _DENY_TYPES:
                continue
            if fname.lower() in _DENY_NAMES:
                continue
            fields.append(ModelField(fname, ftype))

    return [ModelDef(name, rel, "java", [], fields)]