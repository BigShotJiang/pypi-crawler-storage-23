from __future__ import annotations

from pathlib import Path


def _possible_java_source_roots(project_root: Path) -> list[Path]:
    out: list[Path] = []
    seen: set[Path] = set()

    def add(p: Path) -> None:
        try:
            pr = p.resolve()
        except Exception:
            return
        if pr in seen:
            return
        if pr.exists() and pr.is_dir():
            seen.add(pr)
            out.append(pr)

    add(project_root / "src" / "main" / "java")
    add(project_root / "src" / "test" / "java")

    for p in project_root.rglob("src"):
        try:
            if not p.is_dir():
                continue
        except Exception:
            continue
        add(p / "main" / "java")
        add(p / "test" / "java")

    add(project_root)

    return out


def resolve_java_import_to_file(module: str, project_root: Path) -> Path | None:
    if not module:
        return None

    rel = Path(*module.split("."))

    for base in _possible_java_source_roots(project_root):
        cand = (base / rel).with_suffix(".java")
        if cand.exists() and cand.is_file():
            return cand.resolve()

    return None
