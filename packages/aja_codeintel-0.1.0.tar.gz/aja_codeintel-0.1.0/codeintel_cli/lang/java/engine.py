from __future__ import annotations

import re
from pathlib import Path

IMP = re.compile(r"^\s*import\s+([\w\.]+)\s*;")


def java_extract_imports(path: Path):
    out: list[str] = []
    try:
        for line in path.read_text(errors="ignore").splitlines():
            m = IMP.match(line)
            if m:
                out.append(m.group(1))
    except Exception:
        pass
    return out
