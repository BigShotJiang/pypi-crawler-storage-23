from __future__ import annotations

from pathlib import Path

from .python.engine import py_extract_imports
from .java.engine import java_extract_imports

def extract_imports(path: Path, lang: str):
    path = path.resolve()
    if lang == "java" or path.suffix.lower() == ".java":
        return java_extract_imports(path)
    return py_extract_imports(path)

def extract_models_for_file(path: Path, project_root: Path):
    path = path.resolve()
    if path.suffix.lower() == ".py":
        from .python.models import extract_python_models
        return extract_python_models(path, project_root)

    if path.suffix.lower() == ".java":
        from .java.models import extract_java_models
        return extract_java_models(path, project_root)

    return []