from __future__ import annotations

from pathlib import Path
from ...parser.imports import extract_imports_from_file


def py_extract_imports(path: Path):
    return extract_imports_from_file(path)
