from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import ast


@dataclass(frozen=True)
class ModelField:
    name: str
    type: str


@dataclass(frozen=True)
class ModelDef:
    name: str
    file: str
    kind: str
    bases: list[str]
    fields: list[ModelField]


def _unparse(node: ast.AST | None) -> str:
    if node is None:
        return "Any"
    try:
        return ast.unparse(node)
    except Exception:
        return node.__class__.__name__


def _base_names(cls: ast.ClassDef) -> list[str]:
    return [_unparse(b) for b in cls.bases]


def _has_decorator(cls: ast.ClassDef, name: str) -> bool:
    for d in cls.decorator_list:
        if isinstance(d, ast.Name) and d.id == name:
            return True
        if isinstance(d, ast.Attribute) and d.attr == name:
            return True
    return False


def _looks_like_model(cls: ast.ClassDef) -> bool:
    bases = _base_names(cls)
    if _has_decorator(cls, "dataclass"):
        return True
    if any("BaseModel" in b for b in bases):
        return True
    if any(b.endswith("Base") for b in bases):
        return True
    return False


def extract_python_models(path: Path, project_root: Path) -> list[ModelDef]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return []

    rel = str(path.relative_to(project_root))
    out: list[ModelDef] = []

    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        if not _looks_like_model(node):
            continue

        fields: list[ModelField] = []
        for st in node.body:
            if isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name):
                fields.append(ModelField(st.target.id, _unparse(st.annotation)))

        out.append(
            ModelDef(
                name=node.name,
                file=rel,
                kind="python",
                bases=_base_names(node),
                fields=fields,
            )
        )

    return out
