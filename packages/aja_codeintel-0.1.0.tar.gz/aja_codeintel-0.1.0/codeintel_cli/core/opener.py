from __future__ import annotations

from pathlib import Path
import os
import subprocess


def find_files(query: str, root: Path, files: list[Path]) -> list[Path]:
    """
    Return files whose relative path contains the query (case-insensitive).
    """
    q = query.replace("/", "\\").lower()
    matches: list[Path] = []

    for f in files:
        rel = str(f.relative_to(root)).lower()
        if q in rel:
            matches.append(f)

    return sorted(matches)


def open_file(path: Path) -> None:
    """
    Open a file in VS Code if available, otherwise open with default app (Windows).
    """
    # Try VS Code first (if 'code' is in PATH)
    try:
        r = subprocess.run(["where", "code"], capture_output=True, text=True)
        if r.returncode == 0:
            subprocess.run(["code", str(path)], check=False)
            return
    except Exception:
        pass

    # Fallback to Windows default app
    os.startfile(path)  # type: ignore[attr-defined]
