from __future__ import annotations

from pathlib import Path

SKIP_DIRS: set[str] = {
    "__pycache__",
    "venv",
    ".venv",
    ".git",
    "site-packages",
    "codeintel.egg-info",
    "build",
    "dist",
    ".mypy_cache",
    ".pytest_cache",
}


def find_project_root(start: Path) -> Path:
    start = start.resolve()
    for p in [start] + list(start.parents):
        if (p / "pyproject.toml").exists():
            return p
        if (p / "setup.py").exists():
            return p
        if (p / ".git").exists():
            return p
        if list(p.glob("*.egg-info")):
            return p
    return start


def is_skipped_path(path: Path) -> bool:
    return any(part in SKIP_DIRS for part in path.parts)
