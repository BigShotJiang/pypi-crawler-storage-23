from __future__ import annotations

import time
import typer


def start_timer() -> float:
    return time.perf_counter()


def end_timer(t0: float) -> None:
    dt = time.perf_counter() - t0
    typer.echo(f"Finished in {dt:.3f}s")
