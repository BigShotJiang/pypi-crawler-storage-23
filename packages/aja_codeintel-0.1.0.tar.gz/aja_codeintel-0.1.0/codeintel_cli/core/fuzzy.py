from __future__ import annotations
from pathlib import Path
import difflib


def rank_paths(query: str, files: list[Path], root: Path, top: int = 3) -> list[tuple[Path, float]]:
    q_raw = query.strip()
    q_lower = q_raw.replace("/", "\\").lower()

    if not q_lower:
        return []

    q_stem = Path(q_raw).stem.lower()
    scored: list[tuple[Path, float]] = []

    for p in files:
        if p.name == "__init__.py":
            continue

        try:
            rel = str(p.relative_to(root)).replace("/", "\\").lower()
        except Exception:
            rel = str(p).replace("/", "\\").lower()

        stem = p.stem.lower()
        name = p.name.lower()
        score = 0.0

        if stem == q_stem:
            score = 0.98
        elif name == q_lower:
            score = 0.97
        elif rel == q_lower:
            score = 0.96
        elif rel.endswith(q_lower):
            score = 0.92
        elif stem.startswith(q_stem):
            score = 0.88
        elif name.startswith(q_lower):
            score = 0.86
        elif q_stem in stem:
            score = 0.82
        elif q_lower in rel:
            score = 0.78
        elif q_lower in name:
            score = 0.74
        else:
            ratio_stem = difflib.SequenceMatcher(a=q_stem, b=stem).ratio()
            ratio_rel = difflib.SequenceMatcher(a=q_lower, b=rel).ratio()
            ratio = max(ratio_stem, ratio_rel)
            if ratio >= 0.5:
                score = 0.50 + (ratio - 0.5) * 0.4

        if score > 0:
            scored.append((p, score))

    scored.sort(key=lambda x: (-x[1], str(x[0]).lower()))
    return scored[: min(top, len(scored))]


def fuzzy_top_matches(query: str, files: list[Path], root: Path, top: int = 3) -> list[tuple[Path, float]]:
    return rank_paths(query, files, root, top=top)


def fuzzy_is_confident(ranked: list[tuple[Path, float]], min_score: float = 0.90, gap: float = 0.05) -> bool:
    if not ranked:
        return False
    if ranked[0][1] < min_score:
        return False
    if len(ranked) == 1:
        return True
    return (ranked[0][1] - ranked[1][1]) >= gap