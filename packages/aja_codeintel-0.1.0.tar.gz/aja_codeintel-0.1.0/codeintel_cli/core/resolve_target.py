from __future__ import annotations
from pathlib import Path
import typer

from ..errors import InvalidPathError
from .project import find_project_root
from .fuzzy import rank_paths, fuzzy_is_confident
from ..scanner.scanner import find_all_supported_files


def resolve_target_file(query: str, root: str = ".", top: int = 3) -> tuple[Path, Path]:
    root_path = Path(root).resolve()
    project_root = find_project_root(root_path)

    q = Path(query)
    if q.exists() and q.is_file():
        return q.resolve(), project_root

    all_files = find_all_supported_files(project_root)

    qstem_lower = Path(query).stem.lower()
    exact_matches = [f for f in all_files if f.stem.lower() == qstem_lower and f.name != "__init__.py"]

    if len(exact_matches) == 1:
        return exact_matches[0].resolve(), project_root

    if len(exact_matches) > 1:
        exact_matches = exact_matches[:top]

    ranked = rank_paths(query, all_files if not exact_matches else exact_matches, project_root, top=top)

    if not ranked:
        raise InvalidPathError(message="File not found", path=Path(query))

    if fuzzy_is_confident(ranked):
        top_score = ranked[0][1]
        ties = [x for x in ranked if abs(x[1] - top_score) < 0.02]
        if len(ties) == 1:
            return ranked[0][0].resolve(), project_root

    typer.echo("Did you mean:")
    for i, (p, score) in enumerate(ranked, 1):
        try:
            rel = p.relative_to(project_root)
        except Exception:
            rel = p
        typer.echo(f"{i}. {rel.as_posix()}   score={score:.2f}")

    choice = typer.prompt("Select number (0=cancel)", type=int, default=0)
    if choice == 0 or choice < 1 or choice > len(ranked):
        raise typer.Exit()

    return ranked[choice - 1][0].resolve(), project_root