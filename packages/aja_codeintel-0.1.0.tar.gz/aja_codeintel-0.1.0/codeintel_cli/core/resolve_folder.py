from __future__ import annotations

from pathlib import Path
import typer

from .project import find_project_root, is_skipped_path
from .fuzzy import fuzzy_top_matches
from ..errors import InvalidPathError


def resolve_target_folder(
    query: str,
    *,
    top: int = 3,
    auto_threshold: float = 0.90,
    min_threshold: float = 0.60,
) -> tuple[Path, Path]:
    root = find_project_root(Path.cwd())

    p = Path(query)
    if p.exists() and p.is_dir():
        return p.resolve(), root

    p2 = root / query
    if p2.exists() and p2.is_dir():
        return p2.resolve(), root

    folders = [d.resolve() for d in root.rglob("*") if d.is_dir() and not is_skipped_path(d)]

    qname = Path(query).name
    exact = [d for d in folders if d.name == qname]
    if len(exact) == 1:
        return exact[0], root

    if len(exact) > 1:
        typer.echo("Multiple exact matches:")
        for i, m in enumerate(exact[:top], 1):
            typer.echo(f"{i}. {m}")
        choice = typer.prompt("Select number (0=cancel)", type=int, default=0)
        if choice == 0:
            raise typer.Exit()
        if choice < 1 or choice > min(len(exact), top):
            raise typer.BadParameter("Invalid selection.")
        return exact[choice - 1], root

    matches = fuzzy_top_matches(query, folders, root, top=top)
    if not matches:
        raise InvalidPathError(message="Folder not found", path=Path(query))

    best_path, best_score = matches[0]
    if best_score < min_threshold:
        raise InvalidPathError(message="Folder not found (low-confidence)", path=Path(query))

    second = matches[1][1] if len(matches) > 1 else 0.0
    if best_score >= auto_threshold and (best_score - second) >= 0.05:
        return best_path.resolve(), root

    typer.echo("Did you mean:")
    for i, (p, score) in enumerate(matches, 1):
        typer.echo(f"{i}. {p}   score={score:.2f}")

    choice = typer.prompt("Select number (0=cancel)", type=int, default=0)
    if choice == 0:
        raise typer.Exit()
    if choice < 1 or choice > len(matches):
        raise typer.BadParameter("Invalid selection.")

    return matches[choice - 1][0].resolve(), root
