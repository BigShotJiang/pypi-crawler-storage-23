from __future__ import annotations
from pathlib import Path
import typer

from ..errors import InvalidPathError
from .project import find_project_root
from .fuzzy import rank_paths, fuzzy_is_confident
from ..scanner.scanner import find_all_supported_files

def _is_domain_model_path(p: Path) -> bool:
    parts = {x.lower() for x in p.parts}
    return bool(parts & {"model", "models", "entity", "entities", "domain"})

def _java_model_annotation_hint(path: Path) -> bool:
    try:
        t = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    return any(x in t for x in ("@Entity", "@Table", "@Embeddable", "@MappedSuperclass"))

def _has_class_definition(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        return "class " in text and len(text.strip()) > 50
    except Exception:
        return False

def _is_java_model_file(p: Path) -> bool:
    if p.suffix.lower() != ".java":
        return False
    if p.name == "__init__.py":
        return False
    if not (_is_domain_model_path(p) or _java_model_annotation_hint(p)):
        return False
    return _has_class_definition(p)

def _is_python_model_file(p: Path) -> bool:
    if p.suffix.lower() != ".py":
        return False
    if p.name in {"__init__.py", "models.py"}:
        return False
    if not _is_domain_model_path(p):
        return False
    return _has_class_definition(p)

def resolve_model_target_file(query: str, root: str = ".", top: int = 3) -> tuple[Path, Path]:
    root_path = Path(root).resolve()
    project_root = find_project_root(root_path)
    
    q = Path(query)
    if q.exists() and q.is_file():
        return q.resolve(), project_root
    
    files = find_all_supported_files(project_root)
    model_files: list[Path] = [p for p in files if _is_java_model_file(p) or _is_python_model_file(p)]
    
    if not model_files:
        raise InvalidPathError(message="No model/entity files found", path=project_root)
    
    qstem_lower = Path(query).stem.lower()
    exact_matches = [f for f in model_files if f.stem.lower() == qstem_lower]
    
    if len(exact_matches) == 1:
        return exact_matches[0].resolve(), project_root
    
    if len(exact_matches) > 1:
        exact_matches = exact_matches[:top]
    
    ranked = rank_paths(query, exact_matches if exact_matches else model_files, project_root, top=top)
    
    if not ranked:
        raise InvalidPathError(message="Model not found", path=Path(query))
    
    if fuzzy_is_confident(ranked):
        top_score = ranked[0][1]
        ties = [x for x in ranked if abs(x[1] - top_score) < 0.02]
        if len(ties) == 1:
            return ranked[0][0].resolve(), project_root
    
    typer.echo("Select model:")
    for i, (p, score) in enumerate(ranked, 1):
        try:
            rel = p.relative_to(project_root)
        except Exception:
            rel = p
        typer.echo(f"{i}. {rel.as_posix()}   score={score:.2f}")
    
    choice = typer.prompt("Select number (0=cancel)", type=int, default=0)
    if choice == 0 or choice < 1 or choice > len(ranked):
        raise typer.Exit()
    
    return ranked[choice - 1][0].resolve(), project_root