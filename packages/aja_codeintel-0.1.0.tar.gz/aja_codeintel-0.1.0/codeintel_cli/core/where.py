from __future__ import annotations

from pathlib import Path


def _py_file_to_module(path: Path, root: Path) -> str | None:
    if path.suffix.lower() != ".py":
        return None
    try:
        rel = path.resolve().relative_to(root.resolve())
    except Exception:
        return None
    parts = list(rel.parts)
    if not parts:
        return None
    if parts[-1] == "__init__.py":
        parts = parts[:-1]
    else:
        parts[-1] = Path(parts[-1]).stem
    if not parts:
        return None
    return ".".join(parts)


def _java_file_to_module(path: Path, root: Path) -> str | None:
    if path.suffix.lower() != ".java":
        return None

    p = path.resolve()
    try:
        rel = p.relative_to(root.resolve())
    except Exception:
        rel = p

    parts = list(rel.parts)
    if not parts:
        return None

    low = [x.lower() for x in parts]

    def build_from(start_idx: int) -> str | None:
        if start_idx >= len(parts):
            return None
        segs = parts[start_idx:]
        if not segs:
            return None
        last = Path(segs[-1]).stem
        segs = list(segs[:-1]) + [last]
        segs = [s for s in segs if s and s not in (".", "..")]
        if not segs:
            return None
        return ".".join(segs)

    if "src" in low:
        i = low.index("src")
        if i + 3 < len(parts) and low[i + 1] in ("main", "test") and low[i + 2] == "java":
            out = build_from(i + 3)
            if out:
                return out

    if "java" in low:
        i = low.index("java")
        out = build_from(i + 1)
        if out:
            return out

    if "com" in low:
        i = low.index("com")
        out = build_from(i)
        if out:
            return out

    return None


def file_to_module(path: Path, root: Path) -> str | None:
    return _py_file_to_module(path, root) or _java_file_to_module(path, root)
