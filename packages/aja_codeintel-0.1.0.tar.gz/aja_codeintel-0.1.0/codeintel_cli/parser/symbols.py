from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import ast


@dataclass(frozen=True)
class ClassInfo:
    name: str
    lineno: int


@dataclass(frozen=True)
class FuncInfo:
    name: str
    lineno: int
    signature: str


def _format_args(a: ast.arguments) -> str:
    parts: list[str] = []

    if getattr(a, "posonlyargs", None):
        for x in a.posonlyargs:
            parts.append(x.arg)
        parts.append("/")

    for x in a.args:
        parts.append(x.arg)

    if a.vararg:
        parts.append(f"*{a.vararg.arg}")
    elif a.kwonlyargs:
        parts.append("*")

    for x in a.kwonlyargs:
        parts.append(x.arg)

    if a.kwarg:
        parts.append(f"**{a.kwarg.arg}")

    return ", ".join(parts)


def _read_source_text(path: Path) -> str:
    try:
        raw = path.read_bytes()
    except Exception:
        return ""

    text = raw.decode("utf-8-sig", errors="ignore")

    if "\x00" in text:
        text = text.replace("\x00", "")
    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")

    return text


def extract_classes_from_file(path: Path) -> list[ClassInfo]:
    try:
        text = _read_source_text(path)
        if not text.strip():
            return []
        tree = ast.parse(text)
    except Exception:
        return []

    out: list[ClassInfo] = []
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            out.append(ClassInfo(node.name, getattr(node, "lineno", 1)))
    return out


def extract_funcs_from_file(path: Path) -> list[FuncInfo]:
    try:
        text = _read_source_text(path)
        if not text.strip():
            return []
        tree = ast.parse(text)
    except Exception:
        return []

    out: list[FuncInfo] = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            sig = f"{node.name}({_format_args(node.args)})"
            out.append(FuncInfo(node.name, getattr(node, "lineno", 1), sig))
    return out