from __future__ import annotations
from pathlib import Path


def resolve_module_to_file(module: str, root: Path) -> Path | None:
    """
    Absolute import resolution (backward compatible).
    Example: 'codeintel_cli.graph.builder' -> root/codeintel_cli/graph/builder.py
    """
    if not module:
        return None

    cand = root / (module.replace(".", "/") + ".py")
    if cand.exists():
        return cand.resolve()

    init = root / module.replace(".", "/") / "__init__.py"
    if init.exists():
        return init.resolve()

    return None


def resolve_import_to_file(module: str, level: int, current_file: Path, root: Path) -> Path | None:
    """
    Supports absolute + relative imports.
    - level=0: absolute import (uses resolve_module_to_file)
    - level>0: relative import (from . / .. / ...)
    """
    # absolute
    if level == 0:
        return resolve_module_to_file(module, root)

    # relative
    base = current_file.parent
    for _ in range(level - 1):
        base = base.parent

    target_base = base if module == "" else base / module.replace(".", "/")

    py = target_base.with_suffix(".py")
    if py.exists():
        return py.resolve()

    init = target_base / "__init__.py"
    if init.exists():
        return init.resolve()

    return None
