from __future__ import annotations

import ast
from pathlib import Path


def extract_imports_from_code(code: str) -> list[tuple[str, int]]:
    code = code.lstrip("\ufeff")
    tree = ast.parse(code)

    out: list[tuple[str, int]] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for n in node.names:
                if n.name:
                    out.append((n.name, 0))
        elif isinstance(node, ast.ImportFrom):
            out.append((node.module or "", node.level))

    return out


def extract_imports_from_file(path: Path) -> list[tuple[str, int]]:
    text = path.read_text(encoding="utf-8-sig")
    return extract_imports_from_code(text)
