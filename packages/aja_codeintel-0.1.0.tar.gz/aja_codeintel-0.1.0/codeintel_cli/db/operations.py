﻿from __future__ import annotations

import hashlib
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any


def _hash_content(content: str) -> str:
    return hashlib.md5(content.encode("utf-8")).hexdigest()


def get_file_modified_time(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except Exception:
        return 0.0


def is_file_cached(conn: sqlite3.Connection, path: Path) -> bool:
    cursor = conn.execute("SELECT modified_time FROM files WHERE path = ?", (str(path.resolve()),))
    row = cursor.fetchone()
    if not row:
        return False
    cached_mtime = float(row[0])
    current_mtime = float(get_file_modified_time(path))
    return abs(cached_mtime - current_mtime) < 0.01


def get_file_id(conn: sqlite3.Connection, path: Path) -> int | None:
    cursor = conn.execute("SELECT id FROM files WHERE path = ?", (str(path.resolve()),))
    row = cursor.fetchone()
    return int(row[0]) if row else None


def upsert_file(conn: sqlite3.Connection, path: Path, rel_path: str, language: str, content: str = "") -> int:
    path_str = str(path.resolve())
    file_id = get_file_id(conn, Path(path_str))
    modified_time = get_file_modified_time(Path(path_str))
    scanned_at = datetime.now().timestamp()
    content_hash = _hash_content(content) if content else None

    if file_id:
        conn.execute(
            "UPDATE files SET rel_path = ?, language = ?, modified_time = ?, scanned_at = ?, content_hash = ? WHERE id = ?",
            (rel_path, language, modified_time, scanned_at, content_hash, file_id),
        )
        return file_id

    cur = conn.execute(
        "INSERT INTO files (path, rel_path, language, modified_time, scanned_at, content_hash) VALUES (?, ?, ?, ?, ?, ?)",
        (path_str, rel_path, language, modified_time, scanned_at, content_hash),
    )
    return int(cur.lastrowid)


def clear_file_data(conn: sqlite3.Connection, file_id: int) -> None:
    conn.execute("DELETE FROM imports WHERE file_id = ?", (file_id,))
    conn.execute("DELETE FROM symbols WHERE file_id = ?", (file_id,))
    cur = conn.execute("SELECT id FROM models WHERE file_id = ?", (file_id,))
    mids = [int(r[0]) for r in cur.fetchall()]
    for mid in mids:
        conn.execute("DELETE FROM model_fields WHERE model_id = ?", (mid,))
        conn.execute("DELETE FROM relationships WHERE model_id = ?", (mid,))
    conn.execute("DELETE FROM models WHERE file_id = ?", (file_id,))


def insert_import(conn: sqlite3.Connection, file_id: int, import_path: str, resolved_file_id: int | None = None) -> None:
    conn.execute(
        "INSERT INTO imports (file_id, import_path, resolved_file_id) VALUES (?, ?, ?)",
        (file_id, import_path, resolved_file_id),
    )


def update_import_resolved(conn: sqlite3.Connection, import_row_id: int, resolved_file_id: int) -> None:
    conn.execute("UPDATE imports SET resolved_file_id = ? WHERE id = ?", (resolved_file_id, import_row_id))


def insert_symbol(conn: sqlite3.Connection, file_id: int, name: str, symbol_type: str, line_number: int | None = None) -> None:
    conn.execute(
        "INSERT INTO symbols (file_id, name, type, line_number) VALUES (?, ?, ?, ?)",
        (file_id, name, symbol_type, line_number),
    )


def insert_model(
    conn: sqlite3.Connection,
    file_id: int,
    model_name: str,
    fields: list[tuple[str, str, bool]],
    relationships: list[dict[str, Any]],
) -> int:
    cur = conn.execute("INSERT INTO models (file_id, name) VALUES (?, ?)", (file_id, model_name))
    model_id = int(cur.lastrowid)

    for field_name, field_type, is_pk in fields:
        conn.execute(
            "INSERT INTO model_fields (model_id, name, type, is_primary_key) VALUES (?, ?, ?, ?)",
            (model_id, field_name, field_type, 1 if is_pk else 0),
        )

    for rel in relationships:
        conn.execute(
            "INSERT INTO relationships (model_id, kind, target, field) VALUES (?, ?, ?, ?)",
            (model_id, str(rel.get("kind", "")), str(rel.get("target", "")), str(rel.get("field", ""))),
        )

    return model_id


def get_all_files(conn: sqlite3.Connection) -> list[Path]:
    cur = conn.execute("SELECT path FROM files ORDER BY path")
    return [Path(r[0]) for r in cur.fetchall()]


def get_file_imports(conn: sqlite3.Connection, file_id: int) -> list[str]:
    cur = conn.execute("SELECT import_path FROM imports WHERE file_id = ? ORDER BY id", (file_id,))
    return [str(r[0]) for r in cur.fetchall()]


def get_file_symbols(conn: sqlite3.Connection, file_id: int) -> list[dict]:
    cur = conn.execute(
        "SELECT name, type, line_number FROM symbols WHERE file_id = ? ORDER BY COALESCE(line_number, 1000000)",
        (file_id,),
    )
    return [{"name": r[0], "type": r[1], "line": r[2]} for r in cur.fetchall()]


def get_models(conn: sqlite3.Connection) -> list[dict]:
    cur = conn.execute(
        "SELECT m.id, m.name, f.path FROM models m JOIN files f ON m.file_id = f.id ORDER BY m.name"
    )
    out: list[dict] = []
    for model_id, name, path in cur.fetchall():
        fcur = conn.execute("SELECT name, type, is_primary_key FROM model_fields WHERE model_id = ?", (model_id,))
        fields = [(r[0], r[1], bool(r[2])) for r in fcur.fetchall()]
        out.append({"name": name, "path": Path(path), "fields": fields})
    return out


def needs_rescan(conn: sqlite3.Connection, project_root: Path) -> bool:
    from ..scanner.scanner import find_all_supported_files

    current_files = {str(p.resolve()) for p in find_all_supported_files(project_root)}
    cur = conn.execute("SELECT path FROM files")
    cached_files = {str(r[0]) for r in cur.fetchall()}
    if current_files != cached_files:
        return True

    cur = conn.execute("SELECT path, modified_time FROM files")
    for path_str, cached_mtime in cur.fetchall():
        p = Path(path_str)
        if not p.exists():
            return True
        now_mtime = get_file_modified_time(p)
        if abs(float(now_mtime) - float(cached_mtime)) > 0.01:
            return True

    return False


def get_imports_map_for_paths(conn: sqlite3.Connection, paths: list[Path]) -> dict[str, list[str]]:
    if not paths:
        return {}

    path_strs = [str(p.resolve()) for p in paths]
    CHUNK = 800
    out: dict[str, list[str]] = {}

    for i in range(0, len(path_strs), CHUNK):
        chunk = path_strs[i : i + CHUNK]
        placeholders = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"""
            SELECT f.path, imp.import_path
            FROM imports imp
            JOIN files f ON f.id = imp.file_id
            WHERE f.path IN ({placeholders})
            ORDER BY imp.id
            """,
            chunk,
        ).fetchall()

        for pstr, imp in rows:
            out.setdefault(str(pstr), []).append(str(imp))

        for pstr in chunk:
            out.setdefault(pstr, out.get(pstr, []))

    return out


def get_deps_map_for_paths(conn: sqlite3.Connection, paths: list[Path]) -> dict[str, list[str]]:
    if not paths:
        return {}

    path_strs = [str(p.resolve()) for p in paths]
    CHUNK = 600
    out: dict[str, list[str]] = {}

    for i in range(0, len(path_strs), CHUNK):
        chunk = path_strs[i : i + CHUNK]
        placeholders = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"""
            SELECT f1.path, f2.path
            FROM imports i
            JOIN files f1 ON f1.id = i.file_id
            JOIN files f2 ON f2.id = i.resolved_file_id
            WHERE f1.path IN ({placeholders})
            ORDER BY f1.path, f2.path
            """,
            chunk,
        ).fetchall()

        for src, dep in rows:
            out.setdefault(str(src), []).append(str(dep))

        for src in chunk:
            out.setdefault(src, out.get(src, []))

    return out


def get_all_file_id_map(conn: sqlite3.Connection) -> dict[str, int]:
    cur = conn.execute("SELECT id, path FROM files")
    return {str(path): int(fid) for fid, path in cur.fetchall()}


def get_unresolved_import_rows(conn: sqlite3.Connection) -> list[tuple[int, int, str]]:
    cur = conn.execute(
        "SELECT id, file_id, import_path FROM imports WHERE resolved_file_id IS NULL ORDER BY id"
    )
    return [(int(r[0]), int(r[1]), str(r[2])) for r in cur.fetchall()]


def get_file_path_and_lang(conn: sqlite3.Connection, file_id: int) -> tuple[str, str] | None:
    cur = conn.execute("SELECT path, language FROM files WHERE id = ?", (file_id,))
    row = cur.fetchone()
    if not row:
        return None
    return str(row[0]), str(row[1])


def get_deps_for_path(conn: sqlite3.Connection, path: Path) -> list[Path]:
    cur = conn.execute(
        """
        SELECT f2.path
        FROM imports i
        JOIN files f1 ON f1.id = i.file_id
        JOIN files f2 ON f2.id = i.resolved_file_id
        WHERE f1.path = ?
        ORDER BY f2.path
        """,
        (str(path.resolve()),),
    )
    return [Path(r[0]) for r in cur.fetchall()]


def get_model_by_file_path(conn: sqlite3.Connection, path: Path) -> tuple[int, str] | None:
    cur = conn.execute(
        """
        SELECT m.id, m.name
        FROM models m
        JOIN files f ON f.id = m.file_id
        WHERE f.path = ?
        """,
        (str(path.resolve()),),
    )
    row = cur.fetchone()
    if not row:
        return None
    return int(row[0]), str(row[1])


def get_model_fields(conn: sqlite3.Connection, model_id: int) -> list[tuple[str, str, bool]]:
    cur = conn.execute(
        "SELECT name, type, is_primary_key FROM model_fields WHERE model_id = ? ORDER BY id",
        (model_id,),
    )
    return [(str(n), str(t), bool(pk)) for n, t, pk in cur.fetchall()]


def get_model_relationships(conn: sqlite3.Connection, model_id: int) -> list[dict[str, str]]:
    cur = conn.execute(
        "SELECT kind, target, field FROM relationships WHERE model_id = ? ORDER BY id",
        (model_id,),
    )
    return [{"kind": str(k), "target": str(t), "field": str(f)} for k, t, f in cur.fetchall()]


def get_fields_by_model_names(conn: sqlite3.Connection, names: list[str]) -> dict[str, list[tuple[str, str, bool]]]:
    if not names:
        return {}
    CHUNK = 400
    out: dict[str, list[tuple[str, str, bool]]] = {}

    for i in range(0, len(names), CHUNK):
        chunk = names[i : i + CHUNK]
        placeholders = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"""
            SELECT m.name, mf.name, mf.type, mf.is_primary_key
            FROM model_fields mf
            JOIN models m ON m.id = mf.model_id
            WHERE m.name IN ({placeholders})
            ORDER BY m.name, mf.id
            """,
            chunk,
        ).fetchall()

        for mname, fname, ftype, pk in rows:
            out.setdefault(str(mname), []).append((str(fname), str(ftype), bool(pk)))

        for n in chunk:
            out.setdefault(n, out.get(n, []))

    return out


def get_reverse_relationships(conn: sqlite3.Connection, target_model_name: str) -> list[dict[str, str]]:
    cur = conn.execute(
        """
        SELECT m.name, r.kind, r.field
        FROM relationships r
        JOIN models m ON m.id = r.model_id
        WHERE r.target = ?
        ORDER BY m.name, r.kind, r.field
        """,
        (target_model_name,),
    )
    return [{"source": str(src), "kind": str(kind), "field": str(field)} for src, kind, field in cur.fetchall()]