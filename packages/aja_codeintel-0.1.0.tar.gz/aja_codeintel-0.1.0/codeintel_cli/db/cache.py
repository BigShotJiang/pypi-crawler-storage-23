from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .schema import init_db, get_db_path
from .operations import (
    is_file_cached,
    upsert_file,
    clear_file_data,
    insert_import,
    insert_symbol,
    insert_model,
    get_all_files,
    get_file_id,
    get_file_imports,
    get_file_symbols,
    get_models,
    needs_rescan,
    get_imports_map_for_paths,
    get_all_file_id_map,
    get_unresolved_import_rows,
    get_file_path_and_lang,
    update_import_resolved,
)
from ..scanner.scanner import find_all_supported_files


def _encode_py_import(mod: str, level: int) -> str:
    mod = (mod or "").strip()
    level = int(level or 0)
    if level <= 0:
        return mod
    return ("." * level) + mod


class CacheManager:
    def __init__(self, project_root: Path):
        self.project_root = project_root.resolve()
        self.db_path = get_db_path(self.project_root)
        self.conn: sqlite3.Connection | None = None

    def __enter__(self):
        self.conn = init_db(self.db_path)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.conn:
            return
        if exc_type is None:
            self.conn.commit()
        else:
            self.conn.rollback()
        self.conn.close()

    def needs_rescan(self) -> bool:
        if not self.conn:
            return True
        return needs_rescan(self.conn, self.project_root)

    def scan_project(self, verbose: bool = False) -> int:
        if not self.conn:
            raise RuntimeError("CacheManager not initialized")

        files = find_all_supported_files(self.project_root)
        scanned = 0

        for file_path in files:
            file_path = file_path.resolve()
            if is_file_cached(self.conn, file_path):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                content = ""

            try:
                rel_path = str(file_path.relative_to(self.project_root))
            except Exception:
                rel_path = str(file_path)

            language = file_path.suffix.lstrip(".").lower()
            file_id = upsert_file(self.conn, file_path, rel_path, language, content)

            clear_file_data(self.conn, file_id)
            self._index_file(file_id, file_path, content, language)

            scanned += 1
            if verbose and scanned % 10 == 0:
                print(f"Indexed {scanned} files...")

        self._resolve_import_edges()
        self.conn.commit()
        return scanned

    def _index_file(self, file_id: int, file_path: Path, content: str, language: str) -> None:
        if language == "py":
            self._index_python_file(file_id, file_path, content)
        elif language == "java":
            self._index_java_file(file_id, file_path, content)

    def _index_python_file(self, file_id: int, file_path: Path, content: str) -> None:
        import ast

        try:
            tree = ast.parse(content)
        except Exception:
            return

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name:
                        insert_import(self.conn, file_id, alias.name, None)
            elif isinstance(node, ast.ImportFrom):
                mod = node.module or ""
                lvl = int(getattr(node, "level", 0) or 0)
                insert_import(self.conn, file_id, _encode_py_import(mod, lvl), None)
            elif isinstance(node, ast.ClassDef):
                insert_symbol(self.conn, file_id, node.name, "class", getattr(node, "lineno", 1))
            elif isinstance(node, ast.FunctionDef):
                insert_symbol(self.conn, file_id, node.name, "function", getattr(node, "lineno", 1))

        try:
            from ..lang.router import extract_models_for_file

            models = extract_models_for_file(file_path, self.project_root)
            for model in models or []:
                fields = [(f.name, f.type, f.name.lower() == "id") for f in (model.fields or [])]
                insert_model(self.conn, file_id, model.name, fields, [])
        except Exception:
            pass

    def _index_java_file(self, file_id: int, file_path: Path, content: str) -> None:
        import re

        for m in re.finditer(r"import\s+([\w.]+)\s*;", content):
            imp = (m.group(1) or "").strip()
            if imp:
                insert_import(self.conn, file_id, imp, None)

        for m in re.finditer(r"\b(class|interface|enum|record)\s+([A-Za-z_]\w*)", content):
            insert_symbol(self.conn, file_id, m.group(2), m.group(1), None)

        try:
            from ..context.java_rel import java_fields_and_rels

            fields, rels = java_fields_and_rels(file_path)
            if fields:
                relationships = [{"kind": r.kind, "target": r.target, "field": r.field} for r in rels]
                insert_model(self.conn, file_id, file_path.stem, fields, relationships)
        except Exception:
            pass

    def _resolve_import_edges(self) -> None:
        if not self.conn:
            return

        from ..parser.resolve import resolve_import_to_file
        from ..lang.java.resolve import resolve_java_import_to_file

        file_id_by_path = get_all_file_id_map(self.conn)
        rows = get_unresolved_import_rows(self.conn)

        for imp_row_id, src_file_id, imp in rows:
            meta = get_file_path_and_lang(self.conn, src_file_id)
            if not meta:
                continue
            src_path_str, lang = meta
            src_path = Path(src_path_str)

            target: Path | None = None

            if lang == "py":
                s = (imp or "").strip()
                if not s:
                    continue
                level = 0
                while level < len(s) and s[level] == ".":
                    level += 1
                mod = s[level:] if level > 0 else s
                target = resolve_import_to_file(mod, level, src_path, self.project_root)

            elif lang == "java":
                s = (imp or "").strip()
                if not s or s.endswith(".*"):
                    continue
                target = resolve_java_import_to_file(s, self.project_root)

            if not target:
                continue

            tid = file_id_by_path.get(str(target.resolve()))
            if tid:
                update_import_resolved(self.conn, imp_row_id, tid)

    def get_cached_files(self) -> list[Path]:
        if not self.conn:
            return []
        return get_all_files(self.conn)

    def get_file_data(self, file_path: Path) -> dict[str, Any]:
        if not self.conn:
            return {}
        file_id = get_file_id(self.conn, file_path)
        if not file_id:
            return {}
        return {"imports": get_file_imports(self.conn, file_id), "symbols": get_file_symbols(self.conn, file_id)}

    def get_all_models(self) -> list[dict]:
        if not self.conn:
            return []
        return get_models(self.conn)

    def get_imports_map(self, files: list[Path]) -> dict[str, list[str]]:
        if not self.conn:
            return {}
        return get_imports_map_for_paths(self.conn, files)


def get_cache(project_root: Path) -> CacheManager:
    return CacheManager(project_root)