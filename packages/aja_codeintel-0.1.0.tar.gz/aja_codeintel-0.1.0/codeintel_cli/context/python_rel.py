from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import ast
import re

from ..core.project import find_project_root
from ..scanner.scanner import find_all_supported_files
from ..lang.router import extract_models_for_file

@dataclass(frozen=True)
class PyRel:
    kind: str
    target: str
    field: str
    via: str = ""

_COLLECTION_RE = re.compile(r"^(list|List|set|Set|tuple|Tuple|Sequence)\[(.+)\]$")
_OPTIONAL_RE = re.compile(r"^(Optional|typing\.Optional)\[(.*)\]$")
_UNION_RE = re.compile(r"^(Union|typing\.Union)\[(.*)\]$")
_PEP604_RE = re.compile(r"^(.+)\s*\|\s*None$|^None\s*\|\s*(.+)$")
_QUOTED_ATOM_RE = re.compile(r'(["\'])([^"\']+)\1')
_FK_SUFFIXES = ("_id", "Id")
_EMBED_HINTS = {"address", "profile", "detail", "details", "meta", "metadata", "settings", "config", "configuration"}
_BUILTIN_TYPES = {
    "str", "int", "float", "bool", "dict", "list", "tuple", "set", "Any", "None", "object", "bytes", "bytearray",
    "Decimal", "UUID", "datetime", "date", "time", "timedelta", "Path", "Optional", "Union", "Literal", "TypeVar",
    "frozenset", "complex", "type", "range", "slice", "memoryview", "property", "classmethod", "staticmethod"
}

def _ann_to_str(n: ast.AST | None) -> str:
    if n is None:
        return ""
    try:
        return ast.unparse(n)
    except Exception:
        if isinstance(n, ast.Name):
            return n.id
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            return n.value
        return ""

def _strip_typing(s: str) -> str:
    t = (s or "").strip()
    t = t.replace("collections.abc.", "")
    return t.strip()

def _unwrap_optional(s: str) -> str:
    t = _strip_typing(s)
    t = _QUOTED_ATOM_RE.sub(r"\2", t)
    m = _OPTIONAL_RE.match(t)
    if m:
        return m.group(2).strip()
    m2 = _UNION_RE.match(t)
    if m2:
        parts = [p.strip() for p in m2.group(2).split(",")]
        parts = [p for p in parts if p and p != "None"]
        if len(parts) == 1:
            return parts[0]
    m3 = _PEP604_RE.match(t)
    if m3:
        left = (m3.group(1) or "").strip()
        right = (m3.group(2) or "").strip()
        return (left or right).strip()
    return t

def _collection_inner(s: str) -> tuple[bool, str]:
    t = _unwrap_optional(s)
    m = _COLLECTION_RE.match(t)
    if not m:
        return False, ""
    inner = _unwrap_optional(m.group(2).strip())
    return True, inner

def _normalize_ref_name(type_str: str) -> str:
    t = _unwrap_optional(type_str).strip()
    if not t:
        return ""
    if (t.startswith('"') and t.endswith('"')) or (t.startswith("'") and t.endswith("'")):
        t = t[1:-1].strip()
    if t.startswith("ForwardRef("):
        t = t.removeprefix("ForwardRef(").removesuffix(")").strip()
        t = t.strip('"').strip("'").strip()
    if "." in t:
        t = t.split(".")[-1].strip()
    return t

def _fk_guess_target(field_name: str, model_names: set[str]) -> str | None:
    n = field_name.strip()
    if not n:
        return None
    base = n
    if base.endswith("_id"):
        base = base[:-3]
    elif base.endswith("Id"):
        base = base[:-2]
    base = base.strip("_")
    if not base:
        return None
    candidates = {base, base.capitalize(), base[:1].upper() + base[1:], base.replace("_", "").capitalize()}
    for c in candidates:
        if c in model_names:
            return c
    return None

@dataclass(frozen=True)
class _ModelInfo:
    name: str
    file: Path
    fields: list[tuple[str, str, bool]]

def _extract_classes_fields_from_ast(py_file: Path) -> list[_ModelInfo]:
    try:
        code = py_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []
    try:
        tree = ast.parse(code)
    except Exception:
        return []
    out: list[_ModelInfo] = []
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        cls_name = node.name
        fields: list[tuple[str, str, bool]] = []
        for b in node.body:
            if isinstance(b, ast.AnnAssign) and isinstance(b.target, ast.Name):
                fname = b.target.id
                ftype = _ann_to_str(b.annotation) or "Any"
                is_pk = fname.lower() in {"id", "pk"}
                fields.append((fname, ftype, is_pk))
            elif isinstance(b, ast.Assign) and len(b.targets) == 1 and isinstance(b.targets[0], ast.Name):
                fname = b.targets[0].id
                is_pk = fname.lower() in {"id", "pk"}
                fields.append((fname, "Any", is_pk))
        if fields:
            out.append(_ModelInfo(name=cls_name, file=py_file, fields=fields))
    return out

def _build_model_index(project_root: Path) -> dict[str, _ModelInfo]:
    model_files: set[Path] = set()
    try:
        for f in find_all_supported_files(project_root):
            if f.suffix.lower() != ".py":
                continue
            defs = extract_models_for_file(f, project_root) or []
            if defs:
                model_files.add(f.resolve())
    except Exception:
        pass
    if not model_files:
        try:
            for f in find_all_supported_files(project_root):
                if f.suffix.lower() != ".py":
                    continue
                parts = {p.lower() for p in f.parts}
                if parts & {"models", "model", "entity", "entities", "domain"}:
                    model_files.add(f.resolve())
        except Exception:
            pass
    idx: dict[str, _ModelInfo] = {}
    for mf in sorted(model_files):
        for mi in _extract_classes_fields_from_ast(mf):
            idx.setdefault(mi.name, mi)
    return idx

def _infer_forward_rels(model: _ModelInfo, model_names: set[str]) -> list[PyRel]:
    rels: list[PyRel] = []
    for fname, ftype, _pk in model.fields:
        if not fname or not ftype:
            continue
        is_coll, inner = _collection_inner(ftype)
        if is_coll:
            tgt = _normalize_ref_name(inner)
            if tgt and tgt in model_names and tgt != model.name and tgt not in _BUILTIN_TYPES:
                rels.append(PyRel(kind="OneToMany", target=tgt, field=fname, via="type"))
            continue
        base = _normalize_ref_name(ftype)
        if base and base in model_names and base != model.name and base not in _BUILTIN_TYPES:
            kind = "OneToOne" if fname.lower() in _EMBED_HINTS else "ManyToOne"
            rels.append(PyRel(kind=kind, target=base, field=fname, via="type"))
            continue
        if fname.endswith(_FK_SUFFIXES) or fname.lower().endswith("_id"):
            tgt = _fk_guess_target(fname, model_names)
            if tgt and tgt != model.name:
                rels.append(PyRel(kind="ManyToOne", target=tgt, field=fname, via="fk"))
    return rels

def _has_collection(rels_by_model: dict[str, list[PyRel]], src: str, dst: str) -> bool:
    return any(r.target == dst and r.kind in {"OneToMany", "ManyToMany"} for r in rels_by_model.get(src, []))

def _has_scalar(rels_by_model: dict[str, list[PyRel]], src: str, dst: str) -> bool:
    return any(r.target == dst and r.kind in {"ManyToOne", "OneToOne"} for r in rels_by_model.get(src, []))

def _upgrade_one_to_one(rels_by_model: dict[str, list[PyRel]]) -> None:
    for src, rels in list(rels_by_model.items()):
        upgraded: list[PyRel] = []
        for r in rels:
            if r.kind not in {"ManyToOne", "OneToOne"}:
                upgraded.append(r)
                continue
            dst = r.target
            if (_has_scalar(rels_by_model, dst, src) and not _has_collection(rels_by_model, src, dst) and not _has_collection(rels_by_model, dst, src)):
                upgraded.append(PyRel(kind="OneToOne", target=dst, field=r.field, via=r.via))
            else:
                upgraded.append(r)
        rels_by_model[src] = upgraded

def _upgrade_many_to_many(rels_by_model: dict[str, list[PyRel]]) -> None:
    for src, rels in list(rels_by_model.items()):
        newrels: list[PyRel] = []
        for r in rels:
            if r.kind != "OneToMany":
                newrels.append(r)
                continue
            dst = r.target
            if any(x.kind == "OneToMany" and x.target == src for x in rels_by_model.get(dst, [])):
                newrels.append(PyRel(kind="ManyToMany", target=dst, field=r.field, via=r.via))
            else:
                newrels.append(r)
        rels_by_model[src] = newrels

def python_collect_relationship_map(target: Path, project_root: Path):
    idx = _build_model_index(project_root)
    model_names = set(idx.keys())
    candidates = [m for m in idx.values() if m.file.resolve() == target.resolve()]
    if not candidates:
        return target.stem, [], [], {}, []
    stem = target.stem
    main = next((m for m in candidates if m.name.lower() == stem.lower()), candidates[0])
    model_name = main.name
    rels_by_model: dict[str, list[PyRel]] = {name: _infer_forward_rels(mi, model_names) for name, mi in idx.items()}
    _upgrade_one_to_one(rels_by_model)
    _upgrade_many_to_many(rels_by_model)
    forward = rels_by_model.get(model_name, [])
    fields_by_entity: dict[str, list[tuple[str, str, bool]]] = {}
    for r in forward:
        if r and r.target and r.target in idx:
            fields_by_entity[r.target] = idx[r.target].fields
    reverse: list[tuple[str, PyRel]] = []
    for src, rels in rels_by_model.items():
        if src == model_name:
            continue
        for r in rels:
            if r and r.target == model_name:
                reverse.append((src, PyRel(kind=r.kind, target=model_name, field=r.field, via=r.via)))
                if src in idx:
                    fields_by_entity.setdefault(src, idx[src].fields)
    reverse.sort(key=lambda x: (x[0].lower(), x[1].kind, x[1].field.lower()))
    return model_name, main.fields, forward, fields_by_entity, reverse