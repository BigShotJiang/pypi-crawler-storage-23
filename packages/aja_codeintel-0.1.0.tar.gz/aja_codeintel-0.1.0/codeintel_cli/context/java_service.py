from __future__ import annotations
from pathlib import Path
import re
from typing import Any

from ..scanner.scanner import find_all_supported_files
from ..context.java_rel import clean_java, top_type_name, java_fields_and_rels

_METHOD_RE = re.compile(
    r"^\s*(?:public|protected|private)?\s+(?:static\s+)?"
    r"([A-Za-z0-9_<>\[\].,?\s]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)",
    re.M,
)
_FIELD_RE = re.compile(
    r"^\s*(?:private|protected)\s+(?:final\s+)?"
    r"([A-Za-z0-9_<>,\s]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*;",
    re.M,
)
_MAPPING_RE = re.compile(
    r"@(Get|Post|Put|Delete|Patch|Request)Mapping"
    r"(?:"
    r"\(\s*(?:value|path)\s*=\s*[\"']([^\"']*)[\"'][^)]*\)"  # named: value="/path"
    r"|\(\s*[\"']([^\"']*)[\"']\s*\)"                         # positional: "/path"
    r"|\(\s*\)"                                                # empty parens: ()
    r"|(?=\s|$|@|\n)"                                         # bare: no parens at all
    r")",
    re.M,
)
_CLASS_MAPPING_RE = re.compile(
    r'@RequestMapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?["\']([^"\']*)["\']'
)
_CLASS_NAME_RE = re.compile(r"\bclass\s+([A-Za-z_][A-Za-z0-9_]*)\b")

_SKIP_TYPES   = {"void", "public", "private", "protected", "static", "final"}
_SKIP_METHODS = {"equals", "hashCode", "toString", "clone"}
_PRIMITIVES   = {"String", "Long", "Integer", "Boolean", "List", "Set", "Optional", "Page", "Object"}

_DEFAULT_REPO_METHODS = [
    "findById(ID) → Optional<T>",
    "save(T) → T",
    "findAll() → List<T>",
    "deleteById(ID)",
    "existsById(ID) → boolean",
]


def _extract_type_name(full_type: str) -> str:
    s = (full_type or "").strip()
    s = s.replace("java.util.", "").replace("org.springframework.", "")
    if "." in s:
        s = re.sub(r"\b\w+\.", "", s)
    return s


def _find_service_impl(service_file: Path, project_root: Path) -> Path | None:
    impl_name = service_file.stem + "Impl"
    for f in find_all_supported_files(project_root):
        if f.stem == impl_name and f.suffix.lower() == ".java":
            return f
    return None


def _find_controllers(project_root: Path, service_name: str) -> list[dict]:
    endpoints: list[dict] = []
    seen: set[tuple[str, str]] = set()

    for f in find_all_supported_files(project_root):
        if f.suffix.lower() != ".java":
            continue
        if "controller" not in {p.lower() for p in f.parts}:
            continue

        try:
            text = clean_java(f.read_text(encoding="utf-8", errors="ignore"))
        except OSError:
            continue

        if service_name not in text:
            continue

        m = _CLASS_NAME_RE.search(text)
        controller_class = m.group(1) if m else ""
        camel_class = controller_class[0].lower() + controller_class[1:] if controller_class else ""

        class_mapping = ""
        cm = _CLASS_MAPPING_RE.search(text)
        if cm:
            class_mapping = cm.group(1).rstrip("/")

        for mm in _MAPPING_RE.finditer(text):
            verb = mm.group(1)
            if not verb:
                continue

            verb = verb.upper()
            if verb == "REQUEST":
                continue  # @RequestMapping on class level — skip, already handled via class_mapping

            raw_path = mm.group(2) or mm.group(3) or ""
            if class_mapping:
                full_path = class_mapping if not raw_path else class_mapping + "/" + raw_path.lstrip("/")
            else:
                full_path = raw_path or "/"
            full_path = re.sub(r"/+", "/", full_path)

            next_chunk = text[mm.end(): mm.end() + 400]
            handler_match = re.search(
                r"(?:public|protected|private)[^(]*\s+([a-z][A-Za-z0-9_]*)\s*\(",
                next_chunk,
            ) or re.search(r"\s+([a-z][A-Za-z0-9_]*)\s*\(", next_chunk)

            if not handler_match:
                continue

            handler_name = handler_match.group(1)
            if handler_name in {controller_class, camel_class}:
                continue

            key = (verb, full_path)
            if key in seen:
                continue
            seen.add(key)

            endpoints.append({
                "method": verb,
                "path": full_path,
                "handler": f"{f.stem}.{handler_name}()",
            })

    return endpoints


def _find_models_used(text: str, project_root: Path) -> dict[str, Any]:
    model_names: set[str] = set()

    for match in re.finditer(r"import\s+[\w.]+\.(?:entity|model|domain)\.([A-Z]\w+);", text):
        model_names.add(match.group(1))

    for match in re.finditer(r"\b([A-Z][A-Za-z0-9_]+)\s+\w+\s*[;=]", text):
        name = match.group(1)
        if len(name) > 2 and not name.isupper() and name not in _PRIMITIVES:
            model_names.add(name)

    models: dict[str, Any] = {}
    entity_dirs = {"model", "models", "entity", "entities", "domain"}

    for model_name in model_names:
        for f in find_all_supported_files(project_root):
            if f.suffix.lower() != ".java" or f.stem != model_name:
                continue
            if not ({p.lower() for p in f.parts} & entity_dirs):
                continue
            try:
                fields, rels = java_fields_and_rels(f)
                if fields:
                    models[model_name] = {
                        "fields": fields,
                        "relationships": [
                            {"kind": r.kind, "target": r.target, "field": r.field}
                            for r in rels
                        ],
                    }
            except Exception:
                pass

    return models


def _find_repositories(text: str) -> list[dict]:
    repos: list[dict] = []

    for match in _FIELD_RE.finditer(text):
        ftype, fname = match.group(1), match.group(2)
        if "Repository" in ftype or "repository" in fname.lower():
            repo_name = _extract_type_name(ftype)
            if not any(r["name"] == repo_name for r in repos):
                repos.append({"name": repo_name, "methods": _DEFAULT_REPO_METHODS})

    for match in re.finditer(r"import\s+[\w.]+\.repository\.([A-Z]\w+Repository);", text):
        repo_name = match.group(1)
        if not any(r["name"] == repo_name for r in repos):
            repos.append({"name": repo_name, "methods": _DEFAULT_REPO_METHODS})

    return repos


def _extract_service_methods(text: str, class_name: str = "") -> list[dict]:
    methods: list[dict] = []
    seen_names: set[str] = set()

    for match in _METHOD_RE.finditer(text):
        raw_ret     = match.group(1).strip()
        method_name = match.group(2)
        params      = match.group(3).strip()

        if method_name in seen_names:
            continue
        if class_name and method_name == class_name:
            continue
        if method_name in _SKIP_METHODS:
            continue
        if method_name.startswith("set") and params:
            continue
        if method_name.startswith("get") and method_name.endswith("Service"):
            continue

        ret_type = _extract_type_name(raw_ret)
        if ret_type in _SKIP_TYPES:
            continue

        param_list: list[str] = []
        for p in params.split(","):
            p = p.strip()
            if not p:
                continue
            tokens = p.split()
            if len(tokens) >= 2:
                ptype = _extract_type_name(" ".join(tokens[:-1]))
                param_list.append(f"{ptype} {tokens[-1]}")

        seen_names.add(method_name)
        methods.append({
            "name":   method_name,
            "params": ", ".join(param_list),
            "return": ret_type if ret_type not in _SKIP_TYPES else "",
        })

    return methods


def analyze_java_service(service_file: Path, project_root: Path) -> dict:
    try:
        text = clean_java(service_file.read_text(encoding="utf-8", errors="ignore"))
    except OSError:
        text = ""

    service_name = top_type_name(text, service_file.stem)

    impl_text = text
    if "interface " in text:
        impl_file = _find_service_impl(service_file, project_root)
        if impl_file:
            try:
                impl_text = clean_java(impl_file.read_text(encoding="utf-8", errors="ignore"))
            except OSError:
                pass

    endpoints = _find_controllers(project_root, service_name)
    methods   = _extract_service_methods(text, service_name)
    models    = _find_models_used(impl_text, project_root)
    repos     = _find_repositories(impl_text)

    flow: list[str] = []
    if endpoints:
        ep = endpoints[0]
        flow.append(f"{ep['method']} {ep['path']}")
        flow.append("  ↓")
        flow.append(f"{ep['handler']}")
        flow.append("  ↓")
        if methods:
            m0  = methods[0]
            arg = m0["params"].split(",")[0].split()[-1] if m0["params"] else ""
            flow.append(f"{service_name}.{m0['name']}({arg + '...' if arg else ''})")
            flow.append("  ↓")
        if models:
            model_name = next(iter(models))
            flow.append(f"Uses {model_name} model")
            if models[model_name].get("relationships"):
                rel = models[model_name]["relationships"][0]
                flow.append(f"  (has {rel['kind']} → {rel['target']})")
            flow.append("  ↓")
        if repos:
            flow.append(f"{repos[0]['name']}.save()")
            flow.append("  ↓")
            if methods and methods[0].get("return"):
                flow.append(f"Returns: {methods[0]['return']}")

    return {
        "service_name": service_name,
        "endpoints":    endpoints,
        "methods":      methods,
        "models":       models,
        "repositories": repos,
        "flow":         flow,
        "summary": {
            "Endpoints":       len(endpoints),
            "Service methods": len(methods),
            "Models used":     len(models),
            "Repositories":    len(repos),
        },
    }