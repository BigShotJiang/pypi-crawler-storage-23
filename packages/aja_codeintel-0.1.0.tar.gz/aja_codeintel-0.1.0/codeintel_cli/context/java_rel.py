from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re


@dataclass(frozen=True)
class Rel:
    kind: str
    target: str
    field: str
    cascade: str | None = None
    fetch: str | None = None
    mapped_by: str | None = None
    join_table: str | None = None
    join_columns: list[str] | None = None


_TYPE_RE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
_RECORD_RE = re.compile(r"\brecord\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)")
_FIELD_RE = re.compile(
    r"^\s*(?:public|protected|private)?\s*(?:static\s+)?(?:final\s+)?([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=.*)?;"
)
_REL_ANNOS = {"OneToOne", "OneToMany", "ManyToMany", "ManyToOne"}
_ANN_START_RE = re.compile(r"^\s*@([A-Za-z_][A-Za-z0-9_]*)\b(.*)$")
_JOINCOL_NAME_RE = re.compile(r'name\s*=\s*"([^"]+)"')
_QUOTED_RE = re.compile(r'^["\'](.*)["\']$')

_DENY_FIELD_NAMES = {"return", "this", "true", "false", "null", "new", "super", "throw"}
_DENY_FIELD_TYPES = {"return", "throw"}


def clean_java(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//.*?$", "", text, flags=re.M)
    return text


def top_type_name(text: str, fallback: str) -> str:
    if not text:
        return fallback
    m = _TYPE_RE.search(text)
    return m.group(2) if m else fallback


def _collapse_annotations(text: str) -> str:
    lines = text.splitlines()
    result: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("@"):
            depth = stripped.count("(") - stripped.count(")")
            combined = stripped
            j = i + 1
            while depth > 0 and j < len(lines):
                nxt = lines[j].strip()
                combined = combined + " " + nxt
                depth += nxt.count("(") - nxt.count(")")
                j += 1
            result.append(combined)
            i = j
        else:
            result.append(line)
            i += 1
    return "\n".join(result)


def _split_record_params(sig: str) -> list[tuple[str, str]]:
    s = (sig or "").strip()
    if not s:
        return []
    parts: list[str] = []
    cur: list[str] = []
    depth = 0
    for ch in s:
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())

    out: list[tuple[str, str]] = []
    for p in parts:
        toks = p.split()
        if len(toks) >= 2:
            t = " ".join(toks[:-1]).strip()
            n = toks[-1].strip()
            if t and n:
                out.append((n, t))
    return out


def _strip_quotes(v: str | None) -> str | None:
    if not v:
        return None
    s = v.strip()
    m = _QUOTED_RE.match(s)
    if m:
        s = m.group(1).strip()
    return s or None


def _extract_arg_map(argstr: str) -> dict[str, str]:
    s = (argstr or "").strip()
    if not s:
        return {}
    out: dict[str, str] = {}
    cur: list[str] = []
    parts: list[str] = []
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())

    for p in parts:
        if not p:
            continue
        if "=" in p:
            k, v = p.split("=", 1)
            out[k.strip()] = v.strip()
        else:
            out["value"] = p.strip()
    return out


def _unwrap_java_type(t: str) -> str:
    s = (t or "").strip()
    if not s:
        return ""
    s = s.replace("java.util.", "")
    s = s.replace("javax.persistence.", "")
    s = s.replace("jakarta.persistence.", "")

    m_opt = re.match(r"^Optional\s*<\s*([^>]+)\s*>$", s)
    if m_opt:
        s = m_opt.group(1).strip()

    m_col = re.match(r"^(List|Set|Collection|Iterable)\s*<\s*([^>]+)\s*>$", s)
    if m_col:
        s = m_col.group(2).strip()

    if "." in s:
        s = s.split(".")[-1].strip()

    return s


def java_fields_and_rels(path: Path) -> tuple[list[tuple[str, str, bool]], list[Rel]]:
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return [], []

    text = clean_java(raw)
    if not text:
        return [], []

    mrec = _RECORD_RE.search(text)
    if mrec:
        params = mrec.group(2)
        flds = [(n, t, n.lower() == "id") for (n, t) in _split_record_params(params)]
        return flds, []

    text = _collapse_annotations(text)

    lines = text.splitlines()
    fields: list[tuple[str, str, bool]] = []
    rels: list[Rel] = []
    pending: list[tuple[str, dict[str, str], str]] = []
    pending_is_id = False

    for line in lines:
        s = line.strip()
        if not s:
            continue

        m = _ANN_START_RE.match(s)
        if m:
            name = m.group(1)
            rest = m.group(2).strip()
            full = rest
            if full.startswith("(") and full.endswith(")"):
                full = full[1:-1].strip()
            args = _extract_arg_map(full)
            if name == "Id":
                pending_is_id = True
            if name in _REL_ANNOS or name in {"JoinTable", "JoinColumn", "JoinColumns"}:
                pending.append((name, args, s))
            continue

        fm = _FIELD_RE.match(line)
        if not fm:
            pending.clear()
            pending_is_id = False
            continue

        ftype = fm.group(1).strip()
        fname = fm.group(2).strip()

        if not fname or fname.lower() in _DENY_FIELD_NAMES:
            pending.clear()
            pending_is_id = False
            continue
        if ftype.lower() in _DENY_FIELD_TYPES:
            pending.clear()
            pending_is_id = False
            continue

        is_pk = pending_is_id or fname.lower() == "id"
        fields.append((fname, ftype, is_pk))

        rel_kind: str | None = None
        rel_args: dict[str, str] = {}
        join_table: str | None = None
        join_cols: list[str] = []

        for aname, aargs, raw_line in pending:
            if aname in _REL_ANNOS:
                rel_kind = aname
                rel_args = aargs
            elif aname == "JoinTable":
                join_table = _strip_quotes(aargs.get("name") or aargs.get("value"))
                if not join_table:
                    mm = re.search(r'name\s*=\s*"([^"]+)"', raw_line)
                    if mm:
                        join_table = mm.group(1).strip()
            elif aname in {"JoinColumn", "JoinColumns"}:
                for mm in _JOINCOL_NAME_RE.finditer(raw_line):
                    join_cols.append(mm.group(1).strip())

        if rel_kind:
            target = _unwrap_java_type(ftype)
            if target:
                rels.append(
                    Rel(
                        kind=rel_kind,
                        target=target,
                        field=fname,
                        cascade=_strip_quotes(rel_args.get("cascade")),
                        fetch=_strip_quotes(rel_args.get("fetch")),
                        mapped_by=_strip_quotes(rel_args.get("mappedBy")),
                        join_table=join_table,
                        join_columns=join_cols or None,
                    )
                )

        pending.clear()
        pending_is_id = False

    return fields, rels


def model_fields_from_extractor(path: Path, project_root: Path) -> list[tuple[str, str, bool]]:
    try:
        from ..lang.router import extract_models_for_file

        defs = extract_models_for_file(path, project_root)
        if not defs:
            return []

        d0 = defs[0]
        out: list[tuple[str, str, bool]] = []

        for f in getattr(d0, "fields", []) or []:
            name = (getattr(f, "name", "") or "").strip()
            typ = (getattr(f, "type", "") or "").strip() or "Object"

            if not name:
                continue
            if name.lower() in _DENY_FIELD_NAMES:
                continue
            if typ.lower() in _DENY_FIELD_TYPES:
                continue

            out.append((name, typ, name.lower() == "id"))

        return out
    except Exception:
        return []