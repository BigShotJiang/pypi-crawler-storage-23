from __future__ import annotations
from pathlib import Path
import ast
import re
from typing import Any

from ..scanner.scanner import find_all_supported_files
from ..context.python_rel import python_collect_relationship_map

_ROUTE_DECORATORS = {"route", "get", "post", "put", "delete", "patch", "api_route", "app.route", "router.get", "router.post"}

def _extract_routes(tree: ast.AST) -> list[dict]:
    routes = []
    
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        
        for dec in node.decorator_list:
            route_info = _parse_route_decorator(dec)
            if route_info:
                route_info["handler"] = node.name
                routes.append(route_info)
                break
    
    return routes

def _parse_route_decorator(dec: ast.AST) -> dict | None:
    method = "GET"
    path = "/"
    
    if isinstance(dec, ast.Call):
        if isinstance(dec.func, ast.Attribute):
            attr_name = dec.func.attr.lower()
            if attr_name in {"get", "post", "put", "delete", "patch"}:
                method = attr_name.upper()
        elif isinstance(dec.func, ast.Name):
            func_name = dec.func.id.lower()
            if func_name in {"get", "post", "put", "delete", "patch"}:
                method = func_name.upper()
        
        if dec.args:
            first_arg = dec.args[0]
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                path = first_arg.value
    
    elif isinstance(dec, ast.Attribute):
        attr_name = dec.attr.lower()
        if attr_name in _ROUTE_DECORATORS:
            return {"method": method, "path": path}
    
    elif isinstance(dec, ast.Name):
        if dec.id.lower() in _ROUTE_DECORATORS:
            return {"method": method, "path": path}
    
    if path != "/":
        return {"method": method, "path": path}
    
    return None

def _extract_functions(tree: ast.AST) -> list[dict]:
    functions = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            if node.name.startswith("_"):
                continue
            
            params = []
            for arg in node.args.args:
                if arg.arg == "self":
                    continue
                param_type = "Any"
                if arg.annotation:
                    try:
                        param_type = ast.unparse(arg.annotation)
                    except Exception:
                        pass
                params.append(f"{arg.arg}: {param_type}")
            
            ret_type = ""
            if node.returns:
                try:
                    ret_type = ast.unparse(node.returns)
                except Exception:
                    pass
            
            functions.append({
                "name": node.name,
                "params": ", ".join(params),
                "return": ret_type,
            })
    
    return functions

def _find_models_used(tree: ast.AST, project_root: Path) -> dict[str, Any]:
    model_names = set()
    
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            name = node.id
            if name and name[0].isupper() and len(name) > 2:
                model_names.add(name)
    
    models = {}
    all_files = find_all_supported_files(project_root)
    
    for model_name in model_names:
        for f in all_files:
            if f.suffix.lower() != ".py":
                continue
            if f.stem.lower() != model_name.lower():
                continue
            parts = {p.lower() for p in f.parts}
            if not (parts & {"model", "models", "entity", "entities", "domain"}):
                continue
            
            try:
                _, fields, rels, _, _ = python_collect_relationship_map(f, project_root)
                if fields:
                    models[model_name] = {
                        "fields": fields,
                        "relationships": [
                            {"kind": r.kind, "target": r.target, "field": r.field}
                            for r in rels
                        ]
                    }
            except Exception:
                pass
    
    return models

def _find_repositories(tree: ast.AST) -> list[dict]:
    repos = []
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            target_name = ""
            if isinstance(node, ast.Assign) and node.targets:
                target = node.targets[0]
                if isinstance(target, ast.Name):
                    target_name = target.id
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name):
                    target_name = node.target.id
            
            if "repo" in target_name.lower() or "dal" in target_name.lower():
                methods = [
                    "get(id)",
                    "save(entity)",
                    "delete(id)",
                    "find_all()",
                    "find_by(**kwargs)",
                ]
                repos.append({"name": target_name, "methods": methods})
    
    return repos

def analyze_python_service(service_file: Path, project_root: Path) -> dict:
    try:
        code = service_file.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(code)
    except Exception:
        tree = ast.Module(body=[], type_ignores=[])
    
    service_name = service_file.stem
    
    routes = _extract_routes(tree)
    functions = _extract_functions(tree)
    models = _find_models_used(tree, project_root)
    repos = _find_repositories(tree)
    
    flow = []
    if routes:
        rt = routes[0]
        flow.append(f"{rt['method']} {rt['path']}")
        flow.append("  ↓")
        flow.append(f"{rt['handler']}()")
        flow.append("  ↓")
        if models:
            model_name = list(models.keys())[0]
            flow.append(f"Uses {model_name} model")
            if models[model_name].get("relationships"):
                rel = models[model_name]["relationships"][0]
                flow.append(f"  (has {rel['kind']} → {rel['target']})")
            flow.append("  ↓")
        if repos:
            flow.append(f"{repos[0]['name']}.save()")
    
    summary = {
        "Routes": len(routes),
        "Functions": len(functions),
        "Models used": len(models),
        "Data access": len(repos),
    }
    
    return {
        "service_name": service_name,
        "endpoints": routes,
        "methods": functions,
        "models": models,
        "repositories": repos,
        "flow": flow,
        "summary": summary,
    }