﻿from __future__ import annotations

from pathlib import Path
import typer

from ..graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ..graph.query import get_related
from ..parser.symbols import extract_classes_from_file, extract_funcs_from_file


def _path_to_module(path: Path, root: Path) -> str:
    rel = path.relative_to(root)
    parts = list(rel.parts)
    if parts and parts[-1] == "__init__.py":
        parts = parts[:-1]
    elif parts:
        parts[-1] = parts[-1][:-3]
    return ".".join(parts)


def _sym_lines_py(f: Path, root: Path, show_line: bool) -> tuple[list[str], set[str]]:
    out: list[str] = []
    imports: set[str] = set()
    mod = _path_to_module(f, root)

    for c in extract_classes_from_file(f):
        if c.name.startswith("_"):
            continue
        out.append(c.name if not show_line else f"{c.name} (line {c.lineno})")
        imports.add(f"from {mod} import {c.name}")

    for fn in extract_funcs_from_file(f):
        if fn.name.startswith("_") or fn.name.startswith("register_"):
            continue
        out.append(fn.name if not show_line else f"{fn.name} (line {fn.lineno})")
        imports.add(f"from {mod} import {fn.name}")

    return sorted(out), imports


def run_python_context(
    *,
    target: Path,
    root: Path,
    all_files: list[Path],
    depth: int,
    forward_only: bool,
    include_hubs: bool,
    line: bool,
) -> None:
    graph, dependents_count = build_graph_with_counts(all_files, root)

    hubs: set[Path] = set()
    if not include_hubs:
        hubs = get_hub_files_by_ratio(dependents_count, len(all_files), 0.5)

    scope = get_related(graph, target, depth, include_reverse=not forward_only, hubs=hubs)
    scope_files = sorted((scope - {target}))

    typer.echo("")
    typer.echo("CONTEXT")
    typer.echo(f"Target: {target.relative_to(root)}")
    typer.echo(f"Depth: {depth}  Mode: {'forward-only' if forward_only else 'forward+reverse'}")
    typer.echo("")

    imports_by_file: dict[Path, set[str]] = {}

    typer.echo("RELATED SYMBOLS")
    if not scope_files:
        typer.echo("  (none)")
        typer.echo("")
        return

    for f in scope_files:
        lines, imps = _sym_lines_py(f, root, line)
        if lines:
            typer.echo(f"• {f.relative_to(root)}")
            for x in lines:
                typer.echo(f"   {x}")
            typer.echo("")
        if imps:
            imports_by_file[f] = imps

    typer.echo("IMPORTS")
    all_imports = sorted({imp for s in imports_by_file.values() for imp in s})
    if all_imports:
        for imp in all_imports:
            typer.echo(f"  {imp}")
    else:
        typer.echo("  (none)")
    typer.echo("")
