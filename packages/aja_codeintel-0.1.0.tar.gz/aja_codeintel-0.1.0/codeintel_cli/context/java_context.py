﻿from __future__ import annotations

import re
from collections import deque
from pathlib import Path
import typer

from ..graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ..lang.router import extract_imports

TYPE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")


def _java_types_only(path: Path) -> list[str]:
    out: list[str] = []
    try:
        for line in path.read_text(errors="ignore").splitlines():
            m = TYPE.search(line)
            if m:
                kind = m.group(1)
                name = m.group(2)
                label = f"{name} ({kind})"
                if label not in out:
                    out.append(label)
    except Exception:
        return out
    return out


def _collect_java_imports(files: list[Path]) -> list[str]:
    acc: set[str] = set()
    for f in files:
        if f.suffix != ".java":
            continue
        for imp in extract_imports(f, "java"):
            acc.add(str(imp))
    return sorted(acc)


def _print_files_with_types(title: str, files: list[Path], root: Path) -> None:
    typer.echo(title)
    if not files:
        typer.echo("  (none)")
        typer.echo("")
        return

    any_printed = False
    for f in files:
        if f.suffix != ".java":
            continue
        types_ = _java_types_only(f)
        if not types_:
            continue
        any_printed = True
        typer.echo(f"• {f.relative_to(root)}")
        for t in types_:
            typer.echo(f"   {t}")
        typer.echo("")

    if not any_printed:
        typer.echo("  (none)")
        typer.echo("")
        return


def _print_imports(title: str, files: list[Path]) -> None:
    typer.echo(title)
    imps = _collect_java_imports(files)
    if imps:
        for x in imps:
            typer.echo(f"  {x}")
    else:
        typer.echo("  (none)")
    typer.echo("")


def _build_reverse_graph(graph: dict[Path, set[Path]]) -> dict[Path, set[Path]]:
    rev: dict[Path, set[Path]] = {}
    for src, deps in graph.items():
        for dep in deps:
            rev.setdefault(dep, set()).add(src)
    return rev


def _bfs_layers(
    graph: dict[Path, set[Path]],
    start: Path,
    depth: int,
    *,
    include_reverse: bool,
    hubs: set[Path],
) -> dict[int, set[Path]]:
    if depth <= 0:
        return {}

    rev = _build_reverse_graph(graph) if include_reverse else {}
    layers: dict[int, set[Path]] = {}
    visited: set[Path] = {start}

    q: deque[tuple[Path, int]] = deque()
    q.append((start, 0))

    while q:
        node, d = q.popleft()
        if d >= depth:
            continue

        neighbors: set[Path] = set()
        neighbors |= graph.get(node, set())
        if include_reverse:
            neighbors |= rev.get(node, set())

        for nb in neighbors:
            if nb in visited:
                continue
            if hubs and nb in hubs:
                continue
            visited.add(nb)
            nd = d + 1
            layers.setdefault(nd, set()).add(nb)
            q.append((nb, nd))

    return layers


def run_java_context(
    *,
    target: Path,
    root: Path,
    all_files: list[Path],
    depth: int,
    forward_only: bool,
    include_hubs: bool,
) -> None:
    graph, dependents_count = build_graph_with_counts(all_files, root)

    hubs: set[Path] = set()
    if not include_hubs:
        hubs = get_hub_files_by_ratio(dependents_count, len(all_files), 0.5)

    same_folder = sorted(
        f
        for f in all_files
        if f.suffix == ".java" and f.parent == target.parent and f != target
    )

    layers = _bfs_layers(
        graph,
        target,
        depth=max(depth, 1),
        include_reverse=not forward_only,
        hubs=hubs,
    )

    level1_files = sorted(layers.get(1, set()))
    level2_files = sorted(layers.get(2, set())) if depth >= 2 else []

    typer.echo("")
    typer.echo("CONTEXT")
    typer.echo(f"Target: {target.relative_to(root)}")
    typer.echo(f"Depth: {depth}  Mode: {'forward-only' if forward_only else 'forward+reverse'}")
    typer.echo("")

    typer.echo("TARGET IMPORTS")
    t_imps = extract_imports(target, "java")
    if t_imps:
        for x in t_imps:
            typer.echo(f"  {x}")
    else:
        typer.echo("  (none)")
    typer.echo("")

    _print_files_with_types("SAME FOLDER TYPES", same_folder, root)

    _print_files_with_types("RELATED LEVEL 1 TYPES", level1_files, root)
    _print_imports("RELATED LEVEL 1 IMPORTS", level1_files)

    if depth >= 2:
        _print_files_with_types("RELATED LEVEL 2 TYPES", level2_files, root)
        _print_imports("RELATED LEVEL 2 IMPORTS", level2_files)
