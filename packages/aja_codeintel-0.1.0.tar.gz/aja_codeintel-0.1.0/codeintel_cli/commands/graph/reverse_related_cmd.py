from __future__ import annotations

import typer

from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...graph.traverse import build_reverse_graph, bfs_related
from ...core.resolve_target import resolve_target_file
from ...db.cache import CacheManager


def register_rrelated(app: typer.Typer) -> None:
    @app.command(help="Show reverse-related files (who depends on this) using depth traversal.")
    def rrelated(
        file: str = typer.Argument(..., help="Target source file (path or filename)"),
        depth: int = typer.Option(2, "--depth", "-d", help="Traversal depth"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        use_sqlite_cache: bool = typer.Option(True, "--use-sqlite-cache/--no-sqlite-cache"),
    ):
        target_file, root_path = resolve_target_file(file)

        if use_sqlite_cache:
            with CacheManager(root_path) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                files = cache.get_cached_files()
        else:
            files = []
            for p in root_path.rglob("*"):
                if p.is_file() and p.suffix.lower() in {".py", ".java"}:
                    files.append(p.resolve())
            files = sorted(set(files))

        graph, dependents_count = build_graph_with_counts(
            files,
            root_path,
            use_sqlite_cache=use_sqlite_cache,
        )

        hubs: set = set()
        if not include_hubs:
            hubs = get_hub_files_by_ratio(dependents_count, len(files), 0.5)

        rev = build_reverse_graph(graph)
        rel = bfs_related(rev, target_file, depth, skip=hubs)

        if not rel:
            typer.echo("No reverse-related files.")
            raise typer.Exit(0)

        for p in sorted(rel):
            try:
                typer.echo(str(p.relative_to(root_path)))
            except Exception:
                typer.echo(str(p))