from __future__ import annotations
import typer

from .deps_cmd import register_deps
from .related_cmd import register_related
from .reverse_related_cmd import register_rrelated
from .relsymbols_cmd import register_relsymbols



def register_graph_commands(app: typer.Typer) -> None:
    register_deps(app)
    register_related(app)
    register_rrelated(app)
    register_relsymbols(app)

    

