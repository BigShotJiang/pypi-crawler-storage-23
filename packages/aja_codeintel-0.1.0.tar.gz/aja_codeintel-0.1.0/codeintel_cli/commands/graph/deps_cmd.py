﻿from __future__ import annotations

from pathlib import Path
import typer

from ...core.resolve_target import resolve_target_file
from ...scanner.scanner import find_all_supported_files
from ...graph.builder import build_graph_with_counts
from ...db.cache import CacheManager
from ...db.operations import get_deps_for_path

def register_deps(app: typer.Typer) -> None:
    @app.command("deps")
    def deps(
        file: str = typer.Argument(...),
        root: str = typer.Argument(".", show_default=False),
        use_sqlite_cache: bool = typer.Option(True, "--use-sqlite-cache/--no-sqlite-cache"),
    ):
        target_file, project_root = resolve_target_file(file, root)

        if use_sqlite_cache:
            with CacheManager(project_root) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                deps_list = get_deps_for_path(cache.conn, target_file) if cache.conn else []
        else:
            files = find_all_supported_files(project_root)
            graph, _ = build_graph_with_counts(files, project_root, use_sqlite_cache=False)
            deps_list = sorted(graph.get(target_file.resolve(), set()))

        for p in deps_list:
            try:
                typer.echo(Path(p).resolve().relative_to(project_root))
            except Exception:
                typer.echo(Path(p).resolve())