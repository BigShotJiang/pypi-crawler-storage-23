from __future__ import annotations

from collections import deque
from pathlib import Path
import typer

from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...core.resolve_target import resolve_target_file
from ...db.cache import CacheManager


def _layered_related(
    graph: dict[Path, set[Path]],
    start: Path,
    depth: int,
    include_reverse: bool,
    hubs: set[Path],
) -> list[list[Path]]:
    adj: dict[Path, set[Path]] = {k: set(v) for k, v in graph.items()}

    if include_reverse:
        rev: dict[Path, set[Path]] = {}
        for src, deps in adj.items():
            for dst in deps:
                rev.setdefault(dst, set()).add(src)
        for node, incoming in rev.items():
            adj.setdefault(node, set()).update(incoming)

    layers: list[list[Path]] = []
    visited: set[Path] = {start}
    q: deque[tuple[Path, int]] = deque([(start, 0)])
    by_depth: dict[int, list[Path]] = {}

    while q:
        node, d = q.popleft()
        if d == depth:
            continue

        for nxt in adj.get(node, set()):
            if nxt in visited:
                continue
            if nxt in hubs:
                continue
            visited.add(nxt)
            nd = d + 1
            by_depth.setdefault(nd, []).append(nxt)
            q.append((nxt, nd))

    for d in range(1, depth + 1):
        items = sorted(by_depth.get(d, []))
        layers.append(items)

    return layers


def register_related(app: typer.Typer) -> None:
    @app.command(help="Show related files using depth traversal (layered).")
    def related(
        file: str = typer.Argument(...),
        root: str = typer.Argument("."),
        depth: int = typer.Option(2, "--depth", "-d"),
        forward_only: bool = typer.Option(False, "--forward-only"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        use_sqlite_cache: bool = typer.Option(True, "--use-sqlite-cache/--no-sqlite-cache"),
    ):
        target, root_path = resolve_target_file(file, root=root)

        if use_sqlite_cache:
            with CacheManager(root_path) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                files = cache.get_cached_files()
        else:
            files = []
            for p in root_path.rglob("*"):
                if p.is_file() and p.suffix.lower() in {".py", ".java"}:
                    files.append(p.resolve())
            files = sorted(set(files))

        graph, dependents_count = build_graph_with_counts(
            files,
            root_path,
            use_sqlite_cache=use_sqlite_cache,
        )

        hubs: set[Path] = set()
        if not include_hubs:
            hubs = get_hub_files_by_ratio(dependents_count, len(files), 0.5)

        layers = _layered_related(
            graph=graph,
            start=target,
            depth=depth,
            include_reverse=not forward_only,
            hubs=hubs,
        )

        total = sum(len(x) for x in layers)
        if total == 0:
            typer.echo("No related files.")
            raise typer.Exit(0)

        typer.echo(f"TARGET: {target.relative_to(root_path)}")
        typer.echo(f"DEPTH: {depth} ({'forward-only' if forward_only else 'forward+reverse'})")
        typer.echo(f"FILES: {total}")
        typer.echo("")

        for i, items in enumerate(layers, 1):
            typer.echo(f"LEVEL {i} ({len(items)})")
            if not items:
                typer.echo("  (none)")
                typer.echo("")
                continue

            for p in items:
                try:
                    typer.echo(f"  {p.relative_to(root_path)}")
                except Exception:
                    typer.echo(f"  {p}")

            typer.echo("")