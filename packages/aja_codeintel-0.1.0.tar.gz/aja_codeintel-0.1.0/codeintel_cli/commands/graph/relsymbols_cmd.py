from __future__ import annotations

from collections import deque
from pathlib import Path
import re
import typer

from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...parser.symbols import extract_classes_from_file, extract_funcs_from_file
from ...core.resolve_target import resolve_target_file
from ...db.cache import CacheManager


_JAVA_TYPE_RE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
_JAVA_METHOD_RE = re.compile(
    r"^\s*(?:@\w+(?:\([^)]*\))?\s*)*(?:public|protected|private)\s+(?:static\s+)?"
    r"(?:final\s+)?([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*"
)


def _detect_lang(p: Path) -> str:
    return "java" if p.suffix.lower() == ".java" else "python"


def _short_path(p: Path, root: Path) -> str:
    try:
        return str(p.relative_to(root))
    except Exception:
        return str(p)


def _java_types(path: Path) -> dict[str, list[str]]:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"class": [], "interface": [], "enum": [], "record": []}

    out: dict[str, list[str]] = {"class": [], "interface": [], "enum": [], "record": []}
    seen: set[str] = set()

    for line in text.splitlines():
        m = _JAVA_TYPE_RE.search(line)
        if not m:
            continue
        kind = m.group(1)
        name = m.group(2)
        key = f"{kind}:{name}"
        if key in seen:
            continue
        seen.add(key)
        out.setdefault(kind, []).append(name)

    return out


def _java_methods(path: Path) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        return []

    out: list[str] = []
    seen: set[str] = set()

    for line in lines:
        s = line.strip()
        if not s:
            continue
        if s.startswith(("class ", "interface ", "record ", "enum ")):
            continue
        m = _JAVA_METHOD_RE.match(line)
        if not m:
            continue
        ret = m.group(1).strip()
        name = m.group(2).strip()
        args = m.group(3).strip()
        sig = f"{name}({args}) → {ret}"
        if sig not in seen:
            seen.add(sig)
            out.append(sig)

    return out


def _py_symbols(path: Path) -> tuple[list[str], list[str]]:
    classes: list[str] = []
    funcs: list[str] = []

    for c in extract_classes_from_file(path):
        if not c.name.startswith("_"):
            classes.append(c.name)

    for fn in extract_funcs_from_file(path):
        if fn.name.startswith("_") or fn.name.startswith("register_"):
            continue
        funcs.append(fn.signature)

    return classes, funcs


def _build_layers(
    graph: dict[Path, set[Path]],
    start: Path,
    depth: int,
    *,
    include_reverse: bool,
    hubs: set[Path],
) -> dict[int, list[Path]]:
    adj: dict[Path, set[Path]] = {k: set(v) for k, v in graph.items()}

    if include_reverse:
        rev: dict[Path, set[Path]] = {}
        for src, deps in adj.items():
            for dst in deps:
                rev.setdefault(dst, set()).add(src)
        for node, incoming in rev.items():
            adj.setdefault(node, set()).update(incoming)

    visited: set[Path] = {start}
    q: deque[tuple[Path, int]] = deque([(start, 0)])
    by_depth: dict[int, list[Path]] = {}

    while q:
        node, d = q.popleft()
        if d >= depth:
            continue

        for nxt in adj.get(node, set()):
            if nxt in visited:
                continue
            if hubs and nxt in hubs:
                continue
            visited.add(nxt)
            nd = d + 1
            by_depth.setdefault(nd, []).append(nxt)
            q.append((nxt, nd))

    for k in list(by_depth.keys()):
        by_depth[k] = sorted(set(by_depth[k]))

    return by_depth


def _print_java_target(path: Path, root: Path, *, all: bool) -> None:
    typer.echo(f"TARGET: {_short_path(path, root)}")
    typer.echo("")

    types_map = _java_types(path)
    methods = _java_methods(path)

    if types_map["interface"]:
        typer.echo("INTERFACES")
        for n in types_map["interface"]:
            typer.echo(f"  {n}")
        typer.echo("")

    if all:
        if types_map["class"]:
            typer.echo("CLASSES")
            for n in types_map["class"]:
                typer.echo(f"  {n}")
            typer.echo("")

        if types_map["record"]:
            typer.echo("RECORDS")
            for n in types_map["record"]:
                typer.echo(f"  {n}")
            typer.echo("")

        if types_map["enum"]:
            typer.echo("ENUMS")
            for n in types_map["enum"]:
                typer.echo(f"  {n}")
            typer.echo("")

        if methods:
            typer.echo("METHODS")
            for m in methods:
                typer.echo(f"  {m}")
            typer.echo("")

    if not types_map["interface"] and not (
        all and (types_map["class"] or types_map["enum"] or types_map["record"] or methods)
    ):
        typer.echo("(no symbols)")
        typer.echo("")


def _print_python_target(path: Path, root: Path) -> None:
    typer.echo(f"TARGET: {_short_path(path, root)}")
    typer.echo("")

    classes, funcs = _py_symbols(path)

    if classes:
        typer.echo("CLASSES")
        for c in classes:
            typer.echo(f"  {c}")
        typer.echo("")

    if funcs:
        typer.echo("FUNCTIONS")
        for f in funcs:
            typer.echo(f"  {f}")
        typer.echo("")

    if not classes and not funcs:
        typer.echo("(no symbols)")
        typer.echo("")


def _print_java_related(path: Path, root: Path, *, all: bool) -> None:
    typer.echo(_short_path(path, root))

    types_map = _java_types(path)

    if types_map["interface"]:
        typer.echo("  INTERFACES")
        for n in types_map["interface"]:
            typer.echo(f"    {n}")

    if all:
        if types_map["class"]:
            typer.echo("  CLASSES")
            for n in types_map["class"]:
                typer.echo(f"    {n}")

        if types_map["record"]:
            typer.echo("  RECORDS")
            for n in types_map["record"]:
                typer.echo(f"    {n}")

        if types_map["enum"]:
            typer.echo("  ENUMS")
            for n in types_map["enum"]:
                typer.echo(f"    {n}")

        methods = _java_methods(path)
        if methods:
            typer.echo("  METHODS")
            for m in methods:
                typer.echo(f"    {m}")

    typer.echo("")


def _print_python_related(path: Path, root: Path) -> None:
    typer.echo(_short_path(path, root))

    classes, funcs = _py_symbols(path)

    if classes:
        typer.echo("  CLASSES")
        for c in classes:
            typer.echo(f"    {c}")

    if funcs:
        typer.echo("  FUNCTIONS")
        for f in funcs:
            typer.echo(f"    {f}")

    typer.echo("")


def register_relsymbols(app: typer.Typer) -> None:
    @app.command(help="Show related classes/functions/interfaces")
    def relsymbols(
        file: str = typer.Argument(...),
        root: str = typer.Argument("."),
        depth: int = typer.Option(1, "--depth", "-d"),
        forward_only: bool = typer.Option(False, "--forward-only"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        all: bool = typer.Option(False, "--all", help="Show all symbols (Java: classes+methods, Python: unchanged)"),
        use_sqlite_cache: bool = typer.Option(True, "--use-sqlite-cache/--no-sqlite-cache"),
    ):
        target, root_path = resolve_target_file(file, root=root)

        if use_sqlite_cache:
            with CacheManager(root_path) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                files = cache.get_cached_files()
        else:
            files = []
            for p in root_path.rglob("*"):
                if p.is_file() and p.suffix.lower() in {".py", ".java"}:
                    files.append(p.resolve())
            files = sorted(set(files))

        graph, dependents_count = build_graph_with_counts(
            files,
            root_path,
            use_sqlite_cache=use_sqlite_cache,
        )

        hubs: set[Path] = set()
        if not include_hubs:
            hubs = get_hub_files_by_ratio(dependents_count, len(files), 0.5)

        depth = max(1, depth)

        layers = _build_layers(
            graph=graph,
            start=target,
            depth=depth,
            include_reverse=not forward_only,
            hubs=hubs,
        )

        lang = _detect_lang(target)
        if lang == "java":
            _print_java_target(target, root_path, all=all)
        else:
            _print_python_target(target, root_path)

        printed_any = False

        for lvl in sorted(layers.keys()):
            items = layers[lvl]
            if not items:
                continue

            printed_any = True
            typer.echo(f"LEVEL {lvl}")
            typer.echo("")

            for item_path in items:
                if item_path.name == "__init__.py":
                    continue

                item_lang = _detect_lang(item_path)

                if item_lang == "java":
                    types_map = _java_types(item_path)
                    if not types_map["interface"] and not (
                        all and (types_map["class"] or types_map["enum"] or types_map["record"])
                    ):
                        continue
                    _print_java_related(item_path, root_path, all=all)
                else:
                    classes, funcs = _py_symbols(item_path)
                    if not classes and not funcs:
                        continue
                    _print_python_related(item_path, root_path)

        if not printed_any:
            typer.echo("(no related symbols)")