﻿from __future__ import annotations

import typer

from ...errors import InvalidPathError
from ...core.where import file_to_module
from ...core.resolve_target import resolve_target_file


def register_where(app: typer.Typer) -> None:
    @app.command(help="Convert file path (or filename) to import path.")
    def where(
        file: str = typer.Argument(..., help="File path OR filename like 'imports.py' or 'UserService.java'"),
    ):
        target, root_path = resolve_target_file(file)

        mod = file_to_module(target, root_path)
        if not mod:
            raise InvalidPathError(message="Cannot convert to module path", path=target)

        typer.echo(mod)
