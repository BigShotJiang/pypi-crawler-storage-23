from __future__ import annotations
from pathlib import Path
import typer

from ...core.resolve_target import resolve_target_file
from ...core.project import find_project_root


def _format_for_ai(files_content: list[tuple[Path, str]], root: Path) -> str:
    lines: list[str] = []
    
    lines.append("=" * 80)
    lines.append(f"COPIED {len(files_content)} FILE(S)")
    lines.append("=" * 80)
    lines.append("")
    
    for i, (path, content) in enumerate(files_content, 1):
        try:
            rel_path = path.relative_to(root)
        except Exception:
            rel_path = path
        
        file_name = path.name
        full_path = rel_path.as_posix()
        lang = "java" if path.suffix == ".java" else "python"
        line_count = content.count("\n") + 1
        
        lines.append("=" * 80)
        lines.append(f"FILE {i}/{len(files_content)}: {file_name}")
        lines.append(f"Path: {full_path}")
        lines.append(f"Lines: {line_count}")
        lines.append("=" * 80)
        lines.append("")
        lines.append(f"```{lang}")
        lines.append(content.rstrip())
        lines.append("```")
        lines.append("")
    
    return "\n".join(lines)


def register_copy(app: typer.Typer) -> None:
    @app.command(help="Copy file(s) contents to clipboard")
    def copy(
        files: list[str] = typer.Argument(..., help="File(s) to copy"),
        root: str = typer.Option(".", "--root", "-r"),
        raw: bool = typer.Option(False, "--raw", help="Raw content without formatting"),
    ) -> None:
        try:
            import pyperclip
        except ImportError:
            typer.echo("Error: pyperclip not installed")
            typer.echo("Install: pip install pyperclip")
            raise typer.Exit(1)

        root_path = Path(root).resolve()
        project_root = find_project_root(root_path)
        
        files_content: list[tuple[Path, str]] = []
        total_lines = 0
        total_chars = 0

        for file_query in files:
            try:
                target, _ = resolve_target_file(file_query, root=str(project_root))
            except Exception as e:
                typer.echo(f"✗ Could not find: {file_query}")
                continue

            try:
                content = target.read_text(encoding="utf-8", errors="ignore")
            except Exception as e:
                typer.echo(f"✗ Error reading {target.name}: {e}")
                continue

            files_content.append((target, content))
            total_lines += content.count("\n") + 1
            total_chars += len(content)

        if not files_content:
            typer.echo("✗ No files copied")
            raise typer.Exit(1)

        if raw:
            combined = "\n\n".join(content for _, content in files_content)
        else:
            combined = _format_for_ai(files_content, project_root)

        try:
            pyperclip.copy(combined)
        except Exception as e:
            typer.echo(f"✗ Error copying to clipboard: {e}")
            raise typer.Exit(1)

        typer.echo(f"✓ Copied {len(files_content)} file(s) to clipboard")
        typer.echo("")
        for path, content in files_content:
            lines = content.count("\n") + 1
            typer.echo(f"  • {path.name} ({lines:,} lines)")
        typer.echo("")
        typer.echo(f"Total: {total_lines:,} lines, {total_chars:,} characters")