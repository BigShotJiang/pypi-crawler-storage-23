from __future__ import annotations

import typer

from ...core.opener import open_file
from ...core.resolve_target import resolve_target_file


def register_open(app: typer.Typer) -> None:
    @app.command(help="Open a file by name or partial path (project-local).")
    def open(
        query: str = typer.Argument(..., help="Example: 'imports.py' or 'parser/imports.py'"),
        yes: bool = typer.Option(False, "--yes", "-y", help="Open without confirmation"),
    ):
        target, _root = resolve_target_file(query)

        if yes or typer.confirm(f"Open this file?\n{target}"):
            open_file(target)
