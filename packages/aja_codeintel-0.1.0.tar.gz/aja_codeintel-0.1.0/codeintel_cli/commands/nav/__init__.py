from __future__ import annotations
import typer

from .copy_cmd import register_copy
from .open_cmd import register_open
from .where_cmd import register_where


def register_nav_commands(app: typer.Typer) -> None:
    register_copy(app)
    register_open(app)
    register_where(app)