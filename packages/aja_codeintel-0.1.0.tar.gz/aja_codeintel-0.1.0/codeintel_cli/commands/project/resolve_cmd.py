from __future__ import annotations

from pathlib import Path
import typer

from ...parser.resolve import resolve_module_to_file
from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...core.resolve_target import resolve_target_file


def register_resolve(app: typer.Typer) -> None:
    @app.command(help="Resolve a module path or filename to a project file.")
    def resolve(
        target: str = typer.Argument(..., help="Module path or filename"),
    ):
        root = find_project_root(Path.cwd())

        mod_hit = resolve_module_to_file(target, root)
        if mod_hit:
            typer.echo(mod_hit.resolve().relative_to(root))
            return

        file_hit, root = resolve_target_file(target)
        if file_hit.exists():
            typer.echo(file_hit.resolve().relative_to(root))
            return

        raise InvalidPathError(message="Not found", path=Path(target))
