from __future__ import annotations
from pathlib import Path
import time
import typer

from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...db.cache import get_cache

def validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder

def register_scan(app: typer.Typer) -> None:
    @app.command(help="Scan and index project files")
    def scan(
        path: str = typer.Argument(".", help="Folder to scan"),
        verbose: bool = typer.Option(False, "--verbose", "-v", help="Show progress"),
        force: bool = typer.Option(False, "--force", "-f", help="Force rescan all files"),
    ):
        folder = validate_folder(path)
        project_root = find_project_root(folder)
        
        start_time = time.perf_counter()
        
        with get_cache(project_root) as cache:
            if not force and not cache.needs_rescan():
                files = cache.get_cached_files()
                elapsed = time.perf_counter() - start_time
                py_count = sum(1 for f in files if f.suffix == ".py")
                java_count = sum(1 for f in files if f.suffix == ".java")
                typer.echo(f"✓ Cache up to date")
                typer.echo(f"Cached {len(files)} files (py={py_count}, java={java_count}) in {elapsed:.3f}s")
                typer.echo(f"Database: {cache.db_path}")
                return
            
            if verbose:
                typer.echo(f"Scanning: {project_root}")
            
            scanned = cache.scan_project(verbose=verbose)
            files = cache.get_cached_files()
            elapsed = time.perf_counter() - start_time
            
            py_count = sum(1 for f in files if f.suffix == ".py")
            java_count = sum(1 for f in files if f.suffix == ".java")
            
            typer.echo(f"✓ Indexed {scanned} files")
            typer.echo(f"Total {len(files)} files (py={py_count}, java={java_count}) in {elapsed:.3f}s")
            typer.echo(f"Database: {cache.db_path}")