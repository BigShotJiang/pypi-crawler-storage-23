﻿from __future__ import annotations

from pathlib import Path
import typer

from ...errors import InvalidPathError
from ...parser.imports import extract_imports_from_file
from ...core.resolve_target import resolve_target_file


def _java_imports(path: Path) -> list[str]:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    out: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("import "):
            continue
        if s.startswith("import static "):
            continue
        s = s.removeprefix("import ").rstrip(";").strip()
        if not s or s.endswith(".*"):
            continue
        out.append(s)
    return out


def register_imports(app: typer.Typer) -> None:
    @app.command(help="Print local imports found in a file (python/java).")
    def imports(
        file: str = typer.Argument(..., help="File or fuzzy name (.py or .java)."),
        java_stdlib: bool = typer.Option(
            False,
            "--java-stdlib",
            help="Include Java/JDK imports (java.*, javax.*, jakarta.*, etc.).",
        ),
    ):
        q = (file or "").strip()
        if not q:
            raise InvalidPathError(message="File not found", path=Path(file))

        target, _ = resolve_target_file(q)

        if not target.exists() or not target.is_file():
            raise InvalidPathError(message="File not found", path=target)

        ext = target.suffix.lower()

        if ext == ".py":
            mods = extract_imports_from_file(target)
            rels = [(m, lvl) for (m, lvl) in mods if lvl > 0]

            if not rels:
                typer.echo("No local relative imports found.")
                raise typer.Exit(0)

            for module, level in rels:
                dots = "." * level
                typer.echo(f"{dots}{module}" if module else dots)
            return

        if ext == ".java":
            imps = _java_imports(target)

            if not java_stdlib:
                imps = [
                    x
                    for x in imps
                    if not (
                        x.startswith("java.")
                        or x.startswith("javax.")
                        or x.startswith("jakarta.")
                        or x.startswith("org.junit.")
                        or x.startswith("org.springframework.")
                    )
                ]

            if not imps:
                typer.echo("No Java imports found.")
                raise typer.Exit(0)

            for x in imps:
                typer.echo(x)
            return

        typer.echo("Unsupported file type. Use .py or .java.")
        raise typer.Exit(2)
