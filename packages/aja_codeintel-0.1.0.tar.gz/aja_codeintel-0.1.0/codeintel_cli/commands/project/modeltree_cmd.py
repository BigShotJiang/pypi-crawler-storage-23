﻿from __future__ import annotations

from collections import deque
from pathlib import Path
import subprocess
import sys
import typer

from ...errors import InvalidPathError
from ...core.resolve_model_target import resolve_model_target_file as _resolve_model_target_file
from ...lang.java.resolve import resolve_java_import_to_file
from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...context.java_rel import (
    clean_java,
    top_type_name,
    java_fields_and_rels,
    model_fields_from_extractor,
    Rel,
)
from ...context.python_rel import python_collect_relationship_map
from ...db.cache import CacheManager

VIEWS = ["compact", "tree", "pretty", "flow", "db"]


def _get_cached_files(project_root: Path) -> list[Path]:
    with CacheManager(project_root) as cache:
        if cache.needs_rescan():
            cache.scan_project(verbose=False)
        return [p.resolve() for p in cache.get_cached_files()]


def _fmt_fields(fields: list[tuple[str, str, bool]], indent: str = "  ") -> list[str]:
    out: list[str] = []
    for n, t, pk in fields:
        out.append(f"{indent}- {n}: {t}" + (" (PK)" if pk else ""))
    return out


def _rel_label(kind: str) -> str:
    return {"OneToOne": "1:1", "OneToMany": "1:N", "ManyToMany": "N:M", "ManyToOne": "N:1"}.get(kind, kind)


def _rel_meta(r: Rel) -> str:
    parts: list[str] = []
    if r.mapped_by:
        parts.append(f"mappedBy={r.mapped_by}")
    if r.join_table:
        parts.append(f"joinTable={r.join_table}")
    if r.join_columns:
        parts.append("joinCols=" + ",".join(r.join_columns))
    return (" [" + "; ".join(parts) + "]") if parts else ""


def _box(body: list[str]) -> list[str]:
    w = max([len(x) for x in body] + [0])
    top = "┌" + "─" * (w + 2) + "┐"
    sep = "├" + "─" * (w + 2) + "┤"
    bot = "└" + "─" * (w + 2) + "┘"
    lines = [top, sep]
    for x in body:
        lines.append("│ " + x.ljust(w) + " │")
    lines.append(bot)
    return lines


def _default_outfile(root: Path, name: str) -> Path:
    base = root / f"codeintel-modeltree-{name}.txt"
    if not base.exists():
        return base
    i = 2
    while True:
        p = root / f"codeintel-modeltree-{name}-{i}.txt"
        if not p.exists():
            return p
        i += 1


def _open_in_editor(path: Path) -> None:
    p = path.resolve()
    try:
        from ...core.opener import open_file

        open_file(p)
        return
    except Exception:
        pass
    try:
        subprocess.Popen(["code", str(p)], close_fds=True)
        return
    except Exception:
        pass
    try:
        if sys.platform.startswith("win"):
            subprocess.Popen(["cmd", "/c", "start", "", str(p)], close_fds=True)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(p)], close_fds=True)
        else:
            subprocess.Popen(["xdg-open", str(p)], close_fds=True)
    except Exception:
        pass


def _is_domain_model_path(p: Path) -> bool:
    parts = {x.lower() for x in p.parts}
    return bool(parts & {"model", "models", "entity", "entities", "domain"})


def _java_model_annotation_hint(path: Path) -> bool:
    try:
        t = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    return any(x in t for x in ("@Entity", "@Table", "@Embeddable", "@MappedSuperclass"))


def _has_class_definition(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        return "class " in text and len(text.strip()) > 50
    except Exception:
        return False


def _is_java_model_file(p: Path) -> bool:
    if p.suffix.lower() != ".java":
        return False
    if p.name == "__init__.py":
        return False
    if not (_is_domain_model_path(p) or _java_model_annotation_hint(p)):
        return False
    return _has_class_definition(p)


def _is_python_model_file(p: Path) -> bool:
    if p.suffix.lower() != ".py":
        return False
    if p.name in {"__init__.py", "models.py"}:
        return False
    if not _is_domain_model_path(p):
        return False
    return _has_class_definition(p)


def _choose_view_interactive(default: str = "tree") -> str:
    typer.echo("Select view:")
    for i, v in enumerate(VIEWS, 1):
        typer.echo(f"{i}. {v}")
    pick = typer.prompt("Enter number", type=int, default=VIEWS.index(default) + 1)
    if 1 <= pick <= len(VIEWS):
        return VIEWS[pick - 1]
    return default


def _layered_related(
    graph: dict[Path, set[Path]],
    start: Path,
    depth: int,
    include_reverse: bool,
    hubs: set[Path],
) -> list[list[Path]]:
    adj: dict[Path, set[Path]] = {k: set(v) for k, v in graph.items()}
    if include_reverse:
        rev: dict[Path, set[Path]] = {}
        for src, deps in adj.items():
            for dst in deps:
                rev.setdefault(dst, set()).add(src)
        for node, incoming in rev.items():
            adj.setdefault(node, set()).update(incoming)

    visited: set[Path] = {start}
    q: deque[tuple[Path, int]] = deque([(start, 0)])
    by_depth: dict[int, list[Path]] = {}

    while q:
        node, d = q.popleft()
        if d == depth:
            continue
        for nxt in adj.get(node, set()):
            if nxt in visited or nxt in hubs:
                continue
            visited.add(nxt)
            nd = d + 1
            by_depth.setdefault(nd, []).append(nxt)
            q.append((nxt, nd))

    return [sorted(by_depth.get(i, [])) for i in range(1, depth + 1)]


def _file_for_java_class(name: str, scope: list[Path], root: Path) -> Path | None:
    if not name:
        return None
    exact = [p for p in scope if p.suffix.lower() == ".java" and p.stem == name]
    if exact:
        return exact[0].resolve()
    try:
        p = resolve_java_import_to_file(name, root)
        if p and p.exists():
            return p.resolve()
    except Exception:
        pass
    return None


def _java_model_scope_from_files(files: list[Path]) -> list[Path]:
    return [p.resolve() for p in files if _is_java_model_file(p)]


def _collect_java_relationship_map(
    target: Path,
    project_root: Path,
    depth: int,
    forward_only: bool,
    include_hubs: bool,
):
    all_files = _get_cached_files(project_root)

    graph, dep_counts = build_graph_with_counts(all_files, project_root, use_sqlite_cache=True)

    hubs: set[Path] = set()
    if not include_hubs:
        hubs = get_hub_files_by_ratio(dep_counts, len(all_files), 0.5)

    layers = _layered_related(
        graph=graph,
        start=target.resolve(),
        depth=depth,
        include_reverse=not forward_only,
        hubs=hubs,
    )

    model_files = set(_java_model_scope_from_files(all_files))
    scope: list[Path] = []
    for layer in layers:
        for p in layer:
            rp = p.resolve()
            if rp in model_files:
                scope.append(rp)

    try:
        text = clean_java(target.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        text = ""

    model_name = top_type_name(text, target.stem)
    main_fields, main_rels = java_fields_and_rels(target)

    fields_by_entity: dict[str, list[tuple[str, str, bool]]] = {}
    for r in main_rels:
        if not r or not r.target:
            continue
        p = _file_for_java_class(r.target, scope + [target], project_root)
        if p and p.exists():
            flds = model_fields_from_extractor(p, project_root)
            if not flds:
                flds, _ = java_fields_and_rels(p)
            if flds:
                fields_by_entity[r.target] = flds

    reverse: list[tuple[str, Rel]] = []
    for p in model_files:
        if p.resolve() == target.resolve():
            continue
        try:
            t = clean_java(p.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            continue
        src_name = top_type_name(t, p.stem)
        _, rels = java_fields_and_rels(p)
        for rr in rels:
            if rr and rr.target == model_name:
                reverse.append((src_name, rr))
                if src_name not in fields_by_entity:
                    flds = model_fields_from_extractor(p, project_root)
                    if not flds:
                        flds, _ = java_fields_and_rels(p)
                    if flds:
                        fields_by_entity[src_name] = flds

    reverse.sort(key=lambda x: (x[0].lower(), x[1].kind, x[1].field.lower()))
    return model_name, main_fields, main_rels, fields_by_entity, reverse


def _view_compact(model: str, fields, rels, reverse) -> list[str]:
    lines: list[str] = [model]
    lines.extend(_fmt_fields(fields))
    lines.append("")
    lines.append("Direct relationships:")
    if not rels:
        lines.append("  (none)")
    else:
        for r in rels:
            lines.append(f"  - @{r.kind} -> {r.target} (field: {r.field}){_rel_meta(r)}")
    lines.append("")
    lines.append("Reverse relationships:")
    if not reverse:
        lines.append("  (none)")
    else:
        for src, r in reverse:
            lines.append(f"  - {src} -> {model} (@{r.kind} via {r.field}){_rel_meta(r)}")
    return lines


def _view_tree(model: str, fields, rels, fields_by, reverse) -> list[str]:
    lines: list[str] = [model, "├─ Fields"]
    for i, (n, t, pk) in enumerate(fields):
        end = "└─" if i == len(fields) - 1 else "├─"
        lines.append(f"│  {end} {n}: {t}" + (" (PK)" if pk else ""))
    lines.append("│")

    groups: dict[str, list] = {}
    for r in rels:
        groups.setdefault(r.kind, []).append(r)

    order = ["OneToOne", "OneToMany", "ManyToMany", "ManyToOne"]
    kinds = [k for k in order if k in groups]

    if not kinds:
        lines.append("└─ Relationships")
        lines.append("   └─ (none)")
    else:
        for ki, kind in enumerate(kinds):
            last_kind = ki == len(kinds) - 1
            kbranch = "└─" if last_kind else "├─"
            kpad = "   " if last_kind else "│  "
            lines.append(f"{kbranch} @{kind}")
            rs = groups[kind]
            for ri, r in enumerate(rs):
                rlast = ri == len(rs) - 1
                rbranch = "└─" if rlast else "├─"
                suffix = "[]" if kind in {"OneToMany", "ManyToMany"} else ""
                lines.append(f"{kpad}{rbranch} {r.target}{suffix}  (field: {r.field}){_rel_meta(r)}")
                flds = fields_by.get(r.target, [])
                for fi, (fn, ft, _pk) in enumerate(flds):
                    flast = fi == len(flds) - 1
                    fbranch = "└─" if flast else "├─"
                    lines.append(f"{kpad}{'   ' if rlast else '│  '}   {fbranch} {fn}: {ft}")

    lines.append("")
    lines.append("Reverse References:")
    if not reverse:
        lines.append("  (none)")
    else:
        for src, r in reverse:
            lines.append(f"  ↑ {src} (@{r.kind} via {r.field}){_rel_meta(r)}")
    return lines


def _view_pretty(model: str, fields, rels, fields_by, reverse) -> list[str]:
    lines: list[str] = [model, "━" * 80]
    for n, t, pk in fields:
        icon = "🔑" if pk else "•"
        lines.append(f"  {icon} {n}: {t}")

    lines.append("")
    lines.append("Relationships")
    lines.append("━" * 80)

    if not rels:
        lines.append("  (none)")
    else:
        for r in rels:
            tgt_fields = fields_by.get(r.target, [])
            body: list[str] = [f"{_rel_label(r.kind)}  {model} -> {r.target}   (field: {r.field}){_rel_meta(r)}", ""]
            if tgt_fields:
                for fn, ft, pk in tgt_fields:
                    icon = "🔑" if pk else "•"
                    body.append(f"{icon} {fn}: {ft}")
            else:
                body.append("(target fields not found)")
            lines.extend(_box(body))
            lines.append("")

    lines.append("Reverse References")
    lines.append("━" * 80)

    if not reverse:
        lines.append("  (none)")
    else:
        for src, rr in reverse:
            lines.append(f"  ↑ {src} (@{rr.kind} via {rr.field}){_rel_meta(rr)}")

    return lines


def _view_flow(model: str, fields, rels, reverse) -> list[str]:
    lines: list[str] = [model, ""]
    for n, t, pk in fields:
        lines.append(f"  - {n}: {t}" + (" (PK)" if pk else ""))
    lines.append("")
    lines.append("Outgoing:")
    if not rels:
        lines.append("  (none)")
    else:
        for r in rels:
            lines.append(f"  {model} --@{r.kind}--> {r.target} (field: {r.field}){_rel_meta(r)}")
    lines.append("")
    lines.append("Incoming:")
    if not reverse:
        lines.append("  (none)")
    else:
        for src, r in reverse:
            lines.append(f"  {src} --@{r.kind}--> {model} (field: {r.field}){_rel_meta(r)}")
    return lines


def _view_db(model: str, fields, rels, reverse) -> list[str]:
    lines: list[str] = [f"TABLE: {model.lower()}"]
    for n, t, pk in fields:
        lines.append(f"  - {n}: {t}" + (" (PK)" if pk else ""))
    lines.append("")
    lines.append("Relationships:")
    if not rels and not reverse:
        lines.append("  (none)")
        return lines
    for r in rels:
        lines.append(f"  - @{r.kind} -> {r.target} (field: {r.field}){_rel_meta(r)}")
    for src, r in reverse:
        lines.append(f"  - {src} -> {model} (@{r.kind} via {r.field}){_rel_meta(r)}")
    return lines


def register_modeltree(app: typer.Typer) -> None:
    @app.command(help="Model relationship tree")
    def modeltree(
        model: str = typer.Argument(...),
        root: str = typer.Option("."),
        depth: int = typer.Option(2, "--depth", "-d"),
        forward_only: bool = typer.Option(False, "--forward-only"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        view: str | None = typer.Option(None, "--view", "-v"),
        out: Path | None = typer.Option(None, "--out"),
    ) -> None:
        target, project_root = _resolve_model_target_file(model, root=root)

        if view is None:
            view = _choose_view_interactive(default="tree")
        if view not in VIEWS:
            raise typer.BadParameter(f"view must be one of: {', '.join(VIEWS)}")

        create_file = typer.confirm("Create .txt file?", default=True)

        if target.suffix.lower() == ".java":
            if not _is_java_model_file(target):
                raise InvalidPathError(message="Not a model/entity file", path=target)
            model_name, fields, rels, fields_by, reverse = _collect_java_relationship_map(
                target, project_root, depth, forward_only, include_hubs
            )
        elif target.suffix.lower() == ".py":
            if not _is_python_model_file(target):
                raise InvalidPathError(message="Not a model/entity file", path=target)
            model_name, fields, rels, fields_by, reverse = python_collect_relationship_map(target, project_root)
        else:
            raise InvalidPathError(message="Unsupported model file type", path=target)

        if view == "compact":
            lines = _view_compact(model_name, fields, rels, reverse)
        elif view == "tree":
            lines = _view_tree(model_name, fields, rels, fields_by, reverse)
        elif view == "pretty":
            lines = _view_pretty(model_name, fields, rels, fields_by, reverse)
        elif view == "flow":
            lines = _view_flow(model_name, fields, rels, reverse)
        else:
            lines = _view_db(model_name, fields, rels, reverse)

        if not create_file:
            typer.echo("")
            for ln in lines:
                typer.echo(ln)
            return

        out_path = out.resolve() if out else _default_outfile(project_root, model_name)
        out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        typer.echo(out_path.as_posix())
        _open_in_editor(out_path)