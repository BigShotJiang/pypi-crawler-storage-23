﻿from __future__ import annotations

from collections import deque
from pathlib import Path
import re
import typer

from ...core.resolve_target import resolve_target_file
from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...lang.router import extract_models_for_file
from ...lang.java.resolve import resolve_java_import_to_file
from ...parser.imports import extract_imports_from_file
from ...parser.resolve import resolve_import_to_file
from ...parser.symbols import extract_classes_from_file, extract_funcs_from_file
from ...db.cache import CacheManager


TYPE_RE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")


def _rel(p: Path, root: Path) -> str:
    try:
        return p.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        return p.resolve().as_posix()


def _print_block(title: str, lines: list[str]) -> None:
    if not lines:
        return
    typer.echo(title)
    for x in lines:
        typer.echo(f"  {x}")
    typer.echo("")


def _layered_related(
    graph: dict[Path, set[Path]],
    start: Path,
    depth: int,
    include_reverse: bool,
    hubs: set[Path],
) -> list[list[Path]]:
    adj: dict[Path, set[Path]] = {k: set(v) for k, v in graph.items()}

    if include_reverse:
        rev: dict[Path, set[Path]] = {}
        for src, deps in adj.items():
            for dst in deps:
                rev.setdefault(dst, set()).add(src)
        for node, incoming in rev.items():
            adj.setdefault(node, set()).update(incoming)

    visited: set[Path] = {start}
    q: deque[tuple[Path, int]] = deque([(start, 0)])
    by_depth: dict[int, list[Path]] = {}

    while q:
        node, d = q.popleft()
        if d == depth:
            continue
        for nxt in adj.get(node, set()):
            if nxt in visited:
                continue
            if nxt in hubs:
                continue
            visited.add(nxt)
            nd = d + 1
            by_depth.setdefault(nd, []).append(nxt)
            q.append((nxt, nd))

    layers: list[list[Path]] = []
    for d in range(1, depth + 1):
        layers.append(sorted(by_depth.get(d, [])))
    return layers


def _is_domain_model_path(p: Path) -> bool:
    parts = {x.lower() for x in p.parts}
    return bool(parts & {"model", "models", "entity", "entities"})


def _models_lines(scope: list[Path], root: Path) -> list[str]:
    out: list[str] = []
    for f in scope:
        if not _is_domain_model_path(f):
            continue
        defs = extract_models_for_file(f, root)
        if not defs:
            continue
        out.append(f"• {_rel(f, root)}")
        for m in defs:
            out.append(f"   {m.name}")
            for field in getattr(m, "fields", []):
                out.append(f"     {field.name}: {field.type}")
        out.append("")
    while out and out[-1] == "":
        out.pop()
    return out


def _py_target_imports(target: Path, root: Path) -> tuple[list[str], list[str]]:
    related: set[str] = set()
    non_related: set[str] = set()

    for mod, level in extract_imports_from_file(target):
        mod = mod or ""
        s = ("." * level + mod) if level else mod
        if not s:
            continue
        resolved = resolve_import_to_file(mod, level, target, root)
        if resolved is None:
            non_related.add(s)
        else:
            related.add(s)

    return sorted(related), sorted(non_related)


def _py_related_imports(files: list[Path]) -> list[str]:
    out: set[str] = set()
    for f in files:
        if f.suffix.lower() != ".py":
            continue
        for mod, level in extract_imports_from_file(f):
            mod = mod or ""
            s = ("." * level + mod) if level else mod
            if s:
                out.add(s)
    return sorted(out)


def _py_types(path: Path) -> list[str]:
    out: list[str] = []
    for c in extract_classes_from_file(path):
        if not c.name.startswith("_"):
            out.append(f"{c.name} (class)")
    for fn in extract_funcs_from_file(path):
        if fn.name.startswith("_") or fn.name.startswith("register_"):
            continue
        out.append(f"{fn.name} (func)")
    return out


def _java_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def _java_imports(path: Path) -> list[str]:
    text = _java_read(path)
    out: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("import "):
            continue
        if s.startswith("import static "):
            continue
        s = s.removeprefix("import ").rstrip(";").strip()
        if not s or s.endswith(".*"):
            continue
        out.append(s)
    return out


def _java_split_imports(imports: list[str], root: Path) -> tuple[list[str], list[str]]:
    proj: set[str] = set()
    ext: set[str] = set()
    for imp in imports:
        if resolve_java_import_to_file(imp, root) is None:
            ext.add(imp)
        else:
            proj.add(imp)
    return sorted(proj), sorted(ext)


def _java_target_imports(target: Path, root: Path) -> tuple[list[str], list[str]]:
    return _java_split_imports(_java_imports(target), root)


def _java_related_imports(files: list[Path]) -> list[str]:
    out: set[str] = set()
    for f in files:
        if f.suffix.lower() != ".java":
            continue
        for imp in _java_imports(f):
            out.add(imp)
    return sorted(out)


def _java_types(path: Path) -> list[str]:
    text = _java_read(path)
    if not text:
        return []
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//.*?$", "", text, flags=re.M)
    m = TYPE_RE.search(text)
    if not m:
        return []
    kind, name = m.group(1), m.group(2)
    return [f"{name} ({kind})"]


def _types_section(title: str, files: list[Path], root: Path, lang: str) -> None:
    lines: list[str] = []
    for f in files:
        ts = _py_types(f) if lang == "python" else _java_types(f)
        if not ts:
            continue
        lines.append(f"• {_rel(f, root)}")
        for t in ts:
            lines.append(f"   {t}")
    if lines:
        typer.echo(title)
        for x in lines:
            typer.echo(x)
        typer.echo("")


def register_context(app: typer.Typer) -> None:
    @app.command(help="Context bundle (layered). Default depth=1.")
    def context(
        new_file: str = typer.Argument(...),
        root: str = typer.Option(".", "--root"),
        depth: int = typer.Option(1, "--depth", "-d"),
        forward_only: bool = typer.Option(False, "--forward-only"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        use_sqlite_cache: bool = typer.Option(True, "--use-sqlite-cache/--no-sqlite-cache"),
    ):
        target, root_path = resolve_target_file(new_file, root=root)

        if use_sqlite_cache:
            with CacheManager(root_path) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                files = cache.get_cached_files()
        else:
            files = []
            for p in root_path.rglob("*"):
                if p.is_file() and p.suffix.lower() in {".py", ".java"}:
                    files.append(p.resolve())
            files = sorted(set(files))

        graph, dependents_count = build_graph_with_counts(
            files,
            root_path,
            use_sqlite_cache=use_sqlite_cache,
        )

        hubs: set[Path] = set()
        if not include_hubs:
            hubs = get_hub_files_by_ratio(dependents_count, len(files), 0.5)

        layers = _layered_related(
            graph=graph,
            start=target.resolve(),
            depth=depth,
            include_reverse=not forward_only,
            hubs=hubs,
        )

        same_folder = sorted(
            f.resolve()
            for f in files
            if f.parent.resolve() == target.parent.resolve()
            and f.resolve() != target.resolve()
            and f.name != "__init__.py"
        )

        banned: set[Path] = {target.resolve(), *[p.resolve() for p in same_folder]}
        new_layers: list[list[Path]] = []
        for layer in layers:
            clean: list[Path] = []
            for p in layer:
                pr = p.resolve()
                if pr in banned:
                    continue
                clean.append(pr)
                banned.add(pr)
            new_layers.append(clean)
        layers = new_layers

        scope_all: list[Path] = [*same_folder]
        for layer in layers:
            scope_all.extend([p.resolve() for p in layer])

        lang = "java" if target.suffix.lower() == ".java" else "python"

        typer.echo("")
        typer.echo("CONTEXT")
        typer.echo(f"Target: {_rel(target, root_path)}")
        typer.echo(f"Depth: {depth}  Mode: {'forward-only' if forward_only else 'forward+reverse'}")
        typer.echo("")

        model_lines = _models_lines(scope_all, root_path)
        if model_lines:
            typer.echo("MODELS")
            for x in model_lines:
                typer.echo(x)
            typer.echo("")

        if lang == "java":
            t_proj, t_ext = _java_target_imports(target, root_path)
            _print_block("TARGET IMPORTS", t_proj)
            _print_block("TARGET NON-RELATED IMPORTS", t_ext)
            _types_section("TARGET TYPES", [target], root_path, lang)
        else:
            t_rel, t_non = _py_target_imports(target, root_path)
            _print_block("TARGET IMPORTS", t_rel)
            _print_block("TARGET NON-RELATED IMPORTS", t_non)

        _types_section("SAME FOLDER TYPES", same_folder, root_path, lang)

        for i, layer in enumerate(layers, 1):
            if not layer:
                continue
            _types_section(f"RELATED LEVEL {i} TYPES", layer, root_path, lang)
            if lang == "java":
                all_imps = _java_related_imports(layer)
                proj, ext = _java_split_imports(all_imps, root_path)
                _print_block(f"RELATED LEVEL {i} PROJECT IMPORTS", proj)
                _print_block(f"RELATED LEVEL {i} EXTERNAL IMPORTS", ext)
            else:
                _print_block(f"RELATED LEVEL {i} IMPORTS", _py_related_imports(layer))