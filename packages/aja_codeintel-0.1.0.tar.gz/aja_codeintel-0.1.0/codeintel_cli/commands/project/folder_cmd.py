﻿from __future__ import annotations

from pathlib import Path
import typer

from ...core.project import is_skipped_path
from ...core.resolve_folder import resolve_target_folder
from ...scanner.scanner import find_source_files


def register_folder(app: typer.Typer) -> None:
    @app.command(help="List source files under a folder (recursive).")
    def folder(
        folder: str = typer.Argument(..., help="Folder path or name (supports fuzzy)"),
        recursive: bool = typer.Option(True, "--recursive/--no-recursive"),
        relative: bool = typer.Option(True, "--relative/--absolute"),
        lang: str = typer.Option("all", "--lang", help="all | python | java"),
    ):
        folder_path, root = resolve_target_folder(folder)

        lang = lang.lower().strip()
        if lang not in {"all", "python", "java"}:
            raise typer.BadParameter("Invalid --lang. Use: all | python | java")

        exts = (".py", ".java") if lang == "all" else (".py",) if lang == "python" else (".java",)

        if recursive:
            files = find_source_files(folder_path, exts)
        else:
            files = []
            for ext in exts:
                for p in folder_path.glob(f"*{ext}"):
                    if not p.is_file():
                        continue
                    if is_skipped_path(p):
                        continue
                    files.append(p.resolve())
            files = sorted(set(files))

        if not files:
            typer.echo("(No matching files found.)")
            raise typer.Exit(0)

        for f in files:
            if relative:
                try:
                    typer.echo(str(f.relative_to(root)))
                except Exception:
                    typer.echo(str(f))
            else:
                typer.echo(str(f))
