from __future__ import annotations

import typer
import importlib.metadata as md
from ...core.resolve_target import resolve_target_file


def register_version(app: typer.Typer) -> None:
    @app.command(help="Show CodeIntel version.")
    def version():
        try:
            typer.echo(md.version("codeintel"))
        except md.PackageNotFoundError:
            typer.echo("codeintel (not installed as a package)")
