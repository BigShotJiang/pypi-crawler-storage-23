from __future__ import annotations
from pathlib import Path
import typer

from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...core.fuzzy import rank_paths, fuzzy_is_confident
from ...context.java_service import analyze_java_service
from ...context.python_service import analyze_python_service
from ...db.cache import CacheManager

PYTHON_SERVICE_DIRS = {"service", "services", "api", "views", "routes"}

ANALYZERS = {
    ".java": analyze_java_service,
    ".py": analyze_python_service,
}


def _is_excluded_java_service_path(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    stem = path.stem.lower()
    name = path.name.lower()

    if name == "package-info.java":
        return True
    if "dto" in parts or "mapper" in parts or "vm" in parts:
        return True
    if stem.endswith("dto") or "dto" in stem:
        return True
    if stem.endswith("mapper") or "mapper" in stem:
        return True
    return False


def _java_has_service_annotation(path: Path) -> bool:
    try:
        txt = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    return "@Service" in txt


def _is_service_file(path: Path) -> bool:
    suffix = path.suffix.lower()
    stem_lower = path.stem.lower()

    if suffix == ".java":
        if _is_excluded_java_service_path(path):
            return False
        if stem_lower.endswith("service"):
            return True
        return _java_has_service_annotation(path)

    if suffix == ".py":
        parts = {p.lower() for p in path.parts}
        return bool(parts & PYTHON_SERVICE_DIRS)

    return False


def _short_rel(path: Path, root: Path, keep: int = 5) -> str:
    try:
        parts = list(path.relative_to(root).parts)
    except ValueError:
        return str(path)
    tail = parts[-keep:] if len(parts) > keep else parts
    return "/".join(tail)


def _resolve_service_file(query: str, root: str = ".", top: int = 6) -> tuple[Path, Path]:
    root_path = Path(root).resolve()
    project_root = find_project_root(root_path)

    direct = Path(query)
    if direct.is_file():
        return direct.resolve(), project_root

    with CacheManager(project_root) as cache:
        if cache.needs_rescan():
            cache.scan_project(verbose=False)
        all_files = cache.get_cached_files()

    service_files = [p for p in all_files if _is_service_file(p)]
    if not service_files:
        raise InvalidPathError(message="No service files found", path=project_root)

    query_stem = Path(query).stem.lower()
    exact = [f for f in service_files if f.stem.lower() == query_stem]
    if len(exact) == 1:
        return exact[0].resolve(), project_root

    ranked = rank_paths(query, service_files, project_root, top=top)
    if not ranked:
        raise InvalidPathError(message="Service not found", path=Path(query))

    if fuzzy_is_confident(ranked):
        top_score = ranked[0][1]
        if sum(1 for _, s in ranked if abs(s - top_score) < 0.01) == 1:
            return ranked[0][0].resolve(), project_root

    typer.echo("Multiple matches found — select a service:")
    for i, (p, score) in enumerate(ranked, 1):
        typer.echo(f"  {i}. {_short_rel(p, project_root)}  (score={score:.2f})")

    choice = typer.prompt("Enter number (0 to cancel)", type=int, default=0)
    if not (1 <= choice <= len(ranked)):
        raise typer.Exit()

    return ranked[choice - 1][0].resolve(), project_root


def _render_service_map(data: dict) -> list[str]:
    lines: list[str] = [data["service_name"], "━" * 80, ""]

    if endpoints := data.get("endpoints", []):
        lines.append("ENDPOINTS")
        for ep in endpoints:
            lines.append(f"  {ep.get('method', '').ljust(7)} {ep.get('path', '')}")
            if handler := ep.get("handler"):
                lines.append(f"           → {handler}")
        lines.append("")

    if methods := data.get("methods", []):
        lines.append("SERVICE METHODS")
        for m in methods:
            sig = f"{m.get('name', '')}({m.get('params', '')})"
            if ret := m.get("return"):
                sig += f" → {ret}"
            lines.append(f"  • {sig}")
        lines.append("")

    if models := data.get("models", {}):
        lines.append("MODELS")
        for model_name, model_data in models.items():
            lines.append(f"  {model_name}")
            for fname, ftype, is_pk in model_data.get("fields", []):
                marker = "🔑" if is_pk else "  "
                lines.append(f"    {marker} {fname}: {ftype}")
            for rel in model_data.get("relationships", []):
                lines.append(f"      → {rel.get('kind', '')} {rel.get('target', '')} (via {rel.get('field', '')})")
        lines.append("")

    if repos := data.get("repositories", []):
        lines.append("REPOSITORIES")
        for repo in repos:
            lines.append(f"  {repo.get('name', '')}")
            for method in repo.get("methods", [])[:3]:
                lines.append(f"    • {method}")
        lines.append("")

    if summary := data.get("summary", {}):
        lines.append("SUMMARY")
        lines.extend(f"  {k}: {v}" for k, v in summary.items())

    return lines


def register_servicemap(app: typer.Typer) -> None:
    @app.command(help="Service endpoint-model relationship map")
    def servicemap(
        service: str = typer.Argument(..., help="Service name or path"),
        root: str = typer.Option(".", help="Project root directory"),
        save: bool = typer.Option(False, "--save", "-s", help="Save output to file"),
    ) -> None:
        target, project_root = _resolve_service_file(service, root=root)

        analyzer = ANALYZERS.get(target.suffix.lower())
        if analyzer is None:
            raise InvalidPathError(message="Unsupported file type", path=target)

        result = analyzer(target, project_root)
        lines = _render_service_map(result)

        if save:
            out_path = project_root / f"codeintel-servicemap-{result['service_name']}.txt"
            out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            typer.echo(f"Saved: {out_path.as_posix()}")
        else:
            typer.echo("\n" + "\n".join(lines))