from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import typer

# Optional: pip install pathspec
try:
    import pathspec  # type: ignore
except Exception:  # pragma: no cover
    pathspec = None


DEFAULT_IGNORE_NAMES = {
    ".git", ".idea", ".vscode",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "venv", ".venv",
    "node_modules", "dist", "build",
    ".DS_Store",
}


@dataclass(frozen=True)
class TreeOptions:
    depth: int                 # -1 = unlimited
    show_hidden: bool          # show dotfiles/dirs
    keep_dotenv: bool          # always show ".env"
    use_gitignore: bool        # apply .gitignore patterns
    exts: tuple[str, ...]      # file extensions to include (".py", ".java")


def _load_gitignore_spec(root: Path):
    if pathspec is None:
        return None
    gi = root / ".gitignore"
    if not gi.exists():
        return None

    lines: list[str] = []
    for line in gi.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        lines.append(s)

    if not lines:
        return None
    return pathspec.PathSpec.from_lines("gitwildmatch", lines)


def _is_hidden(name: str) -> bool:
    return name.startswith(".")


def _gitignore_matches(spec, rel_posix: str, is_dir: bool) -> bool:
    if spec is None:
        return False
    if spec.match_file(rel_posix):
        return True
    if is_dir and spec.match_file(rel_posix.rstrip("/") + "/"):
        return True
    return False


def _is_ignored(root: Path, p: Path, spec, opts: TreeOptions) -> bool:
    name = p.name

    if opts.keep_dotenv and name == ".env":
        return False

    if name in DEFAULT_IGNORE_NAMES:
        return True

    if _is_hidden(name) and not opts.show_hidden:
        return True

    if opts.use_gitignore and spec is not None:
        rel = p.relative_to(root).as_posix()
        if _gitignore_matches(spec, rel, p.is_dir()):
            return True

    return False


def _is_source_file(p: Path, opts: TreeOptions) -> bool:
    if not p.is_file():
        return False
    # include only selected extensions
    return p.suffix.lower() in opts.exts


def _list_children(root: Path, cur: Path, spec, opts: TreeOptions) -> list[Path]:
    try:
        entries = list(cur.iterdir())
    except (PermissionError, FileNotFoundError):
        return []

    kept: list[Path] = []
    for p in entries:
        if _is_ignored(root, p, spec, opts):
            continue
        if p.is_dir():
            kept.append(p)
        else:
            if _is_source_file(p, opts) or (opts.keep_dotenv and p.name == ".env"):
                kept.append(p)

    # dirs first, then files; alpha
    kept.sort(key=lambda x: (x.is_file(), x.name.lower()))
    return kept


def _dir_has_visible_sources(root: Path, cur: Path, spec, opts: TreeOptions, remaining_depth: int) -> bool:
    """
    True if this directory contains any visible source file (directly or deeper).
    remaining_depth: how many more levels we can descend; -1 for unlimited.
    """
    children = _list_children(root, cur, spec, opts)
    if not children:
        return False

    for c in children:
        if c.is_file():
            return True

    if remaining_depth == 0:
        # we can't descend further; if it has dirs but no files shown, treat as empty
        return False

    next_depth = -1 if remaining_depth == -1 else remaining_depth - 1
    for c in children:
        if c.is_dir() and _dir_has_visible_sources(root, c, spec, opts, next_depth):
            return True

    return False


def _print_tree(root: Path, opts: TreeOptions) -> None:
    spec = _load_gitignore_spec(root) if opts.use_gitignore else None

    def walk(cur: Path, prefix: str, level: int) -> None:
        if opts.depth != -1 and level > opts.depth:
            return

        items = _list_children(root, cur, spec, opts)

        # prune empty dirs (dirs that contain no visible sources)
        pruned: list[Path] = []
        for p in items:
            if p.is_dir():
                remaining = -1 if opts.depth == -1 else max(opts.depth - level, 0)
                if _dir_has_visible_sources(root, p, spec, opts, remaining):
                    pruned.append(p)
            else:
                pruned.append(p)

        items = pruned

        for i, p in enumerate(items):
            last = i == len(items) - 1
            branch = "└── " if last else "├── "
            typer.echo(prefix + branch + p.name)

            if p.is_dir():
                extension = "    " if last else "│   "
                walk(p, prefix + extension, level + 1)

    typer.echo(root.name)
    walk(root, prefix="", level=1)


def register_tree(app: typer.Typer) -> None:
    @app.command(help="Tree view of source files only (python/java).")
    def tree(
        root: str = typer.Argument(".", help="Folder to print tree for"),
        depth: int = typer.Option(12, "--depth", help="Max depth (-1 = unlimited)"),
        hidden: bool = typer.Option(False, "--hidden", help="Show hidden dotfiles/folders"),
        no_gitignore: bool = typer.Option(False, "--no-gitignore", help="Do not apply .gitignore rules"),
        keep_dotenv: bool = typer.Option(True, "--keep-dotenv/--no-keep-dotenv", help="Always show .env"),
        lang: str = typer.Option("all", "--lang", help="all | py | java"),
    ):
        root_path = Path(root).resolve()
        if not root_path.exists() or not root_path.is_dir():
            raise typer.BadParameter(f"Invalid folder: {root_path}")

        lang_norm = lang.strip().lower()
        if lang_norm == "py":
            exts = (".py",)
        elif lang_norm == "java":
            exts = (".java",)
        elif lang_norm == "all":
            exts = (".py", ".java")
        else:
            raise typer.BadParameter("Invalid --lang. Use: all | py | java")

        opts = TreeOptions(
            depth=depth,
            show_hidden=hidden,
            keep_dotenv=keep_dotenv,
            use_gitignore=not no_gitignore,
            exts=exts,
        )
        _print_tree(root_path, opts)
