from __future__ import annotations

from pathlib import Path
import typer

from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files


def _import_extractors():
    py = None
    jv = None

    try:
        from ...lang.python.models import extract_python_models as _py  # type: ignore

        py = _py
    except Exception:
        pass

    try:
        from ...context.python_context import extract_python_models as _py  # type: ignore

        py = _py
    except Exception:
        pass

    try:
        from ...lang.java.models import extract_java_models as _jv  # type: ignore

        jv = _jv
    except Exception:
        pass

    try:
        from ...context.java_context import extract_java_models as _jv  # type: ignore

        jv = _jv
    except Exception:
        pass

    return py, jv


def _is_model_path(rel: Path) -> bool:
    keys = {"model", "models", "entity", "entities", "domain", "domains"}
    parts = [p.lower() for p in rel.parts]
    if "src" in parts and "test" in parts:
        return False
    return any(part in keys for part in parts)


def register_models(app: typer.Typer) -> None:
    @app.command(help="List domain models (from model/entity folders only).")
    def models(
        root: str = typer.Argument(".", help="Project root folder"),
    ):
        root_path = Path(root).resolve()
        project_root = find_project_root(root_path)

        extract_python_models, extract_java_models = _import_extractors()

        files = find_all_supported_files(project_root)

        candidates: list[Path] = []
        pr = project_root.resolve()
        for f in files:
            fr = f.resolve()
            try:
                rel = fr.relative_to(pr)
            except Exception:
                continue
            if _is_model_path(rel):
                candidates.append(fr)

        out: list[str] = []

        for f in sorted(candidates, key=lambda x: str(x).lower()):
            ext = f.suffix.lower()

            if ext == ".py" and extract_python_models is not None:
                defs = extract_python_models(f, project_root)
            elif ext == ".java" and extract_java_models is not None:
                defs = extract_java_models(f, project_root)
            else:
                continue

            for d in defs:
                out.append(f"{d.name}  ({d.kind})  {d.file}")
                for fld in d.fields:
                    out.append(f"  - {fld.name}: {fld.type}")

        if not out:
            typer.echo("No domain models found.")
            raise typer.Exit(0)

        for line in out:
            typer.echo(line)