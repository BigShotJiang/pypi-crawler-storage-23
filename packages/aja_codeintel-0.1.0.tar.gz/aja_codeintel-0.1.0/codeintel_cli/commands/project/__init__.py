from __future__ import annotations
import typer

from .scan_cmd import register_scan
from .imports_cmd import register_imports
from .version_cmd import register_version
from .resolve_cmd import register_resolve
from .context_cmd import register_context
from .folder_cmd import register_folder
from .tree_cmd import register_tree
from .modeltree_cmd import register_modeltree
from .models_cmd import register_models
from .servicemap_cmd import register_servicemap


def register_project_commands(app: typer.Typer) -> None:
    register_scan(app)
    register_imports(app)
    register_version(app)
    register_resolve(app)
    register_context(app)
    register_folder(app)
    register_tree(app)
    register_modeltree(app)
    register_models(app)
    register_servicemap(app)