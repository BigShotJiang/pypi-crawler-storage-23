﻿from __future__ import annotations

from pathlib import Path

from ..core.project import is_skipped_path


def find_source_files(root: Path, exts: tuple[str, ...]) -> list[Path]:
    root = root.resolve()
    results: list[Path] = []

    for ext in exts:
        for p in root.rglob(f"*{ext}"):
            if not p.is_file():
                continue
            if is_skipped_path(p):
                continue
            results.append(p.resolve())

    return sorted(set(results))


def find_python_files(root: Path) -> list[Path]:
    return find_source_files(root, (".py",))


def find_java_files(root: Path) -> list[Path]:
    return find_source_files(root, (".java",))


def find_all_supported_files(root: Path) -> list[Path]:
    root = root.resolve()
    results: list[Path] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if is_skipped_path(p):
            continue
        if p.suffix.lower() in {".py", ".java"}:
            results.append(p.resolve())
    return sorted(set(results))
