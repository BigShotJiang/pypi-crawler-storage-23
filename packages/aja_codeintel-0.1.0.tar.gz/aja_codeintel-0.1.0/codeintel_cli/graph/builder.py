﻿from __future__ import annotations

from pathlib import Path
import sys

from ..lang.router import extract_imports
from ..lang.java.resolve import resolve_java_import_to_file
from ..parser.resolve import resolve_import_to_file
from ..core.where import file_to_module
from ..db.cache import CacheManager
from ..db.operations import get_deps_map_for_paths

def _is_under_root(path: Path, root: Path) -> bool:
    try:
        path = path.resolve()
        root = root.resolve()
    except Exception:
        return False
    try:
        path.relative_to(root)
        return True
    except Exception:
        return False

def _is_stdlib_module(module: str) -> bool:
    if not module:
        return False
    top = module.split(".", 1)[0]
    stdlib_names = getattr(sys, "stdlib_module_names", None)
    if stdlib_names and top in stdlib_names:
        return True
    if top in {"__future__", "builtins"}:
        return True
    return False

def _detect_lang(path: Path) -> str:
    return "java" if path.suffix == ".java" else "python"

def build_graph(files: list[Path], root: Path) -> dict[Path, set[Path]]:
    graph, _ = build_graph_with_counts(files, root)
    return graph

def build_graph_with_counts(
    files: list[Path],
    root: Path,
    *,
    ignore_stdlib: bool = True,
    ignore_outside_root: bool = True,
    use_sqlite_cache: bool = False,
) -> tuple[dict[Path, set[Path]], dict[Path, int]]:
    root = root.resolve()
    graph: dict[Path, set[Path]] = {}
    dependents_count: dict[Path, int] = {}

    java_map: dict[str, Path] = {}
    for f0 in files:
        f0r = f0.resolve()
        if f0r.suffix.lower() == ".java":
            m = file_to_module(f0r, root)
            if m:
                java_map[m] = f0r

    cached_deps_by_path: dict[str, list[str]] | None = None
    if use_sqlite_cache:
        try:
            with CacheManager(root) as cache:
                if cache.needs_rescan():
                    cache.scan_project(verbose=False)
                cached_deps_by_path = get_deps_map_for_paths(cache.conn, files) if cache.conn else None
        except Exception:
            cached_deps_by_path = None

    for f in files:
        f = f.resolve()
        lang = _detect_lang(f)

        deps: set[Path] = set()

        if cached_deps_by_path is not None:
            for dst in cached_deps_by_path.get(str(f), []):
                t = Path(dst)
                try:
                    t = t.resolve()
                except Exception:
                    continue
                if ignore_outside_root and not _is_under_root(t, root):
                    continue
                if t == f:
                    continue
                if t not in deps:
                    deps.add(t)
                    dependents_count[t] = dependents_count.get(t, 0) + 1

            graph[f] = deps
            continue

        try:
            imports = extract_imports(f, lang)
        except Exception:
            imports = []

        for item in imports:
            if isinstance(item, tuple):
                mod, level = item
            else:
                mod, level = str(item), 0

            if lang == "python":
                if ignore_stdlib and _is_stdlib_module(mod):
                    continue
                target = resolve_import_to_file(mod, level, f, root)
            else:
                if not mod or mod.endswith(".*"):
                    continue
                target = resolve_java_import_to_file(mod, root)
                if not target:
                    target = java_map.get(mod)

            if not target:
                continue

            try:
                target = target.resolve()
            except Exception:
                continue

            if ignore_outside_root and not _is_under_root(target, root):
                continue

            if target == f:
                continue

            if target not in deps:
                deps.add(target)
                dependents_count[target] = dependents_count.get(target, 0) + 1

        graph[f] = deps

    return graph, dependents_count

def get_hub_files_by_ratio(
    dependents_count: dict[Path, int],
    total_files: int,
    ratio: float,
) -> set[Path]:
    if total_files <= 0 or ratio <= 0:
        return set()
    limit = total_files * ratio
    return {p for p, c in dependents_count.items() if c > limit}