from __future__ import annotations

from pathlib import Path
from collections import deque


def build_reverse_graph(graph: dict[Path, set[Path]]) -> dict[Path, set[Path]]:
    rev: dict[Path, set[Path]] = {}

    for src, targets in graph.items():
        rev.setdefault(src, set())
        for t in targets:
            rev.setdefault(t, set()).add(src)

    return rev


def bfs_related(
    graph: dict[Path, set[Path]],
    start: Path,
    max_depth: int,
    skip: set[Path] | None = None,
) -> set[Path]:
    if max_depth <= 0:
        return set()

    skip = skip or set()
    seen: set[Path] = set()
    q = deque([(start, 0)])

    while q:
        node, depth = q.popleft()

        expand = node not in skip

        for nxt in graph.get(node, set()):
            if nxt == start or nxt in seen:
                continue

            next_depth = depth + 1
            if next_depth > max_depth:
                continue

            seen.add(nxt)

            if expand:
                q.append((nxt, next_depth))

    return seen
