from __future__ import annotations
from pathlib import Path

from .traverse import build_reverse_graph, bfs_related


def get_direct_deps(graph: dict[Path, set[Path]], file: Path) -> set[Path]:
    return graph.get(file, set())


def get_reverse_deps(graph: dict[Path, set[Path]], file: Path) -> set[Path]:
    rev = build_reverse_graph(graph)
    return rev.get(file, set())


def get_related(
    graph: dict[Path, set[Path]],
    file: Path,
    depth: int,
    include_reverse: bool = True,
    hubs: set[Path] | None = None,
) -> set[Path]:
    out = set()
    out |= bfs_related(graph, file, depth, skip=hubs)

    if include_reverse:
        rev = build_reverse_graph(graph)
        out |= bfs_related(rev, file, depth, skip=hubs)

    return out
