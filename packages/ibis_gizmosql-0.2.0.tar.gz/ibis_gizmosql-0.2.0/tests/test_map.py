from ibis.backends.tests.test_map import *  # noqa: F401,F403
