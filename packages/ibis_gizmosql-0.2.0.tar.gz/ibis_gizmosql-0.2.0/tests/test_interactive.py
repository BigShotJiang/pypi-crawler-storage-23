from ibis.backends.tests.test_interactive import *  # noqa: F401,F403
