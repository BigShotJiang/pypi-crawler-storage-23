from ibis.backends.tests.test_dot_sql import *  # noqa: F401,F403
