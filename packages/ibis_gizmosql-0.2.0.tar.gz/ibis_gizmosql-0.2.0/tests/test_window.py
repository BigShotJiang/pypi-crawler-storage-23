from ibis.backends.tests.test_window import *  # noqa: F401,F403
