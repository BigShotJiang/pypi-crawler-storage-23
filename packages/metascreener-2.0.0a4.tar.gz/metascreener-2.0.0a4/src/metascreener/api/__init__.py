"""MetaScreener 2.0 FastAPI service layer."""
