"""MetaScreener Layer 2 — Semantic Rule Engine (hard + soft rules)."""
