"""MetaScreener Layer 4 — Hierarchical Decision Router."""
