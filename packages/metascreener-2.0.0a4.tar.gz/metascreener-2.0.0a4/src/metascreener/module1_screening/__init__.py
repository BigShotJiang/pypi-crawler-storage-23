"""Module 1: Literature Screening (Hierarchical Consensus Network)."""
from metascreener.module1_screening.ta_screener import TAScreener

__all__ = ["TAScreener"]
