"""MetaScreener Layer 3 — Calibrated Confidence Aggregation (CCA)."""
