"""Entry point for python -m metascreener."""
from __future__ import annotations

from metascreener.cli import app

if __name__ == "__main__":
    app()
