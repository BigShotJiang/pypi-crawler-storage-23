"""Tests for IlumError → HTTP status code mapping."""

from __future__ import annotations

from ilum.api.errors import status_for_error
from ilum.errors import (
    AuthError,
    ClusterConnectionError,
    HelmError,
    HelmTimeoutError,
    IlumError,
    ModuleError,
    ReleaseExistsError,
    ReleaseNotFoundError,
    ValuesError,
)


class TestErrorMapping:
    def test_module_error_is_400(self) -> None:
        assert status_for_error(ModuleError("bad module")) == 400

    def test_auth_error_is_401(self) -> None:
        assert status_for_error(AuthError("unauthorized")) == 401

    def test_release_not_found_is_404(self) -> None:
        assert status_for_error(ReleaseNotFoundError("not found")) == 404

    def test_release_exists_is_409(self) -> None:
        assert status_for_error(ReleaseExistsError("exists")) == 409

    def test_values_error_is_422(self) -> None:
        assert status_for_error(ValuesError("bad values")) == 422

    def test_helm_error_is_502(self) -> None:
        assert status_for_error(HelmError("helm failed")) == 502

    def test_cluster_connection_error_is_503(self) -> None:
        assert status_for_error(ClusterConnectionError("no cluster")) == 503

    def test_helm_timeout_error_is_504(self) -> None:
        assert status_for_error(HelmTimeoutError("timeout")) == 504

    def test_base_ilum_error_is_500(self) -> None:
        assert status_for_error(IlumError("unknown")) == 500
