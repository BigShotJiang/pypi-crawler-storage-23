"""Tests for the module logs endpoint."""

from __future__ import annotations

from unittest.mock import MagicMock

from fastapi.testclient import TestClient

from ilum.core.kubernetes import PodStatus


class TestModuleLogs:
    def test_get_logs_returns_lines(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="ilum-jupyter-0",
                namespace="default",
                phase="Running",
                ready=True,
                restart_count=0,
            ),
        ]
        mock_api_manager.k8s.read_pod_log.return_value = (
            "2026-02-17 Starting server\n2026-02-17 Ready"
        )
        resp = api_client.get("/api/v1/modules/jupyter/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["module_name"] == "jupyter"
        assert data["pod_name"] == "ilum-jupyter-0"
        assert len(data["lines"]) == 2
        assert "Starting server" in data["lines"][0]

    def test_get_logs_specific_pod(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="pod-a", namespace="default", phase="Running", ready=True, restart_count=0
            ),
            PodStatus(
                name="pod-b", namespace="default", phase="Running", ready=True, restart_count=0
            ),
        ]
        mock_api_manager.k8s.read_pod_log.return_value = "log line"
        resp = api_client.get("/api/v1/modules/jupyter/logs?pod=pod-b")
        assert resp.status_code == 200
        assert resp.json()["pod_name"] == "pod-b"
        mock_api_manager.k8s.read_pod_log.assert_called_once()
        call_args = mock_api_manager.k8s.read_pod_log.call_args
        assert call_args[0][1] == "pod-b"

    def test_get_logs_pod_not_found(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="pod-a", namespace="default", phase="Running", ready=True, restart_count=0
            ),
        ]
        resp = api_client.get("/api/v1/modules/jupyter/logs?pod=nonexistent")
        assert resp.status_code == 404

    def test_get_logs_no_pods_returns_empty(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = []
        resp = api_client.get("/api/v1/modules/jupyter/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["pod_name"] == ""
        assert data["lines"] == []

    def test_get_logs_unknown_module(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        resp = api_client.get("/api/v1/modules/nonexistent/logs")
        assert resp.status_code == 400

    def test_get_logs_with_tail_param(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="pod-a", namespace="default", phase="Running", ready=True, restart_count=0
            ),
        ]
        mock_api_manager.k8s.read_pod_log.return_value = "line"
        resp = api_client.get("/api/v1/modules/jupyter/logs?tail=50")
        assert resp.status_code == 200
        call_kwargs = mock_api_manager.k8s.read_pod_log.call_args
        assert call_kwargs[1]["tail_lines"] == 50

    def test_get_logs_with_previous_param(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="pod-a", namespace="default", phase="Running", ready=True, restart_count=0
            ),
        ]
        mock_api_manager.k8s.read_pod_log.return_value = "old log"
        resp = api_client.get("/api/v1/modules/jupyter/logs?previous=true")
        assert resp.status_code == 200
        call_kwargs = mock_api_manager.k8s.read_pod_log.call_args
        assert call_kwargs[1]["previous"] is True

    def test_prefers_unhealthy_pod(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        mock_api_manager.k8s.list_pods_by_label.return_value = [
            PodStatus(
                name="healthy-pod",
                namespace="default",
                phase="Running",
                ready=True,
                restart_count=0,
            ),
            PodStatus(
                name="sick-pod", namespace="default", phase="Running", ready=False, restart_count=5
            ),
        ]
        mock_api_manager.k8s.read_pod_log.return_value = "error log"
        resp = api_client.get("/api/v1/modules/jupyter/logs")
        assert resp.status_code == 200
        assert resp.json()["pod_name"] == "sick-pod"

    def test_auth_required(self, unauthed_client: TestClient, mock_api_manager: MagicMock) -> None:
        resp = unauthed_client.get("/api/v1/modules/jupyter/logs")
        assert resp.status_code == 401
