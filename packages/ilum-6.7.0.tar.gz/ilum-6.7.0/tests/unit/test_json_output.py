"""Tests for per-command JSON/YAML output (Phase 2)."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from ilum.cli.main import app


class TestModuleListJson:
    def test_module_list_json(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--output", "json", "module", "list"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "name" in data[0]
        assert "category" in data[0]
        assert "description" in data[0]
        assert "default_enabled" in data[0]

    def test_module_list_yaml(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--output", "yaml", "module", "list"])
        assert result.exit_code == 0
        assert "name:" in result.output

    def test_module_list_json_with_category_filter(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--output", "json", "module", "list", "--category", "core"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert all(m["category"] == "core" for m in data)


class TestModuleShowJson:
    def test_module_show_json(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--output", "json", "module", "show", "core"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "core"
        assert "enable_flags" in data
        assert "requires" in data

    def test_module_show_yaml(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--output", "yaml", "module", "show", "core"])
        assert result.exit_code == 0
        assert "name: core" in result.output


class TestQuietMode:
    def test_quiet_json_still_emits(self) -> None:
        """In quiet mode, JSON output should still be emitted."""
        runner = CliRunner()
        result = runner.invoke(app, ["--quiet", "--output", "json", "module", "list"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_quiet_json_module_show_parseable(self) -> None:
        """--quiet --output json module show should produce valid JSON with no Rich noise."""
        runner = CliRunner()
        result = runner.invoke(app, ["--quiet", "--output", "json", "module", "show", "core"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["name"] == "core"

    def test_quiet_table_suppresses_widgets(self) -> None:
        """In quiet+table mode, Rich widgets like table() and panel() should be suppressed."""
        from ilum.cli.output import IlumConsole

        c = IlumConsole()
        c.quiet = True
        # These should all return without printing (no exception = success)
        c.table("Test", ["Col"], [["row"]])
        c.panel("content", "title")
        c.operation_summary([["k", "v"]])
        c.command_preview(["helm", "upgrade"])
