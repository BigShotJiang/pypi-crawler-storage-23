"""Tests for ilum.core.versioning — version parsing and comparison."""

from __future__ import annotations

from ilum.core.versioning import minor_version_changed, parse_version, version_satisfies


class TestParseVersion:
    def test_simple_semver(self) -> None:
        assert parse_version("1.2.3") == (1, 2, 3)

    def test_major_minor_only(self) -> None:
        assert parse_version("3.14") == (3, 14, 0)

    def test_helm_version_string(self) -> None:
        assert parse_version("v3.14.2+g1a524f4") == (3, 14, 2)

    def test_kubectl_version_string(self) -> None:
        assert parse_version("Client Version: v1.30.0") == (1, 30, 0)

    def test_no_version_found(self) -> None:
        assert parse_version("no version here") == (0, 0, 0)

    def test_embedded_version(self) -> None:
        assert parse_version("Docker version 24.0.7, build afdd53b") == (24, 0, 7)

    def test_empty_string(self) -> None:
        assert parse_version("") == (0, 0, 0)


class TestVersionSatisfies:
    def test_exact_match(self) -> None:
        assert version_satisfies("3.14.0", (3, 14)) is True

    def test_above_minimum(self) -> None:
        assert version_satisfies("3.15.0", (3, 14)) is True

    def test_below_minimum(self) -> None:
        assert version_satisfies("3.11.0", (3, 14)) is False

    def test_major_above(self) -> None:
        assert version_satisfies("4.0.0", (3, 14)) is True

    def test_major_below(self) -> None:
        assert version_satisfies("2.99.0", (3, 0)) is False

    def test_unparseable(self) -> None:
        assert version_satisfies("garbage", (1, 0)) is False

    def test_helm_version_with_suffix(self) -> None:
        assert version_satisfies("v3.14.2+g1a524f4", (3, 12)) is True


class TestMinorVersionChanged:
    def test_minor_changed(self) -> None:
        assert minor_version_changed("6.6.0", "6.7.0") is True

    def test_same_version(self) -> None:
        assert minor_version_changed("6.7.0", "6.7.0") is False

    def test_patch_only(self) -> None:
        assert minor_version_changed("6.7.0", "6.7.1") is False

    def test_major_changed(self) -> None:
        assert minor_version_changed("6.7.0", "7.0.0") is False

    def test_unparseable_current(self) -> None:
        assert minor_version_changed("garbage", "6.7.0") is False

    def test_unparseable_target(self) -> None:
        assert minor_version_changed("6.7.0", "garbage") is False
