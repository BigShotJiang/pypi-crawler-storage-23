#!/usr/bin/env bash
# =============================================================================
# Phase 6: Upgrade & Configuration Changes
# =============================================================================
# Test upgrade command with dry-run and live operations.
# =============================================================================

print_phase "Phase 6: Upgrade & Configuration Changes"

# Ensure we're connected
if ! "$ILUM" config show &>/dev/null; then
    "$ILUM" connect --release "$HELM_RELEASE" --namespace "$HELM_NAMESPACE" --yes 2>/dev/null || true
fi

# ---- Dry-run tests ----

run_test "P6-001" "upgrade --dry-run (no changes)" "$ILUM" upgrade --dry-run
assert_exit_code 0 || true

run_test "P6-002" "upgrade --dry-run with --set" "$ILUM" upgrade --dry-run --set ilum-core.replicaCount=2
assert_exit_code 0 || true

run_test "P6-003" "upgrade --dry-run --version 6.6.1" "$ILUM" upgrade --dry-run --version 6.6.1
assert_exit_code 0 || true

run_test "P6-004" "upgrade --dry-run --module kestra" "$ILUM" upgrade --dry-run --module kestra
assert_exit_code 0 || true

run_test "P6-005" "upgrade --dry-run --force-rollback" "$ILUM" upgrade --dry-run --force-rollback
# Should note release is not stuck
assert_exit_code 0 || true

# ---- Values file ----

VALS_FILE=$(create_temp_values "ilum-core:
  replicaCount: 1
  jvmOptions: \"-Xmx512m\"")

run_test "P6-006" "upgrade --dry-run --values file" "$ILUM" upgrade --dry-run --values "$VALS_FILE"
assert_exit_code 0 || true

run_test "P6-007" "upgrade --dry-run --values nonexistent" "$ILUM" upgrade --dry-run --values /nonexistent/file.yaml
assert_exit_code_not 0 || true

rm -f "$VALS_FILE" 2>/dev/null || true

# ---- Live upgrade ----

BEFORE_REV=$(get_revision)

UNIQUE_VAL="e2e-test-$(date +%s)"
run_test "P6-008" "upgrade --set env var --yes (live)" "$ILUM" upgrade --set "ilum-core.env.E2E_MARKER=$UNIQUE_VAL" --yes --timeout 15m
if [[ "$LAST_EXIT_CODE" -eq 0 ]]; then
    assert_exit_code 0 || true

    # Verify revision bumped
    AFTER_REV=$(get_revision)
    run_test "P6-009" "revision bumped after upgrade" echo "before=$BEFORE_REV after=$AFTER_REV"
    if [[ "$AFTER_REV" -gt "$BEFORE_REV" ]]; then
        PASSED_TESTS=$((PASSED_TESTS + 1))
        print_pass "P6-009 — revision bumped from $BEFORE_REV to $AFTER_REV"
        echo "PASS" > "$TEST_LOG_DIR/P6-009/result.txt"
    else
        FAILED_TESTS=$((FAILED_TESTS + 1))
        print_fail "P6-009 — revision not bumped"
        echo "FAIL" > "$TEST_LOG_DIR/P6-009/result.txt"
        FAILURES+=("P6-009: revision not bumped after upgrade")
    fi
else
    log_issue "BUG" "high" "P6-008" "upgrade --set failed: exit $LAST_EXIT_CODE"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    print_fail "P6-008 — upgrade --set failed"
    echo "FAIL" > "$TEST_LOG_DIR/P6-008/result.txt"
    FAILURES+=("P6-008: upgrade failed")
    skip_test "P6-009" "revision bump check" "upgrade failed"
fi

# ---- Drift detection ----
# Make a raw helm change, then check if CLI detects drift

BEFORE_REV=$(get_revision)

# Direct helm upgrade to inject drift
log_info "Injecting drift via raw helm upgrade..."
helm upgrade "$HELM_RELEASE" "$ILUM_CHART_DIR" \
    -n "$HELM_NAMESPACE" \
    --reuse-values \
    --set ilum-core.env.DRIFT_TEST=true \
    --timeout 10m \
    --wait=false 2>/dev/null || true

# Wait briefly for helm to process
sleep 5

run_test "P6-010" "upgrade --dry-run detects drift" "$ILUM" upgrade --dry-run
# Check if output mentions drift or external changes
if echo "$LAST_STDOUT$LAST_STDERR" | grep -qiE "drift|external|changed|outside"; then
    PASSED_TESTS=$((PASSED_TESTS + 1))
    print_pass "P6-010 — drift detected"
    echo "PASS" > "$TEST_LOG_DIR/P6-010/result.txt"
else
    if [[ "$LAST_EXIT_CODE" -eq 0 ]]; then
        log_issue "UX" "medium" "P6-010" "No drift warning after external helm change"
        PASSED_TESTS=$((PASSED_TESTS + 1))
        print_pass "P6-010 — no drift warning (may be expected if no snapshot)"
        echo "PASS" > "$TEST_LOG_DIR/P6-010/result.txt"
    else
        FAILED_TESTS=$((FAILED_TESTS + 1))
        print_fail "P6-010 — upgrade --dry-run failed after drift injection"
        echo "FAIL" > "$TEST_LOG_DIR/P6-010/result.txt"
        FAILURES+=("P6-010: upgrade --dry-run failed after drift")
    fi
fi

# Clean up the drift change
run_test "P6-011" "upgrade to clean up drift --yes" "$ILUM" upgrade --yes --timeout 15m
assert_exit_code 0 || {
    log_issue "BUG" "medium" "P6-011" "Failed to clean up after drift test"
    true
}

log_info "Phase 6 complete — upgrade & configuration tested"
