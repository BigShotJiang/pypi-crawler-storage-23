#!/usr/bin/env bash
# =============================================================================
# Phase 1: Read-Only Commands
# =============================================================================
# Test all commands that do NOT modify state.
# =============================================================================

print_phase "Phase 1: Read-Only Commands"

# ---- Help flags ----

run_test "P1-001" "ilum --help shows usage" "$ILUM" --help
assert_exit_code 0 || true

run_test "P1-002" "ilum --version shows version" "$ILUM" --version
assert_exit_code 0 || true

run_test "P1-003" "ilum module --help" "$ILUM" module --help
assert_exit_code 0 || true

run_test "P1-004" "ilum config --help" "$ILUM" config --help
assert_exit_code 0 || true

run_test "P1-005" "ilum cluster --help" "$ILUM" cluster --help
assert_exit_code 0 || true

run_test "P1-006" "ilum airgap --help" "$ILUM" airgap --help
assert_exit_code 0 || true

run_test "P1-007" "ilum preset --help" "$ILUM" preset --help
assert_exit_code 0 || true

run_test "P1-008" "ilum install --help" "$ILUM" install --help
assert_exit_code 0 || true

run_test "P1-009" "ilum upgrade --help" "$ILUM" upgrade --help
assert_exit_code 0 || true

run_test "P1-010" "ilum uninstall --help" "$ILUM" uninstall --help
assert_exit_code 0 || true

run_test "P1-011" "ilum status --help" "$ILUM" status --help
assert_exit_code 0 || true

run_test "P1-012" "ilum doctor --help" "$ILUM" doctor --help
assert_exit_code 0 || true

run_test "P1-013" "ilum connect --help" "$ILUM" connect --help
assert_exit_code 0 || true

run_test "P1-014" "ilum init --help" "$ILUM" init --help
assert_exit_code 0 || true

run_test "P1-015" "ilum logs --help" "$ILUM" logs --help
assert_exit_code 0 || true

run_test "P1-016" "ilum history --help" "$ILUM" history --help
assert_exit_code 0 || true

# ---- Module list commands ----

run_test "P1-017" "module list shows all modules" "$ILUM" module list
assert_exit_code 0 || true

run_test "P1-018" "module list --category infrastructure" "$ILUM" module list --category infrastructure
assert_exit_code 0 || true

run_test "P1-019" "module list --category notebook" "$ILUM" module list --category notebook
assert_exit_code 0 || true

run_test "P1-020" "module list --enabled" "$ILUM" module list --enabled
assert_exit_code 0 || true

run_test "P1-021" "module list --disabled" "$ILUM" module list --disabled
assert_exit_code 0 || true

run_test "P1-022" "module list --search kafka" "$ILUM" module list --search kafka
assert_contains "kafka" || true

run_test "P1-023" "module list --search nonexistent" "$ILUM" module list --search zzz_nonexistent_zzz
assert_exit_code 0 || true

# ---- Module show/tree ----

run_test "P1-024" "module show core" "$ILUM" module show core
assert_exit_code 0 || true

run_test "P1-025" "module show airflow" "$ILUM" module show airflow
assert_exit_code 0 || true

run_test "P1-026" "module show nonexistent" "$ILUM" module show nonexistent_module
assert_exit_code_not 0 || true

run_test "P1-027" "module tree airflow" "$ILUM" module tree airflow
assert_exit_code 0 || true

run_test "P1-028" "module tree core" "$ILUM" module tree core
assert_exit_code 0 || true

# ---- Preset list ----

run_test "P1-029" "preset list" "$ILUM" preset list
assert_exit_code 0 || true

# ---- Cluster list ----

run_test "P1-030" "cluster list" "$ILUM" cluster list
assert_exit_code 0 || true

# ---- Output format flags ----

run_test "P1-031" "module list -o json" "$ILUM" --output json module list
assert_exit_code 0 || true

run_test "P1-032" "module list -o yaml" "$ILUM" --output yaml module list
assert_exit_code 0 || true

# ---- Invalid inputs ----

run_test "P1-033" "module list --category invalid" "$ILUM" module list --category fake_category
# Should fail with "Unknown category" error
assert_exit_code_not 0 || true

run_test "P1-034" "invalid global flag" "$ILUM" --output badformat module list
assert_exit_code_not 0 || true

run_test "P1-035" "unknown subcommand" "$ILUM" nonexistent_command
assert_exit_code_not 0 || true

# ---- Performance check for read-only ----

run_test "P1-036" "module list performance" "$ILUM" module list
assert_duration_under 10000 || {
    log_issue "PERF" "medium" "P1-036" "module list took ${LAST_DURATION}ms (>10s)"
    true
}

log_info "Phase 1 complete — read-only commands tested"
