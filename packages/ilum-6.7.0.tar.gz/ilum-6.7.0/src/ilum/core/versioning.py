"""Semantic version parsing and comparison utilities."""

from __future__ import annotations

import re


def parse_version(raw: str) -> tuple[int, ...]:
    """Extract the first semver-like version from a string.

    Returns a tuple ``(major, minor, patch)`` — defaults to ``(0, 0, 0)``
    when no version pattern is found.
    """
    match = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", raw)
    if not match:
        return (0, 0, 0)
    major, minor, patch = match.group(1), match.group(2), match.group(3)
    return (int(major), int(minor), int(patch or 0))


def version_satisfies(version: str, minimum: tuple[int, int]) -> bool:
    """Return ``True`` if *version* is >= *minimum* ``(major, minor)``."""
    parsed = parse_version(version)
    return (parsed[0], parsed[1]) >= minimum


def minor_version_changed(current: str, target: str) -> bool:
    """Return True if current and target differ in their minor version."""
    c = parse_version(current)
    t = parse_version(target)
    if c == (0, 0, 0) or t == (0, 0, 0):
        return False
    return c[0] == t[0] and c[1] != t[1]
