"""Dependency injection for FastAPI — singleton ReleaseManager."""

from __future__ import annotations

from ilum.core.release import ReleaseManager

_manager: ReleaseManager | None = None


def set_manager(mgr: ReleaseManager) -> None:
    """Store the singleton ReleaseManager (called during startup)."""
    global _manager  # noqa: PLW0603
    _manager = mgr


def get_manager() -> ReleaseManager:
    """FastAPI dependency that yields the singleton ReleaseManager."""
    if _manager is None:
        msg = "ReleaseManager not initialised — API is not connected to a release."
        raise RuntimeError(msg)
    return _manager
