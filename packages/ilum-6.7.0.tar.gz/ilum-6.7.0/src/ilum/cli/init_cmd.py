"""``ilum init`` command — interactive setup wizard."""

from __future__ import annotations

import typer

from ilum.cli.output import console
from ilum.config.manager import ConfigManager
from ilum.config.paths import IlumPaths
from ilum.core.modules import ModuleResolver
from ilum.errors import IlumError
from ilum.wizard.flow import InitWizard


def init(
    yes: bool = typer.Option(False, "--yes", "-y", help="Non-interactive mode with defaults."),
    profile: str = typer.Option("default", "--profile", "-p", help="Profile name to create."),
) -> None:
    """Initialize the Ilum CLI with an interactive setup wizard."""
    paths = IlumPaths.default()
    config_mgr = ConfigManager(paths)
    resolver = ModuleResolver()

    wizard = InitWizard(console, config_mgr, resolver)

    try:
        result = wizard.run(non_interactive=yes, profile_name=profile)
    except IlumError as exc:
        console.handle_error(exc)
        raise typer.Exit(code=1) from None
    except KeyboardInterrupt:
        console.warning("Setup interrupted.")
        raise typer.Exit(code=130) from None

    console.success("Setup complete!")
    console.info(f"Active profile: {result.name}")
    console.info("Run 'ilum install' to deploy Ilum.")
