"""Pydantic v2 configuration models for the Ilum CLI."""

from __future__ import annotations

from pydantic import BaseModel


class ClusterConfig(BaseModel):
    kubecontext: str = ""
    namespace: str = "default"
    chart_version: str = ""
    chart_repo: str = "https://charts.ilum.cloud"


class ProfileConfig(BaseModel):
    name: str
    release_name: str = ""
    cluster: ClusterConfig = ClusterConfig()
    enabled_modules: list[str] = []
    communication_type: str = "grpc"
    auth_type: str = "internal"
    access_type: str = "nodeport"
    custom_values_path: str = ""


class ClusterRecord(BaseModel):
    """Tracks a locally-managed Kubernetes cluster."""

    name: str
    provider: str  # "minikube", "k3d", "kind"
    kubecontext: str
    created_at: str = ""
    source: str = "managed"  # "managed" or "detected" — not persisted for detected
    status: str = ""  # "Running", "Stopped", "" — ephemeral


class IlumConfig(BaseModel):
    config_version: str = "1"
    active_profile: str = "default"
    profiles: dict[str, ProfileConfig] = {}
    clusters: list[ClusterRecord] = []
    created_at: str = ""
    updated_at: str = ""
