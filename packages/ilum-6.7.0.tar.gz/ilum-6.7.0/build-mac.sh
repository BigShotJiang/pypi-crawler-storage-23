#!/bin/zsh

chmod +x build-mac-arm64.sh
chmod +x build-mac-x86_64.sh

./build-mac-arm64.sh &
./build-mac-x86_64.sh &
wait

echo "Done building for macOS"