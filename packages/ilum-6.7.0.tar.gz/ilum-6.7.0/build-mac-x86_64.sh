#!/bin/zsh

BDIR=".temp-build-x86_64"
mkdir -p $BDIR
cp -r src $BDIR/
cp -r pyproject.toml $BDIR/
cp -r ilum.spec $BDIR/
cp -r README.md $BDIR/

cd $BDIR

arch -x86_64 /usr/local/bin/brew install uv
arch -x86_64 /usr/local/bin/uv venv --python cpython-3.12-macos-x86_64-none
source ./.venv/bin/activate
arch -x86_64 /usr/local/bin/uv pip install -e '.[build]'
arch -x86_64 pyinstaller ilum.spec --distpath dist/x86_64 --clean

cd ..

cp -r $BDIR/dist/x86_64 dist/x86_64

rm -rf $BDIR