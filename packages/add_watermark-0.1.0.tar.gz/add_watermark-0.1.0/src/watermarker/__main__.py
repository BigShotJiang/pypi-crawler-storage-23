"""Module entrypoint for `python -m watermarker`."""

from __future__ import annotations

from watermarker.cli import main


if __name__ == "__main__":
    main()
