# /// script
# dependencies = [
#   "pygame-turbo",
#   "pygame-ce",
#   "cffi",
#   "pymunk",
# ]
# ///

import pygame_turbo


async def main():
    """initializing the engine and starting the main scene."""

    pygame_turbo.debug = False

    # Initialize the display (window size, title, etc.)
    pygame_turbo.Display.init(
        title="Test",
        resolution=(600, 600),
        fullscreen=False,
        resizable=True,
        stretch=False,
    )

    # Load game assets (e.g., images, sounds, etc.)
    pygame_turbo.Assets.init(pre_load=True, scenes="/scenes")

    # Create and configure the initial scene (scene name,**kwargs)
    pygame_turbo.Scene.manager.create("game", max_fps=-1)

    # Start the async scene
    await pygame_turbo.Scene.manager.start()


if __name__ == "__main__":
    pygame_turbo.asyncio.run(main)
