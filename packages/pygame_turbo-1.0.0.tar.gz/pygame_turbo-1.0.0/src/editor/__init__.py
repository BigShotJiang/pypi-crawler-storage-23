"""
Editor Module
Provides an integrated development environment for pygame_turbo projects.
"""

from .app import run_editor

__all__ = ["run_editor"]
