# Dummy Markdown

This is a **dummy** markdown file for tests.

## Section one

- Item one
- Item two
- Item three

## Section two

Some `inline code` and a [link](https://example.com).

```text
A code block for testing.
```

> A blockquote.
