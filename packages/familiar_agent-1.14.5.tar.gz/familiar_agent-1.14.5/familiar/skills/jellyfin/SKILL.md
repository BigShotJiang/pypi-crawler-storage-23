# Jellyfin

Manage and browse your Jellyfin media server.

## Usage

Use this skill when the user asks about their personal media library — movies, TV shows, music, or audiobooks hosted on Jellyfin. This includes searching for titles, checking what's currently playing, browsing libraries, and starting playback on a specific device.

## Examples

- "Do I have The Matrix?"
- "What's currently playing on Jellyfin?"
- "Play Blade Runner on the living room TV"
- "Show me what's in my movie library"
- "List Jellyfin users"
- "Search for any Studio Ghibli films"
- "What shows do I have?"

## Important

- Always use `jf_search_media` before `jf_play_media` to get the correct item ID.
- Playback requires a valid session — use `jf_now_playing` to find active sessions/devices.
- Media titles may have multiple versions (4K, 1080p); confirm with the user if ambiguous.

## Disambiguation

- This is **NOT** for streaming services (Netflix, Hulu, etc.) — only self-hosted Jellyfin.
- This is **NOT** for local media files on disk — use `read_document` or `run_shell` for local files.
- This is **NOT** for YouTube or web video — use browser tools or `web_search` instead.

## Setup

Set `JELLYFIN_URL`, `JELLYFIN_TOKEN`, and `JELLYFIN_USER_ID` environment variables.

## Tools

- `jf_search_media` — Search for media items
- `jf_now_playing` — Show currently playing sessions
- `jf_play_media` — Start playing media on a session (requires confirmation)
- `jf_get_library` — Browse a library's contents
- `jf_list_users` — List Jellyfin users
