*****
Usage
*****

.. _Activate an Incoterm for a company:

Activate an Incoterm for a company
==================================

To allow the usage of an `Incoterm <model-incoterm.incoterm>` in Tryton, you
must add it to the :guilabel:`Incoterms` field of the `Company
<company:model-company.company>`.
You can also remove it later to prevent it from being used in the future.
