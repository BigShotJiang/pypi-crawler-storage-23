---
name: Slow Task
cron: "0 0 * * *"
active: true
---
sleep 5
