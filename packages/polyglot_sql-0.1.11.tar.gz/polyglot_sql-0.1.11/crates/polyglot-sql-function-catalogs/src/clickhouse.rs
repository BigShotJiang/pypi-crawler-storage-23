use crate::{CatalogSink, FunctionNameCase, FunctionSignature};

/// Register the ClickHouse function catalog.
///
/// This file is generated from the extracted function list discussed in
/// https://github.com/tobilg/polyglot/pull/14 and contains core functions and aliases.
pub(crate) fn register<S: CatalogSink>(catalog: &mut S) {
    let d = "clickhouse";
    catalog.set_dialect_name_case(d, FunctionNameCase::Insensitive);
    catalog.register(d, "__actionName", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "__bitBoolMaskAnd", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "__bitBoolMaskOr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "__bitSwapLastTwo", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "__bitWrapperFunc", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "__filterContains", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "__getScalar", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "__patchPartitionID",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "__scalarSubqueryResult",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "_CAST", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "abs", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "accurateCast", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "accurateCastOrDefault",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "accurateCastOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "acos", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "acosh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "addDate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addDays", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addHours", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addInterval", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addMicroseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addMilliseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addMinutes", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addMonths", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addNanoseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addQuarters", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addressToLine", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "addressToLineWithInlines",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "addressToSymbol", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "addSeconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addTupleOfIntervals", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addWeeks", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "addYears", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "aes_decrypt_mysql", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "aes_encrypt_mysql", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "age", vec![FunctionSignature::range(3, 4)]);
    catalog.register(d, "aggThrow", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "alphaTokens", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "analysisOfVariance",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "and", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "any", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "any_respect_nulls", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "anyHeavy", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "anyLast", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "anyLast_respect_nulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "appendTrailingCharIfAbsent",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "approx_top_k", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "approx_top_sum", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "argMax", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "argMin", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "array", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayAll", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayAUCPR", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayAvg", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayCompact", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayConcat", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayCount", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "arrayCumSum", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "arrayCumSumNonNegative",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "arrayDifference", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayDistinct", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayDotProduct", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayElement", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayElementOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayEnumerate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayEnumerateDense", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "arrayEnumerateDenseRanked",
        vec![FunctionSignature::exact(3)],
    );
    catalog.register(
        d,
        "arrayEnumerateUniq",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "arrayEnumerateUniqRanked",
        vec![FunctionSignature::exact(3)],
    );
    catalog.register(d, "arrayExcept", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayExists", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayFill", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayFilter", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "arrayFirst", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayFirstIndex", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayFirstOrNull", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayFlatten", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayFold", vec![FunctionSignature::variadic(3)]);
    catalog.register(d, "arrayIntersect", vec![FunctionSignature::variadic(3)]);
    catalog.register(d, "arrayJaccardIndex", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayJoin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayLast", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayLastIndex", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayLastOrNull", vec![FunctionSignature::variadic(2)]);
    catalog.register(
        d,
        "arrayLevenshteinDistance",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "arrayLevenshteinDistanceWeighted",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "arrayMap", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayMax", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayMin", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayNormalizedGini", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "arrayPartialReverseSort",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "arrayPartialShuffle", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayPartialSort", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayPopBack", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayPopFront", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayProduct", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayPushBack", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayPushFront", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayRandomSample", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayReduce", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "arrayReduceInRanges",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "arrayResize", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayReverse", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arrayReverseFill", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayReverseSort", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "arrayReverseSplit", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayROCAUC", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayRotateLeft", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayRotateRight", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayShiftLeft", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayShiftRight", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayShingles", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayShuffle", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arraySimilarity", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "arraySlice", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arraySort", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "arraySplit", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "arrayStringConcat", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "arraySum", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "arraySymmetricDifference",
        vec![FunctionSignature::variadic(3)],
    );
    catalog.register(d, "arrayUnion", vec![FunctionSignature::variadic(3)]);
    catalog.register(d, "arrayUniq", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "arrayWithConstant", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayZip", vec![FunctionSignature::variadic(3)]);
    catalog.register(d, "arrayZipUnaligned", vec![FunctionSignature::variadic(3)]);
    catalog.register(d, "ascii", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "asin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "asinh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "assumeNotNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "atan", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "atan2", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "atanh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "avg", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "avgWeighted", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "bar", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "base32Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base32Encode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base58Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base58Encode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base64Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base64Encode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base64URLDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "base64URLEncode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "basename", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bech32Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bech32Encode", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitAnd", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitCount", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitHammingDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapAnd", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapAndCardinality", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapAndnot", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "bitmapAndnotCardinality",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "bitmapBuild", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmapCardinality", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmapContains", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapHasAll", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapHasAny", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapMax", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmapMin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmapOr", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapOrCardinality", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapSubsetInRange", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "bitmapSubsetLimit", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "bitmapToArray", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmapTransform", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "bitmapXor", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmapXorCardinality", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitmaskToArray", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitmaskToList", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitNot", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitOr", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitPositionsToArray", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "bitRotateLeft", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitRotateRight", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitShiftLeft", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitShiftRight", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitSlice", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitTest", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "bitTestAll", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "bitTestAny", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "bitXor", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "BLAKE3", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "blockNumber", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "blockSerializedSize",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "blockSize", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "boundingRatio", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "buildId", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "byteHammingDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "byteSize", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "byteSwap", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "caseWithExpression",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "CAST", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "catboostEvaluate", vec![FunctionSignature::variadic(2)]);
    catalog.register(
        d,
        "categoricalInformationValue",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "cbrt", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ceil", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "changeDay", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "changeHour", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "changeMinute", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "changeMonth", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "changeSecond", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "changeYear", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "char", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "cityHash64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "clamp", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "coalesce", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "colorOKLCHToSRGB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "colorSRGBToOKLCH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "compareSubstrings", vec![FunctionSignature::exact(5)]);
    catalog.register(d, "concat", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "concatAssumeInjective",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "concatWithSeparator",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "concatWithSeparatorAssumeInjective",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "connectionId", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "contingency", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "conv", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "convertCharset", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "corr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "corrMatrix", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "corrStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "cos", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "cosh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "cosineDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "count", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "countDigits", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "countEqual", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "countMatches", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "countMatchesCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "countSubstrings", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "countSubstringsCaseInsensitive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "countSubstringsCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "covarPop", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "covarPopMatrix", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "covarPopStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "covarSamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "covarSampMatrix", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "covarSampStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "cramersV", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "cramersVBiasCorrected",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "CRC32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "CRC32IEEE", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "CRC64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "currentDatabase", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "currentProfiles", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "currentQueryID", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "currentRoles", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "currentSchemas", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "currentUser", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "cutFragment", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "cutIPv6", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "cutQueryString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "cutQueryStringAndFragment",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomain",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainCustom",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainCustomRFC",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainCustomWithWWW",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainCustomWithWWWRFC",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainRFC",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainWithWWW",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "cutToFirstSignificantSubdomainWithWWWRFC",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "cutURLParameter", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "cutWWW", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "damerauLevenshteinDistance",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "DATE", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "dateDiff", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "dateName", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "dateTime64ToSnowflake",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "dateTime64ToSnowflakeID",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "dateTimeToSnowflake", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "dateTimeToSnowflakeID",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "dateTimeToUUIDv7", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "dateTrunc", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "decodeHTMLComponent", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "decodeURLComponent", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "decodeURLFormComponent",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "decodeXMLComponent", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "decrypt", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "defaultProfiles", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "defaultRoles", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "defaultValueOfArgumentType",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "defaultValueOfTypeName",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "degrees", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "deltaSum", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "deltaSumTimestamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "demangle", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "denseRank", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "detectCharset", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "detectLanguage", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "detectLanguageMixed", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "detectLanguageUnknown",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "detectProgrammingLanguage",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "detectTonality", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "dictGet", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetAll", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetChildren", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "dictGetDate", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetDateOrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictGetDateTime", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetDateTimeOrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetDescendants", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetFloat32", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetFloat32OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetFloat64", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetFloat64OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetHierarchy", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "dictGetInt16", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetInt16OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetInt32", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetInt32OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetInt64", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetInt64OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetInt8", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetInt8OrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictGetIPv4", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetIPv4OrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictGetIPv6", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetIPv6OrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictGetOrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictGetOrNull", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetString", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetStringOrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetUInt16", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetUInt16OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetUInt32", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetUInt32OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetUInt64", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetUInt64OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetUInt8", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "dictGetUInt8OrDefault",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "dictGetUUID", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "dictGetUUIDOrDefault", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "dictHas", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "dictIsIn", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "displayName", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "distinctDynamicTypes",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "distinctJSONPaths", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "distinctJSONPathsAndTypes",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "divide", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "divideDecimal", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "divideOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "domain", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "domainRFC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "domainWithoutWWW", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "domainWithoutWWWRFC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "dotProduct", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "dumpColumnStructure", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "dynamicElement", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "dynamicType", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "e", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "editDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "editDistanceUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "empty", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "emptyArrayDate", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayDateTime", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayFloat32", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayFloat64", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayInt16", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayInt32", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayInt64", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayInt8", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayString", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayToSingle", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "emptyArrayUInt16", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayUInt32", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayUInt64", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "emptyArrayUInt8", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "enabledProfiles", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "enabledRoles", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "encodeURLComponent", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "encodeURLFormComponent",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "encodeXMLComponent", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "encrypt", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "endsWith", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "endsWithCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "endsWithCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "endsWithUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "entropy", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "equals", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "erf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "erfc", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "errorCodeToName", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "estimateCompressionRatio",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "evalMLMethod", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "exp", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "exp10", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "exp2", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "exponentialMovingAverage",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "exponentialTimeDecayedAvg",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "exponentialTimeDecayedCount",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "exponentialTimeDecayedMax",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "exponentialTimeDecayedSum",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "extract", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "extractAll", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "extractAllGroupsHorizontal",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "extractAllGroupsVertical",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "extractGroups", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "extractKeyValuePairs",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "extractKeyValuePairsWithEscaping",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "extractTextFromHTML", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "extractURLParameter", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "extractURLParameterNames",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "extractURLParameters", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "factorial", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "farmFingerprint64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "farmHash64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "file", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "filesystemAvailable",
        vec![FunctionSignature::range(0, 1)],
    );
    catalog.register(
        d,
        "filesystemCapacity",
        vec![FunctionSignature::range(0, 1)],
    );
    catalog.register(
        d,
        "filesystemUnreserved",
        vec![FunctionSignature::range(0, 1)],
    );
    catalog.register(d, "finalizeAggregation", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "financialInternalRateOfReturn",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "financialInternalRateOfReturnExtended",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "financialNetPresentValue",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "financialNetPresentValueExtended",
        vec![FunctionSignature::exact(3)],
    );
    catalog.register(d, "firstLine", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "firstNonDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "firstSignificantSubdomain",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "firstSignificantSubdomainCustom",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "firstSignificantSubdomainCustomRFC",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "firstSignificantSubdomainRFC",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "flameGraph", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "flattenTuple", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "floor", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "format", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "formatDateTime", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "formatDateTimeInJodaSyntax",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "formatQuery", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "formatQueryOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "formatQuerySingleLine",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "formatQuerySingleLineOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "formatReadableDecimalSize",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "formatReadableQuantity",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "formatReadableSize", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "formatReadableTimeDelta",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "formatRow", vec![FunctionSignature::variadic(3)]);
    catalog.register(
        d,
        "formatRowNoNewline",
        vec![FunctionSignature::variadic(3)],
    );
    catalog.register(d, "FQDN", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "fragment", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "fromDaysSinceYearZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromDaysSinceYearZero32",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromModifiedJulianDay",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromModifiedJulianDayOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "fromUnixTimestamp", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "fromUnixTimestamp64Micro",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromUnixTimestamp64Milli",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromUnixTimestamp64Nano",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromUnixTimestamp64Second",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "fromUnixTimestampInJodaSyntax",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "fromUTCTimestamp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "fuzzBits", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "gccMurmurHash", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "gcd", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "generateRandomStructure",
        vec![FunctionSignature::range(0, 2)],
    );
    catalog.register(d, "generateSerialID", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "generateSnowflakeID",
        vec![FunctionSignature::range(0, 2)],
    );
    catalog.register(d, "generateULID", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "generateUUIDv4", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "generateUUIDv7", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "geoDistance", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "geohashDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "geohashEncode", vec![FunctionSignature::range(2, 3)]);
    catalog.register(d, "geohashesInBox", vec![FunctionSignature::exact(5)]);
    catalog.register(d, "geoToH3", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "geoToS2", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "getClientHTTPHeader", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getMacro", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "getMaxTableNameLengthForDatabase",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "getMergeTreeSetting", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getOSKernelVersion", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "getServerPort", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getServerSetting", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getSetting", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getSettingOrDefault", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "getSizeOfEnumType", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "getSubcolumn", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "getTypeSerializationStreams",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "globalIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "globalInIgnoreSet", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "globalNotIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "globalNotInIgnoreSet",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "globalNotNullIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "globalNotNullInIgnoreSet",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "globalNullIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "globalNullInIgnoreSet",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "globalVariable", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "greatCircleAngle", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "greatCircleDistance", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "greater", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "greaterOrEquals", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "greatest", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "groupArray", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "groupArrayInsertAt",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "groupArrayIntersect",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "groupArrayLast", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "groupArrayMovingAvg",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "groupArrayMovingSum",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "groupArraySample", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupArraySorted", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitAnd", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitmap", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitmapAnd", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitmapOr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitmapXor", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitOr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupBitXor", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "groupConcat", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "groupNumericIndexedVector",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "groupUniqArray", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "h3CellAreaM2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3CellAreaRads2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3Distance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3EdgeAngle", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3EdgeLengthKm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3EdgeLengthM", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3ExactEdgeLengthKm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3ExactEdgeLengthM", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "h3ExactEdgeLengthRads",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "h3GetBaseCell", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "h3GetDestinationIndexFromUnidirectionalEdge",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "h3GetFaces", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "h3GetIndexesFromUnidirectionalEdge",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "h3GetOriginIndexFromUnidirectionalEdge",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "h3GetPentagonIndexes", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3GetRes0Indexes", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "h3GetResolution", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "h3GetUnidirectionalEdge",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "h3GetUnidirectionalEdgeBoundary",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "h3GetUnidirectionalEdgesFromHexagon",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "h3HexAreaKm2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3HexAreaM2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3HexRing", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "h3IndexesAreNeighbors",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "h3IsPentagon", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3IsResClassIII", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3IsValid", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3kRing", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3Line", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3NumHexagons", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3PointDistKm", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "h3PointDistM", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "h3PointDistRads", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "h3ToCenterChild", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3ToChildren", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3ToGeo", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3ToGeoBoundary", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "h3ToParent", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "h3ToString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "h3UnidirectionalEdgeIsValid",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "halfMD5", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "has", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasAll", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasAllTokens", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasAny", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasAnyTokens", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasColumnInTable", vec![FunctionSignature::range(2, 6)]);
    catalog.register(d, "hasSubsequence", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "hasSubsequenceCaseInsensitive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "hasSubsequenceCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "hasSubsequenceUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "hasSubstr", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasThreadFuzzer", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "hasToken", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "hasTokenCaseInsensitive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "hasTokenCaseInsensitiveOrNull",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "hasTokenOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hex", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "hilbertDecode", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hilbertEncode", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "histogram", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "hiveHash", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "hop", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "hopEnd", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "hopStart", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "hostName", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "hypot", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "icebergBucket", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "icebergHash", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "icebergTruncate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "identity", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "idnaDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "idnaEncode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "if", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "ifNotFinite", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ifNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ignore", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ilike", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "in", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "indexHint", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "indexOf", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "indexOfAssumeSorted", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "inIgnoreSet", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "initcap", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "initcapUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "initializeAggregation",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(d, "initialQueryID", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "initialQueryStartTime",
        vec![FunctionSignature::exact(0)],
    );
    catalog.register(d, "intDiv", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "intDivOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "intDivOrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "intervalLengthSum", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "intExp10", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "intExp2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "intHash32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "intHash64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "IPv4CIDRToRange", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "IPv4NumToString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "IPv4NumToStringClassC",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "IPv4StringToNum", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "IPv4StringToNumOrDefault",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "IPv4StringToNumOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "IPv4ToIPv6", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "IPv6CIDRToRange", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "IPv6NumToString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "IPv6StringToNum", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "IPv6StringToNumOrDefault",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "IPv6StringToNumOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "isConstant", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isDecimalOverflow", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "isDynamicElementInSharedData",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "isFinite", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isInfinite", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isIPAddressInRange", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "isIPv4String", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isIPv6String", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "isMergeTreePartCoveredBy",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "isNaN", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isNotDistinctFrom", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "isNotNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isNullable", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isValidASCII", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "isValidJSON", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isValidUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "isZeroOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "jaroSimilarity", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "jaroWinklerSimilarity",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "javaHash", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "javaHashUTF16LE", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "joinGet", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "joinGetOrNull", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "JSON_EXISTS", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "JSON_QUERY", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "JSON_VALUE", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "JSONAllPaths", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "JSONAllPathsWithTypes",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "JSONArrayLength", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "JSONDynamicPaths", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "JSONDynamicPathsWithTypes",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "JSONExtract", vec![FunctionSignature::variadic(2)]);
    catalog.register(
        d,
        "JSONExtractArrayRaw",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "JSONExtractArrayRawCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractBool", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractBoolCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "JSONExtractCaseInsensitive",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(d, "JSONExtractFloat", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractFloatCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractInt", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractIntCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractKeys", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractKeysAndValues",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(
        d,
        "JSONExtractKeysAndValuesCaseInsensitive",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(
        d,
        "JSONExtractKeysAndValuesRaw",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "JSONExtractKeysAndValuesRawCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "JSONExtractKeysCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractRaw", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractRawCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractString", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractStringCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONExtractUInt", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "JSONExtractUIntCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "JSONHas", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "JSONKey", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "JSONLength", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "JSONMergePatch", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "JSONSharedDataPaths", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "JSONSharedDataPathsWithTypes",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "JSONType", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "jumpConsistentHash", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "kafkaMurmurHash", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "keccak256", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "kolmogorovSmirnovTest",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "kostikConsistentHash", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "kql_array_sort_asc",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "kql_array_sort_desc",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "kurtPop", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "kurtSamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "L1Distance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "L1Norm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "L1Normalize", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "L2Distance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "L2DistanceTransposed", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "L2Norm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "L2Normalize", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "L2SquaredDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "L2SquaredNorm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lag", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "lagInFrame", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "largestTriangleThreeBuckets",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "lcm", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "lead", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "leadInFrame", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "least", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "left", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "leftPad", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "leftPadUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "leftUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "lemmatize", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "length", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lengthUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "less", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "lessOrEquals", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "lgamma", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "like", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "linear_equation", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "LinfDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "LinfNorm", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "LinfNormalize", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "locate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "log", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "log10", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "log1p", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "log2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "logTrace", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "lowCardinalityIndices",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "lowCardinalityKeys", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lower", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lowerUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "LpDistance", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "LpNorm", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "LpNormalize", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "MACNumToString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "MACStringToNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "MACStringToOUI", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "makeDate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "makeDate32", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "makeDateTime", vec![FunctionSignature::exact(6)]);
    catalog.register(d, "makeDateTime64", vec![FunctionSignature::exact(6)]);
    catalog.register(d, "mannWhitneyUTest", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "map", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "mapAdd", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "mapAll", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "mapApply", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapConcat", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "mapContainsKey", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapContainsKeyLike", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapContainsValue", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapContainsValueLike", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapExists", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "mapExtractKeyLike", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapExtractValueLike", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapFilter", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapFromArrays", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapKeys", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "mapPartialReverseSort",
        vec![FunctionSignature::range(1, 3)],
    );
    catalog.register(d, "mapPartialSort", vec![FunctionSignature::range(1, 3)]);
    catalog.register(d, "mapPopulateSeries", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapReverseSort", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "mapSort", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "mapSubtract", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "mapUpdate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapValues", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "match", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "materialize", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "max", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "max2", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "maxIntersections", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "maxIntersectionsPosition",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "maxMappedArrays", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "MD4", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "MD5", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "meanZTest", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "mergeTreePartInfo", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "metroHash64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "min", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "min2", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "minMappedArrays", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "minSampleSizeContinuous",
        vec![FunctionSignature::exact(5)],
    );
    catalog.register(
        d,
        "minSampleSizeConversion",
        vec![FunctionSignature::exact(4)],
    );
    catalog.register(d, "minus", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "modulo", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "moduloLegacy", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "moduloOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "moduloOrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "monthName", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "mortonDecode", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mortonEncode", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "multiFuzzyMatchAllIndices",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiFuzzyMatchAny",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiFuzzyMatchAnyIndex",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "multiIf", vec![FunctionSignature::variadic(5)]);
    catalog.register(
        d,
        "multiMatchAllIndices",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "multiMatchAny", vec![FunctionSignature::variadic(2)]);
    catalog.register(
        d,
        "multiMatchAnyIndex",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "multiply", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "multiplyDecimal", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "multiSearchAllPositions",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(
        d,
        "multiSearchAllPositionsCaseInsensitive",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(
        d,
        "multiSearchAllPositionsCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiSearchAllPositionsUTF8",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(d, "multiSearchAny", vec![FunctionSignature::variadic(2)]);
    catalog.register(
        d,
        "multiSearchAnyCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "multiSearchAnyCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "multiSearchAnyUTF8",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "multiSearchFirstIndex",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiSearchFirstIndexCaseInsensitive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiSearchFirstIndexCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiSearchFirstIndexUTF8",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "multiSearchFirstPosition",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(
        d,
        "multiSearchFirstPositionCaseInsensitive",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "multiSearchFirstPositionCaseInsensitiveUTF8",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "multiSearchFirstPositionUTF8",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(d, "murmurHash2_32", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "murmurHash2_64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "murmurHash3_128", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "murmurHash3_32", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "murmurHash3_64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "negate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "neighbor", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "nested", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "netloc", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ngramDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "ngramDistanceCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "ngramDistanceCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "ngramDistanceUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ngramMinHash", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ngramMinHashArg", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "ngramMinHashArgCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "ngramMinHashArgCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "ngramMinHashArgUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "ngramMinHashCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "ngramMinHashCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "ngramMinHashUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ngrams", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ngramSearch", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "ngramSearchCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "ngramSearchCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "ngramSearchUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ngramSimHash", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "ngramSimHashCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "ngramSimHashCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "ngramSimHashUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "nonNegativeDerivative",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "normalizedQueryHash", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "normalizedQueryHashKeepNames",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "normalizeQuery", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "normalizeQueryKeepNames",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "normalizeUTF8NFC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeUTF8NFD", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeUTF8NFKC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeUTF8NFKD", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "not", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "notEmpty", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "notEquals", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "nothing", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "nothingNull", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "nothingUInt64", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "notILike", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "notIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "notInIgnoreSet", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "notLike", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "notNullIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "notNullInIgnoreSet",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "now", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "now64", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "nowInBlock", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "nowInBlock64", vec![FunctionSignature::range(0, 2)]);
    catalog.register(d, "nth_value", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "ntile", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "nullIf", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "nullIn", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "nullInIgnoreSet", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "numericIndexedVectorAllValueSum",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "numericIndexedVectorBuild",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "numericIndexedVectorCardinality",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "numericIndexedVectorGetValue",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseAdd",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseDivide",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseEqual",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseGreater",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseGreaterEqual",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseLess",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseLessEqual",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseMultiply",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseNotEqual",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorPointwiseSubtract",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "numericIndexedVectorShortDebugString",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "numericIndexedVectorToMap",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "or", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "overlay", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "overlayUTF8", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "parseDateTime", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "parseDateTime32BestEffort",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime32BestEffortOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime32BestEffortOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "parseDateTime64", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "parseDateTime64BestEffort",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64BestEffortOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64BestEffortOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64BestEffortUS",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64BestEffortUSOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64BestEffortUSOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTime64InJodaSyntax",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTime64InJodaSyntaxOrNull",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTime64InJodaSyntaxOrZero",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTime64OrNull",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTime64OrZero",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffort",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffortOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffortOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffortUS",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffortUSOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeBestEffortUSOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseDateTimeInJodaSyntax",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTimeInJodaSyntaxOrNull",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "parseDateTimeInJodaSyntaxOrZero",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "parseDateTimeOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "parseDateTimeOrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "parseReadableSize", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "parseReadableSizeOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "parseReadableSizeOrZero",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "parseTimeDelta", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "partitionId", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "path", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "pathFull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "percentRank", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "pi", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "plus", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "pointInEllipses", vec![FunctionSignature::variadic(10)]);
    catalog.register(d, "pointInPolygon", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "polygonAreaCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonAreaSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonConvexHullCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonPerimeterCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonPerimeterSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsDistanceCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsDistanceSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsEqualsCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsIntersectCartesian",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "polygonsIntersectionCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsIntersectionSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsIntersectSpherical",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "polygonsSymDifferenceCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsSymDifferenceSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsUnionCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsUnionSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsWithinCartesian",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "polygonsWithinSpherical",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "port", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "portRFC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "position", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "positionCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "positionCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "positionUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "positiveModulo", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "positiveModuloOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "pow", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "printf", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "proportionsZTest", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "protocol", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "punycodeDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "punycodeEncode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "quantile", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "quantileBFloat16", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileBFloat16Weighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileDD", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileDeterministic",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileExact", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileExactExclusive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileExactHigh", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileExactInclusive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileExactLow", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileExactWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantileExactWeightedInterpolated",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileGK", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileInterpolatedWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantilePrometheusHistogram",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantiles", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "quantilesBFloat16", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesBFloat16Weighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesDD", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesDeterministic",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesExact", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesExactExclusive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantilesExactHigh",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantilesExactInclusive",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesExactLow", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesExactWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantilesExactWeightedInterpolated",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesGK", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesInterpolatedWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "quantilesPrometheusHistogram",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesTDigest", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesTDigestWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantilesTiming", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantilesTimingWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileTDigest", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileTDigestWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "quantileTiming", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "quantileTimingWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "queryID", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "queryString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "queryStringAndFragment",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "radians", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "rand", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "rand64", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "randBernoulli", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randBinomial", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "randCanonical", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "randChiSquared", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randConstant", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "randExponential", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randFisherF", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "randLogNormal", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "randNegativeBinomial", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "randNormal", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "randomFixedString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randomPrintableASCII", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randomString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randomStringUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randPoisson", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randStudentT", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "randUniform", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "range", vec![FunctionSignature::range(0, 3)]);
    catalog.register(d, "rank", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "rankCorr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "readWKBLineString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "readWKBMultiLineString",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "readWKBMultiPolygon", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "readWKBPoint", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "readWKBPolygon", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "readWKTLineString", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "readWKTMultiLineString",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "readWKTMultiPolygon",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "readWKTPoint", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "readWKTPolygon", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "readWKTRing", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "regexpExtract", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "regexpQuoteMeta", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionHierarchy", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionIn", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "regionToArea", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToCity", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToContinent", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToCountry", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToDistrict", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToName", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToPopulation", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "regionToTopContinent", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpret", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "reinterpretAsDate", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "reinterpretAsDateTime",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "reinterpretAsFixedString",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "reinterpretAsFloat32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsFloat64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt128", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt16", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt256", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsInt8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt128", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt16", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt256", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUInt8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reinterpretAsUUID", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "repeat", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "replaceAll", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "replaceOne", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "replaceRegexpAll", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "replaceRegexpOne", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "replicate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "retention", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "reverse", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "reverseUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "revision", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "right", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "rightPad", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "rightPadUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "rightUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "RIPEMD160", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "round", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "roundAge", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "roundBankers", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "roundDown", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "roundDuration", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "roundToExp2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "row_number", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "rowNumberInAllBlocks", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "rowNumberInBlock", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "runningAccumulate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "runningConcurrency", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "runningDifference", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "runningDifferenceStartingWithFirstValue",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "s2CapContains", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2CapUnion", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2CellsIntersect", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2GetNeighbors", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2RectAdd", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2RectContains", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "s2RectIntersection",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "s2RectUnion", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "s2ToGeo", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sequenceCount", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sequenceMatch", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "sequenceMatchEvents",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "sequenceNextNode", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "seriesDecomposeSTL", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "seriesOutliersDetectTukey",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "seriesPeriodDetectFFT",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "serverTimezone", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "serverUUID", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "SHA1", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "SHA224", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "SHA256", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "SHA384", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "SHA512", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "SHA512_256", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "shardCount", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "shardNum", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "showCertificate", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "sigmoid", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sign", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "simpleJSONExtractBool",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "simpleJSONExtractFloat",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "simpleJSONExtractInt", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "simpleJSONExtractRaw", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "simpleJSONExtractString",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "simpleJSONExtractUInt",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "simpleJSONHas", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "simpleLinearRegression",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "sin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "singleValueOrNull", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sinh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sipHash128", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "sipHash128Keyed", vec![FunctionSignature::variadic(1)]);
    catalog.register(
        d,
        "sipHash128Reference",
        vec![FunctionSignature::variadic(1)],
    );
    catalog.register(
        d,
        "sipHash128ReferenceKeyed",
        vec![FunctionSignature::variadic(2)],
    );
    catalog.register(d, "sipHash64", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "sipHash64Keyed", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "skewPop", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "skewSamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sleep", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sleepEachRow", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "snowflakeIDToDateTime",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "snowflakeIDToDateTime64",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "snowflakeToDateTime", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "snowflakeToDateTime64",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "soundex", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "space", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sparkbar", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sparseGrams", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sparseGramsHashes", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "sparseGramsHashesUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "sparseGramsUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "splitByChar", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "splitByNonAlpha", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "splitByRegexp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "splitByString", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "splitByWhitespace", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sqidDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sqidEncode", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "sqrt", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "startsWith", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "startsWithCaseInsensitive",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "startsWithCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "startsWithUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "stddevPop", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "stddevPopStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "stddevSamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "stddevSampStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "stem", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "stochasticLinearRegression",
        vec![FunctionSignature::variadic(3)],
    );
    catalog.register(
        d,
        "stochasticLogisticRegression",
        vec![FunctionSignature::variadic(3)],
    );
    catalog.register(d, "stringBytesEntropy", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "stringBytesUniq", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "stringJaccardIndex", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "stringJaccardIndexUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "stringToH3", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "structureToCapnProtoSchema",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "structureToProtobufSchema",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "studentTTest", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "studentTTestOneSample",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "subBitmap", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "subDate", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "substring", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "substringIndex", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "substringIndexUTF8", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "substringUTF8", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractDays", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractHours", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractInterval", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractMicroseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractMilliseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractMinutes", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractMonths", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractNanoseconds", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractQuarters", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractSeconds", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "subtractTupleOfIntervals",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "subtractWeeks", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "subtractYears", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "sum", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sumCount", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sumKahan", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "sumMapFiltered", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "sumMapFilteredWithOverflow",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "sumMappedArrays", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "sumMapWithOverflow",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "sumWithOverflow", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "svg", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "synonyms", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tan", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tanh", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tcpPort", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "tgamma", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "theilsU", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "throwIf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tid", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "timeDiff", vec![FunctionSignature::range(3, 4)]);
    catalog.register(
        d,
        "timeSeriesChangesToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesDeltaToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesDerivToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "timeSeriesFromGrid", vec![FunctionSignature::exact(4)]);
    catalog.register(
        d,
        "timeSeriesGroupArray",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "timeSeriesIdToTags", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "timeSeriesIdToTagsGroup",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "timeSeriesInstantDeltaToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesInstantRateToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesLastTwoSamples",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesPredictLinearToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "timeSeriesRange", vec![FunctionSignature::exact(3)]);
    catalog.register(
        d,
        "timeSeriesRateToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesResampleToGridWithStaleness",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesResetsToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesStoreTags",
        vec![FunctionSignature::variadic(4)],
    );
    catalog.register(
        d,
        "timeSeriesTagsGroupToTags",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "timeSlot", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "timeSlots", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "timestamp", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "timezone", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "timezoneOf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "timezoneOffset", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toBFloat16", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toBFloat16OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toBFloat16OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toBool", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toColumnTypeName", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDate32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDate32OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toDate32OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDate32OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateOrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toDateOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateOrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateTime", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateTime32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateTime64", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "toDateTime64OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDateTime64OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateTime64OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toDateTimeOrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDateTimeOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDateTimeOrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "today", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "toDayOfMonth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDayOfWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDayOfYear", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDaysSinceYearZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toDecimal128", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "toDecimal128OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDecimal128OrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal128OrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal256", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "toDecimal256OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDecimal256OrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal256OrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal32", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "toDecimal32OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDecimal32OrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal32OrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal64", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "toDecimal64OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toDecimal64OrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimal64OrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toDecimalString", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toFixedString", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toFloat32", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toFloat32OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toFloat32OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toFloat32OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toFloat64", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toFloat64OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toFloat64OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toFloat64OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toHour", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt128", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt128OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt128OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt128OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt16", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt16OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt16OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt16OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt256", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt256OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt256OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt256OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt32OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt32OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt32OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt64OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt64OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt64OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt8OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toInt8OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInt8OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toInterval", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toIntervalDay", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalHour", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toIntervalMicrosecond",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "toIntervalMillisecond",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "toIntervalMinute", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalMonth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalNanosecond", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalQuarter", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalSecond", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIntervalYear", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv4", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv4OrDefault", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv4OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv4OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv6", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv6OrDefault", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv6OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toIPv6OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toISOWeek", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toISOYear", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toJSONString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tokens", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toLastDayOfMonth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toLastDayOfWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toLowCardinality", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toMillisecond", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toMinute", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toModifiedJulianDay", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toModifiedJulianDayOrNull",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "toMonday", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toMonth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toMonthNumSinceEpoch", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toNullable", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "topK", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "topKWeighted", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "topLevelDomain", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "topLevelDomainRFC", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toQuarter", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeDayNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeHourNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeMinuteNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeMonthNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeQuarterNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeSecondNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeWeekNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toRelativeYearNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toSecond", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfDay", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toStartOfFifteenMinutes",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "toStartOfFiveMinutes", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfHour", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfInterval", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toStartOfISOYear", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toStartOfMicrosecond",
        vec![FunctionSignature::range(1, 2)],
    );
    catalog.register(
        d,
        "toStartOfMillisecond",
        vec![FunctionSignature::range(1, 2)],
    );
    catalog.register(d, "toStartOfMinute", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfMonth", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toStartOfNanosecond",
        vec![FunctionSignature::range(1, 2)],
    );
    catalog.register(d, "toStartOfQuarter", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfSecond", vec![FunctionSignature::range(1, 2)]);
    catalog.register(d, "toStartOfTenMinutes", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStartOfYear", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toStringCutToZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTime", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTime64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTime64OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTime64OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTimeOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTimeOrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTimeWithFixedDate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTimezone", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toTypeName", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt128", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toUInt128OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toUInt128OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt128OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt16", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt16OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toUInt16OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt16OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt256", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "toUInt256OrDefault",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "toUInt256OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt256OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt32OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toUInt32OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt32OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt64OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toUInt64OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt64OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt8OrDefault", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "toUInt8OrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUInt8OrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUnixTimestamp", vec![FunctionSignature::range(1, 2)]);
    catalog.register(
        d,
        "toUnixTimestamp64Micro",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "toUnixTimestamp64Milli",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "toUnixTimestamp64Nano",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "toUnixTimestamp64Second",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "toUTCTimestamp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toUUID", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUUIDOrDefault", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toUUIDOrNull", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toUUIDOrZero", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toValidUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYear", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYearNumSinceEpoch", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYearWeek", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYYYYMM", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYYYYMMDD", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toYYYYMMDDhhmmss", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "transactionID", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "transactionLatestSnapshot",
        vec![FunctionSignature::exact(0)],
    );
    catalog.register(
        d,
        "transactionOldestSnapshot",
        vec![FunctionSignature::exact(0)],
    );
    catalog.register(d, "transform", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "translate", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "translateUTF8", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "trimBoth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "trimLeft", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "trimRight", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "trunc", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryBase32Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryBase58Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryBase64Decode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryBase64URLDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryDecrypt", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "tryIdnaEncode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tryPunycodeDecode", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tumble", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tumbleEnd", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tumbleStart", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tuple", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "tupleConcat", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "tupleDivide", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleDivideByNumber", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleElement", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleHammingDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleIntDiv", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleIntDivByNumber", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleIntDivOrZero", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "tupleIntDivOrZeroByNumber",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "tupleMinus", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleModulo", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleModuloByNumber", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "tupleMultiply", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "tupleMultiplyByNumber",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "tupleNames", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "tupleNegate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "tuplePlus", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "tupleToNameValuePairs",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "ULIDStringToDateTime", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "unbin", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "unhex", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "uniq", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqCombined", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqCombined64", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqExact", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqHLL12", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqTheta", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "uniqThetaIntersect", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "uniqThetaNot", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "uniqThetaUnion", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "uniqUpTo", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "upper", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "upperUTF8", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "uptime", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "URLHash", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "URLHierarchy", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "URLPathHierarchy", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "UTCTimestamp", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "UUIDNumToString", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "UUIDStringToNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "UUIDToNum", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "UUIDv7ToDateTime", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "validateNestedArraySizes",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "variantElement", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "variantType", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "varPop", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "varPopStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "varSamp", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "varSampStable", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "version", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "visibleWidth", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "welchTTest", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "widthBucket", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "windowFunnel", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "windowID", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "wkb", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "wkt", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "wordShingleMinHash", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "wordShingleMinHashArg",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashArgCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashArgCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashArgUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleMinHashUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "wordShingleSimHash", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "wordShingleSimHashCaseInsensitive",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleSimHashCaseInsensitiveUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "wordShingleSimHashUTF8",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "wyHash64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "xor", vec![FunctionSignature::variadic(2)]);
    catalog.register(d, "xxh3", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "xxHash32", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "xxHash64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "yesterday", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "YYYYMMDDhhmmssToDateTime",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(
        d,
        "YYYYMMDDhhmmssToDateTime64",
        vec![FunctionSignature::exact(1)],
    );
    catalog.register(d, "YYYYMMDDToDate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "YYYYMMDDToDate32", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "zookeeperSessionUptime",
        vec![FunctionSignature::exact(0)],
    );
    catalog.register(d, "anova", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "any_value", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "any_value_respect_nulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "anyLastRespectNulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "anyRespectNulls", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "anyValueRespectNulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "approx_top_count", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "array_agg", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "array_concat_agg", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "arrayAUC", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "arrayPRAUC", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "BIT_AND", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "BIT_OR", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "BIT_XOR", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "byteSlice", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "caseWithExpr", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "caseWithoutExpr", vec![FunctionSignature::variadic(5)]);
    catalog.register(
        d,
        "caseWithoutExpression",
        vec![FunctionSignature::variadic(5)],
    );
    catalog.register(d, "ceiling", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "CHAR_LENGTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "CHARACTER_LENGTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "concat_ws", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "connection_id", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "COVAR_POP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "COVAR_SAMP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "curdate", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "current_database", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "current_date", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "current_query_id", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "current_schemas", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "current_timestamp", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "current_user", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "DATABASE", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "date_bin", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "DATE_DIFF", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "date_diff", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "DATE_FORMAT", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "DATE_TRUNC", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "DAY", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "DAYOFMONTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "DAYOFWEEK", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "DAYOFYEAR", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "dense_rank", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "distanceL1", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "distanceL2", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "distanceL2Squared", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "distanceL2Transposed", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "distanceLinf", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "distanceLp", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "extractAllGroups", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "first_value", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "first_value_respect_nulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "firstValueRespectNulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "flatten", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "FORMAT_BYTES", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "FROM_BASE64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "FROM_DAYS", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "FROM_UNIXTIME", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "from_utc_timestamp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "fullHostName", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "group_concat", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "hasAllToken", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hasAnyToken", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "hostname", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "HOUR", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "INET6_ATON", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "INET6_NTOA", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "INET_ATON", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "INET_NTOA", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "initial_query_id", vec![FunctionSignature::exact(0)]);
    catalog.register(
        d,
        "initial_query_start_time",
        vec![FunctionSignature::exact(0)],
    );
    catalog.register(d, "instr", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "isASCII", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "JSON_ARRAY_LENGTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "jsonMergePatch", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "LAST_DAY", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "last_value", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "last_value_respect_nulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "lastValueRespectNulls",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "lcase", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "levenshteinDistance", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "levenshteinDistanceUTF8",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "ln", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lpad", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "ltrim", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "lttb", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "MAP_FROM_ARRAYS", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapContains", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mapFromString", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "median", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "medianBFloat16", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianBFloat16Weighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "medianDD", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianDeterministic",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "medianExact", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "medianExactHigh", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "medianExactLow", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianExactWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "medianExactWeightedInterpolated",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "medianGK", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianInterpolatedWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "medianTDigest", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianTDigestWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "medianTiming", vec![FunctionSignature::variadic(0)]);
    catalog.register(
        d,
        "medianTimingWeighted",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "mid", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "MILLISECOND", vec![FunctionSignature::exact(1)]);
    catalog.register(
        d,
        "minSampleSizeContinous",
        vec![FunctionSignature::exact(5)],
    );
    catalog.register(d, "MINUTE", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "mismatches", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "mod", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "modOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "MONTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeL1", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeL2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeLinf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normalizeLp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "normL1", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normL2", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normL2Squared", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normLinf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "normLp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "OCTET_LENGTH", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "partitionID", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "percent_rank", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "pmod", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "pmodOrNull", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "positive_modulo", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "positive_modulo_or_null",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "power", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "QUARTER", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "query_id", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "rand32", vec![FunctionSignature::range(0, 1)]);
    catalog.register(d, "REGEXP_EXTRACT", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "REGEXP_MATCHES", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "REGEXP_REPLACE", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "replace", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "rpad", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "rtrim", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "scalarProduct", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "SCHEMA", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "SECOND", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "serverTimeZone", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "sparkBar", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "splitByAlpha", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "sqid", vec![FunctionSignature::variadic(1)]);
    catalog.register(d, "ST_LineFromWKB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ST_MLineFromWKB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ST_MPolyFromWKB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ST_PointFromWKB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ST_PolyFromWKB", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "STD", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "STDDEV_POP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "STDDEV_SAMP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "str_to_date", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "str_to_map", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "substr", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "SUBSTRING_INDEX", vec![FunctionSignature::exact(3)]);
    catalog.register(d, "SVG", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "time_bucket", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "timeSeriesIdeltaToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesIrateToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(
        d,
        "timeSeriesLastToGrid",
        vec![FunctionSignature::variadic(0)],
    );
    catalog.register(d, "TIMESTAMP_DIFF", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "timestamp_diff", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "timestampDiff", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "timeZone", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "timeZoneOf", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "timeZoneOffset", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "TO_BASE64", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "TO_DAYS", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "TO_UNIXTIME", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "to_utc_timestamp", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "toStartOfFiveMinute", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "toTimeZone", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "trim", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "truncate", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "ucase", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "user", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "UTC_timestamp", vec![FunctionSignature::exact(0)]);
    catalog.register(d, "VAR_POP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "VAR_SAMP", vec![FunctionSignature::variadic(0)]);
    catalog.register(d, "vectorDifference", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "vectorSum", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "visitParamExtractBool",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "visitParamExtractFloat",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "visitParamExtractInt", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "visitParamExtractRaw", vec![FunctionSignature::exact(2)]);
    catalog.register(
        d,
        "visitParamExtractString",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(
        d,
        "visitParamExtractUInt",
        vec![FunctionSignature::exact(2)],
    );
    catalog.register(d, "visitParamHas", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "week", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "width_bucket", vec![FunctionSignature::exact(4)]);
    catalog.register(d, "yandexConsistentHash", vec![FunctionSignature::exact(2)]);
    catalog.register(d, "YEAR", vec![FunctionSignature::exact(1)]);
    catalog.register(d, "yearweek", vec![FunctionSignature::exact(1)]);
}
