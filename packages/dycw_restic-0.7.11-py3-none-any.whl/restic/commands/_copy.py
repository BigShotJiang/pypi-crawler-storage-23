from __future__ import annotations

from typing import TYPE_CHECKING

from click import command
from utilities.click import CONTEXT_SETTINGS, Path, SecretStr, argument, option
from utilities.core import (
    duration_to_seconds,
    is_pytest,
    set_up_logging,
    sync_sleep,
    to_logger,
)
from utilities.subprocess import run
from whenever import TimeDelta

from restic import __version__
from restic._click import ClickRepo, print_option, sleep_option, tag_option
from restic._constants import (
    RESTIC_DEST_PASSWORD,
    RESTIC_DEST_PASSWORD_FILE,
    RESTIC_PASSWORD,
    RESTIC_PASSWORD_FILE,
    RESTIC_SRC_PASSWORD,
    RESTIC_SRC_PASSWORD_FILE,
)
from restic._utilities import expand_tag, yield_password

if TYPE_CHECKING:
    from collections.abc import Callable

    from click import Command
    from utilities.types import Duration, MaybeSequenceStr, PathLike, SecretLike

    from restic._repo import Repo


_LOGGER = to_logger(__name__)


##


def copy(
    src: Repo,
    dest: Repo,
    /,
    *,
    src_password: SecretLike | None = RESTIC_SRC_PASSWORD,
    src_password_file: PathLike | None = RESTIC_SRC_PASSWORD_FILE,
    dest_password: SecretLike | None = RESTIC_DEST_PASSWORD,
    dest_password_file: PathLike | None = RESTIC_DEST_PASSWORD_FILE,
    tag: MaybeSequenceStr | None = None,
    sleep: Duration | None = None,
    print: bool = True,  # noqa: A002
) -> None:
    """Copy one or more snapshots from one repository to another."""
    _LOGGER.info("Copying snapshots from %s to %s...", src, dest)
    with (
        src.yield_env("RESTIC_FROM_REPOSITORY"),
        dest.yield_env(),
        yield_password(
            password=src_password,
            password_file=src_password_file,
            env_var="RESTIC_FROM_PASSWORD_FILE",
        ),
        yield_password(password=dest_password, password_file=dest_password_file),
    ):
        run("restic", "copy", *expand_tag(tag=tag), print=print)
    if sleep is None:
        _LOGGER.info("Finished copying snapshots from %r to %r", src, dest)
    else:
        delta = TimeDelta(seconds=duration_to_seconds(sleep))
        _LOGGER.info(
            "Finished copying snapshots from %s to %s; sleeping for %s...",
            src,
            dest,
            delta,
        )
        sync_sleep(sleep)
        _LOGGER.info("Finishing sleeping for %s", delta)


##


def make_copy_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @argument("src", type=ClickRepo())
    @argument("dest", type=ClickRepo())
    @option(
        "--src-password",
        type=SecretStr(),
        default=RESTIC_PASSWORD,
        help="Restic source password",
    )
    @option(
        "--src-password-file",
        type=Path(exist="file if exists"),
        default=RESTIC_PASSWORD_FILE,
        help="Restic source password file",
    )
    @option(
        "--dest-password",
        type=SecretStr(),
        default=RESTIC_PASSWORD,
        help="Restic destination password",
    )
    @option(
        "--dest-password-file",
        type=Path(exist="file if exists"),
        default=RESTIC_PASSWORD_FILE,
        help="Restic destination password file",
    )
    @tag_option
    @sleep_option
    @print_option
    def func(
        *,
        src: Repo,
        dest: Repo,
        src_password: SecretLike | None,
        src_password_file: PathLike | None,
        dest_password: SecretLike | None,
        dest_password_file: PathLike | None,
        tag: MaybeSequenceStr | None,
        sleep: Duration | None,
        print: bool,  # noqa: A002
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        copy(
            src,
            dest,
            src_password=src_password,
            src_password_file=src_password_file,
            dest_password=dest_password,
            dest_password_file=dest_password_file,
            tag=tag,
            sleep=sleep,
            print=print,
        )

    return cli(name=name, help="Copy snapshots", **CONTEXT_SETTINGS)(func)


__all__ = ["copy", "make_copy_cmd"]
