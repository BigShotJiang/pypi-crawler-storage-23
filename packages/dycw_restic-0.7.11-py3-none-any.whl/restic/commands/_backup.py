from __future__ import annotations

from re import MULTILINE, search
from typing import TYPE_CHECKING

from click import command
from utilities.click import CONTEXT_SETTINGS, Path, argument, flag, option
from utilities.core import (
    duration_to_seconds,
    is_pytest,
    set_up_logging,
    sync_sleep,
    to_logger,
)
from utilities.subprocess import RunCalledProcessError, run
from whenever import TimeDelta

from restic import __version__
from restic._click import (
    dry_run_option,
    exclude_i_option,
    exclude_option,
    group_by_option,
    keep_daily_option,
    keep_hourly_option,
    keep_last_option,
    keep_monthly_option,
    keep_weekly_option,
    keep_within_daily_option,
    keep_within_hourly_option,
    keep_within_monthly_option,
    keep_within_option,
    keep_within_weekly_option,
    keep_within_yearly_option,
    keep_yearly_option,
    password_file_option,
    password_option,
    prune_option,
    repack_cacheable_only_option,
    repack_small_option,
    repack_uncompressed_option,
    repo_argument,
    sleep_option,
    tag_option,
)
from restic._constants import READ_CONCURRENCY, RESTIC_PASSWORD, RESTIC_PASSWORD_FILE
from restic._utilities import (
    expand_dry_run,
    expand_exclude,
    expand_exclude_i,
    expand_read_concurrency,
    expand_tag,
    yield_password,
)
from restic.commands._forget import forget
from restic.commands._init import init

if TYPE_CHECKING:
    from collections.abc import Callable

    from click import Command
    from utilities.types import Duration, MaybeSequenceStr, PathLike, SecretLike

    from restic._repo import Repo


_LOGGER = to_logger(__name__)


##


def backup(
    path: PathLike,
    repo: Repo,
    /,
    *,
    password: SecretLike | None = RESTIC_PASSWORD,
    password_file: PathLike | None = RESTIC_PASSWORD_FILE,
    dry_run: bool = False,
    exclude: MaybeSequenceStr | None = None,
    exclude_i: MaybeSequenceStr | None = None,
    read_concurrency: int = READ_CONCURRENCY,
    tag: MaybeSequenceStr | None = None,
    print_backup: bool = True,
    print_init: bool = True,
    run_forget: bool = True,
    keep_last: int | None = None,
    keep_hourly: int | None = None,
    keep_daily: int | None = None,
    keep_weekly: int | None = None,
    keep_monthly: int | None = None,
    keep_yearly: int | None = None,
    keep_within: str | None = None,
    keep_within_hourly: str | None = None,
    keep_within_daily: str | None = None,
    keep_within_weekly: str | None = None,
    keep_within_monthly: str | None = None,
    keep_within_yearly: str | None = None,
    group_by: MaybeSequenceStr | None = None,
    prune: bool = True,
    repack_cacheable_only: bool = False,
    repack_small: bool = True,
    repack_uncompressed: bool = True,
    print_forget: bool = True,
    sleep: Duration | None = None,
) -> None:
    """Create a new snapshot."""
    _LOGGER.info("Backing up %r to %s...", str(path), repo)
    try:
        _backup_core(
            path,
            repo,
            password=password,
            password_file=password_file,
            dry_run=dry_run,
            exclude=exclude,
            exclude_i=exclude_i,
            read_concurrency=read_concurrency,
            tag=tag,
            print=print_backup,
        )
    except RunCalledProcessError as error:
        if search(
            "Is there a repository at the following location?",
            error.stderr,
            flags=MULTILINE,
        ):
            _LOGGER.info("Auto-initializing repo...")
            init(repo, password=password, password_file=password_file, print=print_init)
            _backup_core(
                path,
                repo,
                password=password,
                password_file=password_file,
                dry_run=dry_run,
                exclude=exclude,
                exclude_i=exclude_i,
                read_concurrency=read_concurrency,
                tag=tag,
                print=print_backup,
            )
        else:
            raise
    if run_forget and (
        (keep_last is not None)
        or (keep_hourly is not None)
        or (keep_daily is not None)
        or (keep_weekly is not None)
        or (keep_monthly is not None)
        or (keep_yearly is not None)
        or (keep_within is not None)
        or (keep_within_hourly is not None)
        or (keep_within_daily is not None)
        or (keep_within_weekly is not None)
        or (keep_within_monthly is not None)
        or (keep_within_yearly is not None)
    ):
        forget(
            repo,
            password=password,
            password_file=password_file,
            keep_last=keep_last,
            keep_hourly=keep_hourly,
            keep_daily=keep_daily,
            keep_weekly=keep_weekly,
            keep_monthly=keep_monthly,
            keep_yearly=keep_yearly,
            keep_within=keep_within,
            keep_within_hourly=keep_within_hourly,
            keep_within_daily=keep_within_daily,
            keep_within_weekly=keep_within_weekly,
            keep_within_monthly=keep_within_monthly,
            keep_within_yearly=keep_within_yearly,
            group_by=group_by,
            prune=prune,
            repack_cacheable_only=repack_cacheable_only,
            repack_small=repack_small,
            repack_uncompressed=repack_uncompressed,
            tag=tag,
            print=print_forget,
        )
    if sleep is None:
        _LOGGER.info("Finished backing up %r to %s", str(path), repo)
    else:
        delta = TimeDelta(seconds=duration_to_seconds(sleep))
        _LOGGER.info(
            "Finished backing up %r to %s; sleeping for %s...", str(path), repo, delta
        )
        sync_sleep(delta)
        _LOGGER.info("Finishing sleeping for %s", delta)


def _backup_core(
    path: PathLike,
    repo: Repo,
    /,
    *,
    password: SecretLike | None = RESTIC_PASSWORD,
    password_file: PathLike | None = RESTIC_PASSWORD_FILE,
    dry_run: bool = False,
    exclude: MaybeSequenceStr | None = None,
    exclude_i: MaybeSequenceStr | None = None,
    read_concurrency: int = READ_CONCURRENCY,
    tag: MaybeSequenceStr | None = None,
    print: bool = True,  # noqa: A002
) -> None:
    with (
        repo.yield_env(),
        yield_password(password=password, password_file=password_file),
    ):
        run(
            "restic",
            "backup",
            *expand_dry_run(dry_run=dry_run),
            *expand_exclude(exclude=exclude),
            *expand_exclude_i(exclude_i=exclude_i),
            *expand_read_concurrency(read_concurrency),
            *expand_tag(tag=tag),
            str(path),
            print=print,
        )


##


def make_backup_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @argument("path", type=Path())
    @repo_argument
    @password_option
    @password_file_option
    @dry_run_option
    @exclude_option
    @exclude_i_option
    @option(
        "--read-concurrency",
        type=int,
        default=READ_CONCURRENCY,
        help="Read `n` files concurrently",
    )
    @tag_option
    @flag("--print-init", default=True, help="Print the output to the console")
    @flag("--print-backup", default=True, help="Print the output to the console")
    @option(
        "--run-forget",
        is_flag=True,
        default=True,
        help="Automatically run the 'forget' command",
    )
    @keep_last_option
    @keep_hourly_option
    @keep_daily_option
    @keep_weekly_option
    @keep_monthly_option
    @keep_yearly_option
    @keep_within_option
    @keep_within_hourly_option
    @keep_within_daily_option
    @keep_within_weekly_option
    @keep_within_monthly_option
    @keep_within_yearly_option
    @group_by_option
    @prune_option
    @repack_cacheable_only_option
    @repack_small_option
    @repack_uncompressed_option
    @flag("--print-forget", default=True, help="Print the output to the console")
    @sleep_option
    def func(
        *,
        path: PathLike,
        repo: Repo,
        password: SecretLike | None,
        password_file: PathLike | None,
        dry_run: bool,
        exclude: MaybeSequenceStr | None,
        exclude_i: MaybeSequenceStr | None,
        read_concurrency: int,
        tag: MaybeSequenceStr | None,
        print_backup: bool,
        print_init: bool,
        run_forget: bool,
        keep_last: int | None,
        keep_hourly: int | None,
        keep_daily: int | None,
        keep_weekly: int | None,
        keep_monthly: int | None,
        keep_yearly: int | None,
        keep_within: str | None,
        keep_within_hourly: str | None,
        keep_within_daily: str | None,
        keep_within_weekly: str | None,
        keep_within_monthly: str | None,
        keep_within_yearly: str | None,
        group_by: MaybeSequenceStr | None,
        prune: bool,
        repack_cacheable_only: bool,
        repack_small: bool,
        repack_uncompressed: bool,
        print_forget: bool,
        sleep: Duration | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        backup(
            path,
            repo,
            password=password,
            password_file=password_file,
            dry_run=dry_run,
            exclude=exclude,
            exclude_i=exclude_i,
            read_concurrency=read_concurrency,
            tag=tag,
            print_backup=print_backup,
            print_init=print_init,
            run_forget=run_forget,
            keep_last=keep_last,
            keep_hourly=keep_hourly,
            keep_daily=keep_daily,
            keep_weekly=keep_weekly,
            keep_monthly=keep_monthly,
            keep_yearly=keep_yearly,
            keep_within=keep_within,
            keep_within_hourly=keep_within_hourly,
            keep_within_daily=keep_within_daily,
            keep_within_weekly=keep_within_weekly,
            keep_within_monthly=keep_within_monthly,
            keep_within_yearly=keep_within_yearly,
            group_by=group_by,
            prune=prune,
            repack_cacheable_only=repack_cacheable_only,
            repack_small=repack_small,
            repack_uncompressed=repack_uncompressed,
            print_forget=print_forget,
            sleep=sleep,
        )

    return cli(name=name, help="Create a new snapshot", **CONTEXT_SETTINGS)(func)


__all__ = ["backup", "make_backup_cmd"]
