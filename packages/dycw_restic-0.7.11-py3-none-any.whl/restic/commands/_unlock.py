from __future__ import annotations

from typing import TYPE_CHECKING

from click import Command, command
from utilities.click import CONTEXT_SETTINGS
from utilities.core import is_pytest, set_up_logging, to_logger
from utilities.subprocess import run
from utilities.types import PathLike, SecretLike

from restic import __version__
from restic._click import (
    password_file_option,
    password_option,
    remove_all_option,
    repo_argument,
)
from restic._constants import RESTIC_PASSWORD, RESTIC_PASSWORD_FILE
from restic._repo import Repo
from restic._utilities import expand_bool, yield_password

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.types import PathLike, SecretLike

    from restic._repo import Repo


_LOGGER = to_logger(__name__)


##


def unlock(
    repo: Repo,
    /,
    *,
    password: SecretLike | None = RESTIC_PASSWORD,
    password_file: PathLike | None = RESTIC_PASSWORD_FILE,
    remove_all: bool = False,
    print: bool = True,  # noqa: A002
) -> None:
    """Remove stale locks that have been created by other 'restic' processes."""
    _LOGGER.info("Unlocking %s...", repo)
    with (
        repo.yield_env(),
        yield_password(password=password, password_file=password_file),
    ):
        run(
            "restic",
            "unlock",
            *expand_bool("remove-all", bool_=remove_all),
            print=print,
        )
    _LOGGER.info("Finished unlocking %s", repo)


##


def make_unlock_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @repo_argument
    @password_option
    @password_file_option
    @remove_all_option
    def func(
        *,
        repo: Repo,
        password: SecretLike | None,
        password_file: PathLike | None,
        remove_all: bool,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        unlock(
            repo, password=password, password_file=password_file, remove_all=remove_all
        )

    return cli(
        name=name,
        help="Remove stale locks that have been created by other restic processes",
        **CONTEXT_SETTINGS,
    )(func)


__all__ = ["make_unlock_cmd", "unlock"]
