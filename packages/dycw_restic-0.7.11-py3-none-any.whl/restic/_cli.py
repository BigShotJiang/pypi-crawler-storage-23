from __future__ import annotations

from click import group, version_option
from utilities.click import CONTEXT_SETTINGS

from restic import __version__
from restic.commands._backup import make_backup_cmd
from restic.commands._copy import make_copy_cmd
from restic.commands._forget import make_forget_cmd
from restic.commands._init import make_init_cmd
from restic.commands._restore import make_restore_cmd
from restic.commands._snapshots import make_snapshots_cmd
from restic.commands._unlock import make_unlock_cmd

backup_cli = make_backup_cmd()
copy_cli = make_copy_cmd()
forget_cli = make_forget_cmd()
init_cli = make_init_cmd()
restore_cli = make_restore_cmd()
snapshots_cli = make_snapshots_cmd()
unlock_cli = make_unlock_cmd()


@group(**CONTEXT_SETTINGS)
@version_option(version=__version__)
def group_cli() -> None: ...


_ = make_backup_cmd(cli=group_cli.command, name="backup")
_ = make_copy_cmd(cli=group_cli.command, name="copy")
_ = make_forget_cmd(cli=group_cli.command, name="forget")
_ = make_init_cmd(cli=group_cli.command, name="init")
_ = make_restore_cmd(cli=group_cli.command, name="restore")
_ = make_snapshots_cmd(cli=group_cli.command, name="snapshots")
_ = make_unlock_cmd(cli=group_cli.command, name="unlock")


__all__ = [
    "backup_cli",
    "copy_cli",
    "forget_cli",
    "group_cli",
    "init_cli",
    "restore_cli",
    "snapshots_cli",
    "unlock_cli",
]
