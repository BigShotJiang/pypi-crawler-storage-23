# LangChain Data Validator Tool

A LangChain tool that validates data, checks facts, and detects logical errors using an external AI agent. Perfect for hallucination prevention in LLM applications.

## Features

- ✅ Fact-checking across multiple domains
- ✅ Logical error detection
- ✅ Misinformation identification
- ✅ $0.10 per request (premium reasoning layer)
- ✅ Async and sync support
- ✅ Easy integration with LangChain agents

## Installation

```bash
pip install langchain-data-validator

## Quick Start
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_openai import ChatOpenAI
from langchain import hub
from langchain_data_validator import DataValidatorTool

# Create tool
validator_tool = DataValidatorTool()

# Setup agent
tools = [validator_tool]
llm = ChatOpenAI(model="gpt-3.5-turbo")
prompt = hub.pull("hwchase17/openai-tools-agent")
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# Use it
result = agent_executor.invoke({
    "input": "Check if 'Bitcoin price is $100,000' is correct"
})
print(result)

## Direct Usage
from langchain_data_validator import DataValidatorTool

tool = DataValidatorTool()
result = tool.run("Water boils at 50°C")
print(result)  # "Result: WRONG: Water boils at 100°C at sea level. (Cost: $0.10)"