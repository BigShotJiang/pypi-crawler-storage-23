"""Unit tests for the data validator tool."""

import unittest
from unittest.mock import patch, MagicMock
from langchain_data_validator.tool import DataValidatorTool


class TestDataValidatorTool(unittest.TestCase):
    
    def setUp(self):
        self.tool = DataValidatorTool()
    
    @patch('requests.post')
    def test_sync_success(self, mock_post):
        # Mock successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "result": "CORRECT",
            "price": 0.10
        }
        mock_post.return_value = mock_response
        
        result = self.tool._run("2+2=4")
        self.assertIn("CORRECT", result)
        self.assertIn("$0.10", result)
    
    @patch('requests.post')
    def test_sync_http_error(self, mock_post):
        # Mock HTTP error
        mock_response = MagicMock()
        mock_response.status_code = 402
        mock_response.text = "Insufficient balance"
        mock_post.return_value = mock_response
        mock_post.side_effect = lambda *args, **kwargs: mock_response
        
        result = self.tool._run("test")
        self.assertIn("Payment required", result)
    
    # More tests can be added


if __name__ == '__main__':
    unittest.main()