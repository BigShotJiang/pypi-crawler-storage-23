"""Undetecta API Client.

A Python client for the Undetecta API - Anti-detection web scraping made simple.

Example:
    ```python
    import asyncio
    from undetecta import UndetectaClient

    async def main():
        async with UndetectaClient(api_key="your-api-key") as client:
            result = await client.scrape(url="https://example.com")
            print(result.markdown)

    asyncio.run(main())
    ```
"""

from __future__ import annotations

from .client import UndetectaClient
from .errors import (
    ApiKeyError,
    AuthenticationError,
    BadRequestError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    UndetectaError,
    ValidationError,
    parse_error_response,
)
from .types import (
    Action,
    ActionType,
    BrandingButtonStyle,
    BrandingColors,
    BrandingComponents,
    BrandingConfidence,
    BrandingImages,
    BrandingPersonality,
    BrandingProfile,
    BrandingSpacing,
    BrandingTypography,
    ImageSearchResult,
    JobStatus,
    NewsSearchResult,
    ScrapedMetadata,
    ScrapeFormat,
    ScrapeJobError,
    ScrapeJobResponse,
    ScrapeMetadata,
    ScrapeOptions,
    ScreenshotClip,
    ScreenshotOptions,
    ScreenshotViewport,
    SearchCategory,
    SearchJobError,
    SearchJobResponse,
    SearchOptions,
    SearchScrapeOptions,
    WaitUntil,
    WebSearchResult,
)

__all__ = [
    # Client
    "UndetectaClient",
    # Types
    "Action",
    "ActionType",
    "BrandingButtonStyle",
    "BrandingColors",
    "BrandingComponents",
    "BrandingConfidence",
    "BrandingImages",
    "BrandingPersonality",
    "BrandingProfile",
    "BrandingSpacing",
    "BrandingTypography",
    "ImageSearchResult",
    "JobStatus",
    "NewsSearchResult",
    "ScrapeFormat",
    "ScrapeJobError",
    "ScrapeJobResponse",
    "ScrapeMetadata",
    "ScrapeOptions",
    "ScreenshotClip",
    "ScreenshotOptions",
    "ScreenshotViewport",
    "ScrapedMetadata",
    "SearchCategory",
    "SearchJobError",
    "SearchJobResponse",
    "SearchOptions",
    "SearchScrapeOptions",
    "WaitUntil",
    "WebSearchResult",
    # Errors
    "ApiKeyError",
    "AuthenticationError",
    "BadRequestError",
    "NetworkError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
    "UndetectaError",
    "ValidationError",
    "parse_error_response",
]

__version__ = "0.1.0"
