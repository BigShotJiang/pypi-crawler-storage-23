"""Tests for the Undetecta Python SDK."""
