"""Pytest configuration for the Undetecta Python SDK tests."""


def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line("markers", "asyncio: mark test as async")
