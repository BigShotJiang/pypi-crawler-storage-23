# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-03-02

### Added
- Initial release of undetecta Python client
- Full async/await support with httpx
- Web scraping with advanced options (screenshots, branding, actions)
- Web search with result scraping capabilities
- Custom error classes with proper hierarchy
- Automatic retry logic with exponential backoff
- Type hints with Pydantic v2 models
- Context manager support for automatic resource cleanup
- 134 passing tests

### Features
- **Scraping**: Extract HTML, markdown, links, screenshots, branding profiles
- **Search**: Google web search with category filters (github, research, pdf)
- **Actions**: Browser automation (click, fill, select, wait, scroll)
- **Health Check**: API status monitoring
- **Error Handling**: ApiKeyError, RateLimitError, TimeoutError, NetworkError, ValidationError, NotFoundError

### Documentation
- Comprehensive README with examples
- Full API reference
- Error handling guide
- Advanced usage examples
