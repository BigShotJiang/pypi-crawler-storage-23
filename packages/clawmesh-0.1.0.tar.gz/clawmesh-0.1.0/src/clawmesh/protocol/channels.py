"""NATS subject naming conventions for ClawMesh channels."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import StrEnum


class ChannelKind(StrEnum):
    GLOBAL = "global"
    DEPARTMENT = "dept"
    TEAM = "team"
    DM = "dm"
    SYSTEM = "sys"


SUBJECT_PATTERN = re.compile(r"^org\.(global|dept|team|dm|sys)(\.[a-zA-Z0-9_.-]+)?$")


@dataclass(frozen=True)
class Channel:
    """Represents a ClawMesh communication channel mapped to a NATS subject."""

    kind: ChannelKind
    name: str = ""

    @property
    def subject(self) -> str:
        if self.kind == ChannelKind.GLOBAL:
            return "org.global"
        return f"org.{self.kind.value}.{self.name}"

    @classmethod
    def parse(cls, subject: str) -> Channel:
        if not validate_channel(subject):
            raise ValueError(f"Invalid channel subject: {subject}")
        parts = subject.split(".", 2)
        kind = ChannelKind(parts[1])
        name = parts[2] if len(parts) > 2 else ""
        return cls(kind=kind, name=name)

    @classmethod
    def global_channel(cls) -> Channel:
        return cls(kind=ChannelKind.GLOBAL)

    @classmethod
    def department(cls, dept_id: str) -> Channel:
        return cls(kind=ChannelKind.DEPARTMENT, name=dept_id)

    @classmethod
    def team(cls, project_id: str) -> Channel:
        return cls(kind=ChannelKind.TEAM, name=project_id)

    @classmethod
    def dm(cls, bot_a: str, bot_b: str) -> Channel:
        """Create a DM channel. Bot IDs are sorted for consistency."""
        sorted_ids = ".".join(sorted([bot_a, bot_b]))
        return cls(kind=ChannelKind.DM, name=sorted_ids)

    @classmethod
    def system(cls, event_type: str) -> Channel:
        return cls(kind=ChannelKind.SYSTEM, name=event_type)


def validate_channel(subject: str) -> bool:
    return bool(SUBJECT_PATTERN.match(subject))
