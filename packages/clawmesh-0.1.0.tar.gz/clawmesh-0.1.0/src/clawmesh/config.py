"""ClawMesh client configuration management.

Config is stored at ~/.clawmesh/config.yaml and managed through
`clawmesh login` and direct editing.
"""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel

CLAWMESH_DIR = Path.home() / ".clawmesh"
CONFIG_PATH = CLAWMESH_DIR / "config.yaml"


class ClawMeshConfig(BaseModel):
    server: str = "nats://localhost:4222"
    bot_id: str = ""
    department: str = ""
    token: str = ""

    @classmethod
    def load(cls, path: Path | None = None) -> ClawMeshConfig:
        cfg_path = path or CONFIG_PATH
        if not cfg_path.exists():
            return cls()
        with open(cfg_path) as f:
            data = yaml.safe_load(f) or {}
        return cls(**data)

    def save(self, path: Path | None = None) -> None:
        cfg_path = path or CONFIG_PATH
        cfg_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cfg_path, "w") as f:
            yaml.dump(self.model_dump(), f, default_flow_style=False, allow_unicode=True)

    @property
    def is_configured(self) -> bool:
        return bool(self.bot_id and self.server)


def ensure_clawmesh_dir() -> Path:
    CLAWMESH_DIR.mkdir(parents=True, exist_ok=True)
    return CLAWMESH_DIR
