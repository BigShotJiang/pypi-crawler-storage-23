"""Token generation and management for ClawMesh authentication.

Tokens are used for NATS client authentication. Each bot gets a unique token
that is configured in the NATS server authorization block.
"""

from __future__ import annotations

import hashlib
import secrets


def generate_token(length: int = 32) -> str:
    """Generate a cryptographically secure random token."""
    return secrets.token_urlsafe(length)


def hash_token(token: str) -> str:
    """Create a SHA-256 hash of a token for safe storage/comparison."""
    return hashlib.sha256(token.encode()).hexdigest()
