"""ClawMesh Daemon - Long-running sidecar process.

Maintains a persistent NATS connection, handles CLI requests via Unix socket,
caches messages locally, and broadcasts heartbeat events.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys

from clawmesh.bus.client import BusClient
from clawmesh.config import ClawMeshConfig
from clawmesh.daemon.cache import MessageCache
from clawmesh.daemon.handler import RequestHandler
from clawmesh.daemon.process import get_sock_path, write_pid
from clawmesh.daemon.protocol import DaemonRequest, DaemonResponse
from clawmesh.protocol.channels import Channel
from clawmesh.protocol.message import Message, MessageType

logger = logging.getLogger("clawmesh.daemon")

HEARTBEAT_INTERVAL = 30  # seconds


class DaemonServer:
    """Unix socket server that bridges CLI commands to the NATS bus."""

    def __init__(self, config: ClawMeshConfig | None = None):
        self._config = config or ClawMeshConfig.load()
        self._bus = BusClient(self._config)
        self._cache = MessageCache()
        self._handler = RequestHandler(self._bus, self._config, self._cache)
        self._sock_path = get_sock_path()
        self._server: asyncio.AbstractServer | None = None
        self._running = False

    async def start(self) -> None:
        write_pid(os.getpid())

        self._sock_path.unlink(missing_ok=True)

        await self._bus.connect()
        logger.info("Connected to NATS at %s as %s", self._config.server, self._config.bot_id)

        self._server = await asyncio.start_unix_server(
            self._handle_connection, path=str(self._sock_path)
        )
        os.chmod(str(self._sock_path), 0o600)
        self._running = True

        logger.info("Daemon listening on %s", self._sock_path)

        await self._broadcast_online()

        heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        subscriber_task = asyncio.create_task(self._subscribe_all())

        stop_event = asyncio.Event()
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop_event.set)

        await stop_event.wait()

        logger.info("Shutting down daemon...")
        self._running = False
        heartbeat_task.cancel()
        subscriber_task.cancel()
        await self._broadcast_offline()
        self._server.close()
        await self._server.wait_closed()
        await self._bus.close()
        self._sock_path.unlink(missing_ok=True)
        logger.info("Daemon stopped.")

    async def _handle_connection(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            while True:
                data = await reader.readline()
                if not data:
                    break
                try:
                    request = DaemonRequest.from_bytes(data)
                    response = await self._handler.handle(request)
                except Exception as e:
                    response = DaemonResponse.fail(str(e))
                writer.write(response.to_bytes())
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            writer.close()

    async def _subscribe_all(self) -> None:
        """Subscribe to org.> and populate cache from live messages."""
        if not self._bus._js:
            return
        try:
            sub = await self._bus._js.subscribe("org.>", ordered_consumer=True)
            while self._running:
                try:
                    msg = await sub.next_msg(timeout=5.0)
                    parsed = Message.from_nats_payload(msg.data)
                    self._cache.push(parsed.to, parsed)
                except TimeoutError:
                    continue
                except Exception as e:
                    logger.debug("Subscribe error: %s", e)
                    await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass

    async def _heartbeat_loop(self) -> None:
        channel = Channel.system("heartbeat")
        try:
            while self._running:
                await asyncio.sleep(HEARTBEAT_INTERVAL)
                msg = Message(
                    from_id=self._config.bot_id,
                    to=channel.subject,
                    type=MessageType.EVENT,
                    content="heartbeat",
                    metadata={"department": self._config.department},
                )
                try:
                    await self._bus.publish(msg)
                except Exception as e:
                    logger.warning("Heartbeat failed: %s", e)
        except asyncio.CancelledError:
            pass

    async def _broadcast_online(self) -> None:
        channel = Channel.system("presence")
        msg = Message(
            from_id=self._config.bot_id,
            to=channel.subject,
            type=MessageType.EVENT,
            content="online",
            metadata={"department": self._config.department},
        )
        try:
            await self._bus.publish(msg)
        except Exception:
            pass

    async def _broadcast_offline(self) -> None:
        channel = Channel.system("presence")
        msg = Message(
            from_id=self._config.bot_id,
            to=channel.subject,
            type=MessageType.EVENT,
            content="offline",
        )
        try:
            await self._bus.publish(msg)
        except Exception:
            pass


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    config = ClawMeshConfig.load()
    if not config.is_configured:
        logger.error("Not configured. Run `clawmesh login` first.")
        sys.exit(1)

    server = DaemonServer(config)
    asyncio.run(server.start())


if __name__ == "__main__":
    main()
