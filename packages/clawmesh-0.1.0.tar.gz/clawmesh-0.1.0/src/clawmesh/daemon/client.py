"""Daemon client - CLI side of the IPC bridge.

Connects to the daemon's Unix socket and sends JSON-RPC requests.
Falls back gracefully when daemon is not running.
"""

from __future__ import annotations

import asyncio
from typing import Any

from clawmesh.daemon.process import get_sock_path, is_socket_available
from clawmesh.daemon.protocol import DaemonMethod, DaemonRequest, DaemonResponse


class DaemonClient:
    """Thin client that communicates with the daemon via Unix socket."""

    def __init__(self):
        self._sock_path = get_sock_path()
        self._req_id = 0

    @staticmethod
    def is_available() -> bool:
        return is_socket_available()

    async def _send(self, method: DaemonMethod, params: dict[str, Any]) -> DaemonResponse:
        self._req_id += 1
        request = DaemonRequest(method=method, params=params, id=self._req_id)

        reader, writer = await asyncio.open_unix_connection(str(self._sock_path))
        try:
            writer.write(request.to_bytes())
            await writer.drain()
            data = await asyncio.wait_for(reader.readline(), timeout=30.0)
            return DaemonResponse.from_bytes(data)
        finally:
            writer.close()
            await writer.wait_closed()

    async def ping(self) -> bool:
        try:
            resp = await self._send(DaemonMethod.PING, {})
            return resp.ok
        except Exception:
            return False

    async def shout(self, channel: str, content: str, msg_type: str = "chat") -> DaemonResponse:
        return await self._send(
            DaemonMethod.SHOUT, {"channel": channel, "content": content, "type": msg_type}
        )

    async def fetch(self, channel: str, limit: int = 10) -> DaemonResponse:
        return await self._send(DaemonMethod.FETCH, {"channel": channel, "limit": limit})

    async def dm(self, target: str, content: str) -> DaemonResponse:
        return await self._send(DaemonMethod.DM, {"target": target, "content": content})

    async def status(self) -> DaemonResponse:
        return await self._send(DaemonMethod.STATUS, {})
