"""ClawMesh - Minimal distributed communication bus for AI Agents."""

__version__ = "0.1.0"
