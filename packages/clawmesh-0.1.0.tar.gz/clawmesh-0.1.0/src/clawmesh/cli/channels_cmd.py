"""clawmesh channels - List well-known channels and conventions."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table

console = Console()


def channels() -> None:
    """List available channel conventions."""
    table = Table(title="ClawMesh Channel Conventions")
    table.add_column("Type", style="bold")
    table.add_column("Pattern", style="cyan")
    table.add_column("Example")
    table.add_column("Description")

    table.add_row("Global", "org.global", "org.global", "Broadcast to all bots")
    table.add_row("Department", "org.dept.<id>", "org.dept.rd", "Department channel")
    table.add_row("Team", "org.team.<id>", "org.team.proj-alpha", "Project team channel")
    table.add_row("DM", "org.dm.<sorted_ids>", "org.dm.bot_a.bot_b", "Direct message")
    table.add_row("System", "org.sys.<event>", "org.sys.heartbeat", "System events")

    console.print(table)
    console.print("\n[dim]Use `clawmesh shout <channel> <message>` to send messages[/dim]")
