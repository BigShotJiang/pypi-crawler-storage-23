"""ClawMesh CLI entry point."""

from __future__ import annotations

import typer

from clawmesh.cli.channels_cmd import channels
from clawmesh.cli.daemon_cmd import daemon_app
from clawmesh.cli.dm import dm
from clawmesh.cli.fetch import fetch
from clawmesh.cli.login import login
from clawmesh.cli.search_cmd import search
from clawmesh.cli.shout import shout
from clawmesh.cli.who import who
from clawmesh.cli.whoami import whoami

app = typer.Typer(
    name="clawmesh",
    help="ClawMesh - Communication bus for AI Agents",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

app.command()(login)
app.command()(shout)
app.command()(fetch)
app.command()(dm)
app.command()(who)
app.command()(whoami)
app.command()(channels)
app.command()(search)
app.add_typer(daemon_app)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
