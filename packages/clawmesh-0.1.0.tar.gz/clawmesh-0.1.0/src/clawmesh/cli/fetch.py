"""clawmesh fetch - Retrieve recent messages from a channel."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from clawmesh.config import ClawMeshConfig
from clawmesh.daemon.client import DaemonClient
from clawmesh.protocol.channels import validate_channel
from clawmesh.protocol.message import Message

console = Console()


def fetch(
    channel: str = typer.Argument(help="Channel to fetch from (e.g. org.dept.rd)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Number of messages to fetch"),
    raw: bool = typer.Option(False, "--raw", help="Output raw JSON"),
) -> None:
    """Fetch recent messages from a channel."""
    if not validate_channel(channel):
        console.print(f"[red]Invalid channel: {channel}[/red]")
        raise typer.Exit(1)

    config = ClawMeshConfig.load()
    if not config.is_configured:
        console.print("[red]Not configured. Run `clawmesh login` first.[/red]")
        raise typer.Exit(1)

    asyncio.run(_fetch(config, channel, limit, raw))


async def _fetch(config: ClawMeshConfig, channel: str, limit: int, raw: bool) -> None:
    messages: list[Message] = []

    if DaemonClient.is_available():
        client = DaemonClient()
        resp = await client.fetch(channel, limit)
        if resp.ok:
            messages = [Message.model_validate(m) for m in resp.result.get("messages", [])]
        else:
            console.print(f"[red]Daemon error: {resp.error}[/red]")
            raise typer.Exit(1)
    else:
        from clawmesh.bus.client import BusClient

        try:
            async with BusClient(config) as bus:
                messages = await bus.fetch_messages(channel, limit=limit)
        except Exception as e:
            console.print(f"[red]Failed to fetch: {e}[/red]")
            raise typer.Exit(1)

    if not messages:
        console.print(f"[dim]No messages in {channel}[/dim]")
        return

    if raw:
        for msg in messages:
            console.print(msg.model_dump_json())
    else:
        via = " [dim](via daemon)[/dim]" if DaemonClient.is_available() else ""
        console.print(f"[bold]#{channel}[/bold] (latest {len(messages)} messages){via}\n")
        for msg in messages:
            console.print(msg.short_display())
