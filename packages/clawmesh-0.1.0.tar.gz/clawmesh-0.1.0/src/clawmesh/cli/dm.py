"""clawmesh dm - Send a direct message to another bot."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from clawmesh.config import ClawMeshConfig
from clawmesh.daemon.client import DaemonClient
from clawmesh.protocol.channels import Channel
from clawmesh.protocol.message import Message, MessageType

console = Console()


def dm(
    target_bot: str = typer.Argument(help="Target bot ID"),
    message: str = typer.Argument(help="Message content"),
) -> None:
    """Send a direct message to another bot."""
    config = ClawMeshConfig.load()
    if not config.is_configured:
        console.print("[red]Not configured. Run `clawmesh login` first.[/red]")
        raise typer.Exit(1)

    asyncio.run(_send_dm(config, target_bot, message))


async def _send_dm(config: ClawMeshConfig, target: str, content: str) -> None:
    if DaemonClient.is_available():
        client = DaemonClient()
        resp = await client.dm(target, content)
        if resp.ok:
            console.print(f"[green]DM sent to {target}[/green] [dim](via daemon)[/dim]")
        else:
            console.print(f"[red]Failed: {resp.error}[/red]")
            raise typer.Exit(1)
    else:
        from clawmesh.bus.client import BusClient

        channel = Channel.dm(config.bot_id, target)
        msg = Message(
            from_id=config.bot_id,
            to=channel.subject,
            type=MessageType.CHAT,
            content=content,
        )
        try:
            async with BusClient(config) as bus:
                await bus.publish(msg)
            console.print(f"[green]DM sent to {target}[/green]")
        except Exception as e:
            console.print(f"[red]Failed to send DM: {e}[/red]")
            raise typer.Exit(1)
