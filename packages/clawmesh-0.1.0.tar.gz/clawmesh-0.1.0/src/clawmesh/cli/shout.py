"""clawmesh shout - Send a message to a channel."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from clawmesh.config import ClawMeshConfig
from clawmesh.daemon.client import DaemonClient
from clawmesh.protocol.channels import validate_channel
from clawmesh.protocol.message import Message, MessageType

console = Console()


def shout(
    channel: str = typer.Argument(help="Target channel (e.g. org.dept.rd, org.global)"),
    message: str = typer.Argument(help="Message content"),
    msg_type: str = typer.Option("chat", "--type", "-t", help="Message type: chat/task/event"),
) -> None:
    """Send a message to a channel."""
    if not validate_channel(channel):
        console.print(f"[red]Invalid channel: {channel}[/red]")
        console.print("  Format: org.global | org.dept.<id> | org.team.<id>")
        raise typer.Exit(1)

    config = ClawMeshConfig.load()
    if not config.is_configured:
        console.print("[red]Not configured. Run `clawmesh login` first.[/red]")
        raise typer.Exit(1)

    asyncio.run(_send(config, channel, message, msg_type))


async def _send(config: ClawMeshConfig, channel: str, content: str, msg_type: str) -> None:
    if DaemonClient.is_available():
        client = DaemonClient()
        resp = await client.shout(channel, content, msg_type)
        if resp.ok:
            console.print(f"[green]Message sent to {channel}[/green] [dim](via daemon)[/dim]")
        else:
            console.print(f"[red]Failed: {resp.error}[/red]")
            raise typer.Exit(1)
    else:
        from clawmesh.bus.client import BusClient

        msg = Message(
            from_id=config.bot_id,
            to=channel,
            type=MessageType(msg_type),
            content=content,
            metadata={"department": config.department} if config.department else {},
        )
        try:
            async with BusClient(config) as bus:
                await bus.publish(msg)
            console.print(f"[green]Message sent to {channel}[/green]")
        except Exception as e:
            console.print(f"[red]Failed to send: {e}[/red]")
            raise typer.Exit(1)
