"""ClawMesh Observer - TUI for humans to watch bot conversations.

Built with Textual for a rich terminal UI experience.
"""

from __future__ import annotations

import asyncio
import sys

from textual import on, work
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Input, Label, ListView, RichLog

from clawmesh.config import ClawMeshConfig
from clawmesh.protocol.message import Message

CHANNELS = [
    "org.global",
    "org.dept.rd",
    "org.dept.qa",
    "org.dept.ops",
    "org.team.default",
    "org.sys.presence",
    "org.sys.heartbeat",
]


class ChannelList(ListView):
    DEFAULT_CSS = """
    ChannelList {
        width: 28;
        border-right: solid $accent;
        padding: 0 1;
    }
    """


class MessageView(RichLog):
    DEFAULT_CSS = """
    MessageView {
        border: none;
        padding: 0 1;
    }
    """


class ClawMeshObserver(App):
    """Terminal UI to observe bot communications in real-time."""

    CSS = """
    Screen {
        layout: vertical;
    }
    #main {
        height: 1fr;
    }
    #sidebar {
        width: 28;
        border-right: solid $accent;
    }
    #sidebar Label {
        padding: 0 1;
        width: 100%;
    }
    #sidebar Label.channel-item {
        padding: 0 1;
        height: 1;
    }
    #sidebar Label.channel-item:hover {
        background: $accent;
    }
    #chat-area {
        width: 1fr;
    }
    #status-bar {
        height: 1;
        background: $accent;
        padding: 0 1;
    }
    #msg-input {
        dock: bottom;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("ctrl+c", "quit", "Quit"),
    ]

    def __init__(self, config: ClawMeshConfig | None = None, **kwargs):
        super().__init__(**kwargs)
        self._config = config or ClawMeshConfig.load()
        self._current_channel = "org.global"
        self._nats_task: asyncio.Task | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="main"):
            with Vertical(id="sidebar"):
                yield Label("[bold]Channels[/bold]", id="channel-header")
                for ch in CHANNELS:
                    short = ch.replace("org.", "#")
                    ch_id = f"ch-{ch.replace('.', '-')}"
                    yield Label(f" {short}", classes="channel-item", id=ch_id)
            with Vertical(id="chat-area"):
                status_text = (
                    f"[bold]#{self._current_channel}[/bold]  |  "
                    f"{self._config.bot_id}@{self._config.server}"
                )
                yield Label(status_text, id="status-bar")
                yield MessageView(id="messages", highlight=True, markup=True)
                yield Input(placeholder="Type a message (Enter to send)...", id="msg-input")
        yield Footer()

    def on_mount(self) -> None:
        self.title = "ClawMesh Observer"
        self.sub_title = f"Watching as {self._config.bot_id}"
        self._load_history()
        self._start_live_feed()

    @work(thread=True)
    def _load_history(self) -> None:
        """Load recent messages from archive or NATS."""
        from clawmesh.archiver.storage import ArchiveStorage

        try:
            with ArchiveStorage() as storage:
                messages = storage.search(query="", channel=self._current_channel, limit=50)
            for msg in messages:
                self._append_message(msg)
        except Exception:
            self.call_from_thread(
                self.query_one("#messages", MessageView).write,
                "[dim]No archived history available.[/dim]",
            )

    @work(thread=True)
    def _start_live_feed(self) -> None:
        """Subscribe to NATS for real-time messages."""
        import nats

        async def _subscribe():
            connect_opts: dict = {"servers": [self._config.server]}
            if self._config.token:
                connect_opts["token"] = self._config.token

            try:
                nc = await nats.connect(**connect_opts)
                js = nc.jetstream()
                sub = await js.subscribe("org.>", ordered_consumer=True)

                while True:
                    try:
                        msg = await sub.next_msg(timeout=2.0)
                        parsed = Message.from_nats_payload(msg.data)
                        if parsed.to == self._current_channel:
                            self._append_message(parsed)
                    except TimeoutError:
                        continue
            except Exception as e:
                self.call_from_thread(
                    self.query_one("#messages", MessageView).write,
                    f"[red]NATS connection error: {e}[/red]",
                )

        asyncio.run(_subscribe())

    def _append_message(self, msg: Message) -> None:
        """Thread-safe message append to the view."""
        if msg.type.value == "event" and msg.content in ("heartbeat", "online", "offline"):
            text = f"[dim]{msg.short_display()}[/dim]"
        else:
            text = msg.short_display()

        try:
            view = self.query_one("#messages", MessageView)
            self.call_from_thread(view.write, text)
        except Exception:
            pass

    @on(Input.Submitted, "#msg-input")
    def _on_send(self, event: Input.Submitted) -> None:
        content = event.value.strip()
        if not content:
            return
        event.input.clear()
        self._send_message(content)

    @work(thread=True)
    def _send_message(self, content: str) -> None:
        from clawmesh.bus.client import BusClient

        msg = Message(
            from_id=f"human:{self._config.bot_id}",
            to=self._current_channel,
            content=content,
        )

        async def _publish():
            async with BusClient(self._config) as bus:
                await bus.publish(msg)

        try:
            asyncio.run(_publish())
            self._append_message(msg)
        except Exception as e:
            self.call_from_thread(
                self.query_one("#messages", MessageView).write,
                f"[red]Send failed: {e}[/red]",
            )


def main() -> None:
    config = ClawMeshConfig.load()
    if not config.is_configured:
        print("Not configured. Run `clawmesh login` first.")
        sys.exit(1)
    app = ClawMeshObserver(config)
    app.run()


if __name__ == "__main__":
    main()
