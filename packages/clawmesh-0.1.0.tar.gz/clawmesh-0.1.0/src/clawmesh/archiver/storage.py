"""SQLite storage layer with FTS5 full-text search for message archival."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from clawmesh.protocol.message import Message

DEFAULT_DB_PATH = Path.home() / ".clawmesh" / "archive.db"


class ArchiveStorage:
    """SQLite-backed message archive with FTS5 full-text search."""

    def __init__(self, db_path: Path | None = None):
        self._db_path = db_path or DEFAULT_DB_PATH
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None

    def open(self) -> None:
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._create_tables()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _create_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                from_id TEXT NOT NULL,
                channel TEXT NOT NULL,
                type TEXT NOT NULL,
                content TEXT NOT NULL,
                reply_to TEXT DEFAULT '',
                metadata TEXT DEFAULT '{}',
                timestamp INTEGER NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel);
            CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages(timestamp);
            CREATE INDEX IF NOT EXISTS idx_messages_from ON messages(from_id);

            CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
                content, from_id, channel,
                content='messages',
                content_rowid='rowid'
            );

            CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
                INSERT INTO messages_fts(rowid, content, from_id, channel)
                VALUES (new.rowid, new.content, new.from_id, new.channel);
            END;
        """)

    def insert(self, msg: Message) -> None:
        import json

        self._conn.execute(
            """INSERT OR IGNORE INTO messages
               (id, from_id, channel, type, content, reply_to, metadata, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                msg.id,
                msg.from_id,
                msg.to,
                msg.type.value,
                msg.content,
                msg.reply_to,
                json.dumps(msg.metadata),
                msg.timestamp,
            ),
        )
        self._conn.commit()

    def insert_batch(self, messages: list[Message]) -> None:
        import json

        self._conn.executemany(
            """INSERT OR IGNORE INTO messages
               (id, from_id, channel, type, content, reply_to, metadata, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            [
                (
                    m.id,
                    m.from_id,
                    m.to,
                    m.type.value,
                    m.content,
                    m.reply_to,
                    json.dumps(m.metadata),
                    m.timestamp,
                )
                for m in messages
            ],
        )
        self._conn.commit()

    def search(
        self,
        query: str,
        channel: str | None = None,
        from_id: str | None = None,
        limit: int = 20,
    ) -> list[Message]:
        """Search archived messages. Uses FTS5 for ASCII, LIKE for CJK."""
        import json

        is_ascii = all(ord(c) < 128 for c in query if not c.isspace())

        if query and is_ascii:
            sql = """
                SELECT m.* FROM messages m
                JOIN messages_fts f ON m.rowid = f.rowid
                WHERE messages_fts MATCH ?
            """
            params: list = [query]
        elif query:
            sql = "SELECT * FROM messages WHERE content LIKE ?"
            params = [f"%{query}%"]
        else:
            sql = "SELECT * FROM messages WHERE 1=1"
            params = []

        if channel:
            tbl = "m" if (query and is_ascii) else ""
            col = f"{tbl}.channel" if tbl else "channel"
            sql += f" AND {col} = ?"
            params.append(channel)
        if from_id:
            tbl = "m" if (query and is_ascii) else ""
            col = f"{tbl}.from_id" if tbl else "from_id"
            sql += f" AND {col} = ?"
            params.append(from_id)

        order_col = "m.timestamp" if (query and is_ascii) else "timestamp"
        sql += f" ORDER BY {order_col} DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(sql, params).fetchall()
        messages = []
        for row in rows:
            messages.append(
                Message(
                    id=row["id"],
                    from_id=row["from_id"],
                    to=row["channel"],
                    type=row["type"],
                    content=row["content"],
                    reply_to=row["reply_to"],
                    metadata=json.loads(row["metadata"]) if row["metadata"] else {},
                    timestamp=row["timestamp"],
                )
            )
        return list(reversed(messages))

    def count(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM messages").fetchone()
        return row[0] if row else 0

    def __enter__(self) -> ArchiveStorage:
        self.open()
        return self

    def __exit__(self, *exc) -> None:
        self.close()
