"""HTTP search API for the archiver service.

Provides a lightweight HTTP endpoint for bots to search message history.
Uses aiohttp for async HTTP serving.
"""

from __future__ import annotations

import logging

from clawmesh.archiver.storage import ArchiveStorage

logger = logging.getLogger("clawmesh.archiver.api")


async def create_app(storage: ArchiveStorage):
    """Create and configure the aiohttp application."""
    from aiohttp import web

    async def handle_search(request: web.Request) -> web.Response:
        query = request.query.get("q", "")
        channel = request.query.get("channel")
        from_id = request.query.get("from")
        limit = min(int(request.query.get("limit", "20")), 100)

        messages = storage.search(query=query, channel=channel, from_id=from_id, limit=limit)
        result = {
            "query": query,
            "count": len(messages),
            "messages": [m.model_dump() for m in messages],
        }
        return web.json_response(result)

    async def handle_stats(request: web.Request) -> web.Response:
        return web.json_response({"total_messages": storage.count()})

    async def handle_health(request: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    app = web.Application()
    app.router.add_get("/search", handle_search)
    app.router.add_get("/stats", handle_stats)
    app.router.add_get("/health", handle_health)

    return app
