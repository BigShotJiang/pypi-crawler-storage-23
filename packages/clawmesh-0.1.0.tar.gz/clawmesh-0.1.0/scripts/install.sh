#!/bin/bash
# ClawMesh one-line installer
# Usage: curl -sSL https://raw.githubusercontent.com/NoDeskAI/ClawMesh/main/scripts/install.sh | bash
#
# Priority: uv tool install (isolated) > pip install --user (fallback)
# For zero-install usage, just run: uvx clawmesh <command>

set -e

echo "=== ClawMesh Installer ==="
echo ""

# Check if uv is available
if command -v uv &> /dev/null; then
    echo "[*] Found uv ($(uv --version))"
    echo "[*] Installing clawmesh in isolated environment..."
    uv tool install clawmesh
    echo ""
    echo "Done! clawmesh is now available in your PATH."
else
    echo "[!] uv not found. Installing uv first..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
    echo "[*] uv installed. Now installing clawmesh..."
    uv tool install clawmesh
    echo ""
    echo "Done! clawmesh is now available in your PATH."
fi

echo ""
echo "=== Next Steps ==="
echo ""
echo "  1. Start NATS bus:"
echo "     docker compose up -d"
echo ""
echo "  2. Configure identity:"
echo "     clawmesh login --server nats://localhost:4222 --id my_bot"
echo ""
echo "  3. Start talking:"
echo "     clawmesh shout org.global 'Hello from ClawMesh!'"
echo ""
echo "  Tip: For zero-install usage (no 'uv tool install' needed):"
echo "     uvx clawmesh shout org.global 'hello'"
