"""
Unpublished work.
Copyright (c) 2025 by Teradata Corporation. All rights reserved.
TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

Primary Owner: aanchal.kavedia@teradata.com
Secondary Owner: sushant.mhambrey@teradata.com

This file implements Collection class along with its method.
"""


import warnings
import enum
import json
import pandas as pd
from json import JSONDecodeError
# TeradataML imports
from teradataml import DataFrame, in_schema
from teradataml.common.constants import HTTPRequest
from teradataml.common.utils import UtilFuncs
from teradataml.context.context import get_connection, get_context
from teradataml.utils.validators import _Validators
from teradataml.common.exceptions import TeradataMlException
from teradataml.common.messages import Messages
from teradataml.common.messagecodes import MessageCodes
from teradataml.scriptmgmt.UserEnv import _get_auth_token
from teradataml.scriptmgmt.lls_utils import set_auth_token

# TeradataGenAI imports
from teradatagenai.vector_store.vector_store import VectorStore, _SimilaritySearch
from teradatagenai.llm.llm import TeradataAI
from teradatagenai.common.constants import CollectionType, CollectionURLs
from teradataml.utils.dtypes import _ListOf
from teradatagenai.common.collection_docstring_params import (
    MODEL_PARAMS, PAGE_PARAMS, RETURN_TYPE_PARAMS, AUTH_PARAMS, 
    CREATE_COMMON_PARAMS, FILTER_PARAMS, SEARCH_PARAMS, UPDATE_PARAMS, EXTRACTION_COMMON_PARAMS, EMBEDDING_COMMON_PARAMS, COLUMN_PARAMS,
    FILE_DOCUMENTS_COMMON_PARAMS
)
from teradatagenai.common.constants import FILE_BASED_VECTOR_STORE_PARAMS
from teradatagenai.common.exceptions import TeradataGenAIException
from teradatagenai.common.message_codes import MessageCodes as MessageCodesGenAI
from teradatagenai.common.utils import GenAIUtilFuncs
from teradatagenai.common.collection_api_schema import build_request
from teradatagenai.utils.doc_decorator import docstring_handler
from teradatagenai.utils.doc_validator import validate_docstring_kwargs
from teradatagenai.telemetry_utils.queryband import collect_queryband
from teradatagenai.vector_store.data_classes import (
    ContentBasedIndex, EmbeddingBasedIndex, ColumnInfo, ColumnExpression, HNSW, FLAT, 
    IVF_FLAT, SearchParams, LocalConfig, S3Config, AzureBlobConfig, GCPConfig,
    BasicIngestor, NVIngestor, UnstructuredIngestor, ExtractionSchema
)
from teradatagenai.utils.filter_utils import process_filter
from teradataml.common.messagecodes import MessageCodes as TDMLMessageCodes


@docstring_handler(
    common_params={**RETURN_TYPE_PARAMS}
)
def _validate_and_normalize_return_type(return_type):
    """
    DESCRIPTION:
        Validates and normalizes the return_type parameter for API methods.
        If return_type is not provided, determines the default based on the 
        connection context:
            - If a teradataml connection exists (create_context has been called),
              defaults to 'teradataml'.
            - If no connection exists (only set_auth_token used), defaults to 'json'.
        Otherwise, uses the provided return_type.

    RETURNS:
        Normalized return_type as a lowercase string ('teradataml', 'pandas', or 'json').

    RAISES:
        TeradataMlException: If the provided return_type is invalid.

    EXAMPLES:
        >>> _validate_and_normalize_return_type(None)  # Defaults based on connection
        >>> _validate_and_normalize_return_type('pandas')
    """
    # Set default return_type based on connection presence.
    if return_type is None:
        if get_connection() is not None:
            normalized_return_type = 'teradataml'
        else:
            normalized_return_type = 'json'
    else:
        normalized_return_type = return_type
    
    # Validate return_type
    arg_info_matrix = [
        ["return_type", normalized_return_type, False, str, True, 
         ["teradataml", "pandas", "json"]]
    ]
    _Validators._validate_function_arguments(arg_info_matrix)
    
    # Normalize to lowercase
    normalized_return_type = normalized_return_type.lower()
    return normalized_return_type


class _CollectionListSessions:
    """
    Internal class to create a _CollectionListSessions object for list_sessions method.
    Displays session details in a readable format.
    """
    def __init__(self, response, **kwargs):
        self.session_count = response['session_count']
        self.self_user_name = response['self_user_name']
        self.page = response['page']
        self.page_size = response['page_size']
        self._json_obj = response['session_details']
        
        # Validate and normalize return_type
        return_type = _validate_and_normalize_return_type(kwargs.get('return_type'))

        if return_type == "json":
            self.session_details = self._json_obj
        else:
            # Create DataFrame from session_details
            self.session_details = VectorStore._convert_to_tdmldf(
                pd.DataFrame(response['session_details'])
            ) if return_type == "teradataml" else pd.DataFrame(response['session_details'])

    def __repr__(self):
        return (f"session_count: {self.session_count}\n"
                f"self_user_name: {self.self_user_name}\n"
                f"page: {self.page}\n"
                f"page_size: {self.page_size}\n\n"
                f"session_details:\n{self.session_details}")


class _CollectionListAvailableModels:
    """
    Internal class to create a _CollectionListAvailableModels object for list_available_models method.
    Displays available models in a readable format.
    """
    def __init__(self, response, **kwargs):
        self._json_obj = response
        
        # Validate and normalize return_type
        return_type = _validate_and_normalize_return_type(kwargs.get('return_type'))

        if return_type == "json":
            self.embedding_models = response.get('embedding_models', [])
            self.chat_models = response.get('chat_models', [])
        else:
            # Create DataFrames from model lists
            embedding_df = pd.DataFrame(response.get('embedding_models', []))
            chat_df = pd.DataFrame(response.get('chat_models', []))
            
            if return_type == "teradataml":
                self.embedding_models = VectorStore._convert_to_tdmldf(embedding_df) if not embedding_df.empty else embedding_df
                self.chat_models = VectorStore._convert_to_tdmldf(chat_df) if not chat_df.empty else chat_df
            else:
                self.embedding_models = embedding_df
                self.chat_models = chat_df

    def __repr__(self):
        return (f"embedding_models:\n{self.embedding_models}\n\n"
                f"chat_models:\n{self.chat_models}")


class V2RequestFormation:
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS}
    )
    def _prepare_for_request(self, return_type):
        """
        DESCRIPTION:
            Prepare headers, and normalizes return_type.
            Common initialization for all API methods.
            Supports both class-level and instance-level usage.
                
        RETURNS:
            Tuple containing (normalized_return_type, manager) ready for _make_request().
        
        RAISES:
            TeradataMlException.
        
        EXAMPLES:
            >>> manager = CollectionManager()
            >>> return_type = manager._prepare_for_request("pandas")
        """
        # Normalize return_type
        return_type = _validate_and_normalize_return_type(return_type)

        # Get authentication headers
        if getattr(self, "auth_data", None) is not None:
            headers = self.auth_data._auth_token.get_header()
        else:
            headers = _get_auth_token()

        self._headers = headers
        return return_type

    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS}
    )
    def _make_request(self, http_method, endpoint, response_key=None, 
                      return_type=None, **kwargs):
        """
        DESCRIPTION:
            Generic HTTP request handler to reduce code duplication.
            Builds URL, makes HTTP request, processes response, and formats output.
        
        PARAMETERS:
            http_method:
                Required Argument.
                Specifies the HTTP method to use.
                Permitted Values: HTTPRequest.GET, HTTPRequest.DELETE
                Types: HTTPRequest
            
            endpoint:
                Required Argument.
                Specifies the endpoint name for URL builder.
                Types: str
            
            response_key:
                Optional Argument.
                Specifies the key to extract from processed response.
                If None, uses entire response.
                Types: str or None

            **kwargs:
                Optional Arguments.
                Additional parameters passed to urls.build() as query params
                or to _http_request() as request body.
                Types: dict
        
        RETURNS:
            Processed response based on return_type - DataFrame or dict.
        
        RAISES:
            TeradataMlException.
        
        EXAMPLES:
            >>> manager = CollectionManager()
            >>> result = manager._make_request(HTTPRequest.GET, "health", None, "json")
        """
        # Build URL with query params from kwargs, excluding None values
        url_params = {k: v for k, v in kwargs.items() if k != 'json' and v is not None}
        url = self.urls.build(endpoint, **url_params)

        # Make HTTP request
        GenAIUtilFuncs._set_queryband()
        
        kwargs['headers'] = self._headers
        http_params = {'headers': self._headers}
        for key in ['headers', 'json', 'files', 'data']:
            if kwargs.get(key) is not None:
                http_params[key] = kwargs[key]

        response = UtilFuncs._http_request(url, http_method, **http_params)
        
        # Process response - endpoint name is also the response processing key
        #processed = VectorStore._process_vs_response(endpoint, response)
        processed = Collection._process_collection_response(endpoint, response)


        # Extract data if response_key provided
        data = (None if processed is None else 
                (processed.get(response_key, processed) if response_key 
                 else processed))
        # Return None in case of status and destroy wherein we dont have any output.
        if data is None:
            return

        # Handle special case for similarity_search.
        if endpoint == "similarity_search":
            return _SimilaritySearch(data, return_type=return_type)
        
        if endpoint == "sessions_list":
            return _CollectionListSessions(processed, return_type=return_type)
        
        if endpoint == "list_available_models":
            return _CollectionListAvailableModels(processed, return_type=return_type)

        # Handle return types
        if return_type == "json":
            return data
        
        if isinstance(data, dict):
            data = [data]
        df = pd.DataFrame(data) if isinstance(data, list) else pd.DataFrame([data])
        if return_type == "pandas":
            return df
        
        return VectorStore._convert_to_tdmldf(df)


class CollectionManager(V2RequestFormation):
    """
    CollectionManager allows users to:
        * Perform health check for the collection service.
        * List all available models configured on the platform.
        * List all collections that are created.
        * List all active sessions.
        * Disconnect database sessions for specified user(s).
    """
    @docstring_handler(
        common_params={**AUTH_PARAMS}
    )
    def __init__(self, auth_data=None):
        """
        Initialize CollectionManager by optionally passing in auth_data.
        If auth_data is not provided, uses latest credentials from set_auth_token().
        
        RETURNS:
            None.
        
        EXAMPLES:
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import CollectionManager
            # Example: Initialize CollectionManager with custom auth_data 
            auth_data = set_auth_token(base_url="https://my-tdai-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")

            >>> manager = CollectionManager(auth_data=auth_data)
        """
        self.auth_data = auth_data
        base_url = getattr(auth_data, "base_url", None) if auth_data is not None else None
        self.urls = CollectionURLs(base_url=base_url)

    @collect_queryband(queryband="Collection_health")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS})
    def health(self=None, return_type=None):
        """
        DESCRIPTION:
            Performs sanity check for the collection service.

        RETURNS:
            Collection service health status in specified format.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import CollectionManager
            
            # Initialize CollectionManager with custom auth_data 
            auth_data = set_auth_token(base_url="https://my-tdai-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")

            >>> cm = CollectionManager(auth_data=auth_data)
            
            # Example 1: Check service health and set return type to json.
            >>> cm.health(return_type="json")

            # Example 2: Check service health with return type as teradataml DataFrame.
            >>> cm.health()
        """
        mgr = self if self is not None else CollectionManager()
        return_type = mgr._prepare_for_request(return_type)
        return mgr._make_request(HTTPRequest.GET, "health", None, return_type)

    @collect_queryband(queryband="Collection_list_available_models")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS})
    def list_available_models(self=None, return_type=None):
        """
        DESCRIPTION:
            Lists all available embedding and chat models configured on the platform.

        RETURNS:
            If "return_type" is 'json', return JSON else returns _CollectionListAvailableModels
            object containing embedding_models and chat_models details.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradataml import set_auth_token, create_context
            >>> from teradatagenai import CollectionManager
            
            # Initialize CollectionManager with custom auth_data 
            create_context(host="my_host", username="my_username", password="my_password")
            auth_data = set_auth_token(base_url="https://my-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")

            >>> cm = CollectionManager(auth_data=auth_data)
            
            # Example 1: List available models with return type as json.
            >>> models = cm.list_available_models(return_type="json")
            >>> print(models.embedding_models)
            >>> print(models.chat_models)

            # Example 2: List available models with return type as pandas DataFrame.
            >>> result = cm.list_available_models(return_type="pandas")
            
            # Example 3: List available models with default return type (teradataml DataFrame).
            >>> result = cm.list_available_models()
        """
        mgr = self if self is not None else CollectionManager()
        return_type = mgr._prepare_for_request(return_type)
        return mgr._make_request(HTTPRequest.GET, "list_available_models", None, return_type)

    @collect_queryband(queryband="Collection_list")
    @docstring_handler(
        common_params={**PAGE_PARAMS, **RETURN_TYPE_PARAMS}
    )
    def list(self=None, authorized=False, page=1, page_size=20, return_type=None):
        """
        DESCRIPTION:
            Lists all the collections that are created.
            
            Notes:
                * Lists all collections if user has admin role permissions.
                * Lists collections only permitted to the user if authorized is 
                  set to True.
                * Supports pagination for handling large numbers of collections.

        RETURNS:
            List of collections in specified return_type.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import CollectionManager
            
            # Initialize CollectionManager with custom auth_data 
            auth_data = set_auth_token(base_url="https://my-tdai-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")

            >>> cm = CollectionManager(auth_data=auth_data)
            
            # Example 1: List collections with return type as JSON.
            >>> cm.list(return_type="json")
            
            # Example 2: List 50 collections from page 1.
            >>> cm.list(page=1, page_size=50)
            
            # Example 3: List authorized collections only.
            >>> cm.list(authorized=True, return_type="pandas")

        """
        arg_info_matrix = []
        arg_info_matrix.append(["authorized", authorized, True, bool, True])
        arg_info_matrix.append(["page", page, True, int, True])
        arg_info_matrix.append(["page_size", page_size, True, int, True])
        _Validators._validate_function_arguments(arg_info_matrix)


        mgr = self if self is not None else CollectionManager()
        return_type = mgr._prepare_for_request(return_type)
        return mgr._make_request(
            HTTPRequest.GET, "collections_list", "collection_list", return_type,
            authorized=authorized, page=page, page_size=page_size
        )

    @collect_queryband(queryband="Collection_list_sessions")
    @docstring_handler(
        common_params={**PAGE_PARAMS, **RETURN_TYPE_PARAMS},
        exclude_params=["authorized"]
    )
    def list_sessions(self=None, page=1, page_size=20, return_type=None):
        """
        DESCRIPTION:
            Lists all active sessions of the collection service.
            
            Notes:
                * Only admin users can use this method.
                * Supports pagination for handling large numbers of sessions.

        RETURNS:
            If "return_type" is 'json', return JSON else returns _CollectionListSessions
            object containing session details.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import CollectionManager
            
            # Initialize CollectionManager with custom auth_data 
            auth_data = set_auth_token(base_url="https://my-tdai-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")
            # Initialize CollectionManager
            >>> cm = CollectionManager(auth_data=auth_data)
            
            # Example 1: List all sessions
            >>> cm.list_sessions()
            
            # Example 2: List sessions with pagination
            >>> cm.list_sessions(page=1, page_size=50)
        """

        arg_info_matrix = []
        arg_info_matrix.append(["page", page, True, int, True])
        arg_info_matrix.append(["page_size", page_size, True, int, True])
        _Validators._validate_function_arguments(arg_info_matrix)

        mgr = self if self is not None else CollectionManager()
        return_type = mgr._prepare_for_request(return_type)
        response_key = "session_details" if return_type == "json" else None
        return mgr._make_request(
            HTTPRequest.GET, "sessions_list", response_key, return_type,
            page=page, page_size=page_size
        )

    @collect_queryband(queryband="Collection_disconnect")
    def disconnect(self=None, user_names=None):
        """
        DESCRIPTION:
            Terminate database sessions for specified users.
            Notes:
                * Only admin users can disconnect sessions.
                * Multiple usernames can be provided as a list.
                * This method disconnects sessions by username, not session ID.

        PARAMETERS:
            user_names:
                Required Argument.
                Specifies one or more usernames whose database sessions should be 
                disconnected.
                Multiple usernames can be passed as separate arguments.
                Types: str or List[str]
        
        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import CollectionManager
            
            # Initialize CollectionManager with custom auth_data 
            auth_data = set_auth_token(base_url="https://my-tdai-server.com",
                                       username="my_username",
                                       password="my_password",
                                       auth_mech = "BASIC")

            # Example 1: Disconnect single user
            >>> cm.disconnect(user_names = "alice")
            
            # Example 2: Disconnect multiple users using list
            >>> cm.disconnect(user_names = ["alice", "bob"])
        """        
        # Validate user_names parameter
        arg_info_matrix = [["user_names", user_names, False, (str, list), True]]
        _Validators._validate_function_arguments(arg_info_matrix)
        
        user_names_list = UtilFuncs._as_list(user_names)

        mgr = self if self is not None else CollectionManager()
        return_type = mgr._prepare_for_request(None)
        return mgr._make_request(
            HTTPRequest.DELETE, "sessions_terminate", None, "json",
            json={"user_names": user_names_list}
        )


class Collection(VectorStore, V2RequestFormation):
    """
    Collection class is a python interface supporting V2 version of
    Teradata Enterprise Vector Store.
    """
    @docstring_handler(
            common_params={**AUTH_PARAMS, **CREATE_COMMON_PARAMS},
            include_params=['name', 'type', 'auth_data']
    )
    def __init__(self, name=None, type=None, auth_data=None, **kwargs):
        """
        DESCRIPTION:
            Collection contains a vectorized version of data.
            The vectorization typically is a result of embeddings generated by
            an AI LLM.
            There are two types of collections supported:
                * Content-based collection: A collection built on the
                  contents of table/view/teradataml DataFrame.
                  The table can be formed from the contents of file / pdf.
                  Questions can be asked against the contents of the table and
                  top matches of relevant rows are returned based on search.
                  This can be followed by a textual response generated using
                  an LLM by manipulating the top matches.

                * Embedding-based collection: A collection built on pre-computed
                  embeddings stored in tables. Questions (both in vector and string form)
                  can be asked against the collection and top matches are returned based
                  on similarity search.
            
            Notes:
                * If the collection mentioned in the name argument
                  already exists, it is initialized for use.
                * If not, user needs to call create() or from_*() methods
                  to create the same.

        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Import Collection class
            >>> from teradatagenai import Collection
            # Initialize a content-based collection
            >>> collection = Collection(name="customer_360")
        """

        
        # Validating name, log, and auth_data FIRST before using them.
        arg_info_matrix = []
        arg_info_matrix.append(["name", name, True, (str), True])
        arg_info_matrix.append(["type", type, True, (str, CollectionType), True])
        arg_info_matrix.append(["auth_data", auth_data, True, (set_auth_token), True])
        
        # Validate argument types.
        _Validators._validate_function_arguments(arg_info_matrix)
        
        self.name = name
        self.type = type
        self._auth_data = auth_data
        self._database = None  # Initialize database attribute
        self.urls = CollectionURLs()
        self.__exists = False  # Use private variable

        return_type = self._prepare_for_request(return_type="json")
        if self.name is not None and self.exists:
            print(f"Collection {self.name} initialized for use.")
        else:
            warnings.warn("Collection does not exist or name is not supplied. Create it before proceeding ahead.")

    @property
    def exists(self):
        """
        Check if the collection exists by querying the CollectionManager list.
        Also sets the collection type and database if found.
        
        Returns:
            bool: True if collection exists, False otherwise
        """
        if self.name is None:
            return False
        
        if self._auth_data:
            self._mgr = CollectionManager(auth_data=self._auth_data)
        else:
            self._mgr = CollectionManager()

        # Get list of all collections with large page_size to get all results
        collections = self._mgr.list(return_type='json', page_size=100000)
        
        # Check if collection name exists in the list
        for collection in collections:
            if self.name.lower() == collection['collection_name'].lower():
                self.__exists = True
                # Set database and type info similar to VectorStore
                self._database = collection.get('target_database')
                if not self.type:  # Only set if not already specified
                    # Convert string collection type to CollectionType enum using enum value lookup
                    collection_type_str = collection.get('collection_type')
                    if collection_type_str:
                        try:
                            # Use enum constructor - works because enum values match the strings
                            self.type = CollectionType(collection_type_str)
                        except ValueError:
                            # Fallback to string if enum value not found (for unknown types)
                            self.type = collection_type_str
                
                # Optionally check for failed status like VectorStore does
                collection_status = collection.get('collection_status', '')
                if 'FAILED' in collection_status.upper():
                    warnings.warn(f"Collection {self.name} has status '{collection_status}'. "
                                  f"Take the appropriate action before moving ahead.")
                return True
        
        self.__exists = False
        return False
    
    @exists.setter
    def exists(self, value):
        self.__exists = value



    @staticmethod
    def _process_collection_response(api_name, response, success_status_code=None, raise_error=True):
        """
        DESCRIPTION:
            Process and validate the Collection service response for v2 API.
        
        PARAMETERS:
            api_name:
                Required Argument.
                Specifies the name of the Collection method.
                Types: str
            
            response:
                Required Argument.
                Specifies the response received from Collection service.
                Types: requests.Response
            
            success_status_code:
                Optional Argument.
                Specifies the expected success status code for the corresponding
                Collection service.
                Default Value: None
                Types: int
            
            raise_error:
                Optional Argument.
                Specifies a boolean flag that decides whether to raise error or not.
                Default Values: True
                Types: bool
        
        RETURNS:
            Response object.
        
        RAISES:
            TeradataMlException, JSONDecodeError.
        
        EXAMPLES:
                >>> _process_collection_response("create", resp)
        """
        try:
            data = response.json()
            # Success status code ranges between 200-300.
            if (success_status_code is None and 200 <= response.status_code <= 303) or \
                    (success_status_code == response.status_code):
                if "message" in data:
                    if api_name not in ["similarity-search", "similarity_search", "prepare-response", "prepare_response", "ask"]:
                        print(data['message'])
                    return data['message']
                else:
                    return data
            # Handle error responses
            # v2 format with 'detail' as list of error objects
            if 'detail' in data:
                if isinstance(data['detail'], list):
                    error_descriptions = []
                    for error_obj in data['detail']:
                        msg = error_obj.get('msg', 'Unknown error')
                        loc = error_obj.get('loc', [])
                        # Use the last element of loc as the field name
                        field_name = loc[-1] if loc else 'unknown'
                        error_descriptions.append(f"{msg} for '{field_name}'")
                    error_description = ", ".join(error_descriptions)
                else:
                    # Old format where detail is a string
                    error_description = data['detail']
            elif 'error_message' in data:
                error_description = data['error_message']
                # Handle collection not found case
                if "Collection" in error_description and "not found" in error_description:
                    print("Collection does not exist or it has been destroyed successfully.")
                    return
            else:
                error_description = str(data)
            error_description = f'Response Code: {response.status_code}, Message: {error_description}'
            error_msg = Messages.get_message(MessageCodes.FUNC_EXECUTION_FAILED,
                                            api_name,
                                            error_description)
            if raise_error:
                raise TeradataMlException(error_msg, MessageCodes.FUNC_EXECUTION_FAILED)
        except JSONDecodeError:
            error_msg = Messages.get_message(MessageCodes.FUNC_EXECUTION_FAILED,
                                            api_name,
                                            f'Response Code: {response.status_code}, Message: {response.text}')
            if raise_error:
                raise TeradataMlException(error_msg, MessageCodes.FUNC_EXECUTION_FAILED)
        except Exception as e:
            if raise_error:
                raise

    def _handle_delete_operations(self, data, **kwargs):
        """
        DESCRIPTION:
            Common helper method for processing delete operations for embedding and content
            based collections.
        
        PARAMETERS:
            data:
                Required Argument.
                Specifies the name of the tables or teradataml DataFrames to be processed.
                Types: str, DataFrame, or list of str/DataFrame
            
            **kwargs:
                Optional keyword arguments.
        
        RETURNS:
            None.
        
        RAISES:
            TeradataMlException.
        """
        arg_info_matrix = [
            ["data", data, False, (str, list, DataFrame), True],
            ["database_name", kwargs.get("database_name"), True, (str), True],
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)

        database_name = kwargs.pop("database_name", None)
        
        # Function to assign DataBaseName and TableName
        def process_item(item):
            df = item if isinstance(item, DataFrame) else DataFrame(item)
            assignments = {"DataBaseName": database_name}
            
            # Table name extraction from DataFrame and from otf is taken 
            # care by the UtilFuncs._extract_table_name method. It handles
            # all cases include single and double dot notation.
            table_name_attr = getattr(df, '_table_name', None)
            if table_name_attr:
                assignments["TableName"] = UtilFuncs._extract_table_name(table_name_attr)
            data = df.assign(**assignments)
            return data

        # Process inputs.
        if database_name is not None:
            if isinstance(data, list):
                data = [process_item(d) for d in data]
            else:
                data = process_item(data)
        return data, kwargs

    @staticmethod
    def _build_embedding_index(data, name=None, create=False, **kwargs):
        """
        Internal method to build an EmbeddingBasedIndex from parameters.
        Common logic shared between from_embeddings and add_embeddings.
        
        Parameters:
            data: Table name(s)/DataFrame(s) containing pre-embedded data
            name: Collection name (required only if create=True)
            create: Whether this is for collection creation (validates name)
            **kwargs: Should contain column parameters that will be popped
        
        Returns:
            tuple: (EmbeddingBasedIndex object, modified kwargs with columns removed)
        """
        # Pop column parameters to avoid passing them to create/update.
        data_columns = kwargs.pop("data_columns", None)
        key_columns = kwargs.pop("key_columns", None)
        embedding_columns = kwargs.pop("embedding_columns", None)
        metadata_columns = kwargs.pop("metadata_columns", None)

        # Define permitted types for columns
        permitted_types = (ColumnInfo, ColumnExpression, _ListOf(ColumnInfo), _ListOf(ColumnExpression))

        # Build validation matrix
        arg_info_matrix = []
        arg_info_matrix.append(["data", data, False, (str, list, DataFrame), True])
        arg_info_matrix.append(["embedding_columns", embedding_columns, not(create), permitted_types, True])
        arg_info_matrix.append(["data_columns", data_columns, True, permitted_types, True])
        arg_info_matrix.append(["key_columns", key_columns, True, permitted_types, True])
        arg_info_matrix.append(["metadata_columns", metadata_columns, True, permitted_types, True])
        
        # Add name validation if this is for create operation
        if create:
            arg_info_matrix.insert(0, ["name", name, False, str, True])

        # Validate all parameters - check types first, then missing required args
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        # Build the index
        index = EmbeddingBasedIndex(
            object_names=data,
            key_columns=key_columns,
            data_columns=data_columns,
            embedding_columns=embedding_columns,
            metadata_columns=metadata_columns
        )
        
        # Return both index and modified kwargs
        return index, kwargs

    @staticmethod
    def _build_dataset_index(data, name=None, embedding=None, create=False, **kwargs):
        """
        Internal method to build a ContentBasedIndex from parameters.
        Common logic shared between from_datasets and add_datasets.
        
        Parameters:
            data: Table name(s)/DataFrame(s) containing content to be embedded
            name: Collection name (required only if create=True)
            embedding: TeradataAI model for generating embeddings (required if create=True)
            create: Whether this is for collection creation (validates name and requires data/data_columns/embedding)
            **kwargs: Should contain column parameters that will be popped
        
        Returns:
            tuple: (ContentBasedIndex object, modified kwargs with columns removed)
        """
        # Pop column parameters to avoid passing them to create/update.
        data_columns = kwargs.pop("data_columns", None)
        key_columns = kwargs.pop("key_columns", None)
        metadata_columns = kwargs.pop("metadata_columns", None)

        # Define permitted types for columns
        permitted_types = (str, ColumnInfo, ColumnExpression, _ListOf(str), _ListOf(ColumnInfo), _ListOf(ColumnExpression))

        # Build validation matrix
        arg_info_matrix = []
        # data, data_columns, and embedding are required if create=True (from_datasets)
        # For add_datasets (create=False), they are optional
        arg_info_matrix.append(["data", data, not(create), (str, list, DataFrame), True])
        arg_info_matrix.append(["embedding", embedding, not(create), (TeradataAI), True])
        arg_info_matrix.append(["data_columns", data_columns, not(create), permitted_types, True])
        arg_info_matrix.append(["key_columns", key_columns, True, permitted_types, True])
        arg_info_matrix.append(["metadata_columns", metadata_columns, True, permitted_types, True])
        
        # Add name and embedding validation if this is for create operation
        if create:
            arg_info_matrix.insert(0, ["name", name, False, str, True])

        # Validate all parameters - check types first, then missing required args
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        # Build the index
        index = ContentBasedIndex(
            object_names=data,
            key_columns=key_columns,
            data_columns=data_columns,
            metadata_columns=metadata_columns
        )
        
        # Return both index and modified kwargs
        return index, kwargs
   
    @classmethod
    @collect_queryband(queryband="Collection_from_datasets")
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **COLUMN_PARAMS, **AUTH_PARAMS, **MODEL_PARAMS},
        exclude_params=['name', 'type', 'index', 'data_columns', 'embedding_model', 'search_params']
    )
    def from_datasets(cls,
                     name,
                     data,
                     embedding = None,
                     auth_data = None,
                     **kwargs):
        """
        DESCRIPTION:
            Creates a new content-based vector collection from input table(s)
            or DataFrame(s) in one operation.
            If vector collection already exists, an error is raised.
            Notes:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.

        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the vector collection to be created from
                input data.
                Types: str

            data:
                Required Argument.
                Specifies the table name(s)/teradataml DataFrame(s) containing
                content to be embedded for vector collection. Teradata recommends
                to use teradataml DataFrame as input.
                Notes:
                    * If multiple tables/views are passed, each table should
                      have the columns which are mentioned in "data_columns"
                      and "key_columns".
                    * When "target_database" is not set, and only table name is passed to
                      "data", then the input is searched in default database.
                Types: str, DataFrame, list of str, list of DataFrame

            embedding:
                Required Argument.
                Specifies the TeradataAI model for generating embeddings.
                Types: TeradataAI

            data_columns:
                Required Argument.
                Specifies the column(s) containing the text data to be embedded.
                Note:
                    When multiple "data_columns" are specified, data is unpivoted
                    to get a new key column "AttributeName" and a single data column
                    "AttributeValue".
                Types: ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression

        RETURNS:
            Collection object.

        RAISES:
            TeradataMLException

        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token, DataFrame, in_schema
            >>> from teradatagenai import Collection, ColumnInfo, TeradataAI, load_data
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Setup authentication and connection
            >>> create_context(host="your-host", username="your-username",
            ...                password="your-password")
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username", 
            ...     password="your-password"
            ... )
            
            # Load sample data
            >>> load_data("byom", "amazon_reviews_25")

            # Example 1: Create content-based collection from a single table
            >>> # Define the embedding model (using TeradataAI with NIM in below examples)
            >>> embedding_model = TeradataAI(api_type="nim",
                                             model_name="nvidia/llama-3.2-nv-embedqa-1b-v2",
                                             api_base="<Enter your API base URL here>")
            >>> # Define key column
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID",
            ...     sources=["amazon_reviews.rev_id"]
            ... )
            >>> 
            >>> # Define data column (text to be embedded)
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content",
            ...     sources=["amazon_reviews.rev_text"]
            ... )
            >>> 
            >>> # Create the collection using from_datasets
            >>> collection = Collection.from_datasets(
            ...     name="collection_content_based",
            ...     data="amazon_reviews_25",
            ...     embedding=embedding_model,
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     description="Content-based collection created from amazon reviews"
            ... )
            >>> 
            >>> # Check collection status
            >>> collection.status()
            >>> 
            >>> # Get collection details
            >>> collection.get_details()
            
            # Example 2: Create collection using DataFrame with ColumnExpression
            >>> 
            >>> # Create DataFrame reference to sample data
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> 
            >>> # Define the embedding model
            >>> embedding_model = TeradataAI(api_type="nim",
            ...                              model_name="nvidia/llama-3.2-nv-embedqa-1b-v2",
            ...                              api_base="<Enter your API base URL here>")
            >>> 
            >>> # Create collection using DataFrame and ColumnExpression for columns
            >>> collection2 = Collection.from_datasets(
            ...     name="collection_dataframe_example",
            ...     data=reviews_df,
            ...     embedding=embedding_model,
            ...     key_columns=reviews_df.rev_id,
            ...     data_columns=reviews_df.rev_text,
            ...     description="Content-based collection created from DataFrame"
            ... )
            >>> 
            >>> # Check collection status
            >>> collection2.status()
        """
        # Build the content-based index (embedding validated inside)
        index, kwargs = cls._build_dataset_index(data, name=name, embedding=embedding, create=True, **kwargs)
        
        # Set index, type, and embedding for create
        kwargs['index'] = index
        kwargs['type'] = CollectionType.CONTENT_BASED
        kwargs['embedding_model'] = embedding

        instance = cls(name=name, auth_data=auth_data, **kwargs)
        instance.create(**kwargs)
        instance.exists
        return instance

    @classmethod
    @collect_queryband(queryband="Collection_from_texts")
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **AUTH_PARAMS, **MODEL_PARAMS},
        exclude_params=["name", "type", "index", "data_columns", "embedding_model", 'search_params']
    )
    def from_texts(cls, 
                   name,
                   texts,
                   embedding = None,
                   auth_data = None,
                   **kwargs):
        """
        DESCRIPTION:
            Creates a new 'content-based' vector collection from the input 
            text(s)
            If vector collection already exists, an error is raised.
            Notes:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.    
        
        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the collection to create from input text(s).
                Types: str
            
            texts:
                Required Argument.
                Specifies the text data to create the collection from.
                Types: str, list of str
            
            embedding:
                Required Argument.
                Specifies the embedding model to use for generating
                embeddings from the text data.
                Types: TeradataAI

        RETURNS:
            Vector Collection instance.
        
        RAISES:
            TeradataMlException.
        
        EXAMPLES:
            # Import required classes
            >>> from teradatagenai import Collection, TeradataAI
            >>> import os
            
            # Set AWS credentials in environment
            >>> os.environ['AWS_ACCESS_KEY_ID'] = 'your_access_key'
            >>> os.environ['AWS_SECRET_ACCESS_KEY'] = 'your_secret_key'
            >>> os.environ['AWS_DEFAULT_REGION'] = 'us-west-2'
            
            # Configure the AWS Bedrock embedding model
            >>> embeddings_model_aws = TeradataAI(
            ...     api_type="aws",
            ...     model_name="amazon.titan-embed-text-v2:0"
            ... )
            
            # Define texts to create collection from
            >>> texts = [
            ...     "This is a sample text.",
            ...     "This is another example of text data.",
            ... ]
            
            # Create collection from texts
            >>> text_coll = Collection.from_texts(
            ...     name="text_collection_example",
            ...     texts=texts,
            ...     embedding=embeddings_model_aws
            ... )
            
            # Check collection status
            >>> text_coll.status()
        """
        # Validate and build index
        index = cls._build_text_index(texts, name=name, embedding=embedding, create=True, **kwargs)

        kwargs["index"] = index
        kwargs["embedding_model"] = embedding
        kwargs['type'] = CollectionType.CONTENT_BASED

        # Create the collection instance
        instance = cls(name=name, auth_data=auth_data, **kwargs)
        instance.create(**kwargs)
        instance.exists
        return instance

    @classmethod
    @collect_queryband(queryband="Collection_from_embeddings")
    @docstring_handler(
        common_params={**EMBEDDING_COMMON_PARAMS, **COLUMN_PARAMS, **AUTH_PARAMS},
        exclude_params=['update_style', 'metadata_operation']
    )
    def from_embeddings(cls,
                        name,
                        data,
                        auth_data = None,
                        **kwargs):
        """

        DESCRIPTION:
            Creates a new embedding-based vector collection from the
            pre embedded input table(s) or DataFrame(s).
            If vector collection already exists, an error is raised.
            Notes:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.    

        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the vector collection to be created from
                input data.
                Types: str

            data:
                Required Argument.
                Specifies the table name(s)/teradataml DataFrame(s) that are pre embedded to be
                indexed for vector collection. Teradata recommends to use teradataml DataFrame as input.
                Notes:
                    * If multiple tables/views are passed, each table should
                      have the columns which are mentioned in "embedding_columns"
                      and "key_columns".
                    * When "target_database" is not set, and only table name is passed to
                      "data", then the input is searched in default database.
                Types: str, DataFrame, list of str, list of DataFrame

            embedding_columns:
                Required Argument.
                Specifies the name of the column that contains the
                pre embedded data.
                Note:
                    When multiple "embedding_columns" are specified, data is unpivoted
                    to get a new key column "AttributeName" and a single data column
                    "AttributeValue".
                Types: ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression
        
        RETURNS:
            None
        
        RAISES:
            TeradataMLException
        
        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, ColumnInfo
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Setup authentication
            >>> base_url = "https://aiop-btms4.td.teradata.com"
            >>> auth_data = set_auth_token(base_url=base_url,
            ...     username='oaf',
            ...     password='oaf',
            ...     auth_mech='Basic'
            ... )
            
            # Example 1: Create collection from a single table with pre-computed embeddings
            >>> # Define key column
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key",
            ...     sources=["amazon_reviews_embedded.rev_id"]
            ... )
            >>> 
            >>> # Define data column (original text for reference)
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content",
            ...     sources=["amazon_reviews_embedded.rev_text"]
            ... )
            >>> 
            >>> # Define embedding column (pre-computed vectors)
            >>> embedding_column = ColumnInfo(
            ...     name="embedding",
            ...     description="Pre-computed embedding vectors",
            ...     sources=["amazon_reviews_embedded.embedding"]
            ... )
            >>> 
            >>> # Create the collection using from_embeddings
            >>> collection = Collection.from_embeddings(
            ...     name="collection_embedded_single_table",
            ...     data="amazon_reviews_embedded",
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     embedding_columns=embedding_column,
            ...     description="Embedding-based collection created from pre-computed embeddings"
            ... )
            >>> 
            >>> # Check collection status
            >>> collection.status()
            >>> 
            >>> # Get collection details
            >>> collection.get_details()
            
            # Example 2: Create collection from multiple tables with simplified column definitions
            >>> # Define columns without source specification
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key"
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content"
            ... )
            >>> 
            >>> embedding_column = ColumnInfo(
            ...     name="embedding",
            ...     description="Pre-computed embedding vectors"
            ... )
            >>> 
            >>> # Create collection from multiple tables at once
            >>> collection2 = Collection.from_embeddings(
            ...     name="collection_embedded_multiple_tables",
            ...     data=["amazon_reviews_embedded", "amazon_reviews_embedded_10_alter"],
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     embedding_columns=embedding_column,
            ...     description="Embedding-based collection created from multiple tables"
            ... )
            >>> 
            >>> # Verify the collection was created
            >>> collection2.status()
        """
        index, kwargs = cls._build_embedding_index(data, name=name, create=True, **kwargs)
        
        # Set index and type for create
        kwargs['index'] = index
        kwargs['type'] = CollectionType.EMBEDDING_BASED

        instance = cls(name=name, auth_data=auth_data, **kwargs)
        instance.create(**kwargs)
        instance.exists
        return instance


    @classmethod
    def _process_documents_object(cls,
                                  name,
                                  documents = None,
                                  type = CollectionType.FILE_CONTENT_BASED,
                                  embedding = None,
                                  auth_data = None,
                                  return_collection = True,
                                  **kwargs):

        """
        DESCRIPTION:
            Internal method containing the core logic for creating file-based Collections
            from documents. This method processes documents and can be used by other 
            integration layers (e.g., langchain_teradata).
            
            Currently handles file-based configurations (LocalConfig, S3Config, etc.).
            
            Note:
                Document objects (e.g., from langchain) will be supported in future releases
                and will be handled through langchain integration.
        
        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the Collection to create.
                Types: str
                
            documents:
                Optional Argument.
                Specifies the document sources to process. Can be:
                - LocalConfig: For local files with file patterns
                - S3Config: For Amazon S3 storage
                - AzureBlobConfig: For Azure Blob storage
                - GCPConfig: For Google Cloud Storage
                Types: LocalConfig, S3Config, AzureBlobConfig, GCPConfig
                
            type:
                Optional Argument.
                Specifies the type of Collection to create.
                Types: CollectionType
                
            embedding:
                Optional Argument.
                Specifies the embedding model.
                Types: str, TeradataAI
                
            auth_data:
                Optional Argument.
                Specifies authentication data.
                Types: set_auth_token
                
            **kwargs:
                Additional parameters for Ingestor configuration.
        
        RETURNS:
            Collection object for the created file-based collection.
        
        RAISES:
            ValueError: If invalid parameters are provided.
            TeradataGenAIException: If the ingestion pipeline fails.
            TeradataMlException: If database operations fail.
        """
        # Import the Ingestor class locally to avoid circular imports
        from teradatagenai.vector_store.Ingestor import Ingestor
        from teradatagenai.vector_store.data_classes import BasicIngestor
        import warnings

        kwargs['embedding_model'] = embedding
        
        # Handle backward compatibility conversions
        documents, kwargs = cls._handle_documents_backward_compatibility(documents, **kwargs)
        
        # Validate required parameters
        # Validate file-based collection types
        file_based_types = [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]

        arg_info_matrix = [
            ["name", name, False, str, False],
            ["type", type, True, CollectionType, True, file_based_types],
            ["documents", documents, False, (LocalConfig, S3Config, AzureBlobConfig, GCPConfig), True]
            ]

        
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        try:
            # Initialize Ingestor with basic configuration
            ingestor_pipeline = Ingestor(
                name=name, 
                type=type, 
                target_database=kwargs.pop('target_database', None),
                description=kwargs.pop('description', None),
                auth_data=auth_data
            )
            
            # Configure extraction options if any extraction parameters are provided
            extraction_param_names = [
                'metadata_json', 'text', 'images', 'tables', 'infographics', 
                'method', 'captions', 'display_metadata'
            ]
            extraction_params = {k: kwargs.pop(k, None) for k in extraction_param_names if k in kwargs}
            if any(v is not None for v in extraction_params.values()):
                ingestor_pipeline.extract(**{k: v for k, v in extraction_params.items() if v is not None})
            
            # Configure file processing
            if documents is not None:
                file_param_names = ['ingestor', 'extraction_schema']
                file_params = {k: kwargs.pop(k, None) for k in file_param_names if k in kwargs}
                file_params['files'] = documents
                
                ingestor_pipeline.files(**{k: v for k, v in file_params.items() if v is not None})
            
            # Configure indexing and finalization
            indexing_param_names = ['indexing_algorithm', 'use_simd', 'search_params', 'ignore_embedding_errors', 'embedding']
            create_params = {k: kwargs.pop(k, None) for k in indexing_param_names if k in kwargs}
            
            # Add any remaining kwargs to create_params
            create_params.update(kwargs)
            
            # Always call create() to ensure indexing stage is configured, even with defaults
            # Filter out None values but ensure create() is always called
            filtered_create_params = {k: v for k, v in create_params.items() if v is not None}
            ingestor_pipeline.upsert(**filtered_create_params)
 
            # Execute the ingestion pipeline
            result = ingestor_pipeline.run()
            
            # Check if the pipeline execution was successful
            if not result.get("status", {}).get("success", False):
                errors = result.get("status", {}).get("errors", ["Unknown pipeline failure"])
                error_msg = f"Ingestor pipeline failed for collection '{name}': {'; '.join(errors)}"
                raise TeradataGenAIException(error_msg, TDMLMessageCodes.FUNC_EXECUTION_FAILED)
            
            # Create and return Collection object only if requested
            if return_collection:
                collection = cls(name=name, type=type, auth_data=auth_data)
                collection.exists = True  # Mark as existing since we just created it
                return collection
            
            # For add operations, don't return anything
            
        except Exception as e:
            # Re-raise with additional context
            if isinstance(e, (TeradataGenAIException, TeradataMlException)):
                raise
            else:
                raise TeradataGenAIException(
                    f"Failed to create Collection from documents: {str(e)}",
                    TDMLMessageCodes.FUNC_EXECUTION_FAILED
                ) from e

    @classmethod
    def _handle_documents_backward_compatibility(cls, documents, **kwargs):
        """
        Handle backward compatibility for legacy VectorStore.from_documents parameters.
        
        This method converts old parameter formats to the new Ingestor-based system for documents.
        """
        import warnings
        from teradatagenai.vector_store.data_classes import LocalConfig, BasicIngestor, NVIngestor, ExtractionSchema, ColumnInfo
        from teradatagenai.llm.llm import TeradataAI
        from teradatasqlalchemy.types import VARCHAR
        
        updated_kwargs = kwargs.copy()
        
        # Handle documents parameter conversion (str/list → LocalConfig)
        if documents is not None and isinstance(documents, (str, list)):
            # Convert legacy documents format to LocalConfig
            if isinstance(documents, list):
                # Multiple files specified as list
                files_pattern = documents[0] if len(documents) == 1 else documents
                warnings.warn(
                    "Passing documents as a list is deprecated. Use LocalConfig instead.",
                    DeprecationWarning, stacklevel=3
                )
            else:
                # Single file, directory, or pattern
                files_pattern = documents
                warnings.warn(
                    "Passing documents as a string is deprecated. Use LocalConfig instead.",
                    DeprecationWarning, stacklevel=3
                )
            
            # Create LocalConfig from legacy format
            documents = LocalConfig(
                files=files_pattern,
                files_type="pdf",
                overwrite_object=updated_kwargs.pop('overwrite_object', False)
            )
        
        # Handle extraction schema parameters (map to ExtractionSchema)
        extraction_schema_params = {}
        
        # Map object_names to table_name
        if 'object_names' in updated_kwargs:
            table_name = updated_kwargs.pop('object_names')
            if table_name:
                extraction_schema_params['table_name'] = table_name
                warnings.warn(
                    "Parameter 'object_names' is deprecated. Use ExtractionSchema(table_name=...) instead.",
                    DeprecationWarning, stacklevel=3
                )
        
        # Map data_columns to data_columns
        if 'data_columns' in updated_kwargs:
            data_columns = updated_kwargs.pop('data_columns')
            if data_columns:
                if isinstance(data_columns, str):
                    data_columns = [data_columns]
                # Convert to ColumnInfo objects
                data_column_infos = []
                for col in data_columns:
                    if isinstance(col, str):
                        data_column_infos.append(ColumnInfo(
                            name=col,
                            datatype=VARCHAR(64000),
                            description=f"Data column: {col}"
                        ))
                    else:
                        data_column_infos.append(col)
                extraction_schema_params['data_columns'] = data_column_infos
                warnings.warn(
                    "Parameter 'data_columns' is deprecated. Use ExtractionSchema(data_columns=...) instead.",
                    DeprecationWarning, stacklevel=3
                )
        
        # Map metadata_columns and metadata_descriptions to metadata_columns
        metadata_cols = updated_kwargs.pop('metadata_columns', None)
        metadata_descs = updated_kwargs.pop('metadata_descriptions', None)
        
        if metadata_cols:
            if isinstance(metadata_cols, str):
                metadata_cols = [metadata_cols]
            metadata_column_infos = []
            
            for i, col in enumerate(metadata_cols):
                if isinstance(col, str):
                    desc = "Metadata column"
                    if metadata_descs and i < len(metadata_descs):
                        desc = metadata_descs[i]
                    
                    metadata_column_infos.append(ColumnInfo(
                        name=col,
                        datatype=VARCHAR(4000),
                        description=desc
                    ))
                else:
                    metadata_column_infos.append(col)
            
            extraction_schema_params['metadata_columns'] = metadata_column_infos
            warnings.warn(
                "Parameters 'metadata_columns' and 'metadata_descriptions' are deprecated. Use ExtractionSchema(metadata_columns=...) instead.",
                DeprecationWarning, stacklevel=3
            )
        
        # Create ExtractionSchema if any related parameters were found
        if extraction_schema_params and 'extraction_schema' not in updated_kwargs:
            updated_kwargs['extraction_schema'] = ExtractionSchema(**extraction_schema_params)
        
        # Handle deprecated vector_column parameter
        if 'vector_column' in updated_kwargs:
            warnings.warn(
                "Parameter 'vector_column' is not supported in V2 Collections and will be ignored.",
                DeprecationWarning, stacklevel=3
            )
            updated_kwargs.pop('vector_column')
        
        # Handle deprecated optimized_chunking parameter
        if 'optimized_chunking' in updated_kwargs:
            warnings.warn(
                "Parameter 'optimized_chunking' is not supported in V2 Collections and will be ignored.",
                DeprecationWarning, stacklevel=3
            )
            updated_kwargs.pop('optimized_chunking')
        
        # Handle embedding model parameters - pass through directly
        if 'embeddings_dims' in updated_kwargs:
            warnings.warn(
                "Parameter 'embeddings_dims' is deprecated. Set embedding_dims in TeradataAI object instead.",
                DeprecationWarning, stacklevel=3
            )
        
        # Handle chat completion model parameters - pass through directly
        if 'chat_completion_model' in updated_kwargs:
            warnings.warn(
                "Parameter 'chat_completion_model' is deprecated. Use TeradataAI object as 'chat_model' instead.",
                DeprecationWarning, stacklevel=3
            )
        
        if 'chat_completion_max_tokens' in updated_kwargs:
            warnings.warn(
                "Parameter 'chat_completion_max_tokens' is deprecated. Set max_tokens in TeradataAI chat_model instead.",
                DeprecationWarning, stacklevel=3
            )
        
        # Handle model_urls - pass through directly
        if 'model_urls' in updated_kwargs:
            warnings.warn(
                "Parameter 'model_urls' is deprecated. Use TeradataAI object with appropriate model configuration instead.",
                DeprecationWarning, stacklevel=3
            )
        
        # Handle embedding_datatype - pass through directly
        if 'embedding_datatype' in updated_kwargs:
            warnings.warn(
                "Parameter 'embedding_datatype' should be passed directly to the create method.",
                DeprecationWarning, stacklevel=3
            )

        # Handle regular ingestor parameter mapping for chunking parameters (BasicIngestor)
        ingestor_params = {}
        chunk_param_mapping = {
            'chunk_size': 'chunk_size',
            'chunk_overlap': 'chunk_overlap', 
            'header_height': 'header_height',
            'footer_height': 'footer_height'
        }
        
        for old_param, new_param in chunk_param_mapping.items():
            if old_param in updated_kwargs:
                ingestor_params[new_param] = updated_kwargs.pop(old_param)
            
        
        # Handle NV ingestor parameter mapping
        if 'nv_ingestor' in updated_kwargs and updated_kwargs.get('nv_ingestor') is True:
            # Extract all NV-specific parameters
            nv_ingestor_params = {}
            
            # Remove nv_ingestor from kwargs as it's not a parameter for NVIngestor constructor
            updated_kwargs.pop('nv_ingestor')
            
            # Map NV-specific parameters
            nv_param_mapping = {
                'ingest_host': 'ingest_host',
                'ingest_port': 'ingest_port',
                'display_metadata': 'display_metadata',
                'extract_text': 'extract_text',
                'extract_images': 'extract_images', 
                'extract_tables': 'extract_tables',
                'extract_infographics': 'extract_infographics',
                'extract_method': 'extract_method',
                'extract_metadata_json': 'extract_metadata_json',
                'extract_caption': 'extract_caption',
                'tokenizer': 'tokenizer',
                # Also include chunking parameters for NVIngestor
                'chunk_size': 'chunk_size',
                'chunk_overlap': 'chunk_overlap', 
                'header_height': 'header_height',
                'footer_height': 'footer_height',
            }
            
            for old_param, new_param in nv_param_mapping.items():
                if old_param in updated_kwargs:
                    nv_ingestor_params[new_param] = updated_kwargs.pop(old_param)
            # Pop VLM parameters only if they exist
            vlm_model = updated_kwargs.pop('vlm_model', None)
            if vlm_model:
                nv_ingestor_params['vlm_model'] = {'model_id': vlm_model , 'base_url': updated_kwargs.pop('vlm_base_url', None)}

            
            # Create NVIngestor with NV-specific parameters if not already provided
            if 'ingestor' not in updated_kwargs:
                updated_kwargs['ingestor'] = NVIngestor(**ingestor_params,**nv_ingestor_params)
        else:
            # Create BasicIngestor with parameters if any chunking params were provided
            if ingestor_params and 'ingestor' not in updated_kwargs:
                updated_kwargs['ingestor'] = BasicIngestor(**ingestor_params)
        
        # Handle optimized_chunking and ingest_params (pass through to FILE_BASED_VECTOR_STORE_PARAMS)
        # These are already handled by the existing parameter system
        
        return documents, updated_kwargs

    @classmethod
    @collect_queryband(queryband="Collection_from_documents")
    @docstring_handler(
        common_params={
            **CREATE_COMMON_PARAMS,
            **AUTH_PARAMS,
            **FILE_DOCUMENTS_COMMON_PARAMS,
            **MODEL_PARAMS
        },
        exclude_params=['name', 'index', 'embedding_model', 'search_params']
    )
    def from_documents(cls,
                       name,
                       documents = None,
                       type = CollectionType.FILE_CONTENT_BASED,
                       embedding = None,
                       auth_data = None,
                       **kwargs):
        """
        Creates a file-based Collection from documents using the Ingestor pipeline.
        
        DESCRIPTION:
            This is a convenience method that creates a file-based Collection by using the 
            Ingestor class internally. It supports both FILE_CONTENT_BASED and 
            FILE_EMBEDDING_BASED collections through a declarative API.
            
            The method orchestrates the complete ingestion pipeline:
            1. Configure extraction options for file processing
            2. Set up file sources (local, S3, Azure Blob, GCP)
            3. Configure embedding generation
            4. Set up indexing algorithm and execute the pipeline
            5. Return a Collection object for the created collection.
        
        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the Collection to create.
                Types: str
                
            documents:
                Required Argument.
                Specifies the document sources to ingest. Can be:
                - LocalConfig: For local files with file patterns and common config
                - S3Config: For Amazon S3 storage with built-in common config
                - AzureBlobConfig: For Azure Blob storage with built-in common config  
                - GCPConfig: For Google Cloud Storage with built-in common config
                Each config includes file type, delimiter, and overwrite options.
                Note: Document objects from langchain will be supported in future releases.
                Types: LocalConfig, S3Config, AzureBlobConfig, GCPConfig
                
            type:
                Optional Argument.
                Specifies the type of Collection to create.
                Default Value: CollectionType.FILE_CONTENT_BASED
                Types: CollectionType
                Permitted Values: FILE_CONTENT_BASED, FILE_EMBEDDING_BASED
                
            embedding:
                Optional Argument.
                Specifies the embedding model to use for generating embeddings.
                Can be a model name string or TeradataAI object.
                Types: str, TeradataAI
            
        
        RETURNS:
            Collection object for the created file-based collection.
            
        RAISES:
            ValueError: If invalid parameters are provided.
            TeradataGenAIException: If the ingestion pipeline fails.
            TeradataMlException: If database operations fail.
            
        EXAMPLES:
            >>> # Import required classes
            >>> from teradatagenai import (Collection, TeradataAI, LocalConfig, S3Config, 
            ...                             BasicIngestor, NVIngestor, HNSW, FLAT)
            >>> from teradataml import set_auth_token

            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
            
            # Example 1: Basic local file ingestion with default settings
            >>> local_config = LocalConfig(
            ...     files="/path/to/documents/*.pdf",
            ...     type="pdf",
            ...     overwrite_files=False
            ... )
            >>> 
            >>> collection = Collection.from_documents(
            ...     name="local_docs_collection",
            ...     documents=local_config,
            ...     embedding="text-embedding-3-small",
            ...     target_database="my_database",
            ...     description="Local PDF documents collection"
            ... )
            
            # Example 2: S3 ingestion with NV processing and comprehensive extraction
            >>> s3_config = S3Config(
            ...     bucket="my-documents-bucket",
            ...     key="research_papers/*.pdf",
            ...     region_name="us-west-2",
            ...     type="pdf",
            ...     overwrite_files=True
            ... )
            >>> 
            >>> # Configure TeradataAI embedding model
            >>> embedding_model = TeradataAI(
            ...     model_name="amazon.titan-embed-text-v2:0",
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com"
            ... )
            >>> 
            >>> collection = Collection.from_documents(
            ...     name="research_papers_collection",
            ...     documents=s3_config,
            ...     embedding=embedding_model,
            ...     target_database="research_db",
            ...     description="Research papers with comprehensive content extraction",
            ...     ingestor=NVIngestor(),
            ...     # Indexing parameters
            ...     indexing_algorithm=HNSW(ef_construction=200, metric="COSINE"),
            ...     use_simd=True
            ... )
            
            # Example 3: Azure Blob Storage with custom extraction schema
            >>> from teradatagenai.vector_store.data_classes import AzureBlobConfig, ExtractionSchema
            >>> 
            >>> azure_config = AzureBlobConfig(
            ...     account_name="myaccount",
            ...     container_name="documents",
            ...     blob_name="contracts/*.docx",
            ...     type="docx",
            ...     overwrite_files=False
            ... )
            >>> 
            >>> extraction_schema = ExtractionSchema(
            ...     content_column="document_content",
            ...     metadata_column="document_metadata"
            ... )
            >>> 
            >>> collection = Collection.from_documents(
            ...     name="contracts_collection",
            ...     documents=azure_config,
            ...     embedding="text-embedding-ada-002",
            ...     target_database="legal_db",
            ...     description="Legal contracts with custom schema",
            ...     ingestor=UnstructuredIngestor(),
            ...     extraction_schema=extraction_schema,
            ...     ignore_embedding_errors=True,
            ...     # Indexing parameters  
            ...     indexing_algorithm=FLAT(),
            ...     use_simd=False
            ... )
            
            # Example 4: GCP Storage with advanced NVIDIA NIM processing
            >>> from teradatagenai.vector_store.data_classes import GCPConfig
            >>> 
            >>> gcp_config = GCPConfig(
            ...     bucket="my-gcp-bucket",
            ...     object_name="medical_docs/*.pdf",
            ...     project_id="my-project-123",
            ...     type="pdf",
            ...     overwrite_files=True
            ... )
            >>> 
            >>> # Configure NVIDIA NIM embedding model
            >>> nim_model = TeradataAI(
            ...     model_name="nvidia/llama-3.2-nv-embedqa-1b-v2",
            ...     api_base="https://your-nim-endpoint.com",
            ...     embeddings_dims=2048
            ... )
            >>> 
            >>> collection = Collection.from_documents(
            ...     name="medical_docs_collection",
            ...     documents=gcp_config,
            ...     embedding=nim_model,
            ...     target_database="medical_db",
            ...     description="Medical documents with NIM processing",
            ...     # Advanced extraction parameters
            ...     text=True,
            ...     images=True,
            ...     tables=True,
            ...     infographics=True,
            ...     captions=True,
            ...     display_metadata=True,
            ...     method="unstructured",
            ...     # Processing parameters
            ...     ingestor=NVIngestor(chunk_size=2048, chunk_overlap=200),
            ...     # Advanced indexing parameters
            ...     indexing_algorithm=HNSW(
            ...         ef_construction=400, 
            ...         metric="COSINE", 
            ...         max_connections=64
            ...     ),
            ...     use_simd=True
            ... )
            
            # Example 5: Using auth_data for authentication
            >>> 
            >>> local_config = LocalConfig(
            ...     files="/data/knowledge_base/*.txt",
            ...     type="txt",
            ...     overwrite_files=False
            ... )
            >>> 
            >>> collection = Collection.from_documents(
            ...     name="kb_collection",
            ...     documents=local_config,
            ...     embedding="text-embedding-3-small",
            ...     auth_data=auth_data,
            ...     target_database="knowledge_db",
            ...     description="Knowledge base text collection",
            ...     ingestor=BasicIngestor(chunk_size=1024),
            ...     indexing_algorithm=FLAT(),
            ...     use_simd=False
            ... )
        """
        try:
            return cls._process_documents_object(
                name=name,
                documents=documents,
                type=type, 
                embedding=embedding,
                auth_data=auth_data,
                **kwargs
            )
        except Exception as e:
                raise TeradataGenAIException(
                    f"from_documents() failed for collection '{name}': {str(e)}",
                    TDMLMessageCodes.FUNC_EXECUTION_FAILED
                ) from e
    
    @collect_queryband(queryband="Collection_add_documents")
    @docstring_handler(
        common_params={
            **CREATE_COMMON_PARAMS,
            **AUTH_PARAMS,
            **FILE_DOCUMENTS_COMMON_PARAMS,
            **MODEL_PARAMS,
            'update_style': UPDATE_PARAMS['update_style']
        },
        exclude_params=['index', 'embedding_model', 'search_params']
    )
    def add_documents(self,
                      documents = None,
                      type = None,
                      embedding = None,
                      **kwargs):
        """
        Adds documents to an existing Collection using the Ingestor pipeline.
        
        DESCRIPTION:
            This method adds new documents to an existing file-based Collection by using the 
            Ingestor class internally. It supports both FILE_CONTENT_BASED and 
            FILE_EMBEDDING_BASED collections through a declarative API.
            
            The method orchestrates the complete ingestion pipeline to add new content:
            1. Configure extraction options for file processing
            2. Set up file sources (local, S3, Azure Blob, GCP)
            3. Configure embedding generation
            4. Set up indexing algorithm and execute the pipeline to add content
            5. Update the existing Collection.
        
        PARAMETERS:
            documents:
                Optional Argument.
                Specifies the document sources to ingest and add to the collection. Can be:
                - LocalConfig: For local files with file patterns and common config
                - S3Config: For Amazon S3 storage with built-in common config
                - AzureBlobConfig: For Azure Blob storage with built-in common config  
                - GCPConfig: For Google Cloud Storage with built-in common config
                Each config includes file type, delimiter, and overwrite options.
                Note: Document objects from langchain will be supported in future releases.
                Types: LocalConfig, S3Config, AzureBlobConfig, GCPConfig
                
            type:
                Optional Argument.
                Specifies the type of Collection. If None, uses the existing collection type.
                Types: CollectionType
                Permitted Values: FILE_CONTENT_BASED, FILE_EMBEDDING_BASED
                
            embedding:
                Optional Argument.
                Specifies the embedding model to use for generating embeddings.
                Can be a model name string or TeradataAI object.
                Types: str, TeradataAI
        
        RETURNS:
            None. Updates the existing Collection in place.
            
        RAISES:
            ValueError: If invalid parameters are provided.
            TeradataGenAIException: If the ingestion pipeline fails.
            TeradataMlException: If database operations fail.
            
        EXAMPLES:
            >>> # Import required classes
            >>> from teradatagenai import (Collection, TeradataAI, LocalConfig, S3Config, 
            ...                             BasicIngestor, NVIngestor)
            >>> from teradataml import set_auth_token

            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
            
            # Example 1: Add local documents to existing collection
            >>> # Assume collection already exists
            >>> collection = Collection(name="existing_collection", auth_data=auth_data)
            >>> 
            >>> local_config = LocalConfig(
            ...     files="/path/to/new_documents/*.pdf",
            ...     type="pdf",
            ...     overwrite_files=False
            ... )
            >>> 
            >>> collection.add_documents(
            ...     documents=local_config,
            ...     embedding="text-embedding-3-small",
            ...     target_database="my_database"
            ... )
            
            # Example 2: Add S3 documents with NV processing
            >>> s3_config = S3Config(
            ...     bucket="my-new-documents-bucket", 
            ...     key="additional_papers/*.pdf",
            ...     region_name="us-west-2",
            ...     type="pdf",
            ...     overwrite_files=True
            ... )
            >>> 
            >>> embedding_model = TeradataAI(
            ...     model_name="amazon.titan-embed-text-v2:0", 
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com"
            ... )
            >>> 
            >>> collection.add_documents(
            ...     documents=s3_config,
            ...     embedding=embedding_model,
            ...     # Processing parameters
            ...     ingestor=NVIngestor(),
            ...     use_simd=True
            ... )
        """
        # Use existing collection type if not specified
        if type is None:
            type = self.type
        
        try:
            # Reuse _process_documents_object but don't return a Collection object
            return self.__class__._process_documents_object(
                name=kwargs.pop("name", self.name),
                documents=documents,
                type=type,
                embedding=embedding,
                auth_data=self._auth_data,
                return_collection=False,
                **kwargs
            )
        except Exception as e:
                raise TeradataGenAIException(
                    f"add_documents() failed for collection '{self.name}': {str(e)}",
                    TDMLMessageCodes.FUNC_EXECUTION_FAILED
                ) from e

    @collect_queryband(queryband="Collection_delete_documents")
    @docstring_handler(
        common_params={**UPDATE_PARAMS},
        include_params={'update_style'}
    )
    def delete_documents(self, documents, **kwargs):
        """
        Deletes documents from an existing Collection.
        
        DESCRIPTION:
            This method removes documents from an existing file-based Collection by 
            using the update method internally. It supports deletion of specific documents
            from FILE_CONTENT_BASED and FILE_EMBEDDING_BASED collections.
            
            The method maps the documents parameter to file_names and sets the 
            alter_operation to DELETE, then calls the update method to perform 
            the deletion operation.
            
        PARAMETERS:
            documents:
                Required Argument.
                Specifies the document file names to delete from the collection.
                Can be a single file name string or a list of file name strings.
                Types: str, list of str
        
        RETURNS:
            None. Updates the existing Collection by removing specified documents.
            
        RAISES:
            ValueError: If invalid parameters are provided.
            TeradataGenAIException: If the deletion operation fails.
            TeradataMlException: If database operations fail.
            
        EXAMPLES:
            >>> # Import required classes
            >>> from teradatagenai import Collection
            >>> from teradataml import set_auth_token

            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
            
            # Example 1: Delete a single document from existing collection
            >>> collection = Collection(name="existing_collection", auth_data=auth_data)
            >>> collection.delete_documents("document1.pdf")
            
            # Example 2: Delete multiple documents from collection
            >>> collection.delete_documents([
            ...     "document1.pdf",
            ...     "document2.pdf", 
            ...     "document3.pdf"
            ... ])
            
            # Example 3: Delete documents with additional parameters
            >>> collection.delete_documents(
            ...     documents=["old_document.pdf"],
            ...     update_style="MINOR"
            ... )
        """
        # Map documents parameter to file_names for update method
        kwargs['file_names'] = documents
        kwargs['alter_operation'] = "DELETE"
        
        # Call the update method to perform the deletion
        self.update(**kwargs)

    @collect_queryband(queryband="Collection_create")
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **MODEL_PARAMS}
    )
    def create(self, **kwargs):
        """
        DESCRIPTION:
            Creates a new Collection from the dataset provided.
            If collection exists, error is raised.
            Supports 'CONTENT-BASED' and 'EMBEDDING-BASED' collections.
            Notes:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.
                * Does not support METADATA-BASED collections.
                * Supports FILE-BASED only for backward compatibility, prefer
                  Ingestor class of creating FILE_BASED collection.
                * ModelUrlParams and IngestParams deprecated but supported
                  for backward compatibility.

        RETURNS:
            None.

        RAISES:
            TeradataGenAIException, TeradataMlException.

        EXAMPLES:
            # Import required classes
            >>> from teradatagenai import (Collection, TeradataAI, ContentBasedIndex, 
            ...                             EmbeddingBasedIndex, ColumnInfo, HNSW)

            >>> from teradatagenai import load_data
            >>> from teradataml import (DataFrame, in_schema, create_context, 
            ...                          set_auth_token, get_connection)
            >>> from teradatasqlalchemy.types import INTEGER, VARCHAR, VECTOR

            # Example 1: Collection creation using auth_data and string object_names
            # (before connection)
            >>> # First, authenticate using set_auth_token (no database connection yet)
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
            >>> 
            >>> # Load sample data using auth_data
            >>> load_data("byom", "amazon_reviews_25")
            >>> 
            >>> # Create collection using auth_data in initialization
            >>> collection = Collection(name="amazon_reviews_auth", auth_data=auth_data)
            >>> 
            >>> # Use string table names.
            >>> reviews_table = "amazon_reviews_25"
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     object_names=[reviews_table],  # String table name instead of 
            ...                                 # DataFrame
            ...     key_columns=["rev_id"],
            ...     data_columns=["rev_text"],  # Using string column names
            ...     embeddings_model="text-embedding-3-small",
            ...     target_database="your_database",
            ...     description=("Collection created with auth_data and string "
            ...              "object names"),
            ...     use_simd=True
            ... )

            # Setup: Load sample data and establish connection (for subsequent examples)
            >>> create_context(host="your-host", username="your-username", password="your-password")
            >>> load_data("byom", "amazon_reviews_25")  # Load content-based sample data
            >>> load_data("amazon", "amazon_reviews_embedded")  # Load embedding-based 
            ...                                                   # sample data

            # Example 2: Content-based collection with amazon reviews data and 
            # key_columns
            # and data_columns as ColumnExpression.
            >>> # Create DataFrame reference to sample data
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> 
            >>> # Define content-based index using the ColumnExpression.
            >>> index = ContentBasedIndex(
            ...     object_names=reviews_df,
            ...     key_columns=reviews_df.rev_id,
            ...     data_columns=reviews_df.rev_text
            ... )
            >>> 
            >>> # Configure embedding model
            >>> embedding_model = TeradataAI(
            ...     model_name="amazon.titan-embed-text-v2:0",
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com"
            ... )
            >>> 
            >>> # Create collection
            >>> collection = Collection(name="amazon_reviews_content")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     target_database="your_database",
            ...     description="Amazon reviews content-based collection",
            ...     use_simd=True
            ... )

            # Example 3: Content-based collection with metadata columns.
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> 
            >>> # Create ColumnInfo objects separately for better readability
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID",
            ...     sources=["your_database.amazon_reviews_25.rev_id"]
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text for embeddings",
            ...     sources=["your_database.amazon_reviews_25.rev_text"]
            ... )
            >>> 
            >>> # Create metadata ColumnInfo objects
            >>> prodsummary_column = ColumnInfo(
            ...     name="prodsummary",
            ...     datatype=VARCHAR(4000),
            ...     description="Product summary metadata",
            ...     sources=["your_database.amazon_reviews_25.prodsummary"]
            ... )
            >>> 
            >>> rev_name_column = ColumnInfo(
            ...     name="rev_name",
            ...     datatype=VARCHAR(500),
            ...     description="Review name metadata",
            ...     sources=["your_database.amazon_reviews_25.rev_name"]
            ... )
            >>> 
            >>> # Define content-based index with metadata columns using the 
            ... # ColumnInfo objects
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[rev_id_column],
            ...     data_columns=[rev_text_column],
            ...     metadata_columns=[prodsummary_column, rev_name_column]
            ... )
            >>> 
            >>> embedding_model = TeradataAI(model_name="text-embedding-3-small")
            >>> 
            >>> collection = Collection(name="amazon_reviews_with_metadata")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     target_database="your_database",
            ...     description="Amazon reviews collection with metadata",
            ...     use_simd=True
            ... )

            # Example 4: Embedding-based collection with pre-computed embeddings.
            >>> embedded_reviews_df = DataFrame(
            ...     in_schema("your_database", "amazon_reviews_embedded")
            ... )
            >>> 
            >>> # Create ColumnInfo objects separately for better readability
            >>> embedding_column = ColumnInfo(
            ...     name="embedding",
            ...     description="Pre-computed review embeddings",
            ...     sources=["your_database.amazon_reviews_embedded.embedding"]
            ... )
            >>> 
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID",
            ...     sources=["your_database.amazon_reviews_embedded.rev_id"]
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text",
            ...     sources=["your_database.amazon_reviews_embedded.rev_text"]
            ... )
            >>> 
            >>> # Define embedding-based index using the ColumnInfo objects
            >>> index = EmbeddingBasedIndex(
            ...     object_names=[embedded_reviews_df],
            ...     embedding_columns=[embedding_column],
            ...     key_columns=[rev_id_column],
            ...     data_columns=[rev_text_column],
            ...     is_normalized=True
            ... )
            >>> 
            >>> # Configure indexing algorithm.
            >>> indexing_algorithm = HNSW(ef_construction=200, metric="COSINE")
            >>> 
            >>> collection = Collection(name="amazon_reviews_embedded")
            >>> collection.create(
            ...     type=CollectionType.EMBEDDING_BASED,
            ...     index=index,
            ...     indexing_algorithm=indexing_algorithm,
            ...     target_database="your_database",
            ...     description="Amazon reviews embedding-based collection"
            ... )

            # Example 5: NVIDIA NIM embedding model with content-based collection.
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> 
            >>> # Create ColumnInfo objects separately for better readability
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID",
            ...     sources=["your_database.amazon_reviews_25.rev_id"]
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text for embeddings",
            ...     sources=["your_database.amazon_reviews_25.rev_text"]
            ... )
            >>> 
            >>> # Define content-based index using the ColumnInfo objects
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[rev_id_column],
            ...     data_columns=[rev_text_column]
            ... )
            >>> 
            >>> embedding_model = TeradataAI(
            ...     model_name="nvidia/llama-3.2-nv-embedqa-1b-v2",
            ...     api_base="https://your-nim-endpoint.com",
            ...     embeddings_dims=2048
            ... )
            >>> 
            >>> collection = Collection(name="amazon_reviews_nim")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     target_database="your_database",
            ...     description="Amazon reviews using NVIDIA NIM embeddings"
            ... )
        """
        self.name = kwargs.pop('name', self.name)
        # Handle type parameter - set default if not provided, convert enum to value if needed
        self.type = kwargs.pop('type', self.type)

        if self.exists:
            raise TeradataGenAIException(
                f"Collection with name '{self.name}' already exists. \n"
                f"Use a different name or delete the existing collection before creating a new one.",
                TDMLMessageCodes.FUNC_EXECUTION_FAILED
            )
        
        if self.type is None:
            self.type = CollectionType.CONTENT_BASED

        arg_info_matrix = [["name", self.name, False, (str), True],
                        ["type", self.type, False, (CollectionType), True]]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)

        # Validate all kwargs using generic validation function
        param_dicts = [CREATE_COMMON_PARAMS, MODEL_PARAMS]
        validate_docstring_kwargs(kwargs, param_dicts)
        
        if self.type in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]:
            self._process_documents_object(name=self.name,
                                           type=self.type,
                                           return_collection=False,
                                           documents=kwargs.pop('document_files', None),
                                           auth_data=self._auth_data,
                                           embedding=kwargs.pop('embeddings_model', None),
                                           **kwargs)
        else:
            # Validate object_names parameter presence
            index = kwargs.get('index', None)
            if index is not None:
                arg_info_matrix = [["index.object_names", index.object_names, False, (list, str, DataFrame), True]]
                _Validators._validate_missing_required_arguments(arg_info_matrix)
            # Handle deprecated parameters with warnings
            kwargs = self._handle_deprecated_params(**kwargs)

            # Convert enum to value for API schema mapping
            if hasattr(self.type, 'value'):
                kwargs['type'] = self.type.value

            # Build request payload.
            json_payload = build_request("create", kwargs)

            return_type = self._prepare_for_request(return_type="json")
            # Make the request to create collection.
            self._make_request(
                http_method=HTTPRequest.POST, endpoint="collection",
                response_key=None, return_type=return_type,
                collection_name=self.name, 
                json=json_payload
            )
            self.exists
        
    def _handle_deprecated_params(self, **kwargs):
        """
        Extract ModelUrlParams and IngestParams for backward compatibility.
        Issue deprecation warnings and unpack parameters.
        
        Returns:
            dict: Updated kwargs with deprecated parameters unpacked
        """
        if "model_urls" in kwargs:
            warnings.warn(
                "ModelUrlParams is deprecated for Collection and will be removed "
                "in a future release. "
                "Use TeradataAI class (preferred) or individual parameters instead.",
                DeprecationWarning,
                stacklevel=3
            )
            model_urls = kwargs.pop("model_urls")
            if model_urls is not None:
                # Extract all attributes from ModelUrlParams
                for key, value in vars(model_urls).items():
                    if value is not None and key not in kwargs:
                        kwargs[key] = value

        if "ingest_params" in kwargs:
            warnings.warn(
                "IngestParams is deprecated for Collection and will be removed "
                "in a future release. "
                "Use individual parameters instead.",
                DeprecationWarning,
                stacklevel=3
            )
            ingest_params = kwargs.pop("ingest_params")
            if ingest_params is not None:
                # Extract all attributes from IngestParams
                for key, value in vars(ingest_params).items():
                    if value is not None and key not in kwargs:
                        kwargs[key] = value

        return kwargs

    @collect_queryband(queryband="Collection_update")
    @docstring_handler(
        common_params={**UPDATE_PARAMS, **CREATE_COMMON_PARAMS, **MODEL_PARAMS},
        exclude_params=['name' , 'type' , 'target_database']
    )
    def update(self, **kwargs):
        """
        DESCRIPTION:
            Updates an existing collection with the specified parameters.
            Notes:
                * Addition of new data and deletion of existing data
                  stored in table/view(s) is possible using
                  "alter_operation" and "update_style".
                * File-based collections should be created through the Ingestor class;
                  this method only supports deletion of existing files.
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.

        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, TeradataAI, ContentBasedIndex, ColumnInfo, HNSW, IVF_FLAT, SearchParams
            >>> from teradatagenai.common.constants import CollectionType
            >>> from teradatasqlalchemy.types import VARCHAR
            >>> import os
            
            # Setup authentication
            >>> base_url = "<base_url>"
            >>> auth_data = set_auth_token(
            ...     base_url=base_url,
            ...     username='oaf',
            ...     password='oaf', 
            ...     auth_mech='Basic'
            ... )
            
            # Set up AWS credentials
            >>> os.environ['AWS_ACCESS_KEY_ID'] = 'your_access_key'
            >>> os.environ['AWS_SECRET_ACCESS_KEY'] = 'your_secret_key'
            >>> os.environ['AWS_DEFAULT_REGION'] = 'us-west-2'
            
            # Configure the AWS Bedrock embedding model
            >>> embeddings_model_aws = TeradataAI(
            ...     api_type="aws",
            ...     model_name="amazon.titan-embed-text-v2:0"
            ... )
            
            # Define columns for initial collection
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key",
            ...     sources=["amazon_reviews_25.rev_id"]
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text for embeddings",
            ...     sources=["amazon_reviews_25.rev_text"]
            ... )
            >>> 
            >>> prodsummary_column = ColumnInfo(
            ...     name="prodsummary",
            ...     datatype=VARCHAR(4000),
            ...     description="Product summary metadata",
            ...     sources=["amazon_reviews_25.prodsummary"]
            ... )
            >>> 
            >>> rev_name_column = ColumnInfo(
            ...     name="rev_name",
            ...     datatype=VARCHAR(500),
            ...     description="Review name metadata",
            ...     sources=["amazon_reviews_25.rev_name"]
            ... )
            
            # Create the content-based index
            >>> index = ContentBasedIndex(
            ...     object_names="amazon_reviews_25",
            ...     key_columns=[rev_id_column],
            ...     data_columns=[rev_text_column],
            ...     metadata_columns=[prodsummary_column, rev_name_column]
            ... )
            
            # Create the collection
            >>> collection = Collection(name="test_update_collection_final")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embeddings_model_aws,
            ...     description="Test collection for update operations",
            ...     use_simd=True
            ... )
            >>> 
            >>> # Check initial status
            >>> collection.status()
            
            # Example 1: Update search parameters
            >>> # Create new search parameters
            >>> new_search_params = SearchParams(
            ...     top_k=7,
            ...     search_type="hybrid_search"
            ... )
            >>> 
            >>> # Update the collection with new search parameters
            >>> collection.update(search_params=new_search_params)
            >>> 
            >>> # Verify the update
            >>> collection.status()
            
            # Example 2: Add additional data to the collection
            >>> index_to_add = ContentBasedIndex(object_names="amazon_reviews_10")
            >>> 
            >>> collection.update(
            ...     index=index_to_add,
            ...     update_style="MINOR",
            ...     alter_operation="ADD"
            ... )
            >>> 
            >>> # Check status after adding data
            >>> collection.status()
            
            # Example 3: Add additional metadata columns
            >>> helpful_column = ColumnInfo(
            ...     name="helpful",
            ...     datatype=VARCHAR(100),
            ...     description="Helpfulness votes for review",
            ...     sources=["amazon_reviews_25.helpful"]
            ... )
            >>> 
            >>> # Update index with new metadata columns
            >>> updated_index = ContentBasedIndex(
            ...     metadata_columns=[helpful_column]
            ... )
            >>> 
            >>> # Add metadata columns
            >>> collection.update(
            ...     index=updated_index,
            ...     metadata_operation="ADD"
            ... )
            >>> 
            >>> collection.status()
            
            # Example 4: Modify metadata column (datatype and description)
            >>> # Modify prodsummary column description and datatype
            >>> modified_prodsummary_column = ColumnInfo(
            ...     name="prodsummary",
            ...     datatype=VARCHAR(5000),
            ...     description="Product summary metadata - UPDATED with extended length",
            ...     sources=["amazon_reviews_25.prodsummary"]
            ... )
            >>> 
            >>> # Create index with modified metadata
            >>> modified_index = ContentBasedIndex(
            ...     metadata_columns=[modified_prodsummary_column]
            ... )
            >>> 
            >>> # Update with MODIFY operation
            >>> collection.update(
            ...     index=modified_index,
            ...     metadata_operation="MODIFY"
            ... )
            >>> 
            >>> # Verify the modification
            >>> collection.status()
            
            # Example 5: Delete data from the collection
            >>> delete_index = ContentBasedIndex(object_names="amazon_reviews_10")
            >>> 
            >>> collection.update(
            ...     index=delete_index,
            ...     alter_operation="DELETE"   
            ... )
            >>> 
            >>> # Check status after deleting data
            >>> collection.status()
            
            # Example 6: Update indexing algorithm to IVF_FLAT
            >>> # Create IVF_FLAT indexing algorithm configuration
            >>> ivf_flat_config = IVF_FLAT(
            ...     metric="COSINE",
            ...     train_numcluster=5
            ... )
            >>> 
            >>> # Update collection with IVF_FLAT algorithm
            >>> collection.update(
            ...     indexing_algorithm=ivf_flat_config
            ... )
            >>> 
            >>> collection.status()

            # Example 7: Add additional data using DataFrame with ColumnExpression
            >>> from teradataml import DataFrame, in_schema
            >>> 
            >>> # Create DataFrame reference to additional data
            >>> additional_reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_10"))
            >>> 
            >>> # Create index using DataFrame - no need to specify columns if they match
            >>> index_with_dataframe = ContentBasedIndex(object_names=additional_reviews_df)
            >>> 
            >>> # Update collection with DataFrame
            >>> collection.update(
            ...     index=index_with_dataframe,
            ...     update_style="MINOR",
            ...     alter_operation="ADD"
            ... )
            >>> 
            >>> # Check status after adding DataFrame data
            >>> collection.status()
        """
        if kwargs.get("standalone", True) and self.exists and \
            self.type in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]\
            and kwargs.get("alter_operation", None) == "ADD":
            self._process_documents_object(name=self.name,
                                           type=self.type,
                                           return_collection=False,
                                           documents=kwargs.pop('document_files', None),
                                           auth_data=self._auth_data,
                                           embedding=kwargs.pop('embeddings_model', None),
                                           **kwargs)
        else:
            validate_docstring_kwargs(kwargs, [CREATE_COMMON_PARAMS, UPDATE_PARAMS, MODEL_PARAMS])

            # Handle deprecated parameters with warnings
            kwargs = self._handle_deprecated_params(**kwargs)
            json_payload = build_request("update", kwargs)

            return_type = self._prepare_for_request(return_type="json")
            # Handle new_vs_name
            original_name = self.name
            try:

                self._make_request(
                    http_method=HTTPRequest.PATCH, endpoint="collection",
                    response_key=None,
                    return_type=return_type,
                    collection_name=self.name,
                    json=json_payload
                )


                # If updating name, update self.name
                new_vs_name = kwargs.get('new_collection_name') or kwargs.get('new_vs_name')
                if new_vs_name is not None:
                    self.name = new_vs_name

            except Exception as e:
                self.name = original_name
                raise

    
    @collect_queryband(queryband="Collection_add_datasets")
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **COLUMN_PARAMS, **MODEL_PARAMS},
        exclude_params=['name', 'type', 'data_columns', 'embedding_model', 'search_params']
    )
    def add_datasets(self, data, **kwargs):
        """
        DESCRIPTION:
            Adds tables/DataFrames to an existing content-based vector collection.
            Creates a new Vector Collection in case it does not exist.
            Notes:
                * For CONTENT-BASED collections only.
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.

        PARAMETERS:
            data:
                Required Argument.
                Specifies the table name(s)/teradataml DataFrame(s) containing
                content to be embedded and added to the vector collection.
                Teradata recommends to use teradataml DataFrame as input.
                Notes:
                    * When "target_database" is not set, and only table name is passed to
                      "data", then the input is searched in default database.
                Types: str, DataFrame, list of str, list of DataFrame

            embedding:
                Optional Argument.
                Specifies the TeradataAI model for generating embeddings.
                Required if collection does not exist (will create new collection).
                Types: TeradataAI

            data_columns:
                Optional Argument.
                Specifies the column(s) containing the text data to be embedded.
                Note:
                    When multiple "data_columns" are specified, data is unpivoted
                    to get a new key column "AttributeName" and a single data column
                    "AttributeValue".
                Types: ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression

            update_style:
                Optional Argument.
                Specifies the update style to use when adding texts to the collection.
                Note: Only applicable when collection already exists.
                Types: str, values can be "MINOR" or "MAJOR"

            name:
                Optional Argument.Required only if collection does not exist.
                Specifies the name of the vector store to be created from
                input texts.
                Note: Used only if the collection does not exist.
                Types: str

                

        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Import required modules
            >>> import os
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, ColumnInfo, TeradataAI, load_data
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Setup authentication and connection
            >>> create_context(host="your-host", 
            ...                username="your-username",
            ...                password="your-password")
            >>> auth_data = set_auth_token(base_url="https://your-platform.teradata.com",
            ...                            username="your-username", 
            ...                            password="your-password")
            
            # Load sample data
            >>> load_data("byom", "amazon_reviews_25")
            >>> load_data("byom", "amazon_reviews_10")
            
            # Example 1: Create collection, then add more data
            >>> # Define the embedding model
                # Set AWS credentials in environment
            >>> os.environ['AWS_ACCESS_KEY_ID'] = 'your_access_key'
            >>> os.environ['AWS_SECRET_ACCESS_KEY'] = 'your_secret_key'
            >>> os.environ['AWS_DEFAULT_REGION'] = 'us-west-2'
            
            # Configure the AWS Bedrock embedding model
            >>> embeddings_model_aws = TeradataAI(
            ...     api_type="aws",
            ...     model_name="amazon.titan-embed-text-v2:0"
            ... )
            >>> 
            >>> # Define columns
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key"
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content"
            ... )
            >>> 
            >>> # Create collection from first table
            >>> collection = Collection.from_datasets(
            ...     name="amazon_content_collection",
            ...     data="amazon_reviews_25",
            ...     embedding=embeddings_model_aws,
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     description="Content-based collection"
            ... )
            >>> 
            >>> # Add more data to existing collection
            >>> collection.add_datasets(
            ...     data="amazon_reviews_10"
            ... )
            >>> 
            >>> # Check status after adding data
            >>> collection.status()
            
            # Example 2: Create collection directly from add_datasets (when collection doesn't exist)
            >>> from teradataml import DataFrame, in_schema
            >>> 
            >>> # Create DataFrame reference to sample data
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> 
            >>> # Define the embedding model
            >>> embeddings_model_aws = TeradataAI(
            ...     api_type="aws",
            ...     model_name="amazon.titan-embed-text-v2:0"
            ... )
            >>> 
            >>> # Define columns
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key"
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content"
            ... )
            >>> 
            >>> # Initialize collection (doesn't exist yet)
            >>> collection_new = Collection(name="amazon_new_collection")
            >>> 
            >>> # add_datasets will create the collection since it doesn't exist
            >>> collection_new.add_datasets(
            ...     data=reviews_df,
            ...     embedding=embeddings_model_aws,
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     description="Collection created via add_datasets"
            ... )
            >>> 
            >>> # Check status
            >>> collection_new.status()
        """
        # Check if vector store exists, if not create it using from_texts
        name = kwargs.pop('name', self.name)
        embedding = kwargs.pop('embedding', kwargs.get('embedding_model', None))

        # Check if collection exists
        if not self.exists:
            print("Collection does not exist. Creating new content-based collection.")
            new_instance = self.from_datasets(name=self.name,
                                              data=data,
                                              embedding=embedding,
                                              **kwargs)
            self.__dict__.update(new_instance.__dict__)
            return
        
        # Build index using common method (validates data and all column parameters)
        # Returns tuple of (index, modified_kwargs) with column params removed
        index, kwargs = self._build_dataset_index(data, embedding=embedding, create=False, **kwargs)
        
        # Set index and alter_operation for update call
        kwargs['alter_operation'] = "ADD"
        kwargs['index'] = index

        kwargs["embedding_model"] = embedding
        
        # Call update with the parameters
        self.update(**kwargs)

    @collect_queryband(queryband="Collection_delete_datasets")
    @docstring_handler(
        common_params={**UPDATE_PARAMS},
        exclude_params=['description', 'target_database', 'is_normalized', 'metadata_operation']
    )
    def delete_datasets(self, data, **kwargs):
        """
        DESCRIPTION:
            Removes tables/DataFrames from an existing content-based vector collection.
            Notes:
                * For CONTENT-BASED collections only.
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.

        PARAMETERS:
            data:
                Required Argument.
                Specifies the name of the tables or teradataml DataFrames containing the content data
                to be deleted from the Vector Collection.
                Types: str, DataFrame, list of str, list of DataFrame

            database_name:
                Optional Argument.
                Specifies the database name where the input table(s) or DataFrame(s) are located.
                Note: If not specified, all input data with the table name of "data" is deleted
                      from the Vector Collection irrespective of the database in which it is located.
                Types: str

        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, ColumnInfo, TeradataAI, load_data
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Setup authentication and connection
            >>> create_context(host="your-host", username="your-username",
            ...                password="your-password")
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username", 
            ...     password="your-password"
            ... )
            
            # Load sample data
            >>> load_data("byom", "amazon_reviews_25")
            >>> load_data("byom", "amazon_reviews_10")
            
            # Example 1: Create collection with multiple tables, then delete one
            >>> # Define the embedding model
            >>> embedding_model = TeradataAI(api_type = "td_hosted",
                                            model_name="text-embedding-ada-002")
            >>> 
            >>> # Define columns
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key"
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content"
            ... )
            >>> 
            >>> # Create collection from multiple tables
            >>> collection = Collection.from_datasets(
            ...     name="amazon_content_multiple",
            ...     data=["amazon_reviews_25", "amazon_reviews_10"],
            ...     embedding=embedding_model,
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     description="Collection with multiple tables for deletion example"
            ... )
            >>> 
            >>> # Delete one of the tables from the collection
            >>> collection.delete_datasets(
            ...     data="amazon_reviews_10"
            ... )
            >>> 
            >>> # Check status after deletion
            >>> collection.status()
        """
        # Process data with database_name if provided
        data, kwargs = self._handle_delete_operations(data, **kwargs)

        # Create ContentBasedIndex with only object_names for deletion
        index = ContentBasedIndex(
            object_names=data
        )

        # Set alter_operation for update call
        kwargs['alter_operation'] = "DELETE"
        kwargs['index'] = index
        self.update(**kwargs)

    @collect_queryband(queryband="Collection_from_embeddings")
    @docstring_handler(
        common_params={**EMBEDDING_COMMON_PARAMS, **COLUMN_PARAMS},
    )
    def add_embeddings(self, data, **kwargs):
        """
        DESCRIPTION:
            Adds data to an existing embedding-based vector collection.
            Creates a new Vector Collection in case it does not exist.
        
        PARAMETERS:
            data:
                Required Argument.
                Specifies the table name(s)/teradataml DataFrame(s) that are pre embedded to be
                indexed or to be added to the vector collection.
                Teradata recommends to use teradataml DataFrame as input.
                Notes:
                    * If multiple tables/views are passed, each table should
                      have the columns which are mentioned in "embedding_columns"
                      and "key_columns".
                    * When "target_database" is not set, and only table name is passed to
                      "data", then the input is searched in default database.
                Types: str, DataFrame, or list of str/DataFrame

            name:
                Optional Argument.
                Specifies the name of the vector store to be created from
                input data.
                Types: str

            embedding_columns:
                Optional Argument.
                Specifies the name of the column that contains the
                pre embedded data.
                Note:
                    When multiple data columns are specified, data is unpivoted
                    to get a new key column "AttributeName" and a single data column
                    "AttributeValue".
                Types: str, list of str
            
        RETURNS:
            None

        RAISES:
            TeradataMlException
        
        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, ColumnInfo
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Setup authentication
            >>> base_url = "https://aiop-btms4.td.teradata.com"
            >>> auth_data = set_auth_token(
            ...     base_url=base_url,
            ...     username='oaf',
            ...     password='oaf',
            ...     auth_mech='Basic'
            ... )
            
            # First, create a collection using from_embeddings
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key",
            ...     sources=["amazon_reviews_embedded.rev_id"]
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content",
            ...     sources=["amazon_reviews_embedded.rev_text"]
            ... )
            >>> 
            >>> embedding_column = ColumnInfo(
            ...     name="embedding",
            ...     description="Pre-computed embedding vectors",
            ...     sources=["amazon_reviews_embedded.embedding"]
            ... )
            >>> 
            >>> collection = Collection.from_embeddings(
            ...     name="collection_embedded_single_table",
            ...     data="amazon_reviews_embedded",
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     embedding_columns=embedding_column,
            ...     description="Embedding-based collection created from pre-computed embeddings"
            ... )
            
            # Example 1: Add embeddings without specifying columns (uses existing schema)
            >>> # When the source table has the same schema as the collection
            >>> collection.add_embeddings(
            ...     data="amazon_reviews_embedded_10_alter",
            ...     update_style="MINOR"
            ... )
            >>> 
            >>> # Check status after adding embeddings
            >>> collection.status()
            >>> 
            >>> # Verify the updated details
            >>> collection.get_details()
            
            # Example 2: Add embeddings with explicit column mapping
            >>> # Create a new collection first
            >>> collection2 = Collection.from_embeddings(
            ...     name="collection_embedded_single_table2",
            ...     data="amazon_reviews_embedded",
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     embedding_columns=embedding_column,
            ...     description="Embedding-based collection for explicit column mapping example"
            ... )
            >>> 
            >>> # Define embedding column for the new data
            >>> embedding_column_to_add = ColumnInfo(
            ...     name="embedding",
            ...     description="Additional pre-computed embedding vectors",
            ...     sources=["amazon_reviews_embedded_10_alter.embedding"]
            ... )
            >>> 
            >>> # Add embeddings with explicit column specification
            >>> collection2.add_embeddings(
            ...     data="amazon_reviews_embedded_10_alter",
            ...     embedding_columns=[embedding_column_to_add],
            ...     update_style="MINOR"
            ... )
            >>> 
            >>> # Check status after the addition
            >>> collection2.status()
        
        """

        # Check if collection exists, if not create it using from_embeddings
        if not self.exists:
            print("Collection does not exist. Creating new embedding-based collection.")
            new_instance = self.from_embeddings(
                name=self.name, 
                data=data,
                **kwargs
            )
            self.__dict__.update(new_instance.__dict__)
            return
        
        # Build index using common method (validates data and all column parameters)
        # Returns tuple of (index, modified_kwargs) with column params removed
        index, kwargs = self._build_embedding_index(data, create=False, **kwargs)
        
        # Set index and alter_operation for update call
        kwargs['index'] = index
        kwargs['alter_operation'] = "ADD"
        
        # Call update with the parameters
        self.update(**kwargs)

    @collect_queryband(queryband="VS_delete_embeddings")
    @docstring_handler(
        common_params = {**EMBEDDING_COMMON_PARAMS},
        exclude_params=["description", "target_database", "is_normalized", "metadata_operation"]
    )
    def delete_embeddings(self, data, **kwargs):
        """
        DESCRIPTION:
            Deletes data from an existing embedding-based vector collection.
        
        PARAMETERS:
            data:
                Required Argument.
                Specifies the name of the tables or teradataml DataFrames containing the embedding data
                to be deleted from the Vector Collection.
                Types: str, DataFrame, or list of str/DataFrame

            database_name:
                Optional Argument.
                Specifies the database name where the input table(s) or DataFrame(s) are located.
                Note: If not specified, all input data with the table name of "data" is deleted 
                      from the Vector Collection irrespective of the database in which it is located.
                Types: str
        
        RETURNS:
            None
        
        RAISES:
            TeradataMlException
        
        EXAMPLES:
            # Import required modules
            >>> from teradataml import set_auth_token
            >>> from teradatagenai import Collection, ColumnInfo
            >>> from teradatasqlalchemy.types import VARCHAR
            
            # Set up authentication
            >>> base_url = "https://aiop-btms4.td.teradata.com"
            >>> auth_data = set_auth_token(
            ...     base_url=base_url,
            ...     username='oaf',
            ...     password='oaf',
            ...     auth_mech='Basic'
            ... )
            
            # Example 1: Create collection with two tables, then delete one table directly
            >>> # Define columns
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     description="Review ID - Primary Key"
            ... )
            >>> 
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     description="Review text content"
            ... )
            >>> 
            >>> embedding_column = ColumnInfo(
            ...     name="embedding",
            ...     description="Pre-computed embedding vectors"
            ... )
            >>> 
            >>> # Create collection from multiple tables
            >>> collection = Collection.from_embeddings(
            ...     name="amazon_embedded_multiple_tables",
            ...     data=["amazon_reviews_embedded", "amazon_reviews_embedded_10_alter"],
            ...     key_columns=rev_id_column,
            ...     data_columns=rev_text_column,
            ...     embedding_columns=embedding_column,
            ...     description="Collection with multiple tables for deletion example"
            ... )
            >>> 
            >>> # Delete one of the tables from the collection
            >>> collection.delete_embeddings(
            ...     data="amazon_reviews_embedded_10_alter"
            ... )
            >>> 
            >>> # Check status after deletion
            >>> collection.status()
        """
        data , kwargs = self._handle_delete_operations(data, **kwargs)

        index = EmbeddingBasedIndex(
            object_names=data
        )

        # Set alter_operation for update call
        kwargs['alter_operation'] = "DELETE"
        kwargs['index'] = index
        self.update(**kwargs)

    @collect_queryband(queryband="Collection_add_texts")
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **COLUMN_PARAMS, **MODEL_PARAMS},
        exclude_params=['name', 'type', 'data_columns', 'embedding_model', 'search_params']
    )
    def add_texts(self, texts, **kwargs):
        """
        DESCRIPTION:
            Adds text/list of texts to an existing Vector Collection.
            Creates a new Vector Collection in case it does not exist.
        
        PARAMETERS:
            texts:
                Required Argument.
                Specifies the text data to add to the collection.
                Can be a single string or a list of strings.
                Types: str, list of str
            
            embedding:
                Optional Argument.
                Specifies the embedding model to use for generating
                embeddings from the text data.
                Types: TeradataAI

            update_style:
                Optional Argument.
                Specifies the update style to use when adding texts to the collection.
                Note: Only applicable when collection already exists.
                Types: str, values can be "MINOR" or "MAJOR"

            name:
                Optional Argument.Required only if collection does not exist.
                Specifies the name of the vector store to be created from
                input texts.
                Note: Used only if the collection does not exist.
                Types: str
        RETURNS:
            None.
        
        RAISES:
            TeradataMlException.
        
        EXAMPLES:
            # Import required classes
            >>> from teradatagenai import Collection, TeradataAI
            >>> import os
            
            >>> texts = [
            ...     "This is a sample text.",
            ...     "This is another example of text data."
            ... ]
            
            # Configure the embedding model
            >>> embeddings_model_aws = TeradataAI(
            ...     api_type="aws",
            ...     model_name="amazon.titan-embed-text-v2:0"
            ... )
            
            # Create or get existing collection
            >>> text_coll = Collection.from_texts(
            ...     name="text_collection_example",
            ...     texts=texts,
            ...     embedding=embeddings_model_aws
            ... )
            
            # Add more texts to the existing collection
            >>> texts_to_add = ["sample_text3", "sample_text4"]
            >>> text_coll.add_texts(
            ...     texts=texts_to_add,
            ... )
            
            # Check updated collection status
            >>> text_coll.status(return_type="json")
        """
        # Check if vector store exists, if not create it using from_texts
        name = kwargs.pop('name', self.name)
        embedding = kwargs.pop('embedding', kwargs.get('embedding_model', None))

        if not self.exists:
            print("Collection does not exist. Creating new content-based collection from texts.")
            new_instance = self.from_texts(name=name, texts=texts, embedding=embedding, **kwargs)
            self.__dict__.update(new_instance.__dict__)
            return
        
        # Build index from texts
        index = self._build_text_index(texts, name=name, embedding=embedding, create=False, **kwargs)
        
        kwargs["alter_operation"] = "ADD"
        kwargs["index"] = index
        kwargs["embedding_model"] = embedding

        # Call the update method with appropriate parameters
        self.update(**kwargs)

    @staticmethod
    def _build_text_index(texts, name=None, embedding=None, create=False, **kwargs):
        """
        Internal method to build a ContentBasedIndex from text data.
        Common logic shared between from_texts and add_texts.
        
        Parameters:
            texts: Text data as str or list of str
            name: Collection name (required only if create=True)
            embedding: TeradataAI model for embeddings (required if create=True)
            create: Whether this is for collection creation (validates name and embedding)
            **kwargs: Additional parameters passed through
        
        Returns:
            ContentBasedIndex object
        """
        # Build validation matrix
        arg_info_matrix = [
            ["texts", texts, False, (str, list), True],
            ["embedding", embedding, not(create), (TeradataAI), True]
        ]
        
        # Add name validation if this is for create operation
        if create:
            arg_info_matrix.insert(0, ["name", name, False, str, True])
        
        # Validate all parameters
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        # Process texts into DataFrame
        texts = UtilFuncs._as_list(texts)
        processed_texts = DataFrame.from_dict(data={"text": texts}, persist=True)
        
        # Build the index
        index = ContentBasedIndex(
            object_names=processed_texts,
            data_columns=ColumnInfo(name="text")
        )

        # Return the index
        return index

    @collect_queryband(queryband="Collection_get_indexes_embeddings")
    def get_indexes_embeddings(self):
        """
        DESCRIPTION:
            Get the output table containing the indexing and embedding information.

        PARAMETERS:
            None.

        RETURNS:
            teradataml DataFrame pointing to the collection view.

        RAISES:
            TeradataMlException: If database connection is not available.

        EXAMPLES:
            >>> from teradatagenai import Collection
            >>> collection = Collection(name="<your_collection_name>")
            >>> collection.get_indexes_embeddings()
        """
        if not get_context():
            raise TeradataMlException(
                Messages.get_message(
                    MessageCodes.FUNC_EXECUTION_FAILED,
                    "get_indexes_embeddings",
                    'Connect to Vantage'
                ),
                MessageCodes.FUNC_EXECUTION_FAILED
            )
        
        return DataFrame(in_schema(self._database, f"collectionV_{self.name}"))

    @collect_queryband(queryband="Collection_get_model_info")
    def get_model_info(self):
        """
        DESCRIPTION:
            Get the output table(s) depending on the search algorithm.
                * hnsw_model: Output table which contains centroids information.
                  Note:
                    Applicable only if search_algorithm is "HNSW".

                * centroids_table: Output table which contains centroids information.
                  Note:
                    Applicable only if search_algorithm is "IVF_FLAT".

                * kmeans_model: Output table which contains kmeans model information.
                  Note:
                    Applicable only if search_algorithm is "IVF_FLAT".
                
                * bm25_model: Output table which contains BM25 model statistics.
                  Note:
                    Applicable with any search_algorithm only if search_type is "HYBRID_SEARCH".

        PARAMETERS:
            None.

        RETURNS:
            dict: Dictionary containing available model artifacts.

        RAISES:
            TeradataMlException: If database connection is not available.

        EXAMPLES:
            >>> from teradatagenai import Collection
            >>> collection = Collection(name="my_collection")
            >>> collection.get_model_info()
        """
        if not get_context():
            raise TeradataMlException(
                Messages.get_message(
                    MessageCodes.FUNC_EXECUTION_FAILED,
                    "get_model_info",
                    'Connect to Vantage'
                ),
                MessageCodes.FUNC_EXECUTION_FAILED
            )
        
        # Get collection details to determine which model artifacts exist
        details = self.get_details(elaborate=True, return_type="json")
        
        model_info = {}
        
        # Extract search algorithm and search type from nested structures
        train_params = details.get('train_params', {})
        search_algorithm = train_params.get('search_algorithm', '').upper() if train_params else ''
        
        search_strategy = details.get('search_strategy', {})
        search_type = search_strategy.get('search_type', '').upper() if search_strategy else ''
        
        # FLAT algorithm doesn't create any model tables, so return empty dict
        if search_algorithm == 'FLAT':
            return model_info
        
        # HNSW model (only for HNSW search algorithm)
        if search_algorithm == 'HNSW':
            model_info['hnsw_model'] = DataFrame(
                in_schema(self._database, f"collection_{self.name}_hnsw_model")
                )
        
        # Centroids table (for KMEANS/IVF_FLAT algorithms)
        if search_algorithm in ['KMEANS', 'IVF_FLAT']:
            model_info['centroids_table'] = DataFrame(
                in_schema(self._database, f"collection_{self.name}_centroids"))

            model_info['kmeans_model'] = DataFrame(
                in_schema(self._database, f"collection_{self.name}_kmeans_model"))
        
        # BM25 model (for hybrid search type, applicable to all indexing algorithms)
        if 'HYBRID' in search_type:
            model_info['bm25_model'] = DataFrame(
                in_schema(self._database, f"collection_{self.name}_bm25_model"))
        
        return model_info

    @collect_queryband(queryband="Collection_get_details")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS}    
    )
    def get_details(self, elaborate=False, return_type=None):
        """
        DESCRIPTION:
            Get details of the collection.
            Notes:
                * When "elaborate" is set to True and return_type is "teradataml", the method 
                  attempts to create UDTs to return detailed information. This may fail on 
                  systems with UDT creation disabled. In such cases, consider using return_type='json'
                  or 'pandas' for detailed information without relying on UDTs.

        PARAMETERS:
            elaborate:
                Optional Argument.
                Specifies whether to return full configuration details of the collection.
                Permitted Values: True, False
                Default Value: False
                Types: bool

        RETURNS:
            teradataml DataFrame (default), pandas DataFrame, or JSON containing 
            the details.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Initialize a Collection instance (do not call create).
            >>> from teradatagenai import Collection
            >>> collection = Collection(name="customer_360")

            # Example: Get details of a collection.
            >>> collection.get_details()
        """
        arg_info_matrix = []
        arg_info_matrix.append(["elaborate", elaborate, True, bool, True])
        _Validators._validate_function_arguments(arg_info_matrix)

        return_type = self._prepare_for_request(return_type)

        if elaborate and return_type == "teradataml":
            warnings.warn(
            "elaborate=True with return_type='teradataml' may fail on systems "
            "with UDT creation disabled. Consider using return_type='json' or 'pandas'."
            )

        return self._make_request(HTTPRequest.GET,
            "collection",
            "get_details",
            return_type,
            collection_name=self.name,
            get_details=elaborate
        )

    @collect_queryband(queryband="Collection_destroy")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS}
    )
    def destroy(self):
        """
        DESCRIPTION:
            Destroys the collection and underlying artifacts.
            Notes:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the User guide for details.

        RETURNS:
            None.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradatagenai import Collection

            # Initialize a Collection instance.
            >>> collection = Collection(name="customer_360")

            # Destroy the Collection.
            >>> collection.destroy()
        """
        # Handles str return type internally wherein it just returns the response.
        # Not introducing new return types here.

        return_type = self._prepare_for_request(return_type="json")  # <-- Add this line

        self._make_request(
            HTTPRequest.DELETE,
            "collection",
            None,
            return_type="json",
            collection_name=self.name
        )

        # TODO: Add logic to handle post-destroy cleanup for nv-ingest 
        # embedding-based tables.
        # https://teradata-pe.atlassian.net/browse/ELE-9619

    def _perform_search_operation(self, endpoint_type="similarity_search", **kwargs):
        """
        DESCRIPTION:
            Internal helper method to perform similarity search or ask operations.
            Used by similarity_search, similarity_search_by_vector, and ask methods.

        PARAMETERS:
            endpoint_type:
                Optional Argument.
                Specifies the type of endpoint to use for the operation.
                Permitted Values: "similarity_search", "ask"
                Default Value: "similarity_search"
                Types: str
            **kwargs:
                Optional Arguments.
                Additional parameters for the search operation, such as page, page_size, search_params, embeddings_model, chat_model, guardrails_model, ranking_model, filter, filter_style, return_type, etc.

        RETURNS:
            The response from the search or ask operation, in the format specified by return_type.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Internal method, typically not called directly by users.
            # Used by similarity_search and similarity_search_by_vector methods.
        """
        # Validate all kwargs using generic validation function
        param_dicts = [PAGE_PARAMS, RETURN_TYPE_PARAMS, MODEL_PARAMS, FILTER_PARAMS, SEARCH_PARAMS]
        validate_docstring_kwargs(kwargs, param_dicts)
        
        # Extract parameters from kwargs
        page = kwargs.pop('page', None)
        page_size = kwargs.pop('page_size', None)
        search_params = kwargs.get('search_params')
        embedding_model = kwargs.get('embedding_model')
        chat_model = kwargs.get('chat_model')
        guardrails_model = kwargs.get('guardrails_model')
        ranking_model = kwargs.get('ranking_model')
        filter = kwargs.get('filter')
        filter_style = kwargs.pop('filter_style', "PRE-FILTERING")
        return_type = kwargs.pop('return_type', None)
        
        # Validate argument types
        arg_info_matrix = []
        arg_info_matrix.append(["page", page, True, int, True])
        arg_info_matrix.append(["page_size", page_size, True, int, True])
        arg_info_matrix.append(["search_params", search_params, True, SearchParams, True])
        arg_info_matrix.append(["embedding_model", embedding_model, True, (TeradataAI, str), True])
        arg_info_matrix.append(["chat_model", chat_model, True, (TeradataAI, str), True])
        arg_info_matrix.append(["guardrails_model", guardrails_model, True, (TeradataAI, str), True])
        arg_info_matrix.append(["ranking_model", ranking_model, True, (TeradataAI, str), True])
        arg_info_matrix.append(["filter", filter, True, str, True])
        arg_info_matrix.append(
            ["filter_style", filter_style, True, str, True, 
             ["PRE-FILTERING", "POST-FILTERING"]]
        )
        
        _Validators._validate_function_arguments(arg_info_matrix)

        # Prepare request
        return_type = self._prepare_for_request(return_type)
        
        # Process filter parameter if provided - reuse VectorStore logic
        if filter is not None:
            processed_filter = process_filter(filter)
            if processed_filter is not None:
                filter_params = {}
                filter_params["condition"] = processed_filter
                filter_params['style'] = filter_style
                kwargs['filter'] = filter_params
                
        # Build request payload using appropriate schema
        json_payload = build_request(endpoint_type, kwargs)

        # Make the request to the appropriate endpoint
        response = self._make_request(
            http_method=HTTPRequest.POST, 
            endpoint=endpoint_type,
            response_key=None, 
            return_type=return_type,
            collection_name=self.name,
            json=json_payload,
            page=page, page_size=page_size
        )
        return response

    @collect_queryband(queryband="Collection_similarity_search")
    @docstring_handler(
        common_params={**PAGE_PARAMS, **RETURN_TYPE_PARAMS, **MODEL_PARAMS, **FILTER_PARAMS, **SEARCH_PARAMS},
        exclude_params=['authorized', 'chat_model']
    )
    def similarity_search(self, 
                          question,
                          **kwargs):
        """
        DESCRIPTION:
            Performs similarity search for input question and returns the "top_k"
            similar items.
        
        PARAMETERS:
            question:
                Required Argument.
                Specifies a string for which similarity search needs to be performed.
                Types: str

        RETURNS:
            _SimilaritySearch object containing search results in specified return_type format.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Complete setup and collection creation for similarity search
            >>> from teradatagenai import (
            ...     Collection, TeradataAI, ContentBasedIndex, ColumnInfo, 
            ...     CollectionType, SearchParams
            ... )
            >>> from teradatagenai import load_data
            >>> from teradataml import DataFrame, in_schema, create_context, set_auth_token
            >>> from teradatasqlalchemy.types import VARCHAR

            # Step 1: Setup authentication and connection.
            #  Change the authentication method to match your environment.
            >>> create_context(host="your-host", username="your-username",
            ...                password="your-password")
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username", 
            ...     password="your-password"
            ... )

            # Step 2: Load sample data
            >>> load_data("byom", "amazon_reviews_25")

            # Step 3: Create Collection with content-based data.
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[ColumnInfo(name="rev_id", datatype=VARCHAR(50))],
            ...     data_columns=[ColumnInfo(name="rev_text", datatype=VARCHAR(64000))]
            ... )
            >>> embedding_model = TeradataAI(model_name="text-embedding-3-small")
            >>> collection = Collection(name="review_search_demo")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     target_database="your_database"
            ... )

            # Example 1: Basic similarity search.
            >>> question = "What are customer satisfaction trends?"
            >>> results = collection.similarity_search(question=question)
            >>> print(f"Found {results.similar_objects_count} similar results")

            # Example 2: Search with top_k and different return types.
            >>> results_json = collection.similarity_search(
            ...     question=question,
            ...     search_params=SearchParams(top_k=10),
            ...     return_type="json"
            ... )
            >>> results_pandas = collection.similarity_search(
            ...     question=question,
            ...     search_params=SearchParams(top_k=5),
            ...     return_type="pandas"
            ... )

            # Example 3: Search with filtering.
            >>> filtered_results = collection.similarity_search(
            ...     question="product quality reviews",
            ...     filter="LENGTH(rev_text) > 100",
            ...     filter_style="PRE-FILTERING",
            ... )

            # Example 4: Search with custom embedding model and SearchParams.
            >>> custom_embeddings_model = TeradataAI(
            ...     model_name="amazon.titan-embed-text-v2:0",
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com"
            ... )
            >>> search_params = SearchParams(top_k=10)
            >>> custom_results = collection.similarity_search(
            ...     question=question,
            ...     embedding_model=custom_embeddings_model,
            ...     search_params=search_params
            ... )
        """
        # Validate required question parameter
        arg_info_matrix = [["question", question, False, str, True]]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)

        # Add question to kwargs and ensure question_vector is None
        kwargs['question'] = question
        kwargs['question_vector'] = None
        
        return self._perform_search_operation(endpoint_type="similarity_search", **kwargs)

    @collect_queryband(queryband="Collection_similarity_search_by_vector")
    @docstring_handler(
        common_params={**PAGE_PARAMS, **RETURN_TYPE_PARAMS, **MODEL_PARAMS, **FILTER_PARAMS, **SEARCH_PARAMS},
        exclude_params=['authorized', 'chat_model']
    )
    def similarity_search_by_vector(self,
                                    question,
                                    **kwargs):
        """
        DESCRIPTION:
            Performs similarity search for input question vector.
            Supports pagination, SearchParams objects, and advanced filtering.

        PARAMETERS:
            question:
                Required Argument.
                Specifies the embedded data (vector as string) for which 
                similarity search needs to be performed.
                Types: str

        RETURNS:
            _SimilaritySearch object containing search results in specified return_type format.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Complete setup for embedding-based similarity search
            >>> from teradatagenai import (
            ...     Collection, TeradataAI, EmbeddingBasedIndex, ColumnInfo, HNSW, 
            ...     CollectionType
            ... )
            >>> from teradatagenai import load_data
            >>> from teradataml import DataFrame, in_schema, create_context, set_auth_token
            >>> from teradatasqlalchemy.types import VARCHAR

            # Step 1: Setup authentication and connection.
            #  Change the authentication method to match your environment.
            >>> create_context(host="your-host", username="your-username", password="your-password")
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
        
            # Step 2: Load sample embedding data
            >>> load_data("amazon", "amazon_reviews_embedded")

            # Step 3: Create embedding-based Collection
            >>> embedded_df = DataFrame(in_schema("your_database", "amazon_reviews_embedded"))
            >>> index = EmbeddingBasedIndex(
            ...     object_names=[embedded_df],
            ...     embedding_columns=[ColumnInfo(name="embedding")],
            ...     key_columns=[ColumnInfo(name="rev_id", datatype=VARCHAR(50))],
            ...     data_columns=[ColumnInfo(name="rev_text", datatype=VARCHAR(64000))],
            ...     is_normalized=True
            ... )
            >>> indexing_algorithm = HNSW(ef_construction=200, metric="COSINE")
            >>> collection = Collection(name="embedded_search_demo")
            >>> collection.create(
            ...     type=CollectionType.EMBEDDING_BASED,
            ...     index=index,
            ...     indexing_algorithm=indexing_algorithm,
            ...     target_database="your_database"
            ... )

            # Example 1: Basic similarity search by vector.
            >>> # Pre-computed embedding vector (1536 dimensions for text-embedding-3-small)
            >>> question_vector = '-0.06944,0.080352,0.045963,0.006985,-0.000496,-0.025461,...'

            >>> results = collection.similarity_search_by_vector(question=question_vector)
            >>> print(f"Found {results.similar_objects_count} similar results")

            # Example 2: Search with different top_k and return types.
            >>> search_params = SearchParams(top_k=10)
            >>> vector_results_json = collection.similarity_search_by_vector(
            ...     question=question_vector,
            ...     search_params=search_params,
            ...     return_type="json"
            ... )
            >>> vector_results_pandas = collection.similarity_search_by_vector(
            ...     question=question_vector,
            ...     search_params=search_params,
            ...     return_type="pandas"
            ... )

            # Example 3: Search with filtering
            >>> filtered_vector_results = collection.similarity_search_by_vector(
            ...     question=question_vector,
            ...     filter="LENGTH(rev_text) > 100",
            ...     filter_style="PRE-FILTERING",
            ...     search_params=search_params
            ... )

        """
        # Validate required question parameter
        arg_info_matrix = [["question", question, False, str, True]]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)

        # Add question to kwargs and ensure question_vector is None
        kwargs['question_vector'] = question
        kwargs['question'] = None
        
        return self._perform_search_operation(endpoint_type="similarity_search", **kwargs)

    @collect_queryband(queryband="Collection_prepare_response")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS, **MODEL_PARAMS}
    )
    def prepare_response(self,
                         similarity_results,
                         question=None,
                         **kwargs):
        """
        DESCRIPTION:
            Provide a natural language response to the user using the input
            question and 'similarity_results' provided by
            similarity_search() method.
            The response is generated by a language model configured
            in the environment using a pre-configured prompt in the 'chat_model'.

        PARAMETERS:
            similarity_results:
                Required Argument.
                Specifies the similarity results obtained by similarity_search().
                Types: _SimilaritySearch

            question:
                Required Argument.
                Specifies a string of text for which response
                needs to be performed.
                Types: str

        RETURNS:
            Response object containing the generated natural language answer.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Complete setup for prepare_response with collection creation
            >>> from teradatagenai import (
            ...     Collection, TeradataAI, ContentBasedIndex, ColumnInfo, 
            ...     SearchParams, CollectionType
            ... )
            >>> from teradatagenai import load_data
            >>> from teradataml import DataFrame, in_schema, create_context, set_auth_token
            >>> from teradatasqlalchemy.types import VARCHAR

            # Step 1: Setup authentication and connection.
            #  Change the authentication method to match your environment.
            >>> create_context(host="your-host", username="your-username", password="your-password")
            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )

            # Step 2: Load sample data and create collection
            >>> load_data("byom", "amazon_reviews_25")
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[ColumnInfo(name="rev_id", datatype=VARCHAR(50))],
            ...     data_columns=[ColumnInfo(name="rev_text", datatype=VARCHAR(64000))]
            ... )
            >>> embedding_model = TeradataAI(model_name="text-embedding-3-small")
            >>> collection = Collection(name="response_demo")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     target_database="your_database"
            ... )

            search_params = SearchParams(top_k=10)

            # Step 3: Perform similarity search first.
            >>> question = "What are customer satisfaction trends?"
            >>> search_results = collection.similarity_search(
            ...     question=question,
            ...     search_params=search_params
            ... )

            # Example 1: Basic prepare response using similarity search results.
            >>> response = collection.prepare_response(
            ...     similarity_results=search_results,
            ...     question=question
            ... )
            >>> print(response)  # Generated response text

            # Example 2: Prepare response with custom chat model.
            >>> chat_model = TeradataAI(
            ...     model_name="gpt-4",
            ...     api_base="https://api.openai.com",
            ...     temperature=0.7,
            ...     max_tokens=500
            ... )
            >>> custom_response = collection.prepare_response(
            ...     similarity_results=search_results,
            ...     question=question,
            ...     chat_model=chat_model
            ... )

            # Example 3: Prepare response with guardrails model.
            >>> guardrails_model = TeradataAI(
            ...     model_name="content-safety-model",
            ...     api_base="https://safety-api.example.com"
            ... )
            >>> safe_response = collection.prepare_response(
            ...     similarity_results=search_results,
            ...     question=question,
            ...     guardrails_model=guardrails_model
            ... )
        """
        # Extract parameters from kwargs
        chat_model = kwargs.get('chat_model')
        guardrails_model = kwargs.get('guardrails_model')
        
        # Validate argument types
        arg_info_matrix = []
        arg_info_matrix.append(["similarity_results", similarity_results, False, _SimilaritySearch, True])
        arg_info_matrix.append(["question", question, False, str, True])
        arg_info_matrix.append(["chat_model", chat_model, True, (TeradataAI, str), True])
        arg_info_matrix.append(["guardrails_model", guardrails_model, True, (TeradataAI, str), True])
        
        _Validators._validate_function_arguments(arg_info_matrix)

        # Add similarity results to kwargs as similar_objects for API schema
        kwargs['similar_objects'] = similarity_results._json_obj if hasattr(similarity_results, '_json_obj') else similarity_results
        kwargs['question'] = question
        
        # Build request payload using schema
        json_payload = build_request("prepare_response", kwargs)

        # Make the request to prepare_response endpoint
        # Handles str return type internally wherein it just returns the response.
        # Not introducing new return types here.
        response = self._make_request(
            http_method=HTTPRequest.POST, 
            endpoint="prepare_response",
            response_key=None, 
            return_type="json", 
            collection_name=self.name,
            json=json_payload
        )
        return response

    @collect_queryband(queryband="Collection_ask")
    @docstring_handler(
        common_params={**PAGE_PARAMS, **RETURN_TYPE_PARAMS, **MODEL_PARAMS, **FILTER_PARAMS, **SEARCH_PARAMS},
        exclude_params=['authorized']
    )
    def ask(self, 
            question,
            **kwargs):
        """
        DESCRIPTION:
            Performs similarity search + response generation in single call.
            Combines similarity_search() and prepare_response() for lower
            latency and simpler interface.

        PARAMETERS:
            question:
                Optional Argument.
                Specifies the question which needs to be answered.
                Types: str

        RETURNS:
            Response object containing response in natural language format.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            # Complete setup for ask method (similarity search + response generation)
            >>> from teradatagenai import Collection, TeradataAI, ContentBasedIndex, ColumnInfo

            >>> from teradatagenai import load_data
            >>> from teradataml import DataFrame, in_schema, create_context, set_auth_token
            >>> from teradatasqlalchemy.types import VARCHAR

            # Step 1: Setup authentication and connection.
            #  Change the authentication method to match your environment.
            >>> create_context(host="your-host", username="your-username", password="your-password")

            >>> auth_data = set_auth_token(
            ...     base_url="https://your-platform.teradata.com",
            ...     username="your-username",
            ...     password="your-password"
            ... )
            
            # Step 2: Load sample data and create collection.
            >>> load_data("byom", "amazon_reviews_25")
            >>> reviews_df = DataFrame(in_schema("your_database", "amazon_reviews_25"))
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[ColumnInfo(name="rev_id", datatype=VARCHAR(50))],
            ...     data_columns=[ColumnInfo(name="rev_text", datatype=VARCHAR(64000))]
            ... )
            >>> embedding_model = TeradataAI(model_name="text-embedding-3-small")
            >>> chat_model = TeradataAI(
            ...     model_name="gpt-4",
            ...     api_base="https://api.openai.com",
            ...     temperature=0.7
            ... )
            >>> collection = Collection(name="ask_demo")
            >>> collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=embedding_model,
            ...     chat_model=chat_model,
            ...     target_database="your_database"
            ... )

            # Example 1: Basic ask - combines search and response generation.
            >>> question = "What are the main customer satisfaction trends?"
            >>> response = collection.ask(question=question)
            >>> print(response)  # Generated answer based on similar documents
            >>> print(f"Based on {len(response.similar_objects)} relevant documents")

            # Example 2: Ask with custom parameters.
            >>> detailed_response = collection.ask(
            ...     question="How do customers rate product quality?",
            ...     search_params=SearchParams(top_k=15)
            ... )
            >>> print(detailed_response['answer'])
            >>> print(f"Search found {len(detailed_response['similar_objects'])} results")

            # Example 3: Ask with filtering.
            >>> filtered_response = collection.ask(
            ...     question="What are common complaints in reviews?",
            ...     filter="LENGTH(rev_text) > 200",
            ...     filter_style="PRE-FILTERING",
            ...     search_params=SearchParams(top_k=15),
            ... )

            # Example 4: Ask with custom embedding and chat models.
            >>> custom_embeddings = TeradataAI(
            ...     model_name="amazon.titan-embed-text-v2:0",
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com"
            ... )
            >>> custom_chat = TeradataAI(
            ...     model_name="anthropic.claude-3-sonnet-20240229-v1:0",
            ...     api_base="https://bedrock-runtime.us-west-2.amazonaws.com",
            ...     temperature=0.5,
            ...     max_tokens=1000
            ... )
            >>> custom_response = collection.ask(
            ...     question=question,
            ...     embedding_model=custom_embedding,
            ...     chat_model=custom_chat
            ... )
        """
        # Validate question parameter if provided
        if question is not None:
            arg_info_matrix = [["question", question, False, str, True]]
            _Validators._validate_missing_required_arguments(arg_info_matrix)
            _Validators._validate_function_arguments(arg_info_matrix)

        # Add question to kwargs
        kwargs['question'] = question
        kwargs['return_type'] = "json"
        
        return self._perform_search_operation(endpoint_type="ask", **kwargs)

    @collect_queryband(queryband="Collection_status")
    @docstring_handler(
        common_params={**RETURN_TYPE_PARAMS}
    )
    def status(self, return_type=None):
        """
        DESCRIPTION:
            Checks the status of the following operations:
               * create
               * destroy
               * update

        RETURNS:
            Pandas DataFrame containing the status of vector store operations.

        RAISES:
            None.

        EXAMPLES:
            # Initialize a Collection instance.
            >>> from teradatagenai import Collection
            >>> collection = Collection(name="customer_360")

            # Example: Check the status of the collection operations.
            >>> collection.status()
        """
        return_type = self._prepare_for_request(return_type)
        return self._make_request(
            HTTPRequest.GET, "collection_status", None, return_type, collection_name=self.name)

    def list_user_permissions(self, page=1, page_size=20, return_type=None):
        """
        DESCRIPTION:
            Lists the user and their corresponding permissions for the collection.
            Note:
                * Only admin users can use this method.
                * Refer to the 'Admin Flow' section in the
                  User guide for details.

        RETURNS:
            JSON, pandas DataFrame or teradataml DataFrame containing
            the users and their corresponding permissions.

        RAISES:
            TeradataMlException.

        EXAMPLES:
            >>> from teradatagenai import Collection
            >>> cm = Collection(name="test_collection")

            # Example 1: List user permissions with return type as JSON.
            >>> cm.list_user_permissions(return_type="json")

            # Example 2: List 50 user permissions from page 2.
            >>> cm.list_user_permissions(page=2, page_size=50)
        """
        arg_info_matrix = []
        arg_info_matrix.append(["page", page, True, int, True])
        arg_info_matrix.append(["page_size", page_size, True, int, True])
        _Validators._validate_function_arguments(arg_info_matrix)

        return_type = self._prepare_for_request(return_type)
        return self._make_request(
            HTTPRequest.GET, "permissions", None, return_type,
            collection_name = self.name, page=page, page_size=page_size
        )

    @collect_queryband(queryband="Collection_delete_by_ids")
    def delete_by_ids(self, ids: list, filename: str = None, **kwargs):
        """
        DESCRIPTION:
            Deletes specific rows from the collection based on TD_IDs.

        PARAMETERS:
            ids:
                Required Argument.
                Specifies the list of TD_IDs to be deleted from the collection.
                Types: list of int or str

            filename:
                Optional Argument.
                Specifies the name of the file from which chunks are to be deleted.
                Types: str
                Notes:
                    * Applicable only for file-based collections.

        RETURNS:
            None
        
        RAISES:
            TeradataMlException: If database connection is not available or arguments are invalid.
        
        EXAMPLES:
            # Example 1: Delete rows from content-based collection
            >>> from teradataml import DataFrame, in_schema
            >>> from teradatagenai import Collection, TeradataAI, ContentBasedIndex, ColumnInfo, CollectionType
            >>> from teradatasqlalchemy.types import VARCHAR
            >>> 
            >>> # Configure embedding model
            >>> nim_embedding_model = TeradataAI(
            ...     api_type="nim",
            ...     model_name="<your_model_name>",
            ...     api_base="<your_model_url>"
            ... )
            >>> 
            >>> # Create content-based collection
            >>> reviews_df = DataFrame(in_schema("oaf", "amazon_reviews_25"))
            >>> rev_id_column = ColumnInfo(
            ...     name="rev_id",
            ...     datatype=VARCHAR(50),
            ...     sources=["amazon_reviews_25.rev_id"]
            ... )
            >>> rev_text_column = ColumnInfo(
            ...     name="rev_text",
            ...     datatype=VARCHAR(64000),
            ...     sources=["amazon_reviews_25.rev_text"]
            ... )
            >>> index = ContentBasedIndex(
            ...     object_names=[reviews_df],
            ...     key_columns=[rev_id_column],
            ...     data_columns=[rev_text_column]
            ... )
            >>> content_collection = Collection(name="test_content_delete_by_ids")
            >>> content_collection.create(
            ...     type=CollectionType.CONTENT_BASED,
            ...     index=index,
            ...     embedding_model=nim_embedding_model,
            ...     description="Content-based collection for testing delete_by_ids"
            ... )

            >>> # Delete specific rows by their TD_IDs
            >>> content_collection.delete_by_ids(ids=[1, 2, 3])
        """
        # Validate that database connection exists
        if not get_context():
            raise TeradataMlException(
                Messages.get_message(
                    MessageCodes.FUNC_EXECUTION_FAILED,
                    "delete_by_ids",
                    'Connect to Vantage'
                ),
                MessageCodes.FUNC_EXECUTION_FAILED
            )
        
        # Validate arguments
        arg_info_matrix = [
            ["ids", ids, False, (list), True],
            ["filename", filename, True, (str), True]
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        # Validate that filename is only provided for file-based collections
        if filename is not None:
            # TODO: Change type check to CollectionType once implemented
            if self.type == CollectionType.CONTENT_BASED or self.type == CollectionType.EMBEDDING_BASED:
                raise ValueError("filename argument is only valid for file-based collections.")
            else:
                df = DataFrame({
                    "TD_FILENAME": [filename] * len(ids),
                    "TD_ID": ids
                })

        else:
            # Content/Embedding-based collection: Filter get_indexes_embeddings()
            # Get all indexes and embeddings
            indexes_df = self.get_indexes_embeddings()
            
            # Filter to only rows with the specified IDs
            df = indexes_df[indexes_df["TD_ID"].isin(ids)]
            
            # Verify that we found the IDs
            if df.shape[0] == 0:
                raise TeradataMlException(
                    f"No rows found with the specified IDs: {ids}",
                    MessageCodes.FUNC_EXECUTION_FAILED
                )

        # Pass the DataFrame to update for deletion
        kwargs["object_names"] = df
        kwargs["alter_operation"] = "DELETE"
        self.update(**kwargs)
