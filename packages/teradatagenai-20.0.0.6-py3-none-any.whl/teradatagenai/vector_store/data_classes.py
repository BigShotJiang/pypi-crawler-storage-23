"""
Type String Format Documentation for collection_docstring_params.py:

When defining parameter types in collection_docstring_params.py, use the following format conventions:

1. BASIC TYPES:
   - Use: "int", "str", "bool", "float"
   - Example: {"types": "int"}

2. CLASS TYPES:
   - Use the exact class name as imported in collection.py
   - Example: {"types": "SearchParams"}, {"types": "TeradataAI"}
   - Available classes: SearchParams, TeradataAI, ContentBasedIndex, EmbeddingBasedIndex, 
     ColumnInfo, HNSW, FLAT, IVF_FLAT

3. LIST TYPES:
   - Use: "list of <type>"
   - Example: {"types": "list of str"}, {"types": "list of SearchParams"}
   - This will be resolved to (list, <resolved_type>)

4. COMPOUND TYPES (Union):
   - Use comma-separated types: "<type1>, <type2>"
   - Example: {"types": "TeradataAI, str"}, {"types": "list of str, SearchParams"}
   - This will be resolved to (<resolved_type1>, <resolved_type2>)

5. COMPLEX COMBINATIONS:
   - Example: {"types": "list of ContentBasedIndex, EmbeddingBasedIndex"}
   - Resolves to ((list, ContentBasedIndex), EmbeddingBasedIndex)

NOTE: The type resolution system will:
- First try to resolve as built-in types (int, str, bool, etc.)
- Then try to resolve as imported classes in globals()
- Fall back to 'object' for unknown types
- Handle nested "list of" patterns correctly
"""

from pydantic.dataclasses import dataclass
from pydantic import ConfigDict
from dataclasses import asdict, is_dataclass
from typing import List, Dict, Tuple, Any, Optional, Union
import os
import glob, json

from teradataml.dataframe.sql_interfaces import ColumnExpression
from teradatasqlalchemy.types import _TDType, INTEGER, VARCHAR, VECTOR
from teradataml.common.messagecodes import MessageCodes
from teradataml.common.messages import Messages
from teradataml.common.exceptions import TeradataMlException
from teradataml import DataFrame
from teradatagenai.utils.doc_decorator import docstring_handler
from teradatagenai.common.collection_docstring_params import COLUMN_PARAMS, INGESTOR_COMMON_PARAMS, EXTRACTION_COMMON_PARAMS
from teradataml.common.utils import UtilFuncs
from teradataml.utils.validators import _Validators
from teradatagenai.garbage_collector.garbage_collector import GarbageCollector
from teradatasqlalchemy.types import _TDType, INTEGER, VARCHAR, VECTOR
from teradatasqlalchemy.dialect import dialect as td_dialect
from teradatagenai.vector_store.vector_store import _ProcessDataFrameObjects


@dataclass
class ColumnInfo:
    """
    DESCRIPTION:
        Represents column metadata and configuration for Collections.
        Defines column specifications including names, data types, descriptions, 
        and source mappings for database columns in vector store Collections.
        
        Notes:
            * Supports standard SQL data types through teradatasqlalchemy.
            * Enables flexible column source mapping and transformation.
            * Essential for configuring key columns, data columns, metadata columns, and embedding columns.
    
    PARAMETERS:
        name:
            Required Argument.
            Specifies the name of the column which will be created in the collection.
            Types: str

        datatype:
            Optional Argument.
            Specifies the SQL data type for the column using teradatasqlalchemy types.
            Notes:
                * Must be an instance of _TDType (e.g., VARCHAR, INTEGER, DECIMAL)
                * If not specified, it is referred from the datatype of the first column in "sources".
            Types: _TDType

        description:
            Optional Argument.
            Specifies a human-readable description of the column's purpose or content.
            Types: str

        sources:
            Optional Argument.
            Specifies the list of source column references or expressions.
            Notes:
                * Can contain string references (e.g., "table.column").
                * Can contain ColumnExpression objects from teradataml.
                * Used to map column sources for data transformation.
                * If not specified, the column name in "name" itself is used as the source.
            Types: str, ColumnExpression, List of str or ColumnExpression

    RETURNS:
        ColumnInfo instance.

    RAISES:
        TeradataMLException.

    EXAMPLES:
        # Example 1: Create a basic ColumnInfo with VARCHAR type.
        >>> from teradatasqlalchemy.types import VARCHAR
        >>> from teradatagenai import ColumnInfo
        >>> col_info = ColumnInfo(
        ...     name="customer_name",
        ...     datatype=VARCHAR(128),
        ...     description="Customer full name",
        ...     sources=["customers.name"]
        ... )

        # Example 2: Create ColumnInfo with ColumnExpression sources.
        >>> from teradataml import DataFrame
        >>> from teradatasqlalchemy.types import INTEGER
        >>> from teradatagenai import ColumnInfo, load_data
        >>> load_data('employee', 'employee_data')
        >>> data = DataFrame('employee_data')
        >>> col_info = ColumnInfo(
        ...     name="employee_id", 
        ...     datatype=INTEGER(),
        ...     sources=[data.emp_id]
        ... )

        # Example 3: Minimal ColumnInfo with just name.
        >>> col_info = ColumnInfo(name="simple_column")
    """
    name: str
    datatype: Optional[Any] = None
    description: Optional[str] = None
    sources: Optional[List[Union[str, ColumnExpression]]] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)
    
    def __post_init__(self):
        """Validate ColumnInfo fields after initialization."""
        # Validate datatype is a teradatasqlalchemy type if provided
        if self.datatype is not None and not isinstance(self.datatype, _TDType):
            invalid_arg_types = [type(self.datatype).__name__]
            raise TypeError(Messages.get_message(MessageCodes.UNSUPPORTED_DATATYPE,
                                                 "datatype", "teradatasqlalchemy types"))


def _convert_column_info_to_service_format(columns: Union[ColumnInfo, List[ColumnInfo]]) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
        DESCRIPTION:
            Convert ColumnInfo object(s) into the service format required by the API.
            This function processes ColumnInfo objects and extracts their source column 
            references and metadata into the format expected by backend services.
            
            The function handles both single ColumnInfo objects and lists of ColumnInfo objects,
            flattening all source references into a single list while preserving the column
            metadata for each ColumnInfo object.
    
        PARAMETERS:
            columns:
                Required Argument.
                Specifies single ColumnInfo object or List of ColumnInfo objects to be converted.
                Each ColumnInfo object contains column name, datatype, description, and source references.
                Types: ColumnInfo, List[ColumnInfo]
    
        RETURNS:
            Tuple containing:
            - List[str]: Flattened list of source column names from all ColumnInfo objects.
                        ColumnExpression objects are compiled to string representations.
                        If no sources specified, uses the column name itself.
            - List[Dict[str, Any]]: List of dictionaries with column metadata.
                                   Each dictionary contains 'name', 'datatype', and 'description' keys.
    
        RAISES:
            TypeError: If columns parameter is not ColumnInfo or List[ColumnInfo].
    
        EXAMPLES:
            >>> from teradatasqlalchemy.types import VARCHAR, INTEGER
            >>> from teradatagenai.common.constants import ColumnInfo, _convert_column_info_to_service_format
            >>> 
            >>> # Example 1: Single ColumnInfo with multiple sources
            >>> col_info = ColumnInfo(
            ...     name="customer_name",
            ...     datatype=VARCHAR(128),
            ...     description="Customer full name",
            ...     sources=["customers.name", "profiles.full_name"]
            ... )
            >>> columns_list, columns_info = _convert_column_info_to_service_format(col_info)
            >>> # columns_list: ["customers.name", "profiles.full_name"]
            >>> # columns_info: [{"name": "customer_name", "datatype": "VARCHAR(128)", "description": "Customer full name"}]
            
            >>> # Example 2: List of ColumnInfo objects
            >>> col1 = ColumnInfo(name="id", datatype=INTEGER(), sources=["table.id"])
            >>> col2 = ColumnInfo(name="name", datatype=VARCHAR(50), sources=["table.name"])
            >>> columns_list, columns_info = _convert_column_info_to_service_format([col1, col2])
            >>> # columns_list: ["table.id", "table.name"]
            >>> # columns_info: [{"name": "id", "datatype": "INTEGER", "description": None}, 
            >>> #                 {"name": "name", "datatype": "VARCHAR(50)", "description": None}]
    """
    # Handle single column case
    if isinstance(columns, ColumnInfo):
        columns = [columns]
    
    columns_list = []
    columns_info = []
    
    for col_info in columns:
        # Add all sources to the columns list
        if col_info.sources:
            # Convert ColumnExpression objects to strings
            for source in col_info.sources:
                if isinstance(source, ColumnExpression):
                    kw_new = dict({'dialect': td_dialect(),
                                   'compile_kwargs':
                                    {
                                            'include_table': True,
                                            'literal_binds': True
                                    }})

                    columns_list.append(str(source.compile(**kw_new)))
                else:
                    columns_list.append(str(source))
        else:
            # If no sources specified, use the column name itself
            columns_list.append(col_info.name)
        
        columns_info_row = {"name": col_info.name}
        # Convert datatype to string representation
        if col_info.datatype is not None:
            # Use str() to get full type specification including length/precision
            columns_info_row["datatype"] = str(col_info.datatype.compile())
        
        if col_info.description is not None:
            columns_info_row["description"] = col_info.description

        columns_info.append(columns_info_row)
    
    return columns_list, columns_info

def _convert_to_service_request_dict(columns: Union[str, ColumnInfo, List[ColumnInfo], List[str]], column_type: str = "key_columns") -> Dict[str, Any]:
    """
        DESCRIPTION:
            Converts ColumnInfo object(s) to service request dictionary format.
            This function creates a properly structured dictionary that can be used in API requests
            for vector store operations. It processes ColumnInfo objects and organizes them into
            the format expected by the service endpoints.
            
            The function validates input parameters and uses _convert_column_info_to_service_format
            internally to transform the ColumnInfo objects into the appropriate structure.
    
        PARAMETERS:
            columns:
                Required Argument.
                Specifies single ColumnInfo object or List of ColumnInfo objects to be converted.
                Can be a single ColumnInfo object, a list of ColumnInfo objects, 
                a string, or a list of strings.
                Types: str, ColumnInfo, List[ColumnInfo], List[str]
                
            column_type:
                Optional Argument.
                Specifies the type of columns being processed, which determines the
                dictionary keys in the returned result.
                Common values include "key_columns", "data_columns", "metadata_columns", etc.
                Types: str
    
        RETURNS:
            Dict[str, Any]: Dictionary with two keys:
            - {column_type}: List of source column names (flattened from all sources)
            - "{column_type}_info": List of dictionaries with column metadata
    
        RAISES:
            TeradataMLException: If argument validation fails.
            TypeError: If columns parameter contains invalid object types.
    
        EXAMPLES:
            >>> from teradatasqlalchemy.types import VARCHAR, INTEGER
            >>> from teradatagenai.common.constants import ColumnInfo, _convert_to_service_request_dict
            >>> 
            >>> # Example 1: Single ColumnInfo for key columns
            >>> col_info = ColumnInfo(
            ...     name="customer_id",
            ...     datatype=INTEGER(),
            ...     description="Unique customer identifier",
            ...     sources=["customers.id", "profiles.customer_id"]
            ... )
            >>> result = _convert_to_service_request_dict(col_info, "key_columns")
            >>> # result: {
            >>> #     "key_columns": ["customers.id", "profiles.customer_id"],
            >>> #     "key_columns_info": [{
            >>> #         "name": "customer_id",
            >>> #         "datatype": "INTEGER",
            >>> #         "description": "Unique customer identifier"
            >>> #     }]
            >>> # }
            
            >>> # Example 2: List of ColumnInfo for data columns
            >>> col1 = ColumnInfo(name="name", datatype=VARCHAR(100), sources=["table.name"])
            >>> col2 = ColumnInfo(name="email", datatype=VARCHAR(255), sources=["table.email"])
            >>> result = _convert_to_service_request_dict([col1, col2], "data_columns")
            >>> # result: {
            >>> #     "data_columns": ["table.name", "table.email"],
            >>> #     "data_columns_info": [
            >>> #         {"name": "name", "datatype": "VARCHAR(100)", "description": None},
            >>> #         {"name": "email", "datatype": "VARCHAR(255)", "description": None}
            >>> #     ]
            >>> # }
    """
    arg_info_matrix = []
    
    # Validate columns parameter
    if isinstance(columns, list):
        # Validate each item in the list is a ColumnInfo
        for i, col in enumerate(columns):
            arg_info_matrix.append([f"columns[{i}]", col, False, (ColumnInfo,str), True])
    else:
        # Validate single ColumnInfo object
        arg_info_matrix.append(["columns", columns, False, (ColumnInfo,str), True])
    
    # Validate column_type parameter
    arg_info_matrix.append(["column_type", column_type, False, (str), True])
    
    # Validate argument types
    _Validators._validate_function_arguments(arg_info_matrix)
    
    columns_list, columns_info = _convert_column_info_to_service_format(columns)
    
    return {
        column_type: columns_list,
        f"{column_type}_info": columns_info
    }

class Serializable:
    """Base class that auto-converts attributes to service format using SERVICE_FIELDS."""
    SERVICE_FIELDS = {}  # Subclasses define: {user_param: service_field}
    COLUMN_FIELDS = []  # Subclasses define list of fields that need column conversion
    DATAFRAME_FIELDS = []  # Subclasses define list of fields that need DataFrame processing

    def to_dict(self, include_none: bool = False) -> dict:
        """Auto-converts attributes to service format."""
        result = {}
        for user_param, value in self.__dict__.items():
            # Skip None values unless explicitly requested
            if value is None and not include_none:
                continue

            # Check if this field needs DataFrame processing (for object_names etc.)
            if user_param in self.DATAFRAME_FIELDS:
                if value is not None:
                    # Process DataFrames using _ProcessDataFrameObjects
                    processed_value = _ProcessDataFrameObjects(value)
                    service_field = self.SERVICE_FIELDS.get(user_param, user_param)
                    result[service_field] = processed_value
                elif include_none:
                    service_field = self.SERVICE_FIELDS.get(user_param, user_param)
                    result[service_field] = None
                continue

            # Check if this field needs special column conversion
            if user_param in self.COLUMN_FIELDS:
                if value is not None:
                    # Normalize to list
                    value_list = UtilFuncs._as_list(value)

                    # Process items in original order to preserve user-specified ordering
                    result_columns = []
                    result_columns_info = []
                    
                    for item in value_list:
                        if isinstance(item, ColumnInfo):
                            # Convert ColumnInfo to service format
                            converted = _convert_to_service_request_dict([item], user_param)
                            result_columns.extend(converted[user_param])
                            result_columns_info.extend(converted[f"{user_param}_info"])
                        elif isinstance(item, ColumnExpression):
                            # Convert ColumnExpression to string.
                            # Only names are needed incase of ColumnExpression as source, datatype 
                            # and description are not applicable.
                            kw_new = dict({'dialect': td_dialect(),
                                           'compile_kwargs':
                                            {
                                                    'include_table': True,
                                                    'literal_binds': True
                                            }})
                            expr_str = str(item.compile(**kw_new))
                            result_columns.append(expr_str)
                        else:
                            # Handle plain strings
                            result_columns.append(str(item))
                    
                    # Set the results maintaining original order
                    result[user_param] = result_columns
                    if result_columns_info:
                        result[f"{user_param}_info"] = result_columns_info
                elif include_none:
                    result[user_param] = None
                    result[f"{user_param}_info"] = None
                continue

            # Regular field processing
            service_field = self.SERVICE_FIELDS.get(user_param, user_param)
            # Recursively convert nested Serializable objects
            if hasattr(value, 'to_dict') and callable(getattr(value, 'to_dict')):
                result[service_field] = value.to_dict(include_none=include_none)
            # Handle dataclasses (like ColumnInfo) that don't inherit from Serializable
            elif is_dataclass(value) and not isinstance(value, type):
                result[service_field] = asdict(value)
            # Handle lists
            elif isinstance(value, list) and value:
                converted_list = []
                for v in value:
                    if hasattr(v, 'to_dict') and callable(getattr(v, 'to_dict')):
                        converted_list.append(v.to_dict(include_none=include_none))
                    elif is_dataclass(v) and not isinstance(v, type):
                        converted_list.append(asdict(v))
                    else:
                        converted_list.append(v)
                result[service_field] = converted_list
            else:
                result[service_field] = value
        return result

@dataclass
@docstring_handler(
    common_params={**COLUMN_PARAMS}
)
class ContentBasedIndex(Serializable):
    """
    DESCRIPTION:
        Configuration for content-based vector Collections.
        Defines how to create Collections from existing tables or DataFrames by specifying
        the source data and column mappings. Supports automatic text embedding generation
        from specified data columns.
        
    PARAMETERS:
        object_names:
            Required Argument.
            Specifies the table name(s) or teradataml DataFrame(s) to be indexed for the collection.
            Types: str or list of str or DataFrame or list of DataFrame
            
    RETURNS:
        ContentBasedIndex object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradataml import DataFrame, in_schema
        >>> from teradatagenai import ContentBasedIndex, ColumnInfo
        >>> from teradatasqlalchemy.types import INTEGER, VARCHAR
        
        # Example using ColumnInfo with string table names
        >>> index = ContentBasedIndex(
             object_names=["db1.table1", "db2.table2"],
             key_columns=[
                 ColumnInfo(
                     name="id",
                     datatype=INTEGER(),
                     description="Primary key",
                     sources=["db1.table1.id", "db2.table2.id1"]
                 )
             ],
             data_columns=[
                 ColumnInfo(
                     name="text",
                     datatype=VARCHAR(1024),
                     description="Text data",
                     sources=["db1.table1.text", "db2.table2.text1"]
                 )
             ]
         )
    """
    object_names: Optional[Union[str, List[str], DataFrame, List[DataFrame]]] = None
    key_columns: Optional[Union[str, ColumnInfo, ColumnExpression, List[Union[str, ColumnInfo, ColumnExpression]]]] = None
    data_columns: Optional[Union[str, ColumnInfo, ColumnExpression, List[Union[str, ColumnInfo, ColumnExpression]]]] = None
    metadata_columns: Optional[Union[str, ColumnInfo, ColumnExpression, List[Union[str, ColumnInfo, ColumnExpression]]]] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)


    SERVICE_FIELDS = {
        "object_names": "object_names",
        "key_columns": "key_columns",
        "data_columns": "data_columns",
        "metadata_columns": "metadata_columns"
    }
    
    COLUMN_FIELDS = ["key_columns", "data_columns", "metadata_columns"]
    DATAFRAME_FIELDS = ["object_names"]

@dataclass
@docstring_handler(
    common_params={**COLUMN_PARAMS}
)
class EmbeddingBasedIndex(ContentBasedIndex):
    """
    DESCRIPTION:
        Configuration for Collections with existing embedding vectors.
        Designed for scenarios where source tables already contain pre-computed embedding vectors.
        Enables creation of vector Collections directly from existing embeddings without 
        requiring additional text processing.
        
    PARAMETERS:
        object_names:
            Required Argument.
            Specifies the table name(s) or teradataml DataFrame(s) to be indexed for the collection.
            Types: str or list of str or DataFrame or list of DataFrame
            
        embedding_columns:
            Required Argument.
            Specifies the input column(s) containing embedding vectors.
            Types: ColumnInfo or ColumnExpression or list of ColumnInfo or list of ColumnExpression
            
        is_normalized:
            Optional Argument.
            Specifies whether the embeddings are already L2-normalized.
            Types: bool
            Default Value: False
            
    RETURNS:
        EmbeddingBasedIndex object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradataml import DataFrame, in_schema
        >>> from teradatagenai import EmbeddingBasedIndex, ColumnInfo
        >>> from teradatasqlalchemy.types import VECTOR
        
        # Example using ColumnInfo with table name
        >>> index = EmbeddingBasedIndex(
             object_names=['customers'],
             embedding_columns=[
                 ColumnInfo(
                     name='profile_text',
                     datatype=VECTOR(),
                     description='Profile embeddings',
                     sources=['customers.profile_text']
                 )
             ],
             is_normalized=True
         )
    """
    embedding_columns: Optional[Union[ColumnInfo, ColumnExpression, List[Union[ColumnInfo, ColumnExpression]]]] = None
    is_normalized: Optional[bool] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    SERVICE_FIELDS = {
        **ContentBasedIndex.SERVICE_FIELDS,
        "embedding_columns": "embedding_columns",
        "is_normalized": "normalized_embedding"
    }
    
    COLUMN_FIELDS = ["key_columns", "data_columns", "metadata_columns", "embedding_columns"]
    DATAFRAME_FIELDS = ["object_names"]  # Inherit DataFrame processing for object_names

@dataclass
class SearchParams(Serializable):
    """
    DESCRIPTION:
        Search configuration parameters for Collection queries.
        Controls search behavior including result count, similarity thresholds, 
        search strategies, and advanced reranking options. Enables fine-tuning
        of search performance and result quality for various use cases.
        
    PARAMETERS:
        top_k:
            Optional Argument.
            Specifies the number of top similarity matches to return.
            Types: int
            Default Value: 10
            
        search_threshold:
            Optional Argument.
            Specifies threshold for match filtering; semantics depend on metric.
            Types: float
            Default Value: None
            
        search_numcluster:
            Optional Argument.
            Specifies the number of clusters or fraction used during search (index-dependent).
            Types: int
            Default Value: None
            
        ef_search:
            Optional Argument.
            Specifies HNSW search breadth parameter.
            Types: int
            Default Value: 32
            
        search_type:
            Optional Argument.
            Specifies the type of search to be performed.
            Types: str
            Default Value: 'semantic_search'
            Permitted Values:
                * 'semantic_search': Performs vector-based search across the entire collection.
                * 'hybrid_search': Combines vector search and BM25 search across the entire collection.
                * 'relevance_search': Performs vector search across the full collection and BM25 search only on the top relevance_top_k results.
                
        scoring_method:
            Optional Argument.
            Specifies how the results from semantic (vector) search and BM25 search are combined (rank fusion).
            Applicable when "search_type" is set to either 'hybrid_search' or 'relevance_search'.
            Types: str
            Default Value: 'weighted_sum'
            Permitted Values:
                * 'weighted_sum': Combines scores from both search methods using the "sparse_weight" parameter.
                * 'rrf': Reciprocal Rank Fusion - combines results based on their ranks from each method.
                * 'weighted_rrf': Uses rank-based fusion and applies weights to scores using the "sparse_weight" parameter.
                
        sparse_weight:
            Optional Argument.
            Specifies the weight assigned to BM25 scores during rank fusion with semantic search results.
            Applicable when "search_type" is set to either 'hybrid_search' or 'relevance_search',
            and "scoring_method" is either 'weighted_sum' or 'weighted_rrf'.
            Types: float
            Default Value: 0.0
            Permitted Values: 0.0 to 1.0
            
        rrf_normalizer:
            Optional Argument.
            Specifies the normalizer value used in Reciprocal Rank Fusion (RRF) to normalize the rank scores during fusion.
            A higher value reduces the influence of lower-ranked results.
            Applicable when "search_type" is set to either 'hybrid_search' or 'relevance_search',
            and "scoring_method" is either 'rrf' or 'weighted_rrf'.
            Types: int
            Default Value: 60
            
        relevance_top_k:
            Optional Argument.
            Specifies the number of top similarity matches to be considered for reranking.
            Types: int
            Default Value: 60
            Permitted Values: 1 to 1024
            
        relevance_search_threshold:
            Optional Argument.
            Specifies the threshold value to consider matching tables/views while reranking.
            A higher threshold value limits responses to the top matches only.
            Types: float
            Default Value: 0.395
            
        maximal_marginal_relevance:
            Optional Argument.
            Specifies whether to use maximal marginal relevance technique to re-rank the search results.
            Types: bool
            Default Value: False
            
        lambda_multiplier:
            Optional Argument.
            Specifies the lambda multiplier value to be used along with "maximal_marginal_relevance" parameter.
            Types: float
            Default Value: 0.5
            Permitted Values: 0.1 to 1.0
            
    RETURNS:
        SearchParams object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradatagenai import SearchParams
        >>> search_params = SearchParams(
             top_k=5,
             ef_search=64
         )
    """
    # Basic search controls
    top_k: Optional[int] = None
    search_threshold: Optional[float] = None
    search_numcluster: Optional[int] = None
    ef_search: Optional[int] = None

    # Advanced strategy/reranking
    search_type: Optional[str] = None
    scoring_method: Optional[str] = None
    sparse_weight: Optional[float] = None
    rrf_normalizer: Optional[int] = None
    relevance_top_k: Optional[int] = None
    relevance_search_threshold: Optional[float] = None
    maximal_marginal_relevance: Optional[bool] = None
    lambda_multiplier: Optional[float] = None
    rerank_sparse_weight: Optional[float] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    # Fields that go into search_params
    SEARCH_PARAMS_FIELDS = {
        "top_k": "top_k",
        "search_threshold": "search_threshold",
        "search_numcluster": "search_numcluster",
        "ef_search": "ef_search",
    }

    # Fields that go into search_strategy
    SEARCH_STRATEGY_FIELDS = {
        "search_type": "search_type",
        "scoring_method": "scoring_method",
        "sparse_weight": "sparse_weight",
        "rrf_normalizer": "rrf_normalizer",
        "relevance_top_k": "relevance_top_k",
        "relevance_search_threshold": "relevance_search_threshold",
        "maximal_marginal_relevance": "maximal_marginal_relevance",
        "lambda_multiplier": "lambda_multiplier",
        "rerank_sparse_weight": "rerank_sparse_weight",
    }

    # SERVICE_FIELDS is not used for SearchParams - it has custom to_dict() method
    SERVICE_FIELDS = {}
    
    def to_dict(self, include_none: bool = False) -> dict:
        """
        Converts SearchParams to REST API format with proper separation.
        
        Returns:
            dict with structure:
            {
                "search_params": {"top_k": 10, "search_threshold": 0.8, ...},
                "search_strategy": {"search_type": "semantic", "scoring_method": "COSINE", ...}
            }
        """
        result = {}
        
        # Build search_params section
        search_params = {}
        for user_param, service_field in self.SEARCH_PARAMS_FIELDS.items():
            value = getattr(self, user_param, None)
            if value is not None or include_none:
                search_params[service_field] = value
        
        if search_params:
            result["search_params"] = search_params
        
        # Build search_strategy section
        search_strategy = {}
        for user_param, service_field in self.SEARCH_STRATEGY_FIELDS.items():
            value = getattr(self, user_param, None)
            if value is not None or include_none:
                search_strategy[service_field] = value
        
        if search_strategy:
            result["search_strategy"] = search_strategy
        
        return result
    
    def get_search_params(self, include_none: bool = False) -> dict:
        """Get only the search_params section."""
        search_params = {}
        for user_param, service_field in self.SEARCH_PARAMS_FIELDS.items():
            value = getattr(self, user_param, None)
            if value is not None or include_none:
                search_params[service_field] = value
        return search_params
    
    def get_search_strategy(self, include_none: bool = False) -> dict:
        """Get only the search_strategy section."""
        search_strategy = {}
        for user_param, service_field in self.SEARCH_STRATEGY_FIELDS.items():
            value = getattr(self, user_param, None)
            if value is not None or include_none:
                search_strategy[service_field] = value
        return search_strategy

@dataclass
class FLAT(Serializable):
    """
    DESCRIPTION:
        Configuration for FLAT vector indexing.
        Provides exhaustive search with guaranteed accuracy by comparing query vectors
        against all stored vectors. Ideal for smaller datasets or applications requiring
        perfect recall.
        
    PARAMETERS:
        metric:
            Optional Argument.
            Specifies the distance metric for similarity.
            Types: str
            Default Value: 'COSINE'
            Permitted Values: 'EUCLIDEAN', 'COSINE', 'DOTPRODUCT'
            
    RETURNS:
        FLAT object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradatagenai import FLAT
        
        # Create FLAT index parameters
        >>> flat_params = FLAT(
             metric='EUCLIDEAN'
         )
    """
    metric: Optional[str] = None
    _algorithm: Optional[str] = "FLAT"
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        self._algorithm = "FLAT"
    
    SERVICE_FIELDS = {
        "metric": "metric",
        "_algorithm": "search_algorithm"
    }

@dataclass
class IVF_FLAT(FLAT):
    """
    DESCRIPTION:
        Configuration for IVF_FLAT vector indexing.
        Balances search speed and accuracy using clustering techniques. Suitable for medium
        to large datasets where faster search times are needed while maintaining good accuracy.
        Offers configurable trade-offs between search performance and result quality.
        
    PARAMETERS:
        metric:
            Optional Argument.
            Specifies the distance metric for similarity.
            Types: str
            Default Value: 'COSINE'
            Permitted Values: 'EUCLIDEAN', 'COSINE', 'DOTPRODUCT'
            
        initial_centroids_method:
            Optional Argument.
            Specifies the centroid initialization strategy.
            Types: str
            Default Value: 'RANDOM'
            Permitted Values: 'RANDOM', 'KMEANS++'
            
        train_numcluster:
            Optional Argument.
            Specifies the number of clusters to train (-1 = auto).
            Types: int
            Default Value: -1
            
        max_iternum:
            Optional Argument.
            Specifies the maximum k-means iterations during training.
            Types: int
            Default Value: 10
            Permitted Values: 1 to 2147483647
            
        stop_threshold:
            Optional Argument.
            Specifies the early-stopping threshold.
            Types: float
            Default Value: 0.0395
            
        seed:
            Optional Argument.
            Specifies the random seed for reproducible training.
            Types: int
            Default Value: 0
            Permitted Values: 0 to 2147483647
            
        num_init:
            Optional Argument.
            Specifies the number of k-means runs with different seeds.
            Types: int
            Default Value: 1
            Permitted Values: 1 to 2147483647
            
    RETURNS:
        IVF_FLAT object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradatagenai import IVF_FLAT
        
        # Create IVF_FLAT index parameters
        >>> ivf_params = IVF_FLAT(
             initial_centroids_method='KMEANS++',
             train_numcluster=100
         )
    """
    initial_centroids_method: Optional[str] = None
    train_numcluster: Optional[int] = None
    max_iternum: Optional[int] = None
    stop_threshold: Optional[float] = None
    seed: Optional[int] = None
    num_init: Optional[int] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        self._algorithm = "IVF_FLAT"

    SERVICE_FIELDS = {
        **FLAT.SERVICE_FIELDS,
        "initial_centroids_method": "initial_centroids_method",
        "train_numcluster": "train_numcluster",
        "max_iternum": "max_iternum",
        "stop_threshold": "stop_threshold",
        "seed": "seed",
        "num_init": "num_init"
    }

@dataclass
class HNSW(FLAT):
    """
    DESCRIPTION:
        Configuration for HNSW vector indexing.
        Delivers fast approximate nearest neighbor search with high accuracy using 
        graph-based algorithms. Optimal for large-scale datasets requiring rapid 
        query responses with excellent recall performance.
        
    PARAMETERS:
        metric:
            Optional Argument.
            Specifies the distance metric for similarity.
            Types: str
            Default Value: 'COSINE'
            Permitted Values: 'EUCLIDEAN', 'COSINE', 'DOTPRODUCT'
            
        num_layer:
            Optional Argument.
            Specifies the maximum number of graph layers.
            Types: int
            Default Value: -1
            Permitted Values: 1 to 1024 or -1 for auto
            
        ef_construction:
            Optional Argument.
            Specifies the number of neighbors considered during graph construction.
            Types: int
            Default Value: 32
            Permitted Values: 1 to 1024

        num_connpernode:
            Optional Argument.
            Specifies the target number of connections per node.
            Types: int
            Default Value: 32
            Permitted Values: 1 to 1024
            
        maxnum_connpernode:
            Optional Argument.
            Specifies the hard cap on connections per node.
            Types: int
            Default Value: 32
            Permitted Values: 1 to 1024
            
        apply_heuristics:
            Optional Argument.
            Specifies whether to apply HNSW construction heuristics.
            Types: bool
            Default Value: True
            
        num_nodes_per_graph:
            Optional Argument.
            Specifies the number of nodes per graph shard.
            Types: int
            Default Value: None
            
        seed:
            Optional Argument.
            Specifies the random seed for reproducible graphs.
            Types: int
            Default Value: 0
            Permitted Values: 0 to 2147483647
            
    RETURNS:
        HNSW object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradatagenai import HNSW
        
        # Create HNSW index parameters
        >>> hnsw_params = HNSW(
             num_layer=3,
             ef_construction=64
         )
    """
    num_layer: Optional[int] = None
    ef_construction: Optional[int] = None
    num_connpernode: Optional[int] = None
    maxnum_connpernode: Optional[int] = None
    apply_heuristics: Optional[bool] = None
    num_nodes_per_graph: Optional[int] = None
    seed: Optional[int] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        self._algorithm = "HNSW"

    SERVICE_FIELDS = {
        **FLAT.SERVICE_FIELDS,
        "num_layer": "num_layer",
        "ef_construction": "ef_construction",
        "num_connpernode": "num_connPerNode",
        "maxnum_connpernode": "maxNum_connPerNode",
        "apply_heuristics": "apply_heuristics",
        "num_nodes_per_graph": "num_NodesPerGraph",
        "seed": "seed"
    }


@dataclass
class FileConfig(Serializable):
    """
    DESCRIPTION:
        Base configuration class for file ingestion parameters.
        Contains common parameters applicable to all file storage types including
        local files and cloud storage configurations.
        
    PARAMETERS:
        files_type:
            Optional Argument.
            Specifies the file type for processing optimization.
            Types: str
            Permitted Values: "pdf", "csv", "json", "jsonl", "parquet", "ndjson", "ldjson"
            
        delimiter:
            Optional Argument.
            Specifies delimiter for structured content (CSV, etc.).
            Types: str
            
        overwrite_files:
            Optional Argument.
            Specifies whether to overwrite existing file entries with the same identity.
            Types: bool
            Default Value: False
            
        overwrite_objects:
            Optional Argument.
            Specifies whether to overwrite backing tables when supported.
            Types: bool
            Default Value: False
            
    RETURNS:
        FileConfig instance.
        
    EXAMPLES:
        >>> from teradatagenai import FileConfig
        >>> config = FileConfig(
        ...     files_type="pdf",
        ...     delimiter=",",
        ...     overwrite_files=True
        ... )
    """
    files_type: Optional[str] = None
    delimiter: Optional[str] = None
    overwrite_files: Optional[bool] = None
    overwrite_objects: Optional[bool] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    SERVICE_FIELDS = {
        "files_type": "files_type",
        "delimiter": "delimiter", 
        "overwrite_files": "overwrite_files",
        "overwrite_objects": "overwrite_objects"
    }
    
    def get_files_parameters(self) -> dict:
        """Get parameters for files_parameters section."""
        result = {}
        if self.files_type is not None:
            result["files_type"] = self.files_type
        if self.delimiter is not None:
            result["delimiter"] = self.delimiter
        return result


@dataclass
class LocalConfig(FileConfig):
    """
    DESCRIPTION:
        Configuration for local file ingestion.
        Extends FileConfig with local file path specification.
        Suitable for ingesting files from the local filesystem.
        
    PARAMETERS:
        files:
            Required Argument.
            Specifies local file pattern(s) or explicit file paths.
            Can be a single pattern/path or list of patterns/paths.
            Supports glob patterns like '*.pdf', '/path/to/docs/*.txt'
            Types: str, List[str]
            
    RETURNS:
        LocalConfig instance.
        
    EXAMPLES:
        >>> from teradatagenai import LocalConfig
        >>> # Single file pattern
        >>> config = LocalConfig(
        ...     files="/docs/*.pdf",
        ...     files_type="pdf",
        ...     overwrite_files=True
        ... )
        >>> 
        >>> # Multiple file patterns
        >>> config = LocalConfig(
        ...     files=["/docs/*.pdf", "/reports/*.docx"],
        ...     overwrite_files=False
        ... )
    """
    files: Optional[Union[str, List[str]]] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)
    _processed_files = None  # Cache for processed files
    
    def __post_init__(self):
        """Validate required fields after initialization."""
        # Validate that files parameter is provided
        arg_info_matrix = [["files", self.files, False, (str, list), True]]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
    
    SERVICE_FIELDS = {
        "files": "files",
        **FileConfig.SERVICE_FIELDS,
    }
    
    @property
    def processed_files(self):
        """Get files processed for service in the required format."""
        if self._processed_files is None:
            self._processed_files = self.process_files_for_service()
        return self._processed_files
    
    def to_dict(self, include_none: bool = False) -> dict:
        """Convert LocalConfig to service format with processed files."""
        result = super().to_dict(include_none=include_none)
        # Replace files with processed files for service
        result["files"] = self.processed_files
        return result
    
    # LocalConfig doesn't have storage_location since files are local
    
    def process_files_for_service(self):
        """
        Process local files into the format required by the service API.
        
        RETURNS:
            List of tuples in the format: [("files", (filename, file_handle, mime_type))]
            
        RAISES:
            TeradataMlException if files don't exist or processing fails.
        """
        if not self.files:
            return []
        
        # Normalize input to a list
        document_files = self.files
        if isinstance(document_files, str):
            document_files = [document_files]

        resolved_files = []
        for path in document_files:
            files = []
            # Wildcard pattern
            if any(char in path for char in ['*', '?']):
                files = glob.glob(path, recursive="**" in path)
            # Directory path
            elif os.path.isdir(path):
                for root, _, filenames in os.walk(path):
                    files.extend(os.path.join(root, f) for f in filenames)
            # Single file path
            else:
                files = [path]
            
            # Add all resolved files to the list
            resolved_files.extend(files)
        
        # Validate ALL resolved files at once - reports all invalid files together
        _Validators._validate_file_exists(resolved_files)

        # Now process the validated files
        processed_files = []
        # Get the file name from fully qualified path
        for file in resolved_files:
            file_name = os.path.basename(file)
            # Get file extension and determine appropriate MIME type
            file_extension = os.path.splitext(file_name)[1].lower().replace(".", "")
            
            # Map file extensions to correct MIME types
            if file_extension == "csv":
                file_type = "text/csv"
            elif file_extension == "json":
                file_type = "application/json"
            elif file_extension == "parquet":
                file_type = "application/octet-stream"
            elif file_extension == "pdf":
                file_type = "application/pdf"
            else:
                # Default fallback for other file types
                file_type = f"application/{file_extension}"
                
            file_handle = open(file, 'rb')
            processed_files.append(('files', (file_name, file_handle, file_type)))
            # Register the file handle with the GarbageCollector.
            GarbageCollector.add_open_file(file_handle)
        
        return processed_files


@dataclass
class S3Config(FileConfig):
    """
    DESCRIPTION:
        Configuration for accessing documents stored in Amazon S3.
        Enables ingestion of files from S3 buckets into vector Collections.
        Supports various authentication methods including access keys, IAM roles,
        and temporary credentials.

    PARAMETERS:
        bucket:
            Required Argument.
            Specifies the S3 bucket name.
            Types: str

        key:
            Required Argument.
            Specifies the object key/path in the bucket.
            Types: str

        region_name:
            Required Argument.
            Specifies the AWS region.
            Types: str

        aws_access_key_id:
            Optional Argument.
            Specifies the AWS access key ID.
            Types: str

        aws_secret_access_key:
            Optional Argument.
            Specifies the AWS secret access key.
            Types: str

        aws_session_token:
            Optional Argument.
            Specifies the AWS session token for temporary credentials.
            Types: str

    RETURNS:
        S3Config instance.

    EXAMPLES:
        # Example 1: Basic S3Config with access keys
        >>> from teradatagenai import S3Config
        >>> s3_config = S3Config(
        ...     bucket="my-data-bucket",
        ...     key="documents/file.pdf",
        ...     region_name="us-east-1",
        ...     aws_access_key_id="<key_id>",
        ...     aws_secret_access_key="<ke>"
        ... )

        # Example 2: S3Config using IAM roles (no explicit credentials)
        >>> s3_config = S3Config(
        ...     bucket="company-documents",
        ...     key="data/*.txt",
        ...     region_name="us-west-2"
        ... )

        # Example 3: S3Config with temporary credentials
        >>> s3_config = S3Config(
        ...     bucket="temp-bucket",
        ...     key="uploads/document.pdf",
        ...     region_name="eu-west-1",
        ...     aws_session_token="<session_token>"
        ... )
    """
    bucket: Optional[str] = None
    key: Optional[str] = None
    region_name: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None
    type: str = "s3"  # Storage type identifier
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        """Validate required fields after initialization."""
        # Validate required S3 parameters
        arg_info_matrix = [
            ["bucket", self.bucket, False, str, True],
            ["key", self.key, False, str, True], 
            ["region_name", self.region_name, False, str, True]
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)

    SERVICE_FIELDS = {
        # Storage location fields (for cloud storage access)
        "type": "type",
        "bucket": "bucket",
        "key": "key",
        "region_name": "region_name",
        "aws_access_key_id": "aws_access_key_id",
        "aws_secret_access_key": "aws_secret_access_key",
        "aws_session_token": "aws_session_token"
        # Note: overwrite parameters handled separately via get_files_parameters()
    }


@dataclass
class AzureBlobConfig(FileConfig):
    """
    DESCRIPTION:
        Configuration for accessing documents stored in Azure Blob Storage.
        Enables ingestion of files from Azure containers into vector Collections.
        Supports authentication through storage account keys and managed identities.

    PARAMETERS:
        container:
            Required Argument.
            Specifies the Azure container name.
            Types: str

        blob_name:
            Required Argument.
            Specifies the blob name/path.
            Types: str

        account_name:
            Required Argument.
            Specifies the storage account name.
            Types: str

        account_key:
            Optional Argument.
            Specifies the storage account key.
            Types: str

    RETURNS:
        AzureBlobConfig instance.

    EXAMPLES:
        # Example 1: Basic AzureBlobConfig with account key
        >>> from teradatagenai import AzureBlobConfig
        >>> azure_config = AzureBlobConfig(
        ...     container="documents",
        ...     blob_name="reports/quarterly-report.pdf",
        ...     account_name="mystorageaccount",
        ...     account_key="<account_key>"
        ... )

        # Example 2: AzureBlobConfig using managed identity (no explicit key)
        >>> azure_config = AzureBlobConfig(
        ...     container="data-files",
        ...     blob_name="input/*.json",
        ...     account_name="companydata"
        ... )

        # Example 3: AzureBlobConfig for specific blob
        >>> azure_config = AzureBlobConfig(
        ...     container="uploads",
        ...     blob_name="user-documents/document.docx",
        ...     account_name="filestore",
        ...     account_key="<account_key>"
        ... )
    """
    container: Optional[str] = None
    blob_name: Optional[str] = None
    account_name: Optional[str] = None
    account_key: Optional[str] = None
    type: str = "azure_blob"  # Storage type identifier
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        """Validate required fields after initialization."""
        # Validate required Azure parameters
        arg_info_matrix = [
            ["container", self.container, False, str, True],
            ["blob_name", self.blob_name, False, str, True],
            ["account_name", self.account_name, False, str, True]
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)

    SERVICE_FIELDS = {
        # Storage location fields (for cloud storage access)
        "type": "type",
        "container": "container",
        "blob_name": "blob_name",
        "account_name": "account_name",
        "account_key": "account_key"
        # Note: overwrite parameters handled separately via get_files_parameters()
    }


@dataclass
class GCPConfig(FileConfig):
    """
    DESCRIPTION:
        Configuration for accessing documents stored in Google Cloud Storage.
        Enables ingestion of files from GCS buckets into vector Collections.
        Supports authentication through service account credentials and 
        default application credentials.

    PARAMETERS:
        bucket:
            Required Argument.
            Specifies the GCS bucket name.
            Types: str

        blob_name:
            Required Argument.
            Specifies the blob/object name/path.
            Types: str

        project_id:
            Required Argument.
            Specifies the GCP project ID.
            Types: str

        secret:
            Optional Argument.
            Specifies the service account credentials (JSON string or parsed dict).
            Types: str, dict

    RETURNS:
        GCPConfig instance.

    EXAMPLES:
        # Example 1: Basic GCPConfig with service account credentials
        >>> from teradatagenai import GCPConfig
        >>> import json
        >>> credentials = {
        ...     "type": "service_account",
        ...     "project_id": "my-project",
        ...     "private_key_id": "key-id",
        ...     "private_key": "-----BEGIN PRIVATE KEY-----\\n...\\n-----END PRIVATE KEY-----\\n",
        ...     "client_email": "service-account@my-project.iam.gserviceaccount.com",
        ...     "client_id": "123456789",
        ...     "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        ...     "token_uri": "https://oauth2.googleapis.com/token"
        ... }
        >>> gcp_config = GCPConfig(
        ...     bucket="my-data-bucket",
        ...     blob_name="documents/file.pdf",
        ...     project_id="my-project-id",
        ...     secret=credentials
        ... )

        # Example 2: GCPConfig using default credentials (no explicit secret)
        >>> gcp_config = GCPConfig(
        ...     bucket="company-files",
        ...     blob_name="data/*.csv",
        ...     project_id="company-project"
        ... )

        # Example 3: GCPConfig with JSON string credentials
        >>> json_credentials = '{"type": "service_account", "project_id": "my-project", ...}'
        >>> gcp_config = GCPConfig(
        ...     bucket="analytics-data",
        ...     blob_name="logs/application.log",
        ...     project_id="analytics-project",
        ...     secret=json_credentials
        ... )
    """
    bucket: Optional[str] = None
    blob_name: Optional[str] = None
    project_id: Optional[str] = None
    secret: Optional[Union[str, dict]] = None
    type: str = "gcp"  # Storage type identifier
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    def __post_init__(self):
        """Validate required fields after initialization."""
        # Validate required GCP parameters
        arg_info_matrix = [
            ["bucket", self.bucket, False, str, True],
            ["blob_name", self.blob_name, False, str, True],
            ["project_id", self.project_id, False, str, True],
            ["secret", self.secret, False, (dict), True]
        ]
        self.secret = json.dumps(self.secret)
        _Validators._validate_missing_required_arguments(arg_info_matrix)

    SERVICE_FIELDS = {
        # Storage location fields (for cloud storage access)
        "type": "type",
        "bucket": "bucket",
        "blob_name": "blob_name",
        "project_id": "project_id",
        "secret": "secret"
        # Note: overwrite parameters handled separately via get_files_parameters()
    }


@dataclass
@docstring_handler(
    common_params={**INGESTOR_COMMON_PARAMS}
)
class BasicIngestor(Serializable):
    """
    DESCRIPTION:
        Standard document processing configuration for file ingestion.
        Provides essential text extraction and chunking capabilities for common document types.
        Suitable for most text-based documents where basic content extraction is sufficient.

    RETURNS:
        BasicIngestor instance.

    EXAMPLES:
        # Example 1: Basic ingestor with default parameters
        >>> from teradatagenai import BasicIngestor
        >>> ingestor = BasicIngestor()

        # Example 2: Custom chunk size and overlap
        >>> ingestor = BasicIngestor(
        ...     chunk_size=1024,
        ...     chunk_overlap=200
        ... )

        # Example 3: With header and footer exclusion
        >>> ingestor = BasicIngestor(
        ...     chunk_size=800,
        ...     chunk_overlap=100,
        ...     header_height=50,
        ...     footer_height=30
        ... )
    """
    chunk_size: Optional[int] = None
    chunk_overlap: Optional[int] = None
    footer_height: Optional[int] = None
    header_height: Optional[int] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    SERVICE_FIELDS = {
        "chunk_size": "chunk_size",
        "chunk_overlap": "chunk_overlap",
        "footer_height": "footer_height",
        "header_height": "header_height",
        "ingestor": "ingestor"
    }

    def __post_init__(self):
        self.ingestor = "basic"


@dataclass
@docstring_handler(
    common_params={**INGESTOR_COMMON_PARAMS, **EXTRACTION_COMMON_PARAMS}
)
class NVIngestor(BasicIngestor):
    """
    DESCRIPTION:
        Advanced document processing configuration using NVIDIA NIM technology.
        Provides comprehensive extraction capabilities including text, images, tables,
        and infographics from complex documents. Ideal for rich document formats 
        requiring sophisticated content analysis and extraction.

    PARAMETERS:
        ingest_host:
            Optional Argument.
            Specifies the document ingestion host URL.
            Types: str

        ingest_port:
            Optional Argument.
            Specifies the document ingestion service port.
            Types: str

        tokenizer:
            Optional Argument.
            Specifies the tokenizer model to use.
            Types: str

        hf_access_token:
            Optional Argument.
            Specifies the HuggingFace access token for model access.
            Types: str

        vlm_model:
            Optional Argument.
            Specifies the vision language model configuration.
            Types: dict

        extract_text:
            Optional Argument.
            Specifies whether to extract text content.
            Types: bool

        extract_infographics:
            Optional Argument.
            Specifies whether to extract infographics.
            Types: bool

        extract_method:
            Optional Argument.
            Specifies the extraction method to use.
            Types: str

        extract_captions:
            Optional Argument.
            Specifies whether to extract captions.
            Types: bool

        display_metadata:
            Optional Argument.
            Specifies whether to extract display metadata.
            Types: bool

    RETURNS:
        NVIngestor instance.

    EXAMPLES:
        # Example 1: Basic NV ingestor with default settings
        >>> from teradatagenai import NVIngestor
        >>> ingestor = NVIngestor()

        # Example 2: NV ingestor with image and table extraction
        >>> ingestor = NVIngestor(
        ...     chunk_size=1024,
        ...     extract_images=True,
        ...     extract_tables=True,
        ...     extract_metadata_json=True
        ... )

        # Example 3: Custom NV ingestor with host configuration
        >>> ingestor = NVIngestor(
        ...     ingest_host="https://my-nim-host.com",
        ...     ingest_port="8080",
        ...     tokenizer="meta-llama/Llama-3.2-3B",
        ...     extract_images=True,
        ...     extract_tables=True,
        ...     extract_infographics=True,
        ...     extract_method="pymupdf"
        ... )
    """
    ingest_host: Optional[str] = None
    ingest_port: Optional[int] = None
    tokenizer: Optional[str] = None
    hf_access_token: Optional[str] = None
    vlm_model: Optional[dict] = None
    extract_metadata_json: Optional[bool] = None
    extract_text: Optional[bool] = None
    extract_images: Optional[bool] = None
    extract_tables: Optional[bool] = None
    extract_infographics: Optional[bool] = None
    extract_method: Optional[str] = None
    extract_captions: Optional[bool] = None
    display_metadata: Optional[bool] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    SERVICE_FIELDS = {
        **BasicIngestor.SERVICE_FIELDS,
        "ingest_host": "doc_ingest_host",
        "ingest_port": "doc_ingest_port",
        "tokenizer": "tokenizer",
        "hf_access_token": "hf_access_token",
        "vlm_model": "vlm_model",
        "extract_metadata_json": "extract_metadata_json",
        "extract_text": "extract_text",
        "extract_images": "extract_images",
        "extract_tables": "extract_tables",
        "extract_infographics": "extract_infographics",
        "extract_method": "extract_method",
        "extract_captions": "extract_captions",
        "display_metadata": "display_metadata"
    }

    def __post_init__(self):
        super().__post_init__()
        self.ingestor = "nv_ingest"


@dataclass
@docstring_handler(
    common_params={**INGESTOR_COMMON_PARAMS, **EXTRACTION_COMMON_PARAMS}
)
class UnstructuredIngestor(BasicIngestor):
    """
    DESCRIPTION:
        Document processing configuration using Unstructured.io technology.
        Specializes in extracting structured content from unstructured documents including
        PDFs, HTML, and various text formats. Provides enhanced parsing capabilities
        for complex document layouts and mixed content types.

    RETURNS:
        UnstructuredIngestor instance.

    EXAMPLES:
        # Example 1: Basic Unstructured ingestor with default settings
        >>> from teradatagenai import UnstructuredIngestor
        >>> ingestor = UnstructuredIngestor()

        # Example 2: Unstructured ingestor with table and metadata extraction
        >>> ingestor = UnstructuredIngestor(
        ...     chunk_size=800,
        ...     chunk_overlap=100,
        ...     extract_tables=True,
        ...     extract_metadata_json=True
        ... )

        # Example 3: Full-featured Unstructured ingestor
        >>> ingestor = UnstructuredIngestor(
        ...     chunk_size=1200,
        ...     chunk_overlap=200,
        ...     extract_images=True,
        ...     extract_tables=True,
        ...     extract_metadata_json=True,
        ...     header_height=40,
        ...     footer_height=25
        ... )
    """
    extract_metadata_json: Optional[bool] = None
    extract_images: Optional[bool] = None
    extract_tables: Optional[bool] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    SERVICE_FIELDS = {
        **BasicIngestor.SERVICE_FIELDS,
        "extract_metadata_json": "extract_metadata_json",
        "extract_images": "extract_images",
        "extract_tables": "extract_tables"
    }

    def __post_init__(self):
        super().__post_init__()
        self.ingestor = "unstructured"


@dataclass
@docstring_handler(
    common_params={**COLUMN_PARAMS}
)
class ExtractionSchema(EmbeddingBasedIndex):
    """
    DESCRIPTION:
        Defines the table schema for storing extracted document content during ingestion.
        This class specifies how documents should be processed and stored in a table 
        during file-based ingestion. It allows defining columns for extracted text,
        metadata, document identifiers, and pre-computed embeddings.
    
    PARAMETERS:
        table_name:
            Optional Argument.
            Specifies the name of the table where extracted content will be stored.
            If not provided, a table name will be auto-generated.
            Types: str
            
    RETURNS:
        ExtractionSchema object.
        
    RAISES:
        TypeError, ValueError.
        
    EXAMPLES:
        >>> from teradatagenai import ExtractionSchema, ColumnInfo
        >>> from teradatasqlalchemy.types import INTEGER, VARCHAR, VECTOR
        >>> 
        >>> # Define schema for PDF document extraction
        >>> schema = ExtractionSchema(
        ...     table_name="document_extracts",
        ...     key_columns=[
        ...         ColumnInfo(name="doc_id", datatype=INTEGER(), description="Document ID"),
        ...         ColumnInfo(name="page_num", datatype=INTEGER(), description="Page number")
        ...     ],
        ...     data_columns=[
        ...         ColumnInfo(name="content", datatype=VARCHAR(8192), description="Extracted text")
        ...     ],
        ...     metadata_columns=[
        ...         ColumnInfo(name="filename", datatype=VARCHAR(512), description="Source filename"),
        ...         ColumnInfo(name="file_type", datatype=VARCHAR(32), description="File type")
        ...     ]
        ... )
    """
    table_name: Optional[str] = None
    # Override parent's required object_names to make it optional with default
    object_names: Optional[Union[str, List[str], DataFrame, List[DataFrame]]] = None
    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)
    
    SERVICE_FIELDS = {
        **EmbeddingBasedIndex.SERVICE_FIELDS,
        "table_name": "table_name"  # Add table_name mapping
    }
    
    # Remove object_names from DATAFRAME_FIELDS since we use table_name
    COLUMN_FIELDS = ["key_columns", "data_columns", "metadata_columns", "embedding_columns"]
    DATAFRAME_FIELDS = []  # table_name is just a string, not a DataFrame
    
    def __post_init__(self):
        """Set object_names from table_name for parent class compatibility."""
        if self.table_name:
            self.object_names = self.table_name
    
    def to_dict(self, include_none: bool = False) -> Dict[str, Any]:
        """Convert ExtractionSchema to API format with simplified column structure."""
        result = {}
        
        # Add table_name if present
        if self.table_name is not None:
            result["table_name"] = self.table_name
        
        # Process each column field type with simplified format
        for field_name in self.COLUMN_FIELDS:
            field_value = getattr(self, field_name, None)
            if field_value is not None:
                # Convert to list if not already
                columns = field_value if isinstance(field_value, list) else [field_value]
                
                # Create simplified column format: [{"name": "...", "datatype": "..."}]
                column_list = []
                for col_info in columns:
                    if hasattr(col_info, 'name'):
                        column_dict = {"name": col_info.name}
                        if col_info.datatype is not None:
                            # Convert datatype to lowercase string
                            datatype_str = str(col_info.datatype.compile()).lower()
                            column_dict["datatype"] = datatype_str
                        column_list.append(column_dict)
                
                if column_list:
                    result[field_name] = column_list
        
        return result
