"""
Unpublished work.
Copyright (c) 2026 by Teradata Corporation. All rights reserved.
TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

Primary Owner: aanchal.kavedia@teradata.com
Secondary Owner: sushant.mhambrey@teradata.com

This file implements Ingestor class along with its methods for Teradata 
Vector Store V2 ingestion pipeline.
The pipeline supports both table-based (CONTENT-BASED/EMBEDDING-BASED) and 
file-based (FILE-CONTENT-BASED) Collections through a declarative API.
"""

from typing import Union, Sequence, Dict, Any, Optional, List
import time
import json

from teradatagenai.garbage_collector.garbage_collector import GarbageCollector
from teradatagenai.vector_store.collection import Collection
from teradataml import DataFrame
from teradataml.common.messagecodes import MessageCodes
from teradataml.common.messages import Messages
from teradataml.utils.validators import _Validators
from teradataml.common.constants import HTTPRequest
from teradataml.hyperparameter_tuner.utils import _ProgressBar

from teradatagenai.vector_store.data_classes import (
    ContentBasedIndex, 
    EmbeddingBasedIndex,
    ColumnInfo,
    FileConfig,
    LocalConfig,
    S3Config,
    AzureBlobConfig, 
    GCPConfig,
    BasicIngestor,
    NVIngestor,
    UnstructuredIngestor,
    SearchParams,
    HNSW,
    FLAT,
    IVF_FLAT,
    Serializable,
    ExtractionSchema
)
from teradatagenai.common.constants import CollectionType
from teradatagenai.common.collection_docstring_params import AUTH_PARAMS, CREATE_COMMON_PARAMS, MODEL_PARAMS, SEARCH_PARAMS, UPDATE_PARAMS, FILE_DOCUMENTS_COMMON_PARAMS
from teradatagenai.common.collection_api_schema import build_request
from teradatagenai.common.utils import GenAIUtilFuncs
from teradatagenai.llm.llm import TeradataAI
from teradatagenai.utils.doc_decorator import docstring_handler
from teradatagenai.utils.doc_validator import validate_docstring_kwargs


class Ingestor:
    """
    Stepwise pipeline orchestrator for creating and populating File-Based/Content-Based Collections.
    
    DESCRIPTION:
        Provides a fluent, declarative API for building ingestion pipelines that can handle
        both table-based and file-based Collection creation and population. The pipeline
        is configured through method chaining and executed via run().
        
        Typical Usage Patterns:
        
        Table-based (CONTENT_BASED):
            ing = (
                Ingestor("customer_collection", 
                         type=CollectionType.CONTENT_BASED,
                         target_database="analytics_db")
                .load(index=ContentBasedIndex(object_names="customers", 
                                              data_columns=[...]))
                .embed(embedding_model=TeradataAI(...))
                .upsert(indexing_algorithm=HNSW(...))
            )
            result = ing.run()
        
        File-based (FILE_CONTENT_BASED):
            ing = (
                Ingestor("docs_collection",
                         type=CollectionType.FILE_CONTENT_BASED,
                         target_database="analytics_db")
                .extract(text=True, images=True, tables=True)
                .files(files=S3Config(...),
                       type="pdf",
                       extraction_schema=ExtractionSchema(...),
                       ingestor=NVIngestor(...))
                .embed(embedding_model=TeradataAI(...))
                .upsert(indexing_algorithm=FLAT(...))
            )
            result = ing.run()
        
        The pipeline stages are:
        1. extract() - Configure extraction options (file-based only)
        2. files() or load() - Configure data sources
        3. embed() - Configure embedding generation
        4. upsert() - Configure indexing algorithm
        5. run() - Execute the complete pipeline
    
    RETURNS:
        Ingestor instance for method chaining.
        
    RAISES:
        ValueError: If invalid configuration is provided.
        RuntimeError: If pipeline execution fails.
    """
    
    # Success status messages for different operations
    SUCCESS_STATUS_MESSAGES = {
        "create_collection": ["initialized"],
        "ingest": ["ingested", "ingested_partially"],
        "load_data": ["create_load_data_completed"],
        "generate_embeddings": ["create_generating_embeddings_completed","generate_embeddings_completed"],
        "create_index": ["create_index_completed", "ready"],
        "update": ["ready"]
    }
    
    # Define failure status messages to properly detect operation failures
    FAILURE_STATUS_MESSAGES = {
        "create_collection": ["create_failed", "initializing_failed"],
        "ingest": ["ingestion_failed", "upload_failed"],
        "load_data": ["load_data_failed", "create_load_data_failed"],
        "generate_embeddings": ["create_generating_embeddings_failed", "update_generating_embeddings_failed"],
        "create_index": ["create_index_failed", "create_generating_index_failed"],
        "update": ["update_failed", "update_generating_index_failed"]
    }
    
    @docstring_handler(
        common_params={**AUTH_PARAMS, **CREATE_COMMON_PARAMS},
        exclude_params=['index']
    )
    def __init__(self, name: str, type: CollectionType = CollectionType.FILE_CONTENT_BASED, 
                 target_database: Optional[str] = None, description: Optional[str] = None, 
                 auth_data: Optional[Any] = None, **kwargs: Any):
        """
        Initialize Ingestor pipeline configuration.
        
        DESCRIPTION:
            Creates a new Ingestor instance with the specified collection configuration.
            The pipeline is configured through method chaining and executed via run().

        PARAMETERS:
            name:
                Required Argument.
                Specifies the name of the Collection to be created.
                Types: str
        
        RETURNS:
            None.
            
        RAISES:
            ValueError: If invalid configuration is provided.

        EXAMPLES:

        >>> # Example 1: Initialize file-based ingestor with basic configuration.
        >>> Ingestor("my_collection", type=CollectionType.FILE_CONTENT_BASED, target_database="analytics_db")
        
        >>> # Example 2: Initialize content-based ingestor with basic configuration.
        >>> Ingestor("my_collection", type=CollectionType.CONTENT_BASED, target_database="analytics_db")

        """
        # Store constructor parameters
        self.name = name
        self.type = type
        self.target_database = target_database
        self.description = description
        self.auth_data = auth_data
        
        # Validate required parameters first
        arg_info_matrix = [
            ["name", name, False, str, True],  # Required
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        
        # Validate parameters using docstring params validation
        validate_docstring_kwargs(
            {"name": name, "type": type, "target_database": target_database, 
             "description": description, "auth_data": auth_data, **kwargs},
            [AUTH_PARAMS, CREATE_COMMON_PARAMS]
        )
        
        # Pre-build basic collection parameters for API calls
        self._basic_collection_params = {
            "type": self.type.value,
            "target_database": self.target_database,
            "description": self.description,
            **kwargs
        }
        
        # Initialize pipeline state - not user-configurable
        self.collection = None  # Will be Collection instance
        self._extract_config = {}
        self._file_config = {}
        self._load_index = None
        # Consolidated configuration dictionaries for cleaner API calls
        self._embedding_config = {}  # Will contain embedding_model, ignore_embedding_errors
        self._upsert_config = {}     # Will contain all upsert() parameters including kwargs
        self._extra_create_params = {}
        self._unused_extract_params = []  # Track extract params not applicable to selected ingestor
        self._upsert_called = False  # Track if upsert() was called
        
    # ========================================================================
    # STAGE 1: extract() - Configure extraction options (file-based only)
    # ========================================================================
    
    def extract(
        self,
        metadata_json: Optional[bool] = None,
        text: Optional[bool] = None,
        images: Optional[bool] = None,
        tables: Optional[bool] = None,
        infographics: Optional[bool] = None,
        method: Optional[str] = None,
        captions: Optional[bool] = None,
        display_metadata: Optional[bool] = None,
    ) -> "Ingestor":
        """
        DESCRIPTION:
            Configure extraction options for file-based ingestion pipelines.
            Sets extraction parameters that will be applied during file processing.
            The available options depend on the ingestor type selected in files():
            
            - BasicIngestor: Only supports basic text chunking (no extraction options)
            - NVIngestor: Supports all extraction options listed below
            - UnstructuredIngestor: Supports metadata_json, images, and tables only
            Note:
                This method is only applicable for file-based Collections 
                (FILE_CONTENT_BASED, FILE_EMBEDDING_BASED).
        
        PARAMETERS:
            metadata_json:
                Optional Argument.
                Specifies whether to extract document metadata as JSON.
                Supported by: NVIngestor, UnstructuredIngestor
                Types: bool
                Default Value: False
                
            text:
                Optional Argument.
                Specifies whether to extract text content.
                Supported by: NVIngestor only
                Types: bool
                Default Value: False
                
            images:
                Optional Argument.
                Specifies whether to extract and process images.
                Supported by: NVIngestor, UnstructuredIngestor
                Types: bool
                Default Value: False
                
            tables:
                Optional Argument.
                Specifies whether to extract and process tables.
                Supported by: NVIngestor, UnstructuredIngestor
                Types: bool
                Default Value: False
                
            infographics:
                Optional Argument.
                Specifies whether to extract infographics.
                Supported by: NVIngestor only
                Types: bool
                Default Value: False
                
            method:
                Optional Argument.
                Specifies the extraction method to use.
                Supported by: NVIngestor only
                Types: str
                Permitted Values: "pdfium", "pymupdf", "unstructured"
                Default Value: None
                
            captions:
                Optional Argument.
                Specifies whether to extract image captions.
                Supported by: NVIngestor only
                Types: bool
                Default Value: False
                
            display_metadata:
                Optional Argument.
                Specifies whether to extract display metadata.
                Supported by: NVIngestor only
                Types: bool
                Default Value: False
        
        RETURNS:
            Ingestor instance for method chaining.
            
        RAISES:
            ValueError: If invalid extraction parameters provided.
            
        EXAMPLES:
            >>> # Configure extraction for comprehensive document processing
            >>> ingestor = (
            ...     Ingestor("my_collection", type=CollectionType.FILE_CONTENT_BASED,
            ...     target_database="analytics_db")
            ...     .extract(text=True, images=True, tables=True, metadata_json=True)
            ...     .files(...)
            ... )
            
            >>> # Configure extraction with specific method
            >>> ingestor = (
            ...     Ingestor("pdf_collection", type=CollectionType.FILE_CONTENT_BASED, 
            ...     target_database="analytics_db")
            ...     .extract(text=True, method="pymupdf", captions=True)
            ...     .files(...)
            ... )
        """   

        if self.type not in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]:
            raise ValueError(f"extract() is only applicable for file-based collections, got {self.type}") 
        
        # Validate parameters using docstring params validation
        # Create temporary parameter dict for validation
        extract_params = {
            "metadata_json": {"types": "bool"},
            "text": {"types": "bool"},
            "images": {"types": "bool"},
            "tables": {"types": "bool"},
            "infographics": {"types": "bool"},
            "method": {"types": "str"},
            "captions": {"types": "bool"},
            "display_metadata": {"types": "bool"},
        }
        validate_docstring_kwargs(
            {"metadata_json": metadata_json, "text": text, "images": images, 
             "tables": tables, "infographics": infographics, "method": method,
             "captions": captions, "display_metadata": display_metadata},
            [extract_params]
        )
        
        # Build configuration dictionary, filtering out None values
        config_updates = {}
        for param_name, value in {
            "extract_metadata_json": metadata_json,
            "extract_text": text, 
            "extract_images": images,
            "extract_tables": tables,
            "extract_infographics": infographics,
            "extract_method": method,
            "extract_captions": captions,
            "display_metadata": display_metadata,
        }.items():
            if value is not None:
                config_updates[param_name] = value
        
        self._extract_config.update(config_updates)
        return self
    
    # ========================================================================
    # STAGE 2a: files() - Configure file-based ingestion
    # ========================================================================
    
    @docstring_handler(
        common_params={**FILE_DOCUMENTS_COMMON_PARAMS}
    )
    def files(
        self,
        files: Optional[Union[LocalConfig, S3Config, AzureBlobConfig, GCPConfig]] = None,
        ingestor: Optional[Union[BasicIngestor, NVIngestor, UnstructuredIngestor]] = None,
        extraction_schema: Optional[ExtractionSchema] = None,
        **kwargs: Any,
    ) -> "Ingestor":
        """
        Configure file-based ingestion sources and processing options.
        
        DESCRIPTION:
            Specifies the files to be ingested and how they should be processed.
            Supports local files, cloud storage, and various file formats.
            This method is only applicable for file-based Collection types.
        
        PARAMETERS:
            files:
                Optional Argument.
                Specifies the file sources to ingest and their configuration. Can be:
                - LocalConfig: For local files with file patterns and common config
                - S3Config: For Amazon S3 storage with built-in common config
                - AzureBlobConfig: For Azure Blob storage with built-in common config
                - GCPConfig: For Google Cloud Storage with built-in common config
                Each config includes file type, delimiter, and overwrite options.
                Types: LocalConfig, S3Config, AzureBlobConfig, GCPConfig
        
        RETURNS:
            Ingestor instance for method chaining.
            
        RAISES:
            ValueError: If collection type is not file-based or invalid parameters provided.
            
        EXAMPLES:
            >>> # Local file ingestion
            >>> local_config = LocalConfig(
            ...     files="/path/to/docs/*.pdf",
            ...     type="pdf",
            ...     overwrite_files=False
            ... )
            >>> ingestor = (
            ...     Ingestor("local_docs", type=CollectionType.FILE_CONTENT_BASED,
            ...               target_database="analytics_db")
            ...     .files(files=local_config, 
            ...            ingestor=BasicIngestor(chunk_size=1024))
            ... )
            
            >>> # S3 file ingestion with NV processing
            >>> s3_config = S3Config(
            ...     bucket="my-bucket",
            ...     key="documents/*.pdf",
            ...     region_name="us-west-2",
            ...     type="pdf",
            ...     overwrite_files=True,
            ...     aws_access_key_id="<access_key_id>",
            ...     aws_secret_access_key="<access_key>",
            ...     aws_session_token="<session_token>"
            ... )
            >>> ingestor = (
            ...     Ingestor("s3_docs", type=CollectionType.FILE_CONTENT_BASED, 
            ...               target_database="analytics_db")
            ...     .files(files=s3_config,
            ...            ingestor=NVIngestor(extract_images=True, extract_tables=True))
            ... )
        """
        # Validate required parameters first
        from teradatagenai.vector_store.data_classes import LocalConfig
        arg_info_matrix = [
            ["files", files, False, (LocalConfig, S3Config, AzureBlobConfig, GCPConfig), True],  # Required
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        
        # Validate parameters using docstring params validation
        validate_docstring_kwargs(
            {"ingestor": ingestor, "extraction_schema": extraction_schema, **kwargs},
            [FILE_DOCUMENTS_COMMON_PARAMS]
        )
        
        # Initialize list to track unused extract parameters
        unused_extract_params = []
        
        # Merge extract configuration into ingestor if present
        if ingestor and hasattr(self, '_extract_config') and self._extract_config:
            for param_name, param_value in self._extract_config.items():
                # Check if this parameter is applicable to the current ingestor type
                if hasattr(ingestor, param_name):
                    # Get current value from ingestor
                    current_value = getattr(ingestor, param_name, None)
                    
                    # If ingestor doesn't have this parameter set (None), update it with extract config value
                    if current_value is None:
                        setattr(ingestor, param_name, param_value)
                else:
                    # Parameter not applicable to this ingestor type
                    unused_extract_params.append(f"{param_name}={param_value}")
        
        # Store unused extract parameters for later reporting
        self._unused_extract_params = unused_extract_params
        
        # Store file configuration
        self._file_config = {
            "files": files,
            "ingestor": ingestor,
            "extraction_schema": extraction_schema,
            **kwargs,
        }
        return self
    
    # ========================================================================
    # STAGE 2b: load() - Configure table-based ingestion (alternative to files)
    # ========================================================================
    
    def load(
        self,
        index: Union[ContentBasedIndex, EmbeddingBasedIndex],
        **kwargs: Any,
    ) -> "Ingestor":
        """
        DESCRIPTION:
            Configure table-based ingestion for CONTENT_BASED or EMBEDDING_BASED Collections.
            Specifies the data sources and column mappings for table-based ingestion.
            This is an alternative to files() for Collections that ingest from existing
            database tables rather than external files.
        
        PARAMETERS:
            index:
                Required Argument.
                Specifies the index configuration describing:
                - object_names: Source table(s) or DataFrame(s)
                - key_columns: Key column definitions
                - data_columns: Text content column definitions
                - metadata_columns: Metadata column definitions
                - embedding_columns: Pre-computed embedding columns (for EMBEDDING_BASED)
                Types: ContentBasedIndex, EmbeddingBasedIndex
        
        RETURNS:
            Ingestor instance for method chaining.
            
        RAISES:
            ValueError: If collection type is not table-based or invalid index provided.
            
        EXAMPLES:
            >>> # Content-based table ingestion
            >>> content_index = ContentBasedIndex(
            ...     object_names=["customer_reviews"],
            ...     key_columns=[ColumnInfo(name="review_id", datatype=INTEGER())],
            ...     data_columns=[ColumnInfo(name="review_text", datatype=VARCHAR(4000))]
            ... )
            >>> ingestor = (
            ...     Ingestor("reviews_collection", type=CollectionType.CONTENT_BASED)
            ...     .load(index=content_index)
            ... )
            
            >>> # Embedding-based table ingestion
            >>> embedding_index = EmbeddingBasedIndex(
            ...     object_names=["product_embeddings"],
            ...     key_columns=[ColumnInfo(name="product_id", datatype=INTEGER())],
            ...     embedding_columns=[ColumnInfo(name="embedding_vector", datatype=VECTOR())]
            ... )
            >>> ingestor = (
            ...     Ingestor("products_collection", type=CollectionType.EMBEDDING_BASED)
            ...     .load(index=embedding_index)
            ... )
        """
        # Validate that this is a table-based collection type
        table_based_types = [CollectionType.CONTENT_BASED, CollectionType.EMBEDDING_BASED]
        
        # Validate required parameters first
        arg_info_matrix = [
            ["index", index, False, (ContentBasedIndex, EmbeddingBasedIndex), True],  # Required
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        _Validators._validate_function_arguments(arg_info_matrix)
        
        # For EMBEDDING_BASED collections, ensure we have an EmbeddingBasedIndex
        if self.type == CollectionType.EMBEDDING_BASED and not isinstance(index, EmbeddingBasedIndex):
            raise ValueError("EMBEDDING_BASED collections require an EmbeddingBasedIndex")
        
        self._load_index = index
        
        # Store any additional configuration
        if kwargs:
            self._file_config.update(kwargs)
        
        return self
    
    # ========================================================================
    # STAGE 3: embed() - Configure embedding generation
    # ========================================================================
    
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, **MODEL_PARAMS},
        include_params=['embedding_model', 'ignore_embedding_errors']
    )
    def embed(
        self,
        embedding_model: TeradataAI,
        ignore_embedding_errors: bool = False,
        **kwargs: Any,
    ) -> "Ingestor":
        """
        DESCRIPTION:
            Configure embedding model and generation options for the pipeline.
            Specifies the embedding model and related configuration for generating
            vector embeddings from text content. This stage is typically required
            for CONTENT_BASED and FILE_CONTENT_BASED Collections.
        
        RETURNS:
            Ingestor instance for method chaining.
            
        RAISES:
            TypeError: If embedding_model is not a TeradataAI instance.
            
        EXAMPLES:
            >>> # Configure embedding with error handling
            >>> embedding_model = TeradataAI(
            ...     model_name="<model_name>",
            ...     api_base="<model_endpoint>"
            ... )
            >>> ingestor = (
            ...     Ingestor("my_collection", type=CollectionType.CONTENT_BASED)
            ...     .load(index=content_index)
            ...     .embed(embedding_model=embedding_model, 
            ...            ignore_embedding_errors=True)
            ... )
        """
        # Validate required parameters first
        arg_info_matrix = [
            ["embedding_model", embedding_model, False, TeradataAI, True],  # Required
        ]
        _Validators._validate_missing_required_arguments(arg_info_matrix)
        
        # Validate parameters using docstring params validation
        validate_docstring_kwargs(
            {"embedding_model": embedding_model, "ignore_embedding_errors": ignore_embedding_errors, **kwargs},
            [CREATE_COMMON_PARAMS],
            model_params_names=['embedding_model']
        )
        
        # Store in consolidated embedding configuration dictionary
        self._embedding_config = {
            "embedding_model": embedding_model,
            "ignore_embedding_errors": ignore_embedding_errors
        }
        
        # Store any additional embedding-related parameters
        if kwargs:
            self._extra_create_params.update(kwargs)
        
        return self
    
    # ========================================================================
    # STAGE 4: upsert() - Configure indexing algorithm and finalization
    # ========================================================================
    
    @docstring_handler(
        common_params={**CREATE_COMMON_PARAMS, 'update_style' : UPDATE_PARAMS['update_style'], **MODEL_PARAMS},
        exclude_params=['name', 'type', 'index', 'description', 'target_database']
    )
    def upsert(
        self,
        indexing_algorithm: Optional[Union[HNSW, FLAT, IVF_FLAT]] = None,
        use_simd: Optional[bool] = None,
        search_params: Optional[SearchParams] = None,
        **kwargs: Any,
    ) -> "Ingestor":
        """
        DESCRIPTION:
            Configure indexing algorithm and finalize pipeline configuration.
            Specifies the vector indexing algorithm and related parameters for
            optimizing similarity search performance. This is the final configuration
            stage before pipeline execution.
        
        RETURNS:
            Ingestor instance for method chaining.
            
        RAISES:
            TypeError: If invalid indexing algorithm provided.
            
        EXAMPLES:
            >>> # Configure HNSW indexing with custom parameters
            >>> hnsw_config = HNSW(
            ...     metric="COSINE",
            ...     ef_construction=64,
            ...     num_connpernode=32
            ... )
            >>> ingestor = (
            ...     Ingestor("my_collection", type=CollectionType.CONTENT_BASED)
            ...     .load(index=content_index)
            ...     .embed(embedding_model=embedding_model)
            ...     .upsert(indexing_algorithm=hnsw_config, use_simd=True)
            ... )
            
            >>> # Configure with search parameters
            >>> search_config = SearchParams(top_k=10, ef_search=64)
            >>> ingestor = (
            ...     Ingestor("my_collection", type=CollectionType.CONTENT_BASED)
            ...     .load(index=content_index)
            ...     .embed(embedding_model=embedding_model)
            ...     .upsert(indexing_algorithm=FLAT(), search_params=search_config)
            ... )

            >>> # Configure ingestor pipeline with file-based ingestion and indexing. 
            ... ingestor = (
            ...     Ingestor("s3_docs", type=CollectionType.FILE_CONTENT_BASED, target_database="analytics_db")
            ...     .files(files=s3_config,
            ...            ingestor=NVIngestor(extract_images=True, extract_tables=True))
            ...     .upsert(indexing_algorithm=FLAT(), search_params=search_config)
            ... )
        """
        # Validate parameters using docstring params validation
        validate_docstring_kwargs(
            {"indexing_algorithm": indexing_algorithm, "use_simd": use_simd, 
             "search_params": search_params, **kwargs},
            [CREATE_COMMON_PARAMS, UPDATE_PARAMS, MODEL_PARAMS]
        )
        
        # Store all create parameters in consolidated configuration dictionary
        config_updates = {}
        if indexing_algorithm is not None:
            config_updates["indexing_algorithm"] = indexing_algorithm
        if use_simd is not None:
            config_updates["use_simd"] = use_simd
        if search_params is not None:
            config_updates["search_params"] = search_params
        
        # Add all extra kwargs directly without transformation
        if kwargs:
            config_updates.update(kwargs)
            
        # Update the consolidated upsert configuration
        self._upsert_config.update(config_updates)
        
        # Mark that upsert() was called, even if no parameters were provided
        self._upsert_called = True
        
        return self
    
    # ========================================================================
    # STAGE 5: run() - Execute the configured pipeline
    # ========================================================================
    
    def run(self) -> Dict[str, Any]:
        """
        Execute the configured ingestion pipeline.
        
        DESCRIPTION:
            Orchestrates the execution of the complete ingestion pipeline based on
            the configuration built through the fluent API. The execution flow depends
            on the collection type and configured stages:
            
            File-based pipeline (FILE_CONTENT_BASED):
            1. Create Collection (create REST API)
            2. Execute ingest operation (file extraction and processing)
            3. Execute load-data operation (load-data REST API) 
            4. Generate embeddings (generate-embeddings REST API if embedding model configured)
            5. Create or update index (create-index REST API with indexing algorithm)
            
            Table-based pipeline (CONTENT_BASED/EMBEDDING_BASED):
            1. Create Collection (create REST API)
            2. Load data from specified tables/DataFrames (load-data REST API)
            3. Generate embeddings (generate-embeddings REST API for CONTENT_BASED)
            4. Create index (create-index REST API with specified algorithm)
        
        RETURNS:
            Dict[str, Any]: Pipeline execution results containing:
                - status: Execution status and any errors
                - collection: The created/updated Collection instance
                - operation_details: Details from each pipeline stage
                
        RAISES:
            ValueError: If pipeline configuration is invalid or incomplete.
            RuntimeError: If pipeline execution fails at any stage.
            
        EXAMPLES:
            >>> # Execute file-based pipeline.
            >>> result = (
            ...     Ingestor("docs_collection", type=CollectionType.FILE_CONTENT_BASED, target_database="analytics_db")
            ...     .extract(text=True, images=True)
            ...     .files(files=s3_config, ingestor=NVIngestor())
            ...     .embed(embedding_model=embedding_model)
            ...     .upsert(indexing_algorithm=HNSW())
            ...     .run()
            ... )
            >>> 
            >>> if result["status"].get("success"):
            ...     collection = result["collection"]
            ...     print(f"Created collection: {collection.name}")
            
            >>> # Execute table-based pipeline.
            >>> result = (
            ...     Ingestor("customers_collection", type=CollectionType.CONTENT_BASED)
            ...     .load(index=content_index)
            ...     .embed(embedding_model=embedding_model)
            ...     .upsert(indexing_algorithm=FLAT())
            ...     .run()
            ... )
        """
        # Initialize results structure
        results: Dict[str, Any] = {
            "status": {"success": False, "errors": [], "warnings": []},
            "collection": None,
            "operation_details": {},
        }
        
        try:
            # Step 1: Create Collection instance and validate configuration
            print("Initializing collection pipeline...")
            temp_collection = Collection(name=self.name, auth_data=self.auth_data)
            
            # Check collection existence and validate configuration
            collection_exists = temp_collection.exists
            
            # Only enforce files/load requirement for new collections
            if not collection_exists:
                if not (self._file_config.get("files") or self._load_index):
                    results["status"]["errors"].append("New collections require either files() or load() configuration")
                    results["status"]["success"] = False
                    return results
                
                # Validate file-based configuration for new collections
                if self._file_config.get("files"):
                    if self.type not in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]:
                        results["status"]["errors"].append(f"files() configuration requires file-based collection type, got {self.type}")
                        results["status"]["success"] = False
                        return results

                # Validate table-based configuration for new collections
                if self._load_index:
                    if self.type not in [CollectionType.CONTENT_BASED, CollectionType.EMBEDDING_BASED]:
                        results["status"]["errors"].append(f"load() configuration requires table-based collection type, got {self.type}")
                        results["status"]["success"] = False
                        return results

            # Step 3: Create Collection (only if it doesn't exist)
            print("Creating collection...")
            create_response = self._execute_create_collection(temp_collection, results)
            if not create_response.get("success", False):
                return results
            results["operation_details"]["create_collection"] = create_response

            # Step 4: Execute data ingestion operations (only if data source is configured)
            if self._file_config and self._file_config.get("files"):
                print("Processing files...")
                ingest_response = self._execute_ingest_operation(temp_collection, results)
                if not ingest_response.get("success", False):
                    return results
                results["operation_details"]["ingest"] = ingest_response

            # Step 5: Load data if load() was configured (for table-based collections)
            if self._load_index:
                print("Loading table data...")
                load_response = self._execute_load_data(temp_collection, results)
                if not load_response.get("success", False):
                    return results
                results["operation_details"]["load_data"] = load_response

            # Step 6: Generate embeddings if embed() was configured
            if self._embedding_config:
                print("Generating embeddings...")
                embed_response = self._execute_generate_embeddings(temp_collection, results)
                if not embed_response.get("success", False):
                    return results
                results["operation_details"]["generate_embeddings"] = embed_response

            # Step 7: Create/Update index if create() was configured
            if self._upsert_called:
                if self._upsert_config:
                    print("Creating index with custom settings...")
                else:
                    print("Creating index with default settings...")
                index_response = self._execute_create_index(temp_collection, results)
                if not index_response.get("success", False):
                    return results
                results["operation_details"]["create_index"] = index_response
            
            # Add warnings for unused extract parameters
            if hasattr(self, '_unused_extract_params') and self._unused_extract_params:
                warning_msg = f"Some extract() parameters were not applicable to the selected ingestor: {', '.join(self._unused_extract_params)}"
                results["status"]["warnings"].append(warning_msg)
                print(f"Warning: {warning_msg}")

            if self._file_config.get("files") and not self._file_config.get("ingestor"):
                warning_msg = "No ingestor specified; BasicIngestor() will be used by default"
                results["status"]["warnings"].append(warning_msg)
            
            # Finalize results
            self.collection = temp_collection
            results["collection"] = self.name
            results["status"]["success"] = True
            results["status"]["message"] = "Pipeline executed successfully"
            
            print(f"Pipeline completed successfully! Operations: {', '.join(results['operation_details'].keys())}")
                
        except Exception as e:
            results["status"]["errors"].append(f"Pipeline execution failed: {str(e)}")
            results["status"]["success"] = False
            print(f"Pipeline failed: {str(e)}")
        
        return results
    
    # ========================================================================
    # Private helper methods for pipeline execution
    # ========================================================================

    def _wait_for_operation_completion(self, temp_collection, operation_name: str, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Wait for an operation to complete by polling the status API with progress indication.
        
        DESCRIPTION:
            Continuously polls the collection status API to monitor operation progress
            and completion. Provides visual feedback through a progress bar and handles
            timeout scenarios. This method is used internally by pipeline execution
            methods to ensure operations complete before proceeding to the next stage.
            
            The method polls every 5 seconds for up to 5 minutes (60 retries) and
            checks for success indicators specific to each operation type.
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making status API calls.
                Types: Collection
                
            operation_name:
                Required Argument.
                Name of the operation being monitored (e.g., "ingest", "create_collection").
                Used for progress display and success message lookup.
                Types: str
                
            results:
                Required Argument.
                Results dictionary to update with errors if operation fails.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Operation completion result containing:
                - success: Boolean indicating operation success/failure
                - status_response: Final status response from the API
                - error: Error message (if operation failed)
                - warnings: Any warnings encountered during operation
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        max_retries = 100  # Maximum 5 minutes with 5-second intervals
        retry_count = 0
        
        print(f"Starting {operation_name.replace('_', ' ')} operation...")
        
        # Create a progress bar for this operation following the llm.py pattern
        progress_bar = None
        try:
            progress_bar = _ProgressBar(jobs=100, prefix=f"Processing {operation_name.replace('_', ' ')}", verbose=2)
        except Exception:
            progress_bar = None
        
        while retry_count < max_retries:
            try:
                status_response = temp_collection.status(return_type="json")
                
                # Check if operation is still in progress
                needs_retry = False
                if hasattr(status_response, 'get') and status_response.get('retry_after'):
                    needs_retry = True
                elif hasattr(status_response, 'retry_after'):
                    needs_retry = True
                
                if needs_retry:
                    # Update progress bar to show ongoing activity
                    if progress_bar:
                        try:
                            progress_bar.update()
                        except Exception:
                            progress_bar = None
                    
                    time.sleep(5)
                    retry_count += 1
                    continue
                
                # Operation completed - finish the progress bar following llm.py pattern
                if progress_bar:
                    try:
                        # Set to 99 and then do final update with completion message
                        progress_bar.completed_jobs = 99
                        progress_bar.update(msg=f"{operation_name.replace('_', ' ').title()} completed.")
                        print()  # Clean newline after progress bar
                    except Exception:
                        print()  # Still add newline even if progress bar fails
                else:
                    print()  # Add newline if no progress bar
                
                # Check for success or failure with optimized string matching
                status_text = status_response['collection_status'].lower()
                success_messages = self.SUCCESS_STATUS_MESSAGES.get(operation_name, [])
                failure_messages = self.FAILURE_STATUS_MESSAGES.get(operation_name, [])
                
                # Fast failure check first (most important for user's case)
                operation_failed = any(msg.lower() in status_text for msg in failure_messages)
                if operation_failed:
                    error_msg = f"{operation_name.replace('_', ' ').title()} failed with status: {status_response['collection_status']}"
                    print(f"Error: {error_msg}")
                    # Get error details with minimal processing
                    error_details = self._get_operation_error_details(temp_collection, operation_name, status_response)
                    if error_details:
                        print(f"   Details: {error_details}")
                    results["status"]["errors"].append(error_msg + (f" | {error_details}" if error_details else ""))
                    return {"success": False, "error": error_msg, "status_response": status_response}
                
                # Success check
                operation_successful = any(msg.lower() in status_text for msg in success_messages)
                if operation_successful:
                    print(f"{operation_name.replace('_', ' ').title()} completed successfully")
                    return {"success": True, "status_response": status_response}
                else:
                    print(f"Warning: {operation_name.replace('_', ' ').title()} completed with warnings")
                    return {"success": True, "status_response": status_response, "warnings": ["Operation completed but success status unclear"]}
                    
            except Exception as e:
                error_msg = f"Error checking status for {operation_name}: {str(e)}"
                results["status"]["errors"].append(error_msg)
                if progress_bar:
                    try:
                        # Complete the progress bar on error following llm.py pattern
                        progress_bar.completed_jobs = 99
                        progress_bar.update(msg=f"{operation_name.replace('_', ' ').title()} failed.")
                        print()  # Clean newline
                    except Exception:
                        print()  # Clean newline even if progress bar fails
                return {"success": False, "error": error_msg}
        
        # Timeout case
        timeout_msg = f"{operation_name.replace('_', ' ').title()} timed out after {max_retries * 5} seconds"
        if progress_bar:
            try:
                # Complete the progress bar on timeout following llm.py pattern
                progress_bar.completed_jobs = 99
                progress_bar.update(msg=f"{operation_name.replace('_', ' ').title()} timed out.")
                print()  # Clean newline
            except Exception:
                print()  # Clean newline even if progress bar fails
        print(f"Timeout: {timeout_msg}")
        results["status"]["errors"].append(timeout_msg)
        return {"success": False, "error": timeout_msg}
    
    def _get_operation_error_details(self, temp_collection, operation_name: str, status_response: Dict[str, Any]) -> Optional[str]:
        """
        Retrieve error details from status response with minimal processing.
        """
        try:
            # Quick check for common error fields - no special processing per operation
            details = [
                status_response.get('error_message'),
                status_response.get('message'), 
                status_response.get('details')
            ]
            
            # Filter out None/empty values and join
            error_details = [str(d) for d in details if d]
            return " | ".join(error_details) if error_details else None
            
        except Exception:
            # Fail silently - don't let error detail retrieval break main flow
            return None
    
    def _execute_ingest_operation(self, temp_collection, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the ingest operation for file-based collections.
        
        DESCRIPTION:
            Orchestrates the file ingestion process for file-based collections by:
            1. Building the ingest API request from file configuration
            2. Preparing multipart form data for file uploads
            3. Making the ingest API call with proper file handling
            4. Waiting for the operation to complete
            
            This method handles both local files and cloud storage sources,
            managing file uploads and processing parameters appropriately.
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making API calls.
                Types: Collection
                
            results:
                Required Argument.
                Results dictionary to update with operation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Ingest operation result containing:
                - success: Boolean indicating operation success/failure
                - api_response: Response from the ingest API call
                - status_result: Result from operation completion polling
                - error: Error message (if operation failed)
                - details: Additional operation details
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        try:
            # Build the ingest request
            ingest_request = build_request("ingest", self._file_config)
            
            # Extract files from JSON payload for multipart upload (if present)
            files_for_request = ingest_request.pop("files", None)
            
            # Prepare request data (JSON payload only)
            request_data = {"docs_request_json": json.dumps(ingest_request)}
            
            # Add overwrite parameters as separate multipart fields
            files_config = self._file_config.get("files")
            if files_config and hasattr(files_config, 'overwrite_files') and files_config.overwrite_files is not None:
                request_data["overwrite_files"] = files_config.overwrite_files
            if files_config and hasattr(files_config, 'overwrite_objects') and files_config.overwrite_objects is not None:
                request_data["overwrite_objects"] = files_config.overwrite_objects
            
            # Call the ingest API endpoint with proper multipart form data
            response = temp_collection._make_request(
                http_method=HTTPRequest.PUT,  # Use PUT as per the service example
                endpoint="ingest",
                response_key=None,
                return_type="json",
                collection_name=self.name,
                data=request_data,
                files=files_for_request
            )
            
            # Wait for ingest operation to complete
            completion_result = self._wait_for_operation_completion(temp_collection, "ingest", results)
            if not completion_result["success"]:
                error_msg = completion_result.get("error", "Unknown ingest error")
                print(f"Ingest operation failed: {error_msg}")
                results["status"]["success"] = False
                return {"success": False, "error": "Ingest operation failed", "details": completion_result}
            
            # Operation succeeded
            return {"success": True, "api_response": response, "status_result": completion_result}
                
        except Exception as e:
            error_msg = f"Failed to execute ingest operation: {str(e)}"
            print(f"Ingest operation failed: {str(e)}")
            results["status"]["errors"].append(error_msg)
            results["status"]["success"] = False
            return {"success": False, "error": error_msg}
    
    def _validate_pipeline_configuration(self, results: Dict[str, Any]) -> None:
        """
        Validate that the pipeline configuration is valid and complete.
        
        DESCRIPTION:
            Performs comprehensive validation of the pipeline configuration to ensure:
            - Required data sources are configured (files or load index)
            - Collection type matches the configured data source type
            - File-based collections have proper file configuration
            - Table-based collections have proper load index configuration
            
            This method is called before pipeline execution to catch configuration
            errors early and provide clear error messages.
        
        PARAMETERS:
            results:
                Required Argument.
                Results dictionary to update with validation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            None: Updates the results dictionary with validation status.
                
        RAISES:
            ValueError: Configuration validation errors are caught and stored in results.
        """
        try:
            # Validate that we have either file config or load index
            if not (self._file_config.get("files") or self._load_index):
                raise ValueError("Pipeline must have either files() or load() configuration")
            
            # For file-based collections, validate file config
            if self._file_config.get("files"):
                if self.type not in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]:
                    raise ValueError(f"files() configuration requires file-based collection type, got {self.type}")
            
            # For table-based collections, validate load index
            if self._load_index:
                if self.type not in [CollectionType.CONTENT_BASED, CollectionType.EMBEDDING_BASED]:
                    raise ValueError(f"load() configuration requires table-based collection type, got {self.type}")
            
            results["status"]["success"] = True
            
        except Exception as e:
            results["status"]["errors"].append(f"Pipeline configuration validation failed: {str(e)}")
            results["status"]["success"] = False
    
    def _execute_create_collection(self, temp_collection, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the create collection API call.
        
        DESCRIPTION:
            Creates a new collection using the REST API if it doesn't already exist.
            This method:
            1. Checks if the collection already exists
            2. Builds the creation request from basic collection parameters
            3. Makes the create collection API call
            4. Waits for the creation operation to complete
            
            If the collection already exists, the operation is skipped with a success status.
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making API calls and existence checks.
                Types: Collection
                
            results:
                Required Argument.
                Results dictionary to update with operation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Create collection operation result containing:
                - success: Boolean indicating operation success/failure
                - api_response: Response from the create collection API call
                - status_result: Result from operation completion polling
                - error: Error message (if operation failed)
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        try:
            # Check if collection already exists
            if temp_collection.exists:
                return {
                    "success": True,
                    "api_response": {"message": "Collection already exists, skipped creation"},
                    "status_result": {"success": True, "status_response": "Collection exists"}
                }
            
            # Use pre-built basic collection parameters
            create_params = dict(self._basic_collection_params)
            
            # Build request payload using collection create schema
            json_payload = build_request("create", create_params)
            
            temp_collection._prepare_for_request(return_type="json")
            
            # Make the create collection API request
            response = temp_collection._make_request(
                http_method=HTTPRequest.POST,
                endpoint="collection",
                response_key=None,
                return_type="json",
                collection_name=self.name,
                json=json_payload
            )
            
            # Wait for create collection operation to complete
            completion_result = self._wait_for_operation_completion(temp_collection, "create_collection", results)
            if not completion_result["success"]:
                results["status"]["success"] = False
                return completion_result
            
            # Operation succeeded
            return {"success": True, "api_response": response, "status_result": completion_result}
            
        except Exception as e:
            results["status"]["errors"].append(f"Create collection failed: {str(e)}")
            results["status"]["success"] = False
            return {"success": False, "error": str(e)}
    
    def _execute_load_data(self, temp_collection, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the load-data API call for table-based collections.
        
        DESCRIPTION:
            Loads data from database tables or DataFrames into the collection using
            the load-data REST API. This method:
            1. Builds the load request from the configured load index
            2. Makes the load-data API call with table/DataFrame specifications
            3. Waits for the data loading operation to complete
            
            This method is used for CONTENT_BASED and EMBEDDING_BASED collections
            that source data from existing database tables rather than external files.
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making API calls.
                Types: Collection
                
            results:
                Required Argument.
                Results dictionary to update with operation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Load data operation result containing:
                - success: Boolean indicating operation success/failure
                - api_response: Response from the load-data API call
                - status_result: Result from operation completion polling
                - error: Error message (if operation failed)
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        try:
            load_params = {}
            
            # Add table-based load index configuration
            if self._load_index:
                load_params["index"] = self._load_index
            
            # Build request payload using load schema
            json_payload = build_request("load", load_params)
            
            # Make the load-data API request
            response = temp_collection._make_request(
                http_method=HTTPRequest.POST,
                endpoint="load_data",
                response_key=None,
                return_type="json",
                collection_name=self.name,
                json=json_payload
            )
            
            # Wait for load data operation to complete
            completion_result = self._wait_for_operation_completion(temp_collection, "load_data", results)
            if not completion_result["success"]:
                results["status"]["success"] = False
                return completion_result
            
            # Operation succeeded
            return {"success": True, "api_response": response, "status_result": completion_result}
            
        except Exception as e:
            results["status"]["errors"].append(f"Load data failed: {str(e)}")
            results["status"]["success"] = False
            return {"success": False, "error": str(e)}
    
    def _execute_generate_embeddings(self, temp_collection, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the generate-embeddings API call.
        
        DESCRIPTION:
            Generates vector embeddings from text content using the configured embedding model.
            This method:
            1. Builds the embedding request from the embedding configuration
            2. Makes the generate-embeddings API call with model specifications
            3. Waits for the embedding generation operation to complete
            
            This method is used for collections that need to generate embeddings from
            text content (CONTENT_BASED and FILE_CONTENT_BASED collections).
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making API calls.
                Types: Collection
                
            results:
                Required Argument.
                Results dictionary to update with operation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Generate embeddings operation result containing:
                - success: Boolean indicating operation success/failure
                - api_response: Response from the generate-embeddings API call
                - status_result: Result from operation completion polling
                - error: Error message (if operation failed)
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        try:
            # Use consolidated embedding configuration directly
            embed_params = dict(self._embedding_config)
            
            # Build request payload using embed schema
            json_payload = build_request("embed", embed_params)
            
            # Make the generate-embeddings API request
            response = temp_collection._make_request(
                http_method=HTTPRequest.POST,
                endpoint="generate_embeddings",
                response_key=None,
                return_type="json",
                collection_name=self.name,
                json=json_payload
            )
            
            # Wait for generate embeddings operation to complete
            completion_result = self._wait_for_operation_completion(temp_collection, "generate_embeddings", results)
            if not completion_result["success"]:
                results["status"]["success"] = False
                return completion_result
            
            return {"success": True, "api_response": response, "status_result": completion_result}
            
        except Exception as e:
            results["status"]["errors"].append(f"Generate embeddings failed: {str(e)}")
            results["status"]["success"] = False
            return {"success": False, "error": str(e)}
    
    def _execute_create_index(self, temp_collection, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute create-index API for content-based collections or update() method for file-based collections.
        
        DESCRIPTION:
            Creates or updates the vector index for similarity search optimization.
            The method behavior depends on the collection type:
            
            File-based collections (FILE_CONTENT_BASED, FILE_EMBEDDING_BASED):
            - Uses Collection.update() method with indexing parameters
            
            Table-based collections (CONTENT_BASED, EMBEDDING_BASED):
            - Uses create-index REST API directly
            
            Both approaches configure the specified indexing algorithm (HNSW, FLAT, IVF_FLAT)
            and optimization settings for efficient vector similarity search.
        
        PARAMETERS:
            temp_collection:
                Required Argument.
                Collection instance for making API calls.
                Types: Collection
                
            results:
                Required Argument.
                Results dictionary to update with operation status and errors.
                Types: Dict[str, Any]
        
        RETURNS:
            Dict[str, Any]: Create index operation result containing:
                - success: Boolean indicating operation success/failure
                - api_response: Response from the create-index API call or update() method
                - status_result: Result from operation completion polling
                - error: Error message (if operation failed)
                
        RAISES:
            None: Exceptions are caught and returned in the result dictionary.
        """
        try:
            # Use consolidated create configuration directly
            index_params = dict(self._upsert_config)
            index_params['alter_operation'] = "ADD"  # Ensure we are adding/updating index
            
            # Check if this is a file-based collection using collection type
            if self._is_file_based_pipeline():
                # File-based collections: Use Collection's update() method
                print("Updating collection with index configuration for file based VS...")
                response = temp_collection.update(**index_params, standalone=False)
                time.sleep(10)  # Short delay before checking status
                
                completion_result = self._wait_for_operation_completion(temp_collection, "update", results)
                if not completion_result["success"]:
                    results["status"]["success"] = False
                    return completion_result
                
                return {"success": True, "api_response": response, "status_result": completion_result}
                
            else:
                # Content-based collections: Use create_index API directly
                json_payload = build_request("ingest_create", index_params)
                
                # Make the create-index API request
                response = temp_collection._make_request(
                    http_method=HTTPRequest.POST,
                    endpoint="create_index",
                    response_key=None,
                    return_type="json",
                    collection_name=self.name,
                    json=json_payload
                )
                
                # Wait for create index operation to complete
                completion_result = self._wait_for_operation_completion(temp_collection, "create_index", results)
                if not completion_result["success"]:
                    results["status"]["success"] = False
                    return completion_result
                
                # Operation succeeded
                return {"success": True, "api_response": response, "status_result": completion_result}
            
        except Exception as e:
            results["status"]["errors"].append(f"Create index failed: {str(e)}")
            results["status"]["success"] = False
            return {"success": False, "error": str(e)}
    
    # ========================================================================
    # Utility methods
    # ========================================================================
    
    def _is_file_based_pipeline(self) -> bool:
        """
        Check if this is a file-based pipeline.
        
        DESCRIPTION:
            Determines whether the current pipeline configuration is for a file-based
            collection type that processes external files (FILE_CONTENT_BASED or 
            FILE_EMBEDDING_BASED) rather than table-based collections that work with
            existing database tables.
            
            This classification affects the pipeline execution flow and API calls used.
        
        RETURNS:
            bool: True if collection type is file-based (FILE_CONTENT_BASED or 
                  FILE_EMBEDDING_BASED), False for table-based types.
                
        RAISES:
            None: This method does not raise exceptions.
        """
        return self.type in [CollectionType.FILE_CONTENT_BASED, CollectionType.FILE_EMBEDDING_BASED]
    
    def get_configuration_summary(self) -> Dict[str, Any]:
        """
        Get a comprehensive summary of the current pipeline configuration.
        
        DESCRIPTION:
            Returns a detailed summary of all pipeline configuration settings including
            collection information, data sources, extraction options, embedding models,
            and indexing algorithms. Useful for debugging, logging, or validation
            before executing the pipeline.
            
            The summary includes:
            - Collection metadata (name, type, database)
            - Pipeline classification (file-based vs table-based)
            - Data source configuration (files or tables)
            - Extraction settings (if applicable for file-based pipelines)
            - Embedding model configuration
            - Indexing algorithm settings
        
        RETURNS:
            Dict[str, Any]: Configuration summary containing:
                - collection_info: Basic collection metadata (name, type, database, description)
                - pipeline_type: Classification as "file-based" or "table-based"
                - extraction_config: Extract settings dictionary (file-based only, None otherwise)
                - data_config: Data source configuration (files or table index details)
                - embedding_config: Embedding model and related settings
                - indexing_config: Indexing algorithm and optimization settings
                
        RAISES:
            None: This method does not raise exceptions.
            
        EXAMPLES:
            >>> # Get configuration summary for validation
            >>> ingestor = (
            ...     Ingestor("my_collection")
            ...     .extract(text=True, images=True)
            ...     .files(files=s3_config, ingestor=NVIngestor())
            ...     .embed(embedding_model=embedding_model)
            ...     .create(indexing_algorithm=HNSW())
            ... )
            >>> 
            >>> config_summary = ingestor.get_configuration_summary()
            >>> print(f"Pipeline type: {config_summary['pipeline_type']}")
            >>> print(f"Data source: {config_summary['data_config']['type']}")
            
            >>> # Check if all required stages are configured
            >>> if config_summary['embedding_config'] and config_summary['indexing_config']:
            ...     print("Pipeline is fully configured and ready to run")
        """
        summary = {
            "collection_info": {
                "name": self.name,
                "type": self.type.value,
                "target_database": self.target_database,
                "description": self.description,
            },
            "pipeline_type": "file-based" if self._is_file_based_pipeline() else "table-based",
            "extraction_config": dict(self._extract_config) if self._extract_config else None,
            "data_config": None,
            "embedding_config": None,
            "indexing_config": None,
        }
        
        # Add data configuration details
        if self._file_config.get("files"):
            summary["data_config"] = {
                "type": "files",
                "files": str(self._file_config.get("files")),
                "ingestor": type(self._file_config.get("ingestor")).__name__ if self._file_config.get("ingestor") else None,
                "file_type": self._file_config.get("type"),
                "extraction_schema": bool(self._file_config.get("extraction_schema")),
            }
        elif self._load_index:
            summary["data_config"] = {
                "type": "table-based",
                "index_type": type(self._load_index).__name__,
                "object_names": getattr(self._load_index, "object_names", None),
            }
        
        # Add embedding configuration
        if self._embedding_config:
            embedding_model = self._embedding_config.get("embedding_model")
            summary["embedding_config"] = {
                "model_type": type(embedding_model).__name__ if embedding_model else None,
                "ignore_errors": self._embedding_config.get("ignore_embedding_errors", False),
                "use_simd": self._upsert_config.get("use_simd"),
            }
        
        # Add indexing configuration
        indexing_algorithm = self._upsert_config.get("indexing_algorithm")
        if indexing_algorithm:
            summary["indexing_config"] = {
                "algorithm": type(indexing_algorithm).__name__,
                "use_simd": self._upsert_config.get("use_simd"),
            }
        
        return summary
    
    def reset_pipeline(self) -> "Ingestor":
        """
        Reset pipeline configuration while preserving basic collection information.
        
        DESCRIPTION:
            Clears all pipeline configuration stages (extract, files/load, embed, create settings)
            while preserving the basic collection information (name, type, database, auth_data).
            This allows reconfiguring a pipeline without creating a new Ingestor instance.
            
            The following configuration is reset:
            - Extract options (text, images, tables, etc.)
            - Data source configuration (files or load index)
            - Embedding model settings
            - Indexing algorithm configuration
            - Collection instance reference
            
            The following is preserved:
            - Collection name, type, target_database, description
            - Authentication data
            - Basic collection parameters
        
        RETURNS:
            Ingestor instance for method chaining with cleared pipeline configuration.
            
        RAISES:
            None: This method does not raise exceptions.
            
        EXAMPLES:
            >>> # Reset and reconfigure pipeline
            >>> ingestor = (
            ...     Ingestor("my_collection").
            ...     .extract(text=True)
            ...     .files(files=local_config)
            ...     .embed(embedding_model=model1)
            ... )
            >>> 
            >>> # Reset configuration
            >>> ingestor.reset_pipeline()
            >>> 
            >>> # Reconfigure with different settings
            >>> result = (
            ...     ingestor = ( Ingestor("my_collection").
            ...     .extract(images=True, tables=True)
            ...     .files(files=s3_config, ingestor=NVIngestor())
            ...     .embed(embedding_model=model2)
            ...     .create(indexing_algorithm=FLAT())
            ...     .run()
            ... )
        """
        self._extract_config.clear()
        self._file_config.clear()
        self._load_index = None
        self._embedding_config.clear()
        self._upsert_config.clear()
        self._extra_create_params.clear()
        self._upsert_called = False
        self.collection = None
        
        return self