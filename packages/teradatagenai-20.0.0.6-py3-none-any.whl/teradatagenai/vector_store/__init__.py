from teradatagenai.vector_store.vector_store import VSManager, VectorStore, VSPattern, ModelUrlParams, IngestParams
from teradatagenai.vector_store.collection import CollectionManager, Collection
from teradatagenai.vector_store.nv_ingest_client import create_nvingest_schema, write_to_nvingest_vector_store, nvingest_retrieval
from teradatagenai.vector_store.data_classes import (SearchParams, FLAT, IVF_FLAT, HNSW, ColumnInfo, ColumnExpression,
                                                    ContentBasedIndex, EmbeddingBasedIndex, ExtractionSchema,
                                                    S3Config, AzureBlobConfig, GCPConfig, LocalConfig,
                                                    BasicIngestor, NVIngestor, UnstructuredIngestor)
from teradatagenai.vector_store.Ingestor import Ingestor

# Optional import for TeradataVDB - requires nv-ingest-client
try:
    from teradatagenai.vector_store.teradataVDB import TeradataVDB
    __all__ = [
        'VSManager', 'VectorStore', 'VSPattern', 'ModelUrlParams', 'IngestParams', 'CollectionManager',
        'Collection',
        'create_nvingest_schema', 'write_to_nvingest_vector_store', 'nvingest_retrieval',
        'Collection', 'CollectionManager', 'SearchParams', 'FLAT', 'IVF_FLAT', 'HNSW',
        'ColumnInfo', 'ColumnExpression', 'ContentBasedIndex', 'EmbeddingBasedIndex', 'ExtractionSchema',
        'S3Config', 'AzureBlobConfig', 'GCPConfig', 'LocalConfig',
        'BasicIngestor', 'NVIngestor', 'UnstructuredIngestor', 'Ingestor',
        'TeradataVDB'
    ]
except ImportError:
    # TeradataVDB is not available if nv-ingest-client is not installed
    __all__ = [
        'VSManager', 'VectorStore', 'VSPattern', 'ModelUrlParams', 'IngestParams', 'CollectionManager',
        'Collection',
        'create_nvingest_schema', 'write_to_nvingest_vector_store', 'nvingest_retrieval',
        'Collection', 'CollectionManager','SearchParams', 'FLAT', 'IVF_FLAT', 'HNSW',
        'ColumnInfo', 'ColumnExpression', 'ContentBasedIndex', 'EmbeddingBasedIndex', 'ExtractionSchema',
        'S3Config', 'AzureBlobConfig', 'GCPConfig', 'LocalConfig',
        'BasicIngestor', 'NVIngestor', 'UnstructuredIngestor', 'Ingestor',
    ]
    TeradataVDB = None
