"""
Copyright (c) 2025 by Teradata Corporation. All rights reserved.
TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET
Primary Owner: snigdha.biswas@teradata.com
Secondary Owner: PankajVinod.Purandare@Teradata.com
This is a common class to include common functionality required
by other classes which can be reused according to the need.
"""
# from ..telemetry_utils.queryband import session_queryband
# from teradataml.utils.utils import execute_sql
from teradataml.utils.validators import _Validators
from teradatagenai import TeradataAI
from teradatagenai.common.constants import CollectionType
from teradatagenai.vector_store.data_classes import (
    ContentBasedIndex, EmbeddingBasedIndex, ColumnInfo, HNSW, FLAT, 
    IVF_FLAT, SearchParams, LocalConfig, S3Config, AzureBlobConfig, 
    GCPConfig, BasicIngestor, NVIngestor, UnstructuredIngestor,
    ExtractionSchema
)
from teradatasqlalchemy.types import VECTOR, VECTOR32
globals()["TeradataAI"] = TeradataAI
globals()["CollectionType"] = CollectionType
globals()["ContentBasedIndex"] = ContentBasedIndex
globals()["EmbeddingBasedIndex"] = EmbeddingBasedIndex
globals()["ColumnInfo"] = ColumnInfo
globals()["HNSW"] = HNSW
globals()["FLAT"] = FLAT
globals()["IVF_FLAT"] = IVF_FLAT
globals()["SearchParams"] = SearchParams
globals()["LocalConfig"] = LocalConfig
globals()["S3Config"] = S3Config
globals()["AzureBlobConfig"] = AzureBlobConfig
globals()["GCPConfig"] = GCPConfig
globals()["BasicIngestor"] = BasicIngestor
globals()["NVIngestor"] = NVIngestor
globals()["UnstructuredIngestor"] = UnstructuredIngestor
globals()["ExtractionSchema"] = ExtractionSchema
globals()["VECTOR"] = VECTOR
globals()["VECTOR32"] = VECTOR32

def validate_docstring_kwargs(kwargs, param_dicts, model_params_names=None):
    """
    Generic function to validate kwargs based on parameter dictionaries from docstring params.
    PARAMETERS:
        kwargs:
            Dict of keyword arguments to validate.
            Types: dict
        param_dicts:
            List of parameter dictionaries containing parameter metadata.
            Each dict should have parameter names as keys and metadata as values.
            Types: list of dict
        model_params_names:
            Optional list of parameter names that should have str added for backward compatibility.
            Default: ['ranking_model', 'chat_model', 'guardrails_model', 'embedding_model']
            Types: list of str
    RETURNS:
        None. Raises TeradataMlException if validation fails.
    """
    if model_params_names is None:
        model_params_names = ['ranking_model', 'chat_model', 'guardrails_model', 'embedding_model']
    
    def _get_param_type(typestr):
        """Convert type string to actual Python type.
        For the TeradataML validators framework, we need to extract the base types
        that elements should be, and also include 'list' if list patterns are detected.
        Supports the following formats:
        - Basic types: "int", "str", "bool"
        - Class types: "SearchParams", "TeradataAI", "ContentBasedIndex", etc.
        - List types: "list of str", "list of SearchParams", etc.
        - Compound types: "TeradataAI, str", "list of str, SearchParams", etc.
        """
        if not typestr:
            return object
        has_list_pattern = False
        def _resolve_single_type(type_expr):
            """Resolve a single type expression to actual Python type."""
            nonlocal has_list_pattern
            type_expr = type_expr.strip()
            # Handle "list of X" pattern - extract the base type X
            if type_expr.startswith("list of "):
                has_list_pattern = True
                inner_type = type_expr[8:].strip()  # Remove "list of "
                return _resolve_type_name(inner_type)
            # Handle single type name
            return _resolve_type_name(type_expr)
        def _resolve_type_name(type_name):
            """Resolve a single type name to actual Python type."""
            import builtins
            # Try builtins first (int, str, bool, etc.)
            try:
                return getattr(builtins, type_name)
            except AttributeError:
                # Try globals (imported classes like SearchParams, TeradataAI)
                try:
                    return globals()[type_name]
                except KeyError:
                    return object
        # Handle compound types like "TeradataAI, str" or "list of str, SearchParams"
        if "," in typestr:
            types = [t.strip() for t in typestr.split(",")]
            resolved_types = [_resolve_single_type(t) for t in types]
            # Remove duplicates while preserving order
            unique_types = []
            for t in resolved_types:
                if t not in unique_types:
                    unique_types.append(t)
            # Add list type if any list patterns were detected
            if has_list_pattern and list not in unique_types:
                unique_types.append(list)
            return tuple(unique_types)
        # Single type (including "list of X")
        result = _resolve_single_type(typestr)
        # For single "list of X" pattern, return both the base type and list
        if has_list_pattern:
            return (result, list)
        return result
    arg_info_matrix = []
    # Validate only the kwargs that are actually passed
    for param, value in kwargs.items():
        # Find this parameter in one of the param_dicts
        meta = None
        for param_dict in param_dicts:
            if param in param_dict:
                meta = param_dict[param]
                break
        if meta is not None:
            typestr = meta.get("types", "")
            param_type = _get_param_type(typestr)

            # For MODEL_PARAMS, add str for backward compatibility. 
            if param in ['ranking_model', 'chat_model', 'embedding_model']:
                if isinstance(param_type, tuple):
                    # If it's already a tuple, add str if not present
                    if str not in param_type:
                        param_type = param_type + (str,)
                else:
                    # If it's a single type, convert to tuple with str
                    param_type = (param_type, str)
            
            # Special handling for embedding_datatype - accept VECTOR/VECTOR32 classes, instances, or strings
            if param == "embedding_datatype":
                # Skip validation here - let build_request handle the conversion and validation
                continue
            
            #print(f"Validating param: {param}, value: {value!r}, expected type: {param_type}")
            arg_info_matrix.append([param, value, True, param_type, True])
    if arg_info_matrix:
        _Validators._validate_function_arguments(arg_info_matrix)