# -*- coding: utf-8 -*-
"""
Unpublished work.
Copyright (c) 2025 by Teradata Corporation. All rights reserved.
TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

Primary Owner: aanchal.kavedia@teradata.com
Secondary Owner: PankajVinod.Purandare@teradata.com

teradatagenai.common.collection_docstring_params
----------
Constants for Collection/Collection Manager parameter documentation
"""

## Collection/Collection Manager params
PAGE_PARAMS ={
    "page": {
        "argument_name": "page",
        "required": "Optional Argument",
        "description": """Specifies the page number for paginated results. Used to retrieve 
                          a specific subset of results when the total number of collections 
                          or sessions exceeds the page_size limit.""",
        "notes": "* Page numbering starts at 1.",
        "default_values": 1,
        "permitted_values": "[1 - 2147483647]",
        "types": "int",
    },
    
    "page_size": {
        "argument_name": "page_size",
        "required": "Optional Argument",
        "description": """Specifies the maximum number of collections or sessions to return 
                          per page. Controls the size of each paginated response to manage 
                          large result sets efficiently.""",
        "notes": """*If "page_size" is not specified, the default value is set to 20.
                    * To retrieve all the collections, users can pass in a large number (e.g, page_size = 100000)""",
        "default_values": 20,
        "permitted_values": "[1 - 1000]",
        "types": "int",
    },

    "authorized": {
        "argument_name": "authorized",
        "required": "Optional Argument",
        "description": """Specifies whether to list only collections that the current user 
                          has explicit permissions for. When False, lists all collections 
                          visible to the user (including those inherited through role permissions).""",
        "notes": "",
        "default_values": False,
        "permitted_values": "",
        "types": "bool",
    },

}

# SEARCH PARAMS section
SEARCH_PARAMS = {
    "search_params": {
        "argument_name": "search_params",
        "required": "Optional Argument",
        "description": """Specifies the search execution and strategy parameters for the collection.\nCan be used to control top_k, thresholds, search type, reranking, and other advanced search options.""",
        "default_values": None,
        "permitted_values": "",
        "types": "SearchParams",
    },
}

RETURN_TYPE_PARAMS = {
    "return_type": {
        "argument_name": "return_type",
        "required": "Optional Argument",
        "description": """Specifies the format in which the results should be returned.""",
        "notes": "",
        "default_values": "teradataml if connection is established else json",
        "permitted_values": "teradataml, pandas, json",
        "types": "str",
    },
}

AUTH_PARAMS = {
    "auth_data": {
        "argument_name": "auth_data",
        "required": "Optional Argument",
        "description": """Specifies the authentication data for API calls.
                          Auth_data is the object returned by set_auth_token().
                          If not provided, will use default authentication from configure.""",
        "notes": """* Default authentication will be overrriden by object instantiation in a session
                    * If multiple set_auth_token() calls are triggered, the latest credentials
                        will be used if object is not passed.""",
        "default_values": "Default authentication from configure",
        "permitted_values": "",
        "types": "set_auth_token",
    },
}


COLUMN_PARAMS = {
    "key_columns": {
        "argument_name": "key_columns",
        "required": "Optional Argument",
        "description": """Specifies the key column(s) with datatype and description.""",
        "notes": "",
        "default_values": None,
        "permitted_values": "",
        "types": "ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression",
    },
    "data_columns": {
        "argument_name": "data_columns",
        "required": "Optional Argument",
        "description": """Specifies the data column(s) whose text/content will be embedded.""",
        "notes": "",
        "default_values": None,
        "permitted_values": "",
        "types": "ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression",
    },
    "metadata_columns": {
        "argument_name": "metadata_columns",
        "required": "Optional Argument",
        "description": """Specifies the metadata column(s) that carry extra metadata into the collection.""",
        "notes": "",
        "default_values": None,
        "permitted_values": "",
        "types": "ColumnInfo, ColumnExpression, list of ColumnInfo, list of ColumnExpression",
    },
}

MODEL_PARAMS = {
    "embedding_model": {
        "argument_name": "embedding_model",
        "required": "Required Argument",
        "description": """Specifies the embedding model configuration for generating or processing embeddings.""",
        "types": "TeradataAI",
    },

    "chat_model": {
        "argument_name": "chat_model",
        "required": "Optional Argument",
        "description": """Specifies the chat completion model to be used for
                          generating text responses.""",
        "types": "TeradataAI",
    },

    "ranking_model": {
        "argument_name": "ranking_model",
        "required": "Optional Argument",
        "description": """Specifies the model to be used for reranking the search results.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "",
        "types": "TeradataAI",
    },

    "guardrails_model": {
        "argument_name": "guardrails_model",
        "required": "Optional Argument",
        "description": """Specifies the guardrails model and its respective base_url to apply.
                          Valid guardrails types are content_safety, topic_control, jailbreak_detection.""",
        "types": "TeradataAI",
    },

    "enable_guardrails": {
        "argument_name": "enable_guardrails",
        "required": "Optional Argument",
        "description": """Specifies which guardrail to enable for content protection and safety.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "content_safety, topic_control, jailbreak_detection",
        "types": "str",
    },
    
    "onnx_model": {
        "argument_name": "onnx_model",
        "required": "Optional Argument",
        "description": """Specifies the ONNX model configuration for generating or processing embeddings.""",
        "types": "TeradataAI",
    },  
}

FILTER_PARAMS = {
    "filter": {
        "argument_name": "filter",
        "required": "Optional Argument",
        "description": """Specifies the filter expression to be used for filtering the results. 
                          Supports logical operators (AND, OR, NOT), comparison operators 
                          (=, !=, <, <=, >, >=), and IN clauses with parentheses grouping.""",
        "notes": """* Simple condition: "age > 25"
                    * Complex condition: "age >= 18 AND status = 'active'"
                    * IN clause: "category IN ('A', 'B', 'C')"
                    * Grouped conditions: "(age > 18 AND status = 'active') OR priority = 'high'"
                    * String matching: "name != 'test' AND description LIKE '%important%'" """,
        "default_values": "",
        "permitted_values": "",
        "types": "str",
    },

    "filter_style": {
        "argument_name": "filter_style",
        "required": "Optional Argument",
        "description": """Specifies whether to apply filtering before or after the similarity_search.""",
        "notes": "",
        "default_values": "PRE-FILTERING",
        "permitted_values": "PRE-FILTERING, POST-FILTERING",
        "types": "str",
    }
}

CREATE_COMMON_PARAMS = {
    "name": {
        "argument_name": "name",
        "required": "Optional Argument",
        "description": """Specifies the name of the collection either to initialize, if it
                          already exists or to create a new collection.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "",
        "types": "str",
    },

    "type": {
        "argument_name": "type",
        "required": "Optional Argument",
        "description": """Specifies the type of collection.
                          Required when creating a new collection.""",
        "notes": "",
        "default_values": "",
        "permitted_values": """* CollectionType.CONTENT_BASED
                               * CollectionType.EMBEDDING_BASED
                               * CollectionType.FILE_CONTENT_BASED
                               * CollectionType.FILE_EMBEDDING_BASED""",
        "types": "CollectionType",
    },

    "target_database": {
        "argument_name": "target_database",
        "required": "Optional Argument",
        "description": """Specifies the database where collection will be created.
                          If not provided, uses current/default database.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "",
        "types": "str",
    },

    "description": {
        "argument_name": "description",
        "required": "Optional Argument",
        "description": """Human-readable description of the collection purpose and content.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "",
        "types": "str",
    },

    "index": {
        "argument_name": "index",
        "required": "Optional Argument, will be Required in future versions",
        "description": """Specifies the Index/schema definition object containing table 
                          references and column mappings.
                          For 'CONTENT-BASED' collections: ContentBasedIndex object
                          For 'EMBEDDING-BASED' collections: EmbeddingBasedIndex object""",
        "types": "ContentBasedIndex, EmbeddingBasedIndex",
    },

    "indexing_algorithm": {
        "argument_name": "indexing_algorithm",
        "required": "Optional Argument",
        "description": """Specifies the algorithm configuration with required parameters
                          for vector indexing and search optimization.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "",
        "types": "HNSW, FLAT, IVF_FLAT",
    },

    "use_simd": {
        "argument_name": "use_simd",
        "required": "Optional Argument",
        "description": """Enable SIMD (Single Instruction, Multiple Data) operations for 
                          faster vector processing.""",
        "notes": "",
        "default_values": False,
        "permitted_values": "",
        "types": "bool",
    },

    "ignore_embedding_errors": {
        "argument_name": "ignore_embedding_errors",
        "required": "Optional Argument",
        "description": """Whether to continue processing when embedding generation encounters errors.""",
        "notes": "",
        "default_values": False,
        "permitted_values": "",
        "types": "bool",
    },

    "embedding_datatype": {
        "argument_name": "embedding_datatype",
        "required": "Optional Argument",
        "description": """Specifies the data type used for embedding vectors.""",
        "notes": "",
        "default_values": "",
        "permitted_values": "VECTOR, VECTOR32",
        "types": "VECTOR, VECTOR32",
    },

    

    # Implicitly includes search_params from SEARCH_PARAMS
    "search_params": SEARCH_PARAMS["search_params"]
}

# Common parameter dictionaries for docstring_handler - only truly repeated parameters
INGESTOR_COMMON_PARAMS = {
    "chunk_size": {
        "argument_name": "chunk_size",
        "required": "Optional Argument",
        "description": "Specifies the size of text chunks for processing.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "int",
    },
    "chunk_overlap": {
        "argument_name": "chunk_overlap",
        "required": "Optional Argument",
        "description": "Specifies the overlap between consecutive chunks.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "int",
    },
    "footer_height": {
        "argument_name": "footer_height",
        "required": "Optional Argument",
        "description": "Specifies the height of footer area to exclude during processing.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "int",
    },
    "header_height": {
        "argument_name": "header_height",
        "required": "Optional Argument",
        "description": "Specifies the height of header area to exclude during processing.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "int",
    },
}

# Parameters shared between NVIngestor and UnstructuredIngestor
EXTRACTION_COMMON_PARAMS = {
    "extract_metadata_json": {
        "argument_name": "extract_metadata_json",
        "required": "Optional Argument",
        "description": "Specifies whether to extract metadata as JSON.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "bool",
    },
    "extract_images": {
        "argument_name": "extract_images",
        "required": "Optional Argument",
        "description": "Specifies whether to extract images.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "bool",
    },
    "extract_tables": {
        "argument_name": "extract_tables",
        "required": "Optional Argument",
        "description": "Specifies whether to extract tables.",
        "notes": "",
        "default_values": "None",
        "permitted_values": "",
        "types": "bool",
    }
}

UPDATE_PARAMS = {
    "new_collection_name": {
        "argument_name": "new_collection_name",
        "required": "Optional Argument",
        "description": "Specifies the new name for the collection.",
        "types": "str",
    },
    "alter_operation": {
        "argument_name": "alter_operation",
        "required": "Optional Argument",
        "description": "Specifies the type of alter operation to perform on the collection index.",
        "permitted_values": "ADD, DELETE",
        "types": "str",
    },
    "update_style": {
        "argument_name": "update_style",
        "required": "Optional Argument",
        "description": "Specifies the update style (e.g., MINOR or MAJOR) for index or data updates.",
        "permitted_values": "MINOR, MAJOR",
        "types": "str",
    },
    "metadata_operation": {
        "argument_name": "metadata_operation",
        "required": "Optional Argument",
        "description": "Specifies the metadata operation (ADD, DELETE, MODIFY) for metadata columns.",
        "permitted_values": "ADD, DELETE, MODIFY",
        "types": "str",
    },
    "file_names": {
        "argument_name": "file_names",
        "required": "Optional Argument",
        "description": "List of file names to be updated in the collection.",
        "types": "list",

    },
}

EMBEDDING_COMMON_PARAMS = {
"target_database": CREATE_COMMON_PARAMS["target_database"],

"description": CREATE_COMMON_PARAMS["description"],

"update_style": UPDATE_PARAMS["update_style"],

"metadata_operation": UPDATE_PARAMS["metadata_operation"],
}

# Shared parameter dictionary for file-based document operations
FILE_DOCUMENTS_COMMON_PARAMS = {
    # Additional file-based parameters
    "ingestor": {
        "argument_name": "ingestor",
        "required": "Optional Argument",
        "description": "Specifies the ingestor type for file processing. If None, defaults to BasicIngestor() at runtime.",
        "types": "BasicIngestor, NVIngestor, UnstructuredIngestor",
    },
    "extraction_schema": {
        "argument_name": "extraction_schema",
        "required": "Optional Argument",
        "description": "Specifies the schema for storing extracted content and metadata in the backing table.",
        "types": "ExtractionSchema"
    }
}