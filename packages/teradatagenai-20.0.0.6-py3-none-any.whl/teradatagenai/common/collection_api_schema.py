# -*- coding: utf-8 -*-
"""
Unpublished work.
Copyright (c) 2025 by Teradata Corporation. All rights reserved.
TERADATA CORPORATION CONFIDENTIAL AND TRADE SECRET

Primary Owner: aanchal.kavedia@teradata.com
Secondary Owner: sushant.mhambrey@teradata.com

teradatagenai.common.collection_api_schema
----------
A dictonary for holding all schemas for V2 APIs.
"""

"""Schema definitions and request builders for TeradataGenAI collection APIs.

        DESCRIPTION:
            This module provides schema-driven request building for various collection API endpoints.
            It defines parameter mappings that transform user-friendly parameter names into the
            proper API request structure required by the backend services.
            
            The main components are:
            - API_SCHEMAS: Dictionary defining parameter mappings for each API endpoint
            - build_request(): Function to transform user parameters using the schemas
            - _set_nested_value(): Utility for setting values in nested dictionary structures
            
            API Schema Format:
                Each API schema maps user parameter names to (target_path, action) tuples:
                - target_path: Dot-separated path where the parameter should be placed
                - action: How to handle the parameter value:
                    - "=": Use value directly
                    - "*": Serialize objects using to_dict() if available
                    - ("s", field): String maps to nested field, objects serialize fully
"""
from teradataml.common.utils import UtilFuncs
from teradataml.common.exceptions import TeradataMlException
from teradataml.utils.validators import _Validators
from teradatasqlalchemy.types import VECTOR, VECTOR32
from teradatagenai.vector_store.vector_store import _ProcessDataFrameObjects

API_SCHEMAS = {
    "create": {
        # Root-level parameters (no dots = goes to request root)
        "name": ("collection_name", "="),
        "type": ("collection_type", "="),
        "target_database": ("target_database", "="),
        "description": ("collection_description", "="),
        
        # Index object mapping - if object passed, use to_dict()
        "index": ("collection_index", "*"),

        # Index individual params
        "object_names": ("collection_index.object_names", "="),
        "key_columns": ("collection_index.key_columns", "="),
        "data_columns": ("collection_index.data_columns", "="),
        "metadata_columns": ("collection_index.metadata_columns", "="),
        "embedding_columns": ("collection_index.embedding_columns", "="),
        "is_normalized": ("collection_index.normalized_embedding", "="),
        
        # Model objects - use to_dict() if objects passed
        "embedding_model": ("collection_parameters.embedding_model", ("s", "model_id")),
        "chat_model": ("collection_parameters.chat_model", ("s", "model_id")),
        "onnx_model": ("collection_parameters.onnx_model", "*"),

        "ranking_model": ("collection_parameters.ranking_model", ("s", "model_id")),
        "guardrails_model": ("collection_parameters.guardrails", "*"),
        "enable_guardrails": ("collection_parameters.guardrails.guardrails_kind", "="),
        
        # Other objects
        "search_params": ("collection_parameters.search_params", "*"),
        "indexing_algorithm": ("collection_parameters.train_params", "*"),
        
        # Direct simple parameters
        "use_simd": ("collection_parameters.use_simd", "="),
        "ignore_embedding_errors": ("collection_parameters.ignore_embedding_errors", "="),
        "embedding_datatype": ("collection_parameters.embedding_datatype", "="),
        
        ## backward compatibility parameters
        "chat_completion_max_tokens": ("collection_parameters.chat_model.max_tokens", "="),
        "embeddings_base_url": ("collection_parameters.embedding_model.base_url", "="),
        "completions_base_url": ("collection_parameters.chat_model.base_url", "="),
        "content_safety_base_url": ("collection_parameters.guardrails.content_safety_model.base_url", "="),
        "topic_control_base_url": ("collection_parameters.guardrails.topic_control_model.base_url", "="),
        "jailbreak_detection_base_url": ("collection_parameters.guardrails.jailbreak_detection_base_url", "="),
        "content_safety_model": ("collection_parameters.guardrails.content_safety_model.model_id", "="),
        "topic_control_model": ("collection_parameters.guardrails.topic_control_model.model_id", "="),
        "guardrails": ("collection_parameters.guardrails.guardrails_kind", "="),
        "ranking_base_url": ("collection_parameters.ranking_model.base_url", "="),
        "embeddings_model" : ("collection_parameters.embedding_model.model_id", "="),
        "chat_completion_model": ("collection_parameters.chat_model.model_id", "="),
        "search_algorithm": ("collection_parameters.train_params.search_algorithm", "="),
        "embeddings_dims": ("collection_parameters.embedding_model.embedding_dims", "="),

        # Individual parameters that build parent objects
        # SearchParams
        "top_k": ("collection_parameters.search_params.top_k", "="),
        "search_threshold": ("collection_parameters.search_params.search_threshold", "="),
        "search_numcluster": ("collection_parameters.search_params.search_numcluster", "="),
        "ef_search": ("collection_parameters.search_params.ef_search", "="),
        "search_type": ("collection_parameters.search_strategy.search_type", "="),
        "scoring_method": ("collection_parameters.search_strategy.scoring_method", "="),
        "sparse_weight": ("collection_parameters.search_strategy.sparse_weight", "="),
        "rrf_normalizer": ("collection_parameters.search_strategy.rrf_normalizer", "="),
        "relevance_top_k": ("collection_parameters.search_strategy.relevance_top_k", "="),
        "relevance_search_threshold": ("collection_parameters.search_strategy.relevance_search_threshold", "="),
        "maximal_marginal_relevance": ("collection_parameters.search_strategy.maximal_marginal_relevance", "="),
        "lambda_multiplier": ("collection_parameters.search_strategy.lambda_multiplier", "="),
        "rerank_weight": ("collection_parameters.search_strategy.rerank_sparse_weight", "="),
        
        # TrainParams
        "search_algorithm": ("collection_parameters.train_params.search_algorithm", "="),
        "metric": ("collection_parameters.train_params.metric", "="),
        # IVF_FLAT    
        "initial_centroids_method": ("collection_parameters.train_params.initial_centroids_method", "="),
        "train_numcluster": ("collection_parameters.train_params.train_numcluster", "="),
        "max_iternum": ("collection_parameters.train_params.max_iternum", "="),
        "stop_threshold": ("collection_parameters.train_params.stop_threshold", "="),
        "seed": ("collection_parameters.train_params.seed", "="),
        "num_init": ("collection_parameters.train_params.num_init", "="),
        # HNSW
        "num_layer": ("collection_parameters.train_params.num_layer", "="),
        "ef_construction": ("collection_parameters.train_params.ef_construction", "="),
        "num_connpernode": ("collection_parameters.train_params.num_connPerNode", "="),
        "maxnum_connpernode": ("collection_parameters.train_params.maxNumConnPerNode", "="),
        "apply_heuristics": ("collection_parameters.train_params.apply_heuristics", "="),
        "num_nodes_per_graph": ("collection_parameters.train_params.num_NodesPerGraph", "=")
    },
    "load": {
        # Index configuration for table-based loading - serialize directly to root
        "index": ("", "*")
    },
    "embed": {
        # Embedding model configuration
        "embedding_model": ("embedding_model", "*"),
        "ignore_embedding_errors": ("ignore_embedding_errors", "="),
        "use_simd": ("use_simd", "="),
        "embedding_datatype": ("embedding_datatype", "="),
        
    },
    
    "ingest": {
        # File configuration - handled specially in build_request
        "files": ("", "="),  # Special handling marker
        
        # Ingestor configuration - serialized JSON  
        "ingestor": ("ingest_parameters", "*"),
        
        # Extraction schema - separate field
        "extraction_schema": ("extraction_schema", "*")
    },
    
    "ingest_create": {
        # Model configuration
        "embedding_model": ("embedding_model", "*"),
        "ignore_embedding_errors": ("ignore_embedding_errors", "="),
        "embedding_datatype": ("embedding_datatype", "="),

        # Indexing algorithm
        "indexing_algorithm": ("train_params", "*"),
        "use_simd": ("use_simd", "="),
        "search_params": ("search_params", "*"),
        
        "ranking_model": ("ranking_model", "*"),
        "chat_model": ("chat_model", "*"),
        "ranking_model": ("ranking_model", "*"),
        "guardrails_model": ("guardrails", "*"),
        "enable_guardrails": ("guardrails.guardrails_kind", "="),
        "onnx_model": ("onnx_model", "*")
    },
    "similarity_search": {
        # Root level
        "question": ("question", "="),
        "question_vector": ("question_vector", "="),
        
        # Model objects
        "embedding_model": ("embedding_model", ("s", "model_id")),
        "chat_model": ("chat_model", ("s", "model_id")),
        "search_params": ("search_params", "*"),
        "ranking_model": ("ranking_model", ("s", "model_id")),
        "guardrails_model": ("guardrails", "*"),
        "enable_guardrails": ("guardrails.guardrails_kind", "="),
        "onnx_model": ("onnx_model", "*"),
        
        # Filter parameters
        "filter": ("filter_params", "="),
        # TODO: Both point to filter_params.
        "filter_params": ("filter_params", "="),
        "filter_style": ("filter_params.style", "="),
        
        # Individual parameters
        "top_k": ("search_params.top_k", "="),
        "search_threshold": ("search_params.search_threshold", "="),
        "search_numcluster": ("search_params.search_numcluster", "="),
        "ef_search": ("search_params.ef_search", "="),
        "search_type": ("search_strategy.search_type", "="),
        "scoring_method": ("search_strategy.scoring_method", "="),
        "sparse_weight": ("search_strategy.sparse_weight", "="),
        "relevance_top_k": ("search_strategy.relevance_top_k", "="),
        "rrf_normalizer": ("search_strategy.rrf_normalizer", "="),
        "relevance_search_threshold": ("search_strategy.relevance_search_threshold", "="),
        "maximal_marginal_relevance": ("search_strategy.maximal_marginal_relevance", "="),
        "lambda_multiplier": ("search_strategy.lambda_multiplier", "="),
        "rerank_weight": ("collection_parameters.search_strategy.rerank_sparse_weight", "="),

        # Remove with ELE-9540
        "embeddings_base_url": ("embedding_model.base_url", "="),
        "completions_base_url": ("chat_model.base_url", "=")
    },
    
    "ask": {
         # Root level
        "question": ("question", "="),
        "question_vector": ("question_vector", "="),
        
        # Model objects
        "embedding_model": ("embedding_model", ("s", "model_id")),
        "chat_model": ("chat_model", ("s", "model_id")),
        "search_params": ("search_params", "*"),
        "ranking_model": ("ranking_model", ("s", "model_id")),
        "guardrails_model": ("guardrails", "*"),
        "enable_guardrails": ("guardrails.guardrails_kind", "="),
        "onnx_model": ("onnx_model", "*"),

        
        # Filter parameters
        "filter": ("filter_params", "="),
        "filter_params": ("filter_params", "="),
        "filter_style": ("filter_params.style", "="),

        # Backward compatibility parameters/Individual parameters
        "top_k": ("search_params.top_k", "="),
        "search_threshold": ("search_params.search_threshold", "="),
        "search_numcluster": ("search_params.search_numcluster", "="),
        "ef_search": ("search_params.ef_search", "="),
        "search_type": ("search_strategy.search_type", "="),
        "scoring_method": ("search_strategy.scoring_method", "="),
        "sparse_weight": ("search_strategy.sparse_weight", "="),
        "relevance_top_k": ("search_strategy.relevance_top_k", "="),
        "rrf_normalizer": ("search_strategy.rrf_normalizer", "="),
        "relevance_search_threshold": ("search_strategy.relevance_search_threshold", "="),
        "maximal_marginal_relevance": ("search_strategy.maximal_marginal_relevance", "="),
        "lambda_multiplier": ("search_strategy.lambda_multiplier", "="),
        "temperature": ("chat_model.temperature", "="),
        "prompt": ("chat_model.prompt", "="),
        # Needs to be removed in future.
        "completions_base_url": ("chat_model.base_url", "="),
        "embeddings_base_url": ("embedding_model.base_url", "=")

    },
    
    "update": {
        # ----------------------------------
        # Root-level fields
        # ----------------------------------
        "new_collection_name": ("new_collection_name", "="),
        "description": ("collection_description", "="),
        # ----------------------------------
        # Collection Index (object as whole)
        # ----------------------------------
        "index": ("collection_index", "*"),
        # Individual index fields (missing earlier)
        "alter_operation": ("collection_index.alter_operation", "="),
        "update_style": ("collection_index.update_style", "="),
        "metadata_operation": ("collection_index.metadata_operation", "="),
        "file_names": ("collection_index.file_names", "="),
        # Basic index fields
        "object_names": ("collection_index.object_names", "="),
        "key_columns": ("collection_index.key_columns", "="),
        "data_columns": ("collection_index.data_columns", "="),
        "metadata_columns": ("collection_index.metadata_columns", "="),
        "embedding_columns": ("collection_index.embedding_columns", "="),
        "is_normalized": ("collection_index.normalized_embedding", "="),
        # ----------------------------------
        # Collection parameters
        # ----------------------------------
        # Search params
        "search_params": ("collection_parameters.search_params", "*"),
        # Train params (corrected: NO indexing_algorithm)
        "indexing_algorithm": ("collection_parameters.train_params", "*"),
        # Embedding / chat / ranking models
        "embedding_model": ("collection_parameters.embedding_model", ("s", "model_id")),
        "chat_model": ("collection_parameters.chat_model", "*"),
        "ranking_model": ("collection_parameters.ranking_model", "*"),
        "onnx_model": ("collection_parameters.onnx_model", "*"),
        # Search strategy
        "search_strategy": ("collection_parameters.search_strategy", "*"),
        # Guardrails
        "guardrails_model": ("collection_parameters.guardrails", "*"),
        "enable_guardrails": ("collection_parameters.guardrails.guardrails_kind", "="),
        # ----------------------------------
        # Direct simple collection parameters
        # ----------------------------------
        "use_simd": ("collection_parameters.use_simd", "="),
        "ignore_embedding_errors": ("collection_parameters.ignore_embedding_errors", "="),
        "embedding_datatype": ("collection_parameters.embedding_datatype", "="),
        "time_zone": ("collection_parameters.time_zone", "="),
        # ----------------------------------
        # Search parameter fields (flattened)
        # ----------------------------------
        "top_k": ("collection_parameters.search_params.top_k", "="),
        "search_threshold": ("collection_parameters.search_params.search_threshold", "="),
        "search_numcluster": ("collection_parameters.search_params.search_numcluster", "="),
        "ef_search": ("collection_parameters.search_params.ef_search", "="),
        # ----------------------------------
        # Search strategy parameters
        # ----------------------------------
        "search_type": ("collection_parameters.search_strategy.search_type", "="),
        "scoring_method": ("collection_parameters.search_strategy.scoring_method", "="),
        "sparse_weight": ("collection_parameters.search_strategy.sparse_weight", "="),
        "rrf_normalizer": ("collection_parameters.search_strategy.rrf_normalizer", "="),
        "relevance_top_k": ("collection_parameters.search_strategy.relevance_top_k", "="),
        "relevance_search_threshold": ("collection_parameters.search_strategy.relevance_search_threshold", "="),
        "maximal_marginal_relevance": ("collection_parameters.search_strategy.maximal_marginal_relevance", "="),
        "lambda_multiplier": ("collection_parameters.search_strategy.lambda_multiplier", "="),
        "rerank_weight": ("collection_parameters.search_strategy.rerank_sparse_weight", "="),
        # ----------------------------------
        # Train params fields (corrected)
        # ----------------------------------
        "search_algorithm": ("collection_parameters.train_params.search_algorithm", "="),
        "metric": ("collection_parameters.train_params.metric", "="),
        # IVF_FLAT
        "initial_centroids_method": ("collection_parameters.train_params.initial_centroids_method", "="),
        "train_numcluster": ("collection_parameters.train_params.train_numcluster", "="),
        "max_iternum": ("collection_parameters.train_params.max_iternum", "="),
        "stop_threshold": ("collection_parameters.train_params.stop_threshold", "="),
        "seed": ("collection_parameters.train_params.seed", "="),
        "num_init": ("collection_parameters.train_params.num_init", "="),
        # HNSW
        "num_layer": ("collection_parameters.train_params.num_layer", "="),
        "ef_construction": ("collection_parameters.train_params.ef_construction", "="),
        "num_connpernode": ("collection_parameters.train_params.num_connPerNode", "="),
        "maxnum_connpernode": ("collection_parameters.train_params.maxNum_connPerNode", "="),
        "apply_heuristics": ("collection_parameters.train_params.apply_heuristics", "="),
        "num_nodes_per_graph": ("collection_parameters.train_params.num_NodesPerGraph", "="),
        # ----------------------------------
        # Backward compatibility parameters
        # ----------------------------------
        "new_vs_name": ("new_collection_name", "="),
        "document_files": ("collection_index.file_names", "="),
        "chat_completion_max_tokens": ("collection_parameters.chat_model.max_tokens", "="),
        "embeddings_base_url": ("collection_parameters.embedding_model.base_url", "="),
        "completions_base_url": ("collection_parameters.chat_model.base_url", "="),
        "content_safety_base_url": ("collection_parameters.guardrails.content_safety_model.base_url", "="),
        "topic_control_base_url": ("collection_parameters.guardrails.topic_control_model.base_url", "="),
        "jailbreak_detection_base_url": ("collection_parameters.guardrails.jailbreak_detection_base_url", "="),
        "content_safety_model": ("collection_parameters.guardrails.content_safety_model.model_id", "="),
        "topic_control_model": ("collection_parameters.guardrails.topic_control_model.model_id", "="),
        "guardrails": ("collection_parameters.guardrails.guardrails_kind", "="),
        "ranking_base_url": ("collection_parameters.ranking_model.base_url", "="),
        "embeddings_model" : ("collection_parameters.embedding_model.model_id", "="),
        "chat_completion_model": ("collection_parameters.chat_model.model_id", "="),
        "search_algorithm": ("collection_parameters.train_params.search_algorithm", "="),
        "prompt": ("collection_parameters.chat_model.prompt", "="),
        "embeddings_dims": ("collection_parameters.embedding_model.embedding_dims", "=")
    },
    
    "prepare_response": {
        "question": ("question", "="),
        "chat_model": ("chat_model", ("s", "model_id")),
        "guardrails_model": ("guardrails", "*"),
        "enable_guardrails": ("guardrails.guardrails_kind", "="),
        "similar_objects": ("similar_objects", "="),
        "onnx_model": ("onnx_model", "*"),

        # Backward compatibility parameters.
        # Needs to be removed in future.
        "completions_base_url": ("chat_model.base_url", "="),
        "temperature": ("chat_model.temperature", "="),
        "prompt": ("chat_model.prompt", "=")
    }
}

def build_request(api_name: str, params: dict) -> dict:
    """
    DESCRIPTION:
        Builds the request dictionary for API calls using schema-based parameter mapping.
        This function converts user-friendly parameter names to the proper API request structure
        based on predefined schemas for different API endpoints. It handles parameter mapping,
        nested object creation, and value transformations according to the schema configuration.

    PARAMETERS:
        api_name:
            Required Argument.
            The name of the API endpoint (e.g., 'create', 'similarity_search', 'ask').
            Must be a key in the API_SCHEMAS dictionary.
            Types: str

        params:
            Required Argument.
            Dictionary of user parameters to be transformed into the API request format.
            Parameter names should match the keys in the corresponding API schema.
            Types: dict

    RETURNS:
        dict: Properly structured request dictionary ready for API consumption.
                The structure varies by API but typically includes sections like:
                - Root-level parameters (collection_type, target_database, etc.)
                - collection_parameters: Nested parameters for models, search config, etc.
                - collection_index: Index-related configuration

    EXAMPLES:
        >>> # Create API request
        >>> params = {
        ...     "type": "DOCUMENT",
        ...     "target_database": "my_db",
        ...     "embeddings_model": "text-embedding-ada-002",  # String -> model_id
        ...     "top_k": 10  # Maps to search_params.top_k
        ... }
        >>> request = build_request("create", params)
        >>> # Returns structured request with proper nesting
        
        >>> # Object serialization
        >>> embedding_model = MyEmbeddingModel()
        >>> params = {"embeddings_model": embedding_model}  # Calls to_dict()
        >>> request = build_request("create", params)
    """
    schema = API_SCHEMAS.get(api_name)
    if not schema:
        raise ValueError(f"Unknown API: {api_name}")
    
    if not isinstance(params, dict):
        raise TypeError("params must be a dictionary")
    
    request = {}
    params_copy = dict(params)  # Don't mutate original
    
    # Special handling for guardrails_model before schema loop
    guardrails_processed = False
    if "guardrails_model" in params_copy:
        guardrails_value = params_copy.pop("guardrails_model")
        guardrails_value = UtilFuncs._as_list(guardrails_value)
        guardrail_types_found = []

        for guardrail_obj in guardrails_value:                
                # Serialize the model
            if hasattr(guardrail_obj, 'to_dict') and callable(getattr(guardrail_obj, 'to_dict')):
                model_dict = guardrail_obj.to_dict()
            else:
                    # Fallback if not a proper object
                continue
                # Now get guardrail_type from the dict
            guardrail_type = model_dict.get("guardrail_type")
            if guardrail_type:
                guardrail_types_found.append(guardrail_type)
                
                # Route to correct path based on guardrail type
                if guardrail_type == "content_safety":
                    _set_nested_value(request, "collection_parameters.guardrails.content_safety_model", model_dict)
                elif guardrail_type == "topic_control":
                    _set_nested_value(request, "collection_parameters.guardrails.topic_control_model", model_dict)
                elif guardrail_type == "jailbreak_detection":
                    # Only base_url for jailbreak_detection
                    if "base_url" in model_dict:
                        _set_nested_value(request, "collection_parameters.guardrails.jailbreak_detection_base_url", model_dict["base_url"])
            
            guardrails_processed = True
            # Store found types for potential auto-population of guardrails_kind
            request["__guardrail_types_found__"] = guardrail_types_found

    # Post-processing: Auto-populate guardrails_kind if guardrails_model was processed but enable_guardrails was not provided
    if guardrails_processed and "__guardrail_types_found__" in request:
        guardrail_types_found = request.pop("__guardrail_types_found__")
        
        # If user didn't provide enable_guardrails, auto-populate from found guardrail types
        if "enable_guardrails" not in params_copy and guardrail_types_found:
            _set_nested_value(request, "collection_parameters.guardrails.guardrails_kind", guardrail_types_found)


    # Handle all params through schema with dotted path notation
    for user_param, (path, action) in schema.items():
        if user_param in params_copy:
            # Remove parameter from params_copy immediately to prevent it from 
            # falling through to collection_parameters section
            value = params_copy.pop(user_param)
            
            # Only process non-None values
            if value is not None:
                try:
                    # Special handling for ingest API files parameter
                    if api_name == "ingest" and user_param == "files":
                        # Process the files config object
                        files_config = value
                        
                        # Add overwrite parameters at request root level
                        if hasattr(files_config, 'overwrite_files') and files_config.overwrite_files is not None:
                            _set_nested_value(request, "overwrite_files", files_config.overwrite_files)
                        if hasattr(files_config, 'overwrite_objects') and files_config.overwrite_objects is not None:
                            _set_nested_value(request, "overwrite_objects", files_config.overwrite_objects)
                        
                        # Add files_parameters (only non-None file type and delimiter)
                        files_params = files_config.get_files_parameters()
                        if files_params:
                            for key, val in files_params.items():
                                _set_nested_value(request, f"files_parameters.{key}", val)
                        
                        # Handle storage location based on config type
                        from teradatagenai.vector_store.data_classes import LocalConfig
                        if not isinstance(files_config, LocalConfig):
                            # For cloud configs: use SERVICE_FIELDS mapping for proper serialization
                            storage_data = {}
                            
                            # Use the config's SERVICE_FIELDS to get the correct field mappings
                            if hasattr(files_config, 'SERVICE_FIELDS'):
                                for user_field, service_field in files_config.SERVICE_FIELDS.items():
                                    value = getattr(files_config, user_field, None)
                                    if value is not None:
                                        # Skip fields that belong in files_parameters or request root
                                        if service_field not in ['files_type', 'delimiter', 'overwrite_files', 'overwrite_objects']:
                                            storage_data[service_field] = value
                            
                            _set_nested_value(request, "storage_location", storage_data)
                        else:
                            # For LocalConfig: include processed files in JSON payload
                            local_config_data = files_config.to_dict()
                            processed_files = local_config_data.get("files")
                            if processed_files:
                                _set_nested_value(request, "files", processed_files)
                        
                        continue
                    
                    # Special handling for SearchParams objects
                    if user_param == "search_params" and hasattr(value, 'get_search_params'):
                        # Extract search_params and search_strategy sections separately
                        search_params_data = value.get_search_params()
                        search_strategy_data = value.get_search_strategy()
                        
                        # Use the actual path from schema instead of hardcoded collection_parameters
                        search_params_path = path  # This is the path from schema for search_params
                        search_strategy_path = path.replace("search_params", "search_strategy")
                        
                        if search_params_data:
                            _set_nested_value(request, search_params_path, search_params_data)
                        if search_strategy_data:
                            _set_nested_value(request, search_strategy_path, search_strategy_data)
                        continue
                    
                    # Handle different action types
                    if action == "*":  # Object with to_dict()
                        if hasattr(value, 'to_dict') and callable(getattr(value, 'to_dict')):
                            try:
                                serialized_value = value.to_dict()
                                # Remove ingestor field from final JSON as it's just metadata
                                value = serialized_value
                            except Exception as e:
                                raise ValueError(f"Failed to serialize parameter '{user_param}' using to_dict(): {str(e)}")
                        else:
                            pass  # If not serializable object, use value as-is
                    elif action == "=":  # Direct value assignment
                        if user_param in ["object_names", "key_columns", "data_columns"] and value is not None:
                            value = UtilFuncs._as_list(value)

                        if user_param == "object_names" and value is not None:
                            # Check if value contains DataFrame(s)
                            from teradataml import DataFrame
                            if isinstance(value, DataFrame) or (isinstance(value, list) and any(isinstance(v, DataFrame) for v in value)):
                                # Process DataFrames to get table references
                                processed_value = _ProcessDataFrameObjects(value)
                                _set_nested_value(request, path, processed_value)
                                continue
                        # Handle VECTOR/VECTOR32 types - convert to string representation
                        if user_param == "embedding_datatype":
                            arg_info_matrix = [
                                ["embedding_datatype", value, True, (VECTOR, VECTOR32), True] 
                            ]
                            _Validators._validate_function_arguments(arg_info_matrix)
                            # Accept both class references and instances
                            if value is VECTOR or isinstance(value, type(VECTOR)):
                                value = "VECTOR"
                            elif value is VECTOR32 or isinstance(value, type(VECTOR32)) or (hasattr(value, '__class__') and value.__class__.__name__ == 'VECTOR32'):
                                value = "VECTOR32"
                        # Normal direct assignment - value stays as-is
                        pass
                    elif isinstance(action, tuple) and action[0] == "s":  # String-or-object with configurable string field
                        string_field = action[1]  # Extract the field name for strings
                        if isinstance(value, str):
                            # String: map to specified field in the nested structure
                            try:
                                path_parts = path.split('.')
                                string_field_path = '.'.join(path_parts + [string_field])
                                _set_nested_value(request, string_field_path, value)
                                continue
                            except Exception as e:
                                raise ValueError(f"Failed to set string parameter '{user_param}' at path '{string_field_path}': {str(e)}")
                        else:
                            # Object: handle as usual with to_dict()
                            if hasattr(value, 'to_dict') and callable(getattr(value, 'to_dict')):
                                try:
                                    value = value.to_dict()
                                except Exception as e:
                                    raise ValueError(f"Failed to serialize parameter '{user_param}' using to_dict(): {str(e)}")
                            # Fall through to set at original path
                    
                    # Set value at dotted path
                    try:
                        # Special case: if path is empty, merge dict directly into request root
                        if not path and isinstance(value, dict):
                            request.update(value)
                        else:
                            _set_nested_value(request, path, value)
                    except Exception as e:
                        raise ValueError(f"Failed to set parameter '{user_param}' at path '{path}': {str(e)}")
                
                except (ValueError, TeradataMlException, TypeError):
                    # Re-raise ValueError and TeradataMlException directly
                    raise
                except Exception as e:
                    # Catch any other unexpected exceptions during parameter processing
                    raise RuntimeError(f"Unexpected error processing parameter '{user_param}': {str(e)}")
    
    return request


def _set_nested_value(request: dict, path: str, value) -> None:
    """
    DESCRIPTION:
        Set value at specified dotted path in nested dictionary structure.
        This utility function creates nested dictionary structures as needed and sets
        the final value at the specified path. It automatically creates intermediate
        dictionaries if they don't exist. Automatically skips None values.

    PARAMETERS:
        request:
            Required Argument.
            The target dictionary to modify. This is modified in-place.
            Types: dict

        path:
            Required Argument.
            Dot-separated path indicating where to set the value.
            Format: "key1.key2.key3" creates request[key1][key2][key3] = value
            Types: str

        value:
            Required Argument.
            The value to set at the specified path. Can be any type.
            If None, the function returns early without setting anything.
            Types: any

    RETURNS:
        None: Modifies the request dictionary in-place or does nothing if value is None.

    EXAMPLES:
        >>> request = {}
        >>> _set_nested_value(request, "collection_parameters.embedding_model.model_id", "ada-002")
        >>> # Result: {"collection_parameters": {"embedding_model": {"model_id": "ada-002"}}}
        
        >>> _set_nested_value(request, "some.path", None)
        >>> # Result: request unchanged (None values are ignored)
    """
    # Skip None values entirely
    if value is None:
        return
        
    keys = path.split('.')
    current = request
    
    # Navigate to parent dictionary
    for key in keys[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]
    
    # Set final value
    current[keys[-1]] = value