# ##################################################################
# 
# Copyright 2024-2025 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
#  
# ################################################################## 

version = "20.00.00.06"
