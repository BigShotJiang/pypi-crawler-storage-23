from .llm import TeradataAI
