# 
# ##################################################################
#
# Copyright 2024-2025 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Sushant Mhambrey (sushant.mhambrey@teradata.com)
# Secondary Owner: Aanchal Kavedia (aanchal.kavedia@teradata.com)
#                  Snigdha Biswas (snigdha.biswas@teradata.com)
#
# Notes:
#   * This code is only for internal use.
#   * The code is used for performing text analytics using ONNX 
#     models
# ##################################################################

import json
import os
import re
import sys
import warnings
from teradatagenai.text_analytics.TextAnalyticsAI import _TextAnalyticsAICommon
from teradataml import configure, retrieve_byom, DataFrame, ONNXEmbeddings, ONNXSeq2Seq
from teradatagenai.telemetry_utils.queryband import collect_queryband
from teradatagenai.common.utils import GenAIUtilFuncs
from teradataml.utils.validators import _Validators
from teradataml.common.exceptions import TeradataMlException

class _TextAnalyticsAIONNX(_TextAnalyticsAICommon):
    """
    Class holds methods for performing embedding generation 
    using ONNX models. 
    """
    def __init__(self, llm):
        """
        DESCRIPTION:
            Constructor for _TextAnalyticsAIONNX class.

        PARAMETERS:
           llm:
               Required Argument.
               Specifies the language model to be used.
               Types: TeradataAI instance
        
        RAISES:
            None
        
        RETURNS:
            None
        
        EXAMPLES:
            # Example 1: Create LLM endpoint and _TextAnalyticsAIONNX
            #            object using "api_type" as 'onnx'.
            >>> from teradatagenai import TeradataAI
            >>> llm_onnx= TeradataAI(api_type = "onnx",
                                     model_name = "bge-small-en-v1.5",
                                     model_id = "td-bge-small",
                                     model_path = "/path/to/onnx/model",
                                     tokenizer_path = "/path/to/onnx/tokenizer,
                                     table_name = "onnx_models")
            >>> obj = _TextAnalyticsAIONNX(llm=llm_onnx)
        """
        super().__init__(llm)

        self.__model_data = self.llm.model_data
        self.__tokenizer_data = self.llm.tokenizer_data

    def _exec(self,**kwargs):
        """
        DESCRIPTION:
            This internal method sets up Text Analytics AI methods.
    
        PARAMETERS:
            data:
                Required Argument.
                Specifies the teradataml DataFrame containing the column specified
                in "column" to analyze the content from.
                Types: teradataml DataFrame
    
            column:
                Required Argument.
                Specifies the column of the teradataml DataFrame containing the text 
                content to analyze.
                Types: str
    
            kwargs:
                Optional Arguments.
                Additional arguments to be passed to the text analytics task.
    
        RETURNS:
            teradataml DataFrame
    
        RAISES:
            TeradataMlException, TypeError, ValueError
    
        EXAMPLES:
            >>> self._exec(data=df_reviews, column="reviews", **kwargs)
        """
        # Determine which ONNX function to use based on context or explicit parameter
        onnx_function = kwargs.pop('_onnx_function', ONNXEmbeddings)
        column = kwargs.get("column", None)
        data = kwargs.get("data", None)

        validate_matrix = self._prepare_validate_matrix(**kwargs)
        self._validate_arguments(column=column, data=data, validate_matrix=validate_matrix)
        
        # Set queryband before crossing package boundary to teradataml
        GenAIUtilFuncs._set_queryband()
        
        # Validate if byom location is set
        _Validators()._validate_function_install_location_is_set(configure.byom_install_location, 
                                                                 "Bring Your Own Model", 
                                                                 "configure.byom_install_location")

        # Build the tokenizer DataFrame with the expected column names for ONNX functions.
        tokenizerdata = (
            self.__tokenizer_data
            .assign(tokenizer_id=self.__tokenizer_data.model_id,
                    tokenizer=self.__tokenizer_data.model)
        )

        # Set queryband before crossing package boundary to teradataml
        GenAIUtilFuncs._set_queryband()

        # Assign txt column to input dataframe
        data = data.assign(txt = data[column])
        try:
            # Set queryband before crossing package boundary to teradataml
            GenAIUtilFuncs._set_queryband()
            
            onnx_result = onnx_function(
                modeldata=self.__model_data.select(["model_id", "model"]),
                tokenizerdata=tokenizerdata.select(["tokenizer_id", "tokenizer"]),
                newdata=data,
                **kwargs
            )
            return onnx_result.result
        
        except TeradataMlException as e:
            raise e

    @collect_queryband(queryband="TAAI_embeddings_onnx")
    def embeddings(self, column, data, **kwargs):
        """
        DESCRIPTION:
            Method Calculates embedding values in
            Vantage with a model that has been created outside
            Vantage and exported to Vantage using ONNX format.

        PARAMETERS:
            data:
                Required Argument.
                Specifies the input teradataml DataFrame that contains
                the data to be scored.
                Types: teradataml DataFrame

            column:
                Required Argument.
                Specifies the name of the input teradataml DataFrame column 
                on which the embedding generation should be applied.
                Types: str

            accumulate:
                Required Argument.
                Specifies the name(s) of input teradataml DataFrame column(s) to
                copy to the output.
                Types: str OR list of strings

            model_output_tensor:
                Required Argument.
                Specifies which tensor model to use for output.
                Permitted Values: 'sentence_embedding', 'token_embeddings'
                Types: str

            encode_max_length:
                Optional Argument.
                Specifies the maximum length of the tokenizer output token
                encodings(only applies for models that do not have fixed dimension).
                Default Value: 512
                Types: int

            show_model_properties:
                Optional Argument.
                Specifies whether to display the input and output tensor
                properties of the model as a varchar column. When set to True, 
                scoring is not run and only the current model properties 
                are shown.
                Default Value: False
                Types: bool

            output_column_prefix:
                Optional Argument.
                Specifies the column prefix for each of the output columns
                when using float32 "output_format".
                Default Value: "emb_"
                Types: str

            output_format:
                Optional Argument.
                Specifies the output format for the model embeddings output.
                Permitted Values: "VARBYTE", "BLOB", "FLOAT32", and "VARCHAR"
                Default Value: "VARBYTE(3072)"
                Types: str

            persist:
                Optional Argument.
                Specifies whether to persist the results of the
                function in a table or not. When set to True,
                results are persisted in a table; otherwise,
                results are garbage collected at the end of the
                session.
                Default Value: False
                Types: bool

            volatile:
                Optional Argument.
                Specifies whether to put the results of the
                function in a volatile table or not. When set to
                True, results are stored in a volatile table,
                otherwise not.
                Default Value: False
                Types: bool

        RETURNS:
            teradataml DataFrame

        RAISES:
            TeradataMlException, TypeError, ValueError

        EXAMPLES:
            # Import the modules and create a teradataml DataFrame.
            >>> from teradatagenai import TeradataAI, TextAnalyticsAI, load_data
            >>> from teradataml import DataFrame
            >>> load_data("byom", "amazon_reviews_25")
            >>> amazon_reviews_25 = DataFrame.from_table("amazon_reviews_25")
            
            # Setup a TeradataAI onnx endpoint.
            >>> llm_onnx= TeradataAI(api_type = "onnx",
                                     model_name = "bge-small-en-v1.5",
                                     model_id = "td-bge-small",
                                     model_path = "/path/to/onnx/model",
                                     tokenizer_path = "/path/to/onnx/tokenizer,
                                     table_name = "onnx_models")

            # Example 1: Create a TextAnalyticsAI object and generate embeddings 
            #            for 'rev_text' column in amazon_reviews_25 teradataml dataframe.
            >>> obj = TextAnalyticsAI(llm=llm_onnx)
            >>> obj.embeddings(data=amazon_reviews_25,
                               column = "rev_text", 
                               accumulate= "rev_id",
                               model_output_tensor = "sentence_embedding")

            # Example 2: Create a TextAnalyticsAI object and generate embeddings 
            #            for 'rev_text' column in amazon_reviews_25 teradataml dataframe.
            #            Include 'rev_id' and 'rev_text' columns in the output dataframe
            #            and generate output embeddings in float32 format with 
            #            384 dimensions.
            >>> obj = TextAnalyticsAI(llm=llm_onnx)
            >>> obj.embeddings(data=amazon_reviews_25,
                               column = "rev_text", 
                               accumulate= "rev_id",
                               model_output_tensor = "sentence_embedding",
                               output_format = "FLOAT32(384)")
        """
        return self._exec(column=column, data=data, **kwargs)
    
    @collect_queryband(queryband="TAAI_seq2seq_onnx")
    def seq2seq(self, column, data, **kwargs):
        """
        DESCRIPTION:
            Method applies a sequence-to-sequence model in
            Vantage with a model that has been created outside
            Vantage and exported to Vantage using ONNX format.
        
        PARAMETERS:
            data:
                Required Argument.
                Specifies the input teradataml DataFrame that contains
                the data to be scored.
                Types: teradataml DataFrame
            
            column:
                Required Argument.
                Specifies the name of the input teradataml DataFrame column 
                on which the embedding generation should be applied.
                Types: str
            
            accumulate:
                Required Argument.
                Specifies the name(s) of input teradataml DataFrame column(s) to
                copy to the output.
                Types: str OR list of strings
            
            model_output_tensor:
                Required Argument.
                Specifies which tensor model to use for output.
                Permitted Values: 'sentence_embedding', 'token_embeddings'
                Types: str
            
            encode_max_length:
                Optional Argument.
                Specifies the maximum length of the tokenizer output token
                encodings(only applies for models that do not have fixed dimension).
                Default Value: 512
                Types: int
            
            show_model_properties:
                Optional Argument.
                Specifies whether to display the input and output tensor
                properties of the model as a varchar column. When set to True, 
                scoring is not run and only the current model properties 
                are shown.
                Default Value: False
                Types: bool

            output_length:
                Optional Argument.
                Specifies the output length for the model sequence output, in number of 
                characters for the VARCHAR output. If the value exceeds the maximum Unicode 
                VARCHAR size of 32000, a CLOB is created automatically.
                Default Value: 1000
                Types: int
            
            overwrite_cached_models:
                Optional Argument.
                Specifies the model name that needs to be removed from the cache.
                When a model loaded into the memory of the node fits in the cache,
                it stays in the cache until being evicted to make space for another
                model that needs to be loaded. Therefore, a model can remain in the
                cache even after the completion of function execution. Other functions
                that use the same model can use it, saving the cost of reloading it
                into memory. User should overwrite a cached model only when it is updated,
                to make sure that the Predict function uses the updated model instead
                of the cached model.
                Note:
                    Do not use the "overwrite_cached_models" argument except when user
                    is trying to replace a previously cached model. Using the argument
                    in other cases, including in concurrent queries or multiple times
                    within a short period of time lead to an OOM error.
                Default Value: "false"
                Permitted Values: true, t, yes, y, 1, false, f, no, n, 0, *,
                                  current_cached_model
                Types: str
            
            enable_memory_check:
                Optional Argument.
                Specifies whether there is enough native memory for large models.
                Default Value: True
                Types: bool
            
            skip_special_tokens:
                Optional Argument.
                Specifies whether to skip special tokens in the output.
                Default Value: True
                Types: bool
            
            const_*:
                Optional Argument.
                Specifies the constant value to be used as a model input by using 
                the argument name const_<field_name>. Providing constant values as 
                parameters reduces system overhead, since the value will not be 
                added to every row being scored.
                Types: str
            
            persist:
                Optional Argument.
                Specifies whether to persist the results of the
                function in a table or not. When set to True,
                results are persisted in a table; otherwise,
                results are garbage collected at the end of the
                session.
                Default Value: False
                Types: bool
            
            volatile:
                Optional Argument.
                Specifies whether to put the results of the
                function in a volatile table or not. When set to
                True, results are stored in a volatile table,
                otherwise not.
                Default Value: False
                Types: bool

        RETURNS:
            teradataml DataFrame
        
        RAISES:
            TeradataMlException, TypeError, ValueError
        
        EXAMPLES:
            # Import the modules and create a teradataml DataFrame.
            >>> from teradatagenai import TeradataAI, TextAnalyticsAI, load_data
            >>> from teradataml import DataFrame
            >>> load_data("byom", "JulesBelvezeDummyData")
            >>> jules_data = DataFrame.from_table("JulesBelvezeDummyData")
            
            # Setup a TeradataAI onnx endpoint.
            >>> llm_onnx= TeradataAI(api_type = "onnx",
                                     model_name = "t5-small-headline-generator",
                                     model_id = "t5-small-headline-generator_fixed",
                                     model_path = "/path/to/onnx/model",
                                     tokenizer_path = "/path/to/onnx/tokenizer",
                                     table_name = "seq_models")
            
            # Example 1: Create a TextAnalyticsAI object and apply seq-to-seq model 
            #            for 'content' column in jules_data teradataml dataframe.
            >>> obj = TextAnalyticsAI(llm=llm_onnx)
            >>> obj.seq2seq(data=jules_data,
                            column = "content", 
                            accumulate= "id",
                            model_output_tensor = "sequences")
            
            # Example 2: Create a TextAnalyticsAI object and apply seq-to-seq model 
            #            for 'content' column with constant values.
            >>> obj = TextAnalyticsAI(llm=llm_onnx)
            >>> obj.seq2seq(data=jules_data,
                            column = "content", 
                            accumulate= "id",
                            model_output_tensor = "sequences",
                            const_min_length=10,
                            const_max_length=84,
                            const_num_beams=4,
                            const_repetition_penalty=1.2,
                            const_length_penalty=2.0,
                            const_num_return_sequences=1)
        """
        return self._exec(column=column, data=data, _onnx_function=ONNXSeq2Seq, **kwargs)
