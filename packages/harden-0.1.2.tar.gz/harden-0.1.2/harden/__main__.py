"""Entry point for running harden as a module (python -m harden)."""

from harden.cli import main

if __name__ == "__main__":
    main()
