"""Post-install script to setup Playwright browsers"""
import subprocess
import sys

def install_playwright_browsers():
    """Install Playwright Chromium browser after package installation"""
    try:
        print("📦 Installing Playwright Chromium browser...")
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
        print("✓ Playwright Chromium installed successfully")
    except subprocess.CalledProcessError:
        print("⚠️ Failed to install Playwright browsers. Run manually: playwright install chromium")
    except Exception as e:
        print(f"⚠️ Playwright browser installation skipped: {e}")

if __name__ == "__main__":
    install_playwright_browsers()
