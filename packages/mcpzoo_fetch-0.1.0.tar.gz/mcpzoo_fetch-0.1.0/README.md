# mcpzoo-fetch

> 网页抓取 — 抓取指定 URL 的网页内容并返回纯文本

## Installation

```bash
uvx mcpzoo-fetch
```

## uvx JSON

```json
{
  "mcpServers": {
    "fetch": {
      "args": ["mcpzoo-fetch"],
      "command": "uvx"
    }
  }
}
```
