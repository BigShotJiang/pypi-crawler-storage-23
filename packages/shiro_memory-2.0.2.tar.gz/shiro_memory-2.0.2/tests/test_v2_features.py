"""
Tests for shiro-memory v2.0 features
- Enriched entry field serialization
- 10-layer search engine returning results
- Enrichment fields surviving load/save cycles
- re_enrich and recent methods
- Content hash generation
"""

import os
import tempfile
import unittest
from antaris_memory import MemorySystem, MemoryEntry


class TestV2Features(unittest.TestCase):

    def setUp(self):
        """Create temporary workspace for each test."""
        self.workspace = tempfile.mkdtemp()
        self.system = MemorySystem(self.workspace, half_life=30.0)

    def tearDown(self):
        """Clean up workspace."""
        import shutil
        shutil.rmtree(self.workspace, ignore_errors=True)

    def test_enriched_entry_serialization(self):
        """Test that new enrichment fields serialize and deserialize correctly."""
        # Create entry with enrichment fields
        entry = MemoryEntry(
            content="This is a test memory about database decisions",
            source="test",
            category="technical"
        )
        
        # Set enrichment fields
        entry.agent_id = "test-agent"
        entry.enriched_summary = "Summary about database decisions"
        entry.search_keywords = ["database", "decisions", "test"]
        
        # Verify content_hash is automatically generated
        self.assertTrue(len(entry.content_hash) > 0)
        self.assertEqual(len(entry.content_hash), 16)  # SHA256[:16]
        
        # Test serialization
        data = entry.to_dict()
        self.assertIn("agent_id", data)
        self.assertIn("enriched_summary", data)
        self.assertIn("search_keywords", data)
        self.assertIn("content_hash", data)
        
        # Test deserialization
        restored = MemoryEntry.from_dict(data)
        self.assertEqual(restored.agent_id, "test-agent")
        self.assertEqual(restored.enriched_summary, "Summary about database decisions")
        self.assertEqual(restored.search_keywords, ["database", "decisions", "test"])
        self.assertEqual(restored.content_hash, entry.content_hash)

    def test_search_returns_results_with_new_engine(self):
        """Test that the 10-layer search engine returns results."""
        self.system.load()
        
        # Ingest some test memories
        self.system.ingest("PostgreSQL database chosen for analytics", category="tech")
        self.system.ingest("Meeting with client about requirements", category="business")
        self.system.ingest("Database performance optimization needed", category="tech")
        
        # Test basic search returns MemoryEntry objects
        results = self.system.search("database")
        self.assertGreater(len(results), 0)
        
        # Results should be MemoryEntry objects
        for result in results:
            self.assertIsInstance(result, MemoryEntry)
            # Should have confidence score (set from relevance)
            self.assertIsInstance(result.confidence, (int, float))
        
        # Test search with explain=True returns SearchResult objects  
        explained_results = self.system.search("database", explain=True)
        self.assertGreater(len(explained_results), 0)
        
        # With explain=True, results should be SearchResult objects
        for result in explained_results:
            self.assertTrue(hasattr(result, 'entry'))
            self.assertTrue(hasattr(result, 'relevance'))
            self.assertIsInstance(result.relevance, (int, float))

    def test_enrichment_fields_survive_load_save(self):
        """Test that enrichment fields persist through save/load cycles."""
        self.system.load()
        
        # Create and ingest entry with enrichment
        entry = MemoryEntry(
            content="Important decision about architecture",
            source="meeting",
            category="strategic"
        )
        entry.agent_id = "architect-bot"
        entry.enriched_summary = "Decision summary about system architecture"
        entry.search_keywords = ["architecture", "decision", "system"]
        
        # Add to system and save
        self.system.memories.append(entry)
        self.system.save()
        
        # Create new system instance and load
        new_system = MemorySystem(self.workspace, half_life=30.0)
        new_system.load()
        
        # Find the entry and verify fields
        found = None
        for mem in new_system.memories:
            if mem.content == "Important decision about architecture":
                found = mem
                break
        
        self.assertIsNotNone(found)
        self.assertEqual(found.agent_id, "architect-bot")
        self.assertEqual(found.enriched_summary, "Decision summary about system architecture")
        self.assertEqual(found.search_keywords, ["architecture", "decision", "system"])
        self.assertTrue(len(found.content_hash) > 0)

    def test_re_enrich_method_exists(self):
        """Test that re_enrich method is available and callable."""
        self.system.load()
        
        # Should have re_enrich method
        self.assertTrue(hasattr(self.system, 're_enrich'))
        self.assertTrue(callable(getattr(self.system, 're_enrich')))
        
        # Should accept expected parameters
        count = self.system.re_enrich(batch_size=10, overwrite=False)
        self.assertIsInstance(count, int)
        self.assertEqual(count, 0)  # No enricher configured, so 0 entries enriched

    def test_recent_method_returns_newest_memories(self):
        """Test that recent method returns memories sorted by access time."""
        self.system.load()
        
        # Ingest memories with different timestamps
        entry1 = MemoryEntry("First memory", created="2024-01-01T10:00:00")
        entry2 = MemoryEntry("Second memory", created="2024-01-02T10:00:00") 
        entry3 = MemoryEntry("Third memory", created="2024-01-03T10:00:00")
        
        # Set different last_accessed times
        entry1.last_accessed = "2024-01-01T10:00:00"
        entry2.last_accessed = "2024-01-02T15:00:00"  # Most recent access
        entry3.last_accessed = "2024-01-01T12:00:00"
        
        self.system.memories = [entry1, entry2, entry3]
        
        # Get recent memories
        recent = self.system.recent(limit=2)
        
        self.assertEqual(len(recent), 2)
        # Should be sorted by last_accessed desc
        self.assertEqual(recent[0].content, "Second memory")  # Most recent
        self.assertEqual(recent[1].content, "Third memory")   # Second most recent


if __name__ == '__main__':
    unittest.main()