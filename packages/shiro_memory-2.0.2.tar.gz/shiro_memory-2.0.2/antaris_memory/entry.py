"""Memory entry — the atomic unit of memory."""

import hashlib
from datetime import datetime
from typing import Dict, List, Optional


class MemoryEntry:
    """Single memory unit with metadata, decay, sentiment, and confidence.

    Sprint 2 additions
    ------------------
    memory_type : str
        One of "episodic", "fact", "preference", "procedure", "mistake"
        or any custom string.  Defaults to "episodic".
    type_metadata : dict
        Type-specific structured data.  For mistakes this holds
        {"what_happened": ..., "correction": ..., "root_cause": ..., "severity": ...}.
        Empty for other types unless the caller populates it.
    
    v2.0 additions
    --------------
    agent_id : str
        Agent identifier for scoped memory access
    enriched_summary : str
        LLM-generated enriched summary of content
    search_keywords : List[str]
        Keywords extracted for enhanced search
    content_hash : str
        Hash computed from content for provenance
    """

    __slots__ = (
        "content", "source", "line", "category", "created",
        "last_accessed", "access_count", "importance", "confidence",
        "sentiment", "tags", "related", "hash",
        # Sprint 2
        "memory_type", "type_metadata",
        # v4.1: session isolation
        "session_id",
        # v2.0: enrichment fields
        "agent_id", "enriched_summary", "search_keywords", "content_hash",
    )

    def __init__(
        self,
        content: str,
        source: str = "",
        line: int = 0,
        category: str = "general",
        created: str = None,
        memory_type: str = "episodic",
    ):
        self.content = content
        self.source = source
        self.line = line
        self.category = category
        self.created = created or datetime.now().isoformat()
        self.last_accessed = self.created
        self.access_count: int = 0
        self.importance: float = 1.0
        self.confidence: float = 0.5
        self.sentiment: Dict[str, float] = {}
        self.tags: List[str] = []
        self.related: List[str] = []
        self.hash = hashlib.md5(
            f"{source}:{line}:{content[:100]}".encode()
        ).hexdigest()[:12]
        # Sprint 2
        self.memory_type: str = memory_type
        self.type_metadata: Dict = {}
        # v4.1: session isolation — empty string means "no session assigned"
        self.session_id: str = ""
        # v2.0: enrichment fields
        self.agent_id: str = ""
        self.enriched_summary: str = ""
        self.search_keywords: List[str] = []
        # Compute content hash from content
        self.content_hash: str = hashlib.sha256(content.encode()).hexdigest()[:16]

    # -- serialisation --------------------------------------------------------

    def to_dict(self) -> Dict:
        d = {
            "hash": self.hash,
            "content": self.content,
            "source": self.source,
            "line": self.line,
            "category": self.category,
            "created": self.created,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
            "importance": round(self.importance, 4),
            "confidence": round(self.confidence, 4),
            "sentiment": self.sentiment,
            "tags": self.tags,
            "related": self.related,
        }
        # Sprint 2 — only write if non-default to keep file size stable
        if self.memory_type and self.memory_type != "episodic":
            d["memory_type"] = self.memory_type
        if self.type_metadata:
            d["type_metadata"] = self.type_metadata
        # v4.1: session_id — only write if set
        if self.session_id:
            d["session_id"] = self.session_id
        # v2.0: enrichment fields — only write if set
        if self.agent_id:
            d["agent_id"] = self.agent_id
        if self.enriched_summary:
            d["enriched_summary"] = self.enriched_summary
        if self.search_keywords:
            d["search_keywords"] = self.search_keywords
        if self.content_hash:
            d["content_hash"] = self.content_hash
        return d

    @classmethod
    def from_dict(cls, d: Dict) -> "MemoryEntry":
        m = cls(
            d["content"], d.get("source", ""), d.get("line", 0),
            d.get("category", "general"), d.get("created"),
            memory_type=d.get("memory_type", "episodic"),
        )
        m.last_accessed = d.get("last_accessed", m.created)
        m.access_count = d.get("access_count", 0)
        m.importance = d.get("importance", 1.0)
        m.confidence = d.get("confidence", 0.5)
        m.sentiment = d.get("sentiment", {})
        m.tags = d.get("tags", [])
        m.related = d.get("related", [])
        m.hash = d.get("hash", m.hash)
        m.type_metadata = d.get("type_metadata", {})
        # v4.1: session_id
        m.session_id = d.get("session_id", "")
        # v2.0: enrichment fields
        m.agent_id = d.get("agent_id", "")
        m.enriched_summary = d.get("enriched_summary", "")
        m.search_keywords = d.get("search_keywords", [])
        m.content_hash = d.get("content_hash", "")
        return m

    def __repr__(self) -> str:
        return (
            f"<Memory {self.hash} type={self.memory_type} "
            f"score={self.importance:.2f} conf={self.confidence:.2f}>"
        )