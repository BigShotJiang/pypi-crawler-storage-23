"""
Search engine for antaris-memory v5.0.0.

Provides ranked search with BM25-inspired scoring, combining:
- Layer 1: Term frequency / inverse document frequency (BM25)
- Layer 2: Exact phrase bonus
- Layer 3: Field boosting (tags, source, category)
- Layer 4: Rarity boost + proper noun boost
- Layer 5: Sliding window context (with positional salience v5.0)
- Layer 6: Semantic (QueryExpander + PPMIBootstrap + CategoryTagger)
- Layer 7: Intent reranker (post-scoring) — v5.0
- Layer 8: Qualifier & negation sensitivity (post-scoring) — v5.0
- Layer 9: Cross-memory clustering (post-scoring) — v5.0

All deterministic, zero dependencies.
"""

import logging
import math
import os
import re
from collections import Counter
from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass
from .category_tagger import CategoryTagger

# Module-level singleton to avoid re-instantiating per search call
_category_tagger = CategoryTagger()

from .query_expansion import QueryExpander
from .ppmi_bootstrap import PPMIBootstrap
from .windowing import WindowIndexer
from .clustering import ClusterIndex

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# Layer 7 — Intent Reranker
# ═══════════════════════════════════════════════════════════════════════════

class IntentReranker:
    """Classify query intent and re-score candidates by structural match.

    Intents:
        temporal    — "when", "what time", "how long ago", "date of"
        entity      — "who", "which person", "whose", "name of"
        event       — "what happened", "tell me about", "describe"
        decision    — "did we decide", "what was decided", "choice", "agreed"
        comparison  — "vs", "compare", "difference between", "better"
        howto       — "how to", "how do", "steps to", "way to"
        quantity    — "how much", "how many", "count", "total", "amount"
        location    — "where", "which place", "location of"

    Each intent has associated memory-side signals that get boosted when found.
    """

    # Query-side intent detection patterns
    INTENT_PATTERNS = {
        "temporal": [
            re.compile(r'\b(when|what\s+time|how\s+long\s+ago|date\s+of|what\s+date|timeline|since\s+when)\b', re.I),
            re.compile(r'\b(before|after|during|yesterday|last\s+week|last\s+month|recently)\b', re.I),
        ],
        "entity": [
            re.compile(r'\b(who|whose|which\s+person|name\s+of|who\'s|whom)\b', re.I),
        ],
        "event": [
            re.compile(r'\b(what\s+happened|tell\s+me\s+about|describe|incident|event|occurred|took\s+place)\b', re.I),
        ],
        "decision": [
            re.compile(r'\b(decid|decision|agreed|chose|choice|settled\s+on|went\s+with|conclusion|resolved\s+to)\b', re.I),
        ],
        "comparison": [
            re.compile(r'\b(vs\.?|versus|compar|difference\s+between|better\s+than|worse\s+than|pros?\s+and\s+cons?)\b', re.I),
        ],
        "howto": [
            re.compile(r'\b(how\s+to|how\s+do|how\s+can|steps?\s+to|way\s+to|process\s+for|instructions?)\b', re.I),
        ],
        "quantity": [
            re.compile(r'\b(how\s+much|how\s+many|count|total|amount|number\s+of|sum\s+of)\b', re.I),
        ],
        "location": [
            re.compile(r'\b(where|which\s+place|location\s+of|located)\b', re.I),
        ],
    }

    # Memory-side signals that indicate a memory satisfies an intent
    MEMORY_SIGNALS = {
        "temporal": [
            # ISO dates, relative dates, timestamps
            re.compile(r'\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b'),
            re.compile(r'\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+\d{1,2}\b', re.I),
            re.compile(r'\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b', re.I),
            re.compile(r'\b(?:yesterday|today|last\s+week|last\s+month|ago|since)\b', re.I),
            re.compile(r'\b\d{1,2}:\d{2}\b'),  # time patterns
        ],
        "entity": [
            # Capitalized names (rough proxy for named entities)
            re.compile(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b'),
            re.compile(r'\b(?:@\w+)\b'),  # @mentions
        ],
        "event": [
            re.compile(r'\b(?:happened|occurred|incident|outage|launched|shipped|broke|failed|succeeded|completed)\b', re.I),
        ],
        "decision": [
            re.compile(r'\b(?:decided|agreed|chose|picked|selected|went\s+with|settled|concluded|resolution)\b', re.I),
        ],
        "comparison": [
            re.compile(r'\b(?:vs\.?|versus|compared|better|worse|faster|slower|cheaper|pros?|cons?)\b', re.I),
        ],
        "howto": [
            re.compile(r'\b(?:step\s+\d|first|then|next|finally|instructions?|guide|tutorial|procedure)\b', re.I),
        ],
        "quantity": [
            re.compile(r'\$[\d,.]+|\b\d+[kmb]?\b', re.I),
            re.compile(r'\b(?:total|sum|count|amount|percent|ratio)\b', re.I),
        ],
        "location": [
            re.compile(r'\b(?:office|building|room|floor|city|country|region|location|address|remote|onsite)\b', re.I),
        ],
    }

    # Boost applied when a memory matches the detected intent
    INTENT_BOOST = 1.25
    # Penalty applied when a memory contradicts the detected intent
    # (e.g., query asks "when" but memory has zero temporal signals)
    INTENT_PENALTY = 0.85

    @classmethod
    def detect_intent(cls, query: str) -> List[str]:
        """Detect intent(s) from the query. Returns list of intent names.

        A query can match multiple intents (e.g., "when did we decide" →
        ["temporal", "decision"]).
        """
        intents = []
        for intent_name, patterns in cls.INTENT_PATTERNS.items():
            for pattern in patterns:
                if pattern.search(query):
                    intents.append(intent_name)
                    break  # one match per intent is enough
        return intents

    @classmethod
    def score_intent_match(cls, content: str, intents: List[str]) -> float:
        """Score how well a memory's content matches the detected intents.

        Returns a multiplier: >1.0 = boost, <1.0 = penalty, 1.0 = neutral.
        """
        if not intents:
            return 1.0

        matches = 0
        for intent in intents:
            signals = cls.MEMORY_SIGNALS.get(intent, [])
            for signal in signals:
                if signal.search(content):
                    matches += 1
                    break  # one signal match per intent is enough

        if matches == len(intents):
            # Memory satisfies all detected intents
            return cls.INTENT_BOOST
        elif matches > 0:
            # Partial match — mild boost
            return 1.0 + (cls.INTENT_BOOST - 1.0) * (matches / len(intents))
        else:
            # No intent signals found — mild penalty
            return cls.INTENT_PENALTY

    @classmethod
    def rerank(cls, query: str, results: list) -> list:
        """Rerank results based on intent match.

        Parameters
        ----------
        query : str
            Original search query.
        results : list
            List of (entry, score, matched_terms) tuples.

        Returns
        -------
        list
            Same tuples with adjusted scores, re-sorted.
        """
        intents = cls.detect_intent(query)
        if not intents:
            return results  # no intent detected, skip

        reranked = []
        for entry, score, matched in results:
            multiplier = cls.score_intent_match(entry.content, intents)
            new_score = score * multiplier
            reranked.append((entry, new_score, matched))

        reranked.sort(key=lambda x: x[1], reverse=True)
        return reranked


# ═══════════════════════════════════════════════════════════════════════════
# Layer 8 — Qualifier & Negation Sensitivity
# ═══════════════════════════════════════════════════════════════════════════

class QualifierAnalyzer:
    """Analyze temporal, outcome, negation, and degree qualifiers.

    Detects qualifiers in both queries and memories, then computes an
    alignment score: matched qualifiers boost, mismatched penalize.
    """

    # Qualifier categories with their antonyms / conflict groups
    TEMPORAL_BEFORE = frozenset({
        'before', 'prior', 'previously', 'earlier', 'preceding',
        'pre', 'until', 'up_to', 'leading_up',
    })
    TEMPORAL_AFTER = frozenset({
        'after', 'following', 'subsequently', 'later', 'since',
        'post', 'once', 'afterward',
    })
    TEMPORAL_DURING = frozenset({
        'during', 'while', 'meanwhile', 'concurrent', 'simultaneously',
        'at_the_time', 'in_progress',
    })

    OUTCOME_SUCCESS = frozenset({
        'succeeded', 'successful', 'passed', 'completed', 'resolved',
        'fixed', 'shipped', 'launched', 'achieved', 'won', 'approved',
        'merged', 'deployed', 'delivered', 'working', 'green',
    })
    OUTCOME_FAILURE = frozenset({
        'failed', 'failure', 'broke', 'broken', 'crashed', 'rejected',
        'denied', 'cancelled', 'abandoned', 'reverted', 'rolled_back',
        'missed', 'lost', 'red', 'blocked', 'errored',
    })

    NEGATION = frozenset({
        'not', 'never', 'no', 'without', 'none', "didn't", "doesn't",
        "wasn't", "weren't", "isn't", "aren't", "don't", "won't",
        "can't", "couldn't", "shouldn't", "wouldn't", "hasn't", "haven't",
        'neither', 'nor', 'nothing', 'nowhere',
    })

    DEGREE_MOST = frozenset({
        'most', 'best', 'highest', 'maximum', 'top', 'greatest',
        'largest', 'biggest', 'primary', 'main', 'first',
    })
    DEGREE_LEAST = frozenset({
        'least', 'worst', 'lowest', 'minimum', 'bottom', 'smallest',
        'fewest', 'last', 'final', 'minor',
    })

    # Scoring constants
    MATCH_BOOST = 1.15       # qualifier alignment bonus
    MISMATCH_PENALTY = 0.80  # qualifier conflict penalty
    NEGATION_PENALTY = 0.75  # negation mismatch penalty

    @classmethod
    def _extract_qualifiers(cls, text: str) -> Dict[str, str]:
        """Extract qualifier categories from text.

        Returns dict of {category: direction}, e.g.:
            {"temporal": "before", "outcome": "failure", "negation": "present"}
        """
        # Normalize contractions and tokenize
        text_lower = text.lower()
        # Handle contractions for negation detection
        text_norm = text_lower.replace("'", "'")
        tokens = set(re.findall(r"[\w']+", text_norm))

        qualifiers = {}

        # Temporal
        if tokens & cls.TEMPORAL_BEFORE:
            qualifiers["temporal"] = "before"
        elif tokens & cls.TEMPORAL_AFTER:
            qualifiers["temporal"] = "after"
        elif tokens & cls.TEMPORAL_DURING:
            qualifiers["temporal"] = "during"

        # Outcome
        if tokens & cls.OUTCOME_SUCCESS:
            qualifiers["outcome"] = "success"
        if tokens & cls.OUTCOME_FAILURE:
            # If both present, mark as "mixed" — no penalty either way
            if qualifiers.get("outcome") == "success":
                qualifiers["outcome"] = "mixed"
            else:
                qualifiers["outcome"] = "failure"

        # Negation
        if tokens & cls.NEGATION:
            qualifiers["negation"] = "present"

        # Degree
        if tokens & cls.DEGREE_MOST:
            qualifiers["degree"] = "most"
        elif tokens & cls.DEGREE_LEAST:
            qualifiers["degree"] = "least"

        return qualifiers

    @classmethod
    def compute_alignment(cls, query: str, content: str) -> float:
        """Compute qualifier alignment between query and memory content.

        Returns a multiplier: >1.0 = aligned, <1.0 = conflicting, 1.0 = neutral.
        """
        q_quals = cls._extract_qualifiers(query)
        m_quals = cls._extract_qualifiers(content)

        if not q_quals:
            return 1.0  # no qualifiers in query, nothing to check

        multiplier = 1.0

        for category, q_direction in q_quals.items():
            m_direction = m_quals.get(category)

            if category == "negation":
                # If query has negation but memory doesn't (or vice versa),
                # this is a likely mismatch
                if q_direction == "present" and m_direction != "present":
                    # Query says "not X" — memory that says "X" is probably wrong
                    multiplier *= cls.NEGATION_PENALTY
                continue

            if m_direction is None:
                # Memory has no signal for this qualifier — neutral
                continue

            if m_direction == "mixed":
                # Memory has both signals — neutral
                continue

            if q_direction == m_direction:
                # Aligned — boost
                multiplier *= cls.MATCH_BOOST
            else:
                # Conflicting — penalize
                multiplier *= cls.MISMATCH_PENALTY

        return multiplier

    @classmethod
    def apply(cls, query: str, results: list) -> list:
        """Apply qualifier sensitivity to search results.

        Parameters
        ----------
        query : str
            Original search query.
        results : list
            List of (entry, score, matched_terms) tuples.

        Returns
        -------
        list
            Same tuples with adjusted scores, re-sorted.
        """
        # Quick check: does the query even have qualifiers?
        q_quals = cls._extract_qualifiers(query)
        if not q_quals:
            return results  # no qualifiers, skip entirely

        adjusted = []
        for entry, score, matched in results:
            multiplier = cls.compute_alignment(query, entry.content)
            new_score = score * multiplier
            adjusted.append((entry, new_score, matched))

        adjusted.sort(key=lambda x: x[1], reverse=True)
        return adjusted


# ═══════════════════════════════════════════════════════════════════════════
# SearchResult + SearchEngine
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SearchResult:
    """A search result with relevance score and explanation."""
    entry: object  # MemoryEntry
    score: float
    relevance: float  # 0.0-1.0 normalized
    matched_terms: List[str]
    explanation: str
    
    @property
    def content(self):
        return self.entry.content
    
    @property
    def source(self):
        return self.entry.source
    
    @property
    def confidence(self):
        return self.relevance
    
    @property
    def category(self):
        return self.entry.category
    
    def __repr__(self):
        return f"<SearchResult score={self.score:.3f} relevance={self.relevance:.2f} '{self.content[:50]}...'>"


class SearchEngine:
    """BM25-inspired search engine for memory entries.
    
    Computes relevance using term frequency, inverse document frequency,
    field boosting, and decay weighting. All operations are deterministic
    and use only the Python standard library.

    v5.0 additions:
    - Layer 7: Intent reranker (post-scoring)
    - Layer 8: Qualifier & negation sensitivity (post-scoring)
    - Layer 9: Cross-memory clustering (post-scoring, via ClusterIndex)
    - Layer 5 enhancement: Positional salience (first/last window boost)
    - All new layers have bypass flags (use_layer7, use_layer8, use_layer9)
    
    Args:
        k1: Term frequency saturation parameter (default 1.5)
        b: Length normalization parameter (default 0.75)
    """
    
    # Stopwords to exclude from scoring (common English words)
    STOPWORDS = frozenset({
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'shall', 'can', 'need', 'dare', 'ought',
        'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from',
        'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
        'between', 'out', 'off', 'over', 'under', 'again', 'further', 'then',
        'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both',
        'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
        'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just',
        'don', 'now', 'and', 'but', 'or', 'if', 'while', 'that', 'this',
        'it', 'its', 'he', 'she', 'they', 'them', 'his', 'her', 'their',
        'what', 'which', 'who', 'whom', 'these', 'those', 'am', 'about',
        'up', 'down', 'we', 'our', 'you', 'your', 'my', 'me', 'i',
    })
    
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self._idf_cache: Dict[str, float] = {}
        self._avg_doc_len: float = 0
        self._doc_count: int = 0
        self._doc_freqs: Counter = Counter()  # term → number of docs containing it
        self._corpus_version: int = 0
        self._indexed_version: int = -1
        # Content fingerprint: lightweight hash of all memory content at index time.
        # Detects in-place content mutations that don't change the memory count
        # (e.g. tag updates, content edits) — fixes search index drift (Gemini review).
        self._content_fingerprint: int = 0
        self._expander = QueryExpander()
        self._ppmi = PPMIBootstrap()
        # v5.0: Cross-memory clustering (Layer 9)
        self._cluster_index = ClusterIndex()
        # v4.9.6: Cached sliding windows (Layer 5) — rebuilt in build_index(), not per-search.
        # Building windows is O(n) and was previously re-run on every single search call.
        self._cached_windows: list = []
        self._window_size: int = 3
        self._window_stride: int = 1

    @staticmethod
    def _compute_fingerprint(memories: list) -> int:
        """XOR hash of all memory content hashes — cheap O(n) mutation detector."""
        fp = 0
        for m in memories:
            fp ^= hash(m.content)
        return fp

    def build_index(self, memories: list) -> None:
        """Build IDF statistics from the memory corpus.
        
        Call this after loading/ingesting memories to enable proper ranking.
        v5.0: Also builds cluster index for Layer 9.
        """
        self._indexed_version = self._corpus_version
        self._content_fingerprint = self._compute_fingerprint(memories)
        self._doc_count = len(memories)
        self._doc_freqs.clear()
        self._idf_cache.clear()
        self._token_cache: Dict[str, Tuple[List[str], List[str], List[str], Counter]] = {}
        self._inverted_index: Dict[str, Set[str]] = {}  # token → set of memory hashes
        
        total_len = 0
        for mem in memories:
            tokens = self._tokenize(mem.content)
            total_len += len(tokens)
            # Count unique terms per document
            for term in set(tokens):
                self._doc_freqs[term] += 1
            
            # Cache tokenization for _score_entry() reuse
            enriched_tokens = self._tokenize(mem.enriched_summary) if getattr(mem, "enriched_summary", "") else []
            keyword_tokens = []
            if getattr(mem, "search_keywords", []):
                for kw in mem.search_keywords:
                    keyword_tokens.extend(self._tokenize(str(kw)))
            all_tokens = tokens + enriched_tokens + keyword_tokens
            e_lower = mem.enriched_summary.lower() if getattr(mem, "enriched_summary", "") else ""
            self._token_cache[mem.hash] = (tokens, enriched_tokens, all_tokens, Counter(all_tokens), e_lower)
            
            # Build inverted index: for each unique token, add memory hash
            for token in set(all_tokens):
                if token not in self._inverted_index:
                    self._inverted_index[token] = set()
                self._inverted_index[token].add(mem.hash)
        
        self._avg_doc_len = total_len / max(self._doc_count, 1)
        
        # Pre-compute IDF for all terms
        for term, df in self._doc_freqs.items():
            # BM25 IDF formula with smoothing
            self._idf_cache[term] = math.log(
                (self._doc_count - df + 0.5) / (df + 0.5) + 1.0
            )

        # v4.9.6: Build sliding window cache (Layer 5) here, not per-search.
        # WindowIndexer.build_windows() is O(n) — acceptable at index time, not query time.
        if len(memories) >= 2:
            try:
                _win_indexer = WindowIndexer(
                    window_size=self._window_size,
                    stride=self._window_stride,
                )
                self._cached_windows = _win_indexer.build_windows(memories)
            except Exception:
                self._cached_windows = []
        else:
            self._cached_windows = []

        # NOTE: Cluster index (Layer 9) is intentionally NOT rebuilt here.
        # build_index() is called on every search when the corpus changes, making
        # cluster rebuild O(n×e) per search — unacceptably slow at scale.
        # Call rebuild_clusters() explicitly after bulk ingestion or via flush().

    def rebuild_clusters(self, memories: list) -> None:
        """Rebuild the Layer 9 cluster index from the given memory corpus.

        Decoupled from build_index() intentionally — cluster building is O(n×e)
        and should run at write time (flush/bulk-ingest), not on every search.

        Called automatically by MemorySystemV4.flush() and rebuild_clusters().
        """
        try:
            self._cluster_index.build(memories)
        except Exception:
            pass  # Non-fatal — Layer 9 boost is additive, search works without it

    def _rarity_boost(self, term: str) -> float:
        """Return a boost multiplier based on how rarely a term appears across documents.

        Tiers:
          - <= 1%  of docs  → 2.0  (very rare / highly specific)
          - 1–5%  of docs  → 1.5
          - 5–15% of docs  → 1.2
          - >15%  of docs  → 1.0  (common, no boost)

        Falls back to 1.0 when the index is empty or the term is unknown.
        """
        if self._doc_count == 0:
            return 1.0
        df = self._doc_freqs.get(term, 0)
        if df == 0:
            # Term not in corpus at all — treat as maximally rare
            return 2.0
        ratio = df / self._doc_count
        if ratio <= 0.01:
            return 2.0
        elif ratio <= 0.05:
            return 1.5
        elif ratio <= 0.15:
            return 1.2
        else:
            return 1.0

    @staticmethod
    def _is_proper_noun(term: str, capitalized_terms: set) -> bool:
        """Heuristic: returns True if *term* was written in Title-case in the query."""
        return term in capitalized_terms

    def search(self, query: str, memories: list, limit: int = 20,
               category: str = None, min_score: float = 0.01,
               decay_fn=None, session_id: Optional[str] = None,
               use_windows: bool = True,
               window_size: int = 3, window_stride: int = 1,
               agent_id: Optional[str] = None,
               # v5.0: New layer toggles
               use_layer7: bool = True,
               use_layer8: bool = True,
               use_layer9: bool = True,
               positional_boost: float = 1.3,
               index_manager=None,
               ) -> List[SearchResult]:
        """Search memories with BM25-inspired ranking.

        Args:
            query: Search query string
            memories: List of MemoryEntry objects to search
            limit: Maximum results to return
            category: Filter by category (optional)
            min_score: Minimum relevance score threshold
            decay_fn: Optional decay scoring function (entry → float)
            session_id: Session isolation filter.
                - None (default): defaults to '*' for backward compat.
                - '*': Return memories across all sessions.
                - <string>: Return only memories belonging to that session.
            use_windows: Enable/disable Layer 5 sliding window scoring.
            window_size: Number of entries per window (Layer 5).
            window_stride: Step size between windows (Layer 5).
            agent_id: Filter by agent_id (v4.5.4).
            use_layer7: Enable/disable Layer 7 intent reranker (v5.0).
            use_layer8: Enable/disable Layer 8 qualifier sensitivity (v5.0).
            use_layer9: Enable/disable Layer 9 cross-memory clustering (v5.0).
            positional_boost: First/last window boost factor (v5.0, default 1.3).

        Returns:
            List of SearchResult objects, sorted by relevance descending.
        """
        # ── session_id guard (Issue #7) ──────────────────────────────────────
        if session_id is None:
            session_id = '*'

        # ── Layer 6: Query expansion + PPMI ──────────────────────────────────
        original_query = query  # preserve for Layer 7/8 intent detection
        query = self._expander.expand(query)
        query = self._ppmi.expand_query(query)

        # ── proper-noun detection (Layer 4) ─────────────────────────────────
        raw_words = query.split()
        capitalized_terms: set = set()
        for word in raw_words[1:]:           # skip first word
            stripped = re.sub(r'[^\w]', '', word)
            if stripped and stripped[0].isupper():
                capitalized_terms.add(stripped.lower())

        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []

        if not memories:
            return []

        # ── Issue #3 fix: Always build index on FULL corpus for correct IDF ──
        current_fp = self._compute_fingerprint(memories)
        if (self._indexed_version != self._corpus_version
                or self._doc_count != len(memories)
                or self._content_fingerprint != current_fp):
            self.build_index(memories)

        # ── Issue #2: Index-based candidate pre-filter ────────────────────────
        candidate_hashes = None
        if index_manager is not None:
            try:
                indexed = index_manager.search(query=original_query, limit=limit * 3)
                if indexed:
                    candidate_hashes = {h for h, _ in indexed}
            except Exception:
                pass  # Fall back to full scan

        # ── Inverted index candidate filtering ────────────────────────────────
        # Use inverted index to collect candidates matching at least one query term
        inverted_candidates = set()
        if hasattr(self, '_inverted_index'):
            for token in query_tokens:
                inverted_candidates.update(self._inverted_index.get(token, set()))

        # ── Layers 1-4: Score each entry ──────────────────────────────────────
        # v4.9.6: Pre-compute query categories ONCE (was called per-entry, 83% of search cost)
        _query_cats = set(_category_tagger.tag(query.lower()))

        results = []
        max_score = 0.0

        for mem in memories:
            # Issue #2: Skip non-candidates when index available
            if candidate_hashes is not None and mem.hash not in candidate_hashes:
                continue
            
            # Inverted index filtering: only score entries with at least one matching term
            # If no candidates found, fall back to scoring all entries (safety net)
            if inverted_candidates and mem.hash not in inverted_candidates:
                continue

            if category and mem.category != category:
                continue

            # Issue #3: Session/agent filtering moved to scoring loop (post-index)
            if session_id != "*":
                if getattr(mem, "session_id", "") != session_id:
                    continue
            if agent_id:
                mem_agent = getattr(mem, "agent_id", None)
                if mem_agent and mem_agent != agent_id:
                    continue
            
            score, matched = self._score_entry(mem, query_tokens, query.lower(), capitalized_terms, _query_cats)
            
            if score <= 0:
                continue
            
            # Apply decay weighting if available
            if decay_fn:
                decay_score = decay_fn(mem)
                score *= (0.3 + 0.7 * decay_score)
            
            max_score = max(max_score, score)
            results.append((mem, score, matched))
        
        # ── Layer 5: Sliding Window scoring + Positional Salience ────────────
        # v4.9.6: Use cached windows built at index time (build_index()) instead of
        # rebuilding the entire window set on every search call. Falls back to
        # a live rebuild only when custom window params differ from the cached defaults.
        if use_windows and len(memories) >= 2:
            if (window_size == self._window_size and window_stride == self._window_stride
                    and self._cached_windows):
                windows = self._cached_windows
            else:
                _indexer = WindowIndexer(window_size=window_size, stride=window_stride)
                windows = _indexer.build_windows(memories)

            # Total number of windows for positional salience calculation
            total_windows = len(windows)

            entry_score_map: Dict[str, float] = {
                mem.hash: score for mem, score, _ in results
            }

            # v5.0.1: Only score windows containing at least one BM25-relevant entry
            scored_hashes = {mem.hash for mem, score, _ in results if score > 0}

            window_raw: List[Tuple[object, float, List[str]]] = []
            for win in windows:
                # Skip windows with no scored constituents
                if scored_hashes and not any(sid in scored_hashes for sid in win.source_ids):
                    continue
                if category and win.category != category:
                    continue
                w_score, w_matched = self._score_entry(
                    win, query_tokens, query.lower(), capitalized_terms, _query_cats
                )
                if w_score <= 0:
                    continue
                if decay_fn:
                    try:
                        first_hash = win.source_ids[0]
                        first_entry = next(
                            m for m in memories if m.hash == first_hash
                        )
                        decay_score = decay_fn(first_entry)
                        w_score *= (0.3 + 0.7 * decay_score)
                    except StopIteration:
                        pass

                # ── v5.0: Positional salience ────────────────────────────
                # First and last windows get a configurable boost.
                # These positions typically contain topic-setting and
                # concluding information that's most retrieval-relevant.
                if total_windows > 2 and positional_boost > 1.0:
                    if win.window_index == 0 or win.window_index == total_windows - 1:
                        w_score *= positional_boost

                max_score = max(max_score, w_score)
                window_raw.append((win, w_score, w_matched))

            # Deduplication: window vs constituent entries
            hashes_to_remove: set = set()
            for win, w_score, w_matched in window_raw:
                constituent_scores = [
                    entry_score_map.get(h, 0.0) for h in win.source_ids
                ]
                if constituent_scores and w_score > max(constituent_scores):
                    hashes_to_remove.update(win.source_ids)
                    results.append((win, w_score, w_matched))

            if hashes_to_remove:
                results = [
                    (m, s, mt) for m, s, mt in results
                    if m.hash not in hashes_to_remove
                ]

        # ── Layer 7: Intent Reranker (post-scoring) ──────────────────────────
        if use_layer7 and results:
            results = IntentReranker.rerank(original_query, results)

        # ── Layer 8: Qualifier & Negation Sensitivity (post-scoring) ─────────
        if use_layer8 and results:
            results = QualifierAnalyzer.apply(original_query, results)

        # ── Normalize scores to 0-1 range ────────────────────────────────────
        # Recalculate max_score after Layers 7+8 may have changed scores
        if results:
            max_score = max(score for _, score, _ in results)

        if max_score > 0:
            normalized = []
            for mem, score, matched in results:
                relevance = score / max_score
                if relevance < min_score:
                    continue

                explanation = self._explain(matched, score, relevance)
                normalized.append(SearchResult(
                    entry=mem,
                    score=score,
                    relevance=round(relevance, 4),
                    matched_terms=matched,
                    explanation=explanation,
                ))
            results = normalized
        else:
            return []

        # ── Layer 9: Cross-Memory Clustering (post-normalization) ────────────
        # Applied AFTER normalization so boost_neighbors() receives SearchResult
        # objects (which have .entry.hash, .score, .matched_terms, .explanation).
        if use_layer9 and results and self._cluster_index._built:
            results = self._cluster_index.apply_cluster_boost(results, top_k=10)

        results.sort(key=lambda r: r.score, reverse=True)
        
        # v4.9.9 — Result content dedup
        seen_content = set()
        deduped = []
        for r in results:
            # Normalize: lowercase, strip, first 200 chars
            content_key = r.entry.content.lower().strip()[:200]
            if content_key not in seen_content:
                seen_content.add(content_key)
                deduped.append(r)
        results = deduped
        
        return results[:limit]
    
    def _score_entry(self, mem, query_tokens: List[str], query_lower: str,
                     capitalized_terms: Optional[set] = None,
                     query_categories: Optional[set] = None) -> Tuple[float, List[str]]:
        """Score a single memory against query tokens.

        Layer 4 additions:
        - Rarity boost: multiply each term's BM25 contribution by
          ``_rarity_boost(term)`` so that rare/specific terms carry more weight.
        - Proper-noun boost: if a term was written in Title-case in the
          original query (detected via *capitalized_terms*) it receives an
          additional 1.5× multiplier, rewarding matches on named entities.
        """
        if capitalized_terms is None:
            capitalized_terms = set()

        content_lower = mem.content.lower()

        # v5.0.1 — use cached tokenization from build_index() when available
        _cached = self._token_cache.get(mem.hash) if hasattr(self, '_token_cache') else None
        if _cached is not None:
            content_tokens, enriched_tokens, all_tokens, tf_counter, enriched_lower = _cached
        else:
            content_tokens = self._tokenize(mem.content)
            enriched_tokens = []
            enriched_lower = ""
            if getattr(mem, "enriched_summary", ""):
                enriched_tokens = self._tokenize(mem.enriched_summary)
                enriched_lower = mem.enriched_summary.lower()
            keyword_tokens = []
            if getattr(mem, "search_keywords", []):
                for kw in mem.search_keywords:
                    keyword_tokens.extend(self._tokenize(str(kw)))
            all_tokens = content_tokens + enriched_tokens + keyword_tokens
            tf_counter = Counter(all_tokens)

        doc_len = len(all_tokens)
        
        score = 0.0
        matched = []
        
        # BM25 scoring per query term
        for term in query_tokens:
            tf = tf_counter.get(term, 0)
            if tf == 0:
                continue

            matched.append(term)
            idf = self._idf_cache.get(term, 1.0)

            # N-gram IDF boost: bigrams get 1.5×, trigrams get 2.0×
            underscore_count = term.count('_')
            if underscore_count == 1:      # bigram
                idf *= 1.5
            elif underscore_count >= 2:    # trigram (or higher)
                idf *= 2.0

            # BM25 TF component with length normalization
            tf_norm = (tf * (self.k1 + 1)) / (
                tf + self.k1 * (1 - self.b + self.b * doc_len / max(self._avg_doc_len, 1))
            )

            # Layer 4 — rarity boost (amplifies rare/specific terms)
            rarity = self._rarity_boost(term)
            # Layer 4 — proper-noun boost (1.5× for mid-sentence capitalised terms)
            proper = 1.5 if self._is_proper_noun(term, capitalized_terms) else 1.0

            score += idf * tf_norm * rarity * proper
        
        # Exact phrase bonus (query tokens appear consecutively in content tokens)
        if len(query_tokens) > 1:
            content_token_str = " ".join(content_tokens)
            query_token_str = " ".join(query_tokens)
            if query_token_str in content_token_str:
                score *= 1.5
            elif enriched_tokens and query_token_str in " ".join(enriched_tokens):
                score *= 1.3  # Slightly lower boost for enriched phrase match
        
        # Field boosting: check tags (at most one 1.2x boost per entry)
        if hasattr(mem, 'tags') and mem.tags:
            tag_text = " ".join(mem.tags).lower()
            tag_hit = False
            for term in query_tokens:
                if term in tag_text:
                    if not tag_hit:
                        score *= 1.2
                        tag_hit = True
                    if term not in matched:
                        matched.append(f"tag:{term}")

        # v4.5.0: Category boost — 1.3x when query belongs to same semantic category
        # v4.9.6: query_categories pre-computed once per search, passed in (was 83% of latency)
        if score > 0 and query_categories and hasattr(mem, 'tags') and mem.tags:
            entry_categories = set(mem.tags) & set(_category_tagger.rules.keys())
            if query_categories & entry_categories:
                score *= 1.3
                matched.append("category_boost")

        # Field boosting: check source (at most one 1.1x boost per entry)
        if hasattr(mem, 'source') and mem.source:
            source_lower = mem.source.lower()
            for term in query_tokens:
                if term in source_lower:
                    score *= 1.1
                    break
        
        # v4.9.9 — Source-weighted scoring: structured memories rank higher
        _source = getattr(mem, 'source', '') or ''
        _mtype = getattr(mem, 'memory_type', 'episodic') or 'episodic'
        if _mtype in ('mistake', 'fact', 'procedure', 'preference'):
            score *= 1.15  # structured knowledge boost
        elif _source.startswith('pipeline:'):
            score *= 0.85  # raw conversation penalty
        
        # v4.9.9 — Enrichment quality boost
        if getattr(mem, 'enriched_summary', ''):
            score *= 1.10  # has LLM-generated summary
        if len(getattr(mem, 'search_keywords', []) or []) > 5:
            score *= 1.05  # rich keyword coverage
        
        return score, matched

    @staticmethod
    def _ngrams(tokens: List[str], n: int) -> List[str]:
        """Generate n-grams from a token list, joined by underscore."""
        if len(tokens) < n:
            return []
        return ["_".join(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]

    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text into lowercase terms, filtering stopwords.

        Returns unigrams + bigrams + trigrams.
        """
        raw = re.findall(r'\w{2,}', text.lower())
        unigrams = [
            t for t in raw
            if t not in self.STOPWORDS and not (t.isdigit() and len(t) < 3)
        ]

        bigrams = [
            bg for bg in self._ngrams(unigrams, 2)
            if not all(p in self.STOPWORDS for p in bg.split('_'))
        ]
        trigrams = [
            tg for tg in self._ngrams(unigrams, 3)
            if not all(p in self.STOPWORDS for p in tg.split('_'))
        ]

        return unigrams + bigrams + trigrams
    
    def _explain(self, matched: List[str], score: float, relevance: float) -> str:
        """Generate a human-readable explanation of the score."""
        parts = [f"matched: {', '.join(matched)}"]
        parts.append(f"raw={score:.3f}")
        parts.append(f"relevance={relevance:.2f}")
        return " | ".join(parts)
    
    # ── v4.6.0: Index Persistence (Incremental Index Loading) ───────────────

    def save_index(self, path: str) -> None:
        """Persist the BM25 index statistics to *path* as JSON.

        Serialises IDF cache, doc-frequency counts, corpus size, and average
        document length so that a subsequent ``load_index()`` can restore the
        search engine state without reprocessing all memories.

        Uses an atomic write (write-to-temp then rename) to prevent
        partial/corrupt index files on crash.

        Args:
            path: Destination file path (e.g. ``{workspace}/.antaris_index.json``).
        """
        import tempfile
        data = {
            "version": "4.6.0",
            "idf_cache": self._idf_cache,
            "avg_doc_len": self._avg_doc_len,
            "doc_count": self._doc_count,
            "doc_freqs": dict(self._doc_freqs),
            "corpus_version": self._corpus_version,
            "indexed_version": self._indexed_version,
            "content_fingerprint": self._content_fingerprint,
        }
        dir_name = os.path.dirname(os.path.abspath(path))
        os.makedirs(dir_name, exist_ok=True)
        try:
            with tempfile.NamedTemporaryFile(
                "w", dir=dir_name, delete=False, suffix=".tmp", encoding="utf-8"
            ) as tf:
                import json as _json
                _json.dump(data, tf, ensure_ascii=False)
                tmp_path = tf.name
            os.replace(tmp_path, path)
        except OSError:
            pass  # non-fatal: next startup will fall back to full build

    def load_index(self, path: str) -> bool:
        """Load a previously saved BM25 index from *path*.

        Restores IDF cache, doc-frequency counts, corpus size, and average
        document length.

        Args:
            path: Source file path (e.g. ``{workspace}/.antaris_index.json``).

        Returns:
            ``True`` if the index was loaded successfully, ``False`` otherwise
            (file not found, JSON error, schema mismatch, etc.).
        """
        import json as _json
        if not os.path.exists(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = _json.load(fh)
            # Validate schema presence
            for required in ("idf_cache", "avg_doc_len", "doc_count", "doc_freqs"):
                if required not in data:
                    return False
            self._idf_cache = data["idf_cache"]
            self._avg_doc_len = float(data["avg_doc_len"])
            self._doc_count = int(data["doc_count"])
            self._doc_freqs = Counter(data["doc_freqs"])
            self._corpus_version = int(data.get("corpus_version", 0))
            self._indexed_version = int(data.get("indexed_version", 0))
            self._content_fingerprint = int(data.get("content_fingerprint", 0))
            return True
        except Exception:
            return False

    def apply_wal_entries(self, entries: list) -> None:
        """Incrementally update the BM25 index with *entries*.

        Called on startup to fold WAL entries (ingested since the last index
        save) into the in-memory index without rebuilding from scratch.

        The update is an approximation: IDF values are recomputed after all
        new documents are processed so the result is numerically identical to
        calling ``build_index()`` on the full corpus.

        Args:
            entries: List of :class:`~antaris_memory.entry.MemoryEntry` objects
                     to incorporate.  Entries already reflected in the saved
                     index should **not** be included.
        """
        if not entries:
            return

        # Add each new document's term contributions
        for entry in entries:
            tokens = self._tokenize(entry.content)
            self._doc_count += 1
            # Running average of document length
            self._avg_doc_len = (
                (self._avg_doc_len * (self._doc_count - 1) + len(tokens))
                / self._doc_count
            )
            for term in set(tokens):
                self._doc_freqs[term] = self._doc_freqs.get(term, 0) + 1

        # Recompute IDF for all terms (BM25 formula)
        for term, df in self._doc_freqs.items():
            self._idf_cache[term] = math.log(
                (self._doc_count - df + 0.5) / (df + 0.5) + 1.0
            )

        self._indexed_version = self._corpus_version

    def mark_dirty(self) -> None:
        """Mark the corpus as changed. Next search() will rebuild the index."""
        self._corpus_version += 1
    
    def reindex(self, memories: list) -> None:
        """Force a full index rebuild."""
        self._corpus_version += 1
        self.build_index(memories)
    
    def stats(self) -> Dict:
        """Return index statistics.

        v5.0: Includes cluster index stats.
        """
        base = {
            "doc_count": self._doc_count,
            "avg_doc_len": round(self._avg_doc_len, 1),
            "vocab_size": len(self._doc_freqs),
            "top_terms": self._doc_freqs.most_common(20),
        }
        base["clusters"] = self._cluster_index.stats()
        return base
