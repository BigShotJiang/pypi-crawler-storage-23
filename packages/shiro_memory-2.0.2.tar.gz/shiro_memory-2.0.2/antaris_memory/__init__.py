"""
Shiro Memory v2.0 — Enhanced persistent memory for OpenClaw agents.

v2.0 Features:
- 10-layer search engine (replaces v1.0 BM25)
- LLM enrichment with search keywords and summaries
- Enhanced entry fields: agent_id, content_hash, enriched_summary, search_keywords
- Pipeline bridge integration for seamless enrichment workflow
- Preserved all of Shiro's original namespace/session logic

Enhanced personal memory system with 10-layer search and LLM enrichment.

Usage:
    from antaris_memory import MemorySystem

    mem = MemorySystem("./workspace")
    mem.load()
    mem.ingest("Key decision made", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()
"""

__version__ = "2.0.2"

# Core
from antaris_memory.core_v4 import MemorySystemV4 as MemorySystem
from antaris_memory.entry import MemoryEntry
from antaris_memory.decay import DecayEngine
from antaris_memory.sentiment import SentimentTagger
from antaris_memory.temporal import TemporalEngine
from antaris_memory.confidence import ConfidenceEngine
from antaris_memory.compression import CompressionEngine
from antaris_memory.forgetting import ForgettingEngine
from antaris_memory.consolidation import ConsolidationEngine
from antaris_memory.gating import InputGate
from antaris_memory.synthesis import KnowledgeSynthesizer

# Multi-agent
from antaris_memory.shared import SharedMemoryPool, AgentPermission

# Storage
from antaris_memory.migration import MigrationManager, Migration
from antaris_memory.indexing import IndexManager, SearchIndex, TagIndex, DateIndex

# Concurrency
from antaris_memory.locking import FileLock, LockTimeout
from antaris_memory.versioning import VersionTracker, ConflictError

# Search
from antaris_memory.search import SearchEngine, SearchResult

# Context Packets (v1.1)
from antaris_memory.context_packet import ContextPacket, ContextPacketBuilder

# Recovery (v3.3.1)
from antaris_memory.recovery import RecoveryConfig, RecoveryManager

# Memory Types + Namespace Isolation (Sprint 2 + Sprint 8)
from antaris_memory.memory_types import MEMORY_TYPE_CONFIGS, get_type_config
from antaris_memory.namespace import NamespacedMemory, NamespaceManager

# Sprint 3 — Semantic utilities
from antaris_memory.utils import cosine_similarity

# v3.2 — Instrumentation
from antaris_memory.instrumentation import (
    SearchContext,
    extract_memory_references,
    anonymize_query,
    build_usage_signal,
)

# Backward compatibility - import legacy core if needed
try:
    from antaris_memory.core import MemorySystem as LegacyMemorySystem
except ImportError:
    LegacyMemorySystem = None

__all__ = [
    "MemorySystem",
    "MemoryEntry",

    # Core engines
    "DecayEngine",
    "SentimentTagger",
    "TemporalEngine",
    "ConfidenceEngine",
    "CompressionEngine",
    "ForgettingEngine",
    "ConsolidationEngine",
    "InputGate",
    "KnowledgeSynthesizer",

    # Multi-agent (v0.3)
    "SharedMemoryPool",
    "AgentPermission",

    # Production features (v0.4)
    "MigrationManager",
    "Migration",
    "IndexManager",
    "SearchIndex",
    "TagIndex",
    "DateIndex",

    # Concurrency (v0.5)
    "FileLock",
    "LockTimeout",
    "VersionTracker",
    "ConflictError",

    # Search (v1.0)
    "SearchEngine",
    "SearchResult",

    # Context Packets (v1.1)
    "ContextPacket",
    "ContextPacketBuilder",

    # Sprint 2 — Memory Types
    "MEMORY_TYPE_CONFIGS",
    "get_type_config",

    # Sprint 8 — Namespace Isolation
    "NamespacedMemory",
    "NamespaceManager",

    # Sprint 3 — Hybrid Semantic Search
    "cosine_similarity",

    # v3.2 — Instrumentation
    "SearchContext",
    "extract_memory_references",
    "anonymize_query",
    "build_usage_signal",
]
