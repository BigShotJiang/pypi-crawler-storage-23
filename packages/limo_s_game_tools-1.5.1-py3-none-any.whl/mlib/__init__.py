from .sfrac import frac
from .smath import *
from .srandom import SimpleRNG
from .scolor import *
from .sgeometry import *
from .ssaver import *
from .svector import *
from .spathfinder import *
from .solver import *
__all__ = [
    # 数学
    'pi', 'e', 'i', 'sqrt', 'root', 'cbrt', 'ln', 'log', 'log10', 'log2',
    'sin', 'cos', 'tan', 'cot', 'sec', 'csc',
    'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh',
    'floor', 'ceil', 'round', 'sign', 'fract', 'wrap', 'map',
    'mean', 'variance', 'mad', 'deg', 'rad',
    
    # 方程求解
    'solve_linear', 'solve_quadratic', 'solve_cubic',
    'solve_polynomial', 'roots', 'poly', 'NoSolutionError',
    
    # 分数
    'frac',
    
    # 向量/几何
    'vec2', 'vec3', 'Rect', 'Circle', 'Line2', 'AABB', 'Sphere',
    'rect', 'circle', 'line', 'aabb', 'sphere',
    'raycast_rect', 'reflect',
    
    # 颜色
    'rgb', 'rgba', 'hex_to_rgb', 'rgb_to_hex', 'lerp', 'blend',
    'rgb_to_hsv', 'hsv_to_rgb',
    "WHITE", "BLACK", "RED", "GREEN", "BLUE", "YELLOW", "PURPLE", "ORANGE", "CYAN", "GRAY", "BROWN", "PINK", "GOLD", "MAGENTA", "BACKGROUND", "LIGHT_BLUE",     "LIGHT_GRAY", "LIGHT_ORANGE", "LIGHT_GREEN", "LIGHT_BROWN", "LIGHT_PINK", "LIGHT_PURPLE", "LIGHT_CYAN", "LIGHT_YELLOW", "LIGHT_CORAL", "DARK_GREEN",     "DARK_BLUE", "DARK_RED", "DARK_GOLD", "DARK_PURPLE", "DARK_BROWN", "DARK_CYAN", "DARK_ORANGE", "DARK_GRAY", "DARK_PINK", "AQUA", "LAVENDER", "CORAL",     "TEAL", "INDIGO", "VIOLET", "MAROON", "OLIVE", "NAVY", "LIME", "FUCHSIA", "SILVER", "PRIMARY", "SECONDARY", "SUCCESS", "WARNING", "ERROR", "INFO",
    
    # 随机
    'SimpleRNG',
    
    # 寻路
    'bfs',
    
    # 存档
    'SGTsaver',
]