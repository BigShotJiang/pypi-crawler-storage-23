"""Yutori MCP Server - Web monitoring and browsing automation."""

from importlib.metadata import version

__version__ = version("yutori-mcp")
