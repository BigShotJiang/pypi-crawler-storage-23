"""AgentLookup tools for CrewAI."""

from __future__ import annotations

import json
from typing import Any, Optional, Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from .client import AgentLookupClient


_client = AgentLookupClient()


def _fmt(data: Any) -> str:
    return json.dumps(data, indent=2)


# ── Schemas ──────────────────────────────────────────────────────────────


class SearchAgentsInput(BaseModel):
    """Input for searching agents in the registry."""
    query: Optional[str] = Field(None, description="Freetext search against agent names, descriptions, and capabilities")
    capability: Optional[str] = Field(None, description="Exact capability match, e.g. 'code-review', 'translation'")
    protocol: Optional[str] = Field(None, description="Exact protocol match, e.g. 'mcp', 'rest', 'graphql'")


class DiscoverAgentsInput(BaseModel):
    """Input for discovering agents in the registry."""
    category: Optional[str] = Field(None, description="One of 'new', 'active', or 'popular'. Omit for a mix.")


class LookupAgentInput(BaseModel):
    """Input for looking up a specific agent."""
    agent_id: str = Field(..., description="The agent's ID, e.g. 'ag_acme-scheduler_x7k2m'")


class RegisterAgentInput(BaseModel):
    """Input for registering a new agent."""
    name: str = Field(..., description="Human-readable agent name, max 100 characters")
    endpoint: str = Field(..., description="The agent's URL where other agents can reach it")
    capabilities: Optional[list[str]] = Field(None, description="What the agent can do, e.g. ['scheduling', 'calendar-read']")
    protocols: Optional[list[str]] = Field(None, description="Communication protocols, e.g. ['mcp', 'rest']")
    description: Optional[str] = Field(None, description="One-line description of the agent")


class HeartbeatInput(BaseModel):
    """Input for sending a heartbeat."""
    heartbeat_token: str = Field(..., description="The agent's heartbeat token (hb_live_*)")


# ── Tools ────────────────────────────────────────────────────────────────


class SearchAgentsTool(BaseTool):
    name: str = "search_agents"
    description: str = (
        "Search the public AI agent registry at agentlookup.dev. "
        "Find agents by what they can do (capability), how they communicate (protocol), "
        "or by keyword. No API key required. At least one parameter must be provided."
    )
    args_schema: Type[BaseModel] = SearchAgentsInput

    def _run(self, query: str | None = None, capability: str | None = None, protocol: str | None = None) -> str:
        if not any([query, capability, protocol]):
            return "Error: provide at least one of query, capability, or protocol."
        try:
            return _fmt(_client.search(query=query, capability=capability, protocol=protocol))
        except Exception as e:
            return f"Error searching registry: {e}"


class DiscoverAgentsTool(BaseTool):
    name: str = "discover_agents"
    description: str = (
        "Browse the public AI agent registry at agentlookup.dev. "
        "Returns new, active, and popular agents. "
        "Optionally filter by category: 'new', 'active', or 'popular'. No API key required."
    )
    args_schema: Type[BaseModel] = DiscoverAgentsInput

    def _run(self, category: str | None = None) -> str:
        try:
            return _fmt(_client.discover(category=category))
        except Exception as e:
            return f"Error discovering agents: {e}"


class LookupAgentTool(BaseTool):
    name: str = "lookup_agent"
    description: str = (
        "Get full details for a specific agent in the public registry at agentlookup.dev. "
        "Returns name, endpoint, capabilities, protocols, status, and timestamps. "
        "Requires an agent_id. No API key required."
    )
    args_schema: Type[BaseModel] = LookupAgentInput

    def _run(self, agent_id: str) -> str:
        try:
            return _fmt(_client.lookup(agent_id))
        except Exception as e:
            return f"Error looking up agent: {e}"


class RegisterAgentTool(BaseTool):
    name: str = "register_agent"
    description: str = (
        "Register a new agent in the public registry at agentlookup.dev. "
        "Returns an agent_id, secret, and heartbeat_token. "
        "IMPORTANT: The secret is returned once and never again. Store it securely. "
        "No API key required. Registration is free."
    )
    args_schema: Type[BaseModel] = RegisterAgentInput

    def _run(
        self,
        name: str,
        endpoint: str,
        capabilities: list[str] | None = None,
        protocols: list[str] | None = None,
        description: str | None = None,
    ) -> str:
        try:
            return _fmt(_client.register(
                name=name, endpoint=endpoint,
                capabilities=capabilities, protocols=protocols,
                description=description,
            ))
        except Exception as e:
            return f"Error registering agent: {e}"


class RegistryStatusTool(BaseTool):
    name: str = "registry_status"
    description: str = (
        "Check the health and statistics of the public AI agent registry at agentlookup.dev. "
        "Returns agents registered, agents active, uptime, and response time. No API key required."
    )

    def _run(self) -> str:
        try:
            return _fmt(_client.status())
        except Exception as e:
            return f"Error checking registry status: {e}"


class HeartbeatTool(BaseTool):
    name: str = "heartbeat"
    description: str = (
        "Send a heartbeat to keep a registered agent active in the registry. "
        "Agents become inactive after 7 days without a heartbeat. "
        "Requires the agent's heartbeat_token (hb_live_*)."
    )
    args_schema: Type[BaseModel] = HeartbeatInput

    def _run(self, heartbeat_token: str) -> str:
        try:
            return _fmt(_client.heartbeat(heartbeat_token))
        except Exception as e:
            return f"Error sending heartbeat: {e}"
