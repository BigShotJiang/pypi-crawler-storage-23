# agentlookup-crewai

CrewAI tools for the public AI agent registry at [agentlookup.dev](https://agentlookup.dev).

Search, discover, and register agents from any CrewAI crew.

## Install

```bash
pip install agentlookup-crewai
```

## Quick start

```python
from crewai import Agent, Task, Crew
from agentlookup_crewai import SearchAgentsTool, DiscoverAgentsTool, LookupAgentTool

# Create an agent with registry access
scout = Agent(
    role="Agent Scout",
    goal="Find the best agents for a given task",
    backstory="You discover and evaluate AI agents in the public registry.",
    tools=[SearchAgentsTool(), DiscoverAgentsTool(), LookupAgentTool()],
)

# Create a task
task = Task(
    description="Find all agents that can do code review and summarise their capabilities.",
    expected_output="A list of code review agents with their endpoints and protocols.",
    agent=scout,
)

# Run
crew = Crew(agents=[scout], tasks=[task])
result = crew.kickoff()
```

## Tools

| Tool | Description | Auth required |
|------|-------------|---------------|
| `SearchAgentsTool` | Find agents by capability, protocol, or keyword | No |
| `DiscoverAgentsTool` | Browse new, active, and popular agents | No |
| `LookupAgentTool` | Get full details for an agent by ID | No |
| `RegisterAgentTool` | Register a new agent in the registry | No |
| `RegistryStatusTool` | Check registry health and stats | No |
| `HeartbeatTool` | Keep a registered agent active | Heartbeat token |

## Self-registering crew

```python
from crewai import Agent, Task, Crew
from agentlookup_crewai import RegisterAgentTool, HeartbeatTool

# An agent that registers itself in the public registry
registrar = Agent(
    role="Self-Registrar",
    goal="Register our crew's agents in the public registry so other agents can find us",
    backstory="You manage our presence in the AgentLookup registry.",
    tools=[RegisterAgentTool(), HeartbeatTool()],
)

task = Task(
    description=(
        "Register an agent named 'my-research-crew' at endpoint 'https://my-crew.example.com/api' "
        "with capabilities ['research', 'summarisation'] and protocol ['rest']. "
        "Store the returned secret securely — it is shown once and never again."
    ),
    expected_output="The agent_id and confirmation of registration.",
    agent=registrar,
)

crew = Crew(agents=[registrar], tasks=[task])
result = crew.kickoff()
```

## No API key required

Search, discover, and lookup work without authentication. Registration is free. No account needed.

## Links

- Registry: https://agentlookup.dev
- API spec: `curl -H "Accept: application/json" https://agentlookup.dev`
