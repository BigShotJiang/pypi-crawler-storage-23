r'''
# cdk-diff-pr-github-action

A [Projen](https://projen.io/) construct library that surfaces **CloudFormation change set diffs and drift status directly on your pull requests** so reviewers can see exactly what will change before merging.

## Why this exists

`cdk diff` output disappears into CI logs that nobody reads. Meanwhile, a single property change on an RDS instance or EC2 "pet" server can trigger a **resource replacement** — destroying the database or instance and recreating it from scratch. If that replacement slips through code review unnoticed, the result is data loss and downtime.

This construct was built to make those dangerous changes impossible to miss:

* **Replacement column front and center** — Every change set row shows whether CloudFormation will modify the resource in place or **replace** it, with before/after property values so reviewers can understand *why*.
* **Comment appears on the PR itself** — No digging through workflow logs. The diff table is posted (and updated in place) as a PR comment and in the GitHub Step Summary.
* **Drift banner** — If the stack has drifted from its template, a warning banner is prepended to the comment so reviewers know the baseline is already out of sync.

If you have ever lost an EC2 instance, an RDS database, or an ElastiCache cluster to an unexpected CloudFormation replacement, this tool is for you.

---


A library that provides GitHub workflows and IAM templates for:

* Creating CloudFormation Change Sets for your CDK stacks on pull requests and commenting a formatted diff back on the PR.
* Detecting CloudFormation drift on a schedule or manual trigger and producing a consolidated summary (optionally creating an issue).
* Deploying IAM roles across AWS Organizations using StackSets.

It also provides ready-to-deploy IAM templates with the minimal permissions required for each workflow.

**Works with or without Projen** -- The StackSet generator can be used standalone in any Node.js project.

This package exposes five constructs:

* `CdkDiffStackWorkflow` — Generates one GitHub Actions workflow per stack to create a change set and render the diff back to the PR and Step Summary.
* `CdkDiffIamTemplate` — Emits a CloudFormation template file with minimal permissions for the Change Set workflow.
* `CdkDriftDetectionWorkflow` — Generates a GitHub Actions workflow to detect CloudFormation drift per stack, upload machine‑readable results, and aggregate a summary.
* `CdkDriftIamTemplate` — Emits a CloudFormation template file with minimal permissions for the Drift Detection workflow.
* `CdkDiffIamTemplateStackSet` — Creates a CloudFormation StackSet template for org-wide deployment of GitHub OIDC and IAM roles (Projen integration).
* `CdkDiffIamTemplateStackSetGenerator` — Pure generator class for StackSet templates (no Projen dependency).

## Quick start

1) Add the constructs to your Projen project (in `.projenrc.ts`).
2) Synthesize with `npx projen`.
3) Commit the generated files.
4) Open a pull request or run the drift detection workflow.

## End-to-end example

A realistic setup for a CDK Pipelines project with multiple stages and accounts. This generates one diff workflow per stack, a shared IAM template, and a scheduled drift detection workflow.

```python
// .projenrc.ts
import { awscdk } from 'projen';
import {
  CdkDiffStackWorkflow,
  CdkDiffIamTemplate,
  CdkDriftDetectionWorkflow,
} from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkTypeScriptApp({
  name: 'my-data-platform',
  defaultReleaseBranch: 'main',
  cdkVersion: '2.170.0',
  github: true,
});

// --- Change Set Diff Workflows (one per stack) ---
// stackName is the CDK construct path used with `cdk deploy <target>`.
// For CDK Pipelines, this is typically: pipeline/Stage/Stack
// The construct automatically resolves the real CloudFormation stack name
// from cdk.out at runtime (e.g., "my-stage-dev-my-stack").

new CdkDiffStackWorkflow({
  project,
  oidcRoleArn: 'arn:aws:iam::111111111111:role/GitHubOIDCRole',
  oidcRegion: 'us-east-1',
  stacks: [
    {
      stackName: 'my-pipeline/dev/DatabaseStack',
      changesetRoleToAssumeArn: 'arn:aws:iam::111111111111:role/CdkChangesetRole',
      changesetRoleToAssumeRegion: 'us-east-1',
    },
    {
      stackName: 'my-pipeline/dev/ComputeStack',
      changesetRoleToAssumeArn: 'arn:aws:iam::111111111111:role/CdkChangesetRole',
      changesetRoleToAssumeRegion: 'us-east-1',
    },
    {
      // Cross-account: prod stacks can use a different OIDC role and region
      stackName: 'my-pipeline/prod/DatabaseStack',
      changesetRoleToAssumeArn: 'arn:aws:iam::222222222222:role/CdkChangesetRole',
      changesetRoleToAssumeRegion: 'us-east-1',
      oidcRoleArn: 'arn:aws:iam::222222222222:role/GitHubOIDCRole',
      oidcRegion: 'us-east-1',
    },
  ],
});

// --- IAM Template (deploy once per account) ---
new CdkDiffIamTemplate({
  project,
  roleName: 'CdkChangesetRole',
  createOidcRole: true,
  githubOidc: {
    owner: 'my-org',
    repositories: ['my-data-platform'],
    branches: ['main'],
  },
});

// --- Drift Detection (scheduled + manual) ---
new CdkDriftDetectionWorkflow({
  project,
  schedule: '0 6 * * 1', // Every Monday at 6 AM UTC
  oidcRoleArn: 'arn:aws:iam::111111111111:role/GitHubOIDCRole',
  oidcRegion: 'us-east-1',
  stacks: [
    {
      stackName: 'dev-DatabaseStack',
      driftDetectionRoleToAssumeArn: 'arn:aws:iam::111111111111:role/CdkDriftRole',
      driftDetectionRoleToAssumeRegion: 'us-east-1',
    },
  ],
});

project.synth();
```

After `npx projen`, this generates:

* `.github/workflows/diff-my-pipeline-dev-databasestack.yml`
* `.github/workflows/diff-my-pipeline-dev-computestack.yml`
* `.github/workflows/diff-my-pipeline-prod-databasestack.yml`
* `.github/workflows/scripts/describe-cfn-changeset.ts`
* `.github/workflows/drift-detection.yml`
* `.github/workflows/scripts/detect-drift.ts`
* `cdk-diff-workflow-iam-template.yaml`

When a pull request is opened, each diff workflow runs automatically and posts a comment like this:

| Action | ID | Type | Replacement | Details |
|--------|-----|------|-------------|---------|
| 🔵 Modify | MyDatabase | AWS::RDS::DBInstance | **True** | 🔵 **DBInstanceClass**: `db.t3.medium` -> `db.t3.large` |
| 🔵 Modify | MyFunction | AWS::Lambda::Function | False | 🔵 **Runtime**: `nodejs18.x` -> `nodejs20.x` |

The **Replacement: True** on the RDS instance is exactly the kind of change this tool is designed to catch before it reaches production.

## Usage: CdkDiffStackWorkflow

`CdkDiffStackWorkflow` renders a workflow per stack named `diff-<StackName>.yml` under `.github/workflows/`. It also generates a helper script at `.github/workflows/scripts/describe-cfn-changeset.ts` that formats the change set output and takes care of posting the PR comment and Step Summary.

Example `.projenrc.ts`:

```python
import { awscdk } from 'projen';
import { CdkDiffStackWorkflow } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({
  // ... your usual settings ...
  workflowName: 'my-lib',
  defaultReleaseBranch: 'main',
  cdkVersion: '2.85.0',
  github: true,
});

new CdkDiffStackWorkflow({
  project,
  stacks: [
    {
      stackName: 'MyAppStack',
      changesetRoleToAssumeArn: 'arn:aws:iam::123456789012:role/cdk-diff-role',
      changesetRoleToAssumeRegion: 'us-east-1',
      // Optional per‑stack OIDC override (if not using the defaults below)
      // oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
      // oidcRegion: 'us-east-1',
    },
  ],
  // Default OIDC role/region used by all stacks unless overridden per‑stack
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
  // Optional: Node version used in the workflow (default: '24.x')
  // nodeVersion: '24.x',
  // Optional: Yarn command to run CDK (default: 'cdk')
  // cdkYarnCommand: 'cdk',
  // Optional: Where to place the helper script (default: '.github/workflows/scripts/describe-cfn-changeset.ts')
  // scriptOutputPath: '.github/workflows/scripts/describe-cfn-changeset.ts',
});

project.synth();
```

### CdkDiffStackWorkflow props

* `project` (required) — Your Projen project instance.
* `stacks` (required) — Array of stack entries.
* `oidcRoleArn` (required unless provided per‑stack) — Default OIDC role ARN.
* `oidcRegion` (required unless provided per‑stack) — Default OIDC region.
* `nodeVersion` (optional, default `'24.x'`) — Node.js version for the workflow runner.
* `cdkYarnCommand` (optional, default `'cdk'`) — Yarn script/command to invoke CDK.
* `scriptOutputPath` (optional, default `'.github/workflows/scripts/describe-cfn-changeset.ts'`) — Where to write the helper script.

If neither top‑level OIDC defaults nor all per‑stack values are supplied, the construct throws a helpful error.

### Stack item fields

* `stackName` (required) — The CDK stack name to create the change set for.
* `changesetRoleToAssumeArn` (required) — The ARN of the role used to create the change set (role chaining after OIDC).
* `changesetRoleToAssumeRegion` (required) — The region for that role.
* `oidcRoleArn` (optional) — Per‑stack override for the OIDC role.
* `oidcRegion` (optional) — Per‑stack override for the OIDC region.

### What gets generated

* `.github/workflows/diff-<StackName>.yml` — One workflow per stack, triggered on PR open/sync/reopen.
* `.github/workflows/scripts/describe-cfn-changeset.ts` — A helper script that:

  * Polls `DescribeChangeSet` until terminal
  * Filters out ignorable logical IDs or resource types using environment variables `IGNORE_LOGICAL_IDS` and `IGNORE_RESOURCE_TYPES`
  * Renders an HTML table with actions, logical IDs, types, replacements, and changed properties
  * **Checks cached drift status** via `DescribeStacks` — if the stack has drifted, a warning banner with drifted resource details is prepended to the output (non-fatal; degrades gracefully if IAM permissions are missing)
  * Prints the HTML and appends to the GitHub Step Summary
  * **Upserts the PR comment** — uses an HTML marker (`<!-- cdk-diff:stack:STACK_NAME -->`) to find and update an existing comment instead of creating duplicates on every push

### Change Set Output Format

The change set script uses the CloudFormation `IncludePropertyValues` API feature to show **actual before/after values** for changed properties, not just property names.

**Example PR comment:**

> **Warning: Stack has drifted (2 resources out of sync)**
>
> Last drift check: 2025-01-15T10:30:00.000Z
>
> <details><summary>View drifted resources</summary>
>
> | Resource | Type | Drift Status |
> |----------|------|-------------|
> | MySecurityGroup | AWS::EC2::SecurityGroup | MODIFIED |
> | OldBucket | AWS::S3::Bucket | DELETED |
>
> </details>

| Action | ID | Type | Replacement | Details |
|--------|-----|------|-------------|---------|
| 🔵 Modify | MyDatabase | AWS::RDS::DBInstance | **True** | 🔵 **DBInstanceClass**: `db.t3.medium` -> `db.t3.large` |
| 🔵 Modify | MyLambdaFunction | AWS::Lambda::Function | False | 🔵 **Runtime**: `nodejs18.x` -> `nodejs20.x` |
| 🟢 Add | NewSecurityGroup | AWS::EC2::SecurityGroup | - | |
| 🔴 Remove | OldRole | AWS::IAM::Role | - | |

**Features:**

* **Replacement column** highlights when CloudFormation will **destroy and recreate** a resource — critical for stateful resources like databases, EC2 instances, and file systems
* **Drift banner** — if the stack has drifted, a warning with drifted resource details appears above the change set table so reviewers know the baseline state
* **Comment upsert** — each stack's comment is updated in place on subsequent pushes instead of creating duplicates; uses an HTML marker for reliable find-and-replace
* **Color-coded indicators**: 🟢 Added, 🔵 Modified, 🔴 Removed
* **Inline values for small changes**: Shows `before -> after` directly in the table
* **Collapsible details for large values**: IAM policies, tags, and other large JSON values are wrapped in expandable `<details>` elements to keep the table readable
* **All attribute types supported**: Properties, Tags, Metadata, etc.
* **HTML-escaped values**: Prevents XSS from property values

### Environment variables used by the change set script

* `STACK_NAME` (required) — Stack name to describe.
* `CHANGE_SET_NAME` (default: same as `STACK_NAME`).
* `AWS_REGION` — Region for CloudFormation API calls. The workflow sets this via the credentials action(s).
* `GITHUB_TOKEN` (optional) — If set with `GITHUB_COMMENT_URL`, posts a PR comment.
* `GITHUB_COMMENT_URL` (optional) — PR comments URL.
* `GITHUB_STEP_SUMMARY` (optional) — When present, appends the HTML to the step summary file.
* `IGNORE_LOGICAL_IDS` (optional) — Comma‑separated logical IDs to ignore (default includes `CDKMetadata`).
* `IGNORE_RESOURCE_TYPES` (optional) — Comma‑separated resource types to ignore (e.g., `AWS::CDK::Metadata`).

## Usage: CdkDiffIamTemplate

Emit an IAM template you can deploy in your account for the Change Set workflow. Supports two modes:

1. **External OIDC Role** — Reference an existing GitHub OIDC role (original behavior)
2. **Self-Contained** — Create the GitHub OIDC provider and role within the same template (new)

### Option 1: Using an Existing OIDC Role (External)

Use this when you already have a GitHub OIDC provider and role set up in your account.

#### With Projen

```python
import { awscdk } from 'projen';
import { CdkDiffIamTemplate } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({
  // ...
});

new CdkDiffIamTemplate({
  project,
  roleName: 'cdk-diff-role',
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
  // Optional: custom output path (default: 'cdk-diff-workflow-iam-template.yaml')
  // outputPath: 'infra/cdk-diff-iam.yaml',
});

project.synth();
```

#### Without Projen (Standalone Generator)

```python
import { CdkDiffIamTemplateGenerator } from '@jjrawlins/cdk-diff-pr-github-action';
import * as fs from 'fs';

const template = CdkDiffIamTemplateGenerator.generateTemplate({
  roleName: 'cdk-diff-role',
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
});

fs.writeFileSync('cdk-diff-iam-template.yaml', template);
```

### Option 2: Self-Contained Template (Create OIDC Role)

Use this when you want a single template that creates everything needed — the GitHub OIDC provider, OIDC role, and changeset role. This simplifies deployment and pairs well with the `CdkDiffStackWorkflow`.

#### With Projen

```python
import { awscdk } from 'projen';
import { CdkDiffIamTemplate } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({
  // ...
});

new CdkDiffIamTemplate({
  project,
  roleName: 'CdkChangesetRole',
  createOidcRole: true,
  oidcRoleName: 'GitHubOIDCRole',  // Optional, default: 'GitHubOIDCRole'
  githubOidc: {
    owner: 'my-org',                          // GitHub org or username
    repositories: ['infra-repo', 'app-repo'], // Repos allowed to assume roles
    branches: ['main', 'release/*'],          // Branch patterns (default: ['*'])
  },
  // Optional: Skip OIDC provider creation if it already exists
  // skipOidcProviderCreation: true,
});

project.synth();
```

#### Without Projen (Standalone Generator)

```python
import { CdkDiffIamTemplateGenerator } from '@jjrawlins/cdk-diff-pr-github-action';
import * as fs from 'fs';

const template = CdkDiffIamTemplateGenerator.generateTemplate({
  roleName: 'CdkChangesetRole',
  createOidcRole: true,
  oidcRoleName: 'GitHubOIDCRole',
  githubOidc: {
    owner: 'my-org',
    repositories: ['infra-repo'],
    branches: ['main'],
  },
});

fs.writeFileSync('cdk-diff-iam-template.yaml', template);
```

#### With Existing OIDC Provider (Skip Creation)

If your account already has a GitHub OIDC provider but you want the template to create the roles:

```python
new CdkDiffIamTemplate({
  project,
  roleName: 'CdkChangesetRole',
  createOidcRole: true,
  skipOidcProviderCreation: true,  // Account already has OIDC provider
  githubOidc: {
    owner: 'my-org',
    repositories: ['*'],  // All repos in org
  },
});
```

### Deploy Task

A Projen task is added for easy deployment:

```bash
npx projen deploy-cdkdiff-iam-template -- --parameter-overrides GitHubOIDCRoleArn=... # plus any extra AWS CLI args
```

### CdkDiffIamTemplate Props

| Property | Type | Description |
|----------|------|-------------|
| `roleName` | `string` | Name for the changeset IAM role (required) |
| `oidcRoleArn` | `string?` | ARN of existing GitHub OIDC role. Required when `createOidcRole` is false. |
| `oidcRegion` | `string?` | Region for OIDC trust condition. Required when `createOidcRole` is false. |
| `createOidcRole` | `boolean?` | Create OIDC role within template (default: false) |
| `oidcRoleName` | `string?` | Name of OIDC role to create (default: 'GitHubOIDCRole') |
| `githubOidc` | `GitHubOidcConfig?` | GitHub OIDC config. Required when `createOidcRole` is true. |
| `skipOidcProviderCreation` | `boolean?` | Skip OIDC provider if it exists (default: false) |
| `outputPath` | `string?` | Template output path (default: 'cdk-diff-workflow-iam-template.yaml') |

### What the Template Creates

**External OIDC Role mode:**

* Parameter `GitHubOIDCRoleArn` — ARN of your existing GitHub OIDC role
* IAM role `CdkChangesetRole` with minimal permissions for change set operations
* Outputs: `CdkChangesetRoleArn`, `CdkChangesetRoleName`

**Self-Contained mode (`createOidcRole: true`):**

* GitHub OIDC Provider (unless `skipOidcProviderCreation: true`)
* IAM role `GitHubOIDCRole` with trust policy for GitHub Actions
* IAM role `CdkChangesetRole` with minimal permissions (trusts the OIDC role)
* Outputs: `GitHubOIDCProviderArn`, `GitHubOIDCRoleArn`, `GitHubOIDCRoleName`, `CdkChangesetRoleArn`, `CdkChangesetRoleName`

**Changeset Role Permissions:**

* CloudFormation Change Set operations
* Access to CDK bootstrap S3 buckets and SSM parameters
* `iam:PassRole` to `cloudformation.amazonaws.com`

Use the created changeset role ARN as `changesetRoleToAssumeArn` in `CdkDiffStackWorkflow`.

---


## Usage: CdkDriftDetectionWorkflow

`CdkDriftDetectionWorkflow` creates a single workflow file (default `drift-detection.yml`) that can run on a schedule and via manual dispatch. It generates a helper script at `.github/workflows/scripts/detect-drift.ts` (by default) that uses AWS SDK v3 to run drift detection, write optional machine‑readable JSON, and print an HTML report for the Step Summary.

Example `.projenrc.ts`:

```python
import { awscdk } from 'projen';
import { CdkDriftDetectionWorkflow } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({ github: true, /* ... */ });

new CdkDriftDetectionWorkflow({
  project,
  workflowName: 'Drift Detection',            // optional; file name derived as 'drift-detection.yml'
  schedule: '0 1 * * *',                      // optional cron
  createIssues: true,                         // default true; create/update issue when drift detected on schedule
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
  // Optional: Node version (default '24.x')
  // nodeVersion: '24.x',
  // Optional: Where to place the helper script (default '.github/workflows/scripts/detect-drift.ts')
  // scriptOutputPath: '.github/workflows/scripts/detect-drift.ts',
  stacks: [
    {
      stackName: 'MyAppStack-Prod',
      driftDetectionRoleToAssumeArn: 'arn:aws:iam::123456789012:role/cdk-drift-role',
      driftDetectionRoleToAssumeRegion: 'us-east-1',
      // failOnDrift: true, // optional (default true)
    },
  ],
});

project.synth();
```

### CdkDriftDetectionWorkflow props

* `project` (required) — Your Projen project instance.
* `stacks` (required) — Array of stacks to check.
* `oidcRoleArn` (required) — Default OIDC role ARN used before chaining into per‑stack drift roles.
* `oidcRegion` (required) — Default OIDC region.
* `workflowName` (optional, default `'drift-detection'`) — Human‑friendly workflow name; the file name is derived in kebab‑case.
* `schedule` (optional) — Cron expression for automatic runs.
* `createIssues` (optional, default `true`) — When true, scheduled runs will create/update a GitHub issue if drift is detected.
* `nodeVersion` (optional, default `'24.x'`) — Node.js version for the runner.
* `scriptOutputPath` (optional, default `'.github/workflows/scripts/detect-drift.ts'`) — Where to write the helper script.

### Per‑stack fields

* `stackName` (required) — The full CloudFormation stack name.
* `driftDetectionRoleToAssumeArn` (required) — Role to assume (after OIDC) for making drift API calls.
* `driftDetectionRoleToAssumeRegion` (required) — Region for that role and API calls.
* `failOnDrift` (optional, default `true`) — Intended to fail the detection step on drift. The provided script exits with non‑zero when drift is found; the job continues to allow artifact upload and issue creation.

### What gets generated

* `.github/workflows/<kebab(workflowName)>.yml` — A workflow with one job per stack plus a final summary job.
* `.github/workflows/scripts/detect-drift.ts` — Helper script that:

  * Starts drift detection and polls until completion
  * Lists non‑`IN_SYNC` resources and builds an HTML report
  * Writes optional JSON to `DRIFT_DETECTION_OUTPUT` when set
  * Prints to stdout and appends to the GitHub Step Summary when available

### Artifacts and summary

* Each stack job uploads `drift-results-<stack>.json` (if produced).
* A final `Drift Detection Summary` job downloads all artifacts and prints a consolidated summary.

### Manual dispatch

* The workflow exposes an input named `stack` with choices including each configured stack and an `all` option.
* Choose a specific stack to run drift detection for that stack only, or select `all` (or leave the input empty) to run all stacks.

Note: The default workflow does not post PR comments for drift. It can create/update an Issue on scheduled runs when `createIssues` is `true`.

### Post-notification steps (e.g., Slack)

You can add your own GitHub Action steps to run after the drift detection step for each stack using `postGitHubSteps`.
Provide your own Slack payload/markdown (this library no longer generates a payload step for you).

Option A: slackapi/slack-github-action (Incoming Webhook, official syntax)

```python
new CdkDriftDetectionWorkflow({
  project,
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
  stacks: [/* ... */],
  postGitHubSteps: ({ stack }) => {
    // Build a descriptive name per stack
    const name = `Notify Slack (${stack} post-drift)`;
    const step = {
      name,
      uses: 'slackapi/slack-github-action@v2.1.1',
      // by default, post steps run only when drift is detected; you can override `if`
      if: "always() && steps.drift.outcome == 'failure'",
      // Use official inputs: webhook + webhook-type, and a YAML payload with blocks
      with: {
        webhook: '${{ secrets.CDK_NOTIFICATIONS_SLACK_WEBHOOK }}',
        'webhook-type': 'incoming-webhook',
        payload: [
          'text: "** ${{ env.STACK_NAME }} ** has drifted!"',
          'blocks:',
          '  - type: "section"',
          '    text:',
          '      type: "mrkdwn"',
          '      text: "*Stack:* ${{ env.STACK_NAME }} (region ${{ env.AWS_REGION }}) has drifted:exclamation:"',
          '  - type: "section"',
          '    fields:',
          '      - type: "mrkdwn"',
          '        text: "*Stack ARN*\\n${{ steps.drift.outputs.stack-arn }}"',
          '      - type: "mrkdwn"',
          '        text: "*Issue*\\n<${{ github.server_url }}/${{ github.repository }}/issues/${{ steps.issue.outputs.result }}|#${{ steps.issue.outputs.result }}>"',
        ].join('\n'),
      },
    };
    return [step];
  },
});
```

Note: The Issue link requires `createIssues: true` (default) so that the `Create Issue on Drift` step runs before this Slack step and exposes `steps.issue.outputs.result`. This library orders the steps accordingly.

Details:

* `postGitHubSteps` can be:

  * an array of step objects, or
  * a factory function `({ stack }) => step | step[]`.
* Each step you provide is inserted after the results are uploaded.
* Default condition: if you do not set `if` on your step, it will default to `always() && steps.drift.outcome == 'failure'`.
* Available context/env you can use:

  * `${{ env.STACK_NAME }}`, `${{ env.DRIFT_DETECTION_OUTPUT }}`
  * `${{ steps.drift.outcome }}` — success/failure of the detect step
  * `${{ steps.drift.outputs.stack-arn }}` — Stack ARN resolved at runtime
  * `${{ steps.issue.outputs.result }}` — Issue number if the workflow created/found one (empty when not applicable)

```

## Usage: CdkDriftIamTemplate

Emit an example IAM template you can deploy in your account for the Drift Detection workflow.

### With Projen

```ts
import { awscdk } from 'projen';
import { CdkDriftIamTemplate } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({
  // ...
});

new CdkDriftIamTemplate({
  project,
  roleName: 'cdk-drift-role',
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
  // Optional: custom output path (default: 'cdk-drift-workflow-iam-template.yaml')
  // outputPath: 'infra/cdk-drift-iam.yaml',
});

project.synth();
```

A Projen task is also added:

```bash
npx projen deploy-cdkdrift-iam-template -- --parameter-overrides GitHubOIDCRoleArn=... # plus any extra AWS CLI args
```

### Without Projen (Standalone Generator)

```python
import { CdkDriftIamTemplateGenerator } from '@jjrawlins/cdk-diff-pr-github-action';
import * as fs from 'fs';

const template = CdkDriftIamTemplateGenerator.generateTemplate({
  roleName: 'cdk-drift-role',
  oidcRoleArn: 'arn:aws:iam::123456789012:role/github-oidc-role',
  oidcRegion: 'us-east-1',
});

fs.writeFileSync('cdk-drift-iam-template.yaml', template);

// Get the deploy command
const deployCmd = CdkDriftIamTemplateGenerator.generateDeployCommand('cdk-drift-iam-template.yaml');
console.log('Deploy with:', deployCmd);
```

### What the template defines

* Parameter `GitHubOIDCRoleArn` with a default from `oidcRoleArn` — the ARN of your existing GitHub OIDC role allowed to assume this drift role.
* IAM role `CdkDriftRole` with minimal permissions for CloudFormation drift detection operations.
* Outputs exporting the role name and ARN.

---


## Usage: CdkDiffIamTemplateStackSet (Org-Wide Deployment)

`CdkDiffIamTemplateStackSet` creates a CloudFormation StackSet template for deploying GitHub OIDC provider, OIDC role, and CDK diff/drift IAM roles across an entire AWS Organization. This is the recommended approach for organizations that want to enable CDK diff/drift workflows across multiple accounts.

### Architecture

Each account in your organization gets:

* **GitHub OIDC Provider** — Authenticates GitHub Actions workflows
* **GitHubOIDCRole** — Trusts the OIDC provider with repo/branch restrictions
* **CdkChangesetRole** — For PR change set previews (trusts GitHubOIDCRole)
* **CdkDriftRole** — For drift detection (trusts GitHubOIDCRole)

This is a self-contained deployment with **no role chaining required**.

### With Projen

```python
import { awscdk } from 'projen';
import { CdkDiffIamTemplateStackSet } from '@jjrawlins/cdk-diff-pr-github-action';

const project = new awscdk.AwsCdkConstructLibrary({ /* ... */ });

new CdkDiffIamTemplateStackSet({
  project,
  githubOidc: {
    owner: 'my-org',                          // GitHub org or username
    repositories: ['infra-repo', 'app-repo'], // Repos allowed to assume roles
    branches: ['main', 'release/*'],          // Branch patterns (default: ['*'])
  },
  targetOrganizationalUnitIds: ['ou-xxxx-xxxxxxxx'], // Target OUs
  regions: ['us-east-1', 'eu-west-1'],               // Target regions
  // Optional settings:
  // oidcRoleName: 'GitHubOIDCRole',       // default
  // changesetRoleName: 'CdkChangesetRole', // default
  // driftRoleName: 'CdkDriftRole',         // default
  // roleSelection: StackSetRoleSelection.BOTH, // BOTH, CHANGESET_ONLY, or DRIFT_ONLY
  // delegatedAdmin: true,                  // Use --call-as DELEGATED_ADMIN (default: true)
});

project.synth();
```

This creates:

* `cdk-diff-workflow-stackset-template.yaml` — CloudFormation template
* Projen tasks for StackSet management

**Projen tasks:**

```bash
npx projen stackset-create          # Create the StackSet
npx projen stackset-update          # Update the StackSet template
npx projen stackset-deploy-instances # Deploy to target OUs/regions
npx projen stackset-delete-instances # Remove stack instances
npx projen stackset-delete          # Delete the StackSet
npx projen stackset-describe        # Show StackSet status
npx projen stackset-list-instances  # List all instances
```

### Without Projen (Standalone Generator)

For non-Projen projects, use `CdkDiffIamTemplateStackSetGenerator` directly:

```python
import {
  CdkDiffIamTemplateStackSetGenerator
} from '@jjrawlins/cdk-diff-pr-github-action';
import * as fs from 'fs';

// Generate the CloudFormation template
const template = CdkDiffIamTemplateStackSetGenerator.generateTemplate({
  githubOidc: {
    owner: 'my-org',
    repositories: ['infra-repo'],
    branches: ['main'],
  },
});

// Write to file
fs.writeFileSync('stackset-template.yaml', template);

// Get AWS CLI commands for StackSet operations
const commands = CdkDiffIamTemplateStackSetGenerator.generateCommands({
  stackSetName: 'cdk-diff-workflow-iam-stackset',
  templatePath: 'stackset-template.yaml',
  targetOrganizationalUnitIds: ['ou-xxxx-xxxxxxxx'],
  regions: ['us-east-1'],
});

console.log('Create StackSet:', commands['stackset-create']);
console.log('Deploy instances:', commands['stackset-deploy-instances']);
```

### GitHub Actions Workflow (Simplified)

With per-account OIDC, your workflow is simplified — no role chaining needed:

```yaml
jobs:
  diff:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: actions/checkout@v4

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::${{ env.ACCOUNT_ID }}:role/GitHubOIDCRole
          aws-region: us-east-1

      - name: Assume Changeset Role
        run: |
          CREDS=$(aws sts assume-role \
            --role-arn arn:aws:iam::${{ env.ACCOUNT_ID }}:role/CdkChangesetRole \
            --role-session-name changeset-session)
          # Export credentials...
```

### GitHubOidcConfig options

| Property | Description |
|----------|-------------|
| `owner` | GitHub organization or username (required) |
| `repositories` | Array of repo names, or `['*']` for all repos (required) |
| `branches` | Array of branch patterns (default: `['*']`) |
| `additionalClaims` | Extra OIDC claims like `['pull_request', 'environment:production']` |

---


## Testing

This repository includes Jest tests that snapshot the synthesized outputs from Projen and assert that:

* Diff workflows are created per stack and contain all expected steps.
* Drift detection workflow produces one job per stack and a summary job.
* Only one helper script file is generated per workflow type.
* Per‑stack OIDC overrides (where supported) are respected.
* Helpful validation errors are thrown for missing OIDC settings.
* The IAM template files contain the expected resources and outputs.

Run tests with:

```bash
yarn test
```

## Notes

* This package assumes your repository is configured with GitHub Actions and that you have a GitHub OIDC role configured in AWS.
* The generated scripts use the AWS SDK v3 for CloudFormation and, where applicable, the GitHub REST API.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *


class CdkDiffIamTemplate(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplate",
):
    '''(experimental) Projen construct that emits a CloudFormation template with minimal IAM permissions for the CDK Diff Stack Workflow.

    For non-Projen projects, use ``CdkDiffIamTemplateGenerator`` directly.

    :stability: experimental
    '''

    def __init__(
        self,
        *,
        project: typing.Any,
        output_path: typing.Optional[builtins.str] = None,
        role_name: builtins.str,
        create_oidc_role: typing.Optional[builtins.bool] = None,
        github_oidc: typing.Optional[typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''
        :param project: (experimental) Projen project instance.
        :param output_path: (experimental) Output path for the template file (default: 'cdk-diff-workflow-iam-template.yaml').
        :param role_name: (experimental) Name for the changeset IAM role.
        :param create_oidc_role: (experimental) Create a GitHub OIDC role within this template instead of using an existing one. When true, githubOidc configuration is required and oidcRoleArn is ignored. Default: false
        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions. Required when createOidcRole is true.
        :param oidc_region: (experimental) Region for the OIDC trust condition. Only used when oidcRoleArn is provided (external OIDC role).
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this changeset role. Required when createOidcRole is false or undefined.
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role to create. Only used when createOidcRole is true. Default: 'GitHubOIDCRole'
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if the account already has a GitHub OIDC provider. Only used when createOidcRole is true. Default: false

        :stability: experimental
        '''
        props = CdkDiffIamTemplateProps(
            project=project,
            output_path=output_path,
            role_name=role_name,
            create_oidc_role=create_oidc_role,
            github_oidc=github_oidc,
            oidc_region=oidc_region,
            oidc_role_arn=oidc_role_arn,
            oidc_role_name=oidc_role_name,
            skip_oidc_provider_creation=skip_oidc_provider_creation,
        )

        jsii.create(self.__class__, self, [props])


class CdkDiffIamTemplateGenerator(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateGenerator",
):
    '''(experimental) Pure generator class for CDK Diff IAM templates.

    No Projen dependency - can be used in any project.

    :stability: experimental
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="generateDeployCommand")
    @builtins.classmethod
    def generate_deploy_command(
        cls,
        template_path: typing.Optional[builtins.str] = None,
    ) -> builtins.str:
        '''(experimental) Generate the AWS CLI deploy command for the IAM template.

        :param template_path: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4940eb27556b68e5b3cc9fced9714c6cb9639c00a7faad56fe7933eb3a85acf7)
            check_type(argname="argument template_path", value=template_path, expected_type=type_hints["template_path"])
        return typing.cast(builtins.str, jsii.sinvoke(cls, "generateDeployCommand", [template_path]))

    @jsii.member(jsii_name="generateTemplate")
    @builtins.classmethod
    def generate_template(
        cls,
        *,
        role_name: builtins.str,
        create_oidc_role: typing.Optional[builtins.bool] = None,
        github_oidc: typing.Optional[typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> builtins.str:
        '''(experimental) Generate the CloudFormation IAM template as a YAML string.

        :param role_name: (experimental) Name for the changeset IAM role.
        :param create_oidc_role: (experimental) Create a GitHub OIDC role within this template instead of using an existing one. When true, githubOidc configuration is required and oidcRoleArn is ignored. Default: false
        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions. Required when createOidcRole is true.
        :param oidc_region: (experimental) Region for the OIDC trust condition. Only used when oidcRoleArn is provided (external OIDC role).
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this changeset role. Required when createOidcRole is false or undefined.
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role to create. Only used when createOidcRole is true. Default: 'GitHubOIDCRole'
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if the account already has a GitHub OIDC provider. Only used when createOidcRole is true. Default: false

        :stability: experimental
        '''
        props = CdkDiffIamTemplateGeneratorProps(
            role_name=role_name,
            create_oidc_role=create_oidc_role,
            github_oidc=github_oidc,
            oidc_region=oidc_region,
            oidc_role_arn=oidc_role_arn,
            oidc_role_name=oidc_role_name,
            skip_oidc_provider_creation=skip_oidc_provider_creation,
        )

        return typing.cast(builtins.str, jsii.sinvoke(cls, "generateTemplate", [props]))


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateGeneratorProps",
    jsii_struct_bases=[],
    name_mapping={
        "role_name": "roleName",
        "create_oidc_role": "createOidcRole",
        "github_oidc": "githubOidc",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "oidc_role_name": "oidcRoleName",
        "skip_oidc_provider_creation": "skipOidcProviderCreation",
    },
)
class CdkDiffIamTemplateGeneratorProps:
    def __init__(
        self,
        *,
        role_name: builtins.str,
        create_oidc_role: typing.Optional[builtins.bool] = None,
        github_oidc: typing.Optional[typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Props for generating CDK Diff IAM templates (no Projen dependency).

        :param role_name: (experimental) Name for the changeset IAM role.
        :param create_oidc_role: (experimental) Create a GitHub OIDC role within this template instead of using an existing one. When true, githubOidc configuration is required and oidcRoleArn is ignored. Default: false
        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions. Required when createOidcRole is true.
        :param oidc_region: (experimental) Region for the OIDC trust condition. Only used when oidcRoleArn is provided (external OIDC role).
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this changeset role. Required when createOidcRole is false or undefined.
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role to create. Only used when createOidcRole is true. Default: 'GitHubOIDCRole'
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if the account already has a GitHub OIDC provider. Only used when createOidcRole is true. Default: false

        :stability: experimental
        '''
        if isinstance(github_oidc, dict):
            github_oidc = GitHubOidcConfig(**github_oidc)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__422bd2274e2bd824a3fea09f4f628de6d8efb1b2aa190c8c255dcb8a1520c1f2)
            check_type(argname="argument role_name", value=role_name, expected_type=type_hints["role_name"])
            check_type(argname="argument create_oidc_role", value=create_oidc_role, expected_type=type_hints["create_oidc_role"])
            check_type(argname="argument github_oidc", value=github_oidc, expected_type=type_hints["github_oidc"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument oidc_role_name", value=oidc_role_name, expected_type=type_hints["oidc_role_name"])
            check_type(argname="argument skip_oidc_provider_creation", value=skip_oidc_provider_creation, expected_type=type_hints["skip_oidc_provider_creation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "role_name": role_name,
        }
        if create_oidc_role is not None:
            self._values["create_oidc_role"] = create_oidc_role
        if github_oidc is not None:
            self._values["github_oidc"] = github_oidc
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn
        if oidc_role_name is not None:
            self._values["oidc_role_name"] = oidc_role_name
        if skip_oidc_provider_creation is not None:
            self._values["skip_oidc_provider_creation"] = skip_oidc_provider_creation

    @builtins.property
    def role_name(self) -> builtins.str:
        '''(experimental) Name for the changeset IAM role.

        :stability: experimental
        '''
        result = self._values.get("role_name")
        assert result is not None, "Required property 'role_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def create_oidc_role(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Create a GitHub OIDC role within this template instead of using an existing one.

        When true, githubOidc configuration is required and oidcRoleArn is ignored.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("create_oidc_role")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def github_oidc(self) -> typing.Optional["GitHubOidcConfig"]:
        '''(experimental) GitHub OIDC configuration for repo/branch restrictions.

        Required when createOidcRole is true.

        :stability: experimental
        '''
        result = self._values.get("github_oidc")
        return typing.cast(typing.Optional["GitHubOidcConfig"], result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''(experimental) Region for the OIDC trust condition.

        Only used when oidcRoleArn is provided (external OIDC role).

        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''(experimental) ARN of the existing GitHub OIDC role that can assume this changeset role.

        Required when createOidcRole is false or undefined.

        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the GitHub OIDC role to create.

        Only used when createOidcRole is true.
        Default: 'GitHubOIDCRole'

        :stability: experimental
        '''
        result = self._values.get("oidc_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_oidc_provider_creation(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Skip creating the OIDC provider (use existing one).

        Set to true if the account already has a GitHub OIDC provider.
        Only used when createOidcRole is true.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("skip_oidc_provider_creation")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffIamTemplateGeneratorProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateProps",
    jsii_struct_bases=[CdkDiffIamTemplateGeneratorProps],
    name_mapping={
        "role_name": "roleName",
        "create_oidc_role": "createOidcRole",
        "github_oidc": "githubOidc",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "oidc_role_name": "oidcRoleName",
        "skip_oidc_provider_creation": "skipOidcProviderCreation",
        "project": "project",
        "output_path": "outputPath",
    },
)
class CdkDiffIamTemplateProps(CdkDiffIamTemplateGeneratorProps):
    def __init__(
        self,
        *,
        role_name: builtins.str,
        create_oidc_role: typing.Optional[builtins.bool] = None,
        github_oidc: typing.Optional[typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
        project: typing.Any,
        output_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Props for the Projen-integrated CDK Diff IAM template construct.

        :param role_name: (experimental) Name for the changeset IAM role.
        :param create_oidc_role: (experimental) Create a GitHub OIDC role within this template instead of using an existing one. When true, githubOidc configuration is required and oidcRoleArn is ignored. Default: false
        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions. Required when createOidcRole is true.
        :param oidc_region: (experimental) Region for the OIDC trust condition. Only used when oidcRoleArn is provided (external OIDC role).
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this changeset role. Required when createOidcRole is false or undefined.
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role to create. Only used when createOidcRole is true. Default: 'GitHubOIDCRole'
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if the account already has a GitHub OIDC provider. Only used when createOidcRole is true. Default: false
        :param project: (experimental) Projen project instance.
        :param output_path: (experimental) Output path for the template file (default: 'cdk-diff-workflow-iam-template.yaml').

        :stability: experimental
        '''
        if isinstance(github_oidc, dict):
            github_oidc = GitHubOidcConfig(**github_oidc)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c59bae450062c72fde714b03a78e1f33a990657c10db0c149be29c4dc15edf7a)
            check_type(argname="argument role_name", value=role_name, expected_type=type_hints["role_name"])
            check_type(argname="argument create_oidc_role", value=create_oidc_role, expected_type=type_hints["create_oidc_role"])
            check_type(argname="argument github_oidc", value=github_oidc, expected_type=type_hints["github_oidc"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument oidc_role_name", value=oidc_role_name, expected_type=type_hints["oidc_role_name"])
            check_type(argname="argument skip_oidc_provider_creation", value=skip_oidc_provider_creation, expected_type=type_hints["skip_oidc_provider_creation"])
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument output_path", value=output_path, expected_type=type_hints["output_path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "role_name": role_name,
            "project": project,
        }
        if create_oidc_role is not None:
            self._values["create_oidc_role"] = create_oidc_role
        if github_oidc is not None:
            self._values["github_oidc"] = github_oidc
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn
        if oidc_role_name is not None:
            self._values["oidc_role_name"] = oidc_role_name
        if skip_oidc_provider_creation is not None:
            self._values["skip_oidc_provider_creation"] = skip_oidc_provider_creation
        if output_path is not None:
            self._values["output_path"] = output_path

    @builtins.property
    def role_name(self) -> builtins.str:
        '''(experimental) Name for the changeset IAM role.

        :stability: experimental
        '''
        result = self._values.get("role_name")
        assert result is not None, "Required property 'role_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def create_oidc_role(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Create a GitHub OIDC role within this template instead of using an existing one.

        When true, githubOidc configuration is required and oidcRoleArn is ignored.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("create_oidc_role")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def github_oidc(self) -> typing.Optional["GitHubOidcConfig"]:
        '''(experimental) GitHub OIDC configuration for repo/branch restrictions.

        Required when createOidcRole is true.

        :stability: experimental
        '''
        result = self._values.get("github_oidc")
        return typing.cast(typing.Optional["GitHubOidcConfig"], result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''(experimental) Region for the OIDC trust condition.

        Only used when oidcRoleArn is provided (external OIDC role).

        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''(experimental) ARN of the existing GitHub OIDC role that can assume this changeset role.

        Required when createOidcRole is false or undefined.

        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the GitHub OIDC role to create.

        Only used when createOidcRole is true.
        Default: 'GitHubOIDCRole'

        :stability: experimental
        '''
        result = self._values.get("oidc_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def skip_oidc_provider_creation(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Skip creating the OIDC provider (use existing one).

        Set to true if the account already has a GitHub OIDC provider.
        Only used when createOidcRole is true.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("skip_oidc_provider_creation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def project(self) -> typing.Any:
        '''(experimental) Projen project instance.

        :stability: experimental
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast(typing.Any, result)

    @builtins.property
    def output_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) Output path for the template file (default: 'cdk-diff-workflow-iam-template.yaml').

        :stability: experimental
        '''
        result = self._values.get("output_path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffIamTemplateProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDiffIamTemplateStackSet(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateStackSet",
):
    '''(experimental) Projen construct that creates a CloudFormation StackSet template for org-wide deployment of GitHub OIDC provider, OIDC role, and CDK Diff/Drift IAM roles.

    This provides a self-contained per-account deployment with no role chaining required.

    For non-Projen projects, use ``CdkDiffIamTemplateStackSetGenerator`` directly.

    :stability: experimental
    '''

    def __init__(
        self,
        *,
        project: typing.Any,
        auto_deployment: typing.Optional[typing.Union["StackSetAutoDeployment", typing.Dict[builtins.str, typing.Any]]] = None,
        delegated_admin: typing.Optional[builtins.bool] = None,
        output_path: typing.Optional[builtins.str] = None,
        regions: typing.Optional[typing.Sequence[builtins.str]] = None,
        stack_set_name: typing.Optional[builtins.str] = None,
        target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        github_oidc: typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]],
        changeset_role_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        drift_role_name: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        role_selection: typing.Optional["StackSetRoleSelection"] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''
        :param project: (experimental) Projen project instance.
        :param auto_deployment: (experimental) Auto-deployment configuration.
        :param delegated_admin: (experimental) Whether to use delegated admin mode for StackSet operations. If true, adds --call-as DELEGATED_ADMIN to commands. If false, assumes running from the management account. Default: true
        :param output_path: (experimental) Output path for the template file (default: 'cdk-diff-workflow-stackset-template.yaml').
        :param regions: (experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).
        :param stack_set_name: (experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').
        :param target_organizational_unit_ids: (experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).
        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions.
        :param changeset_role_name: (experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').
        :param description: (experimental) Description for the StackSet.
        :param drift_role_name: (experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').
        :param role_selection: (experimental) Which roles to include (default: BOTH).
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if accounts already have a GitHub OIDC provider. The template will reference the existing provider by ARN. Default: false

        :stability: experimental
        '''
        props = CdkDiffIamTemplateStackSetProps(
            project=project,
            auto_deployment=auto_deployment,
            delegated_admin=delegated_admin,
            output_path=output_path,
            regions=regions,
            stack_set_name=stack_set_name,
            target_organizational_unit_ids=target_organizational_unit_ids,
            github_oidc=github_oidc,
            changeset_role_name=changeset_role_name,
            description=description,
            drift_role_name=drift_role_name,
            oidc_role_name=oidc_role_name,
            role_selection=role_selection,
            skip_oidc_provider_creation=skip_oidc_provider_creation,
        )

        jsii.create(self.__class__, self, [props])


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateStackSetCommandsProps",
    jsii_struct_bases=[],
    name_mapping={
        "auto_deployment": "autoDeployment",
        "delegated_admin": "delegatedAdmin",
        "regions": "regions",
        "stack_set_name": "stackSetName",
        "target_organizational_unit_ids": "targetOrganizationalUnitIds",
        "template_path": "templatePath",
    },
)
class CdkDiffIamTemplateStackSetCommandsProps:
    def __init__(
        self,
        *,
        auto_deployment: typing.Optional[typing.Union["StackSetAutoDeployment", typing.Dict[builtins.str, typing.Any]]] = None,
        delegated_admin: typing.Optional[builtins.bool] = None,
        regions: typing.Optional[typing.Sequence[builtins.str]] = None,
        stack_set_name: typing.Optional[builtins.str] = None,
        target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        template_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Props for generating StackSet CLI commands (no Projen dependency).

        :param auto_deployment: (experimental) Auto-deployment configuration.
        :param delegated_admin: (experimental) Whether to use delegated admin mode for StackSet operations. If true, adds --call-as DELEGATED_ADMIN to commands. Default: true
        :param regions: (experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).
        :param stack_set_name: (experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').
        :param target_organizational_unit_ids: (experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).
        :param template_path: (experimental) Path to the template file (default: 'cdk-diff-workflow-stackset-template.yaml').

        :stability: experimental
        '''
        if isinstance(auto_deployment, dict):
            auto_deployment = StackSetAutoDeployment(**auto_deployment)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7e432c7e84fd22a0f705400e803c2beb9718b0b87dff89e95daebd3f6846488)
            check_type(argname="argument auto_deployment", value=auto_deployment, expected_type=type_hints["auto_deployment"])
            check_type(argname="argument delegated_admin", value=delegated_admin, expected_type=type_hints["delegated_admin"])
            check_type(argname="argument regions", value=regions, expected_type=type_hints["regions"])
            check_type(argname="argument stack_set_name", value=stack_set_name, expected_type=type_hints["stack_set_name"])
            check_type(argname="argument target_organizational_unit_ids", value=target_organizational_unit_ids, expected_type=type_hints["target_organizational_unit_ids"])
            check_type(argname="argument template_path", value=template_path, expected_type=type_hints["template_path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if auto_deployment is not None:
            self._values["auto_deployment"] = auto_deployment
        if delegated_admin is not None:
            self._values["delegated_admin"] = delegated_admin
        if regions is not None:
            self._values["regions"] = regions
        if stack_set_name is not None:
            self._values["stack_set_name"] = stack_set_name
        if target_organizational_unit_ids is not None:
            self._values["target_organizational_unit_ids"] = target_organizational_unit_ids
        if template_path is not None:
            self._values["template_path"] = template_path

    @builtins.property
    def auto_deployment(self) -> typing.Optional["StackSetAutoDeployment"]:
        '''(experimental) Auto-deployment configuration.

        :stability: experimental
        '''
        result = self._values.get("auto_deployment")
        return typing.cast(typing.Optional["StackSetAutoDeployment"], result)

    @builtins.property
    def delegated_admin(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to use delegated admin mode for StackSet operations.

        If true, adds --call-as DELEGATED_ADMIN to commands.
        Default: true

        :stability: experimental
        '''
        result = self._values.get("delegated_admin")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def regions(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).

        :stability: experimental
        '''
        result = self._values.get("regions")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def stack_set_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').

        :stability: experimental
        '''
        result = self._values.get("stack_set_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def target_organizational_unit_ids(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).

        :stability: experimental
        '''
        result = self._values.get("target_organizational_unit_ids")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def template_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) Path to the template file (default: 'cdk-diff-workflow-stackset-template.yaml').

        :stability: experimental
        '''
        result = self._values.get("template_path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffIamTemplateStackSetCommandsProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDiffIamTemplateStackSetGenerator(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateStackSetGenerator",
):
    '''(experimental) Pure generator class for StackSet templates and commands.

    No Projen dependency - can be used in any project.

    :stability: experimental
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="generateCommands")
    @builtins.classmethod
    def generate_commands(
        cls,
        *,
        auto_deployment: typing.Optional[typing.Union["StackSetAutoDeployment", typing.Dict[builtins.str, typing.Any]]] = None,
        delegated_admin: typing.Optional[builtins.bool] = None,
        regions: typing.Optional[typing.Sequence[builtins.str]] = None,
        stack_set_name: typing.Optional[builtins.str] = None,
        target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        template_path: typing.Optional[builtins.str] = None,
    ) -> typing.Mapping[builtins.str, builtins.str]:
        '''(experimental) Generate AWS CLI commands for StackSet operations.

        Returns a map of command names to shell commands.

        :param auto_deployment: (experimental) Auto-deployment configuration.
        :param delegated_admin: (experimental) Whether to use delegated admin mode for StackSet operations. If true, adds --call-as DELEGATED_ADMIN to commands. Default: true
        :param regions: (experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).
        :param stack_set_name: (experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').
        :param target_organizational_unit_ids: (experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).
        :param template_path: (experimental) Path to the template file (default: 'cdk-diff-workflow-stackset-template.yaml').

        :stability: experimental
        '''
        props = CdkDiffIamTemplateStackSetCommandsProps(
            auto_deployment=auto_deployment,
            delegated_admin=delegated_admin,
            regions=regions,
            stack_set_name=stack_set_name,
            target_organizational_unit_ids=target_organizational_unit_ids,
            template_path=template_path,
        )

        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.sinvoke(cls, "generateCommands", [props]))

    @jsii.member(jsii_name="generateTemplate")
    @builtins.classmethod
    def generate_template(
        cls,
        *,
        github_oidc: typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]],
        changeset_role_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        drift_role_name: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        role_selection: typing.Optional["StackSetRoleSelection"] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> builtins.str:
        '''(experimental) Generate the CloudFormation StackSet template as a YAML string.

        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions.
        :param changeset_role_name: (experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').
        :param description: (experimental) Description for the StackSet.
        :param drift_role_name: (experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').
        :param role_selection: (experimental) Which roles to include (default: BOTH).
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if accounts already have a GitHub OIDC provider. The template will reference the existing provider by ARN. Default: false

        :stability: experimental
        '''
        props = CdkDiffIamTemplateStackSetGeneratorProps(
            github_oidc=github_oidc,
            changeset_role_name=changeset_role_name,
            description=description,
            drift_role_name=drift_role_name,
            oidc_role_name=oidc_role_name,
            role_selection=role_selection,
            skip_oidc_provider_creation=skip_oidc_provider_creation,
        )

        return typing.cast(builtins.str, jsii.sinvoke(cls, "generateTemplate", [props]))


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateStackSetGeneratorProps",
    jsii_struct_bases=[],
    name_mapping={
        "github_oidc": "githubOidc",
        "changeset_role_name": "changesetRoleName",
        "description": "description",
        "drift_role_name": "driftRoleName",
        "oidc_role_name": "oidcRoleName",
        "role_selection": "roleSelection",
        "skip_oidc_provider_creation": "skipOidcProviderCreation",
    },
)
class CdkDiffIamTemplateStackSetGeneratorProps:
    def __init__(
        self,
        *,
        github_oidc: typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]],
        changeset_role_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        drift_role_name: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        role_selection: typing.Optional["StackSetRoleSelection"] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Props for generating StackSet templates (no Projen dependency).

        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions.
        :param changeset_role_name: (experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').
        :param description: (experimental) Description for the StackSet.
        :param drift_role_name: (experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').
        :param role_selection: (experimental) Which roles to include (default: BOTH).
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if accounts already have a GitHub OIDC provider. The template will reference the existing provider by ARN. Default: false

        :stability: experimental
        '''
        if isinstance(github_oidc, dict):
            github_oidc = GitHubOidcConfig(**github_oidc)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db2d89e564fd3108439ec5501be14444604083e26aed44d4cafc0b70cf2e9e13)
            check_type(argname="argument github_oidc", value=github_oidc, expected_type=type_hints["github_oidc"])
            check_type(argname="argument changeset_role_name", value=changeset_role_name, expected_type=type_hints["changeset_role_name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument drift_role_name", value=drift_role_name, expected_type=type_hints["drift_role_name"])
            check_type(argname="argument oidc_role_name", value=oidc_role_name, expected_type=type_hints["oidc_role_name"])
            check_type(argname="argument role_selection", value=role_selection, expected_type=type_hints["role_selection"])
            check_type(argname="argument skip_oidc_provider_creation", value=skip_oidc_provider_creation, expected_type=type_hints["skip_oidc_provider_creation"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "github_oidc": github_oidc,
        }
        if changeset_role_name is not None:
            self._values["changeset_role_name"] = changeset_role_name
        if description is not None:
            self._values["description"] = description
        if drift_role_name is not None:
            self._values["drift_role_name"] = drift_role_name
        if oidc_role_name is not None:
            self._values["oidc_role_name"] = oidc_role_name
        if role_selection is not None:
            self._values["role_selection"] = role_selection
        if skip_oidc_provider_creation is not None:
            self._values["skip_oidc_provider_creation"] = skip_oidc_provider_creation

    @builtins.property
    def github_oidc(self) -> "GitHubOidcConfig":
        '''(experimental) GitHub OIDC configuration for repo/branch restrictions.

        :stability: experimental
        '''
        result = self._values.get("github_oidc")
        assert result is not None, "Required property 'github_oidc' is missing"
        return typing.cast("GitHubOidcConfig", result)

    @builtins.property
    def changeset_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').

        :stability: experimental
        '''
        result = self._values.get("changeset_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) Description for the StackSet.

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def drift_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').

        :stability: experimental
        '''
        result = self._values.get("drift_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').

        :stability: experimental
        '''
        result = self._values.get("oidc_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def role_selection(self) -> typing.Optional["StackSetRoleSelection"]:
        '''(experimental) Which roles to include (default: BOTH).

        :stability: experimental
        '''
        result = self._values.get("role_selection")
        return typing.cast(typing.Optional["StackSetRoleSelection"], result)

    @builtins.property
    def skip_oidc_provider_creation(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Skip creating the OIDC provider (use existing one).

        Set to true if accounts already have a GitHub OIDC provider.
        The template will reference the existing provider by ARN.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("skip_oidc_provider_creation")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffIamTemplateStackSetGeneratorProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffIamTemplateStackSetProps",
    jsii_struct_bases=[CdkDiffIamTemplateStackSetGeneratorProps],
    name_mapping={
        "github_oidc": "githubOidc",
        "changeset_role_name": "changesetRoleName",
        "description": "description",
        "drift_role_name": "driftRoleName",
        "oidc_role_name": "oidcRoleName",
        "role_selection": "roleSelection",
        "skip_oidc_provider_creation": "skipOidcProviderCreation",
        "project": "project",
        "auto_deployment": "autoDeployment",
        "delegated_admin": "delegatedAdmin",
        "output_path": "outputPath",
        "regions": "regions",
        "stack_set_name": "stackSetName",
        "target_organizational_unit_ids": "targetOrganizationalUnitIds",
    },
)
class CdkDiffIamTemplateStackSetProps(CdkDiffIamTemplateStackSetGeneratorProps):
    def __init__(
        self,
        *,
        github_oidc: typing.Union["GitHubOidcConfig", typing.Dict[builtins.str, typing.Any]],
        changeset_role_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        drift_role_name: typing.Optional[builtins.str] = None,
        oidc_role_name: typing.Optional[builtins.str] = None,
        role_selection: typing.Optional["StackSetRoleSelection"] = None,
        skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
        project: typing.Any,
        auto_deployment: typing.Optional[typing.Union["StackSetAutoDeployment", typing.Dict[builtins.str, typing.Any]]] = None,
        delegated_admin: typing.Optional[builtins.bool] = None,
        output_path: typing.Optional[builtins.str] = None,
        regions: typing.Optional[typing.Sequence[builtins.str]] = None,
        stack_set_name: typing.Optional[builtins.str] = None,
        target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Props for the Projen-integrated StackSet construct.

        :param github_oidc: (experimental) GitHub OIDC configuration for repo/branch restrictions.
        :param changeset_role_name: (experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').
        :param description: (experimental) Description for the StackSet.
        :param drift_role_name: (experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').
        :param oidc_role_name: (experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').
        :param role_selection: (experimental) Which roles to include (default: BOTH).
        :param skip_oidc_provider_creation: (experimental) Skip creating the OIDC provider (use existing one). Set to true if accounts already have a GitHub OIDC provider. The template will reference the existing provider by ARN. Default: false
        :param project: (experimental) Projen project instance.
        :param auto_deployment: (experimental) Auto-deployment configuration.
        :param delegated_admin: (experimental) Whether to use delegated admin mode for StackSet operations. If true, adds --call-as DELEGATED_ADMIN to commands. If false, assumes running from the management account. Default: true
        :param output_path: (experimental) Output path for the template file (default: 'cdk-diff-workflow-stackset-template.yaml').
        :param regions: (experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).
        :param stack_set_name: (experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').
        :param target_organizational_unit_ids: (experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).

        :stability: experimental
        '''
        if isinstance(github_oidc, dict):
            github_oidc = GitHubOidcConfig(**github_oidc)
        if isinstance(auto_deployment, dict):
            auto_deployment = StackSetAutoDeployment(**auto_deployment)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a8159f856c24b15134aa7a1be616f48ad617adb8391234235252ec0b13d6944)
            check_type(argname="argument github_oidc", value=github_oidc, expected_type=type_hints["github_oidc"])
            check_type(argname="argument changeset_role_name", value=changeset_role_name, expected_type=type_hints["changeset_role_name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument drift_role_name", value=drift_role_name, expected_type=type_hints["drift_role_name"])
            check_type(argname="argument oidc_role_name", value=oidc_role_name, expected_type=type_hints["oidc_role_name"])
            check_type(argname="argument role_selection", value=role_selection, expected_type=type_hints["role_selection"])
            check_type(argname="argument skip_oidc_provider_creation", value=skip_oidc_provider_creation, expected_type=type_hints["skip_oidc_provider_creation"])
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument auto_deployment", value=auto_deployment, expected_type=type_hints["auto_deployment"])
            check_type(argname="argument delegated_admin", value=delegated_admin, expected_type=type_hints["delegated_admin"])
            check_type(argname="argument output_path", value=output_path, expected_type=type_hints["output_path"])
            check_type(argname="argument regions", value=regions, expected_type=type_hints["regions"])
            check_type(argname="argument stack_set_name", value=stack_set_name, expected_type=type_hints["stack_set_name"])
            check_type(argname="argument target_organizational_unit_ids", value=target_organizational_unit_ids, expected_type=type_hints["target_organizational_unit_ids"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "github_oidc": github_oidc,
            "project": project,
        }
        if changeset_role_name is not None:
            self._values["changeset_role_name"] = changeset_role_name
        if description is not None:
            self._values["description"] = description
        if drift_role_name is not None:
            self._values["drift_role_name"] = drift_role_name
        if oidc_role_name is not None:
            self._values["oidc_role_name"] = oidc_role_name
        if role_selection is not None:
            self._values["role_selection"] = role_selection
        if skip_oidc_provider_creation is not None:
            self._values["skip_oidc_provider_creation"] = skip_oidc_provider_creation
        if auto_deployment is not None:
            self._values["auto_deployment"] = auto_deployment
        if delegated_admin is not None:
            self._values["delegated_admin"] = delegated_admin
        if output_path is not None:
            self._values["output_path"] = output_path
        if regions is not None:
            self._values["regions"] = regions
        if stack_set_name is not None:
            self._values["stack_set_name"] = stack_set_name
        if target_organizational_unit_ids is not None:
            self._values["target_organizational_unit_ids"] = target_organizational_unit_ids

    @builtins.property
    def github_oidc(self) -> "GitHubOidcConfig":
        '''(experimental) GitHub OIDC configuration for repo/branch restrictions.

        :stability: experimental
        '''
        result = self._values.get("github_oidc")
        assert result is not None, "Required property 'github_oidc' is missing"
        return typing.cast("GitHubOidcConfig", result)

    @builtins.property
    def changeset_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the CdkChangesetRole (default: 'CdkChangesetRole').

        :stability: experimental
        '''
        result = self._values.get("changeset_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) Description for the StackSet.

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def drift_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the CdkDriftRole (default: 'CdkDriftRole').

        :stability: experimental
        '''
        result = self._values.get("drift_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the GitHub OIDC role (default: 'GitHubOIDCRole').

        :stability: experimental
        '''
        result = self._values.get("oidc_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def role_selection(self) -> typing.Optional["StackSetRoleSelection"]:
        '''(experimental) Which roles to include (default: BOTH).

        :stability: experimental
        '''
        result = self._values.get("role_selection")
        return typing.cast(typing.Optional["StackSetRoleSelection"], result)

    @builtins.property
    def skip_oidc_provider_creation(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Skip creating the OIDC provider (use existing one).

        Set to true if accounts already have a GitHub OIDC provider.
        The template will reference the existing provider by ARN.
        Default: false

        :stability: experimental
        '''
        result = self._values.get("skip_oidc_provider_creation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def project(self) -> typing.Any:
        '''(experimental) Projen project instance.

        :stability: experimental
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast(typing.Any, result)

    @builtins.property
    def auto_deployment(self) -> typing.Optional["StackSetAutoDeployment"]:
        '''(experimental) Auto-deployment configuration.

        :stability: experimental
        '''
        result = self._values.get("auto_deployment")
        return typing.cast(typing.Optional["StackSetAutoDeployment"], result)

    @builtins.property
    def delegated_admin(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to use delegated admin mode for StackSet operations.

        If true, adds --call-as DELEGATED_ADMIN to commands.
        If false, assumes running from the management account.
        Default: true

        :stability: experimental
        '''
        result = self._values.get("delegated_admin")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def output_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) Output path for the template file (default: 'cdk-diff-workflow-stackset-template.yaml').

        :stability: experimental
        '''
        result = self._values.get("output_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def regions(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Target regions for deployment (e.g., ['us-east-1', 'eu-west-1']).

        :stability: experimental
        '''
        result = self._values.get("regions")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def stack_set_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the StackSet (default: 'cdk-diff-workflow-iam-stackset').

        :stability: experimental
        '''
        result = self._values.get("stack_set_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def target_organizational_unit_ids(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Target OUs for deployment (e.g., ['ou-xxxx-xxxxxxxx', 'r-xxxx']).

        :stability: experimental
        '''
        result = self._values.get("target_organizational_unit_ids")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffIamTemplateStackSetProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffStack",
    jsii_struct_bases=[],
    name_mapping={
        "changeset_role_to_assume_arn": "changesetRoleToAssumeArn",
        "changeset_role_to_assume_region": "changesetRoleToAssumeRegion",
        "stack_name": "stackName",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
    },
)
class CdkDiffStack:
    def __init__(
        self,
        *,
        changeset_role_to_assume_arn: builtins.str,
        changeset_role_to_assume_region: builtins.str,
        stack_name: builtins.str,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param changeset_role_to_assume_arn: 
        :param changeset_role_to_assume_region: 
        :param stack_name: 
        :param oidc_region: 
        :param oidc_role_arn: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4269959bff369e12ddef9db120d66bb983e4d98054ca9ac00605855098f3edbf)
            check_type(argname="argument changeset_role_to_assume_arn", value=changeset_role_to_assume_arn, expected_type=type_hints["changeset_role_to_assume_arn"])
            check_type(argname="argument changeset_role_to_assume_region", value=changeset_role_to_assume_region, expected_type=type_hints["changeset_role_to_assume_region"])
            check_type(argname="argument stack_name", value=stack_name, expected_type=type_hints["stack_name"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "changeset_role_to_assume_arn": changeset_role_to_assume_arn,
            "changeset_role_to_assume_region": changeset_role_to_assume_region,
            "stack_name": stack_name,
        }
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn

    @builtins.property
    def changeset_role_to_assume_arn(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("changeset_role_to_assume_arn")
        assert result is not None, "Required property 'changeset_role_to_assume_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def changeset_role_to_assume_region(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("changeset_role_to_assume_region")
        assert result is not None, "Required property 'changeset_role_to_assume_region' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stack_name(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("stack_name")
        assert result is not None, "Required property 'stack_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffStack(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDiffStackWorkflow(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffStackWorkflow",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        *,
        project: typing.Any,
        stacks: typing.Sequence[typing.Union["CdkDiffStack", typing.Dict[builtins.str, typing.Any]]],
        cdk_yarn_command: typing.Optional[builtins.str] = None,
        node_version: typing.Optional[builtins.str] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        script_output_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param project: 
        :param stacks: 
        :param cdk_yarn_command: 
        :param node_version: 
        :param oidc_region: 
        :param oidc_role_arn: 
        :param script_output_path: 

        :stability: experimental
        '''
        props = CdkDiffStackWorkflowProps(
            project=project,
            stacks=stacks,
            cdk_yarn_command=cdk_yarn_command,
            node_version=node_version,
            oidc_region=oidc_region,
            oidc_role_arn=oidc_role_arn,
            script_output_path=script_output_path,
        )

        jsii.create(self.__class__, self, [props])


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDiffStackWorkflowProps",
    jsii_struct_bases=[],
    name_mapping={
        "project": "project",
        "stacks": "stacks",
        "cdk_yarn_command": "cdkYarnCommand",
        "node_version": "nodeVersion",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "script_output_path": "scriptOutputPath",
    },
)
class CdkDiffStackWorkflowProps:
    def __init__(
        self,
        *,
        project: typing.Any,
        stacks: typing.Sequence[typing.Union["CdkDiffStack", typing.Dict[builtins.str, typing.Any]]],
        cdk_yarn_command: typing.Optional[builtins.str] = None,
        node_version: typing.Optional[builtins.str] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        script_output_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param project: 
        :param stacks: 
        :param cdk_yarn_command: 
        :param node_version: 
        :param oidc_region: 
        :param oidc_role_arn: 
        :param script_output_path: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b43eba1e69093a4ed7af7be3a8346e69e74a3cd7b329bf4f993c208621006e32)
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument stacks", value=stacks, expected_type=type_hints["stacks"])
            check_type(argname="argument cdk_yarn_command", value=cdk_yarn_command, expected_type=type_hints["cdk_yarn_command"])
            check_type(argname="argument node_version", value=node_version, expected_type=type_hints["node_version"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument script_output_path", value=script_output_path, expected_type=type_hints["script_output_path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "project": project,
            "stacks": stacks,
        }
        if cdk_yarn_command is not None:
            self._values["cdk_yarn_command"] = cdk_yarn_command
        if node_version is not None:
            self._values["node_version"] = node_version
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn
        if script_output_path is not None:
            self._values["script_output_path"] = script_output_path

    @builtins.property
    def project(self) -> typing.Any:
        '''
        :stability: experimental
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast(typing.Any, result)

    @builtins.property
    def stacks(self) -> typing.List["CdkDiffStack"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("stacks")
        assert result is not None, "Required property 'stacks' is missing"
        return typing.cast(typing.List["CdkDiffStack"], result)

    @builtins.property
    def cdk_yarn_command(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("cdk_yarn_command")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def node_version(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("node_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def script_output_path(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("script_output_path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDiffStackWorkflowProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDriftDetectionWorkflow(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftDetectionWorkflow",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        *,
        project: typing.Any,
        stacks: typing.Sequence[typing.Union["Stack", typing.Dict[builtins.str, typing.Any]]],
        create_issues: typing.Optional[builtins.bool] = None,
        node_version: typing.Optional[builtins.str] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        post_git_hub_steps: typing.Any = None,
        schedule: typing.Optional[builtins.str] = None,
        script_output_path: typing.Optional[builtins.str] = None,
        workflow_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param project: 
        :param stacks: 
        :param create_issues: 
        :param node_version: 
        :param oidc_region: 
        :param oidc_role_arn: 
        :param post_git_hub_steps: (experimental) Optional additional GitHub Action steps to run after drift detection for each stack. These steps run after results are uploaded for each stack. You can include any notifications you like (e.g., Slack). Provide explicit inputs (e.g., payload/markdown) directly in your step without relying on a pre-generated payload.
        :param schedule: 
        :param script_output_path: 
        :param workflow_name: 

        :stability: experimental
        '''
        props = CdkDriftDetectionWorkflowProps(
            project=project,
            stacks=stacks,
            create_issues=create_issues,
            node_version=node_version,
            oidc_region=oidc_region,
            oidc_role_arn=oidc_role_arn,
            post_git_hub_steps=post_git_hub_steps,
            schedule=schedule,
            script_output_path=script_output_path,
            workflow_name=workflow_name,
        )

        jsii.create(self.__class__, self, [props])


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftDetectionWorkflowProps",
    jsii_struct_bases=[],
    name_mapping={
        "project": "project",
        "stacks": "stacks",
        "create_issues": "createIssues",
        "node_version": "nodeVersion",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "post_git_hub_steps": "postGitHubSteps",
        "schedule": "schedule",
        "script_output_path": "scriptOutputPath",
        "workflow_name": "workflowName",
    },
)
class CdkDriftDetectionWorkflowProps:
    def __init__(
        self,
        *,
        project: typing.Any,
        stacks: typing.Sequence[typing.Union["Stack", typing.Dict[builtins.str, typing.Any]]],
        create_issues: typing.Optional[builtins.bool] = None,
        node_version: typing.Optional[builtins.str] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
        post_git_hub_steps: typing.Any = None,
        schedule: typing.Optional[builtins.str] = None,
        script_output_path: typing.Optional[builtins.str] = None,
        workflow_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param project: 
        :param stacks: 
        :param create_issues: 
        :param node_version: 
        :param oidc_region: 
        :param oidc_role_arn: 
        :param post_git_hub_steps: (experimental) Optional additional GitHub Action steps to run after drift detection for each stack. These steps run after results are uploaded for each stack. You can include any notifications you like (e.g., Slack). Provide explicit inputs (e.g., payload/markdown) directly in your step without relying on a pre-generated payload.
        :param schedule: 
        :param script_output_path: 
        :param workflow_name: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22a5b8885f12f60dfdb8eff26ff4500820f6d82da230a604b66d5a8da1a88aaf)
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument stacks", value=stacks, expected_type=type_hints["stacks"])
            check_type(argname="argument create_issues", value=create_issues, expected_type=type_hints["create_issues"])
            check_type(argname="argument node_version", value=node_version, expected_type=type_hints["node_version"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument post_git_hub_steps", value=post_git_hub_steps, expected_type=type_hints["post_git_hub_steps"])
            check_type(argname="argument schedule", value=schedule, expected_type=type_hints["schedule"])
            check_type(argname="argument script_output_path", value=script_output_path, expected_type=type_hints["script_output_path"])
            check_type(argname="argument workflow_name", value=workflow_name, expected_type=type_hints["workflow_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "project": project,
            "stacks": stacks,
        }
        if create_issues is not None:
            self._values["create_issues"] = create_issues
        if node_version is not None:
            self._values["node_version"] = node_version
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn
        if post_git_hub_steps is not None:
            self._values["post_git_hub_steps"] = post_git_hub_steps
        if schedule is not None:
            self._values["schedule"] = schedule
        if script_output_path is not None:
            self._values["script_output_path"] = script_output_path
        if workflow_name is not None:
            self._values["workflow_name"] = workflow_name

    @builtins.property
    def project(self) -> typing.Any:
        '''
        :stability: experimental
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast(typing.Any, result)

    @builtins.property
    def stacks(self) -> typing.List["Stack"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("stacks")
        assert result is not None, "Required property 'stacks' is missing"
        return typing.cast(typing.List["Stack"], result)

    @builtins.property
    def create_issues(self) -> typing.Optional[builtins.bool]:
        '''
        :stability: experimental
        '''
        result = self._values.get("create_issues")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def node_version(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("node_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def post_git_hub_steps(self) -> typing.Any:
        '''(experimental) Optional additional GitHub Action steps to run after drift detection for each stack.

        These steps run after results are uploaded for each stack. You can include
        any notifications you like (e.g., Slack). Provide explicit inputs (e.g., payload/markdown)
        directly in your step without relying on a pre-generated payload.

        :stability: experimental
        '''
        result = self._values.get("post_git_hub_steps")
        return typing.cast(typing.Any, result)

    @builtins.property
    def schedule(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("schedule")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def script_output_path(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("script_output_path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def workflow_name(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("workflow_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDriftDetectionWorkflowProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDriftIamTemplate(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftIamTemplate",
):
    '''(experimental) Projen construct that emits a CloudFormation template with minimal IAM permissions for the CDK Drift Detection Workflow.

    For non-Projen projects, use ``CdkDriftIamTemplateGenerator`` directly.

    :stability: experimental
    '''

    def __init__(
        self,
        *,
        project: typing.Any,
        output_path: typing.Optional[builtins.str] = None,
        oidc_region: builtins.str,
        oidc_role_arn: builtins.str,
        role_name: builtins.str,
    ) -> None:
        '''
        :param project: (experimental) Projen project instance.
        :param output_path: (experimental) Output path for the template file (default: 'cdk-drift-workflow-iam-template.yaml').
        :param oidc_region: (experimental) Region for the OIDC trust condition.
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this drift role.
        :param role_name: (experimental) Name for the IAM role.

        :stability: experimental
        '''
        props = CdkDriftIamTemplateProps(
            project=project,
            output_path=output_path,
            oidc_region=oidc_region,
            oidc_role_arn=oidc_role_arn,
            role_name=role_name,
        )

        jsii.create(self.__class__, self, [props])


class CdkDriftIamTemplateGenerator(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftIamTemplateGenerator",
):
    '''(experimental) Pure generator class for CDK Drift IAM templates.

    No Projen dependency - can be used in any project.

    :stability: experimental
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="generateDeployCommand")
    @builtins.classmethod
    def generate_deploy_command(
        cls,
        template_path: typing.Optional[builtins.str] = None,
    ) -> builtins.str:
        '''(experimental) Generate the AWS CLI deploy command for the IAM template.

        :param template_path: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a09e05fb253535e5442df09b981c8d727e6f7eae7f609c37c54397f23b1454e)
            check_type(argname="argument template_path", value=template_path, expected_type=type_hints["template_path"])
        return typing.cast(builtins.str, jsii.sinvoke(cls, "generateDeployCommand", [template_path]))

    @jsii.member(jsii_name="generateTemplate")
    @builtins.classmethod
    def generate_template(
        cls,
        *,
        oidc_region: builtins.str,
        oidc_role_arn: builtins.str,
        role_name: builtins.str,
    ) -> builtins.str:
        '''(experimental) Generate the CloudFormation IAM template as a YAML string.

        :param oidc_region: (experimental) Region for the OIDC trust condition.
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this drift role.
        :param role_name: (experimental) Name for the IAM role.

        :stability: experimental
        '''
        props = CdkDriftIamTemplateGeneratorProps(
            oidc_region=oidc_region, oidc_role_arn=oidc_role_arn, role_name=role_name
        )

        return typing.cast(builtins.str, jsii.sinvoke(cls, "generateTemplate", [props]))


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftIamTemplateGeneratorProps",
    jsii_struct_bases=[],
    name_mapping={
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "role_name": "roleName",
    },
)
class CdkDriftIamTemplateGeneratorProps:
    def __init__(
        self,
        *,
        oidc_region: builtins.str,
        oidc_role_arn: builtins.str,
        role_name: builtins.str,
    ) -> None:
        '''(experimental) Props for generating CDK Drift IAM templates (no Projen dependency).

        :param oidc_region: (experimental) Region for the OIDC trust condition.
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this drift role.
        :param role_name: (experimental) Name for the IAM role.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f41dc20b7ea937dd146b5c0d1dc20b792ffcac5172f7d106df11c36721d8030)
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument role_name", value=role_name, expected_type=type_hints["role_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "oidc_region": oidc_region,
            "oidc_role_arn": oidc_role_arn,
            "role_name": role_name,
        }

    @builtins.property
    def oidc_region(self) -> builtins.str:
        '''(experimental) Region for the OIDC trust condition.

        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        assert result is not None, "Required property 'oidc_region' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def oidc_role_arn(self) -> builtins.str:
        '''(experimental) ARN of the existing GitHub OIDC role that can assume this drift role.

        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        assert result is not None, "Required property 'oidc_role_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_name(self) -> builtins.str:
        '''(experimental) Name for the IAM role.

        :stability: experimental
        '''
        result = self._values.get("role_name")
        assert result is not None, "Required property 'role_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDriftIamTemplateGeneratorProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.CdkDriftIamTemplateProps",
    jsii_struct_bases=[CdkDriftIamTemplateGeneratorProps],
    name_mapping={
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
        "role_name": "roleName",
        "project": "project",
        "output_path": "outputPath",
    },
)
class CdkDriftIamTemplateProps(CdkDriftIamTemplateGeneratorProps):
    def __init__(
        self,
        *,
        oidc_region: builtins.str,
        oidc_role_arn: builtins.str,
        role_name: builtins.str,
        project: typing.Any,
        output_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Props for the Projen-integrated CDK Drift IAM template construct.

        :param oidc_region: (experimental) Region for the OIDC trust condition.
        :param oidc_role_arn: (experimental) ARN of the existing GitHub OIDC role that can assume this drift role.
        :param role_name: (experimental) Name for the IAM role.
        :param project: (experimental) Projen project instance.
        :param output_path: (experimental) Output path for the template file (default: 'cdk-drift-workflow-iam-template.yaml').

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__971a5cf20cf4a5e82cfe24ad53df9002d13454fd436a485bbe7bef575497886e)
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
            check_type(argname="argument role_name", value=role_name, expected_type=type_hints["role_name"])
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument output_path", value=output_path, expected_type=type_hints["output_path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "oidc_region": oidc_region,
            "oidc_role_arn": oidc_role_arn,
            "role_name": role_name,
            "project": project,
        }
        if output_path is not None:
            self._values["output_path"] = output_path

    @builtins.property
    def oidc_region(self) -> builtins.str:
        '''(experimental) Region for the OIDC trust condition.

        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        assert result is not None, "Required property 'oidc_region' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def oidc_role_arn(self) -> builtins.str:
        '''(experimental) ARN of the existing GitHub OIDC role that can assume this drift role.

        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        assert result is not None, "Required property 'oidc_role_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_name(self) -> builtins.str:
        '''(experimental) Name for the IAM role.

        :stability: experimental
        '''
        result = self._values.get("role_name")
        assert result is not None, "Required property 'role_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def project(self) -> typing.Any:
        '''(experimental) Projen project instance.

        :stability: experimental
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast(typing.Any, result)

    @builtins.property
    def output_path(self) -> typing.Optional[builtins.str]:
        '''(experimental) Output path for the template file (default: 'cdk-drift-workflow-iam-template.yaml').

        :stability: experimental
        '''
        result = self._values.get("output_path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDriftIamTemplateProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.GitHubOidcConfig",
    jsii_struct_bases=[],
    name_mapping={
        "owner": "owner",
        "repositories": "repositories",
        "additional_claims": "additionalClaims",
        "branches": "branches",
    },
)
class GitHubOidcConfig:
    def __init__(
        self,
        *,
        owner: builtins.str,
        repositories: typing.Sequence[builtins.str],
        additional_claims: typing.Optional[typing.Sequence[builtins.str]] = None,
        branches: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) GitHub repository restrictions for OIDC authentication.

        :param owner: (experimental) GitHub organization or username (e.g., 'my-org' or 'my-username').
        :param repositories: (experimental) Repository names allowed to assume the role (e.g., ['repo1', 'repo2']) Use ['*'] to allow all repos in the organization.
        :param additional_claims: (experimental) Additional subject claims for fine-grained access e.g., ['pull_request', 'environment:production'].
        :param branches: (experimental) Branch patterns allowed (e.g., ['main', 'release/*']) Default: ['*'] (all branches).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74604e3432febf874eca4106d20d930c6338d5020089922682ee59ac37fbedc4)
            check_type(argname="argument owner", value=owner, expected_type=type_hints["owner"])
            check_type(argname="argument repositories", value=repositories, expected_type=type_hints["repositories"])
            check_type(argname="argument additional_claims", value=additional_claims, expected_type=type_hints["additional_claims"])
            check_type(argname="argument branches", value=branches, expected_type=type_hints["branches"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "owner": owner,
            "repositories": repositories,
        }
        if additional_claims is not None:
            self._values["additional_claims"] = additional_claims
        if branches is not None:
            self._values["branches"] = branches

    @builtins.property
    def owner(self) -> builtins.str:
        '''(experimental) GitHub organization or username (e.g., 'my-org' or 'my-username').

        :stability: experimental
        '''
        result = self._values.get("owner")
        assert result is not None, "Required property 'owner' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def repositories(self) -> typing.List[builtins.str]:
        '''(experimental) Repository names allowed to assume the role (e.g., ['repo1', 'repo2']) Use ['*'] to allow all repos in the organization.

        :stability: experimental
        '''
        result = self._values.get("repositories")
        assert result is not None, "Required property 'repositories' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def additional_claims(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Additional subject claims for fine-grained access e.g., ['pull_request', 'environment:production'].

        :stability: experimental
        '''
        result = self._values.get("additional_claims")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def branches(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Branch patterns allowed (e.g., ['main', 'release/*']) Default: ['*'] (all branches).

        :stability: experimental
        '''
        result = self._values.get("branches")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GitHubOidcConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.Stack",
    jsii_struct_bases=[],
    name_mapping={
        "drift_detection_role_to_assume_arn": "driftDetectionRoleToAssumeArn",
        "drift_detection_role_to_assume_region": "driftDetectionRoleToAssumeRegion",
        "stack_name": "stackName",
        "fail_on_drift": "failOnDrift",
        "oidc_region": "oidcRegion",
        "oidc_role_arn": "oidcRoleArn",
    },
)
class Stack:
    def __init__(
        self,
        *,
        drift_detection_role_to_assume_arn: builtins.str,
        drift_detection_role_to_assume_region: builtins.str,
        stack_name: builtins.str,
        fail_on_drift: typing.Optional[builtins.bool] = None,
        oidc_region: typing.Optional[builtins.str] = None,
        oidc_role_arn: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param drift_detection_role_to_assume_arn: 
        :param drift_detection_role_to_assume_region: 
        :param stack_name: 
        :param fail_on_drift: 
        :param oidc_region: 
        :param oidc_role_arn: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cfd47aeadef895a9d2c7d9c3785c0ba4d4eb29e95dab8adceae64a03de471a75)
            check_type(argname="argument drift_detection_role_to_assume_arn", value=drift_detection_role_to_assume_arn, expected_type=type_hints["drift_detection_role_to_assume_arn"])
            check_type(argname="argument drift_detection_role_to_assume_region", value=drift_detection_role_to_assume_region, expected_type=type_hints["drift_detection_role_to_assume_region"])
            check_type(argname="argument stack_name", value=stack_name, expected_type=type_hints["stack_name"])
            check_type(argname="argument fail_on_drift", value=fail_on_drift, expected_type=type_hints["fail_on_drift"])
            check_type(argname="argument oidc_region", value=oidc_region, expected_type=type_hints["oidc_region"])
            check_type(argname="argument oidc_role_arn", value=oidc_role_arn, expected_type=type_hints["oidc_role_arn"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "drift_detection_role_to_assume_arn": drift_detection_role_to_assume_arn,
            "drift_detection_role_to_assume_region": drift_detection_role_to_assume_region,
            "stack_name": stack_name,
        }
        if fail_on_drift is not None:
            self._values["fail_on_drift"] = fail_on_drift
        if oidc_region is not None:
            self._values["oidc_region"] = oidc_region
        if oidc_role_arn is not None:
            self._values["oidc_role_arn"] = oidc_role_arn

    @builtins.property
    def drift_detection_role_to_assume_arn(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("drift_detection_role_to_assume_arn")
        assert result is not None, "Required property 'drift_detection_role_to_assume_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def drift_detection_role_to_assume_region(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("drift_detection_role_to_assume_region")
        assert result is not None, "Required property 'drift_detection_role_to_assume_region' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stack_name(self) -> builtins.str:
        '''
        :stability: experimental
        '''
        result = self._values.get("stack_name")
        assert result is not None, "Required property 'stack_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def fail_on_drift(self) -> typing.Optional[builtins.bool]:
        '''
        :stability: experimental
        '''
        result = self._values.get("fail_on_drift")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def oidc_region(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def oidc_role_arn(self) -> typing.Optional[builtins.str]:
        '''
        :stability: experimental
        '''
        result = self._values.get("oidc_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "Stack(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-diff-pr-github-action.StackSetAutoDeployment",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "retain_stacks_on_account_removal": "retainStacksOnAccountRemoval",
    },
)
class StackSetAutoDeployment:
    def __init__(
        self,
        *,
        enabled: typing.Optional[builtins.bool] = None,
        retain_stacks_on_account_removal: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Configuration for StackSet auto-deployment.

        :param enabled: (experimental) Enable auto-deployment to new accounts in target OUs (default: true).
        :param retain_stacks_on_account_removal: (experimental) Retain stacks when account leaves OU (default: false).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a7e5d547aca96f57ed635f675cd68e726661269625e35d65f16b2a18f229800)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument retain_stacks_on_account_removal", value=retain_stacks_on_account_removal, expected_type=type_hints["retain_stacks_on_account_removal"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled
        if retain_stacks_on_account_removal is not None:
            self._values["retain_stacks_on_account_removal"] = retain_stacks_on_account_removal

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Enable auto-deployment to new accounts in target OUs (default: true).

        :stability: experimental
        '''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def retain_stacks_on_account_removal(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Retain stacks when account leaves OU (default: false).

        :stability: experimental
        '''
        result = self._values.get("retain_stacks_on_account_removal")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StackSetAutoDeployment(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@jjrawlins/cdk-diff-pr-github-action.StackSetRoleSelection")
class StackSetRoleSelection(enum.Enum):
    '''(experimental) Which roles to include in the StackSet.

    :stability: experimental
    '''

    CHANGESET_ONLY = "CHANGESET_ONLY"
    '''(experimental) Include only the changeset role (CdkChangesetRole).

    :stability: experimental
    '''
    DRIFT_ONLY = "DRIFT_ONLY"
    '''(experimental) Include only the drift role (CdkDriftRole).

    :stability: experimental
    '''
    BOTH = "BOTH"
    '''(experimental) Include both roles (default).

    :stability: experimental
    '''


__all__ = [
    "CdkDiffIamTemplate",
    "CdkDiffIamTemplateGenerator",
    "CdkDiffIamTemplateGeneratorProps",
    "CdkDiffIamTemplateProps",
    "CdkDiffIamTemplateStackSet",
    "CdkDiffIamTemplateStackSetCommandsProps",
    "CdkDiffIamTemplateStackSetGenerator",
    "CdkDiffIamTemplateStackSetGeneratorProps",
    "CdkDiffIamTemplateStackSetProps",
    "CdkDiffStack",
    "CdkDiffStackWorkflow",
    "CdkDiffStackWorkflowProps",
    "CdkDriftDetectionWorkflow",
    "CdkDriftDetectionWorkflowProps",
    "CdkDriftIamTemplate",
    "CdkDriftIamTemplateGenerator",
    "CdkDriftIamTemplateGeneratorProps",
    "CdkDriftIamTemplateProps",
    "GitHubOidcConfig",
    "Stack",
    "StackSetAutoDeployment",
    "StackSetRoleSelection",
]

publication.publish()

def _typecheckingstub__4940eb27556b68e5b3cc9fced9714c6cb9639c00a7faad56fe7933eb3a85acf7(
    template_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__422bd2274e2bd824a3fea09f4f628de6d8efb1b2aa190c8c255dcb8a1520c1f2(
    *,
    role_name: builtins.str,
    create_oidc_role: typing.Optional[builtins.bool] = None,
    github_oidc: typing.Optional[typing.Union[GitHubOidcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
    oidc_role_name: typing.Optional[builtins.str] = None,
    skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c59bae450062c72fde714b03a78e1f33a990657c10db0c149be29c4dc15edf7a(
    *,
    role_name: builtins.str,
    create_oidc_role: typing.Optional[builtins.bool] = None,
    github_oidc: typing.Optional[typing.Union[GitHubOidcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
    oidc_role_name: typing.Optional[builtins.str] = None,
    skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    project: typing.Any,
    output_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7e432c7e84fd22a0f705400e803c2beb9718b0b87dff89e95daebd3f6846488(
    *,
    auto_deployment: typing.Optional[typing.Union[StackSetAutoDeployment, typing.Dict[builtins.str, typing.Any]]] = None,
    delegated_admin: typing.Optional[builtins.bool] = None,
    regions: typing.Optional[typing.Sequence[builtins.str]] = None,
    stack_set_name: typing.Optional[builtins.str] = None,
    target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    template_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db2d89e564fd3108439ec5501be14444604083e26aed44d4cafc0b70cf2e9e13(
    *,
    github_oidc: typing.Union[GitHubOidcConfig, typing.Dict[builtins.str, typing.Any]],
    changeset_role_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    drift_role_name: typing.Optional[builtins.str] = None,
    oidc_role_name: typing.Optional[builtins.str] = None,
    role_selection: typing.Optional[StackSetRoleSelection] = None,
    skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a8159f856c24b15134aa7a1be616f48ad617adb8391234235252ec0b13d6944(
    *,
    github_oidc: typing.Union[GitHubOidcConfig, typing.Dict[builtins.str, typing.Any]],
    changeset_role_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    drift_role_name: typing.Optional[builtins.str] = None,
    oidc_role_name: typing.Optional[builtins.str] = None,
    role_selection: typing.Optional[StackSetRoleSelection] = None,
    skip_oidc_provider_creation: typing.Optional[builtins.bool] = None,
    project: typing.Any,
    auto_deployment: typing.Optional[typing.Union[StackSetAutoDeployment, typing.Dict[builtins.str, typing.Any]]] = None,
    delegated_admin: typing.Optional[builtins.bool] = None,
    output_path: typing.Optional[builtins.str] = None,
    regions: typing.Optional[typing.Sequence[builtins.str]] = None,
    stack_set_name: typing.Optional[builtins.str] = None,
    target_organizational_unit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4269959bff369e12ddef9db120d66bb983e4d98054ca9ac00605855098f3edbf(
    *,
    changeset_role_to_assume_arn: builtins.str,
    changeset_role_to_assume_region: builtins.str,
    stack_name: builtins.str,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b43eba1e69093a4ed7af7be3a8346e69e74a3cd7b329bf4f993c208621006e32(
    *,
    project: typing.Any,
    stacks: typing.Sequence[typing.Union[CdkDiffStack, typing.Dict[builtins.str, typing.Any]]],
    cdk_yarn_command: typing.Optional[builtins.str] = None,
    node_version: typing.Optional[builtins.str] = None,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
    script_output_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22a5b8885f12f60dfdb8eff26ff4500820f6d82da230a604b66d5a8da1a88aaf(
    *,
    project: typing.Any,
    stacks: typing.Sequence[typing.Union[Stack, typing.Dict[builtins.str, typing.Any]]],
    create_issues: typing.Optional[builtins.bool] = None,
    node_version: typing.Optional[builtins.str] = None,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
    post_git_hub_steps: typing.Any = None,
    schedule: typing.Optional[builtins.str] = None,
    script_output_path: typing.Optional[builtins.str] = None,
    workflow_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a09e05fb253535e5442df09b981c8d727e6f7eae7f609c37c54397f23b1454e(
    template_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f41dc20b7ea937dd146b5c0d1dc20b792ffcac5172f7d106df11c36721d8030(
    *,
    oidc_region: builtins.str,
    oidc_role_arn: builtins.str,
    role_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__971a5cf20cf4a5e82cfe24ad53df9002d13454fd436a485bbe7bef575497886e(
    *,
    oidc_region: builtins.str,
    oidc_role_arn: builtins.str,
    role_name: builtins.str,
    project: typing.Any,
    output_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74604e3432febf874eca4106d20d930c6338d5020089922682ee59ac37fbedc4(
    *,
    owner: builtins.str,
    repositories: typing.Sequence[builtins.str],
    additional_claims: typing.Optional[typing.Sequence[builtins.str]] = None,
    branches: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfd47aeadef895a9d2c7d9c3785c0ba4d4eb29e95dab8adceae64a03de471a75(
    *,
    drift_detection_role_to_assume_arn: builtins.str,
    drift_detection_role_to_assume_region: builtins.str,
    stack_name: builtins.str,
    fail_on_drift: typing.Optional[builtins.bool] = None,
    oidc_region: typing.Optional[builtins.str] = None,
    oidc_role_arn: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a7e5d547aca96f57ed635f675cd68e726661269625e35d65f16b2a18f229800(
    *,
    enabled: typing.Optional[builtins.bool] = None,
    retain_stacks_on_account_removal: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass
