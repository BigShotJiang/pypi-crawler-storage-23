# stringmaster

A lightweight Python utility library for string operations and validation.

## Features

- Validate email, phone, and custom patterns
- Check palindrome string or not
- Easy to integrate

## Installation

```bash
pip install stringmaster