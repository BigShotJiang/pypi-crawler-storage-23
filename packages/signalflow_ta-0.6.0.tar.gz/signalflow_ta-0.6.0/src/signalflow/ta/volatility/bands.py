"""Channel and envelope volatility indicators."""

from dataclasses import dataclass
from typing import ClassVar, Literal

import numpy as np
import polars as pl

from signalflow.core import feature
from signalflow.feature.base import Feature
from signalflow.ta._numba_kernels import (
    ema_sma_init as _ema_sma_init,
)
from signalflow.ta._numba_kernels import (
    keltner_kernel as _keltner_kernel,
)
from signalflow.ta._numba_kernels import (
    rolling_max as _rolling_max,
)
from signalflow.ta._numba_kernels import (
    rolling_min as _rolling_min,
)
from signalflow.ta._numba_kernels import (
    sma_nb as _sma_nb,
)


@dataclass
@feature("volatility/bollinger")
class BollingerVol(Feature):
    """Bollinger Bands.

    Volatility bands around a moving average.

    Middle = MA(close, period)
    Upper = Middle + std_dev * StdDev(close, period)
    Lower = Middle - std_dev * StdDev(close, period)

    Outputs:
    - bb_upper: upper band
    - bb_middle: middle band (MA)
    - bb_lower: lower band
    - bb_width: (upper - lower) / middle * 100 (bandwidth)
    - bb_pct: (close - lower) / (upper - lower) (%B)

    Interpretation:
    - Price at upper band: overbought / strong uptrend
    - Price at lower band: oversold / strong downtrend
    - Band squeeze: low volatility, potential breakout
    - Band expansion: high volatility

    Reference: John Bollinger
    https://www.investopedia.com/terms/b/bollingerbands.asp
    """

    period: int = 20
    std_dev: float = 2.0
    ma_type: Literal["sma", "ema"] = "sma"
    normalized: bool = False
    norm_period: int | None = None

    requires: ClassVar[list[str]] = ["close"]
    outputs: ClassVar[list[str]] = [
        "bb_upper_{period}",
        "bb_middle_{period}",
        "bb_lower_{period}",
        "bb_width_{period}",
        "bb_pct_{period}",
    ]

    def compute_pair(self, df: pl.DataFrame) -> pl.DataFrame:
        close = df["close"].to_numpy().astype(np.float64)
        from signalflow.ta._numba_kernels import rolling_std as _rolling_std

        # Rolling std (ddof=1) → correct to ddof=0 for Bollinger
        std_raw = _rolling_std(close, self.period)
        factor = np.sqrt((self.period - 1) / self.period)
        std = std_raw * factor

        middle = _ema_sma_init(close, self.period) if self.ma_type == "ema" else _sma_nb(close, self.period)

        upper = middle + self.std_dev * std
        lower = middle - self.std_dev * std
        width = 100 * (upper - lower) / (middle + 1e-10)
        pct = (close - lower) / (upper - lower + 1e-10)

        # Normalization for unbounded outputs
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window, normalize_zscore

            norm_window = self.norm_period or get_norm_window(self.period)
            upper = normalize_zscore(upper, window=norm_window)
            middle = normalize_zscore(middle, window=norm_window)
            lower = normalize_zscore(lower, window=norm_window)
            width = normalize_zscore(width, window=norm_window)

        output_names = self._get_output_names()
        return df.with_columns(
            [
                pl.Series(name=output_names[0], values=upper),
                pl.Series(name=output_names[1], values=middle),
                pl.Series(name=output_names[2], values=lower),
                pl.Series(name=output_names[3], values=width),
                pl.Series(name=output_names[4], values=pct),
            ]
        )

    def _get_output_names(self) -> list[str]:
        """Generate output column names with normalization suffix."""
        suffix = "_norm" if self.normalized else ""
        return [
            f"bb_upper_{self.period}{suffix}",
            f"bb_middle_{self.period}{suffix}",
            f"bb_lower_{self.period}{suffix}",
            f"bb_width_{self.period}{suffix}",
            f"bb_pct_{self.period}",  # %B is already [0,1], not normalized
        ]

    test_params: ClassVar[list[dict]] = [
        {"period": 20, "std_dev": 2.0, "ma_type": "sma"},
        {"period": 20, "std_dev": 2.0, "ma_type": "sma", "normalized": True},
        {"period": 30, "std_dev": 2.0, "ma_type": "sma"},
        {"period": 60, "std_dev": 2.5, "ma_type": "ema"},
    ]

    @property
    def warmup(self) -> int:
        """Minimum bars needed for stable, reproducible output."""
        base_warmup = self.period * 2
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window

            norm_window = self.norm_period or get_norm_window(self.period)
            return base_warmup + norm_window
        return base_warmup


@dataclass
@feature("volatility/keltner")
class KeltnerVol(Feature):
    """Keltner Channels.

    Volatility envelope based on ATR.

    Basis = EMA(close, period)
    Upper = Basis + multiplier * ATR(period)
    Lower = Basis - multiplier * ATR(period)

    Outputs:
    - kc_upper: upper channel
    - kc_basis: middle line (EMA)
    - kc_lower: lower channel

    Compared to Bollinger:
    - Uses ATR instead of standard deviation
    - Generally smoother bands
    - Less reactive to sudden price spikes

    Reference: Chester Keltner (original), Linda Raschke (modern version)
    https://school.stockcharts.com/doku.php?id=technical_indicators:keltner_channels
    """

    period: int = 20
    multiplier: float = 2.0
    ma_type: Literal["ema", "sma"] = "ema"
    use_true_range: bool = True
    normalized: bool = False
    norm_period: int | None = None

    requires: ClassVar[list[str]] = ["high", "low", "close"]
    outputs: ClassVar[list[str]] = ["kc_upper_{period}", "kc_basis_{period}", "kc_lower_{period}"]

    def compute_pair(self, df: pl.DataFrame) -> pl.DataFrame:
        high = df["high"].to_numpy()
        low = df["low"].to_numpy()
        close = df["close"].to_numpy()
        _n = len(close)

        if self.use_true_range:
            prev_close = np.roll(close, 1)
            prev_close[0] = close[0]
            range_vals = np.maximum(
                high - low,
                np.maximum(np.abs(high - prev_close), np.abs(low - prev_close)),
            )
            range_vals[0] = high[0] - low[0]
        else:
            range_vals = high - low

        close_f = close.astype(np.float64)
        range_f = range_vals.astype(np.float64)

        if self.ma_type == "ema":
            upper, basis, lower = _keltner_kernel(close_f, range_f, self.period, self.multiplier)
        else:
            basis = _sma_nb(close_f, self.period)
            atr = _sma_nb(range_f, self.period)
            upper = basis + self.multiplier * atr
            lower = basis - self.multiplier * atr

        # Normalization for unbounded outputs
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window, normalize_zscore

            norm_window = self.norm_period or get_norm_window(self.period)
            upper = normalize_zscore(upper, window=norm_window)
            basis = normalize_zscore(basis, window=norm_window)
            lower = normalize_zscore(lower, window=norm_window)

        output_names = self._get_output_names()
        return df.with_columns(
            [
                pl.Series(name=output_names[0], values=upper),
                pl.Series(name=output_names[1], values=basis),
                pl.Series(name=output_names[2], values=lower),
            ]
        )

    def _get_output_names(self) -> list[str]:
        """Generate output column names with normalization suffix."""
        suffix = "_norm" if self.normalized else ""
        return [
            f"kc_upper_{self.period}{suffix}",
            f"kc_basis_{self.period}{suffix}",
            f"kc_lower_{self.period}{suffix}",
        ]

    test_params: ClassVar[list[dict]] = [
        {"period": 20, "multiplier": 2.0, "ma_type": "ema", "use_true_range": True},
        {
            "period": 20,
            "multiplier": 2.0,
            "ma_type": "ema",
            "use_true_range": True,
            "normalized": True,
        },
        {"period": 30, "multiplier": 1.5, "ma_type": "ema", "use_true_range": True},
        {"period": 60, "multiplier": 2.0, "ma_type": "sma", "use_true_range": False},
    ]

    @property
    def warmup(self) -> int:
        """Minimum bars needed for stable, reproducible output."""
        base_warmup = self.period * 5
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window

            norm_window = self.norm_period or get_norm_window(self.period)
            return base_warmup + norm_window
        return base_warmup


@dataclass
@feature("volatility/donchian")
class DonchianVol(Feature):
    """Donchian Channels.

    Price channel based on highest high and lowest low.

    Upper = Highest High over period
    Lower = Lowest Low over period
    Middle = (Upper + Lower) / 2

    Outputs:
    - dc_upper: upper channel (resistance)
    - dc_middle: midline
    - dc_lower: lower channel (support)

    Classic breakout indicator:
    - Price breaks above upper: bullish breakout
    - Price breaks below lower: bearish breakout
    - Width shows volatility

    Reference: Richard Donchian (Turtle Trading)
    https://school.stockcharts.com/doku.php?id=technical_indicators:donchian_channels
    """

    period: int = 20
    normalized: bool = False
    norm_period: int | None = None

    requires: ClassVar[list[str]] = ["high", "low"]
    outputs: ClassVar[list[str]] = ["dc_upper_{period}", "dc_middle_{period}", "dc_lower_{period}"]

    def compute_pair(self, df: pl.DataFrame) -> pl.DataFrame:
        high = df["high"].to_numpy().astype(np.float64)
        low = df["low"].to_numpy().astype(np.float64)

        upper = _rolling_max(high, self.period)
        lower = _rolling_min(low, self.period)
        middle = (upper + lower) / 2

        # Normalization for unbounded outputs
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window, normalize_zscore

            norm_window = self.norm_period or get_norm_window(self.period)
            upper = normalize_zscore(upper, window=norm_window)
            middle = normalize_zscore(middle, window=norm_window)
            lower = normalize_zscore(lower, window=norm_window)

        output_names = self._get_output_names()
        return df.with_columns(
            [
                pl.Series(name=output_names[0], values=upper),
                pl.Series(name=output_names[1], values=middle),
                pl.Series(name=output_names[2], values=lower),
            ]
        )

    def _get_output_names(self) -> list[str]:
        """Generate output column names with normalization suffix."""
        suffix = "_norm" if self.normalized else ""
        return [
            f"dc_upper_{self.period}{suffix}",
            f"dc_middle_{self.period}{suffix}",
            f"dc_lower_{self.period}{suffix}",
        ]

    test_params: ClassVar[list[dict]] = [
        {"period": 20},
        {"period": 20, "normalized": True},
        {"period": 55},
        {"period": 120},
    ]

    @property
    def warmup(self) -> int:
        """Minimum bars needed for stable, reproducible output."""
        base_warmup = self.period * 5
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window

            norm_window = self.norm_period or get_norm_window(self.period)
            return base_warmup + norm_window
        return base_warmup


@dataclass
@feature("volatility/accbands")
class AccBandsVol(Feature):
    """Acceleration Bands.

    Envelope bands that widen with volatility.

    HL_Ratio = c * (High - Low) / (High + Low)
    Upper = MA(High * (1 + HL_Ratio), period)
    Lower = MA(Low * (1 - HL_Ratio), period)
    Middle = MA(Close, period)

    Outputs:
    - accb_upper: upper band
    - accb_middle: middle band
    - accb_lower: lower band

    Breakout indicator:
    - Close above upper band: strong uptrend
    - Close below lower band: strong downtrend
    - Inside bands: consolidation

    Reference: Price Headley
    https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/acceleration-bands-abands/
    """

    period: int = 20
    factor: float = 4.0
    ma_type: Literal["sma", "ema"] = "sma"
    normalized: bool = False
    norm_period: int | None = None

    requires: ClassVar[list[str]] = ["high", "low", "close"]
    outputs: ClassVar[list[str]] = ["accb_upper_{period}", "accb_middle_{period}", "accb_lower_{period}"]

    def compute_pair(self, df: pl.DataFrame) -> pl.DataFrame:
        high = df["high"].to_numpy()
        low = df["low"].to_numpy()
        close = df["close"].to_numpy()
        n = len(close)

        hl_range = high - low
        hl_sum = high + low
        hl_ratio = self.factor * hl_range / (hl_sum + 1e-10)

        upper_raw = high * (1 + hl_ratio)
        lower_raw = low * (1 - hl_ratio)

        upper = np.full(n, np.nan)
        middle = np.full(n, np.nan)
        lower = np.full(n, np.nan)

        if self.ma_type == "ema":
            alpha = 2 / (self.period + 1)
            upper[0] = upper_raw[0]
            middle[0] = close[0]
            lower[0] = lower_raw[0]
            for i in range(1, n):
                upper[i] = alpha * upper_raw[i] + (1 - alpha) * upper[i - 1]
                middle[i] = alpha * close[i] + (1 - alpha) * middle[i - 1]
                lower[i] = alpha * lower_raw[i] + (1 - alpha) * lower[i - 1]
        else:
            for i in range(self.period - 1, n):
                upper[i] = np.mean(upper_raw[i - self.period + 1 : i + 1])
                middle[i] = np.mean(close[i - self.period + 1 : i + 1])
                lower[i] = np.mean(lower_raw[i - self.period + 1 : i + 1])

        # Normalization for unbounded outputs
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window, normalize_zscore

            norm_window = self.norm_period or get_norm_window(self.period)
            upper = normalize_zscore(upper, window=norm_window)
            middle = normalize_zscore(middle, window=norm_window)
            lower = normalize_zscore(lower, window=norm_window)

        output_names = self._get_output_names()
        return df.with_columns(
            [
                pl.Series(name=output_names[0], values=upper),
                pl.Series(name=output_names[1], values=middle),
                pl.Series(name=output_names[2], values=lower),
            ]
        )

    def _get_output_names(self) -> list[str]:
        """Generate output column names with normalization suffix."""
        suffix = "_norm" if self.normalized else ""
        return [
            f"accb_upper_{self.period}{suffix}",
            f"accb_middle_{self.period}{suffix}",
            f"accb_lower_{self.period}{suffix}",
        ]

    test_params: ClassVar[list[dict]] = [
        {"period": 20, "factor": 4.0, "ma_type": "sma"},
        {"period": 30, "factor": 3.0, "ma_type": "sma"},
        {"period": 60, "factor": 4.0, "ma_type": "ema"},
        {"period": 20, "factor": 4.0, "ma_type": "sma", "normalized": True},
    ]

    @property
    def warmup(self) -> int:
        """Minimum bars needed for stable, reproducible output."""
        base_warmup = self.period * 5
        if self.normalized:
            from signalflow.ta._normalization import get_norm_window

            norm_window = self.norm_period or get_norm_window(self.period)
            return base_warmup + norm_window
        return base_warmup
