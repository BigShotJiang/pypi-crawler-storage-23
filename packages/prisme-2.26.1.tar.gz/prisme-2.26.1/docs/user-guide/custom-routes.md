# Custom Frontend Routes

Add custom pages and routes to your Prism-generated frontend application.

## Overview

Prism provides two ways to add custom routes to your frontend:

1. **Declarative Configuration** (`customRoutes.tsx`) — Define routes in a configuration array
2. **Programmatic Hook API** (`useRouteConfig`) — Register routes dynamically from components

Both approaches integrate seamlessly with the generated router and navigation system.

## Declarative Routes

The simplest way to add custom routes is through the `customRoutes.tsx` file.

### Basic Example

```tsx title="src/routes/customRoutes.tsx"
import { type ReactElement } from 'react';
import AnalyticsPage from '../pages/AnalyticsPage';
import ReportsPage from '../pages/ReportsPage';

export const customRoutes: CustomRouteConfig[] = [
  {
    path: '/analytics',
    element: <AnalyticsPage />,
    nav: {
      label: 'Analytics',
      order: 50,
    },
  },
  {
    path: '/reports',
    element: <ReportsPage />,
    nav: {
      label: 'Reports',
      order: 60,
    },
  },
];
```

### Route Configuration

Each route accepts the following properties:

| Property | Type | Description |
|----------|------|-------------|
| `path` | `string` | URL path (e.g., `/analytics`) |
| `element` | `ReactElement` | React component to render |
| `nav` | `object` | Navigation config (omit to hide from sidebar) |
| `nav.label` | `string` | Display label in sidebar |
| `nav.icon` | `ReactElement` | Optional SVG icon |
| `nav.order` | `number` | Sort order (lower = higher, default: 100) |
| `requireAuth` | `boolean` | Require authentication (default: inherits from app) |
| `roles` | `string[]` | Required roles for access |

### Examples

#### Route Without Sidebar Link

```tsx
{
  path: '/onboarding',
  element: <OnboardingPage />,
  // No 'nav' property — accessible but hidden from navigation
}
```

#### Route With Custom Icon

```tsx
{
  path: '/analytics',
  element: <AnalyticsPage />,
  nav: {
    label: 'Analytics',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
    order: 10,  // Appears near top of sidebar
  },
}
```

#### Role-Protected Route

```tsx
{
  path: '/admin-dashboard',
  element: <AdminDashboard />,
  nav: { label: 'Admin Dashboard', order: 100 },
  roles: ['admin'],  // Only admins can access
}
```

## Programmatic Route Registration

For dynamic or conditional routes, use the `useRouteConfig` hook.

### Setup

Wrap your app with `RouteConfigProvider` (this is done automatically in generated projects):

```tsx title="src/App.tsx"
import { RouteConfigProvider } from './hooks/useRouteConfig';

export default function App() {
  return (
    <RouteConfigProvider>
      <RouterProvider router={router} />
    </RouteConfigProvider>
  );
}
```

### Registering Routes

```tsx title="src/components/FeatureRegistry.tsx"
import { useEffect } from 'react';
import { useRouteConfig } from '../hooks/useRouteConfig';
import FeaturePage from '../pages/FeaturePage';

export function FeatureRegistry() {
  const { registerRoute } = useRouteConfig();

  useEffect(() => {
    // Register route on component mount
    registerRoute({
      path: '/special-feature',
      element: <FeaturePage />,
      nav: {
        label: 'Special Feature',
        order: 75,
      },
    });
  }, [registerRoute]);

  return null;  // This component doesn't render anything
}
```

### Conditional Routes

Register routes based on user permissions or feature flags:

```tsx
import { useAuth } from '../contexts/AuthContext';
import { useRouteConfig } from '../hooks/useRouteConfig';

export function ConditionalRoutes() {
  const { user, hasRole } = useAuth();
  const { registerRoute } = useRouteConfig();

  useEffect(() => {
    if (hasRole('premium')) {
      registerRoute({
        path: '/premium-features',
        element: <PremiumPage />,
        nav: { label: 'Premium', order: 20 },
      });
    }

    if (hasRole('admin')) {
      registerRoute({
        path: '/audit-log',
        element: <AuditLogPage />,
        nav: { label: 'Audit Log', order: 90 },
      });
    }
  }, [user, hasRole, registerRoute]);

  return null;
}
```

## Protected Regions

For one-off custom routes that don't belong in `customRoutes.tsx`, use protected regions:

```tsx title="src/router.tsx"
export const router = createBrowserRouter([
  // ... generated routes ...
  {
    element: <Layout />,
    children: [
      // ... model routes ...
      ...customRoutes.map((r) => ({ path: r.path, element: r.element })),
      // PRISM:PROTECTED:START - Custom Routes
      { path: '/quick-action', element: <QuickActionPage /> },
      // PRISM:PROTECTED:END
      { path: '*', element: <NotFoundPage /> },
    ],
  },
]);
```

Protected regions preserve your code during regeneration.

## Navigation Order

Control sidebar ordering with the `order` property:

- **1-20**: High-priority links (dashboards, key features)
- **21-50**: Primary navigation (most model routes default here)
- **51-80**: Secondary features
- **81-100**: Utility pages (settings, help, etc.)

Model-generated routes appear in the order they're defined in your spec. Custom routes are inserted based on their `order` value.

## Best Practices

### File Organization

Keep custom pages organized:

```
src/pages/
├── custom/           # Your custom pages
│   ├── AnalyticsPage.tsx
│   ├── ReportsPage.tsx
│   └── OnboardingPage.tsx
├── DashboardPage.tsx # Generated
└── customers/        # Generated model pages
```

### Route Naming

Use kebab-case for URLs:

```tsx
// Good
{ path: '/user-analytics', ... }
{ path: '/reports/monthly', ... }

// Avoid
{ path: '/UserAnalytics', ... }
{ path: '/reports_monthly', ... }
```

### Component Imports

Import custom pages at the top of `customRoutes.tsx`:

```tsx
// All custom page imports at top
import AnalyticsPage from '../pages/custom/AnalyticsPage';
import ReportsPage from '../pages/custom/ReportsPage';
import OnboardingPage from '../pages/custom/OnboardingPage';

export const customRoutes: CustomRouteConfig[] = [
  // Route definitions
];
```

### Type Safety

The `CustomRouteConfig` interface ensures type-safe route definitions:

```tsx
import type { CustomRouteConfig } from './routes/customRoutes';

// TypeScript will catch missing required fields
const route: CustomRouteConfig = {
  path: '/analytics',
  element: <AnalyticsPage />,
  // TypeScript error if 'element' is missing
};
```

## Examples

### Analytics Dashboard

```tsx title="src/pages/custom/AnalyticsPage.tsx"
export default function AnalyticsPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Analytics</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Your analytics widgets */}
      </div>
    </div>
  );
}
```

```tsx title="src/routes/customRoutes.tsx"
import AnalyticsPage from '../pages/custom/AnalyticsPage';

export const customRoutes: CustomRouteConfig[] = [
  {
    path: '/analytics',
    element: <AnalyticsPage />,
    nav: {
      label: 'Analytics',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      ),
      order: 15,
    },
  },
];
```

### Multi-Step Form

```tsx title="src/pages/custom/OnboardingPage.tsx"
export default function OnboardingPage() {
  const [step, setStep] = useState(1);

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Welcome! Let's get you set up.</h1>
      {step === 1 && <StepOne onNext={() => setStep(2)} />}
      {step === 2 && <StepTwo onNext={() => setStep(3)} />}
      {step === 3 && <StepThree />}
    </div>
  );
}
```

```tsx title="src/routes/customRoutes.tsx"
export const customRoutes: CustomRouteConfig[] = [
  {
    path: '/onboarding',
    element: <OnboardingPage />,
    // No 'nav' — hidden from sidebar
  },
];
```

## Troubleshooting

### Route Not Appearing

1. Check that the route is exported in `customRoutes`
2. Verify the component import path
3. Check console for React errors

### Nav Link Not Showing

1. Ensure `nav` property is defined
2. Check that `nav.label` is not empty
3. Verify `order` is a reasonable number

### Protected Route Not Working

For auth-protected routes, ensure `requireAuth: true` or `roles: [...]` is set:

```tsx
{
  path: '/premium',
  element: <PremiumPage />,
  nav: { label: 'Premium', order: 20 },
  requireAuth: true,  // Add this
}
```

## Next Steps

- [Extensibility](extensibility.md) — Learn how to extend services, components, and endpoints
- [Spec Guide](spec-guide.md) — Understand the full StackSpec configuration
- [CLI Reference](cli-reference.md) — Explore all Prism CLI commands
