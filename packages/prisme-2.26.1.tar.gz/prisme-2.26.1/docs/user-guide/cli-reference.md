# CLI Reference

Complete reference for all Prisme CLI commands.

## Global Options

```bash
prisme --version  # Show version
prisme --help     # Show help
```

## Project Commands

### `prisme create`

Create a new Prisme project.

```bash
prisme create <project_name> [options]
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `project_name` | Name of the project (kebab-case recommended) |

**Options:**

| Option | Description |
|--------|-------------|
| `--template` | Project template: `full` (default), `minimal`, `api-only` |
| `--docker` | Initialize with Docker support |
| `--spec <file>` | Copy existing spec file into project |

**Examples:**

```bash
# Full-stack project
prisme create my-app

# Backend-only minimal project
prisme create my-api --template minimal

# With Docker support
prisme create my-app --docker

# With existing spec file
prisme create my-app --spec ../specs/models.py
```

---

### `prisme generate`

Generate code from your specification.

```bash
prisme generate [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `--dry-run` | Preview changes without writing files |
| `--only <layer>` | Generate specific layer only |
| `--spec <file>` | Use specific spec file (default: auto-detect) |

**Layers for `--only`:**

- `models` - SQLAlchemy models
- `schemas` - Pydantic schemas
- `services` - Service layer
- `rest` - REST API endpoints
- `graphql` - GraphQL types and resolvers
- `mcp` - MCP tools
- `frontend` - React components and hooks
- `tests` - Test files

**Examples:**

```bash
# Generate everything
prisme generate

# Preview changes
prisme generate --dry-run

# Generate only GraphQL
prisme generate --only graphql

# Use specific spec file
prisme generate --spec specs/v2/models.py
```

---

### `prisme validate`

Validate a specification file.

```bash
prisme validate [spec_path]
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `spec_path` | Path to spec file (optional, auto-detects if omitted) |

**Examples:**

```bash
# Validate default spec
prisme validate

# Validate specific file
prisme validate specs/models.py
```

---

### `prisme install`

Install project dependencies.

```bash
prisme install [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `--backend-only` | Install only Python dependencies |
| `--frontend-only` | Install only Node.js dependencies |

**Examples:**

```bash
# Install all dependencies
prisme install

# Backend only
prisme install --backend-only

# Frontend only
prisme install --frontend-only
```

---

### `prisme dev`

Start development servers.

```bash
prisme dev [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `--backend-only` | Start only backend server |
| `--frontend-only` | Start only frontend server |
| `--docker` | Use Docker development environment |

**Examples:**

```bash
# Start all servers
prisme dev

# Backend only
prisme dev --backend-only

# With Docker
prisme dev --docker
```

---

### `prisme test`

Run tests.

```bash
prisme test [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `--backend-only` | Run only backend tests (pytest) |
| `--frontend-only` | Run only frontend tests (vitest) |
| `--coverage` | Generate coverage report |

**Examples:**

```bash
# Run all tests
prisme test

# With coverage
prisme test --coverage

# Backend only
prisme test --backend-only
```

---

## Database Commands

### `prisme db init`

Initialize Alembic for database migrations.

```bash
prisme db init
```

Creates the `alembic/` directory and configuration.

---

### `prisme db migrate`

Create and apply database migrations.

```bash
prisme db migrate [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `-m <message>` | Migration message (descriptive name) |

**Examples:**

```bash
# Auto-generate and apply migration
prisme db migrate

# With descriptive message
prisme db migrate -m "add customer status field"
```

---

### `prisme db reset`

Reset the database (drops all tables and recreates).

```bash
prisme db reset
```

!!! warning
    This deletes all data in the database. Use with caution!

---

### `prisme db seed`

Seed the database with test data.

```bash
prisme db seed
```

---

## Docker Commands

### `prisme docker init`

Initialize Docker configuration for the project.

```bash
prisme docker init
```

Creates:

- `docker-compose.dev.yml`
- `Dockerfile.backend`
- `Dockerfile.frontend`
- `.dockerignore`

---

### `prisme docker logs`

View container logs.

```bash
prisme docker logs [options] [service]
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `service` | Service name: `backend`, `frontend`, `db`, `redis` |

**Options:**

| Option | Description |
|--------|-------------|
| `-f` | Follow log output |

**Examples:**

```bash
# All logs
prisme docker logs

# Follow backend logs
prisme docker logs -f backend
```

---

### `prisme docker shell`

Open a shell in a container.

```bash
prisme docker shell <service>
```

**Examples:**

```bash
prisme docker shell backend
prisme docker shell db
```

---

### `prisme docker down`

Stop all Docker services.

```bash
prisme docker down
```

---

### `prisme docker reset-db`

Reset the Docker database.

```bash
prisme docker reset-db
```

---

### `prisme docker backup-db`

Backup the database to a SQL file.

```bash
prisme docker backup-db <filename>
```

**Example:**

```bash
prisme docker backup-db backup-2024-01-15.sql
```

---

### `prisme docker restore-db`

Restore the database from a SQL file.

```bash
prisme docker restore-db <filename>
```

**Example:**

```bash
prisme docker restore-db backup-2024-01-15.sql
```

---

### `prisme docker init-prod`

Initialize production Docker configuration.

```bash
prisme docker init-prod
```

---

### `prisme docker build-prod`

Build production Docker images.

```bash
prisme docker build-prod
```

---

## Project Management Commands

### `prisme projects list`

List all running Prisme projects.

```bash
prisme projects list
```

---

### `prisme projects down-all`

Stop all running Prisme projects.

```bash
prisme projects down-all
```

**Options:**

| Option | Description |
|--------|-------------|
| `--volumes`, `-v` | Also remove volumes when stopping |
| `--quiet`, `-q` | Suppress detailed output |

This command:
1. Uses `docker compose down --remove-orphans` for each project
2. Falls back to individual container stops if compose fails
3. Finds and stops orphaned containers not on the proxy network

---

## Review Commands

Commands for reviewing generated changes.

### `prisme review list`

List files pending review.

```bash
prisme review list [options]
```

**Options:**

| Option | Description |
|--------|-------------|
| `--unreviewed` | Show only unreviewed files |

---

### `prisme review summary`

Show summary of changes.

```bash
prisme review summary
```

---

### `prisme review mark-reviewed`

Mark a file as reviewed.

```bash
prisme review mark-reviewed <file>
```

---

### `prisme review mark-all-reviewed`

Mark all files as reviewed.

```bash
prisme review mark-all-reviewed
```

---

### `prisme review diff`

Show diff for a specific overridden file.

```bash
prisme review diff <file>
```

---

### `prisme review show`

Show full override details for a file.

```bash
prisme review show <file>
```

---

### `prisme review clear`

Clear reviewed overrides from the log.

```bash
prisme review clear
```

---

### `prisme review restore`

Restore generated code, discarding your override.

```bash
prisme review restore <file>
```

**Options:**

| Option | Description |
|--------|-------------|
| `--yes`, `-y` | Skip confirmation |

This command replaces your customized code with the originally generated code, effectively rejecting your override. The override is removed from the log after restoration.

---

## CI Commands

### `prisme ci init`

Initialize CI/CD configuration.

```bash
prisme ci init
```

---

### `prisme ci status`

Check CI status.

```bash
prisme ci status
```

---

### `prisme ci validate`

Validate CI configuration.

```bash
prisme ci validate
```

---

### `prisme ci add-docker`

Add Docker support to CI workflow.

```bash
prisme ci add-docker
```

---

## Environment Variables

Prisme respects these environment variables:

| Variable | Description |
|----------|-------------|
| `PRISM_SPEC_FILE` | Default spec file path |
| `PRISM_BACKEND_PATH` | Override backend output path |
| `PRISM_FRONTEND_PATH` | Override frontend output path |
| `DATABASE_URL` | Database connection string |
| `DEBUG` | Enable debug mode |

---

## Exit Codes

| Code | Description |
|------|-------------|
| `0` | Success |
| `1` | General error |
| `2` | Invalid arguments |
| `3` | Spec validation error |
| `4` | Generation error |
| `5` | Test failure |

---

## See Also

- [Quick Start](../getting-started/quickstart.md)
- [Model Specification Guide](spec-guide.md)
- [Docker Development](docker-development.md)
