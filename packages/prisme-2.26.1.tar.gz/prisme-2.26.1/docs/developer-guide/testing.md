# Testing Guide

Guidelines for running and writing tests for Prisme.

## Running Tests

### Basic Commands

```bash
# Run all tests (excludes slow, e2e, docker by default)
uv run pytest

# With coverage report
uv run pytest --cov

# With HTML coverage report
uv run pytest --cov --cov-report=html
open htmlcov/index.html

# Stop on first failure
uv run pytest -x

# Verbose output
uv run pytest -v

# Very verbose (see print statements)
uv run pytest -vv -s
```

### Running Specific Tests

```bash
# Specific file
uv run pytest tests/spec/test_models.py

# Specific test class
uv run pytest tests/spec/test_models.py::TestModelSpec

# Specific test function
uv run pytest tests/spec/test_models.py::TestModelSpec::test_valid_model

# Pattern matching
uv run pytest -k "model"
uv run pytest -k "model and not slow"
```

### Test Markers

Prisme defines three custom markers. All are **excluded from default runs** (configured in `pyproject.toml`).

```bash
# Run slow tests
uv run pytest -m slow

# Run end-to-end tests
uv run pytest -m e2e

# Run Docker tests (requires Docker)
uv run pytest -m docker

# Run all tests including slow and e2e
uv run pytest -m ""
```

| Marker | Purpose | Requires |
|--------|---------|----------|
| `slow` | Tests that take longer to run | Nothing extra |
| `e2e` | End-to-end tests (full generation + validation) | Nothing extra |
| `docker` | Tests requiring Docker | Docker running |

### Test Configuration

Key settings from `pyproject.toml`:

- **Test paths**: `tests/`
- **Async mode**: `auto` (no need for `@pytest.mark.asyncio` on every test)
- **Timeout**: 120 seconds per test
- **Default filter**: `-m "not slow and not e2e"` (excludes slow and e2e)
- **Strict markers**: Unknown markers cause errors

## Test Organization

### Directory Structure

```
tests/
├── conftest.py              # Shared fixtures (sample_field_spec, sample_model_spec, sample_stack_spec)
├── spec/                    # Specification model tests
│   ├── test_fields.py       # FieldSpec, FieldType tests
│   ├── test_models.py       # ModelSpec tests
│   ├── test_exposure.py     # Exposure config tests
│   └── ...
├── generators/              # Generator tests
│   ├── backend/             # Backend generator tests
│   │   ├── test_models_generator.py
│   │   ├── test_services_generator.py
│   │   ├── test_rest_generator.py
│   │   └── ...
│   ├── frontend/            # Frontend generator tests
│   │   ├── test_types_generator.py
│   │   ├── test_components_generator.py
│   │   └── ...
│   └── infrastructure/      # Infrastructure generator tests
├── cli/                     # CLI command tests
├── e2e/                     # End-to-end tests (full pipeline)
├── docker/                  # Docker integration tests
├── deploy/                  # Deployment tests
├── devcontainer/            # Dev container tests
├── tracking/                # Manifest & override tracking tests
├── ci/                      # CI/CD generation tests
├── config/                  # Configuration tests
├── dx/                      # Developer experience tests
├── migration/               # Migration tests
└── planning/                # Planning module tests
```

### Naming Conventions

- Test files: `test_<module>.py`
- Test classes: `Test<Feature>`
- Test functions: `test_<behavior>`

## Writing Tests

### Basic Test Structure

```python
import pytest
from prisme.spec import ModelSpec, FieldSpec, FieldType

class TestModelSpec:
    """Tests for ModelSpec."""

    def test_valid_model(self):
        """Test creating a valid model specification."""
        model = ModelSpec(
            name="Customer",
            fields=[
                FieldSpec(name="email", type=FieldType.STRING),
            ],
        )
        assert model.name == "Customer"
        assert len(model.fields) == 1

    def test_model_requires_name(self):
        """Test that model requires a name."""
        with pytest.raises(ValueError):
            ModelSpec(name="", fields=[])
```

### Async Tests

The project uses `asyncio_mode = "auto"`, so async test functions are automatically detected without needing `@pytest.mark.asyncio` on every test:

```python
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

async def test_service_creates_record(db_session: AsyncSession):
    """Test service creates a database record."""
    service = CustomerService(db_session)

    customer = await service.create({
        "name": "Test",
        "email": "test@example.com",
    })

    assert customer.id is not None
    assert customer.name == "Test"
```

### Parametrized Tests

```python
import pytest
from prisme.spec import FieldType

@pytest.mark.parametrize("field_type,expected_python", [
    (FieldType.STRING, "str"),
    (FieldType.INTEGER, "int"),
    (FieldType.BOOLEAN, "bool"),
    (FieldType.DATETIME, "datetime"),
])
def test_field_type_mapping(field_type, expected_python):
    """Test field types map to correct Python types."""
    assert field_type.python_type == expected_python
```

### Using Fixtures

The shared fixtures in `tests/conftest.py` provide pre-built spec objects:

```python
# tests/conftest.py provides:
# - sample_field_spec: A basic FieldSpec
# - sample_model_spec: A basic ModelSpec with fields
# - sample_stack_spec: A complete StackSpec with models

@pytest.fixture
def simple_spec():
    """Create a simple test specification."""
    return StackSpec(
        name="test-app",
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True),
                ],
            ),
        ],
    )

@pytest.fixture
def generator_context(simple_spec, tmp_path):
    """Create a generator context for testing."""
    from prisme.generators import GeneratorContext

    return GeneratorContext(
        spec=simple_spec,
        backend_path=tmp_path / "backend",
        frontend_path=tmp_path / "frontend",
        package_name="test_app",
    )
```

Using fixtures in tests:

```python
def test_generates_models(generator_context):
    """Test that models are generated correctly."""
    generator = ModelsGenerator(generator_context)
    result = generator.generate()

    assert len(result.files) > 0
    assert "class User" in result.files[0].content
```

## Testing Generators

### Template Output Tests

```python
def test_model_template_output(generator_context):
    """Test model template generates correct code."""
    generator = ModelsGenerator(generator_context)
    result = generator.generate()

    model_file = result.files[0]

    # Check structure
    assert "from sqlalchemy" in model_file.content
    assert "class User(Base):" in model_file.content
    assert "__tablename__" in model_file.content

    # Check fields
    assert "email = Column(" in model_file.content
```

### Testing File Strategies

When testing generators, verify the correct `FileStrategy` is assigned:

```python
from prisme.generators.base import FileStrategy

def test_schema_uses_always_overwrite(generator_context):
    """Test that schema files use ALWAYS_OVERWRITE strategy."""
    generator = SchemasGenerator(generator_context)
    result = generator.generate()

    for file in result.files:
        if "schemas/" in str(file.path):
            assert file.strategy == FileStrategy.ALWAYS_OVERWRITE

def test_service_extension_uses_generate_once(generator_context):
    """Test user service files use GENERATE_ONCE strategy."""
    generator = ServicesGenerator(generator_context)
    result = generator.generate()

    for file in result.files:
        if "_generated" not in str(file.path) and "service" in str(file.path):
            assert file.strategy == FileStrategy.GENERATE_ONCE
```

## Testing CLI Commands

```python
from click.testing import CliRunner
from prisme.cli import main

def test_create_command():
    """Test prisme create command."""
    runner = CliRunner()

    with runner.isolated_filesystem():
        result = runner.invoke(main, ["create", "test-project"])

        assert result.exit_code == 0
        assert "Created project" in result.output
        assert Path("test-project").exists()

def test_generate_dry_run():
    """Test prisme generate --dry-run."""
    runner = CliRunner()

    with runner.isolated_filesystem():
        # Setup project
        runner.invoke(main, ["create", "test-project"])

        # Run generate with dry-run
        result = runner.invoke(main, ["generate", "--dry-run"], cwd="test-project")

        assert result.exit_code == 0
        assert "Would generate" in result.output
```

## Test Coverage

### Viewing Coverage

```bash
# Terminal report
uv run pytest --cov --cov-report=term-missing

# HTML report
uv run pytest --cov --cov-report=html
open htmlcov/index.html

# XML for CI
uv run pytest --cov --cov-report=xml
```

### Coverage Configuration

From `pyproject.toml`:

```toml
[tool.coverage.run]
source = ["src/prisme"]
branch = true

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "if TYPE_CHECKING:",
    "raise NotImplementedError",
]
```

## Best Practices

### Do

- Write tests for all new functionality
- Use descriptive test names that explain the expected behavior
- Test edge cases and error conditions
- Keep tests focused and independent
- Use fixtures for shared setup
- Mark slow tests with `@pytest.mark.slow`
- Mark e2e tests with `@pytest.mark.e2e`
- Mark Docker-dependent tests with `@pytest.mark.docker`
- Use `tmp_path` fixture for tests that write files

### Don't

- Test implementation details (test behavior instead)
- Use `sleep()` in tests
- Leave print statements in test code
- Skip tests without a reason
- Create tests that depend on execution order

## CI Integration

Tests run automatically on every PR:

1. **Lint Job**: ruff check, ruff format --check, mypy
2. **Test Job**: pytest with coverage
3. **Coverage Upload**: Results sent to Codecov

All checks must pass for a PR to be merged. The pre-push git hook mirrors this pipeline locally.
