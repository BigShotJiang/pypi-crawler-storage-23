# Quick Start

Get a full-stack application running in under 5 minutes.

## TL;DR

```bash
prisme create my-app && cd my-app && prisme install && prisme generate && prisme test && prisme dev
```

## Step-by-Step

### 1. Create a New Project

```bash
prisme create my-app
cd my-app
```

This scaffolds a full-stack project with:

```
my-app/
├── packages/
│   ├── backend/          # Python/FastAPI backend
│   │   ├── src/my_app/   # Your Python package
│   │   ├── pyproject.toml
│   │   └── tests/
│   └── frontend/         # React + TypeScript frontend
│       ├── src/
│       ├── package.json
│       └── vite.config.ts
├── specs/
│   └── models.py         # Your model definitions
└── prisme.toml           # Prisme configuration
```

### 2. Install Dependencies

```bash
prisme install
```

This installs both backend (Python) and frontend (Node.js) dependencies.

### 3. Review the Example Spec

Open `specs/models.py` to see the example model:

```python title="specs/models.py"
from prisme import (
    StackSpec, ModelSpec, FieldSpec, FieldType,
)

spec = StackSpec(
    name="my-app",
    version="1.0.0",
    models=[
        ModelSpec(
            name="User",
            fields=[
                FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                FieldSpec(name="name", type=FieldType.STRING, required=True),
            ],
        ),
    ],
)
```

### 4. Generate Code

```bash
prisme generate
```

This generates:

- **Backend**: Models, schemas, services, REST/GraphQL/MCP APIs
- **Frontend**: TypeScript types, React components, hooks
- **Tests**: Unit and integration tests

### 5. Run Tests

```bash
prisme test
```

Verifies everything is working correctly.

### 6. Start Development

```bash
prisme dev
```

This starts:

- **Backend**: FastAPI server at `http://localhost:8000`
- **Frontend**: Vite dev server at `http://localhost:5173`

Open your browser to:

- **App**: [http://localhost:5173](http://localhost:5173)
- **API Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **GraphQL**: [http://localhost:8000/graphql](http://localhost:8000/graphql)

## What's Next?

### Modify Your Models

Edit `specs/models.py` to add or modify models, then regenerate:

```bash
prisme generate
```

Your customizations in user files are preserved!

### Add More Models

```python
ModelSpec(
    name="Post",
    fields=[
        FieldSpec(name="title", type=FieldType.STRING, required=True),
        FieldSpec(name="content", type=FieldType.TEXT),
        FieldSpec(name="published", type=FieldType.BOOLEAN, default=False),
    ],
    timestamps=True,  # Adds created_at, updated_at
    soft_delete=True, # Adds deleted_at for soft deletion
)
```

### Use Docker

For containerized development:

```bash
prisme docker init
prisme dev --docker
```

## Common Commands

| Command | Description |
|---------|-------------|
| `prisme create <name>` | Create new project |
| `prisme install` | Install dependencies |
| `prisme generate` | Generate code from spec |
| `prisme generate --dry-run` | Preview changes |
| `prisme test` | Run all tests |
| `prisme dev` | Start dev servers |
| `prisme db migrate` | Create & run migrations |
| `prisme validate` | Validate spec file |

## Next Steps

- [First Project Tutorial](first-project.md) - Build a complete CRM
- [Model Specification Guide](../user-guide/spec-guide.md) - Learn all spec options
- [CLI Reference](../user-guide/cli-reference.md) - All available commands
