# Security

This document describes security considerations and best practices for Prism-generated applications.

## Authentication Security

### API Key Authentication

Prism's API key authentication system uses constant-time comparison to prevent timing attacks.

#### Timing Attack Protection

API key validation uses `secrets.compare_digest()` for constant-time string comparison. This prevents attackers from using timing analysis to guess valid API keys byte-by-byte.

**Secure implementation (used by Prism):**

```python
import secrets

def verify_key(self, api_key: str) -> bool:
    """Verify an API key using constant-time comparison."""
    try:
        valid_keys = self._load_keys()
        # Use constant-time comparison to prevent timing attacks
        return any(secrets.compare_digest(api_key, key) for key in valid_keys)
    except APIKeyError:
        return False
```

**Vulnerable implementation (DO NOT USE):**

```python
# VULNERABLE: Standard comparison leaks timing information
def verify_key(self, api_key: str) -> bool:
    valid_keys = self._load_keys()
    return api_key in valid_keys  # ❌ Timing attack vulnerable
```

#### Why Timing Attacks Matter

Standard string comparison (`==`, `in`) short-circuits on the first differing byte, causing measurable timing differences:

- Matching the first byte: ~1μs slower than mismatching it
- An attacker can use ~256 requests per byte to extract a key
- For a 32-byte key, this is only ~8,192 requests total

Constant-time comparison always compares all bytes regardless of differences, preventing this attack vector.

#### Best Practices

1. **Always use `secrets.compare_digest()`** for comparing:
   - API keys
   - Session tokens
   - Password hashes
   - CSRF tokens
   - Any security-sensitive string

2. **Never use**:
   - `==` for security-sensitive comparisons
   - `in` operator for checking membership of security tokens
   - String comparison operators in authentication logic

3. **Key rotation**: Prism's API key service supports multiple keys and runtime reloading for zero-downtime rotation.

## Related Security Features

- **Password hashing**: Uses bcrypt with configurable rounds
- **JWT tokens**: HS256 with secret key rotation support
- **CORS**: Configurable origin validation
- **Rate limiting**: Request throttling (when configured)

## Reporting Security Issues

If you discover a security vulnerability in Prism, please report it to:
- GitHub Security Advisories: https://github.com/Lasse-numerous/prisme/security/advisories
- Do not open public issues for security vulnerabilities
