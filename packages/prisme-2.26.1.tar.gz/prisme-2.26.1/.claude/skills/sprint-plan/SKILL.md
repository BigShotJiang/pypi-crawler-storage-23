---
name: sprint-plan
description: Plan sprint/cycle work by moving ready issues from Backlog to Predev Review for user approval before development.
argument-hint: "[optional: sprint goal or focus area]"
---

You are planning sprint work for the **Prisme project** (`prisme` on PyPI) — a code generation framework that produces full-stack CRUD applications from Pydantic model specifications.

## Your Responsibility

**Plan the current cycle** by:
- Identifying high-value issues in **Backlog**
- Moving groomed issues to **Predev Review** for user approval
- Balancing effort, priorities, and dependencies
- Aligning with roadmap tiers
- Ensuring issues are groomed and ready for user review
- Setting sprint goals and themes

**Workflow**:
1. Select issues from Backlog → Move to **Predev Review**
2. User reviews and approves issues
3. User moves approved issues to **Ready**
4. Development can be launched on **Ready** issues

## Context Sources

```bash
# Current board state
gh project item-list 1 --owner Lasse-numerous --format json

# Issues by status
gh issue list --state open --json number,title,labels,milestone --jq 'group_by(.milestone.title)'

# Recent velocity (closed in last 14 days)
gh issue list --state closed --json number,title,closedAt --jq '[.[] | select(.closedAt > (now - 14*24*3600 | strftime("%Y-%m-%dT%H:%M:%SZ")))] | length'

# Open PRs (current in-flight work)
gh pr list --state open --json number,title,labels,isDraft
```

Read these files for context:
- `dev/roadmap.md` — roadmap tiers and priorities
- `dev/plans/index.md` — active implementation plans
- `dev/issues/index.md` — issue analysis

## GitHub Setup

| Resource | Details |
|----------|---------|
| **Repo** | `Lasse-numerous/prisme` |
| **Project board** | #2 "Prisme" |

### Board Columns

| Column | Purpose |
|--------|---------|
| **Backlog** | Groomed, not planned for current cycle |
| **Up Next** | Planned for current cycle, ready to pick up |
| **In Progress** | Has active branch/PR |
| **In Review** | PR open, awaiting review |
| **Done** | Merged to main |

## Roadmap Tiers (Priority Order)

1. **Tier 1 — Ship Now** (v2.12.0): CLI DX (#4), managed subdomain (#9), frontend routes (#91), enhanced deps (#92), security fixes (#107, #108, #109)
2. **Tier 2 — Core Platform** (v3.0.0): Background jobs (#94), plugin ecosystem (#95)
3. **Tier 3 — Differentiators**: AI agents (#96), multi-tenancy (#97), real-time (#98)
4. **Tier 4 — Expanding Reach**: i18n (#99), visual builder (#100), media files (#101)
5. **Tier 5 — Specialized**: TimescaleDB (#102), external services (#103), webhooks (#104)

## Planning Process

1. **Review current state**:
   - What's in Up Next?
   - What's In Progress?
   - How much capacity do we have?

2. **Check recent velocity**:
   - How many issues closed in last 1-2 weeks?
   - Are there stalled issues blocking progress?

3. **Identify candidates** from Backlog:
   - Filter by current roadmap tier
   - Prioritize `priority:high` issues
   - Look for quick wins (small effort, high value)
   - Check for dependency chains

4. **Balance the sprint**:
   - Mix of bugs and features
   - Mix of effort levels (don't overload with only large tasks)
   - Focus on completing work in progress before adding new items
   - Align with a sprint theme if applicable

5. **Verify readiness**:
   - Issues have clear AC
   - No blocking dependencies
   - Properly labeled and scoped

6. **Recommend moves** from Backlog → Up Next

## Decision Framework

When selecting issues, prioritize based on:

1. **Strategic alignment** — Current roadmap tier > future tiers
2. **User value** — High-impact features/fixes > nice-to-haves
3. **Dependencies** — Unblocking issues > standalone work
4. **Effort vs. value** — Quick wins > large efforts (within same tier)
5. **Momentum** — Completing partial work > starting new features
6. **Balance** — Mix of backend/frontend/infra work

## Sprint Capacity Guidelines

- **Small sprint** (1 week): 3-5 issues
- **Medium sprint** (2 weeks): 6-10 issues
- **Large sprint** (3-4 weeks): 10-15 issues

Adjust based on:
- Team size (currently solo/small team)
- Issue complexity
- Amount of in-flight work

## Output

Provide a **sprint plan** with:

1. **Sprint goal** — One sentence describing the focus
2. **Issues to move to Up Next** — Numbered list with justifications
3. **Expected outcomes** — What will be delivered
4. **Risks/blockers** — Anything that could derail the sprint
5. **Board updates** — Specific moves to make

Example:
```markdown
## Sprint Goal
Complete Tier 1 CLI DX improvements and ship v2.12.0.

## Move to Up Next

1. **#4 - CLI simplification** (priority:high, scope:cli)
   - Tier 1 feature, high user impact, well-groomed
2. **#107 - Fix CORS security issue** (priority:high, bug)
   - Security fix, must ship in v2.12.0
3. **#91 - Frontend route generation** (priority:medium, scope:frontend)
   - Tier 1, unblocks #92

## Expected Outcomes
- CLI commands reduced by 30%
- Security vulnerability patched
- Frontend routing auto-generated

## Risks
- #4 may require breaking changes (needs migration guide)
```

## User Interaction

**Use AskUserQuestion for all decisions and confirmations.** Structured prompts with selectable options are preferred over plain text questions.

- **Before board updates**: Use AskUserQuestion to approve the sprint plan before moving issues (e.g., "Move these 4 issues to Predev Review?" with Approve All/Select Individual/Adjust options).
- **For capacity decisions**: Use AskUserQuestion when sprint size is ambiguous (e.g., "How many issues for this cycle?" with Small/Medium/Large options).
- **For priority conflicts**: Use AskUserQuestion to resolve trade-offs between competing issues.

Moving issues to Predev Review represents a commitment to work on them in the current cycle, so user approval is essential.

## Moving Issues on the Board

After user approval, execute the board updates:

### Get Project Item IDs

```bash
# Get all project items with their issue numbers and status
gh project item-list 1 --owner Lasse-numerous --format json > /tmp/project-items.json

# Get item ID for a specific issue
ITEM_ID=$(jq -r ".items[] | select(.content.number == [ISSUE_NUMBER]) | .id" /tmp/project-items.json)
```

### Move Issue to "Predev Review"

```bash
# Move single issue to Predev Review (awaiting user approval)
gh project item-edit --project-id PVT_kwDOQ_zirM4An6Uh \
  --id $ITEM_ID \
  --field-id PVTSSF_lAHOB7EJrM4BN7W9zg8x7ss \
  --text "Predev Review"
```

### Move Multiple Issues (Batch)

```bash
# Example: Move issues #4, #91, #92 to Predev Review for user approval
for ISSUE_NUM in 4 91 92; do
  ITEM_ID=$(jq -r ".items[] | select(.content.number == $ISSUE_NUM) | .id" /tmp/project-items.json)
  if [ -n "$ITEM_ID" ]; then
    echo "Moving #$ISSUE_NUM to Predev Review..."
    gh project item-edit --project-id PVT_kwDOQ_zirM4An6Uh \
      --id $ITEM_ID \
      --field-id PVTSSF_lAHOB7EJrM4BN7W9zg8x7ss \
      --text "Predev Review"
  fi
done
```

### Verify Board Updates

```bash
# List all issues in "Predev Review" column (awaiting user approval)
gh project item-list 1 --owner Lasse-numerous --format json | \
  jq -r '.items[] | select(.status == "Predev Review") | "#\(.content.number): \(.content.title)"'

# List all issues in "Ready" column (user-approved, ready to launch)
gh project item-list 1 --owner Lasse-numerous --format json | \
  jq -r '.items[] | select(.status == "Ready") | "#\(.content.number): \(.content.title)"'
```

### Board Status Values

Use these exact strings when moving issues:
- `"Backlog"` - Groomed, not planned for current cycle
- `"Predev Review"` - Ready for user review before launching development
- `"Ready"` - User-approved, ready to launch development
- `"Up Next"` - (Legacy - use Ready instead)
- `"In Progress"` - Active implementation
- `"In Review"` - PR open, awaiting review
- `"Done"` - Merged to main

**Note**: Always move issues to "Predev Review" for user approval. User will move to "Ready" after reviewing and approving.

### Project Board IDs (Reference)

- **Project ID**: `PVT_kwDOQ_zirM4An6Uh`
- **Status Field ID**: `PVTSSF_lAHOB7EJrM4BN7W9zg8x7ss`
- **Project Number**: `1`
- **Owner**: `Lasse-numerous`
