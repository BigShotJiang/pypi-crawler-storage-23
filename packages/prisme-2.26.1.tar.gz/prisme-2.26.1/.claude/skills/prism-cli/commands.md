# Prism CLI — Full Command Reference

All commands should be run with `uv run prisme ...`.

## Project & Code Generation

| Command | Description |
|---------|-------------|
| `prisme create <name>` | Create a new project with template, package manager, and DX options |
| `prisme generate` | Generate code from Pydantic specifications |
| `prisme generate --dry-run` | Preview what would be generated without writing files |
| `prisme validate` | Validate specification files |
| `prisme schema` | Generate GraphQL SDL or output schema |

## Development

| Command | Description |
|---------|-------------|
| `prisme dev` | Start development servers (backend, frontend, MCP) |
| `prisme install` | Install dependencies (backend, frontend, or both) |
| `prisme test` | Run tests with coverage support |

## Database (`prisme db`)

| Command | Description |
|---------|-------------|
| `prisme db init` | Initialize Alembic for migrations |
| `prisme db migrate` | Create/run database migrations |
| `prisme db reset` | Reset database |
| `prisme db seed` | Seed database with test data |

## Docker (`prisme docker`)

| Command | Description |
|---------|-------------|
| `prisme docker init` | Generate Docker Compose files |
| `prisme docker logs` | View container logs |
| `prisme docker shell` | Open shell in container |
| `prisme docker down` | Stop containers |
| `prisme docker reset-db` | Reset database in containers |
| `prisme docker backup-db` | Backup database |
| `prisme docker restore-db` | Restore database |
| `prisme docker init-prod` | Initialize production setup |
| `prisme docker build-prod` | Build production images |

## Code Review (`prisme review`)

Manages conflicts between custom code overrides and regenerated code.

| Command | Description |
|---------|-------------|
| `prisme review list` | List overridden files |
| `prisme review diff` | Show differences |
| `prisme review show` | Show file content |
| `prisme review mark-reviewed` | Mark as reviewed |
| `prisme review mark-all-reviewed` | Mark all as reviewed |
| `prisme review clear` | Clear overrides |
| `prisme review restore` | Restore generated code |

## Multi-Project (`prisme projects`)

| Command | Description |
|---------|-------------|
| `prisme projects list` | List projects |
| `prisme projects down-all` | Stop all running projects |

## Proxy (`prisme proxy`)

| Command | Description |
|---------|-------------|
| `prisme proxy status` | Check proxy status |
| `prisme proxy diagnose` | Diagnose proxy issues |
| `prisme proxy restart` | Restart proxy |

## CI/CD (`prisme ci`)

| Command | Description |
|---------|-------------|
| `prisme ci init` | Initialize CI workflows |
| `prisme ci status` | Check CI status |
| `prisme ci validate` | Validate CI configuration |
| `prisme ci add-docker` | Add Docker to CI |

## Deployment (`prisme deploy`)

| Command | Description |
|---------|-------------|
| `prisme deploy init` | Initialize Hetzner/Terraform deployment |
| `prisme deploy plan` | Show terraform plan |
| `prisme deploy apply` | Apply terraform changes |
| `prisme deploy destroy` | Destroy infrastructure |
| `prisme deploy ssh` | SSH into deployed instance |
| `prisme deploy logs` | View deployment logs |
| `prisme deploy status` | Check deployment status |
| `prisme deploy ssl` | Configure SSL certificates |

## Auth (`prisme auth`)

| Command | Description |
|---------|-------------|
| `prisme auth login` | Login to Prism services |
| `prisme auth logout` | Logout |
| `prisme auth status` | Check auth status |

## Subdomains (`prisme subdomain`)

| Command | Description |
|---------|-------------|
| `prisme subdomain list` | List managed subdomains |
| `prisme subdomain claim` | Claim a subdomain |
| `prisme subdomain activate` | Activate subdomain |
| `prisme subdomain status` | Check subdomain status |
| `prisme subdomain release` | Release subdomain |

## Dev Stack (`prisme devstack`) (renamed from devcontainer)

| Command | Description |
|---------|-------------|
| `prisme devstack up` | Start dev stack |
| `prisme devstack down` | Stop dev stack |
| `prisme devstack shell` | Open shell in dev stack |
| `prisme devstack logs` | View dev stack logs |
| `prisme devstack status` | Check dev stack status |
| `prisme devstack list` | List dev stacks |
| `prisme devstack exec` | Execute command in dev stack |
| `prisme devstack test` | Run tests in dev stack |
| `prisme devstack migrate` | Run migrations in dev stack |
| `prisme devstack url` | Get dev stack URL |
| `prisme devstack generate` | Generate code in dev stack |
