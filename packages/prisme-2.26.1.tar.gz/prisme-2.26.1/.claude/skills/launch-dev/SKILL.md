---
name: launch-dev
description: Kick off development work on ready issues using Claude Code GitHub Actions. Verify issue readiness, trigger implementation, and monitor progress.
argument-hint: "[issue number]"
---

You are launching development work for the **Prisme project** (`prisme` on PyPI) using **Claude Code GitHub Actions** for AI-powered implementation.

## Your Responsibility

**Launch implementation** on ready issues by:
- Verifying issue readiness
- **Getting user confirmation before triggering** (see below)
- Triggering Claude Code via GitHub Actions
- Updating board status
- Monitoring progress
- Following up on PR creation

## ⚠️ User Confirmation Required

**CRITICAL**: Launching development work triggers GitHub Actions workflows, consumes API credits, and creates branches/PRs automatically. **Always use AskUserQuestion to get explicit user approval before triggering.**

### Confirmation Template

After verifying issue readiness, ask the user:

```json
{
  "questions": [{
    "question": "Ready to launch development on issue #[NUMBER] via GitHub Actions?",
    "header": "Launch Dev",
    "multiSelect": false,
    "options": [
      {
        "label": "Yes, launch now (Recommended)",
        "description": "Trigger @claude to implement [brief description]. Creates branch and PR automatically."
      },
      {
        "label": "Review issue first",
        "description": "Show me the issue details and acceptance criteria before launching."
      },
      {
        "label": "Groom issue first",
        "description": "Issue needs clearer AC or more context before implementation."
      },
      {
        "label": "Not yet",
        "description": "Don't launch. I'll trigger manually when ready."
      }
    ]
  }]
}
```

**Only proceed** if the user selects "Yes, launch now".

### Why Confirmation is Required

- **API costs** — GitHub Actions runs consume Claude API credits
- **Automated changes** — Creates branches and PRs without human review
- **Hard to stop** — Once triggered, workflow runs to completion
- **Shared system** — Affects the repository and project board

## Prerequisites

### Repository Setup

Verify the repository has Claude Code GitHub Actions configured:

```bash
# Check if workflow file exists
ls -la .github/workflows/claude.yml

# Check if Claude GitHub App is installed (look for recent workflow runs)
gh run list --workflow=claude.yml --limit 5
```

If not set up, use `/github-actions` skill to configure.

### Issue Readiness Checklist

Before launching, verify the issue has:

- [ ] **Board status is "Ready"** (user-approved, see workflow below)
- [ ] **Clear acceptance criteria** (see `/backlog-groom` if missing)
- [ ] **Proper labels** (priority, scope, type)
- [ ] **Assigned milestone** (based on roadmap tier)
- [ ] **No blockers** (check `blockedBy` or dependencies in comments)
- [ ] **No missing context** (vague description, unclear scope)

If any are missing, **do not launch** — groom the issue or move to "Predev Review" for user approval first.

**Workflow for issue preparation**:
1. Backlog → Groom issue (add AC, labels, milestone)
2. Backlog → **Predev Review** (ready for user approval)
3. User reviews and approves
4. Predev Review → **Ready** (user-approved, ready to launch)
5. Launch development (this skill)

## Launch Process

### 1. Verify Issue Readiness and Board Status

```bash
# Get issue details
gh issue view [ISSUE_NUMBER] --json number,title,body,labels,milestone

# Check board status - MUST be "Ready"
CURRENT_STATUS=$(gh project item-list 1 --owner Lasse-numerous --format json | jq -r ".items[] | select(.content.number == [ISSUE_NUMBER]) | .status")

if [ "$CURRENT_STATUS" != "Ready" ]; then
  echo "❌ Issue #[ISSUE_NUMBER] is not in 'Ready' status (current: $CURRENT_STATUS)"
  echo "Move to 'Predev Review' for user approval first."
  exit 1
fi

# Check for blockers in comments
gh issue view [ISSUE_NUMBER] --comments
```

**CRITICAL**: Only proceed if issue status is "Ready". If in "Backlog" or "Predev Review", the user has not approved it for development yet.

Read the issue and confirm:
- **Status is "Ready"** (user-approved)
- AC is clear and testable
- Scope is well-defined
- No dependencies are blocking

### 2. Get User Confirmation

**Use AskUserQuestion** to get explicit approval before triggering:

```json
{
  "questions": [{
    "question": "Ready to launch development on issue #[NUMBER]?",
    "header": "Launch Dev",
    "multiSelect": false,
    "options": [
      {
        "label": "Yes, launch now (Recommended)",
        "description": "Trigger GitHub Actions to implement the feature automatically."
      },
      {
        "label": "Review issue first",
        "description": "Show me the issue details before launching."
      },
      {
        "label": "Not yet",
        "description": "Don't launch. I'll trigger manually."
      }
    ]
  }]
}
```

**Only proceed to step 3 if user approves.**

### 3. Trigger Claude Code Implementation

**After user confirmation**, comment on the issue to trigger the GitHub Action:

```bash
gh issue comment [ISSUE_NUMBER] --body "@claude implement this feature following the acceptance criteria above. Create a PR when ready."
```

**Alternative commands**:
- `@claude fix this bug based on the description and AC above`
- `@claude implement #[ISSUE_NUMBER] - create a feature branch and PR`
- `@claude complete the acceptance criteria for issue #[ISSUE_NUMBER]`

The Claude Code GitHub Action will:
1. Read the issue and AC
2. Explore the codebase
3. Create a feature branch
4. Implement the changes
5. Run tests
6. Open a PR linked to the issue

### 4. Update Board Status to "In Progress"

Move the issue to **In Progress** immediately after triggering:

```bash
# Get the project item ID for the issue
ITEM_ID=$(gh project item-list 1 --owner Lasse-numerous --format json | jq -r ".items[] | select(.content.number == [ISSUE_NUMBER]) | .id")

# Move to "In Progress"
gh project item-edit --project-id PVT_kwDOQ_zirM4An6Uh --id $ITEM_ID --field-id PVTSSF_lAHOB7EJrM4BN7W9zg8x7ss --text "In Progress"
```

**Why**: This signals that active work has started on the issue.

### 5. Monitor Progress

**Watch for workflow runs**:
```bash
# List recent Claude workflow runs
gh run list --workflow=claude.yml --limit 10

# View specific run
gh run view [RUN_ID]

# Follow run logs in real-time
gh run watch [RUN_ID]
```

**Check for branch creation**:
```bash
# Fetch latest branches
git fetch --all

# Look for Claude branches for this issue
git branch -r | grep "claude/issue-[ISSUE_NUMBER]"
```

### 6. Create PR (If Claude Doesn't)

**IMPORTANT**: Claude Code may create a branch but not open a PR automatically. If the workflow completes but no PR exists:

1. **Check for the branch**:
   ```bash
   git fetch --all
   BRANCH=$(git branch -r | grep "claude/issue-[ISSUE_NUMBER]" | head -1 | xargs)
   ```

2. **Get the commit message** from the branch:
   ```bash
   git log $BRANCH --oneline -1
   ```

3. **Create the PR manually**:
   ```bash
   gh pr create --base main --head ${BRANCH#origin/} \
     --title "[commit-title]" \
     --body "Closes #[ISSUE_NUMBER]

   ## Summary
   [Brief description from issue]

   ## Changes
   [Key changes made]

   ## Implementation
   Implemented by Claude Code via GitHub Actions.

   Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>"
   ```

4. **Move to "In Review"** on the board:
   ```bash
   ITEM_ID=$(gh project item-list 1 --owner Lasse-numerous --format json | jq -r ".items[] | select(.content.number == [ISSUE_NUMBER]) | .id")
   gh project item-edit --project-id PVT_kwDOQ_zirM4An6Uh --id $ITEM_ID --field-id PVTSSF_lAHOB7EJrM4BN7W9zg8x7ss --text "In Review"
   ```

### 7. Review and Merge

Once the PR exists:

1. **Review the PR** using `/product-review [PR_NUMBER]`

2. **Provide feedback** if changes are needed:
   ```bash
   gh pr comment [PR_NUMBER] --body "@claude please address the following feedback: [details]"
   ```

3. **Approve and merge** if ready:
   ```bash
   gh pr review [PR_NUMBER] --approve
   gh pr merge [PR_NUMBER] --squash
   ```

4. **Board updates automatically** to "Done" when PR is merged

## Alternative Workflows

### Scheduled Implementation
Create a workflow to auto-implement issues on a schedule:

```yaml
# .github/workflows/scheduled-dev.yml
name: Scheduled Development
on:
  schedule:
    - cron: '0 9 * * 1'  # Every Monday at 9am
jobs:
  implement-high-priority:
    runs-on: ubuntu-latest
    steps:
      - uses: anthropics/claude-code-action@v1
        with:
          prompt: "Implement all priority:high issues that are ready. Create PRs for each."
```

Use `/github-actions` to set this up.

### Automated Code Reviews
Create a workflow to review PRs automatically:

```yaml
# .github/workflows/pr-review.yml
name: Claude PR Review
on:
  pull_request:
    types: [opened, synchronize]
jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - uses: anthropics/claude-code-action@v1
        with:
          prompt: "Review this PR for code quality, test coverage, and adherence to acceptance criteria."
```

### Custom Cloud Providers
Use AWS Bedrock or Google Vertex AI instead of Anthropic API:

```bash
# For Bedrock
claude github-actions create-workflow \
  --provider bedrock \
  --region us-east-1 \
  --model anthropic.claude-4-6-v1

# For Vertex AI
claude github-actions create-workflow \
  --provider vertex \
  --project my-gcp-project \
  --region us-central1
```

Use `/github-actions` skill for detailed setup.

## Monitoring and Follow-up

### Check Implementation Status

```bash
# Issues currently being worked on by Claude
gh issue list --label "claude:in-progress"

# PRs created by Claude
gh pr list --author "claude-code-bot"
```

### Handle Failures

If Claude encounters errors:

1. **Check workflow logs**:
   ```bash
   gh run view [RUN_ID] --log-failed
   ```

2. **Provide clarification** in issue comments:
   ```bash
   gh issue comment [ISSUE_NUMBER] --body "@claude the implementation failed because [reason]. Please [specific guidance]."
   ```

3. **Retry with more context**:
   ```bash
   gh issue comment [ISSUE_NUMBER] --body "@claude implement this again, but [additional context or constraints]."
   ```

## Output

When launching, provide:

1. **Readiness verification** (issue details and checklist)
2. **User confirmation request** (via AskUserQuestion)
3. **Trigger command** used (after approval)
4. **Board update** made
5. **Next steps** for monitoring

Example:
```markdown
## Launch Development Workflow: #42

### 1. Issue Readiness ✅
- Clear AC ✅
- Labeled (priority:high, scope:backend) ✅
- Milestone v2.12.0 ✅
- No blockers ✅

### 2. Requesting User Approval
[AskUserQuestion prompt shown to user]

### 3. Triggered Implementation 🚀
Comment posted: "@claude implement this feature following the acceptance criteria above. Create a PR when ready."

### 4. Board Updated 📋
Status: Backlog → In Progress

### 5. Monitor Progress 👀
- Watch workflow: `gh run watch`
- Watch for PR: `gh pr list`
- Review when ready: `/product-review [PR_NUMBER]`
```
