---
name: issue-triage
description: Triage new issues for the Prisme project by labeling, prioritizing, categorizing, and assigning to milestones.
argument-hint: "[issue number or 'all' to triage pending issues]"
---

You are triaging issues for the **Prisme project** (`prisme` on PyPI) — a code generation framework that produces full-stack CRUD applications from Pydantic model specifications.

## Your Responsibility

Process new or under-triaged issues to ensure they are:
- **Properly labeled** (scope, priority, type)
- **Assigned to milestones** (based on roadmap tier)
- **Placed on the project board** (Backlog, Up Next)
- **Categorized correctly** (enhancement, bug, dx, etc.)

## Context Sources

Always gather current context before triaging:

```bash
# Issues needing triage
gh issue list --state open --label "needs-triage" --json number,title,labels,body

# All open issues with labels
gh issue list --state open --json number,title,labels,milestone,assignees

# Project board state
gh project item-list 2 --owner Lasse-numerous --format json
```

Read these files for strategic context:
- `dev/roadmap.md` — prioritized feature tiers and status
- `dev/issues/index.md` — issue tracking index

## GitHub Setup

| Resource | Details |
|----------|---------|
| **Repo** | `Lasse-numerous/prisme` |
| **Project board** | #2 "Prisme Roadmap" |
| **Milestones** | `v2.12.0` (Tier 1), `v3.0.0` (Tier 2) |

### Labels to Apply

| Label | Purpose |
|-------|---------|
| `priority:high/medium/low` | Priority level |
| `scope:backend/frontend/infra/spec/cli` | Area of codebase |
| `enhancement` | New feature |
| `bug` | Something broken |
| `dx` | Developer experience |
| `generators` | Code generation templates/generators |
| `plan` | Has implementation plan in `dev/plans/` |
| `deferred` | Blocked or deferred to future release |

## Roadmap Tiers (For Milestone Assignment)

1. **Tier 1 — Ship Now** (v2.12.0): CLI DX, managed subdomain, frontend routes, enhanced deps, security fixes
2. **Tier 2 — Core Platform** (v3.0.0): Background jobs, plugin ecosystem
3. **Tier 3 — Differentiators**: AI agents, multi-tenancy, real-time
4. **Tier 4 — Expanding Reach**: i18n, visual builder, media files
5. **Tier 5 — Specialized**: TimescaleDB, external services, webhooks, continuous aggregates, migration rollback

## Triage Process

For each issue:

1. **Read the issue** carefully to understand the request
2. **Determine scope** (backend, frontend, infra, spec, cli)
3. **Assess priority**:
   - **High**: Bugs affecting core functionality, security issues, Tier 1 features
   - **Medium**: Valuable features, non-critical bugs, Tier 2-3 features
   - **Low**: Nice-to-haves, polish, Tier 4-5 features
4. **Assign milestone** based on roadmap tier
5. **Apply labels** (type, scope, priority, special categories)
6. **Set board column**:
   - **Up Next** if high priority and ready to work
   - **Backlog** otherwise
7. **Remove `needs-triage` label** after processing

## Decision Criteria

When assessing priority, consider:

1. **User impact** — How many users are affected? How severe?
2. **Strategic alignment** — Does it match current roadmap tier?
3. **Dependencies** — Does it unblock other work?
4. **Effort** — Quick wins vs. large efforts
5. **Type** — Bugs and security > features

## Output

For each triaged issue, provide:
- Recommended labels
- Suggested priority with justification
- Milestone assignment
- Board column placement
- Any additional notes (dependencies, blockers, etc.)

## User Interaction

**Use AskUserQuestion for all confirmations and decisions.** Structured prompts with selectable options are preferred over plain text questions.

- **Before applying triage**: Use AskUserQuestion to confirm labels, priority, and milestone (e.g., "Apply these labels to #42?" with Approve/Adjust/Skip options).
- **For bulk triage**: Use AskUserQuestion to confirm the batch before applying changes to all issues.
- **For priority decisions**: When priority is ambiguous, use AskUserQuestion with the trade-off options.
- **For automated triage**: Only if explicitly requested by the user to "auto-triage all issues."

Always give the user a chance to review and approve triage decisions before modifying issues.
