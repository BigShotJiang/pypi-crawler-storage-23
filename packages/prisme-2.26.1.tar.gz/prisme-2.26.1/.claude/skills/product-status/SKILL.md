---
name: product-status
description: Report on project health, milestone progress, recent merges, blockers, and risks for the Prisme project.
argument-hint: "[optional: milestone or time period]"
---

You are reporting on project status for the **Prisme project** (`prisme` on PyPI) — a code generation framework that produces full-stack CRUD applications from Pydantic model specifications.

## Your Responsibility

Provide **status reports** covering:
- **Board state** — What's in each column, any stale items
- **Milestone progress** — How close to release goals
- **Recent activity** — What shipped, what's in flight
- **Blockers and risks** — What could derail progress
- **Velocity** — How fast are we moving

## Context Sources

```bash
# Board state
gh project item-list 2 --owner Lasse-numerous --format json

# Issues by status
gh issue list --state open --json number,title,labels,milestone,createdAt,updatedAt

# Recent closed issues
gh issue list --state closed --limit 20 --json number,title,closedAt,milestone

# Open PRs
gh pr list --state open --json number,title,labels,isDraft,createdAt

# Milestone progress
gh api repos/Lasse-numerous/prisme/milestones --jq '.[] | "\(.title): \(.open_issues) open, \(.closed_issues) closed, due \(.due_on // "none")"'

# Recent commits to main
git log --oneline --since="2 weeks ago" origin/main
```

Read these files for context:
- `dev/roadmap.md` — roadmap tiers and priorities
- `dev/plans/index.md` — active implementation plans
- `dev/issues/index.md` — issue tracking

## Report Format

Provide a concise status report with these sections:

### 1. Executive Summary
**One-paragraph overview** of project health and trajectory.

Example:
```markdown
## Executive Summary
v2.12.0 is 60% complete with 4/10 issues closed. CLI simplification (#4) is in progress and on track. 3 security fixes are merged and ready to ship. Frontend routing (#91) is blocked by design decisions. Next major milestone (v3.0.0) is scheduled to start next sprint.
```

### 2. Board Snapshot

| Status | Count | Notes |
|--------|-------|-------|
| Up Next | 5 | Ready to pick up |
| In Progress | 3 | On track |
| In Review | 2 | Awaiting review |
| Backlog | 42 | Groomed and prioritized |

**Stale items** (>14 days without update):
- #XX - [title] (In Progress, last updated 21 days ago)

### 3. Milestone Progress

#### v2.12.0 (Tier 1 — Ship Now)
**Progress**: 4/10 issues closed (40%)

**Completed**:
- ✅ #107 - CORS security fix (merged)
- ✅ #108 - XSS prevention (merged)
- ✅ #109 - SQL injection fix (merged)
- ✅ #93 - Email integration (shipped in v2.11.0)

**In Flight**:
- 🚧 #4 - CLI simplification (PR #XXX in review)
- 🚧 #91 - Frontend routing (branch created)

**Blocked**:
- 🚫 #92 - Enhanced deps (waiting on #91)

**Not Started**:
- ⏳ #9 - Managed subdomain

**Target**: End of month (Feb 28)

#### v3.0.0 (Tier 2 — Core Platform)
**Progress**: 0/2 issues closed (0%)
**Status**: Planning phase, starts after v2.12.0 ships

### 4. Recent Velocity

| Period | Issues Closed | PRs Merged |
|--------|---------------|------------|
| Last 7 days | 2 | 3 |
| Last 14 days | 5 | 6 |
| Last 30 days | 12 | 14 |

**Trend**: Steady velocity, on track for monthly release cadence

### 5. Active Work (In Progress + In Review)

| PR | Issue | Status | Age |
|----|-------|--------|-----|
| #XXX | #4 - CLI simplification | In Review | 3 days |
| #XXX | #107 - CORS fix | In Review | 1 day |
| (none) | #91 - Frontend routing | In Progress | 5 days |

### 6. Blockers and Risks

**Current Blockers**:
- 🚫 #92 (Enhanced deps) blocked by #91 (Frontend routing)
- 🚫 Design decision needed for #91 (routing strategy)

**Risks**:
- ⚠️ v2.12.0 target date (Feb 28) at risk if #4 (CLI simplification) takes >1 week
- ⚠️ Stale issue #XX has been In Progress for 21 days without PR
- ⚠️ 3 PRs in review with no reviewer assigned

**Mitigation**:
- Schedule design sync for #91
- Follow up on stale issue #XX
- Assign reviewers to open PRs

### 7. What's Next

**This Week**:
- Ship #4 (CLI simplification)
- Resolve design decision for #91
- Start #9 (Managed subdomain)

**This Sprint**:
- Complete all v2.12.0 Tier 1 issues
- Cut v2.12.0 release
- Begin planning v3.0.0 (background jobs)

## Analysis Tips

When generating the report:

1. **Calculate percentages** — milestone completion, velocity trends
2. **Identify outliers** — Stale issues, long-running PRs, blocked items
3. **Spot patterns** — Is velocity increasing/decreasing? Are certain areas stuck?
4. **Flag risks early** — Target dates at risk, blocked dependencies, resource constraints
5. **Be specific** — Use issue numbers, dates, and concrete metrics

## Output Variations

**Quick status** (for daily standups):
- Board snapshot
- Active work
- Blockers

**Full status** (for weekly reviews):
- All sections above

**Milestone-focused** (for release planning):
- Milestone progress (detailed)
- Blockers and risks
- Target date assessment
- What's next

Adapt the report format based on what the user needs.
