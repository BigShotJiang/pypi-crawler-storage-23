# Issue: Golden Tests — Full Pipeline Validation Per Starter Template

**Status**: In Progress
**Priority**: High
**Type**: Enhancement
**Created**: 2026-02-10
**Branch**: `claude/golden-tests-setup-GS5S0`
**GitHub**: #126

## Problem

The golden test suite (`tests/e2e/test_template_golden.py`) currently only validates create → generate → ruff lint for each starter template. It does **not** verify that the generated code actually works: generated tests aren't run, frontend linting is skipped, devcontainers aren't smoke-tested, and there are no browser-level checks. Breakages in generated output can ship undetected.

## Impact

- A template change can produce code that passes ruff but fails at runtime
- Generated backend tests may not even execute successfully
- Generated frontend code may have TypeScript/ESLint errors we never catch
- Devcontainer configuration is only unit-tested, never lifecycle-tested
- No validation that the generated UI actually renders or performs CRUD

## Proposed Solution

Expand golden tests across 4 tiers, all parametrized over the 7 starter templates:

### Tier 1 — Generated Tests (`e2e`, `docker`)

| What | Templates | Database |
|---|---|---|
| Backend: `prisme devcontainer test --backend-only` | All 7 | PostgreSQL (via devcontainer) |
| Frontend: `prisme devcontainer test --frontend-only` | 4 with frontend | N/A |

### Tier 2 — Frontend Linting (`e2e`, `docker`)

| What | Templates |
|---|---|
| `pnpm lint` (ESLint) via `prisme devcontainer exec` | 4 with frontend |

### Tier 3 — Devcontainer Smoke (`e2e`, `docker`) — main only

| What | Templates |
|---|---|
| `prisme devcontainer up` → `prisme dev` → health checks → `prisme devcontainer down` | All 7 |

Health checks: backend `GET /health` → 200, frontend `GET /` → 200.

### Tier 4 — Playwright Browser Smoke (`e2e`, `docker`, `slow`) — main only

| What | Templates |
|---|---|
| Full CRUD smoke: page load → list → create → read detail → update → delete | 4 with frontend |

### Test files

```
tests/e2e/
├── test_template_golden_tests.py         # Tier 1 ✅
├── test_template_golden_lint.py          # Tier 2 ✅
├── test_template_golden_devcontainer.py  # Tier 3 ✅
├── test_template_golden_playwright.py    # Tier 4 ✅
```

### CI jobs

| Job | Trigger | Timeout | Status |
|---|---|---|---|
| `golden-tests` | All PRs + main | 45 min | ✅ Added |
| `golden-devcontainer` | main only | 45 min | ✅ Added |
| `golden-playwright` | main only | 45 min | ✅ Added |

### Dependencies added

```toml
playwright = ">=1.40"
pytest-playwright = ">=0.4"
```

## Acceptance Criteria

### Phase 1 — Generated Tests (Tier 1 + 2)
- [x] `test_generated_backend_tests_pass[<template>]` passes for all 7 templates (verified: 7/7 PASSED)
- [x] `test_generated_frontend_tests_pass[<template>]` passes for all 4 frontend templates (verified: 4/4 PASSED)
- [x] `test_eslint_passes[<template>]` passes for all 4 frontend templates (verified: 4/4 PASSED)
- [x] Tests skip (not fail) when required runtimes are missing — `skip_if_no_docker()` implemented
- [x] Each test reuses cached project from `_get_project()` — module-level `_cache` dict
- [x] CI job `golden-tests` added
- [ ] CI job green — PR not yet run in CI

### Phase 2 — Devcontainer Smoke (Tier 3)
- [x] `test_devcontainer_smoke[<template>]` implemented for all 7 templates
- [x] Containers always torn down (even on failure) via `finally:` block
- [x] Skipped when Docker not available — `skip_if_no_docker()`
- [x] 5-minute timeout per template — `DEVCONTAINER_TIMEOUT = 300`
- [x] CI job `golden-devcontainer` added, gated to `main`
- [x] Verified locally — 7/7 PASSED
- [ ] CI job green — not yet run

### Phase 3 — Playwright (Tier 4)
- [x] `test_playwright_crud_smoke[<template>]` implemented for all 4 frontend templates
- [x] Full CRUD: page load, list, create, read detail, update, delete
- [x] Headless in CI, screenshots on failure
- [x] Skipped when Playwright browsers not installed — `_check_playwright_available()`
- [x] 3-minute timeout per template — `PLAYWRIGHT_TIMEOUT = 180`
- [x] CI job `golden-playwright` added, gated to `main`
- [x] Verified locally — 4/4 PASSED
- [ ] CI job green — not yet run

## Template Fixes Applied

During implementation, several issues were found and fixed in the starter templates:

| Fix | Files | Commit |
|---|---|---|
| Minimal: sync → async database | `base.py`, `main_minimal.py.jinja2` | `2331ab6` |
| Minimal: router wiring (commented stubs → try/except) | `main_minimal.py.jinja2` | `2331ab6` |
| Minimal: missing `strawberry-graphql` dependency | `pyproject.minimal.toml.jinja2` | `2331ab6` |
| Minimal: missing test deps (factory-boy, httpx, etc.) | `pyproject.minimal.toml.jinja2` | `0526a24` |
| `_detect_python_manager()`: check parent directories | `cli.py` | `0526a24` |
| `GeneratorConfig`: single-package output paths | `project_spec.py.jinja2` | `0526a24` |
| Vitest: test include path `__tests__/` → `src/__tests__/` | `vitest.config.ts.jinja2` | `c5831bf` |
| ESLint: `react-refresh/only-export-components` in useRouteConfig | `useRouteConfig.ts.jinja2` | `c5831bf` |
| ESLint: unnecessary useCallback deps in SurveyPage | `survey.tsx.jinja2` | `c5831bf` |
| ESLint: `set-state-in-effect` in useSearch (derived isPending) | `useSearch.ts.jinja2` | `c5831bf` |
| ESLint: ref access during render in JsonEditor (state pattern) | `JsonEditor.tsx.jinja2` | `c5831bf` |
| ESLint: `set-state-in-effect` in ThemeToggle (lazy init) | `ThemeToggle.tsx.jinja2` | `c5831bf` |

## Implementation Plan

See `dev/plans/golden-tests-full-pipeline-plan.md` for full design and implementation steps.
