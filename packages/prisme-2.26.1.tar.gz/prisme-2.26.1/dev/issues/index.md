# Issue Tracking

> **Note**: Issues are tracked on GitHub: https://github.com/Lasse-numerous/prisme/issues
>
> This folder contains detailed analysis documents linked from GitHub Issues.

## Open Issues

| Document | GitHub Issue | Status |
|----------|-------------|--------|
| [cli-simplification-roadmap.md](cli-simplification-roadmap.md) | [#4](https://github.com/Lasse-numerous/prisme/issues/4) | Open (15% done) |

## Deferred Issues

| Document | GitHub Issue | Status |
|----------|-------------|--------|
| [schema-drift-not-detected.md](schema-drift-not-detected.md) | [#6](https://github.com/Lasse-numerous/prisme/issues/6) | Deferred |
| [no-custom-graphql-extension.md](no-custom-graphql-extension.md) | [#7](https://github.com/Lasse-numerous/prisme/issues/7) | Deferred |

## Resolved Issues (Archived)

These documents have been moved to [archive/historical/](../archive/historical/):

| Document | Resolution |
|----------|------------|
| app-tsx-overwrites-providers.md | Protected regions in App.tsx |
| async-sqlalchemy-eager-loading.md | `load_relationships` parameter added |
| ci-init-spec-loading.md | Made spec loading optional with CLI flags |
| cli-docs-missing-commands.md | CLI docs updated to match actual commands |
| custom-routes-not-preserved.md | Protected regions in router.tsx |
| down-all-incomplete.md | Improved container cleanup with orphan detection |
| generate-ignores-config-paths.md | Fixed config path handling |
| nav-links-ignore-config.md | `include_in_nav` flag now respected |
| no-override-restore-mechanism.md | `prism review restore` command added |
| override-warning-unclear.md | Warning message reworded for clarity |
| router-generates-nonexistent-routes.md | FrontendExposure flag checks added |

## Issue Workflow

1. Create GitHub Issue for new bugs/features
2. Add detailed analysis document here if needed (link from issue)
3. Use GitHub labels for prioritization
4. Close issues via PR references (`Closes #N`)
5. Archive resolved analysis documents to `archive/historical/`
