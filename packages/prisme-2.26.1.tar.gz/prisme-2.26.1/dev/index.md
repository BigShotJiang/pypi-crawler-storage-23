# Prism Development Documentation

Welcome to the internal development documentation for the **Prism** project. This site contains roadmaps, implementation plans, issue tracking, and development guidelines.

## Quick Links

<div class="grid cards" markdown>

-   :material-map-marker-path:{ .lg .middle } **[Roadmap](roadmap.md)**

    ---

    Strategic priorities organized by tier (Ship Now → Core → Differentiators)

-   :material-file-document-multiple:{ .lg .middle } **[Plans](plans/index.md)**

    ---

    Detailed implementation plans for features

-   :material-bug:{ .lg .middle } **[Issues](issues/index.md)**

    ---

    Bug tracking and problem documentation

-   :material-archive:{ .lg .middle } **[Archive](archive/index.md)**

    ---

    Completed plans, removed features, historical discussions

</div>

## Architecture Overview

```mermaid
graph TB
    subgraph "Prism CLI"
        CLI[prism CLI]
        Parser[Spec Parser]
        Generators[Code Generators]
    end

    subgraph "Specification"
        Spec[prism.yaml]
        Models[Models]
        Auth[Authentication]
        APIs[API Config]
    end

    subgraph "Generated Project"
        Backend[FastAPI Backend]
        Frontend[React Frontend]
        Docker[Docker Compose]
        Infra[Infrastructure]
    end

    Spec --> Parser
    Parser --> Generators
    Generators --> Backend
    Generators --> Frontend
    Generators --> Docker
    Generators --> Infra

    Models --> Parser
    Auth --> Parser
    APIs --> Parser
```

## Current Priorities

| Tier | Feature | Status |
|------|---------|--------|
| **1** | [Managed Subdomain](plans/managed-subdomain-plan.md) | :material-progress-clock: 85% |
| **1** | [CLI Simplification & DX](issues/cli-simplification-roadmap.md) | :material-progress-clock: 15% |
| **1** | Custom Frontend Routes + Landing | :material-progress-clock: 60% |
| **1** | Enhanced Dependency Templates | :material-progress-clock: 55% |
| **2** | Email Integration | :material-check-circle:{ .green } Complete |
| **2** | [Background Jobs](plans/background-jobs-scheduling-plan.md) | :material-circle-outline: Not Started |
| **2** | [Plugin Ecosystem](plans/plugin-ecosystem-plan.md) | :material-circle-outline: Not Started |
| **3** | AI Agents with MCP | :material-progress-clock: 35% |
| **3** | [Multi-Tenancy](plans/multi-tenancy-saas-plan.md) | :material-circle-outline: Not Started |
| **3** | [Real-Time & WebSockets](plans/realtime-websockets-plan.md) | :material-circle-outline: ~8% |

## Feature Categories

```mermaid
mindmap
  root((Prism Features))
    Framework
      CI/CD Pipeline
      Documentation Site
      CLI Tooling
      Plugin Ecosystem
    User-Facing
      AI Agents + MCP
      Email Integration
      Deployment Templates
      Multi-Tenancy & SaaS
      i18n & Localization
    IoT & Data Platform
      Background Jobs
      TimescaleDB
      External Services
      Webhooks
      Media Files
    Real-Time
      WebSockets
      Live Queries
      Presence System
    Platform & DX
      Visual Spec Builder
      Dev Containers
      Managed Subdomains
    Authentication
      Built-in JWT Auth
      IAM & Roles
      MFA Support
```

## Getting Started

1. **Read the [Documentation Guide](dev-docs.md)** - Understand folder structure and conventions
2. **Check the [Roadmap](roadmap.md)** - See current priorities and timeline
3. **Review relevant [Plans](plans/index.md)** - Detailed implementation specifications

## Status Legend

| Icon | Meaning |
|------|---------|
| :material-check-circle:{ .green } | Complete |
| :material-progress-clock:{ .yellow } | In Progress |
| :material-circle-outline: | Not Started |
| :material-alert-circle:{ .red } | Blocked |
