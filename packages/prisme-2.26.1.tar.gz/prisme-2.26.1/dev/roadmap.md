# Prism Development Roadmap

**Document Purpose**: Strategic priorities for Prism framework and user-facing features
**Last Updated**: 2026-02-08
**Current Version**: 2.11.0

---

## Prioritized Roadmap

Features are organized into tiers based on strategic impact, dependencies, and user value. Statuses verified against the codebase on 2026-02-06.

### Tier 1 — Ship Now

Highest ROI. Nearly done, quick wins, or unblocks everything else.

| # | Feature | Remaining | Status | Rationale |
|---|---------|-----------|--------|-----------|
| 1 | [Managed Subdomain (madewithpris.me)](#1-managed-subdomain--https-madewithprisme) | ~1 week | 🟡 85% done | Only Phase 6 (production deploy) remains |
| 2 | [CLI Simplification & DX](#2-cli-simplification--developer-experience) | 3-5 weeks | 🟡 15% done | Protected regions done; wizard, watcher, config missing |
| 3 | [Custom Frontend Routes + Landing](#3-custom-frontend-routes--landing-page) | ~1 week | 🟡 60% done | Landing page + protected regions done; router hooks missing |
| 4 | [Enhanced Dependency Templates](#4-enhanced-dependency--install-templates) | <1 week | 🟡 55% done | `prism install` + dep groups + setup.sh done; version files missing |

### Tier 2 — Core Platform

Makes Prism production-ready for real applications.

| # | Feature | Remaining | Status | Rationale |
|---|---------|-----------|--------|-----------|
| 5 | [Email Integration (General-Purpose)](#5-email-integration-general-purpose) | — | 🟢 Complete | Shipped in PR #79 (2026-02-07) |
| 6 | [Background Jobs & Scheduling](#6-background-jobs--scheduling) | 3-4 weeks | 🔴 Not Started | Plan exists, zero implementation |
| 7 | [Plugin & Extension Ecosystem](#7-plugin--extension-ecosystem) | 6-8 weeks | 🔴 Not Started | Plan exists, zero implementation |

### Tier 3 — Differentiators

Unique capabilities that set Prism apart from other frameworks.

| # | Feature | Remaining | Status | Rationale |
|---|---------|-----------|--------|-----------|
| 8 | [AI Agents with MCP](#8-ai-agents-with-mcp-integration) | 3-4 weeks | 🟡 35% done | MCP generator 100% done; agent layer + chat UI missing |
| 9 | [Multi-Tenancy & SaaS Mode](#9-multi-tenancy--saas-mode) | 6-8 weeks | 🔴 Not Started | Plan only |
| 10 | [Real-Time & WebSockets](#10-real-time--websockets) | 5-6 weeks | 🔴 ~8% | GraphQL subscription stubs exist; everything else missing |

### Tier 4 — Expanding Reach

Broadens audience and capabilities.

| # | Feature | Remaining | Status | Rationale |
|---|---------|-----------|--------|-----------|
| 11 | [Internationalization (i18n)](#11-internationalization-i18n--localization) | 4-5 weeks | 🔴 Not Started | Plan only |
| 12 | [Visual Spec Builder (GUI)](#12-visual-spec-builder-gui) | 8-10 weeks | 🔴 Not Started | Plan only |
| 13 | [Media File Handling](#13-media-file-handling) | 4-5 weeks | 🔴 Not Started | No plan, no implementation |

### Tier 5 — Specialized

Niche use cases and lower-priority items.

| # | Feature | Remaining | Status | Rationale |
|---|---------|-----------|--------|-----------|
| 14 | [TimescaleDB Support](#14-timescaledb-support) | 3-4 weeks | 🔴 Not Started | Plan only |
| 15 | [External Service Integration](#15-external-service-integration) | 2-3 weeks | 🔴 Not Started | Plan only |
| 16 | [Webhook/Event Handling](#16-webhookevent-handling) | 2 weeks | 🔴 Not Started | Plan only |
| 17 | [Continuous Aggregates](#17-continuous-aggregates-timescaledb) | 2-3 weeks | 🔴 Not Started | Depends on #14 |
| 18 | [Migration Rollback Support](#18-migration-rollback-support) | 1-2 weeks | 🟡 25% done | Alembic downgrade works; no auto-generation of down SQL |

---

## Tier 1 — Ship Now

### 1. Managed Subdomain + HTTPS (madewithpris.me)

**Status**: 🟡 In Progress (85%) | **Remaining**: ~1 week | **Category**: Platform / DX

Provides `*.madewithpris.me` subdomains with automatic HTTPS for Hetzner deploys. Phases 0-5 complete. Only Phase 6 (production deploy + live testing) remains.

**What exists in codebase**:
- `prism subdomain claim/activate/status/release` CLI commands
- `prism auth login/logout/status` CLI commands
- API key auth generator + middleware + templates
- Credential storage at `~/.config/prism/credentials.json`
- prisme-saas project: 66 tests, CI/CD, Docker config

**What's left**: Deploy prisme-saas to Hetzner, live DNS + SSL testing.

**Detailed Plan**: [managed-subdomain-plan.md](plans/managed-subdomain-plan.md)

---

### 2. CLI Simplification & Developer Experience

**Status**: 🟡 15% done | **Remaining**: 3-5 weeks | **Category**: Framework / DX

**What exists in codebase**:
- Protected regions utility (`src/prisme/utils/file_handler.py`) with `parse_protected_regions()` and `merge_protected_regions()`
- Protected region markers in `router.tsx.jinja2` and `App.tsx.jinja2`
- `prism dev` command exists with `--watch` flag defined — but watcher **not implemented** (no watchdog)

**What's left**:
- Interactive wizard (`prism init`) — currently `prism init` is for DB migrations only
- File watcher in `prism dev` — flag exists but no implementation
- `.prism/config.yaml` config system — not started
- `prism self-upgrade` — not started

**Detailed Plan**: [cli-simplification-roadmap.md](issues/cli-simplification-roadmap.md)

---

### 3. Custom Frontend Routes + Landing Page

**Status**: 🟡 60% done | **Remaining**: ~1 week | **Category**: User-Facing

**What exists in codebase**:
- Landing page generator (`src/prisme/generators/frontend/landing.py`) — generates `LandingPage.tsx` for auth-enabled projects
- Landing page template (`landing.tsx.jinja2`) with project title, description, dark mode
- Protected regions in `router.tsx.jinja2` for custom routes (`// PRISM:PROTECTED:START - Custom Routes`)
- Protected regions in `App.tsx.jinja2` for custom providers

**What's left**:
- `router.hook.tsx` type-safe hook system for cleaner route injection
- Automatic route discovery from file system

---

### 4. Enhanced Dependency & Install Templates

**Status**: 🟡 55% done | **Remaining**: <1 week | **Category**: User-Facing

**What exists in codebase**:
- `prism install` command (`cli.py:2959-3068`) — auto-detects uv/poetry/pdm/pip, `--backend-only`/`--frontend-only` flags
- Grouped dependencies in `pyproject.full.toml.jinja2` — `dev` and `docs` groups
- `setup.sh` script template (`devcontainer/setup.sh.jinja2`, 74 lines) — installs backend + frontend deps, runs migrations

**What's left**:
- `.python-version` template (file exists in Prism itself but not generated in projects)
- `.nvmrc` template — not implemented
- `INSTALL.md` template — not implemented

---

## Tier 2 — Core Platform

### 5. Email Integration (General-Purpose)

**Status**: 🟢 Complete | **Shipped**: PR #79 (2026-02-07) | **Category**: User-Facing

General-purpose email service with multi-provider support, HTML templates, and CLI commands.

**What was delivered**:
- `EmailConfig` spec model with multi-provider support
- Email service generator with Resend, SMTP, SendGrid, Mailgun, AWS SES providers
- General-purpose email API for business logic (not just auth)
- HTML email template system (Jinja2)
- Auth integration: verification, password reset, invite emails
- `prism email send` and `prism email test-config` CLI commands

---

### 6. Background Jobs & Scheduling

**Status**: 🔴 Not Started | **Remaining**: 3-4 weeks | **Category**: User-Facing

Define scheduled jobs in specification, auto-generate APScheduler config with history/logging.

```yaml
schedulers:
  - name: price_fetcher
    trigger: interval
    interval_minutes: 15
    function: plugins.prices.fetch
```

**Codebase evidence**: Plan document only. No spec models, generators, templates, or tests.

**Detailed Plan**: [background-jobs-scheduling-plan.md](plans/background-jobs-scheduling-plan.md)

---

### 7. Plugin & Extension Ecosystem

**Status**: 🔴 Not Started | **Remaining**: 6-8 weeks | **Category**: Platform / Framework

Transforms Prism from a tool into a platform. Community plugins add generators, templates, spec extensions, and pre-built model packs.

```yaml
plugins:
  - prism-plugin-audit-log:
      track_models: all
  - prism-plugin-blog:
      prefix: blog
```

**Codebase evidence**: Plan document only. No plugin API, hook system, or CLI commands.

**Detailed Plan**: [plugin-ecosystem-plan.md](plans/plugin-ecosystem-plan.md)

---

## Tier 3 — Differentiators

### 8. AI Agents with MCP Integration

**Status**: 🟡 35% done | **Remaining**: 3-4 weeks | **Category**: User-Facing

**What exists in codebase** (MCP layer — 100% done):
- MCP generator (`src/prisme/generators/backend/mcp.py`, 392 lines) — generates FastMCP tools for all exposed models
- `MCPExposure` spec config with operations, tool_prefix, resource_uri_template
- MCP templates: `server.py.jinja2`, `tools.py.jinja2` — CRUD tools with filtering, pagination
- Both stdio and SSE transports supported
- Tutorial: `docs/tutorials/mcp-integration.md` (407 lines)
- Docker/Traefik integration for MCP service

**What's left** (Agent layer — 0%):
- Agent service with LLM provider integration (Anthropic/OpenAI/Ollama)
- Conversation history / state management
- `agents:` spec section with system prompts, tool selection, roles
- Chat widget React component (`AgentChat.tsx`)
- Streaming responses (SSE)
- `prism agents list/test/chat` CLI commands

---

### 9. Multi-Tenancy & SaaS Mode

**Status**: 🔴 Not Started | **Remaining**: 6-8 weeks | **Category**: User-Facing

Transforms "generate a CRUD app" into "generate a SaaS product." Three isolation strategies (RLS, schema-per-tenant, database-per-tenant), tenant resolution middleware, onboarding flows.

**Codebase evidence**: Plan document only. No spec models, middleware, RLS policies, or tenant UI.

**Detailed Plan**: [multi-tenancy-saas-plan.md](plans/multi-tenancy-saas-plan.md)

---

### 10. Real-Time & WebSockets

**Status**: 🔴 ~8% | **Remaining**: 5-6 weeks | **Category**: User-Facing

**What exists in codebase**:
- GraphQL subscriptions template (`subscriptions.py.jinja2`) — generates stub resolvers (raises `NotImplementedError`)
- `GraphQLConfig.subscriptions_enabled` flag (default True)
- Per-model `subscriptions` override in `DeliveryOverrides`
- Frontend subscription template (`subscriptions.ts.jinja2`) — basic TypeScript client

**What's left**: WebSocket server, connection manager, event emission in services, React hooks, presence, SSE fallback.

**Detailed Plan**: [realtime-websockets-plan.md](plans/realtime-websockets-plan.md)

---

## Tier 4 — Expanding Reach

### 11. Internationalization (i18n) & Localization

**Status**: 🔴 Not Started | **Remaining**: 4-5 weeks | **Category**: User-Facing

**Codebase evidence**: Plan document only. No i18n generators, translation files, or react-i18next setup.

**Detailed Plan**: [i18n-localization-plan.md](plans/i18n-localization-plan.md)

---

### 12. Visual Spec Builder (GUI)

**Status**: 🔴 Not Started | **Remaining**: 8-10 weeks | **Category**: Platform / DX

**Codebase evidence**: Plan document only. No React app, no `prism builder` command.

**Detailed Plan**: [visual-spec-builder-plan.md](plans/visual-spec-builder-plan.md)

---

### 13. Media File Handling

**Status**: 🔴 Not Started | **Remaining**: 4-5 weeks | **Category**: User-Facing

**Codebase evidence**: No plan document, no implementation. `FieldType` enum has no FILE/MEDIA type.

---

## Tier 5 — Specialized

### 14. TimescaleDB Support

**Status**: 🔴 Not Started | **Remaining**: 3-4 weeks

**Codebase evidence**: Plan document only.

**Detailed Plan**: [timescaledb-support-plan.md](plans/timescaledb-support-plan.md)

---

### 15. External Service Integration

**Status**: 🔴 Not Started | **Remaining**: 2-3 weeks

**Codebase evidence**: Plan document only.

**Detailed Plan**: [external-service-integration-plan.md](plans/external-service-integration-plan.md)

---

### 16. Webhook/Event Handling

**Status**: 🔴 Not Started | **Remaining**: 2 weeks

**Codebase evidence**: Plan document only. Existing `events.py` is for lifespan management, not webhooks.

**Detailed Plan**: [webhook-event-handling-plan.md](plans/webhook-event-handling-plan.md)

---

### 17. Continuous Aggregates (TimescaleDB)

**Status**: 🔴 Not Started | **Remaining**: 2-3 weeks | **Depends on**: #14

**Codebase evidence**: No plan, no implementation.

---

### 18. Migration Rollback Support

**Status**: 🟡 25% done | **Remaining**: 1-2 weeks

**What exists in codebase**:
- Alembic `script.py.mako` template includes `upgrade()` and `downgrade()` functions
- Migration README documents `alembic downgrade -1` and `alembic downgrade base`
- `down_revision` tracking in generated migrations

**What's left**:
- Auto-generate intelligent `downgrade()` SQL (currently `pass` placeholder)
- `prism migrate rollback` CLI command
- Rollback safety checks (data loss warnings)

---

## Completed Features

| Feature | Version | Date | Evidence |
|---------|---------|------|----------|
| **Email Integration (General-Purpose)** | v2.11.0 | 2026-02-07 | PR #79 |
| **Organization Management with RBAC** | v2.11.0 | 2026-02-07 | PR #87 |
| **Analytics Spec + Generators** | v2.11.0 | 2026-02-07 | PR #84 |
| **Streaming Updates + gRPC Exposure** | v2.11.0 | 2026-02-07 | PR #82 |
| **GDPR/NIS2 Compliance Generators** | v2.11.0 | 2026-02-07 | PR #81 |
| **Website Generators (Blog, SEO, Chatbot)** | v2.11.0 | 2026-02-07 | PR #80 |
| **Hetzner Runner + AWS Batch Infrastructure** | v2.11.0 | 2026-02-07 | PR #86 |
| Service Abstraction | — | — | Base+extension services, bulk ops, nested creates, lifecycle hook stubs |
| Docker Compose Templates | — | — | DockerGenerator, dev+prod compose, Dockerfiles, Traefik routing |
| Admin Panel & User Access Control | v1.6.0 | 2026-01-30 | PR #63 |
| Enterprise Auth (Built-in JWT) | v0.15.0 | 2026-01-29 | — |
| Frontend Design System (Nordic) | v0.12.0 | 2026-01-26 | PR #2 |
| Dev Container with Claude Code | v0.12.0 | 2026-01-26 | PR #3 |
| CI/CD Pipeline | — | 2026-01-23 | — |
| Documentation Site (MkDocs) | — | 2026-01-23 | — |
| Hetzner Deployment Templates | — | 2026-01-23 | — |

Detailed descriptions of older completed features are in [archive/](archive/).

---

## Codebase Audit Summary (2026-02-06)

Every roadmap feature was verified against the actual codebase. Key findings:

| Finding | Impact |
|---------|--------|
| **Service Abstraction was already done** | Removed from roadmap, moved to Completed. Frees up Tier 2. |
| **Docker Compose was already done** | Removed from Tier 5, moved to Completed. |
| **Custom Frontend Routes is 60% done** | Landing page generator shipped (`3c56b70`). Reduced remaining effort. |
| **Enhanced Dependencies is 55% done** | `prism install` + dep groups + setup.sh exist. Only version files + INSTALL.md remain. |
| **Email is COMPLETE** | Shipped in PR #79 (2026-02-07). Multi-provider email service with templates, CLI commands. |
| **AI Agents/MCP is 35% done** | MCP generator fully implemented (392 lines). Agent orchestration layer is what's missing. |
| **Real-Time has 8% foundation** | GraphQL subscription stubs + config exist. WebSocket server not started. |
| **Migration Rollback is 25% done** | Alembic downgrade infrastructure exists. Auto-generation of down SQL missing. |
| **CLI Simplification is 15% done** | Protected regions utility implemented. `--watch` flag exists but unimplemented. |

**Revised total remaining effort**: ~68-88 weeks across all features (down from ~84-104 weeks before audit, accounting for already-completed work).

---

**Last Updated**: 2026-02-08 | **Maintainer**: Prism Core Team
