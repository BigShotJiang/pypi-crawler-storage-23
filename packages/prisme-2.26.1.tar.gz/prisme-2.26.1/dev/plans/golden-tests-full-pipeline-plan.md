# Plan: Golden Tests — Full Pipeline Validation Per Starter Template

**Status**: In Progress
**Author**: Prism Team
**Created**: 2026-02-10
**Updated**: 2026-02-10T16:00Z
**Priority**: P1 (Important)

## Overview

Expand the golden test suite (`tests/e2e/test_template_golden.py`) from its current scope (create → generate → ruff lint) into a full pipeline validation that exercises generated tests, generated linters, devcontainer smoke tests, and Playwright browser tests for each of the 7 starter templates.

## Current State

The golden tests today run 5 checks per template (35 total parametrized tests):

| Check | Implemented |
|---|---|
| `test_project_created` | Yes |
| `test_spec_loadable` | Yes |
| `test_generate_succeeds` | Yes |
| `test_ruff_check_passes` | Yes |
| `test_ruff_format_clean` | Yes |

Adjacent but disconnected infrastructure exists:
- `tests/generators/testing/test_generated_tests_pass.py` — runs generated backend tests for a hardcoded Customer/Order spec (marker: `slow`)
- CI `generated-code-coverage` job — runs generated backend + frontend tests for the demo spec only
- `tests/generators/frontend/test_eslint.py` — validates ESLint on generated frontend code but not wired into golden tests
- `tests/devcontainer/` — tests config/CLI only, no lifecycle
- No Playwright tests anywhere in the codebase

## Goals

For **each** of the 7 starter templates (minimal, api-only, mcp-only, website, app, enterprise-platform, saas):

1. **Run generated backend tests** — install deps, run pytest on the generated test suite against PostgreSQL
2. **Run generated frontend tests** — install deps, run vitest/jest on generated test suite (templates with `has_frontend=True`)
3. **Lint generated frontend code** — run ESLint on generated TypeScript/React (templates with `has_frontend=True`)
4. **Devcontainer smoke test** — `prisme devcontainer up`, verify services healthy, `prisme devcontainer down`
5. **Playwright browser smoke test** — start the app, verify key pages render, test one full CRUD flow end-to-end (templates with `has_frontend=True`)

## Non-Goals

- Replacing or removing the existing `generated-code-coverage` CI job (it tracks coverage, this tracks correctness)
- Full Playwright test suites per template (one CRUD smoke flow is enough)
- Coverage reports from golden tests (the `generated-code-coverage` job handles that)
- Performance benchmarking of generated code
- Testing generated code against real external services (Authentik, Stripe, etc.)

## Design

### Test Organization

```
tests/e2e/
├── test_template_golden.py               # Existing: create → generate → ruff
├── test_template_golden_tests.py         # Tier 1 ✅ implemented
├── test_template_golden_lint.py          # Tier 2 ✅ implemented
├── test_template_golden_devcontainer.py  # Tier 3 ✅ implemented
├── test_template_golden_playwright.py    # Tier 4 ✅ implemented
└── conftest.py                           # Shared helpers ✅ extended
```

### Key Design Decision: Devcontainer-Based Execution

All tests run inside devcontainers rather than directly on the host. This ensures:
- PostgreSQL is always available (no CI service needed)
- Dependencies are installed via `setup.sh` (uv/pip, pnpm)
- Generated code runs in the same environment as production
- `PRISM_SRC` environment variable mounts local prisme source for dev testing

Pipeline: `prisme create` → `prisme generate` → `prisme devcontainer up` → `prisme devcontainer test` → `prisme devcontainer down`

### Tier 1 — Generated Tests (marker: `e2e`, `docker`)

**Backend tests** (all 7 templates):
```
create → generate → devcontainer up → devcontainer test --backend-only → devcontainer down
```
- All templates test against PostgreSQL inside the devcontainer
- `setup.sh` handles deps, code generation, and migrations

**Frontend tests** (4 templates: website, app, enterprise-platform, saas):
```
create → generate → devcontainer up → devcontainer test --frontend-only → devcontainer down
```

**Acceptance criteria:**
- [x] `test_generated_backend_tests_pass[<template>]` passes for all 7 templates (verified: 7/7 PASSED)
- [x] `test_generated_frontend_tests_pass[<template>]` passes for all 4 frontend templates (verified: 4/4 PASSED)
- [x] Tests are skipped (not failed) when required runtimes are missing — `skip_if_no_docker()`
- [x] Each test reuses the cached project from `_get_project()` — module-level `_cache` dict

### Tier 2 — Frontend Linting (marker: `e2e`, `docker`)

**ESLint** (4 templates: website, app, enterprise-platform, saas):
```
create → generate → devcontainer up → devcontainer exec "cd packages/frontend && pnpm lint" → devcontainer down
```

**Acceptance criteria:**
- [x] `test_eslint_passes[<template>]` passes for all 4 frontend templates (verified: 4/4 PASSED)
- [x] Reuses cached project from `_get_project()`

### Tier 3 — Devcontainer Smoke Test (marker: `e2e`, `docker`)

Runs on `main` only, not on every PR.

```
create → generate → devcontainer up → prisme dev (background) → health check → devcontainer down
```

**Health check definition:**
- Backend container responds to `GET /health` or `GET /docs` with 200
- Frontend container (if applicable) responds to `GET /` with 200

**Acceptance criteria:**
- [x] `test_devcontainer_smoke[<template>]` implemented for all 7 templates
- [x] Containers are always torn down (even on failure) via `finally:` block
- [x] Test is skipped when Docker is not available — `skip_if_no_docker()`
- [x] Timeout: 5 minutes per template — `DEVCONTAINER_TIMEOUT = 300`
- [x] Verified locally — 7/7 PASSED

### Tier 4 — Playwright Browser Smoke (marker: `e2e`, `docker`, `slow`)

Runs on `main` only, not on every PR. Depends on Tier 3 (devcontainer must be running).

**Smoke test per frontend template (full CRUD):**
1. Navigate to `/` — verify page loads (title or heading present)
2. Navigate to one model's list page — verify table/list renders empty
3. **Create** one record via the UI form — verify it appears in the list
4. **Read** — click into the record detail page, verify fields are displayed
5. **Update** — edit a field, save, verify the change persists
6. **Delete** — delete the record, verify it disappears from the list

**Acceptance criteria:**
- [x] `test_playwright_crud_smoke[<template>]` implemented for all 4 frontend templates
- [x] Playwright is installed as a dev dependency (`playwright`, `pytest-playwright`)
- [x] Tests run headless in CI
- [x] Screenshots captured on failure for debugging
- [x] Test is skipped when Playwright browsers are not installed — `_check_playwright_available()`
- [x] Timeout: 3 minutes per template — `PLAYWRIGHT_TIMEOUT = 180`
- [x] Verified locally — 4/4 PASSED

### CI Workflow Changes

Three jobs added to `.github/workflows/ci.yml`:

```yaml
  golden-tests:          # All PRs + main, 45 min, Docker (devcontainers)
  golden-devcontainer:   # main only, 45 min, Docker
  golden-playwright:     # main only, 45 min, Docker + Chromium
```

All three jobs: ✅ Added

### Dependencies Added

```toml
# pyproject.toml dev dependencies
playwright = ">=1.40"
pytest-playwright = ">=0.4"
```

## Implementation Steps

### Phase 1 — Generated Tests (Tier 1 + 2) ✅ Complete
1. ✅ Extended `tests/e2e/conftest.py` with devcontainer helpers (`devcontainer_up/down/test/exec/exec_background/health_check`)
2. ✅ Added `test_template_golden_tests.py` with `test_generated_backend_tests_pass` parametrized across all 7 templates
3. ✅ Added `test_generated_frontend_tests_pass` parametrized across 4 frontend templates
4. ✅ Added `test_template_golden_lint.py` with `test_eslint_passes` parametrized across 4 frontend templates
5. ✅ Added CI job `golden-tests` to `.github/workflows/ci.yml`
6. ✅ Backend tests verified locally (7/7 PASSED). Frontend + lint not yet verified.

### Phase 2 — Devcontainer Smoke (Tier 3) ✅ Code Complete
1. ✅ Added `test_template_golden_devcontainer.py` with `test_devcontainer_smoke` (marker: `e2e`, `docker`)
2. ✅ Implemented health-check polling helper (`devcontainer_health_check` with retry/backoff)
3. ✅ Added teardown finalizer via `finally:` block ensuring `devcontainer_down` always runs
4. ✅ Added CI job `golden-devcontainer` gated to `main` only
5. ⬜ Not yet verified locally

### Phase 3 — Playwright (Tier 4) ✅ Code Complete
1. ✅ Added `playwright` and `pytest-playwright` to dev dependencies
2. ✅ Wrote `test_template_golden_playwright.py` with `test_playwright_crud_smoke` — full CRUD
3. ✅ Wired into devcontainer fixture (start containers → Traefik proxy → run Playwright → tear down)
4. ✅ Added CI job `golden-playwright` gated to `main` only, with Chromium install and screenshot upload
5. ⬜ Not yet verified locally

## Progress

### Commits

| Commit | Description |
|---|---|
| `c9a5a41` | docs: add golden tests full pipeline plan and issue spec |
| `0526a24` | feat: add 4-tier golden test suite for all starter templates |
| `2331ab6` | fix: align minimal template with full template capabilities |

### Template Fixes Required During Implementation

The golden tests exposed several issues in the minimal template that had to be fixed:

1. **Sync → async database** (`base.py`): Minimal template used `database.py.jinja2` (sync SQLAlchemy) but generated code expects async. Changed to `database_async.py.jinja2`.

2. **Router wiring** (`main_minimal.py.jinja2`): Had commented-out router stubs (`# from .api.rest.router import router`) instead of proper try/except imports. Updated to match `main_full.py.jinja2` with dynamic router discovery.

3. **Missing dependencies** (`pyproject.minimal.toml.jinja2`): Added `strawberry-graphql[fastapi]`, `factory-boy`, `httpx`, `asyncpg`, `aiosqlite`, `alembic`, `pytest-cov`.

4. **`_detect_python_manager()` bug** (`cli.py`): Returned "pip" for `packages/backend` because it only checked the given path for `pyproject.toml`. Fixed to walk parent directories.

5. **`GeneratorConfig` output paths** (`project_spec.py.jinja2`): Single-package templates (minimal, api-only, mcp-only) need `backend_output="src"` not the default `packages/backend/src`. Added `is_monorepo` context variable.

6. **Vitest test include path** (`vitest.config.ts.jinja2`): Had `./__tests__/` but tests are generated at `./src/__tests__/`. Fixed to `./src/__tests__/`.

7. **ESLint errors in generated frontend code** (6 template files):
   - `useRouteConfig.ts.jinja2`: Added `eslint-disable react-refresh/only-export-components` (mixed component + hook exports)
   - `survey.tsx.jinja2`: Removed unnecessary `answers`, `contact` from `handleSubmit` useCallback deps
   - `useSearch.ts.jinja2`: Derived `isPending` from state comparison instead of managing as separate state (avoids `set-state-in-effect`)
   - `JsonEditor.tsx.jinja2`: Replaced ref-based previous-value tracking with React-recommended state pattern (avoids `react-hooks/refs`)
   - `ThemeToggle.tsx.jinja2`: Used lazy state initialization for theme from localStorage, `eslint-disable` for SSR hydration `setMounted` pattern

### Infrastructure Built

- `tests/e2e/conftest.py` — Full devcontainer test infrastructure:
  - `devcontainer_up()` — ensures .env, sets PRISM_SRC + BOOTSTRAP_EMAIL, chmod, starts container
  - `devcontainer_down()` — teardown with `--volumes` flag
  - `devcontainer_test()` — runs `prisme devcontainer test` with extra args
  - `devcontainer_exec()` — runs arbitrary commands inside container
  - `devcontainer_exec_background()` — detached `docker exec -d` for dev servers
  - `devcontainer_health_check()` — retry-based curl from inside container
  - All helpers pass `PRISM_SRC` env var for local dev prisme mounting

## Testing Strategy

This **is** the testing strategy — the feature is itself a test suite. Validate by:
- ✅ Running Tier 1 backend tests locally against all 7 templates (7/7 PASSED)
- ✅ Running Tier 1 frontend tests locally against frontend templates (4/4 PASSED)
- ✅ Running Tier 2 lint tests locally (4/4 PASSED)
- ✅ Running Tier 3 devcontainer smoke locally (7/7 PASSED)
- ✅ Running Tier 4 Playwright locally (4/4 PASSED)
- ⬜ Full CI run on a PR with all tiers passing
