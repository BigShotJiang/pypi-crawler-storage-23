# Implementation Plans

Detailed implementation plans for features and significant changes to Prism.

## Plan Status Overview

```mermaid
pie title Plans by Status
    "Active" : 9
    "Completed/Archived" : 3
```

## Active Plans

### Tier 1-2 — Ship Now & Core Platform

| Plan | Tier | Description | Status |
|------|------|-------------|--------|
| [Managed Subdomain + HTTPS](managed-subdomain-plan.md) | 1 | `*.madewithpris.me` subdomains with auto-SSL | :material-progress-clock: In Progress (85%) |
| [Background Jobs & Scheduling](background-jobs-scheduling-plan.md) | 2 | APScheduler for data ingestion & async workflows | :material-circle-outline: Not Started |
| [Plugin & Extension Ecosystem](plugin-ecosystem-plan.md) | 2 | Community plugins, model packs, generation hooks | :material-circle-outline: Not Started |

### Tier 3 — Differentiators

| Plan | Description | Status |
|------|-------------|--------|
| [Multi-Tenancy & SaaS Mode](multi-tenancy-saas-plan.md) | RLS, tenant isolation, SaaS product generation | :material-circle-outline: Not Started |
| [Real-Time & WebSockets](realtime-websockets-plan.md) | WebSocket channels, live model subscriptions, presence | :material-circle-outline: Not Started |

### Tier 4-5 — Expanding Reach & Specialized

| Plan | Description | Status |
|------|-------------|--------|
| [Internationalization (i18n)](i18n-localization-plan.md) | Auto-extracted translations, react-i18next, RTL | :material-circle-outline: Not Started |
| [Visual Spec Builder (GUI)](visual-spec-builder-plan.md) | Drag-and-drop spec editor with React Flow | :material-circle-outline: Not Started |
| [TimescaleDB Support](timescaledb-support-plan.md) | Time-series hypertables, compression, retention | :material-circle-outline: Not Started |
| [External Service Integration](external-service-integration-plan.md) | Type-safe HTTP clients for external APIs | :material-circle-outline: Not Started |
| [Webhook/Event Handling](webhook-event-handling-plan.md) | Authenticated webhook endpoints | :material-circle-outline: Not Started |

## Archived Plans

| Plan | Reason | Location |
|------|--------|----------|
| Email Integration | Completed (PR #79, 2026-02-07) | Shipped — see [roadmap](../roadmap.md#5-email-integration-general-purpose) |
| Admin Panel & User Access Control | Completed (PR #63, 2026-01-30) | [archive/completed-plans/](../archive/completed-plans/admin-panel-plan.md) |
| Authentik Integration | Removed in v0.15.0 (replaced by built-in auth) | [archive/removed-features/](../archive/removed-features/authentik-integration-plan.md) |

## Plan Dependencies

```mermaid
graph LR
    subgraph "Tier 1 - Ship Now"
        MS[Managed Subdomain]
        CLI[CLI Simplification]
        FR[Frontend Routes]
    end

    subgraph "Tier 2 - Core Platform"
        BG[Background Jobs]
        PL[Plugin Ecosystem]
    end

    subgraph "Tier 3 - Differentiators"
        AI[AI Agents]
        MT[Multi-Tenancy]
        RT[Real-Time & WS]
    end

    subgraph "Tier 4-5"
        I18N[i18n]
        VB[Visual Builder]
        TS[TimescaleDB]
        CA[Continuous Aggregates]
    end

    CLI --> AI
    PL --> MT
    PL --> RT
    PL --> I18N
    TS --> CA

    style MS fill:#4ade80
    style CLI fill:#fbbf24
    style FR fill:#fbbf24
    style BG fill:#fb923c
    style PL fill:#fb923c
    style AI fill:#a78bfa
    style MT fill:#a78bfa
    style RT fill:#a78bfa
    style I18N fill:#93c5fd
    style VB fill:#93c5fd
    style TS fill:#d1d5db
    style CA fill:#d1d5db
```

## Creating New Plans

Follow the template in [Documentation Guide](../dev-docs.md#plans-plans):

```markdown
# Plan: <Feature Name>

**Status**: Draft | Approved | In Progress | Complete
**Author**: <name>
**Created**: YYYY-MM-DD
**Updated**: YYYY-MM-DD

## Overview
## Goals
## Non-Goals
## Design
## Implementation Steps
## Testing Strategy
## Rollout Plan
## Open Questions
```
