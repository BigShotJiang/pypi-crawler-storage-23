# Feature Improvements & Gap Analysis

**Status**: Proposal
**Created**: 2026-02-08
**Scope**: Generator capabilities, spec models, CLI completeness, template quality, missing integrations

---

## Executive Summary

Prism is **~58% feature-complete** across Tier 1-2 roadmap items. The framework excels at generating CRUD backends and frontends but has critical gaps in three areas: non-functional generated code (gRPC, GraphQL subscriptions), missing common web features (file uploads, background jobs), and incomplete frontend integrations (chatbot, survey, inquiry, register-interest generators).

---

## Critical Issues (Block Production Use)

### 1. gRPC Feature is Non-Functional

**Files**:
- `src/prisme/generators/backend/grpc.py` (line 111: TODO)
- `src/prisme/templates/jinja2/backend/grpc/service.py.jinja2` (lines 67, 85, 103, 121, 139, 192, 212)

**Problem**: 11 `NotImplementedError` stubs in generated gRPC service code. Proto files are not compiled.

**Impact**: Any user enabling gRPC gets code that raises `NotImplementedError` at runtime.

**Recommendation**: Either implement fully or remove from framework. Removing is 2 hours; implementing is 3-4 weeks.

### 2. GraphQL Subscriptions Non-Functional

**Files**:
- `src/prisme/templates/jinja2/backend/graphql/subscriptions.py.jinja2` (lines 38, 59, 76)

**Problem**: 3 `NotImplementedError` stubs. Feature is enabled by default (`GraphQLConfig.subscriptions_enabled = True`) but generates broken code.

**Impact**: Real-time updates fail silently at runtime.

**Recommendation**: Disable subscriptions by default (`subscriptions_enabled = False`) or implement Redis pub/sub backend.

### 3. GDPR Privacy Routes Audit Gap

**File**: `src/prisme/templates/jinja2/backend/privacy/privacy_routes.py.jinja2` (lines 98, 124)

**Problem**: `requesting_user_id=None` — cannot track WHO requested data deletion/export.

**Impact**: GDPR Article 12 audit trail is incomplete; regulatory risk for EU-facing apps.

**Recommendation**: Extract `requesting_user_id` from JWT claims in the template. Effort: 2-4 hours.

---

## Major Feature Gaps

| Gap | Type | Effort | Notes |
|-----|------|--------|-------|
| **File Upload / Media** | Missing FieldType | 4-5 weeks | No `FILE` or `MEDIA` in FieldType enum (`src/prisme/spec/fields.py:17-32`) |
| **Background Jobs** | Roadmap #6 — 0% | 3-4 weeks | Plan exists at `dev/plans/background-jobs-scheduling-plan.md`, zero code |
| **Real-Time / WebSockets** | Roadmap #10 — 8% | 5-6 weeks | Streaming generator has event bus framework only, no pub/sub |
| **Multi-Tenancy** | Roadmap #9 — 0% | 6-8 weeks | Plan only |
| **Plugin System** | Roadmap #7 — 0% | 6-8 weeks | Plan only |

---

## Incomplete Frontend Generators (Stubs)

Four frontend generators produce UI-only code with "Wire up to your backend API endpoint" TODOs:

| Generator | File | Template TODO Location |
|-----------|------|----------------------|
| **Chatbot** | `src/prisme/generators/frontend/chatbot.py` | `templates/.../chatbot.tsx.jinja2` line 55: "placeholder response" |
| **Survey** | `src/prisme/generators/frontend/survey.py` | `templates/.../survey.tsx.jinja2` line 184 |
| **Inquiry** | `src/prisme/generators/frontend/inquiry.py` | `templates/.../inquiry.tsx.jinja2` line 35 |
| **Register Interest** | `src/prisme/generators/frontend/register_interest.py` | `templates/.../register_interest.tsx.jinja2` line 25 |

**Recommendation**: Generate corresponding backend routes (form submission endpoints) alongside the frontend forms. Effort: 2-3 weeks total.

---

## Spec Model Gaps

### FieldType Enum Missing Critical Types

**File**: `src/prisme/spec/fields.py` (lines 17-32)

Current 13 types: `STRING, TEXT, INTEGER, FLOAT, DECIMAL, BOOLEAN, DATETIME, DATE, TIME, UUID, JSON, ENUM, FOREIGN_KEY`

Missing:
- `FILE` — No file upload support anywhere
- `MEDIA` — No image/video storage
- `BINARY` — No blob storage
- `ARRAY` — No native list fields
- `IP_ADDRESS` — Common for logging/analytics

### Auth Config Gaps

**File**: `src/prisme/spec/auth.py`

- OAuth: Only GitHub implemented. Missing: Google, Discord, Microsoft, Apple
- No LDAP/SSO integration
- No magic link authentication
- No WebAuthn/passkeys

---

## Template Quality Issues

41 templates across the codebase have TODO/FIXME/placeholder markers. Key categories:

| Category | Count | Severity |
|----------|-------|----------|
| NotImplementedError stubs | 9 templates | Critical |
| "Wire up" / "placeholder" TODOs | 4 templates | Major |
| OAuth expansion TODOs | 2 templates | Medium |
| Widget system incomplete | 1 template (`defaults.ts.jinja2` line 42: TimePicker) | Minor |

---

## CLI Completeness Gaps

**File**: `src/prisme/cli.py` (6,497 lines)

| Missing Feature | Status | Notes |
|-----------------|--------|-------|
| Interactive `prism init` wizard | Not implemented | `prism init` is DB-only (line 2435) |
| File watcher in `prism dev` | Flag exists, not implemented | `--watch` flag defined but watcher only partially connected (line 2919) |
| `.prism/config.yaml` system | Not started | No persistent CLI configuration |
| `prism self-upgrade` | Not started | No version checking |
| Schema drift detection | Not implemented | See `dev/issues/schema-drift-not-detected.md` |
| `prism migrate rollback` | Missing | Must use `alembic downgrade` directly |

---

## Prioritized Recommendations

### Immediate (1-2 weeks)

1. **Fix gRPC**: Decide — implement or deprecate/remove
2. **Fix GraphQL subscriptions**: Disable by default or implement pub/sub
3. **Fix GDPR audit trail**: Extract user ID from JWT in privacy routes template

### Short Term (1-2 months)

4. **Add `FieldType.FILE`**: Enable file upload support across the stack
5. **Complete CLI simplification**: Interactive wizard, file watcher, config system
6. **Wire up frontend stubs**: Add backend routes for chatbot/survey/inquiry/register-interest

### Medium Term (2-4 months)

7. **Background jobs**: Implement APScheduler integration per plan
8. **Additional OAuth providers**: Google, Discord, Microsoft
9. **Real-time updates**: WebSocket server with Redis pub/sub

---

**Analysis Date**: 2026-02-08
