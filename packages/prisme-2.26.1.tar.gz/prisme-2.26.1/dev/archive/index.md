# Archive

Historical and completed documents preserved for reference. These are no longer actively maintained.

## Removed Features

| Document | Reason | Date |
|----------|--------|------|
| [authentik-integration-plan.md](removed-features/authentik-integration-plan.md) | Replaced by built-in JWT auth system in v0.15.0 | 2026-01-29 |

## Completed Plans

| Document | PR | Date |
|----------|-----|------|
| [admin-panel-plan.md](completed-plans/admin-panel-plan.md) | PR #63 | 2026-01-30 |

## Resolved Issues

Bug reports and improvement analyses that have been resolved. Moved from `issues/` after resolution.

| Document | Resolution |
|----------|------------|
| [app-tsx-overwrites-providers.md](historical/app-tsx-overwrites-providers.md) | Protected regions in App.tsx |
| [async-sqlalchemy-eager-loading.md](historical/async-sqlalchemy-eager-loading.md) | `load_relationships` parameter |
| [ci-init-spec-loading.md](historical/ci-init-spec-loading.md) | Optional spec loading with CLI flags |
| [cli-docs-missing-commands.md](historical/cli-docs-missing-commands.md) | CLI docs updated |
| [custom-routes-not-preserved.md](historical/custom-routes-not-preserved.md) | Protected regions in router.tsx |
| [down-all-incomplete.md](historical/down-all-incomplete.md) | Orphan container detection |
| [nav-links-ignore-config.md](historical/nav-links-ignore-config.md) | `include_in_nav` flag respected |
| [no-override-restore-mechanism.md](historical/no-override-restore-mechanism.md) | `prism review restore` command |
| [override-warning-unclear.md](historical/override-warning-unclear.md) | Warning message reworded |
| [router-generates-nonexistent-routes.md](historical/router-generates-nonexistent-routes.md) | FrontendExposure flag checks |

## Historical Discussions

Background conversations that informed major design decisions.

| Document | Context |
|----------|---------|
| [v1-feedback.md](historical/v1-feedback.md) | Analysis of v1 spec/config boundary confusion — prompted the v2 refactor |
| [v1-review-new-perspective.md](historical/v1-review-new-perspective.md) | Clarification of v1 three-layer architecture |
| [generate-ignores-config-paths.md](historical/generate-ignores-config-paths.md) | Issue #5 (closed) — generate ignoring config paths |
