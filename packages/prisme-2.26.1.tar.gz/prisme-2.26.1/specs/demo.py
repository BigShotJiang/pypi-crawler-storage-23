"""Prism Demo Specification — Product Catalog.

A realistic product-catalog domain that demonstrates key Prism features:
- All field types (STRING, TEXT, INTEGER, FLOAT, DECIMAL, BOOLEAN, DATETIME, DATE, ENUM, JSON)
- Relationships (one_to_many, many_to_one)
- Nested create (Product → Variant)
- Temporal / time-series queries (PriceSnapshot)
- Conditional validation
- Custom UI widgets (richtext, currency, rating, tags, datepicker, switch, slider)
- Soft delete and timestamps
- Lifecycle hooks
- v2 exposure model (expose, operations, overrides)
- MCP tool customization
- Frontend overrides (nav labels, table columns, form layout)

Run:
    prism validate specs/demo.py
    prism create demo-app --spec specs/demo.py && cd demo-app && prism generate
"""

from prisme import (
    DeliveryOverrides,
    FieldSpec,
    FieldType,
    FilterOperator,
    FrontendOverrides,
    MCPOverrides,
    ModelSpec,
    RelationshipSpec,
    StackSpec,
    TemporalConfig,
)

# =============================================================================
# STACK SPECIFICATION
# =============================================================================

stack = StackSpec(
    name="prism-demo",
    version="1.0.0",
    title="Prism Product Catalog",
    description="Demo product catalog showcasing Prism features",
    models=[
        # ==================================================================
        # BRAND
        # Basic parent entity — timestamps, soft delete, typed JSON tags,
        # MCP overrides, frontend nav customization.
        # ==================================================================
        ModelSpec(
            name="Brand",
            description="A product brand or manufacturer",
            table_name="brands",
            soft_delete=True,
            timestamps=True,
            fields=[
                FieldSpec(
                    name="name",
                    type=FieldType.STRING,
                    max_length=200,
                    min_length=2,
                    required=True,
                    unique=True,
                    indexed=True,
                    searchable=True,
                    label="Brand Name",
                    filter_operators=[
                        FilterOperator.EQ,
                        FilterOperator.CONTAINS,
                        FilterOperator.STARTS_WITH,
                    ],
                ),
                FieldSpec(
                    name="description",
                    type=FieldType.TEXT,
                    required=False,
                    searchable=True,
                    ui_widget="richtext",
                    label="About",
                ),
                FieldSpec(
                    name="website",
                    type=FieldType.STRING,
                    max_length=500,
                    required=False,
                    pattern=r"^https?://.*",
                    ui_widget="url",
                ),
                FieldSpec(
                    name="founded_year",
                    type=FieldType.INTEGER,
                    min_value=1800,
                    max_value=2100,
                    required=False,
                    label="Year Founded",
                ),
                FieldSpec(
                    name="is_active",
                    type=FieldType.BOOLEAN,
                    default=True,
                    filter_operators=[FilterOperator.EQ],
                ),
                FieldSpec(
                    name="tags",
                    type=FieldType.JSON,
                    json_item_type="str",
                    required=False,
                    ui_widget="tags",
                    description="Categorization tags",
                ),
            ],
            relationships=[
                RelationshipSpec(
                    name="products",
                    target_model="Product",
                    type="one_to_many",
                    back_populates="brand",
                    use_dataloader=True,
                ),
            ],
            expose=True,
            delivery_overrides=DeliveryOverrides(
                rest_tags=["brands"],
                page_size=25,
                max_page_size=100,
            ),
            mcp_overrides=MCPOverrides(
                tool_prefix="brand",
                tool_descriptions={
                    "list": "Search and list product brands",
                    "read": "Get brand details by ID",
                    "create": "Register a new brand",
                },
            ),
            frontend_overrides=FrontendOverrides(
                nav_label="Brands",
                nav_icon="building-2",
            ),
        ),
        # ==================================================================
        # PRODUCT
        # Rich entity — many field types, conditional validation, nested
        # create with Variants, lifecycle hooks, custom widgets.
        # ==================================================================
        ModelSpec(
            name="Product",
            description="A product with variants and pricing",
            soft_delete=True,
            timestamps=True,
            fields=[
                FieldSpec(
                    name="brand_id",
                    type=FieldType.FOREIGN_KEY,
                    references="Brand",
                    on_delete="CASCADE",
                    required=True,
                    indexed=True,
                ),
                FieldSpec(
                    name="name",
                    type=FieldType.STRING,
                    max_length=255,
                    required=True,
                    searchable=True,
                    label="Product Name",
                    filter_operators=[
                        FilterOperator.EQ,
                        FilterOperator.CONTAINS,
                        FilterOperator.ILIKE,
                    ],
                ),
                FieldSpec(
                    name="sku",
                    type=FieldType.STRING,
                    max_length=50,
                    required=True,
                    unique=True,
                    indexed=True,
                    label="SKU",
                ),
                FieldSpec(
                    name="description",
                    type=FieldType.TEXT,
                    required=False,
                    searchable=True,
                    ui_widget="markdown",
                ),
                FieldSpec(
                    name="category",
                    type=FieldType.ENUM,
                    enum_values=[
                        "electronics",
                        "clothing",
                        "home",
                        "sports",
                        "books",
                        "other",
                    ],
                    default="other",
                    required=True,
                    filter_operators=[FilterOperator.EQ, FilterOperator.IN],
                ),
                FieldSpec(
                    name="price",
                    type=FieldType.DECIMAL,
                    precision=10,
                    scale=2,
                    min_value=0,
                    required=True,
                    ui_widget="currency",
                    ui_widget_props={"currency": "USD", "locale": "en-US"},
                    filter_operators=[
                        FilterOperator.EQ,
                        FilterOperator.GT,
                        FilterOperator.LT,
                        FilterOperator.BETWEEN,
                    ],
                ),
                FieldSpec(
                    name="weight_kg",
                    type=FieldType.FLOAT,
                    min_value=0.0,
                    required=False,
                    label="Weight (kg)",
                ),
                FieldSpec(
                    name="stock_quantity",
                    type=FieldType.INTEGER,
                    min_value=0,
                    default=0,
                    filter_operators=[
                        FilterOperator.EQ,
                        FilterOperator.GT,
                        FilterOperator.LTE,
                    ],
                ),
                FieldSpec(
                    name="rating",
                    type=FieldType.FLOAT,
                    min_value=0.0,
                    max_value=5.0,
                    required=False,
                    ui_widget="rating",
                ),
                FieldSpec(
                    name="is_available",
                    type=FieldType.BOOLEAN,
                    default=True,
                    ui_widget="switch",
                    label="Available for Sale",
                ),
                FieldSpec(
                    name="released_at",
                    type=FieldType.DATE,
                    required=False,
                    ui_widget="datepicker",
                    label="Release Date",
                    filter_operators=[
                        FilterOperator.GT,
                        FilterOperator.LT,
                        FilterOperator.BETWEEN,
                    ],
                ),
                # Conditional: required only for electronics
                FieldSpec(
                    name="warranty_months",
                    type=FieldType.INTEGER,
                    min_value=0,
                    required=False,
                    conditional_required="category == electronics",
                    description="Warranty period — required for electronics",
                ),
                FieldSpec(
                    name="features",
                    type=FieldType.JSON,
                    json_item_type="str",
                    required=False,
                    ui_widget="tags",
                    description="Product feature highlights",
                ),
                FieldSpec(
                    name="specifications",
                    type=FieldType.JSON,
                    required=False,
                    ui_widget="json",
                    description="Technical specifications (key-value pairs)",
                ),
            ],
            relationships=[
                RelationshipSpec(
                    name="brand",
                    target_model="Brand",
                    type="many_to_one",
                    back_populates="products",
                ),
                RelationshipSpec(
                    name="variants",
                    target_model="Variant",
                    type="one_to_many",
                    back_populates="product",
                    cascade="all, delete-orphan",
                ),
            ],
            nested_create=["variants"],
            before_create="validate_product",
            after_create="index_for_search",
            before_update="check_price_change",
            expose=True,
            delivery_overrides=DeliveryOverrides(
                rest_tags=["products"],
                page_size=20,
                subscriptions=True,
            ),
            mcp_overrides=MCPOverrides(tool_prefix="product"),
            frontend_overrides=FrontendOverrides(
                nav_label="Products",
                nav_icon="package",
                table_columns=["name", "sku", "category", "price", "stock_quantity"],
                form_layout="vertical",
            ),
        ),
        # ==================================================================
        # VARIANT
        # Child entity for nested create — hidden from navigation.
        # ==================================================================
        ModelSpec(
            name="Variant",
            description="A product variant (size, color, etc.)",
            timestamps=True,
            fields=[
                FieldSpec(
                    name="product_id",
                    type=FieldType.FOREIGN_KEY,
                    references="Product",
                    required=True,
                ),
                FieldSpec(
                    name="sku_suffix",
                    type=FieldType.STRING,
                    max_length=30,
                    required=True,
                    label="Variant SKU",
                ),
                FieldSpec(
                    name="color",
                    type=FieldType.STRING,
                    max_length=50,
                    required=False,
                ),
                FieldSpec(
                    name="size",
                    type=FieldType.ENUM,
                    enum_values=["xs", "s", "m", "l", "xl", "xxl", "one_size"],
                    default="one_size",
                ),
                FieldSpec(
                    name="price_override",
                    type=FieldType.DECIMAL,
                    precision=10,
                    scale=2,
                    min_value=0,
                    required=False,
                    ui_widget="currency",
                    description="Leave blank to use the base product price",
                ),
                FieldSpec(
                    name="stock_quantity",
                    type=FieldType.INTEGER,
                    min_value=0,
                    default=0,
                ),
                FieldSpec(
                    name="is_available",
                    type=FieldType.BOOLEAN,
                    default=True,
                ),
            ],
            relationships=[
                RelationshipSpec(
                    name="product",
                    target_model="Product",
                    type="many_to_one",
                    back_populates="variants",
                ),
            ],
            expose=True,
            delivery_overrides=DeliveryOverrides(rest_tags=["variants"]),
            frontend_overrides=FrontendOverrides(
                include_in_nav=False,
            ),
        ),
        # ==================================================================
        # PRICE SNAPSHOT
        # Temporal / time-series — tracks product price changes over time.
        # Read-only (create + read + list), no update/delete.
        # ==================================================================
        ModelSpec(
            name="PriceSnapshot",
            description="Historical price record for temporal queries",
            timestamps=False,
            fields=[
                FieldSpec(
                    name="product_sku",
                    type=FieldType.STRING,
                    max_length=50,
                    required=True,
                    indexed=True,
                    filter_operators=[FilterOperator.EQ, FilterOperator.IN],
                ),
                FieldSpec(
                    name="price",
                    type=FieldType.DECIMAL,
                    precision=10,
                    scale=2,
                    required=True,
                ),
                FieldSpec(
                    name="currency",
                    type=FieldType.STRING,
                    max_length=3,
                    default="USD",
                ),
                FieldSpec(
                    name="recorded_at",
                    type=FieldType.DATETIME,
                    required=True,
                    indexed=True,
                ),
                FieldSpec(
                    name="source",
                    type=FieldType.STRING,
                    max_length=50,
                    required=False,
                    description="Price feed source",
                ),
            ],
            temporal=TemporalConfig(
                timestamp_field="recorded_at",
                group_by_field="product_sku",
                generate_latest_query=True,
                generate_history_query=True,
            ),
            expose=True,
            operations=["create", "read", "list"],
            delivery_overrides=DeliveryOverrides(rest_tags=["price-history"]),
            mcp_overrides=MCPOverrides(
                tool_prefix="price_snapshot",
                tool_descriptions={
                    "list": "Query price history for a product",
                    "read": "Get a specific price snapshot",
                },
            ),
            frontend_overrides=FrontendOverrides(
                nav_label="Price History",
                nav_icon="trending-up",
            ),
        ),
        # ==================================================================
        # REVIEW
        # Read-only model — no mutations via API, demonstrates operations
        # subset and limited exposure.
        # ==================================================================
        ModelSpec(
            name="Review",
            description="Product review — read-only via API",
            timestamps=True,
            fields=[
                FieldSpec(
                    name="product_id",
                    type=FieldType.FOREIGN_KEY,
                    references="Product",
                    required=True,
                    indexed=True,
                ),
                FieldSpec(
                    name="reviewer_name",
                    type=FieldType.STRING,
                    max_length=100,
                    required=True,
                    searchable=True,
                ),
                FieldSpec(
                    name="rating",
                    type=FieldType.INTEGER,
                    min_value=1,
                    max_value=5,
                    required=True,
                    filter_operators=[FilterOperator.EQ, FilterOperator.GTE, FilterOperator.LTE],
                ),
                FieldSpec(
                    name="comment",
                    type=FieldType.TEXT,
                    required=False,
                    searchable=True,
                ),
                FieldSpec(
                    name="is_verified",
                    type=FieldType.BOOLEAN,
                    default=False,
                    description="Whether the reviewer purchased the product",
                ),
            ],
            expose=True,
            operations=["read", "list"],
            delivery_overrides=DeliveryOverrides(rest_tags=["reviews"]),
            frontend_overrides=FrontendOverrides(
                nav_label="Reviews",
                nav_icon="star",
            ),
        ),
    ],
)

__all__ = ["stack"]
