"""Workspace configuration for dev containers."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


def normalize_workspace_name(name: str) -> str:
    """Normalize name for use in container/volume/hostname.

    - Lowercase
    - Replace / with -
    - Remove special characters
    - Max 63 chars (DNS limit)
    """
    normalized = name.lower()
    normalized = normalized.replace("/", "-")
    normalized = normalized.replace("_", "-")
    normalized = re.sub(r"[^a-z0-9\-]", "", normalized)
    normalized = re.sub(r"-+", "-", normalized)  # Collapse multiple dashes
    normalized = normalized.strip("-")
    return normalized[:63]


def get_current_branch() -> str | None:
    """Get current git branch name."""
    try:
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def get_project_name_from_dir(project_dir: Path) -> str:
    """Get project name from directory name."""
    return project_dir.name


def _resolve_prisme_src() -> Path | None:
    """Resolve the prisme source directory from the running installation.

    For editable installs (pip install -e), returns the project root.
    For regular installs, returns None (container uses PyPI version).
    """
    try:
        from importlib.metadata import distribution

        dist = distribution("prisme")
        # Check if this is an editable install by looking for direct_url.json
        direct_url = dist.read_text("direct_url.json")
        if direct_url:
            import json

            info = json.loads(direct_url)
            url = info.get("url", "")
            if url.startswith("file://"):
                return Path(url.removeprefix("file://"))
    except Exception as e:
        import logging

        logging.getLogger("prisme").debug("direct_url.json resolution failed: %s", e)

    # Fallback: resolve from prisme package __file__
    try:
        import prisme as _prisme

        pkg_path = Path(_prisme.__file__).resolve()
        # src/prisme/__init__.py -> src/prisme -> src -> project root
        candidate = pkg_path.parent.parent.parent
        if (candidate / "pyproject.toml").exists():
            return candidate
    except Exception as e:
        import logging

        logging.getLogger("prisme").debug("Package path resolution failed: %s", e)

    return None


@dataclass
class WorkspaceConfig:
    """Configuration for a development workspace."""

    project_name: str
    project_dir: Path
    workspace_name: str | None = None
    branch: str | None = None
    include_redis: bool = False
    python_version: str = "3.13"
    node_version: str = "22"
    frontend_path: str | None = "packages/frontend"
    backend_path: str | None = "packages/backend"
    spec_path: str | None = "specs/models.py"
    system_packages: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Initialize computed fields after dataclass init."""
        # Auto-detect branch if not provided
        if self.branch is None:
            self.branch = get_current_branch()

        # Generate workspace name if not provided
        if self.workspace_name is None:
            if self.branch:
                self.workspace_name = f"{self.project_name}-{self.branch}"
            else:
                self.workspace_name = self.project_name

        # Normalize the workspace name
        self.workspace_name = normalize_workspace_name(self.workspace_name)

    @property
    def prisme_src(self) -> Path | None:
        """Resolved path to prisme source directory, if editable install."""
        return _resolve_prisme_src()

    @property
    def database_name(self) -> str:
        """Database name (underscores for postgres compatibility)."""
        assert self.workspace_name is not None  # Set in __post_init__
        return self.workspace_name.replace("-", "_")

    @property
    def hostname(self) -> str:
        """Hostname for Traefik routing."""
        assert self.workspace_name is not None  # Set in __post_init__
        return self.workspace_name

    @property
    def devcontainer_dir(self) -> Path:
        """Path to .devcontainer directory."""
        return self.project_dir / ".devcontainer"

    @property
    def env_file(self) -> Path:
        """Path to .env file."""
        return self.devcontainer_dir / ".env"

    @property
    def compose_file(self) -> Path:
        """Path to docker-compose.yml file (VS Code config)."""
        return self.devcontainer_dir / "docker-compose.yml"

    @property
    def stack_compose_file(self) -> Path:
        """Path to docker-compose.stack.yml file (devstack orchestration)."""
        return self.devcontainer_dir / "docker-compose.stack.yml"

    @property
    def prisme_uv_mount_target(self) -> str | None:
        """Container path where uv expects prisme, from pyproject.toml [tool.uv.sources]."""
        if not self.backend_path:
            return None
        try:
            import posixpath
            import tomllib

            pyproject = self.project_dir / self.backend_path / "pyproject.toml"
            if not pyproject.exists():
                return None
            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
            rel_path = (
                data.get("tool", {}).get("uv", {}).get("sources", {}).get("prisme", {}).get("path")
            )
            if not rel_path:
                return None
            container_backend = posixpath.join("/workspace", self.backend_path)
            resolved = posixpath.normpath(posixpath.join(container_backend, rel_path))
            # Only return if the resolved path is inside /workspace
            if resolved.startswith("/workspace/"):
                return resolved
            return None
        except Exception:
            return None

    @classmethod
    def from_directory(
        cls,
        project_dir: Path | None = None,
        workspace_name: str | None = None,
        include_redis: bool = False,
    ) -> WorkspaceConfig:
        """Create config from project directory.

        Args:
            project_dir: Project directory (defaults to cwd)
            workspace_name: Custom workspace name (defaults to project-branch)
            include_redis: Include Redis service

        Returns:
            WorkspaceConfig instance
        """
        project_dir = project_dir or Path.cwd()
        project_name = get_project_name_from_dir(project_dir)

        # Check for frontend directory
        frontend_path: str | None = None
        for candidate in ["packages/frontend", "frontend", "web", "client"]:
            if (project_dir / candidate / "package.json").exists():
                frontend_path = candidate
                break

        # Check for backend directory
        backend_path: str | None = None
        for candidate in ["packages/backend", "backend", "api", "."]:
            if (project_dir / candidate / "pyproject.toml").exists():
                backend_path = candidate
                break

        # Check for spec file
        spec_path: str | None = None
        for candidate in ["specs/models.py", "spec.py", "specs/stack.py"]:
            if (project_dir / candidate).exists():
                spec_path = candidate
                break

        # Load system_packages from project spec if available
        system_packages: list[str] = []
        for spec_candidate in ["specs/project.py", "spec.py"]:
            spec_file = project_dir / spec_candidate
            if spec_file.exists():
                try:
                    from prisme.utils.spec_loader import load_project_spec

                    project_spec = load_project_spec(spec_file)
                    if project_spec.docker and project_spec.docker.system_packages:
                        system_packages = list(project_spec.docker.system_packages)
                    if (
                        not include_redis
                        and project_spec.docker
                        and project_spec.docker.include_redis
                    ):
                        include_redis = True
                except Exception:
                    pass
                break

        return cls(
            project_name=project_name,
            project_dir=project_dir,
            workspace_name=workspace_name,
            include_redis=include_redis,
            frontend_path=frontend_path,
            backend_path=backend_path,
            spec_path=spec_path,
            system_packages=system_packages,
        )


@dataclass
class WorkspaceInfo:
    """Information about a running workspace."""

    workspace_name: str
    status: str  # running, exited, etc.
    services: list[str] = field(default_factory=list)
    url: str = ""
    project_dir: str = ""
