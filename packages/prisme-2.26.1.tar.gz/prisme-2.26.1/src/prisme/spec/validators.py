"""Validation helpers for Prism specifications.

This module contains validation logic that requires cross-model context.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from prisme.spec.project import ProjectSpec
    from prisme.spec.stack import StackSpec


def validate_auth_config(stack: StackSpec, project: ProjectSpec | None = None) -> list[str]:
    """Validate authentication configuration consistency.

    For JWT preset, checks that:
    1. User model exists if auth is enabled
    2. User model has required fields (username_field, password_hash, is_active, roles)
    3. password_hash field is excluded from API responses
    4. Default role exists in roles list (if roles are defined)

    For API key preset:
    - No user model validation is required
    - Only validates that auth is properly configured

    Args:
        stack: The complete stack specification
        project: The project specification (auth config lives here in v2)

    Returns:
        List of validation error messages (empty if valid)
    """
    errors: list[str] = []

    # In v2, auth config lives on ProjectSpec
    if project is None:
        from prisme.spec.auth import AuthConfig

        auth = AuthConfig()
    else:
        auth = project.auth

    if not auth.enabled:
        return errors

    # API key auth doesn't require a user model or any of the JWT-specific validations
    if auth.preset == "api_key":
        return errors

    # Find user model (JWT preset only)
    user_model = None
    for model in stack.models:
        if model.name == auth.user_model:
            user_model = model
            break

    if not user_model:
        errors.append(
            f"Authentication is enabled but user model '{auth.user_model}' "
            f"not found in models list. Add a model with name='{auth.user_model}' "
            "or set auth.enabled=False."
        )
        return errors  # Can't continue validation without user model

    # Validate required fields exist
    required_fields = {
        auth.username_field,  # email or username
        "password_hash",
        "is_active",
        "roles",
    }

    model_field_names = {field.name for field in user_model.fields}
    missing = required_fields - model_field_names

    if missing:
        errors.append(
            f"User model '{user_model.name}' is missing required fields for "
            f"authentication: {sorted(missing)}. Add these fields to the model "
            "or disable authentication."
        )

    # Validate password_hash is hidden from API
    password_hash_field = None
    for field in user_model.fields:
        if field.name == "password_hash":
            password_hash_field = field
            break

    if password_hash_field and not password_hash_field.hidden:
        errors.append(
            f"Field 'password_hash' in user model '{user_model.name}' must have "
            "hidden=True to prevent exposure in API responses. This is a critical "
            "security requirement."
        )

    # Validate default role exists in roles list (if roles are defined)
    if auth.roles:
        role_names = {role.name for role in auth.roles}
        if auth.default_role not in role_names:
            errors.append(
                f"Default role '{auth.default_role}' is not defined in "
                f"auth.roles. Either add a role with name='{auth.default_role}' "
                "or change auth.default_role to an existing role."
            )

    return errors


def validate_org_config(stack: StackSpec, project: ProjectSpec | None = None) -> list[str]:
    """Validate organization configuration consistency.

    Checks that:
    1. Auth must be enabled when organization is enabled
    2. Default org role exists in roles list
    3. Organization roles have unique names

    Args:
        stack: The complete stack specification
        project: The project specification

    Returns:
        List of validation error messages (empty if valid)
    """
    errors: list[str] = []

    if project is None:
        return errors

    org = project.auth.organization
    if not org.enabled:
        return errors

    # Auth must be enabled for organizations to work
    if not project.auth.enabled:
        errors.append(
            "Organization management requires authentication to be enabled. "
            "Set auth.enabled=True or disable organization.enabled."
        )

    # Validate org roles are unique
    role_names = [role.name for role in org.roles]
    seen = set()
    for name in role_names:
        if name in seen:
            errors.append(
                f"Duplicate organization role name '{name}'. "
                "Each organization role must have a unique name."
            )
        seen.add(name)

    # Validate default role exists in roles list
    if org.roles:
        valid_role_names = {role.name for role in org.roles}
        if org.default_role not in valid_role_names:
            errors.append(
                f"Default organization role '{org.default_role}' is not defined in "
                f"organization.roles. Either add a role with name='{org.default_role}' "
                "or change organization.default_role to an existing role."
            )

    return errors


def validate_model_relationships(stack: StackSpec) -> list[str]:
    """Validate that all relationship references point to existing models.

    Args:
        stack: The complete stack specification

    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    model_names = {model.name for model in stack.models}

    for model in stack.models:
        for rel in model.relationships:
            if rel.target_model not in model_names:
                errors.append(
                    f"Model '{model.name}' has relationship '{rel.name}' targeting "
                    f"non-existent model '{rel.target_model}'. Available models: "
                    f"{sorted(model_names)}"
                )

    return errors


def validate_privacy_config(stack: StackSpec, project: ProjectSpec | None = None) -> list[str]:
    """Validate GDPR privacy configuration consistency.

    Checks that:
    1. Models marked as personal data have timestamps enabled (needed for retention)
    2. Retention policies require soft_delete when soft_delete_first is True
    3. Models with GDPR config require privacy to be enabled at project level
    4. Organization name is set when privacy is enabled

    Args:
        stack: The complete stack specification
        project: The project specification

    Returns:
        List of validation error messages (empty if valid)
    """
    errors: list[str] = []

    if project is None:
        return errors

    privacy = project.privacy

    # Check models that use GDPR config
    models_with_gdpr = [m for m in stack.models if m.gdpr and m.gdpr.is_personal_data]

    if models_with_gdpr and not privacy.enabled:
        model_names = [m.name for m in models_with_gdpr]
        errors.append(
            f"Models {model_names} have gdpr.is_personal_data=True but "
            "project privacy is not enabled. Set privacy.enabled=True in "
            "your project spec."
        )

    if privacy.enabled and not privacy.organization_name:
        errors.append(
            "privacy.organization_name is required when privacy is enabled. "
            "This is used in generated compliance documentation."
        )

    for model in models_with_gdpr:
        gdpr = model.gdpr
        assert gdpr is not None  # guaranteed by filter above

        # Retention policies need timestamps for age calculation
        if gdpr.retention and not model.timestamps:
            errors.append(
                f"Model '{model.name}' has a retention policy but timestamps=False. "
                "Enable timestamps=True so the retention job can determine record age."
            )

        # soft_delete_first requires the model to have soft_delete enabled
        if gdpr.retention and gdpr.retention.soft_delete_first and not model.soft_delete:
            errors.append(
                f"Model '{model.name}' has retention.soft_delete_first=True but "
                "soft_delete=False. Either enable soft_delete on the model or "
                "set soft_delete_first=False in the retention policy."
            )

    return errors


def validate_stack(stack: StackSpec, project: ProjectSpec | None = None) -> list[str]:
    """Run all validation checks on a stack specification.

    This is the main entry point for validation. It runs all validation
    functions and aggregates errors.

    Args:
        stack: The complete stack specification
        project: The project specification (optional)

    Returns:
        List of all validation error messages (empty if valid)
    """
    errors = []

    # Run all validators
    errors.extend(validate_auth_config(stack, project))
    errors.extend(validate_org_config(stack, project))
    errors.extend(validate_model_relationships(stack))
    errors.extend(validate_privacy_config(stack, project))

    return errors
