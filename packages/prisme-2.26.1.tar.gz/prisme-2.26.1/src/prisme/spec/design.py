"""Design system configuration for Prism.

This module defines the design system configuration including theme,
colors, typography, and component styling options.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class ThemePreset(StrEnum):
    """Available theme presets."""

    NORDIC = "nordic"
    """Clean, muted, sophisticated - slate/sky color palette."""

    MINIMAL = "minimal"
    """Ultra-clean with subtle grays - neutral color palette."""

    CORPORATE = "corporate"
    """Professional blue-based palette - blue/slate colors."""


class IconSet(StrEnum):
    """Available icon libraries."""

    LUCIDE = "lucide"
    """Lucide React - MIT licensed, tree-shakeable, 1400+ icons."""

    HEROICONS = "heroicons"
    """Heroicons - MIT licensed, by Tailwind Labs."""


class FontFamily(StrEnum):
    """Font family presets."""

    INTER = "inter"
    """Inter - Modern, highly legible sans-serif."""

    SYSTEM = "system"
    """System UI fonts - Native look on each platform."""

    GEIST = "geist"
    """Geist - Vercel's modern font family."""


class BorderRadius(StrEnum):
    """Border radius presets."""

    NONE = "none"
    """No border radius - sharp corners."""

    SM = "sm"
    """Small radius - 4px."""

    MD = "md"
    """Medium radius - 8px (default)."""

    LG = "lg"
    """Large radius - 12px."""

    FULL = "full"
    """Full radius - pill shapes."""


class DesignSystemConfig(BaseModel):
    """Design system configuration.

    Controls the visual appearance of generated frontend components
    including theme, colors, typography, and component styling.

    Example:
        >>> config = DesignSystemConfig(
        ...     theme="nordic",
        ...     dark_mode=True,
        ...     icon_set="lucide",
        ...     border_radius="md",
        ... )

        >>> # With custom primary color
        >>> config = DesignSystemConfig(
        ...     theme="minimal",
        ...     primary_color="#2563eb",
        ... )
    """

    # Theme selection
    theme: ThemePreset = Field(
        default=ThemePreset.NORDIC,
        description="Theme preset: 'nordic', 'minimal', or 'corporate'",
    )

    # Color overrides
    primary_color: str | None = Field(
        default=None,
        description="Override primary color (CSS color value or RGB triplet)",
    )
    accent_color: str | None = Field(
        default=None,
        description="Override accent color (CSS color value or RGB triplet)",
    )

    # Dark mode
    dark_mode: bool = Field(
        default=True,
        description="Enable dark mode toggle and styles",
    )
    default_theme: str = Field(
        default="system",
        description="Default theme: 'light', 'dark', or 'system'",
    )

    # Icons
    icon_set: IconSet = Field(
        default=IconSet.LUCIDE,
        description="Icon library to use: 'lucide' or 'heroicons'",
    )

    # Typography
    font_family: FontFamily = Field(
        default=FontFamily.INTER,
        description="Font family preset: 'inter', 'system', or 'geist'",
    )
    custom_font_url: str | None = Field(
        default=None,
        description="Custom font URL (Google Fonts, etc.) - overrides font_family",
    )

    # Component styling
    border_radius: BorderRadius = Field(
        default=BorderRadius.MD,
        description="Border radius preset: 'none', 'sm', 'md', 'lg', or 'full'",
    )
    enable_animations: bool = Field(
        default=True,
        description="Enable transition animations",
    )

    model_config = {"extra": "forbid"}

    def get_theme_palette(self) -> dict[str, str]:
        """Get the full CSS custom property palette for the configured theme.

        Returns a dict of CSS variable names (without --) to RGB triplet values.
        Respects primary_color and accent_color overrides.

        Returns:
            Dict mapping token names to RGB triplet values.
        """
        palettes: dict[ThemePreset, dict[str, str]] = {
            ThemePreset.NORDIC: {
                # Primary - slate-900/800/700
                "color-primary": "15 23 42",
                "color-primary-hover": "30 41 59",
                "color-primary-active": "51 65 85",
                # Secondary - slate-100/200
                "color-secondary": "241 245 249",
                "color-secondary-hover": "226 232 240",
                # Accent - sky-500/600/100
                "color-accent": "14 165 233",
                "color-accent-hover": "2 132 199",
                "color-accent-light": "224 242 254",
                # Surfaces
                "color-background": "255 255 255",
                "color-surface": "248 250 252",
                "color-surface-elevated": "255 255 255",
                "color-surface-sunken": "241 245 249",
                # Text
                "color-text": "15 23 42",
                "color-text-secondary": "71 85 105",
                "color-text-muted": "100 116 139",
                "color-text-placeholder": "148 163 184",
                "color-text-inverse": "255 255 255",
                # Borders
                "color-border": "226 232 240",
                "color-border-light": "241 245 249",
                "color-border-focus": "14 165 233",
                # Dark mode
                "dark-color-primary": "241 245 249",
                "dark-color-primary-hover": "226 232 240",
                "dark-color-primary-active": "203 213 225",
                "dark-color-secondary": "51 65 85",
                "dark-color-secondary-hover": "71 85 105",
                "dark-color-accent": "56 189 248",
                "dark-color-accent-hover": "14 165 233",
                "dark-color-accent-light": "12 74 110",
                "dark-color-background": "15 23 42",
                "dark-color-surface": "30 41 59",
                "dark-color-surface-elevated": "51 65 85",
                "dark-color-surface-sunken": "15 23 42",
                "dark-color-text": "241 245 249",
                "dark-color-text-secondary": "203 213 225",
                "dark-color-text-muted": "148 163 184",
                "dark-color-text-placeholder": "100 116 139",
                "dark-color-text-inverse": "15 23 42",
                "dark-color-border": "71 85 105",
                "dark-color-border-light": "51 65 85",
                "dark-color-border-focus": "56 189 248",
            },
            ThemePreset.MINIMAL: {
                # Primary - neutral-900/800/700
                "color-primary": "23 23 23",
                "color-primary-hover": "38 38 38",
                "color-primary-active": "64 64 64",
                # Secondary - neutral-100/200
                "color-secondary": "245 245 245",
                "color-secondary-hover": "229 229 229",
                # Accent - neutral-600/700/100
                "color-accent": "82 82 82",
                "color-accent-hover": "64 64 64",
                "color-accent-light": "245 245 245",
                # Surfaces
                "color-background": "255 255 255",
                "color-surface": "250 250 250",
                "color-surface-elevated": "255 255 255",
                "color-surface-sunken": "245 245 245",
                # Text
                "color-text": "23 23 23",
                "color-text-secondary": "82 82 82",
                "color-text-muted": "115 115 115",
                "color-text-placeholder": "163 163 163",
                "color-text-inverse": "255 255 255",
                # Borders
                "color-border": "229 229 229",
                "color-border-light": "245 245 245",
                "color-border-focus": "23 23 23",
                # Dark mode
                "dark-color-primary": "245 245 245",
                "dark-color-primary-hover": "229 229 229",
                "dark-color-primary-active": "212 212 212",
                "dark-color-secondary": "64 64 64",
                "dark-color-secondary-hover": "82 82 82",
                "dark-color-accent": "163 163 163",
                "dark-color-accent-hover": "115 115 115",
                "dark-color-accent-light": "38 38 38",
                "dark-color-background": "10 10 10",
                "dark-color-surface": "23 23 23",
                "dark-color-surface-elevated": "38 38 38",
                "dark-color-surface-sunken": "10 10 10",
                "dark-color-text": "245 245 245",
                "dark-color-text-secondary": "212 212 212",
                "dark-color-text-muted": "163 163 163",
                "dark-color-text-placeholder": "115 115 115",
                "dark-color-text-inverse": "23 23 23",
                "dark-color-border": "64 64 64",
                "dark-color-border-light": "38 38 38",
                "dark-color-border-focus": "212 212 212",
            },
            ThemePreset.CORPORATE: {
                # Primary - blue-700/800/900
                "color-primary": "29 78 216",
                "color-primary-hover": "30 64 175",
                "color-primary-active": "30 58 138",
                # Secondary - slate-100/200
                "color-secondary": "241 245 249",
                "color-secondary-hover": "226 232 240",
                # Accent - blue-500/600/50
                "color-accent": "59 130 246",
                "color-accent-hover": "37 99 235",
                "color-accent-light": "239 246 255",
                # Surfaces
                "color-background": "255 255 255",
                "color-surface": "248 250 252",
                "color-surface-elevated": "255 255 255",
                "color-surface-sunken": "241 245 249",
                # Text
                "color-text": "15 23 42",
                "color-text-secondary": "51 65 85",
                "color-text-muted": "100 116 139",
                "color-text-placeholder": "148 163 184",
                "color-text-inverse": "255 255 255",
                # Borders
                "color-border": "226 232 240",
                "color-border-light": "241 245 249",
                "color-border-focus": "59 130 246",
                # Dark mode
                "dark-color-primary": "96 165 250",
                "dark-color-primary-hover": "147 197 253",
                "dark-color-primary-active": "191 219 254",
                "dark-color-secondary": "51 65 85",
                "dark-color-secondary-hover": "71 85 105",
                "dark-color-accent": "96 165 250",
                "dark-color-accent-hover": "59 130 246",
                "dark-color-accent-light": "23 37 84",
                "dark-color-background": "15 23 42",
                "dark-color-surface": "30 41 59",
                "dark-color-surface-elevated": "51 65 85",
                "dark-color-surface-sunken": "15 23 42",
                "dark-color-text": "241 245 249",
                "dark-color-text-secondary": "203 213 225",
                "dark-color-text-muted": "148 163 184",
                "dark-color-text-placeholder": "100 116 139",
                "dark-color-text-inverse": "15 23 42",
                "dark-color-border": "71 85 105",
                "dark-color-border-light": "51 65 85",
                "dark-color-border-focus": "96 165 250",
            },
        }

        palette = dict(palettes[self.theme])

        # Apply user overrides
        if self.primary_color:
            palette["color-primary"] = self.primary_color
        if self.accent_color:
            palette["color-accent"] = self.accent_color

        return palette

    def get_font_css_import(self) -> str | None:
        """Get the CSS import statement for the configured font.

        Returns:
            CSS @import statement or None if using system fonts.
        """
        if self.custom_font_url:
            return f'@import url("{self.custom_font_url}");'

        font_urls = {
            FontFamily.INTER: (
                '@import url("https://fonts.googleapis.com/css2?family=Inter:'
                'wght@400;500;600;700&display=swap");'
            ),
            FontFamily.GEIST: (
                '@import url("https://fonts.googleapis.com/css2?family=Geist:'
                'wght@400;500;600;700&display=swap");'
            ),
            FontFamily.SYSTEM: None,
        }
        return font_urls.get(self.font_family)

    def get_font_family_css(self) -> str:
        """Get the CSS font-family value.

        Returns:
            CSS font-family value string.
        """
        font_stacks = {
            FontFamily.INTER: (
                "'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
            ),
            FontFamily.GEIST: (
                "'Geist', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
            ),
            FontFamily.SYSTEM: (
                "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', "
                "Roboto, 'Helvetica Neue', Arial, sans-serif"
            ),
        }
        return font_stacks.get(self.font_family, font_stacks[FontFamily.SYSTEM])

    def get_icon_package(self) -> str:
        """Get the npm package name for the configured icon set.

        Returns:
            npm package name.
        """
        packages = {
            IconSet.LUCIDE: "lucide-react",
            IconSet.HEROICONS: "@heroicons/react",
        }
        return packages[self.icon_set]

    def get_icon_package_version(self) -> str:
        """Get the npm package version for the configured icon set.

        Returns:
            npm package version string.
        """
        versions = {
            IconSet.LUCIDE: "^0.460.0",
            IconSet.HEROICONS: "^2.2.0",
        }
        return versions[self.icon_set]

    def get_radius_css(self) -> str:
        """Get the CSS border-radius value.

        Returns:
            CSS border-radius value.
        """
        radii = {
            BorderRadius.NONE: "0",
            BorderRadius.SM: "0.25rem",
            BorderRadius.MD: "0.5rem",
            BorderRadius.LG: "0.75rem",
            BorderRadius.FULL: "9999px",
        }
        return radii[self.border_radius]
