"""Detect field-level changes in generated SQLAlchemy model files.

Compares old (on-disk) model content with newly generated content to identify
added and removed fields per model class.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from prisme.generators.base import GeneratorResult

# Matches lines like: field_name: Mapped[...]
_FIELD_RE = re.compile(r"^\s+(\w+): Mapped\[")

# Matches class declarations like: class User(Base): or class User(TimestampMixin, Base):
_CLASS_RE = re.compile(r"^class (\w+)\(")

# Matches full field definitions to capture type information
# Example: field_name: Mapped[str] = mapped_column(String(100))
_FIELD_WITH_TYPE_RE = re.compile(r"^\s+(\w+): Mapped\[([\w\[\]|, ]+)\]")

# Matches mapped_column type definitions
# Example: mapped_column(String(100)) or mapped_column(Text())
_MAPPED_COLUMN_TYPE_RE = re.compile(r"mapped_column\((\w+)\(")

# Matches relationship definitions
# Example: orders: Mapped[list["Order"]] = relationship(...)
_RELATIONSHIP_RE = re.compile(r"^\s+(\w+): Mapped\[.*\]\s*=\s*relationship\(")

# Matches index definitions
# Example: __table_args__ = (Index(...), )
_INDEX_RE = re.compile(r"^\s+__table_args__\s*=")


@dataclass
class ModelFieldChange:
    """Describes field-level changes for a single model class."""

    model_name: str
    added: list[str]
    removed: list[str]
    modified: list[str] | None = None  # Fields with type changes


def _extract_fields(content: str) -> dict[str, set[str]]:
    """Extract field names per class from model file content.

    Returns a dict mapping class name to set of field names.
    """
    result: dict[str, set[str]] = {}
    current_class: str | None = None

    for line in content.splitlines():
        class_match = _CLASS_RE.match(line)
        if class_match:
            current_class = class_match.group(1)
            result.setdefault(current_class, set())
            continue

        if current_class:
            field_match = _FIELD_RE.match(line)
            if field_match:
                result[current_class].add(field_match.group(1))

    return result


def _extract_fields_with_types(content: str) -> dict[str, dict[str, str]]:
    """Extract field names and their types per class from model file content.

    Returns a dict mapping class name to dict of field name to type signature.
    Example: {"User": {"id": "int", "name": "str", "email": "str | None"}}

    For fields with mapped_column, includes both Mapped type and column type.
    Example: {"Article": {"content": "str|String"}} for Mapped[str] = mapped_column(String(500))
    """
    result: dict[str, dict[str, str]] = {}
    current_class: str | None = None

    for line in content.splitlines():
        class_match = _CLASS_RE.match(line)
        if class_match:
            current_class = class_match.group(1)
            result.setdefault(current_class, {})
            continue

        if current_class:
            field_match = _FIELD_WITH_TYPE_RE.match(line)
            if field_match:
                field_name = field_match.group(1)
                field_type = field_match.group(2).strip()

                # Also check for mapped_column type
                mapped_col_match = _MAPPED_COLUMN_TYPE_RE.search(line)
                if mapped_col_match:
                    column_type = mapped_col_match.group(1)
                    # Combine both types for comparison
                    field_type = f"{field_type}|{column_type}"

                result[current_class][field_name] = field_type

    return result


def detect_field_changes(
    old_content: str, new_content: str, filename: str = ""
) -> list[ModelFieldChange]:
    """Compare old and new model file content, returning per-class field changes."""
    old_fields = _extract_fields(old_content)
    new_fields = _extract_fields(new_content)
    old_types = _extract_fields_with_types(old_content)
    new_types = _extract_fields_with_types(new_content)

    all_classes = set(old_fields) | set(new_fields)
    changes: list[ModelFieldChange] = []

    for cls in sorted(all_classes):
        old = old_fields.get(cls, set())
        new = new_fields.get(cls, set())
        added = sorted(new - old)
        removed = sorted(old - new)

        # Detect type changes for fields that exist in both versions
        modified: list[str] = []
        common_fields = old & new
        for field in sorted(common_fields):
            old_type = old_types.get(cls, {}).get(field, "")
            new_type = new_types.get(cls, {}).get(field, "")
            if old_type and new_type and old_type != new_type:
                modified.append(field)

        if added or removed or modified:
            changes.append(
                ModelFieldChange(
                    model_name=cls, added=added, removed=removed, modified=modified or None
                )
            )

    return changes


def detect_model_changes(results: GeneratorResult) -> list[ModelFieldChange]:
    """Detect field-level changes across all model files in a GeneratorResult.

    Uses the old_content captured before files were written (stored in GeneratedFile.old_content)
    to compare with the newly generated content. Falls back to reading from disk if old_content
    is not set (for backwards compatibility with tests and direct API usage).
    """
    all_changes: list[ModelFieldChange] = []

    for gen_file in results.files:
        path = gen_file.path if isinstance(gen_file.path, Path) else Path(gen_file.path)

        # Only look at model files (contain Mapped[ patterns)
        if "Mapped[" not in gen_file.content:
            continue

        new_content = gen_file.content

        # Use old_content from GeneratedFile if available (captured before writing)
        if gen_file.old_content is not None:
            old_content = gen_file.old_content
        elif path.exists():
            # Fallback: read from disk (for backwards compatibility)
            try:
                old_content = path.read_text()
            except OSError:
                continue
        else:
            # New file — all fields are "added"
            changes = detect_field_changes("", new_content, str(path))
            all_changes.extend(changes)
            continue

        # Skip if content unchanged
        if old_content == new_content:
            continue

        changes = detect_field_changes(old_content, new_content, str(path))
        all_changes.extend(changes)

    return all_changes
