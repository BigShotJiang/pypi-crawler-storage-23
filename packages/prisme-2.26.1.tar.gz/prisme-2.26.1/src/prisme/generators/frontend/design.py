"""Design system generator for Prism.

Generates design system components including ThemeToggle, Icon wrapper,
and UI component exports for frontend applications.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.design import IconSet
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class DesignSystemGenerator(GeneratorBase):
    """Generator for design system UI components.

    Generates:
    - ThemeToggle.tsx: Dark/light mode toggle component
    - Icon.tsx: Icon wrapper with size props
    - ui/index.ts: UI component exports
    """

    REQUIRED_TEMPLATES = [
        "frontend/components/ThemeToggle.tsx.jinja2",
        "frontend/components/Icon.tsx.jinja2",
        "cli/design-tokens.css.jinja2",
        "cli/tailwind.config.js.jinja2",
        "cli/index.css.jinja2",
        "cli/custom-tokens.css.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        """Initialize the design system generator."""
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.src_path = frontend_base
        self.ui_path = frontend_base / "ui"

        # Initialize template renderer
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate design system component files.

        Returns:
            List of generated files for design system components.
        """
        files: list[GeneratedFile] = []

        design_config = self.design_config

        # Generate CSS design tokens (always overwrite - theme-driven)
        files.append(self._generate_design_tokens_css())

        # Generate Tailwind config
        files.append(self._generate_tailwind_config())

        # Generate index.css (Tailwind directives + component styles)
        files.append(self._generate_index_css())

        # Generate custom tokens file (user customizations, generate once)
        files.append(self._generate_custom_tokens_css())

        # Always generate Icon component
        files.append(self._generate_icon_component())

        # Generate ThemeToggle only if dark mode is enabled
        if design_config.dark_mode:
            files.append(self._generate_theme_toggle())

        # Generate UI index file
        files.append(self._generate_ui_index())

        return files

    def _generate_design_tokens_css(self) -> GeneratedFile:
        """Generate CSS custom properties from the design system config.

        Returns:
            Generated design-tokens.css file.
        """
        palette = self.design_config.get_theme_palette()
        content = self.renderer.render_file(
            "cli/design-tokens.css.jinja2",
            context={"design": palette},
        )

        return GeneratedFile(
            path=self.src_path / "design-tokens.css",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Design system CSS custom properties",
        )

    def _generate_tailwind_config(self) -> GeneratedFile:
        """Generate Tailwind CSS configuration.

        Returns:
            Generated tailwind.config.js file.
        """
        content = self.renderer.render_file(
            "cli/tailwind.config.js.jinja2",
            context={},
        )

        # tailwind.config.js lives at frontend root, one level up from src
        frontend_root = self.src_path.parent
        return GeneratedFile(
            path=frontend_root / "tailwind.config.js",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Tailwind CSS configuration with design token mapping",
        )

    def _generate_index_css(self) -> GeneratedFile:
        """Generate main CSS file with Tailwind directives and component styles.

        Returns:
            Generated index.css file.
        """
        content = self.renderer.render_file(
            "cli/index.css.jinja2",
            context={},
        )

        return GeneratedFile(
            path=self.src_path / "index.css",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Main CSS with Tailwind directives and component styles",
        )

    def _generate_custom_tokens_css(self) -> GeneratedFile:
        """Generate custom tokens override file (user-editable).

        Returns:
            Generated custom-tokens.css file.
        """
        content = self.renderer.render_file(
            "cli/custom-tokens.css.jinja2",
            context={},
        )

        return GeneratedFile(
            path=self.src_path / "custom-tokens.css",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,
            description="Custom design token overrides (user-editable)",
        )

    def _generate_theme_toggle(self) -> GeneratedFile:
        """Generate ThemeToggle component.

        Returns:
            Generated ThemeToggle.tsx file.
        """
        content = self.renderer.render_file(
            "frontend/components/ThemeToggle.tsx.jinja2",
            context={
                "design": self.design_config,
            },
        )

        return GeneratedFile(
            path=self.ui_path / "ThemeToggle.tsx",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,
            description="Theme toggle component for dark/light mode switching",
        )

    def _generate_icon_component(self) -> GeneratedFile:
        """Generate Icon wrapper component.

        Returns:
            Generated Icon.tsx file.
        """
        design_config = self.design_config

        content = self.renderer.render_file(
            "frontend/components/Icon.tsx.jinja2",
            context={
                "design": design_config,
                "icon_set": design_config.icon_set.value,
                "is_lucide": design_config.icon_set == IconSet.LUCIDE,
            },
        )

        return GeneratedFile(
            path=self.ui_path / "Icon.tsx",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,
            description="Icon wrapper component with consistent sizing",
        )

    def _generate_ui_index(self) -> GeneratedFile:
        """Generate UI components index file.

        Returns:
            Generated ui/index.ts file.
        """
        design_config = self.design_config

        exports = [
            "// Design System UI Components",
            "// AUTO-GENERATED BY PRISM",
            "",
            "// Icons",
            "export * from './Icon';",
        ]

        if design_config.dark_mode:
            exports.extend(
                [
                    "",
                    "// Theme",
                    "export { ThemeToggle, useTheme } from './ThemeToggle';",
                ]
            )

        content = "\n".join(exports) + "\n"

        return GeneratedFile(
            path=self.ui_path / "index.ts",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="UI component exports",
        )


__all__ = ["DesignSystemGenerator"]
