"""Blog pages generator for Prism.

Generates a blog listing page and a blog post detail page.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class BlogGenerator(GeneratorBase):
    """Generator for blog page components (listing + post detail)."""

    REQUIRED_TEMPLATES = [
        "frontend/pages/blog.tsx.jinja2",
        "frontend/pages/blog_post.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.pages_path = frontend_base / self.generator_config.pages_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate blog listing and post detail pages."""
        project_title = self.spec.effective_title
        project_description = self.spec.description or f"{project_title} - Built with Prism"
        dark_mode = self.design_config.dark_mode

        context = {
            "project_title": project_title,
            "project_description": project_description,
            "dark_mode": dark_mode,
        }

        files = []
        for template, filename, description in [
            ("frontend/pages/blog.tsx.jinja2", "BlogPage.tsx", "Blog listing page"),
            ("frontend/pages/blog_post.tsx.jinja2", "BlogPostPage.tsx", "Blog post detail page"),
        ]:
            content = self.renderer.render_file(template, context=context)
            files.append(
                GeneratedFile(
                    path=self.pages_path / filename,
                    content=content,
                    strategy=FileStrategy.GENERATE_ONCE,
                    description=description,
                )
            )

        return files


__all__ = ["BlogGenerator"]
