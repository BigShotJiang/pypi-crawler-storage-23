"""Inquiry / Contact form page generator for Prism.

Generates a contact form page for collecting user inquiries.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class InquiryGenerator(GeneratorBase):
    """Generator for the inquiry/contact form page."""

    REQUIRED_TEMPLATES = [
        "frontend/pages/inquiry.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.pages_path = frontend_base / self.generator_config.pages_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate the inquiry/contact form page."""
        project_title = self.spec.effective_title
        dark_mode = self.design_config.dark_mode

        content = self.renderer.render_file(
            "frontend/pages/inquiry.tsx.jinja2",
            context={
                "project_title": project_title,
                "dark_mode": dark_mode,
            },
        )

        return [
            GeneratedFile(
                path=self.pages_path / "InquiryPage.tsx",
                content=content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Inquiry/contact form page",
            ),
        ]


__all__ = ["InquiryGenerator"]
