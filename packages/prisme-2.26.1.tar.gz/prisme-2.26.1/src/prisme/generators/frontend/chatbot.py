"""Chatbot widget generator for Prism.

Generates a floating chatbot widget component.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class ChatbotGenerator(GeneratorBase):
    """Generator for the chatbot widget component."""

    REQUIRED_TEMPLATES = [
        "frontend/components/chatbot.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.components_path = frontend_base / self.generator_config.components_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate the chatbot widget component."""
        project_title = self.spec.effective_title

        content = self.renderer.render_file(
            "frontend/components/chatbot.tsx.jinja2",
            context={
                "project_title": project_title,
            },
        )

        return [
            GeneratedFile(
                path=self.components_path / "ChatbotWidget.tsx",
                content=content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Floating chatbot widget component",
            ),
        ]


__all__ = ["ChatbotGenerator"]
