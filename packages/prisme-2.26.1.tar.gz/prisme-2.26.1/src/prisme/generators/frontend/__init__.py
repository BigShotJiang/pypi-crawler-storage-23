"""Frontend code generators for Prism.

This module contains generators for:
- TypeScript types
- GraphQL operations
- Widget system
- Headless UI hooks
- React components
- React hooks
- Page components
- Router configuration
- Authentication components
- Blog pages
- Inquiry / contact form
- Register interest / waitlist
- SEO components
- Robots.txt / sitemap
- Chatbot widget
- Survey pages
"""

from prisme.generators.frontend.admin import FrontendAdminGenerator
from prisme.generators.frontend.analytics import FrontendAnalyticsGenerator
from prisme.generators.frontend.auth import FrontendAuthGenerator
from prisme.generators.frontend.blog import BlogGenerator
from prisme.generators.frontend.chatbot import ChatbotGenerator
from prisme.generators.frontend.components import ComponentsGenerator
from prisme.generators.frontend.dashboard import DashboardGenerator
from prisme.generators.frontend.design import DesignSystemGenerator
from prisme.generators.frontend.error_pages import ErrorPagesGenerator
from prisme.generators.frontend.graphql_ops import GraphQLOpsGenerator
from prisme.generators.frontend.headless import HeadlessGenerator
from prisme.generators.frontend.hooks import HooksGenerator
from prisme.generators.frontend.inquiry import InquiryGenerator
from prisme.generators.frontend.landing import LandingPageGenerator
from prisme.generators.frontend.marketing import MarketingPagesGenerator
from prisme.generators.frontend.organization import FrontendOrgGenerator
from prisme.generators.frontend.pages import PagesGenerator
from prisme.generators.frontend.profile import ProfilePagesGenerator
from prisme.generators.frontend.register_interest import RegisterInterestGenerator
from prisme.generators.frontend.robots import RobotsGenerator
from prisme.generators.frontend.router import RouterGenerator
from prisme.generators.frontend.search import SearchPageGenerator
from prisme.generators.frontend.seo import SEOGenerator
from prisme.generators.frontend.survey import SurveyGenerator
from prisme.generators.frontend.types import TypeScriptGenerator
from prisme.generators.frontend.widgets import WidgetSystemGenerator

__all__ = [
    "BlogGenerator",
    "ChatbotGenerator",
    "ComponentsGenerator",
    "DashboardGenerator",
    "DesignSystemGenerator",
    "ErrorPagesGenerator",
    "FrontendAdminGenerator",
    "FrontendAnalyticsGenerator",
    "FrontendAuthGenerator",
    "FrontendOrgGenerator",
    "GraphQLOpsGenerator",
    "HeadlessGenerator",
    "HooksGenerator",
    "InquiryGenerator",
    "LandingPageGenerator",
    "MarketingPagesGenerator",
    "PagesGenerator",
    "ProfilePagesGenerator",
    "RegisterInterestGenerator",
    "RobotsGenerator",
    "RouterGenerator",
    "SEOGenerator",
    "SearchPageGenerator",
    "SurveyGenerator",
    "TypeScriptGenerator",
    "WidgetSystemGenerator",
]
