"""Landing page generator for Prism.

Generates a public-facing SaaS landing page when auth is enabled.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class LandingPageGenerator(GeneratorBase):
    """Generator for the public landing page (auth-enabled projects only)."""

    REQUIRED_TEMPLATES = [
        "frontend/pages/landing.tsx.jinja2",
        "frontend/pages/custom/ExampleCustomPage.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.pages_path = frontend_base / self.generator_config.pages_path
        self.custom_pages_path = self.pages_path / "custom"
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate the landing page and example custom page."""
        files = []

        # Generate example custom page (always)
        example_content = self.renderer.render_file(
            "frontend/pages/custom/ExampleCustomPage.tsx.jinja2",
            context={},
        )
        files.append(
            GeneratedFile(
                path=self.custom_pages_path / "ExampleCustomPage.tsx",
                content=example_content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Example custom page",
            )
        )

        # Skip landing page if marketing is enabled (MarketingPagesGenerator handles it)
        if self.marketing_config.enabled:
            return files

        # Generate landing page (only when auth is enabled and marketing is not)
        if not self.auth_config.enabled:
            return files

        project_title = self.spec.effective_title
        project_description = self.spec.description or f"{project_title} - Built with Prism"
        dark_mode = self.design_config.dark_mode

        landing_content = self.renderer.render_file(
            "frontend/pages/landing.tsx.jinja2",
            context={
                "project_title": project_title,
                "project_description": project_description,
                "dark_mode": dark_mode,
                "design_config": self.design_config,
            },
        )

        files.append(
            GeneratedFile(
                path=self.pages_path / "LandingPage.tsx",
                content=landing_content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Landing page",
            )
        )

        return files


__all__ = ["LandingPageGenerator"]
