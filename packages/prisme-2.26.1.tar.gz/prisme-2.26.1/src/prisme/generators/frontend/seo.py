"""SEO components generator for Prism.

Generates SEO head management components (meta tags, Open Graph, JSON-LD).
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class SEOGenerator(GeneratorBase):
    """Generator for SEO components (SEOHead + SEOProvider)."""

    REQUIRED_TEMPLATES = [
        "frontend/components/seo_head.tsx.jinja2",
        "frontend/components/seo_provider.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.components_path = frontend_base / self.generator_config.components_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate SEO component files."""
        project_title = self.spec.effective_title
        project_description = self.spec.description or f"{project_title} - Built with Prism"

        context = {
            "project_title": project_title,
            "project_description": project_description,
        }

        files = []
        for template, filename, description in [
            (
                "frontend/components/seo_head.tsx.jinja2",
                "SEOHead.tsx",
                "SEO head meta tag component",
            ),
            (
                "frontend/components/seo_provider.tsx.jinja2",
                "SEOProvider.tsx",
                "SEO helmet provider wrapper",
            ),
        ]:
            content = self.renderer.render_file(template, context=context)
            files.append(
                GeneratedFile(
                    path=self.components_path / filename,
                    content=content,
                    strategy=FileStrategy.GENERATE_ONCE,
                    description=description,
                )
            )

        return files


__all__ = ["SEOGenerator"]
