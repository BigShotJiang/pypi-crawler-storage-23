"""Robots.txt and sitemap generator for Prism.

Generates robots.txt and a basic sitemap.xml for the frontend public directory.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class RobotsGenerator(GeneratorBase):
    """Generator for robots.txt and sitemap.xml."""

    REQUIRED_TEMPLATES = [
        "frontend/public/robots.txt.jinja2",
        "frontend/public/sitemap.xml.jinja2",
    ]

    # Default paths to disallow for crawlers
    DEFAULT_DISALLOW = [
        "/dashboard",
        "/admin",
        "/api/",
        "/graphql",
        "/settings",
        "/profile",
    ]

    # Default public pages for the sitemap
    DEFAULT_PAGES = [
        {"loc": "/", "changefreq": "weekly", "priority": "1.0"},
        {"loc": "/blog", "changefreq": "daily", "priority": "0.8"},
        {"loc": "/contact", "changefreq": "monthly", "priority": "0.5"},
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        # robots.txt and sitemap go into the frontend public directory
        frontend_base = Path(self.generator_config.frontend_output)
        # public/ is a sibling of src/ in a typical Vite project
        self.public_path = frontend_base.parent / "public"
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate robots.txt and sitemap.xml."""
        files = []

        # Get disallow paths based on marketing config
        disallow_paths = self._get_disallow_paths()

        # robots.txt
        robots_content = self.renderer.render_file(
            "frontend/public/robots.txt.jinja2",
            context={
                "disallow_paths": disallow_paths,
                "sitemap_url": "/sitemap.xml",
            },
        )
        files.append(
            GeneratedFile(
                path=self.public_path / "robots.txt",
                content=robots_content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="robots.txt for search engine crawlers",
            )
        )

        # Get sitemap pages based on marketing config
        sitemap_pages = self._get_sitemap_pages()

        # sitemap.xml
        sitemap_content = self.renderer.render_file(
            "frontend/public/sitemap.xml.jinja2",
            context={
                "urls": sitemap_pages,
            },
        )
        files.append(
            GeneratedFile(
                path=self.public_path / "sitemap.xml",
                content=sitemap_content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="XML sitemap for search engines",
            )
        )

        return files

    def _get_disallow_paths(self) -> list[str]:
        """Get disallow paths based on marketing config."""
        paths = ["/admin", "/api/", "/graphql", "/settings", "/profile"]

        if self.marketing_config.enabled:
            # When marketing is enabled, disallow the entire platform
            paths.append(f"{self.marketing_config.platform_prefix}/*")
        else:
            # Default behavior
            paths.append("/dashboard")

        return paths

    def _get_sitemap_pages(self) -> list[dict]:
        """Get sitemap pages based on marketing config."""
        if not self.marketing_config.enabled:
            return self.DEFAULT_PAGES

        pages = [{"loc": "/", "changefreq": "weekly", "priority": "1.0"}]

        # Add marketing pages to sitemap
        for page in self.marketing_config.pages:
            if page == "landing":
                continue  # Already added as /

            priority = "0.9" if page in ["features", "pricing"] else "0.8"
            changefreq = "monthly" if page in ["features", "pricing", "about"] else "weekly"

            pages.append(
                {
                    "loc": f"/{page}",
                    "changefreq": changefreq,
                    "priority": priority,
                }
            )

        return pages


__all__ = ["RobotsGenerator"]
