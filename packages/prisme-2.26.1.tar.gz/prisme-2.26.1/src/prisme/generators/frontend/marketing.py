"""Marketing website pages generator.

Generates marketing pages and components for SaaS templates when enabled.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy


class MarketingPagesGenerator(GeneratorBase):
    """Generates marketing website pages and components.

    Creates marketing pages (features, pricing, about, contact) and
    supporting layout components (header, footer) for SaaS templates.
    All files use GENERATE_ONCE strategy to allow user customization.
    """

    REQUIRED_TEMPLATES = [
        "frontend/pages/marketing/features.tsx.jinja2",
        "frontend/pages/marketing/pricing.tsx.jinja2",
        "frontend/pages/marketing/about.tsx.jinja2",
        "frontend/pages/marketing/contact.tsx.jinja2",
        "frontend/components/marketing/MarketingLayout.tsx.jinja2",
        "frontend/components/marketing/MarketingHeader.tsx.jinja2",
        "frontend/components/marketing/Footer.tsx.jinja2",
    ]

    def generate_files(self) -> list[GeneratedFile]:
        """Generate marketing files based on config."""
        if not self.marketing_config.enabled:
            return []

        files = []

        # Always generate layout components
        files.extend(self._generate_layouts())

        # Generate pages based on config
        for page in self.marketing_config.pages:
            if page in ["features", "pricing", "about", "contact"]:
                files.append(self._generate_page(page))

        return files

    def _generate_layouts(self) -> list[GeneratedFile]:
        """Generate layout components."""
        files = []

        # MarketingLayout wrapper
        files.append(
            GeneratedFile(
                path=self._get_component_path("marketing/MarketingLayout.tsx"),
                content=self._render_layout(),
                strategy=FileStrategy.GENERATE_ONCE,
                description="Marketing layout wrapper with header and footer",
            )
        )

        # MarketingHeader
        files.append(
            GeneratedFile(
                path=self._get_component_path("marketing/MarketingHeader.tsx"),
                content=self._render_header(),
                strategy=FileStrategy.GENERATE_ONCE,
                description="Marketing site navigation header",
            )
        )

        # Footer
        files.append(
            GeneratedFile(
                path=self._get_component_path("marketing/Footer.tsx"),
                content=self._render_footer(),
                strategy=FileStrategy.GENERATE_ONCE,
                description="Marketing site footer",
            )
        )

        return files

    def _generate_page(self, page: str) -> GeneratedFile:
        """Generate a specific marketing page."""
        page_map = {
            "features": ("Features", "Product features and capabilities"),
            "pricing": ("Pricing", "Pricing plans and tiers"),
            "about": ("About", "About the company"),
            "contact": ("Contact", "Contact form"),
        }

        title, _description = page_map.get(page, (page.title(), f"{page.title()} page"))

        return GeneratedFile(
            path=self._get_page_path(f"marketing/{page}.tsx"),
            content=self._render_page(page),
            strategy=FileStrategy.GENERATE_ONCE,
            description=f"{title} page",
        )

    def _render_layout(self) -> str:
        """Render MarketingLayout component."""
        context = self._get_template_context()
        return self.renderer.render_file(
            "frontend/components/marketing/MarketingLayout.tsx.jinja2",
            context=context,
        )

    def _render_header(self) -> str:
        """Render MarketingHeader component."""
        context = self._get_template_context()
        context["pages"] = self.marketing_config.pages
        context["platform_prefix"] = self.marketing_config.platform_prefix
        return self.renderer.render_file(
            "frontend/components/marketing/MarketingHeader.tsx.jinja2",
            context=context,
        )

    def _render_footer(self) -> str:
        """Render Footer component."""
        context = self._get_template_context()
        context["pages"] = self.marketing_config.pages
        return self.renderer.render_file(
            "frontend/components/marketing/Footer.tsx.jinja2",
            context=context,
        )

    def _render_page(self, page: str) -> str:
        """Render a marketing page."""
        context = self._get_template_context()
        context["page"] = page
        return self.renderer.render_file(
            f"frontend/pages/marketing/{page}.tsx.jinja2",
            context=context,
        )

    def _get_template_context(self) -> dict:
        """Get template rendering context."""
        project_title = (
            self.spec.title if self.spec.title else self.spec.name.replace("-", " ").title()
        )
        project_description = self.spec.description or f"{project_title} - Modern SaaS Platform"

        return {
            "spec": self.spec,
            "project_title": project_title,
            "project_description": project_description,
            "design_config": self.design_config,
            "auth_enabled": self.auth_config.enabled if self.project_spec else False,
            "marketing_config": self.marketing_config,
        }

    def _get_component_path(self, relative_path: str) -> Path:
        """Get full path for a component file."""
        components_path = self.generator_config.components_path
        return Path(components_path) / relative_path

    def _get_page_path(self, relative_path: str) -> Path:
        """Get full path for a page file."""
        pages_path = self.generator_config.pages_path
        return Path(pages_path) / relative_path


__all__ = ["MarketingPagesGenerator"]
