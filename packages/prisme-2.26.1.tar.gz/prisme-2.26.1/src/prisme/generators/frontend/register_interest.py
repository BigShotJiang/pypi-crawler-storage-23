"""Register Interest / Waitlist page generator for Prism.

Generates a pre-launch waitlist signup page.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class RegisterInterestGenerator(GeneratorBase):
    """Generator for the register interest / waitlist page."""

    REQUIRED_TEMPLATES = [
        "frontend/pages/register_interest.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.pages_path = frontend_base / self.generator_config.pages_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate the register interest / waitlist page."""
        project_title = self.spec.effective_title
        project_description = self.spec.description or f"{project_title} - Built with Prism"
        dark_mode = self.design_config.dark_mode

        content = self.renderer.render_file(
            "frontend/pages/register_interest.tsx.jinja2",
            context={
                "project_title": project_title,
                "project_description": project_description,
                "dark_mode": dark_mode,
            },
        )

        return [
            GeneratedFile(
                path=self.pages_path / "RegisterInterestPage.tsx",
                content=content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Register interest / waitlist page",
            ),
        ]


__all__ = ["RegisterInterestGenerator"]
