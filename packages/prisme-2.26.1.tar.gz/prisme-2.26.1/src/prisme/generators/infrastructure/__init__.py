"""Infrastructure code generators for Prism.

This module contains generators for:
- Traefik reverse proxy configuration
- Environment configuration templates
"""

__all__: list[str] = []
