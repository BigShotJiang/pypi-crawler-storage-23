"""Docker build service generator.

Generates CI/CD workflows for building Docker images on different
providers:

- **github**: Build using GitHub Actions (default, free for public repos)
- **hetzner**: Build on a dedicated Hetzner VM (faster, more resources)
- **aws**: Build using AWS CodeBuild + push to ECR
"""

from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, PackageLoader, select_autoescape

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy


class BuildGenerator(GeneratorBase):
    """Generate Docker build service from ProjectSpec.build."""

    def generate_files(self) -> list[GeneratedFile]:
        project_spec = self.context.project_spec
        if project_spec is None or project_spec.build is None:
            return []

        build = project_spec.build

        env = Environment(
            loader=PackageLoader("prisme", "templates/jinja2"),
            autoescape=select_autoescape(),
            trim_blocks=True,
            lstrip_blocks=True,
        )

        files: list[GeneratedFile] = []

        if build.provider == "hetzner":
            template = env.get_template("ci/github/build-hetzner.yml.jinja2")
            content = template.render(
                project_name=project_spec.name,
                registry=build.registry,
                build_server_type=build.build_server_type,
                build_location=build.build_location,
                build_args=build.build_args,
                platforms=build.platforms,
                cache_from=build.cache_from,
            )
            files.append(
                GeneratedFile(
                    path=Path(".github/workflows/build-docker.yml"),
                    content=content,
                    strategy=FileStrategy.GENERATE_ONCE,
                    description="Docker build workflow (Hetzner)",
                )
            )

        elif build.provider == "aws":
            template = env.get_template("ci/github/build-aws.yml.jinja2")
            content = template.render(
                project_name=project_spec.name,
                registry=build.registry,
                aws_region=build.aws_region,
                ecr_repository=build.ecr_repository or project_spec.name,
                build_args=build.build_args,
                platforms=build.platforms,
            )
            files.append(
                GeneratedFile(
                    path=Path(".github/workflows/build-docker.yml"),
                    content=content,
                    strategy=FileStrategy.GENERATE_ONCE,
                    description="Docker build workflow (AWS)",
                )
            )

        else:
            # GitHub Actions native build (default)
            template = env.get_template("ci/github/build-github.yml.jinja2")
            content = template.render(
                project_name=project_spec.name,
                registry=build.registry,
                build_args=build.build_args,
                platforms=build.platforms,
                cache_from=build.cache_from,
            )
            files.append(
                GeneratedFile(
                    path=Path(".github/workflows/build-docker.yml"),
                    content=content,
                    strategy=FileStrategy.GENERATE_ONCE,
                    description="Docker build workflow (GitHub)",
                )
            )

        return files
