"""Alembic migration generator for Prism.

This generator creates Alembic configuration for database migrations including:
- alembic.ini configuration file
- alembic/env.py with async SQLAlchemy support
- alembic/script.py.mako migration template
- alembic/versions/ directory for migrations
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class AlembicGenerator(GeneratorBase):
    """Generates Alembic configuration for database migrations."""

    REQUIRED_TEMPLATES = [
        "backend/alembic/alembic.ini.jinja2",
        "backend/alembic/env.py.jinja2",
        "backend/alembic/script.py.mako.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)

        # Initialize template renderer
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

        # Setup paths for generated alembic files
        alembic_base = Path(self.generator_config.alembic_path)
        self.backend_base = alembic_base
        self.alembic_dir = alembic_base / "alembic"
        self.versions_dir = self.alembic_dir / "versions"

        # Package name for imports
        self.package_name = self.get_package_name()

    def generate_files(self) -> list[GeneratedFile]:
        """Generate all Alembic configuration files.

        If alembic.ini already exists at the target location, only regenerate
        env.py (ALWAYS_OVERWRITE) to keep it in sync with models.  The other
        files (alembic.ini, script.py.mako, versions/README) are skipped so
        that manual customizations are preserved.

        Returns:
            List of generated files with content and strategies
        """
        files = []

        alembic_ini_path = self.output_dir / self.backend_base / "alembic.ini"
        existing = alembic_ini_path.exists()

        if not existing:
            files.append(self._generate_alembic_ini())

        # env.py is ALWAYS_OVERWRITE — must stay in sync with models
        files.append(self._generate_env_py())

        if not existing:
            files.append(self._generate_script_mako())
            files.append(self._generate_versions_readme())

        return files

    def _generate_alembic_ini(self) -> GeneratedFile:
        """Generate alembic.ini configuration file.

        Returns:
            GeneratedFile for alembic.ini
        """
        content = self.renderer.render_file(
            "backend/alembic/alembic.ini.jinja2",
            context={
                "project_name": self.package_name,
            },
        )

        return GeneratedFile(
            path=self.backend_base / "alembic.ini",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,  # Allow user customization
            description="Alembic configuration",
        )

    def _generate_env_py(self) -> GeneratedFile:
        """Generate alembic/env.py with async SQLAlchemy support.

        Returns:
            GeneratedFile for alembic/env.py
        """
        # Get all model names for imports
        model_names = [model.name for model in self.spec.models]

        # Check if async driver is enabled
        async_driver = self.database_config.async_driver

        # Check if auth/admin features are enabled (need extra model imports)
        auth_enabled = self.auth_config and self.auth_config.enabled
        admin_enabled = (
            auth_enabled and self.auth_config.admin_panel and self.auth_config.admin_panel.enabled
        )

        content = self.renderer.render_file(
            "backend/alembic/env.py.jinja2",
            context={
                "package_name": self.package_name,
                "models": model_names,
                "async_driver": async_driver,
                "auth_enabled": auth_enabled,
                "admin_enabled": admin_enabled,
            },
        )

        return GeneratedFile(
            path=self.alembic_dir / "env.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,  # Keep in sync with models
            description="Alembic environment configuration",
        )

    def _generate_script_mako(self) -> GeneratedFile:
        """Generate alembic/script.py.mako template.

        Returns:
            GeneratedFile for alembic/script.py.mako
        """
        content = self.renderer.render_file(
            "backend/alembic/script.py.mako.jinja2",
            context={},
        )

        return GeneratedFile(
            path=self.alembic_dir / "script.py.mako",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,  # Allow user customization
            description="Alembic migration script template",
        )

    def _generate_versions_readme(self) -> GeneratedFile:
        """Generate a README in versions directory to ensure it's created.

        Returns:
            GeneratedFile for alembic/versions/README
        """
        content = """# Alembic Migrations

This directory contains database migration scripts generated by Alembic.

## Creating Migrations

Generate a new migration based on model changes:

```bash
prism db migrate -m "description of changes"
```

Or using alembic directly:

```bash
uv run alembic revision --autogenerate -m "description of changes"
```

## Applying Migrations

Apply all pending migrations:

```bash
prism db migrate
```

Or using alembic directly:

```bash
uv run alembic upgrade head
```

## Reverting Migrations

Revert the last migration:

```bash
uv run alembic downgrade -1
```

Revert all migrations:

```bash
uv run alembic downgrade base
```
"""

        return GeneratedFile(
            path=self.versions_dir / "README",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,
            description="Alembic versions directory readme",
        )


__all__ = ["AlembicGenerator"]
