"""Golden E2E tests — Tier 1: Generated backend + frontend tests.

Pipeline: prisme create → prisme generate → prisme devcontainer up →
          prisme devcontainer test → prisme devcontainer down

Validates that generated test suites actually pass when executed inside
the devcontainer (with PostgreSQL, deps, migrations all handled by setup.sh).

Markers: e2e, docker
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.e2e.conftest import (
    devcontainer_down,
    devcontainer_test,
    devcontainer_up,
    ensure_docker_network,
    skip_if_no_docker,
)
from tests.e2e.test_template_golden import TEMPLATE_CONFIGS, _get_project

# All templates for backend tests
ALL_TEMPLATES = [t[0] for t in TEMPLATE_CONFIGS]

# Only templates with frontend
FRONTEND_TEMPLATE_LIST = [t[0] for t in TEMPLATE_CONFIGS if t[2]]


@pytest.fixture(scope="module")
def golden_base_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Shared temporary directory for golden test projects."""
    return tmp_path_factory.mktemp("golden_tests")


@pytest.mark.e2e
@pytest.mark.docker
class TestGeneratedBackendTests:
    """Run generated backend pytest suites for each template via devcontainer."""

    @pytest.mark.parametrize("template", ALL_TEMPLATES, ids=ALL_TEMPLATES)
    @pytest.mark.timeout(600)
    def test_generated_backend_tests_pass(
        self,
        golden_base_dir: Path,
        template: str,
    ) -> None:
        """Backend pytest passes inside the devcontainer."""
        skip_if_no_docker()
        ensure_docker_network()

        project_dir = _get_project(template, golden_base_dir)
        try:
            devcontainer_up(project_dir, template)
            result = devcontainer_test(project_dir, template, "--backend-only")
            assert result.returncode == 0, (
                f"Generated backend tests failed for template '{template}':\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )
        finally:
            devcontainer_down(project_dir, template)


@pytest.mark.e2e
@pytest.mark.docker
class TestGeneratedFrontendTests:
    """Run generated frontend test suites for templates with a frontend."""

    @pytest.mark.parametrize("template", FRONTEND_TEMPLATE_LIST, ids=FRONTEND_TEMPLATE_LIST)
    @pytest.mark.timeout(600)
    def test_generated_frontend_tests_pass(
        self,
        golden_base_dir: Path,
        template: str,
    ) -> None:
        """Frontend tests (vitest) pass inside the devcontainer."""
        skip_if_no_docker()
        ensure_docker_network()

        project_dir = _get_project(template, golden_base_dir)
        try:
            devcontainer_up(project_dir, template)
            result = devcontainer_test(project_dir, template, "--frontend-only")
            assert result.returncode == 0, (
                f"Generated frontend tests failed for template '{template}':\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )
        finally:
            devcontainer_down(project_dir, template)
