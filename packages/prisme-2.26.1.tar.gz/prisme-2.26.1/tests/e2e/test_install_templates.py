"""E2E tests for dependency and install template features.

Tests:
- .python-version file generation
- .nvmrc file generation
- INSTALL.md file generation
- README links to INSTALL.md
- prism install command functionality
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.e2e.conftest import get_prism_command, run_command


@pytest.mark.e2e
class TestInstallTemplates:
    """Test dependency and install template features."""

    @pytest.fixture(scope="class")
    def minimal_project(self, tmp_path_factory: pytest.TempPathFactory) -> Path:
        """Create a minimal project for testing."""
        base_dir = tmp_path_factory.mktemp("install_test_minimal")
        run_command(
            [
                *get_prism_command(),
                "create",
                "test-minimal",
                "--template",
                "minimal",
                "--no-install",
                "--no-git",
                "-y",
            ],
            cwd=base_dir,
        )
        return base_dir / "test-minimal"

    @pytest.fixture(scope="class")
    def api_project(self, tmp_path_factory: pytest.TempPathFactory) -> Path:
        """Create an API project for testing."""
        base_dir = tmp_path_factory.mktemp("install_test_api")
        run_command(
            [
                *get_prism_command(),
                "create",
                "test-api",
                "--template",
                "api-only",
                "--no-install",
                "--no-git",
                "-y",
            ],
            cwd=base_dir,
        )
        return base_dir / "test-api"

    @pytest.fixture(scope="class")
    def monorepo_project(self, tmp_path_factory: pytest.TempPathFactory) -> Path:
        """Create a monorepo project for testing."""
        base_dir = tmp_path_factory.mktemp("install_test_monorepo")
        run_command(
            [
                *get_prism_command(),
                "create",
                "test-website",
                "--template",
                "website",
                "--no-install",
                "--no-git",
                "-y",
            ],
            cwd=base_dir,
        )
        return base_dir / "test-website"

    def test_python_version_minimal(self, minimal_project: Path) -> None:
        """.python-version file is generated in minimal project."""
        python_version_file = minimal_project / ".python-version"
        assert python_version_file.exists()
        content = python_version_file.read_text()
        assert "3.13" in content

    def test_python_version_api(self, api_project: Path) -> None:
        """.python-version file is generated in API project."""
        python_version_file = api_project / ".python-version"
        assert python_version_file.exists()
        content = python_version_file.read_text()
        assert "3.13" in content

    def test_python_version_monorepo(self, monorepo_project: Path) -> None:
        """.python-version file is generated in monorepo project."""
        python_version_file = monorepo_project / ".python-version"
        assert python_version_file.exists()
        content = python_version_file.read_text()
        assert "3.13" in content

    def test_nvmrc_not_in_minimal(self, minimal_project: Path) -> None:
        """.nvmrc file is NOT generated in minimal project (no frontend)."""
        nvmrc_file = minimal_project / ".nvmrc"
        assert not nvmrc_file.exists()

    def test_nvmrc_not_in_api(self, api_project: Path) -> None:
        """.nvmrc file is NOT generated in API project (no frontend)."""
        nvmrc_file = api_project / ".nvmrc"
        assert not nvmrc_file.exists()

    def test_nvmrc_in_monorepo(self, monorepo_project: Path) -> None:
        """.nvmrc file is generated in monorepo project (has frontend)."""
        nvmrc_file = monorepo_project / ".nvmrc"
        assert nvmrc_file.exists()
        content = nvmrc_file.read_text()
        assert "22" in content

    def test_install_md_minimal(self, minimal_project: Path) -> None:
        """INSTALL.md file is generated in minimal project."""
        install_file = minimal_project / "INSTALL.md"
        assert install_file.exists()
        content = install_file.read_text()
        assert "Installation Guide" in content
        assert "Prerequisites" in content
        assert "Quick Start" in content
        assert "Troubleshooting" in content

    def test_install_md_api(self, api_project: Path) -> None:
        """INSTALL.md file is generated in API project."""
        install_file = api_project / "INSTALL.md"
        assert install_file.exists()
        content = install_file.read_text()
        assert "Installation Guide" in content
        assert "Troubleshooting" in content

    def test_install_md_monorepo(self, monorepo_project: Path) -> None:
        """INSTALL.md file is generated in monorepo project."""
        install_file = monorepo_project / "INSTALL.md"
        assert install_file.exists()
        content = install_file.read_text()
        assert "Installation Guide" in content
        assert "Troubleshooting" in content

    def test_install_md_has_troubleshooting(self, minimal_project: Path) -> None:
        """INSTALL.md includes troubleshooting section with common errors."""
        install_file = minimal_project / "INSTALL.md"
        content = install_file.read_text()

        # Check for troubleshooting section
        assert "## Troubleshooting" in content

        # Check for common error solutions
        assert "uv not found" in content
        assert "PostgreSQL connection error" in content
        assert "Python version mismatch" in content

    def test_install_md_has_helpful_solutions(self, api_project: Path) -> None:
        """INSTALL.md includes helpful installation commands in errors."""
        install_file = api_project / "INSTALL.md"
        content = install_file.read_text()

        # Check for installation commands
        assert "curl -LsSf https://astral.sh/uv/install.sh" in content
        assert "brew install" in content or "pyenv install" in content

    def test_readme_links_to_install_minimal(self, minimal_project: Path) -> None:
        """README in minimal project links to INSTALL.md."""
        readme_file = minimal_project / "README.md"
        assert readme_file.exists()
        content = readme_file.read_text()
        assert "INSTALL.md" in content

    def test_readme_links_to_install_api(self, api_project: Path) -> None:
        """README in API project links to INSTALL.md."""
        readme_file = api_project / "README.md"
        assert readme_file.exists()
        content = readme_file.read_text()
        assert "INSTALL.md" in content

    def test_readme_links_to_install_monorepo(self, monorepo_project: Path) -> None:
        """README in monorepo project links to INSTALL.md."""
        readme_file = monorepo_project / "README.md"
        assert readme_file.exists()
        content = readme_file.read_text()
        assert "INSTALL.md" in content


@pytest.mark.e2e
class TestInstallCommand:
    """Test the prism install command functionality."""

    @pytest.fixture(scope="class")
    def test_project(self, tmp_path_factory: pytest.TempPathFactory) -> Path:
        """Create a test project without installing dependencies."""
        base_dir = tmp_path_factory.mktemp("install_cmd_test")
        run_command(
            [
                *get_prism_command(),
                "create",
                "test-install",
                "--template",
                "minimal",
                "--no-install",
                "--no-git",
                "-y",
            ],
            cwd=base_dir,
        )
        return base_dir / "test-install"

    def test_install_command_exists(self, test_project: Path) -> None:
        """prism install command runs without error."""
        result = run_command(
            [*get_prism_command(), "install", "--help"],
            cwd=test_project,
        )
        assert result.returncode == 0
        assert "Install project dependencies" in result.stdout

    def test_install_has_backend_only_flag(self, test_project: Path) -> None:
        """prism install supports --backend-only flag."""
        result = run_command(
            [*get_prism_command(), "install", "--help"],
            cwd=test_project,
        )
        assert "--backend-only" in result.stdout

    def test_install_has_frontend_only_flag(self, test_project: Path) -> None:
        """prism install supports --frontend-only flag."""
        result = run_command(
            [*get_prism_command(), "install", "--help"],
            cwd=test_project,
        )
        assert "--frontend-only" in result.stdout

    def test_install_detects_package_manager(self, test_project: Path) -> None:
        """prism install detects and reports the package manager."""
        # Note: This test may fail in CI if uv is not installed
        # We test that the command runs and produces output, not that it succeeds
        result = run_command(
            [*get_prism_command(), "install", "--backend-only"],
            cwd=test_project,
            check=False,  # Don't fail if deps aren't actually installed
        )
        # Should mention the package manager being used
        assert (
            "uv" in result.stdout
            or "pip" in result.stdout
            or "poetry" in result.stdout
            or "pdm" in result.stdout
        )

    def test_install_shows_progress(self, test_project: Path) -> None:
        """prism install shows progress messages."""
        result = run_command(
            [*get_prism_command(), "install", "--backend-only"],
            cwd=test_project,
            check=False,
        )
        # Should show progress indicators
        assert "Installing dependencies" in result.stdout or "Installing" in result.stdout

    def test_install_helpful_error_for_missing_manager(
        self, tmp_path_factory: pytest.TempPathFactory
    ) -> None:
        """prism install provides helpful error when package manager is missing."""
        # Create a project in an environment where we can simulate missing tools
        base_dir = tmp_path_factory.mktemp("missing_manager_test")
        run_command(
            [
                *get_prism_command(),
                "create",
                "test-missing",
                "--template",
                "minimal",
                "--no-install",
                "--no-git",
                "-y",
            ],
            cwd=base_dir,
        )
        project_dir = base_dir / "test-missing"

        # Run install - if it fails due to missing manager, check error message
        result = run_command(
            [*get_prism_command(), "install", "--backend-only"],
            cwd=project_dir,
            check=False,
        )

        # If the command failed, it should have a helpful error message
        if result.returncode != 0:
            output = result.stdout + result.stderr
            # Should suggest how to install the missing tool
            assert (
                "curl -LsSf https://astral.sh/uv/install.sh" in output
                or "Install" in output
                or "not found" in output
            )
