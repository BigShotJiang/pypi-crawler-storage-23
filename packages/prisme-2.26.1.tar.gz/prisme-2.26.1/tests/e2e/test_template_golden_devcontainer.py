"""Golden E2E tests — Tier 3: Devcontainer smoke tests.

Pipeline: prisme create → prisme generate → prisme devcontainer up →
          prisme devcontainer dev (background) → health checks →
          prisme devcontainer down

Validates devcontainer lifecycle and that dev servers start and respond.

Markers: e2e, docker
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.e2e.conftest import (
    devcontainer_down,
    devcontainer_exec_background,
    devcontainer_health_check,
    devcontainer_up,
    ensure_docker_network,
    has_frontend,
    skip_if_no_docker,
)
from tests.e2e.test_template_golden import TEMPLATE_CONFIGS, _get_project

ALL_TEMPLATES = [t[0] for t in TEMPLATE_CONFIGS]

# Timeout for container startup + dev servers + health checks
DEVCONTAINER_TIMEOUT = 300  # 5 minutes


@pytest.fixture(scope="module")
def golden_base_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Shared temporary directory for devcontainer golden tests."""
    return tmp_path_factory.mktemp("golden_devcontainer")


@pytest.mark.e2e
@pytest.mark.docker
class TestDevcontainerSmoke:
    """Verify devcontainer lifecycle and dev server health for each template."""

    @pytest.mark.parametrize("template", ALL_TEMPLATES, ids=ALL_TEMPLATES)
    @pytest.mark.timeout(DEVCONTAINER_TIMEOUT)
    def test_devcontainer_smoke(
        self,
        golden_base_dir: Path,
        template: str,
    ) -> None:
        """Devcontainer starts, dev servers respond, and tears down cleanly."""
        skip_if_no_docker()
        ensure_docker_network()

        project_dir = _get_project(template, golden_base_dir)
        try:
            # Start devcontainer (setup.sh installs deps, generates, migrates)
            devcontainer_up(project_dir, template)

            # Start dev servers in the background inside the container
            devcontainer_exec_background(project_dir, template, "prisme dev --skip-port-check")

            # Health check: backend (all templates have a backend)
            assert devcontainer_health_check(
                project_dir, template, "/health", retries=30, interval=3.0
            ) or devcontainer_health_check(
                project_dir, template, "/docs", retries=10, interval=2.0
            ), f"Backend health check failed for template '{template}'"

            # Health check: frontend (only monorepo templates)
            if has_frontend(template):
                assert devcontainer_health_check(
                    project_dir, template, "/", retries=30, interval=3.0
                ), f"Frontend health check failed for template '{template}'"

        finally:
            # Always tear down, even on failure
            devcontainer_down(project_dir, template)
