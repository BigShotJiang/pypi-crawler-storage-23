"""Golden E2E tests — Tier 4: Playwright browser smoke tests.

Pipeline: prisme create → prisme generate → prisme devcontainer up →
          prisme devcontainer dev (background) → Playwright CRUD smoke →
          prisme devcontainer down

Validates full CRUD flow via browser for templates with a frontend.
Requires Traefik proxy for host-accessible URLs.

Markers: e2e, docker, slow
"""

from __future__ import annotations

import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import pytest

from tests.e2e.conftest import (
    devcontainer_down,
    devcontainer_exec_background,
    devcontainer_health_check,
    devcontainer_up,
    ensure_docker_network,
    get_workspace_url,
    skip_if_no_docker,
)
from tests.e2e.test_template_golden import TEMPLATE_CONFIGS, _get_project

# Only templates with frontend
FRONTEND_TEMPLATE_LIST = [t[0] for t in TEMPLATE_CONFIGS if t[2]]

# Timeout for Playwright tests per template
PLAYWRIGHT_TIMEOUT = 180  # 3 minutes

# Map template → first model name (for CRUD testing)
TEMPLATE_FIRST_MODEL: dict[str, str] = {
    "website": "Page",
    "app": "Task",
    "enterprise-platform": "Project",
    "saas": "Plan",
}


def _check_playwright_available() -> bool:
    """Check if Playwright and browsers are installed."""
    try:
        import playwright  # noqa: F401
    except ImportError:
        return False

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            browser.close()
        return True
    except Exception:
        return False


def _start_traefik_proxy() -> None:
    """Start the Traefik proxy for host-accessible workspace URLs."""
    from prisme.docker.proxy import ProxyManager

    proxy = ProxyManager()
    proxy.start()

    # Wait for Traefik API to be ready (dashboard on port 8080)
    for _ in range(15):
        try:
            with urlopen("http://localhost:8080/api/overview", timeout=2) as resp:
                if resp.status == 200:
                    return
        except (URLError, TimeoutError, OSError):
            pass
        time.sleep(1)


def _stop_traefik_proxy() -> None:
    """Stop the Traefik proxy."""
    from prisme.docker.proxy import ProxyManager

    proxy = ProxyManager()
    proxy.stop()


def _wait_for_host_route(workspace_url: str, retries: int = 20, interval: float = 2.0) -> None:
    """Wait for Traefik to discover and serve the workspace route from the host.

    After the container health check passes (from inside), Traefik still needs time
    to discover the container labels and create routes. This polls the workspace URL
    from the host to confirm end-to-end connectivity.
    """
    for attempt in range(retries):
        try:
            with urlopen(f"{workspace_url}/", timeout=3) as resp:
                if resp.status == 200:
                    return
        except (URLError, TimeoutError, OSError):
            pass
        if attempt < retries - 1:
            time.sleep(interval)
    # Don't assert here — let Playwright provide the actual failure message


@pytest.fixture(scope="module")
def golden_base_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Shared temporary directory for Playwright golden tests."""
    return tmp_path_factory.mktemp("golden_playwright")


@pytest.mark.e2e
@pytest.mark.docker
@pytest.mark.slow
class TestPlaywrightCrudSmoke:
    """Browser-based CRUD smoke tests for frontend templates."""

    @pytest.mark.parametrize("template", FRONTEND_TEMPLATE_LIST, ids=FRONTEND_TEMPLATE_LIST)
    @pytest.mark.timeout(PLAYWRIGHT_TIMEOUT)
    def test_playwright_crud_smoke(
        self,
        golden_base_dir: Path,
        template: str,
        tmp_path: Path,
    ) -> None:
        """Full CRUD smoke: page load → list → create → read → update → delete."""
        skip_if_no_docker()
        ensure_docker_network()

        if not _check_playwright_available():
            pytest.skip("Playwright browsers not installed")

        from playwright.sync_api import sync_playwright

        project_dir = _get_project(template, golden_base_dir)
        model_name = TEMPLATE_FIRST_MODEL[template]
        model_slug = model_name.lower() + "s"  # Simple pluralization
        workspace_url = get_workspace_url(template)
        screenshots_dir = tmp_path / "screenshots"
        screenshots_dir.mkdir(exist_ok=True)

        try:
            # Start Traefik proxy for host-accessible URLs
            _start_traefik_proxy()

            # Start devcontainer
            devcontainer_up(project_dir, template)

            # Start dev servers in background
            devcontainer_exec_background(project_dir, template, "prisme dev --skip-port-check")

            # Wait for services to be ready (check from inside container)
            assert devcontainer_health_check(
                project_dir, template, "/", retries=30, interval=3.0
            ), f"Frontend not ready for template '{template}'"

            assert devcontainer_health_check(
                project_dir, template, "/health", retries=15, interval=3.0
            ) or devcontainer_health_check(
                project_dir, template, "/docs", retries=10, interval=2.0
            ), f"Backend not ready for template '{template}'"

            # Wait for Traefik to discover the route and serve it from the host
            _wait_for_host_route(workspace_url, retries=20, interval=2.0)

            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context()
                page = context.new_page()

                try:
                    # 1. Page load — verify homepage renders
                    page.goto(f"{workspace_url}/", timeout=15000)
                    page.wait_for_load_state("networkidle", timeout=15000)
                    assert page.title() or page.locator("h1, h2, [role='heading']").count() > 0, (
                        f"Homepage didn't render for template '{template}'"
                    )
                    page.screenshot(path=str(screenshots_dir / f"{template}-01-homepage.png"))

                    # 2. Navigate to model list page
                    page.goto(f"{workspace_url}/{model_slug}", timeout=15000)
                    page.wait_for_load_state("networkidle", timeout=15000)
                    page.screenshot(path=str(screenshots_dir / f"{template}-02-list-empty.png"))

                    # 3. Create — find and click create/add button
                    create_btn = page.locator(
                        "a:has-text('Create'), a:has-text('Add'), a:has-text('New'), "
                        "button:has-text('Create'), button:has-text('Add'), "
                        "button:has-text('New')"
                    ).first
                    if create_btn.is_visible(timeout=5000):
                        create_btn.click()
                        page.wait_for_load_state("networkidle", timeout=10000)

                        # Fill first visible text input
                        text_inputs = page.locator(
                            "input[type='text'], input:not([type]), textarea"
                        )
                        if text_inputs.count() > 0:
                            text_inputs.first.fill(f"Test {model_name}")

                        # Submit the form
                        submit_btn = page.locator(
                            "button[type='submit'], button:has-text('Save'), "
                            "button:has-text('Create'), button:has-text('Submit')"
                        ).first
                        if submit_btn.is_visible(timeout=3000):
                            submit_btn.click()
                            page.wait_for_load_state("networkidle", timeout=10000)

                        page.screenshot(
                            path=str(screenshots_dir / f"{template}-03-after-create.png")
                        )

                    # 4. Read — verify record appears, click into detail
                    page.goto(f"{workspace_url}/{model_slug}", timeout=15000)
                    page.wait_for_load_state("networkidle", timeout=15000)

                    detail_link = page.locator(
                        f"a[href*='{model_slug}/'], "
                        "tr:has-text('Test') a, "
                        "td a, "
                        "[data-testid*='detail'], [data-testid*='view']"
                    ).first
                    if detail_link.is_visible(timeout=5000):
                        detail_link.click()
                        page.wait_for_load_state("networkidle", timeout=10000)
                        page.screenshot(path=str(screenshots_dir / f"{template}-04-detail.png"))

                    # 5. Update — find edit button, modify, save
                    edit_btn = page.locator("a:has-text('Edit'), button:has-text('Edit')").first
                    if edit_btn.is_visible(timeout=3000):
                        edit_btn.click()
                        page.wait_for_load_state("networkidle", timeout=10000)

                        text_inputs = page.locator(
                            "input[type='text'], input:not([type]), textarea"
                        )
                        if text_inputs.count() > 0:
                            text_inputs.first.fill(f"Updated {model_name}")

                        submit_btn = page.locator(
                            "button[type='submit'], button:has-text('Save'), "
                            "button:has-text('Update')"
                        ).first
                        if submit_btn.is_visible(timeout=3000):
                            submit_btn.click()
                            page.wait_for_load_state("networkidle", timeout=10000)

                        page.screenshot(
                            path=str(screenshots_dir / f"{template}-05-after-update.png")
                        )

                    # 6. Delete — find delete button, confirm
                    delete_btn = page.locator(
                        "button:has-text('Delete'), a:has-text('Delete')"
                    ).first
                    if delete_btn.is_visible(timeout=3000):
                        page.on("dialog", lambda dialog: dialog.accept())
                        delete_btn.click()
                        page.wait_for_load_state("networkidle", timeout=10000)
                        page.screenshot(
                            path=str(screenshots_dir / f"{template}-06-after-delete.png")
                        )

                finally:
                    try:
                        page.screenshot(
                            path=str(screenshots_dir / f"{template}-99-final-state.png")
                        )
                    except Exception:
                        pass
                    context.close()
                    browser.close()

        finally:
            devcontainer_down(project_dir, template)
            _stop_traefik_proxy()
