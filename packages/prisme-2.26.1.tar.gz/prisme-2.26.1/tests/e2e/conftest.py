"""E2E test configuration and shared fixtures."""

from __future__ import annotations

import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent.parent
DEMO_SPEC_PATH = PROJECT_ROOT / "specs" / "demo.py"

# Templates with frontend (monorepo structure)
FRONTEND_TEMPLATES = {"website", "app", "enterprise-platform", "saas"}

# Templates with api structure (single package, no frontend)
API_TEMPLATES = {"api-only", "mcp-only"}

# Minimal template (single package, SQLite)
MINIMAL_TEMPLATES = {"minimal"}


def get_prism_command() -> list[str]:
    """Get the command to invoke prism CLI.

    Works in both local development and CI environments.
    Uses python -m to ensure the installed package is used.
    """
    return [sys.executable, "-m", "prisme.cli"]


def run_command(
    cmd: list[str],
    cwd: Path | None = None,
    timeout: int = 120,
    check: bool = True,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a command and return the result.

    Args:
        cmd: Command and arguments to run
        cwd: Working directory for the command
        timeout: Timeout in seconds
        check: Whether to raise on non-zero exit code
        env: Optional environment variables (merged with os.environ)

    Returns:
        CompletedProcess with stdout/stderr captured

    Raises:
        subprocess.CalledProcessError: If check=True and command fails
        subprocess.TimeoutExpired: If command exceeds timeout
    """
    import os

    run_env = None
    if env:
        run_env = {**os.environ, **env}

    result = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=run_env,
    )
    if check and result.returncode != 0:
        print(f"Command failed: {' '.join(cmd)}")
        print(f"STDOUT:\n{result.stdout}")
        print(f"STDERR:\n{result.stderr}")
        raise subprocess.CalledProcessError(result.returncode, cmd, result.stdout, result.stderr)
    return result


def setup_project_with_spec(project_dir: Path) -> Path:
    """Setup a project directory with the demo spec inside it."""
    project_dir.mkdir(parents=True, exist_ok=True)
    spec_dir = project_dir / "specs"
    spec_dir.mkdir(parents=True, exist_ok=True)
    spec_dest = spec_dir / "models.py"
    shutil.copy(DEMO_SPEC_PATH, spec_dest)
    return spec_dest


def has_frontend(template: str) -> bool:
    """Check if a template includes a frontend package."""
    return template in FRONTEND_TEMPLATES


def _set_env_var(env_file: Path, key: str, value: str) -> None:
    """Set or update an environment variable in a .env file."""
    lines = env_file.read_text().splitlines() if env_file.exists() else []
    found = False
    for i, line in enumerate(lines):
        if line.startswith(f"{key}="):
            lines[i] = f"{key}={value}"
            found = True
            break
    if not found:
        lines.append(f"{key}={value}")
    env_file.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Devcontainer helpers
# ---------------------------------------------------------------------------


def get_workspace_name(template: str) -> str:
    """Get the devcontainer workspace name for a golden test template."""
    return f"golden-{template}"


def get_workspace_url(template: str) -> str:
    """Get the Traefik URL for a golden test workspace."""
    return f"http://{get_workspace_name(template)}.localhost"


def devcontainer_up(
    project_dir: Path,
    template: str,
    timeout: int = 600,
) -> None:
    """Start a devcontainer for the given template project.

    Runs `prisme devstack up --name golden-{template}`.
    This generates .devcontainer/, starts docker-compose, and runs setup.sh
    (which installs deps, generates code, and runs migrations).
    """
    # Ensure .env exists at project root (docker-compose env_file requires it)
    env_file = project_dir / ".env"
    if not env_file.exists():
        env_example = project_dir / ".env.example"
        if env_example.exists():
            shutil.copy(env_example, env_file)
        else:
            env_file.write_text("")

    # Set PRISM_SRC so docker-compose mounts our dev source at /prism
    # and setup.sh installs the local dev version instead of PyPI
    _set_env_var(env_file, "PRISM_SRC", str(PROJECT_ROOT))

    # Set BOOTSTRAP_EMAIL for admin user bootstrapping in setup.sh
    _set_env_var(env_file, "BOOTSTRAP_EMAIL", "test@golden.local")

    # Make project directory writable by the container's vscode user (uid 1000)
    import subprocess as _sp

    _sp.run(["chmod", "-R", "a+rwX", str(project_dir)], capture_output=True, timeout=30)

    run_command(
        [*get_prism_command(), "devstack", "up", "--name", get_workspace_name(template)],
        cwd=project_dir,
        timeout=timeout,
        env={"PRISM_SRC": str(PROJECT_ROOT)},
    )


def devcontainer_down(
    project_dir: Path,
    template: str,
    timeout: int = 60,
    volumes: bool = True,
) -> None:
    """Stop and remove a devcontainer for the given template.

    Always called in a finally block; never raises.
    """
    cmd = [*get_prism_command(), "devstack", "down", "--name", get_workspace_name(template)]
    if volumes:
        cmd.append("--volumes")
    run_command(
        cmd,
        cwd=project_dir,
        timeout=timeout,
        check=False,
        env={"PRISM_SRC": str(PROJECT_ROOT)},
    )


def devcontainer_test(
    project_dir: Path,
    template: str,
    *extra_args: str,
    timeout: int = 300,
) -> subprocess.CompletedProcess[str]:
    """Run `prisme devcontainer test` inside the container.

    Passes extra_args through to `prisme test` (e.g. "--backend-only").
    Returns CompletedProcess (does not raise on failure).
    """
    cmd = [
        *get_prism_command(),
        "devcontainer",
        "test",
        "--name",
        get_workspace_name(template),
    ]
    if extra_args:
        cmd.append("--")
        cmd.extend(extra_args)
    return run_command(
        cmd,
        cwd=project_dir,
        timeout=timeout,
        check=False,
        env={"PRISM_SRC": str(PROJECT_ROOT)},
    )


def devcontainer_exec(
    project_dir: Path,
    template: str,
    command: str,
    timeout: int = 120,
    check: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Run a shell command inside the devcontainer via `prisme devcontainer exec`."""
    return run_command(
        [
            *get_prism_command(),
            "devcontainer",
            "exec",
            "--name",
            get_workspace_name(template),
            command,
        ],
        cwd=project_dir,
        timeout=timeout,
        check=check,
        env={"PRISM_SRC": str(PROJECT_ROOT)},
    )


def devcontainer_exec_background(
    project_dir: Path,
    template: str,
    command: str,
) -> None:
    """Run a command inside the devcontainer in detached mode.

    Uses `docker exec -d` to start the process without blocking.
    Useful for starting dev servers that need to run in the background.
    """
    container_name = f"{get_workspace_name(template)}-app"
    subprocess.run(
        ["docker", "exec", "-d", container_name, "bash", "-lc", command],
        capture_output=True,
        timeout=30,
        check=True,
    )


def devcontainer_health_check(
    project_dir: Path,
    template: str,
    path: str = "/api/health",
    retries: int = 30,
    interval: float = 3.0,
) -> bool:
    """Health-check a service from inside the devcontainer.

    Runs curl inside the container to check localhost:8000 (backend)
    or localhost:5173 (frontend).
    """
    # Backend runs on 8000, frontend on 5173 inside the container
    port = 8000 if path.startswith("/api") or path in ("/health", "/docs") else 5173

    for attempt in range(retries):
        result = devcontainer_exec(
            project_dir,
            template,
            f"curl -sf --max-time 3 http://localhost:{port}{path}",
            timeout=15,
        )
        if result.returncode == 0:
            return True
        if attempt < retries - 1:
            time.sleep(interval)
    return False


def skip_if_no_docker() -> None:
    """Skip the test if docker is not available or not running."""
    if not shutil.which("docker"):
        pytest.skip("docker not installed")
    result = subprocess.run(
        ["docker", "info"],
        capture_output=True,
        timeout=10,
    )
    if result.returncode != 0:
        pytest.skip("docker daemon not running")


def ensure_docker_network() -> None:
    """Create the prism_proxy_network if it doesn't exist."""
    subprocess.run(
        ["docker", "network", "create", "prism_proxy_network"],
        capture_output=True,
        timeout=10,
    )


@pytest.fixture(scope="module")
def e2e_temp_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Create a temporary directory for e2e tests."""
    return tmp_path_factory.mktemp("prism_e2e")


@pytest.fixture
def prism_cmd() -> list[str]:
    """Get the prism command for subprocess calls."""
    return get_prism_command()
