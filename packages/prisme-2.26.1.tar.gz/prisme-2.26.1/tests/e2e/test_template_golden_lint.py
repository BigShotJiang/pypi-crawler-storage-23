"""Golden E2E tests — Tier 2: Frontend linting (ESLint).

Pipeline: prisme create → prisme generate → prisme devcontainer up →
          prisme devcontainer exec "pnpm lint" → prisme devcontainer down

Validates that generated frontend TypeScript/React code passes ESLint
inside the devcontainer.

Markers: e2e, docker
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.e2e.conftest import (
    devcontainer_down,
    devcontainer_exec,
    devcontainer_up,
    ensure_docker_network,
    skip_if_no_docker,
)
from tests.e2e.test_template_golden import TEMPLATE_CONFIGS, _get_project

# Only templates with frontend
FRONTEND_TEMPLATE_LIST = [t[0] for t in TEMPLATE_CONFIGS if t[2]]


@pytest.fixture(scope="module")
def golden_base_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Shared temporary directory for golden lint tests."""
    return tmp_path_factory.mktemp("golden_lint")


@pytest.mark.e2e
@pytest.mark.docker
class TestFrontendLint:
    """Validate ESLint passes on generated frontend code inside devcontainer."""

    @pytest.mark.parametrize("template", FRONTEND_TEMPLATE_LIST, ids=FRONTEND_TEMPLATE_LIST)
    @pytest.mark.timeout(600)
    def test_eslint_passes(
        self,
        golden_base_dir: Path,
        template: str,
    ) -> None:
        """ESLint passes on all generated TypeScript/React code."""
        skip_if_no_docker()
        ensure_docker_network()

        project_dir = _get_project(template, golden_base_dir)
        try:
            devcontainer_up(project_dir, template)
            result = devcontainer_exec(
                project_dir,
                template,
                "cd packages/frontend && pnpm lint",
                timeout=180,
            )
            assert result.returncode == 0, (
                f"ESLint failed for template '{template}':\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )
        finally:
            devcontainer_down(project_dir, template)
