"""Tests for developer experience features."""
