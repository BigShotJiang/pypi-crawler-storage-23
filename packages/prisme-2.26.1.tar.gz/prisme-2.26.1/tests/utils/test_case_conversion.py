"""Tests for string case conversion utilities."""

from __future__ import annotations

from prisme.utils.case_conversion import (
    pluralize,
    singularize,
    to_camel_case,
    to_kebab_case,
    to_pascal_case,
    to_snake_case,
)


class TestToSnakeCase:
    """Tests for to_snake_case."""

    def test_pascal_case(self) -> None:
        assert to_snake_case("CustomerOrder") == "customer_order"

    def test_camel_case(self) -> None:
        assert to_snake_case("customerOrder") == "customer_order"

    def test_kebab_case(self) -> None:
        assert to_snake_case("customer-order") == "customer_order"

    def test_acronyms(self) -> None:
        assert to_snake_case("HTTPResponse") == "http_response"

    def test_already_snake(self) -> None:
        assert to_snake_case("customer_order") == "customer_order"

    def test_single_word(self) -> None:
        assert to_snake_case("customer") == "customer"

    def test_empty_string(self) -> None:
        assert to_snake_case("") == ""

    def test_with_spaces(self) -> None:
        assert to_snake_case("customer order") == "customer_order"

    def test_uppercase(self) -> None:
        assert to_snake_case("CUSTOMER") == "customer"

    def test_mixed_separators(self) -> None:
        assert to_snake_case("customer-order_item") == "customer_order_item"


class TestToPascalCase:
    """Tests for to_pascal_case."""

    def test_snake_case(self) -> None:
        assert to_pascal_case("customer_order") == "CustomerOrder"

    def test_kebab_case(self) -> None:
        assert to_pascal_case("customer-order") == "CustomerOrder"

    def test_camel_case(self) -> None:
        assert to_pascal_case("customerOrder") == "CustomerOrder"

    def test_already_pascal(self) -> None:
        assert to_pascal_case("CustomerOrder") == "CustomerOrder"

    def test_single_word(self) -> None:
        assert to_pascal_case("customer") == "Customer"

    def test_empty_string(self) -> None:
        assert to_pascal_case("") == ""

    def test_with_spaces(self) -> None:
        assert to_pascal_case("customer order") == "CustomerOrder"


class TestToCamelCase:
    """Tests for to_camel_case."""

    def test_snake_case(self) -> None:
        assert to_camel_case("customer_order") == "customerOrder"

    def test_pascal_case(self) -> None:
        assert to_camel_case("CustomerOrder") == "customerOrder"

    def test_kebab_case(self) -> None:
        assert to_camel_case("customer-order") == "customerOrder"

    def test_already_camel(self) -> None:
        assert to_camel_case("customerOrder") == "customerOrder"

    def test_single_word(self) -> None:
        assert to_camel_case("customer") == "customer"

    def test_empty_string(self) -> None:
        assert to_camel_case("") == ""


class TestToKebabCase:
    """Tests for to_kebab_case."""

    def test_pascal_case(self) -> None:
        assert to_kebab_case("CustomerOrder") == "customer-order"

    def test_snake_case(self) -> None:
        assert to_kebab_case("customer_order") == "customer-order"

    def test_camel_case(self) -> None:
        assert to_kebab_case("customerOrder") == "customer-order"

    def test_already_kebab(self) -> None:
        assert to_kebab_case("customer-order") == "customer-order"

    def test_empty_string(self) -> None:
        assert to_kebab_case("") == ""


class TestPluralize:
    """Tests for pluralize."""

    def test_regular(self) -> None:
        assert pluralize("customer") == "customers"

    def test_y_ending(self) -> None:
        assert pluralize("category") == "categories"

    def test_y_after_vowel(self) -> None:
        assert pluralize("day") == "days"

    def test_s_ending(self) -> None:
        assert pluralize("status") == "statuses"

    def test_x_ending(self) -> None:
        assert pluralize("box") == "boxes"

    def test_z_ending(self) -> None:
        assert pluralize("quiz") == "quizes"

    def test_ch_ending(self) -> None:
        assert pluralize("match") == "matches"

    def test_sh_ending(self) -> None:
        assert pluralize("wish") == "wishes"

    def test_f_ending(self) -> None:
        assert pluralize("leaf") == "leaves"

    def test_fe_ending(self) -> None:
        assert pluralize("knife") == "knives"

    def test_irregular_child(self) -> None:
        assert pluralize("child") == "children"

    def test_irregular_person(self) -> None:
        assert pluralize("person") == "people"

    def test_irregular_man(self) -> None:
        assert pluralize("man") == "men"

    def test_irregular_woman(self) -> None:
        assert pluralize("woman") == "women"

    def test_irregular_foot(self) -> None:
        assert pluralize("foot") == "feet"

    def test_irregular_tooth(self) -> None:
        assert pluralize("tooth") == "teeth"

    def test_irregular_goose(self) -> None:
        assert pluralize("goose") == "geese"

    def test_irregular_mouse(self) -> None:
        assert pluralize("mouse") == "mice"

    def test_irregular_ox(self) -> None:
        assert pluralize("ox") == "oxen"

    def test_empty_string(self) -> None:
        assert pluralize("") == ""

    def test_capitalize_preserved(self) -> None:
        assert pluralize("Child") == "Children"

    def test_pascal_case_model(self) -> None:
        assert pluralize("Customer") == "Customers"


class TestSingularize:
    """Tests for singularize."""

    def test_regular_s(self) -> None:
        assert singularize("customers") == "customer"

    def test_ies_ending(self) -> None:
        assert singularize("categories") == "category"

    def test_es_ending_s(self) -> None:
        assert singularize("statuses") == "status"

    def test_es_ending_x(self) -> None:
        assert singularize("boxes") == "box"

    def test_es_ending_ch(self) -> None:
        assert singularize("matches") == "match"

    def test_es_ending_sh(self) -> None:
        assert singularize("wishes") == "wish"

    def test_irregular_children(self) -> None:
        assert singularize("children") == "child"

    def test_irregular_people(self) -> None:
        assert singularize("people") == "person"

    def test_irregular_men(self) -> None:
        assert singularize("men") == "man"

    def test_irregular_women(self) -> None:
        assert singularize("women") == "woman"

    def test_irregular_feet(self) -> None:
        assert singularize("feet") == "foot"

    def test_irregular_teeth(self) -> None:
        assert singularize("teeth") == "tooth"

    def test_irregular_geese(self) -> None:
        assert singularize("geese") == "goose"

    def test_irregular_mice(self) -> None:
        assert singularize("mice") == "mouse"

    def test_irregular_oxen(self) -> None:
        assert singularize("oxen") == "ox"

    def test_empty_string(self) -> None:
        assert singularize("") == ""

    def test_capitalize_preserved(self) -> None:
        assert singularize("Children") == "Child"

    def test_ves_ending(self) -> None:
        assert singularize("knives") == "knife"

    def test_word_ending_in_ss(self) -> None:
        # Words ending in ss should not lose the s
        assert singularize("class") == "class"

    def test_already_singular(self) -> None:
        assert singularize("item") == "item"
