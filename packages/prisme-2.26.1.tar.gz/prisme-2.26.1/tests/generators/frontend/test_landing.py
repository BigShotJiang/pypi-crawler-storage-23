"""Tests for the landing page generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.landing import LandingPageGenerator
from prisme.spec.auth import AuthConfig
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestLandingPageGenerator:
    """Tests for LandingPageGenerator."""

    def test_generates_landing_when_auth_enabled(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 2
        assert any("LandingPage.tsx" in str(f.path) for f in files)
        assert any("ExampleCustomPage.tsx" in str(f.path) for f in files)

    def test_no_landing_when_auth_disabled(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=False),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        # Still generates example custom page even when auth is disabled
        assert len(files) == 1
        assert "ExampleCustomPage.tsx" in str(files[0].path)

    def test_landing_uses_generate_once_strategy(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        # Both landing page and example custom page use GENERATE_ONCE
        assert all(f.strategy == FileStrategy.GENERATE_ONCE for f in files)

    def test_landing_content_has_project_info(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        landing_file = next(f for f in files if "LandingPage.tsx" in str(f.path))
        assert len(landing_file.content) > 0

    def test_example_custom_page_always_generated(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        """Example custom page should be generated regardless of auth setting."""
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=False),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert any("ExampleCustomPage.tsx" in str(f.path) for f in files)
        example_file = next(f for f in files if "ExampleCustomPage.tsx" in str(f.path))
        assert "Example custom page" in example_file.content
        assert example_file.strategy == FileStrategy.GENERATE_ONCE
