"""Tests for the blog pages generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.blog import BlogGenerator
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestBlogGenerator:
    """Tests for BlogGenerator."""

    def test_generates_two_blog_pages(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = BlogGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 2
        file_paths = [str(f.path) for f in files]
        assert any("BlogPage.tsx" in p for p in file_paths)
        assert any("BlogPostPage.tsx" in p for p in file_paths)

    def test_blog_uses_generate_once_strategy(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = BlogGenerator(ctx)
        files = gen.generate_files()
        for f in files:
            assert f.strategy == FileStrategy.GENERATE_ONCE

    def test_blog_content_has_project_info(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = BlogGenerator(ctx)
        files = gen.generate_files()
        listing = next(f for f in files if "BlogPage" in str(f.path))
        assert "Blog" in listing.content
        assert len(listing.content) > 0

    def test_blog_post_page_content(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = BlogGenerator(ctx)
        files = gen.generate_files()
        post = next(f for f in files if "BlogPostPage" in str(f.path))
        assert "slug" in post.content
