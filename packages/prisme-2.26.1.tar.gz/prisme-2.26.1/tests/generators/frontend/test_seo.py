"""Tests for the SEO components generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.seo import SEOGenerator
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestSEOGenerator:
    """Tests for SEOGenerator."""

    def test_generates_seo_components(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SEOGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 2
        file_paths = [str(f.path) for f in files]
        assert any("SEOHead.tsx" in p for p in file_paths)
        assert any("SEOProvider.tsx" in p for p in file_paths)

    def test_seo_uses_generate_once_strategy(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SEOGenerator(ctx)
        files = gen.generate_files()
        for f in files:
            assert f.strategy == FileStrategy.GENERATE_ONCE

    def test_seo_head_has_meta_tags(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SEOGenerator(ctx)
        files = gen.generate_files()
        seo_head = next(f for f in files if "SEOHead" in str(f.path))
        assert "og:title" in seo_head.content
        assert "twitter:card" in seo_head.content
        assert "description" in seo_head.content

    def test_seo_provider_has_helmet(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SEOGenerator(ctx)
        files = gen.generate_files()
        provider = next(f for f in files if "SEOProvider" in str(f.path))
        assert "HelmetProvider" in provider.content
