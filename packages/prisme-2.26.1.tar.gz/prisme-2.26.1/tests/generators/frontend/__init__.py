"""Tests for frontend generators."""
