"""Tests for MarketingPagesGenerator."""

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.marketing import MarketingPagesGenerator
from prisme.spec.project import MarketingConfig, ProjectSpec
from prisme.spec.stack import StackSpec


@pytest.fixture
def base_stack_spec():
    """Create a basic stack spec for testing."""
    return StackSpec(
        name="test-app",
        title="Test App",
        description="A test application",
        models=[],
    )


@pytest.fixture
def project_spec_with_marketing():
    """Create project spec with marketing enabled."""
    return ProjectSpec(
        name="test-app",
        marketing=MarketingConfig(
            enabled=True,
            pages=["landing", "features", "pricing", "about", "contact"],
        ),
    )


@pytest.fixture
def project_spec_without_marketing():
    """Create project spec with marketing disabled."""
    return ProjectSpec(
        name="test-app",
        marketing=MarketingConfig(enabled=False),
    )


def test_marketing_generator_when_enabled(base_stack_spec, project_spec_with_marketing, tmp_path):
    """Test that marketing pages are generated when enabled."""
    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=project_spec_with_marketing,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    assert len(files) > 0

    # Check for layout components
    assert any("MarketingLayout.tsx" in str(f.path) for f in files)
    assert any("MarketingHeader.tsx" in str(f.path) for f in files)
    assert any("Footer.tsx" in str(f.path) for f in files)

    # Check for pages
    assert any("features.tsx" in str(f.path) for f in files)
    assert any("pricing.tsx" in str(f.path) for f in files)
    assert any("about.tsx" in str(f.path) for f in files)
    assert any("contact.tsx" in str(f.path) for f in files)


def test_marketing_generator_when_disabled(
    base_stack_spec, project_spec_without_marketing, tmp_path
):
    """Test that no files are generated when marketing is disabled."""
    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=project_spec_without_marketing,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    assert len(files) == 0


def test_marketing_generator_with_custom_pages(base_stack_spec, tmp_path):
    """Test that only specified pages are generated."""
    project_spec = ProjectSpec(
        name="test-app",
        marketing=MarketingConfig(
            enabled=True,
            pages=["landing", "features"],  # Only features, no pricing/about/contact
        ),
    )
    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=project_spec,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    # Should have layout components
    assert any("MarketingLayout.tsx" in str(f.path) for f in files)

    # Should have features page
    assert any("features.tsx" in str(f.path) for f in files)

    # Should NOT have pricing/about/contact pages
    assert not any("pricing.tsx" in str(f.path) for f in files)
    assert not any("about.tsx" in str(f.path) for f in files)
    assert not any("contact.tsx" in str(f.path) for f in files)


def test_marketing_generator_file_paths(base_stack_spec, project_spec_with_marketing, tmp_path):
    """Test that generated files have correct paths."""
    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=project_spec_with_marketing,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    # Check component paths
    layout_file = next(f for f in files if "MarketingLayout.tsx" in str(f.path))
    assert "components/marketing" in str(layout_file.path)

    header_file = next(f for f in files if "MarketingHeader.tsx" in str(f.path))
    assert "components/marketing" in str(header_file.path)

    # Check page paths
    features_file = next(f for f in files if "features.tsx" in str(f.path))
    assert "pages/marketing" in str(features_file.path)


def test_marketing_generator_file_strategy(base_stack_spec, project_spec_with_marketing, tmp_path):
    """Test that all files use GENERATE_ONCE strategy."""
    from prisme.spec.stack import FileStrategy

    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=project_spec_with_marketing,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    # All marketing files should use GENERATE_ONCE
    for file in files:
        assert file.strategy == FileStrategy.GENERATE_ONCE


def test_marketing_generator_without_project_spec(base_stack_spec, tmp_path):
    """Test that generator handles missing project spec gracefully."""
    context = GeneratorContext(
        domain_spec=base_stack_spec,
        output_dir=tmp_path,
        project_spec=None,
    )
    generator = MarketingPagesGenerator(context)
    files = generator.generate_files()

    # Should return empty list when marketing is not enabled (default)
    assert len(files) == 0
