"""Tests for the chatbot widget generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.chatbot import ChatbotGenerator
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestChatbotGenerator:
    """Tests for ChatbotGenerator."""

    def test_generates_chatbot_widget(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = ChatbotGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 1
        assert "ChatbotWidget.tsx" in str(files[0].path)

    def test_chatbot_uses_generate_once_strategy(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = ChatbotGenerator(ctx)
        files = gen.generate_files()
        assert files[0].strategy == FileStrategy.GENERATE_ONCE

    def test_chatbot_content_has_chat_elements(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = ChatbotGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "ChatMessage" in content or "message" in content
        assert "ChatbotWidget" in content
