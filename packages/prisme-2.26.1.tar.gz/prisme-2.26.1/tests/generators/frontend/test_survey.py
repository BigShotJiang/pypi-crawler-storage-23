"""Tests for the survey page generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.survey import SurveyGenerator
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestSurveyGenerator:
    """Tests for SurveyGenerator."""

    def test_generates_survey_page(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 1
        assert "SurveyPage.tsx" in str(files[0].path)

    def test_survey_uses_generate_once_strategy(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        assert files[0].strategy == FileStrategy.GENERATE_ONCE

    def test_survey_content_has_question_types(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "multiple_choice" in content
        assert "yes_no" in content
        assert "'text'" in content

    def test_survey_content_has_contact_details(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "ContactDetails" in content
        assert "email" in content
        assert "name" in content

    def test_survey_content_has_pagination(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "currentPage" in content
        assert "Previous" in content
        assert "Next" in content

    def test_survey_content_has_submission(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "Submit" in content
        assert "submitted" in content

    def test_survey_content_has_progress_bar(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "progressPct" in content or "progress" in content.lower()

    def test_survey_content_has_question_groups(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = SurveyGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "QuestionGroup" in content
        assert "SURVEY_GROUPS" in content
