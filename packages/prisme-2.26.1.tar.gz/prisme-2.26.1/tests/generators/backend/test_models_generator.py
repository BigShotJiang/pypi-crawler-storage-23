"""Tests for the ModelsGenerator, including DateTime timezone support."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from prisme.generators.backend.models import ModelsGenerator
from prisme.generators.base import GeneratorContext
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import StackSpec

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def datetime_model() -> ModelSpec:
    """Create a model with a DateTime field."""
    return ModelSpec(
        name="Event",
        fields=[
            FieldSpec(name="name", type=FieldType.STRING, required=True),
            FieldSpec(name="started_at", type=FieldType.DATETIME, required=True),
        ],
    )


@pytest.fixture
def datetime_model_with_timestamps() -> ModelSpec:
    """Create a model with TimestampMixin enabled."""
    return ModelSpec(
        name="Article",
        fields=[
            FieldSpec(name="title", type=FieldType.STRING, required=True),
            FieldSpec(name="published_at", type=FieldType.DATETIME, required=False),
        ],
        timestamps=True,
    )


@pytest.fixture
def datetime_model_with_soft_delete() -> ModelSpec:
    """Create a model with SoftDeleteMixin enabled."""
    return ModelSpec(
        name="Post",
        fields=[
            FieldSpec(name="content", type=FieldType.TEXT, required=True),
        ],
        soft_delete=True,
    )


@pytest.fixture
def datetime_stack(datetime_model: ModelSpec) -> StackSpec:
    return StackSpec(
        name="test-datetime",
        version="1.0.0",
        models=[datetime_model],
    )


@pytest.fixture
def datetime_stack_with_timestamps(datetime_model_with_timestamps: ModelSpec) -> StackSpec:
    return StackSpec(
        name="test-datetime-timestamps",
        version="1.0.0",
        models=[datetime_model_with_timestamps],
    )


@pytest.fixture
def datetime_stack_with_soft_delete(datetime_model_with_soft_delete: ModelSpec) -> StackSpec:
    return StackSpec(
        name="test-datetime-soft-delete",
        version="1.0.0",
        models=[datetime_model_with_soft_delete],
    )


@pytest.fixture
def datetime_context(datetime_stack: StackSpec, tmp_path: Path) -> GeneratorContext:
    return GeneratorContext(
        domain_spec=datetime_stack,
        output_dir=tmp_path,
        dry_run=True,
        project_spec=ProjectSpec(name="test-datetime"),
    )


@pytest.fixture
def datetime_context_with_timestamps(
    datetime_stack_with_timestamps: StackSpec, tmp_path: Path
) -> GeneratorContext:
    return GeneratorContext(
        domain_spec=datetime_stack_with_timestamps,
        output_dir=tmp_path,
        dry_run=True,
        project_spec=ProjectSpec(name="test-datetime-timestamps"),
    )


@pytest.fixture
def datetime_context_with_soft_delete(
    datetime_stack_with_soft_delete: StackSpec, tmp_path: Path
) -> GeneratorContext:
    return GeneratorContext(
        domain_spec=datetime_stack_with_soft_delete,
        output_dir=tmp_path,
        dry_run=True,
        project_spec=ProjectSpec(name="test-datetime-soft-delete"),
    )


class TestDateTimeTimezone:
    """Issue #56: DateTime columns should include timezone=True."""

    def test_datetime_column_has_timezone(
        self, datetime_context: GeneratorContext, datetime_stack: StackSpec
    ) -> None:
        """DateTime fields should generate DateTime(timezone=True) in mapped_column."""
        generator = ModelsGenerator(datetime_context)
        files = generator.generate_files()

        # Find the Event model file
        event_file = next(f for f in files if "event" in str(f.path))
        assert "DateTime(timezone=True)" in event_file.content

    def test_datetime_column_does_not_use_bare_datetime(
        self, datetime_context: GeneratorContext
    ) -> None:
        """DateTime fields should NOT use bare DateTime without timezone."""
        generator = ModelsGenerator(datetime_context)
        files = generator.generate_files()

        event_file = next(f for f in files if "event" in str(f.path))
        # Should not have bare "DateTime)" without timezone
        # But "DateTime(timezone=True)" is fine
        content = event_file.content
        assert "DateTime(timezone=True)" in content
        # Ensure there's no mapped_column(DateTime) without timezone
        assert "mapped_column(DateTime)" not in content

    def test_timestamp_mixin_uses_timezone(
        self, datetime_context_with_timestamps: GeneratorContext
    ) -> None:
        """TimestampMixin fields (created_at, updated_at) should use DateTime(timezone=True)."""
        generator = ModelsGenerator(datetime_context_with_timestamps)
        files = generator.generate_files()

        # Find the base model file
        base_file = next(f for f in files if "base.py" in str(f.path))
        content = base_file.content

        # Check that TimestampMixin uses DateTime(timezone=True)
        assert "class TimestampMixin:" in content
        assert "created_at" in content
        assert "updated_at" in content
        # Count occurrences - should be at least 2 (created_at and updated_at)
        timezone_count = content.count("DateTime(timezone=True)")
        assert timezone_count >= 2, (
            f"Expected at least 2 DateTime(timezone=True), found {timezone_count}"
        )

    def test_soft_delete_mixin_uses_timezone(
        self, datetime_context_with_soft_delete: GeneratorContext
    ) -> None:
        """SoftDeleteMixin deleted_at field should use DateTime(timezone=True)."""
        generator = ModelsGenerator(datetime_context_with_soft_delete)
        files = generator.generate_files()

        # Find the base model file
        base_file = next(f for f in files if "base.py" in str(f.path))
        content = base_file.content

        # Check that SoftDeleteMixin uses DateTime(timezone=True)
        assert "class SoftDeleteMixin:" in content
        assert "deleted_at" in content
        # deleted_at should use DateTime(timezone=True)
        assert "deleted_at: Mapped[datetime | None] = mapped_column" in content

    def test_optional_datetime_field_uses_timezone(self, tmp_path: Path) -> None:
        """Optional DateTime fields should use DateTime(timezone=True)."""
        model = ModelSpec(
            name="Task",
            fields=[
                FieldSpec(name="name", type=FieldType.STRING, required=True),
                FieldSpec(name="completed_at", type=FieldType.DATETIME, required=False),
            ],
        )
        stack = StackSpec(name="test-optional-datetime", version="1.0.0", models=[model])
        context = GeneratorContext(
            domain_spec=stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-optional-datetime"),
        )

        generator = ModelsGenerator(context)
        files = generator.generate_files()

        task_file = next(f for f in files if "task" in str(f.path))
        content = task_file.content

        # Check that optional datetime field uses DateTime(timezone=True)
        assert "completed_at" in content
        assert "DateTime(timezone=True)" in content
        assert "nullable=True" in content

    def test_no_bare_datetime_anywhere(self, datetime_context: GeneratorContext) -> None:
        """No generated file should contain DateTime() without timezone=True."""
        generator = ModelsGenerator(datetime_context)
        files = generator.generate_files()

        for file in files:
            content = file.content
            # Check for patterns that would indicate bare DateTime usage
            # We want to catch "DateTime)" but not "DateTime(timezone=True)"
            lines = content.split("\n")
            for line_num, line in enumerate(lines, 1):
                if "DateTime" in line and "timezone=True" not in line and "import" not in line:
                    # This is a usage of DateTime, it should have timezone=True
                    raise AssertionError(
                        f"Found DateTime usage without timezone=True in {file.path}:{line_num}\n"
                        f"Line: {line.strip()}"
                    )
