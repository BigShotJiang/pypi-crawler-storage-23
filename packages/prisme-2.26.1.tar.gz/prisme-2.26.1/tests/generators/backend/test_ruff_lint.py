"""Tests that generated Python code passes ruff linting.

Generates all backend code with a representative spec, runs the post-generation
formatting step, then verifies ruff check reports zero errors.

Marked @pytest.mark.slow because it runs ruff as a subprocess.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import TYPE_CHECKING

import pytest

from prisme.generators.backend import (
    AdminGenerator,
    AlembicGenerator,
    APIKeyAuthGenerator,
    AuthGenerator,
    GraphQLGenerator,
    MCPGenerator,
    ModelsGenerator,
    RESTGenerator,
    SchemasGenerator,
    ServicesGenerator,
)
from prisme.generators.base import GeneratorContext
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec, RelationshipSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import StackSpec

if TYPE_CHECKING:
    from pathlib import Path


@pytest.mark.slow
class TestGeneratedPythonRuffClean:
    """Verify that all generated backend Python passes ruff check."""

    @pytest.fixture(scope="class")
    def stack_spec(self) -> StackSpec:
        """Create a representative stack spec with relationships, auth, etc."""
        return StackSpec(
            name="test-ruff",
            version="1.0.0",
            models=[
                ModelSpec(
                    name="Customer",
                    description="Customer entity",
                    soft_delete=True,
                    timestamps=True,
                    fields=[
                        FieldSpec(
                            name="name", type=FieldType.STRING, required=True, max_length=255
                        ),
                        FieldSpec(
                            name="email",
                            type=FieldType.STRING,
                            required=True,
                            unique=True,
                            max_length=255,
                        ),
                        FieldSpec(
                            name="status",
                            type=FieldType.ENUM,
                            enum_values=["active", "inactive"],
                            default="active",
                        ),
                    ],
                    relationships=[
                        RelationshipSpec(
                            name="orders",
                            target_model="Order",
                            type="one_to_many",
                            back_populates="customer",
                        ),
                    ],
                ),
                ModelSpec(
                    name="Order",
                    description="Order entity",
                    timestamps=True,
                    fields=[
                        FieldSpec(name="order_number", type=FieldType.STRING, required=True),
                        FieldSpec(name="total", type=FieldType.DECIMAL, required=True),
                        FieldSpec(
                            name="customer_id",
                            type=FieldType.FOREIGN_KEY,
                            references="Customer",
                        ),
                    ],
                    relationships=[
                        RelationshipSpec(
                            name="customer",
                            target_model="Customer",
                            type="many_to_one",
                            back_populates="orders",
                        ),
                        RelationshipSpec(
                            name="items",
                            target_model="OrderItem",
                            type="one_to_many",
                            back_populates="order",
                        ),
                    ],
                    nested_create=["items"],
                ),
                ModelSpec(
                    name="OrderItem",
                    description="Order line item",
                    fields=[
                        FieldSpec(name="product_name", type=FieldType.STRING, required=True),
                        FieldSpec(name="quantity", type=FieldType.INTEGER, required=True),
                        FieldSpec(
                            name="order_id",
                            type=FieldType.FOREIGN_KEY,
                            references="Order",
                        ),
                    ],
                    relationships=[
                        RelationshipSpec(
                            name="order",
                            target_model="Order",
                            type="many_to_one",
                            back_populates="items",
                        ),
                    ],
                ),
            ],
        )

    @pytest.fixture(scope="class")
    def generated_project(
        self, stack_spec: StackSpec, tmp_path_factory: pytest.TempPathFactory
    ) -> Path:
        """Generate all backend code and run post-generation formatting."""
        root = tmp_path_factory.mktemp("ruff-lint")

        context = GeneratorContext(
            domain_spec=stack_spec,
            output_dir=root,
            project_spec=ProjectSpec(name="test-ruff"),
        )

        # Run all backend generators
        generators = [
            ModelsGenerator,
            AlembicGenerator,
            SchemasGenerator,
            ServicesGenerator,
            AuthGenerator,
            AdminGenerator,
            APIKeyAuthGenerator,
            RESTGenerator,
            GraphQLGenerator,
            MCPGenerator,
        ]

        all_py_files: list[str] = []
        for gen_cls in generators:
            try:
                gen = gen_cls(context)
                result = gen.generate()
                for f in result.files:
                    file_path = root / f.path
                    if str(f.path).endswith(".py") and file_path.exists():
                        all_py_files.append(str(file_path))
            except Exception:
                # Some generators may fail without full project setup; that's OK
                pass

        # Write a ruff config matching wind-pipeline's rules
        ruff_toml = root / "ruff.toml"
        ruff_toml.write_text(
            'target-version = "py313"\n'
            "line-length = 100\n"
            "\n"
            "[lint]\n"
            'select = ["E", "F", "I", "UP", "B", "SIM"]\n'
        )

        # Run post-generation formatting (same as cli.py does)
        if all_py_files and shutil.which("ruff"):
            subprocess.run(
                ["ruff", "check", "--fix", *all_py_files],
                capture_output=True,
                timeout=120,
            )
            subprocess.run(
                ["ruff", "format", *all_py_files],
                capture_output=True,
                timeout=120,
            )

        return root

    def test_ruff_check_passes(self, generated_project: Path) -> None:
        """All generated Python files pass ruff check."""
        if not shutil.which("ruff"):
            pytest.skip("ruff not installed")

        result = subprocess.run(
            ["ruff", "check", str(generated_project)],
            capture_output=True,
            text=True,
            timeout=60,
        )
        assert result.returncode == 0, f"ruff check failed:\n{result.stdout}\n{result.stderr}"
