"""Infrastructure generator tests."""
