"""CLI tests for Prism."""
