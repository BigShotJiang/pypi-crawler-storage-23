"""Tests for project structure constants."""

from __future__ import annotations

from pathlib import Path

from prisme.project.structure import (
    APP_BACKEND_DIR,
    APP_BACKEND_EXTENSIONS_DIR,
    APP_DIR,
    APP_FRONTEND_DIR,
    CONFIG_FILE,
    DEVCONTAINER_DIR,
    DOCKER_DIR,
    DOMAIN_SPEC_FILE,
    GENERATED_BACKEND_DIR,
    GENERATED_DIR,
    GENERATED_FRONTEND_DIR,
    GITHUB_DIR,
    MANIFEST_PATH,
    PACKAGES_BACKEND_DIR,
    PACKAGES_DIR,
    PACKAGES_FRONTEND_DIR,
    PROJECT_SPEC_FILE,
    SPECS_DIR,
)


class TestProjectStructureConstants:
    """Verify all project structure constants have expected values."""

    def test_generated_dir(self) -> None:
        assert Path("generated") == GENERATED_DIR

    def test_app_dir(self) -> None:
        assert Path("app") == APP_DIR

    def test_packages_dir(self) -> None:
        assert Path("packages") == PACKAGES_DIR

    def test_specs_dir(self) -> None:
        assert Path("specs") == SPECS_DIR

    def test_generated_backend_dir(self) -> None:
        assert GENERATED_BACKEND_DIR == GENERATED_DIR / "backend"

    def test_generated_frontend_dir(self) -> None:
        assert GENERATED_FRONTEND_DIR == GENERATED_DIR / "frontend"

    def test_app_backend_dir(self) -> None:
        assert APP_BACKEND_DIR == APP_DIR / "backend"

    def test_app_frontend_dir(self) -> None:
        assert APP_FRONTEND_DIR == APP_DIR / "frontend"

    def test_app_backend_extensions_dir(self) -> None:
        assert APP_BACKEND_EXTENSIONS_DIR == APP_BACKEND_DIR / "extensions"

    def test_packages_backend_dir(self) -> None:
        assert PACKAGES_BACKEND_DIR == PACKAGES_DIR / "backend"

    def test_packages_frontend_dir(self) -> None:
        assert PACKAGES_FRONTEND_DIR == PACKAGES_DIR / "frontend"

    def test_config_file(self) -> None:
        assert Path("prisme.toml") == CONFIG_FILE

    def test_manifest_path(self) -> None:
        assert MANIFEST_PATH == GENERATED_DIR / ".prisme-manifest.json"

    def test_domain_spec_file(self) -> None:
        assert DOMAIN_SPEC_FILE == SPECS_DIR / "models.py"

    def test_project_spec_file(self) -> None:
        assert PROJECT_SPEC_FILE == SPECS_DIR / "project.py"

    def test_docker_dir(self) -> None:
        assert Path("docker") == DOCKER_DIR

    def test_github_dir(self) -> None:
        assert Path(".github") == GITHUB_DIR

    def test_devcontainer_dir(self) -> None:
        assert Path(".devcontainer") == DEVCONTAINER_DIR

    def test_all_are_path_objects(self) -> None:
        for const in [
            GENERATED_DIR,
            APP_DIR,
            PACKAGES_DIR,
            SPECS_DIR,
            GENERATED_BACKEND_DIR,
            GENERATED_FRONTEND_DIR,
            APP_BACKEND_DIR,
            APP_FRONTEND_DIR,
            APP_BACKEND_EXTENSIONS_DIR,
            PACKAGES_BACKEND_DIR,
            PACKAGES_FRONTEND_DIR,
            CONFIG_FILE,
            MANIFEST_PATH,
            DOMAIN_SPEC_FILE,
            PROJECT_SPEC_FILE,
            DOCKER_DIR,
            GITHUB_DIR,
            DEVCONTAINER_DIR,
        ]:
            assert isinstance(const, Path)
