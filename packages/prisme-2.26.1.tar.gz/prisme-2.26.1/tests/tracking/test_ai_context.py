"""Tests for the AI context generation system."""

from __future__ import annotations

from pathlib import Path

from prisme.tracking.ai_context import AIContext, AIContextManager
from prisme.tracking.manifest import FileManifest, TrackedFile


def test_ai_context_to_dict():
    """Test converting AIContext to dictionary."""
    context = AIContext(
        spec_path="specs/models.py",
        project_name="my-app",
        prisme_version="0.12.1",
        models=["Customer", "Order"],
        generated_readonly_dirs=["services/_generated", "schemas"],
        extension_points=[
            {"path": "services/customer.py", "base": "services/_generated/customer_base.py"}
        ],
        commands={"generate": "uv run prism generate"},
    )

    data = context.to_dict()
    assert data["spec_path"] == "specs/models.py"
    assert data["project_name"] == "my-app"
    assert data["models"] == ["Customer", "Order"]
    assert "services/_generated" in data["generated_readonly_dirs"]
    assert len(data["extension_points"]) == 1
    assert data["protected_region_marker"] == "PRISM:PROTECTED"


def test_ai_context_save_and_load(tmp_path: Path):
    """Test saving and loading AI context."""
    context = AIContext(
        spec_path="specs/models.py",
        project_name="test-app",
        prisme_version="0.12.1",
        models=["User"],
        commands={"test": "uv run prism test"},
    )

    AIContextManager.save(context, tmp_path)

    loaded = AIContextManager.load(tmp_path)
    assert loaded is not None
    assert loaded.project_name == "test-app"
    assert loaded.models == ["User"]
    assert loaded.commands["test"] == "uv run prism test"


def test_ai_context_load_missing(tmp_path: Path):
    """Test loading returns None when file doesn't exist."""
    result = AIContextManager.load(tmp_path)
    assert result is None


def test_ai_context_generate(tmp_path: Path):
    """Test full generation from manifest data."""
    manifest = FileManifest()
    manifest.track_file(
        TrackedFile(
            path="src/app/schemas/customer.py",
            strategy="always_overwrite",
            content_hash="abc",
            generated_at="2026-01-01T00:00:00",
        )
    )
    manifest.track_file(
        TrackedFile(
            path="src/app/services/_generated/customer_base.py",
            strategy="always_overwrite",
            content_hash="def",
            generated_at="2026-01-01T00:00:00",
        )
    )
    manifest.track_file(
        TrackedFile(
            path="src/app/services/customer.py",
            strategy="generate_once",
            content_hash="ghi",
            generated_at="2026-01-01T00:00:00",
            extends="src/app/services/_generated/customer_base.py",
        )
    )

    spec_file = tmp_path / "specs" / "models.py"
    spec_file.parent.mkdir(parents=True)
    spec_file.write_text("# spec")

    AIContextManager.generate(
        output_dir=tmp_path,
        spec_file=spec_file,
        project_name="test-app",
        model_names=["Customer"],
        manifest=manifest,
    )

    loaded = AIContextManager.load(tmp_path)
    assert loaded is not None
    assert loaded.project_name == "test-app"
    assert loaded.models == ["Customer"]
    assert "src/app/services/_generated" in loaded.generated_readonly_dirs
    assert "src/app/schemas" in loaded.generated_readonly_dirs
    assert len(loaded.extension_points) == 1
    assert loaded.extension_points[0]["path"] == "src/app/services/customer.py"
    assert loaded.commands["generate"] == "uv run prism generate"
