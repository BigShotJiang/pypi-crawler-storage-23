"""Tests for PrismConfig (legacy config) and migration detector."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme import PrismConfig
from prisme.migration.detector import detect_versions


class TestPrismConfig:
    """Tests for PrismConfig.load_from_file."""

    def test_load_valid_config(self, tmp_path: Path) -> None:
        config_file = tmp_path / "prism.config.py"
        config_file.write_text(
            """\
from prisme import PrismConfig

config = PrismConfig(
    spec_path="specs/models.py",
    backend_path="packages/backend/src/app",
    frontend_path="packages/frontend",
)
"""
        )
        result = PrismConfig.load_from_file(config_file)
        assert result.spec_path == "specs/models.py"
        assert result.backend_path == "packages/backend/src/app"

    def test_load_config_file_not_found(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError, match="not found"):
            PrismConfig.load_from_file(tmp_path / "nonexistent.py")

    def test_load_config_no_config_variable(self, tmp_path: Path) -> None:
        config_file = tmp_path / "bad.py"
        config_file.write_text("x = 42\n")
        with pytest.raises(ValueError, match="must define a 'config' variable"):
            PrismConfig.load_from_file(config_file)

    def test_default_values(self) -> None:
        config = PrismConfig()
        assert config.spec_path == "specs/models.py"
        assert config.backend_port == 8000
        assert config.frontend_port == 5173
        assert config.enable_mcp is True
        assert config.enable_graphql is True
        assert config.enable_rest is True


class TestMigrationDetector:
    """Tests for detect_versions."""

    def test_empty_project(self, tmp_path: Path) -> None:
        info = detect_versions(tmp_path)
        assert not info.needs_config_migration

    def test_with_prisme_toml(self, tmp_path: Path) -> None:
        (tmp_path / "prisme.toml").write_text('prisme_version = "0.12.1"\n')
        info = detect_versions(tmp_path)
        assert not info.needs_config_migration

    def test_with_legacy_config(self, tmp_path: Path) -> None:
        (tmp_path / "prism.config.py").write_text("config = None\n")
        info = detect_versions(tmp_path)
        assert info.needs_config_migration
