"""Tests for the plan executor."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.planning.executor import PlanExecutionError, apply_plan
from prisme.planning.planner import GenerationPlan, PlannedFile, save_plan


class TestApplyPlan:
    """Tests for apply_plan."""

    def test_no_plan_raises_error(self, tmp_path: Path) -> None:
        with pytest.raises(PlanExecutionError, match="No plan found"):
            apply_plan(tmp_path)

    def test_returns_plan_when_exists(self, tmp_path: Path) -> None:
        plan = GenerationPlan(
            created_at="2024-01-01",
            spec_path="models.py",
            files=[
                PlannedFile(path="test.py", action="create", strategy="always_overwrite"),
            ],
        )
        save_plan(plan, tmp_path)
        result = apply_plan(tmp_path)
        assert isinstance(result, GenerationPlan)
        assert len(result.files) == 1


class TestPlanExecutionError:
    """Tests for PlanExecutionError."""

    def test_message(self) -> None:
        err = PlanExecutionError("test error")
        assert "test error" in str(err)
