Please refer to the **CONFIGURATION** section of the README of the
module *account_cutoff_base*.
