- Alexis de Lattre \<<alexis.delattre@akretion.com>\>

- Stéphane Bidoul \<<stephane.bidoul@acsone.eu>\>

- Jim Hoefnagels \<<jim.hoefnagels@dynapps.be>\>

- [Trobz](https://trobz.com):  
  - Dzung Tran \<<dungtd@trobz.com>\>
  - Thao Le <thaolt@trobz.com>
