# Copyright 2014-2022 ACSONE SA/NV (http://acsone.eu)
# @author Stéphane Bidoul <stephane.bidoul@acsone.eu>
# Copyright 2016-2022 Akretion (Alexis de Lattre <alexis.delattre@akretion.com>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).


import time

from odoo import Command, fields
from odoo.tests import tagged

from odoo.addons.account.tests.common import AccountTestInvoicingCommon


@tagged("post_install", "-at_install")
class TestCutoffPrepaid(AccountTestInvoicingCommon):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.env = cls.env(context=dict(cls.env.context, tracking_disable=True))
        cls.test_company_dict = cls.setup_other_company(name="Cutme Inc.")
        cls.company = cls.test_company_dict["company"]
        cls.env.user.write({"company_ids": [Command.link(cls.company.id)]})
        cls.inv_model = cls.env["account.move"]
        cls.cutoff_model = cls.env["account.cutoff"]
        cls.account_expense = cls.test_company_dict["default_account_expense"]
        cls.account_cutoff = cls.env["account.account"].create(
            {
                "account_type": "liability_current",
                "company_ids": [Command.set([cls.company.id])],
                "name": "Test cutoff",
                "code": "TC.1",
            }
        )
        cls.cutoff_journal = cls.test_company_dict["default_journal_misc"]
        cls.purchase_journal = cls.test_company_dict["default_journal_purchase"]
        cls.partner = cls.env["res.partner"].create({"name": "Odoo fanboy"})
        cls.company.write(
            {
                "default_cutoff_journal_id": cls.cutoff_journal.id,
                "default_prepaid_expense_account_id": cls.account_cutoff.id,
            }
        )

    def _date(self, date):
        """convert MM-DD to current year date YYYY-MM-DD"""
        return time.strftime("%Y-" + date)

    def _days(self, start_date, end_date):
        start_date = fields.Date.from_string(self._date(start_date))
        end_date = fields.Date.from_string(self._date(end_date))
        return (end_date - start_date).days + 1

    def _create_invoice(self, date, amount, start_date, end_date):
        invoice = self.inv_model.create(
            {
                "company_id": self.company.id,
                "invoice_date": self._date(date),
                "date": self._date(date),
                "partner_id": self.partner.id,
                "journal_id": self.purchase_journal.id,
                "move_type": "in_invoice",
                "invoice_line_ids": [
                    Command.create(
                        {
                            "name": "expense",
                            "price_unit": amount,
                            "quantity": 1,
                            "account_id": self.account_expense.id,
                            "start_date": self._date(start_date),
                            "end_date": self._date(end_date),
                        },
                    )
                ],
            }
        )
        invoice.action_post()
        self.assertEqual(amount, invoice.amount_untaxed)
        return invoice

    def _create_cutoff(self, date):
        cutoff = self.cutoff_model.create(
            {
                "company_id": self.company.id,
                "cutoff_date": self._date(date),
                "cutoff_type": "prepaid_expense",
            }
        )
        self.assertTrue(self.purchase_journal in cutoff.source_journal_ids)
        self.assertEqual(cutoff.cutoff_journal_id, self.cutoff_journal)
        self.assertEqual(cutoff.cutoff_account_id, self.account_cutoff)
        return cutoff

    def test_with_cutoff_before_after_and_in_the_middle(self):
        """basic test with cutoff before, after and in the middle"""
        amount = self._days("04-01", "06-30")
        amount_2months = self._days("05-01", "06-30")
        # invoice to be spread of 3 months
        self._create_invoice("01-15", amount, start_date="04-01", end_date="06-30")
        # cutoff after one month of invoice period -> 2 months cutoff
        cutoff = self._create_cutoff("04-30")
        cutoff.get_lines()
        self.assertEqual(amount_2months, cutoff.total_cutoff_amount)
        # cutoff at end of invoice period -> no cutoff
        cutoff = self._create_cutoff("06-30")
        cutoff.get_lines()
        self.assertEqual(0, cutoff.total_cutoff_amount)
        # cutoff before invoice period -> full value cutoff
        cutoff = self._create_cutoff("01-31")
        cutoff.get_lines()
        self.assertEqual(amount, cutoff.total_cutoff_amount)

    def tests_1(self):
        """generate move, and test move lines grouping"""
        # two invoices
        amount = self._days("04-01", "06-30")
        self._create_invoice("01-15", amount, start_date="04-01", end_date="06-30")
        self._create_invoice("01-16", amount, start_date="04-01", end_date="06-30")
        # cutoff before invoice period -> full value cutoff
        cutoff = self._create_cutoff("01-31")
        cutoff.get_lines()
        cutoff.create_move()
        self.assertEqual(amount * 2, cutoff.total_cutoff_amount)
        self.assertTrue(cutoff.move_id, "move not generated")
        # two invoices, but two lines (because the two cutoff lines
        # have been grouped into one line plus one counterpart)
        self.assertEqual(len(cutoff.move_id.line_ids), 2)

    def test_include_tax_lines(self):
        """Test that include_tax_lines includes tax move lines in cutoff."""
        tax = self.env["account.tax"].create(
            {
                "name": "Test Tax 10%",
                "type_tax_use": "purchase",
                "amount_type": "percent",
                "amount": 10,
                "company_id": self.company.id,
            }
        )
        amount = self._days("04-01", "06-30")
        amount_2months = self._days("05-01", "06-30")
        # Create invoice with tax
        invoice = self.inv_model.create(
            {
                "company_id": self.company.id,
                "invoice_date": self._date("01-15"),
                "date": self._date("01-15"),
                "partner_id": self.partner.id,
                "journal_id": self.purchase_journal.id,
                "move_type": "in_invoice",
                "invoice_line_ids": [
                    Command.create(
                        {
                            "name": "expense with tax",
                            "price_unit": amount,
                            "quantity": 1,
                            "account_id": self.account_expense.id,
                            "start_date": self._date("04-01"),
                            "end_date": self._date("06-30"),
                            "tax_ids": [Command.set(tax.ids)],
                        },
                    )
                ],
            }
        )
        invoice.action_post()
        # Set start_date and end_date on tax lines (not auto-propagated)
        tax_lines = invoice.line_ids.filtered(lambda line: line.display_type == "tax")
        self.assertTrue(tax_lines, "Invoice should have tax lines")
        tax_lines.write(
            {
                "start_date": self._date("04-01"),
                "end_date": self._date("06-30"),
            }
        )
        tax_line_balance = sum(tax_lines.mapped("balance"))

        # Without include_tax_lines: only product line in cutoff
        cutoff = self._create_cutoff("01-31")
        cutoff.get_lines()
        self.assertEqual(len(cutoff.line_ids), 1)
        self.assertEqual(cutoff.total_cutoff_amount, amount)
        cutoff.unlink()

        # With include_tax_lines, cutoff before period: full amount + tax
        cutoff = self.cutoff_model.create(
            {
                "company_id": self.company.id,
                "cutoff_date": self._date("01-31"),
                "cutoff_type": "prepaid_expense",
                "include_tax_lines": True,
            }
        )
        cutoff.get_lines()
        self.assertEqual(len(cutoff.line_ids), 2)
        self.assertEqual(
            cutoff.total_cutoff_amount,
            amount + tax_line_balance,
        )

        # With include_tax_lines, cutoff in the middle: prorated amount + tax
        cutoff = self.cutoff_model.create(
            {
                "company_id": self.company.id,
                "cutoff_date": self._date("04-30"),
                "cutoff_type": "prepaid_expense",
                "include_tax_lines": True,
            }
        )
        cutoff.get_lines()
        self.assertEqual(len(cutoff.line_ids), 2)
        expected_tax_cutoff = self.company.currency_id.round(
            tax_line_balance * amount_2months / amount
        )
        self.assertEqual(
            cutoff.total_cutoff_amount,
            amount_2months + expected_tax_cutoff,
        )

        # With include_tax_lines, cutoff at end of period: no cutoff
        cutoff = self.cutoff_model.create(
            {
                "company_id": self.company.id,
                "cutoff_date": self._date("06-30"),
                "cutoff_type": "prepaid_expense",
                "include_tax_lines": True,
            }
        )
        cutoff.get_lines()
        self.assertEqual(len(cutoff.line_ids), 0)
        self.assertEqual(cutoff.total_cutoff_amount, 0)
