"""Math Tools - Example tool module for ChukMCPServer."""
