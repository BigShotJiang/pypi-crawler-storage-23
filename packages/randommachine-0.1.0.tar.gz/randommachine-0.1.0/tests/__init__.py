"""
Tests for the randommachine package.
"""
