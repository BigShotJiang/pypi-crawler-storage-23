"""Backward-compatible setup.py — config lives in pyproject.toml."""
from setuptools import setup

setup()
