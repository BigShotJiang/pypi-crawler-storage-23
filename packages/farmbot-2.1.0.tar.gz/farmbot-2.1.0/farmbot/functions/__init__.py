"""
Initialization for functions module.
"""
