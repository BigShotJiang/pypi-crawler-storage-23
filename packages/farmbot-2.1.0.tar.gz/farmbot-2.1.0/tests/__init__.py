"""
Initialization for tests module.
"""
