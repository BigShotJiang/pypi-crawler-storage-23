# excel-backend

Turn any Excel or CSV file into a REST API with one command.

```bash
pip install excel-backend
excel-backend run students.xlsx
```

```
✓ Loaded students.xlsx
  students: 50 rows, 5 columns
  courses: 12 rows, 3 columns
  3 images extracted

✓ API running at http://127.0.0.1:8000
  Docs at http://127.0.0.1:8000/docs
```

Your data is now a full CRUD API:

```
GET    /students        → list all students
GET    /students/1      → get student by id
POST   /students        → create a student
PUT    /students/1      → update a student
DELETE /students/1      → delete a student
GET    /images/file.png → serve extracted images
```

Auto-generated Swagger docs at `/docs`.

## Install

```bash
pip install excel-backend
```

## CLI Usage

### Start API server

```bash
excel-backend run data.xlsx
excel-backend run data.csv
excel-backend run data.tsv
```

Options:

```bash
excel-backend run data.xlsx --port 3000
excel-backend run data.xlsx --host 0.0.0.0
excel-backend run data.xlsx --db data.sqlite  # persist to file
```

### Inspect schema

```bash
excel-backend schema data.xlsx
```

```
table: students
columns:
  - id INTEGER (primary key)
  - name TEXT
  - age INTEGER
  - photo IMAGE
```

## Python API

```python
from excel_backend import ExcelBackend

eb = ExcelBackend("students.xlsx")

# List tables
print(eb.tables)  # ["students", "courses"]

# Read data
for row in eb["students"]:
    print(row["name"])

# CRUD
eb.create("students", {"name": "Alice", "age": 22})
eb.update("students", 1, {"age": 23})
eb.delete("students", 1)

# Start API server
eb.serve(port=8000)
```

## How It Works

```
Excel/CSV → Schema Model → SQLite → FastAPI
```

1. **Loader** parses your file (`.xlsx`, `.csv`, `.tsv`)
2. **Schema engine** infers column types (INTEGER, FLOAT, TEXT, BOOLEAN, DATE, IMAGE)
3. **Storage adapter** creates tables and inserts data (SQLite)
4. **API generator** creates CRUD endpoints from the schema

Each sheet in an Excel file becomes a separate table with its own endpoints.

### Image Extraction

Images embedded in `.xlsx` files are automatically:

- Extracted from the zip archive
- Mapped to their row/column position
- Served at `/images/{filename}`
- Referenced in API responses

## Architecture

```
excel_backend/
├── schema/model.py      # Schema, Column, type inference
├── loader/
│   ├── base.py          # BaseLoader interface
│   ├── excel.py         # .xlsx parser + image extraction
│   └── csv.py           # .csv/.tsv parser
├── storage/
│   ├── base.py          # BaseStorage interface
│   └── sqlite.py        # SQLite adapter
├── api/generator.py     # Schema → FastAPI routes
└── cli/main.py          # CLI entry point
```

The **Schema model** is the core abstraction. Everything flows through it. Storage and API layers are pluggable — they only depend on the Schema, not on each other.

## Supported Types

| Excel Data | Detected Type |
|-----------|--------------|
| 1, 42, -3 | INTEGER |
| 3.14, 0.5 | FLOAT |
| "hello" | TEXT |
| TRUE/FALSE | BOOLEAN |
| 2024-01-15 | DATE |
| embedded image | IMAGE |

## License

MIT
