"""Base storage interface. Adapters consume Schema and provide CRUD."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from excel_backend.schema.model import Schema


class BaseStorage(ABC):
    @abstractmethod
    def create_table(self, schema: Schema) -> None: ...

    @abstractmethod
    def insert_rows(self, table: str, rows: list[dict[str, Any]]) -> None: ...

    @abstractmethod
    def get_all(self, table: str) -> list[dict[str, Any]]: ...

    @abstractmethod
    def get_one(self, table: str, pk_value: Any) -> dict[str, Any] | None: ...

    @abstractmethod
    def create(self, table: str, data: dict[str, Any]) -> dict[str, Any]: ...

    @abstractmethod
    def update(self, table: str, pk_value: Any, data: dict[str, Any]) -> dict[str, Any] | None: ...

    @abstractmethod
    def delete(self, table: str, pk_value: Any) -> bool: ...
