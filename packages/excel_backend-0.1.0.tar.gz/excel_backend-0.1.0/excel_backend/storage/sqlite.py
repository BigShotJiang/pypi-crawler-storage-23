"""SQLite storage adapter."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from excel_backend.schema.model import ColumnType, Schema
from excel_backend.storage.base import BaseStorage

_TYPE_MAP = {
    ColumnType.INTEGER: "INTEGER",
    ColumnType.FLOAT: "REAL",
    ColumnType.TEXT: "TEXT",
    ColumnType.BOOLEAN: "INTEGER",
    ColumnType.DATE: "TEXT",
    ColumnType.IMAGE: "TEXT",  # stores image URL path
}


class SQLiteStorage(BaseStorage):
    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._schemas: dict[str, Schema] = {}

    def create_table(self, schema: Schema) -> None:
        self._schemas[schema.table] = schema
        cols = []
        for c in schema.columns:
            parts = f'"{c.name}" {_TYPE_MAP[c.type]}'
            if c.primary_key:
                parts += " PRIMARY KEY"
                if c.name == "_id":
                    parts += " AUTOINCREMENT"
            cols.append(parts)
        sql = f'CREATE TABLE IF NOT EXISTS "{schema.table}" ({", ".join(cols)})'
        self._conn.execute(sql)
        self._conn.commit()

    def insert_rows(self, table: str, rows: list[dict[str, Any]]) -> None:
        if not rows:
            return
        schema = self._schemas[table]
        # Exclude auto-generated _id from inserts
        cols = [c.name for c in schema.columns if c.name != "_id"]
        placeholders = ", ".join("?" for _ in cols)
        col_names = ", ".join(f'"{c}"' for c in cols)
        sql = f'INSERT INTO "{table}" ({col_names}) VALUES ({placeholders})'

        values = []
        for row in rows:
            values.append(tuple(self._coerce(row.get(c), schema, c) for c in cols))
        self._conn.executemany(sql, values)
        self._conn.commit()

    def get_all(self, table: str) -> list[dict[str, Any]]:
        cur = self._conn.execute(f'SELECT * FROM "{table}"')
        return [dict(r) for r in cur.fetchall()]

    def get_one(self, table: str, pk_value: Any) -> dict[str, Any] | None:
        pk = self._pk_col(table)
        cur = self._conn.execute(f'SELECT * FROM "{table}" WHERE "{pk}" = ?', (pk_value,))
        row = cur.fetchone()
        return dict(row) if row else None

    def create(self, table: str, data: dict[str, Any]) -> dict[str, Any]:
        schema = self._schemas[table]
        cols = [c.name for c in schema.columns if c.name in data]
        placeholders = ", ".join("?" for _ in cols)
        col_names = ", ".join(f'"{c}"' for c in cols)
        values = tuple(self._coerce(data[c], schema, c) for c in cols)
        sql = f'INSERT INTO "{table}" ({col_names}) VALUES ({placeholders})'
        cur = self._conn.execute(sql, values)
        self._conn.commit()
        return self.get_one(table, cur.lastrowid or data.get(self._pk_col(table))) or data

    def update(self, table: str, pk_value: Any, data: dict[str, Any]) -> dict[str, Any] | None:
        if not self.get_one(table, pk_value):
            return None
        pk = self._pk_col(table)
        sets = ", ".join(f'"{k}" = ?' for k in data)
        values = tuple(data.values()) + (pk_value,)
        self._conn.execute(f'UPDATE "{table}" SET {sets} WHERE "{pk}" = ?', values)
        self._conn.commit()
        return self.get_one(table, pk_value)

    def delete(self, table: str, pk_value: Any) -> bool:
        pk = self._pk_col(table)
        cur = self._conn.execute(f'DELETE FROM "{table}" WHERE "{pk}" = ?', (pk_value,))
        self._conn.commit()
        return cur.rowcount > 0

    def _pk_col(self, table: str) -> str:
        schema = self._schemas[table]
        pk = schema.pk
        return pk.name if pk else "_id"

    def _coerce(self, value: Any, schema: Schema, col_name: str) -> Any:
        if value is None:
            return None
        col = next((c for c in schema.columns if c.name == col_name), None)
        if col and col.type == ColumnType.BOOLEAN:
            if isinstance(value, str):
                return 1 if value.lower() in ("true", "yes", "1") else 0
            return 1 if value else 0
        return value
