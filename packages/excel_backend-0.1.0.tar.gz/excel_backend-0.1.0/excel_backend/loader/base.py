"""Base loader interface. All loaders produce TableData through the Schema layer."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from excel_backend.schema.model import TableData


class BaseLoader(ABC):
    def __init__(self, path: Path):
        self.path = path

    @abstractmethod
    def load(self) -> list[TableData]:
        """Load file and return a list of TableData (one per sheet/table)."""
        ...
