"""CSV/TSV loader — parses delimited text files into TableData."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from excel_backend.loader.base import BaseLoader
from excel_backend.schema.model import TableData, infer_schema


class CSVLoader(BaseLoader):
    def load(self) -> list[TableData]:
        delimiter = "\t" if self.path.suffix.lower() == ".tsv" else ","

        with open(self.path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            headers = reader.fieldnames or []
            rows: list[dict[str, Any]] = list(reader)

        if not headers or not rows:
            return []

        table_name = self.path.stem
        schema = infer_schema(table_name, headers, rows)
        return [TableData(schema=schema, rows=rows)]
