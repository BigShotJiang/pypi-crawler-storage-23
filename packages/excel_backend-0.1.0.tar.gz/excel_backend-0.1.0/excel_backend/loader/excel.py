"""Excel loader — parses .xlsx files, extracts data and images."""

from __future__ import annotations

import zipfile
from io import BytesIO
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import openpyxl

from excel_backend.loader.base import BaseLoader
from excel_backend.schema.model import TableData, infer_schema

# XML namespaces used in xlsx drawing files
_NS = {
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}


class ExcelLoader(BaseLoader):
    def load(self) -> list[TableData]:
        wb = openpyxl.load_workbook(self.path, data_only=True)
        image_map = self._extract_images()
        results: list[TableData] = []

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            raw_rows = list(ws.iter_rows(values_only=True))
            if not raw_rows:
                continue

            headers = [str(h) if h is not None else f"col_{i}" for i, h in enumerate(raw_rows[0])]
            rows: list[dict[str, Any]] = []
            for row in raw_rows[1:]:
                if all(v is None for v in row):
                    continue
                rows.append(dict(zip(headers, row)))

            if not rows:
                continue

            # Get images for this sheet
            sheet_images = image_map.get(sheet_name, {})
            image_columns: set[str] = set()
            images: dict[str, bytes] = {}

            for (row_idx, col_idx), img_bytes in sheet_images.items():
                if col_idx < len(headers):
                    col_name = headers[col_idx]
                    image_columns.add(col_name)
                    ext = _guess_ext(img_bytes)
                    fname = f"{sheet_name}_{row_idx}_{col_name}.{ext}"
                    images[fname] = img_bytes
                    # Inject image path into row data
                    if 0 < row_idx <= len(rows):
                        rows[row_idx - 1][col_name] = f"/images/{fname}"

            schema = infer_schema(sheet_name, headers, rows, image_columns)
            results.append(TableData(schema=schema, rows=rows, images=images))

        wb.close()
        return results

    def _extract_images(self) -> dict[str, dict[tuple[int, int], bytes]]:
        """Parse xlsx zip to map images to (sheet, row, col) positions."""
        result: dict[str, dict[tuple[int, int], bytes]] = {}

        try:
            zf = zipfile.ZipFile(self.path)
        except zipfile.BadZipFile:
            return result

        with zf:
            # Map sheet index to sheet name via workbook.xml
            sheet_names = self._get_sheet_names(zf)

            for i, sheet_name in enumerate(sheet_names, 1):
                sheet_rels_path = f"xl/worksheets/_rels/sheet{i}.xml.rels"
                if sheet_rels_path not in zf.namelist():
                    continue

                # Find drawing reference for this sheet
                drawing_path = self._find_drawing(zf, sheet_rels_path)
                if not drawing_path:
                    continue

                # Parse drawing to get anchor positions + image refs
                drawing_rels_path = f"xl/drawings/_rels/{Path(drawing_path).name}.rels"
                image_refs = self._parse_drawing_rels(zf, drawing_rels_path)
                anchors = self._parse_anchors(zf, drawing_path)

                sheet_images: dict[tuple[int, int], bytes] = {}
                for r_id, (row, col) in anchors.items():
                    img_path = image_refs.get(r_id)
                    if img_path and img_path in zf.namelist():
                        sheet_images[(row, col)] = zf.read(img_path)

                if sheet_images:
                    result[sheet_name] = sheet_images

        return result

    def _get_sheet_names(self, zf: zipfile.ZipFile) -> list[str]:
        try:
            tree = ET.parse(zf.open("xl/workbook.xml"))
            ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            return [el.get("name", "") for el in tree.findall(".//s:sheet", ns)]
        except Exception:
            return []

    def _find_drawing(self, zf: zipfile.ZipFile, rels_path: str) -> str | None:
        try:
            tree = ET.parse(zf.open(rels_path))
            for rel in tree.findall(".//rel:Relationship", _NS):
                if "drawing" in rel.get("Type", ""):
                    target = rel.get("Target", "")
                    return f"xl/{target.lstrip('../')}" if target else None
        except Exception:
            pass
        return None

    def _parse_drawing_rels(self, zf: zipfile.ZipFile, path: str) -> dict[str, str]:
        """Map rId -> image file path."""
        refs: dict[str, str] = {}
        if path not in zf.namelist():
            return refs
        try:
            tree = ET.parse(zf.open(path))
            for rel in tree.findall(".//rel:Relationship", _NS):
                if "image" in rel.get("Type", ""):
                    target = rel.get("Target", "")
                    refs[rel.get("Id", "")] = f"xl/media/{Path(target).name}"
        except Exception:
            pass
        return refs

    def _parse_anchors(self, zf: zipfile.ZipFile, path: str) -> dict[str, tuple[int, int]]:
        """Parse drawing XML to get rId -> (row, col) mapping."""
        anchors: dict[str, tuple[int, int]] = {}
        if path not in zf.namelist():
            return anchors
        try:
            tree = ET.parse(zf.open(path))
            root = tree.getroot()
            for anchor_type in ("twoCellAnchor", "oneCellAnchor"):
                for anchor in root.findall(f"xdr:{anchor_type}", _NS):
                    from_el = anchor.find("xdr:from", _NS)
                    if from_el is None:
                        continue
                    row_el = from_el.find("xdr:row", _NS)
                    col_el = from_el.find("xdr:col", _NS)
                    if row_el is None or col_el is None:
                        continue
                    row = int(row_el.text or 0)
                    col = int(col_el.text or 0)

                    # Find the embedded image reference
                    blip = anchor.find(".//a:blip", _NS)
                    if blip is not None:
                        r_id = blip.get(f"{{{_NS['r']}}}embed", "")
                        if r_id:
                            anchors[r_id] = (row, col)
        except Exception:
            pass
        return anchors


def _guess_ext(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:2] == b"\xff\xd8":
        return "jpeg"
    if data[:4] == b"GIF8":
        return "gif"
    return "png"
