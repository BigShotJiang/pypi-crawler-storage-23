"""excel-backend: Turn any Excel or CSV file into a backend API with one command."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterator

from excel_backend.schema.model import Schema, TableData


class ExcelBackend:
    """Main library interface.

    Usage:
        eb = ExcelBackend("students.xlsx")
        for row in eb["students"]:
            print(row["name"])
    """

    def __init__(self, path: str | Path, db: str = ":memory:"):
        from excel_backend.loader.csv import CSVLoader
        from excel_backend.loader.excel import ExcelLoader
        from excel_backend.storage.sqlite import SQLiteStorage

        self.path = Path(path)
        ext = self.path.suffix.lower()

        if ext == ".xlsx":
            loader = ExcelLoader(self.path)
        elif ext in (".csv", ".tsv"):
            loader = CSVLoader(self.path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")

        self._tables = loader.load()
        self._storage = SQLiteStorage(db)
        self._schemas: dict[str, Schema] = {}

        for td in self._tables:
            self._storage.create_table(td.schema)
            self._storage.insert_rows(td.schema.table, td.rows)
            self._schemas[td.schema.table] = td.schema

    @property
    def tables(self) -> list[str]:
        return list(self._schemas.keys())

    @property
    def schemas(self) -> dict[str, Schema]:
        return dict(self._schemas)

    def __getitem__(self, table: str) -> list[dict[str, Any]]:
        return self._storage.get_all(table)

    def __iter__(self) -> Iterator[str]:
        return iter(self.tables)

    def get(self, table: str, pk: Any) -> dict[str, Any] | None:
        return self._storage.get_one(table, pk)

    def create(self, table: str, data: dict[str, Any]) -> dict[str, Any]:
        return self._storage.create(table, data)

    def update(self, table: str, pk: Any, data: dict[str, Any]) -> dict[str, Any] | None:
        return self._storage.update(table, pk, data)

    def delete(self, table: str, pk: Any) -> bool:
        return self._storage.delete(table, pk)

    def serve(self, host: str = "127.0.0.1", port: int = 8000) -> None:
        """Start the API server programmatically."""
        import uvicorn

        from excel_backend.api.generator import create_app

        app = create_app(self._storage, list(self._schemas.values()))
        uvicorn.run(app, host=host, port=port)
