"""API generator — Schema → FastAPI CRUD routes + image serving."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse

from excel_backend.schema.model import Schema
from excel_backend.storage.base import BaseStorage


def create_app(
    storage: BaseStorage,
    schemas: list[Schema],
    image_dir: Path | None = None,
) -> FastAPI:
    app = FastAPI(title="excel-backend", description="Auto-generated API from spreadsheet data")

    # Index route — list all available tables
    @app.get("/")
    def index():
        return {
            "tables": [s.table for s in schemas],
            "endpoints": {s.table: f"/{s.table}" for s in schemas},
        }

    # Generate CRUD routes for each table
    for schema in schemas:
        _register_routes(app, storage, schema)

    # Image serving
    if image_dir and image_dir.exists():
        @app.get("/images/{filename}")
        def serve_image(filename: str):
            path = image_dir / filename
            if not path.exists():
                raise HTTPException(404, "Image not found")
            return FileResponse(path)

    return app


def _register_routes(app: FastAPI, storage: BaseStorage, schema: Schema) -> None:
    table = schema.table
    pk_name = schema.pk.name if schema.pk else "_id"

    @app.get(f"/{table}", tags=[table])
    def get_all(request: Request):
        return storage.get_all(table)

    @app.get(f"/{table}/{{pk}}", tags=[table])
    def get_one(pk: str, request: Request):
        # Try int conversion for integer PKs
        pk_val = _parse_pk(pk)
        row = storage.get_one(table, pk_val)
        if not row:
            raise HTTPException(404, f"{table} with {pk_name}={pk} not found")
        return row

    @app.post(f"/{table}", tags=[table], status_code=201)
    async def create_one(request: Request):
        data = await request.json()
        return storage.create(table, data)

    @app.put(f"/{table}/{{pk}}", tags=[table])
    async def update_one(pk: str, request: Request):
        pk_val = _parse_pk(pk)
        data = await request.json()
        row = storage.update(table, pk_val, data)
        if not row:
            raise HTTPException(404, f"{table} with {pk_name}={pk} not found")
        return row

    @app.delete(f"/{table}/{{pk}}", tags=[table])
    def delete_one(pk: str, request: Request):
        pk_val = _parse_pk(pk)
        if not storage.delete(table, pk_val):
            raise HTTPException(404, f"{table} with {pk_name}={pk} not found")
        return {"deleted": True}


def _parse_pk(pk: str):
    try:
        return int(pk)
    except ValueError:
        return pk
