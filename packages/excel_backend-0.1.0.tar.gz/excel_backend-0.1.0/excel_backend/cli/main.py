"""CLI — the entry point. excel-backend run file.xlsx"""

from __future__ import annotations

from pathlib import Path

import typer
import uvicorn

app = typer.Typer(
    name="excel-backend",
    help="Turn any Excel or CSV file into a backend API with one command.",
    add_completion=False,
)


def _get_loader(path: Path):
    from excel_backend.loader.csv import CSVLoader
    from excel_backend.loader.excel import ExcelLoader

    ext = path.suffix.lower()
    if ext == ".xlsx":
        return ExcelLoader(path)
    if ext in (".csv", ".tsv"):
        return CSVLoader(path)
    raise typer.BadParameter(f"Unsupported file type: {ext}. Use .xlsx, .csv, or .tsv")


@app.command()
def run(
    file: Path = typer.Argument(..., help="Path to .xlsx, .csv, or .tsv file"),
    port: int = typer.Option(8000, "--port", "-p", help="Port to run the server on"),
    host: str = typer.Option("127.0.0.1", "--host", "-h", help="Host to bind to"),
    db: str = typer.Option("", "--db", help="SQLite database path (default: in-memory)"),
):
    """Start a REST API server from a spreadsheet file."""
    if not file.exists():
        typer.echo(f"Error: File not found: {file}", err=True)
        raise typer.Exit(1)

    from excel_backend.api.generator import create_app
    from excel_backend.storage.sqlite import SQLiteStorage

    loader = _get_loader(file)
    tables = loader.load()

    if not tables:
        typer.echo("Error: No data found in file.", err=True)
        raise typer.Exit(1)

    # Save images to disk
    image_dir = Path(".excel_backend_images")
    has_images = any(t.images for t in tables)
    if has_images:
        image_dir.mkdir(exist_ok=True)
        for table_data in tables:
            for fname, img_bytes in table_data.images.items():
                (image_dir / fname).write_bytes(img_bytes)

    # Storage
    storage = SQLiteStorage(db or ":memory:")
    schemas = []
    for table_data in tables:
        storage.create_table(table_data.schema)
        storage.insert_rows(table_data.schema.table, table_data.rows)
        schemas.append(table_data.schema)

    # Print summary
    typer.echo(f"\n✓ Loaded {file.name}")
    for s in schemas:
        row_count = len(storage.get_all(s.table))
        typer.echo(f"  {s.table}: {row_count} rows, {len(s.columns)} columns")
    if has_images:
        total_images = sum(len(t.images) for t in tables)
        typer.echo(f"  {total_images} images extracted")
    typer.echo(f"\n✓ API running at http://{host}:{port}")
    typer.echo(f"  Docs at http://{host}:{port}/docs\n")

    # Start server
    api = create_app(storage, schemas, image_dir if has_images else None)
    uvicorn.run(api, host=host, port=port, log_level="info")


@app.command()
def schema(
    file: Path = typer.Argument(..., help="Path to .xlsx, .csv, or .tsv file"),
):
    """Print the detected schema for a file."""
    if not file.exists():
        typer.echo(f"Error: File not found: {file}", err=True)
        raise typer.Exit(1)

    loader = _get_loader(file)
    tables = loader.load()

    for table_data in tables:
        s = table_data.schema
        typer.echo(f"\ntable: {s.table}")
        typer.echo("columns:")
        for col in s.columns:
            pk = " (primary key)" if col.primary_key else ""
            typer.echo(f"  - {col.name} {col.type.value}{pk}")


if __name__ == "__main__":
    app()
