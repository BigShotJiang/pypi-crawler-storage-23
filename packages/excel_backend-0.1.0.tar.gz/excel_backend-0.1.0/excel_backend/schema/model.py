"""Schema model — the core abstraction that everything flows through."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class ColumnType(Enum):
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    TEXT = "TEXT"
    BOOLEAN = "BOOLEAN"
    DATE = "DATE"
    IMAGE = "IMAGE"


@dataclass
class Column:
    name: str
    type: ColumnType
    primary_key: bool = False


@dataclass
class Schema:
    table: str
    columns: list[Column]

    @property
    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]

    @property
    def pk(self) -> Column | None:
        return next((c for c in self.columns if c.primary_key), None)


@dataclass
class TableData:
    schema: Schema
    rows: list[dict[str, Any]]
    images: dict[str, bytes] = field(default_factory=dict)  # filename -> bytes


def infer_type(values: list[Any]) -> ColumnType:
    """Infer column type from a sample of non-None values."""
    samples = [v for v in values if v is not None and str(v).strip() != ""]
    if not samples:
        return ColumnType.TEXT

    # Check if all values are already typed (openpyxl returns native types)
    types = {type(v) for v in samples}

    if types <= {bool}:
        return ColumnType.BOOLEAN
    if types <= {int}:
        return ColumnType.INTEGER
    if types <= {int, float}:
        return ColumnType.FLOAT
    if types <= {datetime}:
        return ColumnType.DATE

    # String-based inference for CSV data
    for parser, col_type in [
        (lambda v: v.lower() in ("true", "false", "yes", "no"), ColumnType.BOOLEAN),
        (lambda v: int(v) is not None, ColumnType.INTEGER),
        (lambda v: float(v) is not None, ColumnType.FLOAT),
    ]:
        try:
            if all(parser(str(v)) for v in samples):
                return col_type
        except (ValueError, TypeError, AttributeError):
            continue

    return ColumnType.TEXT


def infer_schema(
    table_name: str,
    headers: list[str],
    rows: list[dict[str, Any]],
    image_columns: set[str] | None = None,
) -> Schema:
    """Build a Schema from headers, sample rows, and known image columns."""
    image_columns = image_columns or set()
    columns: list[Column] = []

    for i, header in enumerate(headers):
        clean = _clean_header(header)
        if clean in image_columns:
            col_type = ColumnType.IMAGE
        else:
            values = [r.get(header) for r in rows[:100]]
            col_type = infer_type(values)

        is_pk = clean.lower() == "id" and i == 0
        columns.append(Column(name=clean, type=col_type, primary_key=is_pk))

    # Auto-add primary key if none detected
    if not any(c.primary_key for c in columns):
        columns.insert(0, Column(name="_id", type=ColumnType.INTEGER, primary_key=True))

    return Schema(table=_clean_table_name(table_name), columns=columns)


def _clean_header(name: str) -> str:
    return str(name).strip().lower().replace(" ", "_").replace("-", "_")


def _clean_table_name(name: str) -> str:
    return str(name).strip().lower().replace(" ", "_").replace("-", "_")
