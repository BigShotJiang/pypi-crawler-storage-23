"""Tests for SQLite storage adapter."""

import pytest

from excel_backend.schema.model import Column, ColumnType, Schema
from excel_backend.storage.sqlite import SQLiteStorage


@pytest.fixture
def storage():
    s = SQLiteStorage(":memory:")
    schema = Schema("users", [
        Column("id", ColumnType.INTEGER, primary_key=True),
        Column("name", ColumnType.TEXT),
        Column("age", ColumnType.INTEGER),
        Column("active", ColumnType.BOOLEAN),
    ])
    s.create_table(schema)
    s.insert_rows("users", [
        {"id": 1, "name": "Alice", "age": 22, "active": True},
        {"id": 2, "name": "Bob", "age": 25, "active": False},
        {"id": 3, "name": "Charlie", "age": 21, "active": True},
    ])
    return s


class TestSQLiteStorage:
    def test_get_all(self, storage):
        rows = storage.get_all("users")
        assert len(rows) == 3
        assert rows[0]["name"] == "Alice"

    def test_get_one(self, storage):
        row = storage.get_one("users", 2)
        assert row["name"] == "Bob"

    def test_get_one_not_found(self, storage):
        assert storage.get_one("users", 999) is None

    def test_create(self, storage):
        row = storage.create("users", {"id": 4, "name": "Diana", "age": 23, "active": True})
        assert row["name"] == "Diana"
        assert len(storage.get_all("users")) == 4

    def test_update(self, storage):
        row = storage.update("users", 1, {"age": 30})
        assert row["age"] == 30
        assert storage.get_one("users", 1)["age"] == 30

    def test_update_not_found(self, storage):
        assert storage.update("users", 999, {"age": 30}) is None

    def test_delete(self, storage):
        assert storage.delete("users", 1) is True
        assert len(storage.get_all("users")) == 2
        assert storage.get_one("users", 1) is None

    def test_delete_not_found(self, storage):
        assert storage.delete("users", 999) is False

    def test_boolean_coercion(self, storage):
        row = storage.get_one("users", 1)
        assert row["active"] == 1  # True stored as 1
        row = storage.get_one("users", 2)
        assert row["active"] == 0  # False stored as 0


class TestAutoIncrementPK:
    def test_auto_id(self):
        s = SQLiteStorage(":memory:")
        schema = Schema("items", [
            Column("_id", ColumnType.INTEGER, primary_key=True),
            Column("name", ColumnType.TEXT),
        ])
        s.create_table(schema)
        s.insert_rows("items", [{"name": "A"}, {"name": "B"}])
        rows = s.get_all("items")
        assert rows[0]["_id"] == 1
        assert rows[1]["_id"] == 2
