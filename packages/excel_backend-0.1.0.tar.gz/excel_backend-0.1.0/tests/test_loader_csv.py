"""Tests for CSV loader."""

import pytest
from pathlib import Path
from tempfile import NamedTemporaryFile

from excel_backend.loader.csv import CSVLoader
from excel_backend.schema.model import ColumnType


def _write_csv(content: str, suffix: str = ".csv") -> Path:
    f = NamedTemporaryFile(mode="w", suffix=suffix, delete=False, encoding="utf-8")
    f.write(content)
    f.close()
    return Path(f.name)


class TestCSVLoader:
    def test_basic_csv(self):
        path = _write_csv("id,name,age\n1,Alice,22\n2,Bob,25\n")
        tables = CSVLoader(path).load()
        assert len(tables) == 1
        td = tables[0]
        assert len(td.rows) == 2
        assert td.rows[0]["name"] == "Alice"

    def test_schema_inference(self):
        path = _write_csv("id,name,score\n1,Alice,95.5\n2,Bob,87.0\n")
        td = CSVLoader(path).load()[0]
        col_map = {c.name: c.type for c in td.schema.columns}
        assert col_map["id"] == ColumnType.INTEGER
        assert col_map["name"] == ColumnType.TEXT
        assert col_map["score"] == ColumnType.FLOAT

    def test_tsv_file(self):
        path = _write_csv("id\tname\n1\tAlice\n2\tBob\n", suffix=".tsv")
        tables = CSVLoader(path).load()
        assert len(tables) == 1
        assert tables[0].rows[0]["name"] == "Alice"

    def test_table_name_from_filename(self):
        path = _write_csv("a,b\n1,2\n")
        td = CSVLoader(path).load()[0]
        assert td.schema.table == path.stem

    def test_empty_csv(self):
        path = _write_csv("")
        tables = CSVLoader(path).load()
        assert tables == []

    def test_no_images(self):
        path = _write_csv("id,name\n1,Alice\n")
        td = CSVLoader(path).load()[0]
        assert td.images == {}
