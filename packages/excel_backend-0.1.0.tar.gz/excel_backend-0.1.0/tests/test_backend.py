"""Tests for ExcelBackend library API."""

import pytest
from pathlib import Path
from tempfile import NamedTemporaryFile

from excel_backend import ExcelBackend


def _write_csv(content: str) -> Path:
    f = NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8")
    f.write(content)
    f.close()
    return Path(f.name)


@pytest.fixture
def eb():
    path = _write_csv("id,name,age\n1,Alice,22\n2,Bob,25\n3,Charlie,21\n")
    return ExcelBackend(path)


class TestExcelBackend:
    def test_tables(self, eb):
        assert len(eb.tables) == 1

    def test_getitem(self, eb):
        rows = eb[eb.tables[0]]
        assert len(rows) == 3
        assert rows[0]["name"] == "Alice"

    def test_iter(self, eb):
        assert list(eb) == eb.tables

    def test_get(self, eb):
        table = eb.tables[0]
        row = eb.get(table, 1)
        assert row["name"] == "Alice"

    def test_create(self, eb):
        table = eb.tables[0]
        row = eb.create(table, {"id": 4, "name": "Diana", "age": 23})
        assert row["name"] == "Diana"
        assert len(eb[table]) == 4

    def test_update(self, eb):
        table = eb.tables[0]
        row = eb.update(table, 1, {"age": 30})
        assert row["age"] == 30

    def test_delete(self, eb):
        table = eb.tables[0]
        assert eb.delete(table, 1) is True
        assert len(eb[table]) == 2

    def test_unsupported_format(self):
        f = NamedTemporaryFile(suffix=".json", delete=False)
        f.close()
        with pytest.raises(ValueError, match="Unsupported"):
            ExcelBackend(f.name)
