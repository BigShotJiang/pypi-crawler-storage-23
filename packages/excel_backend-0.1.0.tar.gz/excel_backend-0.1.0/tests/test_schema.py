"""Tests for schema model and type inference."""

import pytest
from datetime import datetime
from excel_backend.schema.model import (
    Column, ColumnType, Schema, TableData,
    infer_type, infer_schema, _clean_header, _clean_table_name,
)


class TestInferType:
    def test_integers(self):
        assert infer_type([1, 2, 3]) == ColumnType.INTEGER

    def test_floats(self):
        assert infer_type([1.5, 2.3]) == ColumnType.FLOAT

    def test_mixed_int_float(self):
        assert infer_type([1, 2.5, 3]) == ColumnType.FLOAT

    def test_booleans(self):
        assert infer_type([True, False, True]) == ColumnType.BOOLEAN

    def test_dates(self):
        assert infer_type([datetime(2024, 1, 1), datetime(2024, 6, 15)]) == ColumnType.DATE

    def test_strings(self):
        assert infer_type(["hello", "world"]) == ColumnType.TEXT

    def test_empty_values(self):
        assert infer_type([None, None, ""]) == ColumnType.TEXT

    def test_string_integers(self):
        """CSV data comes as strings — should still detect INTEGER."""
        assert infer_type(["1", "2", "3"]) == ColumnType.INTEGER

    def test_string_floats(self):
        assert infer_type(["1.5", "2.3"]) == ColumnType.FLOAT

    def test_string_booleans(self):
        assert infer_type(["true", "false", "true"]) == ColumnType.BOOLEAN


class TestInferSchema:
    def test_basic_schema(self):
        headers = ["id", "name", "age"]
        rows = [
            {"id": 1, "name": "Alice", "age": 22},
            {"id": 2, "name": "Bob", "age": 25},
        ]
        schema = infer_schema("students", headers, rows)
        assert schema.table == "students"
        assert schema.pk.name == "id"
        assert schema.pk.primary_key is True

        col_map = {c.name: c.type for c in schema.columns}
        assert col_map["id"] == ColumnType.INTEGER
        assert col_map["name"] == ColumnType.TEXT
        assert col_map["age"] == ColumnType.INTEGER

    def test_auto_pk_when_no_id_column(self):
        headers = ["name", "age"]
        rows = [{"name": "Alice", "age": 22}]
        schema = infer_schema("people", headers, rows)
        assert schema.pk.name == "_id"
        assert schema.pk.primary_key is True

    def test_image_columns(self):
        headers = ["id", "name", "photo"]
        rows = [{"id": 1, "name": "Alice", "photo": "/images/test.png"}]
        schema = infer_schema("students", headers, rows, image_columns={"photo"})
        col_map = {c.name: c.type for c in schema.columns}
        assert col_map["photo"] == ColumnType.IMAGE

    def test_clean_headers(self):
        headers = ["Student Name", "Date-Of-Birth"]
        rows = [{"Student Name": "Alice", "Date-Of-Birth": "2000-01-01"}]
        schema = infer_schema("My Sheet", headers, rows)
        assert schema.table == "my_sheet"
        names = schema.column_names
        assert "student_name" in names
        assert "date_of_birth" in names


class TestSchemaProperties:
    def test_column_names(self):
        schema = Schema("t", [Column("a", ColumnType.TEXT), Column("b", ColumnType.INTEGER)])
        assert schema.column_names == ["a", "b"]

    def test_pk_found(self):
        schema = Schema("t", [Column("id", ColumnType.INTEGER, primary_key=True)])
        assert schema.pk.name == "id"

    def test_pk_none(self):
        schema = Schema("t", [Column("name", ColumnType.TEXT)])
        assert schema.pk is None


class TestCleanHelpers:
    def test_clean_header(self):
        assert _clean_header("  First Name ") == "first_name"
        assert _clean_header("date-created") == "date_created"

    def test_clean_table_name(self):
        assert _clean_table_name("My Sheet") == "my_sheet"
        assert _clean_table_name("sales-data") == "sales_data"
