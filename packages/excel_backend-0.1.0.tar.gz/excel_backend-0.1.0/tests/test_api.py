"""Tests for API generator — Schema → FastAPI CRUD routes."""

import pytest
from fastapi.testclient import TestClient

from excel_backend.api.generator import create_app
from excel_backend.schema.model import Column, ColumnType, Schema
from excel_backend.storage.sqlite import SQLiteStorage


@pytest.fixture
def client():
    storage = SQLiteStorage(":memory:")
    schema = Schema("students", [
        Column("id", ColumnType.INTEGER, primary_key=True),
        Column("name", ColumnType.TEXT),
        Column("age", ColumnType.INTEGER),
    ])
    storage.create_table(schema)
    storage.insert_rows("students", [
        {"id": 1, "name": "Alice", "age": 22},
        {"id": 2, "name": "Bob", "age": 25},
    ])
    app = create_app(storage, [schema])
    return TestClient(app)


class TestIndex:
    def test_index_lists_tables(self, client):
        r = client.get("/")
        assert r.status_code == 200
        assert "students" in r.json()["tables"]


class TestGetAll:
    def test_returns_all_rows(self, client):
        r = client.get("/students")
        assert r.status_code == 200
        assert len(r.json()) == 2

    def test_row_content(self, client):
        rows = client.get("/students").json()
        assert rows[0]["name"] == "Alice"


class TestGetOne:
    def test_found(self, client):
        r = client.get("/students/1")
        assert r.status_code == 200
        assert r.json()["name"] == "Alice"

    def test_not_found(self, client):
        r = client.get("/students/999")
        assert r.status_code == 404


class TestCreate:
    def test_create_row(self, client):
        r = client.post("/students", json={"id": 3, "name": "Charlie", "age": 21})
        assert r.status_code == 201
        assert r.json()["name"] == "Charlie"
        assert len(client.get("/students").json()) == 3


class TestUpdate:
    def test_update_row(self, client):
        r = client.put("/students/1", json={"age": 30})
        assert r.status_code == 200
        assert r.json()["age"] == 30

    def test_update_not_found(self, client):
        r = client.put("/students/999", json={"age": 30})
        assert r.status_code == 404


class TestDelete:
    def test_delete_row(self, client):
        r = client.delete("/students/1")
        assert r.status_code == 200
        assert r.json()["deleted"] is True
        assert len(client.get("/students").json()) == 1

    def test_delete_not_found(self, client):
        r = client.delete("/students/999")
        assert r.status_code == 404


class TestMultiTable:
    def test_two_tables(self):
        storage = SQLiteStorage(":memory:")
        s1 = Schema("students", [
            Column("id", ColumnType.INTEGER, primary_key=True),
            Column("name", ColumnType.TEXT),
        ])
        s2 = Schema("courses", [
            Column("id", ColumnType.INTEGER, primary_key=True),
            Column("title", ColumnType.TEXT),
        ])
        storage.create_table(s1)
        storage.create_table(s2)
        storage.insert_rows("students", [{"id": 1, "name": "Alice"}])
        storage.insert_rows("courses", [{"id": 1, "title": "Math"}])

        app = create_app(storage, [s1, s2])
        c = TestClient(app)

        assert len(c.get("/").json()["tables"]) == 2
        assert c.get("/students").json()[0]["name"] == "Alice"
        assert c.get("/courses").json()[0]["title"] == "Math"
