"""Allow running helloagents as a module: python -m helloagents."""

from helloagents.cli import main

main()
