from tko.play.flags import Flags
from tko.play.floating_drop_down import FloatingDropDown
from tko.play.floating_drop_down import FloatingInputData
from tko.util.text import Text
from tko.util.symbols import symbols
from tko.play.keys import GuiKeys
from tko.play.play_actions import PlayActions
from tko.play.floating_calibrate import FloatingCalibrate
from tko.play.floating import Floating

class PlayPalette:
    def __init__(self, actions: PlayActions):
        self.actions = actions
        self.app = self.actions.settings.app
        self.fman = self.actions.fman
        self.gui = self.actions.gui

    def command_pallete(self):
        options: list[FloatingInputData] = []

        def icon(value: bool):
            return Text.Token("✓", "g") if value else Text.Token("✗", "r")
        
        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Tarefa: {y} para o repositório", symbols.action, "Baixar"),
                self.actions.down_remote_task,
                GuiKeys.down_task
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Tarefa: Abrir {y} com a descrição", symbols.action, "URL"),
                self.actions.open_link,
                GuiKeys.open_url
            ).set_exit_on_action(True)
        )

        # self evaluate
        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Tarefa: Auto {y} método de estudo", symbols.action, "Avaliar"),
                self.actions.self_evaluate,
                GuiKeys.self_evaluate
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Tarefa: {y} pasta", symbols.action, "Apagar"),
                self.actions.delete_folder,
                ""
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Mostrar {y}", symbols.action, "Ajuda"),
                self.gui.show_help,
                GuiKeys.key_help
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Mostrar {y}", icon(self.app.get_use_borders()), "Bordas"),
                self.app.toggle_borders,
                GuiKeys.borders
            )
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Mostrar {y}", icon(self.app.get_use_images()), "Imagens"),
                self.app.toggle_images, 
                GuiKeys.images
            )
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Mostrar {y} decorrido", icon(Flags.show_time.is_true()), "Tempo"),
                lambda: Flags.show_time.toggle(),
                GuiKeys.show_time
            )
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Mudar {y} de programação", symbols.action, "Linguagem"),
                self.gui.language.set_language,
                GuiKeys.set_lang_drafts
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} {y} as teclas direcionais", symbols.action, "Calibrar"),
                lambda: self.fman.add_input(FloatingCalibrate(self.actions.settings)),
                GuiKeys.calibrate
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Criar {y} na pasta local", symbols.action, "Rascunho"),
                self.actions.create_draft,
                GuiKeys.create_draft
            ).set_exit_on_action(True)
        )

        options.append(
            FloatingInputData(
                lambda: Text.format(" {} Ver {y} da tarefa ", symbols.action, "versões"),
                self.actions.open_versions,
                GuiKeys.unfold_patch
            ).set_exit_on_action(True)
        )

        self.fman.add_input(
            FloatingDropDown().set_floating(
                    Floating().top()
                    .set_text_ljust()
                    .set_footer(" Use Enter para aplicar e Esc para Sair ")
                    .set_header(" Selecione uma ação da lista ")
            )
            .set_options(options)
            .set_exit_on_enter(False)
        )