"""AuthFort repositories — database query functions.

Each module provides async functions that operate on SQLModel models via AsyncSession.
"""
