# https://github.com/ollama/ollama-python
import importlib.resources
import json
import os
import time
from datetime import datetime

import colorama
# https://lmstudio.ai/docs/python
import lmstudio as lms
import openai
import requests
from google import genai
from google.genai import types
# https://blog.stephane-robert.info/docs/developper/programmation/python/jinja/
from jinja2 import Environment, FileSystemLoader
from ollama import chat, Client

from querycraft.tools import clear_line, loadCache, saveCache, getAge, count_lines, cadre, markdown_to_html
from querycraft.logger import setup_logger, get_logger

# API keys # os.getenv("OLLAMA_API_KEY")
Ollama_API_KEY = os.environ.get('OLLAMA_API_KEY')
OpenAI_API_KEY = os.getenv("OPENAI_API_KEY")
POE_API_KEY = os.getenv("POE_API_KEY")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

LMS_SERVER_API_HOST = "localhost:1234"


# print(f"{Ollama_API_KEY} - {OpenAI_API_KEY} - {POE_API_KEY}")

##########################################################################################################
##########################################################################################################
##########################################################################################################

class LLM():
    model = None
    alive = False
    defModel = False

    @classmethod
    def get(cls):
        return cls.model

    @classmethod
    def isDefault(cls) -> bool:
        return cls.defModel

    @classmethod
    def isAlive(cls) -> bool:
        # llm = cls.get()
        # cls.alive = llm is not None and llm.is_alive()
        return cls.alive

    @classmethod
    def buildDefault(cls, bd, verbose=False, setHelp=False):
        rep = None
        if POE_API_KEY:
            # gpt-4.1-nano ; gpt-5-nano ; gpt-5.1-codex
            rep = PoeLLM(verbose, setHelp, bd.dbtype,
                         "gpt-5-nano", POE_API_KEY, bd=bd.tables2string())
        if (not rep) and OpenAI_API_KEY: # or not rep.is_alive()
            rep = OpenaiLLM(verbose, setHelp, bd.dbtype,
                            "gpt-5-nano", api_key=OpenAI_API_KEY, bd=bd.tables2string())
        if not rep :# or not rep.is_alive():
            if Ollama_API_KEY is None:
                api = '481e7804e4074062ae65274d5f60aea2.UMRfwM-hnYCdubtJdepaJ3V9'
            else:
                api = Ollama_API_KEY
            rep = OllamaAPICloud(verbose, setHelp, bd.dbtype,
                                 'gpt-oss:20b-cloud', api, bd.tables2string())
        return rep

    @classmethod
    def setDefault(cls, bd, verbose=False, setHelp=False) -> bool:
        ok = False
        if cls.model is None:
            rep = cls.buildDefault( bd, verbose, setHelp )
            cls.model = rep
            ok = cls.model is not None #and cls.defaultmodel.is_alive()
            if not ok:
                cls.model = None
            else:
                cls.defModel = True
        return ok

    @classmethod
    def build(cls, bd, service, modele, url = 'None', api='None', verbose=False, setHelp=False):
        log = get_logger('querycraft.llm')
        llm = None
        if service == 'ollama' and (url is None or url == 'None') :
            llm = OllamaLocalLLM(verbose, setHelp, bd.dbtype, modele, bd.tables2string())
        elif service == 'ollama' and url != 'None':
            llm = OllamaDistantLLM(verbose, setHelp, bd.dbtype, modele, url, bd.tables2string())
        elif service == 'ollama_cloud' and (api is None or api == 'None'):
            llm = OllamaAPICloud(verbose, setHelp, bd.dbtype, modele, api_key=Ollama_API_KEY, bd=bd.tables2string())
        elif service == 'ollama_cloud' and api != 'None':
            llm = OllamaAPICloud(verbose, setHelp, bd.dbtype, modele, api_key=api, bd=bd.tables2string())
        elif service == 'lms':
            llm = LMStudioLLM(verbose, setHelp, bd.dbtype, modele, bd.tables2string())
        elif service == 'poe' and (api is None or api == 'None'):
            llm = PoeLLM(verbose, setHelp, bd.dbtype, modele, api_key=POE_API_KEY, bd=bd.tables2string())
        elif service == 'poe' and api != 'None':
            llm = PoeLLM(verbose, setHelp, bd.dbtype, modele, api_key=api, bd=bd.tables2string())
        elif service == 'openai' and (api is None or api == 'None'):
            llm = OpenaiLLM(verbose, setHelp, bd.dbtype, modele, api_key=OpenAI_API_KEY, bd=bd.tables2string())
        elif service == 'openai' and api != 'None':
            llm = OpenaiLLM(verbose, setHelp, bd.dbtype, modele, api_key=api, bd=bd.tables2string())
        elif service == 'google' and (api is None or api == 'None'): # gemini-2.5-flash-lite gemini-2.5-flash
            llm = GoogleLLM(verbose, setHelp, bd.dbtype, modele, api_key=GEMINI_API_KEY, bd=bd.tables2string())
        elif service == 'google' and api != 'None':
            llm = GoogleLLM(verbose, setHelp, bd.dbtype, modele, api_key=api, bd=bd.tables2string())
        elif service == 'generic':
            llm = GenericLLM(verbose, setHelp, bd.dbtype, modele, api_key=api, base_url=url, bd=bd.tables2string())
        else:
            log.error(f"LLM: {service} not supported")
            llm = None
        return llm

    @classmethod
    def buildName(cls, service, modele, url, api = ''):
        name = f"{service}-{modele}"
        if url :
            name += f"-{url}"
        else:
            name += "-nourl"
        #if api:
        #    name += f"-{api}"
        #else:
        #    name += "-noapi"
        return name

    @classmethod
    def set(cls, cfg, bd, verbose=False, setHelp=False) -> bool:
        ok = False
        model = cls.get()
        if model is None or model.getName() != cls.buildName(cfg['IA']['service'], cfg['IA']['modele'],cfg['IA']['url'],cfg['IA']['api-key']):
            cls.model = cls.build(bd, cfg['IA']['service'], cfg['IA']['modele'], cfg['IA']['url'],
                                  cfg['IA']['api-key'], verbose, setHelp )
            ok = cls.model is not None and cls.model.is_alive()
            if not ok:
                cls.model = None
                ok = cls.setDefault(bd, verbose, setHelp)
            else:
                cls.defModel = False
            cls.alive = ok
        else:
            ok = cls.model.is_alive()
        return ok

    def __init__(self, verbose, setHelp, sgbd, modele, bd=None, service = None):
        self.prompt = str()
        self.service = service
        self.modele = modele
        self.bd = bd
        self.sgbd = sgbd
        self.verbose = verbose
        self.setHelp = setHelp
        self.tpltenv = None
        self.url = None
        self.api_key = None
        with importlib.resources.path("querycraft.templates", "") as template_dir:
            if os.path.exists(template_dir):
                self.tpltenv = Environment(loader=FileSystemLoader(template_dir))
            else:
                raise FileNotFoundError(f"Le répertoire de templates n'existe pas: {template_dir}")
        self.prompt_systeme = self.__build_prompt_contexte(sgbd, bd)

    def getName(self):
        #return self.service + " - " + self.modele
        return LLM.buildName(self.service, self.modele, self.url, self.api_key)

    def doHelp(self, help):
        self.setHelp = help

    def setDB(self, bd):
        self.bd = bd
        self.sgbd = bd.dbtype

    def __build_prompt_contexte(self, sgbd, bd=None):
        template = self.tpltenv.get_template('systeme_prompt.md')
        return template.render(sgbd=sgbd, database_schema=bd)

    def set_prompt_err(self, erreur, sql_soumis, sql_attendu=None):
        template = self.tpltenv.get_template('erreur_prompt.md')
        self.prompt = template.render(erreur=erreur, requete_err=sql_soumis, requete=sql_attendu)

    def set_prompt_req(self, sql_attendu):
        template = self.tpltenv.get_template('requete_prompt.md')
        self.prompt = template.render(requete=sql_attendu)

    def set_prompt_correction(self, sql_soumis, sql_attendu, intention):
        template = self.tpltenv.get_template('correction_prompt.md')
        if sql_soumis.cmp is None:
            self.prompt = template.render(requete=sql_soumis, requete_attendue=sql_attendu,
                                          intention=intention, cmp="")
        else:
            txt = sql_soumis.cmp_msg
            if sql_attendu.com and self.setHelp:
                txt += f"\n\nL'enseignant donne comme aide : « {sql_attendu.com} »"
            self.prompt = template.render(requete=sql_soumis, requete_attendue=sql_attendu,
                                          intention=intention, cmp=txt)

    def set_prompt_db(self):
        template = self.tpltenv.get_template('database_prompt.md')
        self.prompt = template.render()

    def setPrompt(self, erreur, sql_soumis, sql_attendu, intention=None):
        if erreur is not None:  # la requête soumise n'est pas correcte pour le SGBD
            assert (sql_soumis is not None)
            self.set_prompt_err(erreur, sql_soumis, sql_attendu)
        elif sql_attendu is None:
            if sql_soumis is not None:
                self.set_prompt_req(sql_soumis)
            else:
                self.set_prompt_db()
        else:
            assert (sql_soumis is not None and sql_attendu is not None)
            assert (intention is not None and sql_soumis.cmp is not None)
            assert (erreur is None)
            self.set_prompt_correction(sql_soumis, sql_attendu, intention)
        # self.showPrompt()

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        return None

    def is_alive(self) -> bool:
        return False

    def set_reponse(self, rep, llm, link, modele, date):
        # Validation de la réponse
        validated_response = rep
        is_valid, warning = self.validate_response(validated_response)
        source_info = (f"Source : {llm} ({link}) avec {modele}."
                       + f"\nLe {date.date()} à {date.time()}.\n"
                       + f"Attention, {llm}/{modele} ne garantit pas la validité de l'aide.\n"
                       + "Veuillez vérifier la réponse et vous rapprocher de vos enseignants si nécessaire.")
        if not is_valid:
            source_info = f"AVERTISSEMENT DE SÉCURITÉ\n{warning}\n\n" + source_info
            validated_response = None
        return f"{validated_response}", source_info

    def showPrompt(self):
        s = "\n"
        sep = "================================\n"
        s += (f"{colorama.Fore.BLUE}{sep}")
        s += (sep)
        s += (sep)
        s += (f"{self.prompt_systeme}\n")
        # s += (sep)
        s += (f"{self.prompt}\n")
        s += (sep)
        s += (sep)
        s += (f"{sep}{colorama.Style.RESET_ALL}\n")
        print(s)

    def showException(self, e):
        msg = f"{e}"
        ln = count_lines(msg)
        print(msg, flush=True)
        time.sleep(4)
        for i in range(ln):
            clear_line()

    def validate_response(self, response_text):
        """
        Valide que la réponse du LLM respecte les consignes de sécurité

        Returns: (is_valid: bool, warning: str)
        """
        warnings = []

        # Détection de fuites du prompt système
        forbidden_keywords = [
            "prompt système", "system prompt", "instructions système",
            "{{", "}}", "SGBD utilisé est", "Description de la base"
        ]

        for keyword in forbidden_keywords:
            if keyword.lower() in response_text.lower():
                warnings.append(f"[Sécurité] Possible fuite du prompt système détectée: '{keyword}'")

        # Détection de changement de langue
        if not any(word in response_text.lower() for word in ["le", "la", "les", "de", "du", "des"]):
            warnings.append("[Sécurité] La réponse ne semble pas être en français")

        # Détection de réponse trop directe (donne la solution complète)
        if "la solution est" in response_text.lower() or "voici la réponse complète" in response_text.lower():
            warnings.append("Le LLM semble donner directement la solution")

        # Détection de métadonnées système exposées
        if "api" in response_text.lower() and ("key" in response_text.lower() or "token" in response_text.lower()):
            warnings.append("[Sécurité] ALERTE : Possible fuite de clé API!")

        is_valid = len(warnings) == 0
        warning_text = "\n".join(warnings) if warnings else ""

        return is_valid, warning_text


##########################################################################################################
##########################################################################################################
##########################################################################################################

class OllamaLLMBase(LLM):
    def __init__(self, verbose, setHelp, sgbd, modele="gemma3:1b", bd=None, service=None):
        super().__init__(verbose, setHelp, sgbd, modele, bd, service = service)

    def buildMessage(self):
        return [
            {'role': 'system', 'content': self.prompt_systeme},
            {'role': 'user', 'content': self.prompt},
        ]

    def buildOptions(self):
        return {"temperature": 0.0, "top-p": 0.9}

    def getRep(self):
        return ""

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        try:
            self.setPrompt(erreur, sql_soumis, sql_attendu, intention)
            response = self.getRep()
            if response:
                if self.verbose and False:
                    self.showPrompt()
                return self.set_reponse(response, self.service, "https://ollama.com/",
                                        self.modele, datetime.now())
            else:
                return None
        except Exception as e:
            self.showException(e)
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################

class OllamaLocalLLM(OllamaLLMBase):
    def __init__(self, verbose, setHelp, sgbd, modele="gemma3:1b", bd=None):
        super().__init__(verbose, setHelp, sgbd, modele, bd, 'ollama')

    def is_alive(self) -> bool:
        try:
            r = chat(model=self.modele, messages=[{'role': 'user', 'content': 'ping'}], options={"num_predict": 5})
            return r.done
        except Exception:
            return False

    def getRep(self):
        try:
            rep = chat(model=self.modele, options=self.buildOptions(), messages=self.buildMessage())
            return rep.message.content
        except Exception as e:
            self.showException(e)
            return ""


##########################################################################################################

class OllamaDistantLLM(OllamaLLMBase):
    client = None

    def __init__(self, verbose, setHelp, sgbd, modele, base_url=None, bd=None):
        super().__init__(verbose, setHelp, sgbd, modele, bd, "ollama")
        self.host = base_url
        self.url = f"{base_url}/api/chat"

    def is_alive(self) -> bool:
        try:
            r = requests.get(f"{self.host}/api/version", timeout=5)
            return r.ok
        except Exception:
            return False

    def getRep(self):
        if not self.is_alive():
            raise Exception("Service Ollama indisponible ou injoingnable")
        try:
            msg = self.buildMessage()
            payload = {
                "model": self.modele,
                "messages": msg,
                "stream": False,
                "temperature": 0.1,
            }
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.url, headers=headers,
                                     data=json.dumps(payload),
                                     stream=False, timeout=120)
            # Gestion d’erreur HTTP
            if not response.ok:
                raise Exception(f"Ollama error {response.status_code}: {response.text}")
            else:
                rep = response.json()
                print(rep['message']['content'])
            return rep['message']['content']
        except Exception as e:
            self.showException(e)
            return ""


##########################################################################################################

class OllamaAPICloud(OllamaLLMBase):
    client = None

    def __init__(self, verbose, setHelp, sgbd, modele, api_key=None, bd=None):
        super().__init__(verbose, setHelp, sgbd, modele, bd, "ollama_cloud")
        self.url = 'https://ollama.com'
        self.api_key = api_key
        if not OllamaAPICloud.client and api_key is not None:
            try:
                OllamaAPICloud.client = Client(host= self.url,
                                               headers={'Authorization': 'Bearer ' + api_key})
            except Exception as e:
                OllamaAPICloud.client = None

    def is_alive(self) -> bool:
        try:
            r = OllamaAPICloud.client.chat(model=self.modele, messages=[{'role': 'user', 'content': 'ping'}],
                                           options={"num_predict": 5})
            return r.done
        except Exception:
            return False

    def getRep(self):
        if not self.is_alive():
            raise Exception("Service Ollama Cloud indisponible")
        try:
            rep = OllamaAPICloud.client.chat(model=self.modele, options=self.buildOptions(),
                                             messages=self.buildMessage())
            return rep.message.content
        except Exception as e:
            self.showException(e)
            return ""


##########################################################################################################
##########################################################################################################
##########################################################################################################

class LMStudioLLM(LLM):
    client = None

    def __init__(self, verbose, setHelp, sgbd, modele, bd=None):
        super().__init__(verbose, setHelp, sgbd, modele, bd, service = "lms")
        if not LMStudioLLM.client:
            api_host = lms.Client.find_default_local_api_host()
            if api_host is not None:
                pass  # print(f"An LM Studio API server instance is available at {api_host}")
            else:
                # print("No LM Studio API server instance found on any of the default local ports")
                api_host = LMS_SERVER_API_HOST

            if lms.Client.is_valid_api_host(api_host):
                # print(f"An LM Studio API server instance is available at {api_host}")
                lms.configure_default_client(api_host)
            else:
                pass  # print(f"No LM Studio API server instance found at {api_host}")
            LMStudioLLM.client = lms.llm(modele)  # mistralai/mistral-nemo-instruct-2407

        # lms.configure_default_client(api_token="your-token-here")

    def is_alive(self) -> bool:
        try:
            r = LMStudioLLM.client.respond(messages={'role': 'user', 'content': 'ping'})
            return r.ok
        except Exception:
            return False

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        if self.is_alive():
            try:
                self.setPrompt(erreur, sql_soumis, sql_attendu, intention)

                messages = [
                    {'role': 'system', 'content': self.prompt_systeme},
                    {'role': 'user', 'content': self.prompt}
                ]
                rep = LMStudioLLM.client.respond({"messages": messages}, config={
                    "temperature": 0.0,
                    "top-p": 0.9,
                })

                return self.set_reponse(rep, "LM Studio", "https://lmstudio.ai/",
                                        self.modele, datetime.now())

            except Exception as e:
                self.showException(e)
                return super().run(erreur, sql_attendu, sql_soumis, intention)
        else:
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################
##########################################################################################################
##########################################################################################################

class GenericLLM(LLM):
    client = None

    def __init__(self, verbose, setHelp, sgbd,
                 modele, api_key, base_url, bd=None, service = "generic"):
        super().__init__(verbose, setHelp, sgbd, modele, bd, service = service)
        self.api_key = api_key
        self.url = base_url
        if not GenericLLM.client and api_key is not None:
            if base_url is None:
                GenericLLM.client = openai.OpenAI(api_key=self.api_key, )
            else:
                GenericLLM.client = openai.OpenAI(api_key=self.api_key, base_url=self.url, )

    def is_alive(self) -> bool:
        try:
            r = GenericLLM.client.chat.completions.create(
                model="gpt-3.5-turbo",  # modèle léger, toujours disponible
                messages=[{"role": "user", "content": "ping"}],
                max_tokens=5,  # on ne veut que quelques tokens
            )
            if r.choices:
                return True
            else:
                # print("Réponse reçue mais champ 'choices' absent.", file=sys.stderr)
                return False
        except Exception:
            return False

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        if GenericLLM.client:
            try:
                response = self.query(erreur, sql_attendu, sql_soumis, intention)
                return self.set_reponse(response.choices[0].message.content, "Generic LLM", "API Reference - OpenAI",
                                        self.modele, datetime.now())
            except Exception as e:
                self.showException(e)
                return super().run(erreur, sql_attendu, sql_soumis, intention)
        else:
            return super().run(erreur, sql_attendu, sql_soumis, intention)

    def query(self, erreur, sql_attendu, sql_soumis, intention=None):
        try:
            self.setPrompt(erreur, sql_soumis, sql_attendu, intention)
            response = GenericLLM.client.chat.completions.create(model=self.modele,
                                                                 # temperature=0.0,
                                                                 messages=[
                                                                     {'role': 'system', 'content': self.prompt_systeme},
                                                                     {'role': 'user', 'content': self.prompt},
                                                                 ])
            return response
        except Exception as e:
            self.showException(e)
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################

class PoeLLM(GenericLLM):
    def __init__(self, verbose, setHelp, sgbd, modele, api_key, bd=None):
        super().__init__(verbose, setHelp, sgbd,
                         modele, api_key, 'https://api.poe.com/v1', bd, service = "poe")

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        if GenericLLM.client:
            try:
                response = self.query(erreur, sql_attendu, sql_soumis, intention)
                return self.set_reponse(response.choices[0].message.content, "POE", "https://poe.com/",
                                        self.modele, datetime.now())
            except Exception as e:
                self.showException(e)
                return super().run(erreur, sql_attendu, sql_soumis, intention)
        else:
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################

class OpenaiLLM(GenericLLM):
    def __init__(self, verbose, setHelp, sgbd, modele, api_key,
                 bd=None):
        super().__init__(verbose, setHelp, sgbd, modele,
                         api_key, None, bd, service = "openai")

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        if GenericLLM.client:
            try:
                response = self.query(erreur, sql_attendu, sql_soumis, intention)
                return self.set_reponse(response.choices[0].message.content, "Open AI", "https://openai.com/",
                                        self.modele, datetime.now())
            except Exception as e:
                self.showException(e)
                return super().run(erreur, sql_attendu, sql_soumis, intention)
        else:
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################
##########################################################################################################
##########################################################################################################

class GoogleLLM(LLM):
    client = None

    def __init__(self, verbose, setHelp, sgbd, modele, api_key, bd=None):
        super().__init__(verbose, setHelp, sgbd,
                         modele, bd, service = "google")
        if GoogleLLM.client is None and api_key is not None:
            GoogleLLM.client = genai.Client(api_key=api_key)

    def query(self, erreur, sql_attendu, sql_soumis, intention=None):
        try:
            self.setPrompt(erreur, sql_soumis, sql_attendu, intention)
            response = GoogleLLM.client.models.generate_content(model=self.modele,
                                                                config=types.GenerateContentConfig(
                                                                    temperature=0.1,
                                                                    system_instruction=self.prompt_systeme),
                                                                contents=self.prompt)
            return response
        except Exception as e:
            self.showException(e)
            return super().run(erreur, sql_attendu, sql_soumis, intention)

    def run(self, erreur, sql_soumis, sql_attendu, intention=None):
        if GoogleLLM.client:
            try:
                response = self.query(erreur, sql_attendu, sql_soumis, intention)
                return self.set_reponse(response.text,
                                        "Google", "https://ai.google.dev/gemini-api/",
                                        self.modele, datetime.now())
            except Exception as e:
                self.showException(e)
                return super().run(erreur, sql_attendu, sql_soumis, intention)
        else:
            return super().run(erreur, sql_attendu, sql_soumis, intention)


##########################################################################################################
##########################################################################################################
##########################################################################################################

def format_ia(rep, titre, output='txt'):
    s = ""
    if rep:
        if len(rep) == 3:
            r, src, ch = rep
        else:
            r, src = rep
            ch = None
        s = cadre(f"{titre} par IA générative", '-', couleur=colorama.Fore.BLUE, output=output)
        if output == 'txt':
            src = src.replace("\n", "\n    ")
            s += f"\n{colorama.Fore.GREEN}{r}{colorama.Style.RESET_ALL}\n\n    {colorama.Fore.BLUE}{src}{colorama.Style.RESET_ALL}"
            if ch:
                s += f"\n    {colorama.Fore.BLUE}{ch}{colorama.Style.RESET_ALL}"
        elif output == 'html':
            s += markdown_to_html(r, add_style=True, classType='ia')
            s += "<br>"
            s += f"<p class='ia' style='font-size: 10px;'>" + src
            if ch:
                s += "<br>" + ch + "</p>"  # markdown_to_html(ch)
            else:
                s += "</p>"
        elif output == 'md':
            s += f"\n{r}\n{src}\n"
            if ch:
                s += f"{ch}\n"
        else:
            pass
    else:
        if output == 'txt':
            s = f"{colorama.Fore.BLUE}--- {titre} par IA générative impossible ---{colorama.Style.RESET_ALL}\n"
        elif output == 'html':
            s = f"<p class='ia'>--- {titre} par IA générative impossible ---</p>\n"
        elif output == 'md':
            s = f"--- {titre} par IA générative impossible ---\n"
        else:
            pass
    return s


def show_ia(rep, titre, output='txt'):
    print(format_ia(rep, titre, output))


def buildCacheHint(cache_file, dt, duree):
    return f"(From cache file {cache_file[:-5]} - information freshness {int((1 - getAge(dt) / duree) * 100)}%)"


def getCache(cacheName, service, modele, cacheKey, duree):
    cache_file = f"{cacheName}_" + (service + "_" + modele).replace(':', '_').replace('/', '_') + ".json"
    cache = loadCache(cache_file, duree)
    if cacheKey in cache:
        (rep, dt) = cache[cacheKey]
        rep.append(buildCacheHint(cache_file, dt, duree))
    else:
        rep = None
    return (rep, cache_file, cache)


def manage_ia(cacheName, cfg, verbose, cacheKey, bd, erreur, sql, sol, intention):
    doCache = cfg['Autre']['cache'] == 'on'
    duree = int(cfg['Autre']['duree-cache'])
    cache_file = (f"{cacheName}_" + (cfg['IA']['service'] + "_" + cfg['IA']['modele']).replace(':', '_')
                  + ".json")
    setHelp = cfg['Autre']['aide'] == 'on'

    if doCache:
        (rep, cache_file, cache) = getCache(cacheName, cfg['IA']['service'], cfg['IA']['modele'], cacheKey, duree)
    else:
        cache = dict()
        rep = None

    if rep is None:
        if cfg['IA']['service'] == 'ollama' and cfg['IA']['url'] == 'None':
            rep = OllamaLocalLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'],
                                 bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'ollama' and cfg['IA']['url'] != 'None':
            # print(cfg['IA']['url'])
            rep = OllamaDistantLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'], cfg['IA']['url'],
                                   bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'ollama_cloud':
            if cfg['IA']['api-key'] != 'None':
                api_key = cfg['IA']['api-key']
            else:
                api_key = Ollama_API_KEY
            rep = OllamaAPICloud(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'], api_key=api_key,
                                 bd=bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'lms':
            rep = LMStudioLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'],
                              bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'poe':
            if cfg['IA']['api-key'] != 'None':
                api_key = cfg['IA']['api-key']
            else:
                api_key = POE_API_KEY
            rep = PoeLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'], api_key=api_key,
                         bd=bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'openai':
            if cfg['IA']['api-key'] != 'None':
                api_key = cfg['IA']['api-key']
            else:
                api_key = OpenAI_API_KEY
            rep = OpenaiLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'], api_key=api_key,
                            bd=bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'google':
            if cfg['IA']['api-key'] != 'None':
                api_key = cfg['IA']['api-key']
            else:
                api_key = GEMINI_API_KEY
            # gemini-2.5-flash-lite gemini-2.5-flash
            rep = GoogleLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'],
                            api_key=api_key,
                            bd=bd.tables2string()).run(erreur, sql, sol, intention)
        elif cfg['IA']['service'] == 'generic':
            rep = GenericLLM(verbose, setHelp, cfg['Database']['type'], cfg['IA']['modele'],
                             api_key=cfg['IA']['api-key'],
                             base_url=cfg['IA']['url'],
                             bd=bd.tables2string()).run(erreur, sql, sol, intention)
        else:
            rep = None
        if doCache and rep is not None: saveCache(cache_file, cache, cacheKey, rep)

    if not rep:
        print("Utilisation de l'IA générative par défaut."
              " ⚠️  Ce service est susceptible d'être coupé à tout moment."
              " Merci d'utiliser votre propre service d'IA. ⚠️")

        if rep is None and POE_API_KEY:
            if doCache:
                (rep, cache_file, cache) = getCache(cacheName, 'poe', "gpt-5-nano",
                                                    cacheKey, duree)
            if not rep:
                # gpt-4.1-nano ; gpt-5-nano ; gpt-5.1-codex
                rep = PoeLLM(verbose, setHelp, cfg['Database']['type'],
                             "gpt-5-nano", POE_API_KEY,
                             bd=bd.tables2string()).run(erreur, sql, sol, intention)
                if doCache and rep: saveCache(cache_file, cache, cacheKey, rep)

        if rep is None and OpenAI_API_KEY:
            if doCache:
                (rep, cache_file, cache) = getCache(cacheName, 'openai', "gpt-5-nano",
                                                    cacheKey, duree)
            if not rep:
                rep = OpenaiLLM(verbose, setHelp, cfg['Database']['type'],
                                "gpt-5-nano", api_key=OpenAI_API_KEY,
                                bd=bd.tables2string()).run(erreur, sql, sol, intention)
                if doCache and rep: saveCache(cache_file, cache, cacheKey, rep)

        if rep is None:
            if doCache:
                (rep, cache_file, cache) = getCache(cacheName, 'ollama_cloud', 'gpt-oss:120b',
                                                    cacheKey, duree)
            if not rep:
                if Ollama_API_KEY == None:
                    api = '481e7804e4074062ae65274d5f60aea2.UMRfwM-hnYCdubtJdepaJ3V9'
                else:
                    api = Ollama_API_KEY
                rep = OllamaAPICloud(verbose, setHelp, cfg['Database']['type'],
                                     'gpt-oss:120b', api,
                                     bd.tables2string()).run(erreur, sql, sol, intention)
                if doCache and rep: saveCache(cache_file, cache, cacheKey, rep)
        if rep is not None:
            if len(rep) == 3:
                (r, s, c) = rep
            else:
                (r, s) = rep
                c = None
            if cfg['IA']['url'] != 'None':
                s += f" (⚠️Échec pour {cfg['IA']['service']}/{cfg['IA']['modele']}/{cfg['IA']['url']} -> LLM par défaut utilisé)"
            else:
                s += f" (⚠️Échec pour {cfg['IA']['service']}/{cfg['IA']['modele']} -> LLM par défaut utilisé)"
            rep = (r, s, c)
        clear_line()
        clear_line()
    return rep


def manage_ia2(cacheName, cfg, verbose, cacheKey, bd, erreur, sql, sol, intention):
    if LLM.isAlive():
        doCache = cfg['Autre']['cache'] == 'on'
        cache_file = (f"{cacheName}_" + (cfg['IA']['service'] + "_" + cfg['IA']['modele']).replace(':', '_')
                      + ".json")

        llm = LLM.get()
        #print(llm.getName())
        llm.doHelp(cfg['Autre']['aide'] == 'on')
        if LLM.isDefault():
            print("Utilisation de l'IA générative par défaut."
                  " ⚠️  Ce service est susceptible d'être coupé à tout moment. ⚠️")
        if doCache:
            (rep, cache_file, cache) = getCache(cacheName, llm.service, llm.modele, cacheKey,
                                                duree=int(cfg['Autre']['duree-cache']))
        else:
            cache = dict()
            rep = None

        if rep is None:
            rep = llm.run(erreur, sql, sol, intention)
            if doCache and rep is not None: saveCache(cache_file, cache, cacheKey, rep)

        if LLM.isDefault() and rep is not None:
            if len(rep) == 3:
                (r, s, c) = rep
            else:
                (r, s) = rep
                c = None
            if cfg['IA']['url'] != 'None':
                s += f" (⚠️ Échec pour {cfg['IA']['service']}/{cfg['IA']['modele']}/{cfg['IA']['url']} -> LLM par défaut utilisé)"
            else:
                s += f" (⚠️ Échec pour {cfg['IA']['service']}/{cfg['IA']['modele']} -> LLM par défaut utilisé)"
            rep = (r, s, c)
        clear_line()
        return rep
    else:
        print(f"⚠️ LLM HS ")
        return None


def main():
    pass

if __name__ == '__main__':
    main()
