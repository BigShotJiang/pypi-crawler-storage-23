"""smellcheck -- vendored for Agent Skills (do not edit, run scripts/vendor-smellcheck.sh)."""
# x-release-please-start-version
__version__ = "0.3.5"
# x-release-please-end
