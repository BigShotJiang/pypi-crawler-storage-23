from astropy import config as _config


class Conf(_config.ConfigNamespace):
    """Configuration parameters for grad300_client."""

    base_url = _config.ConfigItem(
        "https://grad300.lam.fr",
        "Base URL of the GRAD300 backend service.",
    )
    api_prefix = _config.ConfigItem(
        "/api/v1",
        "API prefix appended to base_url.",
    )
    timeout = _config.ConfigItem(
        30.0,
        "HTTP timeout in seconds.",
    )
    default_page_size = _config.ConfigItem(
        100,
        "Default page size for scan list/query methods.",
    )


conf = Conf()

__all__ = ["Conf", "conf"]
