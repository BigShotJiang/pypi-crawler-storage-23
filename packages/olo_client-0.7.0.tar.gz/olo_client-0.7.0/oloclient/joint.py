"""
OLO Joint API - Joint Control and Manipulation
Handles robot joint control, joint state management, and trajectory publishing.
"""

import asyncio
import re
from typing import List, Dict, Any, Optional, Callable


class OLOJoint:
    """
    Joint control API for robot arm manipulation.
    Mirrors the JavaScript OLOJointClient API.
    
    Provides methods for:
    - Joint state reading and monitoring
    - Arm joint detection
    - Joint trajectory publishing
    - Movement control with abort support
    """

    def __init__(self, ros_client, core):
        """
        Initialize OLO Joint module

        Args:
            ros_client: roslibpy.Ros instance
            core: OLOCore instance for publishing/subscribing
        """
        self._ros = ros_client
        self._core = core
        self._cached_joint_states = None
        self._joint_state_subscription = None
        # Caching for robot info auto-detection
        self._cached_srdf = None
        self._cached_srdf_timestamp = 0
        self._cached_urdf = None
        self._cached_urdf_timestamp = 0
        self._cached_robot_info = None
        self._cached_robot_info_timestamp = 0
        # Planning scene management
        self._planning_scene_callbacks = {}
        self._planning_scene_message_handler = None
        self._planning_scene_loop = None
        # Live collision object management
        self._collision_object_callbacks = {}
        self._collision_object_message_handler = None
        self._collision_object_loop = None

    async def get_current_joint_states(self) -> Dict[str, Any]:
        """
        Get current joint states

        Returns:
            Dict with:
                - names: List of joint names
                - positions: List of positions
                - velocities: List of velocities
                - efforts: List of efforts
                - jointStates: Dict mapping name -> position
                - timestamp: Timestamp
        """
        import roslibpy

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        import time as time_module
        loop = asyncio.get_running_loop()
        future = loop.create_future()

        topic = roslibpy.Topic(
            self._ros,
            '/joint_states',
            'sensor_msgs/JointState'
        )

        def callback(message):
            try:
                names = message.get('name', [])
                positions = message.get('position', [])
                velocities = message.get('velocity', [])
                efforts = message.get('effort', [])

                if not names or not positions:
                    if not future.done():
                        loop.call_soon_threadsafe(
                            future.set_exception,
                            Exception('Invalid joint states message')
                        )
                    return

                joint_states = {}
                for i, name in enumerate(names):
                    joint_states[name] = positions[i] if i < len(positions) else 0.0

                result = {
                    'names': names,
                    'positions': positions,
                    'velocities': velocities,
                    'efforts': efforts,
                    'jointStates': joint_states,
                    'timestamp': time_module.time()
                }

                # Cache the joint states
                self._cached_joint_states = result

                topic.unsubscribe()
                if not future.done():
                    loop.call_soon_threadsafe(future.set_result, result)
            except Exception as e:
                topic.unsubscribe()
                if not future.done():
                    loop.call_soon_threadsafe(future.set_exception, e)

        topic.subscribe(callback)

        try:
            return await asyncio.wait_for(future, timeout=3.0)
        except asyncio.TimeoutError:
            topic.unsubscribe()
            raise TimeoutError("Timeout waiting for joint states")

    async def subscribe_to_joint_states(self, callback: Callable[[Dict], None]) -> str:
        """
        Subscribe to joint states with callback

        Args:
            callback: Function to call with joint state updates

        Returns:
            Subscription ID (topic name)
        """
        # Unsubscribe from any existing subscription
        if self._joint_state_subscription:
            await self._core.unsubscribe('/joint_states')
            self._joint_state_subscription = None

        import time as time_module

        def wrapped_callback(message):
            names = message.get('name', [])
            positions = message.get('position', [])
            velocities = message.get('velocity', [])
            efforts = message.get('effort', [])

            if names and positions:
                joint_states = {}
                for i, name in enumerate(names):
                    joint_states[name] = positions[i] if i < len(positions) else 0.0

                result = {
                    'names': names,
                    'positions': positions,
                    'velocities': velocities,
                    'efforts': efforts,
                    'jointStates': joint_states,
                    'timestamp': time_module.time()
                }

                # Cache the joint states
                self._cached_joint_states = result

                callback(result)

        self._joint_state_subscription = await self._core.subscribe(
            '/joint_states',
            wrapped_callback,
            message_type='sensor_msgs/JointState'
        )

        return self._joint_state_subscription

    async def detect_arm_joints(self, options: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        Auto-detect arm joints from joint states.
        Filters for arm-specific joints (shoulder, elbow, wrist) and excludes
        leg/torso/gripper joints. For dual-arm robots, auto-selects one side.

        Args:
            options: Optional dict with:
                - side: Preferred side: 'left', 'right', or None (auto, prefers left)
                - maxJoints: Maximum number of joints to return (default: 7)
                - armPatterns: List of regex patterns to identify arm joints
                - excludePatterns: List of regex patterns to exclude (default: gripper/finger)

        Returns:
            List of detected arm joint names
        """
        if options is None:
            options = {}

        joint_states = await self.get_current_joint_states()
        joint_names = joint_states['names']

        exclude_patterns = options.get('excludePatterns', [
            re.compile(r'(finger|hand|grip|gripper|thumb|palm)', re.I)
        ])
        arm_patterns = options.get('armPatterns', [
            re.compile(r'(shoulder|elbow|wrist|arm)', re.I)
        ])
        leg_patterns = [
            re.compile(r'(hip|knee|ankle|leg|foot|toe|waist|torso|pelvis|spine)', re.I)
        ]
        max_joints = options.get('maxJoints', 7)
        side = options.get('side', None)

        # Helper: detect a group of numbered joints
        def detect_numbered_joint_group(names):
            groups = {}
            for idx, n in enumerate(names):
                m = re.match(r'^(.*?)(?:[_-]?(?:joint))?[_-]?(\d+)$', n, re.I)
                if not m:
                    continue
                prefix = m.group(1) or ''
                num = int(m.group(2))
                if prefix not in groups:
                    groups[prefix] = []
                groups[prefix].append({'name': n, 'idx': idx, 'num': num})

            best = None
            for arr in groups.values():
                if not best or len(arr) > len(best):
                    best = arr

            if not best or len(best) < 2:
                return None

            best.sort(key=lambda x: x['num'])
            return [x['name'] for x in best]

        # Strategy 1: Find joints matching arm-specific naming patterns
        arm_named = [
            name for name in joint_names
            if any(p.search(name) for p in arm_patterns)
            and not any(p.search(name) for p in exclude_patterns)
            and not any(p.search(name) for p in leg_patterns)
        ]

        if arm_named:
            filtered = arm_named
            if side:
                side_filtered = [n for n in arm_named if side.lower() in n.lower()]
                if side_filtered:
                    filtered = side_filtered
            else:
                # Auto-detect: pick first side that has joints (prefer left)
                left = [n for n in arm_named if re.search(r'left|_l_', n, re.I)]
                right = [n for n in arm_named if re.search(r'right|_r_', n, re.I)]
                if left:
                    filtered = left
                elif right:
                    filtered = right

            result = filtered[:max_joints]
            print(f'[OLOJoint] Detected arm joints: {", ".join(result)}')
            return result

        # Strategy 2: Try numbered group detection (e.g. panda_joint1..7)
        arm_joints = detect_numbered_joint_group(joint_names)

        if not arm_joints:
            # Strategy 3 (last resort): first N joints excluding gripper + leg
            all_exclude = exclude_patterns + leg_patterns
            filtered = [
                name for name in joint_names
                if not any(p.search(name) for p in all_exclude)
            ]
            arm_joints = filtered[:min(max_joints, len(filtered))]

        if not arm_joints:
            raise Exception('No arm joints detected')

        print(f'[OLOJoint] Detected arm joints: {", ".join(arm_joints)}')
        return arm_joints

    async def detect_joint_trajectory_topic(self, joint_names: Optional[List[str]] = None) -> str:
        """
        Auto-detect joint trajectory topic using dynamic discovery.
        When multiple controllers exist and joint_names is provided, matches
        the controller that manages those specific joints.

        Args:
            joint_names: Optional list of joint names to match against controllers.
                When provided with multiple controllers, the best-matching controller
                is selected by subscribing to each controller's /state topic.

        Returns:
            Trajectory topic name
        """
        print('[OLOJoint] Using dynamic discovery to find active trajectory topic...')
        
        # Method 1: Try dynamic action server discovery first (matches JavaScript SDK)
        try:
            action_servers = await self.get_action_servers()
            print(f'[OLOJoint] Received action servers: {action_servers}')
            
            # Find trajectory controllers from discovered actions
            trajectory_actions = [
                action for action in action_servers
                if isinstance(action, str) and 'follow_joint_trajectory' in action
            ]
            
            if trajectory_actions:
                selected_action = trajectory_actions[0]

                # If joint names provided and multiple controllers, match by joint overlap
                if joint_names and len(trajectory_actions) > 1:
                    print(f'[OLOJoint] Multiple controllers found, matching by joints...')
                    matched = await self._match_controller_to_joints(trajectory_actions, joint_names)
                    if matched:
                        selected_action = matched

                topic_name = selected_action.replace('/follow_joint_trajectory', '/joint_trajectory')
                
                print(f'[OLOJoint] Dynamic discovery selected active controller topic: {topic_name} (from action: {selected_action})')
                return topic_name
            
            print('[OLOJoint] No active trajectory controllers found via dynamic discovery, falling back to topic listing...')
            
        except Exception as e:
            print(f'[OLOJoint] Dynamic discovery failed, falling back to topic listing: {e}')
        
        # Method 2: Fallback to static topic listing (for backward compatibility)
        topics = await self._core.list_topics(refresh=True)

        # Score candidates
        candidates = []
        for t in topics:
            name = t.get('name', '')
            msg_type = t.get('type', '')

            if msg_type == 'trajectory_msgs/JointTrajectory' or \
               'joint_trajectory' in name.lower():
                score = 0
                if msg_type == 'trajectory_msgs/JointTrajectory':
                    score += 10
                if 'controller' in name.lower():
                    score += 5
                if 'arm' in name.lower() or 'manipulator' in name.lower():
                    score += 2
                if 'joint_trajectory' in name.lower():
                    score += 1
                candidates.append({'name': name, 'type': msg_type, 'score': score})

        if not candidates:
            raise Exception('No joint trajectory topic found')

        # Sort by score descending
        candidates.sort(key=lambda x: -x['score'])
        selected = candidates[0]['name']

        print(f'[OLOJoint] Fallback topic detection selected: {selected}')
        return selected

    async def _match_controller_to_joints(
        self,
        trajectory_actions: List[str],
        joint_names: List[str]
    ) -> Optional[str]:
        """
        Match the correct controller to a set of joints by subscribing to each
        controller's /state topic and checking joint_names overlap.

        Args:
            trajectory_actions: Action server names
            joint_names: Joint names to match

        Returns:
            Best matching action name, or None
        """
        import roslibpy

        async def check_controller(action: str) -> Dict[str, Any]:
            controller_name = action.split('/')[1] if '/' in action else action
            loop = asyncio.get_running_loop()
            future = loop.create_future()

            topic = roslibpy.Topic(
                self._ros,
                f'/{controller_name}/state',
                'control_msgs/JointTrajectoryControllerState'
            )

            def callback(msg):
                controller_joints = msg.get('joint_names', [])
                overlap = len([j for j in joint_names if j in controller_joints])
                topic.unsubscribe()
                if not future.done():
                    loop.call_soon_threadsafe(future.set_result, {'action': action, 'overlap': overlap})

            topic.subscribe(callback)

            try:
                return await asyncio.wait_for(future, timeout=3.0)
            except asyncio.TimeoutError:
                topic.unsubscribe()
                return {'action': action, 'overlap': 0}

        results = await asyncio.gather(*[check_controller(a) for a in trajectory_actions])
        best = max(results, key=lambda r: r['overlap'])
        if best['overlap'] > 0:
            print(f'[OLOJoint] Matched controller {best["action"]} ({best["overlap"]}/{len(joint_names)} joints overlap)')
            return best['action']
        return None

    async def publish_joint_trajectory(
        self,
        topic: str,
        joint_names: List[str],
        points: List[Dict[str, Any]],
        options: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Publish joint trajectory

        Args:
            topic: Trajectory topic name
            joint_names: Joint names in order
            points: Trajectory points with positions, velocities, time_from_start
            options: Publishing options (frameId, etc.)
        """
        if options is None:
            options = {}

        # Build trajectory message
        message = {
            'header': {
                'frame_id': options.get('frameId', ''),
                'stamp': {
                    'sec': 0,
                    'nanosec': 0
                }
            },
            'joint_names': joint_names,
            'points': []
        }

        for point in points:
            traj_point = {
                'positions': point.get('positions', []),
                'velocities': point.get('velocities', [0.0] * len(joint_names)),
                'accelerations': point.get('accelerations', [0.0] * len(joint_names)),
                'time_from_start': point.get('time_from_start', {'sec': 1, 'nanosec': 0})
            }
            message['points'].append(traj_point)

        print(f'[OLOJoint] Publishing trajectory to {topic} for joints: {", ".join(joint_names)}')
        await self._core.publish(topic, message, {'messageType': 'trajectory_msgs/JointTrajectory'})

    async def move_joints_to_positions(
        self,
        joint_names: List[str],
        target_positions: List[float],
        options: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Move joints to target positions

        Args:
            joint_names: Joint names in order
            target_positions: Target positions for each joint
            options: Movement options:
                - topic: Trajectory topic (optional, auto-detected)
                - duration: Movement duration in seconds (default: 2)
                - currentPositions: Current positions (optional, fetched if not provided)
                - abortSignal: Signal dict with 'aborted' key
        """
        if options is None:
            options = {}

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        abort_signal = options.get('abortSignal')

        # Check if already aborted
        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        if len(joint_names) != len(target_positions):
            raise ValueError('Joint names and positions arrays must have same length')

        # Get current positions if not provided
        current_positions = options.get('currentPositions')
        if not current_positions:
            if abort_signal and abort_signal.get('aborted'):
                raise Exception('Aborted')

            joint_states = await self.get_current_joint_states()
            current_positions = [
                joint_states['jointStates'].get(name, 0.0)
                for name in joint_names
            ]

        # Auto-detect trajectory topic if not provided
        topic = options.get('topic')
        if not topic:
            if abort_signal and abort_signal.get('aborted'):
                raise Exception('Aborted')

            # Pass joint names so the detector can match the correct controller
            topic = await self.detect_joint_trajectory_topic(joint_names)

        # Final abort check
        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        duration = options.get('duration', 2)
        points = [
            # Start point (current positions)
            {
                'positions': current_positions,
                'time_from_start': {'sec': 0, 'nanosec': 0}
            },
            # End point (target positions)
            {
                'positions': target_positions,
                'time_from_start': {'sec': duration, 'nanosec': 0}
            }
        ]

        print(f'[OLOJoint] Moving {len(joint_names)} joints over {duration}s')

        # Publish the trajectory
        await self.publish_joint_trajectory(topic, joint_names, points, options)
        print('[OLOJoint] Trajectory published, robot is moving...')

        # Wait for trajectory duration while checking abort signal
        trajectory_duration_s = duration
        check_interval = 0.1
        elapsed = 0.0

        while elapsed < trajectory_duration_s:
            if abort_signal and abort_signal.get('aborted'):
                print('[OLOJoint] Joint movement aborted - stopping')
                try:
                    await self.stop_joint_movement(topic, joint_names)
                    print('[OLOJoint] Joint movement successfully stopped')
                except Exception as e:
                    print(f'[OLOJoint] Could not send stop trajectory: {e}')
                raise Exception('Aborted')

            await asyncio.sleep(check_interval)
            elapsed += check_interval

        print('[OLOJoint] Joint trajectory completed successfully')

    async def stop_joint_movement(self, topic: str, joint_names: List[str]) -> None:
        """
        Stop joint movement by publishing a hold trajectory

        Args:
            topic: Trajectory topic name
            joint_names: Joint names
        """
        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        print('[OLOJoint] Stopping joint movement')

        # Get current positions
        joint_states = await self.get_current_joint_states()
        current_positions = [
            joint_states['jointStates'].get(name, 0.0)
            for name in joint_names
        ]

        # Send hold trajectory (two points at current position)
        hold_duration = 0.05
        hold_points = [
            {
                'positions': current_positions,
                'time_from_start': {'sec': 0, 'nanosec': 0}
            },
            {
                'positions': current_positions,
                'time_from_start': {
                    'sec': int(hold_duration),
                    'nanosec': int((hold_duration % 1) * 1_000_000_000)
                }
            }
        ]

        await self.publish_joint_trajectory(topic, joint_names, hold_points)
        print('[OLOJoint] Hold trajectory sent')

    async def stop_all_joints(self) -> None:
        """
        Stop all arm joints immediately
        """
        try:
            arm_joints = await self.detect_arm_joints()
            topic = await self.detect_joint_trajectory_topic()
            await self.stop_joint_movement(topic, arm_joints)
        except Exception as e:
            print(f'[OLOJoint] Failed to stop all joints: {e}')
            raise

    def get_cached_joint_states(self) -> Optional[Dict[str, Any]]:
        """
        Get cached joint states if available

        Returns:
            Cached joint states or None
        """
        return self._cached_joint_states

    async def move_end_effector_to_position(
        self,
        target_pose: Dict[str, Any],
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Move end effector to target position using inverse kinematics planning.

        Args:
            target_pose: Target pose for end effector
                - position: Dict with x, y, z in meters
                - orientation: Optional Dict with x, y, z, w quaternion
            options: Movement options
                - planningGroup: MoveIt planning group (auto-detected if not provided)
                - endEffectorLink: End effector link name (auto-detected if not provided)
                - baseFrame: Base frame for pose coordinates (auto-detected if not provided)
                - timeout: Planning timeout in seconds (default: 5)
                - executeTrajectory: Whether to execute (default: True)
                - speed: Speed multiplier (default: 1.0)
                - maxJointDisplacement: Max radians each joint can move from current position.
                    Default is PI (180 deg). Use lower values like 0.5 (30 deg) to prevent
                    sweeping moves and force nearby IK solutions.
                - useMotionPlanning: Use MoveIt's path planner to compute a collision-free
                    trajectory that avoids obstacles in the planning scene (default: False).
                    When enabled, MoveIt uses OMPL planners (e.g. RRTConnect) to find a
                    multi-waypoint path around collision objects. Requires obstacles to be
                    synced to MoveIt's planning scene first.
                - abortSignal: Signal dict with 'aborted' key

        Returns:
            Dict with planning result including joint_names, joint_positions, etc.
        """
        import json
        import time
        import random
        import string

        if options is None:
            options = {}

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        abort_signal = options.get('abortSignal')

        # Check if already aborted
        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        if not target_pose or 'position' not in target_pose:
            raise ValueError('Target pose with position {x, y, z} is required')

        print(f'[OLOJoint] Planning end effector movement to position: {target_pose["position"]}')

        # Get orientation - use provided or default to identity quaternion
        orientation = target_pose.get('orientation')
        if not orientation:
            print('[OLOJoint] No orientation specified, using identity quaternion')
            orientation = {'x': 0, 'y': 0, 'z': 0, 'w': 1}

        # Get options or auto-detect planning group, end effector, and base frame
        planning_group = options.get('planningGroup')
        end_effector_link = options.get('endEffectorLink')
        base_frame = options.get('baseFrame')
        timeout = options.get('timeout', 5)
        execute_trajectory = options.get('executeTrajectory', True)
        speed = options.get('speed', 1.0)

        # Auto-detect planning group, end effector, and base frame if not provided
        if not planning_group or not end_effector_link or not base_frame:
            # Check abort signal before potentially slow operation
            if abort_signal and abort_signal.get('aborted'):
                raise Exception('Aborted')
            
            try:
                robot_info = await self.detect_robot_info()
                if robot_info:
                    planning_group = planning_group or robot_info.get('planning_group')
                    end_effector_link = end_effector_link or robot_info.get('end_effector_link')
                    base_frame = base_frame or robot_info.get('base_frame')
            except Exception as e:
                print(f'[OLOJoint] Could not auto-detect robot info: {e}')
        
        # Final fallbacks if auto-detection failed
        if not planning_group:
            print('[OLOJoint] Warning: Could not auto-detect planning group, using fallback')
            planning_group = 'manipulator'  # Common default for UR robots
        if not end_effector_link:
            print('[OLOJoint] Warning: Could not auto-detect end effector, using fallback')
            end_effector_link = 'tool0'  # Common default for UR robots
        if not base_frame:
            print('[OLOJoint] Warning: Could not auto-detect base frame, using fallback')
            base_frame = 'base_link'

        # Final abort check before planning
        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        print(f'[OLOJoint] Using planning group: {planning_group}, end effector: {end_effector_link}')
        print(f'[OLOJoint] Using base frame: {base_frame}')

        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'ik_{int(time.time() * 1000)}_{random_suffix}'

        # Create IK request
        ik_request = {
            'op': 'execute_moveit_ik',
            'request_id': request_id,
            'planning_group': planning_group,
            'end_effector_link': end_effector_link,
            'target_pose': {
                'position': target_pose['position'],
                'orientation': orientation
            },
            'timeout': timeout,
            'execute_trajectory': execute_trajectory,
            'base_frame': base_frame,
            'speed': speed,
            'avoid_collisions': options.get('avoidCollisions', False),
            'min_duration': options.get('minDuration')
        }
        
        # Add maxJointDisplacement if provided
        max_joint_displacement = options.get('maxJointDisplacement')
        if max_joint_displacement is not None:
            ik_request['max_joint_displacement'] = max_joint_displacement
        
        # Add useMotionPlanning if provided - uses MoveIt path planner for collision-free trajectories
        use_motion_planning = options.get('useMotionPlanning', False)
        if use_motion_planning:
            ik_request['use_motion_planning'] = True

        print(f'[OLOJoint] Sending IK planning request')

        # Send request and wait for response
        result = await self._send_ik_request(ik_request, timeout + 2)

        # Check abort after completion
        if abort_signal and abort_signal.get('aborted'):
            print('[OLOJoint] IK planning/execution aborted by user')
            try:
                await self.stop_all_joints()
                print('[OLOJoint] Robot movement successfully stopped')
            except Exception as e:
                print(f'[OLOJoint] Could not stop robot movement: {e}')
            raise Exception('Aborted')

        print('[OLOJoint] End effector movement completed successfully')
        return result

    async def _send_ik_request(
        self,
        ik_request: Dict[str, Any],
        timeout: float
    ) -> Dict[str, Any]:
        """
        Send IK request to the appliance and wait for response

        Args:
            ik_request: The IK request dict
            timeout: Timeout in seconds

        Returns:
            Planning result dict
        """
        import json

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        request_id = ik_request['request_id']

        def handle_message(msg):
            """Handle incoming messages looking for our response"""
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'moveit_ik_result':
                    if data.get('success'):
                        print('[OLOJoint] IK planning successful')
                        result = data.get('result', {})
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, result)
                    else:
                        error_msg = data.get('error', 'IK planning failed')
                        print(f'[OLOJoint] IK planning failed: {error_msg}')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance for sending/receiving messages
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        # Hook into roslibpy's message handling
        old_onMessage = None
        custom_ops = {'moveit_ik_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')

                        # Handle our custom messages
                        handle_message(msg_str)

                        # Only call original handler for non-custom ops
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            # Send the message
            msg_json = json.dumps(ik_request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            # Wait for response with timeout
            return await asyncio.wait_for(future, timeout=timeout)

        except asyncio.TimeoutError:
            raise TimeoutError(f"IK planning request timed out after {timeout}s")
        finally:
            # Restore original handler
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def execute_planned_trajectory(
        self,
        plan_result: Dict[str, Any],
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Execute a previously planned trajectory.
        
        This allows for a two-step workflow: plan first (with executeTrajectory: false),
        review/validate the plan, then execute it separately.

        Args:
            plan_result: The planning result from move_end_effector_to_position
                - joint_names: List of joint names
                - joint_positions: List of target positions
            options: Execution options
                - speed: Speed multiplier (default: 1.0)
                - useMotionPlanning: Use MoveIt path planner for collision-free
                    trajectories (default: False). Requires planningGroup.
                - planningGroup: MoveIt planning group name (auto-detected if not
                    provided). Required when useMotionPlanning is True.
                - abortSignal: Signal dict with 'aborted' key

        Returns:
            Dict with execution result
        """
        import json
        import time
        import random
        import string

        if options is None:
            options = {}

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        abort_signal = options.get('abortSignal')

        # Check if already aborted
        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        # Validate plan result
        if not plan_result:
            raise ValueError('Plan result is required')

        joint_names = plan_result.get('joint_names', [])
        joint_positions = plan_result.get('joint_positions', [])

        if not joint_names or len(joint_names) == 0:
            raise ValueError('Invalid plan result: missing joint_names array')

        if not joint_positions or len(joint_positions) == 0:
            raise ValueError('Invalid plan result: missing joint_positions array')

        if len(joint_names) != len(joint_positions):
            raise ValueError('Invalid plan result: joint_names and joint_positions must have same length')

        print(f'[OLOJoint] Executing planned trajectory for {len(joint_names)} joints')

        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'exec_{int(time.time() * 1000)}_{random_suffix}'

        # Create execution request
        execution_request = {
            'op': 'execute_planned_trajectory',
            'request_id': request_id,
            'joint_names': joint_names,
            'joint_positions': joint_positions,
            'speed': options.get('speed', 1.0)
        }
        
        # Add motion planning options if requested
        use_motion_planning = options.get('useMotionPlanning', False)
        if use_motion_planning:
            execution_request['use_motion_planning'] = True
            planning_group = options.get('planningGroup')
            if not planning_group:
                try:
                    robot_info = await self.detect_robot_info()
                    planning_group = robot_info.get('planning_group') if robot_info else None
                except Exception as e:
                    print(f'[OLOJoint] Could not auto-detect planning group: {e}')
            if planning_group:
                execution_request['planning_group'] = planning_group

        # Send request and wait for response
        result = await self._send_execution_request(execution_request, 30)

        # Check abort after completion
        if abort_signal and abort_signal.get('aborted'):
            print('[OLOJoint] Trajectory execution aborted by user')
            try:
                await self.stop_all_joints()
                print('[OLOJoint] Robot movement successfully stopped')
            except Exception as e:
                print(f'[OLOJoint] Could not stop robot movement: {e}')
            raise Exception('Aborted')

        print('[OLOJoint] Planned trajectory execution completed successfully')
        return result

    async def _send_execution_request(
        self,
        execution_request: Dict[str, Any],
        timeout: float
    ) -> Dict[str, Any]:
        """
        Send execution request to the appliance and wait for response

        Args:
            execution_request: The execution request dict
            timeout: Timeout in seconds

        Returns:
            Execution result dict
        """
        import json

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        request_id = execution_request['request_id']

        def handle_message(msg):
            """Handle incoming messages looking for our response"""
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'execute_planned_trajectory_result':
                    if data.get('success'):
                        print('[OLOJoint] Trajectory execution successful')
                        result = data.get('result', {})
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, result)
                    else:
                        error_msg = data.get('error', 'Trajectory execution failed')
                        print(f'[OLOJoint] Trajectory execution failed: {error_msg}')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance for sending/receiving messages
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        # Hook into roslibpy's message handling
        old_onMessage = None
        custom_ops = {'execute_planned_trajectory_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')

                        # Handle our custom messages
                        handle_message(msg_str)

                        # Only call original handler for non-custom ops
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            # Send the message
            msg_json = json.dumps(execution_request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
                print('[OLOJoint] Sent trajectory execution request to appliance')
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            # Wait for response with timeout
            return await asyncio.wait_for(future, timeout=timeout)

        except asyncio.TimeoutError:
            raise TimeoutError(f"Trajectory execution request timed out after {timeout}s")
        finally:
            # Restore original handler
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def get_available_planning_groups(self) -> List[str]:
        """
        Get list of available planning groups from robot configuration.

        Returns:
            List of planning group names
        """
        try:
            robot_info = await self.detect_robot_info()
            if robot_info and robot_info.get('available_groups'):
                return robot_info['available_groups']
        except Exception as e:
            print(f'[OLOJoint] Could not get planning groups: {e}')
        return []

    async def get_srdf(self) -> str:
        """
        Get SRDF (Semantic Robot Description Format) data from the appliance.
        
        Returns:
            SRDF XML string
        """
        import json
        import time as time_module
        import random
        import string
        import base64

        # Return cached SRDF if fresh (1 minute cache)
        now = time_module.time()
        if self._cached_srdf and (now - self._cached_srdf_timestamp) < 60:
            print('[OLOJoint] Using cached SRDF')
            return self._cached_srdf

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'srdf_{int(time_module.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'srdf_data':
                    if data.get('error'):
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(data['error'])
                            )
                    else:
                        # Decode base64 SRDF data
                        srdf_data = base64.b64decode(data.get('data', '')).decode('utf-8')
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, srdf_data)
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'srdf_data'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            request = {
                'op': 'get_srdf',
                'request_id': request_id
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            result = await asyncio.wait_for(future, timeout=5.0)
            
            # Cache the result
            self._cached_srdf = result
            self._cached_srdf_timestamp = time_module.time()
            
            return result

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for SRDF data")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def get_robot_description(self) -> str:
        """
        Get URDF robot description from the /robot_description topic.
        
        Returns:
            URDF XML string
        """
        import time as time_module

        # Return cached URDF if fresh (1 minute cache)
        now = time_module.time()
        if self._cached_urdf and (now - self._cached_urdf_timestamp) < 60:
            print('[OLOJoint] Using cached robot description')
            return self._cached_urdf

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        # Subscribe to /robot_description topic
        from roslibpy import Topic

        topic = Topic(self._ros, '/robot_description', 'std_msgs/String')

        def callback(message):
            if not future.done():
                loop.call_soon_threadsafe(future.set_result, message.get('data', ''))
            topic.unsubscribe()

        topic.subscribe(callback)

        try:
            result = await asyncio.wait_for(future, timeout=5.0)
            
            # Cache the result
            self._cached_urdf = result
            self._cached_urdf_timestamp = time_module.time()
            
            return result
        except asyncio.TimeoutError:
            topic.unsubscribe()
            raise TimeoutError("Timeout waiting for robot description")

    async def detect_robot_info(self) -> Optional[Dict[str, Any]]:
        """
        Auto-detect robot configuration from SRDF and URDF.
        Returns planning group, end effector link, base frame, and available groups.
        
        Returns:
            Dict with planningGroup, endEffectorLink, baseFrame, availableGroups
        """
        import time as time_module
        import xml.etree.ElementTree as ET

        # Return cached robot info if fresh
        now = time_module.time()
        is_fallback = self._cached_robot_info and self._cached_robot_info.get('is_fallback', False)
        ttl = 5 if is_fallback else 60  # 5s for fallback, 1min for proper detection
        
        if self._cached_robot_info and (now - self._cached_robot_info_timestamp) < ttl:
            print('[OLOJoint] Using cached robot info')
            return self._cached_robot_info

        try:
            # Get SRDF data
            srdf_data = await self.get_srdf()
            print('[OLOJoint] Parsing SRDF data for robot configuration...')
            
            # Parse SRDF XML
            root = ET.fromstring(srdf_data)
            
            # Find all planning groups
            planning_groups = []
            group_defs = {}
            
            for group in root.findall('.//group'):
                name = group.get('name')
                if not name:
                    continue
                
                # Get joints, links, and chains defined in this group
                joints = [j.get('name') for j in group.findall('joint') if j.get('name')]
                links = [l.get('name') for l in group.findall('link') if l.get('name')]
                chains = [{'base': c.get('base_link'), 'tip': c.get('tip_link')} 
                         for c in group.findall('chain') if c.get('base_link') and c.get('tip_link')]
                
                if joints or links or chains:
                    print(f"[OLOJoint] Group '{name}': joints={joints}, links={links}, chains={chains}")
                    planning_groups.append(name)
                    group_defs[name] = {'joints': joints, 'links': links, 'chains': chains}
            
            print(f'[OLOJoint] Found planning groups: {planning_groups}')
            
            # Choose the best planning group (prefer arm-like groups)
            selected_group = None
            arm_priorities = ['arm', 'manipulator', 'robot']
            
            for priority in arm_priorities:
                for group in planning_groups:
                    if priority in group.lower():
                        selected_group = group
                        break
                if selected_group:
                    break
            
            # If no arm-like group found, use the first non-gripper group
            if not selected_group and planning_groups:
                for group in planning_groups:
                    if 'gripper' not in group.lower() and 'hand' not in group.lower():
                        selected_group = group
                        break
                if not selected_group:
                    selected_group = planning_groups[0]
            
            # Extract end effector information from SRDF
            end_effector_link = None
            for ee in root.findall('.//end_effector'):
                parent_link = ee.get('parent_link')
                if parent_link:
                    end_effector_link = parent_link
                    print(f'[OLOJoint] Found end effector from SRDF: {end_effector_link}')
                    break
            
            # If no end effector in SRDF, look at selected group's chains
            if not end_effector_link and selected_group and selected_group in group_defs:
                chains = group_defs[selected_group].get('chains', [])
                if chains:
                    end_effector_link = chains[0].get('tip')
                    print(f'[OLOJoint] Found end effector from chain tip: {end_effector_link}')
            
            # Try to get end effector from URDF if still not found
            if not end_effector_link:
                try:
                    end_effector_link = await self._detect_end_effector_from_urdf()
                    print(f'[OLOJoint] Got end effector from URDF: {end_effector_link}')
                except Exception as e:
                    print(f'[OLOJoint] Could not detect end effector from URDF: {e}')
                    end_effector_link = 'tool0'  # Final fallback
            
            # Detect base frame from URDF
            base_frame = 'base_link'
            try:
                base_frame = await self._detect_base_frame_from_urdf()
            except Exception as e:
                print(f'[OLOJoint] Could not detect base frame from URDF: {e}')
            
            robot_info = {
                'planning_group': selected_group,
                'end_effector_link': end_effector_link,
                'base_frame': base_frame,
                'available_groups': planning_groups,
                'group_definitions': group_defs
            }
            
            # Cache the result
            self._cached_robot_info = robot_info
            self._cached_robot_info_timestamp = time_module.time()
            
            print(f'[OLOJoint] Detected robot info: {robot_info}')
            return robot_info
            
        except Exception as e:
            print(f'[OLOJoint] Could not detect robot info from SRDF: {e}')
            return None

    async def _detect_end_effector_from_urdf(self) -> str:
        """
        Detect end effector link from URDF by finding leaf links or pattern matching.
        
        Returns:
            End effector link name
        """
        urdf = await self.get_robot_description()
        
        # Method 1: Look for links with end effector naming patterns
        end_effector_patterns = ['tool0', 'tcp', 'end_effector', 'eef', 'gripper', 'hand']
        
        for pattern in end_effector_patterns:
            import re
            match = re.search(rf'<link\s+name="([^"]*{pattern}[^"]*)"', urdf, re.IGNORECASE)
            if match:
                print(f'[OLOJoint] Found end effector link by pattern: {match.group(1)}')
                return match.group(1)
        
        # Method 2: Find leaf link (link that is not a parent in any joint)
        import re
        link_matches = re.findall(r'<link\s+name="([^"]+)"', urdf)
        all_links = set(link_matches)
        
        parent_matches = re.findall(r'<parent\s+link="([^"]+)"', urdf)
        parent_links = set(parent_matches)
        
        # Leaf links are links that are never parents
        child_matches = re.findall(r'<child\s+link="([^"]+)"', urdf)
        child_links = set(child_matches)
        
        # Links that are children but not parents
        leaf_links = [l for l in all_links if l not in parent_links and l in child_links]
        if leaf_links:
            print(f'[OLOJoint] Found end effector as leaf link: {leaf_links[0]}')
            return leaf_links[0]
        
        return 'tool0'

    async def _detect_base_frame_from_urdf(self) -> str:
        """
        Detect base frame from URDF.
        
        Returns:
            Base frame name
        """
        urdf = await self.get_robot_description()
        import re
        
        # Prefer common base names if present
        common_bases = ['base_link', 'world', 'base', 'base_footprint']
        for base in common_bases:
            if re.search(rf'<link\s+name="{base}"', urdf):
                return base
        
        # Compute root link: link that never appears as a child in any joint
        link_matches = re.findall(r'<link\s+name="([^"]+)"', urdf)
        all_links = set(link_matches)
        
        child_matches = re.findall(r'<child\s+link="([^"]+)"', urdf)
        child_links = set(child_matches)
        
        roots = [name for name in all_links if name not in child_links]
        if roots:
            return roots[0]
        
        # Fallback: look for names like *_link0
        link0 = next((n for n in all_links if re.search(r'link0$', n, re.IGNORECASE)), None)
        if link0:
            return link0
        
        return 'base_link'

    async def get_action_servers(self) -> List[str]:
        """
        Get available action servers from the appliance.

        Returns:
            List of action server names
        """
        import json
        import time
        import random
        import string

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'actions_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'action_servers_data':
                    if data.get('error'):
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(data['error'])
                            )
                    else:
                        actions = data.get('actions', [])
                        # Extract action names from objects or strings
                        action_names = []
                        for action in actions:
                            if isinstance(action, str):
                                action_names.append(action.split(' ')[0])
                            elif isinstance(action, dict):
                                action_names.append(action.get('name', str(action)))
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, action_names)
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'action_servers_data'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            request = {
                'op': 'get_action_servers',
                'request_id': request_id
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=5.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for action servers")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def get_current_end_effector_pose(
        self,
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Get current end effector pose.

        Args:
            options: Optional dict with planningGroup, endEffectorLink, baseFrame

        Returns:
            Dict with position {x, y, z} and orientation {x, y, z, w}
        """
        import json
        import time
        import random
        import string

        if options is None:
            options = {}

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        # Get options or auto-detect planning group, end effector, and base frame
        planning_group = options.get('planningGroup')
        end_effector_link = options.get('endEffectorLink')
        base_frame = options.get('baseFrame')

        # Auto-detect if not provided
        if not planning_group or not end_effector_link or not base_frame:
            try:
                robot_info = await self.detect_robot_info()
                if robot_info:
                    planning_group = planning_group or robot_info.get('planning_group')
                    end_effector_link = end_effector_link or robot_info.get('end_effector_link')
                    base_frame = base_frame or robot_info.get('base_frame')
            except Exception as e:
                print(f'[OLOJoint] Could not auto-detect robot info: {e}')
        
        # Final fallbacks if auto-detection failed
        if not planning_group:
            planning_group = 'manipulator'
        if not end_effector_link:
            end_effector_link = 'tool0'
        if not base_frame:
            base_frame = 'base_link'

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        import time
        import random
        import string
        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'pose_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'end_effector_pose_result':
                    if data.get('success'):
                        pose = data.get('pose', {})
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, pose)
                    else:
                        error_msg = data.get('error', 'Failed to get end effector pose')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'end_effector_pose_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            request = {
                'op': 'get_end_effector_pose',
                'request_id': request_id,
                'planning_group': planning_group,
                'end_effector_link': end_effector_link,
                'base_frame': base_frame
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=5.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for end effector pose")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def control_gripper(
        self,
        options: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Control gripper using MoveIt planning.

        Args:
            options: Gripper control options
                - planningGroup: Planning group name for gripper (required)
                - controllerName: Controller name for gripper (required)
                - jointNames: List of joint names for the gripper (optional)
                - position: Target position (0.0 = closed, 1.0 = open by default)
                - isNormalized: If True (default), position is 0-1 range. If False, position is actual joint value.
                - maxEffort: Maximum effort (default: 20.0)
                - timeout: Command timeout in seconds (default: 5)
                - abortSignal: Signal dict with 'aborted' key

        Returns:
            Dict with gripper control result
        """
        import json
        import time
        import random
        import string

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        abort_signal = options.get('abortSignal')

        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        if options.get('position') is None:
            raise ValueError('Position is required (0.0 = closed, 1.0 = open)')

        if not options.get('planningGroup'):
            raise ValueError('Planning group is required for gripper control')

        if not options.get('controllerName'):
            raise ValueError('Controller name is required for gripper control')

        planning_group = options['planningGroup']
        controller_name = options['controllerName']
        joint_names = options.get('jointNames')  # Optional: specific joint names
        position = options['position']
        max_effort = options.get('maxEffort', 20.0)
        timeout = options.get('timeout', 5)
        is_normalized = options.get('isNormalized', True)  # Default True for backward compatibility

        # Auto-detect joint names from cached robot info if not provided
        if not joint_names:
            # Try to get from cache first, otherwise fetch robot info
            if not self._cached_robot_info:
                try:
                    print('[OLOJoint] No cached robot info, fetching for joint name auto-detection...')
                    await self.detect_robot_info()
                except Exception as e:
                    print(f'[OLOJoint] Could not fetch robot info for joint detection: {e}')
            
            if self._cached_robot_info:
                group_defs = self._cached_robot_info.get('group_definitions', {})
                group_def = group_defs.get(planning_group)
                if group_def and group_def.get('joints'):
                    joint_names = group_def['joints']
                    print(f'[OLOJoint] Auto-detected joint names from SRDF: {joint_names}')

        print(f'[OLOJoint] Controlling gripper to position: {position}')
        print(f'[OLOJoint] Using gripper planning group: {planning_group}')
        print(f'[OLOJoint] Using gripper controller: {controller_name}')
        print(f'[OLOJoint] Using gripper joints: {joint_names if joint_names else "(none)"}')

        # Try to get joint type and limits from URDF for accurate scaling
        joint_type = None
        joint_limits = None
        if joint_names and len(joint_names) > 0:
            try:
                urdf = await self.get_robot_description()
                if urdf:
                    main_joint = joint_names[0]
                    # Parse joint type and limits from URDF
                    import re
                    joint_pattern = rf'<joint[^>]+name=["\']({re.escape(main_joint)})["\'][^>]*>([\s\S]*?)</joint>'
                    joint_match = re.search(joint_pattern, urdf, re.IGNORECASE)
                    if joint_match:
                        joint_block = joint_match.group(0)
                        joint_content = joint_match.group(2)
                        # Get joint type
                        type_match = re.search(r'type=["\'](\w+)["\']', joint_block, re.IGNORECASE)
                        if type_match:
                            joint_type = type_match.group(1).lower()
                            print(f'[OLOJoint] Detected joint type from URDF: {joint_type}')
                        # Get joint limits
                        limit_match = re.search(r'<limit[^>]+/>', joint_content, re.IGNORECASE)
                        if limit_match:
                            limit_str = limit_match.group(0)
                            lower_match = re.search(r'lower=["\']([^"\']+)["\']', limit_str, re.IGNORECASE)
                            upper_match = re.search(r'upper=["\']([^"\']+)["\']', limit_str, re.IGNORECASE)
                            if lower_match and upper_match:
                                joint_limits = {
                                    'lower': float(lower_match.group(1)),
                                    'upper': float(upper_match.group(1))
                                }
                                print(f'[OLOJoint] Detected joint limits from URDF: [{joint_limits["lower"]}, {joint_limits["upper"]}]')
            except Exception as e:
                print(f'[OLOJoint] Could not parse joint info from URDF: {e}')

        if abort_signal and abort_signal.get('aborted'):
            raise Exception('Aborted')

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        # Generate unique request ID
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'gripper_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'joint_control_result':
                    if data.get('success'):
                        print('[OLOJoint] Gripper control successful')
                        result = data.get('result', {'success': True})
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, result)
                    else:
                        error_msg = data.get('error', 'Gripper control failed')
                        print(f'[OLOJoint] Gripper control failed: {error_msg}')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        # Get the protocol instance
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'joint_control_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            # By default, SDK uses normalized positions (0.0 = closed, 1.0 = open)
            # Set isNormalized: False to pass actual joint positions (e.g., from waypoint playback)
            request = {
                'op': 'execute_joint_control',
                'request_id': request_id,
                'command_type': 'moveit_gripper',
                'controller_name': controller_name,
                'planning_group': planning_group,  # Required for MoveGroup action
                'joint_names': joint_names,  # Optional: specific joint names for the gripper
                'position': position,
                'max_effort': max_effort,
                'timeout': timeout,
                'is_normalized': is_normalized,  # True = 0-1 range (appliance scales), False = actual joint position
                'joint_type': joint_type,  # From URDF: 'revolute' or 'prismatic'
                'joint_limits': joint_limits  # From URDF: { 'lower', 'upper' }
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
                print('[OLOJoint] Sent gripper control request')
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            result = await asyncio.wait_for(future, timeout=timeout + 2)

            if abort_signal and abort_signal.get('aborted'):
                raise Exception('Aborted')

            print('[OLOJoint] Gripper control completed successfully')
            return result

        except asyncio.TimeoutError:
            raise TimeoutError(f"Gripper control request timed out after {timeout}s")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def open_gripper(self, options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Open gripper (convenience method).

        Args:
            options: Options for gripper control (planningGroup and controllerName required)

        Returns:
            Dict with gripper control result
        """
        return await self.control_gripper({**options, 'position': 1.0})

    async def close_gripper(self, options: Dict[str, Any]) -> Dict[str, Any]:
        """
        Close gripper (convenience method).

        Args:
            options: Options for gripper control (planningGroup and controllerName required)

        Returns:
            Dict with gripper control result
        """
        return await self.control_gripper({**options, 'position': 0.0})

    async def list_moveit_configs(self) -> List[Dict[str, Any]]:
        """
        List available MoveIt configuration packages on the appliance.

        Returns:
            List of config objects with package name and launch file info
        """
        import json
        import time
        import random
        import string

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'moveit_list_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'moveit_list_configs_result':
                    if data.get('success'):
                        configs = data.get('configs', [])
                        print(f'[OLOJoint] Available MoveIt configs: {configs}')
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, configs)
                    else:
                        error_msg = data.get('error', 'Failed to list MoveIt configs')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'moveit_list_configs_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            request = {
                'op': 'moveit_list_configs',
                'request_id': request_id
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=10.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for MoveIt configs list")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def start_moveit_engine(
        self,
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Start the MoveIt2 motion planning engine on the appliance.

        Args:
            options: Configuration options
                - configPackage: MoveIt config package name (e.g., 'moveit_resources_panda_moveit_config')
                - moveGroupOnly: If True, only start move_group (robot must already be running)
                - useSimTime: Use simulation time (auto-detected if not specified)
                - robotNamespace: Robot namespace for multi-robot scenarios

        Returns:
            Dict with success status, launchPackage, launchFile, etc.
        """
        import json
        import time
        import random
        import string

        if options is None:
            options = {}

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'moveit_start_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'moveit_start_result':
                    if data.get('success'):
                        print('[OLOJoint] MoveIt engine started successfully')
                        result = {
                            'success': True,
                            'message': data.get('message'),
                            'launchPackage': data.get('launchPackage'),
                            'launchFile': data.get('launchFile'),
                            'warning': data.get('warning'),
                            'already_running': data.get('already_running', False)
                        }
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, result)
                    else:
                        error_msg = data.get('error', 'Failed to start MoveIt engine')
                        print(f'[OLOJoint] Failed to start MoveIt: {error_msg}')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'moveit_start_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            mode = ' (move_group only)' if options.get('moveGroupOnly') else ''
            config = options.get('configPackage')
            if config:
                print(f'[OLOJoint] Starting MoveIt engine{mode} with config: {config}')
            else:
                print(f'[OLOJoint] Starting MoveIt engine{mode} (auto-detect configuration)')

            request = {
                'op': 'moveit_start',
                'request_id': request_id,
                'configPackage': options.get('configPackage'),
                'moveGroupOnly': options.get('moveGroupOnly', False),
                'robotNamespace': options.get('robotNamespace'),
                'useSimTime': options.get('useSimTime')
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=60.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for MoveIt start response")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def stop_moveit_engine(self) -> Dict[str, Any]:
        """
        Stop the MoveIt2 motion planning engine on the appliance.

        Returns:
            Dict with success status
        """
        import json
        import time
        import random
        import string

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'moveit_stop_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'moveit_stop_result':
                    if data.get('success'):
                        print('[OLOJoint] MoveIt engine stopped successfully')
                        if not future.done():
                            loop.call_soon_threadsafe(future.set_result, {'success': True})
                    else:
                        error_msg = data.get('error', 'Failed to stop MoveIt engine')
                        print(f'[OLOJoint] Failed to stop MoveIt: {error_msg}')
                        if not future.done():
                            loop.call_soon_threadsafe(
                                future.set_exception,
                                Exception(error_msg)
                            )
            except (json.JSONDecodeError, TypeError):
                pass

        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'moveit_stop_result'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            print('[OLOJoint] Stopping MoveIt engine')
            request = {
                'op': 'moveit_stop',
                'request_id': request_id
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=10.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for MoveIt stop response")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    async def get_moveit_status(self) -> Dict[str, Any]:
        """
        Check the MoveIt engine status on the appliance.

        Returns:
            Dict with is_running, moveit_available, running_components, source
        """
        import json
        import time
        import random
        import string

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to ROS")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=9))
        request_id = f'moveit_status_{int(time.time() * 1000)}_{random_suffix}'

        def handle_message(msg):
            try:
                if isinstance(msg, str):
                    data = json.loads(msg)
                elif isinstance(msg, dict):
                    data = msg
                else:
                    return

                if data.get('request_id') != request_id:
                    return

                op = data.get('op', '')

                if op == 'moveit_status_response':
                    print(f'[OLOJoint] MoveIt status: {data}')
                    result = {
                        'is_running': data.get('is_running', False),
                        'moveit_available': data.get('moveit_available', False),
                        'running_components': data.get('running_components', []),
                        'source': data.get('source')
                    }
                    if not future.done():
                        loop.call_soon_threadsafe(future.set_result, result)
            except (json.JSONDecodeError, TypeError):
                pass

        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        old_onMessage = None
        custom_ops = {'moveit_status_response'}

        if proto_instance and hasattr(proto_instance, 'onMessage'):
            old_onMessage = proto_instance.onMessage

            def patched_onMessage(payload, isBinary):
                if not isBinary:
                    try:
                        msg_str = payload.decode('utf-8') if isinstance(payload, bytes) else payload
                        msg = json.loads(msg_str)
                        op = msg.get('op', '')
                        handle_message(msg_str)
                        if op not in custom_ops and old_onMessage:
                            old_onMessage(payload, isBinary)
                    except json.JSONDecodeError:
                        if old_onMessage:
                            old_onMessage(payload, isBinary)
                else:
                    if old_onMessage:
                        old_onMessage(payload, isBinary)

            proto_instance.onMessage = patched_onMessage

        try:
            request = {
                'op': 'moveit_status_check',
                'request_id': request_id
            }
            msg_json = json.dumps(request)
            if proto_instance:
                proto_instance.sendMessage(msg_json.encode('utf-8'))
            else:
                raise ConnectionError("Cannot send message - protocol not connected")

            return await asyncio.wait_for(future, timeout=5.0)

        except asyncio.TimeoutError:
            raise TimeoutError("Timeout waiting for MoveIt status response")
        finally:
            if proto_instance and old_onMessage is not None:
                proto_instance.onMessage = old_onMessage

    # ===========================================
    # PLANNING SCENE MANAGEMENT
    # ===========================================

    def _setup_planning_scene_message_handler(self) -> None:
        """Set up message handler for planning scene operations (saved scenes via server DB)"""
        import json

        def handler(message: Dict[str, Any]) -> None:
            op = message.get('op', '')
            if op.startswith('planning_scene_'):
                try:
                    self._handle_planning_scene_message(message)
                except Exception as e:
                    import traceback
                    print(f"[OLOJoint] Error handling {op}: {e}", flush=True)
                    print(traceback.format_exc(), flush=True)

        self._planning_scene_message_handler = handler
        self._register_ws_handler(handler)

    def _handle_planning_scene_message(self, message: Dict[str, Any]) -> None:
        """Handle planning scene operation responses"""
        op = message.get('op')
        request_id = message.get('request_id')

        entry = self._planning_scene_callbacks.get(request_id)
        if not entry:
            return

        future = entry.get('future')
        if not future or future.done():
            return

        loop = entry.get('loop') or self._planning_scene_loop
        if not loop:
            return

        response_ops = [
            'planning_scene_list_response',
            'planning_scene_get_response',
            'planning_scene_save_response',
            'planning_scene_update_response',
            'planning_scene_delete_response',
        ]

        if op in response_ops:
            if message.get('success'):
                loop.call_soon_threadsafe(future.set_result, message.get('result'))
            else:
                loop.call_soon_threadsafe(
                    future.set_exception,
                    Exception(message.get('error', 'Planning scene operation failed'))
                )
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]

        elif op == 'planning_scene_error_response':
            loop.call_soon_threadsafe(
                future.set_exception,
                Exception(message.get('error', 'Planning scene operation failed'))
            )
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]

    def _send_ws_message(self, message: Dict[str, Any]) -> None:
        """Send a WebSocket message"""
        import json

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        # Get protocol instance
        proto_instance = None
        if hasattr(self._ros, 'factory') and self._ros.factory:
            proto_instance = getattr(self._ros.factory, '_proto', None)

        if proto_instance:
            proto_instance.sendMessage(json.dumps(message).encode('utf-8'))
        else:
            raise ConnectionError("Cannot send message - protocol not connected")

    def _register_ws_handler(self, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Register a handler for WebSocket messages"""
        from . import _custom_message_handlers

        def wrapped_handler(msg):
            if isinstance(msg, dict):
                handler(msg)

        _custom_message_handlers.append(wrapped_handler)

    async def list_planning_scenes(
        self,
        options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Get list of saved planning scenes for the current user.

        Args:
            options: Optional dict with:
                - limit: Maximum scenes to return (default: 50)
                - offset: Pagination offset (default: 0)
                - search: Search term to filter by name/description

        Returns:
            Dict with scenes list and pagination info
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        if options is None:
            options = {}

        request_id = f"list_scenes_{int(time.time() * 1000)}_{id(options) % 10000}"

        if not self._planning_scene_message_handler:
            self._setup_planning_scene_message_handler()

        loop = asyncio.get_event_loop()
        self._planning_scene_loop = loop
        future = loop.create_future()

        self._planning_scene_callbacks[request_id] = {'future': future, 'loop': loop}

        list_message = {
            'op': 'planning_scene_list',
            'request_id': request_id,
            'limit': options.get('limit', 50),
            'offset': options.get('offset', 0),
            'search': options.get('search')
        }

        self._send_ws_message(list_message)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]
            raise TimeoutError("Planning scene list request timed out")

    async def get_planning_scene(
        self,
        scene_id: int,
        include_data: bool = False
    ) -> Dict[str, Any]:
        """
        Get a specific planning scene by ID.

        Args:
            scene_id: Scene ID
            include_data: Whether to include scene data (default: False)

        Returns:
            Scene information (includes scene_data when include_data is True)
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"get_scene_{int(time.time() * 1000)}_{scene_id}"

        if not self._planning_scene_message_handler:
            self._setup_planning_scene_message_handler()

        loop = asyncio.get_event_loop()
        self._planning_scene_loop = loop
        future = loop.create_future()

        self._planning_scene_callbacks[request_id] = {'future': future, 'loop': loop}

        get_message = {
            'op': 'planning_scene_get',
            'request_id': request_id,
            'sceneId': scene_id,
            'includeData': include_data
        }

        self._send_ws_message(get_message)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]
            raise TimeoutError(f"Get planning scene request timed out for scene ID: {scene_id}")

    async def save_planning_scene(
        self,
        name: str,
        scene_data: str,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Save a new planning scene.

        Args:
            name: Scene name (required)
            scene_data: JSON string of serialized obstacles (required)
            description: Scene description (optional)
            metadata: Scene metadata, e.g. { obstacleCount, types } (optional)

        Returns:
            Saved scene information
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        if not name or not scene_data:
            raise ValueError("Name and scene_data are required")

        request_id = f"save_scene_{int(time.time() * 1000)}_{id(name) % 10000}"

        if not self._planning_scene_message_handler:
            self._setup_planning_scene_message_handler()

        loop = asyncio.get_event_loop()
        self._planning_scene_loop = loop
        future = loop.create_future()

        self._planning_scene_callbacks[request_id] = {'future': future, 'loop': loop}

        save_message = {
            'op': 'planning_scene_save',
            'request_id': request_id,
            'name': name,
            'description': description,
            'sceneData': scene_data,
            'metadata': metadata
        }

        self._send_ws_message(save_message)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]
            raise TimeoutError("Save planning scene request timed out")

    async def update_planning_scene(
        self,
        scene_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
        scene_data: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Update an existing planning scene.

        Args:
            scene_id: Scene ID to update
            name: New name (optional)
            description: New description (optional)
            scene_data: New scene data JSON string (optional)
            metadata: New metadata (optional)

        Returns:
            Updated scene information
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"update_scene_{int(time.time() * 1000)}_{scene_id}"

        if not self._planning_scene_message_handler:
            self._setup_planning_scene_message_handler()

        loop = asyncio.get_event_loop()
        self._planning_scene_loop = loop
        future = loop.create_future()

        self._planning_scene_callbacks[request_id] = {'future': future, 'loop': loop}

        update_message = {
            'op': 'planning_scene_update',
            'request_id': request_id,
            'sceneId': scene_id
        }
        if name is not None:
            update_message['name'] = name
        if description is not None:
            update_message['description'] = description
        if scene_data is not None:
            update_message['sceneData'] = scene_data
        if metadata is not None:
            update_message['metadata'] = metadata

        self._send_ws_message(update_message)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]
            raise TimeoutError(f"Update planning scene request timed out for scene ID: {scene_id}")

    async def delete_planning_scene(self, scene_id: int) -> Dict[str, Any]:
        """
        Delete a planning scene.

        Args:
            scene_id: Scene ID to delete

        Returns:
            Deletion result
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"delete_scene_{int(time.time() * 1000)}_{scene_id}"

        if not self._planning_scene_message_handler:
            self._setup_planning_scene_message_handler()

        loop = asyncio.get_event_loop()
        self._planning_scene_loop = loop
        future = loop.create_future()

        self._planning_scene_callbacks[request_id] = {'future': future, 'loop': loop}

        delete_message = {
            'op': 'planning_scene_delete',
            'request_id': request_id,
            'sceneId': scene_id
        }

        self._send_ws_message(delete_message)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._planning_scene_callbacks:
                del self._planning_scene_callbacks[request_id]
            raise TimeoutError(f"Delete planning scene request timed out for scene ID: {scene_id}")

    # ===========================================
    # LIVE MOVEIT COLLISION OBJECTS
    # ===========================================

    def _setup_collision_object_message_handler(self) -> None:
        """Set up message handler for live MoveIt collision object operations"""

        def handler(message: Dict[str, Any]) -> None:
            op = message.get('op', '')
            if op in ('apply_collision_objects_result', 'get_planning_scene_result'):
                try:
                    self._handle_collision_object_message(message)
                except Exception as e:
                    import traceback
                    print(f"[OLOJoint] Error handling {op}: {e}", flush=True)
                    print(traceback.format_exc(), flush=True)

        self._collision_object_message_handler = handler
        self._register_ws_handler(handler)

    def _handle_collision_object_message(self, message: Dict[str, Any]) -> None:
        """Handle collision object operation responses"""
        op = message.get('op')
        request_id = message.get('request_id')

        entry = self._collision_object_callbacks.get(request_id)
        if not entry:
            return  # Might be handled by another component

        future = entry.get('future')
        if not future or future.done():
            return

        loop = entry.get('loop') or self._collision_object_loop
        if not loop:
            return

        if op == 'apply_collision_objects_result':
            if message.get('success'):
                loop.call_soon_threadsafe(future.set_result, {
                    'success': True,
                    'processed_ids': message.get('processed_ids')
                })
            else:
                loop.call_soon_threadsafe(
                    future.set_exception,
                    Exception(message.get('error', 'Collision object operation failed'))
                )
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]

        elif op == 'get_planning_scene_result':
            if message.get('success'):
                loop.call_soon_threadsafe(future.set_result, {
                    'success': True,
                    'collision_objects': message.get('collision_objects', [])
                })
            else:
                loop.call_soon_threadsafe(
                    future.set_exception,
                    Exception(message.get('error', 'Failed to get planning scene'))
                )
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]

    async def add_collision_objects(
        self,
        collision_objects: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Add collision objects to MoveIt's live planning scene.
        Objects are defined in ROS Z-up coordinates.

        Args:
            collision_objects: List of collision objects, each with:
                - id (str): Unique object ID
                - type (str): 'box', 'cylinder', 'sphere', or 'mesh'
                - position (dict): { x, y, z } in ROS Z-up coordinates
                - rotation (dict): Quaternion { x, y, z, w }
                - dimensions (dict): Depends on type:
                    - box: { width, height, depth }
                    - cylinder: { radius, height }
                    - sphere: { radius }
                - frame_id (str): Reference frame (default: 'world')
                - mesh_vertices (list): For mesh type, flat array [x,y,z,...]
                - mesh_triangles (list): For mesh type, flat array of indices

        Returns:
            Dict with { success, processed_ids }
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"add_collision_{int(time.time() * 1000)}_{len(collision_objects)}"

        if not self._collision_object_message_handler:
            self._setup_collision_object_message_handler()

        loop = asyncio.get_event_loop()
        self._collision_object_loop = loop
        future = loop.create_future()

        self._collision_object_callbacks[request_id] = {'future': future, 'loop': loop}

        objects = []
        for obj in collision_objects:
            co = dict(obj)
            co['operation'] = 0  # ADD
            co.setdefault('frame_id', 'world')
            objects.append(co)

        request = {
            'op': 'apply_collision_objects',
            'request_id': request_id,
            'collision_objects': objects
        }

        self._send_ws_message(request)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]
            raise TimeoutError("Add collision objects request timed out")

    async def remove_collision_objects(
        self,
        object_ids: List[str]
    ) -> Dict[str, Any]:
        """
        Remove collision objects from MoveIt's live planning scene.

        Args:
            object_ids: List of object IDs to remove

        Returns:
            Dict with { success, processed_ids }
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"remove_collision_{int(time.time() * 1000)}_{len(object_ids)}"

        if not self._collision_object_message_handler:
            self._setup_collision_object_message_handler()

        loop = asyncio.get_event_loop()
        self._collision_object_loop = loop
        future = loop.create_future()

        self._collision_object_callbacks[request_id] = {'future': future, 'loop': loop}

        objects = [{'id': oid, 'operation': 1} for oid in object_ids]  # REMOVE

        request = {
            'op': 'apply_collision_objects',
            'request_id': request_id,
            'collision_objects': objects
        }

        self._send_ws_message(request)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]
            raise TimeoutError("Remove collision objects request timed out")

    async def move_collision_objects(
        self,
        collision_objects: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Move (reposition) collision objects in MoveIt's live planning scene.
        Only updates position/rotation without re-sending geometry data.

        Args:
            collision_objects: List of objects to move, each with:
                - id (str): Object ID (must already exist in scene)
                - position (dict): New position { x, y, z } in ROS Z-up coordinates
                - rotation (dict): New quaternion { x, y, z, w }
                - frame_id (str): Reference frame (default: 'world')

        Returns:
            Dict with { success, processed_ids }
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"move_collision_{int(time.time() * 1000)}_{len(collision_objects)}"

        if not self._collision_object_message_handler:
            self._setup_collision_object_message_handler()

        loop = asyncio.get_event_loop()
        self._collision_object_loop = loop
        future = loop.create_future()

        self._collision_object_callbacks[request_id] = {'future': future, 'loop': loop}

        objects = [{
            'id': obj['id'],
            'position': obj.get('position'),
            'rotation': obj.get('rotation'),
            'frame_id': obj.get('frame_id', 'world'),
            'operation': 3  # MOVE
        } for obj in collision_objects]

        request = {
            'op': 'apply_collision_objects',
            'request_id': request_id,
            'collision_objects': objects
        }

        self._send_ws_message(request)

        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]
            raise TimeoutError("Move collision objects request timed out")

    async def get_collision_objects(self) -> Dict[str, Any]:
        """
        Get current collision objects from MoveIt's live planning scene.

        Returns:
            Dict with { success, collision_objects }
        """
        import time

        if not self._ros.is_connected:
            raise ConnectionError("Not connected to robot")

        request_id = f"get_collision_{int(time.time() * 1000)}"

        if not self._collision_object_message_handler:
            self._setup_collision_object_message_handler()

        loop = asyncio.get_event_loop()
        self._collision_object_loop = loop
        future = loop.create_future()

        self._collision_object_callbacks[request_id] = {'future': future, 'loop': loop}

        request = {
            'op': 'get_planning_scene',
            'request_id': request_id
        }

        self._send_ws_message(request)

        try:
            return await asyncio.wait_for(future, timeout=15.0)
        except asyncio.TimeoutError:
            if request_id in self._collision_object_callbacks:
                del self._collision_object_callbacks[request_id]
            raise TimeoutError("Get collision objects request timed out")

    def cleanup(self):
        """Clean up joint control resources"""
        self._cached_joint_states = None
        self._joint_state_subscription = None
        self._planning_scene_callbacks.clear()
        self._collision_object_callbacks.clear()

