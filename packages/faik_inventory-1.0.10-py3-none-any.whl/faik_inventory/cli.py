import argparse
import atexit
import os
import pwd
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import uvicorn


def _print_managed_neo4j_setup_and_exit(reason: str) -> None:
    print("Managed Neo4j prerequisites are missing or invalid.", file=sys.stderr)
    print(f"Reason: {reason}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Install steps for a Debian-based Python image:", file=sys.stderr)
    print("1. Install OS dependencies:", file=sys.stderr)
    print("   apt-get update", file=sys.stderr)
    print("   apt-get install -y curl ca-certificates gnupg procps", file=sys.stderr)
    print("2. Add Neo4j apt repository:", file=sys.stderr)
    print(
        "   curl -fsSL https://debian.neo4j.com/neotechnology.gpg.key | "
        "gpg --dearmor -o /usr/share/keyrings/neo4j.gpg",
        file=sys.stderr,
    )
    print(
        "   echo 'deb [signed-by=/usr/share/keyrings/neo4j.gpg] "
        "https://debian.neo4j.com stable latest' "
        "> /etc/apt/sources.list.d/neo4j.list",
        file=sys.stderr,
    )
    print("3. Install Neo4j:", file=sys.stderr)
    print("   apt-get update", file=sys.stderr)
    print("   apt-get install -y neo4j", file=sys.stderr)
    print("4. Verify Neo4j command is available:", file=sys.stderr)
    print("   neo4j --version", file=sys.stderr)
    print("5. Run the app again:", file=sys.stderr)
    print("   faik-inventory --managed-neo4j --host 0.0.0.0 --port 8000", file=sys.stderr)
    raise SystemExit(1)


def _default_managed_dir() -> Path:
    # Debian Neo4j packages often switch to the `neo4j` user when started as root.
    # /root is not readable by that user, so prefer /tmp in root-run containers.
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return Path("/tmp") / "faik-inventory"
    return Path.home() / ".local" / "share" / "faik-inventory"


def _resolve_neo4j_home(explicit_home: str | None) -> Path:
    if explicit_home:
        home = Path(explicit_home).expanduser().resolve()
    elif os.getenv("NEO4J_HOME"):
        home = Path(os.environ["NEO4J_HOME"]).expanduser().resolve()
    else:
        neo4j_bin = shutil.which("neo4j")
        if not neo4j_bin:
            raise RuntimeError(
                "Could not find Neo4j. Set --managed-neo4j-home or NEO4J_HOME, or install `neo4j` in PATH."
            )
        home = Path(neo4j_bin).resolve().parent.parent

    if not (home / "bin" / "neo4j").exists():
        neo4j_bin = shutil.which("neo4j")
        if neo4j_bin:
            return Path(neo4j_bin).resolve().parent.parent
        raise RuntimeError(f"Invalid Neo4j home: {home} (missing bin/neo4j)")
    return home


def _write_managed_neo4j_conf(
    conf_dir: Path,
    runtime_dir: Path,
    bolt_port: int,
    http_port: int,
) -> None:
    conf_dir.mkdir(parents=True, exist_ok=True)
    (runtime_dir / "data").mkdir(parents=True, exist_ok=True)
    (runtime_dir / "logs").mkdir(parents=True, exist_ok=True)
    (runtime_dir / "plugins").mkdir(parents=True, exist_ok=True)
    (runtime_dir / "import").mkdir(parents=True, exist_ok=True)
    (runtime_dir / "run").mkdir(parents=True, exist_ok=True)

    conf_text = f"""
server.default_listen_address=127.0.0.1
server.bolt.listen_address=127.0.0.1:{bolt_port}
server.http.listen_address=127.0.0.1:{http_port}
server.https.enabled=false
dbms.security.auth_enabled=false
server.directories.data={runtime_dir / "data"}
server.directories.logs={runtime_dir / "logs"}
server.directories.plugins={runtime_dir / "plugins"}
server.directories.import={runtime_dir / "import"}
server.directories.run={runtime_dir / "run"}
""".strip()
    (conf_dir / "neo4j.conf").write_text(conf_text + "\n", encoding="utf-8")


def _wait_for_port(host: str, port: int, timeout_seconds: int) -> None:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1.0)
            if sock.connect_ex((host, port)) == 0:
                return
        time.sleep(0.5)
    raise RuntimeError(f"Timed out waiting for Neo4j on {host}:{port}")


def _start_managed_neo4j(neo4j_home: Path, runtime_dir: Path, bolt_port: int, http_port: int) -> subprocess.Popen:
    conf_dir = runtime_dir / "conf"
    _write_managed_neo4j_conf(conf_dir, runtime_dir, bolt_port, http_port)

    env = os.environ.copy()
    env["NEO4J_HOME"] = str(neo4j_home)
    env["NEO4J_CONF"] = str(conf_dir)
    preexec_fn = None

    # In root containers, run managed Neo4j as the `neo4j` OS user when present.
    # This avoids permission mismatches from distro wrappers that switch users.
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        try:
            neo4j_user = pwd.getpwnam("neo4j")
            for path in [runtime_dir, runtime_dir / "data", runtime_dir / "logs", runtime_dir / "plugins", runtime_dir / "import", runtime_dir / "run", conf_dir]:
                path.mkdir(parents=True, exist_ok=True)
                os.chown(path, neo4j_user.pw_uid, neo4j_user.pw_gid)
            env["HOME"] = neo4j_user.pw_dir

            def _demote() -> None:
                os.setgid(neo4j_user.pw_gid)
                os.setuid(neo4j_user.pw_uid)

            preexec_fn = _demote
        except KeyError:
            pass

    proc = subprocess.Popen(
        [str(neo4j_home / "bin" / "neo4j"), "console"],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
        preexec_fn=preexec_fn,
    )

    try:
        _wait_for_port("127.0.0.1", bolt_port, timeout_seconds=45)
    except Exception:
        proc.terminate()
        raise
    return proc


def _install_cleanup(proc: subprocess.Popen) -> None:
    def cleanup() -> None:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()

    atexit.register(cleanup)

    def _signal_handler(signum: int, frame: object) -> None:
        cleanup()
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the faik-inventory FastAPI server")
    parser.add_argument("--host", default=os.getenv("FAIK_INVENTORY_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("FAIK_INVENTORY_PORT", "8000")))
    parser.add_argument("--reload", action="store_true", default=False)
    parser.add_argument("--managed-neo4j", action="store_true", help="Start and manage a local Neo4j process.")
    parser.add_argument("--managed-neo4j-home", default=os.getenv("NEO4J_HOME", ""), help="Path to Neo4j installation.")
    parser.add_argument(
        "--managed-neo4j-dir",
        default=os.getenv("FAIK_INVENTORY_MANAGED_DIR", str(_default_managed_dir())),
        help="Directory to store managed Neo4j runtime files and database.",
    )
    parser.add_argument(
        "--managed-neo4j-bolt-port",
        type=int,
        default=int(os.getenv("FAIK_INVENTORY_MANAGED_BOLT_PORT", "7687")),
    )
    parser.add_argument(
        "--managed-neo4j-http-port",
        type=int,
        default=int(os.getenv("FAIK_INVENTORY_MANAGED_HTTP_PORT", "7474")),
    )
    args = parser.parse_args()

    if args.managed_neo4j:
        try:
            neo4j_home = _resolve_neo4j_home(args.managed_neo4j_home or None)
        except Exception as exc:
            _print_managed_neo4j_setup_and_exit(str(exc))
        runtime_dir = Path(args.managed_neo4j_dir).expanduser().resolve() / "neo4j"
        runtime_dir.mkdir(parents=True, exist_ok=True)

        try:
            proc = _start_managed_neo4j(
                neo4j_home=neo4j_home,
                runtime_dir=runtime_dir,
                bolt_port=args.managed_neo4j_bolt_port,
                http_port=args.managed_neo4j_http_port,
            )
        except Exception as exc:
            _print_managed_neo4j_setup_and_exit(str(exc))
        _install_cleanup(proc)

        # app.py reads these env vars on import through uvicorn.
        os.environ["NEO4J_URI"] = f"bolt://127.0.0.1:{args.managed_neo4j_bolt_port}"
        os.environ.setdefault("NEO4J_USER", os.getenv("FAIK_INVENTORY_MANAGED_NEO4J_USER", "neo4j"))
        os.environ.setdefault("NEO4J_PASSWORD", os.getenv("FAIK_INVENTORY_MANAGED_NEO4J_PASSWORD", "neo4j"))
        os.environ.setdefault("NEO4J_DATABASE", "neo4j")

        print(f"Managed Neo4j started from {neo4j_home}", file=sys.stderr)
        print(f"Managed Neo4j data dir: {runtime_dir / 'data'}", file=sys.stderr)

    uvicorn.run("app:app", host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
