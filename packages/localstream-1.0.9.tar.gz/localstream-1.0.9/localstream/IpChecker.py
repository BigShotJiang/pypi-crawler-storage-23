import json
import socket
import ssl
import subprocess
from urllib import request

from localstream.Config import load_config

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"
WHITE = "\033[97m"
RESET = "\033[0m"


def _fetch_json_direct(timeout=6.0):
    with request.urlopen("https://ipapi.co/json/", timeout=timeout) as resp:
        data = resp.read().decode("utf-8", errors="replace")
        return json.loads(data)


def _recv_exact(sock, length):
    data = b""
    while len(data) < length:
        chunk = sock.recv(length - len(data))
        if not chunk:
            raise RuntimeError("Connection closed")
        data += chunk
    return data


def _socks5_connect(socks_host, socks_port, target_host, target_port, timeout=6.0):
    sock = socket.create_connection((socks_host, socks_port), timeout=timeout)
    sock.settimeout(timeout)

    sock.sendall(b"\x05\x01\x00")
    hello = _recv_exact(sock, 2)
    if hello[0] != 0x05 or hello[1] == 0xFF:
        sock.close()
        raise RuntimeError("SOCKS5 authentication failed")

    host_bytes = target_host.encode("idna")
    req = b"\x05\x01\x00\x03" + bytes([len(host_bytes)]) + host_bytes + target_port.to_bytes(2, "big")
    sock.sendall(req)

    head = _recv_exact(sock, 4)
    if head[1] != 0x00:
        sock.close()
        raise RuntimeError("SOCKS5 connect failed")

    atyp = head[3]
    if atyp == 0x01:
        _recv_exact(sock, 4)
    elif atyp == 0x03:
        ln = _recv_exact(sock, 1)[0]
        _recv_exact(sock, ln)
    elif atyp == 0x04:
        _recv_exact(sock, 16)
    _recv_exact(sock, 2)
    return sock


def _fetch_json_via_socks(socks_host, socks_port, timeout=6.0):
    raw = _socks5_connect(socks_host, socks_port, "ipapi.co", 443, timeout=timeout)
    tls = ssl.create_default_context().wrap_socket(raw, server_hostname="ipapi.co")
    try:
        req = (
            "GET /json/ HTTP/1.1\r\n"
            "Host: ipapi.co\r\n"
            "User-Agent: LocalStream/1.0.9\r\n"
            "Connection: close\r\n\r\n"
        ).encode("utf-8")
        tls.sendall(req)
        chunks = []
        while True:
            chunk = tls.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)
        raw_resp = b"".join(chunks)
    finally:
        try:
            tls.close()
        except Exception:
            pass

    body = raw_resp.split(b"\r\n\r\n", 1)[1] if b"\r\n\r\n" in raw_resp else raw_resp
    return json.loads(body.decode("utf-8", errors="replace"))


def _extract_geo(data):
    ip = str(data.get("ip", "")).strip()
    country = str(data.get("country_name") or data.get("country") or "").strip()
    country_code = str(data.get("country_code") or "").strip()
    return ip, country, country_code


def _has_loopback_dns(dns_servers):
    for dns in dns_servers:
        d = dns.strip()
        if d.startswith("127.") or d == "::1":
            return True
    return False


def _get_system_dns_servers():
    servers = []
    try:
        if socket.gethostname():
            pass
    except Exception:
        pass

    try:
        import os
        if os.name == "nt":
            output = subprocess.check_output(["ipconfig", "/all"], stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="ignore")
            lines = output.splitlines()
            i = 0
            while i < len(lines):
                line = lines[i]
                if "DNS Servers" in line:
                    parts = line.split(":", 1)
                    if len(parts) == 2:
                        first = parts[1].strip()
                        if first:
                            servers.append(first)
                    i += 1
                    while i < len(lines):
                        nxt = lines[i]
                        if ":" in nxt and not nxt.startswith(" " * 20):
                            break
                        val = nxt.strip()
                        if val and ":" not in val:
                            servers.append(val)
                        i += 1
                    continue
                i += 1
        else:
            with open("/etc/resolv.conf", "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    ln = line.strip()
                    if ln.startswith("nameserver "):
                        parts = ln.split()
                        if len(parts) >= 2:
                            servers.append(parts[1].strip())
    except Exception:
        pass

    uniq = []
    seen = set()
    for s in servers:
        if s and s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq


def _is_local_proxy_active(port, timeout=0.8):
    try:
        with socket.create_connection(("127.0.0.1", int(port)), timeout=timeout):
            return True
    except Exception:
        return False


def check_ip_status():
    config = load_config()
    local_port = int(config.get("local_port", 5201))
    profile_dns = str(config.get("server_ip", "")).strip()

    direct_data = {}
    proxy_data = {}

    try:
        direct_data = _fetch_json_direct()
    except Exception:
        direct_data = {}

    local_proxy_active = _is_local_proxy_active(local_port)
    if local_proxy_active:
        try:
            proxy_data = _fetch_json_via_socks("127.0.0.1", local_port)
        except Exception:
            proxy_data = {}

    direct_ip, direct_country, direct_cc = _extract_geo(direct_data)
    proxy_ip, proxy_country, proxy_cc = _extract_geo(proxy_data)

    effective_ip = proxy_ip or direct_ip
    effective_country = proxy_country or direct_country
    effective_cc = proxy_cc or direct_cc

    if local_proxy_active and proxy_ip and direct_ip:
        ip_leak = proxy_ip == direct_ip
    elif local_proxy_active and proxy_ip and not direct_ip:
        ip_leak = False
    else:
        ip_leak = True

    dns_servers = _get_system_dns_servers()
    has_loopback_dns = _has_loopback_dns(dns_servers)
    dns_matches_profile = bool(profile_dns and profile_dns in dns_servers)
    dns_secure = has_loopback_dns or dns_matches_profile
    dns_leak = not dns_secure

    return {
        "ip": effective_ip,
        "country": effective_country,
        "country_code": effective_cc,
        "ip_leak": ip_leak,
        "dns_leak": dns_leak,
        "local_proxy_active": local_proxy_active,
        "direct_ip": direct_ip,
        "proxy_ip": proxy_ip,
        "dns_servers": dns_servers,
        "profile_dns": profile_dns,
    }


def run_ip_checker():
    print(f"\n{CYAN}========================================{RESET}")
    print(f"{CYAN} IP Checker{RESET}")
    print(f"{CYAN}========================================{RESET}\n")

    result = check_ip_status()

    ip = result.get("ip", "")
    country = result.get("country", "")
    country_code = result.get("country_code", "")
    ip_leak = bool(result.get("ip_leak", True))
    dns_leak = bool(result.get("dns_leak", True))
    local_proxy_active = bool(result.get("local_proxy_active", False))
    direct_ip = result.get("direct_ip", "")
    proxy_ip = result.get("proxy_ip", "")
    dns_servers = result.get("dns_servers", [])
    profile_dns = result.get("profile_dns", "")

    ip_leak_text = f"{RED}DETECTED{RESET}" if ip_leak else f"{GREEN}NOT DETECTED{RESET}"
    dns_leak_text = f"{RED}DETECTED{RESET}" if dns_leak else f"{GREEN}NOT DETECTED{RESET}"
    proxy_text = f"{GREEN}ACTIVE{RESET}" if local_proxy_active else f"{YELLOW}INACTIVE{RESET}"

    print(f"  {GREEN}IP{RESET}          : {WHITE}{ip or '-'}{RESET}")
    print(f"  {GREEN}Country{RESET}     : {WHITE}{country or '-'}{RESET} {DIM}{country_code}{RESET}")
    print(f"  {GREEN}Proxy Port{RESET}  : {proxy_text}")
    print(f"  {GREEN}IP Leak{RESET}     : {ip_leak_text}")
    print(f"  {GREEN}DNS Leak{RESET}    : {dns_leak_text}")
    print(f"  {DIM}Direct IP{RESET}   : {direct_ip or '-'}")
    print(f"  {DIM}Proxy IP{RESET}    : {proxy_ip or '-'}")
    print(f"  {DIM}Profile DNS{RESET} : {profile_dns or '-'}")
    print(f"  {DIM}System DNS{RESET}  : {', '.join(dns_servers) if dns_servers else '-'}")

    return result
