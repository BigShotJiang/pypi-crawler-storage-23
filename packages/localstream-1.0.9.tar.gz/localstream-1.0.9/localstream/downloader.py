import os
import sys
import platform
import subprocess
import shutil
import requests
import zipfile
import tarfile
import tempfile
from pathlib import Path

from localstream.Config import get_config_dir


CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
WHITE = "\033[97m"
DIM = "\033[2m"
RESET = "\033[0m"


def _configure_output_streams():
    for stream in (sys.stdout, sys.stderr):
        if stream and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(errors="replace")
            except Exception:
                pass


_configure_output_streams()


_direct_session = requests.Session()
_direct_session.trust_env = False


def _http_get(url: str, stream: bool = False, timeout: int = 120, headers: dict | None = None, allow_redirects: bool = True):
    try:
        return requests.get(url, stream=stream, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
    except requests.exceptions.RequestException:
        return _direct_session.get(url, stream=stream, timeout=timeout, headers=headers, allow_redirects=allow_redirects)


SLIPSTREAM_WINDOWS_URL = "https://github.com/AliRezaBeigy/slipstream-rust-deploy/releases/latest/download/slipstream-client-windows-amd64.exe"
SLIPSTREAM_LINUX_URL = "https://github.com/AliRezaBeigy/slipstream-rust-deploy/releases/latest/download/slipstream-client-linux-amd64"

TUN2PROXY_WINDOWS_URL = "https://github.com/tun2proxy/tun2proxy/releases/download/v0.7.19/tun2proxy-x86_64-pc-windows-msvc.zip"
TUN2PROXY_LINUX_URL = "https://github.com/tun2proxy/tun2proxy/releases/download/v0.7.19/tun2proxy-x86_64-unknown-linux-gnu.zip"

DNSTT_WINDOWS_URL = "https://dnstt.network/dnstt-client-windows-amd64.exe"
DNSTT_LINUX_URL = "https://dnstt.network/dnstt-client-linux-amd64"

WINTUN_URL = "https://www.wintun.net/builds/wintun-0.14.1.zip"

PRIVOXY_WINDOWS_URL = "https://github.com/ssrlive/privoxy/releases/latest/download/privoxy-windows-x64.zip"

PINGTUNNEL_WINDOWS_URL = "https://github.com/esrrhs/pingtunnel/releases/latest/download/pingtunnel_windows_amd64.zip"
PINGTUNNEL_LINUX_URL = "https://github.com/esrrhs/pingtunnel/releases/latest/download/pingtunnel_linux_amd64.zip"

DNSPROXY_WINDOWS_URLS = [
    "https://github.com/AdguardTeam/dnsproxy/releases/latest/download/dnsproxy-windows-amd64.exe",
    "https://github.com/AdguardTeam/dnsproxy/releases/latest/download/dnsproxy-windows-amd64-v0.76.1.zip",
]
DNSPROXY_LINUX_URLS = [
    "https://github.com/AdguardTeam/dnsproxy/releases/latest/download/dnsproxy-linux-amd64",
    "https://github.com/AdguardTeam/dnsproxy/releases/latest/download/dnsproxy-linux-amd64-v0.76.1.tar.gz",
]
SINGBOX_RELEASE_API = "https://api.github.com/repos/SagerNet/sing-box/releases/latest"


def get_platform() -> str:
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "linux":
        return "linux"
    return "unsupported"


def is_windows() -> bool:
    return get_platform() == "windows"


def is_linux() -> bool:
    return get_platform() == "linux"


def get_bin_dir() -> Path:
    primary = get_config_dir() / "bin"
    try:
        primary.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    if _dir_is_writable(primary):
        _seed_bundled_bins(primary)
        return primary

    for fallback in _get_fallback_bin_dirs():
        try:
            fallback.mkdir(parents=True, exist_ok=True)
        except Exception:
            continue
        if _dir_is_writable(fallback):
            _seed_bundled_bins(fallback)
            return fallback

    raise PermissionError("No writable bin directory found for LocalStream")


def _dir_is_writable(path: Path) -> bool:
    try:
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
        probe = path / ".localstream_write_test"
        with open(probe, "wb") as f:
            f.write(b"1")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _get_fallback_bin_dirs() -> list:
    candidates = []
    if is_windows():
        localapp = os.getenv("LOCALAPPDATA")
        if localapp:
            candidates.append(Path(localapp) / "LocalStream" / "bin")
    xdg = os.getenv("XDG_CACHE_HOME")
    if xdg:
        candidates.append(Path(xdg) / "localstream" / "bin")
    candidates.append(Path.home() / ".cache" / "localstream" / "bin")
    candidates.append(Path(tempfile.gettempdir()) / "localstream" / "bin")
    return candidates


def _get_bundled_bin_dir() -> Path | None:
    if not getattr(sys, "frozen", False):
        return None
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        p = Path(meipass) / "localstream" / "bin"
        if p.exists():
            return p
    exe_dir = Path(sys.executable).resolve().parent
    p = exe_dir / "localstream" / "bin"
    if p.exists():
        return p
    p = exe_dir / "bin"
    if p.exists():
        return p
    return None


def _seed_bundled_bins(bin_dir: Path) -> None:
    src_dir = _get_bundled_bin_dir()
    if not src_dir:
        return
    if is_windows():
        name_map = {
            "dnstt-client-windows-amd64.exe": "dnstt-client.exe",
            "slipstream-client-windows-amd64.exe": "slipstream-client.exe",
            "tun2proxy.exe": "tun2proxy.exe",
            "wintun.dll": "wintun.dll",
            "pingtunnel.exe": "pingtunnel.exe",
            "dnsproxy.exe": "dnsproxy.exe",
            "sing-box.exe": "sing-box.exe",
        }
    elif is_linux():
        name_map = {
            "dnstt-client-linux-amd64": "dnstt-client",
            "slipstream-client-linux-amd64": "slipstream-client",
            "tun2proxy": "tun2proxy",
            "pingtunnel": "pingtunnel",
            "dnsproxy": "dnsproxy",
            "sing-box": "sing-box",
        }
    else:
        name_map = {}
    try:
        for child in src_dir.iterdir():
            dst = bin_dir / name_map.get(child.name, child.name)
            if child.is_dir():
                shutil.copytree(child, dst, dirs_exist_ok=True)
                continue
            if dst.exists():
                continue
            shutil.copy2(child, dst)
    except Exception:
        pass


def get_client_path() -> Path:
    if is_windows():
        return get_bin_dir() / "slipstream-client.exe"
    return get_bin_dir() / "slipstream-client"


def get_tun2proxy_path() -> Path:
    if is_windows():
        return get_bin_dir() / "tun2proxy.exe"
    return get_bin_dir() / "tun2proxy"


def get_wintun_path() -> Path:
    return get_bin_dir() / "wintun.dll"


def get_dnstt_path() -> Path:
    if is_windows():
        return get_bin_dir() / "dnstt-client.exe"
    return get_bin_dir() / "dnstt-client"


def client_exists() -> bool:
    return get_client_path().exists()


def dnstt_exists() -> bool:
    return get_dnstt_path().exists()


def get_doh_proxy_path() -> Path:
    if is_windows():
        return get_bin_dir() / "dnsproxy.exe"
    return get_bin_dir() / "dnsproxy"


def doh_proxy_exists() -> bool:
    return get_doh_proxy_path().exists()


def get_pingtunnel_path() -> Path:
    if is_windows():
        return get_bin_dir() / "pingtunnel.exe"
    return get_bin_dir() / "pingtunnel"


def get_singbox_path() -> Path:
    if is_windows():
        return get_bin_dir() / "sing-box.exe"
    return get_bin_dir() / "sing-box"


def pingtunnel_exists() -> bool:
    return get_pingtunnel_path().exists()


def singbox_exists() -> bool:
    return get_singbox_path().exists()


def get_pingtunnel_quarantine_marker() -> Path:
    return get_bin_dir() / "pingtunnel.quarantined"


def pingtunnel_quarantine_flagged() -> bool:
    return get_pingtunnel_quarantine_marker().exists()


def set_pingtunnel_quarantine_flag(reason: str = ""):
    marker = get_pingtunnel_quarantine_marker()
    try:
        marker.write_text(reason, encoding="utf-8")
    except Exception:
        pass


def clear_pingtunnel_quarantine_flag():
    marker = get_pingtunnel_quarantine_marker()
    if marker.exists():
        try:
            marker.unlink()
        except Exception:
            pass


def print_pingtunnel_quarantine_help():
    bin_dir = get_bin_dir()
    print(f"\n{YELLOW}!{RESET} Ping Tunnel was removed by antivirus.")
    print(f"{YELLOW}!{RESET} Restore it from Windows Security > Protection history.")
    print(f"{YELLOW}!{RESET} Add this folder to exclusions:")
    print(f"{WHITE}  {bin_dir}{RESET}")
    print(f"{DIM}  Windows Security > Virus & threat protection > Manage settings > Exclusions{RESET}")


def tun2proxy_exists() -> bool:
    tun2proxy_path = get_tun2proxy_path()
    if is_windows():
        return tun2proxy_path.exists() and get_wintun_path().exists()
    return tun2proxy_path.exists()


def download_file(url: str, dest_path: Path, name: str) -> bool:
    print(f"\n{CYAN}â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—{RESET}")
    print(f"{CYAN}â•‘{RESET}  {YELLOW}âŸ³{RESET} Downloading {name}...{' ' * (37 - len(name))}{CYAN}â•‘{RESET}")
    print(f"{CYAN}â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•{RESET}")
    print(f"\n{DIM}  URL: {url[:50]}...{RESET}")
    print(f"{DIM}  Destination: {dest_path}{RESET}\n")
    
    try:
        response = _http_get(url, stream=True, timeout=120)
        response.raise_for_status()
        
        total_size = int(response.headers.get("content-length", 0))
        downloaded = 0
        
        with open(dest_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        bar_length = 40
                        filled = int(bar_length * downloaded / total_size)
                        bar = f"{GREEN}{'â–ˆ' * filled}{DIM}{'â–‘' * (bar_length - filled)}{RESET}"
                        size_mb = downloaded / (1024 * 1024)
                        total_mb = total_size / (1024 * 1024)
                        print(f"\r  {bar} {percent:5.1f}% ({size_mb:.1f}/{total_mb:.1f} MB)", end="", flush=True)
        
        print(f"\n\n{GREEN}âœ“{RESET} Download complete!")
        
        if is_linux() and not str(dest_path).endswith(".zip"):
            os.chmod(dest_path, 0o755)
        
        return True
        
    except Exception as e:
        print(f"\n\n{RED}âœ—{RESET} Download failed: {e}")
        if dest_path.exists():
            dest_path.unlink()
        return False


def download_client(force: bool = False) -> bool:
    client_path = get_client_path()
    
    if client_path.exists() and not force:
        return True
    
    if is_windows():
        url = SLIPSTREAM_WINDOWS_URL
    elif is_linux():
        url = SLIPSTREAM_LINUX_URL
    else:
        print(f"{RED}âœ—{RESET} Unsupported platform: {get_platform()}")
        return False
    
    return download_file(url, client_path, "slipstream-client")


def download_dnstt_client(force: bool = False) -> bool:
    dnstt_path = get_dnstt_path()
    
    if dnstt_path.exists() and not force:
        return True
    
    if is_windows():
        url = DNSTT_WINDOWS_URL
    elif is_linux():
        url = DNSTT_LINUX_URL
    else:
        print(f"{RED}âœ—{RESET} Unsupported platform: {get_platform()}")
        return False
    
    return download_file(url, dnstt_path, "dnstt-client")


def download_doh_proxy(force: bool = False) -> bool:
    doh_proxy_path = get_doh_proxy_path()

    if doh_proxy_path.exists() and not force:
        return True

    urls = DNSPROXY_WINDOWS_URLS if is_windows() else DNSPROXY_LINUX_URLS

    for url in urls:
        if url.endswith(".exe") or not url.endswith(".zip"):
            if download_file(url, doh_proxy_path, "dnsproxy"):
                if is_linux():
                    os.chmod(doh_proxy_path, 0o755)
                return True
        else:
            try:
                with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                    tmp_path = Path(tmp.name)

                response = _http_get(url, stream=True, timeout=120)
                response.raise_for_status()
                with open(tmp_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)

                with zipfile.ZipFile(tmp_path, "r") as zip_ref:
                    for file_info in zip_ref.namelist():
                        lower = file_info.lower()
                        if is_windows() and lower.endswith("dnsproxy.exe"):
                            with zip_ref.open(file_info) as src:
                                with open(doh_proxy_path, "wb") as dst:
                                    dst.write(src.read())
                            break
                        if is_linux() and (lower == "dnsproxy" or lower.endswith("/dnsproxy")):
                            with zip_ref.open(file_info) as src:
                                with open(doh_proxy_path, "wb") as dst:
                                    dst.write(src.read())
                            os.chmod(doh_proxy_path, 0o755)
                            break

                tmp_path.unlink()
                if doh_proxy_path.exists():
                    return True
            except Exception:
                if "tmp_path" in locals() and tmp_path.exists():
                    try:
                        tmp_path.unlink()
                    except Exception:
                        pass
                continue

    return False


def _normalize_arch() -> str:
    arch = platform.machine().lower()
    if arch in ["x86_64", "amd64"]:
        return "amd64"
    if arch in ["aarch64", "arm64"]:
        return "arm64"
    if arch in ["i386", "i686", "x86"]:
        return "386"
    return arch


def _get_latest_singbox_asset_url() -> str:
    arch = _normalize_arch()
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "LocalStream/1.0.9",
    }
    response = _http_get(SINGBOX_RELEASE_API, timeout=30, headers=headers)
    response.raise_for_status()
    payload = response.json()
    assets = payload.get("assets", [])

    if is_windows():
        preferred = [f"windows-{arch}.zip", "windows-amd64.zip", "windows-amd64v3.zip", "windows-amd64v2.zip"]
    else:
        preferred = [f"linux-{arch}.tar.gz", "linux-amd64.tar.gz", "linux-amd64v3.tar.gz", "linux-amd64v2.tar.gz"]

    for suffix in preferred:
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if name.endswith(suffix) and ".sha256" not in name and ".sig" not in name:
                return str(asset.get("browser_download_url", ""))

    if is_windows():
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if "windows" in name and arch in name and name.endswith(".zip") and ".sha256" not in name and ".sig" not in name:
                return str(asset.get("browser_download_url", ""))
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if "windows" in name and "amd64" in name and name.endswith(".zip") and ".sha256" not in name and ".sig" not in name:
                return str(asset.get("browser_download_url", ""))
    else:
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if "linux" in name and arch in name and name.endswith(".tar.gz") and ".sha256" not in name and ".sig" not in name:
                return str(asset.get("browser_download_url", ""))
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if "linux" in name and "amd64" in name and name.endswith(".tar.gz") and ".sha256" not in name and ".sig" not in name:
                return str(asset.get("browser_download_url", ""))

    return ""


def download_singbox(force: bool = False) -> bool:
    singbox_path = get_singbox_path()
    if singbox_path.exists() and not force:
        return True

    if not is_windows() and not is_linux():
        print(f"{RED}x{RESET} Unsupported platform: {get_platform()}")
        return False

    arch = _normalize_arch()

    if force and singbox_path.exists():
        try:
            singbox_path.unlink()
        except Exception:
            pass

    def _extract_singbox(archive_path: Path) -> bool:
        if is_windows():
            with zipfile.ZipFile(archive_path, "r") as zf:
                for item in zf.namelist():
                    lower = item.lower()
                    if lower.endswith("sing-box.exe"):
                        with zf.open(item) as src:
                            with open(singbox_path, "wb") as dst:
                                dst.write(src.read())
                        return True
            return False
        with tarfile.open(archive_path, "r:gz") as tf:
            for member in tf.getmembers():
                lower = member.name.lower()
                if lower.endswith("/sing-box") or lower == "sing-box":
                    src = tf.extractfile(member)
                    if src:
                        with open(singbox_path, "wb") as dst:
                            dst.write(src.read())
                        os.chmod(singbox_path, 0o755)
                        return True
        return False

    def _download_and_extract(url: str) -> tuple[bool, str]:
        tmp_path = None
        try:
            suffix = ".zip" if is_windows() else ".tar.gz"
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
                tmp_path = Path(tmp.name)

            response = _http_get(url, stream=True, timeout=180, allow_redirects=True)
            response.raise_for_status()
            with open(tmp_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)

            if not _extract_singbox(tmp_path):
                return False, "sing-box extraction failed"
            if not singbox_path.exists():
                return False, "sing-box binary missing after extraction"
            return True, ""
        except Exception as e:
            return False, str(e)
        finally:
            if tmp_path and tmp_path.exists():
                try:
                    tmp_path.unlink()
                except Exception:
                    pass

    print(f"\n{CYAN}Downloading sing-box for {get_platform()}/{arch}...{RESET}")

    candidate_urls = []
    try:
        api_url = _get_latest_singbox_asset_url()
        if api_url:
            candidate_urls.append(api_url)
    except Exception:
        pass

    latest_base = "https://github.com/SagerNet/sing-box/releases/latest/download"
    if is_windows():
        candidate_urls.extend([
            f"{latest_base}/sing-box-windows-{arch}.zip",
            f"{latest_base}/sing-box-windows-amd64.zip",
            f"{latest_base}/sing-box-windows-amd64v3.zip",
            f"{latest_base}/sing-box-windows-amd64v2.zip",
        ])
    else:
        candidate_urls.extend([
            f"{latest_base}/sing-box-linux-{arch}.tar.gz",
            f"{latest_base}/sing-box-linux-amd64.tar.gz",
            f"{latest_base}/sing-box-linux-amd64v3.tar.gz",
            f"{latest_base}/sing-box-linux-amd64v2.tar.gz",
        ])

    seen = set()
    ordered_urls = []
    for url in candidate_urls:
        if url and url not in seen:
            seen.add(url)
            ordered_urls.append(url)

    last_error = "unknown error"
    first_error = ""
    for url in ordered_urls:
        ok, err = _download_and_extract(url)
        if ok:
            print(f"{GREEN}OK{RESET} sing-box downloaded: {singbox_path}")
            return True
        current_error = err or "download failed"
        if not first_error:
            first_error = current_error
        lowered = current_error.lower()
        if "permission denied" in lowered or "access is denied" in lowered:
            print(f"{RED}x{RESET} Failed to write sing-box binary: {current_error}")
            return False
        if "404" not in lowered:
            last_error = current_error
        elif not last_error or "404" in last_error.lower():
            last_error = current_error

    if (not last_error or last_error == "unknown error") and first_error:
        last_error = first_error
    print(f"{RED}x{RESET} Failed to download sing-box: {last_error}")
    return False

def download_tun2proxy(force: bool = False) -> bool:
    tun2proxy_path = get_tun2proxy_path()
    bin_dir = get_bin_dir()
    
    if is_windows():
        wintun_path = get_wintun_path()
        if tun2proxy_path.exists() and wintun_path.exists() and not force:
            return True
    else:
        if tun2proxy_path.exists() and not force:
            return True
    
    if is_windows():
        url = TUN2PROXY_WINDOWS_URL
    elif is_linux():
        url = TUN2PROXY_LINUX_URL
    else:
        print(f"{RED}âœ—{RESET} Unsupported platform: {get_platform()}")
        return False
    
    if not tun2proxy_path.exists() or force:
        print(f"\n{CYAN}â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—{RESET}")
        print(f"{CYAN}â•‘{RESET}  {YELLOW}âŸ³{RESET} Downloading tun2proxy...                            {CYAN}â•‘{RESET}")
        print(f"{CYAN}â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•{RESET}")
        print(f"\n{DIM}  URL: {url[:50]}...{RESET}\n")
        
        try:
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                tmp_path = Path(tmp.name)
            
            response = _http_get(url, stream=True, timeout=120)
            response.raise_for_status()
            
            total_size = int(response.headers.get("content-length", 0))
            downloaded = 0
            
            with open(tmp_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            bar_length = 40
                            filled = int(bar_length * downloaded / total_size)
                            bar = f"{GREEN}{'â–ˆ' * filled}{DIM}{'â–‘' * (bar_length - filled)}{RESET}"
                            size_mb = downloaded / (1024 * 1024)
                            total_mb = total_size / (1024 * 1024)
                            print(f"\r  {bar} {percent:5.1f}% ({size_mb:.1f}/{total_mb:.1f} MB)", end="", flush=True)
            
            print(f"\n\n{YELLOW}âŸ³{RESET} Extracting tun2proxy...")
            
            with zipfile.ZipFile(tmp_path, 'r') as zip_ref:
                for file_info in zip_ref.namelist():
                    if is_windows():
                        if file_info.endswith("tun2proxy-bin.exe") or file_info.endswith("tun2proxy.exe"):
                            with zip_ref.open(file_info) as src:
                                with open(tun2proxy_path, "wb") as dst:
                                    dst.write(src.read())
                            break
                        elif file_info.endswith(".exe") and "tun2proxy" in file_info:
                            with zip_ref.open(file_info) as src:
                                with open(tun2proxy_path, "wb") as dst:
                                    dst.write(src.read())
                            break
                    else:
                        if "tun2proxy" in file_info and not file_info.endswith("/"):
                            with zip_ref.open(file_info) as src:
                                with open(tun2proxy_path, "wb") as dst:
                                    dst.write(src.read())
                            os.chmod(tun2proxy_path, 0o755)
                            break
            
            tmp_path.unlink()
            
            if not tun2proxy_path.exists():
                print(f"{RED}âœ—{RESET} Failed to extract tun2proxy from archive")
                return False
            
            print(f"{GREEN}âœ“{RESET} tun2proxy extracted!")
            
        except Exception as e:
            print(f"\n{RED}âœ—{RESET} Failed to download tun2proxy: {e}")
            return False
    
    if is_windows():
        wintun_path = get_wintun_path()
        if not wintun_path.exists() or force:
            print(f"\n{YELLOW}âŸ³{RESET} Downloading wintun driver...")
            
            try:
                with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                    tmp_path = Path(tmp.name)
                
                response = _http_get(WINTUN_URL, timeout=120)
                response.raise_for_status()
                
                with open(tmp_path, "wb") as f:
                    f.write(response.content)
                
                print(f"{YELLOW}âŸ³{RESET} Extracting wintun.dll...")
                
                with zipfile.ZipFile(tmp_path, 'r') as zip_ref:
                    for file_info in zip_ref.namelist():
                        if file_info.endswith("amd64/wintun.dll"):
                            with zip_ref.open(file_info) as src:
                                with open(wintun_path, "wb") as dst:
                                    dst.write(src.read())
                            break
                
                tmp_path.unlink()
                
                if not wintun_path.exists():
                    print(f"{RED}âœ—{RESET} Failed to extract wintun.dll from archive")
                    return False
                
                print(f"{GREEN}âœ“{RESET} Wintun driver extracted!")
                
            except Exception as e:
                print(f"{RED}âœ—{RESET} Failed to download wintun: {e}")
                return False
    
    return True


def get_privoxy_dir() -> Path:
    return get_bin_dir() / "privoxy"


def get_privoxy_exe() -> Path:
    if is_windows():
        return get_privoxy_dir() / "privoxy.exe"
    return Path("/usr/sbin/privoxy")


def privoxy_exists() -> bool:
    if is_linux():
        result = subprocess.run(["which", "privoxy"], capture_output=True)
        return result.returncode == 0
    return get_privoxy_exe().exists()


def download_pingtunnel(force: bool = False) -> bool:
    pingtunnel_path = get_pingtunnel_path()
    
    if pingtunnel_path.exists() and not force:
        clear_pingtunnel_quarantine_flag()
        return True
    
    if is_windows() and pingtunnel_quarantine_flagged() and not force:
        print_pingtunnel_quarantine_help()
    
    if is_windows():
        url = PINGTUNNEL_WINDOWS_URL
    elif is_linux():
        url = PINGTUNNEL_LINUX_URL
    else:
        print(f"{RED}âœ—{RESET} Unsupported platform: {get_platform()}")
        return False
    
    print(f"\n{CYAN}â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—{RESET}")
    print(f"{CYAN}â•‘{RESET}  {YELLOW}âŸ³{RESET} Downloading Ping Tunnel...                          {CYAN}â•‘{RESET}")
    print(f"{CYAN}â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•{RESET}")
    print(f"\n{DIM}  URL: {url[:50]}...{RESET}\n")
    
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp_path = Path(tmp.name)
        
        response = _http_get(url, stream=True, timeout=120)
        response.raise_for_status()
        
        total_size = int(response.headers.get("content-length", 0))
        downloaded = 0
        
        with open(tmp_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        bar_length = 40
                        filled = int(bar_length * downloaded / total_size)
                        bar = f"{GREEN}{'â–ˆ' * filled}{DIM}{'â–‘' * (bar_length - filled)}{RESET}"
                        size_mb = downloaded / (1024 * 1024)
                        total_mb = total_size / (1024 * 1024)
                        print(f"\r  {bar} {percent:5.1f}% ({size_mb:.1f}/{total_mb:.1f} MB)", end="", flush=True)
        
        print(f"\n\n{YELLOW}âŸ³{RESET} Extracting Ping Tunnel...")
        
        with zipfile.ZipFile(tmp_path, 'r') as zip_ref:
            for file_info in zip_ref.namelist():
                if is_windows():
                    if file_info.lower().endswith("pingtunnel.exe"):
                        with zip_ref.open(file_info) as src:
                            with open(pingtunnel_path, "wb") as dst:
                                dst.write(src.read())
                        break
                else:
                    if file_info.lower() == "pingtunnel" or file_info.lower().endswith("/pingtunnel"):
                        with zip_ref.open(file_info) as src:
                            with open(pingtunnel_path, "wb") as dst:
                                dst.write(src.read())
                        os.chmod(pingtunnel_path, 0o755)
                        break
        
        if tmp_path and tmp_path.exists():
            tmp_path.unlink()
        
        if not pingtunnel_path.exists():
            print(f"{RED}âœ—{RESET} Failed to extract Ping Tunnel from archive")
            if is_windows():
                set_pingtunnel_quarantine_flag("missing-after-extract")
                print_pingtunnel_quarantine_help()
            return False
        
        clear_pingtunnel_quarantine_flag()
        print(f"{GREEN}âœ“{RESET} Ping Tunnel extracted!")
        return True
        
    except Exception as e:
        if is_windows():
            if isinstance(e, PermissionError) or "Permission denied" in str(e) or "Access is denied" in str(e):
                set_pingtunnel_quarantine_flag(str(e))
                print_pingtunnel_quarantine_help()
        print(f"{RED}âœ—{RESET} Failed to download/extract Ping Tunnel: {e}")
        return False
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass


def download_privoxy(force: bool = False) -> bool:
    if is_linux():
        print(f"\n{CYAN}â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—{RESET}")
        print(f"{CYAN}â•‘{RESET}  {YELLOW}âŸ³{RESET} Installing Privoxy via apt...                       {CYAN}â•‘{RESET}")
        print(f"{CYAN}â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•{RESET}\n")
        
        try:
            result = subprocess.run(
                ["sudo", "apt", "install", "-y", "privoxy"],
                check=True
            )
            print(f"\n{GREEN}âœ“{RESET} Privoxy installed!")
            return True
        except subprocess.CalledProcessError as e:
            print(f"\n{RED}âœ—{RESET} Failed to install Privoxy: {e}")
            print(f"{YELLOW}!{RESET} Try manually: sudo apt install privoxy")
            return False
        except FileNotFoundError:
            print(f"\n{RED}âœ—{RESET} apt not found. Install privoxy manually.")
            return False
    
    privoxy_dir = get_privoxy_dir()
    privoxy_exe = get_privoxy_exe()
    
    if privoxy_exe.exists() and not force:
        return True
    
    print(f"\n{DIM}  URL: {PRIVOXY_WINDOWS_URL[:60]}...{RESET}")
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp_path = Path(tmp.name)
            
        print(f"  {DIM}Requesting...{RESET}")
        response = _http_get(PRIVOXY_WINDOWS_URL, headers=headers, stream=True, timeout=120, allow_redirects=True)
        response.raise_for_status()
        
        total_size = int(response.headers.get("content-length", 0))
        downloaded = 0
        
        with open(tmp_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        bar_length = 40
                        filled = int(bar_length * downloaded / total_size)
                        bar = f"{GREEN}{'â–ˆ' * filled}{DIM}{'â–‘' * (bar_length - filled)}{RESET}"
                        size_mb = downloaded / (1024 * 1024)
                        total_mb = total_size / (1024 * 1024)
                        print(f"\r  {bar} {percent:5.1f}% ({size_mb:.1f}/{total_mb:.1f} MB)", end="", flush=True)

        print(f"\n\n{YELLOW}âŸ³{RESET} Extracting Privoxy...")
        
        if privoxy_dir.exists():
            import shutil
            shutil.rmtree(privoxy_dir)
        privoxy_dir.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(tmp_path, 'r') as zip_ref:
            for file_info in zip_ref.namelist():
                if file_info.endswith(".exe") or file_info.endswith(".dll") or file_info.endswith(".conf") or file_info.endswith("config.txt"):
                    filename = os.path.basename(file_info)
                    if filename:
                        target = privoxy_dir / filename
                        with zip_ref.open(file_info) as src:
                            with open(target, "wb") as dst:
                                dst.write(src.read())

        tmp_path.unlink()
        
        if not privoxy_exe.exists():
            print(f"{RED}âœ—{RESET} Failed to extract privoxy.exe")
            return False
            
        print(f"{GREEN}âœ“{RESET} Privoxy installed!")
        return True
        
    except Exception as e:
        print(f"\n{RED}âœ—{RESET} Failed to download Privoxy: {e}")
        return False

