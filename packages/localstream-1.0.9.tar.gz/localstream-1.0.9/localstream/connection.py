import subprocess
import signal
import sys
import os
import json
import threading
import re
import time
import socket
import ipaddress
from pathlib import Path

if sys.platform == "win32":
    pass

from localstream.Downloader import get_client_path, get_tun2proxy_path, get_doh_proxy_path, get_singbox_path, client_exists, tun2proxy_exists, doh_proxy_exists, singbox_exists, download_client, download_tun2proxy, download_doh_proxy, download_singbox, privoxy_exists, download_privoxy, is_windows, is_linux
from localstream.SystemProxy import set_system_proxy, unset_system_proxy
from localstream.PrivoxyManager import start_privoxy, stop_privoxy
from localstream.Fragmenter import TlsFragmenter
from localstream.SingBox import is_singbox_tunnel, build_singbox_config, extract_link_server


CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
WHITE = "\033[97m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


LOG_PATTERNS = {
    r"INFO.*Listening on TCP port (\d+)": lambda m: f"{GREEN}●{RESET} Listening on port {WHITE}{m.group(1)}{RESET}",
    r"INFO.*Connection ready": lambda m: f"{GREEN}●{RESET} {GREEN}Connection ready!{RESET}",
    r"INFO.*accepted new client": lambda m: f"{BLUE}→{RESET} New client connected",
    r"INFO.*client disconnected": lambda m: f"{BLUE}←{RESET} Client disconnected",
    r"WARN.*certificate pinning": lambda m: f"{YELLOW}!{RESET} {DIM}Certificate pinning disabled{RESET}",
    r".*(ERROR|FATAL).*": lambda m: f"{RED}✗{RESET} {m.group(0).strip()}",
    r"INFO.*bytes.*transferred": lambda m: f"{DIM}↔{RESET} {DIM}Data transferred{RESET}",
    r"actively refused": lambda m: None,
}


def format_log_line(line: str) -> str:
    line = line.strip()
    if not line:
        return None
    
    if any(x in line for x in ["actively refused", "HostUnreachable", "connection failed"]):
        return None
    
    for pattern, formatter in LOG_PATTERNS.items():
        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            return formatter(match)
    
    if "INFO" in line or "DEBUG" in line:
        return None
    
    return f"{DIM}│{RESET} {line}"


def is_admin() -> bool:
    if is_windows():
        try:
            import ctypes
            if ctypes.windll.shell32.IsUserAnAdmin():
                return True
            # Fallback: Try executing a command that requires admin privileges
            import subprocess
            try:
                return subprocess.run(["net", "session"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
            except:
                return False
        except:
            return False
    else:
        return os.geteuid() == 0


def run_as_admin():
    if is_windows():
        try:
            import ctypes
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            return True
        except:
            return False
    else:
        print(f"{YELLOW}!{RESET} Please run with sudo for VPN mode")
        return False


class ConnectionManager:
    def __init__(self, log_callback=None):
        self.slipstream_process = None
        self.dnstt_process = None
        self.doh_proxy_process = None
        self.singbox_process = None
        self.pingtunnel_process = None
        self.ssh_process = None
        self.tun2proxy_process = None
        self.privoxy_process = None
        self.fragmenter = None
        self.restart_requested = False
        self.user_disconnected = False
        self.stop_listener = False
        self._original_sigint = None
        self._listener_thread = None
        self._monitor_thread = None
        self._auto_restart_thread = None
        self.start_time = None
        self.auto_restart_seconds = 0
        self.skip_signal_handlers = False
        self.log_callback = log_callback
        self.singbox_config_path = None
        
    def _start_log_reader(self, process, name="Process"):
        def reader():
            try:
                if not process.stdout:
                    return
                for line in iter(process.stdout.readline, ''):
                    if line:
                        line = line.strip()
                        if self.log_callback:
                            try:
                                if name == "Ping Tunnel" and "socks command not supported" in line.lower():
                                    self.log_callback(f"[{name}] WARN SOCKS command not supported (ignored)")
                                else:
                                    self.log_callback(f"[{name}] {line}")
                            except:
                                pass
                        else:
                            formatted = format_log_line(line)
                            if formatted:
                                print(f"  {formatted}")
            except Exception:
                pass
                
        t = threading.Thread(target=reader, daemon=True)
        t.start()
    
    def _setup_signal_handlers(self):
        if self.skip_signal_handlers:
            return
        try:
            self._original_sigint = signal.signal(signal.SIGINT, self._sigint_handler)
        except ValueError:
            pass
    
    def _restore_signal_handlers(self):
        if self.skip_signal_handlers:
            return
        if self._original_sigint:
            try:
                signal.signal(signal.SIGINT, self._original_sigint)
            except ValueError:
                pass
    
    def _sigint_handler(self, signum, frame):
        print(f"\n\n{YELLOW}⟳{RESET} Disconnecting...")
        self.user_disconnected = True
        self.disconnect()
    
    def _keyboard_listener(self):
        if is_windows():
            try:
                import msvcrt
                while not self.stop_listener:
                    if msvcrt.kbhit():
                        key = msvcrt.getch()
                        if key == b'\x04':
                            self.restart_requested = True
                            self.disconnect()
                            return
                    threading.Event().wait(0.1)
            except:
                pass
        else:
            try:
                import sys
                import select
                import tty
                import termios
                old_settings = termios.tcgetattr(sys.stdin)
                try:
                    tty.setcbreak(sys.stdin.fileno())
                    while not self.stop_listener:
                        if select.select([sys.stdin], [], [], 0.1)[0]:
                            key = sys.stdin.read(1)
                            if key == '\x04':
                                self.restart_requested = True
                                self.disconnect()
                                return
                finally:
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            except:
                pass
    
    def _start_keyboard_listener(self):
        self.stop_listener = False
        self._listener_thread = threading.Thread(target=self._keyboard_listener, daemon=True)
        self._listener_thread.start()
    
    def _stop_keyboard_listener(self):
        self.stop_listener = True
        if self._listener_thread and self._listener_thread.is_alive():
            self._listener_thread.join(timeout=0.5)
    
    def _auto_restart_timer(self):
        start = time.time()
        while not self.user_disconnected and not self.restart_requested:
            elapsed = time.time() - start
            if elapsed >= self.auto_restart_seconds:
                print(f"\n  {YELLOW}⟳{RESET} Auto-restart triggered after {int(self.auto_restart_seconds // 60)} minutes")
                self.restart_requested = True
                return
            time.sleep(1)
    
    def _start_auto_restart_timer(self, minutes: int):
        if minutes > 0:
            self.auto_restart_seconds = minutes * 60
            self._auto_restart_thread = threading.Thread(target=self._auto_restart_timer, daemon=True)
            self._auto_restart_thread.start()
    
    def _stop_auto_restart_timer(self):
        if self._auto_restart_thread and self._auto_restart_thread.is_alive():
            self._auto_restart_thread.join(timeout=0.5)
        self._auto_restart_thread = None
    
    def get_uptime(self):
        if self.start_time:
            elapsed = time.time() - self.start_time
            return f"{int(elapsed // 60):02d}:{int(elapsed % 60):02d}"
        return "00:00"

    def get_uptime_seconds(self):
        if self.start_time:
            return int(time.time() - self.start_time)
        return 0

    def _get_vpn_bypass_entries(self, config: dict, server_ip: str) -> list:
        entries = []
        try:
            ipaddress.ip_address(server_ip)
            entries.append(server_ip)
        except Exception:
            pass

        raw_value = config.get("bypass_list", "")
        if config.get("split_tunnel_enabled", False):
            split_value = config.get("split_include_list", "")
            if split_value:
                raw_value = f"{raw_value},{split_value}" if raw_value else split_value
        if raw_value is None:
            return entries

        for token in re.split(r"[,\s;]+", str(raw_value)):
            value = token.strip()
            if not value:
                continue
            if value == "<local>":
                continue
            try:
                if "/" in value:
                    ipaddress.ip_network(value, strict=False)
                else:
                    ipaddress.ip_address(value)
            except Exception:
                continue
            if value not in entries:
                entries.append(value)

        for ip in self._resolve_singbox_bypass_ips(config):
            if ip not in entries:
                entries.append(ip)

        return entries

    def _start_doh_proxy(self, config: dict):
        if not doh_proxy_exists():
            if not download_doh_proxy():
                raise Exception("dnsproxy not available")

        doh_proxy_path = get_doh_proxy_path()
        listen_port = int(config.get("doh_local_dns_port", 5300))
        doh_url = config.get("doh_url", "https://1.1.1.1/dns-query").strip()
        doh_bootstrap_ip = config.get("doh_bootstrap_ip", "").strip()
        doh_insecure = bool(config.get("doh_insecure", False))

        if not doh_url:
            raise Exception("DoH URL is required")

        cmd = [
            str(doh_proxy_path),
            "-l", "127.0.0.1",
            "-p", str(listen_port),
            "-u", doh_url,
        ]
        if doh_bootstrap_ip:
            cmd.extend(["-b", doh_bootstrap_ip])
        if doh_insecure:
            cmd.append("--insecure")

        self.doh_proxy_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )

        time.sleep(1)
        if self.doh_proxy_process.poll() is not None:
            raise Exception("dnsproxy failed to start")
        self._start_log_reader(self.doh_proxy_process, "DoH")

    def _get_slipstream_resolver(self, config: dict) -> str:
        tunnel_type = config.get("tunnel_type", "slipstream")
        if tunnel_type == "doh":
            self._start_doh_proxy(config)
            return f"127.0.0.1:{int(config.get('doh_local_dns_port', 5300))}"
        server_ip = config.get("server_ip", "")
        server_port = config.get("server_port", 53)
        return f"{server_ip}:{server_port}"

    def _resolve_singbox_bypass_ips(self, config: dict) -> list:
        entries = []
        server_ip = str(config.get("server_ip", "")).strip()
        if server_ip:
            try:
                ipaddress.ip_address(server_ip)
                entries.append(server_ip)
            except Exception:
                pass

        uri = str(config.get("singbox_uri", "")).strip()
        tunnel_type = str(config.get("tunnel_type", "")).strip().lower()
        if uri and is_singbox_tunnel(tunnel_type):
            try:
                host, _, _ = extract_link_server(uri, tunnel_type=tunnel_type)
                try:
                    ipaddress.ip_address(host)
                    if host not in entries:
                        entries.append(host)
                except Exception:
                    for family, _, _, _, sockaddr in socket.getaddrinfo(host, None):
                        if family in (socket.AF_INET, socket.AF_INET6):
                            ip = sockaddr[0]
                            if ip and ip not in entries:
                                entries.append(ip)
            except Exception:
                pass

        return entries

    def _start_singbox_proxy(self, config: dict, local_port: int):
        tunnel_type = str(config.get("tunnel_type", "")).strip().lower()
        if not is_singbox_tunnel(tunnel_type):
            raise Exception("Unsupported sing-box tunnel type")

        if not singbox_exists():
            if not download_singbox():
                raise Exception(f"sing-box not available at {get_singbox_path()}")

        link = str(config.get("singbox_uri", "")).strip()
        if not link:
            raise Exception("sing-box link is required")

        cfg, meta = build_singbox_config(link, tunnel_type=tunnel_type, local_port=local_port)
        config["server_ip"] = meta.get("server", "")
        config["server_port"] = int(meta.get("server_port", 0) or 0)

        cfg_dir = Path.home() / ".localstream" / "runtime"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = cfg_dir / "sing-box.json"
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, separators=(",", ":"))

        self.singbox_config_path = cfg_path
        singbox_path = get_singbox_path()
        env = os.environ.copy()
        env["ENABLE_DEPRECATED_SPECIAL_OUTBOUNDS"] = "true"

        self.singbox_process = subprocess.Popen(
            [str(singbox_path), "run", "-c", str(cfg_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            env=env
        )
        time.sleep(2)
        if self.singbox_process.poll() is not None:
            output = self.singbox_process.stdout.read() if self.singbox_process.stdout else "No output"
            print(f"{RED}x{RESET} sing-box output:\n{DIM}{output}{RESET}")
            raise Exception("sing-box failed to start")
        self._start_log_reader(self.singbox_process, "SingBox")

    def _wait_local_proxy_ready(self, port: int, timeout_seconds: float = 8.0) -> bool:
        deadline = time.time() + max(1.0, timeout_seconds)
        while time.time() < deadline:
            try:
                sock = socket.create_connection(("127.0.0.1", int(port)), timeout=0.8)
                sock.close()
                return True
            except Exception:
                time.sleep(0.2)
        return False

    def connect_proxy(self, config: dict) -> str:
        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()
        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                print(f"{RED}x{RESET} Invalid configuration: sing-box link is required")
                return "error"
        else:
            if not server_ip:
                print(f"{RED}x{RESET} Invalid configuration: server_ip is required")
                return "error"
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                print(f"{RED}x{RESET} Invalid configuration: domain is required for {tunnel_type}")
                return "error"

        if tunnel_type in ["slipstream", "doh"] and not client_exists() and not download_client():
            print(f"{RED}x{RESET} Cannot connect: slipstream-client not available")
            return "error"

        self._setup_signal_handlers()
        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        try:
            if tunnel_type in ["slipstream", "doh"]:
                print(f"  {YELLOW}!{RESET} Starting Slipstream client...")
                client_path = get_client_path()
                keep_alive = config.get("keep_alive_interval", 200)
                congestion = config.get("congestion_control", "bbr")
                enable_gso = config.get("enable_gso", False)
                resolver = self._get_slipstream_resolver(config)
                cmd = [
                    str(client_path),
                    "--resolver", resolver,
                    "--domain", domain,
                    "--tcp-listen-port", str(local_port),
                    "--keep-alive-interval", str(keep_alive),
                    "--congestion-control", congestion,
                    "--gso", str(enable_gso).lower(),
                ]
                self.slipstream_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
                )
                time.sleep(2)
                if self.slipstream_process.poll() is not None:
                    raise Exception("slipstream-client failed to start")
                self._start_log_reader(self.slipstream_process, "Slipstream")
            elif tunnel_type == "pingtunnel":
                print(f"  {YELLOW}!{RESET} Starting Ping Tunnel...")
                self._start_pingtunnel(config, local_port)
                print(f"  {GREEN}OK{RESET} Ping Tunnel established")
            elif is_singbox_tunnel(tunnel_type):
                print(f"  {YELLOW}!{RESET} Starting sing-box...")
                self._start_singbox_proxy(config, local_port)
                print(f"  {GREEN}OK{RESET} sing-box tunnel established")
            else:
                print(f"  {YELLOW}!{RESET} Starting DNSTT client...")
                dnstt_local_port = 7000
                self._start_dnstt(config, dnstt_local_port)
                print(f"  {GREEN}OK{RESET} DNSTT tunnel established")
                print(f"  {YELLOW}!{RESET} Opening SSH tunnel...")
                self._start_ssh(config, dnstt_local_port)
                print(f"  {GREEN}OK{RESET} SSH tunnel established")

            self._start_keyboard_listener()
            self._start_auto_restart_timer(config.get("auto_restart_minutes", 0))

            print(f"  {GREEN}OK{RESET} Connection ready on port {local_port}")
            print(f"  {DIM}Press Ctrl+C to disconnect / Ctrl+D to restart{RESET}")

            while not self.user_disconnected and not self.restart_requested:
                if tunnel_type in ["slipstream", "doh"] and self.slipstream_process and self.slipstream_process.poll() is not None:
                    print(f"  {RED}x{RESET} Slipstream process exited unexpectedly")
                    return "error"
                if is_singbox_tunnel(tunnel_type) and self.singbox_process and self.singbox_process.poll() is not None:
                    print(f"  {RED}x{RESET} sing-box process exited unexpectedly")
                    return "error"
                if tunnel_type == "dnstt":
                    if self.dnstt_process and self.dnstt_process.poll() is not None:
                        print(f"  {RED}x{RESET} DNSTT process exited unexpectedly")
                        return "error"
                    if self.ssh_process and self.ssh_process.poll() is not None:
                        print(f"  {RED}x{RESET} SSH process exited unexpectedly")
                        return "error"
                if tunnel_type == "pingtunnel" and self.pingtunnel_process and self.pingtunnel_process.poll() is not None:
                    print(f"  {RED}x{RESET} Ping Tunnel process exited unexpectedly")
                    return "error"
                time.sleep(1)

            if self.restart_requested:
                return "restart"
            return "done"
        except Exception as e:
            print(f"{RED}x{RESET} Connection error: {e}")
            return "error"
        finally:
            self._restore_signal_handlers()
            self._stop_keyboard_listener()
            self.disconnect()

    def _monitor_slipstream(self, cmd):
        reconnect_count = 0
        while not self.user_disconnected and not self.restart_requested:
            if self.slipstream_process and self.slipstream_process.poll() is not None:
                return_code = self.slipstream_process.returncode
                if return_code != 0 and not self.user_disconnected:
                    reconnect_count += 1
                    print(f"\n  {YELLOW}!{RESET} Slipstream dropped (code: {return_code})")
                    print(f"  {YELLOW}⟳{RESET} Auto-reconnecting...")
                    time.sleep(2)
                    
                    try:
                        self.slipstream_process = subprocess.Popen(
                            cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            text=True,
                            bufsize=1,
                            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
                        )
                        time.sleep(2)
                        if self.slipstream_process.poll() is None:
                            print(f"  {GREEN}●{RESET} Slipstream reconnected! (attempt #{reconnect_count + 1})")
                    except:
                        pass
            time.sleep(1)
    
    def connect_vpn(self, config: dict) -> str:
        if not is_admin():
            print(f"{RED}x{RESET} VPN Mode requires Administrator privileges")
            return "error"

        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()
        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                print(f"{RED}x{RESET} Invalid configuration: sing-box link is required")
                return "error"
        else:
            if not server_ip:
                print(f"{RED}x{RESET} Invalid configuration: server_ip is required")
                return "error"
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                print(f"{RED}x{RESET} Invalid configuration: domain is required for {tunnel_type}")
                return "error"

        if tunnel_type in ["slipstream", "doh"] and not client_exists() and not download_client():
            print(f"{RED}x{RESET} Cannot connect: slipstream-client not available")
            return "error"

        if not tun2proxy_exists() and not download_tun2proxy():
            print(f"{RED}x{RESET} Cannot connect: tun2proxy not available")
            return "error"

        tun2proxy_path = get_tun2proxy_path()
        self._setup_signal_handlers()
        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        try:
            proxy_port = local_port

            if tunnel_type in ["slipstream", "doh"]:
                client_path = get_client_path()
                keep_alive = config.get("keep_alive_interval", 200)
                congestion = config.get("congestion_control", "bbr")
                enable_gso = config.get("enable_gso", False)
                enable_frag = config.get("enable_fragmentation", False)
                frag_size = config.get("fragment_size", 77)
                frag_delay = config.get("fragment_delay", 200)
                resolver = self._get_slipstream_resolver(config)
                if enable_frag:
                    fragmenter_port = 5202
                    self.fragmenter = TlsFragmenter(
                        listen_port=fragmenter_port,
                        upstream_port=local_port,
                        fragment_size=frag_size,
                        fragment_delay=frag_delay,
                    )
                    if self.fragmenter.start():
                        proxy_port = fragmenter_port

                slipstream_cmd = [
                    str(client_path),
                    "--resolver", resolver,
                    "--domain", domain,
                    "--tcp-listen-port", str(local_port),
                    "--keep-alive-interval", str(keep_alive),
                    "--congestion-control", congestion,
                    "--gso", str(enable_gso).lower(),
                ]
                self.slipstream_process = subprocess.Popen(
                    slipstream_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
                )
                time.sleep(2)
                if self.slipstream_process.poll() is not None:
                    raise Exception("slipstream-client failed to start")
                self._start_log_reader(self.slipstream_process, "Slipstream")
                print(f"  {GREEN}OK{RESET} Slipstream tunnel established")
            elif tunnel_type == "pingtunnel":
                print(f"  {YELLOW}!{RESET} Starting Ping Tunnel...")
                self._start_pingtunnel(config, local_port)
                print(f"  {GREEN}OK{RESET} Ping Tunnel established")
            elif is_singbox_tunnel(tunnel_type):
                print(f"  {YELLOW}!{RESET} Starting sing-box...")
                self._start_singbox_proxy(config, local_port)
                print(f"  {GREEN}OK{RESET} sing-box tunnel established")
            else:
                print(f"  {YELLOW}!{RESET} Starting DNSTT client...")
                dnstt_local_port = 7000
                self._start_dnstt(config, dnstt_local_port)
                print(f"  {GREEN}OK{RESET} DNSTT tunnel established")
                print(f"  {YELLOW}!{RESET} Opening SSH tunnel...")
                self._start_ssh(config, dnstt_local_port)
                print(f"  {GREEN}OK{RESET} SSH tunnel established")

            if not self._wait_local_proxy_ready(local_port, timeout_seconds=8.0):
                raise Exception(f"Local SOCKS proxy did not become ready on 127.0.0.1:{local_port}")

            tun2proxy_cmd = [
                str(tun2proxy_path),
                "--setup",
                "--proxy", f"socks5://127.0.0.1:{proxy_port}",
                "--dns", "virtual",
            ]
            current_server_ip = config.get("server_ip", "")
            for bypass in self._get_vpn_bypass_entries(config, current_server_ip):
                tun2proxy_cmd.extend(["--bypass", bypass])

            if sys.platform == "win32":
                bin_dir = os.path.dirname(tun2proxy_path)
                self.tun2proxy_process = subprocess.Popen(
                    tun2proxy_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    cwd=bin_dir,
                )
            else:
                self.tun2proxy_process = subprocess.Popen(
                    tun2proxy_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )

            time.sleep(3)
            if self.tun2proxy_process.poll() is not None:
                raise Exception("tun2proxy failed to start")
            self._start_log_reader(self.tun2proxy_process, "tun2proxy")
            print(f"  {GREEN}OK{RESET} VPN tunnel ready on local SOCKS {local_port}")
            print(f"  {DIM}Press Ctrl+C to disconnect / Ctrl+D to restart{RESET}")

            self._start_keyboard_listener()
            self._start_auto_restart_timer(config.get("auto_restart_minutes", 0))

            while not self.user_disconnected and not self.restart_requested:
                if tunnel_type in ["slipstream", "doh"] and self.slipstream_process and self.slipstream_process.poll() is not None:
                    print(f"  {RED}x{RESET} Slipstream process exited unexpectedly")
                    break
                if is_singbox_tunnel(tunnel_type) and self.singbox_process and self.singbox_process.poll() is not None:
                    print(f"  {RED}x{RESET} sing-box process exited unexpectedly")
                    break
                if tunnel_type == "dnstt":
                    if self.dnstt_process and self.dnstt_process.poll() is not None:
                        print(f"  {RED}x{RESET} DNSTT process exited unexpectedly")
                        break
                    if self.ssh_process and self.ssh_process.poll() is not None:
                        print(f"  {RED}x{RESET} SSH process exited unexpectedly")
                        break
                if tunnel_type == "pingtunnel" and self.pingtunnel_process and self.pingtunnel_process.poll() is not None:
                    print(f"  {RED}x{RESET} Ping Tunnel process exited unexpectedly")
                    break
                if self.tun2proxy_process and self.tun2proxy_process.poll() is not None:
                    print(f"  {RED}x{RESET} tun2proxy process exited unexpectedly")
                    break
                time.sleep(1)

            if self.restart_requested:
                return "restart"
            return "done"
        except Exception as e:
            print(f"{RED}x{RESET} Connection error: {e}")
            return "error"
        finally:
            self._restore_signal_handlers()
            self._stop_keyboard_listener()
            self.disconnect()

    def connect_system_proxy(self, config: dict) -> str:
        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()

        if not privoxy_exists() and not download_privoxy():
            print(f"{RED}x{RESET} Cannot connect: Privoxy not available")
            return "error"

        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        privoxy_port = 8118
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                print(f"{RED}x{RESET} Invalid configuration: sing-box link is required")
                return "error"
        else:
            if not server_ip:
                print(f"{RED}x{RESET} Invalid configuration: server_ip is required")
                return "error"
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                print(f"{RED}x{RESET} Invalid configuration: domain is required for {tunnel_type}")
                return "error"

        if tunnel_type in ["slipstream", "doh"] and not client_exists() and not download_client():
            print(f"{RED}x{RESET} Cannot connect: client not available")
            return "error"

        proxy_port = local_port
        self._setup_signal_handlers()
        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        try:
            if tunnel_type in ["slipstream", "doh"]:
                client_path = get_client_path()
                keep_alive = config.get("keep_alive_interval", 200)
                congestion = config.get("congestion_control", "bbr")
                enable_gso = config.get("enable_gso", False)
                enable_frag = config.get("enable_fragmentation", False)
                frag_size = config.get("fragment_size", 77)
                frag_delay = config.get("fragment_delay", 200)
                resolver = self._get_slipstream_resolver(config)

                if enable_frag:
                    fragmenter_port = 5202
                    self.fragmenter = TlsFragmenter(
                        listen_port=fragmenter_port,
                        upstream_port=local_port,
                        fragment_size=frag_size,
                        fragment_delay=frag_delay,
                    )
                    if self.fragmenter.start():
                        proxy_port = fragmenter_port
                    else:
                        self.fragmenter = None

                slipstream_cmd = [
                    str(client_path),
                    "--resolver", resolver,
                    "--domain", domain,
                    "--tcp-listen-port", str(local_port),
                    "--keep-alive-interval", str(keep_alive),
                    "--congestion-control", congestion,
                    "--gso", str(enable_gso).lower(),
                ]
                self.slipstream_process = subprocess.Popen(
                    slipstream_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
                )
                time.sleep(2)
                if self.slipstream_process and self.slipstream_process.poll() is not None:
                    return "error"
                self._start_log_reader(self.slipstream_process, "Slipstream")
            elif tunnel_type == "pingtunnel":
                self._start_pingtunnel(config, local_port)
            elif is_singbox_tunnel(tunnel_type):
                self._start_singbox_proxy(config, local_port)
            else:
                dnstt_local_port = 7000
                self._start_dnstt(config, dnstt_local_port)
                self._start_ssh(config, dnstt_local_port)

            if not self._wait_local_proxy_ready(proxy_port, timeout_seconds=8.0):
                raise Exception(f"Local SOCKS proxy did not become ready on 127.0.0.1:{proxy_port}")

            self.privoxy_process = start_privoxy(proxy_port, privoxy_port)
            time.sleep(2)
            if self.privoxy_process and self.privoxy_process.poll() is not None:
                self.disconnect()
                return "error"

            set_system_proxy("127.0.0.1", privoxy_port, config.get("bypass_list", "<local>"))
            self._start_keyboard_listener()
            self._start_auto_restart_timer(config.get("auto_restart_minutes", 0))

            while not self.user_disconnected and not self.restart_requested:
                if tunnel_type in ["slipstream", "doh"] and self.slipstream_process and self.slipstream_process.poll() is not None:
                    break
                if is_singbox_tunnel(tunnel_type) and self.singbox_process and self.singbox_process.poll() is not None:
                    break
                if tunnel_type == "dnstt":
                    if self.dnstt_process and self.dnstt_process.poll() is not None:
                        break
                    if self.ssh_process and self.ssh_process.poll() is not None:
                        break
                if tunnel_type == "pingtunnel" and self.pingtunnel_process and self.pingtunnel_process.poll() is not None:
                    break
                if self.privoxy_process and self.privoxy_process.poll() is not None:
                    break
                time.sleep(1)

            if self.restart_requested:
                return "restart"
            return "done"

        except KeyboardInterrupt:
            return "done"
        except Exception as e:
            print(f"{RED}x{RESET} Error: {e}")
            return "error"
        finally:
            self._restore_signal_handlers()
            self._stop_keyboard_listener()
            self.disconnect()

    def disconnect(self):
        self.user_disconnected = True

        unset_system_proxy()

        if self.fragmenter:
            self.fragmenter.stop()
            self.fragmenter = None

        if self.privoxy_process:
            stop_privoxy(self.privoxy_process)
            print(f"{GREEN}?{RESET} Privoxy stopped")
        self.privoxy_process = None

        if self.ssh_process and self.ssh_process.poll() is None:
            self.ssh_process.terminate()
            try:
                self.ssh_process.wait(timeout=3)
            except:
                self.ssh_process.kill()
            print(f"{GREEN}?{RESET} SSH tunnel closed")
        self.ssh_process = None

        if self.dnstt_process and self.dnstt_process.poll() is None:
            self.dnstt_process.terminate()
            try:
                self.dnstt_process.wait(timeout=3)
            except:
                self.dnstt_process.kill()
            print(f"{GREEN}?{RESET} DNSTT disconnected")
        self.dnstt_process = None

        if self.doh_proxy_process and self.doh_proxy_process.poll() is None:
            self.doh_proxy_process.terminate()
            try:
                self.doh_proxy_process.wait(timeout=3)
            except:
                self.doh_proxy_process.kill()
            print(f"{GREEN}?{RESET} DoH proxy stopped")
        self.doh_proxy_process = None

        if self.singbox_process and self.singbox_process.poll() is None:
            self.singbox_process.terminate()
            try:
                self.singbox_process.wait(timeout=3)
            except:
                self.singbox_process.kill()
            print(f"{GREEN}?{RESET} sing-box disconnected")
        self.singbox_process = None

        if self.pingtunnel_process and self.pingtunnel_process.poll() is None:
            self.pingtunnel_process.terminate()
            try:
                self.pingtunnel_process.wait(timeout=3)
            except:
                self.pingtunnel_process.kill()
            print(f"{GREEN}?{RESET} Ping Tunnel disconnected")
        self.pingtunnel_process = None

        if self.tun2proxy_process and self.tun2proxy_process.poll() is None:
            self.tun2proxy_process.terminate()
            try:
                self.tun2proxy_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.tun2proxy_process.kill()
            print(f"{GREEN}?{RESET} VPN tunnel closed")
        self.tun2proxy_process = None

        if self.slipstream_process and self.slipstream_process.poll() is None:
            self.slipstream_process.terminate()
            try:
                self.slipstream_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.slipstream_process.kill()
            print(f"{GREEN}?{RESET} Slipstream disconnected")
        self.slipstream_process = None

        if self.singbox_config_path and Path(self.singbox_config_path).exists():
            try:
                Path(self.singbox_config_path).unlink()
            except Exception:
                pass
        self.singbox_config_path = None

    def _start_dnstt(self, config: dict, local_dnstt_port=7000):
        from localstream.Downloader import get_dnstt_path, download_dnstt_client
        if not download_dnstt_client():
            raise Exception("DNSTT client not available")
            
        dnstt_path = get_dnstt_path()
        dns_server = config.get("server_ip", "8.8.8.8")
        domain = config.get("domain", "")
        pubkey = config.get("dnstt_pubkey", "")
        
        # Create a temporary pubkey file
        pubkey_path = Path.home() / ".localstream" / "server.pub"
        with open(pubkey_path, "w") as f:
            f.write(pubkey)
            
        cmd = [
            str(dnstt_path),
            "-udp", f"{dns_server}:53",
            "-pubkey-file", str(pubkey_path),
            domain,
            f"127.0.0.1:{local_dnstt_port}"
        ]
        
        self.dnstt_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        time.sleep(2)
        if self.dnstt_process.poll() is not None:
            raise Exception("dnstt-client failed to start")
        self._start_log_reader(self.dnstt_process, "DNSTT")

    def _start_ssh(self, config: dict, local_bridge_port=7000):
        ssh_user = config.get("ssh_user", "")
        ssh_pass = config.get("ssh_pass", "")
        ssh_port = config.get("ssh_port", 22)
        local_proxy_port = config.get("local_port", 5201)
        
        # We tunnel through the local bridge port (local_bridge_port)
        # ssh -D local_proxy_port -p local_bridge_port user@127.0.0.1
        
        ssh_cmd = [
            "ssh",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "PreferredAuthentications=password",
            "-p", str(local_bridge_port),
            "-D", str(local_proxy_port),
            "-N",
            f"{ssh_user}@127.0.0.1"
        ]
        
        # Attempt to use SSH_ASKPASS or similar for password handling if possible
        # but for a CLI tool, using a more direct method or plink is better.
        # For now, we'll try to start it. Note: This might require a TTY on some systems.
        
        self.ssh_process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        
        time.sleep(3)
        if self.ssh_process.poll() is not None:
             raise Exception("SSH tunnel failed to start (password may be required or TTY missing)")
             
        self._start_log_reader(self.ssh_process, "SSH")

    def connect_proxy_gui(self, config: dict) -> str:
        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()
        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                raise Exception("Invalid configuration: sing-box link is required")
        else:
            if not server_ip:
                raise Exception("Invalid configuration: server_ip is required")
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                raise Exception("Invalid configuration: domain is required")

        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        if tunnel_type in ["slipstream", "doh"]:
            if not client_exists() and not download_client():
                raise Exception("Cannot connect: slipstream-client not available")

            client_path = get_client_path()
            keep_alive = config.get("keep_alive_interval", 200)
            congestion = config.get("congestion_control", "bbr")
            enable_gso = config.get("enable_gso", False)
            resolver = self._get_slipstream_resolver(config)
            cmd = [
                str(client_path),
                "--resolver", resolver,
                "--domain", domain,
                "--tcp-listen-port", str(local_port),
                "--keep-alive-interval", str(keep_alive),
                "--congestion-control", congestion,
                "--gso", str(enable_gso).lower(),
            ]

            self.slipstream_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
            time.sleep(2)
            if self.slipstream_process.poll() is not None:
                raise Exception("slipstream-client failed to start")
            self._start_log_reader(self.slipstream_process, "Slipstream")
        elif tunnel_type == "pingtunnel":
            self._start_pingtunnel(config, local_port)
        elif is_singbox_tunnel(tunnel_type):
            self._start_singbox_proxy(config, local_port)
        else:
            dnstt_local_port = 7000
            self._start_dnstt(config, dnstt_local_port)
            self._start_ssh(config, dnstt_local_port)

        if not self._wait_local_proxy_ready(local_port, timeout_seconds=8.0):
            raise Exception(f"Local SOCKS proxy did not become ready on 127.0.0.1:{local_port}")

        return "connected"

    def _linux_sudo_cached(self) -> bool:
        if not is_linux() or is_admin():
            return True
        try:
            result = subprocess.run(
                ["sudo", "-n", "true"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return result.returncode == 0
        except Exception:
            return False

    def _linux_sudo_validate_password(self, sudo_password: str) -> bool:
        if not is_linux() or is_admin():
            return True
        if not sudo_password:
            return False
        try:
            result = subprocess.run(
                ["sudo", "-S", "-k", "-p", "", "true"],
                input=f"{sudo_password}\n",
                text=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return result.returncode == 0
        except Exception:
            return False

    def connect_vpn_gui(self, config: dict, sudo_password: str = "") -> str:
        if not is_admin() and not is_linux():
            raise Exception("VPN Mode requires Administrator privileges")

        linux_needs_sudo = is_linux() and not is_admin()
        sudo_is_cached = self._linux_sudo_cached() if linux_needs_sudo else False
        if linux_needs_sudo and not sudo_is_cached and not sudo_password:
            raise Exception("SUDO_PASSWORD_REQUIRED")
        if linux_needs_sudo and sudo_password and not self._linux_sudo_validate_password(sudo_password):
            raise Exception("SUDO_PASSWORD_INVALID")

        if not tun2proxy_exists() and not download_tun2proxy():
            raise Exception("Cannot connect: tun2proxy not available")

        tun2proxy_path = get_tun2proxy_path()
        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()
        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                raise Exception("Invalid configuration: sing-box link is required")
        else:
            if not server_ip:
                raise Exception("Invalid configuration: server_ip is required")
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                raise Exception("Invalid configuration: domain is required")

        proxy_port = local_port
        tun2proxy_cmd = [
            str(tun2proxy_path),
            "--setup",
            "--proxy", f"socks5://127.0.0.1:{proxy_port}",
            "--dns", "virtual",
        ]
        for bypass in self._get_vpn_bypass_entries(config, server_ip):
            tun2proxy_cmd.extend(["--bypass", bypass])

        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        if tunnel_type in ["slipstream", "doh"]:
            if not client_exists() and not download_client():
                raise Exception("Cannot connect: slipstream-client not available")

            client_path = get_client_path()
            keep_alive = config.get("keep_alive_interval", 200)
            congestion = config.get("congestion_control", "bbr")
            enable_gso = config.get("enable_gso", False)
            enable_frag = config.get("enable_fragmentation", False)
            frag_size = config.get("fragment_size", 77)
            frag_delay = config.get("fragment_delay", 200)
            resolver = self._get_slipstream_resolver(config)

            if enable_frag:
                fragmenter_port = 5202
                self.fragmenter = TlsFragmenter(
                    listen_port=fragmenter_port,
                    upstream_port=local_port,
                    fragment_size=frag_size,
                    fragment_delay=frag_delay,
                )
                if self.fragmenter.start():
                    proxy_port = fragmenter_port
                    tun2proxy_cmd[tun2proxy_cmd.index("--proxy") + 1] = f"socks5://127.0.0.1:{proxy_port}"

            slipstream_cmd = [
                str(client_path),
                "--resolver", resolver,
                "--domain", domain,
                "--tcp-listen-port", str(local_port),
                "--keep-alive-interval", str(keep_alive),
                "--congestion-control", congestion,
                "--gso", str(enable_gso).lower(),
            ]

            self.slipstream_process = subprocess.Popen(
                slipstream_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
            time.sleep(2)
            if self.slipstream_process.poll() is not None:
                raise Exception("Slipstream failed to start")
            self._start_log_reader(self.slipstream_process, "Slipstream")
        elif tunnel_type == "pingtunnel":
            self._start_pingtunnel(config, local_port)
        elif is_singbox_tunnel(tunnel_type):
            self._start_singbox_proxy(config, local_port)
        else:
            dnstt_local_port = 7000
            self._start_dnstt(config, dnstt_local_port)
            self._start_ssh(config, dnstt_local_port)

        if not self._wait_local_proxy_ready(local_port, timeout_seconds=8.0):
            raise Exception(f"Local SOCKS proxy did not become ready on 127.0.0.1:{local_port}")

        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            bin_dir = os.path.dirname(tun2proxy_path)
            self.tun2proxy_process = subprocess.Popen(
                tun2proxy_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                startupinfo=startupinfo,
                cwd=bin_dir,
            )
        else:
            sudo_cmd = list(tun2proxy_cmd)
            use_sudo_stdin = False
            if linux_needs_sudo:
                if sudo_password:
                    sudo_cmd = ["sudo", "-S", "-p", ""] + sudo_cmd
                    use_sudo_stdin = True
                else:
                    sudo_cmd = ["sudo", "-n"] + sudo_cmd
            self.tun2proxy_process = subprocess.Popen(
                sudo_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                stdin=subprocess.PIPE if use_sudo_stdin else None,
            )
            if use_sudo_stdin and self.tun2proxy_process.stdin:
                self.tun2proxy_process.stdin.write(f"{sudo_password}\n")
                self.tun2proxy_process.stdin.flush()
                self.tun2proxy_process.stdin.close()

        self._start_log_reader(self.tun2proxy_process, "tun2proxy")
        time.sleep(3)
        if self.tun2proxy_process.poll() is not None:
            self.disconnect()
            raise Exception("tun2proxy failed to start (check logs)")

        return "connected"

    def connect_system_proxy_gui(self, config: dict) -> str:
        if not privoxy_exists() and not download_privoxy():
            raise Exception("Cannot connect: Privoxy not available")

        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()
        server_ip = config.get("server_ip", "")
        local_port = config.get("local_port", 5201)
        privoxy_port = 8118
        domain = config.get("domain", "")

        if is_singbox_tunnel(tunnel_type):
            if not str(config.get("singbox_uri", "")).strip():
                raise Exception("Invalid configuration: sing-box link is required")
        else:
            if not server_ip:
                raise Exception("Invalid configuration")
            if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
                raise Exception("Invalid configuration")

        proxy_port = local_port
        self.restart_requested = False
        self.user_disconnected = False
        self.start_time = time.time()

        if tunnel_type in ["slipstream", "doh"]:
            if not client_exists() and not download_client():
                raise Exception("Cannot connect: client not available")

            client_path = get_client_path()
            keep_alive = config.get("keep_alive_interval", 200)
            congestion = config.get("congestion_control", "bbr")
            enable_gso = config.get("enable_gso", False)
            enable_frag = config.get("enable_fragmentation", False)
            frag_size = config.get("fragment_size", 77)
            frag_delay = config.get("fragment_delay", 200)
            resolver = self._get_slipstream_resolver(config)

            if enable_frag:
                fragmenter_port = 5202
                self.fragmenter = TlsFragmenter(
                    listen_port=fragmenter_port,
                    upstream_port=local_port,
                    fragment_size=frag_size,
                    fragment_delay=frag_delay,
                )
                if self.fragmenter.start():
                    proxy_port = fragmenter_port

            slipstream_cmd = [
                str(client_path),
                "--resolver", resolver,
                "--domain", domain,
                "--tcp-listen-port", str(local_port),
                "--keep-alive-interval", str(keep_alive),
                "--congestion-control", congestion,
                "--gso", str(enable_gso).lower(),
            ]

            self.slipstream_process = subprocess.Popen(
                slipstream_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            )
            time.sleep(2)
            if self.slipstream_process.poll() is not None:
                raise Exception("Slipstream failed")
            self._start_log_reader(self.slipstream_process, "Slipstream")
        elif tunnel_type == "pingtunnel":
            self._start_pingtunnel(config, local_port)
        elif is_singbox_tunnel(tunnel_type):
            self._start_singbox_proxy(config, local_port)
        else:
            dnstt_local_port = 7000
            self._start_dnstt(config, dnstt_local_port)
            self._start_ssh(config, dnstt_local_port)

        if not self._wait_local_proxy_ready(proxy_port, timeout_seconds=8.0):
            raise Exception(f"Local SOCKS proxy did not become ready on 127.0.0.1:{proxy_port}")

        self.privoxy_process = start_privoxy(proxy_port, privoxy_port)
        time.sleep(2)

        if self.privoxy_process and self.privoxy_process.poll() is not None:
            self.disconnect()
            raise Exception("Privoxy failed")

        set_system_proxy("127.0.0.1", privoxy_port, "<local>")
        return "connected"



    def _start_pingtunnel(self, config: dict, local_bridge_port=5201):
        from localstream.Downloader import pingtunnel_exists, download_pingtunnel, get_pingtunnel_path, pingtunnel_quarantine_flagged, print_pingtunnel_quarantine_help
        
        if not pingtunnel_exists():
            if not download_pingtunnel():
                raise Exception("Ping Tunnel download failed")
            
        pingtunnel_path = get_pingtunnel_path()
        if not pingtunnel_path.exists():
            if is_windows() and pingtunnel_quarantine_flagged():
                print_pingtunnel_quarantine_help()
            raise Exception("Ping Tunnel binary not found")
        server_ip = config.get("server_ip", "")
        key = config.get("pingtunnel_key", 0)
        
        # Command: pingtunnel -type client -l :5201 -s server -sock5 1
        cmd = [
            str(pingtunnel_path),
            "-type", "client",
            "-l", f":{local_bridge_port}",
            "-s", server_ip,
            "-sock5", "1"
        ]
        
        if key > 0:
            cmd.extend(["-key", str(key)])
            
        self.pingtunnel_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        
        self._start_log_reader(self.pingtunnel_process, "Ping Tunnel")
        time.sleep(3) # Give it time to initialize raw sockets/connection
        
        if self.pingtunnel_process.poll() is not None:
            raise Exception("Ping Tunnel failed to start (elevation may be required)")



