import sys
import os
import argparse
import time




if sys.platform == "win32":
    import io
    import ctypes
    from ctypes import wintypes
    
    kernel32 = ctypes.windll.kernel32
    
    def is_stdout_working():
        try:
            if sys.stdout is None or sys.stdout.closed:
                return False
            sys.stdout.write('')
            return True
        except Exception:
            return False

    def is_stdin_working():
        try:
            if sys.stdin is None or sys.stdin.closed:
                return False
            return sys.stdin.isatty()
        except Exception:
            return False

    def attach_console_if_needed():
        stdout_ok = is_stdout_working()
        stdin_ok = is_stdin_working()
        
        if stdout_ok and stdin_ok:
            return

        kernel32.AttachConsole(-1)

        try:
            if not stdout_ok:
                sys.stdout = open("CONOUT$", "w", encoding="utf-8", errors="replace")
                sys.stderr = open("CONOUT$", "w", encoding="utf-8", errors="replace")
            
            if not stdin_ok:
                sys.stdin = open("CONIN$", "r", encoding="utf-8", errors="replace")
        except Exception:
            pass
        
        if not is_stdout_working():
            try:
                devnull = open(os.devnull, 'w', encoding='utf-8', errors='replace')
                sys.stdout = devnull
                try:
                    sys.stderr.write('')
                except:
                    sys.stderr = devnull
            except:
                pass

    attach_console_if_needed()

    if sys.stdout and not sys.stdout.closed and hasattr(sys.stdout, 'buffer'):
        try:
            if getattr(sys.stdout, 'encoding', '').lower() != 'utf-8':
                sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        except Exception:
            pass

    if sys.stderr and not sys.stderr.closed and hasattr(sys.stderr, 'buffer'):
        try:
           if getattr(sys.stderr, 'encoding', '').lower() != 'utf-8':
                sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except Exception:
            pass

    try:
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except:
        pass

if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

try:
    import colorama
    if sys.stdout and not sys.stdout.closed and sys.stdout.isatty():
        colorama.init()
    elif sys.stdout and not sys.stdout.closed:
        colorama.init(strip=True)
except (ImportError, ValueError, AttributeError):
    pass

from localstream.Config import (
    config_exists, load_config, save_config, get_default_config,
    list_profiles, get_active_profile_name, switch_profile,
    create_profile, update_profile, clone_profile, delete_profile,
    is_profile_locked, create_profile_with_lock, get_last_successful_profile, set_last_successful_profile
)
from localstream.ConfigFile import export_config, import_config, is_valid_local_file
from localstream.DnsChecker import run_dns_checker, run_profile_dns_checker
from localstream.IpChecker import run_ip_checker
from localstream.SingBox import extract_link_server, is_singbox_tunnel
from localstream.Connection import ConnectionManager, is_admin
from localstream.Downloader import (
    client_exists, download_client, tun2proxy_exists, download_tun2proxy,
    privoxy_exists, download_privoxy, dnstt_exists, pingtunnel_exists, doh_proxy_exists, singbox_exists, is_windows, is_linux
)
from localstream.Speedtest import run_speedtest
from localstream.Autostart import enable_autostart, disable_autostart, is_autostart_enabled


CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
MAGENTA = "\033[95m"
BLUE = "\033[94m"
WHITE = "\033[97m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


LOGO = f"""
{CYAN}╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║  {MAGENTA}██╗      ██████╗  ██████╗ █████╗ ██╗     {CYAN}                    ║
║  {MAGENTA}██║     ██╔═══██╗██╔════╝██╔══██╗██║     {CYAN}                    ║
║  {MAGENTA}██║     ██║   ██║██║     ███████║██║     {CYAN}                    ║
║  {MAGENTA}██║     ██║   ██║██║     ██╔══██║██║     {CYAN}                    ║
║  {MAGENTA}███████╗╚██████╔╝╚██████╗██║  ██║███████╗{CYAN}                    ║
║  {MAGENTA}╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝{CYAN}                    ║
║                                                               ║
║  {BLUE}███████╗████████╗██████╗ ███████╗ █████╗ ███╗   ███╗{CYAN}         ║
║  {BLUE}██╔════╝╚══██╔══╝██╔══██╗██╔════╝██╔══██╗████╗ ████║{CYAN}         ║
║  {BLUE}███████╗   ██║   ██████╔╝█████╗  ███████║██╔████╔██║{CYAN}         ║
║  {BLUE}╚════██║   ██║   ██╔══██╗██╔══╝  ██╔══██║██║╚██╔╝██║{CYAN}         ║
║  {BLUE}███████║   ██║   ██║  ██║███████╗██║  ██║██║ ╚═╝ ██║{CYAN}         ║
║  {BLUE}╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝{CYAN}         ║
║                                                               ║
║  {DIM}SlipStream | DNSTT | PingTunnel | DoH • Python CLI Client{CYAN}    ║
╚═══════════════════════════════════════════════════════════════╝{RESET}
"""

MINI_LOGO = f"""
{CYAN}╔═══════════════════════════════════════════╗
║  {MAGENTA}LocalStream{CYAN} • {DIM}SlipStream CLI Client{CYAN}      ║
╚═══════════════════════════════════════════╝{RESET}
"""


def clear_screen():
    return


def print_logo(mini: bool = False):
    if mini:
        print(MINI_LOGO)
    else:
        print(LOGO)


import re

def strip_ansi(text: str) -> str:
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)


def print_box(title: str, content: list, color: str = CYAN):
    visible_title_len = len(strip_ansi(title))
    max_len = 0
    if content:
        max_len = max(len(strip_ansi(line)) for line in content)

    max_len = max(max_len, visible_title_len + 4)
    width = max_len + 4

    print(f"\n{color}┌{'─' * width}┐{RESET}")
    padding_title = width - visible_title_len - 2
    print(f"{color}│{RESET}  {BOLD}{title}{RESET}{' ' * padding_title}{color}│{RESET}")
    print(f"{color}├{'─' * width}┤{RESET}")

    for line in content:
        visible_len = len(strip_ansi(line))
        padding = width - visible_len - 2
        print(f"{color}│{RESET}  {line}{' ' * padding}{color}│{RESET}")

    print(f"{color}└{'─' * width}┘{RESET}")


def print_config(config: dict):
    active_profile = get_active_profile_name()
    is_locked = is_profile_locked()
    admin_status = f"{GREEN}✓ Admin{RESET}" if is_admin() else f"{YELLOW}○ User{RESET}"

    if is_locked:
        server = f"{YELLOW}●●●●●●●●{RESET}"
        domain = f"{YELLOW}●●●●●●●●{RESET}"
        lock_badge = f" {RED}[LOCKED]{RESET}"
    else:
        server = f"{config.get('server_ip', 'N/A')}:{config.get('server_port', 53)}"
        domain = config.get('domain', 'N/A')
        lock_badge = ""

    content = [
        f"{GREEN}●{RESET} Profile    : {WHITE}{active_profile}{RESET}{lock_badge}",
        f"{GREEN}●{RESET} Server     : {WHITE}{server}{RESET}",
        f"{GREEN}●{RESET} Domain     : {WHITE}{domain}{RESET}",
        f"{GREEN}●{RESET} Local Port : {WHITE}{config.get('local_port', 5201)}{RESET}",
        f"{DIM}─────────────────────────────────{RESET}",
        f"{BLUE}●{RESET} Status     : {admin_status}",
    ]
    print_box("Current Configuration", content, CYAN)


def get_input(prompt: str, default: str = "") -> str:
    if default:
        result = input(f"  {GREEN}▸{RESET} {prompt} {DIM}[{default}]{RESET}: ").strip()
        return result if result else default
    return input(f"  {GREEN}▸{RESET} {prompt}: ").strip()


def get_int_input(prompt: str, default: int) -> int:
    while True:
        result = input(f"  {GREEN}▸{RESET} {prompt} {DIM}[{default}]{RESET}: ").strip()
        if not result:
            return default
        try:
            return int(result)
        except ValueError:
            print(f"  {RED}✗{RESET} Please enter a valid number")


def prompt_for_config(tunnel_type="slipstream") -> dict:
    existing = load_config()
    config = {**get_default_config(), **existing}
    config["tunnel_type"] = tunnel_type

    if tunnel_type == "slipstream":
        print(f"\n{YELLOW}━━━ SlipStream Configuration ━━━{RESET}\n")
        config["server_ip"] = get_input("Server IP", existing.get("server_ip"))
        while not config["server_ip"]:
            print(f"  {RED}✗{RESET} Server IP is required")
            config["server_ip"] = get_input("Server IP")

        config["server_port"] = get_int_input("Server Port", existing.get("server_port", 53))
        config["local_port"] = get_int_input("Local Port", existing.get("local_port", 5201))

        config["domain"] = get_input("Domain", existing.get("domain"))
        while not config["domain"]:
            print(f"  {RED}✗{RESET} Domain is required")
            config["domain"] = get_input("Domain")

    elif tunnel_type == "doh":
        print(f"\n{YELLOW}━━━ DoH Configuration ━━━{RESET}\n")
        config["server_ip"] = get_input("Tunnel Server IP", existing.get("server_ip"))
        while not config["server_ip"]:
            print(f"  {RED}✗{RESET} Tunnel Server IP is required")
            config["server_ip"] = get_input("Tunnel Server IP")

        config["server_port"] = get_int_input("Tunnel Server Port", existing.get("server_port", 53))
        config["local_port"] = get_int_input("Local Port", existing.get("local_port", 5201))

        config["domain"] = get_input("Domain", existing.get("domain"))
        while not config["domain"]:
            print(f"  {RED}✗{RESET} Domain is required")
            config["domain"] = get_input("Domain")

        config["doh_url"] = get_input("DoH URL", existing.get("doh_url", "https://1.1.1.1/dns-query"))
        while not config["doh_url"]:
            print(f"  {RED}✗{RESET} DoH URL is required")
            config["doh_url"] = get_input("DoH URL")

        config["doh_local_dns_port"] = get_int_input("Local DNS Port", existing.get("doh_local_dns_port", 5300))
        config["doh_bootstrap_ip"] = get_input("DoH Bootstrap IP (optional)", existing.get("doh_bootstrap_ip", ""))
        config["doh_sni"] = get_input("DoH SNI (optional)", existing.get("doh_sni", ""))

    elif tunnel_type in ["vless", "vmess", "trojan", "shadowsocks"]:
        print(f"\n{YELLOW}??? Sing-box {tunnel_type.upper()} Configuration ???{RESET}\n")
        config["singbox_uri"] = get_input("Protocol Link", existing.get("singbox_uri", ""))
        while not config["singbox_uri"]:
            print(f"  {RED}?{RESET} Protocol Link is required")
            config["singbox_uri"] = get_input("Protocol Link")
        try:
            host, port, _ = extract_link_server(config["singbox_uri"], tunnel_type=tunnel_type)
            config["server_ip"] = host
            config["server_port"] = port
        except Exception:
            pass

    elif tunnel_type == "dnstt":
        print(f"\n{YELLOW}━━━ DNSTT Configuration ━━━{RESET}\n")
        config["server_ip"] = get_input("DNS Server IP", existing.get("server_ip", "8.8.8.8"))
        while not config["server_ip"]:
            print(f"  {RED}✗{RESET} DNS Server IP is required")
            config["server_ip"] = get_input("DNS Server IP")

        config["domain"] = get_input("Domain", existing.get("domain"))
        while not config["domain"]:
            print(f"  {RED}✗{RESET} Domain is required")
            config["domain"] = get_input("Domain")

        config["dnstt_pubkey"] = get_input("Public Key", existing.get("dnstt_pubkey"))
        while not config["dnstt_pubkey"]:
            print(f"  {RED}✗{RESET} Public Key is required")
            config["dnstt_pubkey"] = get_input("Public Key")

        config["ssh_host"] = get_input("SSH Host", existing.get("ssh_host", "127.0.0.1"))
        config["ssh_port"] = get_int_input("SSH Port", existing.get("ssh_port", 22))

        config["ssh_user"] = get_input("SSH Username", existing.get("ssh_user"))
        while not config["ssh_user"]:
            print(f"  {RED}✗{RESET} SSH Username is required")
            config["ssh_user"] = get_input("SSH Username")

        config["ssh_pass"] = get_input("SSH Password", existing.get("ssh_pass"))
        while not config["ssh_pass"]:
            print(f"  {RED}✗{RESET} SSH Password is required")
            config["ssh_pass"] = get_input("SSH Password")

        config["local_port"] = get_int_input("Local Port (for SOCKS)", existing.get("local_port", 5201))

    elif tunnel_type == "pingtunnel":
        print(f"\n{YELLOW}━━━ Ping Tunnel Configuration ━━━{RESET}\n")
        config["server_ip"] = get_input("Server IP", existing.get("server_ip"))
        while not config["server_ip"]:
            print(f"  {RED}✗{RESET} Server IP is required")
            config["server_ip"] = get_input("Server IP")

        config["pingtunnel_key"] = get_int_input("ICMP Key (0-2147483647)", existing.get("pingtunnel_key", 0))
        config["local_port"] = get_int_input("Local Port (for SOCKS)", existing.get("local_port", 5201))

    return config


def print_connecting_banner(config: dict, mode: str):
    is_locked = is_profile_locked()
    tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()

    if is_locked:
        server = f"{YELLOW}●●●●●●●●{RESET}"
        domain = f"{YELLOW}●●●●●●●●{RESET}"
    else:
        if is_singbox_tunnel(tunnel_type):
            try:
                host, port, _ = extract_link_server(config.get("singbox_uri", ""), tunnel_type=tunnel_type)
                server = f"{host}:{port}"
            except Exception:
                server = f"{config.get('server_ip', '0.0.0.0')}:{config.get('server_port', 0)}"
        else:
            server = f"{config.get('server_ip', '0.0.0.0')}:{config.get('server_port', 0)}"
        domain = config.get('domain', '')
    local_port = str(config.get('local_port', 5201))

    if mode == "vpn":
        mode_display = f"{GREEN}VPN{RESET}"
    elif mode == "system":
        mode_display = f"{MAGENTA}SYSTEM{RESET}"
    else:
        mode_display = f"{BLUE}PROXY{RESET}"

    width = 55

    def print_line(content):
        visible_len = len(strip_ansi(content))
        padding = width - visible_len
        print(f"{CYAN}║{RESET}  {content}{' ' * (padding - 4)}{CYAN}║{RESET}")

    print(f"\n{CYAN}╔{'═' * (width - 2)}╗{RESET}")

    header = f"{GREEN}●{RESET} {BOLD}Connecting in {mode_display} Mode...{RESET}"
    print_line(header)

    print(f"{CYAN}╟{'─' * (width - 2)}╢{RESET}")

    print_line(f"Resolver   : {WHITE}{server}{RESET}")
    print_line(f"Domain     : {WHITE}{domain}{RESET}")
    print_line(f"Local Port : {WHITE}{local_port}{RESET}")

    print(f"{CYAN}╟{'─' * (width - 2)}╢{RESET}")

    print_line(f"{DIM}Press Ctrl+C to disconnect • Ctrl+D to restart{RESET}")

    print(f"{CYAN}╚{'═' * (width - 2)}╝{RESET}\n")


def build_failover_candidates(config: dict) -> list:
    active = get_active_profile_name()
    methods = config.get("failover_methods", []) if config.get("enable_failover", False) else []
    profiles = config.get("failover_profiles", []) if config.get("enable_failover", False) else []

    valid_methods = [
        m
        for m in methods
        if m in ["slipstream", "doh", "dnstt", "pingtunnel", "vless", "vmess", "trojan", "shadowsocks"]
    ]
    if not valid_methods:
        valid_methods = [config.get("tunnel_type", "slipstream")]

    candidates = [(active, dict(config))]
    for method in valid_methods:
        cfg = dict(config)
        cfg["tunnel_type"] = method
        candidates.append((active, cfg))

    current_active = active
    for profile in profiles:
        if not switch_profile(profile):
            continue
        profile_cfg = load_config()
        if current_active:
            switch_profile(current_active)
        candidates.append((profile, dict(profile_cfg)))
        for method in valid_methods:
            cfg = dict(profile_cfg)
            cfg["tunnel_type"] = method
            candidates.append((profile, cfg))

    unique = []
    seen = set()
    for profile, cfg in candidates:
        key = (
            profile,
            cfg.get("tunnel_type", "slipstream"),
            cfg.get("server_ip", ""),
            cfg.get("domain", ""),
            cfg.get("singbox_uri", ""),
        )
        if key in seen:
            continue
        seen.add(key)
        unique.append((profile, cfg))
    return unique


def handle_connection(config: dict, mode: str):
    while True:
        restart_requested = False
        connected = False

        for profile_name, candidate in build_failover_candidates(config):
            switch_profile(profile_name)
            clear_screen()
            print_logo(mini=True)
            print_connecting_banner(candidate, mode)

            manager = ConnectionManager()

            if mode == "vpn":
                result = manager.connect_vpn(candidate)
            elif mode == "system":
                result = manager.connect_system_proxy(candidate)
            else:
                result = manager.connect_proxy(candidate)

            if result == "restart":
                restart_requested = True
                break
            if result == "done":
                set_last_successful_profile(profile_name)
                connected = True
                break

        if restart_requested:
            print(f"\n{YELLOW}⟳{RESET} Restarting connection...")
            continue
        if connected:
            break
        if config.get("enable_failover", False):
            print(f"\n  {RED}✗{RESET} All failover attempts failed")
            time.sleep(2)
        break


def handle_profiles():
    while True:
        clear_screen()
        print_logo(mini=True)

        profiles = list_profiles()
        active = get_active_profile_name()

        print(f"\n{YELLOW}━━━ Profile Management ━━━{RESET}\n")

        for i, name in enumerate(profiles, 1):
            status = f"{GREEN}●{RESET}" if name == active else "○"
            locked = is_profile_locked(name)
            if name != active:
                switch_profile(name)
            cfg = load_config()
            label = cfg.get("profile_label", "").strip()
            label_text = f" {DIM}[{label}]{RESET}" if label else ""
            lock_badge = f" {RED}[LOCKED]{RESET}" if locked else ""
            print(f"  {status} {i}. {name}{label_text}{lock_badge}")

        if active:
            switch_profile(active)

        print(f"\n{DIM}─────────────────────────────────{RESET}")
        print(f"  {YELLOW}[S]{RESET} Switch Profile")
        print(f"  {YELLOW}[Q]{RESET} Quick Connect Profile")
        print(f"  {YELLOW}[N]{RESET} New Profile")
        print(f"  {YELLOW}[C]{RESET} Clone Profile")
        print(f"  {YELLOW}[L]{RESET} Set Profile Label")
        print(f"  {YELLOW}[D]{RESET} Delete Profile")
        print(f"  {YELLOW}[I]{RESET} Import Config (.local)")
        print(f"  {YELLOW}[E]{RESET} Export Config (.local)")
        print(f"  {YELLOW}[B]{RESET} Back")

        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip().lower()

        if choice == 'b':
            break

        if choice == 's':
            name = get_input("Profile Name")
            if switch_profile(name):
                print(f"  {GREEN}✓{RESET} Switched to {name}")
            else:
                print(f"  {RED}✗{RESET} Profile not found")
            time.sleep(1)

        elif choice == 'q':
            quick = get_last_successful_profile()
            if quick and switch_profile(quick):
                print(f"  {GREEN}✓{RESET} Quick connected profile: {quick}")
            else:
                print(f"  {YELLOW}!{RESET} No quick-connect profile available")
            time.sleep(1)

        elif choice == 'n':
            print(f"\n{YELLOW}--- New Profile ---{RESET}\n")
            print(f"  {YELLOW}[1]{RESET} SlipStream")
            print(f"  {YELLOW}[2]{RESET} DNSTT")
            print(f"  {YELLOW}[3]{RESET} Ping Tunnel")
            print(f"  {YELLOW}[4]{RESET} DoH")
            print(f"  {YELLOW}[5]{RESET} VLESS (sing-box)")
            print(f"  {YELLOW}[6]{RESET} VMESS (sing-box)")
            print(f"  {YELLOW}[7]{RESET} TROJAN (sing-box)")
            print(f"  {YELLOW}[8]{RESET} SHADOWSOCKS (sing-box)")

            type_choice = input(f"\n  {MAGENTA}>{RESET} Select type [1-8]: ").strip()
            if type_choice not in ['1', '2', '3', '4', '5', '6', '7', '8']:
                print(f"  {RED}x{RESET} Invalid type")
                time.sleep(1)
                continue

            if type_choice == '1':
                tunnel_type = "slipstream"
            elif type_choice == '2':
                tunnel_type = "dnstt"
            elif type_choice == '3':
                tunnel_type = "pingtunnel"
            elif type_choice == '4':
                tunnel_type = "doh"
            elif type_choice == '5':
                tunnel_type = "vless"
            elif type_choice == '6':
                tunnel_type = "vmess"
            elif type_choice == '7':
                tunnel_type = "trojan"
            else:
                tunnel_type = "shadowsocks"

            name = get_input("New Profile Name")
            if name in profiles:
                print(f"  {RED}✗{RESET} Profile exists")
                time.sleep(1)
                continue

            config = prompt_for_config(tunnel_type)
            label = get_input("Profile Label (optional)", "")
            config["profile_label"] = label
            create_profile(name, config)
            switch_profile(name)
            print(f"  {GREEN}✓{RESET} Profile created and selected")
            time.sleep(1)

        elif choice == 'c':
            source = get_input("Source profile")
            target = get_input("New cloned profile name")
            if not source or not target:
                print(f"  {RED}✗{RESET} Source and target are required")
            elif clone_profile(source, target):
                print(f"  {GREEN}✓{RESET} Cloned '{source}' into '{target}'")
            else:
                print(f"  {RED}✗{RESET} Clone failed")
            time.sleep(1)

        elif choice == 'l':
            target = get_input("Profile name")
            if target not in profiles:
                print(f"  {RED}✗{RESET} Profile not found")
                time.sleep(1)
                continue
            current_active = get_active_profile_name()
            switch_profile(target)
            cfg = load_config()
            cfg["profile_label"] = get_input("Label", cfg.get("profile_label", ""))
            save_config(cfg)
            if current_active:
                switch_profile(current_active)
            print(f"  {GREEN}✓{RESET} Label updated")
            time.sleep(1)

        elif choice == 'd':
            name = get_input("Profile to delete")
            if delete_profile(name):
                print(f"  {GREEN}✓{RESET} Deleted {name}")
            else:
                print(f"  {RED}✗{RESET} Cannot delete {name}")
            time.sleep(1)

        elif choice == 'i':
            handle_import_config()

        elif choice == 'e':
            handle_export_config()

def handle_import_config():
    from pathlib import Path

    print(f"\n{YELLOW}━━━ Import Config ━━━{RESET}\n")

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)

        file_path = filedialog.askopenfilename(
            title="Select LocalStream Config File",
            filetypes=[("LocalStream Config", "*.local"), ("All Files", "*.*")],
            initialdir=Path.home(),
        )
        root.destroy()

        if not file_path:
            print(f"  {YELLOW}!{RESET} No file selected")
            time.sleep(1)
            return

    except Exception:
        print(f"  {YELLOW}!{RESET} File picker not available")
        file_path = get_input("Enter file path")
        if not file_path:
            return

    file_path = Path(file_path)

    if file_path.suffix.lower() != ".local":
        print(f"  {RED}✗{RESET} File must have .local extension")
        time.sleep(1)
        return

    if not file_path.exists():
        print(f"  {RED}✗{RESET} File not found")
        time.sleep(2)
        return

    if not is_valid_local_file(file_path):
        print(f"  {RED}✗{RESET} Invalid LocalStream config file")
        time.sleep(2)
        return

    config, is_locked, error = import_config(file_path)

    if error:
        print(f"  {RED}✗{RESET} Import failed: {error}")
        time.sleep(2)
        return

    profile_name = get_input("Profile name for imported config", file_path.stem)
    existing_profiles = list_profiles()

    if profile_name in existing_profiles:
        print(f"\n  {YELLOW}[1]{RESET} Replace")
        print(f"  {YELLOW}[2]{RESET} Rename")
        print(f"  {YELLOW}[3]{RESET} Merge")
        mode = input(f"\n  {MAGENTA}▸{RESET} Conflict mode [1-3]: ").strip()

        if mode == "1":
            pass
        elif mode == "2":
            base = profile_name
            counter = 1
            while profile_name in existing_profiles:
                profile_name = f"{base} ({counter})"
                counter += 1
        elif mode == "3":
            current_active = get_active_profile_name()
            switch_profile(profile_name)
            existing = load_config()
            merged = {**existing, **config}
            create_profile_with_lock(profile_name, merged, is_locked)
            switch_profile(profile_name)
            lock_status = f"{RED}[LOCKED]{RESET}" if is_locked else f"{GREEN}[UNLOCKED]{RESET}"
            print(f"  {GREEN}✓{RESET} Imported (merged): {profile_name} {lock_status}")
            time.sleep(2)
            return
        else:
            print(f"  {YELLOW}!{RESET} Import cancelled")
            time.sleep(1)
            return

    create_profile_with_lock(profile_name, config, is_locked)
    switch_profile(profile_name)

    lock_status = f"{RED}[LOCKED]{RESET}" if is_locked else f"{GREEN}[UNLOCKED]{RESET}"
    print(f"  {GREEN}✓{RESET} Imported: {profile_name} {lock_status}")
    time.sleep(2)

def handle_export_config():
    from pathlib import Path

    print(f"\n{YELLOW}━━━ Export Config ━━━{RESET}\n")

    if is_profile_locked():
        print(f"  {RED}✗{RESET} Cannot export a locked profile")
        time.sleep(2)
        return

    config = load_config()
    active = get_active_profile_name()

    lock_choice = get_input("Lock config? (y/n)", "n")
    is_locked = lock_choice.lower() == 'y'

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)

        file_path = filedialog.asksaveasfilename(
            title="Save LocalStream Config",
            defaultextension=".local",
            filetypes=[("LocalStream Config", "*.local")],
            initialfile=f"{active}.local",
            initialdir=Path.home(),
        )
        root.destroy()

        if not file_path:
            print(f"  {YELLOW}!{RESET} Export cancelled")
            time.sleep(1)
            return

    except Exception:
        print(f"  {YELLOW}!{RESET} File picker not available")
        file_path = get_input("Enter save path", f"{active}.local")
        if not file_path:
            return

    file_path = Path(file_path)
    if file_path.suffix.lower() != ".local":
        file_path = file_path.with_suffix(".local")

    if export_config(config, file_path, is_locked, None, active, "1.0.9"):
        lock_status = f"{RED}[LOCKED]{RESET}" if is_locked else f"{GREEN}[UNLOCKED]{RESET}"
        print(f"  {GREEN}✓{RESET} Exported: {file_path.name} {lock_status}")
    else:
        print(f"  {RED}✗{RESET} Export failed")

    time.sleep(2)

def handle_connection_doctor():
    config = load_config()
    checks = [
        f"Profile      : {WHITE}{get_active_profile_name()}{RESET}",
        f"Tunnel Type  : {WHITE}{config.get('tunnel_type', 'slipstream')}{RESET}",
        f"Admin        : {GREEN}YES{RESET}" if is_admin() else f"Admin        : {RED}NO{RESET}",
        f"Client Bin   : {GREEN}OK{RESET}" if client_exists() else f"Client Bin   : {RED}MISSING{RESET}",
        f"tun2proxy    : {GREEN}OK{RESET}" if tun2proxy_exists() else f"tun2proxy    : {RED}MISSING{RESET}",
        f"Privoxy      : {GREEN}OK{RESET}" if privoxy_exists() else f"Privoxy      : {RED}MISSING{RESET}",
        f"DNSTT        : {GREEN}OK{RESET}" if dnstt_exists() else f"DNSTT        : {RED}MISSING{RESET}",
        f"PingTunnel   : {GREEN}OK{RESET}" if pingtunnel_exists() else f"PingTunnel   : {RED}MISSING{RESET}",
        f"DoH Proxy    : {GREEN}OK{RESET}" if doh_proxy_exists() else f"DoH Proxy    : {RED}MISSING{RESET}",
        f"SingBox      : {GREEN}OK{RESET}" if singbox_exists() else f"SingBox      : {RED}MISSING{RESET}",
        f"Server IP    : {WHITE}{config.get('server_ip', '') or 'N/A'}{RESET}",
        f"Domain       : {WHITE}{config.get('domain', '') or 'N/A'}{RESET}",
    ]
    print_box("Connection Doctor", checks, CYAN)


def handle_tools():
    while True:
        clear_screen()
        print_logo(mini=True)
        
        content = [
            f"{YELLOW}[1]{RESET} Speed Test",
            f"{YELLOW}[2]{RESET} Connection Doctor",
            f"{YELLOW}[3]{RESET} Back"
        ]
        print_box("Tools", content, BLUE)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()
        
        if choice == '1':
            config = load_config()
            port = config.get("local_port", 5201)
            print(f"\n  {YELLOW}!{RESET} Ensure you are connected in another terminal!")
            input(f"  {DIM}Press Enter to start test...{RESET}")
            result = run_speedtest(proxy_port=port, verbose=True)
            if result.get("success"):
                metrics = [
                    f"Latency Avg : {WHITE}{result.get('latency_avg_ms', 0):.1f}{RESET} ms",
                    f"Latency Min : {WHITE}{result.get('latency_min_ms', 0):.1f}{RESET} ms",
                    f"Latency Max : {WHITE}{result.get('latency_max_ms', 0):.1f}{RESET} ms",
                    f"Jitter      : {WHITE}{result.get('jitter_ms', 0):.1f}{RESET} ms",
                    f"Packet Loss : {WHITE}{result.get('packet_loss_pct', 0):.1f}{RESET}%",
                    f"Download    : {WHITE}{result.get('download_mbps', 0):.2f}{RESET} Mbps",
                ]
                print_box("Speed Test Result", metrics, CYAN)
            else:
                print(f"  {RED}✗{RESET} Speed test failed: {result.get('error', 'unknown error')}")
            input(f"\n  {DIM}Press Enter to continue...{RESET}")
        elif choice == '2':
            handle_connection_doctor()
            input(f"\n  {DIM}Press Enter to continue...{RESET}")
        elif choice == '3':
            break


def handle_advanced_settings():
    while True:
        clear_screen()
        print_logo(mini=True)
        
        config = load_config()
        
        keep_alive = config.get("keep_alive_interval", 200)
        congestion = config.get("congestion_control", "bbr").upper()
        gso_status = f"{GREEN}ON{RESET}" if config.get("enable_gso", False) else f"{RED}OFF{RESET}"
        frag_status = f"{GREEN}ON{RESET}" if config.get("enable_fragmentation", False) else f"{RED}OFF{RESET}"
        frag_size = config.get("fragment_size", 77)
        frag_delay = config.get("fragment_delay", 200)
        auto_restart = config.get("auto_restart_minutes", 0)
        auto_restart_str = f"{WHITE}{auto_restart}{RESET} min" if auto_restart > 0 else f"{RED}OFF{RESET}"
        
        content = [
            f"{YELLOW}[1]{RESET} Keep-Alive Interval: {WHITE}{keep_alive}{RESET} ms",
            f"{YELLOW}[2]{RESET} Congestion Control: {WHITE}{congestion}{RESET}",
            f"{YELLOW}[3]{RESET} GSO (Segmentation Offload): {gso_status}",
            f"{DIM}─────────────────────────────────{RESET}",
            f"{YELLOW}[4]{RESET} TLS Fragmentation: {frag_status}",
            f"{YELLOW}[5]{RESET} Fragment Size: {WHITE}{frag_size}{RESET} bytes",
            f"{YELLOW}[6]{RESET} Fragment Delay: {WHITE}{frag_delay}{RESET} ms",
            f"{DIM}─────────────────────────────────{RESET}",
            f"{YELLOW}[7]{RESET} Auto Restart: {auto_restart_str}",
            f"{DIM}─────────────────────────────────{RESET}",
            f"{YELLOW}[8]{RESET} Back"
        ]
        print_box("Advanced Settings", content, MAGENTA)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()
        
        if choice == '1':
            new_interval = get_int_input("Keep-Alive Interval (ms)", config.get("keep_alive_interval", 200))
            if 50 <= new_interval <= 5000:
                config["keep_alive_interval"] = new_interval
                save_config(config)
                print(f"\n  {GREEN}✓{RESET} Keep-alive interval set to {new_interval}ms")
            else:
                print(f"\n  {RED}✗{RESET} Interval must be between 50 and 5000")
            time.sleep(1)
            
        elif choice == '2':
            print(f"\n{YELLOW}━━━ Congestion Control Algorithm ━━━{RESET}\n")
            print(f"  {YELLOW}[1]{RESET} BBR (recommended)")
            print(f"  {YELLOW}[2]{RESET} Cubic")
            cc_choice = input(f"\n  {MAGENTA}▸{RESET} Select: ").strip()
            if cc_choice == '1':
                config["congestion_control"] = "bbr"
            elif cc_choice == '2':
                config["congestion_control"] = "cubic"
            save_config(config)
            print(f"\n  {GREEN}✓{RESET} Congestion control set to {config['congestion_control'].upper()}")
            time.sleep(1)
        
        elif choice == '3':
            config["enable_gso"] = not config.get("enable_gso", False)
            save_config(config)
            status = "enabled" if config["enable_gso"] else "disabled"
            print(f"\n  {GREEN}✓{RESET} GSO {status}")
            time.sleep(1)
        
        elif choice == '4':
            config["enable_fragmentation"] = not config.get("enable_fragmentation", False)
            save_config(config)
            status = "enabled" if config["enable_fragmentation"] else "disabled"
            print(f"\n  {GREEN}✓{RESET} TLS Fragmentation {status}")
            time.sleep(1)
        
        elif choice == '5':
            new_size = get_int_input("Fragment Size (bytes)", config.get("fragment_size", 77))
            if 10 <= new_size <= 500:
                config["fragment_size"] = new_size
                save_config(config)
                print(f"\n  {GREEN}✓{RESET} Fragment size set to {new_size} bytes")
            else:
                print(f"\n  {RED}✗{RESET} Size must be between 10 and 500")
            time.sleep(1)
        
        elif choice == '6':
            new_delay = get_int_input("Fragment Delay (ms)", config.get("fragment_delay", 200))
            if 10 <= new_delay <= 1000:
                config["fragment_delay"] = new_delay
                save_config(config)
                print(f"\n  {GREEN}✓{RESET} Fragment delay set to {new_delay}ms")
            else:
                print(f"\n  {RED}✗{RESET} Delay must be between 10 and 1000")
            time.sleep(1)
        
        elif choice == '7':
            new_restart = get_int_input("Auto Restart (minutes, 0=off)", config.get("auto_restart_minutes", 0))
            if 0 <= new_restart <= 60:
                config["auto_restart_minutes"] = new_restart
                save_config(config)
                if new_restart > 0:
                    print(f"\n  {GREEN}✓{RESET} Auto restart set to every {new_restart} minutes")
                else:
                    print(f"\n  {GREEN}✓{RESET} Auto restart disabled")
            else:
                print(f"\n  {RED}✗{RESET} Must be between 0 and 60")
            time.sleep(1)
            
        elif choice == '8':
            break


def handle_feature_controls():
    while True:
        clear_screen()
        print_logo(mini=True)

        config = load_config()
        failover_status = f"{GREEN}ON{RESET}" if config.get("enable_failover", False) else f"{RED}OFF{RESET}"
        split_status = f"{GREEN}ON{RESET}" if config.get("split_tunnel_enabled", False) else f"{RED}OFF{RESET}"
        kill_status = f"{GREEN}ON{RESET}" if config.get("kill_switch_enabled", False) else f"{RED}OFF{RESET}"
        dns_guard = f"{GREEN}ON{RESET}" if config.get("dns_leak_guard_enabled", False) else f"{RED}OFF{RESET}"
        methods = ",".join(config.get("failover_methods", [])) or "-"
        profiles = ",".join(config.get("failover_profiles", [])) or "-"

        content = [
            f"{YELLOW}[1]{RESET} Enable Failover: {failover_status}",
            f"{YELLOW}[2]{RESET} Failover Profiles: {WHITE}{profiles}{RESET}",
            f"{YELLOW}[3]{RESET} Failover Methods: {WHITE}{methods}{RESET}",
            f"{YELLOW}[4]{RESET} Failover Timeout: {WHITE}{config.get('failover_timeout_seconds', 8)}{RESET} sec",
            f"{DIM}─────────────────────────────────{RESET}",
            f"{YELLOW}[5]{RESET} Split Tunneling: {split_status}",
            f"{YELLOW}[6]{RESET} Split Include List: {WHITE}{config.get('split_include_list', '') or '-'}{RESET}",
            f"{YELLOW}[7]{RESET} Kill Switch: {kill_status}",
            f"{YELLOW}[8]{RESET} DNS Leak Guard: {dns_guard}",
            f"{DIM}─────────────────────────────────{RESET}",
            f"{YELLOW}[9]{RESET} Back",
        ]
        print_box("Feature Controls", content, MAGENTA)

        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()

        if choice == "1":
            config["enable_failover"] = not config.get("enable_failover", False)
        elif choice == "2":
            value = get_input("Failover Profiles (comma-separated)", ",".join(config.get("failover_profiles", [])))
            config["failover_profiles"] = [x.strip() for x in value.split(",") if x.strip()]
        elif choice == "3":
            value = get_input(
                "Failover Methods (slipstream,doh,dnstt,pingtunnel,vless,vmess,trojan,shadowsocks)",
                ",".join(config.get("failover_methods", [])),
            )
            methods = [x.strip().lower() for x in value.split(",") if x.strip()]
            config["failover_methods"] = [
                m
                for m in methods
                if m in ["slipstream", "doh", "dnstt", "pingtunnel", "vless", "vmess", "trojan", "shadowsocks"]
            ]
        elif choice == "4":
            timeout = get_int_input("Failover Timeout (sec)", config.get("failover_timeout_seconds", 8))
            config["failover_timeout_seconds"] = max(1, timeout)
        elif choice == "5":
            config["split_tunnel_enabled"] = not config.get("split_tunnel_enabled", False)
        elif choice == "6":
            config["split_include_list"] = get_input("Split Include List", config.get("split_include_list", ""))
        elif choice == "7":
            config["kill_switch_enabled"] = not config.get("kill_switch_enabled", False)
        elif choice == "8":
            config["dns_leak_guard_enabled"] = not config.get("dns_leak_guard_enabled", False)
        elif choice == "9":
            break
        else:
            continue

        save_config(config)


def handle_settings():
    while True:
        clear_screen()
        print_logo(mini=True)

        config = load_config()
        theme = config.get("ui_theme", "dark")
        update_channel = config.get("update_channel", "stable")

        if is_windows():
            autostart_status = f"{GREEN}ON{RESET}" if is_autostart_enabled() else f"{RED}OFF{RESET}"
            content = [
                f"{YELLOW}[1]{RESET} Edit Configuration",
                f"{YELLOW}[2]{RESET} Advanced Settings",
                f"{YELLOW}[3]{RESET} Feature Controls",
                f"{YELLOW}[4]{RESET} Theme: {WHITE}{theme.upper()}{RESET}",
                f"{YELLOW}[5]{RESET} Update Channel: {WHITE}{update_channel.upper()}{RESET}",
                f"{YELLOW}[6]{RESET} Auto-start: {autostart_status}",
                f"{YELLOW}[7]{RESET} Back",
            ]
        else:
            content = [
                f"{YELLOW}[1]{RESET} Edit Configuration",
                f"{YELLOW}[2]{RESET} Advanced Settings",
                f"{YELLOW}[3]{RESET} Feature Controls",
                f"{YELLOW}[4]{RESET} Theme: {WHITE}{theme.upper()}{RESET}",
                f"{YELLOW}[5]{RESET} Update Channel: {WHITE}{update_channel.upper()}{RESET}",
                f"{YELLOW}[6]{RESET} Back",
            ]

        print_box("Settings", content, BLUE)
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()

        if choice == '1':
            if is_profile_locked():
                print(f"\n  {RED}✗{RESET} Cannot edit a locked profile")
                time.sleep(2)
                continue
            config = prompt_for_config(config.get("tunnel_type", "slipstream"))
            save_config(config)
            print(f"\n  {GREEN}✓{RESET} Saved")
            time.sleep(1)
        elif choice == '2':
            handle_advanced_settings()
        elif choice == '3':
            handle_feature_controls()
        elif choice == '4':
            config["ui_theme"] = "light" if theme == "dark" else "dark"
            save_config(config)
            print(f"\n  {GREEN}✓{RESET} Theme set to {config['ui_theme']}")
            time.sleep(1)
        elif choice == '5':
            config["update_channel"] = "beta" if update_channel == "stable" else "stable"
            save_config(config)
            print(f"\n  {GREEN}✓{RESET} Update channel set to {config['update_channel']}")
            time.sleep(1)
        elif choice == '6' and is_windows():
            if is_autostart_enabled():
                disable_autostart()
            else:
                enable_autostart()
        elif choice == '7' and is_windows():
            break
        elif choice == '6' and not is_windows():
            break

def handle_dns_checker():
    while True:
        clear_screen()
        print_logo(mini=True)

        content = [
            f"{YELLOW}[1]{RESET} Normal DNS Test",
            f"{YELLOW}[2]{RESET} Profile-based DNS Test",
            f"{YELLOW}[B]{RESET} Back to Menu"
        ]
        print_box("DNS Checker", content, MAGENTA)

        choice = input(f"\n  {MAGENTA}>{RESET} Select option: ").strip().lower()

        if choice == 'b':
            break

        if choice == '1':
            clear_screen()
            print_logo(mini=True)
            content = [
                f"Enter a DNS server IP to check connectivity.",
                f"Example: {YELLOW}8.8.8.8{RESET}, {YELLOW}1.1.1.1{RESET}",
                "",
                f"{YELLOW}[B]{RESET} Back"
            ]
            print_box("Normal DNS Test", content, MAGENTA)

            dns_server = input(f"\n  {MAGENTA}>{RESET} DNS Server: ").strip()
            if dns_server.lower() == 'b':
                continue
            if not dns_server:
                continue
            run_dns_checker(dns_server)
            input(f"\n  {DIM}Press Enter to continue...{RESET}")
            continue

        if choice == '2':
            profiles = list_profiles()
            active = get_active_profile_name()
            if not profiles:
                print(f"\n  {RED}x{RESET} No profiles found")
                input(f"\n  {DIM}Press Enter to continue...{RESET}")
                continue

            clear_screen()
            print_logo(mini=True)
            profile_lines = []
            for idx, name in enumerate(profiles, start=1):
                marker = f"{GREEN}*{RESET}" if name == active else f"{DIM}-{RESET}"
                profile_lines.append(f"{YELLOW}[{idx}]{RESET} {marker} {WHITE}{name}{RESET}")
            profile_lines.append(f"{YELLOW}[B]{RESET} Back")
            print_box("Profile-based DNS Test", profile_lines, MAGENTA)

            selected = input(f"\n  {MAGENTA}>{RESET} Select profile: ").strip().lower()
            if selected == 'b':
                continue

            try:
                selected_index = int(selected)
            except ValueError:
                continue
            if selected_index < 1 or selected_index > len(profiles):
                continue

            profile_name = profiles[selected_index - 1]
            run_profile_dns_checker(profile_name)
            input(f"\n  {DIM}Press Enter to continue...{RESET}")
            continue


def handle_ip_checker():
    while True:
        clear_screen()
        print_logo(mini=True)

        content = [
            f"Checks your public IP and country.",
            f"Checks IP leak and DNS leak status.",
            "",
            f"{YELLOW}[1]{RESET} Run IP Checker",
            f"{YELLOW}[B]{RESET} Back to Menu",
        ]
        print_box("IP Checker", content, MAGENTA)

        choice = input(f"\n  {MAGENTA}>{RESET} Select option: ").strip().lower()

        if choice == "b":
            break
        if choice != "1":
            continue

        run_ip_checker()
        input(f"\n  {DIM}Press Enter to continue...{RESET}")


def handle_menu():
    while True:
        clear_screen()
        print_logo()
        
        config = load_config()
        print_config(config)
        
        content = [
            f"{YELLOW}[1]{RESET} Connect",
            f"{YELLOW}[2]{RESET} Profiles",
            f"{YELLOW}[3]{RESET} Settings",
            f"{YELLOW}[4]{RESET} Tools",
            f"{YELLOW}[5]{RESET} DNS Checker",
            f"{YELLOW}[6]{RESET} IP Checker",
            f"{YELLOW}[7]{RESET} Exit",
        ]
        print_box("Menu", content, BLUE)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option [1-7]: ").strip()
        
        if choice == '1':
            vpn_status = f"{GREEN}●{RESET}" if is_admin() else f"{RED}○{RESET}"
            admin_note = "" if is_admin() else f" {DIM}(requires Admin/sudo){RESET}"
            
            if is_windows():
                content = [
                    f"{YELLOW}[1]{RESET} {vpn_status} VPN Mode       {DIM}(system-wide){RESET}{admin_note}",
                    f"{YELLOW}[2]{RESET} {GREEN}●{RESET} System Proxy   {DIM}(HTTP Global){RESET}",
                    f"{YELLOW}[3]{RESET} {GREEN}●{RESET} Local Proxy    {DIM}(SOCKS5 Only){RESET}",
                    f"{YELLOW}[4]{RESET} Back",
                ]
            else:
                content = [
                    f"{YELLOW}[1]{RESET} {vpn_status} VPN Mode       {DIM}(system-wide){RESET}{admin_note}",
                    f"{YELLOW}[2]{RESET} {GREEN}●{RESET} Local Proxy    {DIM}(SOCKS5 Only){RESET}",
                    f"{YELLOW}[3]{RESET} Back",
                ]
            print_box("Connection Mode", content, MAGENTA)
            
            max_opt = "4" if is_windows() else "3"
            mode = input(f"\n  {MAGENTA}▸{RESET} Select mode [1-{max_opt}]: ").strip()
            
            if mode == '1':
                if not is_admin():
                    if is_linux():
                        import subprocess
                        exe_path = os.path.join(os.path.dirname(sys.executable), 'LocalStream')
                        print(f"\n  {YELLOW}!{RESET} VPN mode requires sudo privileges...")
                        result = subprocess.run(['sudo', exe_path, '--vpn'])
                        sys.exit(result.returncode)
                    else:
                        print(f"\n  {RED}✗{RESET} Requires Administrator!")
                        time.sleep(3)
                        continue
                if not tun2proxy_exists():
                    download_tun2proxy()
                handle_connection(config, "vpn")
                
            elif mode == '2':
                if is_windows():
                    if not privoxy_exists():
                        if not download_privoxy():
                            print(f"\n{RED}✗{RESET} Privoxy download failed.")
                            input(f"\n  {DIM}Press Enter to return to menu...{RESET}")
                            continue
                    handle_connection(config, "system")
                else:
                    handle_connection(config, "proxy")
                
            elif mode == '3':
                if is_windows():
                    handle_connection(config, "proxy")
                
        elif choice == '2':
            handle_profiles()
            
        elif choice == '3':
            handle_settings()

        elif choice == '4':
            handle_tools()
            
        elif choice == '5':
            handle_dns_checker()
            
        elif choice == '6':
            handle_ip_checker()

        elif choice == '7':
            sys.exit(0)


def handle_first_run():
    clear_screen()
    print_logo()
    
    print(f"\n{GREEN}✓{RESET} Welcome to LocalStream!")
    print(f"{DIM}  First-time setup{RESET}")
    
    content = [
        f"{YELLOW}[1]{RESET} Manual Setup",
        f"{YELLOW}[2]{RESET} Import Config (.local)",
    ]
    print_box("Setup Options", content, MAGENTA)
    
    choice = input(f"\n  {MAGENTA}▸{RESET} Select option [1-2]: ").strip()
    
    if choice == '2':
        handle_import_config()
        if config_exists():
            handle_menu()
            return
        print(f"\n  {YELLOW}!{RESET} No profile configured, starting manual setup...")
        time.sleep(1)
    
    if not client_exists():
        download_client()
        
    config = prompt_for_config()
    save_config(config)
    handle_menu()


def main():
    parser = argparse.ArgumentParser(description="LocalStream CLI Client")
    parser.add_argument("--vpn", action="store_true", help="Connect in VPN mode")
    parser.add_argument("--system-proxy", action="store_true", help="Connect in System Proxy mode")
    parser.add_argument("--proxy", action="store_true", help="Connect in Local Proxy mode")
    parser.add_argument("--profile", help="Use specific profile")
    
    args = parser.parse_args()
    
    try:
        if not config_exists():
            handle_first_run()
            return

        if args.profile:
            if not switch_profile(args.profile):
                print(f"{RED}✗{RESET} Profile '{args.profile}' not found")
                sys.exit(1)
        
        config = load_config()
        
        if args.vpn:
            if not is_admin():
                if is_linux():
                    import subprocess
                    exe_path = os.path.join(os.path.dirname(sys.executable), 'LocalStream')
                    print(f"{YELLOW}!{RESET} VPN mode requires sudo privileges...")
                    result = subprocess.run(['sudo', exe_path, '--vpn'])
                    sys.exit(result.returncode)
                else:
                    print(f"{RED}✗{RESET} VPN mode requires Administrator privileges")
                    sys.exit(1)
            if not tun2proxy_exists():
                download_tun2proxy()
            handle_connection(config, "vpn")
            
        elif args.system_proxy:
            if not privoxy_exists():
                download_privoxy()
            handle_connection(config, "system")
            
        elif args.proxy:
            handle_connection(config, "proxy")
            
        else:
            handle_menu()
            
    except KeyboardInterrupt:
        print(f"\n\n{GREEN}✓{RESET} Goodbye!")
        sys.exit(0)


if __name__ == "__main__":
    main()


