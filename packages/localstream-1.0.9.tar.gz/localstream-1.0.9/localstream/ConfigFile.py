import base64
import hashlib
import json
import os
from datetime import datetime
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

FILE_HEADER = b"LOCALSTREAM_V1"
APP_SIGNATURE = b"LocalStream_SecureConfig_2024"
TARGET_FILE_SIZE = 10 * 1024
KDF_ITERATIONS = 600000
KDF_DIGEST = "sha512"
SALT_LENGTH = 16


def _legacy_fernet(password: str = None) -> Fernet:
    material = APP_SIGNATURE
    if password:
        material += password.encode("utf-8")
    key_material = hashlib.sha256(material).digest()
    return Fernet(base64.urlsafe_b64encode(key_material))


def _derive_key(password: str, salt: bytes, iterations: int) -> bytes:
    material = APP_SIGNATURE + (password or "").encode("utf-8")
    key_material = hashlib.pbkdf2_hmac(KDF_DIGEST, material, salt, iterations, dklen=32)
    return base64.urlsafe_b64encode(key_material)


def _encrypt_payload(payload: bytes, password: str = None) -> tuple[str, dict]:
    salt = os.urandom(SALT_LENGTH)
    key = _derive_key(password or "", salt, KDF_ITERATIONS)
    token = Fernet(key).encrypt(payload).decode("utf-8")
    crypto = {
        "scheme": "fernet-pbkdf2-sha512",
        "iterations": KDF_ITERATIONS,
        "salt": base64.urlsafe_b64encode(salt).decode("ascii"),
    }
    return token, crypto


def _decrypt_payload(token: str, crypto: dict, password: str = None) -> bytes:
    iterations = int(crypto.get("iterations", KDF_ITERATIONS))
    salt = base64.urlsafe_b64decode(str(crypto.get("salt", "")).encode("ascii"))
    key = _derive_key(password or "", salt, iterations)
    return Fernet(key).decrypt(token.encode("utf-8"))


def _encode_envelope(envelope: dict, locked: bool) -> bytes:
    raw = json.dumps(envelope, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    prefix = FILE_HEADER + b"\n" + (b"1" if locked else b"0") + b"\n"
    missing = TARGET_FILE_SIZE - (len(prefix) + len(raw))
    if missing > 0:
        envelope["padding"] = "0" * missing
        raw = json.dumps(envelope, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return prefix + raw


def export_config(
    config: dict,
    file_path: Path,
    locked: bool = False,
    password: str = None,
    profile_name: str = "",
    app_version: str = "",
) -> bool:
    try:
        normalized = dict(config or {})
        normalized["is_locked"] = bool(locked)

        payload = {
            "format_version": 3,
            "metadata": {
                "exported_at": datetime.utcnow().isoformat() + "Z",
                "profile_name": profile_name,
                "app_version": app_version,
            },
            "config": normalized,
            "locked": bool(locked),
        }

        payload_bytes = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        token, crypto = _encrypt_payload(payload_bytes, password)

        envelope = {
            "format": "localstream",
            "format_version": 3,
            "locked": bool(locked),
            "crypto": crypto,
            "payload": token,
            "padding": "",
        }

        encoded = _encode_envelope(envelope, bool(locked))
        with open(file_path, "wb") as f:
            f.write(encoded)

        return True
    except Exception:
        return False


def _parse_payload(payload: dict, fallback_locked: bool) -> tuple:
    if isinstance(payload, dict) and "config" in payload:
        config = payload.get("config", {})
        is_locked = bool(payload.get("locked", fallback_locked))
    else:
        config = payload if isinstance(payload, dict) else {}
        is_locked = fallback_locked

    if not isinstance(config, dict):
        return None, False, "Invalid config payload"

    return config, is_locked, None


def import_config(file_path: Path, password: str = None) -> tuple:
    try:
        with open(file_path, "rb") as f:
            header = f.readline().strip()
            if header != FILE_HEADER:
                return None, False, "Invalid file format"

            locked_flag = f.readline().strip()
            file_locked = locked_flag == b"1"
            body = f.read()

        try:
            envelope = json.loads(body.decode("utf-8"))
        except Exception:
            envelope = None

        if isinstance(envelope, dict) and envelope.get("payload") and envelope.get("crypto"):
            decrypted = _decrypt_payload(str(envelope.get("payload")), envelope.get("crypto", {}), password)
            payload = json.loads(decrypted.decode("utf-8"))
            return _parse_payload(payload, bool(envelope.get("locked", file_locked)))

        decrypted = _legacy_fernet(password).decrypt(body)
        payload = json.loads(decrypted.decode("utf-8"))
        return _parse_payload(payload, file_locked)
    except InvalidToken:
        return None, False, "Invalid password or corrupted file"
    except Exception as e:
        return None, False, str(e)


def is_valid_local_file(file_path: Path) -> bool:
    try:
        with open(file_path, "rb") as f:
            header = f.readline().strip()
            return header == FILE_HEADER
    except Exception:
        return False


def get_file_info(file_path: Path) -> dict:
    try:
        with open(file_path, "rb") as f:
            header = f.readline().strip()
            if header != FILE_HEADER:
                return None

            locked_flag = f.readline().strip()
            file_locked = locked_flag == b"1"
            body = f.read()

        info = {
            "valid": True,
            "locked": file_locked,
            "format_version": 1,
            "profile_name": "",
            "app_version": "",
            "exported_at": "",
            "path": str(file_path),
            "size_bytes": len(FILE_HEADER) + 1 + len(locked_flag) + 1 + len(body),
        }

        envelope = None
        try:
            envelope = json.loads(body.decode("utf-8"))
        except Exception:
            envelope = None

        if isinstance(envelope, dict) and envelope.get("payload") and envelope.get("crypto"):
            info["format_version"] = int(envelope.get("format_version", 3))
            info["locked"] = bool(envelope.get("locked", file_locked))
            try:
                decrypted = _decrypt_payload(str(envelope.get("payload")), envelope.get("crypto", {}), "")
                payload = json.loads(decrypted.decode("utf-8"))
                metadata = payload.get("metadata", {}) if isinstance(payload, dict) else {}
                if isinstance(metadata, dict):
                    info["profile_name"] = metadata.get("profile_name", "")
                    info["app_version"] = metadata.get("app_version", "")
                    info["exported_at"] = metadata.get("exported_at", "")
            except Exception:
                pass
            return info

        try:
            decrypted = _legacy_fernet().decrypt(body)
            payload = json.loads(decrypted.decode("utf-8"))
            if isinstance(payload, dict):
                info["format_version"] = int(payload.get("format_version", 1))
                info["locked"] = bool(payload.get("locked", file_locked))
                metadata = payload.get("metadata", {})
                if isinstance(metadata, dict):
                    info["profile_name"] = metadata.get("profile_name", "")
                    info["app_version"] = metadata.get("app_version", "")
                    info["exported_at"] = metadata.get("exported_at", "")
        except Exception:
            pass

        return info
    except Exception:
        return None
