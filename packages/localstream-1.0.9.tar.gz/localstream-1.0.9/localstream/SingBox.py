import base64
import json
from urllib.parse import parse_qs, unquote, urlparse


SUPPORTED_SINGBOX_TUNNELS = ("vless", "vmess", "trojan", "shadowsocks")


def is_singbox_tunnel(tunnel_type: str) -> bool:
    return str(tunnel_type or "").strip().lower() in SUPPORTED_SINGBOX_TUNNELS


def _b64decode_auto(value: str) -> str:
    data = value.strip()
    if not data:
        return ""
    data = data.replace("-", "+").replace("_", "/")
    pad = len(data) % 4
    if pad:
        data += "=" * (4 - pad)
    return base64.b64decode(data.encode("utf-8")).decode("utf-8", errors="replace")


def _param(params: dict, name: str, default: str = "") -> str:
    values = params.get(name) or params.get(name.lower()) or params.get(name.upper())
    if not values:
        return default
    return str(values[0] or default)


def _parse_host_port(value: str) -> tuple[str, int]:
    parsed = urlparse(f"//{value}")
    host = parsed.hostname or ""
    port = int(parsed.port or 0)
    if not host or port <= 0:
        raise ValueError("Invalid server or port in link")
    return host, port


def _build_transport(transport_type: str, params: dict, default_path: str = "", default_host: str = "") -> dict | None:
    t = str(transport_type or "tcp").strip().lower()
    if t in ["tcp", "raw"]:
        return None
    if t == "ws":
        path = unquote(_param(params, "path", default_path or "/")) or "/"
        host = _param(params, "host", default_host).strip()
        transport = {"type": "ws", "path": path}
        if host:
            transport["headers"] = {"Host": host}
        return transport
    if t == "grpc":
        service_name = unquote(_param(params, "serviceName", _param(params, "service_name", default_path.lstrip("/")))).strip()
        transport = {"type": "grpc"}
        if service_name:
            transport["service_name"] = service_name
        return transport
    return None


def _build_tls(params: dict, security: str, default_sni: str = "") -> dict | None:
    sec = str(security or "").strip().lower()
    if sec not in ["tls", "reality"]:
        return None

    tls = {"enabled": True}
    sni = _param(params, "sni", _param(params, "serverName", default_sni)).strip()
    if sni:
        tls["server_name"] = sni

    alpn_raw = _param(params, "alpn", "h2,http/1.1").strip()
    if alpn_raw:
        tls["alpn"] = [x.strip() for x in alpn_raw.replace("|", ",").split(",") if x.strip()]

    fingerprint = _param(params, "fp", "chrome").strip()
    if fingerprint and fingerprint.lower() != "none":
        tls["utls"] = {"enabled": True, "fingerprint": fingerprint}

    insecure = _param(params, "allowInsecure", _param(params, "insecure", "false")).strip().lower()
    if insecure in ["1", "true", "yes", "on"]:
        tls["insecure"] = True

    if sec == "reality":
        public_key = _param(params, "pbk", _param(params, "public_key", "")).strip()
        short_id = _param(params, "sid", _param(params, "short_id", "")).strip()
        reality = {"enabled": True}
        if public_key:
            reality["public_key"] = public_key
        if short_id:
            reality["short_id"] = short_id
        tls["reality"] = reality

    return tls


def _parse_vless(uri: str) -> tuple[dict, dict]:
    parsed = urlparse(uri)
    if not parsed.username or not parsed.hostname or not parsed.port:
        raise ValueError("Invalid vless link")

    params = parse_qs(parsed.query, keep_blank_values=True)
    security = _param(params, "security", "none")
    transport = _build_transport(_param(params, "type", "tcp"), params)
    tls = _build_tls(params, security, default_sni=parsed.hostname)

    outbound = {
        "type": "vless",
        "tag": "proxy",
        "server": parsed.hostname,
        "server_port": int(parsed.port),
        "uuid": parsed.username,
        "packet_encoding": "xudp",
        "domain_resolver": "google"
    }

    flow = _param(params, "flow", "").strip()
    if flow:
        outbound["flow"] = flow
    if tls:
        outbound["tls"] = tls
    if transport:
        outbound["transport"] = transport

    return outbound, {
        "protocol": "vless",
        "server": parsed.hostname,
        "server_port": int(parsed.port),
        "name": unquote(parsed.fragment or "").strip(),
    }


def _parse_trojan(uri: str) -> tuple[dict, dict]:
    parsed = urlparse(uri)
    if not parsed.username or not parsed.hostname or not parsed.port:
        raise ValueError("Invalid trojan link")

    params = parse_qs(parsed.query, keep_blank_values=True)
    security = _param(params, "security", "tls")
    transport = _build_transport(_param(params, "type", "tcp"), params)
    tls = _build_tls(params, security, default_sni=parsed.hostname)

    outbound = {
        "type": "trojan",
        "tag": "proxy",
        "server": parsed.hostname,
        "server_port": int(parsed.port),
        "password": parsed.username,
        "packet_encoding": "xudp",
        "domain_resolver": "google"
    }

    if tls:
        outbound["tls"] = tls
    if transport:
        outbound["transport"] = transport

    return outbound, {
        "protocol": "trojan",
        "server": parsed.hostname,
        "server_port": int(parsed.port),
        "name": unquote(parsed.fragment or "").strip(),
    }


def _parse_vmess_json_payload(payload: dict) -> tuple[dict, dict]:
    server = str(payload.get("add") or payload.get("server") or "").strip()
    port = int(payload.get("port") or 0)
    uuid = str(payload.get("id") or payload.get("uuid") or "").strip()
    if not server or port <= 0 or not uuid:
        raise ValueError("Invalid vmess link")

    params = {}
    if payload.get("host"):
        params["host"] = [str(payload.get("host"))]
    if payload.get("path"):
        params["path"] = [str(payload.get("path"))]
    if payload.get("serviceName"):
        params["serviceName"] = [str(payload.get("serviceName"))]
    if payload.get("sni"):
        params["sni"] = [str(payload.get("sni"))]
    if payload.get("alpn"):
        params["alpn"] = [str(payload.get("alpn"))]
    if payload.get("fp"):
        params["fp"] = [str(payload.get("fp"))]
    if payload.get("allowInsecure") is not None:
        params["allowInsecure"] = [str(payload.get("allowInsecure"))]

    network = str(payload.get("net") or payload.get("type") or "tcp").strip().lower()
    tls_flag = str(payload.get("tls") or "").strip().lower()
    security = "tls" if tls_flag in ["tls", "reality"] else "none"

    outbound = {
        "type": "vmess",
        "tag": "proxy",
        "server": server,
        "server_port": port,
        "uuid": uuid,
        "packet_encoding": "xudp",
        "domain_resolver": "google"
    }

    alter_id = int(payload.get("aid") or payload.get("alterId") or 0)
    if alter_id > 0:
        outbound["alter_id"] = alter_id

    vmess_security = str(payload.get("scy") or payload.get("security") or "auto").strip()
    if vmess_security:
        outbound["security"] = vmess_security

    tls = _build_tls(params, security, default_sni=server)
    transport = _build_transport(network, params, default_path=str(payload.get("path") or ""), default_host=str(payload.get("host") or ""))
    if tls:
        outbound["tls"] = tls
    if transport:
        outbound["transport"] = transport

    return outbound, {
        "protocol": "vmess",
        "server": server,
        "server_port": port,
        "name": str(payload.get("ps") or payload.get("name") or "").strip(),
    }


def _parse_vmess(uri: str) -> tuple[dict, dict]:
    raw = uri[len("vmess://"):].strip()
    if not raw:
        raise ValueError("Invalid vmess link")

    if raw.startswith("{") and raw.endswith("}"):
        payload = json.loads(raw)
        return _parse_vmess_json_payload(payload)

    try:
        payload_text = _b64decode_auto(raw)
        payload = json.loads(payload_text)
        return _parse_vmess_json_payload(payload)
    except Exception:
        parsed = urlparse(uri)
        if not parsed.username or not parsed.hostname or not parsed.port:
            raise ValueError("Invalid vmess link")
        params = parse_qs(parsed.query, keep_blank_values=True)
        security = _param(params, "security", _param(params, "tls", "none"))
        network = _param(params, "type", _param(params, "net", "tcp"))
        outbound = {
            "type": "vmess",
            "tag": "proxy",
            "server": parsed.hostname,
            "server_port": int(parsed.port),
            "uuid": parsed.username,
            "packet_encoding": "xudp",
            "domain_resolver": "google"
        }
        alter_id = int(_param(params, "aid", "0") or 0)
        if alter_id > 0:
            outbound["alter_id"] = alter_id
        scy = _param(params, "scy", "auto").strip()
        if scy:
            outbound["security"] = scy
        tls = _build_tls(params, security, default_sni=parsed.hostname)
        transport = _build_transport(network, params)
        if tls:
            outbound["tls"] = tls
        if transport:
            outbound["transport"] = transport
        return outbound, {
            "protocol": "vmess",
            "server": parsed.hostname,
            "server_port": int(parsed.port),
            "name": unquote(parsed.fragment or "").strip(),
        }


def _decode_ss_credential(credential: str) -> str:
    if ":" in credential:
        return credential
    try:
        return _b64decode_auto(credential)
    except Exception:
        return credential


def _parse_shadowsocks(uri: str) -> tuple[dict, dict]:
    raw = uri[len("ss://"):].strip()
    if not raw:
        raise ValueError("Invalid shadowsocks link")

    fragment_name = ""
    if "#" in raw:
        raw, frag = raw.split("#", 1)
        fragment_name = unquote(frag).strip()

    query = ""
    if "?" in raw:
        raw, query = raw.split("?", 1)

    if "@" in raw:
        credential_part, server_part = raw.rsplit("@", 1)
        credential = _decode_ss_credential(credential_part)
    else:
        decoded = _b64decode_auto(raw)
        if "@" not in decoded:
            raise ValueError("Invalid shadowsocks link")
        credential, server_part = decoded.rsplit("@", 1)

    if ":" not in credential:
        raise ValueError("Invalid shadowsocks credential")
    method, password = credential.split(":", 1)
    server, port = _parse_host_port(server_part)

    outbound = {
        "type": "shadowsocks",
        "tag": "proxy",
        "server": server,
        "server_port": int(port),
        "method": method.strip(),
        "password": password,
    }

    params = parse_qs(query, keep_blank_values=True)
    plugin = _param(params, "plugin", "").strip()
    if plugin:
        outbound["plugin"] = plugin

    return outbound, {
        "protocol": "shadowsocks",
        "server": server,
        "server_port": int(port),
        "name": fragment_name,
    }


def parse_singbox_uri(uri: str, tunnel_type: str = "") -> tuple[dict, dict]:
    link = str(uri or "").strip()
    if not link:
        raise ValueError("Proxy link is required")

    parsed = urlparse(link)
    scheme = str(parsed.scheme or "").lower()
    forced = str(tunnel_type or "").strip().lower()
    protocol = forced if forced in SUPPORTED_SINGBOX_TUNNELS else scheme

    if protocol not in SUPPORTED_SINGBOX_TUNNELS:
        raise ValueError("Unsupported protocol in link")

    if protocol == "vless":
        return _parse_vless(link)
    if protocol == "vmess":
        return _parse_vmess(link)
    if protocol == "trojan":
        return _parse_trojan(link)
    return _parse_shadowsocks(link)


def extract_link_server(uri: str, tunnel_type: str = "") -> tuple[str, int, str]:
    _, meta = parse_singbox_uri(uri, tunnel_type=tunnel_type)
    return str(meta.get("server", "")), int(meta.get("server_port", 0)), str(meta.get("protocol", ""))


def build_singbox_config(uri: str, tunnel_type: str, local_port: int) -> tuple[dict, dict]:
    outbound, meta = parse_singbox_uri(uri, tunnel_type=tunnel_type)
    config = {
        "log": {"level": "info", "timestamp": True},
        "inbounds": [
            {
                "type": "socks",
                "tag": "socks-in",
                "listen": "127.0.0.1",
                "listen_port": int(local_port),
            }
        ],
        "dns": {
            "servers": [
                {"tag": "google", "type": "udp", "server": "8.8.8.8", "server_port": 53},
                {"tag": "cloudflare", "type": "udp", "server": "1.1.1.1", "server_port": 53},
                {"tag": "local", "type": "local"}
            ],
            "rules": [
                {"query_type": ["A", "AAAA"], "server": "google"}
            ],
            "final": "google",
            "strategy": "prefer_ipv4"
        },
        "outbounds": [
            outbound,
            {"type": "direct", "tag": "direct"}
        ],
        "route": {
            "auto_detect_interface": True,
            "default_domain_resolver": "google",
            "rules": [
                {"protocol": "dns", "action": "hijack-dns"},
                {"ip_cidr": ["8.8.8.8/32", "1.1.1.1/32"], "action": "route", "outbound": "direct"},
                {"ip_cidr": [outbound.get("server", "0.0.0.0")], "action": "route", "outbound": "direct"},
                {"domain": [outbound.get("server", "")], "action": "route", "outbound": "direct"}
            ],
            "final": "proxy",
        },
    }
    return config, meta
