import json
from pathlib import Path


def get_config_dir() -> Path:
    config_dir = Path.home() / ".localstream"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_config_path() -> Path:
    return get_config_dir() / "config.json"


def config_exists() -> bool:
    return get_config_path().exists()


def get_default_config() -> dict:
    return {
        "tunnel_type": "slipstream",
        "server_ip": "",
        "server_port": 53,
        "local_port": 5201,
        "domain": "",
        "doh_url": "https://1.1.1.1/dns-query",
        "doh_bootstrap_ip": "",
        "doh_local_dns_port": 5300,
        "doh_sni": "",
        "doh_insecure": False,
        "singbox_uri": "",
        "dnstt_pubkey": "",
        "ssh_host": "127.0.0.1",
        "ssh_port": 22,
        "ssh_user": "",
        "ssh_pass": "",
        "pingtunnel_key": 0,
        "is_locked": False,
        "keep_alive_interval": 200,
        "congestion_control": "bbr",
        "enable_gso": False,
        "enable_fragmentation": False,
        "fragment_size": 77,
        "fragment_delay": 200,
        "auto_restart_minutes": 0,
        "bypass_list": "<local>",
        "ui_theme": "dark",
        "quick_connect_profile": "",
        "enable_failover": False,
        "failover_profiles": [],
        "failover_methods": [],
        "failover_timeout_seconds": 8,
        "split_tunnel_enabled": False,
        "split_include_list": "",
        "kill_switch_enabled": False,
        "dns_leak_guard_enabled": False,
        "update_channel": "stable",
        "profile_label": "",
    }


def _default_root() -> dict:
    return {
        "active_profile": "Profile 1",
        "profiles": {"Profile 1": get_default_config()},
        "last_successful_profile": "Profile 1",
    }


def _normalize_profile(config: dict) -> dict:
    defaults = get_default_config()
    if not isinstance(config, dict):
        return defaults

    normalized = {**defaults, **config}

    if normalized.get("ui_theme") not in ["dark", "light"]:
        normalized["ui_theme"] = "dark"

    if normalized.get("update_channel") not in ["stable", "beta"]:
        normalized["update_channel"] = "stable"

    if not isinstance(normalized.get("failover_profiles"), list):
        normalized["failover_profiles"] = []

    if not isinstance(normalized.get("failover_methods"), list):
        normalized["failover_methods"] = []

    if not isinstance(normalized.get("split_include_list", ""), str):
        normalized["split_include_list"] = str(normalized.get("split_include_list", ""))

    return normalized


def _normalize_raw_config(data: dict) -> tuple[dict, bool]:
    changed = False

    if not isinstance(data, dict):
        data = {}
        changed = True

    if "server_ip" in data:
        data = {
            "active_profile": "Profile 1",
            "profiles": {
                "Profile 1": data
            },
            "last_successful_profile": "Profile 1",
        }
        changed = True

    profiles = data.get("profiles")
    if not isinstance(profiles, dict) or not profiles:
        profiles = {"Profile 1": get_default_config()}
        data["profiles"] = profiles
        changed = True

    normalized_profiles = {}
    for name, config in profiles.items():
        profile_name = str(name)
        normalized = _normalize_profile(config)
        normalized_profiles[profile_name] = normalized
        if normalized != config or profile_name != name:
            changed = True

    data["profiles"] = normalized_profiles

    active_profile = data.get("active_profile")
    if active_profile not in normalized_profiles:
        active_profile = list(normalized_profiles.keys())[0]
        data["active_profile"] = active_profile
        changed = True

    last_successful_profile = data.get("last_successful_profile", "")
    if last_successful_profile and last_successful_profile not in normalized_profiles:
        last_successful_profile = ""
        changed = True
    if not last_successful_profile:
        last_successful_profile = active_profile
        changed = True
    data["last_successful_profile"] = last_successful_profile

    return data, changed


def _read_raw_config() -> dict:
    config_path = get_config_path()

    if not config_path.exists():
        return _default_root()

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = _default_root()
        _write_raw_config(data)
        return data

    data, changed = _normalize_raw_config(data)
    if changed:
        _write_raw_config(data)

    return data


def _write_raw_config(data: dict) -> None:
    data, _ = _normalize_raw_config(data)
    config_path = get_config_path()
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def load_config() -> dict:
    raw = _read_raw_config()
    active = raw.get("active_profile")
    if not active and raw.get("profiles"):
        active = list(raw["profiles"].keys())[0]
    return _normalize_profile(raw.get("profiles", {}).get(active, get_default_config()))


def save_config(config: dict) -> None:
    raw = _read_raw_config()
    active = raw.get("active_profile")
    if not active and raw.get("profiles"):
        active = list(raw["profiles"].keys())[0]
    if "profiles" not in raw:
        raw["profiles"] = {}
    raw["profiles"][active] = _normalize_profile(config)
    _write_raw_config(raw)


def is_profile_locked(name: str = None) -> bool:
    raw = _read_raw_config()
    if name is None:
        name = get_active_profile_name()
    profile = raw.get("profiles", {}).get(name, {})
    return bool(profile.get("is_locked", False))


def create_profile_with_lock(name: str, config: dict, is_locked: bool) -> None:
    raw = _read_raw_config()
    if "profiles" not in raw:
        raw["profiles"] = {}
    normalized = _normalize_profile(config)
    normalized["is_locked"] = bool(is_locked)
    raw["profiles"][name] = normalized
    _write_raw_config(raw)


def list_profiles() -> list:
    raw = _read_raw_config()
    return list(raw.get("profiles", {}).keys())


def get_active_profile_name() -> str:
    raw = _read_raw_config()
    active = raw.get("active_profile")
    if not active and raw.get("profiles"):
        return list(raw["profiles"].keys())[0]
    return active or ""


def get_last_successful_profile() -> str:
    raw = _read_raw_config()
    return raw.get("last_successful_profile", "")


def set_last_successful_profile(name: str) -> bool:
    raw = _read_raw_config()
    if name not in raw.get("profiles", {}):
        return False
    raw["last_successful_profile"] = name
    for profile_name, profile_config in raw.get("profiles", {}).items():
        if isinstance(profile_config, dict):
            profile_config["quick_connect_profile"] = name
    _write_raw_config(raw)
    return True


def switch_profile(name: str) -> bool:
    raw = _read_raw_config()
    if name in raw.get("profiles", {}):
        raw["active_profile"] = name
        _write_raw_config(raw)
        return True
    return False


def update_profile(name: str, config: dict) -> bool:
    raw = _read_raw_config()
    if name not in raw.get("profiles", {}):
        return False
    raw["profiles"][name] = _normalize_profile(config)
    _write_raw_config(raw)
    return True


def create_profile(name: str, config: dict = None) -> None:
    raw = _read_raw_config()
    if config is None:
        config = get_default_config()
    if "profiles" not in raw:
        raw["profiles"] = {}
    raw["profiles"][name] = _normalize_profile(config)
    _write_raw_config(raw)


def clone_profile(source_name: str, target_name: str) -> bool:
    raw = _read_raw_config()
    profiles = raw.get("profiles", {})
    if source_name not in profiles or target_name in profiles:
        return False
    profiles[target_name] = _normalize_profile(dict(profiles[source_name]))
    _write_raw_config(raw)
    return True


def delete_profile(name: str) -> bool:
    raw = _read_raw_config()
    profiles = raw.get("profiles", {})

    if len(profiles) <= 1:
        return False

    if name in profiles:
        del profiles[name]

        if name == raw.get("active_profile"):
            raw["active_profile"] = list(profiles.keys())[0]

        if name == raw.get("last_successful_profile"):
            raw["last_successful_profile"] = raw.get("active_profile", "")

        _write_raw_config(raw)
        return True

    return False
