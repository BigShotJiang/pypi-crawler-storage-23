import socket
import time
import struct
import os

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"
RESET = "\033[0m"

def build_dns_query(domain):
    ID = struct.pack("!H", 0x1234)
    FLAGS = struct.pack("!H", 0x0100)  # Standard query
    QDCOUNT = struct.pack("!H", 0x0001)
    ANCOUNT = struct.pack("!H", 0x0000)
    NSCOUNT = struct.pack("!H", 0x0000)
    ARCOUNT = struct.pack("!H", 0x0000)
    
    query = ID + FLAGS + QDCOUNT + ANCOUNT + NSCOUNT + ARCOUNT
    
    for part in domain.split('.'):
        query += struct.pack("!B", len(part))
        query += part.encode('utf-8')
    query += struct.pack("!B", 0)
    
    QTYPE = struct.pack("!H", 0x0001)  # A record
    QCLASS = struct.pack("!H", 0x0001) # IN class
    
    return query + QTYPE + QCLASS

def check_dns(dns_server, domain="google.com", timeout=2):
    sock = None
    try:
        query_id = 0x1234
        query = build_dns_query(domain)
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        
        start_time = time.time()
        sock.sendto(query, (dns_server, 53))
        
        try:
            data, addr = sock.recvfrom(512)
            end_time = time.time()
            
            if len(data) < 12:
                return False, 0
                
            res_id = struct.unpack("!H", data[:2])[0]
            res_flags = struct.unpack("!H", data[2:4])[0]
            res_qdcount = struct.unpack("!H", data[4:6])[0]
            res_ancount = struct.unpack("!H", data[6:8])[0]
            
            # Check ID matches and it's a response (0x8000) and no error code (last 4 bits)
            is_response = (res_flags & 0x8000) != 0
            has_no_error = (res_flags & 0x000F) == 0
            
            if res_id == query_id and is_response and has_no_error and res_ancount > 0:
                latency = (end_time - start_time) * 1000
                return True, latency
            return False, 0
            
        except socket.timeout:
            return False, 0
    except Exception:
        return False, 0
    finally:
        if sock:
            sock.close()

def run_dns_checker(dns_server):
    print(f"\n{CYAN}╔═══════════════════════════════════════════════════════╗{RESET}")
    print(f"{CYAN}║{RESET}  {YELLOW}⟳{RESET} Testing DNS: {dns_server.ljust(37)} {CYAN}║{RESET}")
    print(f"{CYAN}╚═══════════════════════════════════════════════════════╝{RESET}\n")
    
    success, latency = check_dns(dns_server)
    
    if success:
        print(f"  {GREEN}✓{RESET} Status: {GREEN}WORKS{RESET}")
        print(f"  {GREEN}●{RESET} Latency: {latency:.1f} ms")
        return True, latency
    else:
        print(f"  {RED}✗{RESET} Status: {RED}FAILED{RESET}")
        print(f"  {DIM}!{RESET} Possible causes: Server offline, blocked port 53, or invalid IP")
        return False, 0

def check_profile_dns(profile_name, timeout=2):
    active_profile = None
    try:
        from localstream.Config import list_profiles, get_active_profile_name, switch_profile, load_config

        profiles = list_profiles()
        if profile_name not in profiles:
            return False, 0, "", "", "Profile not found"

        active_profile = get_active_profile_name()
        if active_profile != profile_name:
            if not switch_profile(profile_name):
                return False, 0, "", "", "Unable to switch profile"

        config = load_config()
        dns_server = str(config.get("server_ip", "")).strip()
        domain = str(config.get("domain", "")).strip()
        tunnel_type = str(config.get("tunnel_type", "slipstream")).strip().lower()

        if not dns_server:
            return False, 0, "", "", "Selected profile has no DNS server IP"

        if tunnel_type in ["slipstream", "dnstt", "doh"] and not domain:
            return False, 0, dns_server, "", "Selected profile has no domain/subdomain"

        test_domain = domain if domain else "google.com"
        success, latency = check_dns(dns_server, domain=test_domain, timeout=timeout)
        return success, latency, dns_server, test_domain, ""
    except Exception as e:
        return False, 0, "", "", str(e)
    finally:
        try:
            from localstream.Config import switch_profile, get_active_profile_name
            if active_profile and get_active_profile_name() != active_profile:
                switch_profile(active_profile)
        except Exception:
            pass


def run_profile_dns_checker(profile_name, timeout=2):
    success, latency, dns_server, domain, error = check_profile_dns(profile_name, timeout=timeout)

    print(f"\n{CYAN}========================================{RESET}")
    print(f"{CYAN} Profile DNS Test: {profile_name}{RESET}")
    if dns_server:
        print(f"{CYAN} DNS Server: {dns_server}{RESET}")
    if domain:
        print(f"{CYAN} Domain: {domain}{RESET}")
    print(f"{CYAN}========================================{RESET}\n")

    if error:
        print(f"  {RED}x{RESET} Status: {RED}FAILED{RESET}")
        print(f"  {DIM}!{RESET} {error}")
        return False, 0

    if success:
        print(f"  {GREEN}OK{RESET} Status: {GREEN}WORKS{RESET}")
        print(f"  {GREEN}*{RESET} Latency: {latency:.1f} ms")
        return True, latency

    print(f"  {RED}x{RESET} Status: {RED}FAILED{RESET}")
    print(f"  {DIM}!{RESET} Possible causes: Server offline, blocked port 53, domain mismatch, or invalid profile settings")
    return False, 0
