import ipaddress
import socket
import statistics
import struct
import time

import requests

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"
RESET = "\033[0m"

TEST_URL = "http://speedtest.tele2.net/10MB.zip"


def _split_target(target: str) -> tuple[str, int]:
    if ":" not in target:
        return target, 443
    host, port = target.rsplit(":", 1)
    return host.strip(), int(port.strip())


def _build_socks_connect_payload(host: str, port: int) -> bytes:
    try:
        ip_obj = ipaddress.ip_address(host)
        if ip_obj.version == 4:
            atyp = b"\x01"
            addr = ip_obj.packed
        else:
            atyp = b"\x04"
            addr = ip_obj.packed
    except ValueError:
        host_bytes = host.encode("idna")
        atyp = b"\x03"
        addr = bytes([len(host_bytes)]) + host_bytes

    return b"\x05\x01\x00" + atyp + addr + struct.pack("!H", port)


def _measure_socks_rtt(proxy_port: int, target_host: str, target_port: int, timeout_seconds: float) -> float | None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout_seconds)
    start = time.perf_counter()
    try:
        sock.connect(("127.0.0.1", proxy_port))
        sock.sendall(b"\x05\x01\x00")
        greeting = sock.recv(2)
        if len(greeting) != 2 or greeting[0] != 0x05 or greeting[1] == 0xFF:
            return None

        payload = _build_socks_connect_payload(target_host, target_port)
        sock.sendall(payload)
        head = sock.recv(4)
        if len(head) != 4 or head[1] != 0x00:
            return None

        atyp = head[3]
        if atyp == 1:
            _ = sock.recv(6)
        elif atyp == 3:
            ln = sock.recv(1)
            if not ln:
                return None
            _ = sock.recv(ln[0] + 2)
        elif atyp == 4:
            _ = sock.recv(18)
        else:
            return None

        end = time.perf_counter()
        return (end - start) * 1000.0
    except Exception:
        return None
    finally:
        try:
            sock.close()
        except Exception:
            pass


def _run_download_test(proxy_port: int, timeout_seconds: float, verbose: bool) -> float:
    proxies = {
        "http": f"socks5://127.0.0.1:{proxy_port}",
        "https": f"socks5://127.0.0.1:{proxy_port}",
    }

    start_time = time.time()
    response = requests.get(TEST_URL, proxies=proxies, stream=True, timeout=max(10, timeout_seconds * 4))
    response.raise_for_status()

    total_size = int(response.headers.get("content-length", 0))
    downloaded = 0

    for chunk in response.iter_content(chunk_size=16384):
        if not chunk:
            continue
        downloaded += len(chunk)
        if verbose and total_size > 0:
            percent = (downloaded / total_size) * 100
            bar_length = 40
            filled = int(bar_length * downloaded / total_size)
            bar = f"{GREEN}{'#' * filled}{DIM}{'-' * (bar_length - filled)}{RESET}"
            elapsed = time.time() - start_time
            speed_mbps = (downloaded * 8) / (max(elapsed, 0.001) * 1024 * 1024)
            print(f"\r  {bar} {percent:5.1f}% {speed_mbps:6.2f} Mbps", end="", flush=True)

    if verbose and total_size > 0:
        print()

    duration = max(time.time() - start_time, 0.001)
    return (downloaded * 8) / (duration * 1024 * 1024)


def run_speedtest(
    proxy_port: int = 5201,
    targets: list[str] | None = None,
    attempts: int = 5,
    timeout_seconds: float = 2.5,
    verbose: bool = True,
) -> dict:
    if targets is None or len(targets) == 0:
        targets = ["1.1.1.1:443", "8.8.8.8:443", "cloudflare.com:443"]

    attempts = max(1, int(attempts))

    if verbose:
        print(f"\n{CYAN}====================================================={RESET}")
        print(f"{CYAN}  {YELLOW}Running Real Speed Test via SOCKS5...{RESET}")
        print(f"{CYAN}====================================================={RESET}\n")

    rtts = []
    failed = 0

    for i in range(attempts):
        target = targets[i % len(targets)]
        host, port = _split_target(target)
        rtt = _measure_socks_rtt(proxy_port, host, port, timeout_seconds)
        if rtt is None:
            failed += 1
            if verbose:
                print(f"  {RED}x{RESET} RTT to {target}: failed")
        else:
            rtts.append(rtt)
            if verbose:
                print(f"  {GREEN}*{RESET} RTT to {target}: {rtt:.1f} ms")

    packet_loss = (failed / attempts) * 100.0

    if len(rtts) > 0:
        latency_avg = sum(rtts) / len(rtts)
        latency_min = min(rtts)
        latency_max = max(rtts)
        if len(rtts) > 1:
            jitter = statistics.mean(abs(rtts[i] - rtts[i - 1]) for i in range(1, len(rtts)))
        else:
            jitter = 0.0
    else:
        latency_avg = 0.0
        latency_min = 0.0
        latency_max = 0.0
        jitter = 0.0

    download_mbps = 0.0
    download_error = ""
    try:
        if verbose:
            print(f"\n  {YELLOW}*{RESET} Running download benchmark...")
        download_mbps = _run_download_test(proxy_port, timeout_seconds, verbose)
    except Exception as e:
        download_error = str(e)
        if verbose:
            print(f"  {RED}x{RESET} Download benchmark failed: {download_error}")

    success = len(rtts) > 0

    result = {
        "success": success,
        "latency_avg_ms": float(latency_avg),
        "latency_min_ms": float(latency_min),
        "latency_max_ms": float(latency_max),
        "jitter_ms": float(jitter),
        "packet_loss_pct": float(packet_loss),
        "download_mbps": float(download_mbps),
        "attempts": attempts,
        "samples": len(rtts),
        "targets": targets,
        "error": download_error if not success else "",
    }

    if verbose and success:
        print(f"\n  {GREEN}Result:{RESET} avg={latency_avg:.1f}ms min={latency_min:.1f}ms max={latency_max:.1f}ms jitter={jitter:.1f}ms loss={packet_loss:.1f}% down={download_mbps:.2f}Mbps")

    if verbose and not success:
        print(f"\n  {RED}x{RESET} RTT measurement failed on all attempts")

    return result
