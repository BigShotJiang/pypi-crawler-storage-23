======================
The TPATH testing path
======================

Some features inside of pop can scan the available paths in python and find extra
plugins. This directory gets added to the sys.path in the test run so we can validate
these types of scans
