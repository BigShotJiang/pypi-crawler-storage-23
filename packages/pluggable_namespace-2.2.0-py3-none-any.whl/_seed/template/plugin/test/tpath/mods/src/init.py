async def func(hub):
    """
    This function will be available to the testing hub as:

        hub.test.init.func()
    """
