====
rend
====

.. image:: https://img.shields.io/badge/made%20with-python-yellow
   :alt: Made with Python
   :target: https://www.python.org/

A collection of tools to render text files into data structures.

About
=====

Rend is the renderer collection used by ``pluggable-namespace`` and ``pluggable-namespace`` derived projects.
It allows for text files of multiple types to be read and rendered into
consistent data structures. These files also get the benefit of having
access to specific components of the hub.
