async def display(hub, data):
    """
    Print the raw data
    """
    return str(data)
