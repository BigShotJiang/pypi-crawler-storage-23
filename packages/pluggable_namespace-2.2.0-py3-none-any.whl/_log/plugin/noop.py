async def process(hub, msg: str):
    """
    No logger, just consume the message
    """
