class PaystackError(Exception):
    """Base exception for all SmartPaystack errors."""
    pass

class PaystackAPIError(PaystackError):
    """Raised when the Paystack API returns an error or fails."""
    pass

class WebhookVerificationError(PaystackError):
    """Raised when a webhook signature fails validation."""
    pass