import os
import uuid
import requests
from decimal import Decimal
from typing import Optional, Dict, Any, Union

from .calculator import PaystackFeeCalculator
from .enums import ChargeStrategy, Currency, RecipientType, TransferSource
from .exceptions import PaystackAPIError

class SmartPaystack:
    """The main client for interacting with the Paystack API."""
    BASE_URL = "https://api.paystack.co"

    def __init__(self, secret_key: Optional[str] = None) -> None:
        self.secret_key = secret_key or os.environ.get("PAYSTACK_SECRET_KEY")
        
        if not self.secret_key:
            raise ValueError(
                "Paystack secret key missing. Pass it to the client "
                "or set the 'PAYSTACK_SECRET_KEY' environment variable."
            )
            
        self.headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None, params: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{self.BASE_URL}{endpoint}"
        try:
            response = requests.request(
                method, url, json=data, params=params, headers=self.headers, timeout=30
            )
            result = response.json()
        except requests.RequestException as e:
            raise PaystackAPIError(f"Network error: {str(e)}")
        except ValueError:
            raise PaystackAPIError("Invalid JSON response from Paystack.")

        if not response.ok or not result.get("status"):
            raise PaystackAPIError(result.get("message", "API Request Failed"))
            
        return result.get("data", result)

    def create_charge(
        self, 
        email: str, 
        amount: Union[int, float, Decimal], 
        currency: Currency = Currency.NGN,
        charge_strategy: ChargeStrategy = ChargeStrategy.ABSORB, 
        split_ratio: float = 0.5, 
        metadata: Optional[Dict[str, Any]] = None, 
        **kwargs: Any
    ) -> Dict[str, Any]:
        """Initializes a transaction applying the correct fee strategy automatically."""
        amount = Decimal(str(amount))
        fee = PaystackFeeCalculator.calculate_fee(amount, currency)

        if charge_strategy == ChargeStrategy.PASS:
            customer_amount = PaystackFeeCalculator.gross_up_amount(amount, currency)
        elif charge_strategy == ChargeStrategy.SPLIT:
            customer_amount = amount + (fee * Decimal(str(split_ratio)))
        else:
            customer_amount = amount

        payload = {
            "email": email,
            "amount": int(customer_amount * 100), # Convert to lowest denomination (kobo/cents)
            "currency": currency.value,
            "reference": kwargs.pop("reference", str(uuid.uuid4())),
            "metadata": {
                "smartpaystack_strategy": charge_strategy.value,
                "merchant_expected": float(amount),
                "customer_amount": float(customer_amount),
                **(metadata or {}),
            },
            **kwargs
        }
        return self._request("POST", "/transaction/initialize", data=payload)
    
    def resolve_account_number(self, account_number: str, bank_code: str) -> Dict[str, Any]:
        """Verifies an account number and bank code before creating a recipient."""
        params = {"account_number": account_number, "bank_code": bank_code}
        return self._request("GET", "/bank/resolve", params=params)

    def create_transfer_recipient(
        self, 
        name: str, 
        account_number: str, 
        bank_code: str, 
        recipient_type: RecipientType = RecipientType.NUBAN,
        currency: Currency = Currency.NGN,
        description: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Creates a recipient code needed to initiate a transfer."""
        payload = {
            "type": recipient_type.value,
            "name": name,
            "account_number": account_number,
            "bank_code": bank_code,
            "currency": currency.value,
            "description": description,
            "metadata": metadata or {}
        }
        return self._request("POST", "/transferrecipient", data=payload)

    def initiate_transfer(
        self, 
        amount: Union[int, float, Decimal], 
        recipient_code: str, 
        currency: Currency = Currency.NGN,
        source: TransferSource = TransferSource.BALANCE,
        reason: str = "",
        reference: Optional[str] = None
    ) -> Dict[str, Any]:
        """Initiates a transfer from your Paystack balance to the recipient."""
        payload = {
            "source": source.value,
            "amount": int(Decimal(str(amount)) * 100), # Convert to kobo/cents
            "currency": currency.value,
            "recipient": recipient_code,
            "reason": reason,
            "reference": reference or str(uuid.uuid4())
        }
        return self._request("POST", "/transfer", data=payload)
    



    def create_plan(
        self,
        name: str,
        amount: Union[int, float, Decimal],
        interval: "Interval", 
        currency: Currency = Currency.NGN,
        description: str = "",
        **kwargs: Any
    ) -> Dict[str, Any]:
        """Creates a recurring subscription plan."""
        payload = {
            "name": name,
            "amount": int(Decimal(str(amount)) * 100), # Convert to kobo/cents
            "interval": interval.value,
            "currency": currency.value,
            "description": description,
            **kwargs
        }
        return self._request("POST", "/plan", data=payload)

    def create_subscription(
        self,
        customer_email: str,
        plan_code: str,
        authorization: Optional[str] = None,
        start_date: Optional[str] = None,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """Subscribes a customer to a plan."""
        payload = {
            "customer": customer_email,
            "plan": plan_code,
            **kwargs
        }
        if authorization:
            payload["authorization"] = authorization
        if start_date:
            payload["start_date"] = start_date
            
        return self._request("POST", "/subscription", data=payload)

    def enable_subscription(self, subscription_code: str, email_token: str) -> Dict[str, Any]:
        """Enables a paused or disabled subscription."""
        payload = {"code": subscription_code, "token": email_token}
        return self._request("POST", "/subscription/enable", data=payload)

    def disable_subscription(self, subscription_code: str, email_token: str) -> Dict[str, Any]:
        """Disables an active subscription."""
        payload = {"code": subscription_code, "token": email_token}
        return self._request("POST", "/subscription/disable", data=payload)