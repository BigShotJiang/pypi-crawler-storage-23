"""Backward-compatible app shim. Implementation moved to modules/migrate/."""

from specfact_cli.modules.migrate.src.commands import app


__all__ = ["app"]
