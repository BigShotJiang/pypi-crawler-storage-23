"""Backward-compatible app shim. Implementation moved to modules/repro/."""

from specfact_cli.modules.repro.src.commands import app


__all__ = ["app"]
