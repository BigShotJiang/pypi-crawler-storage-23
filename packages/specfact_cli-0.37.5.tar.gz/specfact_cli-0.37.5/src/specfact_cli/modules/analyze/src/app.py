"""analyze command entrypoint."""

from specfact_cli.modules.analyze.src.commands import app


__all__ = ["app"]
