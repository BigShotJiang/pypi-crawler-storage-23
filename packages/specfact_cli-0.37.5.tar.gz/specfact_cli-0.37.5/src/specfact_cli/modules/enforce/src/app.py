"""enforce command entrypoint."""

from specfact_cli.modules.enforce.src.commands import app


__all__ = ["app"]
