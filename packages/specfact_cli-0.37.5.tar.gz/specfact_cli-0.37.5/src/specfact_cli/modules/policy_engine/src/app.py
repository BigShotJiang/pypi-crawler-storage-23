"""policy command entrypoint."""

from specfact_cli.modules.policy_engine.src.commands import app


__all__ = ["app"]
