"""Patch commands: apply."""
