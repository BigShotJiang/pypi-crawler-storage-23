"""Schemas list and schema detail widgets."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import openapi_pydantic.v3.v3_0 as _v30
import openapi_pydantic.v3.v3_1 as _v31
from textual.app import ComposeResult
from textual.binding import Binding
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Markdown, Static, Tree

from ..._diff import ChangeType, SchemaPropertyChange
from ..._parser import NamedSchema, OpenAPIParser, Schema
from .._diff_service import DiffService

_REFERENCE_TYPES = (_v30.Reference, _v31.Reference)


@runtime_checkable
class _SchemaLinkRouter(Protocol):
    def action_view_schema(self, name: str) -> None: ...


def _schema_type_markup(schema: _v30.Schema | _v31.Schema) -> str:
    if schema.allOf:
        return "[dim]allOf[/dim]"
    if schema.oneOf:
        return "[dim]oneOf[/dim]"
    if schema.anyOf:
        return "[dim]anyOf[/dim]"
    t = schema.type
    if t is None:
        return "[dim]any[/dim]"

    t = t[0] if isinstance(t, list) else t
    type_str = t.value if t else "object"
    return f"[dim]{type_str}[/dim]"


def _prop_type_str(
    openapi: OpenAPIParser,
    prop_schema: _v30.Reference | _v31.Reference | _v30.Schema | _v31.Schema,
) -> str:
    if isinstance(prop_schema, _REFERENCE_TYPES):
        ref_name = prop_schema.ref.split("/")[-1]
        return f"[{ref_name}](schema:{ref_name})"

    if prop_schema.allOf:
        parts = [_prop_type_str(openapi, s) for s in prop_schema.allOf]
        return "allOf(" + ", ".join(parts) + ")"
    if prop_schema.oneOf:
        parts = [_prop_type_str(openapi, s) for s in prop_schema.oneOf]
        return "oneOf(" + ", ".join(parts) + ")"
    if prop_schema.anyOf:
        parts = [_prop_type_str(openapi, s) for s in prop_schema.anyOf]
        return "anyOf(" + ", ".join(parts) + ")"

    t = prop_schema.type
    t = t[0] if isinstance(t, list) else t

    if t is not None and t.value == "array":
        items = prop_schema.items
        if items is None:
            return "array"
        if isinstance(items, _REFERENCE_TYPES):
            item_name = items.ref.split("/")[-1]
            return f"array of [{item_name}](schema:{item_name})"
        item_type = items.type
        if item_type is None:
            return "array"
        item_type = item_type[0] if isinstance(item_type, list) else item_type
        return f"array of `{item_type.value}`"

    if t is None:
        return "*unspecified*"

    fmt = prop_schema.schema_format
    return f"`{t.value}`" + (f" ({fmt})" if fmt else "")


def _prop_constraints(schema: Schema) -> str:
    parts: list[str] = []
    if schema.minimum is not None:
        parts.append(f"min: {schema.minimum}")
    if schema.maximum is not None:
        parts.append(f"max: {schema.maximum}")
    if schema.exclusiveMinimum is not None:
        parts.append(f"excl. min: {schema.exclusiveMinimum}")
    if schema.exclusiveMaximum is not None:
        parts.append(f"excl. max: {schema.exclusiveMaximum}")
    if schema.multipleOf is not None:
        parts.append(f"multiple of: {schema.multipleOf}")
    if schema.minLength is not None:
        parts.append(f"minLen: {schema.minLength}")
    if schema.maxLength is not None:
        parts.append(f"maxLen: {schema.maxLength}")
    if schema.pattern is not None:
        parts.append(f"pattern: `{schema.pattern}`")
    if schema.minItems is not None:
        parts.append(f"minItems: {schema.minItems}")
    if schema.maxItems is not None:
        parts.append(f"maxItems: {schema.maxItems}")
    if schema.uniqueItems:
        parts.append("unique")
    if schema.enum:
        values = ", ".join(f"`{v}`" for v in schema.enum)
        parts.append(f"enum: {values}")
    return ", ".join(parts)


def _schema_to_markdown(
    openapi: OpenAPIParser,
    diff_service: DiffService,
    named_schema: NamedSchema,
) -> str:
    """Render a Schema as Markdown content."""
    lines: list[str] = []

    name, referenced_schema = named_schema
    schema: Schema = openapi.get_referenced(referenced_schema)  # type: ignore[assignment]

    if schema.description:
        lines.append(schema.description.strip())
        lines.append("")

    properties = schema.properties or {}
    required_fields = set(schema.required or [])

    # Collect removed properties from the base schema
    removed_properties: dict[
        str, _v30.Schema | _v31.Schema | _v30.Reference | _v31.Reference
    ] = {}
    removed_required_fields: set[str] = set()
    if diff_service.base_parser and diff_service.is_diff_available():
        base_schema_map = dict(diff_service.base_parser.schemas)
        if name in base_schema_map:
            base_schema_entry = diff_service.base_parser.get_referenced(
                base_schema_map[name]
            )
            if isinstance(base_schema_entry, (_v30.Schema, _v31.Schema)):
                base_props = base_schema_entry.properties or {}
                removed_required_fields = set(base_schema_entry.required or [])
                for prop_name in set(base_props) - set(properties):
                    prop_change = diff_service.get_property_change(name, prop_name)
                    if (
                        isinstance(prop_change, SchemaPropertyChange)
                        and prop_change.change_type == ChangeType.REMOVED
                    ):
                        removed_properties[prop_name] = base_props[prop_name]

    if properties or removed_properties:
        lines.append("### Properties")
        lines.append("")
        lines.append("| Property | Req | Type | Constraints | Description |")
        lines.append("| --- | --- | --- | --- | --- |")
        for prop_name, prop_schema in properties.items():
            prop_change = diff_service.get_property_change(name, prop_name)
            if diff_service.is_diff_only_mode() and prop_change is None:
                continue

            # Apply diff highlighting
            diff_prefix = ""
            if isinstance(prop_change, SchemaPropertyChange):
                if prop_change.change_type == ChangeType.ADDED:
                    diff_prefix = "`+` "
                elif prop_change.change_type == ChangeType.REMOVED:
                    diff_prefix = "`-` "
                elif prop_change.change_type == ChangeType.MODIFIED:
                    diff_prefix = "`~` "

            name_markup = f"{diff_prefix}**{prop_name}**"

            req = "✱" if prop_name in required_fields else ""
            type_str = _prop_type_str(openapi, prop_schema)

            resolved_schema: Schema
            if isinstance(prop_schema, _REFERENCE_TYPES):
                resolved_schema = openapi.resolve_reference(prop_schema)
            else:
                resolved_schema = prop_schema

            constraints = _prop_constraints(resolved_schema)
            desc = (
                (resolved_schema.description or "")
                .replace("|", "\\|")
                .replace("\n", " ")
                .strip()
            )

            # Add change indicator for modified properties
            change_indicator = ""
            if prop_change and prop_change.change_type == ChangeType.MODIFIED:
                change_details = []
                for fc in prop_change.field_changes:
                    if fc.field == "required":
                        change_details.append(
                            f"required: {fc.old_value} → {fc.new_value}"
                        )
                    elif fc.field == "type":
                        change_details.append(f"type: {fc.old_value} → {fc.new_value}")
                    elif fc.field == "description":
                        change_details.append("description changed")
                    elif fc.field == "enum":
                        change_details.append("enum values changed")
                if change_details:
                    change_indicator = f"  *({', '.join(change_details)})*"

            lines.append(
                f"| {name_markup} | {req} | {type_str} | {constraints} | {desc} {change_indicator}|"
            )
        base_parser = diff_service.base_parser
        for prop_name, prop_schema in removed_properties.items():
            removed_resolved: Schema
            if isinstance(prop_schema, _REFERENCE_TYPES):
                assert base_parser is not None
                removed_resolved = base_parser.resolve_reference(prop_schema)
            else:
                removed_resolved = prop_schema

            req = "✱" if prop_name in removed_required_fields else ""
            assert base_parser is not None
            type_str = _prop_type_str(base_parser, prop_schema)
            constraints = _prop_constraints(removed_resolved)
            desc = (
                (removed_resolved.description or "")
                .replace("|", "\\|")
                .replace("\n", " ")
                .strip()
            )
            lines.append(
                f"| `- ` **{prop_name}** | {req} | {type_str} | {constraints} | {desc} |"
            )

        lines.append("")

    for combiner_name, combiner_list in [
        ("allOf", schema.allOf),
        ("oneOf", schema.oneOf),
        ("anyOf", schema.anyOf),
    ]:
        if not combiner_list:
            continue
        lines.append(f"### {combiner_name}")
        lines.append("")
        for sub in combiner_list:
            if isinstance(sub, _REFERENCE_TYPES):
                ref_name = sub.ref.split("/")[-1]
                lines.append(f"- [{ref_name}](schema:{ref_name})")
            else:
                t = sub.type
                t = t[0] if isinstance(t, list) else t
                lines.append(f"- `{t.value if t else 'any'}`")
        lines.append("")

    if schema.enum:
        lines.append("### Enum Values")
        lines.append("")
        for val in schema.enum:
            lines.append(f"- `{val}`")
        lines.append("")

    if not lines:
        return "*No details available*"

    return "\n".join(lines)


class SchemaDetail(Widget):
    """Shows the details of a selected schema, with navigation history."""

    can_focus = True

    BINDINGS = [
        Binding("b", "back", "← Back", show=False),
    ]

    DEFAULT_CSS = """
    SchemaDetail {
        width: 2fr;
        height: 1fr;
        border: round $primary-darken-2;
        overflow-y: auto;
    }
    SchemaDetail #schema-placeholder {
        height: 1fr;
        content-align: center middle;
        color: $text-muted;
    }
    SchemaDetail Markdown {
        background: transparent;
        padding: 1 2;
        display: none;
    }
    """

    class PanelClosed(Message):
        """Posted when the endpoint-schema panel is closed via back."""

    def __init__(
        self,
        openapi: OpenAPIParser,
        diff_service: DiffService,
        in_endpoint_screen: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.openapi = openapi
        self.in_endpoint_screen = in_endpoint_screen
        self.diff_service = diff_service
        self._schema: NamedSchema | None = None
        self._history: list[NamedSchema] = []

    def on_mount(self) -> None:
        self.border_title = "Schema"

    def compose(self) -> ComposeResult:
        yield Static(
            "[dim]Select a schema from the list[/dim]",
            id="schema-placeholder",
            markup=True,
        )
        yield Markdown("", id="schema-markdown", open_links=False)

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        """Route schema: links to the appropriate panel."""
        if event.href.startswith("schema:"):
            schema_name = event.href[len("schema:") :]
            screen = self.screen
            if isinstance(screen, _SchemaLinkRouter):
                screen.action_view_schema(schema_name)
            event.prevent_default()

    def show_schema(self, schema: NamedSchema) -> None:
        """Navigate directly (clears history — used by SchemasList selection)."""
        self._history.clear()
        self._schema = schema
        self._refresh_display()

    def reload(self, openapi: OpenAPIParser) -> None:
        self.openapi = openapi
        self.reset()

    def rerender(self) -> None:
        """Re-render the currently displayed schema, e.g. after a mode toggle."""
        self._refresh_display()

    def reset(self) -> None:
        """Clear history and current schema (used when closing the panel)."""
        self._history.clear()
        self._schema = None
        self.border_title = "Schema"
        self.border_subtitle = ""
        self.query_one("#schema-placeholder").display = True
        self.query_one("#schema-markdown", Markdown).display = False

    def navigate_to(self, schema: NamedSchema) -> None:
        """Navigate to schema while pushing the current one onto history."""
        if self._schema is not None:
            self._history.append(self._schema)
        self._schema = schema
        self._refresh_display()

    def action_back(self) -> None:
        """Go back in history, or close/clear the panel if history is empty."""
        if self._history:
            self._schema = self._history.pop()
            self._refresh_display()
        elif self.in_endpoint_screen:
            self._schema = None
            self.display = False
            self.border_subtitle = ""
            self.post_message(self.PanelClosed())

    def _refresh_display(self) -> None:
        if self._schema is None:
            return

        name, schema = self._schema

        self.query_one("#schema-placeholder").display = False

        type_markup = (
            _schema_type_markup(schema)
            if isinstance(schema, (_v30.Schema, _v31.Schema))
            else ""
        )

        # Add diff indicator if available
        diff_indicator = ""
        if self.diff_service.is_diff_available():
            change_type = self.diff_service.get_schema_change_type(name)
            if change_type:
                icon = self.diff_service.get_change_icon(change_type)
                diff_indicator = f"  {icon}"

        self.border_title = f"[bold]{name}[/bold] {type_markup}{diff_indicator}"
        if self._history:
            trail = " › ".join(s[0] for s in self._history) + f" › {name}"
            self.border_subtitle = f"{trail}  b: back"
        elif self.in_endpoint_screen:
            self.border_subtitle = f"{name}  b: close"
        else:
            self.border_subtitle = ""

        md = self.query_one("#schema-markdown", Markdown)
        md.display = True
        if isinstance(schema, (_v30.Schema, _v31.Schema)):
            md.update(
                _schema_to_markdown(self.openapi, self.diff_service, self._schema)
            )


def _get_schema_label(schema: NamedSchema, diff_service: DiffService) -> str:
    """Get the Tree label markup for a schema entry."""
    name, s = schema
    type_markup = (
        _schema_type_markup(s) if isinstance(s, (_v30.Schema, _v31.Schema)) else ""
    )

    diff_indicator = ""
    if diff_service.is_diff_available():
        change_type = diff_service.get_schema_change_type(name)
        if change_type:
            icon = diff_service.get_change_icon(change_type)
            diff_indicator = f"{icon} "

    return f"{diff_indicator}[bold]{name}[/bold]  {type_markup}"


class SchemasList(Widget):
    """Widget showing all schemas from the OpenAPI spec."""

    DEFAULT_CSS = """
    SchemasList {
        width: 1fr;
        height: 1fr;
        border: round $primary-darken-2;
        margin: 0 1 0 0;
    }
    SchemasList > Tree {
        height: 1fr;
        border: none;
        background: $surface;
        padding: 0 0 0 1;
    }
    """

    class SchemaSelected(Message):
        """Posted when the user selects a schema."""

        def __init__(self, schema: NamedSchema) -> None:
            super().__init__()
            self.schema = schema

    def __init__(self, openapi: OpenAPIParser, diff_service: DiffService) -> None:
        super().__init__()
        self.openapi = openapi
        self.diff_service = diff_service

    def compose(self) -> ComposeResult:
        yield Tree("Schemas", id="schemas-tree")

    def on_mount(self) -> None:
        self.border_title = "Schemas"
        tree = self.query_one("#schemas-tree", Tree)
        tree.show_root = False
        tree.show_guides = False
        self._rebuild_tree()

    def reload(self, openapi: OpenAPIParser) -> None:
        self.openapi = openapi
        self._rebuild_tree()

    def _rebuild_tree(self) -> None:
        tree: Tree[NamedSchema] = self.query_one("#schemas-tree", Tree)
        tree.root.remove_children()
        for named_schema in self.openapi.schemas:
            name, _ = named_schema
            if not self.diff_service.should_show_schema(name):
                continue
            tree.root.add_leaf(
                _get_schema_label(named_schema, self.diff_service),
                data=named_schema,
            )

    def on_tree_node_selected(self, event: Tree.NodeSelected[NamedSchema]) -> None:
        if event.node.data is not None:
            self.post_message(self.SchemaSelected(event.node.data))

    def select_schema(self, name: str) -> None:
        """Move the tree cursor to the schema with the given name (if visible)."""
        tree: Tree[NamedSchema] = self.query_one("#schemas-tree", Tree)
        for node in tree.root.children:
            if node.data is not None and node.data[0] == name:
                tree.move_cursor(node)
                break

    def apply_diff_filtering(self) -> None:
        """Apply diff filtering to the schemas list."""
        self._rebuild_tree()
