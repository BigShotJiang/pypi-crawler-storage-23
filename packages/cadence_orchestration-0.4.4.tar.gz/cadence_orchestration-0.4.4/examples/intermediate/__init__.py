"""Intermediate examples - branching, parallelism, hooks, and composition."""
