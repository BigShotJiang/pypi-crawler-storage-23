"""Basic examples - getting started with Cadence."""
