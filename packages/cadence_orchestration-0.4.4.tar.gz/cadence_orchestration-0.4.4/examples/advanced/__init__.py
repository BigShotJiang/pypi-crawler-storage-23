"""Advanced examples - framework integration, resilience, and testing."""
