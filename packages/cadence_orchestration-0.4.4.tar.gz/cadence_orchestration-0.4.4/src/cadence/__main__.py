"""Entry point for `python -m cadence`."""

import sys

from cadence.cli import main

if __name__ == "__main__":
    sys.exit(main())
