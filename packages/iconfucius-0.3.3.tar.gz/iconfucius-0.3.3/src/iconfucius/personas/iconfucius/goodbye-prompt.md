Say goodbye to the user in one short sentence in your voice. Be warm and wise.
