Reply with a single profound quote about {topic}. Start with "{icon} ". Do not wrap the quote in quotation marks. One line only.
