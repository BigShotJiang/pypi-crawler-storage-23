"""IConfucius | Wisdom for Bitcoin Markets"""

__version__ = "0.3.3"
