"""Allow running as `python -m opencode_usage`."""

from .cli import main

main()
