from pathlib import Path
from typing import Optional
import platform
import sys
from .logger import logger


def not_preferred(obj):
    """
    This algorithm is not preferred.
    :param obj:
    :return:
    """
    return obj


def visible_for_testing(func):
    """
    annotation for function that exits for testing
    :param func:
    :return:
    """
    return func


def is_android() -> bool:
    return "android" in platform.system().lower() or "ANDROID_ARGUMENT" in sys.argv


def assert_folder_exists(folder: Path):
    """
    assert folder exists, and print the first not exists folder if not exits.
    :param folder:
    :return:
    """
    assert folder.exists(), (f'{folder} dose not exist, and the first not exist folder is: '
                             f'{_safe_as_posix(_get_first_not_exists(folder))}')


def _safe_as_posix(path: Optional[Path]) -> str:
    if path is None:
        return "None"
    return path.resolve().as_posix()


def _get_first_not_exists(path: Path) -> Optional[Path]:
    """
    返回路径中第一个不存在的部分。
    如果路径所有父级都存在，但完整路径不存在，则返回该完整路径本身。
    """
    path = path.resolve()
    p = path

    # 不断向上回溯，直到找到存在的部分
    while not p.exists():
        parent = p.parent
        if parent == p:  # 已到最顶层（防止死循环）
            return p
        p = parent

    # 此时 p 是第一个存在的路径
    # 从 p 开始一点点往下找第一个不存在的部分
    current = p
    for part in path.parts[len(p.parts):]:
        current = current / part
        if not current.exists():
            return current

    # 如果都存在（极小概率情况），返回 None 或路径本身
    return None
