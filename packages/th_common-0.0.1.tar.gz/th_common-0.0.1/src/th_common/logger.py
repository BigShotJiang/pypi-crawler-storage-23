# this is a simple logger that will print to the file also
import logging
from logging.handlers import TimedRotatingFileHandler

logger = logging.getLogger("app")
logger.setLevel(logging.INFO)

handler = TimedRotatingFileHandler(
    filename="app.log",
    when="midnight",   # 每天切割
    interval=1,
    backupCount=7,     # 只保留7个文件（自动删除旧的）
    encoding="utf-8"
)

formatter = logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s"
)
handler.setFormatter(formatter)

logger.addHandler(handler)