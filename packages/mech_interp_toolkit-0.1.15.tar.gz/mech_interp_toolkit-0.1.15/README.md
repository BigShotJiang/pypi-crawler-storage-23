# MI-Toolkit

A comprehensive library for mechanistic interpretability of language models.

## Installation

```bash
pip install mech_interp_toolkit
```

## Usage

Work in progress!