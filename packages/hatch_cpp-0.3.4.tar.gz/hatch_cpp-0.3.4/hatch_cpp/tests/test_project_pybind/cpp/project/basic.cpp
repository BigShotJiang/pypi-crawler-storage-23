#include "project/basic.hpp"

std::string hello() {
    return "A string";
}

