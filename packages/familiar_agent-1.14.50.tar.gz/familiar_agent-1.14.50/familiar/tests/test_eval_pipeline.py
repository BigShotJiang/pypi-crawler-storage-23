# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License - see LICENSE file for details

"""Tests for Pipeline 4: Eval baseline suite and dataset builder."""

import json
from pathlib import Path

BASELINE_PATH = Path(__file__).parent / "evals" / "baseline.json"


# ── baseline.json is valid JSON with ≥10 tests ───────────────

def test_baseline_json_valid():
    data = json.loads(BASELINE_PATH.read_text())
    assert "tests" in data
    assert "name" in data
    assert len(data["tests"]) >= 10


def test_baseline_json_has_25_tests():
    data = json.loads(BASELINE_PATH.read_text())
    assert len(data["tests"]) >= 25


# ── Every test has required fields ────────────────────────────

def test_baseline_tests_have_required_fields():
    data = json.loads(BASELINE_PATH.read_text())
    for test in data["tests"]:
        assert "id" in test, f"Test missing 'id': {test}"
        assert "input" in test, f"Test missing 'input': {test.get('id', '?')}"
        assert "category" in test, f"Test missing 'category': {test.get('id', '?')}"
        assert test["id"], "Test has empty id"
        assert test["input"], "Test has empty input"


def test_baseline_covers_all_categories():
    data = json.loads(BASELINE_PATH.read_text())
    categories = {t["category"] for t in data["tests"]}
    expected = {"conversation", "tool_use", "multi_step", "safety", "personality"}
    assert expected.issubset(categories), f"Missing categories: {expected - categories}"


def test_baseline_ids_unique():
    data = json.loads(BASELINE_PATH.read_text())
    ids = [t["id"] for t in data["tests"]]
    assert len(ids) == len(set(ids)), "Duplicate test IDs found"


# ── load_test_suite parses baseline.json without errors ───────

def test_load_test_suite_parses_baseline():
    from familiar.core.evaluation import load_test_suite

    suite = load_test_suite(BASELINE_PATH)
    assert suite["name"] == "baseline"
    assert len(suite["tests"]) >= 25
    # Verify TestCase objects were created
    for tc in suite["tests"]:
        assert hasattr(tc, "id")
        assert hasattr(tc, "input")
        assert hasattr(tc, "category")


# ── EvalDatasetBuilder.add_from_trace accumulates ─────────────

def test_dataset_builder_add_from_trace():
    from familiar.core.evaluation import EvalDatasetBuilder

    builder = EvalDatasetBuilder()
    builder.add_from_trace(
        user_input="Hello",
        agent_response="Hi there!",
        tools_called=[],
        success=True,
    )
    builder.add_from_trace(
        user_input="Remember my name is Alice",
        agent_response="Got it, I'll remember that.",
        tools_called=["remember"],
        success=True,
    )
    assert len(builder.pending_cases) == 2
    assert builder.pending_cases[0]["input"] == "Hello"
    assert builder.pending_cases[1]["tools"] == ["remember"]


def test_dataset_builder_build_requires_min_cases():
    from familiar.core.evaluation import EvalDatasetBuilder

    builder = EvalDatasetBuilder()
    for i in range(5):
        builder.add_from_trace(
            user_input=f"msg {i}",
            agent_response=f"resp {i}",
            tools_called=[],
            success=True,
        )
    # Default min_cases=10, so this should return None
    result = builder.build_dataset("test_suite")
    assert result is None
    assert len(builder.pending_cases) == 5  # Not cleared on failure
