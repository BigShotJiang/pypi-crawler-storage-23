# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Job Class System — Final Fantasy-inspired agent roles.

Adds a 4th axis to the Personality Triangle: *what role* the agent fills.
Users can switch class anytime via the dashboard, like switching jobs in FFV.

Initial classes:
  - Helper      — general-purpose assistant (default, no extra prompt)
  - Social Worker — case management, advocacy, resource navigation
  - Business Buddy — productivity, scheduling, professional comms
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

JOB_CLASS_REGISTRY: dict[str, "JobClass"] = {}


@dataclass
class JobClass:
    """Definition of an agent job class (role specialization)."""

    key: str  # "social_worker", "helper", "business_buddy"
    name: str  # "Social Worker"
    icon: str  # Font Awesome icon name
    description: str  # One-line summary
    prompt_fragment: str  # Injected into system prompt after species voice
    skill_weights: dict[str, float] = field(default_factory=dict)  # tool -> priority boost
    species_flavor: dict[str, str] = field(default_factory=dict)  # species_key -> flavor text
    recommended_connects: list[str] = field(default_factory=list)  # Service keys to suggest
    proactive_focus: list[str] = field(default_factory=list)  # Topics for proactive check-ins


def register_job_class(cls: JobClass) -> None:
    """Register a job class in the global registry."""
    JOB_CLASS_REGISTRY[cls.key] = cls
    logger.debug("Registered job class: %s", cls.key)


def get_job_class(key: str) -> Optional[JobClass]:
    """Look up a job class by key. Returns None if not found."""
    return JOB_CLASS_REGISTRY.get(key)


def list_job_classes() -> list[JobClass]:
    """Return all registered job classes, sorted by key."""
    return sorted(JOB_CLASS_REGISTRY.values(), key=lambda jc: jc.key)


def get_active_job_class() -> Optional[JobClass]:
    """Read from creature state, return the active JobClass or None."""
    try:
        from ..creature.state import load_creature

        creature = load_creature()
        if creature and creature.job_class:
            return JOB_CLASS_REGISTRY.get(creature.job_class)
    except Exception:
        pass
    return None


# Auto-import job class modules to populate the registry
from . import business_buddy as _bb  # noqa: E402, F401
from . import helper as _h  # noqa: E402, F401
from . import social_worker as _sw  # noqa: E402, F401
