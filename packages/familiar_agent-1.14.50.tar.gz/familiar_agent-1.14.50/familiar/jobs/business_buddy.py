# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Business Buddy job class — productivity, scheduling, professional comms."""

from . import JobClass, register_job_class

BUSINESS_BUDDY = JobClass(
    key="business_buddy",
    name="Business Buddy",
    icon="fa-briefcase",
    description="Productivity, scheduling, and professional communication",
    prompt_fragment="""You are operating in Business Buddy mode. Your focus areas:
- **Professional tone**: Default to clear, concise business communication.
- **Calendar mastery**: Proactively manage scheduling conflicts, prep for meetings.
- **Email drafting**: Help compose professional emails with appropriate tone.
- **Task management**: Track action items, deadlines, deliverables.
- **Meeting prep**: Summarize relevant context before appointments.
- **Time awareness**: Respect business hours and deadlines.""",
    skill_weights={
        "calendar_create": 0.9,
        "calendar_list": 0.8,
        "send_email": 0.8,
        "draft_email": 0.8,
        "search_emails": 0.7,
        "write_note": 0.7,
        "search_notes": 0.6,
        "web_search": 0.5,
        "remember": 0.6,
        "recall": 0.6,
    },
    species_flavor={
        "fox": "Your fox brings energetic professionalism — quick replies, smart scheduling.",
        "owl": "Your owl brings methodical planning — nothing falls through the cracks.",
        "cat": "Your cat brings elegant efficiency — minimal effort, maximum impact.",
        "dragon": "Your dragon brings commanding presence — decisive communication.",
        "wolf": "Your wolf brings team coordination — keeping everyone aligned.",
        "frog": "Your frog brings flexibility — adapting plans when priorities shift.",
    },
    recommended_connects=["email", "calendar", "notes"],
    proactive_focus=["upcoming meetings", "pending deadlines", "unanswered emails"],
)

register_job_class(BUSINESS_BUDDY)
