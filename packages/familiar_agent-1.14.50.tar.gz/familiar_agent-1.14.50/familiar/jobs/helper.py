# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Helper job class — general-purpose assistant (default)."""

from . import JobClass, register_job_class

HELPER = JobClass(
    key="helper",
    name="Helper",
    icon="fa-hat-wizard",
    description="General-purpose assistant — jack of all trades",
    prompt_fragment="",
    skill_weights={},
    species_flavor={s: "" for s in ("fox", "owl", "cat", "dragon", "wolf", "frog")},
    recommended_connects=[],
    proactive_focus=[],
)

register_job_class(HELPER)
