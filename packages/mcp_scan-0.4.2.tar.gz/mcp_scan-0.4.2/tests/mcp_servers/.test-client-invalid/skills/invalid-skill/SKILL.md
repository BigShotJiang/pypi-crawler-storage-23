---
name: test-skill
license: Complete terms in LICENSE.txt
---

# Test skill

This skill has no name!
