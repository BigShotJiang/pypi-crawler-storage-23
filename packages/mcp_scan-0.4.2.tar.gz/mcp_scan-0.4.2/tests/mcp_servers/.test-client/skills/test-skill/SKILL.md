---
name: test-skill
description: This is a test that everythings is correct
license: Complete terms in LICENSE.txt
---

# Test skill

This skill is just to double check that everything works fine
