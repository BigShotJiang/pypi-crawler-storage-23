# Reporting Security Issues

To report a security vulnerability to us, please see https://docs.snyk.io/snyk-data-and-governance/reporting-security-issues.
