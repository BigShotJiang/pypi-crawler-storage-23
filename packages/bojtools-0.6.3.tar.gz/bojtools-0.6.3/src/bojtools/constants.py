BOJ_HOST = 'https://www.acmicpc.net'
SOLVED_HOST = 'https://solved.ac'
STATUS_NONE = 0
STATUS_AC = 1
STATUS_WA = 2
