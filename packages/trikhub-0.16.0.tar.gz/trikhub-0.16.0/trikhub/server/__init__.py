"""
TrikHub HTTP Server

Placeholder for Phase 6 - will provide FastAPI server matching
packages/trik-server API.
"""

# Will export:
# - create_app() -> FastAPI
# - run_server()
