"""Fast Python documentation browser with IDE-style navigation."""

__version__ = "0.1.9"
