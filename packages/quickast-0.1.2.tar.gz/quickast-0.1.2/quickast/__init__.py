"""QuickAST — Instant codebase intelligence for AI coding agents."""

__version__ = "0.1.2"
