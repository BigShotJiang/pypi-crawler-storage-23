import asyncio
import json
import math
import random
import re
import time
import traceback
from pathlib import Path
from typing import ClassVar

import pandas as pd
from pydantic import BaseModel
from util_common.decorator import deprecated
from util_common.io_util import json2bytes
from util_common.list_util import in_batches
from util_common.path import (
    EXCEL_EXTS,
    IMAGE_EXTS,
    PDF_EXTS,
    WORD_EXTS,
    duplicate,
    ensure_folder,
    get_extension,
    sort_paths,
    split_basename,
)

from batch_store._log import logger
from batch_store.preprocessors import (
    close_all_clients,
    decompress_sample_and_save,
    request_unify_pages,
    save_unified_file,
    unify_pages_and_save,
)
from batch_store.settings import batch_store_settings


class TagRecord(BaseModel):
    batch_name: str
    sample_name: str
    page_name: str
    tag: str


class Page(BaseModel):
    name: str
    page_dir: Path


class Sample(BaseModel):
    name: str
    sample_dir: Path
    pages: list[Page]


class SplitCount(BaseModel):
    train: int = 0
    eval: int = 0
    test: int = 0


class SplitCounts(BaseModel):
    sample_level: SplitCount = SplitCount()
    page_level: SplitCount = SplitCount()


class SplitedSampleNames(BaseModel):
    train: list[str] = []
    eval: list[str] = []
    test: list[str] = []


class SplitDict(BaseModel):
    counts: SplitCounts = SplitCounts()
    samples: SplitedSampleNames = SplitedSampleNames()


class BatchStore:
    """
    功能:
    对一个批次内的样本进行统一的数据预处理, 以及存储操作, 并提供一些辅助功能

    目录结构:
    不指定 batch_dir 时, 数据根目录结构:
    |-batch_store_settings.data_root
    |   |-batches
    |   |   |-batch-1
    |   |   |   |-raw:
    |   |   |   |   |-sample_1.zip
    |   |   |   |   |-sample_2
    |   |   |   |   |-sample_3.pdf
    |   |   |   |   |-sample_4.xls
    |   |   |   |   |-...

    指定 batch_dir 时, 数据根目录结构:
    |-batch_dir
    |   |-raw:
    |   |   |-sample_1.zip
    |   |   |-sample_2
    |   |   |-sample_3.pdf
    |   |   |-sample_4.xls
    |   |   |-...

    依赖:
    解压缩服务
    文件归一化服务

    使用方法:
    配置环境变量 DATA_ROOT 为数据根目录
    配置环境变量 UNIFY_BASE_URL 为文件归一化服务地址

    使用示例:
    batch_store = BatchStore('batch-1')
    asyncio.run(batch_store.preprocess_batch())
    """

    batches_root = batch_store_settings.data_root / 'batches'
    all_batch_names: ClassVar[list[str]] = [x.name for x in sort_paths(batches_root.iterdir())]

    def __init__(self, batch_name: str | None = None, batch_dir: Path | None = None) -> None:
        if batch_name is None and batch_dir is None:
            raise ValueError('batch_name or batch_dir must be provided')
        if batch_name is not None and batch_dir is not None:
            if batch_dir.name != batch_name:
                raise ValueError('batch_name and batch_dir must have the same name')
        self.batch_name = batch_name or batch_dir.name  # type: ignore
        self.batch_dir = batch_dir or self.batches_root / self.batch_name
        self.raw_dir = self.batch_dir / 'raw'
        self.decompressed_dir = self.batch_dir / 'decompressed'
        self.unified_dir = self.batch_dir / 'unified'
        self.failed_dir = self.batch_dir / 'failed'
        self.results_dir = self.batch_dir / 'result'  # 端到端结果存放
        self.debug_dir = self.batch_dir / 'debug'  # 调试结果存放
        self.tag_dir = self.batch_dir / 'tag'  # 端到端标签存放
        self.compare_dir = self.batch_dir / 'compare'  # 端到端结果对比
        self.task_results_dir = self.batch_dir / 'task_results'  # 单任务结果存放
        self.task_tag_dir = self.batch_dir / 'task_tags'  # 备份标注
        self.task_compare_dir = self.batch_dir / 'task_compares'  # 单任务结果对比
        self.classified_dir = (
            self.batch_dir / 'classified'
        )  # 按照分类标签分拣到对应文件夹下用来查看
        self.sessions_dir = (
            self.batch_dir / 'sessions'
        )  # 保存一次运行会话的上下文信息, 应当包含方法/任务ID, 会话ID, 测试ID, 运行时间, 运行参数, 结果路径等
        self.split_dict_path = self.batch_dir / 'split_dict.json'
        self.tagging_status_path = self.batch_dir / 'tagging_status.json'

    def _get_file_type(self, page_dir: Path) -> str | None:
        if get_extension(page_dir) in EXCEL_EXTS:
            return "excel"
        if get_extension(page_dir) in WORD_EXTS:
            return "word"
        if get_extension(page_dir) in PDF_EXTS:
            return "pdf"
        if get_extension(page_dir) in IMAGE_EXTS:
            return "image"
        return None

    @staticmethod
    def _need_check(check_empty: bool, redo_searchable: bool, redo_file_types: list[str]) -> bool:
        return any([check_empty, redo_searchable, redo_file_types])

    def _need_redo(
        self,
        page_dir: Path,
        file_type: str,
        *,
        check_empty: bool,
        redo_searchable: bool,
        redo_file_types: list[str],
    ) -> bool:
        if check_empty and not page_dir.joinpath('pure.txt').read_text().strip():
            return True
        if redo_file_types:
            return file_type in redo_file_types
        if redo_searchable:
            if not page_dir.joinpath('char_block.json').exists():
                return True
            char_block = json.loads(page_dir.joinpath('char_block.json').read_text())
            if (
                not isinstance(char_block, dict)
                or char_block.get('header', {}).get('detect_method') == 'elec'
            ):
                return True
        return False

    @staticmethod
    def _get_file(page_dir: Path, file_type: str) -> tuple[str, bytes] | None:
        if file_type == "excel" and page_dir.joinpath('raw.xlsx').exists():
            return "raw.xlsx", page_dir.joinpath('raw.xlsx').read_bytes()
        if file_type == "word" and page_dir.joinpath('raw.docx').exists():
            return "raw.docx", page_dir.joinpath('raw.docx').read_bytes()
        if file_type == "pdf" and page_dir.joinpath('raw.pdf').exists():
            return "raw.pdf", page_dir.joinpath('raw.pdf').read_bytes()
        if file_type == "image" and page_dir.joinpath('norm.png').exists():
            return "raw.png", page_dir.joinpath('norm.png').read_bytes()
        return None

    async def _process_check_mode(
        self,
        save_dir: Path,
        target_results: list[str],
        check_empty: bool,
        redo_searchable: bool,
        redo_file_types: list[str],
        crop_block_content: bool,
        excel_crop_html_content: bool,
        pdf_ocr_textline_fn_name: str,
        local_debug: bool,
    ) -> None:
        for page_dir in sort_paths(save_dir.iterdir()):
            file_type = self._get_file_type(page_dir)
            if file_type is None:
                continue
            if not self._need_redo(
                page_dir,
                file_type,
                check_empty=check_empty,
                redo_searchable=redo_searchable,
                redo_file_types=redo_file_types,
            ):
                continue
            file = self._get_file(page_dir, file_type)
            if file is None:
                continue
            file_name, file_content = file
            logger.info(f'Checking empty page: {page_dir.name} ...')
            success_pages, failed_files = await request_unify_pages(
                file_name,
                file_content,
                target_results=target_results,
                crop_block_content=crop_block_content,
                excel_crop_html_content=excel_crop_html_content,
                pdf_ocr_textline_fn_name=pdf_ocr_textline_fn_name,
                local_debug=local_debug,
            )
            if file_type == "excel":
                success_pages = [
                    x for x in success_pages if x['sheet_name'] != 'Evaluation Warning'
                ]
            if len(success_pages) == 1:
                await save_unified_file(page_dir, success_pages[0])
                if page_dir.joinpath('pure.txt').read_text().strip():
                    logger.info(f'Extract page success: {page_dir.name}')
                else:
                    logger.info(f'Empty page checked! {page_dir.name}')
            else:
                logger.error(f'Check empty page failed! {page_dir.name}')

    async def _process_normal_mode(
        self,
        sample_path: Path,
        save_dir: Path,
        target_results: list[str],
        crop_block_content: bool = False,
        excel_crop_html_content: bool = False,
        pdf_ocr_textline_fn_name: str = 'default',
        local_debug: bool = False,
    ) -> None:
        file_paths = decompress_sample_and_save(
            sample_path,
            self.decompressed_dir,
            self.failed_dir,
        )
        await asyncio.gather(
            *[
                unify_pages_and_save(
                    file_path,
                    save_dir,
                    self.failed_dir,
                    target_results,
                    crop_block_content,
                    excel_crop_html_content,
                    pdf_ocr_textline_fn_name,
                    local_debug,
                )
                for file_path in file_paths
            ]
        )

    async def _preprocess_sample(
        self,
        sample_path: Path,
        target_results: list[str] = [],
        fix_broken: bool = False,
        check_empty: bool = False,
        redo_searchable: bool = False,
        redo_file_types: list[str] = [],
        crop_block_content: bool = False,
        excel_crop_html_content: bool = False,
        pdf_ocr_textline_fn_name: str = 'default',
        local_debug: bool = False,
        unified_dir: Path | None = None,
    ) -> None:
        if unified_dir is None:
            unified_dir = self.unified_dir
        if not unified_dir.is_dir():
            raise ValueError(f'unified_dir {unified_dir} is not a directory')
        save_dir = unified_dir / sample_path.name
        if fix_broken and save_dir.is_dir():
            return
        try:
            if self._need_check(check_empty, redo_searchable, redo_file_types):
                await self._process_check_mode(
                    save_dir,
                    target_results,
                    check_empty=check_empty,
                    redo_searchable=redo_searchable,
                    redo_file_types=redo_file_types,
                    crop_block_content=crop_block_content,
                    excel_crop_html_content=excel_crop_html_content,
                    pdf_ocr_textline_fn_name=pdf_ocr_textline_fn_name,
                    local_debug=local_debug,
                )
            else:
                await self._process_normal_mode(
                    sample_path,
                    save_dir,
                    target_results,
                    crop_block_content,
                    excel_crop_html_content,
                    pdf_ocr_textline_fn_name,
                    local_debug=local_debug,
                )
        except Exception:
            logger.error(f"Error processing sample {sample_path}: {traceback.format_exc()}")
            self.failed_dir.mkdir(parents=True, exist_ok=True)
            duplicate(sample_path, self.failed_dir / sample_path.name)

    async def preprocess_batch(
        self,
        sample_names: list[str] = [],
        target_results: list[str] = [],
        concurrency: int = 1,
        failed_only: bool = False,
        fix_broken: bool = False,
        check_empty: bool = False,
        redo_searchable: bool = False,
        redo_file_types: list[str] = [],
        crop_block_content: bool = False,
        excel_crop_html_content: bool = False,
        pdf_ocr_textline_fn_name: str = 'default',
        local_debug: bool = False,  # Only available in soft install mode
        unified_dir: Path | None = None,
    ) -> None:
        """Process all samples in the batch with proper error handling.
        target_results: 目标结果类型
            - text: 文本
            - xlsx: Excel
            - html: HTML
            - pdf: PDF
            - norm_image: 归一化图片
            - char_block: 字符块
            - text_block: 文本块
            - table_block: 表格块
        concurrency: 并发数
        failed_only: 只处理 failed 下的样本
        fix_broken: 跳过已经处理过的样本
        check_empty: 检查样本 pure.txt 是否为空, 如果为空再试一次
        redo_searchable: 重新识别 detect_method 为 elec 的样本
        redo_file_types: 重新识别指定类型的文件, 支持 excel, word, pdf, image
        failed_only, fix_broken, check_empty, redo_searchable, redo_file_types 不可以组合使用
        """
        if (
            sum(
                [
                    1 if x else 0
                    for x in [
                        failed_only,
                        fix_broken,
                        check_empty,
                        redo_searchable,
                        len(redo_file_types),
                    ]
                ]
            )
            > 1
        ):
            raise ValueError(
                'failed_only, fix_broken, check_empty, redo_searchable, redo_file_types 不可以组合使用'
            )
        # Ensure all required directories exist
        for dir_path in [
            self.raw_dir,
            self.decompressed_dir,
            self.unified_dir,
            self.failed_dir,
        ]:
            ensure_folder(dir_path)

        try:
            if failed_only:
                sample_paths = sort_paths(self.failed_dir.iterdir())
            else:
                sample_paths = sort_paths(self.raw_dir.iterdir())
            if sample_names:
                sample_paths = [x for x in sample_paths if x.name in sample_names]

            for i, samples in enumerate(in_batches(sample_paths, concurrency)):
                start_time = time.time()

                await asyncio.gather(
                    *[
                        self._preprocess_sample(
                            sample_path,
                            target_results,
                            fix_broken,
                            check_empty,
                            redo_searchable,
                            redo_file_types,
                            crop_block_content,
                            excel_crop_html_content,
                            pdf_ocr_textline_fn_name,
                            local_debug,
                            unified_dir,
                        )
                        for sample_path in samples
                    ]
                )
                end_time = time.time()
                logger.info(
                    f'### Preprocess batch {i + 1} finished in {end_time - start_time:.2f} seconds'
                )
        except Exception as e:
            logger.error(f"Error in preprocess_batch: {traceback.format_exc()}")
            raise e
        finally:
            await close_all_clients()

    def load_unified_samples(self) -> list[Sample]:
        samples = []
        for sample_dir in sort_paths(self.unified_dir.iterdir()):
            pages = []
            for page_dir in sort_paths(sample_dir.iterdir()):
                pages.append(Page(name=page_dir.name, page_dir=page_dir))
            samples.append(Sample(name=sample_dir.name, sample_dir=sample_dir, pages=pages))
        return samples

    def save_sample(self, content: bytes, file_name: str):
        save_path = self.raw_dir / file_name
        ensure_folder(save_path.parent)
        save_path.write_bytes(content)

    def split_dataset(
        self,
        train_proportion: float = 0.8,
        eval_proportion: float = 0.1,
        test_proportion: float = 0.1,
        seed: int = 42,
        update_proportion: bool = False,
    ) -> SplitDict:
        """
        Split the dataset into train, eval and test sets.
        自动删除实际不存在的样本, 更新新加入的样本。
        如果 update_proportion 为 False, 不会更新旧样本的数据的 split_type, 只会给新加入的数据按比例分配。
        """
        total_proportion = train_proportion + eval_proportion + test_proportion
        if not math.isclose(total_proportion, 1.0, rel_tol=1e-9, abs_tol=1e-9):
            message = (
                'train_proportion + eval_proportion + test_proportion must be 1 '
                f'(got {total_proportion:.12f})'
            )
            raise ValueError(message)

        random.seed(seed)
        samples = self.load_unified_samples()
        if self.split_dict_path.exists():
            split_dict = SplitDict.model_validate_json(self.split_dict_path.read_text())
        else:
            split_dict = SplitDict()

        actual_train_samples: list[str] = []
        actual_eval_samples: list[str] = []
        actual_test_samples: list[str] = []

        train_page_counts = 0
        eval_page_counts = 0
        test_page_counts = 0
        for sample in samples:
            if sample.name in split_dict.samples.train:
                actual_train_samples.append(sample.name)
                train_page_counts += len(sample.pages)
            elif sample.name in split_dict.samples.eval:
                actual_eval_samples.append(sample.name)
                eval_page_counts += len(sample.pages)
            elif sample.name in split_dict.samples.test:
                actual_test_samples.append(sample.name)
                test_page_counts += len(sample.pages)
            else:
                _random = random.random()
                if _random <= train_proportion:
                    actual_train_samples.append(sample.name)
                    train_page_counts += len(sample.pages)
                elif _random <= train_proportion + eval_proportion:
                    actual_eval_samples.append(sample.name)
                    eval_page_counts += len(sample.pages)
                else:
                    actual_test_samples.append(sample.name)
                    test_page_counts += len(sample.pages)
        if update_proportion:
            raise NotImplementedError('update_proportion is not implemented')
        split_dict = SplitDict(
            counts=SplitCounts(
                sample_level=SplitCount(
                    train=len(actual_train_samples),
                    eval=len(actual_eval_samples),
                    test=len(actual_test_samples),
                ),
                page_level=SplitCount(
                    train=train_page_counts,
                    eval=eval_page_counts,
                    test=test_page_counts,
                ),
            ),
            samples=SplitedSampleNames(
                train=actual_train_samples,
                eval=actual_eval_samples,
                test=actual_test_samples,
            ),
        )
        self.split_dict_path.write_text(split_dict.model_dump_json(indent=4))
        return split_dict

    def get_split_dict(
        self,
        check_updated: bool = False,
        train_proportion: float | None = None,
        eval_proportion: float | None = None,
        test_proportion: float | None = None,
    ) -> SplitDict:
        if check_updated is False and self.split_dict_path.exists():
            return SplitDict.model_validate_json(self.split_dict_path.read_text())
        # If any proportion is provided, require all three and pass through; else, use defaults
        provided_any = (
            train_proportion is not None
            or eval_proportion is not None
            or test_proportion is not None
        )
        if provided_any:
            if train_proportion is None or eval_proportion is None or test_proportion is None:
                raise ValueError(
                    '请同时提供训练/验证/测试比例: '
                    'train_proportion, eval_proportion, test_proportion'
                )
            self.split_dataset(
                train_proportion=train_proportion,
                eval_proportion=eval_proportion,
                test_proportion=test_proportion,
            )
        else:
            logger.warning('没有提供训练/验证/测试比例, 使用默认比例: 0.8, 0.1, 0.1')
            self.split_dataset()
        return self.get_split_dict(check_updated=False)

    def get_result_dir(
        self,
        method_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
    ) -> Path:
        if method_id is None or session_id is None:
            raise ValueError(
                f"Result save directory not found: \n\n"
                f"method_id - {method_id}, \n\n"
                f"session_id - {session_id}, \n\n"
                f"test_id - {test_id}"
            )
        result_dir = self.results_dir / f'{method_id}-{session_id}'
        if test_id:
            result_dir = result_dir / test_id
        return result_dir

    def get_sample_result_path(
        self,
        sample_name: str | None = None,
        method_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        result_dir: Path | None = None,
        suffix: str = 'json',
    ) -> Path:
        if result_dir is None:
            result_dir = self.get_result_dir(method_id, session_id, test_id)
        if sample_name is None:
            raise ValueError('sample_name must be provided')
        result_path = result_dir / f'{sample_name}.{suffix}'
        if result_dir and result_path.parent != result_dir:
            logger.warning(
                f'result_path is not in the results directory, return result_path: {result_path}'
            )
        return result_path

    def save_sample_result(
        self,
        result: list[dict] | dict,
        sample_name: str | None = None,
        method_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        save_dir: Path | None = None,
        save_path: Path | None = None,
    ):
        """
        method_id: 方法ID, 运行主要方法
        session_id: 会话ID, 该方法固定参数下运行的一次会话
        test_id: 测试ID, 同一会话重复运行多次的试验
        """
        if save_path is None:
            save_path = self.get_sample_result_path(
                sample_name=sample_name,
                method_id=method_id,
                session_id=session_id,
                test_id=test_id,
                result_dir=save_dir,
            )
        save_path.parent.mkdir(parents=True, exist_ok=True)
        save_path.write_bytes(json2bytes(result))

    def get_sample_result(
        self,
        sample_name: str,
        method_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        result_dir: Path | None = None,
    ):
        result_path = self.get_sample_result_path(
            sample_name, method_id, session_id, test_id, result_dir
        )
        if not result_path.exists():
            raise ValueError(f"Result file {result_path} not found")
        return json.loads(result_path.read_text())

    def get_task_result_dir(
        self,
        task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
    ) -> Path:
        if task_id is None or session_id is None:
            raise ValueError(
                f"Result save directory not found: \n\n"
                f"task_id - {task_id}, \n\n"
                f"session_id - {session_id}, \n\n"
                f"test_id - {test_id}"
            )
        result_dir = self.task_results_dir / task_id / f'{task_id}-{session_id}'
        if test_id:
            result_dir = result_dir / test_id
        return result_dir

    @deprecated(replacement='get_task_result_dir')
    def get_sample_task_result_dir(
        self,
        task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
    ) -> Path | None:
        return self.get_task_result_dir(task_id, session_id, test_id)

    def get_sample_task_result_path(
        self,
        sample_name: str,
        task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        result_dir: Path | None = None,
        suffix: str = 'json',
    ) -> Path:
        if result_dir is None:
            result_dir = self.get_task_result_dir(task_id, session_id, test_id)
        return self.get_sample_result_path(sample_name, result_dir=result_dir, suffix=suffix)

    def save_sample_task_result(
        self,
        result: list[dict] | dict | bytes,
        sample_name: str | None = None,
        task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        save_dir: Path | None = None,
        save_path: Path | None = None,
        suffix: str = 'json',
    ):
        """
        task_id: 任务ID
        session_id: 会话ID, 该任务固定参数下运行的一次会话
        test_id: 测试ID, 同一会话重复运行多次的试验
        suffix: 结果文件后缀
        """
        if save_path is None:
            if sample_name is None:
                raise ValueError('save_path or sample_name must be provided')
            save_path = self.get_sample_task_result_path(
                sample_name=sample_name,
                task_id=task_id,
                session_id=session_id,
                test_id=test_id,
                result_dir=save_dir,
                suffix=suffix,
            )
        save_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if suffix == 'json':
                save_path.write_bytes(json2bytes(result))  # type: ignore
            else:
                save_path.write_bytes(result)  # type: ignore
        except Exception:
            raise ValueError(f"Invalid result: {str(result)[:100]}")
        return save_path

    def get_sample_task_result(
        self,
        sample_name,
        task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        result_dir: Path | None = None,
        suffix: str = 'json',
    ):
        result_path = self.get_sample_task_result_path(
            sample_name, task_id, session_id, test_id, result_dir, suffix
        )
        if not result_path.exists():
            raise ValueError(f"Result file {result_path} not found")
        if suffix == 'json':
            return json.loads(result_path.read_text())
        else:
            return result_path.read_bytes()

    def get_session_info_path(
        self,
        method_or_task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
    ) -> Path:
        if method_or_task_id is None or session_id is None:
            raise ValueError(
                f"method_or_task_id and session_id must be provided: \n\n"
                f"method_or_task_id - {method_or_task_id}, \n\n"
                f"session_id - {session_id}, \n\n"
                f"test_id - {test_id}"
            )
        save_dir = self.sessions_dir / method_or_task_id
        if not test_id:
            return save_dir / f'{method_or_task_id}-{session_id}.json'
        else:
            return save_dir / f'{method_or_task_id}-{session_id}-{test_id}.json'

    def save_session_info(
        self,
        session_info: dict,
        method_or_task_id: str | None = None,
        session_id: int | str | None = None,
        test_id: str | None = None,
        session_info_path: Path | None = None,
    ) -> None:
        if session_info_path is None:
            session_info_path = self.get_session_info_path(
                method_or_task_id=method_or_task_id,
                session_id=session_id,
                test_id=test_id,
            )
        ensure_folder(session_info_path.parent)
        session_info_path.write_bytes(json2bytes(session_info))

    def get_compare_dir(self, method_id: str, session_id: int | str, test_id: str | None = None):
        compare_dir = self.compare_dir / f'{method_id}-{session_id}'
        if test_id:
            compare_dir = compare_dir / test_id
        compare_dir.mkdir(parents=True, exist_ok=True)
        return compare_dir

    def get_task_compare_dir(self, task_id: str, session_id: int | str, test_id: str | None = None):
        compare_dir = self.task_compare_dir / task_id / f'{task_id}-{session_id}'
        if test_id:
            compare_dir = compare_dir / test_id
        compare_dir.mkdir(parents=True, exist_ok=True)
        return compare_dir

    def backup_tag(self, tag_name: str):
        records = []
        for sample_dir in sort_paths(self.unified_dir.iterdir()):
            for page_dir in sort_paths(sample_dir.iterdir()):
                tag_path = page_dir / f"tag-{tag_name}.json"
                if tag_path.exists():
                    record = TagRecord(
                        batch_name=self.batch_name,
                        sample_name=sample_dir.name,
                        page_name=page_dir.name,
                        tag=tag_path.read_text(),
                    )
                    records.append(record.model_dump())

        df = pd.DataFrame.from_records(records)
        logger.info(f'Saving {tag_name}.csv...')
        logger.info(f'total {df.shape[0]} records')
        logger.info(f'first 5 records: {df.head()}')
        logger.info(f'last 5 records: {df.tail()}')
        ensure_folder(self.task_tag_dir)
        df.to_csv(f'{self.task_tag_dir}/{tag_name}.csv', index=False)

    def restore_tag(self, tag_name: str):
        df = pd.read_csv(f'{self.task_tag_dir}/{tag_name}.csv')
        for _, row in df.iterrows():
            sample_name = row['sample_name']
            page_name = row['page_name']
            tag = row['tag']
            save_path = self.unified_dir / sample_name / page_name / f'tag-{tag_name}.json'
            try:
                save_path.write_text(tag)  # type: ignore
            except Exception:
                logger.error(f'{sample_name} {page_name} {tag_name} restore failed, skip')

    @staticmethod
    def get_unified_page_dir(batch_root: Path, batch_name: str, sample_name: str, page_name: str):
        return batch_root / batch_name / 'unified' / sample_name / page_name

    @staticmethod
    def split_page_name(page_name: str) -> tuple[str | None, int, str | None]:
        def get_filename(stem: str, span: tuple[int, int]) -> str:
            filename = stem[: span[0]]
            return filename

        def get_page_id_and_sheetname(stem: str, span: tuple[int, int]) -> tuple[int, str]:
            src_segment = stem[span[0] :]
            match = re.match(r'-p\d+_', src_segment)
            sheetname = ''
            page_id = 0
            if match:
                span = match.span()
                sheetname = src_segment[span[1] :]
                page_id = int(src_segment[2 : span[1] - 1])
            return page_id, sheetname

        def get_page_id(stem: str, span: tuple[int, int]) -> int:
            src_segment = stem[span[0] :]
            match = re.match(r'-p\d+$', src_segment)
            page_id = 0
            if match:
                span = match.span()
                page_id = int(src_segment[2 : span[1]])
            return page_id

        stem, suffix = split_basename(page_name)
        filename = None
        sheetname = None
        page_id = 0
        if suffix in EXCEL_EXTS:
            match = re.search(fr'-p\d+_.+\.{suffix}$', page_name)
            if match:
                span = match.span()
                filename = get_filename(stem, span)
                page_id, sheetname = get_page_id_and_sheetname(stem, span)
        else:
            match = re.search(fr'-p\d+\.{suffix}$', page_name)
            if match:
                span = match.span()
                filename = get_filename(stem, span)
                page_id = get_page_id(stem, span)
        return filename, page_id, sheetname

    @staticmethod
    def draw_blocks(
        image: bytes,
        char_boxes: list[tuple[int, int, int, int]],
        text_boxes: list[tuple[int, int, int, int]],
        cell_boxes: list[tuple[int, int, int, int]],
        method: str = '',
    ) -> bytes:

        from util_intelligence.color import ColorBGR
        from util_intelligence.drawer import draw_bboxes, put_ascii_texts
        from util_intelligence.image_util import imdecode, imencode

        image_array = draw_bboxes(
            imdecode(image),
            char_boxes,
            [ColorBGR.LIME],
        )
        image_array = draw_bboxes(
            image_array,
            text_boxes,
            [ColorBGR.MAGENTA],
        )
        image_array = draw_bboxes(
            image_array,
            cell_boxes,
            [ColorBGR.YELLOW],
        )
        image_array = put_ascii_texts(
            image_array, [(method, [5, 5, 100, 50])], colors=[ColorBGR.RED]
        )
        return imencode(image_array)

    def debug_blocks(self):
        for sample_dir in sort_paths(self.unified_dir.iterdir()):
            logger.info(f'Saving debug blocks for {sample_dir.name}...')
            for page_dir in sort_paths(sample_dir.iterdir()):
                image_path = page_dir.joinpath('norm.png')
                if not image_path.exists():
                    continue
                image = image_path.read_bytes()
                char_block_path = page_dir.joinpath('char_block.json')
                text_block_path = page_dir.joinpath('text_block.json')
                table_block_path = page_dir.joinpath('table_block.json')
                char_boxes = []
                text_boxes = []
                cell_boxes = []
                if char_block_path.exists():
                    char_block = json.loads(char_block_path.read_text())
                    char_boxes = [x['box'] for x in char_block['chars']]
                if text_block_path.exists():
                    text_block = json.loads(text_block_path.read_text())
                    text_boxes = [x['box'] for x in text_block['texts']]
                if table_block_path.exists():
                    table_block = json.loads(table_block_path.read_text())
                    cell_boxes = [
                        cell for table in table_block['tables'] for cell in table['cells']
                    ]
                image = self.draw_blocks(
                    image,
                    char_boxes,
                    text_boxes,
                    cell_boxes,
                    method=char_block['header']['detect_method'],
                )
                save_path = self.debug_dir / f'{sample_dir.name}-{page_dir.name}.png'
                save_path.parent.mkdir(parents=True, exist_ok=True)
                save_path.write_bytes(image)
            logger.info(f'Debug blocks for {sample_dir.name} saved.')


if __name__ == '__main__':
    filename, page_id, sheetname = BatchStore.split_page_name('test-p1.pdf')
    print(filename, page_id, sheetname)
