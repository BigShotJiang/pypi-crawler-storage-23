import logging
from importlib import import_module
from typing import Dict, List

from hmd_base_service import BaseService
from hmd_cli_tools import HmdEntityNotFoundException
from hmd_entity_storage import BaseEngine
from hmd_meta_types import Entity, Relationship, Noun
from hmd_schema_loader import DefaultLoader
from .handlers import RestHandler, GraphQLHandler
from .utils import *

logger = logging.getLogger(f"HMD.{__name__}")


def do_pre_ops(evt, ctx, operation: str):
    config_to_use = get_entity_config(evt, ctx)
    operation_config = config_to_use[operation]
    if operation_config["expose"] is not True:
        raise Exception(
            f"The {operation} operation is not exposed for {evt['class_name']}."
        )
    for method in operation_config.get("pre", []):
        method(evt, ctx)


def do_post_ops(evt, ctx, operation: str):
    config_to_use = get_entity_config(evt, ctx)
    for method in config_to_use[operation].get("post", []):
        method(evt, ctx)


def get_basic_service(
    entity_configs: Dict,
    db_engines: Dict[str, BaseEngine],
    schema_uri: str,
    operations_module: str = None,
):
    schema_locations = schema_uri.split(";")
    logger.info("Instantiating DefaultLoader...")
    loader = DefaultLoader(base=schema_locations)
    loader.load_all()
    logger.info("DefaultLoader instantiated.")

    svc = BaseService(
        {"loader": loader, "storage": db_engines, "entity_configs": entity_configs}
    )

    # Make sure at least one persistence engine is defined for each entity.
    for key in loader:
        get_first_db_engine({"class_name": key}, svc.context)

    svc.register_handler(GraphQLHandler(), "/graphql")
    svc.register_handler(RestHandler(), "/api")

    @svc.operation(
        rest_path="/api/<class_name>",
        rest_methods=["POST"],
        graphql_query="search_{class_name}",
        graphql_return_list=True,
        args={"filter": "json"},
    )
    def search_entity(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)

        if entity_class is not None:
            do_pre_ops(evt, ctx, "search")
            db = get_first_db_engine(evt, ctx)
            filter_ = evt["args"].get("filter", {})
            if filter_ is None:
                filter_ = {}
            results = db.search_entities(entity_class, filter_)
            do_post_ops(evt, ctx, "search")
            return [r.serialize() for r in (results if not results is None else [])]
        else:
            raise Exception(f"No support found for entity: {class_name}")

    @svc.operation(
        rest_path="/api/<class_name>/<args_id>",
        rest_methods=["GET"],
        graphql_query="get_{class_name}",
        graphql_entity_type=Noun,
        args={"id": "id"},
    )
    def get_entity(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)
        if entity_class is not None:
            do_pre_ops(evt, ctx, "read")
            db = get_first_db_engine(evt, ctx)
            id_ = evt["args"]["id"]
            result = db.get_entity(entity_class, id_)
            do_post_ops(evt, ctx, "read")
            if result is None:
                raise HmdEntityNotFoundException(class_name, id_)
            return result.serialize()
        else:
            raise Exception(f"No support found for entity: {class_name}")

    @svc.operation(
        rest_path="/api/instances/<class_name>",
        rest_methods=["GET", "POST"],
        graphql_query="get_{class_name}_instances",
        graphql_entity_type=Noun,
        graphql_return_list=True,
        args={"payload": "json"},
    )
    def get_entities(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)
        if entity_class is not None:
            do_pre_ops(evt, ctx, "read")
            db = get_first_db_engine(evt, ctx)
            payload = evt["args"]["payload"]
            results = db.get_entities(entity_class, payload)
            do_post_ops(evt, ctx, "read")
            return [ent.serialize() for ent in results]
        else:
            raise Exception(f"No support found for entity: {class_name}")

    @svc.operation(
        rest_path="/api/<class_name>/<args_id>",
        rest_methods=["DELETE"],
        graphql_mutation="delete_{class_name}",
        args={"id": "id"},
    )
    def delete_entity(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)
        if entity_class is not None:
            do_pre_ops(evt, ctx, "delete")
            dbs = get_db_engines(evt, ctx)
            id_ = evt["args"]["id"]
            for db in dbs:
                db.delete_entity(entity_class, id_)
            do_post_ops(evt, ctx, "delete")
        else:
            raise Exception(f"No support found for entity: {class_name}")

    @svc.operation(
        rest_path="/api/<class_name>/<args_from_to>/<args_id>",
        rest_methods=["GET"],
        graphql_query="get_{class_name}_fromto",
        graphql_entity_type=Relationship,
        graphql_return_list=True,
        args={"id": "id", "from_to": "string"},
    )
    def get_relationships_from_to(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)
        if entity_class is not None:
            from_to = evt["args"].get("from_to", None)
            if from_to not in ["from", "to"]:
                raise Exception(f'Invalid "from_to" argument: {from_to}')
            db = get_first_db_engine(evt, ctx)
            id_ = evt["args"]["id"]
            if from_to == "from":
                result = db.get_relationships_from(entity_class, id_)
            else:
                result = db.get_relationships_to(entity_class, id_)
            return [r.serialize() for r in result]
        else:
            raise Exception(f"No support found for entity: {class_name}")

    @svc.operation(
        rest_path="/api/<class_name>",
        rest_methods=["PUT"],
        graphql_mutation="put_{class_name}",
        graphql_input_type=True,
        args={"input": "json"},
    )
    def put_entity(evt, ctx):
        class_name = evt["class_name"]
        entity_class = ctx["loader"].get_class(class_name)
        if entity_class is not None:
            input_ = evt["args"]["input"]
            operation = "update" if "identifier" in input_ else "create"
            do_pre_ops(evt, ctx, operation)
            dbs = get_db_engines(evt, ctx)
            entity = Entity.deserialize(entity_class, input_)

            result = None
            for db in dbs:
                tmp_result = db.put_entity(entity).serialize()
                if not result:
                    result = tmp_result

            do_post_ops(evt, ctx, operation)
            return result
        else:
            raise Exception(f"No support for entity: {class_name}")

    @svc.operation(
        rest_path="/apisearch/<args_name>",
        rest_methods=["GET"],
        args={"name": "string"},
    )
    def saved_search(evt, ctx):
        search_name = evt["args"].get("name", None)
        if search_name is None:
            raise Exception("No named search supplied")

        search = svc.searches.get(search_name, None)
        if search is None:
            raise Exception(f"Cannot find search {search_name}")
        db = ctx["storage"]
        results = []

        for ent in search["entities"]:
            query_results = db.search_entities(ent, search["filter"])
            results.extend(query_results)

        return [r.serialize() for r in results]

    if operations_module:
        module = import_module(operations_module)
        setup_method = getattr(module, "setup")
        setup_method(svc)

    svc.run()

    return svc
