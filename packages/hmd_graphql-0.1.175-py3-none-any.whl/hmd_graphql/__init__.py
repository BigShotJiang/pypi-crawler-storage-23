from .hmd_graphql import get_basic_service
