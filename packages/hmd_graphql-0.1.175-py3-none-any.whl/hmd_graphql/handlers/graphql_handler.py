import json
import logging

from graphql import graphql_sync
from graphql.type import (
    GraphQLArgument,
    GraphQLField,
    GraphQLList,
    GraphQLObjectType,
    GraphQLScalarType,
    GraphQLSchema,
    GraphQLString,
)
from graphql.type.scalars import GraphQLFloat, GraphQLID, GraphQLInt

from hmd_base_service import BaseHandler
from hmd_meta_types import Noun, Relationship
from ..types.core import EntityInput, EntityObject

logger = logging.getLogger(f"HMD.{__name__}")


class GraphQLHandler(BaseHandler):
    def __init__(self) -> None:
        self.graphql_schema = None

    def setup(self, operations, context):
        loader = context["loader"]
        json_scalar = GraphQLScalarType(
            "JSON", serialize=json.dumps, parse_value=json.loads
        )
        __type_map = {
            "string": GraphQLString,
            "int": GraphQLInt,
            "id": GraphQLID,
            "float": GraphQLFloat,
            "datetime": GraphQLString,
            "json": json_scalar,
            "mapping": GraphQLString,
            "collection": GraphQLString,
            "blob": GraphQLString,
        }

        types_ = []
        inputs = []
        query_fields = {}
        mutation_fields = {}

        for schema_name in loader:
            entity_class = loader.get_class(schema_name)

            graphql_obj = EntityObject.get_graphql_type(entity_class, loader)
            input_obj = EntityInput.get_graphql_input_type(graphql_obj)

            types_.append(graphql_obj)
            inputs.append(input_obj)

            # process nouns before relationships...
            for klass in (Noun, Relationship):
                if issubclass(entity_class, klass):
                    for _, op in operations.items():

                        def resolver(op, query_name, class_name):
                            def _resolver(_, _info, **args):
                                evt = {
                                    "class_name": class_name,
                                    "path": query_name,
                                    "args": args,
                                    **_info.context.get("event", {}),
                                }
                                return op["fn"](evt, _info.context)

                            return _resolver

                        if "graphql_query" in op:
                            _type = (
                                op["graphql_entity_type"]
                                if "graphql_entity_type" in op
                                else (Relationship, Noun)
                            )
                            if issubclass(entity_class, _type):
                                query_name = op["graphql_query"].format_map(
                                    {"class_name": graphql_obj.name}
                                )

                                query_fld_type = graphql_obj
                                if op.get("graphql_return_list", False):
                                    query_fld_type = GraphQLList(graphql_obj)

                                args = {}
                                if "args" in op:
                                    for k, v in op["args"].items():
                                        args[k] = GraphQLArgument(
                                            __type_map.get(v, GraphQLString)
                                        )

                                query_fields[query_name] = GraphQLField(
                                    query_fld_type,
                                    resolve=resolver(
                                        op, query_name, class_name=schema_name
                                    ),
                                    args=args,
                                )

                        if "graphql_mutation" in op:
                            _type = (
                                op["graphql_entity_type"]
                                if "graphql_entity_type" in op
                                else (Relationship, Noun)
                            )
                            if issubclass(entity_class, _type):
                                mutation_name = op["graphql_mutation"].format_map(
                                    {"class_name": graphql_obj.name}
                                )

                                mutation_fld_type = graphql_obj
                                if op.get("graphql_return_list", False):
                                    mutation_fld_type = GraphQLList(graphql_obj)

                                args = {}
                                if op.get("graphql_input_type", False):
                                    args["input"] = GraphQLArgument(input_obj)
                                elif "args" in op:
                                    for k, v in op["args"].items():
                                        args[k] = GraphQLArgument(
                                            __type_map.get(v, GraphQLString)
                                        )

                                mutation_fields[mutation_name] = GraphQLField(
                                    mutation_fld_type,
                                    resolve=resolver(
                                        op, query_name, class_name=schema_name
                                    ),
                                    args=args,
                                )

        query_type = None
        mutation_type = None

        if query_fields:
            query_type = GraphQLObjectType("Query", fields=query_fields)
        if mutation_fields:
            mutation_type = GraphQLObjectType("Mutation", fields=mutation_fields)

        if query_type is None:
            raise Exception(
                "No schema generated for the given loader and configuration."
            )

        self.graphql_schema = GraphQLSchema(
            query_type, mutation=mutation_type, types=[json_scalar]
        )

    def execute(self, evt, ctx):
        query = evt["payload"]["query"]
        variables = evt["payload"].get("variables", {})
        op_name = evt["payload"].get("operation_name", None)

        result = graphql_sync(
            self.graphql_schema,
            query,
            variable_values=variables,
            context_value={"event": evt, **ctx},
            operation_name=op_name,
        )

        if result.errors:
            for err in result.errors:
                logger.error(err)

        result_body = {
            "return_code": 200,
            "body": {},
            "headers": {"Content-Type": "application/json"},
            "isBase64Encoded": False,
        }
        if result.data is not None:
            result_body["body"]["data"] = result.data

        if result.errors is not None:
            result_body["body"]["errors"] = [str(err) for err in result.errors]

        return result_body
