import re
import logging

from hmd_base_service import BaseHandler
from hmd_cli_tools import ServiceException

logger = logging.getLogger(f"HMD.{__name__}")


class RestHandler(BaseHandler):
    def __init__(self):
        self.routes = {}

    def get_route_path(self, path: str):
        def repl(matchobj):
            return f"(?P{matchobj.group(0)}[\\w+\\-\.*]+)"

        return re.sub(r"\<([\w]+)\>", repl, path)

    def setup(self, operations, context):
        for _, op in operations.items():
            if "rest_path" in op:
                route_path = self.get_route_path(op["rest_path"])
                methods = op.get("rest_methods", [])
                for m in methods:
                    if self.routes.get(m, None) is None:
                        self.routes[m] = {}
                    self.routes[m][route_path] = {
                        "methods": op.get("rest_methods", []),
                        "fn": op["fn"],
                        "args": op.get("args", {}),
                        "headers": op.get(
                            "headers", {"Content-Type": "application/json"}
                        ),
                        "isBase64Encoded": op.get("isBase64Encoded", False),
                        "response_headers": op.get(
                            "response_headers", {"Content-Type": "application/json"}
                        ),
                        "success_code": op.get("success_code", 200),
                    }

    def execute(self, evt, ctx):
        evt_path = evt["path"]
        evt_method = evt.get("httpMethod", None)

        class_name = None
        op = None
        args = {}

        logger.debug(self.routes)
        logger.info(f"Path: {evt_path}; Method: {evt_method}")
        for route in self.routes[evt_method]:
            m = re.search(route, evt_path)
            if m and m.end() == len(evt_path):
                op = self.routes[evt_method][route]
                if "class_name" in route:
                    class_name = m.group("class_name")
                for k, _ in op.get("args", {}).items():
                    if f"args_{k}" in route:
                        args[k] = m.group(f"args_{k}")
                break

        if op is None:
            raise Exception(
                f"No operation found for method: {evt_method}, path: {evt_path}"
            )

        # For REST, we just want the entire body to be available
        # so all args that are not on the path just become the entire payload...
        for k, _ in op.get("args", {}).items():
            if args.get(k, None) is None:
                args[k] = evt["payload"]

        return_code = op["success_code"]
        event = {"class_name": class_name, "args": args, **evt}
        try:
            result = op["fn"](event, ctx)
        except ServiceException as se:
            return_code = se.status
            body = {"message": se.message}
        else:
            body = result

        return {
            "return_code": return_code,
            "body": body,
            "headers": op["response_headers"],
            "isBase64Encoded": False,
        }
