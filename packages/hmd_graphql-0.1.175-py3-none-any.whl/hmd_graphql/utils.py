from typing import List
from hmd_entity_storage import BaseEngine

__default_operation_config__ = {"expose": True, "pre": [], "post": []}
__default_entity_config__ = {
    "create": __default_operation_config__,
    "read": __default_operation_config__,
    "update": __default_operation_config__,
    "delete": __default_operation_config__,
    "search": __default_operation_config__,
}


def get_entity_config(evt, ctx):
    class_name = evt.get("class_name", "")
    entity_configs = ctx["entity_configs"]
    class_name_config = entity_configs.get(class_name, {})
    defined_default = entity_configs.get("__default__", {})

    return {**__default_entity_config__, **defined_default, **class_name_config}


def get_db_engines(evt, ctx) -> List[BaseEngine]:
    config_to_use = get_entity_config(evt, ctx)
    if "persistence" not in config_to_use:
        raise Exception(f"No 'persistence' defined for {evt['class_name']}.")
    db_engines = ctx["storage"]
    for key in config_to_use["persistence"]:
        if key not in db_engines:
            raise Exception(f"Persistence key, {key}, not defined as a DB engine.")
    return [db_engines[key] for key in config_to_use["persistence"]]


def get_first_db_engine(evt, ctx) -> BaseEngine:
    engines = get_db_engines(evt, ctx)
    return engines[0] if len(engines) > 0 else None
