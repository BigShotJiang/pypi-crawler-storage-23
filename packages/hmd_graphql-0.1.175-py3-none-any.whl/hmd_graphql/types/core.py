import logging
from typing import Dict, Any, List, Type
import json
from datetime import datetime
from hmd_meta_types import Entity, Relationship, Noun
from hmd_schema_loader import DefaultLoader
from hmd_graphql_client.hmd_db_engine_client import DbEngineClient
from hmd_graphql_client.relationship_support import RelationshipSupport
from ..utils import get_db_engines, get_first_db_engine

from graphql.type import (
    GraphQLObjectType,
    GraphQLInputObjectType,
    GraphQLInputField,
    GraphQLInputObjectType,
    GraphQLList,
    GraphQLField,
    GraphQLEnumType,
    GraphQLEnumValue,
    GraphQLString,
    GraphQLInt,
    GraphQLFloat,
    GraphQLID,
    GraphQLNonNull,
    GraphQLScalarType,
    is_object_type,
    is_input_type,
    is_list_type,
)
from graphql.pyutils import snake_to_camel


logger = logging.getLogger(f"HMD.{__name__}")


def map_type_to_graphql(schema_type: str):
    __type_map = {
        "string": GraphQLString,
        "integer": GraphQLInt,
        "float": GraphQLFloat,
        "timestamp": GraphQLString,
        "mapping": GraphQLString,
        "collection": GraphQLString,
        "blob": GraphQLString,
    }

    return __type_map[schema_type]


class EntityObject(GraphQLObjectType):
    entity_types = {}

    def __init__(self, name: str, entity_class: Type[Entity], loader: DefaultLoader):
        self.__name = name
        self.__entity_class = entity_class
        self.__loader = loader
        self.typename = self.__name
        super().__init__(self.__name, lambda: self.__fields())
        self.__class__.entity_types[self.__name] = self

    @classmethod
    def get_graphql_type(cls, entity_class: Type[Entity], loader: DefaultLoader):
        name = entity_class.get_namespace_name().replace(".", "_")
        if name in cls.entity_types:
            return cls.entity_types[name]
        return cls(name, entity_class, loader)

    def __fields(self) -> Dict[str, GraphQLField]:
        flds = {"identifier": GraphQLField(GraphQLID)}
        for name, definition in (
            self.__entity_class.entity_definition().get("attributes", {}).items()
        ):
            required = definition.get("required", False)
            fld = self.__build_field(name, definition, required=required)
            flds[name] = fld

        if issubclass(self.__entity_class, Noun):
            from_rels = list(
                filter(
                    lambda ent: issubclass(self.__loader.get_class(ent), Relationship)
                    and issubclass(
                        self.__loader.get_class(ent).ref_from_type(),
                        self.__entity_class,
                    ),
                    self.__loader,
                )
            )
            if len(from_rels) > 0:
                from_rels_fld_type = GraphQLObjectType(
                    f"{self.typename}_from_rels",
                    {
                        rel.replace(".", "_"): self.__build_relationship_field(
                            "from", self.__loader.get_class(rel)
                        )
                        for rel in from_rels
                    },
                )
                flds["from_rels"] = GraphQLField(
                    from_rels_fld_type,
                    resolve=lambda root, _info: root,  # Resolve to root noun to get relationships
                )
            to_rels = list(
                filter(
                    lambda ent: issubclass(self.__loader.get_class(ent), Relationship)
                    and issubclass(
                        self.__loader.get_class(ent).ref_to_type(), self.__entity_class
                    ),
                    self.__loader,
                )
            )
            if len(to_rels) > 0:
                to_rels_fld_type = GraphQLObjectType(
                    f"{self.typename}_to_rels",
                    {
                        rel.replace(".", "_"): self.__build_relationship_field(
                            "to", self.__loader.get_class(rel)
                        )
                        for rel in to_rels
                    },
                )
                flds["to_rels"] = GraphQLField(
                    to_rels_fld_type,
                    resolve=lambda root, _info: root,  # Resolve to root noun to get relationships
                )

        if issubclass(self.__entity_class, Relationship):
            # flds["ref_from"] = self.__build_field(
            #     "ref_from", {"type": "string"}, required=True
            # )
            # flds["ref_to"] = self.__build_field(
            #     "ref_to", {"type": "string"}, required=True
            # )
            flds["ref_from"] = self.__build_reference_field(
                "ref_from", self.__entity_class.ref_from_type()
            )
            flds["ref_to"] = self.__build_reference_field(
                "ref_to", self.__entity_class.ref_to_type()
            )
        return flds

    def __build_field(
        self, name: str, definition: dict, required: bool = False
    ) -> GraphQLField:
        graphql_type = None
        schema_type = definition["type"]
        if schema_type == "enum":
            enum_def = definition["enum_def"]
            graphql_type = GraphQLEnumType(
                name, {k: GraphQLEnumValue(k) for k in enum_def}
            )
        else:
            graphql_type = map_type_to_graphql(schema_type)
        if required:
            graphql_type = GraphQLNonNull(graphql_type)
        return GraphQLField(
            graphql_type, description=definition.get("description", None)
        )

    def __build_reference_field(
        self, name: str, ref_class: Type[Entity]
    ) -> GraphQLField:
        def ref_resolver(root, _info, **kwargs):
            client = DbEngineClient(
                get_first_db_engine(_info.context.get("event", {}), _info.context),
                loader=_info.context["loader"],
            )
            rs = RelationshipSupport([client])
            rel: Relationship = self.__entity_class.deserialize(
                self.__entity_class, root
            )
            rs.pull_relationship_nouns([rel])

            if name == "ref_from":
                return rs.ref_from(rel).serialize()

            if name == "ref_to":
                return rs.ref_to(rel).serialize()

        # for references, the resolver assumes that the reference has already been retrieved
        # which is our default implementation
        ref_obj = EntityObject.get_graphql_type(ref_class, self.__loader)
        return GraphQLField(ref_obj, resolve=ref_resolver)

    def __build_relationship_field(
        self, from_to: str, rel_class: Type[Relationship]
    ) -> GraphQLField:
        def rel_resolver(root, _info, **kwargs):
            client = DbEngineClient(
                get_first_db_engine(_info.context.get("event", {}), _info.context),
                loader=_info.context["loader"],
            )
            entity = self.__entity_class.deserialize(self.__entity_class, root)

            if from_to == "from":
                return [
                    rel.serialize()
                    for rel in client.get_relationships_from(
                        entity, rel_class.get_namespace_name()
                    )
                ]

            if from_to == "to":
                return [
                    rel.serialize()
                    for rel in client.get_relationships_to(
                        entity, rel_class.get_namespace_name()
                    )
                ]

        ref_obj = EntityObject.get_graphql_type(rel_class, self.__loader)
        return GraphQLField(GraphQLList(ref_obj), resolve=rel_resolver)


class EntityInput(GraphQLInputObjectType):
    entity_inputs = {}
    input_types = {}

    def __init__(self, entity_obj: EntityObject):
        flds = self.__convert_fields(entity_obj.fields, entity_obj)
        super().__init__(
            f"{entity_obj.name}_input",
            fields=flds,
            description=f"input for {entity_obj.name}",
        )
        self.__class__.entity_inputs[entity_obj.name] = self

    @classmethod
    def get_graphql_input_type(cls, entity_object: EntityObject):
        if entity_object.name in cls.entity_inputs:
            return cls.entity_inputs[entity_object.name]
        return cls(entity_object)

    def __get_internal_type(self, type_):
        if not type_.name in EntityInput.input_types:
            EntityInput.input_types[type_.name] = GraphQLInputObjectType(
                f"{type_.name}_input_", self.__convert_fields(type_.fields)
            )
        return EntityInput.input_types[type_.name]

    def __convert_fields(
        self, fields: Dict[str, GraphQLField], obj: EntityObject = None
    ) -> Dict[str, GraphQLInputField]:
        input_flds = {}
        for fld_name, fld in fields.items():
            if fld_name == "from_rels":
                continue
            if fld_name == "to_rels":
                continue

            type_ = fld.type
            if is_object_type(type_):
                type_ = self.__get_internal_type(type_)
            elif is_list_type(type_):
                type_ = GraphQLList(self.__get_internal_type(type_))
            input_flds[fld_name] = GraphQLInputField(type_, description=fld.description)

        return input_flds
