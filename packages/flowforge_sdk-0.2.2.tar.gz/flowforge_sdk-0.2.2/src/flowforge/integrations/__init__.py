"""Framework integrations for FlowForge SDK."""

from flowforge.integrations.fastapi import serve as serve_fastapi

__all__ = ["serve_fastapi"]
