"""FORMAL: Fortran FORD VitePress Markdown Documentation HTML generator.

Generate VitePress-ready API documentation from FORD-parsed Fortran sources.
"""

__version__ = "0.2.16"
__author__ = "Stefano Zaghi"
__license__ = "MIT"
