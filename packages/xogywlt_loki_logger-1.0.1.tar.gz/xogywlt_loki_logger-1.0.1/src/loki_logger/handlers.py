"""
Handlers: responsible for delivering log records to a destination.

Hierarchy
---------
BaseHandler
├── ConsoleHandler          – writes to stdout / stderr
├── LokiHandler             – synchronous HTTP push to Loki
├── AsyncLokiHandler        – async HTTP push (asyncio)
└── BufferedLokiHandler     – batches records and flushes periodically
"""

import json
import queue
import sys
import threading
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from .formatters import BaseFormatter, JSONFormatter
from .levels import LogLevel
from .record import LogRecord


# --------------------------------------------------------------------------- #
# Base                                                                         #
# --------------------------------------------------------------------------- #


class BaseHandler(ABC):
    """
    Abstract base for all handlers.

    Subclasses must implement :py:meth:`emit`.  ``handle`` is the public entry
    point; it applies the level filter and calls ``emit``.
    """

    def __init__(
        self,
        level: LogLevel = LogLevel.DEBUG,
        formatter: Optional[BaseFormatter] = None,
    ) -> None:
        self.level = level
        self.formatter: BaseFormatter = formatter or JSONFormatter()

    # ---------------------------------------------------------------------- #
    # Public API                                                               #
    # ---------------------------------------------------------------------- #

    def handle(self, record: LogRecord) -> None:
        """Filter by level then delegate to :py:meth:`emit`."""
        if record.level >= self.level:
            self.emit(record)

    def set_formatter(self, formatter: BaseFormatter) -> None:
        """Replace the formatter used by this handler."""
        self.formatter = formatter

    def set_level(self, level: LogLevel) -> None:
        """Change the minimum severity level this handler will process."""
        self.level = level

    # ---------------------------------------------------------------------- #
    # Abstract                                                                 #
    # ---------------------------------------------------------------------- #

    @abstractmethod
    def emit(self, record: LogRecord) -> None:
        """Write *record* to the handler's destination."""
        ...

    def close(self) -> None:
        """Release any resources held by this handler (override if needed)."""


# --------------------------------------------------------------------------- #
# ConsoleHandler                                                               #
# --------------------------------------------------------------------------- #


class ConsoleHandler(BaseHandler):
    """
    Writes formatted log lines to *stdout* (or *stderr* for WARNING+).

    Parameters
    ----------
    level:
        Minimum log level to emit.
    formatter:
        Formatter instance. Defaults to :class:`~loki_logger.JSONFormatter`.
    use_stderr_for_errors:
        When ``True`` (default) WARNING and above go to *stderr*.
    """

    def __init__(
        self,
        level: LogLevel = LogLevel.DEBUG,
        formatter: Optional[BaseFormatter] = None,
        use_stderr_for_errors: bool = True,
    ) -> None:
        super().__init__(level=level, formatter=formatter)
        self._use_stderr = use_stderr_for_errors

    def emit(self, record: LogRecord) -> None:
        line = self.formatter.format(record)
        stream = (
            sys.stderr
            if self._use_stderr and record.level >= LogLevel.WARNING
            else sys.stdout
        )
        print(line, file=stream, flush=True)


# --------------------------------------------------------------------------- #
# Loki Push API helpers                                                        #
# --------------------------------------------------------------------------- #


def _build_loki_payload(
    records: List[LogRecord],
    formatter: BaseFormatter,
    default_labels: Dict[str, str],
) -> bytes:
    """
    Build the JSON payload expected by Loki's ``/loki/api/v1/push`` endpoint.

    Loki payload structure::

        {
            "streams": [
                {
                    "stream": {"label_key": "label_value", ...},
                    "values": [
                        ["<unix epoch ns as string>", "<log line>"],
                        ...
                    ]
                }
            ]
        }

    Records are grouped by their label set so each unique label combination
    maps to exactly one stream object.
    """
    streams: Dict[str, Dict[str, Any]] = {}

    for record in records:
        labels = record.merged_labels(default_labels)
        # Use a stable string key to group records with identical labels.
        stream_key = json.dumps(labels, sort_keys=True)

        if stream_key not in streams:
            streams[stream_key] = {"stream": labels, "values": []}

        log_line = formatter.format(record)
        streams[stream_key]["values"].append(
            [str(record.timestamp_ns), log_line]
        )

    payload = {"streams": list(streams.values())}
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


# --------------------------------------------------------------------------- #
# LokiHandler (synchronous)                                                    #
# --------------------------------------------------------------------------- #


class LokiHandler(BaseHandler):
    """
    Synchronous handler that pushes log records directly to a Loki instance.

    Each call to :py:meth:`emit` performs a blocking HTTP POST to
    ``<url>/loki/api/v1/push``.

    Parameters
    ----------
    url:
        Base URL of the Loki instance (e.g. ``"http://localhost:3100"``).
    labels:
        Default labels attached to every stream pushed by this handler.
    level:
        Minimum log level to process.
    formatter:
        Formatter instance. Defaults to :class:`~loki_logger.JSONFormatter`.
    timeout:
        HTTP request timeout in seconds (default ``5``).
    username / password:
        Optional HTTP Basic Auth credentials (for Grafana Cloud).
    extra_headers:
        Additional HTTP headers to include in every request.
    """

    PUSH_PATH = "/loki/api/v1/push"

    def __init__(
        self,
        url: str,
        labels: Optional[Dict[str, str]] = None,
        level: LogLevel = LogLevel.DEBUG,
        formatter: Optional[BaseFormatter] = None,
        timeout: float = 5.0,
        username: Optional[str] = None,
        password: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        super().__init__(level=level, formatter=formatter)
        self.url = url.rstrip("/")
        self.labels: Dict[str, str] = labels or {}
        self.timeout = timeout
        self._username = username
        self._password = password
        self._extra_headers: Dict[str, str] = extra_headers or {}

    # ---------------------------------------------------------------------- #

    def _make_request(self, payload: bytes) -> None:
        endpoint = f"{self.url}{self.PUSH_PATH}"
        headers = {
            "Content-Type": "application/json",
            **self._extra_headers,
        }

        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")

        if self._username and self._password:
            import base64
            token = base64.b64encode(
                f"{self._username}:{self._password}".encode()
            ).decode()
            req.add_header("Authorization", f"Basic {token}")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                if resp.status not in (200, 204):
                    sys.stderr.write(
                        f"[LokiHandler] Unexpected response: {resp.status}\n"
                    )
        except urllib.error.URLError as exc:
            sys.stderr.write(f"[LokiHandler] Failed to push log: {exc}\n")

    def emit(self, record: LogRecord) -> None:
        payload = _build_loki_payload([record], self.formatter, self.labels)
        self._make_request(payload)


# --------------------------------------------------------------------------- #
# AsyncLokiHandler                                                             #
# --------------------------------------------------------------------------- #


class AsyncLokiHandler(BaseHandler):
    """
    Async-friendly handler for use inside ``asyncio`` applications.

    ``emit`` is synchronous (so it satisfies the :class:`BaseHandler`
    contract), but internally it schedules the HTTP push as a coroutine on the
    running event loop.  Call ``await handler.flush()`` to wait for all
    pending pushes to complete.

    .. note::
        Requires Python 3.8+ and the ``aiohttp`` package::

            pip install aiohttp
    """

    def __init__(
        self,
        url: str,
        labels: Optional[Dict[str, str]] = None,
        level: LogLevel = LogLevel.DEBUG,
        formatter: Optional[BaseFormatter] = None,
        timeout: float = 5.0,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> None:
        super().__init__(level=level, formatter=formatter)
        self.url = url.rstrip("/")
        self.labels: Dict[str, str] = labels or {}
        self.timeout = timeout
        self._username = username
        self._password = password
        self._tasks: List[Any] = []

    def emit(self, record: LogRecord) -> None:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop — fall back to a blocking push.
            payload = _build_loki_payload([record], self.formatter, self.labels)
            self._sync_push(payload)
            return

        task = loop.create_task(self._async_push(record))
        self._tasks.append(task)

    async def flush(self) -> None:
        """Await all pending push tasks."""
        import asyncio

        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
            self._tasks.clear()

    async def _async_push(self, record: LogRecord) -> None:
        try:
            import aiohttp  # type: ignore
        except ImportError:
            raise RuntimeError(
                "AsyncLokiHandler requires 'aiohttp'. Install it with: pip install aiohttp"
            )

        payload = _build_loki_payload([record], self.formatter, self.labels)
        endpoint = f"{self.url}/loki/api/v1/push"

        auth = None
        if self._username and self._password:
            auth = aiohttp.BasicAuth(self._username, self._password)  # type: ignore

        async with aiohttp.ClientSession() as session:  # type: ignore
            try:
                async with session.post(  # type: ignore
                    endpoint,
                    data=payload,
                    headers={"Content-Type": "application/json"},
                    auth=auth,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),  # type: ignore
                ) as resp:  # type: ignore
                    if resp.status not in (200, 204):  # type: ignore
                        sys.stderr.write(
                            f"[AsyncLokiHandler] Unexpected status: {resp.status}\n"  # type: ignore
                        )

            except Exception as exc:
                sys.stderr.write(f"[AsyncLokiHandler] Push failed: {exc}\n")

    def _sync_push(self, payload: bytes) -> None:
        import urllib.request as _ur

        endpoint = f"{self.url}/loki/api/v1/push"
        req = _ur.Request(
            endpoint,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            _ur.urlopen(req, timeout=self.timeout)
        except Exception as exc:
            sys.stderr.write(f"[AsyncLokiHandler] Sync fallback failed: {exc}\n")


# --------------------------------------------------------------------------- #
# BufferedLokiHandler                                                          #
# --------------------------------------------------------------------------- #


class BufferedLokiHandler(LokiHandler):
    """
    Loki handler that accumulates records in an in-memory buffer and flushes
    them in batches — either when the buffer reaches *max_batch_size* or when
    the *flush_interval* elapses.

    A background daemon thread is responsible for the time-based flush.

    Parameters
    ----------
    url:
        Base URL of the Loki instance.
    labels:
        Default stream labels.
    level:
        Minimum log level to process.
    formatter:
        Formatter instance.
    timeout:
        HTTP request timeout in seconds.
    username / password:
        Optional HTTP Basic Auth.
    max_batch_size:
        Number of records that trigger an immediate flush (default ``100``).
    flush_interval:
        Seconds between automatic flushes (default ``5``).
    """

    def __init__(
        self,
        url: str,
        labels: Optional[Dict[str, str]] = None,
        level: LogLevel = LogLevel.DEBUG,
        formatter: Optional[BaseFormatter] = None,
        timeout: float = 5.0,
        username: Optional[str] = None,
        password: Optional[str] = None,
        max_batch_size: int = 100,
        flush_interval: float = 5.0,
    ) -> None:
        super().__init__(
            url=url,
            labels=labels,
            level=level,
            formatter=formatter,
            timeout=timeout,
            username=username,
            password=password,
        )
        self._max_batch = max_batch_size
        self._flush_interval = flush_interval
        self._buffer: queue.Queue[LogRecord] = queue.Queue()
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._flush_thread = threading.Thread(
            target=self._periodic_flush, daemon=True, name="LokiBufferFlusher"
        )
        self._flush_thread.start()

    # ---------------------------------------------------------------------- #

    def emit(self, record: LogRecord) -> None:
        self._buffer.put(record)
        if self._buffer.qsize() >= self._max_batch:
            self._flush()

    def flush(self) -> None:
        """Flush all buffered records immediately (blocking)."""
        self._flush()

    def close(self) -> None:
        """Stop the background thread and flush remaining records."""
        self._stop_event.set()
        self._flush_thread.join(timeout=self._flush_interval + 1)
        self._flush()

    # ---------------------------------------------------------------------- #

    def _flush(self) -> None:
        records: List[LogRecord] = []
        with self._lock:
            while not self._buffer.empty():
                try:
                    records.append(self._buffer.get_nowait())
                except queue.Empty:
                    break

        if not records:
            return

        payload = _build_loki_payload(records, self.formatter, self.labels)
        self._make_request(payload)

    def _periodic_flush(self) -> None:
        while not self._stop_event.is_set():
            time.sleep(self._flush_interval)
            try:
                self._flush()
            except Exception as exc:
                sys.stderr.write(f"[BufferedLokiHandler] Flush error: {exc}\n")
