"""
examples.py — Usage examples for loki_logger
=============================================

Run this file directly to see all examples print to stdout.
(A real Loki instance is NOT required; examples that push to Loki are
commented-out or guarded so the file runs without a network connection.)
"""

# --------------------------------------------------------------------------- #
# 1. Basic setup with the global root logger                                   #
# --------------------------------------------------------------------------- #

from typing import Dict, Literal, Union

from loki_logger import (
    AsyncLokiHandler as AsyncLokiHandler,
    BufferedLokiHandler as BufferedLokiHandler,
    ConsoleHandler,
    JSONFormatter,
    LabelFormatter,
    LogContext,
    LogLevel,
    LokiHandler as LokiHandler,
    TextFormatter,
    bind_context,
    clear_context,
    configure,
    get_logger,
)

print("=" * 60)
print("1. Configure root logger (console, JSON output)")
print("=" * 60)

mode: Literal['console', 'loki'] = 'console'

if mode == 'console':
    configure(
        level=LogLevel.DEBUG,
        handlers=[ConsoleHandler(formatter=JSONFormatter(indent=None))],
        default_labels={"app": "my-service", "env": "dev"},
        default_extra={"version": "1.0.0"},
    )

else:
    configure(
        level=LogLevel.DEBUG,
        handlers=[
            AsyncLokiHandler(
                url="http://localhost:3100",
                labels={"app": "my-service", "env": "production"},
                formatter=JSONFormatter(indent=None),
            )
        ],
        default_labels={"app": "my-service", "env": "dev"},
        default_extra={"version": "1.0.0"},
    )

root = get_logger()
root.debug("Application starting")
root.info("Ready to serve requests", port=8080)
root.warning("Config file not found, using defaults", config_path="/etc/app.yaml")


# --------------------------------------------------------------------------- #
# 2. Named child loggers                                                       #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("2. Named child loggers")
print("=" * 60)

db_logger = get_logger("myapp.db")
db_logger.info("Connected to database", host="localhost", db="orders")

payments_logger = get_logger("myapp.payments")
payments_logger.info("Payment processed", order_id="ORD-999", amount=49.99)


# --------------------------------------------------------------------------- #
# 3. Exception logging                                                         #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("3. Exception capture")
print("=" * 60)

try:
    result = 1 / 0
except ZeroDivisionError:
    root.exception("Unhandled error during computation", operation="divide")


# --------------------------------------------------------------------------- #
# 4. Thread-local context binding                                              #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("4. Thread-local context (bind_context / LogContext)")
print("=" * 60)

bind_context(request_id="req-abc123", user_id=42)
root.info("Processing request")   # ← request_id & user_id appear automatically
clear_context()

with LogContext(trace_id="trace-xyz", tenant="acme"):
    root.info("Inside the context block")

root.info("Outside — no trace_id or tenant")


# --------------------------------------------------------------------------- #
# 5. Different formatters                                                      #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("5. Different formatters")
print("=" * 60)

# Text formatter
text_handler = ConsoleHandler(formatter=TextFormatter())
text_logger = get_logger("text_demo")
text_logger.add_handler(text_handler)
text_logger.info("Human-readable text line", key="value")

# Label formatter
label_handler = ConsoleHandler(formatter=LabelFormatter())
label_logger = get_logger("label_demo")
label_logger.add_handler(label_handler)
label_logger.info("Key=value pairs for easy LogQL filtering", user="alice", action="login")


# --------------------------------------------------------------------------- #
# 6. Custom per-logger labels                                                  #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("6. Per-logger default labels")
print("=" * 60)

from loki_logger import Logger

service_logger: Logger = Logger(
    name="billing",
    level=LogLevel.INFO,
    handlers=[ConsoleHandler()],
    default_labels={"service": "billing", "team": "finance"},
    default_extra={"region": "us-east-1"},
)

service_logger.info("Invoice generated", invoice_id="INV-2024-001", amount=1299.00)


# --------------------------------------------------------------------------- #
# 7. LokiHandler (requires a running Loki — kept commented out)               #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("7. LokiHandler (synchronous) — skipped (no Loki server)")
print("=" * 60)

# Uncomment to test against a real Loki instance:
#
# loki_handler = LokiHandler(
#     url="http://localhost:3100",
#     labels={"app": "my-service", "env": "dev"},
#     level=LogLevel.INFO,
# )
# configure(level=LogLevel.INFO, handlers=[loki_handler])
# get_logger().info("Pushed to Loki!", key="value")

print("  (set up LokiHandler with url='http://localhost:3100' to enable)")


# --------------------------------------------------------------------------- #
# 8. BufferedLokiHandler                                                       #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("8. BufferedLokiHandler — skipped (no Loki server)")
print("=" * 60)

# buffered = BufferedLokiHandler(
#     url="http://localhost:3100",
#     labels={"app": "my-service"},
#     max_batch_size=50,
#     flush_interval=2.0,
# )
# for i in range(10):
#     get_logger().info(f"Batch record {i}")
# buffered.flush()   # or let the daemon thread flush automatically
# buffered.close()

print("  (set up BufferedLokiHandler to enable batch pushing)")


# --------------------------------------------------------------------------- #
# 9. Async example                                                             #
# --------------------------------------------------------------------------- #

print("\n" + "=" * 60)
print("9. AsyncLokiHandler — demo (no actual push)")
print("=" * 60)

import asyncio


async def demo_async() -> None:
    # async_handler = AsyncLokiHandler(url="http://localhost:3100")
    # async_logger = Logger("async_demo", handlers=[async_handler])
    # async_logger.info("Async push", coroutine="demo_async")
    # await async_handler.flush()
    print("  AsyncLokiHandler works in asyncio — uncomment to push to Loki.")


asyncio.run(demo_async())

print("\nAll examples completed successfully ✓")


# --------------------------------------------------------------------------- #
# 9. Dict example                                                             #
# --------------------------------------------------------------------------- #

# Como fazer um logger.info(some_dict)?
# Você pode passar um dicionário de duas formas

users = get_logger("myapp.users")
pythondata: Dict[str, Union[str, int]] = {"user_id": 42, "action": "login"}

users.info("Evento", **pythondata)

# Os campos aparecem como campos estruturados no JSON enviado ao Loki.