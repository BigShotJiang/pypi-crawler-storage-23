# MindBot 开发计划

> 基于 Thryve 的多通道 AI 助手

## 项目愿景

MindBot 是一个开箱即用的多通道 AI 助手。

## 阶段划分

| 阶段 | 内容 | 优先级 |
|------|------|--------|
| [阶段一](phase1_core.md) | 项目初始化与核心类 | P0 |
| [阶段二](phase2_cli.md) | CLI 实现 | P0 |
| [阶段三](phase3_channels.md) | 通道实现 | P1 |
| [阶段四](phase4_tools.md) | 工具系统 | P1 |
| [阶段五](phase5_integration.md) | 完善与集成 | P2 |

## 技术栈

- **核心框架**: Thryve v0.2.0
- **CLI**: typer + prompt_toolkit + rich
- **通道**: aiohttp/FastAPI
- **工具**: 内置 + MCP

## 快速开始

```bash
# 安装
pip install mindbot

# 初始化
mindbot onboard

# 对话
mindbot chat -m "你好"

# 交互式
mindbot shell

# 启动服务
mindbot serve --port 8080
```
