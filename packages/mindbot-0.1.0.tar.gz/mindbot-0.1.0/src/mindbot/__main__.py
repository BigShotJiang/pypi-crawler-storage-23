"""Entry point for running mindbot as a module: python -m mindbot"""

from mindbot.cli import app

if __name__ == "__main__":
    app()
