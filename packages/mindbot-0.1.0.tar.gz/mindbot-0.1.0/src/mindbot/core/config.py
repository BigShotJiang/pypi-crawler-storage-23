"""MindBot configuration."""

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# 默认路径
ROOT_DIR = Path.home() / ".mindbot"


class ChannelConfig:
    """通道配置包装类，支持属性访问。"""

    def __init__(self, config: dict):
        self._config = config

    def __getattr__(self, name: str):
        """获取子配置，返回 ChannelConfig 实例或原始值。"""
        if name in self._config:
            value = self._config[name]
            if isinstance(value, dict):
                return ChannelConfig(value)
            return value
        return None


class MindConfig(BaseSettings):
    """MindBot 根配置。

    封装所有配置，对外不暴露 Thryve 实现细节。
    """

    model_config = SettingsConfigDict(
        env_prefix="MIND_",
        env_nested_delimiter="__",
    )

    # ===== 路径配置 =====
    root_dir: Path = Field(default=ROOT_DIR)
    settings_path: Path = Field(default=ROOT_DIR / "settings.yaml")

    # ===== 行为配置 =====
    greeting: str = "你好！我是 MindBot，有什么可以帮你的吗？"
    max_turns: int = 10

    # ===== LLM 配置 =====
    model: str = "openai/kimi-k2.5"
    temperature: float = 1.0
    max_tokens: int = 8192

    # ===== 内存配置 =====
    short_term_days: int = 7

    # ===== 内部状态（不作为配置）=====
    _provider_config: dict = {}
    _channels_config: dict = {}

    # ===== 路径属性 =====

    @property
    def skills_dir(self) -> Path:
        """技能目录 (~/.mindbot/skills)"""
        return self.root_dir / "skills"

    @property
    def memory_dir(self) -> Path:
        """记忆目录 (~/.mindbot/memory)"""
        return self.root_dir / "memory"

    @property
    def db_path(self) -> Path:
        """数据库路径 (~/.mindbot/mindbot.db)"""
        return self.root_dir / "mindbot.db"

    @property
    def history_dir(self) -> Path:
        """历史记录目录 (~/.mindbot/history)"""
        return self.root_dir / "history"

    @property
    def cron_dir(self) -> Path:
        """Cron 目录 (~/.mindbot/cron)"""
        return self.root_dir / "cron"

    @property
    def channels(self) -> "ChannelConfig | None":
        """通道配置"""
        if not hasattr(self, "_channels_config") or not self._channels_config:
            return None
        return ChannelConfig(self._channels_config)

    # ===== Thryve 配置生成 =====
    # 对内使用，生成 Thryve 配置

    def to_thryve_config(self) -> dict:
        """生成 Thryve 配置字典。"""
        return {
            "agent": {
                "model": self.model,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
            },
            "providers": self._provider_config,
            "memory": {
                "storage_path": str(self.db_path),
                "markdown_path": str(self.memory_dir),
                "short_term_retention_days": self.short_term_days,
            },
        }

    # ===== 类方法 =====

    @classmethod
    def from_file(cls, path: Path | str) -> "MindConfig":
        """从 YAML 文件加载配置。

        Args:
            path: 配置文件路径

        Returns:
            MindConfig 实例
        """
        import yaml

        path = Path(path)
        if not path.exists():
            return cls()

        with open(path) as f:
            data = yaml.safe_load(f) or {}

        # 提取 Mind 配置
        inst = cls()

        # 路径
        if "root_dir" in data:
            inst.root_dir = Path(data["root_dir"]).expanduser()
            inst.settings_path = path

        # 行为配置
        if "greeting" in data:
            inst.greeting = data["greeting"]
        if "max_turns" in data:
            inst.max_turns = data["max_turns"]

        # LLM 配置
        if "agent" in data:
            if "model" in data["agent"]:
                inst.model = data["agent"]["model"]
            if "temperature" in data["agent"]:
                inst.temperature = data["agent"]["temperature"]
            if "max_tokens" in data["agent"]:
                inst.max_tokens = data["agent"]["max_tokens"]

        # 内存配置
        if "memory" in data:
            if "short_term_retention_days" in data["memory"]:
                inst.short_term_days = data["memory"]["short_term_retention_days"]

        # 保存 providers 配置供内部使用
        inst._provider_config = data.get("providers", {})

        # 保存 channels 配置供内部使用
        inst._channels_config = data.get("channels", {})

        return inst

    @classmethod
    def from_defaults(cls) -> "MindConfig":
        """从默认路径 (~/.mindbot/settings.yaml) 加载配置。"""
        default_path = ROOT_DIR / "settings.yaml"
        if default_path.exists():
            return cls.from_file(default_path)
        return cls()

    # ===== 方法 =====

    def ensure_directories(self) -> None:
        """确保必要目录存在。"""
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.cron_dir.mkdir(parents=True, exist_ok=True)
