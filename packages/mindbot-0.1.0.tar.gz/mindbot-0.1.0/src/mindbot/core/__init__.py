"""MindBot core module."""

from mindbot.core.bot import MindBot
from mindbot.core.config import MindConfig

__all__ = [
    "MindBot",
    "MindConfig",
]
