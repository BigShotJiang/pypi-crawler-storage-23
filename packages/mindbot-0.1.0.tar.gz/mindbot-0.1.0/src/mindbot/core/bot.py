"""MindBot - main application class."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from thryve import Thryve
from thryve.config import Config as ThryveConfig
from thryve.memory.types import MemoryChunk

from mindbot.core.config import MindConfig
from mindbot.cron import CronService


class MindBot:
    """MindBot - AI Assistant.

    Usage::

        from mindbot import MindBot

        bot = MindBot()
        response = bot.chat("Hello!")
    """

    def __init__(self, config: MindConfig | None = None) -> None:
        """初始化 MindBot。

        Args:
            config: MindConfig 配置。若为 None，则从默认路径加载。
        """
        self.config = config or MindConfig.from_defaults()

        # 确保目录存在
        self.config.ensure_directories()

        # 初始化 Thryve（内部使用）
        thryve_cfg = ThryveConfig(**self.config.to_thryve_config())
        self._thryve: Thryve = Thryve(thryve_cfg)

        # 初始化 Cron 服务
        cron_path = self.config.cron_dir / "jobs.json"
        self.cron: CronService = CronService(cron_path)

        # 状态
        self._running = False

    @classmethod
    def from_config(cls, config: MindConfig) -> "MindBot":
        """从配置实例创建 Bot。

        Args:
            config: MindConfig 实例

        Returns:
            MindBot 实例
        """
        return cls(config)

    @classmethod
    def from_file(cls, path: str | None = None) -> "MindBot":
        """从配置文件创建 Bot。

        Args:
            path: 配置文件路径。默认为 ~/.mindbot/settings.yaml

        Returns:
            MindBot 实例
        """
        if path:
            config = MindConfig.from_file(path)
        else:
            config = MindConfig.from_defaults()
        return cls(config)

    # ==================================================================
    # 配置属性（封装对外接口）
    # ==================================================================

    @property
    def model(self) -> str:
        """当前使用的模型。"""
        return self.config.model

    @property
    def provider(self) -> str:
        """当前使用的 Provider。"""
        return self.model.split("/")[0] if "/" in self.model else "unknown"

    @property
    def greeting(self) -> str:
        """问候语。"""
        return self.config.greeting

    # ==================================================================
    # Chat 接口
    # ==================================================================

    async def chat_async(
        self,
        message: str,
        session_id: str = "default",
    ) -> str:
        """异步对话。

        Args:
            message: 用户消息
            session_id: 会话 ID

        Returns:
            助手回复
        """
        return await self._thryve.chat_async(message, session_id=session_id)

    async def chat_stream_async(
        self,
        message: str,
        session_id: str = "default",
    ) -> AsyncIterator[str]:
        """异步流式对话。

        Args:
            message: 用户消息
            session_id: 会话 ID

        Yields:
            回复片段
        """
        async for chunk in self._thryve.chat_stream_async(
            message, session_id=session_id
        ):
            yield chunk

    def chat(
        self,
        message: str,
        session_id: str = "default",
    ) -> str:
        """同步对话。

        Args:
            message: 用户消息
            session_id: 会话 ID

        Returns:
            助手回复
        """
        return self._thryve.chat(message, session_id=session_id)

    # ==================================================================
    # Agent 接口
    # ==================================================================

    async def chat_with_agent_async(
        self,
        message: str,
        agent_name: str = "default",
    ) -> Any:
        """异步 Agent 对话（可使用工具）。

        Args:
            message: 用户消息
            agent_name: Agent 名称

        Returns:
            TurnResult
        """
        return await self._thryve.chat_with_agent_async(message, agent_name=agent_name)

    def chat_with_agent(
        self,
        message: str,
        agent_name: str = "default",
    ) -> Any:
        """同步 Agent 对话（可使用工具）。

        Args:
            message: 用户消息
            agent_name: Agent 名称

        Returns:
            TurnResult
        """
        return self._thryve.chat_with_agent(message, agent_name=agent_name)

    # ==================================================================
    # Memory 接口
    # ==================================================================

    def add_to_memory(self, content: str, permanent: bool = False) -> None:
        """添加内容到记忆。

        Args:
            content: 要记忆的内容
            permanent: 若为 True，则添加到长期记忆。默认 False（短期记忆）
        """
        self._thryve.add_to_memory(content, permanent=permanent)

    def add_short_term_memory(self, content: str) -> None:
        """添加内容到短期记忆（7天过期）。

        Args:
            content: 要记忆的内容
        """
        self._thryve.add_to_memory(content, permanent=False)

    def add_long_term_memory(self, content: str) -> None:
        """添加内容到长期记忆（永久保存）。

        Args:
            content: 要记忆的内容
        """
        self._thryve.add_to_memory(content, permanent=True)

    def search_memory(self, query: str, top_k: int = 5) -> list[MemoryChunk]:
        """搜索记忆。

        Args:
            query: 搜索查询
            top_k: 返回结果数量

        Returns:
            记忆片段列表
        """
        return self._thryve.search_memory(query, top_k=top_k)

    # ==================================================================
    # Tool 接口
    # ==================================================================

    def register_tool(self, tool: Any) -> None:
        """注册工具。

        Args:
            tool: 工具实例
        """
        self._thryve.register_tool(tool)

    def list_tools(self) -> list[Any]:
        """列出已注册的工具。

        Returns:
            工具列表
        """
        return self._thryve.list_tools()

    # ==================================================================
    # Introspection
    # ==================================================================

    def get_llm_info(self) -> Any:
        """获取 LLM Provider 信息。

        Returns:
            ProviderInfo
        """
        return self._thryve.get_llm_info()

    @property
    def is_running(self) -> bool:
        """检查 Bot 是否正在运行。"""
        return self._running

    async def start(self) -> None:
        """启动 Bot 和 Cron 服务。"""
        self._running = True
        await self.cron.start()

    async def stop(self) -> None:
        """停止 Bot 和 Cron 服务。"""
        self._running = False
        await self.cron.stop()
