"""MindBot - AI Assistant powered by Thryve."""

__version__ = "0.1.0"

__logo__ = """
╔════════════════════════════════════╗
║            MindBot                ║
╚════════════════════════════════════╝
"""

from mindbot.core.bot import MindBot
from mindbot.core.config import MindConfig
from mindbot.bus import MessageBus, InboundMessage, OutboundMessage
from mindbot.channels import BaseChannel, ChannelManager

__all__ = [
    "MindBot",
    "MindConfig",
    "MessageBus",
    "InboundMessage",
    "OutboundMessage",
    "BaseChannel",
    "ChannelManager",
    "__version__",
    "__logo__",
]
