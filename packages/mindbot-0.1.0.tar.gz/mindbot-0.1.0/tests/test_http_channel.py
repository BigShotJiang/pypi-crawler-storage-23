#!/usr/bin/env python3
"""Test script for mindbot HTTP channel.

This script tests all HTTP endpoints provided by mindbot:
- GET  /health          - Health check
- POST /chat            - Send message
- POST /chat/stream     - Streaming response
- GET  /memory/search   - Search memory
"""

import asyncio
import json
import sys
from typing import Any

import aiohttp

# Default configuration
DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8080
BASE_URL = f"http://{DEFAULT_HOST}:{DEFAULT_PORT}"


class Colors:
    """ANSI color codes for terminal output."""
    GREEN = "\033[92m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    END = "\033[0m"


def print_success(msg: str) -> None:
    """Print success message in green."""
    print(f"{Colors.GREEN}✓ {msg}{Colors.END}")


def print_error(msg: str) -> None:
    """Print error message in red."""
    print(f"{Colors.RED}✗ {msg}{Colors.END}")


def print_info(msg: str) -> None:
    """Print info message in cyan."""
    print(f"{Colors.CYAN}ℹ {msg}{Colors.END}")


def print_section(msg: str) -> None:
    """Print section header."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}═══ {msg} ═══{Colors.END}\n")


async def test_health(session: aiohttp.ClientSession) -> bool:
    """Test health check endpoint."""
    print_section("Health Check Test")
    try:
        async with session.get(f"{BASE_URL}/health") as response:
            if response.status == 200:
                data = await response.json()
                print_info(f"Status: {data.get('status')}")
                print_info(f"Channel: {data.get('channel')}")
                print_info(f"Bus queue sizes: {data.get('bus', {})}")
                print_success("Health check passed")
                return True
            else:
                print_error(f"Health check failed with status {response.status}")
                return False
    except Exception as e:
        print_error(f"Health check error: {e}")
        return False


async def test_chat(session: aiohttp.ClientSession) -> bool:
    """Test chat endpoint."""
    print_section("Chat Endpoint Test")
    test_cases = [
        {
            "name": "Normal message",
            "payload": {
                "content": "Hello, MindBot!",
                "chat_id": "test_user_001",
                "session_id": "test_session"
            }
        },
        {
            "name": "Message with emoji",
            "payload": {
                "content": "How are you today? 😊",
                "chat_id": "test_user_002"
            }
        },
        {
            "name": "Long message",
            "payload": {
                "content": "This is a longer message to test if the bot can handle " * 10,
                "chat_id": "test_user_003"
            }
        }
    ]

    results = []
    for test_case in test_cases:
        try:
            async with session.post(
                f"{BASE_URL}/chat",
                json=test_case["payload"],
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    print_success(f"{test_case['name']}: {data.get('message')}")
                    results.append(True)
                else:
                    error = await response.text()
                    print_error(f"{test_case['name']}: Failed with status {response.status} - {error}")
                    results.append(False)
        except Exception as e:
            print_error(f"{test_case['name']}: Error - {e}")
            results.append(False)

    return all(results)


async def test_chat_stream(session: aiohttp.ClientSession) -> bool:
    """Test streaming chat endpoint."""
    print_section("Streaming Chat Test")
    try:
        async with session.post(
            f"{BASE_URL}/chat/stream",
            json={
                "content": "Tell me a short story",
                "chat_id": "stream_test_user"
            },
            headers={"Content-Type": "application/json"},
            timeout=aiohttp.ClientTimeout(total=10)
        ) as response:
            if response.status == 200:
                print_info("Streaming response status: 200")
                print_info(f"Content-Type: {response.headers.get('Content-Type', 'N/A')}")

                # Read the full stream response
                full_data = b""
                chunk_count = 0
                async for data in response.content.iter_any():
                    full_data += data
                    chunk_count += 1
                    # Limit reading to avoid hanging
                    if chunk_count > 10 or len(full_data) > 5000:
                        break

                if full_data:
                    preview = full_data[:200].decode('utf-8', errors='replace')
                    print_success(f"Stream is working. Received {chunk_count} chunks, {len(full_data)} bytes")
                    print_info(f"Content preview: {preview}")
                    return True
                else:
                    print_error("No data received from stream")
                    return False
            else:
                error_text = await response.text()
                print_error(f"Stream failed with status {response.status}: {error_text}")
                return False
    except asyncio.TimeoutError:
        print_error("Stream test timed out (this may indicate the stream is waiting for data)")
        return False
    except Exception as e:
        print_error(f"Stream test error: {type(e).__name__}: {e}")
        return False


async def test_memory_search(session: aiohttp.ClientSession) -> bool:
    """Test memory search endpoint."""
    print_section("Memory Search Test")
    test_cases = [
        {
            "name": "Valid search query",
            "params": {"q": "test", "limit": 5}
        },
        {
            "name": "Search with high limit",
            "params": {"q": "memory", "limit": 100}
        }
    ]

    results = []
    for test_case in test_cases:
        try:
            async with session.get(
                f"{BASE_URL}/memory/search",
                params=test_case["params"]
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    print_success(f"{test_case['name']}: Found {data.get('count', 0)} results")
                    results.append(True)
                else:
                    print_error(f"{test_case['name']}: Failed with status {response.status}")
                    results.append(False)
        except Exception as e:
            print_error(f"{test_case['name']}: Error - {e}")
            results.append(False)

    return all(results)


async def test_error_handling(session: aiohttp.ClientSession) -> bool:
    """Test error handling."""
    print_section("Error Handling Test")
    error_cases = [
        {
            "name": "Missing content",
            "endpoint": "/chat",
            "payload": {"chat_id": "test"},
            "expected_error": "content is required"
        },
        {
            "name": "Invalid JSON",
            "endpoint": "/chat",
            "payload": "invalid json",
            "expected_status": 400
        },
        {
            "name": "Memory search without query",
            "endpoint": "/memory/search",
            "params": {},
            "expected_error": "query parameter 'q' is required"
        }
    ]

    results = []
    for error_case in error_cases:
        try:
            if error_case["endpoint"] in ["/chat", "/chat/stream"]:
                async with session.post(
                    f"{BASE_URL}{error_case['endpoint']}",
                    json=error_case["payload"] if isinstance(error_case["payload"], dict) else None,
                    data=error_case["payload"] if isinstance(error_case["payload"], str) else None,
                    headers={"Content-Type": "application/json"}
                ) as response:
                    data = await response.json() if response.content_type == "application/json" else await response.text()
                    if "expected_error" in error_case:
                        if error_case["expected_error"] in str(data):
                            print_success(f"{error_case['name']}: Correctly rejected")
                            results.append(True)
                        else:
                            print_error(f"{error_case['name']}: Unexpected error message")
                            results.append(False)
                    else:
                        if response.status == error_case.get("expected_status", 400):
                            print_success(f"{error_case['name']}: Correctly rejected with {response.status}")
                            results.append(True)
                        else:
                            print_error(f"{error_case['name']}: Unexpected status {response.status}")
                            results.append(False)
            else:  # GET requests
                async with session.get(
                    f"{BASE_URL}{error_case['endpoint']}",
                    params=error_case.get("params", {})
                ) as response:
                    data = await response.json() if response.content_type == "application/json" else await response.text()
                    if error_case.get("expected_error") in str(data):
                        print_success(f"{error_case['name']}: Correctly rejected")
                        results.append(True)
                    else:
                        print_error(f"{error_case['name']}: Unexpected response")
                        results.append(False)
        except Exception as e:
            print_error(f"{error_case['name']}: Error - {e}")
            results.append(False)

    return all(results)


async def run_all_tests(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> dict[str, bool]:
    """Run all HTTP channel tests."""
    global BASE_URL
    BASE_URL = f"http://{host}:{port}"

    print(f"\n{Colors.BOLD}{Colors.YELLOW}MindBot HTTP Channel Test Suite{Colors.END}")
    print(f"{Colors.CYAN}Target: {BASE_URL}{Colors.END}\n")

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        results = {
            "health": await test_health(session),
            "chat": await test_chat(session),
            "stream": await test_chat_stream(session),
            "memory_search": await test_memory_search(session),
            "error_handling": await test_error_handling(session)
        }

    return results


def print_summary(results: dict[str, bool]) -> None:
    """Print test summary."""
    print_section("Test Summary")
    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, passed_flag in results.items():
        status = f"{Colors.GREEN}PASSED{Colors.END}" if passed_flag else f"{Colors.RED}FAILED{Colors.END}"
        print(f"{test_name:20s}: {status}")

    print(f"\n{Colors.BOLD}Total: {passed}/{total} tests passed{Colors.END}\n")

    if passed == total:
        print_success("All tests passed!")
        sys.exit(0)
    else:
        print_error("Some tests failed!")
        sys.exit(1)


def main() -> None:
    """Main entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="Test mindbot HTTP channel")
    parser.add_argument("--host", default=DEFAULT_HOST, help="Server host (default: localhost)")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Server port (default: 8080)")
    args = parser.parse_args()

    results = asyncio.run(run_all_tests(args.host, args.port))
    print_summary(results)


if __name__ == "__main__":
    main()
