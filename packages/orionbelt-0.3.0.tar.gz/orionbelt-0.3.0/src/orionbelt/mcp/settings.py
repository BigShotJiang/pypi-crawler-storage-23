"""MCP server settings — re-exported from shared settings module."""

from orionbelt.settings import Settings as MCPSettings

__all__ = ["MCPSettings"]
