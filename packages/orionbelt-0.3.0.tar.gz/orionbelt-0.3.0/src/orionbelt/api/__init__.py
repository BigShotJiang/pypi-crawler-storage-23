"""FastAPI REST layer for OrionBelt Semantic Layer."""
