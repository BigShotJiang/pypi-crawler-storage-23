"""OrionBelt Semantic Layer — Compiles YAML semantic models into analytical SQL."""

__version__ = "0.3.0"
