"""Core service layer for OrionBelt Semantic Layer."""
