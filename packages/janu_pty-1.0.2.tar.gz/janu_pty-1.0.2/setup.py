from setuptools import setup, find_packages

setup(
    name="janu_pty",
    version="1.0.2",
    description="A simple and powerful web based Terminal Engine - A Docker-powered Cloud PTY",
    author="shaikjanu",
    packages=find_packages(),
    install_requires=[
        "docker",          # To control the isolated sandboxes
        "flask",           # For the embedded web server
        "flask-socketio",  # For lightning-fast real-time terminal streaming
        "eventlet"         # The async engine to keep it lag-free
    ],
    include_package_data=True, # Important: This ensures our HTML UI file gets packaged later!
)
