# OSCR
Open Source Combatlog Reader for Star Trek Online. This repository contains the parser itself. It is intended to compile this into a package and make it accessible via PyPi.

## CLI
The CLI can be used to provide an overview over a combatlog file.

Usage: `python -m OSCR.cli` / `python3 -m OSCR.cli`
