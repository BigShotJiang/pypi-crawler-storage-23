"""
Media management for archaeological documentation
"""

from .media_handler import MediaHandler

__all__ = [
    "MediaHandler"
]