"""
Scripts package for PyArchInit-Mini
"""