"""Shared utilities for logging, observability, serialization, and process management."""
