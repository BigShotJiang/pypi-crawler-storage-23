# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Cross-channel formatting helpers.

Each channel uses a different markup syntax for bold, code, and italic text.
These helpers let the shared ConnectMixin build messages once and render them
correctly for any channel.
"""

from enum import Enum
from html import escape as _html_escape


class FormatMode(Enum):
    """Markup dialect understood by each channel."""

    HTML = "html"  # Telegram
    MARKDOWN = "markdown"  # Discord, Teams
    WHATSAPP = "whatsapp"  # WhatsApp (*bold*)
    PLAIN = "plain"  # Signal, Matrix


def fmt_bold(text: str, mode: FormatMode) -> str:
    """Render *text* as bold in the given format."""
    if mode is FormatMode.HTML:
        return f"<b>{text}</b>"
    if mode is FormatMode.MARKDOWN:
        return f"**{text}**"
    if mode is FormatMode.WHATSAPP:
        return f"*{text}*"
    return text


def fmt_code(text: str, mode: FormatMode) -> str:
    """Render *text* as inline code in the given format."""
    if mode is FormatMode.HTML:
        return f"<code>{_html_escape(text)}</code>"
    if mode in (FormatMode.MARKDOWN, FormatMode.WHATSAPP):
        return f"`{text}`"
    return text


def fmt_italic(text: str, mode: FormatMode) -> str:
    """Render *text* as italic in the given format."""
    if mode is FormatMode.HTML:
        return f"<i>{text}</i>"
    if mode is FormatMode.MARKDOWN:
        return f"*{text}*"
    if mode is FormatMode.WHATSAPP:
        return f"_{text}_"
    return text
