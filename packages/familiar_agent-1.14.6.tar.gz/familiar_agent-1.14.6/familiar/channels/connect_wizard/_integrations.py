# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""SMS, Browser, Voice, Healthcare, and WebSearch wizards."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import yaml

from ..formatting import fmt_bold, fmt_code, fmt_italic
from ._helpers import _check_twilio_lib, _test_http_service, _update_env_file, _update_yaml_config
from ._protocol import WizardHost

logger = logging.getLogger(__name__)


# ── SMS (Twilio) wizard ──────────────────────────────────────────


async def wizard_sms(host: WizardHost, recipient_id: str, args: list) -> None:
    m = host.format_mode
    sub = args[0] if args else ""

    if sub == "test":
        to_number = args[1] if len(args) > 1 else ""
        await wizard_sms_test(host, recipient_id, to_number)
        return

    if sub.startswith("AC") and len(args) >= 3:
        await wizard_sms_save(host, recipient_id, args[0], args[1], args[2])
        return

    has_sid = bool(os.environ.get("TWILIO_ACCOUNT_SID"))
    has_token = bool(os.environ.get("TWILIO_AUTH_TOKEN"))
    has_phone = bool(os.environ.get("TWILIO_PHONE_NUMBER"))
    has_lib = _check_twilio_lib()

    if has_sid and has_token and has_phone:
        phone = os.environ.get("TWILIO_PHONE_NUMBER", "")
        _icon = "\u2705" if has_lib else "\u274c"
        await host.wizard_send(
            recipient_id,
            f"\U0001f4f1 {fmt_bold('SMS Configuration', m)}\n\n"
            f"  \u2705 Twilio SID: "
            f"{fmt_code(os.environ.get('TWILIO_ACCOUNT_SID', '')[:8] + '...', m)}\n"
            f"  \u2705 Auth Token: \u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\n"
            f"  \u2705 Phone: {fmt_code(phone, m)}\n"
            f"  {_icon} twilio package\n\n"
            f"{fmt_bold('Commands:', m)}\n"
            f"  {fmt_code('/connect sms test +1XXXXXXXXXX', m)}"
            f" \u2014 send test\n\n"
            f"Cost: ~$1/month + $0.0079/SMS",
        )
        return

    await host.wizard_send(
        recipient_id,
        f"\U0001f4f1 {fmt_bold('Connect SMS (Twilio)', m)}\n\n"
        f"{fmt_bold('Setup:', m)}\n"
        f"1. Create account at https://www.twilio.com\n"
        f"2. Get a phone number (~$1/month)\n"
        f"3. Find credentials on Twilio Console dashboard\n\n"
        f"{fmt_bold('One-shot setup (3 values, space-separated):', m)}\n"
        f"  {fmt_code('/connect sms <SID> <TOKEN> <PHONE>', m)}\n\n"
        f"{fmt_bold('Example:', m)}\n"
        f"  {fmt_code('/connect sms ACe0a988d7... 9f3c8b... +15551234567', m)}\n\n"
        f"  \u2022 SID starts with {fmt_bold('AC', m)}"
        f" (from Console > Account Info)\n"
        f"  \u2022 Token is the 32-char hex string below it\n"
        f"  \u2022 Phone is your Twilio number"
        f" (not your personal number)\n\n"
        f"Cost: ~$1/month + $0.0079/SMS sent",
    )


async def wizard_sms_save(
    host: WizardHost,
    recipient_id: str,
    sid: str,
    token: str,
    phone: str,
) -> None:
    m = host.format_mode
    env_vars = {
        "TWILIO_ACCOUNT_SID": sid,
        "TWILIO_AUTH_TOKEN": token,
        "TWILIO_PHONE_NUMBER": phone,
    }
    for k, v in env_vars.items():
        os.environ[k] = v
    env_path = Path.home() / ".familiar" / ".env"
    try:
        _update_env_file(env_path, env_vars)
    except Exception as e:
        await host.wizard_send(
            recipient_id,
            f"\u26a0\ufe0f Failed to save: {e}",
        )
        return

    has_lib = _check_twilio_lib()
    _icon = "\u2705" if has_lib else "\u274c (auto-installs on first use)"
    await host.wizard_send(
        recipient_id,
        f"\u2705 {fmt_bold('SMS configured!', m)}\n\n"
        f"  SID: {fmt_code(sid[:8] + '...', m)}\n"
        f"  Phone: {fmt_code(phone, m)}\n"
        f"  twilio package: {_icon}\n\n"
        f"Test: {fmt_code('/connect sms test +1XXXXXXXXXX', m)}",
    )


async def wizard_sms_test(
    host: WizardHost,
    recipient_id: str,
    to_number: str,
) -> None:
    m = host.format_mode
    if not to_number:
        await host.wizard_send(
            recipient_id,
            f"Usage: {fmt_code('/connect sms test +1XXXXXXXXXX', m)}",
        )
        return
    if not os.environ.get("TWILIO_ACCOUNT_SID"):
        await host.wizard_send(
            recipient_id,
            "\u26a0\ufe0f Twilio not configured. Use /connect sms",
        )
        return
    try:
        from twilio.rest import Client
    except ImportError:
        from familiar.core.deps import SMS_PACKAGES, ensure_packages

        ok, _ = ensure_packages(SMS_PACKAGES)
        if not ok:
            await host.wizard_send(
                recipient_id,
                "\u274c twilio installation failed. Check server logs.",
            )
            return
        from twilio.rest import Client

    try:
        client = Client(
            os.environ["TWILIO_ACCOUNT_SID"],
            os.environ["TWILIO_AUTH_TOKEN"],
        )
        message = client.messages.create(
            body="Hello from Familiar! \U0001f40d SMS is working.",
            from_=os.environ["TWILIO_PHONE_NUMBER"],
            to=to_number,
        )
        await host.wizard_send(
            recipient_id,
            f"\u2705 Test SMS sent to {to_number}\nSID: {message.sid}",
        )
    except Exception as e:
        await host.wizard_send(
            recipient_id,
            f"\u274c SMS failed: {e}",
        )


# ── Browser (Playwright) checker ─────────────────────────────────


async def wizard_browser(host: WizardHost, recipient_id: str) -> None:
    m = host.format_mode
    has_playwright = False
    has_chromium = False

    try:
        import playwright  # noqa: F401

        has_playwright = True
    except ImportError:
        pass

    if has_playwright:
        # Check for Chromium binary on disk — sync_playwright() cannot
        # run inside an async event loop (Telegram, Discord, etc.)
        _pw_dir = Path.home() / ".cache" / "ms-playwright"
        if _pw_dir.exists():
            has_chromium = any(
                _pw_dir.glob("chromium-*/chrome-linux*/chrome"),
            )

    ck, cr = "\u2705", "\u274c"
    if has_playwright and has_chromium:
        await host.wizard_send(
            recipient_id,
            f"\U0001f310 {fmt_bold('Browser Automation', m)}\n\n"
            f"  {ck} playwright package\n"
            f"  {ck} Chromium browser\n\n"
            f'Ready! Try: "Search the web for..."\n\n'
            f"{fmt_italic('Requires TRUSTED or OWNER trust level.', m)}",
        )
        return

    lines = [
        f"\U0001f310 {fmt_bold('Browser Automation Setup', m)}\n",
        f"  {ck if has_playwright else cr} playwright package",
        f"  {ck if has_chromium else cr} Chromium browser\n",
    ]
    if not has_playwright:
        lines.append(
            f"Tap {fmt_bold('Install now', m)} to install playwright + Chromium.",
        )
    elif not has_chromium:
        lines.append(
            f"Tap {fmt_bold('Install now', m)} to install Chromium browser.",
        )

    lines.append(
        fmt_italic(
            "Chromium requires ~150MB and system libraries.",
            m,
        ),
    )

    if host.supports_buttons:
        await host.wizard_send_menu(
            recipient_id,
            "\n".join(lines),
            [
                ("browser_install_cmd", "\U0001f4e6 Install now"),
                ("browser_recheck", "\U0001f504 Re-check installation"),
            ],
        )
    else:
        await host.wizard_send(recipient_id, "\n".join(lines))


# ── Voice (Whisper/TTS) checker ──────────────────────────────────


async def wizard_voice(host: WizardHost, recipient_id: str) -> None:
    m = host.format_mode
    has_faster_whisper = False
    has_whisper = False
    has_piper = False

    try:
        import faster_whisper  # noqa: F401

        has_faster_whisper = True
    except ImportError:
        pass
    try:
        import whisper  # noqa: F401

        has_whisper = True
    except ImportError:
        pass
    try:
        import piper  # noqa: F401

        has_piper = True
    except ImportError:
        pass

    has_openai_tts = bool(os.environ.get("OPENAI_API_KEY"))
    ck, em = "\u2705", "\u2b1c"
    has_any_stt = has_faster_whisper or has_whisper
    has_any_tts = has_piper or has_openai_tts

    lines = [
        f"\U0001f3a4 {fmt_bold('Voice & Transcription', m)}\n",
        f"{fmt_bold('Speech-to-Text:', m)}",
        f"  {ck if has_faster_whisper else em} faster-whisper (recommended, fast)",
        f"  {ck if has_whisper else em} openai-whisper (original, slower)",
        "",
        f"{fmt_bold('Text-to-Speech:', m)}",
        f"  {ck if has_piper else em} piper-tts (local, fast)",
        f"  {ck if has_openai_tts else em} OpenAI TTS (cloud, high quality)",
        "",
    ]

    if has_any_stt:
        engine = "faster-whisper" if has_faster_whisper else "openai-whisper"
        lines.append(f"\u2705 Transcription ready ({engine})")
    else:
        lines.append(
            f"Tap {fmt_bold('Install now', m)} to install faster-whisper (STT).",
        )

    if not has_any_tts:
        lines.append(
            f"Tap {fmt_bold('Install now', m)} to also install piper-tts (TTS).",
        )

    lines.append(
        f"\n{fmt_italic('Whisper models download on first use (~75MB for tiny).', m)}",
    )

    fully_installed = has_any_stt and has_any_tts
    if host.supports_buttons and not fully_installed:
        await host.wizard_send_menu(
            recipient_id,
            "\n".join(lines),
            [
                ("voice_install_cmd", "\U0001f4e6 Install now"),
                ("voice_recheck", "\U0001f504 Re-check installation"),
            ],
        )
    else:
        await host.wizard_send(recipient_id, "\n".join(lines))


# ── Healthcare / Compliance ──────────────────────────────────────


async def wizard_healthcare(
    host: WizardHost,
    recipient_id: str,
    args: list,
) -> None:
    """``/connect healthcare [hipaa|pii|disable]``"""
    m = host.format_mode

    agent = getattr(host, "agent", None)
    compliance_mode = getattr(agent, "compliance_mode", None)
    compliance_str = (
        compliance_mode.value
        if hasattr(compliance_mode, "value")
        else str(compliance_mode or "none")
    )
    pii_cfg = getattr(getattr(agent, "config", None), "agent", None)
    pii_on = getattr(pii_cfg, "enable_pii_detection", False) if pii_cfg else False

    if not args:
        # Show current status + options menu
        if compliance_str == "hipaa":
            current = "HIPAA mode active (encryption + PII blocking + audit logging)"
        elif pii_on:
            current = "PII detection enabled (redact mode)"
        else:
            current = "Not enabled"

        lines = [
            f"\U0001f3e5 {fmt_bold('Healthcare / Compliance', m)}\n",
            f"{fmt_bold('Current:', m)} {current}\n",
            f"{fmt_bold('Options:', m)}",
            f"  \u2022 {fmt_bold('HIPAA', m)} \u2014 encryption + PII blocking + audit logging",
            f"  \u2022 {fmt_bold('PII only', m)}"
            f" \u2014 redact sensitive data (SSN, email, phone),"
            f" no full HIPAA",
            f"  \u2022 {fmt_bold('Disable', m)} \u2014 no compliance features\n",
            "Commands:",
            f"  {fmt_code('/connect healthcare hipaa', m)}",
            f"  {fmt_code('/connect healthcare pii', m)}",
            f"  {fmt_code('/connect healthcare disable', m)}",
        ]

        options = [
            ("healthcare_hipaa", "\U0001f3e5 Enable HIPAA"),
            ("healthcare_pii", "\U0001f50d PII Only"),
            ("healthcare_disable", "\u274c Disable"),
        ]

        await host.wizard_send_menu(
            recipient_id,
            "\n".join(lines),
            options,
        )
        return

    action = args[0].lower()

    if action == "hipaa":
        try:
            _update_yaml_config(
                {
                    "compliance": {
                        "mode": "hipaa",
                        "require_encryption": True,
                        "log_phi_access": True,
                    },
                    "agent": {"enable_pii_detection": True},
                }
            )
            # Live-update agent config if available
            if agent:
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "compliance",
                ):
                    agent.config.compliance.mode = "hipaa"
                    agent.config.compliance.require_encryption = True
                    agent.config.compliance.log_phi_access = True
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "agent",
                ):
                    agent.config.agent.enable_pii_detection = True
                if hasattr(agent, "guardrails"):
                    agent.guardrails.set_compliance_mode("hipaa")
            await host.wizard_send(
                recipient_id,
                f"{fmt_bold('HIPAA mode enabled', m)} \u2705\n\n"
                f"\u2022 PII detection:"
                f" {fmt_bold('BLOCK', m)}"
                f" (SSN, email, phone, credit card)\n"
                f"\u2022 Encryption: required\n"
                f"\u2022 PHI audit logging: on\n\n"
                f"Saved to {fmt_code('~/.familiar/config.yaml', m)}",
            )
        except Exception as e:
            await host.wizard_send(
                recipient_id,
                f"\u26a0\ufe0f Failed to enable HIPAA mode: {e}",
            )

    elif action == "pii":
        try:
            _update_yaml_config(
                {
                    "compliance": {"mode": "none"},
                    "agent": {"enable_pii_detection": True},
                }
            )
            if agent:
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "compliance",
                ):
                    agent.config.compliance.mode = "none"
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "agent",
                ):
                    agent.config.agent.enable_pii_detection = True
                # Ensure guardrails has a PII detector in redact mode
                if hasattr(agent, "guardrails"):
                    g = agent.guardrails
                    if not g._pii_detector:
                        from familiar.core.guardrails import (
                            PIIConfig,
                            PIIDetector,
                        )

                        g._pii_detector = PIIDetector(PIIConfig())
                        g.pii_config = g._pii_detector.config
            await host.wizard_send(
                recipient_id,
                f"{fmt_bold('PII detection enabled', m)} \u2705\n\n"
                f"\u2022 Action:"
                f" {fmt_bold('REDACT', m)}"
                f" (SSN, email, phone, credit card)\n"
                f"\u2022 Compliance mode:"
                f" none (no HIPAA overhead)\n\n"
                f"Saved to {fmt_code('~/.familiar/config.yaml', m)}",
            )
        except Exception as e:
            await host.wizard_send(
                recipient_id,
                f"\u26a0\ufe0f Failed to enable PII detection: {e}",
            )

    elif action == "disable":
        try:
            _update_yaml_config(
                {
                    "compliance": {
                        "mode": "none",
                        "require_encryption": False,
                        "log_phi_access": False,
                    },
                    "agent": {"enable_pii_detection": False},
                }
            )
            if agent:
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "compliance",
                ):
                    agent.config.compliance.mode = "none"
                    agent.config.compliance.require_encryption = False
                    agent.config.compliance.log_phi_access = False
                if hasattr(agent, "config") and hasattr(
                    agent.config,
                    "agent",
                ):
                    agent.config.agent.enable_pii_detection = False
                if hasattr(agent, "guardrails"):
                    agent.guardrails._pii_detector = None
                    agent.guardrails.pii_config = None
            await host.wizard_send(
                recipient_id,
                f"{fmt_bold('Healthcare / compliance disabled', m)}"
                f" \u2705\n\n"
                f"\u2022 PII detection: off\n"
                f"\u2022 Compliance mode: none\n\n"
                f"Saved to {fmt_code('~/.familiar/config.yaml', m)}",
            )
        except Exception as e:
            await host.wizard_send(
                recipient_id,
                f"\u26a0\ufe0f Failed to disable compliance: {e}",
            )

    else:
        await host.wizard_send(
            recipient_id,
            f"Unknown healthcare option: {action}\n\n"
            f"Use: {fmt_code('/connect healthcare hipaa', m)}, "
            f"{fmt_code('/connect healthcare pii', m)}, or "
            f"{fmt_code('/connect healthcare disable', m)}",
        )


# ── WebSearch wizard ──────────────────────────────────────────────


async def wizard_websearch(
    host: WizardHost,
    recipient_id: str,
    args: list,
) -> None:
    """WebSearch backend configuration wizard."""
    m = host.format_mode
    sub = args[0].lower() if args else ""

    if sub == "test":
        await wizard_websearch_test(host, recipient_id)
        return

    if sub == "searxng" and len(args) > 1:
        url = args[1]
        await wizard_websearch_save_searxng(host, recipient_id, url)
        return

    if sub in ("duckduckgo", "ddg"):
        # Reset to default DuckDuckGo backend
        _update_yaml_config(
            {"websearch": {"backend": "duckduckgo", "searxng_url": ""}},
        )
        await host.wizard_send(
            recipient_id,
            f"\u2705 WebSearch backend reset to {fmt_bold('DuckDuckGo', m)} (default).",
        )
        return

    # Show current status
    config_path = Path.home() / ".familiar" / "config.yaml"
    backend = "duckduckgo"
    searxng_url = ""
    try:
        if config_path.exists():
            cfg = yaml.safe_load(config_path.read_text()) or {}
            ws = cfg.get("websearch", {})
            backend = ws.get("backend", "duckduckgo")
            searxng_url = ws.get("searxng_url", "")
    except Exception:
        pass

    searxng_line = ""
    if searxng_url:
        searxng_line = f"\nSearXNG URL: {fmt_code(searxng_url, m)}"

    await host.wizard_send(
        recipient_id,
        f"\U0001f50d {fmt_bold('WebSearch Configuration', m)}\n\n"
        f"Active backend: {fmt_bold(backend, m)}{searxng_line}\n\n"
        f"{fmt_bold('Commands:', m)}\n"
        f"/connect websearch test \u2014 test current backend\n"
        f"/connect websearch searxng <url>"
        f" \u2014 use SearXNG instance\n"
        f"/connect websearch duckduckgo \u2014 reset to default\n\n"
        f"{fmt_bold('Backends:', m)}\n"
        f"  \u2022 {fmt_bold('DuckDuckGo', m)}"
        f" \u2014 works out of the box, no setup needed\n"
        f"  \u2022 {fmt_bold('SearXNG', m)}"
        f" \u2014 self-hosted, private, configurable\n\n"
        f"{fmt_bold('SearXNG setup:', m)}\n"
        f"  1. Deploy SearXNG (Docker recommended):\n"
        f"     {fmt_code('docker run -d -p 8080:8080 searxng/searxng', m)}\n"
        f"  2. Configure:"
        f" {fmt_code('/connect websearch searxng http://localhost:8080', m)}\n"
        f"  3. Test: {fmt_code('/connect websearch test', m)}",
    )


async def wizard_websearch_save_searxng(
    host: WizardHost,
    recipient_id: str,
    url: str,
) -> None:
    """Save SearXNG as the active websearch backend."""
    m = host.format_mode
    _update_yaml_config(
        {"websearch": {"backend": "searxng", "searxng_url": url}},
    )

    await host.wizard_send(
        recipient_id,
        f"\u2705 {fmt_bold('SearXNG Configured', m)}\n\n"
        f"URL: {fmt_code(url, m)}\n"
        f"Backend: searxng\n"
        f"Saved to: {fmt_code('~/.familiar/config.yaml', m)}\n\n"
        f"Testing...",
    )

    # Auto-test after save
    await wizard_websearch_test(host, recipient_id)


async def wizard_websearch_test(
    host: WizardHost,
    recipient_id: str,
) -> None:
    """Test websearch backend reachability."""
    m = host.format_mode
    ck = "\u2705"
    cr = "\u274c"
    results = []

    # Always test DuckDuckGo
    ddg_ok, ddg_msg = _test_http_service(
        "https://html.duckduckgo.com/html/",
    )
    results.append(f"  {ck if ddg_ok else cr} DuckDuckGo: {ddg_msg}")

    # Test SearXNG if configured
    config_path = Path.home() / ".familiar" / "config.yaml"
    backend = "duckduckgo"
    searxng_url = ""
    try:
        if config_path.exists():
            cfg = yaml.safe_load(config_path.read_text()) or {}
            ws = cfg.get("websearch", {})
            backend = ws.get("backend", "duckduckgo")
            searxng_url = ws.get("searxng_url", "")
    except Exception:
        pass

    if searxng_url:
        sx_ok, sx_msg = _test_http_service(searxng_url)
        results.append(
            f"  {ck if sx_ok else cr} SearXNG ({searxng_url}): {sx_msg}",
        )

    active_marker = f"\n\nActive backend: {fmt_bold(backend, m)}"

    await host.wizard_send(
        recipient_id,
        f"\U0001f50d {fmt_bold('WebSearch Test', m)}\n\n" + "\n".join(results) + active_marker,
    )


# ── Menu-selection dispatcher ────────────────────────────────────


async def handle_menu_selection(
    host: WizardHost,
    recipient_id: str,
    key: str,
) -> bool:
    """Dispatch button callbacks for integration wizards.

    Returns ``True`` if the *key* was handled, ``False`` otherwise.
    """
    if key == "sms_menu":
        await wizard_sms(host, recipient_id, [])
        return True
    if key == "browser_menu":
        await wizard_browser(host, recipient_id)
        return True
    if key == "voice_menu":
        await wizard_voice(host, recipient_id)
        return True
    if key == "healthcare_menu":
        await wizard_healthcare(host, recipient_id, [])
        return True
    if key.startswith("healthcare_"):
        action = key[len("healthcare_") :]
        await wizard_healthcare(host, recipient_id, [action])
        return True
    if key == "websearch_menu":
        await wizard_websearch(host, recipient_id, [])
        return True
    return False
