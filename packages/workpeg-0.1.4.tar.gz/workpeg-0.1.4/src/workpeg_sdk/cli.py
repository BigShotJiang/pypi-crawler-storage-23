import argparse
import sys

from workpeg_sdk import create_new, runtime, submit


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="workpeg")
    sub = p.add_subparsers(dest="command", required=True)

    # workpeg submit
    # <function>:<version> [--api ...] [--path ...] [--timeout ...]
    submit_p = sub.add_parser("submit", help="Submit a function bundle")
    submit_p.add_argument("ref")
    submit_p.add_argument("--api", default=None)
    submit_p.add_argument("--path", default=None)
    submit_p.add_argument("--timeout", type=int, default=None)
    submit_p.set_defaults(_handler="submit")

    # workpeg new-function <path> [--force]
    new_p = sub.add_parser(
        "new-function", help="Create a new function project from template")
    new_p.add_argument("path")
    new_p.add_argument("--force", action="store_true")
    new_p.set_defaults(_handler="new-function")

    # workpeg runtime
    run_p = sub.add_parser(
        "runtime", help="Run a function locally (reads JSON from stdin)")
    run_p.set_defaults(_handler="runtime")

    return p


def main(argv=None) -> None:
    argv = argv if argv is not None else sys.argv[1:]
    parser = build_parser()
    args = parser.parse_args(argv)

    if args._handler == "new-function":
        # call the implementation directly (no double-argparse)
        try:
            out = create_new.create_new_project(args.path, force=args.force)
            print(str(out))
        except create_new.TemplateError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            raise SystemExit(2)
        return

    if args._handler == "runtime":
        # runtime may read stdin, so call directly
        runtime.main([])
        return

    if args._handler == "submit":
        # build argv for submit.main (it already supports argv)
        submit_argv = [args.ref]
        if args.api:
            submit_argv += ["--api", args.api]
        if args.path:
            submit_argv += ["--path", args.path]
        if args.timeout is not None:
            submit_argv += ["--timeout", str(args.timeout)]
        submit.main(submit_argv)
        return
