import argparse
import base64
import io
import json
import os
import sys
import tarfile
from pathlib import Path
from typing import Tuple

import requests


DEFAULT_API_BASE = "https://repo.workpeg.com"
JWT_ENV = "WORKPEG_PK"
API_ENV = "WORKPEG_API_BASE"
PATH_ENV = "WORKPEG_SUBMIT_PATH"


def _fail(msg: str, code: int = 2) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(code)


def parse_ref(ref: str) -> Tuple[str, str]:
    """
    Parse "function_name:version"
    """
    if ":" not in ref:
        _fail("Expected <function_name>:<version> (example: fn_echo:1.0.0)")
    function_id, version = ref.split(":", 1)
    function_id = function_id.strip()
    version = version.strip()

    if not function_id:
        _fail("function_name is empty")
    if not version:
        _fail("version is empty")

    return function_id, version


def decode_jwt_payload_no_verify(token: str) -> dict:
    """
    Extract JWT payload WITHOUT verifying signature.
    We only use it to find peg_namespace for routing.
    Server will validate the token signature anyway.
    """
    parts = token.split(".")
    if len(parts) != 3:
        _fail("Invalid JWT format (expected 3 segments)")

    payload_b64 = parts[1]
    # Add required padding for base64url
    padding = "=" * (-len(payload_b64) % 4)
    payload_b64 += padding

    try:
        raw = base64.urlsafe_b64decode(payload_b64.encode("utf-8"))
        payload = json.loads(raw.decode("utf-8"))
        return payload
    except Exception:
        _fail("Could not decode JWT payload")


def build_tar_gz_bytes(source_dir: Path) -> bytes:
    """
    Create a tar.gz archive in memory from a source directory.
    Excludes common junk by default.
    """
    if not source_dir.exists() or not source_dir.is_dir():
        _fail(f"Path does not exist or is not a directory: {source_dir}")

    exclude_names = {
        ".git",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".venv",
        "venv",
        "dist",
        "build",
        ".DS_Store",
    }

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for p in source_dir.rglob("*"):
            rel = p.relative_to(source_dir)

            # skip excluded dirs/files
            if any(part in exclude_names for part in rel.parts):
                continue

            # tar wants posix paths
            arcname = rel.as_posix()

            # Always include directories as needed
            tar.add(p.as_posix(), arcname=arcname, recursive=False)

    return buf.getvalue()


def submit_bundle(
    *,
    api_base: str,
    peg_id: str,
    token: str,
    function_id: str,
    version: str,
    bundle_bytes: bytes,
    timeout_s: int = 60,
) -> dict:
    url = f"{api_base.rstrip('/')}/api/pegs/{peg_id}/functions/"

    files = {
        "bundle": ("bundle.tar.gz", bundle_bytes, "application/gzip"),
    }
    data = {
        "function_id": function_id,
        "version": version,
    }
    headers = {
        "Authorization": f"Bearer {token}",
    }

    r = requests.post(url, data=data, files=files,
                      headers=headers, timeout=timeout_s)
    if r.status_code >= 400:
        # try to show API error
        try:
            body = r.json()
        except Exception:
            body = r.text
        _fail(f"Submit failed ({r.status_code}): {body}", code=1)

    return r.json()


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        prog="workpeg submit",
        description="Submit a Workpeg function bundle to a Peg.")
    parser.add_argument(
        "ref",
        help="Function reference in the form <function_name>:<version>"
        " (e.g., fn_echo:1.0.0)")
    parser.add_argument("--api", default=os.environ.get(API_ENV,
                        DEFAULT_API_BASE), help="API base URL")
    parser.add_argument("--path", default=os.environ.get(PATH_ENV,
                        "."), help="Function project directory")
    parser.add_argument("--timeout", type=int, default=60,
                        help="Request timeout (seconds)")
    args = parser.parse_args(argv)

    token = os.environ.get(JWT_ENV)
    if not token:
        _fail(f"Missing env var {JWT_ENV}")

    function_id, version = parse_ref(args.ref)

    payload = decode_jwt_payload_no_verify(token)
    peg_id = payload.get("peg_namespace")
    if not peg_id:
        _fail(
            "JWT missing peg_namespace "
            "(cannot route to /api/pegs/{peg_id}/...)")

    source_dir = Path(args.path).resolve()
    bundle_bytes = build_tar_gz_bytes(source_dir)

    result = submit_bundle(
        api_base=args.api,
        peg_id=str(peg_id),
        token=token,
        function_id=function_id,
        version=version,
        bundle_bytes=bundle_bytes,
        timeout_s=args.timeout,
    )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
