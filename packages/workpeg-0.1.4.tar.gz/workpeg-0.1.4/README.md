# Workpeg SDK

Python SDK for building **Workpeg functions and Pegs**.

The SDK provides tools to:

* Create new Workpeg function projects
* Run functions locally
* Submit function packages to the Workpeg registry

More features are coming, including Peg development tools, UI capabilities, and deployment workflows.

Repository
[https://gitlab.com/workpeg/workpeg-sdk](https://gitlab.com/workpeg/workpeg-sdk)

---

# Installation

```bash
pip install workpeg
```

Or install from source:

```bash
pip install -e .
```

---

# Getting Started

## 1. Create a new function project

```bash
workpeg new-function my-function
```

This creates a project scaffold like:

```
my-function/
  app/
    __init__.py
    main.py
```

Your function lives in `app/main.py`.

Example:

```python
def main(context, payload):
    return {
        "message": "Hello from Workpeg",
        "payload": payload
    }
```

---

## 2. Run locally

Functions are executed through the runtime.

Example:

```bash
echo '{"context": {}, "payload": {"name": "world"}}' | workpeg runtime
```

Output:

```json
{
  "status": "success",
  "result": {
    "message": "Hello from Workpeg",
    "payload": {"name": "world"}
  }
}
```

The runtime expects input in this format:

```json
{
  "context": {...},
  "payload": {...}
}
```

---

## 3. Submit a function

Package your function and submit it to the Workpeg registry.

```bash
workpeg submit my-function:1.0.0
```

Authentication is provided through the `WORKPEG_PK` environment variable.

Example:

```bash
export WORKPEG_PK=<your-token>
```

The function will be uploaded to:

```
https://repo.workpeg.com
```

---

# Function Entrypoint

By default the runtime loads:

```
app.main:main
```

You can override this using an environment variable:

```
FUNCTION_ENTRYPOINT=module.path:function
```

Example:

```bash
FUNCTION_ENTRYPOINT=app.main:handler workpeg runtime
```

---

# Project Structure

Typical function project:

```
my-function
 ├─ app
 │  ├─ __init__.py
 │  └─ main.py
 └─ requirements.txt
```

---

# Roadmap

The SDK will expand to support:

* Peg development tooling
* UI features for building Peg interfaces
* Packaging and deployment workflows
* Function sandboxing and execution tooling

---

# Documentation

Full documentation is coming soon.

---

# License

MIT License
