import argparse
import logging
import os
import random
import time
from collections.abc import Callable
from datetime import datetime
from typing import Any

from notion_client import APIResponseError, Client

from ml_loadtest.analyze import LoadTestAnalyzer, PerformanceMetrics, compute_rate_limits

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

DATABASE_TITLE = "ML Load Test Results"
ENDPOINT_DATABASE_TITLE = "ML Endpoint Statistics"

DATABASE_SCHEMA: dict[str, Any] = {
    "Name": {"title": {}},
    "Service Name": {"select": {}},
    "Service Version": {"rich_text": {}},
    "Date": {"date": {}},
    "P99 (ms)": {"number": {"format": "number"}},
    "RPS": {"number": {"format": "number"}},
    "P99 Baseline (ms)": {"number": {"format": "number"}},
    "RPS Baseline": {"number": {"format": "number"}},
    "P99 Change (%)": {"number": {"format": "number"}},
    "RPS Change (%)": {"number": {"format": "number"}},
    "Instance Type": {"select": {}},
    "Provider": {"select": {}},
    "CPU Cores (Physical)": {"number": {"format": "number"}},
    "CPU Cores (Logical)": {"number": {"format": "number"}},
    "Memory (GB)": {"number": {"format": "number"}},
    "Total Standard Limit": {"number": {"format": "number"}},
    "Total Burst Limit": {"number": {"format": "number"}},
}

ENDPOINT_DATABASE_SCHEMA: dict[str, Any] = {
    "Name": {"title": {}},
    "Endpoint": {"select": {}},
    "Service Name": {"select": {}},
    "Service Version": {"rich_text": {}},
    "P99 (ms)": {"number": {"format": "number"}},
    "RPS": {"number": {"format": "number"}},
    "P99 Baseline (ms)": {"number": {"format": "number"}},
    "RPS Baseline": {"number": {"format": "number"}},
    "P99 Change (%)": {"number": {"format": "number"}},
    "RPS Change (%)": {"number": {"format": "number"}},
    "Standard Limit": {"number": {"format": "number"}},
    "Burst Limit": {"number": {"format": "number"}},
}

MAX_RETRIES = 3
BASE_DELAY = 1.0


def _rich_text(text: str) -> list[dict[str, Any]]:
    return [{"type": "text", "text": {"content": str(text)}}]


def _heading_2(text: str) -> dict[str, Any]:
    return {
        "object": "block",
        "type": "heading_2",
        "heading_2": {"rich_text": _rich_text(text)},
    }


def _heading_3(text: str) -> dict[str, Any]:
    return {
        "object": "block",
        "type": "heading_3",
        "heading_3": {"rich_text": _rich_text(text)},
    }


def _paragraph(text: str) -> dict[str, Any]:
    return {
        "object": "block",
        "type": "paragraph",
        "paragraph": {"rich_text": _rich_text(text)},
    }


def _build_table_block(headers: list[str], rows: list[list[str]]) -> list[dict[str, Any]]:
    """Build a Notion table block with header row and data rows.

    Notion tables require a parent table block with table_rows as children.
    """
    width = len(headers)
    table_rows: list[dict[str, Any]] = []

    table_rows.append(
        {
            "object": "block",
            "type": "table_row",
            "table_row": {"cells": [_rich_text(h) for h in headers]},
        }
    )

    for row in rows:
        padded = row + [""] * (width - len(row))
        table_rows.append(
            {
                "object": "block",
                "type": "table_row",
                "table_row": {"cells": [_rich_text(cell) for cell in padded[:width]]},
            }
        )

    return [
        {
            "object": "block",
            "type": "table",
            "table": {
                "table_width": width,
                "has_column_header": True,
                "has_row_header": False,
                "children": table_rows,
            },
        }
    ]


class NotionSync:
    def __init__(
        self,
        token: str,
        test_results_database_id: str | None = None,
        endpoint_database_id: str | None = None,
        parent_page_id: str | None = None,
    ) -> None:
        self.client = Client(auth=token)
        self.test_results_database_id = test_results_database_id
        self.endpoint_database_id = endpoint_database_id
        self.parent_page_id = parent_page_id

    def _api_call_with_retry(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        for attempt in range(MAX_RETRIES):
            try:
                return fn(*args, **kwargs)
            except APIResponseError as e:
                if e.status == 429 and attempt < MAX_RETRIES - 1:
                    delay = BASE_DELAY * (2**attempt) + random.uniform(0, 1)  # noqa: S311
                    logger.warning(f"Rate limited, retrying in {delay:.1f}s (attempt {attempt + 1}/{MAX_RETRIES})")
                    time.sleep(delay)
                else:
                    raise
        return None  # unreachable, satisfies mypy

    def ensure_database(self) -> str:
        if self.test_results_database_id:
            try:
                self._api_call_with_retry(self.client.databases.retrieve, database_id=self.test_results_database_id)
                logger.info(f"Using existing database: {self.test_results_database_id}")
                return self.test_results_database_id
            except APIResponseError as e:
                if e.status == 403:
                    raise RuntimeError(
                        f"Permission denied for database {self.test_results_database_id}. "
                        "Ensure the Notion integration has access to this database."
                    ) from e
                else:
                    raise

        if not self.parent_page_id:
            raise RuntimeError(
                "No database_id configured and no --parent-page-id provided. "
                "On first run, provide --parent-page-id to create the database."
            )

        logger.info(f"Creating test results database under page {self.parent_page_id}")
        # Notion API expects properties inside initial_data_source, not top-level.
        result = self._api_call_with_retry(
            self.client.databases.create,
            parent={"type": "page_id", "page_id": self.parent_page_id},
            title=_rich_text(DATABASE_TITLE),
            initial_data_source={"properties": DATABASE_SCHEMA},
        )
        self.test_results_database_id = result["id"]
        logger.info(f"Created test results database: {self.test_results_database_id}")
        return self.test_results_database_id

    def ensure_endpoint_database(self) -> str:
        if self.endpoint_database_id:
            try:
                self._api_call_with_retry(self.client.databases.retrieve, database_id=self.endpoint_database_id)
                logger.info(f"Using existing endpoint database: {self.endpoint_database_id}")
                return self.endpoint_database_id
            except APIResponseError as e:
                if e.status == 403:
                    raise RuntimeError(
                        f"Permission denied for endpoint database {self.endpoint_database_id}. "
                        "Ensure the Notion integration has access to this database."
                    ) from e
                else:
                    raise

        if not self.parent_page_id:
            raise RuntimeError(
                "No endpoint_database_id configured and no --parent-page-id provided. "
                "On first run, provide --parent-page-id to create the database."
            )

        test_results_db_id = self.ensure_database()

        logger.info(f"Creating endpoint database under page {self.parent_page_id}")
        result = self._api_call_with_retry(
            self.client.databases.create,
            parent={"type": "page_id", "page_id": self.parent_page_id},
            title=_rich_text(ENDPOINT_DATABASE_TITLE),
            initial_data_source={"properties": ENDPOINT_DATABASE_SCHEMA},
        )
        self.endpoint_database_id = result["id"]

        fields_to_update = ["Test Run", "Date", "Service Name", "Service Version"]
        for field in fields_to_update:
            logger.warning(
                f"Please edit the `{field}` property in the endpoint database to set it as a relation "
                f"to the `{test_results_db_id}` database for better linking and filtering"
            )

        logger.info(f"Created endpoint database: {self.endpoint_database_id}")
        return self.endpoint_database_id

    def _build_properties(
        self,
        service_name: str,
        service_version: str,
        metrics: PerformanceMetrics,
        safety_factor: float,
        baseline: PerformanceMetrics | None = None,
    ) -> dict[str, Any]:
        instance = metrics.instance_info
        instance_type = instance.instance_type if instance else None
        provider = instance.provider if instance else None

        _, total_standard, total_burst = compute_rate_limits(
            metrics.individual_capacities, metrics.endpoint_stats, safety_factor
        )

        date_str = metrics.timestamp
        try:
            dt = datetime.fromisoformat(date_str)
            iso_date = dt.strftime("%Y-%m-%dT%H:%M:%S")
        except (ValueError, TypeError):
            iso_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        title = f"Load Test — {service_name} — {service_version} — {iso_date}"
        props: dict[str, Any] = {
            "Name": {"title": _rich_text(title)},
            "Service Name": {"select": {"name": service_name}},
            "Service Version": {"rich_text": _rich_text(service_version)},
            "Date": {"date": {"start": iso_date}},
            "P99 (ms)": {"number": round(metrics.p99_ms, 2)},
            "RPS": {"number": round(metrics.rps, 2)},
        }

        if baseline:
            props["P99 Baseline (ms)"] = {"number": round(baseline.p99_ms, 2)}
            props["RPS Baseline"] = {"number": round(baseline.rps, 2)}

        if instance_type:
            props["Instance Type"] = {"select": {"name": instance_type}}
        if provider:
            props["Provider"] = {"select": {"name": provider}}
        if instance and instance.cpu_count_physical_cores is not None:
            props["CPU Cores (Physical)"] = {"number": instance.cpu_count_physical_cores}
        if instance and instance.cpu_count_logical_cores is not None:
            props["CPU Cores (Logical)"] = {"number": instance.cpu_count_logical_cores}
        if instance and instance.memory_gb is not None:
            props["Memory (GB)"] = {"number": instance.memory_gb}
        if total_standard is not None:
            props["Total Standard Limit"] = {"number": total_standard}
        if total_burst is not None:
            props["Total Burst Limit"] = {"number": total_burst}

        return props

    def _build_detail_blocks(self, metrics: PerformanceMetrics, safety_factor: float) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = []
        instance = metrics.instance_info

        if instance:
            blocks.append(_heading_2("Instance Information"))
            rows = [
                ["Hostname", str(instance.hostname or "N/A")],
                ["OS", f'{instance.os_name or "N/A"} {instance.os_version or ""}'],
                ["Instance Type", str(instance.instance_type or "N/A")],
                ["Instance ID", str(instance.instance_id or "N/A")],
                ["Provider", str(instance.provider or "N/A")],
                ["CPU Model", str(instance.cpu_model or "N/A")],
                ["CPU Cores (Physical)", str(instance.cpu_count_physical_cores or "N/A")],
                ["CPU Cores (Logical)", str(instance.cpu_count_logical_cores or "N/A")],
                ["Memory (GB)", str(instance.memory_gb or "N/A")],
            ]
            blocks.extend(_build_table_block(["Field", "Value"], rows))

        blocks.append(_heading_2("Production Results"))
        blocks.append(_paragraph(f"Global P99: {metrics.p99_ms:.1f}ms"))
        blocks.append(_paragraph(f"Global RPS: {metrics.rps:.2f}"))

        if metrics.distribution_weights or metrics.endpoint_stats:
            rows = []
            endpoints = set(metrics.distribution_weights.keys() if metrics.distribution_weights else [])
            endpoints.update(metrics.endpoint_stats.keys() if metrics.endpoint_stats else [])
            for ep in sorted(endpoints):
                weight = (metrics.distribution_weights or {}).get(ep, 0)
                stats = (metrics.endpoint_stats or {}).get(ep)
                p99 = f"{stats.p99_ms:.1f}" if stats else "-"
                rps = f"{stats.rps:.2f}" if stats else "-"
                rows.append([ep, f"{weight}", p99, rps])

            blocks.extend(_build_table_block(["Endpoint", "Weight (%)", "P99 (ms)", "RPS"], rows))

        if metrics.individual_capacities:
            blocks.append(_heading_2("Individual Capacities"))
            rows = []
            for ep, stats in metrics.individual_capacities.items():
                rows.append([ep, f"{stats.p99_ms:.1f}", f"{stats.rps:.2f}"])
            blocks.extend(_build_table_block(["Endpoint", "P99 (ms)", "Max RPS"], rows))

        rate_limits, total_standard, total_burst = compute_rate_limits(
            metrics.individual_capacities, metrics.endpoint_stats, safety_factor
        )
        if rate_limits:
            blocks.append(_heading_2("Rate Limit Recommendations"))
            blocks.append(_paragraph(f"Safety Factor: {safety_factor * 100:.0f}%"))
            rows = []
            for ep, limits in rate_limits.items():
                std = str(limits["per_second"]) if limits["per_second"] is not None else "N/A"
                burst = str(limits["burst"]) if limits["burst"] is not None else "N/A"
                rows.append([ep, std, burst])
            if total_standard is not None and total_burst is not None:
                rows.append(["GLOBAL TOTAL", str(total_standard), str(total_burst)])
            blocks.extend(_build_table_block(["Endpoint", "Standard (req/s)", "Burst (req/s)"], rows))

        return blocks

    def _create_endpoint_entries(
        self,
        test_run_page_id: str,
        service_name: str,
        service_version: str,
        metrics: PerformanceMetrics,
        safety_factor: float,
        iso_date: str,
        baseline: PerformanceMetrics | None = None,
    ) -> None:
        endpoint_db_id = self.ensure_endpoint_database()

        rate_limits, _, _ = compute_rate_limits(metrics.individual_capacities, metrics.endpoint_stats, safety_factor)

        all_endpoints = set(metrics.endpoint_stats.keys()) | set(metrics.individual_capacities.keys())
        if baseline and baseline.individual_capacities:
            all_endpoints |= set(baseline.individual_capacities.keys())

        for ep in sorted(all_endpoints):
            title = f"{ep} — {service_name} — {service_version} — {iso_date}"
            props: dict[str, Any] = {
                "Name": {"title": _rich_text(title)},
                "Endpoint": {"select": {"name": ep}},
                "Test Run": {"relation": [{"id": test_run_page_id}]},
            }

            if ep in metrics.individual_capacities:
                props["P99 (ms)"] = {"number": round(metrics.individual_capacities[ep].p99_ms, 2)}
                props["RPS"] = {"number": round(metrics.individual_capacities[ep].rps, 2)}

            if baseline and baseline.individual_capacities and ep in baseline.individual_capacities:
                props["P99 Baseline (ms)"] = {"number": round(baseline.individual_capacities[ep].p99_ms, 2)}
                props["RPS Baseline"] = {"number": round(baseline.individual_capacities[ep].rps, 2)}

            if ep in rate_limits:
                limits = rate_limits[ep]
                if limits["per_second"] is not None:
                    props["Standard Limit"] = {"number": limits["per_second"]}
                if limits["burst"] is not None:
                    props["Burst Limit"] = {"number": limits["burst"]}

            self._api_call_with_retry(
                self.client.pages.create,
                parent={"database_id": endpoint_db_id},
                properties=props,
            )
            logger.info(f"Created endpoint entry: {ep}")

    def create_page(
        self,
        service_name: str,
        service_version: str,
        metrics: PerformanceMetrics,
        safety_factor: float,
        baseline: PerformanceMetrics | None = None,
    ) -> str:
        db_id = self.ensure_database()
        properties = self._build_properties(
            service_name=service_name,
            service_version=service_version,
            metrics=metrics,
            safety_factor=safety_factor,
            baseline=baseline,
        )
        detail_blocks = self._build_detail_blocks(metrics=metrics, safety_factor=safety_factor)

        result = self._api_call_with_retry(
            self.client.pages.create,
            parent={"database_id": db_id},
            properties=properties,
            children=detail_blocks,
        )
        page_id: str = result["id"]
        page_url = result.get("url", "")
        logger.info(f"Created page: {page_url}")

        date_str = metrics.timestamp
        try:
            dt = datetime.fromisoformat(date_str)
            iso_date = dt.strftime("%Y-%m-%dT%H:%M:%S")
        except (ValueError, TypeError):
            logger.warning("Invalid or missing timestamp in metrics, using current date for endpoint entries")
            iso_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        self._create_endpoint_entries(
            test_run_page_id=page_id,
            service_name=service_name,
            service_version=service_version,
            metrics=metrics,
            safety_factor=safety_factor,
            iso_date=iso_date,
            baseline=baseline,
        )

        return page_id


def load_metrics(report_file: str, baseline_file: str) -> tuple[PerformanceMetrics, PerformanceMetrics | None]:
    analyzer = LoadTestAnalyzer(loadtest_report_file=report_file, baseline_file=baseline_file)
    metrics = analyzer.load_from_report()

    baseline = analyzer.load_baseline()
    if baseline and not metrics.distribution_weights:
        metrics.distribution_weights = baseline.distribution_weights
    if baseline and not metrics.individual_capacities:
        metrics.individual_capacities = baseline.individual_capacities

    randomize_data = False
    if randomize_data:
        # Add small random noise to metrics to prevent identical values which can cause issues in Notion
        # (e.g. duplicate page titles)
        noise_factor = 0.5
        metrics.p99_ms *= 1 + random.uniform(-noise_factor, noise_factor)
        metrics.rps *= 1 + random.uniform(-noise_factor, noise_factor)
        if metrics.endpoint_stats:
            for stats in metrics.endpoint_stats.values():
                stats.p99_ms *= 1 + random.uniform(-noise_factor, noise_factor)
                stats.rps *= 1 + random.uniform(-noise_factor, noise_factor)
        if metrics.individual_capacities:
            for stats in metrics.individual_capacities.values():
                stats.p99_ms *= 1 + random.uniform(-noise_factor, noise_factor)
                stats.rps *= 1 + random.uniform(-noise_factor, noise_factor)

    return metrics, baseline


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync ML load test results to Notion")
    parser.add_argument(
        "service_name",
        help="Name of the service being tested (used for page title)",
    )
    parser.add_argument(
        "service_version",
        help="Version of the service being tested (used for page title and properties)",
    )
    parser.add_argument(
        "--report-file",
        default="report_loadtest_results.json",
        help="Path to load test report JSON file",
    )
    parser.add_argument(
        "--baseline-file",
        default="baseline.json",
        help="Path to baseline JSON file",
    )
    parser.add_argument(
        "--notion-token",
        default=None,
        help="Notion integration token (or set NOTION_TOKEN env var)",
    )
    parser.add_argument(
        "--test-results-database-id",
        default=None,
        help="Existing Notion test results database ID (or set NOTION_TEST_RESULTS_DATABASE_ID env var)",
    )
    parser.add_argument(
        "--endpoint-database-id",
        default=None,
        help="Existing Notion endpoint statistics database ID (or set NOTION_ENDPOINT_DATABASE_ID env var)",
    )
    parser.add_argument(
        "--parent-page-id",
        default=None,
        help="Notion page ID to create database under (first run)",
    )
    parser.add_argument(
        "--safety-factor",
        type=float,
        default=0.7,
        help="Safety factor for rate limit calculation (default: 0.7)",
    )

    args = parser.parse_args()

    token = args.notion_token or os.environ.get("NOTION_TOKEN")
    if not token:
        parser.error("Notion token required: use --notion-token or set NOTION_TOKEN env var")

    test_results_database_id = args.test_results_database_id or os.environ.get("NOTION_TEST_RESULTS_DATABASE_ID")
    endpoint_database_id = args.endpoint_database_id or os.environ.get("NOTION_ENDPOINT_DATABASE_ID")

    metrics, baseline = load_metrics(args.report_file, args.baseline_file)

    sync = NotionSync(
        token=token,
        test_results_database_id=test_results_database_id,
        endpoint_database_id=endpoint_database_id,
        parent_page_id=args.parent_page_id,
    )

    sync.create_page(
        service_name=args.service_name,
        service_version=args.service_version,
        metrics=metrics,
        safety_factor=args.safety_factor,
        baseline=baseline,
    )

    logger.info("Sync complete")


if __name__ == "__main__":
    main()
