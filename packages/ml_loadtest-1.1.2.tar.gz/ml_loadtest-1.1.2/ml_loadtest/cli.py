"""CLI helper to provide path to installed locustfile for direct locust usage."""

import sys
from pathlib import Path


def get_locustfile_path() -> str:
    """Return absolute path to installed locustfile.py.

    Returns:
        Absolute path string to the locustfile.py in the installed package.
    """
    package_dir = Path(__file__).parent
    locustfile = package_dir / "locustfile.py"
    return str(locustfile.absolute())


def main() -> None:
    """CLI entry point that prints locustfile path.

    Usage:
        locust -f $(ml-loadtest-file) --host http://api:8000 [any locust params]
    """
    print(get_locustfile_path())
    sys.exit(0)


if __name__ == "__main__":
    main()
