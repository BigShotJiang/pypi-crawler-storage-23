import io
import json
import logging
import platform
import random
import threading
import time
import urllib
from collections import deque
from dataclasses import asdict, dataclass
from enum import Enum

import numpy as np
import psutil
from locust import HttpUser, TaskSet, events, task
from locust.runners import LocalRunner, MasterRunner

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class Mode(str, Enum):
    """Test modes."""

    INDIVIDUAL = "individual"
    PRODUCTION = "production"
    EXPLORATION = "exploration"
    SPIKE = "spike"

    def __str__(self) -> str:
        """Return the string representation of the mode.

        :returns: The string value of the mode.
        """
        return self.value


@dataclass
class EndpointMetrics:
    """Metrics for a single endpoint."""

    latency_buffer: deque[float]
    timestamp_buffer: deque[float]

    def calculate_p99(self, min_samples: int = 100) -> float | None:
        """Calculate P99 latency for this endpoint.

        :param min_samples: Minimum number of samples required to calculate P99.
        :returns: P99 latency in milliseconds, or None if not enough samples.
        """
        if len(self.latency_buffer) < min_samples:
            return None
        return float(np.percentile(self.latency_buffer, 99))

    def calculate_rps(self, window_sec: int = 60) -> float:
        """Calculate requests per second (RPS) for this endpoint.

        :param window_sec: Time window in seconds to calculate RPS.
        :returns: Requests per second in the specified window.
        """
        now = time.time()
        window_start = now - window_sec
        recent_count = sum(1 for ts in self.timestamp_buffer if ts >= window_start)
        return recent_count / window_sec if window_sec > 0 else 0.0

    def clear_buffers(self) -> None:
        """Clear the latency and timestamp buffers."""
        self.latency_buffer.clear()
        self.timestamp_buffer.clear()


@dataclass
class EndpointStats:
    """Statistics for a single endpoint during a test run."""

    p99_ms: float
    rps: float


@dataclass
class Report:
    """Report for a single test run configuration."""

    mode: Mode
    weights: dict[str, float]
    p99_ms: float
    rps: float
    endpoint_stats: dict[str, EndpointStats]
    elapsed_time: str


@dataclass
class WeightsConfig:
    """Configuration for endpoint weights during tests."""

    mode: Mode
    name: str
    weights: dict[str, float]


@dataclass
class InstanceInfo:
    """Information about the test instance"""

    # Basic system info
    hostname: str | None
    os_name: str | None
    os_version: str | None

    # Hardware info
    cpu_count_physical_cores: int | None
    cpu_count_logical_cores: int | None
    cpu_model: str | None
    memory_gb: float | None

    # Cloud provider info
    instance_type: str | None = None
    instance_id: str | None = None
    provider: str | None = None


class Timer:
    """Simple timer class to track elapsed time."""

    def __init__(self) -> None:
        """Initialize the timer."""
        self.start_time: float | None = None

    def start(self) -> None:
        """Start the timer."""
        self.start_time = time.perf_counter()

    def get_elapsed_seconds(self) -> int:
        """Return total elapsed seconds since start.

        :returns: The number of elapsed seconds as an integer.
        :raises ValueError: If the timer has not been started.
        """
        if self.start_time is None:
            raise ValueError("Timer has not been started.")
        return int(time.perf_counter() - self.start_time)

    def get_elapsed_str(self) -> str:
        """Return elapsed time in format 'XhYmZs'.

        :returns: A string representation of elapsed time in format 'XhYmZs'.
        """
        total_seconds = self.get_elapsed_seconds()
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours}h{minutes}m{seconds}s"


class InstanceInfoCollector:
    @staticmethod
    def collect() -> InstanceInfo:
        """Gather all available instance information

        :returns: An InstanceInfo object with collected data.
        """
        info = InstanceInfo(
            hostname=platform.node(),
            os_name=platform.system(),
            os_version=platform.release(),
            cpu_count_physical_cores=psutil.cpu_count(logical=False),
            cpu_count_logical_cores=psutil.cpu_count(logical=True),
            cpu_model=InstanceInfoCollector._get_cpu_model(),
            memory_gb=round(psutil.virtual_memory().total / (1024**3), 2),
        )
        InstanceInfoCollector._collect_aws_info(info)
        return info

    @staticmethod
    def _collect_aws_info(info: InstanceInfo) -> None:
        """Collect AWS EC2 metadata

        :param info: InstanceInfo object to populate with AWS data.
        :raises: Exception if metadata cannot be retrieved.
        """
        try:
            # Get IMDSv2 token
            token_req = urllib.request.Request(
                "http://169.254.169.254/latest/api/token",
                headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"},
                method="PUT",
            )
            token_response = urllib.request.urlopen(token_req, timeout=1)  # noqa: S310
            token = token_response.read().decode()

            def get_metadata(path) -> str:
                req = urllib.request.Request(
                    f"http://169.254.169.254/latest/meta-data/{path}", headers={"X-aws-ec2-metadata-token": token}
                )
                return urllib.request.urlopen(req, timeout=1).read().decode()  # noqa: S310

            info.provider = "AWS"
            info.instance_type = get_metadata("instance-type")
            info.instance_id = get_metadata("instance-id")

        except Exception as e:  # noqa: BLE001
            logger.warning(f"Warning: Could not collect AWS metadata: {e}")

    @staticmethod
    def _get_cpu_model() -> str:
        """Get CPU model name

        :returns: CPU model name or 'Unknown' if not available.
        """
        try:
            if platform.system() == "Linux":
                with open("/proc/cpuinfo") as f:
                    for line in f:
                        if "model name" in line:
                            return line.split(":")[1].strip()
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Warning: Could not get CPU model: {e}")
        return platform.processor() or "Unknown"


class EndpointCapacityExplorer:
    """Explores the capacity of each endpoint individually and in combination."""

    def __init__(
        self,
        output_file: str,
        target_p99_ms: int,
        min_users: int,
        max_users: int,
        increase_rate: float,
        decrease_rate: float,
        check_interval: int,
        tolerance: float,
        stable_periods_required: int,
        buffer_size: int,
        min_samples: int,
        production_run_duration: int,
        individual_run_max_duration: int,
        enable_individual_run: bool,
        enable_production_run: bool,
        enable_exploration_run: bool,
        enable_spike_run: bool,
        spike_target_rps: int,
        spike_duration: int,
    ) -> None:
        """Initialize the explorer with configuration parameters.

        :param output_file: The base name for output files (without extension).
        :param target_p99_ms: Target P99 latency in milliseconds.
        :param min_users: Minimum number of users to spawn.
        :param max_users: Maximum number of users to spawn.
        :param increase_rate: Multiplier for increasing user count.
        :param decrease_rate: Multiplier for decreasing user count.
        :param check_interval: Interval in seconds between checks.
        :param tolerance: Tolerance factor for P99 target (e.g., 0.1 = 10%).
        :param stable_periods_required: Number of stable periods before increasing users.
        :param buffer_size: Size of the latency buffer for metrics calculation.
        :param min_samples: Minimum number of samples required for P99 calculation.
        :param production_run_duration: Duration in seconds for production run mode.
        :param individual_run_max_duration: Maximum duration in seconds for individual endpoint runs.
        :param enable_individual_run: Whether to enable individual endpoint testing.
        :param enable_production_run: Whether to enable production configuration testing.
        :param enable_exploration_run: Whether to enable exploration variations testing.
        :param enable_spike_run: Whether to enable spike testing.
        :param spike_target_rps: Target RPS for spike mode.
        :param spike_duration: Duration in seconds for spike mode.
        """
        self.output_file = output_file
        self.target_p99_ms = target_p99_ms
        self.min_users = min_users
        self.max_users = max_users
        self.current_users = min_users

        # Control parameters
        self.increase_rate = increase_rate
        self.decrease_rate = decrease_rate
        self.check_interval = check_interval
        self.tolerance = tolerance
        self.stable_periods_required = stable_periods_required

        # Mode control flags
        self.enable_individual_run = enable_individual_run
        self.enable_production_run = enable_production_run
        self.enable_exploration_run = enable_exploration_run
        self.enable_spike_run = enable_spike_run

        # spike mode parameters
        self.spike_target_rps = spike_target_rps
        self.spike_duration = spike_duration

        # Metrics storage per endpoint
        self.endpoint_metrics: dict[str, EndpointMetrics] = {}
        self.buffer_size = buffer_size
        self.min_samples = min_samples

        # Global metrics
        self.global_latency_buffer: deque[float] = deque(maxlen=self.buffer_size)
        self.global_timestamp_buffer: deque[float] = deque(maxlen=self.buffer_size)

        # Control settings
        self.runner = None
        self.control_thread = None
        self.complete = False
        self.current_endpoint_index = 0
        self.stable_periods = 0
        self.timer = Timer()
        self.production_run_duration = production_run_duration
        self.individual_run_max_duration = individual_run_max_duration

        # Results storage
        self.reports: dict[str, Report] = {}

        # Weight configurations to test
        self.weight_configurations: list[WeightsConfig] = []
        self.current_config_index: int | None = None

    def initialize_endpoints(self, endpoint_names: list[str]) -> None:
        """Initialize metrics tracking for each endpoint.

        :param endpoint_names: List of endpoint names to initialize metrics for.
        """
        for name in endpoint_names:
            self.endpoint_metrics[name] = EndpointMetrics(
                latency_buffer=deque(maxlen=self.buffer_size),
                timestamp_buffer=deque(maxlen=self.buffer_size),
            )

    def add_response_time(self, endpoint_name: str, response_time_ms: float) -> None:
        """Add a response time for a specific endpoint.

        :param endpoint_name: Name of the endpoint.
        :param response_time_ms: Response time in milliseconds.
        """
        # Add to global buffer
        self.global_latency_buffer.append(response_time_ms)
        self.global_timestamp_buffer.append(time.time())

        # Add to endpoint-specific buffer
        if endpoint_name in self.endpoint_metrics:
            metrics = self.endpoint_metrics[endpoint_name]
            metrics.latency_buffer.append(response_time_ms)
            metrics.timestamp_buffer.append(time.time())

    def calculate_global_p99(self) -> float | None:
        """Calculate global P99 latency.

        :returns: Global P99 latency in milliseconds, or None if not enough samples.
        """
        if len(self.global_latency_buffer) < self.min_samples:
            return None
        return float(np.percentile(self.global_latency_buffer, 99))

    def calculate_global_rps(self, window_sec: int = 60) -> float:
        """Calculate global requests per second (RPS).

        :param window_sec: Time window in seconds to calculate RPS.
        :returns: Global requests per second in the specified window.
        """
        now = time.time()
        window_start = now - window_sec
        recent_count = sum(1 for ts in self.global_timestamp_buffer if ts >= window_start)
        return recent_count / window_sec if window_sec > 0 else 0.0

    def generate_weight_configurations(self, distribution_weights: dict[str, float]) -> None:
        """Generate weight configurations for exploration.

        :param distribution_weights: Dictionary mapping endpoints to their production weight values.
        """
        configs: list[WeightsConfig] = []

        if self.enable_individual_run:
            # Individual endpoint tests (100% traffic to each)
            logger.info("Individual endpoint tests enabled")
            for endpoint in distribution_weights:
                weights = {ep: 0.0 for ep in distribution_weights}
                weights[endpoint] = 100.0
                config = WeightsConfig(mode=Mode.INDIVIDUAL, name=endpoint, weights=weights)
                configs.append(config)

        if self.enable_production_run:
            # Production load test
            logger.info("Production endpoint tests enabled")
            config = WeightsConfig(mode=Mode.PRODUCTION, name="baseline", weights=distribution_weights)
            configs.append(config)

        if self.enable_exploration_run:
            # Variations around production weights
            logger.info("Exploration endpoint tests enabled")
            for endpoint in distribution_weights:
                # Test with 2x weight for this endpoint
                original_weight = distribution_weights[endpoint]
                weights = distribution_weights.copy()
                weights[endpoint] = original_weight * 2
                config = WeightsConfig(mode=Mode.EXPLORATION, name=f"2x_{endpoint}", weights=weights)
                configs.append(config)

        if self.enable_spike_run:
            # Spike mode - stress test with target RPS
            logger.info("Spike stress test enabled")
            config = WeightsConfig(
                mode=Mode.SPIKE,
                name="spike_test",
                weights=distribution_weights,
            )
            configs.append(config)

        # Check that there are no configs with the same name
        unique_names = set()
        for config in configs:
            if config.name in unique_names:
                raise ValueError(f"Duplicate weight configuration name found: {config.name}")
            unique_names.add(config.name)

        self.weight_configurations = configs
        logger.info(f"Generated {len(configs)} weight configurations")
        for config in configs:
            logger.info(f" - {config.mode}:{config.name} with weights {config.weights}")

    def test_weight_configuration(self) -> None:
        """Test a specific weight configuration."""
        if self.current_config_index is None:
            logger.info("No weight configuration selected, waiting...")
            return

        if self.current_config_index >= len(self.weight_configurations):
            # Done with all configurations
            logger.info("Completed all weight configuration tests")
            self.complete = True
            return

        config = self.weight_configurations[self.current_config_index]
        mode, name, weights = config.mode, config.name, config.weights

        global_p99 = self.calculate_global_p99()
        global_rps = self.calculate_global_rps()

        if global_p99 is None:
            logger.info(f"[{mode}:{name}] Not enough samples, waiting...")
            return

        # Calculate per-endpoint metrics
        endpoint_stats = {}
        for endpoint, metrics in self.endpoint_metrics.items():
            p99 = metrics.calculate_p99(20)  # Use fewer samples for per-endpoint
            rps = metrics.calculate_rps()
            if p99 is not None:
                endpoint_stats[endpoint] = EndpointStats(p99_ms=p99, rps=rps)

        logger.info(f"[{mode}:{name}] P99: {global_p99:.2f}ms, RPS: {global_rps:.4f}, Users: {self.current_users}")
        for endpoint, stats in endpoint_stats.items():
            logger.info(f"  - {endpoint}: P99={stats.p99_ms:.2f}ms, RPS={stats.rps:.4f}")

        if mode == Mode.SPIKE:
            elapsed = self.timer.get_elapsed_seconds()
            target_rps = self.spike_target_rps

            if elapsed < self.spike_duration:
                # Still running spike test
                logger.info(
                    f"[SPIKE] Target: {target_rps:.2f} RPS, Actual: {global_rps:.2f} RPS, "
                    f"Time: {elapsed}/{self.spike_duration}s"
                )
                return

            # Spike test complete
            logger.info(f"[SPIKE] Completed stress test at {global_rps:.2f} RPS (target: {target_rps:.2f})")
            report = Report(
                mode=mode,
                weights=weights.copy(),
                p99_ms=global_p99,
                rps=global_rps,
                endpoint_stats=endpoint_stats.copy(),
                elapsed_time=self.timer.get_elapsed_str(),
            )
            self.reports[name] = report
            self._move_to_next_run()

        elif mode == Mode.PRODUCTION and self.timer.get_elapsed_seconds() < self.production_run_duration:
            # If in production mode and not yet reached duration, continue adjusting
            self.standard_adjustment()
        elif (
            (mode == Mode.PRODUCTION and self.timer.get_elapsed_seconds() >= self.production_run_duration)
            or (global_p99 > self.target_p99_ms * (1 + self.tolerance))
            or (self.current_users >= self.max_users)
            or (mode == Mode.INDIVIDUAL and self.timer.get_elapsed_seconds() >= self.individual_run_max_duration)
        ):
            # If test duration, steady state, or user limit has been reached
            # Save results and proceed to the next configuration
            report = Report(
                mode=mode,
                weights=weights.copy(),
                p99_ms=global_p99,
                rps=global_rps,
                endpoint_stats=endpoint_stats.copy(),
                elapsed_time=self.timer.get_elapsed_str(),
            )
            self.reports[name] = report
            self._move_to_next_run()

        else:
            # Still within limits, increase users
            self.standard_adjustment()

    def _move_to_next_run(self) -> None:
        """Move to the next configuration run."""
        # Reset for next configuration
        if self.current_config_index is None:
            self.current_config_index = 0
        else:
            self.current_config_index += 1

        # Update weights for next configuration
        if self.current_config_index < len(self.weight_configurations):
            next_config = self.weight_configurations[self.current_config_index]
            next_weights = next_config.weights
            self.stop_users()

            if self.current_config_index > 0:
                # There may be in-flight requests that will affect the next test, so wait a bit and clear buffers before starting
                time_to_wait = 60
                logger.info(
                    f"Waiting {time_to_wait} seconds for in-flight requests to complete before starting next configuration..."
                )
                time.sleep(time_to_wait)

            self.update_endpoint_weights(next_weights)
            self.clear_buffers()

            if next_config.mode == Mode.SPIKE:
                self.current_users = self.spike_target_rps
                self.spawn_users(self.spike_target_rps, instant=True)
            else:
                self.current_users = self.min_users
                self.spawn_users(self.min_users, instant=False)

            self.timer.start()

    def standard_adjustment(self) -> None:
        """Adjust number of users based on P99 latency."""
        p99 = self.calculate_global_p99()

        if p99 is None:
            return

        lower_bound = self.target_p99_ms * (1 - self.tolerance)
        upper_bound = self.target_p99_ms * (1 + self.tolerance)

        if p99 > upper_bound:
            # Latency too high, reduce users
            # Use floor to round down, but ensure at least 1 user change
            calculated_users = self.current_users * self.decrease_rate
            new_users = int(calculated_users)
            if new_users == self.current_users and calculated_users < self.current_users:
                new_users = self.current_users - 1
            new_users = max(self.min_users, new_users)
            if new_users != self.current_users:
                logger.info(f"P99 too high ({p99:.2f}ms), reducing users from {self.current_users} to {new_users}")
                self.spawn_users(new_users)
                self.stable_periods = 0

        elif p99 < lower_bound or self.stable_periods >= self.stable_periods_required:
            # Latency low or stable enough, increase users
            # Use floor to round down, but ensure at least 1 user change
            calculated_users = self.current_users * self.increase_rate
            new_users = int(calculated_users)
            if new_users == self.current_users and calculated_users > self.current_users:
                new_users = self.current_users + 1
            new_users = min(self.max_users, new_users)

            if new_users != self.current_users:
                if self.stable_periods >= self.stable_periods_required:
                    logger.info(
                        f"P99 stable for {self.stable_periods} periods, "
                        f"increasing users from {self.current_users} to {new_users}"
                    )
                else:
                    logger.info(f"P99 low ({p99:.2f}ms), increasing users from {self.current_users} to {new_users}")
                self.spawn_users(new_users)
                self.stable_periods = 0
        else:
            # Within tolerance
            self.stable_periods += 1
            logger.info(f"P99 within tolerance ({p99:.2f}ms), stable for {self.stable_periods} periods")

    @staticmethod
    def update_endpoint_weights(weights: dict[str, float]) -> None:
        """Update the weights for endpoint selection.

        :param weights: Dictionary mapping endpoints to their weight values.
        """
        # This would need to communicate with the HttpUser class
        # For now, we'll store it and the HttpUser will check it
        global current_test_weights  # noqa: PLW0603
        current_test_weights = weights
        logger.info(f"Updated weights: {weights}")

    def clear_buffers(self) -> None:
        """Clear all metric buffers."""
        self.global_latency_buffer.clear()
        self.global_timestamp_buffer.clear()
        for metrics in self.endpoint_metrics.values():
            metrics.clear_buffers()

    def stop_users(self) -> None:
        """Stop all users."""
        self.runner.start(0, spawn_rate=10, wait=True)

    def spawn_users(self, user_count, instant: bool = False) -> None:
        """Spawn or stop users to reach target count.

        :param user_count: Target number of users to spawn.
        :param instant: If True, spawn all users instantly; otherwise, use gradual spawn rate.
        """
        if self.runner is None:
            return

        self.current_users = user_count
        spawn_rate = user_count if instant else max(1, user_count // 10)
        self.runner.start(user_count, spawn_rate=spawn_rate)

    def control_loop(self) -> None:
        """Control loop."""
        start = time.time()
        logger.info("Starting endpoint capacity exploration")

        self._move_to_next_run()
        while not self.complete:
            self.test_weight_configuration()
            time.sleep(self.check_interval)

        completion_time = time.time() - start
        logger.info(f"Load test completed in {completion_time:.2f} seconds")

        # Final report
        self.print_and_save_final_report()

        self.runner.quit()

    def print_and_save_final_report(self) -> None:
        """Print comprehensive test results and save to file."""
        report_buffer = io.StringIO()

        def write_line(line: str) -> None:
            """Write a line to both console and report buffer.

            :param line: The line to write.
            """
            print(line)
            report_buffer.write(line + "\n")

        def write_block(name: str, r: Report) -> None:
            """Write a report block for a configuration.

            :param name: The name of the configuration.
            :param r: The Report object containing test results.
            """
            write_line(f"Configuration: {r.mode}:{name}")
            write_line(f"  Weights: {r.weights}")
            write_line(f"  P99: {r.p99_ms:.2f}ms")
            write_line(f"  RPS: {r.rps:.4f}")
            write_line(f"  Elapsed time: {r.elapsed_time}")
            for endpoint, stats in r.endpoint_stats.items():
                write_line(f"    {endpoint}: P99={stats.p99_ms:.2f}ms, RPS={stats.rps:.4f}")
            write_line("")

        write_line("\n" + "=" * 80)
        write_line("ENDPOINT CAPACITY EXPLORATION RESULTS")
        write_line("=" * 80)

        # Configuration setup
        write_line("Configuration:")
        write_line(f"  Target P99: {self.target_p99_ms}ms")
        write_line(f"  Min users: {self.min_users}, Max users: {self.max_users}")
        write_line(
            f"  Increase rate: {self.increase_rate:.2f}, Decrease rate: {self.decrease_rate:.2f}, "
            f"tolerance: {self.tolerance:.2f}"
        )
        write_line(f"  Stable periods required: {self.stable_periods_required}")
        write_line(f"  Buffer size: {self.buffer_size}")
        write_line(f"  Check interval: {self.check_interval} seconds")

        if self.enable_spike_run:
            write_line(f"  Spike mode: Target RPS={self.spike_target_rps}, Duration={self.spike_duration}s")

        instance_info = None
        instance_info_dict = {}
        try:
            instance_info = InstanceInfoCollector.collect()
            instance_info_dict = asdict(instance_info)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Warning: Could not collect instance information: {e}")
        if instance_info:
            write_line("\nInstance information:")
            write_line(f"  Hostname: {instance_info.hostname}")
            write_line(f"  OS: {instance_info.os_name} {instance_info.os_version}")
            write_line(f"  CPU Physical cores: {instance_info.cpu_count_physical_cores}")
            write_line(f"  CPU Logical cores: {instance_info.cpu_count_logical_cores}")
            write_line(f"  CPU Model: {instance_info.cpu_model}")
            write_line(f"  Memory: {instance_info.memory_gb} GB")

        if self.enable_individual_run:
            # Individual endpoint capacities
            write_line("\nINDIVIDUAL ENDPOINT CAPACITIES:")
            write_line("-" * 40)
            reports = [(name, report) for name, report in self.reports.items() if report.mode == Mode.INDIVIDUAL]
            for name, report in reports:
                write_block(name, report)

        if self.enable_production_run:
            # Production baseline
            write_line("\nPRODUCTION CONFIGURATION RESULTS:")
            write_line("-" * 40)
            reports = [(name, report) for name, report in self.reports.items() if report.mode == Mode.PRODUCTION]
            for name, report in reports:
                write_block(name, report)

        if self.enable_exploration_run:
            # Exploration insights
            write_line("\nEXPLORATION INSIGHTS:")
            write_line("-" * 40)
            reports = [(name, report) for name, report in self.reports.items() if report.mode == Mode.EXPLORATION]
            for name, report in reports:
                write_block(name, report)

        if self.enable_spike_run:
            # Spike stress test results
            write_line("\nSPIKE TEST RESULTS:")
            write_line("-" * 40)
            reports = [(name, report) for name, report in self.reports.items() if report.mode == Mode.SPIKE]
            for name, report in reports:
                write_block(name, report)

        write_line("=" * 80)

        # Save text report
        with open(f"{self.output_file}.txt", "w") as f:
            f.write(report_buffer.getvalue())

        # Save raw JSON report
        with open(f"{self.output_file}.json", "w") as f:
            metrics_dict = {k: asdict(v) for k, v in self.reports.items()}
            report = {
                "metrics": metrics_dict,
                "instance_info": instance_info_dict,
            }  # type: ignore
            f.write(json.dumps(report, indent=4))

    def start(self, runner) -> None:
        """Start the controller.

        :param runner: The Locust runner instance to control.
        """
        self.runner = runner
        self.control_thread = threading.Thread(target=self.control_loop)  # type: ignore
        self.control_thread.daemon = True
        self.control_thread.start()


# Add custom command line arguments
@events.init_command_line_parser.add_listener
def init_parser(parser) -> None:
    """Add custom command line arguments for explorer settings.

    :param parser: The ArgumentParser instance to add arguments to.
    """
    parser.add_argument(
        "--output-file",
        type=str,
        default="report_loadtest_results",
        help="File to save loadtest results without extension (default: report_loadtest_results)",
    )
    parser.add_argument(
        "--target-p99-ms",
        type=int,
        default=1000,
        help="Target P99 latency in milliseconds (default: 1000)",
    )
    parser.add_argument(
        "--min-users",
        type=int,
        default=1,
        help="Minimum number of users (default: 1)",
    )
    parser.add_argument(
        "--max-users",
        type=int,
        default=32,
        help="Maximum number of users (default: 32)",
    )
    parser.add_argument(
        "--increase-rate",
        type=float,
        default=1.2,
        help="Rate to increase users when P99 is below target (default: 1.2)",
    )
    parser.add_argument(
        "--decrease-rate",
        type=float,
        default=0.8,
        help="Rate to decrease users when P99 is above target (default: 0.8)",
    )
    parser.add_argument(
        "--check-interval",
        type=int,
        default=30,
        help="Interval in seconds between checks (default: 30)",
    )
    parser.add_argument(
        "--tolerance",
        type=float,
        default=0.1,
        help="Tolerance for P99 target (default: 0.1 = 10%)",
    )
    parser.add_argument(
        "--stable-periods-required",
        type=int,
        default=3,
        help="Stable periods required before increasing users (default: 3)",
    )
    parser.add_argument(
        "--buffer-size",
        type=int,
        default=2000,
        help="Size of the latency buffer for P99 calculation (default: 2000)",
    )
    parser.add_argument(
        "--min-samples",
        type=int,
        default=100,
        help="Minimum samples required for P99 calculation (default: 100)",
    )
    parser.add_argument(
        "--production-run-duration",
        type=int,
        default=1200,  # 20 minutes
        help="Duration in seconds for production run (default: 1200 = 20 minutes)",
    )
    parser.add_argument(
        "--individual-run-max-duration",
        type=int,
        default=600,  # 10 minutes
        help="Maximum duration in seconds for individual endpoint runs (default: 600 = 10 minutes)",
    )
    parser.add_argument(
        "--test-mode",
        nargs="+",
        choices=["INDIVIDUAL", "PRODUCTION", "EXPLORATION", "SPIKE"],
        default=["INDIVIDUAL", "PRODUCTION"],
        help="Test modes to run. Space-separated for multiple (default: INDIVIDUAL PRODUCTION)",
    )
    parser.add_argument(
        "--spike-target-rps",
        type=float,
        default=100.0,
        help="Target requests per second for spike mode (default: 100.0)",
    )
    parser.add_argument(
        "--spike-duration",
        type=int,
        default=30,
        help="Duration in seconds for spike mode (default: 30)",
    )
    parser.add_argument(
        "--weights-module",
        type=str,
        default=None,
        required=True,
        help="Python module path containing production_weights",
    )


@events.request.add_listener
def on_request(request_type, name, response_time, response_length, exception, **kwargs) -> None:
    """Capture response times for P99 calculation.

    :param request_type: The type of request (e.g., 'GET', 'POST').
    :param name: The name of the request endpoint.
    :param response_time: The response time in milliseconds.
    :param response_length: The length of the response in bytes.
    :param exception: Any exception that occurred during the request.
    :param kwargs: Additional keyword arguments passed by the event.
    """
    if exception is None:
        explorer.add_response_time(name, response_time)


@events.test_start.add_listener
def on_test_start(environment, **kwargs) -> None:
    """Start the explorer when test starts.

    :param environment: The Locust environment object.
    :param kwargs: Additional keyword arguments passed by the event.
    """
    if isinstance(environment.runner, LocalRunner | MasterRunner):
        explorer.start(environment.runner)


# Global weight configuration that can be updated dynamically
current_test_weights: dict[str, float] = {}

# Global explorer instance to be initialized later
explorer = None

# Global production weights to be loaded from --weights-module
production_weights: dict = {}


@events.init.add_listener
def on_locust_init(environment, **kwargs) -> None:
    """Initialize the explorer with command line arguments.

    :param environment: The Locust environment object.
    :param kwargs: Additional keyword arguments passed by the event.
    """
    global explorer, production_weights  # noqa: PLW0603

    # Get parsed arguments from environment
    args = environment.parsed_options

    # Load production weights from module
    if hasattr(args, "weights_module") and args.weights_module:
        import importlib

        weights_module = importlib.import_module(args.weights_module)
        production_weights = weights_module.production_weights
        logger.info(f"Loaded production_weights from {args.weights_module}")
    else:
        raise ValueError(
            "No weights module specified. Use --weights-module to specify a Python module "
            "containing production_weights.\n"
        )

    weights_to_use = production_weights

    # Parse test modes (argparse already validated choices)
    modes = args.test_mode
    enable_individual_run = "INDIVIDUAL" in modes
    enable_production_run = "PRODUCTION" in modes
    enable_exploration_run = "EXPLORATION" in modes
    enable_spike_run = "SPIKE" in modes

    # Create explorer settings from command line arguments
    explorer_settings = {
        "output_file": args.output_file,
        "target_p99_ms": args.target_p99_ms,
        "min_users": args.min_users,
        "max_users": args.max_users,
        "spike_target_rps": args.spike_target_rps,
        "spike_duration": args.spike_duration,
        "increase_rate": args.increase_rate,
        "decrease_rate": args.decrease_rate,
        "check_interval": args.check_interval,
        "tolerance": args.tolerance,
        "stable_periods_required": args.stable_periods_required,
        "buffer_size": args.buffer_size,
        "min_samples": args.min_samples,
        "production_run_duration": args.production_run_duration,
        "individual_run_max_duration": args.individual_run_max_duration,
        "enable_individual_run": enable_individual_run,
        "enable_production_run": enable_production_run,
        "enable_exploration_run": enable_exploration_run,
        "enable_spike_run": enable_spike_run,
    }

    # Initialize explorer with command line settings
    explorer = EndpointCapacityExplorer(**explorer_settings)

    # Initialize with endpoint names
    distribution_weights = {ts.endpoint: weight for ts, weight in weights_to_use.items()}
    explorer.initialize_endpoints(list(distribution_weights.keys()))
    explorer.generate_weight_configurations(distribution_weights)


class LoadTestHttpUser(HttpUser):
    """Custom HttpUser for load testing with dynamic task sets."""

    def __init__(self, *args, **kwargs) -> None:
        """Initialize the LoadTestHttpUser with task sets.

        :param args: Positional arguments passed to the parent HttpUser.
        :param kwargs: Keyword arguments passed to the parent HttpUser.
        """
        super().__init__(*args, **kwargs)
        self.task_sets: dict[str, TaskSet] = {}

    def on_start(self) -> None:
        """Initialize all task sets."""
        global current_test_weights  # noqa: PLW0602

        # Get task set classes from current weights configuration
        for endpoint_name in current_test_weights:
            for task_set_class in production_weights:
                task_set_inst = task_set_class(parent=self)
                if task_set_inst.endpoint == endpoint_name:
                    task_set_inst.on_start()
                    self.task_sets[task_set_inst.endpoint] = task_set_inst
                    break

    @task
    def test_load_test(self) -> None:
        """Execute a test based on current weight configuration."""
        global current_test_weights  # noqa: PLW0602

        if not current_test_weights:
            return

        # Select task set based on weights
        task_names = list(current_test_weights.keys())
        task_weights = list(current_test_weights.values())

        # Filter out zero-weight tasks
        active_tasks = [(name, weight) for name, weight in zip(task_names, task_weights, strict=True) if weight > 0]

        if not active_tasks:
            return

        task_names, task_weights = zip(*active_tasks, strict=True)  # type: ignore
        selected_name = random.choices(task_names, weights=task_weights, k=1)[0]  # noqa: S311

        # Execute the selected task
        task_set = self.task_sets.get(selected_name)
        if task_set and hasattr(task_set, "test_endpoint"):
            task_set.test_endpoint()
        else:
            raise NotImplementedError(f"Test method not implemented for {selected_name}")
