"""Example TaskSet implementations for ml-loadtest demonstration and testing."""

from ml_loadtest.examples.demo_tasks import (
    EchoTaskSet,
    HealthCheckTaskSet,
    ImageProcessingTaskSet,
    PredictionTaskSet,
    StatusTaskSet,
)

__all__ = [
    "EchoTaskSet",
    "HealthCheckTaskSet",
    "ImageProcessingTaskSet",
    "PredictionTaskSet",
    "StatusTaskSet",
]
