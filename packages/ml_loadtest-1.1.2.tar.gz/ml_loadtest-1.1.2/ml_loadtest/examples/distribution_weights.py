"""Example production weight configurations for load testing.

This module provides a sample `production_weights` dictionary that maps
TaskSet classes to their relative weights in the load test.

Weight interpretation:
- Higher weight = more requests to that endpoint
- Weights are relative (e.g., 50:25:15:5:5 means 50% to first, 25% to second, etc.)
- Total distribution is normalized by Locust automatically

Usage:
    locust -f $(ml-loadtest-file) --host http://api:8000

Or with custom weights module:
    locust -f $(ml-loadtest-file) --host http://api:8000 --weights-module my_module.weights
"""

from ml_loadtest.examples.demo_tasks import (
    EchoTaskSet,
    HealthCheckTaskSet,
    ImageProcessingTaskSet,
    PredictionTaskSet,
    StatusTaskSet,
)

production_weights = {
    HealthCheckTaskSet: 50,
    StatusTaskSet: 25,
    EchoTaskSet: 15,
    PredictionTaskSet: 5,
    ImageProcessingTaskSet: 5,
}
