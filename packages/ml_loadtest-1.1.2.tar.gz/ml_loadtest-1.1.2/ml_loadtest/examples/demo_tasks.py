"""Example TaskSet implementations demonstrating the ml-loadtest interface.

Each TaskSet must:
1. Inherit from locust.TaskSet
2. Have an `endpoint` attribute (str) identifying the endpoint
3. Implement `test_endpoint()` method that performs the actual HTTP request

These examples can be used directly for testing the tool or as templates for custom TaskSets.
"""

import json
import random

from locust import TaskSet


class HealthCheckTaskSet(TaskSet):
    """Example: Simple health check endpoint.

    Demonstrates minimal TaskSet implementation for a GET request.
    """

    endpoint = "/health"

    def test_endpoint(self) -> None:
        """Test health check endpoint."""
        with self.client.get(
            self.endpoint,
            name=self.endpoint,
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Health check failed with status {response.status_code}")


class StatusTaskSet(TaskSet):
    """Example: Status endpoint with query parameters.

    Demonstrates TaskSet with query parameters.
    """

    endpoint = "/status"

    def test_endpoint(self) -> None:
        """Test status endpoint with optional query params."""
        params = {"verbose": random.choice(["true", "false"])}

        with self.client.get(
            self.endpoint,
            params=params,
            name=self.endpoint,
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Status check failed with status {response.status_code}")


class EchoTaskSet(TaskSet):
    """Example: Echo endpoint with POST request.

    Demonstrates TaskSet with JSON payload and POST method.
    """

    endpoint = "/echo"

    def test_endpoint(self) -> None:
        """Test echo endpoint by sending and validating JSON payload."""
        payload = {
            "message": f"test-{random.randint(1000, 9999)}",
            "timestamp": "2025-01-01T00:00:00Z",
        }

        with self.client.post(
            self.endpoint,
            json=payload,
            name=self.endpoint,
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if response_data.get("message") == payload["message"]:
                        response.success()
                    else:
                        response.failure("Echo response did not match request")
                except json.JSONDecodeError:
                    response.failure("Invalid JSON response")
            else:
                response.failure(f"Echo failed with status {response.status_code}")


class PredictionTaskSet(TaskSet):
    """Example: ML prediction endpoint simulation.

    Demonstrates TaskSet for ML inference API with various input sizes.
    """

    endpoint = "/predict"

    def test_endpoint(self) -> None:
        """Test prediction endpoint with random input data."""
        input_size = random.choice([10, 50, 100, 500])
        payload = {
            "model": "example-model-v1",
            "inputs": [random.random() for _ in range(input_size)],
            "options": {"temperature": 0.7},
        }

        with self.client.post(
            self.endpoint,
            json=payload,
            name=self.endpoint,
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                try:
                    result = response.json()
                    if "prediction" in result or "predictions" in result:
                        response.success()
                    else:
                        response.failure("Missing prediction in response")
                except json.JSONDecodeError:
                    response.failure("Invalid JSON response")
            elif response.status_code == 422:
                response.failure("Invalid input data")
            else:
                response.failure(f"Prediction failed with status {response.status_code}")


class ImageProcessingTaskSet(TaskSet):
    """Example: Image processing endpoint simulation.

    Demonstrates TaskSet for binary data upload (simulated).
    """

    endpoint = "/process-image"

    def test_endpoint(self) -> None:
        """Test image processing endpoint with simulated binary data."""
        image_sizes = [
            ("small", 1024 * 50),
            ("medium", 1024 * 200),
            ("large", 1024 * 500),
        ]
        size_name, size_bytes = random.choice(image_sizes)

        fake_image_data = b"x" * size_bytes

        files = {"image": ("test.jpg", fake_image_data, "image/jpeg")}
        data = {
            "operation": random.choice(["resize", "crop", "filter"]),
            "quality": random.randint(70, 100),
        }

        with self.client.post(
            self.endpoint,
            files=files,
            data=data,
            name=f"{self.endpoint}-{size_name}",
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                try:
                    result = response.json()
                    if "processed" in result or "url" in result:
                        response.success()
                    else:
                        response.failure("Missing processed result")
                except json.JSONDecodeError:
                    response.failure("Invalid JSON response")
            elif response.status_code == 413:
                response.failure("Image too large")
            else:
                response.failure(f"Image processing failed with status {response.status_code}")
