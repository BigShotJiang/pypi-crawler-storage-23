# {{project_name}} State

## Current Context

* **Active Phase:** Not started
* **Current Task:** None

## Completed Tasks
