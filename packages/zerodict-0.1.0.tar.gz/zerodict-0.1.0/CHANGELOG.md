# Changelog

## 0.1.0 (2026-03-01)


### Features

* initial release ([68c3596](https://github.com/francescofavi/zerodict/commit/68c3596389a5fdc0392def551d6bd00bbea7bc65))
