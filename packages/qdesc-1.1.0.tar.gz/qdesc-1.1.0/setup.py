from setuptools import setup, find_packages 
from pathlib import Path 

# Read the contents of the README file 
this_directory = Path(__file__).parent 
long_description = (this_directory / "README.md").read_text()

setup(
    name='qdesc',
    version='1.1.0',
    packages=find_packages(),
    install_requires=[
        'pandas>=3.0.0',
        'numpy>=2.4.2',
        'scipy>=1.17',
        'seaborn>=0.13.2',
        'matplotlib>=3.10.8',
        'statsmodels>=0.14.6',
        'adjusttext>=1.3.0'
    ],
    author='Paolo Hilado',
    author_email='datasciencepgh@proton.me',
    description= 'Quick and Easy way to do descriptive analysis.',
    url= "https://github.com/Dcroix/qdesc",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    long_description=long_description, 
    long_description_content_type='text/markdown',
)
