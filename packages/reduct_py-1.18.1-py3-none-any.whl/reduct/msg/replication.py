"""Message types for the Replication API"""

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class ReplicationMode(str, Enum):
    """Replication mode"""

    ENABLED = "enabled"
    PAUSED = "paused"
    DISABLED = "disabled"


class ReplicationInfo(BaseModel):
    """Replication information"""

    name: str
    """name of the replication"""
    is_provisioned: bool
    """replication is provisioned and can't be deleted or changed"""
    is_active: bool
    """replication is active and the remote server is reachable"""
    mode: ReplicationMode = ReplicationMode.ENABLED
    """current replication mode"""
    pending_records: int
    """number of records to replicate"""


class ReplicationList(BaseModel):
    """List of replications"""

    replications: List[ReplicationInfo]
    """list of replications"""


class ReplicationDiagnosticsError(BaseModel):
    """Error information for replication"""

    count: int
    """number of times this error occurred"""
    last_message: str
    """last error message for this error"""


class ReplicationDiagnosticsDetail(BaseModel):
    """Diagnostics information for replication"""

    ok: int
    """number of successful replications"""
    errored: int
    """number of failed replications"""
    errors: Dict[int, ReplicationDiagnosticsError]
    """list of errors grouped by status code"""


class ReplicationDiagnostics(BaseModel):
    """Detailed diagnostics for replication"""

    hourly: ReplicationDiagnosticsDetail
    """hourly diagnostics"""


class ReplicationSettings(BaseModel):
    """Settings for creating a replication"""

    src_bucket: str
    """source bucket name"""
    dst_bucket: str
    """destination bucket name"""
    dst_host: str
    """url of the destination instance"""
    dst_token: Optional[str] = None
    """access token for the destination instance"""
    entries: List[str] = Field([])
    """list of entries to replicate. If empty, all entries are replicated.
    Wildcards are supported"""
    when: Optional[Dict] = None
    """replication schedule in cron format"""
    mode: ReplicationMode = ReplicationMode.ENABLED
    """replication mode"""


class ReplicationDetailInfo(BaseModel):
    """Complete information about a replication"""

    diagnostics: ReplicationDiagnostics
    """diagnostics information"""
    info: ReplicationInfo
    """replication information"""
    settings: ReplicationSettings
    """replication settings"""
