Authors
=======

members of the Billinge Group and PDF beamline at NSLS-II

Contributors
------------

For a list of contributors, visit
https://github.com/pdf-bl/pdfbl.sequential/graphs/contributors
