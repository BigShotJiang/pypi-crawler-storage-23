"""Installation and Utility Utilities for WebTools CLI"""
import os
import sys
import json
import random
import binascii
import requests
import subprocess
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Util import Counter
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# --- PLAYWRIGHT SETUP ---

def install_playwright_browsers():
    """Install Playwright Chromium browser after package installation"""
    try:
        print("📦 Installing Playwright Chromium browser...")
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
        print("✓ Playwright Chromium installed successfully")
    except subprocess.CalledProcessError:
        print("⚠️ Failed to install Playwright browsers. Run manually: playwright install chromium")
    except Exception as e:
        print(f"⚠️ Playwright browser installation skipped: {e}")

# --- INTERNAL MEGA CLIENT (Conflict-free & Python 3.11+ compatible) ---

class RequestError(Exception):
    """Exception for Mega API requests"""
    pass

def base64_url_decode(data):
    data += '=' * (4 - len(data) % 4)
    return binascii.a2b_base64(data.replace('-', '+').replace('_', '/'))

def base64_url_encode(data):
    return binascii.b2a_base64(data).decode('utf-8').strip().replace('+', '-').replace('/', '_').replace('=', '')

def a32_to_str(a):
    return binascii.unhexlify(''.join(format(i, '08x') for i in a))

def str_to_a32(s):
    if len(s) % 4:
        s += b'\0' * (4 - len(s) % 4)
    return [int(binascii.hexlify(s[i:i + 4]), 16) for i in range(0, len(s), 4)]

def base64_to_a32(s):
    return str_to_a32(base64_url_decode(s))

def a32_to_base64(a):
    return base64_url_encode(a32_to_str(a))

def aes_cbc_encrypt(data, key):
    cipher = AES.new(a32_to_str(key), AES.MODE_CBC, b'\0' * 16)
    return str_to_a32(cipher.encrypt(a32_to_str(data)))

def aes_cbc_decrypt(data, key):
    cipher = AES.new(a32_to_str(key), AES.MODE_CBC, b'\0' * 16)
    return str_to_a32(cipher.decrypt(a32_to_str(data)))

def decrypt_key(a, k):
    res = []
    for i in range(0, len(a), 4):
        res += aes_cbc_decrypt(a[i:i + 4], k)
    return res

def encrypt_key(a, k):
    res = []
    for i in range(0, len(a), 4):
        res += aes_cbc_encrypt(a[i:i + 4], k)
    return res

def prepare_key(a):
    v = [0x93C467E3, 0x7DB0C7A4, 0xD1BE3F81, 0x0152CB56]
    for _ in range(0x10000):
        for j in range(0, len(a), 4):
            key = [0, 0, 0, 0]
            for k in range(4):
                if j + k < len(a):
                    key[k] = a[j + k]
            v = aes_cbc_encrypt(v, key)
    return v

def mpi_to_int(s):
    return int(binascii.hexlify(s[2:]), 16)

class Mega:
    def __init__(self):
        self.sid = None
        self.api_url = "https://g.api.mega.co.nz/cs"
        self.sequence_num = random.randint(0, 0xFFFFFFFF)

    def login(self, email, password):
        password_aes = prepare_key(str_to_a32(password.encode('utf-8')))
        user_hash = self._stringhash(email, password_aes)
        resp = self._api_request({'a': 'us', 'user': email, 'uh': user_hash})
        
        if isinstance(resp, int) and resp < 0:
            raise RequestError(f"Login failed: {resp}")

        encrypted_key = base64_to_a32(resp['k'])
        self.master_key = decrypt_key(encrypted_key, password_aes)
        
        if 'tsid' in resp:
            self.sid = resp['tsid']
        elif 'csid' in resp:
            encrypted_rsa_private_key = base64_to_a32(resp['privk'])
            rsa_private_key = decrypt_key(encrypted_rsa_private_key, self.master_key)
            private_key_str = a32_to_str(rsa_private_key)
            components = [0, 0, 0, 0]
            for i in range(4):
                l = int(((private_key_str[0]) * 256 + (private_key_str[1]) + 7) / 8) + 2
                components[i] = mpi_to_int(private_key_str[:l])
                private_key_str = private_key_str[l:]
            encrypted_sid = mpi_to_int(base64_url_decode(resp['csid']))
            p, q, d, _ = components
            n, phi = p * q, (p - 1) * (q - 1)
            try: e = pow(d, -1, phi)
            except: e = 65537
            rsa_decrypter = RSA.construct((n, e, d, p, q))
            sid_int = rsa_decrypter._decrypt(encrypted_sid)
            sid_hex = '%x' % sid_int
            if len(sid_hex) % 2: sid_hex = '0' + sid_hex
            self.sid = base64_url_encode(binascii.unhexlify(sid_hex)[:43])
        return self

    def _stringhash(self, email, aes_key):
        s = email.encode('utf-8')
        h = [0, 0, 0, 0]
        for i, b in enumerate(s): h[i % 4] ^= b
        for _ in range(0x4000): h = aes_cbc_encrypt(h, aes_key)
        return a32_to_base64([h[0], h[2]])

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10), 
           retry=retry_if_exception_type(requests.exceptions.RequestException))
    def _api_request(self, data):
        url = f"{self.api_url}?id={self.sequence_num}"
        if self.sid: url += f"&sid={self.sid}"
        self.sequence_num += 1
        response = requests.post(url, json=[data], timeout=30)
        response.raise_for_status()
        result = response.json()
        if isinstance(result, list):
            res = result[0]
            if isinstance(res, int) and res < 0: raise RequestError(f"API Error {res}")
            return res
        return result

    def get_storage_space(self):
        resp = self._api_request({'a': 'uq', 'strg': 1})
        return {'total': resp['mstrg'], 'used': resp['cstrg']}

    def upload(self, filename, dest_folder=None):
        size = os.path.getsize(filename)
        resp = self._api_request({'a': 'u', 's': size})
        upload_url = resp['p']
        with open(filename, 'rb') as f: data = f.read()
        r = requests.post(upload_url, data=data, timeout=60)
        upload_token = r.text
        file_key = [random.randint(0, 0xFFFFFFFF) for _ in range(6)]
        attribs = {'n': os.path.basename(filename)}
        encoded_attribs = base64_url_encode(b'MEGA' + json.dumps(attribs).encode('utf-8'))
        data = {'a': 'p', 't': dest_folder or 'ROOT', 'n': [{'h': upload_token, 't': 0, 'a': encoded_attribs, 'k': a32_to_base64(file_key[:4])}]}
        return self._api_request(data)

if __name__ == "__main__":
    install_playwright_browsers()
