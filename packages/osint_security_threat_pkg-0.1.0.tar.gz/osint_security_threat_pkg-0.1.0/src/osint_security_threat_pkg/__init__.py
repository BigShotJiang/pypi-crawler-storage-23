from .otx_scanner import OtxScanner
from .global_firepower import GlobalFirePowerScraper

__all__ = [
    "OtxScanner",
    "GlobalFirePowerScraper"
]