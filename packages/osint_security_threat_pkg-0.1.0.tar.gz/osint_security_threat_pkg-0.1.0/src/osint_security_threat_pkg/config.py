import os
import logging

class Settings:
    def __init__(self):
        # Tries to get the key from the environment, defaults to None
        self.ALIENTVAULT_OTX_API_KEY = os.getenv("ALIENTVAULT_OTX_API_KEY", None)

settings = Settings()