"""
Sangreal Calendar - Advanced Trading Date Management System.

This package provides comprehensive functionality for managing trading calendars,
calculating periodic dates, and handling futures-related trading date operations.

Key Features:
- Trade date manipulation and adjustment
- Periodic frequency calculations (daily, weekly, monthly, quarterly, etc.)
- Futures delivery date calculations
- Contract switching logic
- Type-safe operations with comprehensive error handling
- Backward compatibility with existing code

Main Components:
- Enhanced core modules with type hints and better error handling
- Configuration management for better maintainability
- Improved documentation and examples

Basic Usage:
    >>> from kepler.pulse import CALENDAR
    >>> CALENDAR.inject(['20240101', '20240102', '20240103'])  # Inject trade dates
    >>> dates = CALENDAR.get_trade_dts('20240101', '20240131')  # Get trade dates
    >>> adjusted = CALENDAR.adjust_trade_dt('20240101', 'next')  # Adjust to next trade date

    # Frequency calculations
    >>> from kepler.pulse.core.refresh_rate_handle import Monthly, Weekly
    >>> monthly = Monthly(1)
    >>> month_ends = monthly.get('20240101', '20241231')

    # Futures operations
    >>> from kepler.pulse.core.trade_dt_futures import get_delistdate
    >>> delivery_dates = get_delistdate('20240115')
"""

# Import all core modules for backward compatibility
from .core.trade_dt_handle import *
from .core.trade_dt_futures import *
from .core.refresh_rate_handle import *

# Import utilities
from .utils import dt_handle, set

# Import enhanced configuration
from .config import config, CalendarConfig

# Version information
__version__ = '1.0.0'
__author__ = 'liubola'
__email__ = 'lby3523@gmail.com'
__license__ = 'GNU General Public License v3.0'

# Export all public components
__all__ = [
    # Core calendar from trade_dt_handle
    'CALENDAR', 'get_trade_dts', 'adjust_trade_dt', 'step_trade_dt', 'delta_trade_dt',

    # Frequency classes from refresh_rate_handle
    'RefreshBase', 'Daily', 'Weekly', 'BiWeekly', 'Monthly', 'Quarterly',
    'Reportly', 'Halfyearly', 'Yearly',

    # Futures functions from trade_dt_futures
    'get_delistdate_all', 'get_delistdate_tf_all', 'get_delistdate', 'get_contract',

    # Utilities
    'dt_handle', 'set',

    # Configuration
    'config', 'CalendarConfig',

    # Meta
    '__version__', '__author__', '__email__', '__license__',

    # Enhanced types from core modules
    'CalendarBase', 'CalendarError',  # From enhanced trade_dt_handle
]
