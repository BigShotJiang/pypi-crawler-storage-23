# scalpel/render/css/panels_palette.py
from __future__ import annotations

from .part04_panels_palette import CSS_PART as CSS_PART
