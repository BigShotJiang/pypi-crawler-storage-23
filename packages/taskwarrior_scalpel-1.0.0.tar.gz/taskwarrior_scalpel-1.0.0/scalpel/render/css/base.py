# scalpel/render/css/base.py
from __future__ import annotations

from .part02_base import CSS_PART as CSS_PART
