# scalpel/render/css/modals_misc.py
from __future__ import annotations

from .part07_modals_misc import CSS_PART as CSS_PART
