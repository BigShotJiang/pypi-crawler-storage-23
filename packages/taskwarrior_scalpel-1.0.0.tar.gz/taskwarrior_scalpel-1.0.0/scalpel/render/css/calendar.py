# scalpel/render/css/calendar.py
from __future__ import annotations

from .part05_calendar import CSS_PART as CSS_PART
