# scalpel/render/css/tokens_theme.py
from __future__ import annotations

from .part01_tokens_theme import CSS_PART as CSS_PART
