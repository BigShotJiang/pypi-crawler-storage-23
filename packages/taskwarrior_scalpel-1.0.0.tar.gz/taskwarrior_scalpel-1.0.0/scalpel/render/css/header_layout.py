# scalpel/render/css/header_layout.py
from __future__ import annotations

from .part03_header_layout import CSS_PART as CSS_PART
