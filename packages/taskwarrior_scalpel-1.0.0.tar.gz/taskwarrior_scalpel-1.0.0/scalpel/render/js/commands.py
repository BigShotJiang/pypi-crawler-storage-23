# scalpel/render/js/commands.py
from __future__ import annotations

from .part05_commands import JS_PART as JS_PART
