# scalpel/render/js/init.py
from __future__ import annotations

from .part07_init import JS_PART as JS_PART
