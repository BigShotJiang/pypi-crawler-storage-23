# scalpel/render/js/drag_resize.py
from __future__ import annotations

from .part06_drag_resize import JS_PART as JS_PART
