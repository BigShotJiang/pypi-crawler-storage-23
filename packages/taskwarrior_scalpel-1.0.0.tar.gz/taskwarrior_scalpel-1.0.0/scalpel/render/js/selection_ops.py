# scalpel/render/js/selection_ops.py
from __future__ import annotations

from .part03_selection_ops import JS_PART as JS_PART
