# scalpel/render/js/palette_goals.py
from __future__ import annotations

from .part02_palette_goals import JS_PART as JS_PART
