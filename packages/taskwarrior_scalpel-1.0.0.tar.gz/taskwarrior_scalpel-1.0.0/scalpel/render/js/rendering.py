# scalpel/render/js/rendering.py
from __future__ import annotations

from .part04_rendering import JS_PART as JS_PART
