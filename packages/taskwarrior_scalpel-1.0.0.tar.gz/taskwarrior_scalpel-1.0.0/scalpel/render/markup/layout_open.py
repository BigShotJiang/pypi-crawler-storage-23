# scalpel/render/markup/layout_open.py
from __future__ import annotations

MARKUP = r"""

<div class="layout" id="layout">
  """
