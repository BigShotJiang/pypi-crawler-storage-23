tsrkit-rs
====

Erasure coding using [reed-solomon-simd](https://crates.io/crates/reed-solomon-simd), matching the JAM graypaper for python.
