# coding: utf-8
from ntfsdump.core import ntfsdump

__all__ = ["ntfsdump"]