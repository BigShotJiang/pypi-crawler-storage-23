from __future__ import annotations

import json
from importlib import metadata as importlib_metadata
from pathlib import Path

import pytest

from icsd import __version__
from icsd.cli.main import (
    CLI_PROG_NAME,
    EXIT_FINDINGS,
    EXIT_OK,
    EXIT_TOOL_ERROR,
    LINT_BASELINE_PROFILE,
    LINT_POLICY_PROFILE,
    build_parser,
    main,
)
from icsd.core.evidence import EvidenceBundle


def test_main_without_command_returns_tool_error() -> None:
    assert main([]) == EXIT_TOOL_ERROR


def test_build_parser_exposes_expected_v1_commands_and_lint_defaults() -> None:
    parser = build_parser()

    verify_args = parser.parse_args(["verify", "artifact.json"])
    lint_args = parser.parse_args(["lint", "."])
    lint_policy_args = parser.parse_args(
        ["lint", ".", "--profile", LINT_POLICY_PROFILE, "--format", "json"]
    )

    assert parser.prog == CLI_PROG_NAME
    assert verify_args.command == "verify"
    assert verify_args.evidence_json == "artifact.json"
    assert lint_args.command == "lint"
    assert lint_args.profile == LINT_BASELINE_PROFILE
    assert lint_args.output_format == "text"
    assert lint_policy_args.profile == LINT_POLICY_PROFILE
    assert lint_policy_args.output_format == "json"


def test_main_unknown_command_returns_argparse_error_exit_code() -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["unknown"])

    assert exc_info.value.code == EXIT_TOOL_ERROR


def test_main_verify_valid_bundle_returns_ok(tmp_path: Path) -> None:
    bundle = EvidenceBundle.from_states(
        transition_id="89f93f18-5de2-4177-9149-7a8f7ecb4f71",
        entity_type="order",
        entity_id="ord-100",
        actor="cli-test",
        authority="pytest",
        before_state={"status": "draft"},
        after_state={"status": "approved"},
        timestamp="2026-03-03T00:00:00Z",
    )
    evidence_path = tmp_path / "evidence.json"
    evidence_path.write_text(json.dumps(bundle.as_dict()), encoding="utf-8")

    assert main(["verify", str(evidence_path)]) == EXIT_OK


def test_main_verify_invalid_bundle_returns_tool_error(
    tmp_path: Path,
) -> None:
    evidence_path = tmp_path / "evidence.json"
    evidence_path.write_text(
        json.dumps({"schema_version": "0.1", "transition_id": "not-a-uuid"}),
        encoding="utf-8",
    )

    assert main(["verify", str(evidence_path)]) == EXIT_TOOL_ERROR


def test_main_verify_missing_file_returns_tool_error(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing.json"

    assert main(["verify", str(missing_path)]) == EXIT_TOOL_ERROR


def test_main_verify_non_object_payload_returns_tool_error(tmp_path: Path) -> None:
    evidence_path = tmp_path / "evidence.json"
    evidence_path.write_text('["not-an-object"]', encoding="utf-8")

    assert main(["verify", str(evidence_path)]) == EXIT_TOOL_ERROR


def test_main_lint_clean_tree_returns_ok(tmp_path: Path) -> None:
    (tmp_path / "ok.py").write_text("def hello() -> str:\n    return 'ok'\n", encoding="utf-8")
    (tmp_path / "ok.json").write_text('{"hello": "world"}\n', encoding="utf-8")

    assert main(["lint", str(tmp_path)]) == EXIT_OK


def test_main_lint_python_syntax_error_returns_findings(
    tmp_path: Path,
) -> None:
    (tmp_path / "broken.py").write_text("def broken(:\n    return 1\n", encoding="utf-8")

    assert main(["lint", str(tmp_path)]) == EXIT_FINDINGS


def test_main_lint_invalid_json_returns_findings(tmp_path: Path) -> None:
    (tmp_path / "broken.json").write_text("{broken}\n", encoding="utf-8")

    assert main(["lint", str(tmp_path)]) == EXIT_FINDINGS


def test_main_lint_missing_path_returns_tool_error(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing"

    assert main(["lint", str(missing_path)]) == EXIT_TOOL_ERROR


def test_main_lint_json_output_reports_clean_tree(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / "ok.py").write_text("def hello() -> str:\n    return 'ok'\n", encoding="utf-8")

    exit_code = main(["lint", str(tmp_path), "--format", "json"])
    report = json.loads(capsys.readouterr().out)

    assert exit_code == EXIT_OK
    assert report["status"] == "ok"
    assert report["profile"] == "baseline"
    assert report["finding_count"] == 0
    assert report["findings"] == []


def test_main_lint_json_output_reports_findings(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / "broken.json").write_text("{broken}\n", encoding="utf-8")

    exit_code = main(["lint", str(tmp_path), "--format", "json"])
    report = json.loads(capsys.readouterr().out)

    assert exit_code == EXIT_FINDINGS
    assert report["status"] == "findings"
    assert report["finding_count"] == 1
    assert report["findings"][0]["rule"] == "json-syntax"


def test_main_lint_json_output_reports_tool_error(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    missing_path = tmp_path / "missing"

    exit_code = main(["lint", str(missing_path), "--format", "json"])
    report = json.loads(capsys.readouterr().out)

    assert exit_code == EXIT_TOOL_ERROR
    assert report["status"] == "error"
    assert report["error"] == f"path does not exist: {missing_path}."
    assert report["finding_count"] == 0


def test_main_lint_policy_profile_flags_dynamic_exec(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / "policy.py").write_text("value = eval('1')\n", encoding="utf-8")

    exit_code = main(["lint", str(tmp_path), "--profile", "policy-v0.1", "--format", "json"])
    report = json.loads(capsys.readouterr().out)

    assert exit_code == EXIT_FINDINGS
    assert report["profile"] == "policy-v0.1"
    assert report["finding_count"] == 1
    assert report["findings"][0]["rule"] == "python-dynamic-exec"


def test_main_lint_policy_profile_validates_evidence_payload(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    (tmp_path / "evidence.json").write_text(
        json.dumps({"schema_version": "0.1", "transition_id": "not-a-uuid"}),
        encoding="utf-8",
    )

    exit_code = main(["lint", str(tmp_path), "--profile", "policy-v0.1", "--format", "json"])
    report = json.loads(capsys.readouterr().out)

    assert exit_code == EXIT_FINDINGS
    assert report["profile"] == "policy-v0.1"
    assert any(finding["rule"] == "evidence-schema" for finding in report["findings"])


def test_main_version_outputs_package_version(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--version"])

    assert exc_info.value.code == 0
    assert capsys.readouterr().out.strip() == f"{CLI_PROG_NAME} {__version__}"


def test_distribution_version_matches_runtime_version() -> None:
    try:
        installed_version = importlib_metadata.version("dpa-icsd")
    except importlib_metadata.PackageNotFoundError:
        pytest.skip("dpa-icsd distribution metadata is unavailable in this environment.")

    assert installed_version == __version__
