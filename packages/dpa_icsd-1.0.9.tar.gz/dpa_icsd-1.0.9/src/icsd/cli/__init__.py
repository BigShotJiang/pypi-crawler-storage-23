"""CLI package for ICSD tooling."""
