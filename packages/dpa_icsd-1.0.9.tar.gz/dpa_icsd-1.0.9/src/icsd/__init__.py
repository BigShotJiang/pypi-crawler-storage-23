"""Public package interface for the dpa-icsd distribution."""

from ._version import __version__

__all__ = ["__version__"]
