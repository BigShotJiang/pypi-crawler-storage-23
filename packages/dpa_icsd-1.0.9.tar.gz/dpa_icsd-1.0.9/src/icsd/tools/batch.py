"""Tooling bridge for deterministic batch state validation."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from icsd.core.batch import BatchReport, BatchStateResult, validate_states
from icsd.core.invariants import InvariantSet

__all__ = ["BatchReport", "BatchStateResult", "validate_states", "validate_states_report"]


def validate_states_report(
    invariant_set: InvariantSet,
    states: Iterable[Any],
    *,
    context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a serialisable batch-validation report payload."""
    return validate_states(invariant_set, states, context=context).as_dict()
