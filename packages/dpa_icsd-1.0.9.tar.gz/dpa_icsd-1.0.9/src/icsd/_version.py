"""Single source of truth for dpa-icsd distribution and runtime versioning."""

__all__ = ["__version__"]

__version__ = "1.0.9"
