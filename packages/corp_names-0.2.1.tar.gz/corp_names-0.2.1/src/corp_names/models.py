from pydantic import BaseModel


class NormalizedName(BaseModel):
    original: str
    normalized: str
    first: str
    last: str
    prefix: str
    suffix: str
    nickname_resolved: bool
