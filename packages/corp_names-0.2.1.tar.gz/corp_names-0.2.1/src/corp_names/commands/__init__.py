import click

from corp_names.commands.normalize import normalize


@click.group()
def main() -> None:
    """Person name normalization CLI."""
    pass


main.add_command(normalize)
