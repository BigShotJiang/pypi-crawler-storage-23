"""Simulation service for running Pulsim simulations."""

from __future__ import annotations

import copy
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, replace
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

from PySide6.QtCore import QMutex, QObject, QThread, QWaitCondition, Signal

from pulsimgui.services.backend_adapter import (
    BackendCallbacks,
    BackendInfo,
    BackendLoader,
    SimulationBackend,
)
from pulsimgui.services.backend_runtime_service import (
    BackendInstallResult,
    BackendRuntimeConfig,
    BackendRuntimeService,
)
from pulsimgui.services.backend_types import (
    ACResult as BackendACResult,
)
from pulsimgui.services.backend_types import (
    ACSettings,
    DCSettings,
)
from pulsimgui.services.backend_types import (
    DCResult as BackendDCResult,
)
from pulsimgui.utils.net_utils import build_node_alias_map, build_node_map

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from pulsimgui.services.settings_service import SettingsService


class SimulationState(Enum):
    """State of the simulation."""

    IDLE = auto()
    RUNNING = auto()
    PAUSED = auto()
    CANCELLED = auto()
    COMPLETED = auto()
    ERROR = auto()


_LEGACY_SOLVER_ALIASES = {
    "rk4": "trapezoidal",
    "rk45": "trapezoidal",
    "bdf": "bdf2",
}

_SUPPORTED_INTEGRATION_METHODS = {
    "auto",
    "trapezoidal",
    "bdf1",
    "bdf2",
    "bdf3",
    "bdf4",
    "bdf5",
    "gear",
    "trbdf2",
    "rosenbrockw",
    "sdirk2",
}


def normalize_integration_method(value: str | None) -> str:
    """Normalize persisted method names to supported backend identifiers."""
    raw = (value or "").strip().lower()
    if not raw:
        return "auto"
    normalized = _LEGACY_SOLVER_ALIASES.get(raw, raw)
    return normalized if normalized in _SUPPORTED_INTEGRATION_METHODS else "auto"


def normalize_step_mode(value: str | None) -> str:
    """Normalize transient step mode setting."""
    raw = (value or "").strip().lower()
    if raw in {"fixed", "variable"}:
        return raw
    return "fixed"


def normalize_thermal_network(value: str | None) -> str:
    """Normalize thermal network setting."""
    raw = (value or "").strip().lower()
    return raw if raw in {"foster", "cauer"} else "foster"


def normalize_formulation_mode(value: str | None) -> str:
    """Normalize transient formulation mode setting."""
    raw = (value or "").strip().lower()
    aliases = {
        "projected": "projected_wrapper",
        "projectedwrapper": "projected_wrapper",
        "native": "projected_wrapper",
        "directdae": "direct",
        "dae": "direct",
    }
    normalized = aliases.get(raw, raw)
    return normalized if normalized in {"projected_wrapper", "direct"} else "projected_wrapper"


@dataclass
class SimulationSettings:
    """Settings for transient simulation."""

    # Time settings
    t_start: float = 0.0
    t_stop: float = 1e-3  # 1ms default
    t_step: float = 1e-6  # 1us default

    # Integration settings
    solver: str = "auto"  # auto, trapezoidal, bdf1..bdf5, gear, trbdf2, rosenbrockw, sdirk2
    step_mode: str = "fixed"  # fixed, variable
    max_step: float = 1e-6
    rel_tol: float = 1e-4
    abs_tol: float = 1e-6
    enable_events: bool = True
    max_step_retries: int = 8

    # Newton solver settings
    max_newton_iterations: int = 100
    enable_voltage_limiting: bool = False
    max_voltage_step: float = 5.0

    # DC analysis settings
    dc_strategy: str = "auto"  # auto, direct, gmin, source, pseudo
    gmin_initial: float = 1e-3
    gmin_final: float = 1e-12
    dc_source_steps: int = 10

    # Transient stability settings
    transient_robust_mode: bool = True
    transient_auto_regularize: bool = True

    # Output settings
    output_points: int = 10000
    enable_losses: bool = True

    # Thermal/loss post-processing settings
    thermal_ambient: float = 25.0
    thermal_include_switching_losses: bool = True
    thermal_include_conduction_losses: bool = True
    thermal_network: str = "foster"

    # Transient formulation mode (supported by pulsim>=0.6.1)
    formulation_mode: str = "projected_wrapper"
    direct_formulation_fallback: bool = True


@dataclass
class SimulationResult:
    """Results from a simulation run."""

    time: list[float] = field(default_factory=list)
    signals: dict[str, list[float]] = field(default_factory=dict)
    statistics: dict[str, Any] = field(default_factory=dict)
    error_message: str = ""

    @property
    def is_valid(self) -> bool:
        """Check if results are valid."""
        return len(self.time) > 0 and not self.error_message


@dataclass
class DCResult:
    """Results from DC operating point analysis."""

    node_voltages: dict[str, float] = field(default_factory=dict)
    branch_currents: dict[str, float] = field(default_factory=dict)
    power_dissipation: dict[str, float] = field(default_factory=dict)
    error_message: str = ""

    @property
    def is_valid(self) -> bool:
        """Check if results are valid."""
        return not self.error_message


@dataclass
class ACResult:
    """Results from AC analysis."""

    frequencies: list[float] = field(default_factory=list)
    magnitude: dict[str, list[float]] = field(default_factory=dict)
    phase: dict[str, list[float]] = field(default_factory=dict)
    error_message: str = ""

    @property
    def is_valid(self) -> bool:
        """Check if results are valid."""
        return len(self.frequencies) > 0 and not self.error_message


@dataclass
class ParameterSweepSettings:
    """Configuration for single-parameter sweeps."""

    component_id: str
    component_name: str
    parameter_name: str
    start_value: float
    end_value: float
    points: int = 5
    scale: str = "linear"
    output_signal: str = "V(out)"
    parallel_workers: int = 1
    baseline_value: float = 1.0

    def generate_values(self) -> list[float]:
        """Generate sweep points."""
        if self.points <= 1:
            return [self.start_value]

        if self.scale == "log":
            if self.start_value <= 0 or self.end_value <= 0:
                raise ValueError("Logarithmic sweeps require positive bounds")
            start = math.log10(self.start_value)
            stop = math.log10(self.end_value)
            step = (stop - start) / (self.points - 1)
            return [10 ** (start + i * step) for i in range(self.points)]

        step = (self.end_value - self.start_value) / (self.points - 1)
        return [self.start_value + i * step for i in range(self.points)]

    def compute_scale_factor(self, value: float) -> float:
        """Return amplitude scaling for placeholder simulation."""
        if abs(self.baseline_value) < 1e-30:
            return 1.0
        return value / self.baseline_value


@dataclass
class ParameterSweepRun:
    """Result of an individual sweep point."""

    order: int
    parameter_value: float
    result: SimulationResult


@dataclass
class ParameterSweepResult:
    """Aggregated sweep results."""

    settings: ParameterSweepSettings
    runs: list[ParameterSweepRun] = field(default_factory=list)
    duration: float = 0.0

    def sorted_runs(self) -> list[ParameterSweepRun]:
        """Return runs in configured order."""
        return sorted(self.runs, key=lambda run: run.order)

    def to_waveform_result(self) -> SimulationResult:
        """Build a SimulationResult aggregating sweep traces."""
        combined = SimulationResult()
        ordered = self.sorted_runs()
        if not ordered:
            return combined

        combined.time = ordered[0].result.time.copy()

        for run in ordered:
            signal = run.result.signals.get(self.settings.output_signal)
            if not signal:
                continue
            label = (
                f"{self.settings.output_signal}"
                f" [{self.settings.parameter_name}={run.parameter_value:g}]"
            )
            combined.signals[label] = signal

        combined.statistics = {
            "sweep_points": len(ordered),
            "parameter": self.settings.parameter_name,
        }
        return combined

    def xy_dataset(self) -> tuple[list[float], list[float]]:
        """Return (parameter, output) pairs for XY plotting."""
        xs: list[float] = []
        ys: list[float] = []

        for run in self.sorted_runs():
            xs.append(run.parameter_value)
            signal = run.result.signals.get(self.settings.output_signal)
            ys.append(signal[-1] if signal else 0.0)

        return xs, ys


class SimulationWorker(QThread):
    """Worker thread for running simulations via the active backend."""

    progress = Signal(float, str)  # progress (0-100), message
    data_point = Signal(float, dict)  # time, signal_values
    finished_signal = Signal(SimulationResult)
    error = Signal(str)

    def __init__(
        self,
        backend: SimulationBackend,
        circuit_data: dict,
        settings: SimulationSettings,
        parent=None,
    ):
        super().__init__(parent)
        self._backend = backend
        self._circuit_data = circuit_data
        self._settings = settings
        self._cancelled = False
        self._paused = False
        self._mutex = QMutex()
        self._pause_condition = QWaitCondition()
        self._thread_ident: int | None = None

    def run(self) -> None:
        """Run the simulation."""
        result = SimulationResult()

        try:
            self._thread_ident = threading.get_ident()

            # Emit initial progress immediately so user sees feedback
            self.progress.emit(0, "Starting simulation...")

            callbacks = BackendCallbacks(
                progress=lambda value, message: self.progress.emit(value, message),
                data_point=lambda t, data: self.data_point.emit(t, data),
                check_cancelled=lambda: self._cancelled,
                wait_if_paused=self._wait_if_paused,
            )

            backend_result = self._backend.run_transient(
                self._circuit_data,
                self._settings,
                callbacks,
            )

            result.time = list(backend_result.time)
            result.signals = {name: list(values) for name, values in backend_result.signals.items()}
            result.statistics = dict(backend_result.statistics)
            result.error_message = backend_result.error_message

            if self._cancelled and not result.error_message:
                result.error_message = "Simulation cancelled"

            if result.error_message:
                self.error.emit(result.error_message)
            self.finished_signal.emit(result)

        except Exception as e:  # pragma: no cover - defensive path
            result.error_message = str(e)
            self.error.emit(str(e))
            self.finished_signal.emit(result)
        finally:
            self._thread_ident = None

    def _wait_if_paused(self) -> None:
        self._mutex.lock()
        try:
            while self._paused and not self._cancelled:
                self._pause_condition.wait(self._mutex)
        finally:
            self._mutex.unlock()

    def cancel(self) -> None:
        """Cancel the simulation."""
        self._cancelled = True
        self._paused = False
        self._pause_condition.wakeAll()
        self._notify_backend_control("request_stop")

    def pause(self) -> None:
        """Pause the simulation."""
        self._mutex.lock()
        self._paused = True
        self._mutex.unlock()
        self._notify_backend_control("request_pause")

    def resume(self) -> None:
        """Resume a paused simulation."""
        self._mutex.lock()
        self._paused = False
        self._mutex.unlock()
        self._pause_condition.wakeAll()
        self._notify_backend_control("request_resume")

    @property
    def is_paused(self) -> bool:
        """Check if simulation is paused."""
        return self._paused

    def _notify_backend_control(self, method_name: str) -> None:
        run_id = self._thread_ident
        if run_id is None:
            return
        handler = getattr(self._backend, method_name, None)
        if handler is None:
            return
        try:
            handler(run_id)
        except TypeError:  # Backends that ignore run identifiers
            handler()
        except Exception:
            pass


class ParameterSweepWorker(QThread):
    """Worker that runs multiple simulations for parameter sweeps."""

    progress = Signal(float, str)
    finished_signal = Signal(ParameterSweepResult)
    error = Signal(str)

    def __init__(
        self,
        backend: SimulationBackend,
        circuit_data: dict,
        sweep_settings: ParameterSweepSettings,
        base_settings: SimulationSettings,
        parent=None,
    ):
        super().__init__(parent)
        self._backend = backend
        self._circuit_data = circuit_data
        self._sweep_settings = sweep_settings
        self._base_settings = base_settings
        self._cancelled = False

    def run(self) -> None:
        """Execute the sweep."""
        runs: list[ParameterSweepRun] = []
        start_time = time.time()

        try:
            values = self._sweep_settings.generate_values()
            total = len(values)
            if total == 0:
                raise ValueError("No sweep points configured")

            parallel = max(1, self._sweep_settings.parallel_workers)
            if parallel > 1:
                with ThreadPoolExecutor(max_workers=parallel) as executor:
                    futures = {
                        executor.submit(self._simulate_value, idx, value): idx
                        for idx, value in enumerate(values)
                    }
                    for future in as_completed(futures):
                        if self._cancelled:
                            break
                        run = future.result()
                        runs.append(run)
                        self._emit_progress(len(runs), total)
            else:
                for idx, value in enumerate(values):
                    if self._cancelled:
                        break
                    runs.append(self._simulate_value(idx, value))
                    self._emit_progress(len(runs), total)

            if not self._cancelled:
                self._emit_progress(total, total)

            duration = time.time() - start_time
            result = ParameterSweepResult(
                settings=self._sweep_settings,
                runs=runs,
                duration=duration,
            )
            self.finished_signal.emit(result)
        except Exception as exc:
            self.error.emit(str(exc))
            result = ParameterSweepResult(settings=self._sweep_settings, runs=runs)
            self.finished_signal.emit(result)

    def cancel(self) -> None:
        """Request cancellation."""
        self._cancelled = True

    @property
    def was_cancelled(self) -> bool:
        """Return whether cancellation was requested."""
        return self._cancelled

    def _emit_progress(self, completed: int, total: int) -> None:
        if not total:
            return
        percent = (completed / total) * 100.0
        self.progress.emit(percent, f"Sweep {completed}/{total}")

    def _simulate_value(self, order: int, value: float) -> ParameterSweepRun:
        circuit_copy = copy.deepcopy(self._circuit_data)
        self._apply_parameter_value(circuit_copy, value)
        settings_copy = replace(self._base_settings)

        callbacks = BackendCallbacks(
            progress=lambda *_: None,
            data_point=lambda *_: None,
            check_cancelled=lambda: self._cancelled,
            wait_if_paused=lambda: None,
        )
        backend_result = self._backend.run_transient(circuit_copy, settings_copy, callbacks)
        sim_result = SimulationResult(
            time=list(backend_result.time),
            signals={name: list(series) for name, series in backend_result.signals.items()},
            statistics=dict(backend_result.statistics),
            error_message=backend_result.error_message,
        )
        return ParameterSweepRun(order=order, parameter_value=value, result=sim_result)

    def _apply_parameter_value(self, circuit_data: dict, value: float) -> None:
        for component in circuit_data.get("components", []):
            if component.get("id") == self._sweep_settings.component_id:
                params = component.setdefault("parameters", {})
                params[self._sweep_settings.parameter_name] = value
                return
        raise ValueError("Target component not found in circuit data")


class SimulationService(QObject):
    """Service for managing simulations."""

    _READY_STATUSES = {"available", "detected"}

    # Signals
    state_changed = Signal(SimulationState)
    progress = Signal(float, str)
    data_point = Signal(float, dict)
    simulation_finished = Signal(SimulationResult)
    dc_finished = Signal(DCResult)
    ac_finished = Signal(ACResult)
    parameter_sweep_finished = Signal(ParameterSweepResult)
    error = Signal(str)
    backend_changed = Signal(BackendInfo)

    def __init__(self, settings_service: SettingsService | None = None, parent=None):
        super().__init__(parent)

        self._state = SimulationState.IDLE
        self._worker: SimulationWorker | None = None
        self._sweep_worker: ParameterSweepWorker | None = None
        self._settings = SimulationSettings()
        self._last_result: SimulationResult | None = None
        self._last_convergence_info = None  # Store last DC convergence info for diagnostics
        self._settings_service = settings_service
        self._runtime_service = BackendRuntimeService()
        self._runtime_config = BackendRuntimeConfig()
        self._runtime_issue: str | None = None
        preferred_backend = None
        if settings_service is not None:
            preferred_backend = settings_service.get_backend_preference()

            # Load persisted simulation settings
            sim_settings = settings_service.get_simulation_settings()
            self._settings.t_stop = sim_settings.get("t_stop", self._settings.t_stop)
            self._settings.t_step = sim_settings.get("t_step", self._settings.t_step)
            self._settings.solver = normalize_integration_method(
                sim_settings.get("solver", self._settings.solver)
            )
            self._settings.step_mode = normalize_step_mode(
                sim_settings.get("step_mode", self._settings.step_mode)
            )
            self._settings.max_step = sim_settings.get("max_step", self._settings.max_step)
            self._settings.rel_tol = sim_settings.get("rel_tol", self._settings.rel_tol)
            self._settings.abs_tol = sim_settings.get("abs_tol", self._settings.abs_tol)
            self._settings.output_points = sim_settings.get("output_points", self._settings.output_points)
            self._settings.enable_events = bool(
                sim_settings.get("enable_events", self._settings.enable_events)
            )
            self._settings.max_step_retries = int(
                sim_settings.get("max_step_retries", self._settings.max_step_retries)
            )
            self._settings.enable_losses = bool(
                sim_settings.get("enable_losses", self._settings.enable_losses)
            )

            # Load persisted solver settings
            solver_settings = settings_service.get_solver_settings()
            self._settings.max_newton_iterations = solver_settings.get("max_newton_iterations", self._settings.max_newton_iterations)
            self._settings.enable_voltage_limiting = solver_settings.get(
                "enable_voltage_limiting",
                self._settings.enable_voltage_limiting,
            )
            self._settings.max_voltage_step = solver_settings.get("max_voltage_step", self._settings.max_voltage_step)
            self._settings.dc_strategy = solver_settings.get("dc_strategy", self._settings.dc_strategy)
            self._settings.gmin_initial = solver_settings.get("gmin_initial", self._settings.gmin_initial)
            self._settings.gmin_final = solver_settings.get("gmin_final", self._settings.gmin_final)
            self._settings.dc_source_steps = solver_settings.get("dc_source_steps", self._settings.dc_source_steps)
            self._settings.transient_robust_mode = solver_settings.get(
                "transient_robust_mode",
                self._settings.transient_robust_mode,
            )
            self._settings.transient_auto_regularize = solver_settings.get(
                "transient_auto_regularize",
                self._settings.transient_auto_regularize,
            )
            self._settings.thermal_ambient = float(
                solver_settings.get("thermal_ambient", self._settings.thermal_ambient)
            )
            self._settings.thermal_include_switching_losses = bool(
                solver_settings.get(
                    "thermal_include_switching_losses",
                    self._settings.thermal_include_switching_losses,
                )
            )
            self._settings.thermal_include_conduction_losses = bool(
                solver_settings.get(
                    "thermal_include_conduction_losses",
                    self._settings.thermal_include_conduction_losses,
                )
            )
            self._settings.thermal_network = str(
                normalize_thermal_network(
                    solver_settings.get("thermal_network", self._settings.thermal_network)
                )
            )
            self._settings.formulation_mode = str(
                normalize_formulation_mode(
                    solver_settings.get("formulation_mode", self._settings.formulation_mode)
                )
            )
            self._settings.direct_formulation_fallback = bool(
                solver_settings.get(
                    "direct_formulation_fallback",
                    self._settings.direct_formulation_fallback,
                )
            )

            # Load backend runtime settings
            runtime_settings = settings_service.get_backend_runtime_settings()
            self._runtime_config = BackendRuntimeConfig.from_dict(runtime_settings)

        if self._runtime_config.auto_sync:
            sync_result = self._runtime_service.ensure_target_version(self._runtime_config, force=False)
            if sync_result.success:
                self._runtime_issue = None
                if sync_result.changed:
                    self._runtime_service.invalidate_backend_import_cache()
            else:
                self._runtime_issue = sync_result.message

        self._backend_loader = BackendLoader(preferred_backend_id=preferred_backend)
        self._backend = self._backend_loader.backend

    @property
    def state(self) -> SimulationState:
        """Get current simulation state."""
        return self._state

    @property
    def settings(self) -> SimulationSettings:
        """Get simulation settings."""
        return self._settings

    @settings.setter
    def settings(self, value: SimulationSettings) -> None:
        """Set simulation settings."""
        self._settings = value
        self._settings.solver = normalize_integration_method(self._settings.solver)
        self._settings.step_mode = normalize_step_mode(self._settings.step_mode)
        self._settings.thermal_network = normalize_thermal_network(self._settings.thermal_network)
        self._settings.formulation_mode = normalize_formulation_mode(
            self._settings.formulation_mode
        )
        self._persist_simulation_settings()

    @property
    def last_result(self) -> SimulationResult | None:
        """Get the last simulation result."""
        return self._last_result

    @property
    def is_running(self) -> bool:
        """Check if simulation is currently running."""
        return self._state in (SimulationState.RUNNING, SimulationState.PAUSED)

    @property
    def backend_info(self) -> BackendInfo:
        """Return metadata about the active simulation backend."""
        return self._backend.info

    @property
    def backend(self):
        """Return the active simulation backend for direct access."""
        return self._backend

    @property
    def backend_runtime_config(self) -> BackendRuntimeConfig:
        """Return backend runtime provisioning settings."""
        return self._runtime_config

    @property
    def last_convergence_info(self):
        """Return the last DC/transient convergence info for diagnostics."""
        return self._last_convergence_info

    def has_capability(self, name: str) -> bool:
        """Check if the backend supports a specific capability.

        Args:
            name: Capability name (e.g., "dc", "ac", "thermal", "transient")

        Returns:
            True if the capability is supported.
        """
        return self._backend.has_capability(name)

    @property
    def available_backends(self) -> list[BackendInfo]:
        """Available backend options discovered at runtime."""
        return self._backend_loader.available_backends

    @property
    def is_backend_ready(self) -> bool:
        """Return True when a real simulation backend is available."""
        info = self._backend.info
        status = (info.status or "").lower()
        return info.identifier != "placeholder" and status in self._READY_STATUSES

    @property
    def backend_issue_message(self) -> str | None:
        """Human-friendly description when the backend cannot be used."""
        if self.is_backend_ready:
            return None

        if self._runtime_issue:
            return self._runtime_issue

        info = self._backend.info
        detail = (info.message or "").strip()
        if detail:
            return detail
        if info.identifier == "placeholder":
            return "No simulation backend detected. Install Pulsim to enable simulations."
        status = info.status or "unavailable"
        return f"Backend '{info.name}' is not available (status: {status})."

    def set_backend_preference(self, identifier: str) -> BackendInfo:
        """Switch to the requested backend if possible."""
        if self.is_running:
            raise RuntimeError("Cannot change backend while a simulation is running")
        info = self._backend_loader.activate(identifier)
        self._backend = self._backend_loader.backend
        if self._settings_service is not None:
            self._settings_service.set_backend_preference(identifier)
        self.backend_changed.emit(info)
        return info

    def update_backend_runtime_config(self, config: BackendRuntimeConfig) -> None:
        """Persist and apply backend runtime configuration."""
        self._runtime_config = config
        if self._settings_service is not None:
            self._settings_service.set_backend_runtime_settings(config.to_dict())

    def install_backend_runtime(
        self,
        config: BackendRuntimeConfig | None = None,
        *,
        force: bool = True,
    ) -> BackendInstallResult:
        """Install or synchronize backend runtime according to configuration."""
        if self.is_running:
            return BackendInstallResult(
                success=False,
                message="Cannot install backend while a simulation is running.",
            )

        effective_config = config or self._runtime_config
        if config is not None:
            self.update_backend_runtime_config(config)

        result = self._runtime_service.ensure_target_version(effective_config, force=force)
        if not result.success:
            self._runtime_issue = result.message
            return result

        self._runtime_issue = None
        if result.changed:
            self._runtime_service.invalidate_backend_import_cache()

        self._reload_backend_loader(emit_signal=True)
        return result

    def _reload_backend_loader(self, *, emit_signal: bool) -> None:
        preferred_backend = None
        if self._settings_service is not None:
            preferred_backend = self._settings_service.get_backend_preference()
        elif self._backend_loader.active_backend_id:
            preferred_backend = self._backend_loader.active_backend_id

        self._backend_loader = BackendLoader(preferred_backend_id=preferred_backend)
        self._backend = self._backend_loader.backend
        if emit_signal:
            self.backend_changed.emit(self._backend.info)

    def _persist_simulation_settings(self) -> None:
        """Persist simulation and solver settings when available."""
        if self._settings_service is None:
            return
        self._settings_service.set_simulation_settings(
            {
                "t_stop": self._settings.t_stop,
                "t_step": self._settings.t_step,
                "solver": normalize_integration_method(self._settings.solver),
                "step_mode": normalize_step_mode(self._settings.step_mode),
                "max_step": self._settings.max_step,
                "rel_tol": self._settings.rel_tol,
                "abs_tol": self._settings.abs_tol,
                "output_points": self._settings.output_points,
                "enable_events": self._settings.enable_events,
                "max_step_retries": self._settings.max_step_retries,
                "enable_losses": self._settings.enable_losses,
            }
        )
        self._settings_service.set_solver_settings(
            {
                "max_newton_iterations": self._settings.max_newton_iterations,
                "enable_voltage_limiting": self._settings.enable_voltage_limiting,
                "max_voltage_step": self._settings.max_voltage_step,
                "dc_strategy": self._settings.dc_strategy,
                "gmin_initial": self._settings.gmin_initial,
                "gmin_final": self._settings.gmin_final,
                "dc_source_steps": self._settings.dc_source_steps,
                "transient_robust_mode": self._settings.transient_robust_mode,
                "transient_auto_regularize": self._settings.transient_auto_regularize,
                "thermal_ambient": self._settings.thermal_ambient,
                "thermal_include_switching_losses": self._settings.thermal_include_switching_losses,
                "thermal_include_conduction_losses": self._settings.thermal_include_conduction_losses,
                "thermal_network": normalize_thermal_network(self._settings.thermal_network),
                "formulation_mode": normalize_formulation_mode(self._settings.formulation_mode),
                "direct_formulation_fallback": bool(
                    self._settings.direct_formulation_fallback
                ),
            }
        )

    def _ensure_backend_ready(self) -> bool:
        """Emit a user-facing error if no backend is currently usable."""
        if self.is_backend_ready:
            return True
        issue = self.backend_issue_message or "Simulation backend unavailable."
        self.error.emit(f"Simulation backend unavailable: {issue}")
        return False

    def run_transient(self, circuit_data: dict) -> None:
        """Run a transient simulation."""
        if not self._ensure_backend_ready():
            return
        if self.is_running:
            self.error.emit("Simulation already running")
            return

        self._set_state(SimulationState.RUNNING)

        # Emit immediate feedback so UI shows activity right away
        self.progress.emit(-1, "Starting simulation...")

        # Create and start worker thread
        self._worker = SimulationWorker(self._backend, circuit_data, self._settings)
        self._worker.progress.connect(self._on_progress)
        self._worker.data_point.connect(self._on_data_point)
        self._worker.finished_signal.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.finished.connect(self._worker.deleteLater)
        self._worker.start()

    def run_dc_operating_point(
        self,
        circuit_data: dict,
        dc_settings: DCSettings | None = None,
    ) -> None:
        """Run DC operating point analysis.

        Args:
            circuit_data: Dictionary representation of the circuit.
            dc_settings: DC analysis settings. If None, builds from SimulationSettings.
        """
        if not self._ensure_backend_ready():
            return
        if self.is_running:
            self.error.emit("Simulation already running")
            return

        self._set_state(SimulationState.RUNNING)
        self.progress.emit(0, "Running DC analysis...")

        # Build DC settings from SimulationSettings if not provided
        if dc_settings is None:
            dc_settings = DCSettings(
                strategy=self._settings.dc_strategy,
                max_iterations=self._settings.max_newton_iterations,
                enable_limiting=self._settings.enable_voltage_limiting,
                max_voltage_step=self._settings.max_voltage_step,
                gmin_initial=self._settings.gmin_initial,
                gmin_final=self._settings.gmin_final,
                source_steps=self._settings.dc_source_steps,
            )

        result = DCResult()

        try:
            # Check if backend supports DC analysis
            if self._backend.has_capability("dc"):
                # Use real backend for DC analysis
                backend_result: BackendDCResult = self._backend.run_dc(circuit_data, dc_settings)

                # Convert backend result to local DCResult
                result.node_voltages = backend_result.node_voltages.copy()
                result.branch_currents = backend_result.branch_currents.copy()
                result.power_dissipation = backend_result.power_dissipation.copy()
                result.error_message = backend_result.error_message

                # Store convergence info for potential diagnostics dialog
                self._last_convergence_info = backend_result.convergence_info

                if backend_result.error_message:
                    self._set_state(SimulationState.ERROR)
                    self.error.emit(backend_result.error_message)
                else:
                    self.progress.emit(100, "DC analysis complete")
                    self._set_state(SimulationState.COMPLETED)
            else:
                # Fallback to placeholder
                result.node_voltages = {
                    "V(out)": 5.0,
                    "V(in)": 10.0,
                    "V(gnd)": 0.0,
                }
                result.branch_currents = {
                    "I(R1)": 0.005,
                    "I(V1)": -0.005,
                }
                result.power_dissipation = {
                    "P(R1)": 0.025,
                }
                self.progress.emit(100, "DC analysis complete (placeholder)")
                self._set_state(SimulationState.COMPLETED)

            self.dc_finished.emit(result)

        except Exception as e:
            result.error_message = str(e)
            self._set_state(SimulationState.ERROR)
            self.error.emit(str(e))
            self.dc_finished.emit(result)

    def run_ac_analysis(
        self,
        circuit_data: dict,
        f_start: float,
        f_stop: float,
        points_per_decade: int = 10,
        ac_settings: ACSettings | None = None,
    ) -> None:
        """Run AC frequency sweep analysis.

        Args:
            circuit_data: Dictionary representation of the circuit.
            f_start: Start frequency (Hz).
            f_stop: Stop frequency (Hz).
            points_per_decade: Number of points per decade.
            ac_settings: AC analysis settings. If None, uses parameters above.
        """
        if not self._ensure_backend_ready():
            return
        if self.is_running:
            self.error.emit("Simulation already running")
            return

        self._set_state(SimulationState.RUNNING)
        self.progress.emit(0, "Running AC analysis...")

        # Build settings if not provided
        if ac_settings is None:
            ac_settings = ACSettings(
                f_start=f_start,
                f_stop=f_stop,
                points_per_decade=points_per_decade,
            )

        result = ACResult()

        try:
            # Check if backend supports AC analysis
            if self._backend.has_capability("ac"):
                # Use real backend for AC analysis
                backend_result: BackendACResult = self._backend.run_ac(circuit_data, ac_settings)

                # Convert backend result to local ACResult
                result.frequencies = backend_result.frequencies.copy()
                result.magnitude = {k: list(v) for k, v in backend_result.magnitude.items()}
                result.phase = {k: list(v) for k, v in backend_result.phase.items()}
                result.error_message = backend_result.error_message

                if backend_result.error_message:
                    self._set_state(SimulationState.ERROR)
                    self.error.emit(backend_result.error_message)
                else:
                    self.progress.emit(100, "AC analysis complete")
                    self._set_state(SimulationState.COMPLETED)
            else:
                result.error_message = (
                    f"AC analysis is not available in backend {self._backend.info.label()}."
                )
                self._set_state(SimulationState.ERROR)
                self.error.emit(result.error_message)

            self.ac_finished.emit(result)

        except Exception as e:
            result.error_message = str(e)
            self._set_state(SimulationState.ERROR)
            self.error.emit(str(e))
            self.ac_finished.emit(result)

    def run_parameter_sweep(
        self, circuit_data: dict, sweep_settings: ParameterSweepSettings
    ) -> None:
        """Run a parameter sweep across multiple simulations."""
        if not self._ensure_backend_ready():
            return
        if self.is_running:
            self.error.emit("Simulation already running")
            return

        self._set_state(SimulationState.RUNNING)

        self._sweep_worker = ParameterSweepWorker(
            self._backend,
            circuit_data,
            sweep_settings,
            self._settings,
        )
        self._sweep_worker.progress.connect(self._on_progress)
        self._sweep_worker.finished_signal.connect(self._on_parameter_sweep_finished)
        self._sweep_worker.error.connect(self._on_error)
        self._sweep_worker.finished.connect(self._on_sweep_thread_finished)
        self._sweep_worker.start()

    def stop(self) -> None:
        """Stop the current simulation."""
        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            self._worker.wait(5000)  # Wait up to 5 seconds
            self._set_state(SimulationState.CANCELLED)

        if self._sweep_worker and self._sweep_worker.isRunning():
            self._sweep_worker.cancel()
            self._sweep_worker.wait(5000)
            self._set_state(SimulationState.CANCELLED)

    def pause(self) -> None:
        """Pause the current simulation."""
        if self._worker and self._state == SimulationState.RUNNING:
            self._worker.pause()
            self._set_state(SimulationState.PAUSED)

    def resume(self) -> None:
        """Resume a paused simulation."""
        if self._worker and self._state == SimulationState.PAUSED:
            self._worker.resume()
            self._set_state(SimulationState.RUNNING)

    def _set_state(self, state: SimulationState) -> None:
        """Set state and emit signal."""
        self._state = state
        self.state_changed.emit(state)

    def _on_progress(self, value: float, message: str) -> None:
        """Handle progress update from worker."""
        self.progress.emit(value, message)

    def _on_data_point(self, time: float, signals: dict) -> None:
        """Handle data point from worker."""
        self.data_point.emit(time, signals)

    def _on_finished(self, result: SimulationResult) -> None:
        """Handle simulation completion."""
        self._last_result = result
        if result.error_message == "Simulation cancelled":
            self._set_state(SimulationState.CANCELLED)
        elif result.error_message:
            self._set_state(SimulationState.ERROR)
        else:
            self._set_state(SimulationState.COMPLETED)
        self.simulation_finished.emit(result)

    def _on_parameter_sweep_finished(self, result: ParameterSweepResult) -> None:
        """Handle completion of a parameter sweep."""
        if self._sweep_worker and self._sweep_worker.was_cancelled:
            self._set_state(SimulationState.CANCELLED)
        elif not result.runs:
            self._set_state(SimulationState.ERROR)
        else:
            self._set_state(SimulationState.COMPLETED)

        self.parameter_sweep_finished.emit(result)

    def _on_sweep_thread_finished(self) -> None:
        """Clear sweep worker reference when the thread ends."""
        self._sweep_worker = None

    def _on_error(self, message: str) -> None:
        """Handle error from worker."""
        self._set_state(SimulationState.ERROR)
        self.error.emit(message)

    def convert_gui_circuit(self, project) -> dict:
        """Convert GUI project/circuit to simulation data format."""
        circuit_data = {
            "components": [],
            "wires": [],
            "nodes": {},
            "node_map": {},
            "node_aliases": {},
            "metadata": {},
        }

        if not project:
            return circuit_data

        circuit = project.get_active_circuit()
        if circuit is None:
            return circuit_data

        node_map_raw = build_node_map(circuit)
        alias_map = build_node_alias_map(circuit, node_map_raw)
        circuit_data["node_aliases"] = alias_map
        circuit_data["metadata"] = {"name": circuit.name}

        component_node_map: dict[str, list[str]] = {}

        for comp in circuit.components.values():
            comp_dict = comp.to_dict()
            comp_dict["parameters"] = copy.deepcopy(comp.parameters)
            comp_id = str(comp.id)
            pin_nodes: list[str] = []
            for pin_index in range(len(comp.pins)):
                node_name = node_map_raw.get((comp_id, pin_index))
                if node_name is None:
                    node_name = ""
                pin_nodes.append(node_name)
            comp_dict["pin_nodes"] = pin_nodes
            circuit_data["components"].append(comp_dict)
            component_node_map[comp_id] = pin_nodes

        circuit_data["node_map"] = component_node_map

        for wire in circuit.wires.values():
            circuit_data["wires"].append(wire.to_dict())

        return circuit_data
