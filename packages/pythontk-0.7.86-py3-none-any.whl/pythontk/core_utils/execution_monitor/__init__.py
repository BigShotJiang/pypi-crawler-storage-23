# coding=utf-8
"""Subpackage — see root ``pythontk.__init__`` for public API."""
