"""Data models for channel communication."""

from typing import Any

from pydantic import BaseModel, Field


class ChannelRequest(BaseModel):
    """Request message structure for channel communication."""

    id: str = Field(..., description="Unique identifier for the request")
    operation: str = Field(..., description="Type of the operation/command")
    service: str = Field(..., description="Type of the service the operation belong to")
    input: dict[str, Any] = Field(
        default_factory=dict, description="Input parameters for the request"
    )


class ChannelResponse(BaseModel):
    """Response message structure for channel communication."""

    id: str = Field(..., description="Request ID this response corresponds to")
    result: dict[str, Any] | None = Field(None, description="Result data if successful")
    error: dict[str, Any] | None = Field(None, description="Error details if failed")
