from typing import Any

from ..session.manager import get_session


class ServiceProxy:
    """Base class for remote platform services."""

    def __init__(self, service_name: str):
        self.service_name = service_name

    async def _invoke(self, operation: str, **params: Any) -> Any:
        session = get_session()
        return await session.invoke(self.service_name, operation, **params)
