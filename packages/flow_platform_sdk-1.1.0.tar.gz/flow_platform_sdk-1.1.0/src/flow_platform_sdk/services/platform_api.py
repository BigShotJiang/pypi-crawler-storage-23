from typing import Any

from .base import ServiceProxy


class PlatformApiService(ServiceProxy):
    def __init__(self):
        super().__init__("platform_api")

    # -------- Data Connectors --------

    async def list_connectors(self) -> dict[str, Any]:
        return await self._invoke("list_connectors")

    async def get_schema(self, connector_id: str) -> dict[str, Any]:
        return await self._invoke(
            "get_schema",
            connector_id=connector_id,
        )

    async def list_integrations(self) -> dict[str, Any]:
        return await self._invoke("list_integrations")

    async def execute_query(
        self,
        connector_id: str,
        sql_query: str,
        max_rows: int = 1000,
    ) -> dict[str, Any]:
        return await self._invoke(
            "execute_query",
            connector_id=connector_id,
            sql_query=sql_query,
            max_rows=max_rows,
        )

    async def discover_schema(
        self,
        connector_id: str,
        include_sample_data: bool = False,
        table_filter: str | None = None,
    ) -> dict[str, Any]:
        return await self._invoke(
            "discover_schema",
            connector_id=connector_id,
            include_sample_data=include_sample_data,
            table_filter=table_filter,
        )

    async def get_table_info(
        self,
        connector_id: str,
        table_name: str,
    ) -> dict[str, Any]:
        return await self._invoke(
            "get_table_info",
            connector_id=connector_id,
            table_name=table_name,
        )

    async def get_sample_data(
        self,
        connector_id: str,
        table_name: str,
        limit: int = 5,
    ) -> dict[str, Any]:
        return await self._invoke(
            "get_sample_data",
            connector_id=connector_id,
            table_name=table_name,
            limit=min(limit, 100),
        )

    # -------- Knowledge Base --------

    async def list_knowledge_bases(self) -> dict[str, Any]:
        return await self._invoke("list_knowledge_bases")

    async def query_knowledge_base(
        self,
        knowledge_base_id: str,
        query: str,
    ) -> dict[str, Any]:
        return await self._invoke(
            "query_knowledge_base",
            knowledge_base_id=knowledge_base_id,
            query=query,
        )

    # -------- Agent Evaluation --------

    async def invoke_agent(
        self,
        agent_spec_id: str,
        draft_skill_id: str | None = None,
        input_message: str = "",
        context: dict[str, Any] | None = None,
        timeout: int = 60,
    ) -> dict[str, Any]:
        """
        Invoke an agent with optional draft skill for evaluation.

        Args:
            agent_spec_id: Agent specification ID to invoke
            draft_skill_id: Optional draft skill ID for testing
            input_message: User input message/query
            context: Optional context dictionary
            timeout: Request timeout in seconds

        Returns:
            {
                "conversation_id": str,
                "output": str,
                "latency_ms": float,
                "trace": List[Dict],
                "error": Optional[str]
            }
        """
        return await self._invoke(
            "invoke_agent",
            agent_spec_id=agent_spec_id,
            draft_skill_id=draft_skill_id,
            input_message=input_message,
            context=context or {},
            timeout=timeout,
        )
