from .channel import StdioChannel
from .session import Session

_session: Session | None = None


def get_session() -> Session:
    """Get or create singleton session with stdio channel."""
    global _session

    if _session:
        return _session

    channel = StdioChannel()
    _session = Session(channel)
    return _session
