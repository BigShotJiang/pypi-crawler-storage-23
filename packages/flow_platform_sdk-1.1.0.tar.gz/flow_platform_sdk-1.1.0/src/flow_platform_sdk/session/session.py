import uuid
from typing import Any

from ..models.channel import ChannelRequest, ChannelResponse
from .channel.base import Channel


class Session:
    """Session for making RPC calls through a channel."""

    def __init__(self, channel: Channel):
        self.channel = channel

    async def invoke(self, service: str, operation: str, **kwargs: Any) -> Any:
        """Invoke a remote service operation."""
        request = ChannelRequest(
            id=str(uuid.uuid4()),
            service=service,
            operation=operation,
            input=kwargs,
        )

        try:
            response: ChannelResponse = await self.channel.request(request)

            if response.error:
                error_msg = (
                    response.error.get("message", str(response.error))
                    if response.error
                    else "Unknown error"
                )
                raise RuntimeError(f"Operation '{operation}' failed: {error_msg}")

            return response.result
        except Exception as e:
            raise RuntimeError(f"Operation '{operation}' failed: {str(e)}")
