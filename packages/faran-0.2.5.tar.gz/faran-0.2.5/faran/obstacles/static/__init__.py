from .basic import (
    NumPyStaticObstacleSimulator as NumPyStaticObstacleSimulator,
)
from .accelerated import (
    JaxStaticObstacleSimulator as JaxStaticObstacleSimulator,
)
