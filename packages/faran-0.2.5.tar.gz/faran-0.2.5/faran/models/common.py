from typing import Final

SMALL_UNCERTAINTY: Final = 1e-4
LARGE_UNCERTAINTY: Final = 1.0
