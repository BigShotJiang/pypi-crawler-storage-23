import"../chunks/BqgPKE-B.js";import"../chunks/zzPCSqzL.js";import{D as a}from"../chunks/C2YdhL3V.js";function m(o){a(o,{})}export{m as component};
