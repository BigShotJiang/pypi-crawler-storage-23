import{c,a as l}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as i}from"./6mnWt3YZ.js";import{I as d,s as $}from"./BfTcz1DI.js";import{l as p,s as m}from"./BJ0MJm0w.js";function M(t,e){const a=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2"}],["path",{d:"M6.453 15h11.094"}],["path",{d:"M8.5 2h7"}]];d(t,m({name:"flask-conical"},()=>a,{get iconNode(){return o},children:(r,f)=>{var s=c(),n=i(s);$(n,e,"default",{}),l(r,s)},$$slots:{default:!0}}))}function N(t,e){const a=p(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z"}]];d(t,m({name:"message-circle"},()=>a,{get iconNode(){return o},children:(r,f)=>{var s=c(),n=i(s);$(n,e,"default",{}),l(r,s)},$$slots:{default:!0}}))}export{M as F,N as M};
