import{c as i,a as n}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as p}from"./6mnWt3YZ.js";import{I as l,s as m}from"./BfTcz1DI.js";import{l as d,s as f}from"./BJ0MJm0w.js";function b(r,o){const s=d(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335"}],["path",{d:"m9 11 3 3L22 4"}]];l(r,f({name:"circle-check-big"},()=>s,{get iconNode(){return t},children:(a,$)=>{var e=i(),c=p(e);m(c,o,"default",{}),n(a,e)},$$slots:{default:!0}}))}export{b as C};
