import{c as n,a as i}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as p}from"./6mnWt3YZ.js";import{I as m,s as l}from"./BfTcz1DI.js";import{l as d,s as f}from"./BJ0MJm0w.js";function y(s,r){const e=d(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["circle",{cx:"11",cy:"11",r:"8"}],["path",{d:"m21 21-4.3-4.3"}]];m(s,f({name:"search"},()=>e,{get iconNode(){return t},children:(a,$)=>{var o=n(),c=p(o);l(c,r,"default",{}),i(a,o)},$$slots:{default:!0}}))}export{y as S};
