import{c as i,a as d}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as h}from"./6mnWt3YZ.js";import{I as n,s as l}from"./BfTcz1DI.js";import{l as c,s as m}from"./BJ0MJm0w.js";function v(o,t){const r=c(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"}],["path",{d:"M12 11h4"}],["path",{d:"M12 16h4"}],["path",{d:"M8 11h.01"}],["path",{d:"M8 16h.01"}]];n(o,m({name:"clipboard-list"},()=>r,{get iconNode(){return s},children:(e,f)=>{var a=i(),p=h(a);l(p,t,"default",{}),d(e,a)},$$slots:{default:!0}}))}export{v as C};
