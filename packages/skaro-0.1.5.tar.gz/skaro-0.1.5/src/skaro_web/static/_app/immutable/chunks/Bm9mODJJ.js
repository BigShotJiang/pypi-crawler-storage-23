import{c as i,a as n}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as p}from"./6mnWt3YZ.js";import{I as l,s as m}from"./BfTcz1DI.js";import{l as d,s as f}from"./BJ0MJm0w.js";function v(s,r){const t=d(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"m15 9-6 6"}],["path",{d:"m9 9 6 6"}]];l(s,f({name:"circle-x"},()=>t,{get iconNode(){return e},children:(a,$)=>{var o=i(),c=p(o);m(c,r,"default",{}),n(a,o)},$$slots:{default:!0}}))}export{v as C};
