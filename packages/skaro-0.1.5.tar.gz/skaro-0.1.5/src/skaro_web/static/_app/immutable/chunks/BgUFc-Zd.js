import{c as d,a as i}from"./BqgPKE-B.js";import"./zzPCSqzL.js";import{f as c}from"./6mnWt3YZ.js";import{I as l,s as p}from"./BfTcz1DI.js";import{l as $,s as m}from"./BJ0MJm0w.js";function N(o,t){const a=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"m9 18 6-6-6-6"}]];l(o,m({name:"chevron-right"},()=>a,{get iconNode(){return r},children:(s,h)=>{var e=d(),n=c(e);p(n,t,"default",{}),i(s,e)},$$slots:{default:!0}}))}function y(o,t){const a=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M10 12.5 8 15l2 2.5"}],["path",{d:"m14 12.5 2 2.5-2 2.5"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"}]];l(o,m({name:"file-code"},()=>a,{get iconNode(){return r},children:(s,h)=>{var e=d(),n=c(e);p(n,t,"default",{}),i(s,e)},$$slots:{default:!0}}))}export{N as C,y as F};
