"""Skaro Core — Spec-Guided Development engine."""

__version__ = "0.1.0"
