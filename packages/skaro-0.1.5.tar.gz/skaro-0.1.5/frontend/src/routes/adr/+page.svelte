<script>
	import AdrPage from '$lib/pages/AdrPage.svelte';
</script>

<AdrPage />
