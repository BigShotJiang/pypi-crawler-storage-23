<script>
	import ConstitutionPage from '$lib/pages/ConstitutionPage.svelte';
</script>

<ConstitutionPage />
