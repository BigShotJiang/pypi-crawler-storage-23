# Architecture

## Overview
<!-- Monolith / microservices / modular monolith / serverless -->

## Components
<!-- List components and their responsibilities -->

## Data Storage
<!-- Database, caching, file storage — what and why -->

## Communication
<!-- REST / gRPC / GraphQL / message broker / events -->

## Infrastructure
<!-- Deployment, CI/CD, monitoring -->

## External Integrations
<!-- 3rd party services, APIs -->

## Security
<!-- Authentication, authorization, data protection -->

## Known Trade-offs
<!-- What was sacrificed and why -->
