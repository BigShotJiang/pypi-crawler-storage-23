# Development Plan

## Overview
<!-- High-level description of the project scope and development strategy -->

## 01 — Foundation
_Directory: `milestones/01-foundation/`_

| # | Task | Status | Dependencies | Description |
|---|------|--------|--------------|-------------|
| 1 | task-slug | planned | — | What this task does |

## 02 — MVP
_Directory: `milestones/02-mvp/`_

| # | Task | Status | Dependencies | Description |
|---|------|--------|--------------|-------------|
| 1 | task-slug | planned | task-x | What this task does |

## Backlog
<!-- Tasks not yet assigned to a milestone -->

| # | Task | Status | Description |
|---|------|--------|-------------|
| 1 | task-slug | idea | What this task does |

---

## Status Legend
- **idea** — not yet scoped
- **planned** — scoped, assigned to milestone
- **in-progress** — actively being developed
- **done** — completed and reviewed
- **cut** — removed from scope (with reason)

## Change Log
<!-- Track major plan changes here -->
- YYYY-MM-DD: Initial plan created
