# AI_NOTES — Stage <N>: <title>

## What was done
- <list of changes>

## Why this approach
- <rationale for key decisions>

## Files created / modified
| File | Action | Description |
|---|---|---|
| `path/to/file` | created / modified | what and why |

## Risks and limitations
- <known limitations>
- <potential issues>

## Invariant compliance
- [ ] <invariant 1> — respected
- [ ] <invariant 2> — respected

## How to verify
1. `<build command>`
2. `<test command>`
3. <manual checks>
