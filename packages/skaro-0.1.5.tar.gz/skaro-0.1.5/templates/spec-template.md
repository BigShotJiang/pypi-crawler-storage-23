# Specification: <название задачи>

## Context
Why this task is needed, what problem it solves.

## User Scenarios
1. **<Scenario 1>:** <description>
2. **<Scenario 2>:** <description>

## Functional Requirements
- FR-01: <requirement>
- FR-02: <requirement>

## Non-Functional Requirements
- NFR-01: <performance / availability / scalability>

## Boundaries (what is NOT included)
- <explicit exclusions>

## Acceptance Criteria
- [ ] <criterion 1>
- [ ] <criterion 2>

## Open Questions
- <questions to be resolved in the Clarify phase>
