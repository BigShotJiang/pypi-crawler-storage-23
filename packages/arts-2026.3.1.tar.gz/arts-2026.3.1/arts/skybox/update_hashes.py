import re, hashlib, platform
from pathlib import Path

import yaml  # pip install pyyaml

root_dir = Path(__file__).parent / 'files'

system_environment = dict(
    operating_system = platform.system(),
    operating_system_version = platform.release(),
    python_version = platform.python_version(),
)

gap_symbol = '----------------------------------------------------------------------'

def update_files_hashes(files_dir: str):
    files_dir: Path = Path(files_dir).resolve()
    files_dir.relative_to(root_dir.resolve())
    print(f"正在更新文件夹 | {files_dir}")
    print(gap_symbol)
    files: list[Path] = []
    for x in list(files_dir.rglob("*")):
        if x.is_file():
            if re.search(r'\.hash\.yaml$', x.as_posix(), re.I):
                print(f"删除哈希文件 | {x}")
                x.unlink()
            else:
                files.append(x)
    print(gap_symbol)
    for x in files:
        print(f"更新哈希文件 | {x}")
        x_bytes = x.read_bytes()
        result = {
            'file_info': {
                'size': x.stat().st_size,
                'sha-512': hashlib.sha512(x_bytes).hexdigest(),
                'sha3-512': hashlib.sha3_512(x_bytes).hexdigest(),
            },
            'system_environment': system_environment,
        }
        result = yaml.dump(result, Dumper=yaml.SafeDumper, indent=4, allow_unicode=True, sort_keys=False)
        Path(f"{x}.hash.yaml").write_text(result, encoding='utf-8')
    print(gap_symbol)
    print('更新完成')

if __name__ == '__main__':
    update_files_hashes(rf'C:\bpath\pypi_arts\arts\skybox\files')
