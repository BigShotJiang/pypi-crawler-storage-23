"""Basic implementations of some optimization algorithms namely

- `purecma.fmin` and `purecma.CMAES`: a basic and readible CMA-ES implementation
  where the core algorithm is coded in under 40 lines (in the method `CMAES.tell`)
- `compact_ga.CompactGA`: compact GA which is the most logical abstraction of an
  genetic algorithm as an estimation of distribution algorithm

"""
