import re
from collections.abc import Callable, Mapping
from typing import Any, ClassVar

import yaml
from langchain_text_splitters import (
    MarkdownHeaderTextSplitter,
)

from chunkmate.chunkers.chunk import Chunk
from chunkmate.splitters.protocols import Splitter
from chunkmate.utils.tokens import default_token_counter


class MarkdownSplitter(Splitter):
    """A splitter for Markdown documents with header-based splitting and contextual enrichment.

    MarkdownSplitter intelligently splits Markdown documents by respecting the
    document structure defined by headers (##, ###). It ensures that content
    remains grouped under its relevant headers while respecting token limits.

    Inspired by Anthropic's Contextual Retrieval approach, each chunk is enriched
    with a ``metadata["context"]`` string derived from the document's structure,
    improving semantic search and retrieval accuracy for RAG systems. The context
    is built purely from document structure (headers, title, frontmatter), making
    it deterministic, fast, and free of external API calls.

    YAML frontmatter (the ``---`` delimited block at the top of many Markdown files)
    is stripped from chunk text so it never appears in the output, but its fields
    are used to enrich context.

    The generated context includes:

    - The document title (from frontmatter ``title`` field, falling back to the first H1)
    - Relevant frontmatter fields (``description``, ``tags``, ``sidebar_label``, ``keywords``)
    - The header breadcrumb path leading to the chunk (e.g., "Installation > Prerequisites")

    The splitter has two modes of operation:

    1. If the entire document fits within max_chunk_size, return it as a single chunk
    2. Otherwise, split by headers (## and ###) using LangChain's MarkdownHeaderTextSplitter

    Attributes:
        max_chunk_size: Maximum number of tokens allowed per chunk.
        count_tokens: Function to count tokens in a text string.

    Example:
        Basic usage with defaults:

        >>> splitter = MarkdownSplitter()
        >>> text = "## Section 1\\n\\nContent here\\n\\n### Subsection\\n\\nMore content"
        >>> chunks = splitter.split(text)
        >>> for chunk in chunks:
        ...     print(f"Tokens: {chunk.token_count}, Text: {chunk.text[:50]}")

        With frontmatter:

        >>> text = "---\\ntitle: API Guide\\ntags: [auth, rest]\\n---\\n\\n## Auth\\n\\nContent."
        >>> splitter = MarkdownSplitter()
        >>> chunks = splitter.split(text)
        >>> print(chunks[0].metadata["context"])
        'Document: API Guide | Tags: auth, rest | Section: Auth'
    """

    _MARKDOWN_INDICATORS: ClassVar[list[str]] = [
        r"^#{1,6}\s",  # Headers (most distinctive)
        r"^```",  # Code blocks
        r"\[.+\]\(.+\)",  # Links (inline elements)
        r"\*\*.*\*\*",  # Bold text (inline elements)
        r"^[-*+]\s+\S",  # Unordered lists
        r"^\d+\.\s+\S",  # Ordered lists
    ]

    # Matches a single H1 line (e.g. "# Title") and captures the title text.
    _H1_PATTERN: ClassVar[re.Pattern[str]] = re.compile(r"^#\s+(.+)$", re.MULTILINE)
    # Matches YAML frontmatter at the very start of the file (between --- fences)
    # and captures the YAML body. re.DOTALL lets . match newlines across the block.
    _FRONTMATTER_PATTERN: ClassVar[re.Pattern[str]] = re.compile(
        r"\A---\s*\n(.+?)\n---\s*\n?", re.DOTALL
    )
    # "title" is intentionally excluded; it is resolved separately via _resolve_title
    # and emitted as "Document: ..." at the start of the context string.
    _CONTEXT_FRONTMATTER_KEYS: ClassVar[list[str]] = [
        "description",
        "tags",
    ]

    def __init__(
        self,
        max_chunk_size: int = 512,
        count_tokens: Callable[[str], int] = default_token_counter,
    ):
        """Initialize the MarkdownSplitter with token limits and counting function.

        Args:
            max_chunk_size: Maximum number of tokens allowed per chunk. If the entire
                           document is smaller than this, it will be returned as a
                           single chunk. Defaults to 512 tokens.
            count_tokens: A callable that takes a string and returns the token count.
                         Defaults to the default_token_counter which uses tiktoken's
                         o200k_base encoding (used by GPT-4o and GPT-4o-mini).

        Example:
            >>> splitter = MarkdownSplitter(max_chunk_size=1024)
            >>> # or with custom token counter
            >>> splitter = MarkdownSplitter(
            ...     max_chunk_size=256,
            ...     count_tokens=lambda text: len(text) // 4
            ... )
        """
        self.max_chunk_size = max_chunk_size
        self.count_tokens = count_tokens
        self._splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=[
                ("##", "Header 2"),
                ("###", "Header 3"),
            ],
            strip_headers=False,
        )

    def split(self, text: str) -> list[Chunk]:
        """Split Markdown text into contextually-enriched chunks.

        The splitting strategy is adaptive:

        1. Empty text returns an empty list
        2. YAML frontmatter is stripped and used for context enrichment
        3. If total tokens <= max_chunk_size, returns the entire text as one chunk
        4. Otherwise, splits by Markdown headers (## and ###), preserving structure

        Headers are not stripped from the chunks, allowing readers to understand
        the context and hierarchy of each chunk. Each chunk receives a
        ``metadata["context"]`` field containing a structured description of
        where the chunk sits within the document.

        Args:
            text: The Markdown text to split. Will be stripped of leading/trailing
                whitespace. YAML frontmatter will be removed from chunk text.

        Returns:
            A list of Chunk objects, each containing:

            - text: The chunk content (including headers, excluding frontmatter)
            - token_count: The number of tokens in the chunk
            - metadata: Dict with a ``"context"`` key containing structural context

        Example:
            >>> splitter = MarkdownSplitter(max_chunk_size=100)
            >>> markdown = '''
            ... ## Introduction
            ... This is the intro section.
            ...
            ... ### Background
            ... Some background information here.
            ...
            ... ## Methods
            ... Description of methods used.
            ... '''
            >>> chunks = splitter.split(markdown)
            >>> print(f"Created {len(chunks)} chunks")
            >>> print(chunks[0].metadata["context"])
        """
        text = text.strip()
        if not text:
            return []

        frontmatter, text = self._strip_frontmatter(text)
        text = text.strip()
        if not text:
            return []

        doc_title = self._resolve_title(frontmatter, text)

        total_tokens = self.count_tokens(text)
        if total_tokens <= self.max_chunk_size:
            context = self._build_context(doc_title, frontmatter, {})
            return [
                Chunk(
                    text=text,
                    token_count=total_tokens,
                    metadata={"context": context},
                )
            ]

        chunks: list[Chunk] = []
        for doc in self._splitter.split_text(text):
            context = self._build_context(doc_title, frontmatter, doc.metadata)
            chunks.append(
                Chunk(
                    text=doc.page_content,
                    token_count=self.count_tokens(doc.page_content),
                    metadata={"context": context},
                )
            )

        return chunks

    def can_handle(self, text: str) -> bool:
        """Determine if this splitter can handle the given text.

        Analyzes the text content to detect if it contains Markdown formatting
        by searching for common Markdown patterns. Uses a scoring system that
        requires multiple different Markdown indicators to be present to avoid
        false positives from plain text.

        The method checks for these Markdown indicators:
        - Headers (# ## ### etc.)
        - Code blocks (```)
        - Links ([text](url))
        - Bold text (**text**)
        - Unordered lists (- * +)
        - Ordered lists (1. 2. 3.)

        Args:
            text: The text content to analyze for Markdown patterns.

        Returns:
            True if 2 or more different Markdown patterns are found, indicating
            this is likely a Markdown document. False otherwise.

        Note:
            The threshold of 2+ patterns helps avoid false positives. Real Markdown
            documents typically contain multiple formatting features (e.g., headers
            and lists, or headers and code blocks), while plain text might
            accidentally match a single pattern.

        Example:
            >>> splitter = MarkdownSplitter()
            >>> markdown_text = "## Title\\n\\nSome content\\n\\n- List item"
            >>> splitter.can_handle(markdown_text)
            True
            >>> plain_text = "Just some plain text content"
            >>> splitter.can_handle(plain_text)
            False
        """
        score = 0
        for pattern in self._MARKDOWN_INDICATORS:
            if re.search(pattern, text, re.MULTILINE):
                score += 1

        return score >= 2

    def _strip_frontmatter(self, text: str) -> tuple[Mapping[str, Any], str]:
        """Extract and remove YAML frontmatter from the text.

        Returns:
            A tuple of (parsed frontmatter dict, remaining text).
            If no valid frontmatter is found, returns an empty dict and the
            original text unchanged.
        """
        match = self._FRONTMATTER_PATTERN.match(text)
        if not match:
            return {}, text

        try:
            parsed = yaml.safe_load(match.group(1))
        except yaml.YAMLError:
            return {}, text

        if not isinstance(parsed, dict):
            return {}, text

        remaining = text[match.end():]
        return parsed, remaining

    def _resolve_title(self, frontmatter: Mapping[str, Any], text: str) -> str | None:
        """Resolve the document title from frontmatter or the first H1 heading."""
        fm_title = frontmatter.get("title")
        if isinstance(fm_title, str) and (title := fm_title.strip()):
            return title

        match = self._H1_PATTERN.search(text)
        return match.group(1).strip() if match else None

    def _build_context(
        self,
        doc_title: str | None,
        frontmatter: Mapping[str, Any],
        header_metadata: Mapping[str, str],
    ) -> str:
        """Build a context string from document structure and frontmatter.

        Args:
            doc_title: The document title, or None.
            frontmatter: Parsed YAML frontmatter dict.
            header_metadata: Header hierarchy from MarkdownHeaderTextSplitter,
                e.g. ``{"Header 2": "Installation", "Header 3": "Prerequisites"}``.

        Returns:
            A context string like
            ``'Document: API Guide | Tags: auth, rest | Section: Auth > Tokens'``.
        """
        parts: list[str] = []

        if doc_title:
            parts.append(f"Document: {doc_title}")

        for key in self._CONTEXT_FRONTMATTER_KEYS:
            value = frontmatter.get(key)
            if not value:
                continue
            label = key.replace("_", " ").title()
            if isinstance(value, list):
                parts.append(f"{label}: {', '.join(str(v) for v in value)}")
            else:
                parts.append(f"{label}: {value}")

        breadcrumb_parts = [
            header_metadata[key]
            for key in ("Header 2", "Header 3")
            if key in header_metadata
        ]
        if breadcrumb_parts:
            parts.append(f"Section: {' > '.join(breadcrumb_parts)}")

        return " | ".join(parts) if parts else ""
