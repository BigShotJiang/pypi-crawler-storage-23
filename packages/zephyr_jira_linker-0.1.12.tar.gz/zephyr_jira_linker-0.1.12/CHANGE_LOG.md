# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.9] - 2026-02-15

### Added

- README documentation for programmatic APIs: `update_test_case(testcase_info, status=..., test_type=..., labels=...)`, `get_testcase_labels(testcase_id)`, `update_testcase_labels(testcase_id, labels)`.
- PyPI publishing instructions in Development section.

## [0.1.8] - 2026-02-15

### Added

- `get_test_status(issue_key)` — Returns a formatted summary of all test cases linked to a Jira issue (ID, name, status, test method, type, component, script type).
- `get_testcase_summary(testcase_id)` — Helper returning a summary dict for a test case for use in status reports.
- Comprehensive docstring for `get_testcase_info()` describing return fields and usage.

### Changed

- README, version, and changelog updated; project prepared for PyPI upload.

## [0.1.7] - 2026-02-14

### Changed

- Internal/version alignment (see 0.1.6).

## [0.1.6] - 2026-02-08

### Changed

- Approve all test cases linked to the issue using --approve tag

## [0.1.5] - 2026-02-08

### Changed

- Timestamp fixes

## [0.1.4] - 2026-02-08

### Changed

- Version bump.

## [0.1.3] - 2026-02-08

### Added

- `--testcases` option to return linked test cases for a ticket (issue key).

## [0.1.2] - 2025-01-06

### Fixed

- Fixed bug where providing direct issue keys (e.g., `IDAK-4020`) would fail with "Invalid issue key format" error
- Corrected global `project_key` variable handling in main function and branch processing

### Added

- Improved project key extraction and validation for direct issue key inputs
- Better global variable management across function scopes

## [0.1.1] - 2025-01-06

### Fixed

- Minor bug fixes and improvements

## [0.1.0] - 2025-01-06

### Added

- Initial release of Zephyr Test Linker
- Automatic extraction of Jira issue keys from Git branch names
- Test case ID extraction from Jira issue descriptions using regex patterns
- Integration with Zephyr Scale API for linking test cases to Jira issues
- Automatic updating of Jira custom fields ('Link to Test Case' and 'Code Changes')
- Comprehensive logging system with file and console output
- Robust error handling and retry logic for API calls
- Command-line interface with proper argument parsing
- Package structure for PyPI distribution
- Support for environment variable configuration
- Branch name validation and issue existence verification

### Features

- Extracts test case IDs using pattern `\b([A-Z]+-T\d+)\b`
- Handles multiple test cases per issue
- Updates 'Link to Test Case' field with first linked test case URL
- Updates 'Code Changes' field with implementation details
- Validates all links and field updates
- Provides detailed progress logging
- Supports Dependabot branch skipping

### Technical Details

- Python 3.7+ compatibility
- Uses `requests` library for API calls
- Implements rotating file logging (10MB max, 5 backups)
- Includes proper exception handling and user-friendly error messages
- Supports both URL and object field types for test case links

### Configuration

- Environment variables for Jira and Zephyr Scale authentication
- Configurable custom field IDs
- Flexible project key detection from branch names

## [Unreleased]

### Planned

- Add unit tests
- Add CI/CD pipeline
- Add more configuration options
- Support for additional Jira field types
- Batch processing for multiple branches
- Integration with popular CI/CD platforms
