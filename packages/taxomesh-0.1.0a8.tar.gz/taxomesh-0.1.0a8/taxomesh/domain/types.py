from typing import TypeAlias
from uuid import UUID

ExternalId: TypeAlias = str | int | UUID
