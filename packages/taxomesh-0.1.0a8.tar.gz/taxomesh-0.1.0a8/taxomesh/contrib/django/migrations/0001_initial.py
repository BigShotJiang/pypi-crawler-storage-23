import uuid

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="CategoryModel",
            fields=[
                ("category_id", models.UUIDField(default=uuid.uuid4, primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=256)),
                ("description", models.CharField(blank=True, default="", max_length=100000)),
                ("enabled", models.BooleanField(default=True)),
                ("external_id", models.CharField(blank=True, default="", max_length=256)),
                ("slug", models.CharField(blank=True, db_index=True, default="", max_length=256)),
                ("metadata", models.JSONField(blank=True, default=dict)),
            ],
            options={
                "verbose_name": "Category",
                "verbose_name_plural": "Categories",
                "db_table": "taxomesh_category",
                "constraints": [
                    models.UniqueConstraint(
                        fields=["slug"],
                        condition=~models.Q(slug=""),
                        name="taxomesh_category_slug_unique_nonempty",
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="ItemModel",
            fields=[
                ("item_id", models.UUIDField(default=uuid.uuid4, primary_key=True, serialize=False)),
                ("name", models.CharField(blank=True, default="", max_length=256)),
                ("external_id", models.CharField(max_length=256)),
                ("slug", models.CharField(blank=True, db_index=True, default="", max_length=256)),
                ("enabled", models.BooleanField(default=True)),
                ("metadata", models.JSONField(blank=True, default=dict)),
            ],
            options={
                "verbose_name": "Item",
                "verbose_name_plural": "Items",
                "db_table": "taxomesh_item",
                "constraints": [
                    models.UniqueConstraint(
                        fields=["slug"],
                        condition=~models.Q(slug=""),
                        name="taxomesh_item_slug_unique_nonempty",
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="TagModel",
            fields=[
                ("tag_id", models.UUIDField(primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=25)),
                ("metadata", models.JSONField(default=dict)),
            ],
            options={
                "verbose_name": "Tag",
                "verbose_name_plural": "Tags",
                "db_table": "taxomesh_tag",
            },
        ),
        migrations.CreateModel(
            name="CategoryParentLinkModel",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sort_index", models.IntegerField(default=0)),
                (
                    "category",
                    models.ForeignKey(
                        db_column="category_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="parent_links",
                        to="taxomesh_contrib_django.categorymodel",
                    ),
                ),
                (
                    "parent_category",
                    models.ForeignKey(
                        db_column="parent_category_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="child_links",
                        to="taxomesh_contrib_django.categorymodel",
                    ),
                ),
            ],
            options={
                "db_table": "taxomesh_category_parent_link",
                "unique_together": {("category", "parent_category")},
            },
        ),
        migrations.CreateModel(
            name="ItemParentLinkModel",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sort_index", models.IntegerField(default=0)),
                (
                    "category",
                    models.ForeignKey(
                        db_column="category_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="item_links",
                        to="taxomesh_contrib_django.categorymodel",
                    ),
                ),
                (
                    "item",
                    models.ForeignKey(
                        db_column="item_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="category_links",
                        to="taxomesh_contrib_django.itemmodel",
                    ),
                ),
            ],
            options={
                "db_table": "taxomesh_item_parent_link",
                "unique_together": {("item", "category")},
            },
        ),
        migrations.CreateModel(
            name="ItemTagLinkModel",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "item",
                    models.ForeignKey(
                        db_column="item_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="tag_links",
                        to="taxomesh_contrib_django.itemmodel",
                    ),
                ),
                (
                    "tag",
                    models.ForeignKey(
                        db_column="tag_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="item_links",
                        to="taxomesh_contrib_django.tagmodel",
                    ),
                ),
            ],
            options={
                "db_table": "taxomesh_item_tag_link",
                "unique_together": {("tag", "item")},
            },
        ),
        migrations.CreateModel(
            name="CategoryGraphProxy",
            fields=[],
            options={
                "verbose_name": "Graph",
                "verbose_name_plural": " Graph",
                "proxy": True,
                "indexes": [],
                "constraints": [],
            },
            bases=("taxomesh_contrib_django.categorymodel",),
        ),
    ]
