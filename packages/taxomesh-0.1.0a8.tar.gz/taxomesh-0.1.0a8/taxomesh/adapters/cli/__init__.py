"""CLI adapter package for taxomesh."""
