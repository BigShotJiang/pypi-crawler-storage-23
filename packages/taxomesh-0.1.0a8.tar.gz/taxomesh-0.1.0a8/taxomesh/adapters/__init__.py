"""taxomesh.adapters — Concrete adapters for storage and REST views."""
