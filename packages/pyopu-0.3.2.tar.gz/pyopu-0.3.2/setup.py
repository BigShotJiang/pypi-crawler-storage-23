from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyopu",
    version="0.3.2",
    author="Neuroqudit Research & Development",
    description="Organoid Processing Unit (OPU) framework with NeoCode Compiler for High-Order Tensor support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.20.0",
        "brian2>=2.5.0",
        "matplotlib>=3.3.0",
        "networkx>=2.5"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
    ],
    python_requires='>=3.8',
)
