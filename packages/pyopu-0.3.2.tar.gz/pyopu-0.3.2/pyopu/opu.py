from pyopu.engine import TensorEngine
from pyopu.interfaces.base_interface import BaseInterface
from pyopu.organoids.base_organoid import BaseOrganoid

class OPU:
    """
    Organoid Processing Unit (The Bio-Hybrid System).
    Acts as the structural container defining the physical hardware topology.
    """
    def __init__(self, tensor_engine: TensorEngine, interface: BaseInterface, organoid: BaseOrganoid):
        self.engine = tensor_engine
        self.interface = interface
        self.organoid = organoid

    def run(self, duration_ms=1000.0, dt_kernel_ms=10.0):
        """
        Powers on the OPU, delegating the execution loop to the internal Tensor Engine.
        """
        return self.engine.run_loop(
            interface=self.interface,
            organoid=self.organoid,
            duration_ms=duration_ms,
            dt_kernel_ms=dt_kernel_ms
        )
