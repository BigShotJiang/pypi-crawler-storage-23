from distutils.core import setup

setup(
    name='pyssp_standard',
    packages=['pyssp_standard'],
    version='0.9.0',
    license='MIT',
    description='Simple python package for reading, modifying and creating files, specified in the SSP Standard',
    long_description='',
    long_description_content_type='text/markdown',
    author='Fredrik Haider',
    author_email='',
    url='https://github.com/pyssporg/pyssp_standard',
    download_url='https://github.com/pyssporg/pyssp_standard/releases/latest/',
    keywords=['SSP', 'system', 'engineering'],
    install_requires=[
        'lxml',
        'xmlschema',
        'pint',
    ],
    package_data={"pyssp_standard": ["resources/*.xsd", "resources/fmi30/*.xsd", "resources/ssp2/*.xsd"]},
    classifiers=[
        'Development Status :: 3 - Alpha',
        # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
)
