""".. include:: ../README.md"""

from interactiveai.version import __version__

from interactiveai.batch_evaluation import (
    BatchEvaluationResult,
    BatchEvaluationResumeToken,
    CompositeEvaluatorFunction,
    EvaluatorInputs,
    EvaluatorStats,
    MapperFunction,
)
from interactiveai.experiment import Evaluation

from .model import (
    GlossaryContent,
    GlossaryEntry,
    GlossaryPromptClient,
    GuidelineEntry,
    GuidelinePromptClient,
    GuidelinesContent,
    RoutineContent,
    RoutinePromptClient,
    RoutineStep,
    VariableEntry,
    VariablePromptClient,
    VariablesContent,
)

from ._client import client as _client_module
from ._client.attributes import InteractiveAIOtelSpanAttributes
from ._client.constants import ObservationTypeLiteral
from ._client.get_client import get_client
from ._client.observe import observe
from ._client.propagation import propagate_attributes
from ._client.span import (
    InteractiveAIAgent,
    InteractiveAIChain,
    InteractiveAIEmbedding,
    InteractiveAIEvaluator,
    InteractiveAIEvent,
    InteractiveAIGeneration,
    InteractiveAIGuardrail,
    InteractiveAIRetriever,
    InteractiveAISpan,
    InteractiveAITool,
)

Interactive = _client_module.Interactive
InteractiveAI = Interactive  # backward-compat alias

__all__ = [
    "Interactive",
    "get_client",
    "observe",
    "propagate_attributes",
    "ObservationTypeLiteral",
    "InteractiveAISpan",
    "InteractiveAIGeneration",
    "InteractiveAIEvent",
    "InteractiveAIOtelSpanAttributes",
    "InteractiveAIAgent",
    "InteractiveAITool",
    "InteractiveAIChain",
    "InteractiveAIEmbedding",
    "InteractiveAIEvaluator",
    "InteractiveAIRetriever",
    "InteractiveAIGuardrail",
    "Evaluation",
    "EvaluatorInputs",
    "MapperFunction",
    "CompositeEvaluatorFunction",
    "EvaluatorStats",
    "BatchEvaluationResumeToken",
    "BatchEvaluationResult",
    "RoutineStep",
    "RoutineContent",
    "RoutinePromptClient",
    "GuidelineEntry",
    "GuidelinesContent",
    "GuidelinePromptClient",
    "VariableEntry",
    "VariablesContent",
    "VariablePromptClient",
    "GlossaryEntry",
    "GlossaryContent",
    "GlossaryPromptClient",
    "__version__",
    "experiment",
    "api",
    "platform",
]
