"""Exception classes for the InteractiveAI platform API."""

from typing import Any, Dict, Optional


class PlatformAPIError(Exception):
    """Base exception for platform API errors.

    Attributes:
        message: Human-readable error message.
        status_code: HTTP status code from the API response.
        code: Optional error code from the API.
        details: Additional error details from the API.
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize a PlatformAPIError.

        Args:
            message: Human-readable error message.
            status_code: HTTP status code from the API response.
            code: Optional error code from the API.
            details: Additional error details from the API.
        """
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.details = details or {}

    def __str__(self) -> str:
        """Return string representation of the error."""
        return f"{self.message} (status_code={self.status_code}, code={self.code})"


class AuthenticationError(PlatformAPIError):
    """Raised when authentication fails (HTTP 401)."""

    pass


class ForbiddenError(PlatformAPIError):
    """Raised when access is forbidden (HTTP 403)."""

    pass


class NotFoundError(PlatformAPIError):
    """Raised when a resource is not found (HTTP 404)."""

    pass


class ConflictError(PlatformAPIError):
    """Raised when there is a conflict (HTTP 409)."""

    pass


class DeploymentHostError(PlatformAPIError):
    """Raised when there is a deployment host error (HTTP 502)."""

    pass


def raise_for_status(status_code: int, response_body: Dict[str, Any]) -> None:
    """Raise an appropriate exception based on HTTP status code.

    Args:
        status_code: The HTTP status code from the response.
        response_body: The parsed JSON response body.

    Raises:
        AuthenticationError: For 401 responses.
        ForbiddenError: For 403 responses.
        NotFoundError: For 404 responses.
        ConflictError: For 409 responses.
        DeploymentHostError: For 502 responses.
        PlatformAPIError: For other 4xx/5xx responses.
    """
    if status_code < 400:
        return

    message = response_body.get("message", response_body.get("error", "Unknown error"))
    code = response_body.get("code")
    details = response_body.get("details")

    exception_map = {
        401: AuthenticationError,
        403: ForbiddenError,
        404: NotFoundError,
        409: ConflictError,
        502: DeploymentHostError,
    }

    exception_class = exception_map.get(status_code, PlatformAPIError)
    raise exception_class(
        message=message,
        status_code=status_code,
        code=code,
        details=details,
    )
