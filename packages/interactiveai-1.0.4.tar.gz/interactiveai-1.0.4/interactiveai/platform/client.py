"""Platform API client for InteractiveAI."""

import base64
from typing import Any, Dict, Optional

import httpx

from interactiveai.logger import interactiveai_logger

from .exceptions import raise_for_status
from .secrets import SecretsManager


class PlatformClient:
    """Client for interacting with the InteractiveAI platform API.

    Provides access to platform features like secrets management. The client
    automatically discovers the organization and project IDs from API key
    validation on first use.

    This client is async-only and should be used with `await` for all operations.

    Attributes:
        API_VERSION: The platform API version being used.
        API_BASE: The base path for platform API endpoints.

    Example:
        ```python
        async with PlatformClient(
            public_key="pk_...",
            secret_key="sk_...",
            host="https://dev.interactive.ai"
        ) as client:
            secrets = await client.secrets.list()
        ```
    """

    API_VERSION = "v1"
    API_BASE = f"/api/platform/{API_VERSION}"

    def __init__(
        self,
        public_key: str,
        secret_key: str,
        host: str,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the PlatformClient.

        Args:
            public_key: InteractiveAI public API key.
            secret_key: InteractiveAI secret API key.
            host: The InteractiveAI API host URL.
            timeout: Request timeout in seconds. Defaults to 30.0.
        """
        self._public_key = public_key
        self._secret_key = secret_key
        self._host = host.rstrip("/")
        self._timeout = timeout

        self._org_id: Optional[str] = None
        self._project_id: Optional[str] = None
        self._http_client: Optional[httpx.AsyncClient] = None
        self._secrets: Optional[SecretsManager] = None
        self._initialized = False

    def _build_path(self, *segments: str) -> str:
        """Build API path with version prefix and project context."""
        base = (
            f"{self.API_BASE}/organizations/{self._org_id}/projects/{self._project_id}"
        )
        if segments:
            return f"{base}/{'/'.join(segments)}"
        return base

    def _build_global_path(self, *segments: str) -> str:
        """Build API path without project context."""
        if segments:
            return f"{self.API_BASE}/{'/'.join(segments)}"
        return self.API_BASE

    def _get_auth_header(self) -> str:
        credentials = f"{self._public_key}:{self._secret_key}"
        encoded = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded}"

    async def _ensure_initialized(self) -> None:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=self._timeout)

        if self._initialized:
            return

        interactiveai_logger.debug(
            "Initializing platform client, discovering org_id and project_id"
        )
        response = await self._http_client.get(
            f"{self._host}{self._build_global_path('projects')}",
            headers={"Authorization": self._get_auth_header()},
        )

        body = response.json()
        raise_for_status(response.status_code, body)

        project_data = body["data"][0]
        self._org_id = project_data["orgId"]
        self._project_id = project_data["id"]
        self._initialized = True

        interactiveai_logger.debug(
            f"Platform client initialized: org_id={self._org_id}, project_id={self._project_id}"
        )

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        await self._ensure_initialized()

        if self._http_client is None:
            http_client_error = "HTTP client not initialized"
            raise RuntimeError(http_client_error)

        url = f"{self._host}{path}"
        interactiveai_logger.debug(f"Platform API request: {method} {path}")

        response = await self._http_client.request(
            method=method,
            url=url,
            headers={"Authorization": self._get_auth_header()},
            json=json,
        )

        body = response.json() if response.content else {}
        raise_for_status(response.status_code, body)
        return body

    @property
    def secrets(self) -> SecretsManager:
        """Access the secrets manager for CRUD operations on secrets."""
        if self._secrets is None:
            self._secrets = SecretsManager(self)
        return self._secrets

    async def __aenter__(self) -> "PlatformClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager and close resources."""
        await self.close()

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
