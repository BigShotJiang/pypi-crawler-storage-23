"""Shared context passed to domain service clients.

SharedContext is a dataclass that bundles the infrastructure every
domain client needs (API clients, caches, etc.) without coupling them to
the Interactive facade or to each other.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from interactiveai._client.resource_manager import InteractiveAIResourceManager
from interactiveai._utils.prompt_cache import PromptCache


@dataclass
class SharedContext:
    """Bag of dependencies injected into domain service clients."""

    api: Any
    async_api: Any
    resources: Optional[InteractiveAIResourceManager]
    base_url: str = ""
    tracing_enabled: bool = False
    environment: Optional[str] = None

    @property
    def prompt_cache(self) -> PromptCache:
        if self.resources is None:
            raise RuntimeError(
                "SDK is not correctly initialized. Check the init logs for more details."
            )
        return self.resources.prompt_cache
