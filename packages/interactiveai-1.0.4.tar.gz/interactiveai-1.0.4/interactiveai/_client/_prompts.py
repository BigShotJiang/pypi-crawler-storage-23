"""Prompts domain service.

Contains all prompt-related business logic: get, create, update, delete,
list, cache clearing, and background refresh.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Type, Union, cast, overload

import backoff

from interactiveai._client._context import SharedContext
from interactiveai._client._helpers import get_bounded_max_retries, url_encode
from interactiveai._utils.prompt_cache import PromptCache
from interactiveai._utils.parse_error import handle_fern_exception
from interactiveai.api.resources.commons.errors.error import Error
from interactiveai.api.resources.commons.errors.not_found_error import NotFoundError
from interactiveai.api.resources.prompts.types import (
    CreatePromptRequest_Chat,
    CreatePromptRequest_Text,
    Prompt_Chat,
    Prompt_Text,
    PromptMetaListResponse,
)
from interactiveai.logger import interactiveai_logger
from interactiveai.model import (
    ChatMessageDict,
    ChatMessageWithPlaceholdersDict,
    ChatPromptClient,
    GlossaryPromptClient,
    GuidelinePromptClient,
    PromptClient,
    RoutinePromptClient,
    StructuredPromptClient,
    TextPromptClient,
    VariablePromptClient,
    PromptType,
)

# Module-level dispatch: structured prompt type -> client class.
# Used by create(), _fetch_and_update_cache(), and validation.
_STRUCTURED_CLIENT_MAP: Dict[str, Type[StructuredPromptClient]] = {
    "routine": RoutinePromptClient,
    "guideline": GuidelinePromptClient,
    "variable": VariablePromptClient,
    "glossary": GlossaryPromptClient,
}


class PromptsClient:
    """Domain service encapsulating all prompt operations."""

    def __init__(self, context: SharedContext) -> None:
        self._ctx = context

    # -- public API -----------------------------------------------------------

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["chat"],
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[List[ChatMessageDict]] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> ChatPromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["text"] = "text",
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[str] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> TextPromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["routine"],
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[str] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> RoutinePromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["guideline"],
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[str] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> GuidelinePromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["variable"],
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[str] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> VariablePromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: Literal["glossary"],
        cache_ttl_seconds: Optional[int] = None,
        fallback: Optional[str] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> GlossaryPromptClient: ...

    def get(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        type: PromptType = "text",
        cache_ttl_seconds: Optional[int] = None,
        fallback: Union[Optional[List[ChatMessageDict]], Optional[str]] = None,
        max_retries: Optional[int] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> PromptClient:
        """Get a prompt.

        This method attempts to fetch the requested prompt from the local cache. If the prompt is not found
        in the cache or if the cached prompt has expired, it will try to fetch the prompt from the server again
        and update the cache. If fetching the new prompt fails, and there is an expired prompt in the cache, it will
        return the expired prompt as a fallback.

        Args:
            name (str): The name of the prompt to retrieve.

        Keyword Args:
            version (Optional[int]): The version of the prompt to retrieve. If no label and version is specified, the `production` label is returned. Specify either version or label, not both.
            label: Optional[str]: The label of the prompt to retrieve. If no label and version is specified, the `production` label is returned. Specify either version or label, not both.
            cache_ttl_seconds: Optional[int]: Time-to-live in seconds for caching the prompt. Must be specified as a
            keyword argument. If not set, defaults to 60 seconds. Disables caching if set to 0.
            type: PromptType: The type of the prompt to retrieve. Defaults to "text". Structured types ("routine", "guideline", "variable", "glossary") parse the text content as YAML/JSON.
            fallback: Union[Optional[List[ChatMessageDict]], Optional[str]]: The prompt string to return if fetching the prompt fails. Important on the first call where no cached prompt is available. For structured types, the fallback must be valid YAML/JSON matching the expected schema. Defaults to None.
            max_retries: Optional[int]: The maximum number of retries in case of API/network errors. Defaults to 2. The maximum value is 4. Retries have an exponential backoff with a maximum delay of 10 seconds.
            fetch_timeout_seconds: Optional[int]: The timeout in seconds for fetching the prompt. Defaults to the default timeout set on the SDK, which is 5 seconds per default.

        Returns:
            The prompt object retrieved from the cache or directly fetched if not cached or expired of type
            - TextPromptClient, if type argument is 'text'.
            - ChatPromptClient, if type argument is 'chat'.
            - RoutinePromptClient, if type argument is 'routine'.
            - GuidelinePromptClient, if type argument is 'guideline'.
            - VariablePromptClient, if type argument is 'variable'.
            - GlossaryPromptClient, if type argument is 'glossary'.

        Raises:
            Exception: Propagates any exceptions raised during the fetching of a new prompt, unless there is an
            expired prompt in the cache, in which case it logs a warning and returns the expired prompt.
        """
        if self._ctx.resources is None:
            raise Error(
                "SDK is not correctly initialized. Check the init logs for more details."
            )
        if version is not None and label is not None:
            raise ValueError("Cannot specify both version and label at the same time.")

        if not name:
            raise ValueError("Prompt name cannot be empty.")

        cache_key = PromptCache.generate_cache_key(
            name, version=version, label=label, target_type=type
        )
        bounded_max_retries = get_bounded_max_retries(
            max_retries, default_max_retries=2, max_retries_upper_bound=4
        )

        interactiveai_logger.debug(f"Getting prompt '{cache_key}'")
        cached_prompt = self._ctx.prompt_cache.get(cache_key)

        if cached_prompt is None or cache_ttl_seconds == 0:
            interactiveai_logger.debug(
                f"Prompt '{cache_key}' not found in cache or caching disabled."
            )
            try:
                return self._fetch_and_update_cache(
                    name,
                    version=version,
                    label=label,
                    ttl_seconds=cache_ttl_seconds,
                    max_retries=bounded_max_retries,
                    fetch_timeout_seconds=fetch_timeout_seconds,
                    target_type=type,
                )
            except Exception as e:
                if fallback:
                    interactiveai_logger.warning(
                        f"Returning fallback prompt for '{cache_key}' due to fetch error: {e}"
                    )

                    fallback_prompt_args: Dict[str, Any] = {
                        "name": name,
                        "prompt": fallback,
                        "type": type if type in ("text", "chat") else "text",
                        "version": version or 0,
                        "config": {},
                        "labels": [label] if label else [],
                        "tags": [],
                    }

                    structured_cls = _STRUCTURED_CLIENT_MAP.get(type)
                    if structured_cls:
                        try:
                            return structured_cls(  # type: ignore[return-value]
                                prompt=Prompt_Text(**fallback_prompt_args),
                                is_fallback=True,
                            )
                        except (ValueError, TypeError) as parse_err:
                            fallback_warning = f"Fallback for '{name}' is not valid {type} content: {parse_err}"
                            interactiveai_logger.warning(fallback_warning)
                            raise e
                    if type == "chat":
                        return ChatPromptClient(
                            prompt=Prompt_Chat(**fallback_prompt_args),
                            is_fallback=True,
                        )
                    if type == "text":
                        return TextPromptClient(
                            prompt=Prompt_Text(**fallback_prompt_args),
                            is_fallback=True,
                        )

                raise e

        if cached_prompt.is_expired():
            interactiveai_logger.debug(f"Stale prompt '{cache_key}' found in cache.")
            try:
                interactiveai_logger.debug(
                    f"Refreshing prompt '{cache_key}' in background."
                )

                def refresh_task() -> None:
                    self._fetch_and_update_cache(
                        name,
                        version=version,
                        label=label,
                        ttl_seconds=cache_ttl_seconds,
                        max_retries=bounded_max_retries,
                        fetch_timeout_seconds=fetch_timeout_seconds,
                        target_type=type,
                    )

                self._ctx.prompt_cache.add_refresh_prompt_task(
                    cache_key,
                    refresh_task,
                )
                interactiveai_logger.debug(
                    f"Returning stale prompt '{cache_key}' from cache."
                )
                return cached_prompt.value

            except Exception as e:
                interactiveai_logger.warning(
                    f"Error when refreshing cached prompt '{cache_key}', returning cached version. Error: {e}"
                )
                return cached_prompt.value

        return cached_prompt.value

    def create(
        self,
        *,
        name: str,
        prompt: Union[
            str, List[Union[ChatMessageDict, ChatMessageWithPlaceholdersDict]]
        ],
        labels: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        type: Optional[PromptType] = "text",
        config: Optional[Any] = None,
        commit_message: Optional[str] = None,
    ) -> PromptClient:
        """Create a new prompt in InteractiveAI.

        Keyword Args:
            name : The name of the prompt to be created.
            prompt : The content of the prompt to be created.
            is_active [DEPRECATED] : A flag indicating whether the prompt is active or not. This is deprecated and will be removed in a future release. Please use the 'production' label instead.
            labels: The labels of the prompt. Defaults to None. To create a default-served prompt, add the 'production' label.
            tags: The tags of the prompt. Defaults to None. Will be applied to all versions of the prompt.
            config: Additional structured data to be saved with the prompt. Defaults to None.
            type: The type of the prompt to be created. Defaults to "text".
            commit_message: Optional string describing the change.

        Returns:
            TextPromptClient: The prompt if type argument is 'text'.
            ChatPromptClient: The prompt if type argument is 'chat'.
            RoutinePromptClient: The prompt if type argument is 'routine'.
            GuidelinePromptClient: The prompt if type argument is 'guideline'.
            VariablePromptClient: The prompt if type argument is 'variable'.
            GlossaryPromptClient: The prompt if type argument is 'glossary'.
        """
        try:
            interactiveai_logger.debug(f"Creating prompt {name=}, {labels=}")

            if type == "chat":
                if not isinstance(prompt, list):
                    raise ValueError(
                        "For 'chat' type, 'prompt' must be a list of chat messages with role and content attributes."
                    )
                request: Union[CreatePromptRequest_Chat, CreatePromptRequest_Text] = (
                    CreatePromptRequest_Chat(
                        name=name,
                        prompt=cast(Any, prompt),
                        labels=labels,
                        tags=tags,
                        config=config or {},
                        commitMessage=commit_message,
                        type="chat",
                    )
                )
                server_prompt = self._ctx.api.prompts.create(request=request)

                if self._ctx.resources is not None:
                    self._ctx.resources.prompt_cache.invalidate(name)

                return ChatPromptClient(prompt=cast(Prompt_Chat, server_prompt))

            if not isinstance(prompt, str):
                msg = f"For '{type}' type, 'prompt' must be a string."
                raise ValueError(msg)

            # Validate structured content on create (fail fast).
            # The parse result is discarded — the PromptClient constructor
            # will re-parse from the server response, which is the source of truth.
            structured_cls = _STRUCTURED_CLIENT_MAP.get(type or "text")
            if structured_cls:
                structured_cls._parse(prompt, name)

            request = CreatePromptRequest_Text(
                name=name,
                prompt=prompt,
                labels=labels or [],
                tags=tags,
                config=config or {},
                commitMessage=commit_message,
                type="text",  # Structured prompts are stored as plain text on the server
            )

            server_prompt = self._ctx.api.prompts.create(request=request)

            if self._ctx.resources is not None:
                self._ctx.resources.prompt_cache.invalidate(name)

            client_cls = _STRUCTURED_CLIENT_MAP.get(type or "text", TextPromptClient)
            return client_cls(prompt=cast(Prompt_Text, server_prompt))  # type: ignore[return-value]

        except Error as e:
            handle_fern_exception(e)
            raise e

    def update(
        self,
        *,
        name: str,
        version: int,
        new_labels: Optional[List[str]] = None,
    ) -> Any:
        """Update an existing prompt version in InteractiveAI. The InteractiveAI SDK prompt cache is invalidated for all prompts with the specified name.

        Args:
            name (str): The name of the prompt to update.
            version (int): The version number of the prompt to update.
            new_labels (List[str], optional): New labels to assign to the prompt version. Labels are unique across versions. The "latest" label is reserved and managed by InteractiveAI. Defaults to [].

        Returns:
            Prompt: The updated prompt from the InteractiveAI API.

        """
        updated_prompt = self._ctx.api.prompt_version.update(
            name=url_encode(name),
            version=version,
            new_labels=new_labels or [],
        )

        if self._ctx.resources is not None:
            self._ctx.resources.prompt_cache.invalidate(name)

        return updated_prompt

    def clear_cache(self) -> None:
        """Clear the entire prompt cache, removing all cached prompts.

        This method is useful when you want to force a complete refresh of all
        cached prompts, for example after major updates or when you need to
        ensure the latest versions are fetched from the server.
        """
        if self._ctx.resources is not None:
            self._ctx.resources.prompt_cache.clear()

    def list(
        self,
        *,
        name: Optional[str] = None,
        label: Optional[str] = None,
        tag: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PromptMetaListResponse:
        """List prompts with their metadata, versions, and labels.

        Args:
            name: Optional name filter to narrow results.
            label: Optional label filter (e.g. ``"production"``).
            tag: Optional tag filter.
            page: Page number, starts at 1.
            limit: Number of items per page.

        Returns:
            PromptMetaListResponse containing:
            - ``data`` — list of ``PromptMeta`` items, each with ``name``,
              ``type`` (``"chat"`` or ``"text"``), ``versions``, ``labels``,
              ``tags``, and ``last_updated_at``.
            - ``meta`` — pagination info: ``page``, ``limit``, ``total_items``,
              ``total_pages``.

        Example:
            result = client.list_prompts(label="production", limit=20)
            for prompt in result.data:
                print(prompt.name, prompt.type, prompt.versions)
        """
        return self._ctx.api.prompts.list(  # type: ignore[no-any-return]
            name=name,
            label=label,
            tag=tag,
            page=page,
            limit=limit,
        )

    def delete(
        self,
        name: str,
        *,
        label: Optional[str] = None,
        version: Optional[int] = None,
    ) -> None:
        """Delete prompt versions and invalidate the local prompt cache.

        If neither ``version`` nor ``label`` is specified, all versions of the
        prompt are deleted.

        Args:
            name: The name of the prompt to delete.
            label: If set, deletes all versions carrying this label.
            version: If set, deletes only this specific version.

        Example:
            # Delete one version
            client.delete_prompt("my-prompt", version=3)

            # Delete all versions labelled "staging"
            client.delete_prompt("my-prompt", label="staging")

            # Delete the entire prompt
            client.delete_prompt("my-prompt")
        """
        self._ctx.api.prompts.delete(
            url_encode(name),
            label=label,
            version=version,
        )
        if self._ctx.resources is not None:
            self._ctx.resources.prompt_cache.invalidate(name)

    # -- private helpers ------------------------------------------------------

    def _fetch_and_update_cache(
        self,
        name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
        max_retries: int,
        fetch_timeout_seconds: Optional[int],
        target_type: PromptType = "text",
    ) -> PromptClient:
        cache_key = PromptCache.generate_cache_key(
            name, version=version, label=label, target_type=target_type
        )
        interactiveai_logger.debug(f"Fetching prompt '{cache_key}' from server...")

        try:

            @backoff.on_exception(
                backoff.constant, Exception, max_tries=max_retries + 1, logger=None
            )
            def fetch_prompts() -> Any:
                return self._ctx.api.prompts.get(
                    url_encode(name),
                    version=version,
                    label=label,
                    request_options={
                        "timeout_in_seconds": fetch_timeout_seconds,
                    }
                    if fetch_timeout_seconds is not None
                    else None,
                )

            prompt_response = fetch_prompts()

            prompt: PromptClient
            structured_cls = _STRUCTURED_CLIENT_MAP.get(target_type)
            if structured_cls:
                prompt = structured_cls(cast(Prompt_Text, prompt_response))  # type: ignore[assignment]
            elif prompt_response.type == "chat":
                prompt = ChatPromptClient(prompt_response)
            else:
                prompt = TextPromptClient(prompt_response)

            if self._ctx.resources is not None:
                self._ctx.resources.prompt_cache.set(cache_key, prompt, ttl_seconds)

            return prompt

        except NotFoundError as not_found_error:
            interactiveai_logger.warning(
                f"Prompt '{cache_key}' not found during refresh, evicting from cache."
            )
            if self._ctx.resources is not None:
                self._ctx.resources.prompt_cache.delete(cache_key)
            raise not_found_error

        except Exception as e:
            error_msg = str(e)
            interactiveai_logger.error(
                f"Error while fetching prompt '{cache_key}': {error_msg}"
            )
            raise e
