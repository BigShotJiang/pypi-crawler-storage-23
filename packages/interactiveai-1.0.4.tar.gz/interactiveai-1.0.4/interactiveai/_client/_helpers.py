"""Shared private helper methods used across domain mixins.

This module contains utility methods that are used by multiple domain mixins
(tracing, scoring, datasets, experiments, prompts). They are extracted here
to avoid duplication and circular dependencies.

These methods rely on instance attributes set by Interactive.__init__:
    _resources, _otel_tracer, _tracing_enabled, _base_url, _environment,
    _project_id, api, async_api
"""

from __future__ import annotations

import re
import urllib.parse
from hashlib import sha256
from typing import TYPE_CHECKING, Any, Optional

from opentelemetry import trace as otel_trace_api
from opentelemetry.sdk.trace.id_generator import RandomIdGenerator
from packaging.version import Version

import httpx

from interactiveai.logger import interactiveai_logger

if TYPE_CHECKING:
    from interactiveai._client.resource_manager import InteractiveAIResourceManager


# -- Module-level constants ---------------------------------------------------

_HTTPX_SKIPS_ENCODING = Version(httpx.__version__) >= Version("0.28.0")
_TRACE_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_SPAN_ID_RE = re.compile(r"^[0-9a-f]{16}$")


# -- Standalone helper functions used by domain services ----------------------


def url_encode(url: str, *, is_url_param: Optional[bool] = False) -> str:
    """Encode a URL string, handling httpx version differences.

    For httpx >= 0.28, skips encoding when the value will be sent directly
    to httpx (is_url_param=True), since httpx does its own WHATWG-compliant quoting.
    """
    if is_url_param and _HTTPX_SKIPS_ENCODING:
        return url

    return urllib.parse.quote(url, safe="")


def get_bounded_max_retries(
    max_retries: Optional[int],
    *,
    default_max_retries: int = 2,
    max_retries_upper_bound: int = 4,
) -> int:
    """Clamp max_retries to [0, max_retries_upper_bound], defaulting if None."""
    if max_retries is None:
        return default_max_retries

    return min(max(max_retries, 0), max_retries_upper_bound)


class _HelpersMixin:
    """Shared private helpers mixed into the Interactive class.

    Subclasses (domain mixins) can call these methods via ``self``.
    The instance attributes are set by ``Interactive.__init__``.
    """

    # -- Type stubs so mypy knows about attrs set by __init__ -----------------
    _resources: Optional[InteractiveAIResourceManager]
    _otel_tracer: otel_trace_api.Tracer
    _tracing_enabled: bool
    _base_url: str
    _environment: Optional[str]
    _project_id: Optional[str]
    api: Any
    async_api: Any

    # -- OTel ID formatting (static) -----------------------------------------

    @staticmethod
    def _format_otel_span_id(span_id_int: int) -> str:
        """Format an integer span ID to a 16-character lowercase hex string.

        Internal method to convert an OpenTelemetry integer span ID to the standard
        W3C Trace Context format (16-character lowercase hex string).

        Args:
            span_id_int: 64-bit integer representing a span ID

        Returns:
            A 16-character lowercase hexadecimal string
        """
        return format(span_id_int, "016x")

    @staticmethod
    def _format_otel_trace_id(trace_id_int: int) -> str:
        """Format an integer trace ID to a 32-character lowercase hex string.

        Internal method to convert an OpenTelemetry integer trace ID to the standard
        W3C Trace Context format (32-character lowercase hex string).

        Args:
            trace_id_int: 128-bit integer representing a trace ID

        Returns:
            A 32-character lowercase hexadecimal string
        """
        return format(trace_id_int, "032x")

    # -- OTel ID extraction from spans ----------------------------------------

    def _get_otel_trace_id(self, otel_span: otel_trace_api.Span) -> str:
        span_context = otel_span.get_span_context()

        return self._format_otel_trace_id(span_context.trace_id)

    def _get_otel_span_id(self, otel_span: otel_trace_api.Span) -> str:
        span_context = otel_span.get_span_context()

        return self._format_otel_span_id(span_context.span_id)

    # -- Current span access --------------------------------------------------

    def _get_current_otel_span(self) -> Optional[otel_trace_api.Span]:
        current_span = otel_trace_api.get_current_span()

        if current_span is otel_trace_api.INVALID_SPAN:
            interactiveai_logger.warning(
                "Context error: No active span in current context. Operations that depend on an active span will be skipped. "
                "Ensure spans are created with start_as_current_span() or that you're operating within an active span context."
            )
            return None

        return current_span

    # -- ID validation --------------------------------------------------------

    def _is_valid_trace_id(self, trace_id: str) -> bool:
        return bool(_TRACE_ID_RE.match(trace_id))

    def _is_valid_span_id(self, span_id: str) -> bool:
        return bool(_SPAN_ID_RE.match(span_id))

    # -- Observation ID generation --------------------------------------------

    def _create_observation_id(self, *, seed: Optional[str] = None) -> str:
        """Create a unique observation ID for use with InteractiveAI.

        This method generates a unique observation ID (span ID in OpenTelemetry terms)
        for use with various InteractiveAI APIs. It can either generate a random ID or
        create a deterministic ID based on a seed string.

        Observation IDs must be 16 lowercase hexadecimal characters, representing 8 bytes.
        This method ensures the generated ID meets this requirement. If you need to
        correlate an external ID with a InteractiveAI observation ID, use the external ID as
        the seed to get a valid, deterministic observation ID.

        Args:
            seed: Optional string to use as a seed for deterministic ID generation.
                 If provided, the same seed will always produce the same ID.
                 If not provided, a random ID will be generated.

        Returns:
            A 16-character lowercase hexadecimal string representing the observation ID.

        Example:
            ```python
            # Generate a random observation ID
            obs_id = interactiveai.create_observation_id()

            # Generate a deterministic ID based on a seed
            user_obs_id = interactiveai.create_observation_id(seed="user-123-feedback")

            # Correlate an external item ID with a InteractiveAI observation ID
            item_id = "item-789012"
            correlated_obs_id = interactiveai.create_observation_id(seed=item_id)

            # Use the ID with InteractiveAI APIs
            interactiveai.create_score(
                name="relevance",
                value=0.95,
                trace_id=trace_id,
                observation_id=obs_id
            )
            ```
        """
        if not seed:
            span_id_int = RandomIdGenerator().generate_span_id()

            return self._format_otel_span_id(span_id_int)

        return sha256(seed.encode("utf-8")).digest()[:8].hex()

    # -- Project ID -----------------------------------------------------------

    def _get_project_id(self) -> Optional[str]:
        """Fetch and return the current project id. Persisted across requests. Returns None if no project id is found for api keys."""
        if not self._project_id:
            proj = self.api.projects.get()
            if not proj.data or not proj.data[0].id:
                return None

            self._project_id = proj.data[0].id

        return self._project_id

    # -- URL encoding ---------------------------------------------------------

    def _url_encode(self, url: str, *, is_url_param: Optional[bool] = False) -> str:
        return url_encode(url, is_url_param=is_url_param)

    # -- Retry bounds ---------------------------------------------------------

    def _get_bounded_max_retries(
        self,
        max_retries: Optional[int],
        *,
        default_max_retries: int = 2,
        max_retries_upper_bound: int = 4,
    ) -> int:
        return get_bounded_max_retries(
            max_retries,
            default_max_retries=default_max_retries,
            max_retries_upper_bound=max_retries_upper_bound,
        )
