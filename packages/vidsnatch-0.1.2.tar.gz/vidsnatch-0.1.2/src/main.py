"""
Main entry point — delegates to the enhanced CLI.
"""

from src.cli import main

if __name__ == "__main__":
    main()
