"""Agent tools — each tool is a function + JSON schema for the LLM."""
