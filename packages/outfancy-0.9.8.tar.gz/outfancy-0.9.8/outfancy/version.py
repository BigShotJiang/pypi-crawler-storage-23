#!/usr/bin/env python3

__version__ = '0.7.0'
