from .hf_runner import HFTacticGenerator
