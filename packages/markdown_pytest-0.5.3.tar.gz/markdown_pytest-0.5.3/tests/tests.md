<!-- name: test_assert_true -->
```python
# test_assert_true
assert True
```

<!-- 
    name: test_multiline_comment_1
-->
```python
assert True
```

<!-- 
name: test_multiline_comment_2 
-->
```python
assert True
```

<!--
name: test_multiline_hidden_code_block
```python
hidden_value = 123
```
-->
```python
assert hidden_value == 123
```

<!-- name: test_with_subtests -->
```python
from collections import Counter
```

<!-- 
    name: test_with_subtests; case: counter
-->
```python
counter = Counter()
```


<!-- 
    name: test_with_subtests; case: counter_add
-->
```python
counter["foo"] = 1
```


<!--- name: test_four_backticks -->
````python
# test_four_backticks
assert True
````

Split test
----------

Part one

<!--- name: test_split -->
```python
from collections import deque

queue = deque(maxlen=2)
```

Part Two

<!--- name: test_split -->
```python
queue.append(1)

assert list(queue) == [1]
```

Part Three

<!--- name: test_split -->
```python
queue.append(2)

assert list(queue) == [1, 2]
```

Part Four

<!--- name: test_split -->
`````python
queue.append(3)
assert list(queue) == [2, 3]
`````

<!--- name: test nervous backtick -->
```````````````python
# test nervous backtick
assert True
```````````````


<!--- name: test_xfail -->
```python
from pytest import xfail

xfail("it's ok")
```


<!--- name: test_raises -->
```python
from pytest import raises

with raises(AssertionError):
    assert False
```

<!-- name: test_two_dashes_name -->
```python
assert True
```

<!--- name: test_three_dashes_name --->
```python
assert True
```

<!-- name: test_mixed_dashes_name_2_3 --->
```python
assert True
```

<!--- name: test_mixed_dashes_name_3_2 -->
```python
assert True
```

<!--- name: test_blank_line_after_comment -->

```python
assert True
```

````
<!--- name: test_will_should_newer_running -->
```python
assert False
```
````


<details>
<summary>Indented code block</summary>

    <!--- name: test_overindented -->
    ```python
    assert True
    ```

</details>

<!--- name: test_function -->
```python
def mul(*args):
    result = args[0]
    for i in args[1:]:
        result *= i
    return result
```

<!--- name: test_function; case: one argument -->
```python
assert mul(0) == 0
```

<!--- name: test_function; case: two arguments -->
```python
assert mul(1, 2) == 2
```

<!--- name: test_function; case: multiple arguments -->
```python
assert mul(*range(1, 10)) == 362880
```

Non-consecutive split test (issue #9)
--------------------------------------

This tests that code blocks with the same name are combined even when
separated by blocks with different names.

Part one: define a class

<!--- name: test_non_consecutive_split -->
```python
class ManDescription:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __repr__(self):
        return f"ManDescription(name={self.name!r}, age={self.age!r})"
```

This is a separator block with a different name:

<!--- name: test_non_consecutive_separator -->
```python
assert True
```

Part two: use the class from part one

<!--- name: test_non_consecutive_split -->
```python
description = ManDescription(name='Evgeniy', age=32)
assert description.name == 'Evgeniy'
assert description.age == 32
```

Another separator:

<!--- name: test_non_consecutive_separator_2 -->
```python
assert True
```

Part three: further operations on the object

<!--- name: test_non_consecutive_split -->
```python
assert repr(description) == "ManDescription(name='Evgeniy', age=32)"
```