from .llm_handler.llm_manager import LLMManager
from .llm_handler.llm_models import GroqModel, History
from .llm_handler.prompts import PROMPT_FOR_IMAGE_MODEL, PROMPT_FOR_TEXT_MODEL

from .utils.media_handle import encode_file


class Manager:
    def __init__(self, api_key: str):
        image_history = History(PROMPT_FOR_IMAGE_MODEL)
        image_llm_model = GroqModel(api_key=api_key, history=image_history, model_name="meta-llama/llama-4-maverick-17b-128e-instruct")
        self.image_llmm = LLMManager(image_llm_model)

        text_history = History(PROMPT_FOR_TEXT_MODEL)
        text_llm_model = GroqModel(api_key=api_key, history=text_history, model_name="openai/gpt-oss-120b")
        self.text_llmm = LLMManager(text_llm_model)

    def load_history(self, data: dict):
        self.text_llmm.llm_model.history.load_history(data)

    def send_text_message(self, message: str):
        result = self.text_llmm.get_answer(message)
        return result



if __name__ == "__main__":

    # image_history = History(PROMPT_FOR_IMAGE_MODEL)
    # image_llm_model = GroqModel(api_key=API_KEY, history=image_history, model_name="meta-llama/llama-4-maverick-17b-128e-instruct")
    # image_llmm = LLMManager(image_llm_model)

    # text_history = History(PROMPT_FOR_TEXT_MODEL)
    # text_llm_model = GroqModel(api_key=API_KEY, history=text_history, model_name="openai/gpt-oss-120b")
    # text_llmm = LLMManager(text_llm_model)

    # answer = image_llmm.get_answer([
    #     {
    #         "type": "image_url",
    #         "image_url": {
    #             "url": f"data:image/jpeg;base64,{encode_file(r"C:\Users\huina\Downloads\unnamed (12).jpg")}"
    #         }
    #     }
    # ])
    # print(answer)
    # user_prompt = """ADG абривиатура, Суть проекта в создании документации для лубого кода на любом языке програмирования автоматичски через git hub workflows или же врпучную через cmd и установкой пайтона. Цель экономия время для разрабов и удобство подключения моего движка к любому прокту через одну концоль. Результат уже готово удобное подключение черезрез командную консоль полная кастомизация через конфиг файл полностью автоматическая документация с линками Intro Text а также основной части где описывается прицип работы кода и примеры использывсания. Стиль хочу в темной теме и чтобы он был современый"""
    # answer = text_llmm.get_answer(prompt=f"""
    #     User Intent: {user_prompt}
    #     Format: A0
    # """)

    # with open(r"C:\Users\huina\Python Projects\Impotant projects\web apps\PostersCreator\test.html", "w", encoding="utf-8") as file:
    #     file.write(answer)

    # while True:
    #     us_input = input("Changes: ")
    #     answer = text_llmm.get_answer(us_input)

    #     with open(r"C:\Users\huina\Python Projects\Impotant projects\web apps\PostersCreator\test.html", "w", encoding="utf-8") as file:
    #         file.write(answer)

    # convertor = CloudConvertor("")
    # cm = ConvertorManager(convertor)
    # cm.convert(r"C:\Users\huina\Python Projects\Impotant projects\web apps\PostersCreator\test.html", "a0", "result.pdf")
    ...