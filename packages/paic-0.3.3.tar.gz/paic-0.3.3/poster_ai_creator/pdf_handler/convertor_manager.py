from .convertors import BaseConvertor



class ConvertorManager:
    def __init__(self, convertor: BaseConvertor):
        self.convertor = convertor

    def convert(self, *args, **kwargs):
        result = self.convertor.convert(*args, **kwargs)
        return result
    
    

