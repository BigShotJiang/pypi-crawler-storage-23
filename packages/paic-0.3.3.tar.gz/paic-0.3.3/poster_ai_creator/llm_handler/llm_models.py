class History:
    def __init__(self, system_prompt: str = ""):
        self._history: list = []
        if system_prompt is not None:
            self.add_to_history("system", system_prompt)

    def load_history(self, data):
        for el in data:
            self.add_to_history(el["role"], el["content"])

    @property
    def history(self):
        return self._history

    def add_to_history(self, role: str, content: str):
        self._history.append({
            "role": role,
            "content": content
        })


class BaseLLMModel():
    def __init__(self, api_key: str, history: History, model_name: str):
        self.history = history
        self.api_key = api_key
        self.model_name = model_name

    def gen_answer(self):
        ...

    def get_answer(self, prompt):
        self.history.add_to_history("user", prompt)
        model_answer = self.gen_answer()
        self.history.add_to_history("assistant", model_answer)
        return model_answer


from groq import Groq


class GroqModel(BaseLLMModel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.client = Groq(api_key=self.api_key)

    def gen_answer(self):
        try:
            chat_completion = self.client.chat.completions.create(
                    messages=self.history.history,
                    model=self.model_name,
                )
            
            result = chat_completion.choices[0].message.content
            
        except Exception as e:
            print(e)
            return ""
        
        return result



