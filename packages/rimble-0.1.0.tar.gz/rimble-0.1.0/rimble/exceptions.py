class RimbleAPIError(Exception):
    """Raised when the Rimble API returns a non-200 response."""

    def __init__(self, status_code, message=None, response=None):
        self.status_code = status_code
        self.message = message or f"API request failed with status {status_code}"
        self.response = response
        super().__init__(self.message)
