from setuptools import setup, find_packages

setup(
    name='rimble',
    version='0.1.0',
    packages=find_packages(),
    install_requires=['requests>=2.20.0'],
    python_requires='>=3.7',
    author='Rimble',
    author_email='support@rimble.io',
    description='Python SDK for the Rimble Raw Data API',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://www.rimble.io',
)
