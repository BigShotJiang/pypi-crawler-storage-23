# Rimble Python SDK

Python client for the [Rimble Raw Data API](https://www.rimble.io/docs) — real-time esports data across 10 titles.

## Installation

```bash
pip install rimble
```

## Quick Start

```python
from rimble import RimbleClient

client = RimbleClient(api_key="YOUR_API_KEY")

# Get upcoming League of Legends matches
matches = client.get_upcoming_matches("lol")
for match in matches:
    print(f"{match['team_1_name']} vs {match['team_2_name']} — {match['date']}")
```

## Filtering with Query Parameters

```python
# Filter by date
matches = client.get_upcoming_matches("csgo", date="2024-03-15")

# Filter by team
matches = client.get_upcoming_matches("valorant", team="Sentinels")

# Filter by league
matches = client.get_completed_matches("lol", league="LCS")

# Multiple filters
matches = client.get_completed_matches("dota2", date="2024-03-10", team="OG")
```

## Available Methods

| Method | Description |
|--------|-------------|
| `get_upcoming_matches(sport, **params)` | Upcoming matches |
| `get_live_matches(sport, **params)` | Currently live matches |
| `get_completed_matches(sport, **params)` | Completed matches (last 5 days) |
| `get_match_status(sport, matchid, **params)` | Status of a specific match |
| `get_league_mappings(sport, **params)` | League/tournament directory |
| `get_teams(sport, **params)` | Team directory |
| `get_players(sport, **params)` | Player directory |

## Supported Esports

`lol`, `csgo`, `dota2`, `valorant`, `rocketleague`, `cod`, `nba2k`, `fifa`, `siege`, `cricket`

## Error Handling

```python
from rimble import RimbleClient, RimbleAPIError

client = RimbleClient(api_key="YOUR_API_KEY")

try:
    matches = client.get_upcoming_matches("lol")
except RimbleAPIError as e:
    print(f"API error: {e.status_code} — {e.message}")
```

## Links

- [API Documentation](https://www.rimble.io/docs)
- [Website](https://www.rimble.io)
- [Contact](mailto:support@rimble.io)
