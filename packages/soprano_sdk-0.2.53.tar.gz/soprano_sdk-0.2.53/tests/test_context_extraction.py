"""
Tests for auto-extraction of data from workflow context.

When a previous collector node's conversation already contains the information
the current node needs, the agent should extract it directly from context
rather than asking the user again.

Covers:
- _check_context_extraction() for pattern matching mode
- _check_context_extraction() for structured output mode
- _generate_prompt() returning None on context extraction
- No extraction when agent asks a question (normal flow)
- Partial multi-field extraction (not all fields found)
- Context extraction skipped when initial_message is configured
"""

import json
from unittest.mock import MagicMock
from jinja2 import Environment
from soprano_sdk.nodes.collect_input import CollectInputStrategy


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_engine_context(**overrides):
    ctx = MagicMock()
    ctx.get_config_value.side_effect = lambda key, default=None: {
        "rollback_strategy": "history_based",
        "template_loader": Environment()
    }.get(key, default)
    ctx.data_fields = overrides.get("data_fields", [])
    ctx.workflow_description = "Test workflow"
    ctx.function_repository = MagicMock()
    ctx.function_repository.load.return_value = lambda **kw: (True, None)
    ctx.mfa_validator_steps = set()
    for k, v in overrides.items():
        if k != "data_fields":
            setattr(ctx, k, v)
    return ctx


def _make_strategy(step_config, engine_context=None):
    if engine_context is None:
        engine_context = _make_engine_context()
    return CollectInputStrategy(step_config, engine_context)


# ===========================================================================
# _check_context_extraction — pattern matching mode
# ===========================================================================

class TestCheckContextExtractionPatternMatching:
    """Tests for _check_context_extraction in pattern matching (non-structured output) mode."""

    def test_extracts_value_from_transition_pattern(self):
        """Agent responds with extraction pattern → field is pre-populated."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })
        state = {}
        agent_response = "REASON_CAPTURED: Defective product"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is True
        assert validation_error is None
        assert state["return_reason"] == "Defective product"

    def test_no_extraction_when_agent_asks_question(self):
        """Agent responds with a question → no extraction."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })
        state = {}
        agent_response = "What is the reason for your return?"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None
        assert state.get("return_reason") is None

    def test_no_extraction_when_pattern_matches_but_value_empty(self):
        """Pattern matches but no value after it → no extraction."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })
        state = {}
        agent_response = "REASON_CAPTURED:"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None
        assert state.get("return_reason") is None

    def test_handles_multiple_patterns_in_transition(self):
        """Transition with multiple patterns — matches the correct one."""
        strategy = _make_strategy({
            "id": "collect_order_id",
            "field": "order_id",
            "agent": {"name": "OrderCollector"},
            "transitions": [
                {"pattern": ["ORDER_ID_CAPTURED:", "ORDER_FOUND:"], "next": "check_eligibility"}
            ]
        })
        state = {}
        agent_response = "ORDER_FOUND: ORD-456"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is True
        assert validation_error is None
        assert state["order_id"] == "ORD-456"

    def test_no_extraction_with_no_transitions(self):
        """No transitions configured → no extraction."""
        strategy = _make_strategy({
            "id": "collect_info",
            "field": "info",
            "agent": {"name": "InfoCollector"},
        })
        state = {}
        agent_response = "Some response"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None


# ===========================================================================
# _check_context_extraction — structured output mode
# ===========================================================================

class TestCheckContextExtractionStructuredOutput:
    """Tests for _check_context_extraction in structured output mode."""

    def test_extracts_field_values_when_no_bot_response(self):
        """Null bot_response with field values → extraction succeeds."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })
        state = {}
        agent_response = json.dumps({
            "bot_response": None,
            "return_reason": "Defective product"
        })

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is True
        assert validation_error is None
        assert state["return_reason"] == {
            "bot_response": None, "options": None, "is_selectable": None,
            "return_reason": "Defective product",
        }

    def test_no_extraction_when_bot_response_present(self):
        """Non-empty bot_response → agent is asking a question, not extracting."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })
        state = {}
        agent_response = json.dumps({
            "bot_response": "Why are you returning this item?",
            "return_reason": None
        })

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None
        assert state.get("return_reason") is None

    def test_no_extraction_when_empty_bot_response_and_no_field_values(self):
        """Empty bot_response AND required field None → no extraction."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })
        state = {}
        agent_response = json.dumps({
            "bot_response": "",
            "return_reason": None
        })

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None
        assert state.get("return_reason") is None

    def test_handles_dict_response_directly(self):
        """Agent response as dict (not string) is handled."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })
        state = {}
        agent_response = {"bot_response": None, "return_reason": "Wrong size"}

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is True
        assert validation_error is None
        assert state["return_reason"] == {
            "bot_response": None, "options": None, "is_selectable": None,
            "return_reason": "Wrong size",
        }

    def test_handles_invalid_json_gracefully(self):
        """Invalid JSON response → no extraction, no crash."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })
        state = {}
        agent_response = "not valid json {{"

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is False
        assert validation_error is None


# ===========================================================================
# _check_context_extraction — multi-field
# ===========================================================================

class TestCheckContextExtractionMultiField:
    """Tests for _check_context_extraction with multi-field collectors."""

    def test_partial_extraction_returns_false(self):
        """Only some fields found → returns False (not all pre-populated)."""
        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        strategy = _make_strategy({
            "id": "collect_contact",
            "fields": ["email", "phone"],
            "agent": {
                "name": "ContactCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "email", "type": "text", "description": "Email address", "required": False},
                        {"name": "phone", "type": "text", "description": "Phone number", "required": False},
                    ]
                }
            }
        }, ctx)
        state = {}
        agent_response = json.dumps({
            "bot_response": None,
            "email": "user@example.com",
            "phone": None
        })

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        # Only email found, phone still missing → returns False
        assert extracted is False
        assert validation_error is None
        # But email should still be stored
        assert state.get("email") == "user@example.com"

    def test_full_extraction_returns_true(self):
        """All fields found → returns True."""
        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        strategy = _make_strategy({
            "id": "collect_contact",
            "fields": ["email", "phone"],
            "agent": {
                "name": "ContactCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "email", "type": "text", "description": "Email address", "required": False},
                        {"name": "phone", "type": "text", "description": "Phone number", "required": False},
                    ]
                }
            }
        }, ctx)
        state = {}
        agent_response = json.dumps({
            "bot_response": None,
            "email": "user@example.com",
            "phone": "555-1234"
        })

        extracted, validation_error = strategy._check_context_extraction(agent_response, state)

        assert extracted is True
        assert validation_error is None
        assert state["email"] == "user@example.com"
        assert state["phone"] == "555-1234"


# ===========================================================================
# _generate_prompt — context extraction integration
# ===========================================================================

class TestGeneratePromptContextExtraction:
    """Tests that _generate_prompt returns None when agent extracts from context."""

    def test_returns_none_on_pattern_matching_extraction(self):
        """Pattern matching: agent extracts from context → returns None."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })

        agent = MagicMock()
        agent.invoke.return_value = "REASON_CAPTURED: Defective product"

        conversation = []
        state = {}

        result = strategy._generate_prompt(agent, conversation, state)

        assert result is None
        assert state["return_reason"] == "Defective product"
        assert len(conversation) == 0  # No message added to conversation

    def test_returns_none_on_structured_output_extraction(self):
        """Structured output: agent extracts from context → returns None."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "return_reason", "type": "text", "description": "Reason for return", "required": True}
                    ]
                }
            }
        })

        agent = MagicMock()
        agent.invoke.return_value = json.dumps({
            "bot_response": None,
            "return_reason": "Wrong size"
        })

        conversation = []
        state = {}

        result = strategy._generate_prompt(agent, conversation, state)

        assert result is None
        assert state["return_reason"] == {
            "bot_response": None, "options": None, "is_selectable": None,
            "return_reason": "Wrong size",
        }
        assert len(conversation) == 0

    def test_normal_flow_when_agent_asks_question(self):
        """Agent asks a question → normal prompt returned."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })

        agent = MagicMock()
        agent.invoke.return_value = "What is the reason for your return?"

        conversation = []
        state = {}

        result = strategy._generate_prompt(agent, conversation, state)

        assert result is not None
        assert result["text"] == "What is the reason for your return?"
        assert len(conversation) == 1
        assert state.get("return_reason") is None

    def test_static_initial_message_skips_context_extraction(self):
        """When initial_message is configured, context extraction is not attempted."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {
                "name": "ReasonCollector",
                "initial_message": "Why are you returning this item?"
            },
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"}
            ]
        })

        engine_context = strategy.engine_context
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": False}

        agent = MagicMock()
        # Agent should NOT be invoked since initial_message is static
        conversation = []
        state = {}

        result = strategy._generate_prompt(agent, conversation, state)

        assert result is not None
        assert result["text"] == "Why are you returning this item?"
        # Agent.invoke should not be called (static message used directly)
        agent.invoke.assert_not_called()


# ===========================================================================
# _handle_pre_populated_field — transition matching
# ===========================================================================

class TestHandlePrePopulatedFieldTransitionMatching:
    """Tests that _handle_pre_populated_field matches transitions instead of always taking the first."""

    def test_matches_second_transition_for_structured_output(self):
        """Pre-populated SO value matches 2nd transition → routes correctly."""
        strategy = _make_strategy({
            "id": "collect_status",
            "field": "approval",
            "agent": {
                "name": "StatusCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "status", "type": "text", "description": "Approval status", "required": True},
                    ]
                }
            },
            "transitions": [
                {"ref": "status", "match": "approved", "next": "approved_step"},
                {"ref": "status", "match": "rejected", "next": "rejected_step"},
            ]
        })
        # Pre-populate with value matching the SECOND transition
        state = {"approval": {"bot_response": None, "options": None, "is_selectable": None, "status": "rejected"}}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_status_rejected_step"

    def test_matches_first_transition_for_structured_output(self):
        """Pre-populated SO value matches 1st transition → still works."""
        strategy = _make_strategy({
            "id": "collect_status",
            "field": "approval",
            "agent": {
                "name": "StatusCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "status", "type": "text", "description": "Approval status", "required": True},
                    ]
                }
            },
            "transitions": [
                {"ref": "status", "match": "approved", "next": "approved_step"},
                {"ref": "status", "match": "rejected", "next": "rejected_step"},
            ]
        })
        state = {"approval": {"bot_response": None, "options": None, "is_selectable": None, "status": "approved"}}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_status_approved_step"

    def test_falls_back_to_first_transition_when_no_match(self):
        """No SO transition matches → falls back to first transition."""
        strategy = _make_strategy({
            "id": "collect_status",
            "field": "approval",
            "agent": {
                "name": "StatusCollector",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "status", "type": "text", "description": "Approval status", "required": True},
                    ]
                }
            },
            "transitions": [
                {"ref": "status", "match": "approved", "next": "approved_step"},
                {"ref": "status", "match": "rejected", "next": "rejected_step"},
            ]
        })
        state = {"approval": {"bot_response": None, "options": None, "is_selectable": None, "status": "pending"}}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_status_approved_step"

    def test_pattern_matching_falls_back_when_no_pattern_in_value(self):
        """Pattern matching: no pattern found in stored value → falls back to first transition."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"},
                {"pattern": "REASON_FAILED:", "next": "failed_step"},
            ]
        })
        state = {"return_reason": "Defective product"}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_reason_process_return"

    def test_pattern_matching_matches_second_transition(self):
        """Pattern matching: stored value contains 2nd transition's pattern → routes correctly."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "transitions": [
                {"pattern": "REASON_CAPTURED:", "next": "process_return"},
                {"pattern": "REASON_FAILED:", "next": "failed_step"},
            ]
        })
        state = {"return_reason": "REASON_FAILED: Invalid reason provided"}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_reason_failed_step"
        # Pattern prefix should be stripped from stored value
        assert state["return_reason"] == "Invalid reason provided"

    def test_uses_next_step_when_no_transitions(self):
        """No transitions configured → falls back to next_step."""
        strategy = _make_strategy({
            "id": "collect_reason",
            "field": "return_reason",
            "agent": {"name": "ReasonCollector"},
            "next": "fallback_step",
        })
        state = {"return_reason": "Defective product"}

        result = strategy._handle_pre_populated_field(state, [])

        assert result["_status"] == "collect_reason_fallback_step"
