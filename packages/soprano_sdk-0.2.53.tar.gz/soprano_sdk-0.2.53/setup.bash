#!/bin/bash
# Setup script: Install dependencies and git hooks

set -e

echo "🔧 Setting up project..."

# Install dependencies
echo "📦 Installing dependencies..."
uv sync

# Install pre-commit hooks
echo "🪝 Installing git hooks..."
pre-commit install --hook-type pre-commit
pre-commit install --hook-type pre-push

echo ""
echo "✅ Setup complete!"
echo ""
echo "Git hooks installed:"
echo "  • pre-commit: Runs ruff lint"
echo "  • pre-push: Runs pytest"
