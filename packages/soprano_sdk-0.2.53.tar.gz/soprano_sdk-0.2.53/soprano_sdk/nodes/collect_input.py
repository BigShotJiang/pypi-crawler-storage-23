from typing import Dict, Any, List, Optional, Tuple
import json

from pydantic import ValidationError

from jinja2 import Environment
from langgraph.types import interrupt

from .base import ActionStrategy
from ..agents.factory import AgentFactory, AgentAdapter
from ..agents.structured_output import create_structured_output_model, validate_field_definitions
from ..core.constants import (
    COLLECT_INPUT_METADATA_FIELDS,
    OPTION_SELECTION_GUIDELINES,
    WorkflowKeys,
    DEFAULT_MAX_ATTEMPTS,
    MAX_ATTEMPTS_MESSAGE,
    TransitionPattern,
    ResponseMarkers
)
from ..core.models import MessagePayload
from ..core.rollback_strategies import (
    RollbackStrategy,
    HistoryBasedRollback,
    DependencyBasedRollback
)
from ..core.state import initialize_state
from ..utils.logger import logger
from ..utils.tracing import trace_node_execution, trace_agent_invocation, trace_validation, add_node_result
from ..utils.parser import convert_to_dict

VALIDATION_ERROR_MESSAGE = "validation failed for the provided input, please enter valid input"


def _extract_conversational_text(content: str) -> Optional[str]:
    """Extract human-readable text from a JSON-formatted assistant message.

    Conversational messages (from _generate_prompt, _handle_validation_failure)
    are stored as JSON: {"text": "...", "options": [...], "is_selectable": ...}.
    Extraction pattern responses (e.g. ORDER_ID_CAPTURED: ...) are plain text.

    Returns:
        The text field if content is valid JSON with a 'text' key, None otherwise.
        Returning None signals that this message is an extraction pattern and
        should be excluded from context summaries.
    """
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict) and "text" in parsed:
            return parsed["text"]
    except (json.JSONDecodeError, TypeError):
        pass
    return None


def _build_workflow_context_summary(state: Dict[str, Any]) -> str:
    """Build a summary of previously collected data and conversation history.

    Uses _node_execution_order, _node_field_map, and _conversations from state
    to construct a context block. Presents collected data as authoritative ground
    truth, with conversation history as supplementary context. Only includes
    conversational assistant messages (JSON-sourced), excluding extraction pattern
    responses to prevent the current agent from mimicking internal patterns.

    Returns empty string if no previous data exists (first node in workflow).
    """
    node_execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
    node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
    conversations = state.get(WorkflowKeys.CONVERSATIONS, {})

    if not node_execution_order:
        return ""

    # Pass 1: Collect all confirmed field values into a flat list
    collected_lines = []
    # Pass 2: Collect conversation history per step
    conversation_sections = []

    for node_id in node_execution_order:
        field_or_fields = node_field_map.get(node_id)
        if not field_or_fields:
            continue

        # Normalize to list for uniform handling
        if isinstance(field_or_fields, str):
            fields = [field_or_fields]
            primary_field = field_or_fields
        else:
            fields = field_or_fields
            primary_field = fields[0]

        # Collect confirmed values
        for field_name in fields:
            value = state.get(field_name)
            if value is not None:
                display_name = field_name.replace('_', ' ').title()
                collected_lines.append(f"- {display_name}: {value}")

        # Build conversation summary (only conversational messages)
        conv_key = f"{primary_field}_conversation"
        conv_messages = conversations.get(conv_key, [])

        conv_lines = []
        for msg in conv_messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "assistant":
                text = _extract_conversational_text(content)
                if text is not None:
                    conv_lines.append(f"  Agent: {text}")
            elif role == "user":
                conv_lines.append(f"  User: {content}")

        if conv_lines:
            node_display = node_id.replace('_', ' ').title()
            conversation_sections.append(
                f"[Step: {node_display}]\n" + "\n".join(conv_lines)
            )

    if not collected_lines and not conversation_sections:
        return ""

    parts = ["<workflow_state>"]
    parts.append(
        "The following data has been collected and verified by prior workflow steps.\n"
        "Treat these values as ground truth. Do NOT re-ask for any value listed here."
    )

    if collected_lines:
        parts.append("\nCOLLECTED DATA:\n" + "\n".join(collected_lines))

    if conversation_sections:
        parts.append(
            "\nCONVERSATION HISTORY:\n" + "\n\n".join(conversation_sections)
        )

    parts.append("</workflow_state>")

    return "\n".join(parts)
INVALID_INPUT_MESSAGE = "Looks like the input is invalid. Please double-check and re-enter it."
COLLECTION_FAILURE_MESSAGE = "I couldn't understand your response. Please try again and provide the required information."
OUT_OF_SCOPE_PATTERN = "OUT_OF_SCOPE:"


def _wrap_instructions_with_out_of_scope_detection(
    instructions: str,
    scope_description: str,
    with_structured_output: bool
) -> str:
    """Append out-of-scope detection instructions. Backward compatible - works with any scope_description."""
    return f"""{instructions}

<out_of_scope_detection>
OUT-OF-SCOPE DETECTION:
You are working within this context: {scope_description}

IMPORTANT: If the user's query is COMPLETELY UNRELATED to the workflow context above:
- {"Set out_of_scope to a brief description of what the user is trying to do" if with_structured_output else "Respond with: OUT_OF_SCOPE: <brief description of user intent>"}
- Do NOT attempt to answer the query or provide information about unrelated topics
- Do NOT confuse this with related questions or intent changes within the workflow

A query is OUT OF SCOPE only if it's about:
- Completely different products, services, or business domains not mentioned in the workflow context
- Actions or requests that have no connection to the workflow purpose
- Topics that are entirely unrelated to what this workflow is designed to handle

A query is IN SCOPE if it:
- Relates to any part of the workflow context described above
- Asks clarifying questions about the current or previous steps
- Requests to change or correct previously collected information (this is an intent change, not out-of-scope)
</out_of_scope_detection>
"""


def _wrap_instructions_with_options_data_guidance(instructions: str) -> str:
    """
    Wrap instructions with OPTIONS_DATA marker guidance for pattern matching mode.
    Only called when NOT using structured output.
    """
    return f"""{instructions}

<options_formatting>
OPTIONS FORMATTING:

{OPTION_SELECTION_GUIDELINES}

When presenting options to the user (single question only):
1. Write your message text WITHOUT listing the options — the UI renders them as buttons/list items
2. Place ALL options ONLY in the {ResponseMarkers.OPTIONS_DATA} marker at the end of your response
3. CRITICAL: The {ResponseMarkers.OPTIONS_DATA} value MUST be a single valid JSON object on ONE LINE
4. If the message contains MULTIPLE questions, do NOT use the {ResponseMarkers.OPTIONS_DATA} marker — include all questions directly in the message text

Format:
{ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "...", "subtext": "..."}}, ...], "is_selectable": true/false}}

Examples:
- Selectable options with pricing (single question):
  Please choose your plan:
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Basic", "subtext": "Free"}}, {{"text": "Pro", "subtext": "$9/month"}}, {{"text": "Enterprise", "subtext": "$49/month"}}], "is_selectable": true}}

- Simple yes/no (single question, no subtext):
  Would you like to proceed?
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Yes", "subtext": ""}}, {{"text": "No", "subtext": ""}}], "is_selectable": true}}

- Clickable links (not selectable):
  For more information, visit:
  {ResponseMarkers.OPTIONS_DATA} {{"options": [{{"text": "Help Center", "subtext": "https://example.com/help"}}, {{"text": "Support Portal", "subtext": "https://example.com/support"}}], "is_selectable": false}}

- Multiple questions (NO options marker):
  What is your order ID? And what is the reason for the return?
</options_formatting>
"""


def _wrap_instructions_with_intent_detection(
        instructions: str,
        collector_nodes: Dict[str, str],
        with_structured_output: bool
) -> str:
    if not collector_nodes:
        return instructions

    collector_nodes_str = "\n".join(f"{node_name}: {description}" for node_name, description in collector_nodes.items())
    return f"""
{instructions}

<intent_detection>
AVAILABLE CONVERSATION INTENTS:
{collector_nodes_str}

Format: <node_name>: <intent_description>

CRITICAL INTENT DETECTION RULES:
1. ONLY check for intent changes against the EXACT node names listed above
2. The node name MUST appear in the list above to be valid
3. Do NOT infer, guess, or create new intent names
4. Tool calls are NOT intent changes
5. If no intents are listed above, NEVER trigger an intent change

Before responding, analyze if the user's query matches a DIFFERENT intent from the list above:

IF the user's query clearly matches a DIFFERENT intent that EXISTS in the list above:
- {"Respond ONLY with: INTENT_CHANGE: <node_name>" if not with_structured_output else "modify intent_change value <node_name>"}
- Use the EXACT node_name from the list above
- Do NOT provide any other response
- Do NOT answer the user's question

IF the user's query continues with the SAME intent OR does not match any intent in the list above:
- Proceed with your normal response
- Do NOT mention intent detection
- Answer the user's question as configured

BOT RESPONSE RULES:
- If the user is asking a question or needs information, provide a helpful and concise response
- If the user input is unclear or does not provide enough information, ask for clarification or more details
- { "populate bot_response field to respond back to the user" if with_structured_output else ""}
- Do not respond or use bot_response if the user provides a valid input
</intent_detection>
"""

def _create_rollback_strategy(strategy_name: str) -> RollbackStrategy:
    if strategy_name == "dependency_based":
        return DependencyBasedRollback()
    elif strategy_name == "history_based":
        return HistoryBasedRollback()
    else:
        logger.warning(f"Unknown rollback strategy '{strategy_name}', using history_based")
        return HistoryBasedRollback()

class CollectInputStrategy(ActionStrategy):
    def __init__(self, step_config: Dict[str, Any], engine_context: Any):
        super().__init__(step_config, engine_context)

        # Support both single field and multiple fields
        self.field = step_config.get('field')           # legacy single-field
        self.fields = step_config.get('fields', [])     # new multi-field

        if self.fields:
            self.is_multi_field = True
            self.primary_field = self.fields[0]
        elif self.field:
            self.is_multi_field = False
            self.fields = [self.field]
            self.primary_field = self.field
        else:
            raise RuntimeError(f"Step '{self.step_id}' missing 'field' or 'fields'")

        self.agent_config = step_config.get('agent', {})
        self.max_attempts = step_config.get('retry_limit') or engine_context.get_config_value("max_retry_limit", DEFAULT_MAX_ATTEMPTS)
        self.on_max_attempts_reached = step_config.get('on_max_attempts_reached')
        self.transitions = self._get_transitions()
        self.next_step = self.step_config.get("next", None)
        self.is_structured_output = self.agent_config.get("structured_output", {}).get("enabled", False)

        self.options = step_config.get("options", []) or []
        self.is_selectable = step_config.get("is_selectable", False)

        # Out-of-scope detection configuration (disabled by default)
        self.enable_out_of_scope = self.agent_config.get("detect_out_of_scope", False)

        if explicit_scope := self.agent_config.get("scope_description"):
            self.scope_description = explicit_scope
        else:
            workflow_desc = engine_context.workflow_description
            fields_label = ", ".join(self.fields)
            agent_desc = self.agent_config.get("description", f"collecting {fields_label}")
            self.scope_description = f"{workflow_desc}. Currently: {agent_desc}"

        rollback_strategy_name = engine_context.get_config_value("rollback_strategy", "history_based")
        self.rollback_strategy = _create_rollback_strategy(rollback_strategy_name)
        logger.info(f"Using rollback strategy: {self.rollback_strategy.get_strategy_name()}")

        self.field_validators = {}
        if validator_function_path := self.step_config.get("validator"):
            self.field_validators[self.primary_field] = self.engine_context.function_repository.load(validator_function_path)
        if validators_config := step_config.get('validators'):
            for field_name, validator_path in validators_config.items():
                self.field_validators[field_name] = self.engine_context.function_repository.load(validator_path)

        if not self.agent_config:
            raise RuntimeError(f"Step '{self.step_id}' missing required 'agent' configuration")

    @property
    def _conversation_key(self) -> str:
        return f'{self.primary_field}_conversation'

    def pre_execute(self, state: Dict[str, Any]) -> None:
        pass

    @property
    def _formatted_field_name(self) -> str:
        if self.is_multi_field:
            return ', '.join(f.replace('_', ' ').title() for f in self.fields)
        return self.primary_field.replace('_', ' ').title()

    def _trace_node_result(self, span, state: Dict[str, Any]):
        """Add trace results for all fields in this step."""
        status = state.get(WorkflowKeys.STATUS)
        for field_name in self.fields:
            add_node_result(span, field_name, state.get(field_name), status)

    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        with trace_node_execution(
            node_id=self.step_id,
            node_type="collect_input_with_agent",
            output_field=self.primary_field
        ) as span:
            state = initialize_state(state)
            self._apply_context_value(state, span)
            conversation = self._get_or_create_conversation(state)

            # Self-loop with pending prompt: interrupt for user input, then process
            pending_prompt = state.get(WorkflowKeys.PENDING_PROMPT)
            if self._is_collecting(state) and pending_prompt is not None:
                state[WorkflowKeys.PENDING_PROMPT] = None
                user_input = interrupt(pending_prompt)
                conversation.append({"role": "user", "content": user_input})
                span.add_event("user.input_received", {"input_length": len(user_input)})

                state = self._process_user_response(state, conversation, span)

                # If still collecting (validation failed, etc.), store next prompt
                if self._is_collecting(state):
                    if self._max_attempts_reached(state):
                        return self._handle_max_attempts(state)
                    prompt_data = self._get_continuation_prompt(conversation)
                    if prompt_data:
                        state[WorkflowKeys.PENDING_PROMPT] = prompt_data
                        self._update_conversation(state, conversation)
                        return state

                self._trace_node_result(span, state)
                return self._add_node_to_execution_order(state)

            # First entry
            if not self._is_collecting(state):
                if self.rollback_strategy.should_save_snapshot():
                    self._save_snapshot_before_execution(state)

            if self._is_field_pre_populated(state):
                span.add_event("field.pre_populated", {
                    "fields": str({f: state.get(f) for f in self.fields})
                })
                state = self._handle_pre_populated_field(state, conversation)

                # If validation failed, store next prompt for the self-loop
                if self._is_collecting(state):
                    prompt_data = self._get_continuation_prompt(conversation)
                    if prompt_data:
                        state[WorkflowKeys.PENDING_PROMPT] = prompt_data
                        self._update_conversation(state, conversation)
                        return state

                self._trace_node_result(span, state)
                return self._add_node_to_execution_order(state)

            if self._max_attempts_reached(state):
                span.add_event("max_attempts.reached")
                return self._handle_max_attempts(state)

            agent = self._create_agent(state)

            prompt_data = self._generate_prompt(agent, conversation, state)

            # If agent extracted from workflow context, handle as pre-populated
            if prompt_data is None and self._is_field_pre_populated(state):
                span.add_event("field.extracted_from_context", {
                    "fields": str({f: state.get(f) for f in self.fields})
                })
                state = self._handle_pre_populated_field(state, conversation)
                self._update_conversation(state, conversation)
                self._trace_node_result(span, state)
                return self._add_node_to_execution_order(state)

            if prompt_data is not None and prompt_data["text"] is not None:
                # Store prompt in state and return so LangGraph checkpoints
                # before interrupt() is called on the self-loop re-entry.
                state[WorkflowKeys.PENDING_PROMPT] = prompt_data
                self._set_status(state, 'collecting')
                self._update_conversation(state, conversation)
                return state

            # No prompt needed — fall through without interrupting
            self._update_conversation(state, conversation)
            self._trace_node_result(span, state)

        return self._add_node_to_execution_order(state)

    def _process_user_response(
        self,
        state: Dict[str, Any],
        conversation: List[Dict[str, str]],
        span
    ) -> Dict[str, Any]:
        """Process user input after interrupt: invoke agent and handle transitions."""
        agent = self._create_agent(state)

        with trace_agent_invocation(
            agent_name=self.agent_config.get('name', self.primary_field),
            model=self.agent_config.get('model', 'default')
        ):
            agent_response = self._get_agent_response(agent, conversation, state)

        user_message = next(
            (msg['content'] for msg in reversed(conversation) if msg['role'] == 'user'),
            ""
        )

        if self.is_structured_output:
            state = self._handle_structured_output_transition(state, conversation, agent_response, user_message)
            self._update_conversation(state, conversation)
            return state

        if self.enable_out_of_scope and agent_response.startswith(OUT_OF_SCOPE_PATTERN):
            span.add_event("out_of_scope.detected")
            return self._handle_out_of_scope(agent_response, state, user_message)

        if agent_response.startswith(TransitionPattern.INTENT_CHANGE):
            span.add_event("intent.change_detected")
            return self._handle_intent_change(agent_response, state)

        state = self._process_transitions(state, conversation, agent_response)
        self._update_conversation(state, conversation)
        return state

    def _render_template_string(self, template_str: str, state: Dict[str, Any]) -> str:
        if not template_str:
            return ""
        template_loader = self.engine_context.get_config_value('template_loader', Environment())
        return template_loader.from_string(template_str).render(state)

    def _should_humanize_prompt(self) -> bool:
        """Determine if initial prompts should be humanized."""
        from ..core.constants import DEFAULT_HUMANIZATION_ENABLED, HumanizationKeys

        # Check workflow-level setting (default: enabled)
        workflow_humanization = self.engine_context._get_humanization_config()
        workflow_enabled = workflow_humanization.get(
            HumanizationKeys.ENABLED,
            DEFAULT_HUMANIZATION_ENABLED
        )

        if not workflow_enabled:
            return False

        return self.agent_config.get('humanize', DEFAULT_HUMANIZATION_ENABLED)

    def _apply_humanization(self, message: str, state: Dict[str, Any]) -> str:
        """Apply template rendering and humanization to a message.

        This is a common helper used by validation failures, collection failures,
        and max attempts messages to ensure consistent localization and humanization.
        """
        # Apply template rendering (for variables like {field})
        message = self._render_template_string(message, state)

        # Apply humanization if enabled
        if self._should_humanize_prompt():
            result = self.engine_context._humanize_message(
                message, state, self.options, self.is_selectable
            )
            message = result.message
            # Update instance variables with humanized options (may have been detected/generated)
            if result.options is not None:
                self.options = result.options
            if result.is_selectable is not None:
                self.is_selectable = result.is_selectable

        return message

    def _get_agent_response(self, agent: AgentAdapter, conversation: List[Dict[str, str]], state: Dict[str, Any]) -> Any:
        """Get agent response and add it to conversation."""
        agent_response = agent.invoke(conversation)
        logger.info(f"Agent raw response: {agent_response}")

        # Convert response to string
        response_str = str(agent_response)


        if not self.is_structured_output:
            result = self._extract_options_from_response(response_str)
            conversation.append({"role": "assistant", "content": result.message})
        else:
            conversation.append({"role": "assistant", "content": response_str})

        return agent_response

    def _apply_context_value(self, state: Dict[str, Any], span) -> None:
        for field_name in self.fields:
            context_value = self.engine_context.get_context_value(field_name)
            if context_value is not None:
                logger.info(f"Using context value for '{field_name}': {context_value}")
                state[field_name] = context_value
                span.add_event("context.value_used", {"field": field_name, "value": str(context_value)})

    def _add_node_to_execution_order(self, state):
        if self._is_collecting(state):
            return state

        self._register_node_execution(state)
        self._register_collector_node(state)

        return state

    def _is_collecting(self, state: Dict[str, Any]) -> bool:
        return state.get(WorkflowKeys.STATUS) == f'{self.step_id}_collecting'

    def _get_continuation_prompt(self, conversation: List[Dict[str, str]]) -> Optional[Dict[str, Any]]:
        """Return the last assistant message as a prompt dict for the self-loop.

        Used when the node needs another round of user input (validation failed, etc.)
        and the prompt is already in conversation — no LLM call needed.
        """
        last_msg = next((msg for msg in reversed(conversation) if msg['role'] == 'assistant'), None)
        if last_msg is None:
            return None
        try:
            content_data = json.loads(last_msg['content'])
            return {
                "text": content_data.get("text", last_msg['content']),
                "options": content_data.get("options", self.options),
                "is_selectable": content_data.get("is_selectable", self.is_selectable),
            }
        except (json.JSONDecodeError, TypeError):
            return {
                "text": last_msg['content'],
                "options": self.options,
                "is_selectable": self.is_selectable,
            }

    def _save_snapshot_before_execution(self, state: Dict[str, Any]):
        state_history = state.get(WorkflowKeys.STATE_HISTORY, [])
        execution_index = len(state_history)
        self.rollback_strategy.save_snapshot(state, self.step_id, execution_index)

    def _register_node_execution(self, state: Dict[str, Any]):
        execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        if self.step_id not in execution_order:
            execution_order.append(self.step_id)
        state[WorkflowKeys.NODE_EXECUTION_ORDER] = execution_order

    def _register_collector_node(self, state: Dict[str, Any]):
        collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})
        description = self.agent_config.get('description', f"Collecting {self.primary_field}")
        collector_nodes[self.step_id] = description
        state[WorkflowKeys.COLLECTOR_NODES] = collector_nodes

        # Register all fields in the node_field_map
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
        if self.is_multi_field:
            node_field_map[self.step_id] = self.fields  # Store as list
        else:
            node_field_map[self.step_id] = self.primary_field
        state[WorkflowKeys.NODE_FIELD_MAP] = node_field_map

    def _is_field_pre_populated(self, state: Dict[str, Any]) -> bool:
        """Check if ALL fields are already populated."""
        return all(state.get(f) is not None for f in self.fields)

    def _check_context_extraction(self, agent_response: str, state: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Check if the agent extracted data from workflow context instead of asking a question.

        When previous workflow context contains the information this node needs,
        the agent may respond with an extraction pattern rather than an opening question.
        This method detects that case and pre-populates the field in state.

        Returns:
            (True, None) if extraction succeeded and field(s) are now populated.
            (False, None) if no extraction was detected (normal flow).
            (False, error_message) if extraction matched but validation failed.
        """
        if self.is_structured_output:
            try:
                response_dict = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
                bot_response = response_dict.get("bot_response")
                if bot_response and str(bot_response).strip():
                    return False, None  # Agent is asking a question, not extracting

                so_model = self._create_structured_output_model(
                    state.get(WorkflowKeys.COLLECTOR_NODES, {})
                )
                validated = so_model.model_validate(response_dict)
                validated_data = validated.model_dump()

                # Check required fields are present (same as _handle_structured_output_transition)
                structured_config = self.agent_config.get('structured_output', {})
                fields_config = structured_config.get('fields', [])
                for field_def in fields_config:
                    field_name = field_def.get("name")
                    is_required = field_def.get("required", True)
                    if field_name in COLLECT_INPUT_METADATA_FIELDS or is_required is False:
                        continue
                    if validated_data.get(field_name) is None:
                        return False, None

                if self.is_multi_field:
                    self._store_field_values(state, validated_data)
                else:
                    self._store_field_value(state, validated_data)

                if self.field_validators:
                    is_valid, validation_error = self._validate_collected_input(state)
                    if not is_valid:
                        return False, validation_error

                return self._is_field_pre_populated(state), None
            except (json.JSONDecodeError, TypeError, ValidationError):
                return False, None
        else:
            # Pattern matching mode: check if response matches any transition pattern
            for transition in self.transitions:
                patterns = transition['pattern']
                if isinstance(patterns, str):
                    patterns = [patterns]
                for pattern in patterns:
                    if pattern in agent_response:
                        value = agent_response.split(pattern)[1].strip()
                        if value:
                            self._store_field_value(state, value)

                            if self.field_validators:
                                is_valid, validation_error = self._validate_collected_input(state)
                                if not is_valid:
                                    return False, validation_error

                            return self._is_field_pre_populated(state), None
            return False, None

    def _get_missing_fields(self, state: Dict[str, Any]) -> List[str]:
        """Return list of fields that are still None."""
        return [f for f in self.fields if state.get(f) is None]

    def _validate_collected_input(self, state: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Validate collected fields using per-field validators."""
        errors = []
        validation_errors = {}
        for field_name in self.fields:
            if field_name in self.field_validators and state.get(field_name) is not None:
                validator = self.field_validators[field_name]
                with trace_validation(self.step_id, field_name) as span:
                    is_valid, error_msg = validator(**state)
                    if span and span.is_recording():
                        span.set_attribute("validation.result", is_valid)
                        if not is_valid:
                            span.set_attribute("validation.error", error_msg or "")
                if not is_valid:
                    # Capture the failed value before clearing
                    validation_errors[field_name] = {"value": state[field_name], "error": error_msg}
                    # Clear the invalid field so agent asks again
                    state[field_name] = None
                    if self.is_multi_field:
                        errors.append(f"{field_name}: {error_msg}")
                    else:
                        errors.append(error_msg)

        state[WorkflowKeys.VALIDATION_ERRORS] = validation_errors

        if errors:
            return False, "\n".join(errors)

        return True, None

    def _handle_pre_populated_field(self, state: Dict[str, Any], conversation: List) -> Dict[str, Any]:
        logger.info(f"Fields {self.fields} are populated, skipping collection")

        is_valid_input, validator_error_message = self._validate_collected_input(state)
        if not is_valid_input:
            self._set_status(state, "collecting")
            pre_populated_values = {f: state.get(f) for f in self.fields}
            conversation.append({"role": "user", "content": str(pre_populated_values)})
            return self._handle_validation_failure(state, conversation, message=validator_error_message)

        if self.transitions:
            next_step = None

            # Try matching transitions against pre-populated values
            if self.is_structured_output:
                if self.is_multi_field:
                    response_dict = {f: state.get(f) for f in self.fields}
                else:
                    field_value = state.get(self.primary_field)
                    response_dict = field_value if isinstance(field_value, dict) else {}
                next_step = self._find_matching_transition(response_dict)
            else:
                # Pattern matching: check if stored value contains a transition pattern
                field_value = str(state.get(self.primary_field, ''))
                for transition in self.transitions:
                    patterns = transition.get('pattern', [])
                    if isinstance(patterns, str):
                        patterns = [patterns]
                    for pattern in patterns:
                        if pattern in field_value:
                            # Strip the pattern prefix and re-store the clean value
                            clean_value = field_value.split(pattern)[1].strip()
                            if clean_value:
                                self._store_field_value(state, clean_value)
                            next_step = transition['next']
                            break
                    if next_step:
                        break

            # Fall back to first transition if no match
            # TODO: remove this behaviour in future release
            if not next_step:
                next_step = self.transitions[0]['next']

            self._set_status(state, next_step)
            if next_step in self.engine_context.outcome_map:
                self._set_outcome(state, next_step)

        elif self.next_step:
            self._set_status(state, self.next_step)

            if self.next_step in self.engine_context.outcome_map:
                self._set_outcome(state, self.next_step)

        return state

    def _max_attempts_reached(self, state: Dict[str, Any]) -> bool:
        conversation = state.get(WorkflowKeys.CONVERSATIONS, {}).get(self._conversation_key, [])
        attempt_count = len([m for m in conversation if m['role'] == 'user'])
        return attempt_count >= self.max_attempts

    def _handle_max_attempts(self, state: Dict[str, Any]) -> Dict[str, Any]:
        logger.warning(f"Max attempts reached for field '{self.primary_field}'")
        self._set_status(state, 'max_attempts')
        if self.on_max_attempts_reached:
            message = self.on_max_attempts_reached
        else:
            message = MAX_ATTEMPTS_MESSAGE.format(field=self.primary_field)

        # Apply template rendering and humanization
        message = self._apply_humanization(message, state)

        state[WorkflowKeys.MESSAGES] = [message]
        return state

    def _get_or_create_conversation(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})

        if self._conversation_key not in conversations:
            conversations[self._conversation_key] = []
            state[WorkflowKeys.CONVERSATIONS] = conversations

        return conversations[self._conversation_key]
    def _get_model_config(self) -> Dict[str, Any]:
        model_config = self.engine_context.get_config_value('model_config')
        if not model_config:
            raise ValueError("Model config not found in engine context")
        
        if model_id := self.agent_config.get("model"):
            model_config = model_config.copy()
            model_config["model_name"] = model_id
        
        return model_config

    def _build_auto_extraction_rule(self) -> str:
        """Build an auto-extraction instruction linking prior conversation history to current fields."""
        field_names = [f.replace('_', ' ').title() for f in self.fields]
        fields_label = ", ".join(field_names)
        return (
            f"<auto_extraction_rule>\n"
            f"You are currently collecting: {fields_label}.\n"
            f"Before asking the user, review the CONVERSATION HISTORY above. "
            f"If the user has already conveyed the information you need to collect "
            f"during a prior step (even if it was not the focus of that step), "
            f"extract and return it immediately using your standard capture/extraction format. "
            f"Do NOT ask the user to repeat information they have already provided.\n"
            f"</auto_extraction_rule>"
        )

    def _get_instructions(self, state: Dict[str, Any], collector_nodes: Dict[str, str]) -> str:
        instructions = self.agent_config.get("instructions")

        instructions = self._render_template_string(instructions, state)

        # Inject localization instructions at the start (per-turn)
        localization_instructions = self.engine_context.get_localization_instructions(state)
        if localization_instructions:
            instructions = f"{localization_instructions}\n\n{instructions}"

        # Add workflow context summary early -- right after base instructions
        workflow_context = _build_workflow_context_summary(state)
        if workflow_context:
            auto_extract_rule = self._build_auto_extraction_rule()
            instructions = f"{instructions}\n\n{workflow_context}\n\n{auto_extract_rule}"

        # Add OPTIONS_DATA guidance for pattern matching mode
        if not self.is_structured_output:
            instructions = _wrap_instructions_with_options_data_guidance(instructions)

        if collector_nodes:
            collector_nodes_for_intent_change = {
                node_id: node_desc for node_id, node_desc in collector_nodes.items()
                if node_id not in self.engine_context.mfa_validator_steps
            }
            instructions = _wrap_instructions_with_intent_detection(instructions, collector_nodes_for_intent_change, self.is_structured_output)

        # Add out-of-scope detection instructions if enabled
        if self.enable_out_of_scope:
            instructions = _wrap_instructions_with_out_of_scope_detection(
                instructions, self.scope_description, self.is_structured_output
            )

        return instructions

    def _load_agent_tools(self, state: Dict[str, Any]) -> List:
        return [
            self.engine_context.tool_repository.load(tool_name, state)
            for tool_name in self.agent_config.get('tools', [])
        ]

    def _create_structured_output_model(self, collector_nodes: Dict[str, str]) -> Any:
        structured_output_config = self.agent_config.get('structured_output')
        if not structured_output_config or not structured_output_config.get('enabled'):
            return None

        fields = structured_output_config.get('fields', [])
        if not fields:
            return None

        validate_field_definitions(fields)
        model_name = f"{self.primary_field.title().replace('_', '')}StructuredOutput"

        return create_structured_output_model(
            fields=fields,
            model_name=model_name,
            needs_intent_change=len(collector_nodes) > 0,
            enable_out_of_scope=self.enable_out_of_scope
        )

    def _create_agent(self, state: Dict[str, Any]) -> AgentAdapter:
        try:
            model_config = self._get_model_config()
            agent_tools = self._load_agent_tools(state)
            collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})

            instructions = self._get_instructions(state, collector_nodes)
            structured_output_model = self._create_structured_output_model(collector_nodes)
            framework = self.engine_context.get_config_value('agent_framework', 'langgraph')

            return AgentFactory.create_agent(
                framework=framework,
                name=self.agent_config.get('name', f'{self.primary_field}Collector'),
                model_config=model_config,
                tools=agent_tools,
                system_prompt=instructions,
                structured_output_model=structured_output_model
            )

        except Exception as e:
            raise RuntimeError(f"Failed to create agent for step '{self.step_id}': {e}")

    def _generate_prompt(
        self,
        agent: AgentAdapter,
        conversation: List[Dict[str, str]],
        state: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Generate the prompt for the user, returning structured prompt data.

        Returns:
            Dict with keys: text (str|None), options (list), is_selectable (bool)
            or None if no prompt is needed.
        """
        # Track if initial_message is from config (static) or agent-generated
        initial_message = self.agent_config.get('initial_message')
        options = self.options
        is_selectable = self.is_selectable

        if not (prompt := initial_message):
            # Agent generates the prompt - LLM naturally produces conversational tone
            user_msg = state.get(WorkflowKeys.USER_MESSAGE, "")
            agent_response = agent.invoke([{"role": "user", "content": user_msg}])
            logger.info(f"Agent raw response: {agent_response}")

            # Check if agent extracted data from workflow context instead of asking
            extracted, validation_error = self._check_context_extraction(agent_response, state)
            if extracted:
                logger.info(f"Agent extracted field(s) from workflow context for step '{self.step_id}'")
                return None  # Field pre-populated from context, no prompt needed

            if validation_error:
                logger.info(f"Context extraction validation failed for step '{self.step_id}': {validation_error}")
                prompt = self._apply_humanization(validation_error, state)
            elif self.is_structured_output:
                try:
                    response_dict = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
                    bot_response = response_dict.get("bot_response", None)
                    # Treat empty or whitespace-only bot_response as None
                    prompt = bot_response if (bot_response and bot_response.strip()) else None
                    # Extract dynamic options from agent response
                    if response_dict.get("options") is not None:
                        options = response_dict["options"] or options
                    if response_dict.get("is_selectable") is not None:
                        is_selectable = response_dict["is_selectable"]
                    # Update instance variables for use in self-loop scenarios (structured output mode)
                    self.options = options
                    self.is_selectable = is_selectable
                except (json.JSONDecodeError, TypeError, ValueError) as e:
                    logger.error(f"Error When Converting Structured Output {agent_response} to JSON {e}")
                    prompt = agent_response
            else:
                result = self._extract_options_from_response(agent_response)
                prompt = result.message
                # Update instance variables for use in self-loop scenarios (pattern matching mode)
                self.options = result.options
                self.is_selectable = result.is_selectable

        if prompt is not None:
            prompt = self._render_template_string(prompt, state)
            if initial_message and self._should_humanize_prompt():
                result = self.engine_context._humanize_message(prompt, state, self.options, self.is_selectable)
                prompt = result.message
                # Update instance variables with humanized options
                self.options = result.options if result.options is not None else self.options
                self.is_selectable = result.is_selectable if result.is_selectable is not None else self.is_selectable

            # Serialize structured data as JSON in content field
            content_data = {
                "text": prompt,
                "options": self.options,
                "is_selectable": self.is_selectable
            }
            conversation.append({"role": "assistant", "content": json.dumps(content_data)})

        return {"text": prompt, "options": self.options, "is_selectable": self.is_selectable} if prompt is not None else None

    def _update_conversation(self, state: Dict[str, Any], conversation: List[Dict[str, str]]):
        state[WorkflowKeys.CONVERSATIONS][self._conversation_key] = conversation

    def _extract_options_from_response(self, agent_response: str) -> MessagePayload:
        """Extract options from agent response with OPTIONS_DATA marker.

        Returns:
            MessagePayload containing cleaned message text and extracted options
        """
        options_marker = ResponseMarkers.OPTIONS_DATA

        if options_marker not in agent_response:
            return MessagePayload(agent_response, self.options, self.is_selectable)

        parts = agent_response.split(options_marker, 1)
        conversational_text = parts[0].strip()
        options_text = parts[1].strip()
        options_data = convert_to_dict(options_text)
        
        if isinstance(options_data, str):
            logger.warning(f"OPTIONS_DATA value is a string: {options_data}")
            return MessagePayload(conversational_text, self.options, self.is_selectable)
        
        extracted_options = options_data.get("options", self.options)
        extracted_selectable = options_data.get("is_selectable", self.is_selectable)

        if not isinstance(extracted_options, list):
            logger.warning(f"OPTIONS_DATA 'options' must be a list, got {type(extracted_options)}")
            return MessagePayload(conversational_text, self.options, self.is_selectable)

        logger.info(f"Extracted {len(extracted_options)} dynamic options from agent response")
        return MessagePayload(conversational_text, extracted_options, extracted_selectable)
        

    def _handle_intent_change(self, target_node_or_response, state: Dict[str, Any]) -> Dict[str, Any]:
        if isinstance(target_node_or_response, str) and TransitionPattern.INTENT_CHANGE in target_node_or_response:
            target_node = target_node_or_response.split(TransitionPattern.INTENT_CHANGE)[1].strip()
        else:
            target_node = target_node_or_response

        logger.info(f"Intent change detected: {self.step_id} -> {target_node}")

        rollback_state = self._rollback_state_to_node(state, target_node)

        if rollback_state is None:
            logger.error(f"Failed to rollback to node '{target_node}'")
            raise RuntimeError(f"Unable to process intent change to '{target_node}'")

        return rollback_state

    def _handle_out_of_scope(self, reason: str, state: Dict[str, Any], user_message: str) -> Dict[str, Any]:
        """Handle out-of-scope user input by signaling to parent orchestrator"""
        if isinstance(reason, str) and OUT_OF_SCOPE_PATTERN in reason:
            reason = reason.split(OUT_OF_SCOPE_PATTERN)[1].strip()

        logger.info(f"Out-of-scope detected in step '{self.step_id}': {reason}")

        # Store the out-of-scope reason and interrupt with user message
        state['_out_of_scope_reason'] = reason
        interrupt({
            "type": "out_of_scope",
            "step_id": self.step_id,
            "reason": reason,
            "user_message": user_message
        })

        return state

    def _rollback_state_to_node(
        self,
        state: Dict[str, Any],
        target_node: str
    ) -> Dict[str, Any]:
        node_execution_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})
        workflow_steps = self.engine_context.steps

        restored_state = self.rollback_strategy.rollback_to_node(
            state=state,
            target_node=target_node,
            node_execution_order=node_execution_order,
            node_field_map=node_field_map,
            workflow_steps=workflow_steps
        )

        for key, value in restored_state.items():
            context_value = self.engine_context.get_context_value(key)
            if context_value is not None:
                restored_state[key] = context_value

        if not restored_state:
            logger.warning(f"Rollback strategy returned empty state for node '{target_node}'")
            return {}

        restored_state[WorkflowKeys.STATUS] = f"{self.step_id}_{target_node}"

        return restored_state

    def _process_transitions(
        self,
        state: Dict[str, Any],
        conversation: List,
        agent_response: str
    ) -> Dict[str, Any]:
        matched = False
        self._set_status(state, 'collecting')

        # Extract dynamic options if present (pattern matching mode)
        result = self._extract_options_from_response(agent_response)
        cleaned_response = result.message

        # Update instance variables for use in self-loop scenarios (validation/collection failure)
        self.options = result.options
        self.is_selectable = result.is_selectable

        for transition in self.transitions:
            patterns = transition['pattern']
            if isinstance(patterns, str):
                patterns = [patterns]

            matched_pattern = None
            for pattern in patterns:
                if pattern in cleaned_response:
                    matched_pattern = pattern
                    break

            if not matched_pattern:
                continue

            matched = True
            next_step = transition['next']

            logger.info(f"Matched transition: {transition}")

            value = cleaned_response.split(matched_pattern)[1].strip()
            if value:
                self._store_field_value(state, value)
                is_valid_input, validation_error_message = self._validate_collected_input(state)
                if not is_valid_input:
                    return self._handle_validation_failure(state, conversation, message=validation_error_message)
                state[WorkflowKeys.MESSAGES] = [f"✓ {self._formatted_field_name} collected: {value}" ]
            else:
                state[WorkflowKeys.MESSAGES] = []

            self._set_status(state, next_step)

            if next_step in self.engine_context.outcome_map:
                self._set_outcome(state, next_step)

            break

        if not matched:
            logger.info(f"No transition matched for response in step '{self.step_id}', continuing collection")
            state[WorkflowKeys.MESSAGES] = []

        return state

    def _handle_structured_output_transition(self, state: Dict[str, Any], conversation: List, agent_response: Any, user_message: str = "") -> Dict[str, Any]:

        try:
            agent_response = json.loads(agent_response) if isinstance(agent_response, str) else agent_response
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

        # Check for out-of-scope first (before intent change)
        if self.enable_out_of_scope and (out_of_scope_reason := agent_response.get("out_of_scope")):
            return self._handle_out_of_scope(out_of_scope_reason, state, user_message)

        if target_node := agent_response.get("intent_change"):
            return self._handle_intent_change(target_node, state)

        self._set_status(state, "collecting")

        if bot_response := agent_response.get("bot_response"):
            # Carry options metadata on conversation message for self-loop pickup
            options = agent_response.get("options") or self.options
            is_selectable = agent_response.get("is_selectable") if agent_response.get("is_selectable") is not None else self.is_selectable

            # Update instance variables for use in self-loop scenarios
            self.options = options
            self.is_selectable = is_selectable

            # Serialize structured data as JSON in content field
            content_data = {
                "text": bot_response,
                "options": options,
                "is_selectable": is_selectable
            }
            conversation.append({
                "role": "assistant",
                "content": json.dumps(content_data)
            })

            # Store partial values if multi-field OR if structured output is enabled
            if self.is_multi_field or (self.agent_config and self.agent_config.get('structured_output', {}).get('enabled')):
                if self.is_multi_field:
                    self._store_field_values(state, agent_response)
                else:
                    structured_config = self.agent_config.get('structured_output', {})
                    fields_config = structured_config.get('fields', [])
                    field_values = {}
                    for field_def in fields_config:
                        field_name = field_def.get("name")
                        if field_name and field_name in agent_response:
                            field_values[field_name] = agent_response[field_name]

                    # Store all fields in _partial_data using nested dict format
                    # to preserve partial data for field_details display
                    self.engine_context._store_partial_data(state, self.primary_field, field_values)

            return state

        # If no bot_response (agent intends to submit data), validate that all REQUIRED fields are present
        if self.agent_config and self.agent_config.get('structured_output', {}).get('enabled'):
            structured_config = self.agent_config.get('structured_output', {})
            fields_config = structured_config.get('fields', [])
            
            missing_required_fields = []
            field_values = {}

            for field_def in fields_config:
                field_name = field_def.get("name")
                is_required = field_def.get("required", True)
                field_value = agent_response.get(field_name)

                if field_name and field_name in agent_response:
                    field_values[field_name] = agent_response[field_name]

                # Skip framework metadata fields
                if field_name in COLLECT_INPUT_METADATA_FIELDS or is_required is False:
                    continue

                if field_value is None:
                    missing_required_fields.append(field_name)
                    continue

                # If field is required but missing/None in response
                if is_required and field_value is None:
                    missing_required_fields.append(field_name)

            # to preserve partial data for field_details display
            self.engine_context._store_partial_data(state, self.primary_field, field_values)

            # Update engine context with renamed keys for backward compatibility
            renamed_values = {f"{self.primary_field}_{k}": v for k, v in field_values.items()}
            self.engine_context.update_context(renamed_values)
            if missing_required_fields:
                error_msg = f"The following required fields are missing: {', '.join(missing_required_fields)}. Please provide the missing fields and submit again."
                logger.warning(f"Structured output missing required fields: {missing_required_fields}")
                # Treat as validation failure to give agent feedback
                return self._handle_validation_failure(state, conversation, message=error_msg)
            self._store_field_value(state, field_values)
            self.engine_context.update_context({self.primary_field: field_values})

        # Validate
        is_valid_input, validation_error_message = self._validate_collected_input(state)
        if not is_valid_input:
            self.engine_context._store_partial_data(state, self.primary_field, None)
            return self._handle_validation_failure(state, conversation, message=validation_error_message)

        # For multi-field, check if all fields are collected
        if self.is_multi_field:
            missing = self._get_missing_fields(state)
            if missing:
                # Still missing fields - continue collecting
                return state

        # Proceed to transition
        if next_node := self._find_matching_transition(agent_response):
            return self._complete_collection(state, next_node, agent_response)

        if self.next_step:
            return self._complete_collection(state, self.next_step, agent_response)

        return self._handle_collection_failure(state, conversation)

    def _handle_validation_failure(self, state: Dict[str, Any], conversation: List, message: Optional[str]=VALIDATION_ERROR_MESSAGE, role="assistant") -> Dict[str, Any]:
        if self.is_multi_field:
            # Only clear fields that are already None (set by _validate_collected_input)
            # Valid fields are preserved so the user doesn't have to re-enter them
            for field_name in self.fields:
                if state.get(field_name) is None:
                    self.engine_context.update_context({field_name: None})
        else:
            self._store_field_value(state, None)
            self.engine_context.update_context({self.primary_field: None})

        # Apply template rendering and humanization
        message = self._apply_humanization(message, state)

        # Serialize structured data as JSON in content field
        content_data = {
            "text": message,
            "options": self.options,
            "is_selectable": self.is_selectable
        }
        conversation.append({"role": role, "content": json.dumps(content_data)})
        return state

    def _find_matching_transition(self, agent_response: Any) -> Optional[str]:
        for transition in self.transitions:
            next_node = transition.get("next")
            match_value = transition.get("match")
            ref_field = transition.get("ref")

            if not next_node or not ref_field or match_value is None:
                raise RuntimeError(f"Transition in step '{self.step_id}' missing required properties for structured output routing")

            field_value = agent_response.get(ref_field)
            if isinstance(match_value, list):
                if field_value in match_value:
                    return next_node
            elif field_value == match_value:
                return next_node

        return None

    def _complete_collection(self, state: Dict[str, Any], next_node: str, agent_response: Any) -> Dict[str, Any]:
        self._set_status(state, next_node)

        if next_node in self.engine_context.outcome_map:
            self._set_outcome(state, next_node)

        # Build message showing collected fields
        if self.is_multi_field:
            collected = {f: state.get(f) for f in self.fields if state.get(f) is not None}
            state[WorkflowKeys.MESSAGES] = [f"✓ Collected: {collected}"]
        else:
            state[WorkflowKeys.MESSAGES] = [
                f"✓ {self._formatted_field_name} collected: {str(agent_response)}"
            ]

        return state

    def _handle_collection_failure(self, state: Dict[str, Any], conversation: List) -> Dict[str, Any]:
        # Apply template rendering and humanization
        message = self._apply_humanization(COLLECTION_FAILURE_MESSAGE, state)

        # Serialize structured data as JSON in content field
        content_data = {
            "text": message,
            "options": self.options,
            "is_selectable": self.is_selectable
        }
        conversation.append({"role": "assistant", "content": json.dumps(content_data)})
        self._store_field_value(state, None)
        return state


    def _store_field_value(self, state: Dict[str, Any], value: Any):
        """Store field value(s). For multi-field, value is a dict."""
        if self.is_multi_field and isinstance(value, dict):
            self._store_field_values(state, value)
        elif not self.is_multi_field:
            # Legacy single-field behavior
            field_def = next((f for f in self.engine_context.data_fields if f['name'] == self.primary_field), None)
            if field_def and field_def.get('type') == 'number':
                try:
                    state[self.primary_field] = int(value)
                except (ValueError, TypeError):
                    state[self.primary_field] = value
            else:
                state[self.primary_field] = value

    def _store_field_values(self, state: Dict[str, Any], values: Dict[str, Any], fields: Optional[List[str]] = None):
        """Store multiple field values from structured output."""
        target_fields = fields or self.fields
        
        # Build local type map from structured output config if available
        local_field_map = {}
        if self.agent_config:
             so_fields = self.agent_config.get('structured_output', {}).get('fields', [])
             for f in so_fields:
                 if f_name := f.get('name'):
                     local_field_map[f_name] = f.get('type')

        for field_name in target_fields:
            if field_name in values and values[field_name] is not None:
                value = values[field_name]
                
                # Check global data fields first
                field_def = next((f for f in self.engine_context.data_fields if f['name'] == field_name), None)
                field_type = field_def.get('type') if field_def else None
                
                # Fallback to local structured output config
                if not field_type:
                    field_type = local_field_map.get(field_name)

                if field_type == 'number':
                    try:
                        state[field_name] = int(value)
                    except (ValueError, TypeError):
                        state[field_name] = value
                else:
                    state[field_name] = value
