"""S3 fetcher for OmniFetcher."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

import boto3
from botocore.exceptions import ClientError

from omni_fetcher.core.registry import source
from omni_fetcher.fetchers.base import BaseFetcher
from omni_fetcher.schemas.atomics import TextDocument, TextFormat
from omni_fetcher.schemas.containers import S3Bucket, S3Object
from omni_fetcher.auth import AuthConfig


@source(
    name="s3",
    uri_patterns=["s3://", "s3.amazonaws.com"],
    priority=10,
    description="Fetch files from AWS S3",
)
class S3Fetcher(BaseFetcher):
    """Fetcher for AWS S3 objects.

    Supports auth via:
    - Constructor: S3Fetcher(aws_access_key_id='xxx', aws_secret_access_key='yyy')
    - set_auth: fetcher.set_auth(AuthConfig(type='aws', ...))
    - OmniFetcher auth registry
    """

    name = "s3"
    priority = 10

    def __init__(
        self,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        region_name: str = "us-east-1",
    ):
        super().__init__()
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.region_name = region_name

    def set_auth(self, auth_config: AuthConfig) -> None:
        """Set auth from AuthConfig."""
        self._auth_config = auth_config

        if auth_config.type == "aws":
            creds = auth_config.get_aws_credentials()
            self.aws_access_key_id = creds.get("aws_access_key_id")
            self.aws_secret_access_key = creds.get("aws_secret_access_key")
            self.region_name = creds.get("region_name", "us-east-1")

    @classmethod
    def can_handle(cls, uri: str) -> bool:
        """Check if this is an S3 URI."""
        return uri.startswith("s3://") or ".s3.amazonaws.com" in uri

    def _is_bucket_list(self, uri: str) -> bool:
        """Check if URI represents a bucket listing (no key)."""
        bucket, key = self._parse_s3_uri(uri)
        return key == "" or key.endswith("/")

    async def fetch(self, uri: str, **kwargs: Any) -> Any:
        """Fetch from S3.

        Args:
            uri: S3 URI (s3://bucket or s3://bucket/key)
            max_keys: Maximum keys to list for bucket

        Returns:
            S3Bucket for bucket listing, S3Object content for object
        """
        bucket, key = self._parse_s3_uri(uri)

        if key == "" or key.endswith("/"):
            return await self._list_bucket(uri, bucket, key, kwargs)
        return await self._get_object(uri, bucket, key)

    async def _list_bucket(
        self, uri: str, bucket: str, prefix: str, kwargs: dict[str, Any]
    ) -> S3Bucket:
        """List objects in bucket."""
        max_keys = kwargs.get("max_keys", 1000)

        def _list():
            client = boto3.client(
                "s3",
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key,
                region_name=self.region_name,
            )
            params = {"Bucket": bucket, "MaxKeys": max_keys}
            if prefix:
                params["Prefix"] = prefix
            return client.list_objects_v2(**params)

        import asyncio

        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(None, _list)

        items = []
        for obj in response.get("Contents", []):
            items.append(
                S3Object(
                    key=obj.get("Key", ""),
                    size=obj.get("Size"),
                    last_modified=obj.get("LastModified"),
                    etag=obj.get("ETag", "").strip('"'),
                )
            )

        continuation_token = response.get("NextContinuationToken")

        return S3Bucket(
            source_uri=uri,
            fetched_at=datetime.now(),
            source_name=self.name,
            bucket_name=bucket,
            prefix=prefix if prefix else None,
            items=items,
            item_count=len(items),
            fetched_fully=continuation_token is None,
            continuation_token=continuation_token,
        )

    async def _get_object(self, uri: str, bucket: str, key: str) -> TextDocument:
        """Get object from S3."""
        obj_data = await self._fetch_object(bucket, key)

        return TextDocument(
            source_uri=uri,
            content=obj_data["content"],
            format=TextFormat.PLAIN,
        )

    def _parse_s3_uri(self, uri: str) -> tuple[str, str]:
        """Parse S3 URI into bucket and key."""
        if uri.startswith("s3://"):
            uri = uri[5:]
            parts = uri.split("/", 1)
            bucket = parts[0]
            key = parts[1] if len(parts) > 1 else ""
        elif ".s3.amazonaws.com" in uri:
            uri = uri.replace("https://", "").replace("http://", "")
            if "/?" in uri:
                parts = uri.split("/?", 1)
                bucket = parts[0]
                key = ""
            else:
                parts = uri.split(".s3.amazonaws.com/", 1)
                bucket = parts[0]
                key = parts[1] if len(parts) > 1 else ""
        else:
            raise ValueError(f"Invalid S3 URI: {uri}")

        return bucket, key

    async def _fetch_object(self, bucket: str, key: str) -> dict[str, Any]:
        """Get object from S3."""

        def _fetch():
            client = boto3.client(
                "s3",
                aws_access_key_id=self.aws_access_key_id,
                aws_secret_access_key=self.aws_secret_access_key,
                region_name=self.region_name,
            )

            try:
                response = client.get_object(Bucket=bucket, Key=key)
                content = response["Body"].read().decode("utf-8")

                return {
                    "content": content,
                    "content_type": response.get("ContentType", "application/octet-stream"),
                    "content_length": response.get("ContentLength"),
                }
            except ClientError as e:
                raise ValueError(f"Failed to get S3 object: {e}")

        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _fetch)
