"""Local file fetcher for OmniFetcher."""

from __future__ import annotations

import os
import mimetypes
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from omni_fetcher.core.registry import source
from omni_fetcher.fetchers.base import BaseFetcher
from omni_fetcher.schemas.base import FetchMetadata
from omni_fetcher.schemas.atomics import (
    VideoDocument,
    AudioDocument,
    ImageDocument,
    TextDocument,
    TextFormat,
)
from omni_fetcher.schemas.documents import PDFDocument
from omni_fetcher.schemas.structured import JSONData, YAMLData


@source(
    name="local_file",
    uri_patterns=["file:///*", "file:///.*", "/.*", "^[A-Za-z]:\\.*"],
    mime_types=["*/*"],
    priority=10,
    description="Fetch files from local filesystem",
)
class LocalFileFetcher(BaseFetcher):
    """Fetcher for local files."""

    name = "local_file"
    priority = 10

    def __init__(self):
        super().__init__()
        mimetypes.init()

    @classmethod
    def can_handle(cls, uri: str) -> bool:
        """Check if this is a local file URI."""
        return uri.startswith("file://") or os.path.isabs(uri)

    async def fetch(self, uri: str, **kwargs: Any) -> Any:
        """Fetch a local file.

        Args:
            uri: File path (absolute or file:// URI)
            **kwargs: Additional options (transcribe, whisper_model for audio)

        Returns:
            Appropriate Pydantic model based on file type
        """
        if uri.startswith("file://"):
            path = uri[7:]
            if path.startswith("/") and not os.name == "nt":
                pass
            elif os.name == "nt" and len(path) > 1 and path[1] == ":":
                pass
            else:
                path = uri.replace("file://localhost/", "").replace("file:///", "")
        else:
            path = uri

        path_obj = Path(path).resolve()

        if not path_obj.exists():
            raise FileNotFoundError(f"File not found: {path}")

        if not path_obj.is_file():
            raise ValueError(f"Not a file: {path}")

        stat = path_obj.stat()
        file_size = stat.st_size
        mime_type = self._guess_mime_type(path)

        metadata = FetchMetadata(
            source_uri=uri,
            fetched_at=datetime.now(),
            source_name=self.name,
            mime_type=mime_type,
            file_size=file_size,
            last_modified=datetime.fromtimestamp(stat.st_mtime),
        )

        return await self._create_result(path_obj, metadata, mime_type, uri, stat, kwargs)

    def _guess_mime_type(self, path: str) -> Optional[str]:
        """Guess MIME type from file extension."""
        mime_type, _ = mimetypes.guess_type(path)
        return mime_type

    async def _create_result(
        self,
        path: Path,
        metadata: FetchMetadata,
        mime_type: Optional[str],
        uri: str,
        stat: Any,
        kwargs: dict[str, Any],
    ) -> Any:
        """Create appropriate result model based on file type."""
        content = None

        if mime_type:
            if mime_type.startswith("text/"):
                try:
                    content = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    content = path.read_text(encoding="latin-1")

                if mime_type == "text/markdown":
                    return TextDocument(
                        source_uri=metadata.source_uri,
                        content=content,
                        format=TextFormat.MARKDOWN,
                        encoding="utf-8",
                    )
                elif mime_type == "text/html":
                    from omni_fetcher.schemas.documents import WebPageDocument

                    return WebPageDocument(
                        metadata=metadata,
                        text=TextDocument(
                            source_uri=metadata.source_uri,
                            content=content,
                            format=TextFormat.HTML,
                        ),
                        title=path.stem,
                    )
                else:
                    return TextDocument(
                        source_uri=metadata.source_uri,
                        content=content,
                        format=TextFormat.PLAIN,
                        encoding="utf-8",
                    )

            elif mime_type == "application/json":
                import json

                try:
                    data = json.loads(path.read_text())
                except json.JSONDecodeError:
                    data = {}

                return JSONData(
                    metadata=metadata,
                    data=data,
                    root_keys=list(data.keys()) if isinstance(data, dict) else None,
                    is_array=isinstance(data, list),
                )

            elif mime_type in ["application/x-yaml", "text/yaml"]:
                try:
                    import yaml

                    data = yaml.safe_load(path.read_text())
                except ImportError:
                    data = {}
                except Exception:
                    data = {}

                return YAMLData(
                    metadata=metadata,
                    data=data,
                    root_keys=list(data.keys()) if isinstance(data, dict) else None,
                )

            elif mime_type == "application/pdf":
                return PDFDocument(
                    metadata=metadata,
                    text=TextDocument(
                        source_uri=metadata.source_uri,
                        content="",
                        format=TextFormat.PLAIN,
                    ),
                )

            elif mime_type.startswith("video/"):
                video_format = mime_type.split("/")[-1] if mime_type else "unknown"
                return VideoDocument(
                    source_uri=uri,
                    duration_seconds=0.0,
                    format=video_format,
                    file_name=path.name,
                    file_size_bytes=stat.st_size,
                )

            elif mime_type.startswith("audio/"):
                return await self._create_audio_result(path, metadata, uri, stat, mime_type, kwargs)

            elif mime_type.startswith("image/"):
                image_format = mime_type.split("/")[-1] if mime_type else "unknown"
                return ImageDocument(
                    source_uri=uri,
                    format=image_format,
                    file_name=path.name,
                    file_size_bytes=stat.st_size,
                )

        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = path.read_text(encoding="latin-1")

        return TextDocument(
            source_uri=metadata.source_uri,
            content=content,
            format=TextFormat.PLAIN,
            encoding="utf-8",
        )

    async def _create_audio_result(
        self,
        path: Path,
        metadata: FetchMetadata,
        uri: str,
        stat: Any,
        mime_type: Optional[str],
        kwargs: dict[str, Any],
    ) -> AudioDocument:
        """Create AudioDocument with metadata from mutagen."""
        audio_format = mime_type.split("/")[-1] if mime_type else "unknown"

        duration_seconds = 0.0
        sample_rate = None
        channels = None
        artist = None
        album = None
        title = None
        year = None
        genre = None
        track_number = None

        try:
            import mutagen

            audio_file = mutagen.File(str(path))
            if audio_file is not None:
                if hasattr(audio_file.info, "length"):
                    duration_seconds = float(audio_file.info.length)
                if hasattr(audio_file.info, "sample_rate"):
                    sample_rate = int(audio_file.info.sample_rate)
                if hasattr(audio_file.info, "channels"):
                    channels = int(audio_file.info.channels)

                if hasattr(audio_file, "tags") and audio_file.tags:
                    tags = audio_file.tags
                    artist = self._get_tag(tags, ["artist", "TPE1", "TPE2"])
                    album = self._get_tag(tags, ["album", "TALB"])
                    title = self._get_tag(tags, ["title", "TIT2"])
                    year = self._get_tag(tags, ["date", "TDRC", "year"])
                    genre = self._get_tag(tags, ["genre", "TCON"])
                    track_number = self._get_tag(tags, ["tracknumber", "TRCK"])

                    if year:
                        try:
                            year = int(str(year)[:4])
                        except (ValueError, TypeError):
                            year = None
                    if track_number:
                        try:
                            if isinstance(track_number, str) and "/" in track_number:
                                track_number = int(track_number.split("/")[0])
                            else:
                                track_number = int(track_number)
                        except (ValueError, TypeError):
                            track_number = None

        except ImportError:
            pass

        transcript = None
        transcribe = kwargs.get("transcribe", False)
        if transcribe:
            transcript = await self._transcribe_audio(path, kwargs)

        return AudioDocument(
            source_uri=uri,
            duration_seconds=duration_seconds,
            format=audio_format,
            sample_rate=sample_rate,
            channels=channels,
            file_name=path.name,
            file_size_bytes=stat.st_size,
            artist=artist,
            album=album,
            title=title,
            year=year,
            genre=genre,
            track_number=track_number,
            transcript=transcript,
        )

    def _get_tag(self, tags: Any, keys: list[str]) -> Optional[str]:
        """Extract tag value from mutagen tags."""
        for key in keys:
            if key in tags:
                value = tags[key]
                if hasattr(value, "text"):
                    return value.text[0] if value.text else None
                if isinstance(value, list) and value:
                    return str(value[0])
                if value:
                    return str(value)
        return None

    async def _transcribe_audio(self, path: Path, kwargs: dict[str, Any]) -> Optional[TextDocument]:
        """Transcribe audio using Whisper."""
        try:
            import whisper

            model_name = kwargs.get("whisper_model", "base")
            model = whisper.load_model(model_name)

            def _transcribe():
                return model.transcribe(str(path))

            import asyncio

            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, _transcribe)

            language = result.get("language")
            text = result.get("text", "").strip()

            if text:
                return TextDocument(
                    source_uri=str(path),
                    content=text,
                    format=TextFormat.TRANSCRIPT,
                    language=language,
                )

        except ImportError:
            raise ImportError("Whisper is not installed. Install with: pip install openai-whisper")
        except Exception:
            pass

        return None
