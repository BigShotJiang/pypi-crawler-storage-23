"""RSS/Atom feed fetcher for OmniFetcher."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

import feedparser

from omni_fetcher.core.registry import source
from omni_fetcher.fetchers.base import BaseFetcher
from omni_fetcher.schemas.containers import RSSFeed, RSSItem


@source(
    name="rss",
    uri_patterns=["feed", "rss", "atom", "rss.xml", ".rss"],
    mime_types=["application/rss+xml", "application/atom+xml", "application/xml"],
    priority=15,
    description="Fetch and parse RSS/Atom feeds",
)
class RSSFetcher(BaseFetcher):
    """Fetcher for RSS and Atom feeds."""

    name = "rss"
    priority = 15

    FEED_EXTENSIONS = [".rss", ".atom", ".feed", ".rdf"]
    FEED_PATTERNS = ["feed", "rss", "atom", "rss.xml"]

    def __init__(self):
        super().__init__()

    @classmethod
    def can_handle(cls, uri: str) -> bool:
        """Check if this is an RSS/Atom feed URL."""
        uri_lower = uri.lower()

        for ext in cls.FEED_EXTENSIONS:
            if uri_lower.endswith(ext):
                return True

        for pattern in cls.FEED_PATTERNS:
            if pattern in uri_lower:
                return True

        return False

    async def fetch(self, uri: str, **kwargs: Any) -> RSSFeed:
        """Fetch and parse an RSS/Atom feed.

        Args:
            uri: Feed URL
            max_items: Maximum number of items to return (default: all)
            container: If True, returns RSSFeed container; if False, returns JSONData (default: True)

        Returns:
            RSSFeed container with items
        """
        max_items = kwargs.get("max_items")

        feed_data = await self._parse_feed(uri, max_items)

        items = [
            RSSItem(
                title=item.get("title"),
                link=item.get("link"),
                summary=item.get("summary"),
                content=item.get("content"),
                author=item.get("author"),
                published=item.get("published"),
                updated=item.get("updated"),
                guid=item.get("guid"),
                tags=item.get("tags"),
            )
            for item in feed_data.get("entries", [])
        ]

        feed = RSSFeed(
            source_uri=uri,
            fetched_at=datetime.now(),
            source_name=self.name,
            title=feed_data.get("title"),
            description=feed_data.get("description"),
            link=feed_data.get("link"),
            language=feed_data.get("language"),
            updated=feed_data.get("updated"),
            items=items,
            item_count=len(items),
            fetched_fully=max_items is None or len(items) < max_items,
        )

        return feed

    async def _parse_feed(self, uri: str, max_items: Optional[int] = None) -> dict[str, Any]:
        """Parse the feed using feedparser."""

        def _parse():
            return feedparser.parse(uri)

        import asyncio

        loop = asyncio.get_event_loop()
        feed = await loop.run_in_executor(None, _parse)

        feed_data = {
            "title": feed.feed.get("title", ""),
            "description": feed.feed.get("description", ""),
            "link": feed.feed.get("link", ""),
            "language": feed.feed.get("language", ""),
            "updated": feed.feed.get("updated", ""),
            "entries": [],
        }

        entries = feed.entries
        if max_items is not None:
            entries = entries[:max_items]

        for entry in entries:
            parsed_entry = self._parse_entry(entry)
            feed_data["entries"].append(parsed_entry)

        return feed_data

    def _parse_entry(self, entry: Any) -> dict[str, Any]:
        """Parse a single feed entry."""
        result = {
            "title": entry.get("title", ""),
            "link": entry.get("link", ""),
            "summary": entry.get("summary", ""),
            "content": entry.get("content", [{}])[0].get("value", "")
            if entry.get("content")
            else "",
            "author": entry.get("author", ""),
            "published": entry.get("published", ""),
            "updated": entry.get("updated", ""),
            "guid": entry.get("id", entry.get("link", "")),
        }

        if hasattr(entry, "tags") and entry.tags:
            result["tags"] = [tag.term for tag in entry.tags]

        if hasattr(entry, "author_detail"):
            result["author"] = entry.author_detail.get("name", "")

        return result
