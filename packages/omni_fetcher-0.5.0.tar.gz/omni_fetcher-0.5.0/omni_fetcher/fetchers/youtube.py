"""YouTube fetcher for OmniFetcher."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Optional

import yt_dlp

from omni_fetcher.core.registry import source
from omni_fetcher.fetchers.base import BaseFetcher
from omni_fetcher.schemas.base import FetchMetadata
from omni_fetcher.schemas.media import YouTubeVideo
from omni_fetcher.schemas.atomics import (
    TextDocument,
    ImageDocument,
    TextFormat,
)
from omni_fetcher.schemas.containers import YouTubePlaylist


@source(
    name="youtube",
    uri_patterns=["youtube.com", "youtu.be", "ytb:"],
    mime_types=["video/*"],
    priority=5,
    description="Fetch video metadata from YouTube",
)
class YouTubeFetcher(BaseFetcher):
    """Fetcher for YouTube videos and playlists."""

    name = "youtube"
    priority = 5

    YOUTUBE_DOMAINS = [
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "www.youtu.be",
    ]

    def __init__(self, api_key: Optional[str] = None):
        super().__init__()
        self.api_key = api_key
        self._ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "extract_flat": False,
        }

    @classmethod
    def can_handle(cls, uri: str) -> bool:
        """Check if this is a YouTube URL."""
        uri_lower = uri.lower()
        return any(domain in uri_lower for domain in cls.YOUTUBE_DOMAINS)

    def _is_playlist(self, uri: str) -> bool:
        """Check if URI is a playlist URL."""
        uri_lower = uri.lower()
        return "playlist" in uri_lower or "list=" in uri_lower

    def _extract_playlist_id(self, uri: str) -> Optional[str]:
        """Extract playlist ID from URL."""
        match = re.search(r"[?&]list=([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)
        match = re.search(r"youtube\.com/playlist\?list=([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)
        return None

    async def fetch(self, uri: str, **kwargs: Any) -> YouTubeVideo | YouTubePlaylist:
        """Fetch video or playlist from YouTube.

        Args:
            uri: YouTube URL (video or playlist)
            max_items: Maximum items for playlists

        Returns:
            YouTubeVideo for single video, YouTubePlaylist for playlist
        """
        if self._is_playlist(uri):
            return await self._fetch_playlist(uri, kwargs)
        return await self._fetch_video(uri)

    async def _fetch_video(self, uri: str) -> YouTubeVideo:
        """Fetch a single video."""
        video_id = self._extract_video_id(uri)

        if not video_id:
            raise ValueError(f"Could not extract video ID from: {uri}")

        video_info = await self._get_video_info(video_id)

        actual_id = video_info.get("id", video_id)

        metadata = FetchMetadata(
            source_uri=uri,
            fetched_at=datetime.now(),
            source_name=self.name,
            mime_type="video/mp4",
        )

        duration = video_info.get("duration")
        duration_seconds = duration if isinstance(duration, (int, float)) else None

        upload_date = video_info.get("upload_date")
        if upload_date:
            try:
                upload_date = datetime.strptime(upload_date, "%Y%m%d")
            except ValueError:
                upload_date = None

        view_count = video_info.get("view_count")
        like_count = video_info.get("like_count")

        tags = video_info.get("tags", [])

        categories = video_info.get("categories", [])
        category = categories[0] if categories else None

        is_live = video_info.get("is_live", False) or video_info.get("live_status") == "is_live"

        thumbnails = video_info.get("thumbnail", "")
        thumbnail_url = (
            video_info.get("thumbnails", [{}])[0].get("url")
            if video_info.get("thumbnails")
            else thumbnails
        )

        return YouTubeVideo(
            metadata=metadata,
            video_id=actual_id,
            title=video_info.get("title", "Unknown"),
            text=TextDocument(
                source_uri=uri,
                content=video_info.get("description", ""),
                format=TextFormat.PLAIN,
            )
            if video_info.get("description")
            else None,
            duration_seconds=duration_seconds,
            width=video_info.get("width"),
            height=video_info.get("height"),
            uploader=video_info.get("uploader", ""),
            uploader_url=video_info.get("uploader_url", ""),
            upload_date=upload_date,
            view_count=view_count,
            like_count=like_count,
            tags=tags if tags else None,
            video_category=category,
            license=video_info.get("license"),
            is_live=is_live,
            is_private=video_info.get("private", False),
            thumbnail=ImageDocument(
                source_uri=thumbnail_url,
                format="jpeg",
            )
            if thumbnail_url
            else None,
        )

    async def _fetch_playlist(self, uri: str, kwargs: dict[str, Any]) -> YouTubePlaylist:
        """Fetch a playlist."""
        playlist_id = self._extract_playlist_id(uri)
        max_items = kwargs.get("max_items", 100)

        if not playlist_id:
            raise ValueError(f"Could not extract playlist ID from: {uri}")

        def _fetch():
            ydl = yt_dlp.YoutubeDL(
                {"quiet": True, "no_warnings": True, "extract_flat": "in_playlist"}
            )
            return ydl.extract_info(uri, download=False)

        import asyncio

        loop = asyncio.get_event_loop()
        playlist_info = await loop.run_in_executor(None, _fetch)

        entries = (
            playlist_info.get("entries", [])[:max_items] if playlist_info.get("entries") else []
        )

        videos = []
        for entry in entries:
            if entry:
                video = self._entry_to_youtube_video(entry, uri)
                videos.append(video)

        upload_date = playlist_info.get("upload_date")
        if upload_date:
            try:
                upload_date = datetime.strptime(upload_date, "%Y%m%d")
            except ValueError:
                upload_date = None

        return YouTubePlaylist(
            source_uri=uri,
            fetched_at=datetime.now(),
            source_name=self.name,
            playlist_id=playlist_id,
            title=playlist_info.get("title"),
            description=playlist_info.get("description"),
            uploader=playlist_info.get("uploader"),
            uploader_url=playlist_info.get("channel_url"),
            item_count_total=playlist_info.get("playlist_count"),
            view_count=playlist_info.get("view_count"),
            items=videos,
            item_count=len(videos),
            fetched_fully=max_items is None or len(videos) >= max_items,
        )

    def _entry_to_youtube_video(self, entry: dict[str, Any], uri: str) -> YouTubeVideo:
        """Convert yt-dlp entry to YouTubeVideo."""
        duration = entry.get("duration")
        duration_seconds = duration if isinstance(duration, (int, float)) else None

        upload_date = entry.get("upload_date")
        if upload_date:
            try:
                upload_date = datetime.strptime(upload_date, "%Y%m%d")
            except ValueError:
                upload_date = None

        thumbnails = entry.get("thumbnail", "")
        thumbnail_url = (
            entry.get("thumbnails", [{}])[0].get("url") if entry.get("thumbnails") else thumbnails
        )

        return YouTubeVideo(
            video_id=entry.get("id", ""),
            title=entry.get("title", "Unknown"),
            text=TextDocument(
                source_uri=uri,
                content=entry.get("description", ""),
                format=TextFormat.PLAIN,
            )
            if entry.get("description")
            else None,
            duration_seconds=duration_seconds,
            width=entry.get("width"),
            height=entry.get("height"),
            uploader=entry.get("uploader", ""),
            uploader_url=entry.get("uploader_url", ""),
            upload_date=upload_date,
            view_count=entry.get("view_count"),
            like_count=entry.get("like_count"),
            tags=entry.get("tags") if entry.get("tags") else None,
            video_category=entry.get("categories", [None])[0] if entry.get("categories") else None,
            license=entry.get("license"),
            is_live=entry.get("is_live", False),
            is_private=entry.get("private", False),
            thumbnail=ImageDocument(source_uri=thumbnail_url, format="jpeg")
            if thumbnail_url
            else None,
        )

    def _extract_video_id(self, uri: str) -> Optional[str]:
        """Extract video ID from various YouTube URL formats."""
        match = re.search(r"[?&]v=([a-zA-Z0-9_-]{11})", uri)
        if match:
            return match.group(1)

        match = re.search(r"youtu\.be/([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)

        match = re.search(r"youtube\.com/shorts/([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)

        match = re.search(r"youtube\.com/embed/([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)

        match = re.search(r"youtube\.com/v/([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)

        match = re.search(r"youtu\.be/([a-zA-Z0-9_-]+)", uri)
        if match:
            return match.group(1)

        return None

    async def _get_video_info(self, video_id: str) -> dict[str, Any]:
        """Get video information using yt-dlp."""

        def _fetch():
            ydl = yt_dlp.YoutubeDL(self._ydl_opts)
            info = ydl.extract_info(f"https://youtube.com/watch?v={video_id}", download=False)
            return info

        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _fetch)

    async def fetch_metadata(self, uri: str) -> dict[str, Any]:
        """Fetch only metadata (faster, less data)."""
        video_id = self._extract_video_id(uri)

        if not video_id:
            raise ValueError(f"Could not extract video ID from: {uri}")

        def _fetch_minimal():
            ydl = yt_dlp.YoutubeDL({"quiet": True, "extract_flat": True})
            info = ydl.extract_info(f"https://youtube.com/watch?v={video_id}", download=False)
            return info

        import asyncio

        loop = asyncio.get_event_loop()
        info = await loop.run_in_executor(None, _fetch_minimal)

        return {
            "video_id": video_id,
            "title": info.get("title"),
            "duration": info.get("duration"),
            "view_count": info.get("view_count"),
            "thumbnail": info.get("thumbnail"),
        }
