"""Basic unit tests."""


def test_basic():
    """Dummy test to validate test infra."""
    assert 1 + 1 == 2
