"""Document normalization helpers."""
