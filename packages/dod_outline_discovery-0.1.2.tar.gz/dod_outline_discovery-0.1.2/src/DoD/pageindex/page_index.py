"""PDF PageIndex tree construction.

Adapted from VectifyAI/PageIndex (MIT License).
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
import math
import os
import random
import re
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional

from DoD.pageindex.utils import (
    ChatGPT_API_async,
    ChatGPT_API_with_finish_reason_async,
    ConfigLoader,
    JsonLogger,
    LLMCache,
    add_node_text,
    add_preface_if_needed,
    convert_page_to_int,
    convert_physical_index_to_int,
    count_tokens,
    create_clean_structure_for_description,
    extract_json,
    generate_doc_description,
    generate_summaries_for_structure,
    get_json_content,
    get_page_tokens,
    get_pdf_name,
    post_processing,
    remove_structure_text,
    request_llm_cache,
    request_llm_concurrency,
    request_openai_config,
    write_node_id,
)


def _ensure_opt(opt: Any) -> Any:
    """Ensure a config namespace is available."""
    if opt is None:
        return ConfigLoader().load({})
    return opt


def _build_token_prefix(page_list: List[tuple[str, int]]) -> List[int]:
    """Build prefix sums for page token counts."""
    prefix = [0]
    running = 0
    for _, tokens in page_list:
        running += tokens
        prefix.append(running)
    return prefix


def _range_token_sum(prefix: List[int], start_index: int, end_index: int) -> int:
    """Return inclusive token sum for [start_index, end_index] (1-based)."""
    return prefix[end_index] - prefix[start_index - 1]


def _ensure_list(value: Any, context: str) -> List[Dict[str, Any]]:
    """Ensure a value is a list of dicts."""
    if isinstance(value, list):
        return value
    raise ValueError(f"{context} expected a list response, got {type(value)}")


logger = logging.getLogger(__name__)
if logger.level == logging.NOTSET:
    logger.setLevel(logging.INFO)


def _progress(iterable, total: int | None, desc: str):
    try:
        from tqdm import tqdm
    except ImportError:
        return iterable
    return tqdm(iterable, total=total, desc=desc)


################### check title in page #########################################################
async def check_title_appearance(
    item: Dict[str, Any],
    page_list: List[tuple[str, int]],
    start_index: int = 1,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """Check whether a section title appears on a page."""
    title = item["title"]
    if "physical_index" not in item or item["physical_index"] is None:
        return {
            "list_index": item.get("list_index"),
            "answer": "no",
            "title": title,
            "page_number": None,
        }

    page_number = item["physical_index"]
    page_text = page_list[page_number - start_index][0]

    prompt = f"""
    Your job is to check if the given section appears or starts in the given page_text.

    Note: do fuzzy matching, ignore any space inconsistency in the page_text.

    The given section title is {title}.
    The given page_text is {page_text}.

    Reply format:
    {{

        "thinking": <why do you think the section appears or starts in the page_text>
        "answer": "yes or no" (yes if the section appears or starts in the page_text, no otherwise)
    }}
    Directly return the final JSON structure. Do not output anything else."""

    response = await ChatGPT_API_async(model=model, prompt=prompt)
    response = extract_json(response)
    if "answer" in response:
        answer = response["answer"]
    else:
        answer = "no"
    result = {
        "list_index": item["list_index"],
        "answer": answer,
        "title": title,
        "page_number": page_number,
    }
    return result


async def check_title_appearance_in_start(
    title: str,
    page_text: str,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> str:
    """Check if a section title starts at the beginning of page text."""
    prompt = f"""
    You will be given the current section title and the current page_text.
    Your job is to check if the current section starts in the beginning of the given page_text.
    If there are other contents before the current section title, then the current section does not start in the beginning of the given page_text.
    If the current section title is the first content in the given page_text, then the current section starts in the beginning of the given page_text.

    Note: do fuzzy matching, ignore any space inconsistency in the page_text.

    The given section title is {title}.
    The given page_text is {page_text}.

    reply format:
    {{
        "thinking": <why do you think the section appears or starts in the page_text>
        "start_begin": "yes or no" (yes if the section starts in the beginning of the page_text, no otherwise)
    }}
    Directly return the final JSON structure. Do not output anything else."""

    response = await ChatGPT_API_async(model=model, prompt=prompt)
    response = extract_json(response)
    if logger:
        logger.debug(f"Response: {response}")
    return response.get("start_begin", "no")


async def check_title_appearance_in_start_concurrent(
    structure: List[Dict[str, Any]],
    page_list: List[tuple[str, int]],
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> List[Dict[str, Any]]:
    """Check title appearance at page starts concurrently."""
    if logger:
        logger.info("Checking title appearance in start concurrently")

    # skip items without physical_index
    for item in structure:
        if item.get("physical_index") is None:
            item["appear_start"] = "no"

    # only for items with valid physical_index
    tasks = []
    valid_items = []
    for item in structure:
        if item.get("physical_index") is not None:
            page_text = page_list[item["physical_index"] - 1][0]
            tasks.append(
                check_title_appearance_in_start(
                    item["title"], page_text, model=model, logger=logger
                )
            )
            valid_items.append(item)

    results = await asyncio.gather(*tasks, return_exceptions=True)
    for item, result in zip(valid_items, results):
        if isinstance(result, Exception):
            if logger:
                logger.error(f"Error checking start for {item['title']}: {result}")
            item["appear_start"] = "no"
        else:
            item["appear_start"] = result

    return structure


async def toc_detector_single_page(content: str, model: Optional[str] = None) -> str:
    """Detect whether a page contains a table of contents."""
    prompt = f"""
    Your job is to detect if there is a table of content provided in the given text.

    Given text: {content}

    return the following JSON format:
    {{
        "thinking": <why do you think there is a table of content in the given text>
        "toc_detected": "<yes or no>",
    }}

    Directly return the final JSON structure. Do not output anything else.
    Please note: abstract,summary, notation list, figure list, table list, etc. are not table of contents."""

    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content.get("toc_detected", "no")


async def toc_detector_single_page_async(
    content: str, model: Optional[str] = None
) -> str:
    """Detect whether a page contains a table of contents asynchronously."""
    prompt = f"""
    Your job is to detect if there is a table of content provided in the given text.

    Given text: {content}

    return the following JSON format:
    {{
        "thinking": <why do you think there is a table of content in the given text>
        "toc_detected": "<yes or no>",
    }}

    Directly return the final JSON structure. Do not output anything else.
    Please note: abstract,summary, notation list, figure list, table list, etc. are not table of contents."""

    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content.get("toc_detected", "no")


async def _detect_toc_for_indices(
    indices: List[int],
    page_list: List[tuple[str, int]],
    model: Optional[str],
    concurrent_requests: int,
) -> Dict[int, str]:
    """Run TOC detection concurrently for a set of page indices."""
    semaphore = asyncio.Semaphore(max(1, concurrent_requests))
    results: Dict[int, str] = {}

    async def _detect(index: int) -> None:
        async with semaphore:
            try:
                results[index] = await toc_detector_single_page_async(
                    page_list[index][0], model=model
                )
            except Exception:
                results[index] = "no"

    tasks = [asyncio.create_task(_detect(index)) for index in indices]
    for task in _progress(
        asyncio.as_completed(tasks), total=len(tasks), desc="TOC detect"
    ):
        await task
    return results


async def check_if_toc_extraction_is_complete(
    content: str, toc: str, model: Optional[str] = None
) -> str:
    """Check whether extracted TOC covers the document."""
    prompt = """
    You are given a partial document  and a  table of contents.
    Your job is to check if the  table of contents is complete, which it contains all the main sections in the partial document.

    Reply format:
    {
        "thinking": <why do you think the table of contents is complete or not>
        "completed": "yes" or "no"
    }
    Directly return the final JSON structure. Do not output anything else."""

    prompt = prompt + "\n Document:\n" + content + "\n Table of contents:\n" + toc
    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content["completed"]


async def check_if_toc_transformation_is_complete(
    content: str, toc: str, model: Optional[str] = None
) -> str:
    """Check whether TOC transformation is complete."""
    prompt = """
    You are given a raw table of contents and a  table of contents.
    Your job is to check if the  table of contents is complete.

    Reply format:
    {
        "thinking": <why do you think the cleaned table of contents is complete or not>
        "completed": "yes" or "no"
    }
    Directly return the final JSON structure. Do not output anything else."""

    prompt = (
        prompt
        + "\n Raw Table of contents:\n"
        + content
        + "\n Cleaned Table of contents:\n"
        + toc
    )
    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content["completed"]


async def extract_toc_content(content: str, model: Optional[str] = None) -> str:
    """Extract full table of contents content."""
    prompt = f"""
    Your job is to extract the full table of contents from the given text, replace ... with :

    Given text: {content}

    Directly return the full table of contents content. Do not output anything else."""

    response, finish_reason = await ChatGPT_API_with_finish_reason_async(
        model=model, prompt=prompt
    )

    if_complete = await check_if_toc_transformation_is_complete(
        content, response, model
    )
    if if_complete == "yes" and finish_reason == "finished":
        return response

    chat_history = [
        {"role": "user", "content": prompt},
        {"role": "assistant", "content": response},
    ]
    prompt = """please continue the generation of table of contents , directly output the remaining part of the structure"""
    new_response, finish_reason = await ChatGPT_API_with_finish_reason_async(
        model=model, prompt=prompt, chat_history=chat_history
    )
    response = response + new_response
    if_complete = await check_if_toc_transformation_is_complete(
        content, response, model
    )

    attempts = 0
    max_attempts = 5
    while not (if_complete == "yes" and finish_reason == "finished"):
        attempts += 1
        if attempts >= max_attempts:
            raise Exception(
                "Failed to complete table of contents after maximum retries"
            )
        chat_history = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": response},
        ]
        prompt = """please continue the generation of table of contents , directly output the remaining part of the structure"""
        new_response, finish_reason = await ChatGPT_API_with_finish_reason_async(
            model=model, prompt=prompt, chat_history=chat_history
        )
        response = response + new_response
        if_complete = await check_if_toc_transformation_is_complete(
            content, response, model
        )

    return response


async def detect_page_index(toc_content: str, model: Optional[str] = None) -> str:
    """Detect whether a TOC contains page indices."""
    logger.info("Detecting page indices in TOC.")
    prompt = f"""
    You will be given a table of contents.

    Your job is to detect if there are page numbers/indices given within the table of contents.

    Given text: {toc_content}

    Reply format:
    {{
        "thinking": <why do you think there are page numbers/indices given within the table of contents>
        "page_index_given_in_toc": "<yes or no>"
    }}
    Directly return the final JSON structure. Do not output anything else."""

    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content["page_index_given_in_toc"]


async def toc_extractor(
    page_list: List[tuple[str, int]], toc_page_list: List[int], model: Optional[str]
) -> Dict[str, Any]:
    """Extract TOC content from a set of pages."""

    def transform_dots_to_colon(text):
        text = re.sub(r"\.{5,}", ": ", text)
        # Handle dots separated by spaces
        text = re.sub(r"(?:\. ){5,}\.?", ": ", text)
        return text

    toc_content = ""
    for page_index in toc_page_list:
        toc_content += page_list[page_index][0]
    toc_content = transform_dots_to_colon(toc_content)
    has_page_index = await detect_page_index(toc_content, model=model)

    return {"toc_content": toc_content, "page_index_given_in_toc": has_page_index}


async def toc_index_extractor(
    toc: Any, content: str, model: Optional[str] = None
) -> Any:
    """Assign physical indices to TOC entries."""
    logger.info("Extracting TOC physical indices.")
    tob_extractor_prompt = """
    You are given a table of contents in a json format and several pages of a document, your job is to add the physical_index to the table of contents in the json format.

    The provided pages contains tags like <physical_index_X> and <physical_index_X> to indicate the physical location of the page X.

    The structure variable is the numeric system which represents the index of the hierarchy section in the table of contents. For example, the first section has structure index 1, the first subsection has structure index 1.1, the second subsection has structure index 1.2, etc.

    The response should be in the following JSON format:
    [
        {
            "structure": <structure index, "x.x.x" or None> (string),
            "title": <title of the section>,
            "physical_index": "<physical_index_X>" (keep the format)
        },
        ...
    ]

    Only add the physical_index to the sections that are in the provided pages.
    If the section is not in the provided pages, do not add the physical_index to it.
    Directly return the final JSON structure. Do not output anything else."""

    prompt = (
        tob_extractor_prompt
        + "\nTable of contents:\n"
        + str(toc)
        + "\nDocument pages:\n"
        + content
    )
    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return json_content


async def toc_transformer(toc_content: str, model: Optional[str] = None) -> Any:
    """Transform TOC text into structured JSON."""
    logger.info("Transforming TOC text into structured JSON.")
    init_prompt = """
    You are given a table of contents, You job is to transform the whole table of content into a JSON format included table_of_contents.

    structure is the numeric system which represents the index of the hierarchy section in the table of contents. For example, the first section has structure index 1, the first subsection has structure index 1.1, the second subsection has structure index 1.2, etc.

    The response should be in the following JSON format:
    {
    table_of_contents: [
        {
            "structure": <structure index, "x.x.x" or None> (string),
            "title": <title of the section>,
            "page": <page number or None>,
        },
        ...
        ],
    }
    You should transform the full table of contents in one go.
    Directly return the final JSON structure, do not output anything else. """

    prompt = init_prompt + "\n Given table of contents\n:" + toc_content
    last_complete, finish_reason = await ChatGPT_API_with_finish_reason_async(
        model=model, prompt=prompt
    )
    if_complete = await check_if_toc_transformation_is_complete(
        toc_content, last_complete, model
    )
    if if_complete == "yes" and finish_reason == "finished":
        last_complete = extract_json(last_complete)
        cleaned_response = convert_page_to_int(last_complete["table_of_contents"])
        return cleaned_response

    last_complete = get_json_content(last_complete)
    while not (if_complete == "yes" and finish_reason == "finished"):
        position = last_complete.rfind("}")
        if position != -1:
            last_complete = last_complete[: position + 2]
        prompt = f"""
        Your task is to continue the table of contents json structure, directly output the remaining part of the json structure.
        The response should be in the following JSON format:

        The raw table of contents json structure is:
        {toc_content}

        The incomplete transformed table of contents json structure is:
        {last_complete}

        Please continue the json structure, directly output the remaining part of the json structure."""

        new_complete, finish_reason = await ChatGPT_API_with_finish_reason_async(
            model=model, prompt=prompt
        )

        if new_complete.startswith("```json"):
            new_complete = get_json_content(new_complete)
            last_complete = last_complete + new_complete

        if_complete = await check_if_toc_transformation_is_complete(
            toc_content, last_complete, model
        )

    last_complete = json.loads(last_complete)

    cleaned_response = convert_page_to_int(last_complete["table_of_contents"])
    return cleaned_response


async def find_toc_pages(
    start_page_index: int,
    page_list: List[tuple[str, int]],
    opt: Any,
    logger: Optional[JsonLogger] = None,
) -> List[int]:
    """Find pages likely containing the table of contents."""
    std_logger = logging.getLogger(__name__)
    std_logger.info("Scanning pages for TOC.")
    total_pages = len(page_list)
    if start_page_index >= total_pages:
        return []

    concurrent_requests = max(1, int(getattr(opt, "concurrent_requests", 4)))
    toc_page_list: List[int] = []
    last_page_is_yes = False

    initial_end = min(total_pages, max(start_page_index, opt.toc_check_page_num))
    initial_indices = list(range(start_page_index, initial_end))
    initial_results = await _detect_toc_for_indices(
        initial_indices, page_list, opt.model, concurrent_requests
    )

    for i in _progress(
        initial_indices, total=len(initial_indices), desc="TOC detect (initial)"
    ):
        detected_result = initial_results.get(i, "no")
        if detected_result == "yes":
            if logger:
                logger.info(f"Page {i} has toc")
            toc_page_list.append(i)
            last_page_is_yes = True
        elif detected_result == "no" and last_page_is_yes:
            if logger:
                logger.info(f"Found the last page with toc: {i - 1}")
            return toc_page_list

    if not last_page_is_yes:
        if logger:
            logger.info("No toc found")
        return toc_page_list

    # Preserve existing behavior: continue scanning after toc_check_page_num
    # only when we already found contiguous TOC pages.
    index = initial_end
    batch_size = max(concurrent_requests, 1)
    while index < total_pages:
        batch_end = min(total_pages, index + batch_size)
        batch_indices = list(range(index, batch_end))
        batch_results = await _detect_toc_for_indices(
            batch_indices, page_list, opt.model, concurrent_requests
        )
        for i in _progress(
            batch_indices, total=len(batch_indices), desc="TOC detect (batch)"
        ):
            detected_result = batch_results.get(i, "no")
            if detected_result == "yes":
                if logger:
                    logger.info(f"Page {i} has toc")
                toc_page_list.append(i)
                last_page_is_yes = True
            elif detected_result == "no" and last_page_is_yes:
                if logger:
                    logger.info(f"Found the last page with toc: {i - 1}")
                return toc_page_list
        index = batch_end

    if not toc_page_list and logger:
        logger.info("No toc found")

    return toc_page_list


def remove_page_number(data: Any) -> Any:
    """Remove page number fields from a TOC structure."""
    if isinstance(data, dict):
        data.pop("page_number", None)
        for key in list(data.keys()):
            if "nodes" in key:
                remove_page_number(data[key])
    elif isinstance(data, list):
        for item in data:
            remove_page_number(item)
    return data


def extract_matching_page_pairs(
    toc_page: List[Dict[str, Any]],
    toc_physical_index: List[Dict[str, Any]],
    start_page_index: int,
) -> List[Dict[str, Any]]:
    """Match TOC pages with physical indices to compute offsets."""
    pairs = []
    for phy_item in toc_physical_index:
        for page_item in toc_page:
            if phy_item.get("title") == page_item.get("title"):
                physical_index = phy_item.get("physical_index")
                if (
                    physical_index is not None
                    and int(physical_index) >= start_page_index
                ):
                    pairs.append(
                        {
                            "title": phy_item.get("title"),
                            "page": page_item.get("page"),
                            "physical_index": physical_index,
                        }
                    )
    return pairs


def calculate_page_offset(pairs: List[Dict[str, Any]]) -> Optional[int]:
    """Calculate the most common page offset."""
    differences = []
    for pair in pairs:
        try:
            physical_index = pair["physical_index"]
            page_number = pair["page"]
            difference = physical_index - page_number
            differences.append(difference)
        except (KeyError, TypeError):
            continue

    if not differences:
        return None

    difference_counts = {}
    for diff in differences:
        difference_counts[diff] = difference_counts.get(diff, 0) + 1

    most_common = max(difference_counts.items(), key=lambda x: x[1])[0]

    return most_common


def add_page_offset_to_toc_json(
    data: List[Dict[str, Any]], offset: int
) -> List[Dict[str, Any]]:
    """Apply a page offset to TOC entries."""
    for i in range(len(data)):
        if data[i].get("page") is not None and isinstance(data[i]["page"], int):
            data[i]["physical_index"] = data[i]["page"] + offset
            del data[i]["page"]

    return data


def page_list_to_group_text(
    page_contents: List[str],
    token_lengths: List[int],
    max_tokens: int = 20000,
    overlap_page: int = 1,
) -> List[str]:
    """Group page text into token-limited chunks."""
    num_tokens = sum(token_lengths)

    if num_tokens <= max_tokens:
        # merge all pages into one text
        page_text = "".join(page_contents)
        return [page_text]

    subsets = []
    current_subset = []
    current_token_count = 0

    expected_parts_num = math.ceil(num_tokens / max_tokens)
    average_tokens_per_part = math.ceil(
        ((num_tokens / expected_parts_num) + max_tokens) / 2
    )

    for i, (page_content, page_tokens) in enumerate(zip(page_contents, token_lengths)):
        if current_token_count + page_tokens > average_tokens_per_part:
            subsets.append("".join(current_subset))
            # Start new subset from overlap if specified
            overlap_start = max(i - overlap_page, 0)
            current_subset = page_contents[overlap_start:i]
            current_token_count = sum(token_lengths[overlap_start:i])

        # Add current page to the subset
        current_subset.append(page_content)
        current_token_count += page_tokens

    # Add the last subset if it contains any pages
    if current_subset:
        subsets.append("".join(current_subset))

    logger.info("Divided page list into %s groups.", len(subsets))
    return subsets


def _merge_page_number_results(
    base: List[Dict[str, Any]], results: List[List[Dict[str, Any]]]
) -> List[Dict[str, Any]]:
    merged = copy.deepcopy(base)
    for idx in range(len(merged)):
        candidates: List[int] = []
        for result in results:
            if idx >= len(result):
                continue
            physical_index = result[idx].get("physical_index")
            if isinstance(physical_index, str) and physical_index.startswith(
                "<physical_index_"
            ):
                physical_index = int(physical_index.split("_")[-1].rstrip(">").strip())
            if isinstance(physical_index, int):
                candidates.append(physical_index)
        if candidates:
            merged[idx]["physical_index"] = min(candidates)
        else:
            merged[idx].pop("physical_index", None)
    return merged


async def add_page_number_to_toc(
    part: str, structure: List[Dict[str, Any]], model: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Fill TOC entries with physical indices for a text chunk."""
    fill_prompt_seq = """
    You are given an JSON structure of a document and a partial part of the document. Your task is to check if the title that is described in the structure is started in the partial given document.

    The provided text contains tags like <physical_index_X> and <physical_index_X> to indicate the physical location of the page X.

    If the full target section starts in the partial given document, insert the given JSON structure with the "start": "yes", and "start_index": "<physical_index_X>".

    If the full target section does not start in the partial given document, insert "start": "no",  "start_index": None.

    The response should be in the following format.
        [
            {
                "structure": <structure index, "x.x.x" or None> (string),
                "title": <title of the section>,
                "start": "<yes or no>",
                "physical_index": "<physical_index_X> (keep the format)" or None
            },
            ...
        ]
    The given structure contains the result of the previous part, you need to fill the result of the current part, do not change the previous result.
    Directly return the final JSON structure. Do not output anything else."""

    prompt = (
        fill_prompt_seq
        + f"\n\nCurrent Partial Document:\n{part}\n\nGiven Structure\n{json.dumps(structure, indent=2)}\n"
    )
    current_json_raw = await ChatGPT_API_async(model=model, prompt=prompt)
    json_result = _ensure_list(extract_json(current_json_raw), "add_page_number_to_toc")

    for item in json_result:
        if "start" in item:
            del item["start"]
    return json_result


def remove_first_physical_index_section(text: str) -> str:
    """Remove the first physical-index section from text."""
    pattern = r"<physical_index_\d+>.*?<physical_index_\d+>"
    match = re.search(pattern, text, re.DOTALL)
    if match:
        # Remove the first matched section
        return text.replace(match.group(0), "", 1)
    return text


### add verify completeness
async def generate_toc_continue(
    toc_content: List[Dict[str, Any]],
    part: str,
    model: Optional[str] = "gpt-4o-2024-11-20",
) -> List[Dict[str, Any]]:
    """Extend a TOC from a subsequent document chunk."""
    logger.info("Generating TOC continuation chunk.")
    prompt = """
    You are an expert in extracting hierarchical tree structure.
    You are given a tree structure of the previous part and the text of the current part.
    Your task is to continue the tree structure from the previous part to include the current part.

    The structure variable is the numeric system which represents the index of the hierarchy section in the table of contents. For example, the first section has structure index 1, the first subsection has structure index 1.1, the second subsection has structure index 1.2, etc.

    For the title, you need to extract the original title from the text, only fix the space inconsistency.

    The provided text contains tags like <physical_index_X> and <physical_index_X> to indicate the start and end of page X. \

    For the physical_index, you need to extract the physical index of the start of the section from the text. Keep the <physical_index_X> format.

    The response should be in the following format.
        [
            {
                "structure": <structure index, "x.x.x"> (string),
                "title": <title of the section, keep the original title>,
                "physical_index": "<physical_index_X> (keep the format)"
            },
            ...
        ]

    Directly return the additional part of the final JSON structure. Do not output anything else."""

    prompt = (
        prompt
        + "\nGiven text\n:"
        + part
        + "\nPrevious tree structure\n:"
        + json.dumps(toc_content, indent=2)
    )
    response, finish_reason = await ChatGPT_API_with_finish_reason_async(
        model=model, prompt=prompt
    )
    if finish_reason == "finished":
        return _ensure_list(extract_json(response), "generate_toc_continue")
    else:
        raise Exception(f"finish reason: {finish_reason}")


### add verify completeness
async def generate_toc_init(
    part: str, model: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Generate an initial TOC from a document chunk."""
    logger.info("Generating initial TOC chunk.")
    prompt = """
    You are an expert in extracting hierarchical tree structure, your task is to generate the tree structure of the document.

    The structure variable is the numeric system which represents the index of the hierarchy section in the table of contents. For example, the first section has structure index 1, the first subsection has structure index 1.1, the second subsection has structure index 1.2, etc.

    For the title, you need to extract the original title from the text, only fix the space inconsistency.

    The provided text contains tags like <physical_index_X> and <physical_index_X> to indicate the start and end of page X.

    For the physical_index, you need to extract the physical index of the start of the section from the text. Keep the <physical_index_X> format.

    The response should be in the following format.
        [
            {{
                "structure": <structure index, "x.x.x"> (string),
                "title": <title of the section, keep the original title>,
                "physical_index": "<physical_index_X> (keep the format)"
            }},

        ],


    Directly return the final JSON structure. Do not output anything else."""

    prompt = prompt + "\nGiven text\n:" + part
    response, finish_reason = await ChatGPT_API_with_finish_reason_async(
        model=model, prompt=prompt
    )

    if finish_reason == "finished":
        return _ensure_list(extract_json(response), "generate_toc_init")
    else:
        raise Exception(f"finish reason: {finish_reason}")


async def process_no_toc(
    page_list: List[tuple[str, int]],
    start_index: int = 1,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> List[Dict[str, Any]]:
    """Generate TOC when no explicit TOC is present."""
    page_contents = []
    token_lengths = []
    for page_index in range(start_index, start_index + len(page_list)):
        page_text = f"<physical_index_{page_index}>\n{page_list[page_index - start_index][0]}\n<physical_index_{page_index}>\n\n"
        page_contents.append(page_text)
        token_lengths.append(count_tokens(page_text, model))
    group_texts = page_list_to_group_text(page_contents, token_lengths)
    if logger:
        logger.info(f"len(group_texts): {len(group_texts)}")

    toc_with_page_number = await generate_toc_init(group_texts[0], model)
    for group_text in group_texts[1:]:
        toc_with_page_number_additional = await generate_toc_continue(
            toc_with_page_number, group_text, model
        )
        toc_with_page_number.extend(toc_with_page_number_additional)
    if logger:
        logger.info(f"process_no_toc generated {len(toc_with_page_number)} toc entries")

    toc_with_page_number = convert_physical_index_to_int(toc_with_page_number)
    if logger:
        logger.info(
            f"process_no_toc converted physical_index for {len(toc_with_page_number)} items"
        )

    return toc_with_page_number


async def process_toc_no_page_numbers(
    toc_content: str,
    toc_page_list: List[int],
    page_list: List[tuple[str, int]],
    start_index: int = 1,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> List[Dict[str, Any]]:
    """Generate TOC when TOC lacks page numbers."""
    page_contents = []
    token_lengths = []
    toc_content = await toc_transformer(toc_content, model)
    if logger:
        logger.info(
            f"process_toc_no_page_numbers transformed {len(toc_content)} toc entries"
        )
    for page_index in range(start_index, start_index + len(page_list)):
        page_text = f"<physical_index_{page_index}>\n{page_list[page_index - start_index][0]}\n<physical_index_{page_index}>\n\n"
        page_contents.append(page_text)
        token_lengths.append(count_tokens(page_text, model))

    group_texts = page_list_to_group_text(page_contents, token_lengths)
    if logger:
        logger.info(f"len(group_texts): {len(group_texts)}")

    base_structure = copy.deepcopy(toc_content)
    group_results = await asyncio.gather(
        *[
            add_page_number_to_toc(group_text, copy.deepcopy(base_structure), model)
            for group_text in group_texts
        ],
        return_exceptions=True,
    )
    results = [result for result in group_results if isinstance(result, list)]
    toc_with_page_number = _merge_page_number_results(base_structure, results)
    if logger:
        logger.info(
            "process_toc_no_page_numbers merged "
            f"{len(results)} grouped results for {len(toc_with_page_number)} entries"
        )

    toc_with_page_number = convert_physical_index_to_int(toc_with_page_number)
    if logger:
        logger.info(
            "process_toc_no_page_numbers converted physical_index for "
            f"{len(toc_with_page_number)} entries"
        )

    return toc_with_page_number


async def process_toc_with_page_numbers(
    toc_content: str,
    toc_page_list: List[int],
    page_list: List[tuple[str, int]],
    toc_check_page_num: Optional[int] = None,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> List[Dict[str, Any]]:
    """Generate TOC when TOC includes page numbers."""
    if toc_check_page_num is None:
        toc_check_page_num = len(page_list)
    toc_with_page_number = await toc_transformer(toc_content, model)
    if logger:
        logger.info(
            f"process_toc_with_page_numbers transformed {len(toc_with_page_number)} entries"
        )

    toc_no_page_number = remove_page_number(copy.deepcopy(toc_with_page_number))

    start_page_index = toc_page_list[-1] + 1
    main_content = ""
    for page_index in range(
        start_page_index, min(start_page_index + toc_check_page_num, len(page_list))
    ):
        main_content += f"<physical_index_{page_index + 1}>\n{page_list[page_index][0]}\n<physical_index_{page_index + 1}>\n\n"

    toc_with_physical_index = await toc_index_extractor(
        toc_no_page_number, main_content, model
    )
    if logger:
        logger.info(
            "process_toc_with_page_numbers extracted physical_index for "
            f"{len(toc_with_physical_index)} entries"
        )

    toc_with_physical_index = convert_physical_index_to_int(toc_with_physical_index)
    if logger:
        logger.info(
            "process_toc_with_page_numbers converted physical_index for "
            f"{len(toc_with_physical_index)} entries"
        )

    matching_pairs = extract_matching_page_pairs(
        toc_with_page_number, toc_with_physical_index, start_page_index
    )
    if logger:
        logger.info(
            f"process_toc_with_page_numbers matching_pairs={len(matching_pairs)}"
        )

    offset = calculate_page_offset(matching_pairs)
    if logger:
        logger.info(f"process_toc_with_page_numbers offset={offset}")
    if offset is None:
        offset = 0

    toc_with_page_number = add_page_offset_to_toc_json(toc_with_page_number, offset)
    if logger:
        logger.info(
            "process_toc_with_page_numbers applied page offset for "
            f"{len(toc_with_page_number)} entries"
        )

    toc_with_page_number = await process_none_page_numbers(
        toc_with_page_number, page_list, model=model
    )
    if logger:
        logger.info(
            f"process_toc_with_page_numbers finalized {len(toc_with_page_number)} entries"
        )

    return toc_with_page_number


##check if needed to process none page numbers
async def process_none_page_numbers(
    toc_items: List[Dict[str, Any]],
    page_list: List[tuple[str, int]],
    start_index: int = 1,
    model: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Fix TOC entries missing physical indices."""
    tasks: List[tuple[int, asyncio.Task[List[Dict[str, Any]]]]] = []
    for i, item in enumerate(toc_items):
        if "physical_index" not in item:
            # logger.info(f"fix item: {item}")
            # Find previous physical_index
            prev_physical_index = 0  # Default if no previous item exists
            for j in range(i - 1, -1, -1):
                if toc_items[j].get("physical_index") is not None:
                    prev_physical_index = toc_items[j]["physical_index"]
                    break

            # Find next physical_index
            next_physical_index = -1  # Default if no next item exists
            for j in range(i + 1, len(toc_items)):
                if toc_items[j].get("physical_index") is not None:
                    next_physical_index = toc_items[j]["physical_index"]
                    break

            page_contents = []
            for page_index in range(prev_physical_index, next_physical_index + 1):
                # Add bounds checking to prevent IndexError
                list_index = page_index - start_index
                if list_index >= 0 and list_index < len(page_list):
                    page_text = f"<physical_index_{page_index}>\n{page_list[list_index][0]}\n<physical_index_{page_index}>\n\n"
                    page_contents.append(page_text)
                else:
                    continue

            item_copy = copy.deepcopy(item)
            del item_copy["page"]
            task = asyncio.create_task(
                add_page_number_to_toc("".join(page_contents), [item_copy], model)
            )
            tasks.append((i, task))

    if tasks:
        results = await asyncio.gather(
            *[task for _, task in tasks], return_exceptions=True
        )
        for (idx, _task), result in zip(tasks, results):
            if isinstance(result, Exception) or not result:
                continue
            physical_index = result[0].get("physical_index")
            if isinstance(physical_index, str) and physical_index.startswith(
                "<physical_index"
            ):
                toc_items[idx]["physical_index"] = int(
                    physical_index.split("_")[-1].rstrip(">").strip()
                )
                toc_items[idx].pop("page", None)

    return toc_items


async def check_toc(
    page_list: List[tuple[str, int]], opt: Any = None
) -> Dict[str, Any]:
    """Detect and parse TOC pages from a document."""
    toc_page_list = await find_toc_pages(
        start_page_index=0, page_list=page_list, opt=opt
    )
    if len(toc_page_list) == 0:
        logger.info("No TOC found.")
        return {
            "toc_content": None,
            "toc_page_list": [],
            "page_index_given_in_toc": "no",
        }
    else:
        logger.info("TOC pages found: %s", toc_page_list)
        toc_json = await toc_extractor(page_list, toc_page_list, opt.model)

        if toc_json["page_index_given_in_toc"] == "yes":
            logger.info("TOC contains page indices.")
            return {
                "toc_content": toc_json["toc_content"],
                "toc_page_list": toc_page_list,
                "page_index_given_in_toc": "yes",
            }
        else:
            current_start_index = toc_page_list[-1] + 1

            while (
                toc_json["page_index_given_in_toc"] == "no"
                and current_start_index < len(page_list)
                and current_start_index < opt.toc_check_page_num
            ):
                additional_toc_pages = await find_toc_pages(
                    start_page_index=current_start_index, page_list=page_list, opt=opt
                )

                if len(additional_toc_pages) == 0:
                    break

                additional_toc_json = await toc_extractor(
                    page_list, additional_toc_pages, opt.model
                )
                if additional_toc_json["page_index_given_in_toc"] == "yes":
                    logger.info("TOC contains page indices (additional scan).")
                    return {
                        "toc_content": additional_toc_json["toc_content"],
                        "toc_page_list": additional_toc_pages,
                        "page_index_given_in_toc": "yes",
                    }

                else:
                    current_start_index = additional_toc_pages[-1] + 1
            logger.info("TOC page indices not found.")
            return {
                "toc_content": toc_json["toc_content"],
                "toc_page_list": toc_page_list,
                "page_index_given_in_toc": "no",
            }


################### fix incorrect toc #########################################################
async def single_toc_item_index_fixer(
    section_title: str, content: str, model: Optional[str] = "gpt-4o-2024-11-20"
) -> Dict[str, Any]:
    """Find the physical index for a single TOC item."""
    tob_extractor_prompt = """
    You will be given a section title and several pages from the document.
    Your job is to find the start page for this section title in the document.

    The provided pages contains tags like <physical_index_X> and <physical_index_X> to indicate the physical location of the page X.

    Reply format:
    {
        "thinking": <why do you think this physical_index is the start page for the section title in the document>
        "physical_index": "<physical_index_X>"
    }
    Directly return the final JSON structure. Do not output anything else.
    """

    prompt = (
        tob_extractor_prompt
        + "\nSection Title:\n"
        + str(section_title)
        + "\nDocument pages:\n"
        + content
    )
    response = await ChatGPT_API_async(model=model, prompt=prompt)
    json_content = extract_json(response)
    return convert_physical_index_to_int(json_content["physical_index"])


async def fix_incorrect_toc(
    toc_with_page_number: List[Dict[str, Any]],
    page_list: List[tuple[str, int]],
    incorrect_results: List[Dict[str, Any]],
    start_index: int = 1,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Attempt to fix incorrect TOC indices."""
    std_logger = logging.getLogger(__name__)
    std_logger.info("Fixing incorrect TOC indices (%s items).", len(incorrect_results))
    if logger:
        logger.info(f"Fixing incorrect TOC indices ({len(incorrect_results)} items).")
    incorrect_indices = {result["list_index"] for result in incorrect_results}

    end_index = len(page_list) + start_index - 1

    incorrect_results_and_range_logs = []

    # Helper function to process and check a single incorrect item
    async def process_and_check_item(incorrect_item):
        item_index = incorrect_item["list_index"]

        # Check if list_index is valid
        if item_index < 0 or item_index >= len(toc_with_page_number):
            # Return an invalid result for out-of-bounds indices
            return {
                "list_index": item_index,
                "title": incorrect_item["title"],
                "physical_index": incorrect_item.get("physical_index"),
                "is_valid": False,
            }

        # Find the previous correct item
        prev_correct = None
        for i in range(item_index - 1, -1, -1):
            if i not in incorrect_indices and i >= 0 and i < len(toc_with_page_number):
                physical_index = toc_with_page_number[i].get("physical_index")
                if physical_index is not None:
                    prev_correct = physical_index
                    break
        # If no previous correct item found, use start_index
        if prev_correct is None:
            prev_correct = start_index - 1

        # Find the next correct item
        next_correct = None
        for i in range(item_index + 1, len(toc_with_page_number)):
            if i not in incorrect_indices and i >= 0 and i < len(toc_with_page_number):
                physical_index = toc_with_page_number[i].get("physical_index")
                if physical_index is not None:
                    next_correct = physical_index
                    break
        # If no next correct item found, use end_index
        if next_correct is None:
            next_correct = end_index

        incorrect_results_and_range_logs.append(
            {
                "list_index": item_index,
                "title": incorrect_item["title"],
                "prev_correct": prev_correct,
                "next_correct": next_correct,
            }
        )

        page_contents = []
        for page_index in range(prev_correct, next_correct + 1):
            # Add bounds checking to prevent IndexError
            page_list_index = page_index - start_index
            if 0 <= page_list_index < len(page_list):
                page_text = f"<physical_index_{page_index}>\n{page_list[page_list_index][0]}\n<physical_index_{page_index}>\n\n"
                page_contents.append(page_text)
            else:
                continue
        content_range = "".join(page_contents)

        physical_index_int = await single_toc_item_index_fixer(
            incorrect_item["title"], content_range, model
        )

        # Check if the result is correct
        check_item = incorrect_item.copy()
        check_item["physical_index"] = physical_index_int
        check_result = await check_title_appearance(
            check_item, page_list, start_index, model
        )

        return {
            "list_index": item_index,
            "title": incorrect_item["title"],
            "physical_index": physical_index_int,
            "is_valid": check_result["answer"] == "yes",
        }

    # Process incorrect items concurrently
    tasks = [process_and_check_item(item) for item in incorrect_results]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    cleaned_results: List[Dict[str, Any]] = []
    for item, result in zip(incorrect_results, results):
        if isinstance(result, Exception):
            std_logger.warning(
                "Processing TOC item %s raised exception: %s", item, result
            )
            if logger:
                logger.warning(f"Processing TOC item {item} raised exception: {result}")
            continue
        cleaned_results.append(result)

    # Update the toc_with_page_number with the fixed indices and check for any invalid results
    invalid_results = []
    for result in cleaned_results:
        if result["is_valid"]:
            # Add bounds checking to prevent IndexError
            list_idx = result["list_index"]
            if 0 <= list_idx < len(toc_with_page_number):
                toc_with_page_number[list_idx]["physical_index"] = result[
                    "physical_index"
                ]
            else:
                # Index is out of bounds, treat as invalid
                invalid_results.append(
                    {
                        "list_index": result["list_index"],
                        "title": result["title"],
                        "physical_index": result["physical_index"],
                    }
                )
        else:
            invalid_results.append(
                {
                    "list_index": result["list_index"],
                    "title": result["title"],
                    "physical_index": result["physical_index"],
                }
            )

    if logger:
        logger.info(
            f"incorrect_results_and_range_logs: {incorrect_results_and_range_logs}"
        )
        logger.info(f"invalid_results: {invalid_results}")

    return toc_with_page_number, invalid_results


async def fix_incorrect_toc_with_retries(
    toc_with_page_number: List[Dict[str, Any]],
    page_list: List[tuple[str, int]],
    incorrect_results: List[Dict[str, Any]],
    start_index: int = 1,
    max_attempts: int = 3,
    model: Optional[str] = None,
    logger: Optional[JsonLogger] = None,
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Retry fixing incorrect TOC indices."""
    std_logger = logging.getLogger(__name__)
    std_logger.info("Starting TOC correction retries.")
    if logger:
        logger.info("Starting TOC correction retries.")
    fix_attempt = 0
    current_toc = toc_with_page_number
    current_incorrect = incorrect_results

    prev_incorrect = len(current_incorrect)
    while current_incorrect:
        std_logger.info("Fixing %s incorrect TOC entries.", len(current_incorrect))
        if logger:
            logger.info(f"Fixing {len(current_incorrect)} incorrect TOC entries.")

        current_toc, current_incorrect = await fix_incorrect_toc(
            current_toc, page_list, current_incorrect, start_index, model, logger
        )

        fix_attempt += 1
        if len(current_incorrect) >= prev_incorrect:
            if logger:
                logger.info("No improvement in fix pass; stopping retries.")
            break
        prev_incorrect = len(current_incorrect)
        if fix_attempt >= max_attempts:
            if logger:
                logger.info("Maximum fix attempts reached")
            break

    return current_toc, current_incorrect


################### verify toc #########################################################
async def verify_toc(
    page_list: List[tuple[str, int]],
    list_result: List[Dict[str, Any]],
    start_index: int = 1,
    N: Optional[int] = None,
    model: Optional[str] = None,
) -> tuple[float, List[Dict[str, Any]]]:
    """Verify TOC accuracy by sampling entries."""
    std_logger = logging.getLogger(__name__)
    std_logger.info("Verifying TOC accuracy.")
    # Find the last non-None physical_index
    last_physical_index = None
    for item in reversed(list_result):
        if item.get("physical_index") is not None:
            last_physical_index = item["physical_index"]
            break

    # Early return if we don't have valid physical indices
    if last_physical_index is None or last_physical_index < len(page_list) / 2:
        return 0, []

    # Determine which items to check
    if N is None:
        sample_indices = range(0, len(list_result))
    else:
        N = min(N, len(list_result))
        sample_indices = random.sample(range(0, len(list_result)), N)

    # Prepare items with their list indices
    indexed_sample_list = []
    for idx in sample_indices:
        item = list_result[idx]
        # Skip items with None physical_index (these were invalidated by validate_and_truncate_physical_indices)
        if item.get("physical_index") is not None:
            item_with_index = item.copy()
            item_with_index["list_index"] = idx  # Add the original index in list_result
            indexed_sample_list.append(item_with_index)

    # Run checks concurrently
    tasks = [
        check_title_appearance(item, page_list, start_index, model)
        for item in indexed_sample_list
    ]
    results = []
    for future in _progress(
        asyncio.as_completed(tasks), total=len(tasks), desc="TOC verify"
    ):
        results.append(await future)

    # Process results
    correct_count = 0
    incorrect_results = []
    for result in results:
        if result["answer"] == "yes":
            correct_count += 1
        else:
            incorrect_results.append(result)

    # Calculate accuracy
    checked_count = len(results)
    accuracy = correct_count / checked_count if checked_count > 0 else 0
    std_logger.info("TOC verification accuracy: %.2f%%", accuracy * 100)
    return accuracy, incorrect_results


################### main process #########################################################
async def meta_processor(
    page_list: List[tuple[str, int]],
    mode: Optional[str] = None,
    toc_content: Optional[str] = None,
    toc_page_list: Optional[List[int]] = None,
    start_index: int = 1,
    opt: Any = None,
    logger: Optional[JsonLogger] = None,
) -> List[Dict[str, Any]]:
    """Route TOC processing based on detected mode."""
    std_logger = logging.getLogger(__name__)
    std_logger.info("TOC mode=%s start_index=%s", mode, start_index)
    if logger:
        logger.info(f"TOC mode={mode} start_index={start_index}")

    if mode == "process_toc_with_page_numbers":
        assert toc_content is not None
        assert toc_page_list is not None
        toc_with_page_number = await process_toc_with_page_numbers(
            toc_content,
            toc_page_list,
            page_list,
            toc_check_page_num=opt.toc_check_page_num,
            model=opt.model,
            logger=logger,
        )
    elif mode == "process_toc_no_page_numbers":
        assert toc_content is not None
        assert toc_page_list is not None
        toc_with_page_number = await process_toc_no_page_numbers(
            toc_content, toc_page_list, page_list, model=opt.model, logger=logger
        )
    else:
        toc_with_page_number = await process_no_toc(
            page_list, start_index=start_index, model=opt.model, logger=logger
        )

    toc_with_page_number = [
        item for item in toc_with_page_number if item.get("physical_index") is not None
    ]

    toc_with_page_number = validate_and_truncate_physical_indices(
        toc_with_page_number, len(page_list), start_index=start_index, logger=logger
    )

    accuracy, incorrect_results = await verify_toc(
        page_list, toc_with_page_number, start_index=start_index, model=opt.model
    )

    if logger:
        logger.info(
            {
                "mode": "process_toc_with_page_numbers",
                "accuracy": accuracy,
                "incorrect_results": incorrect_results,
            }
        )
    if accuracy == 1.0 and len(incorrect_results) == 0:
        return toc_with_page_number
    if accuracy > 0.6 and len(incorrect_results) > 0:
        toc_with_page_number, incorrect_results = await fix_incorrect_toc_with_retries(
            toc_with_page_number,
            page_list,
            incorrect_results,
            start_index=start_index,
            max_attempts=getattr(opt, "max_fix_attempts", 3),
            model=opt.model,
            logger=logger,
        )
        return toc_with_page_number
    else:
        if mode == "process_toc_with_page_numbers":
            return await meta_processor(
                page_list,
                mode="process_toc_no_page_numbers",
                toc_content=toc_content,
                toc_page_list=toc_page_list,
                start_index=start_index,
                opt=opt,
                logger=logger,
            )
        elif mode == "process_toc_no_page_numbers":
            return await meta_processor(
                page_list,
                mode="process_no_toc",
                start_index=start_index,
                opt=opt,
                logger=logger,
            )
        else:
            raise Exception("Processing failed")


async def process_large_node_recursively(
    node, page_list, token_prefix: List[int], opt: Any = None, logger=None
):
    """Recursively split large nodes into smaller subtrees."""
    opt = _ensure_opt(opt)
    node_page_list = page_list[node["start_index"] - 1 : node["end_index"]]
    token_num = _range_token_sum(token_prefix, node["start_index"], node["end_index"])

    if (
        node["end_index"] - node["start_index"] > opt.max_page_num_each_node
        and token_num >= opt.max_token_num_each_node
    ):
        std_logger = logging.getLogger(__name__)
        std_logger.info(
            "Large node split: title=%s start=%s end=%s tokens=%s",
            node["title"],
            node["start_index"],
            node["end_index"],
            token_num,
        )
        if logger:
            logger.info(
                "Large node split: "
                f"title={node['title']} start={node['start_index']} "
                f"end={node['end_index']} tokens={token_num}"
            )

        node_toc_tree = await meta_processor(
            node_page_list,
            mode="process_no_toc",
            start_index=node["start_index"],
            opt=opt,
            logger=logger,
        )
        node_toc_tree = await check_title_appearance_in_start_concurrent(
            node_toc_tree, page_list, model=opt.model, logger=logger
        )

        # Filter out items with None physical_index before post_processing
        valid_node_toc_items = [
            item for item in node_toc_tree if item.get("physical_index") is not None
        ]

        if (
            valid_node_toc_items
            and node["title"].strip() == valid_node_toc_items[0]["title"].strip()
        ):
            node["nodes"] = post_processing(valid_node_toc_items[1:], node["end_index"])
            node["end_index"] = (
                valid_node_toc_items[1]["start_index"]
                if len(valid_node_toc_items) > 1
                else node["end_index"]
            )
        else:
            node["nodes"] = post_processing(valid_node_toc_items, node["end_index"])
            node["end_index"] = (
                valid_node_toc_items[0]["start_index"]
                if valid_node_toc_items
                else node["end_index"]
            )

    if "nodes" in node and node["nodes"]:
        tasks = [
            process_large_node_recursively(
                child_node, page_list, token_prefix, opt, logger=logger
            )
            for child_node in node["nodes"]
        ]
        await asyncio.gather(*tasks)

    return node


async def tree_parser(
    page_list, opt: Any, doc=None, logger=None, token_prefix: Optional[List[int]] = None
):
    """Parse a PDF into a hierarchical tree structure."""
    opt = _ensure_opt(opt)
    if token_prefix is None:
        token_prefix = _build_token_prefix(page_list)
    check_toc_result = await check_toc(page_list, opt)
    if logger:
        logger.info(
            {
                "toc_page_count": len(check_toc_result.get("toc_page_list", [])),
                "page_index_given_in_toc": check_toc_result.get(
                    "page_index_given_in_toc"
                ),
                "toc_content_length": len(check_toc_result.get("toc_content") or ""),
            }
        )

    if (
        check_toc_result.get("toc_content")
        and check_toc_result["toc_content"].strip()
        and check_toc_result["page_index_given_in_toc"] == "yes"
    ):
        toc_with_page_number = await meta_processor(
            page_list,
            mode="process_toc_with_page_numbers",
            start_index=1,
            toc_content=check_toc_result["toc_content"],
            toc_page_list=check_toc_result["toc_page_list"],
            opt=opt,
            logger=logger,
        )
    else:
        toc_with_page_number = await meta_processor(
            page_list, mode="process_no_toc", start_index=1, opt=opt, logger=logger
        )

    toc_with_page_number = add_preface_if_needed(toc_with_page_number)
    toc_with_page_number = await check_title_appearance_in_start_concurrent(
        toc_with_page_number, page_list, model=opt.model, logger=logger
    )

    # Filter out items with None physical_index before post_processings
    valid_toc_items = [
        item for item in toc_with_page_number if item.get("physical_index") is not None
    ]

    toc_tree = post_processing(valid_toc_items, len(page_list))
    tasks = [
        process_large_node_recursively(
            node, page_list, token_prefix, opt, logger=logger
        )
        for node in toc_tree
    ]
    await asyncio.gather(*tasks)

    return toc_tree


def page_index_main(doc, opt: Any = None):
    """Run PageIndex on a PDF path or BytesIO."""
    logger = JsonLogger(doc)
    opt = _ensure_opt(opt)

    is_valid_pdf = (
        isinstance(doc, str) and os.path.isfile(doc) and doc.lower().endswith(".pdf")
    ) or isinstance(doc, BytesIO)
    if not is_valid_pdf:
        raise ValueError(
            "Unsupported input type. Expected a PDF file path or BytesIO object."
        )

    logging.getLogger(__name__).info("Parsing PDF for PageIndex.")
    page_list = get_page_tokens(doc)

    logger.info({"total_page_number": len(page_list)})
    logger.info({"total_token": sum([page[1] for page in page_list])})

    async def page_index_builder():
        token_prefix = _build_token_prefix(page_list)
        structure = await tree_parser(
            page_list, opt, doc=doc, logger=logger, token_prefix=token_prefix
        )
        if opt.if_add_node_id == "yes":
            write_node_id(structure)
        if opt.if_add_node_text == "yes":
            add_node_text(structure, page_list)
        if opt.if_add_node_summary == "yes":
            if opt.if_add_node_text == "no":
                add_node_text(structure, page_list)
            await generate_summaries_for_structure(structure, model=opt.model)
            if opt.if_add_node_text == "no":
                remove_structure_text(structure)
            if opt.if_add_doc_description == "yes":
                # Create a clean structure without unnecessary fields for description generation
                clean_structure = create_clean_structure_for_description(structure)
                doc_description = await generate_doc_description(
                    clean_structure, model=opt.model
                )
                return {
                    "doc_name": get_pdf_name(doc),
                    "doc_description": doc_description,
                    "structure": structure,
                }
        return {"doc_name": get_pdf_name(doc), "structure": structure}

    cache_dir = Path(os.getenv("DOD_LLM_CACHE_DIR", "outputs/llm_cache"))
    cache = LLMCache(cache_dir)
    with request_llm_cache(cache), request_llm_concurrency(opt.concurrent_requests):
        return asyncio.run(page_index_builder())


def page_index(
    doc,
    model=None,
    concurrent_requests=None,
    toc_check_page_num=None,
    max_page_num_each_node=None,
    max_token_num_each_node=None,
    max_fix_attempts=None,
    if_add_node_id=None,
    if_add_node_summary=None,
    if_add_doc_description=None,
    if_add_node_text=None,
    api_key=None,
    api_base_url=None,
):
    """Entry point for PageIndex with explicit configuration overrides."""
    user_opt = {
        arg: value
        for arg, value in locals().items()
        if arg != "doc" and value is not None
    }
    opt = ConfigLoader().load(user_opt)
    with request_openai_config(api_key=api_key, base_url=api_base_url):
        return page_index_main(doc, opt)


def page_index_from_page_list(
    page_list,
    doc_name="document",
    model=None,
    concurrent_requests=None,
    toc_check_page_num=None,
    max_page_num_each_node=None,
    max_token_num_each_node=None,
    max_fix_attempts=None,
    if_add_node_id=None,
    if_add_node_summary=None,
    if_add_doc_description=None,
    if_add_node_text=None,
    api_key=None,
    api_base_url=None,
):
    """Run PageIndex using a precomputed page_list (text, token_count)."""
    user_opt = {
        arg: value
        for arg, value in locals().items()
        if arg not in {"page_list", "doc_name"} and value is not None
    }
    opt = ConfigLoader().load(user_opt)
    logger = JsonLogger(doc_name)

    async def page_index_builder():
        token_prefix = _build_token_prefix(page_list)
        structure = await tree_parser(
            page_list, opt, doc=None, logger=logger, token_prefix=token_prefix
        )
        if opt.if_add_node_id == "yes":
            write_node_id(structure)
        if opt.if_add_node_text == "yes":
            add_node_text(structure, page_list)
        if opt.if_add_node_summary == "yes":
            if opt.if_add_node_text == "no":
                add_node_text(structure, page_list)
            await generate_summaries_for_structure(structure, model=opt.model)
            if opt.if_add_node_text == "no":
                remove_structure_text(structure)
            if opt.if_add_doc_description == "yes":
                clean_structure = create_clean_structure_for_description(structure)
                doc_description = await generate_doc_description(
                    clean_structure, model=opt.model
                )
                return {
                    "doc_name": doc_name,
                    "doc_description": doc_description,
                    "structure": structure,
                }
        return {"doc_name": doc_name, "structure": structure}

    cache_dir = Path(os.getenv("DOD_LLM_CACHE_DIR", "outputs/llm_cache"))
    cache = LLMCache(cache_dir)
    with request_openai_config(api_key=api_key, base_url=api_base_url):
        with request_llm_cache(cache), request_llm_concurrency(opt.concurrent_requests):
            return asyncio.run(page_index_builder())


def validate_and_truncate_physical_indices(
    toc_with_page_number, page_list_length, start_index=1, logger=None
):
    """Validates and truncates physical indices that exceed the actual document length.

    This prevents errors when TOC references pages that don't exist in the document (e.g. the file is broken or incomplete).
    """
    if not toc_with_page_number:
        return toc_with_page_number

    max_allowed_page = page_list_length + start_index - 1
    truncated_items = []

    for i, item in enumerate(toc_with_page_number):
        if item.get("physical_index") is not None:
            original_index = item["physical_index"]
            if original_index > max_allowed_page:
                item["physical_index"] = None
                truncated_items.append(
                    {
                        "title": item.get("title", "Unknown"),
                        "original_index": original_index,
                    }
                )
                if logger:
                    logger.info(
                        f"Removed physical_index for '{item.get('title', 'Unknown')}' (was {original_index}, too far beyond document)"
                    )

    if truncated_items and logger:
        logger.info(f"Total removed items: {len(truncated_items)}")

    std_logger = logging.getLogger(__name__)
    std_logger.info(
        "Document validation: %s pages, max allowed index: %s",
        page_list_length,
        max_allowed_page,
    )
    if truncated_items:
        std_logger.info(
            "Truncated %s TOC items that exceeded document length", len(truncated_items)
        )

    return toc_with_page_number
