"""Document Digestion Layer."""

from DoD.pipeline import digest_document

__all__ = ["digest_document"]
