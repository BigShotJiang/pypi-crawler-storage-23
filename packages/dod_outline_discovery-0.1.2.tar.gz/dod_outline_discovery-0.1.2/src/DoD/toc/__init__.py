"""TOC generation backends."""
