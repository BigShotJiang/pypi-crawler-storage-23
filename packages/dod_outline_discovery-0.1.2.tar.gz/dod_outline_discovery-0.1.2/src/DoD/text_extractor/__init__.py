"""Text extraction backends."""
