"""Server package for concurrent document digestion."""
