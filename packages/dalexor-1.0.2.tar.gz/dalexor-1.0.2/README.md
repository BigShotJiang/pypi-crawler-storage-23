# Dalexor MI — MCP Server & AI Code Intelligence 🧠

> **The #1 MCP (Model Context Protocol) server for persistent AI code intelligence.**  
> Give Claude, ChatGPT, Gemini, Grok, Cursor, and Windsurf a deep, evolving memory of your entire codebase.

[![PyPI version](https://img.shields.io/pypi/v/dalexor.svg)](https://pypi.org/project/dalexor/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://python.org)
[![License: Proprietary](https://img.shields.io/badge/license-Proprietary-red.svg)](https://dalexor.com/terms.html)
[![Website](https://img.shields.io/badge/website-dalexor.com-purple.svg)](https://dalexor.com)

---

## What is Dalexor MI?

**Dalexor MI** solves the #1 problem in AI-assisted development: **AI coding assistants have no memory of your codebase between sessions.**

When you ask Claude or ChatGPT to fix a bug, it only sees the files you paste in. It has no idea:
- Why code was written a certain way
- What changed in the last week
- Which files depend on the one you're modifying  
- Whether a team member is editing the same code right now

**Dalexor MI fixes all of this.** It is a background service that watches your project, understands every meaningful change, and makes that intelligence instantly available to any AI assistant via the **Model Context Protocol (MCP)**.

---

## Install in 60 Seconds

```bash
# Install the CLI
pip install dalexor

# Authenticate and configure
dx init

# Start watching your project (run from project root)
dx watch
```



```

Restart your AI client. Done. Your AI now has persistent memory of your codebase.

---

## 9 MCP Tools Available Instantly

Once installed, your AI coding assistant gets 9 powerful tools:

| Tool | What It Does |
|------|-------------|
| `mcp_dalexor_get_logical_evolution` | Replay what changed in your project over the last hour — with AI-generated intent labels |
| `mcp_dalexor_trace_dependency` | Find every file that uses a specific function/class — the blast radius of any change |
| `mcp_dalexor_find_definition` | Locate where any symbol is defined across all files and repositories |
| `mcp_dalexor_get_surgical_context` | Get a file's full history plus all its linked neighbors |
| `mcp_dalexor_get_atomic_diff` | Compare exact code changes between last two versions of any file |
| `mcp_dalexor_get_dependency_topology` | Map the full structural graph of any file's relationships |
| `mcp_dalexor_predict_conflicts` | Detect concurrent edits and predict merge conflicts before they happen |
| `mcp_dalexor_find_related_decisions` | Retrieve architectural decisions and pinned notes for any topic |
| `mcp_dalexor_mcp_health_check` | Verify bridge connectivity and authentication status |

---

## Who Is It For?

**Solo developers**: Your AI finally knows your whole project, not just the file you have open.

**Engineering teams**: Shared codebase memory — when any developer syncs a change, every AI assistant on the team benefits.

**Engineering managers / CTOs**: Full visibility into what your team is building and how the architecture is evolving.

**Regulated industries** (fintech, healthcare, legal): Neural Vault tier uses AES-256-GCM client-side encryption — your source code **never reaches the cloud in plaintext**.

---

## How It Works

```
Your Files → Entropy Filter → Scrub Engine → Neural Vault (opt.) → Global Brain
                 ↓                  ↓                                     ↓
         Only meaningful      Strips API keys,              Versioned atoms with
         changes synced       secrets, passwords            AI-generated summaries
                                                                    ↓
                                                            9 MCP Tools ← AI Client
```

### Shannon Entropy Filter
Not every keystroke is meaningful. Dalexor uses `H(X) = -Σ P(xᵢ) log₂ P(xᵢ)` to score changes:
- `0–2.0`: Ignored (whitespace, boilerplate)
- `2.1–5.0`: Logic evolution → synced
- `5.1–10.0`: High-entropy shift → immediately sealed as milestone

### Ancestry Shield (Lineage Tracking)
Every file is tracked with versioned `parent_id → child_id` chains. 20-minute coalescence window merges rapid edits. AI sees the evolution, not just the current state.

### Neural Vault (E2EE)
Enterprise/Sovereign tier: AES-256-GCM with PBKDF2 key derivation (100,000 iterations). Your code is encrypted before it leaves your machine.

---

## Supported AI Clients

| Client | Status |
|--------|--------|
| Claude Desktop | ✅ Full support |
| Cursor | ✅ Full support |
| Windsurf | ✅ Full support |
| VS Code + Copilot (MCP Preview) | ✅ Full support |
| Gemini CLI | ✅ Full support |
| Any MCP-compatible client | ✅ Full support |

## Supported Languages

Python, TypeScript, JavaScript, Rust, Go, C++, PHP, HTML, CSS, SQL, Markdown, and more.

---

## All CLI Commands

| Command | Description |
|---------|-------------|
| `dx init` | Authenticate and configure API key + project |
| `dx watch` | Start real-time filesystem monitoring (keep running in background) |
| `dx sync` | One-time full sync of all existing project files |
| `dx bridge` | Start MCP bridge server (for AI client integration) |
| `dx chat` | Interactive CLI chat with your project's memory |


---

## 

Personal (FREE): 100 Snapshots, 500 Connections, 15 req/h.
Hobby (USERS): 10,000 Snapshots, 25,000 Connections, 60 req/h.
Pro (STANDARD): 100,000 Snapshots, 500,000 Connections, 500 req/h.
Expert (PRO): 200,000 Snapshots, 2,000,000 Connections, 2,000 req/h.
Startup (ENTERPRISE): Unlimited Snapshots/Connections, 10,000 req/h.

[View pricing →](https://dalexor.com/pricing.html)

---

## Keywords (for discoverability)

`MCP server` `Model Context Protocol` `AI code intelligence` `code memory` `persistent AI context` `developer tools` `coding assistant memory` `codebase analysis` `code evolution tracking` `dependency tracking` `merge conflict prevention` `code history` `AI developer tools` `Claude MCP` `Cursor MCP` `Gemini developer tools` `code documentation` `team collaboration` `software architecture tools` `best developer tools 2025`

---

## Links

- **Homepage**: https://dalexor.com
- **Documentation**: https://dalexor.com/docs.html
- **Pricing**: https://dalexor.com/pricing.html
- **LLM Guide**: https://dalexor.com/llms.txt
- **MCP Capsule**: https://dalexor.com/.well-known/mcp-capsule.json
- **Support**: https://dalexor.com/support.html

---

## License

Proprietary software. All rights reserved by Dalexor MI.  
Unauthorized copying, modification, or redistribution is strictly prohibited.  
[Terms of Service](https://dalexor.com/terms.html) | [Privacy Policy](https://dalexor.com/privacy.html)
