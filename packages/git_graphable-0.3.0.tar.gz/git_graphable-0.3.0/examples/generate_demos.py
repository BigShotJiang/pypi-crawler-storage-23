import os
import shutil
import subprocess
import time
from pathlib import Path

EXAMPLES_DIR = Path(__file__).parent
REPOS_DIR = EXAMPLES_DIR / "repos"
ASSETS_DIR = EXAMPLES_DIR / "assets"


def run_git(args, cwd):
    subprocess.run(["git"] + args, cwd=cwd, check=True, capture_output=True)


def create_base_repo(name):
    path = REPOS_DIR / name
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True)

    run_git(["init", "-b", "main"], path)
    run_git(["config", "user.email", "demo@example.com"], path)
    run_git(["config", "user.name", "Demo User"], path)
    run_git(["config", "commit.gpgsign", "false"], path)

    # Root commit
    (path / "README.md").write_text(f"# {name}")
    run_git(["add", "README.md"], path)
    run_git(["commit", "-m", "initial commit"], path)
    return path


def generate_pristine():
    print("Generating repo-pristine...")
    path = create_base_repo("repo-pristine")

    # Clean history with multiple authors
    authors = [
        ("Alice", "alice@example.com"),
        ("Bob", "bob@example.com"),
        ("Charlie", "charlie@example.com"),
    ]

    for i in range(3):
        name, email = authors[i % len(authors)]
        run_git(["config", "user.name", name], path)
        run_git(["config", "user.email", email], path)

        (path / f"file_{i}.txt").write_text(f"content {i}")
        run_git(["add", f"file_{i}.txt"], path)
        run_git(["commit", "-m", f"feat: add component {i}"], path)

    # Alice merges a feature branch
    run_git(["config", "user.name", "Alice"], path)
    run_git(["config", "user.email", "alice@example.com"], path)
    run_git(["checkout", "-b", "feature/login"], path)
    (path / "login.py").write_text("def login(): pass")
    run_git(["add", "login.py"], path)
    run_git(["commit", "-m", "feat: implement login logic"], path)

    run_git(["checkout", "main"], path)
    run_git(
        [
            "merge",
            "--no-ff",
            "feature/login",
            "-m",
            "Merge pull request #1 from feature/login",
        ],
        path,
    )


def generate_messy():
    print("Generating repo-messy...")
    path = create_base_repo("repo-messy")

    # 1. Direct pushes to main
    for i in range(2):
        (path / f"hotfix_{i}.txt").write_text("fix")
        run_git(["add", f"hotfix_{i}.txt"], path)
        run_git(["commit", "-m", f"urgent fix {i}"], path)

    # 2. WIP commits
    run_git(["checkout", "-b", "feature/draft"], path)
    for i in range(3):
        (path / f"draft_{i}.txt").write_text("draft")
        run_git(["add", f"draft_{i}.txt"], path)
        run_git(["commit", "-m", f"WIP: saving work {i}"], path)

    # 3. Stale branch (backdated commit)
    run_git(["checkout", "-b", "stale-branch"], path)
    (path / "stale.txt").write_text("old")
    run_git(["add", "stale.txt"], path)
    # Set date to 60 days ago
    old_date = int(time.time()) - (60 * 24 * 60 * 60)
    env = os.environ.copy()
    env["GIT_AUTHOR_DATE"] = f"{old_date} +0000"
    env["GIT_COMMITTER_DATE"] = f"{old_date} +0000"
    subprocess.run(
        ["git", "commit", "-m", "feat: ancient work"], cwd=path, env=env, check=True
    )


def generate_features():
    print("Generating repo-features...")
    path = create_base_repo("repo-features")

    # 1. Divergence
    run_git(["checkout", "-b", "feature/diverged"], path)
    (path / "feature.txt").write_text("feat")
    run_git(["add", "feature.txt"], path)
    run_git(["commit", "-m", "feat: divergence start"], path)

    run_git(["checkout", "main"], path)
    (path / "main_update.txt").write_text("update")
    run_git(["add", "main_update.txt"], path)
    run_git(["commit", "-m", "chore: update base with critical fix"], path)

    # 2. Orphan commit
    run_git(["checkout", "--orphan", "detached-work"], path)
    (path / "orphan.txt").write_text("orphan")
    run_git(["add", "orphan.txt"], path)
    run_git(["commit", "-m", "feat: some experimental work"], path)
    # Create a tag so it's visible in git log --all, then delete the branch
    run_git(["tag", "v0.0.1-exp"], path)
    run_git(["checkout", "main"], path)
    run_git(["branch", "-D", "detached-work"], path)


def generate_risk_silo():
    print("Generating repo-risk-silo...")
    path = create_base_repo("repo-risk-silo")

    # Create a long-running branch with only one author (Alice)
    run_git(["checkout", "-b", "feature/huge-silo"], path)
    run_git(["config", "user.name", "Alice"], path)
    run_git(["config", "user.email", "alice@example.com"], path)

    for i in range(25):
        (path / f"work_{i}.txt").write_text(f"work {i}")
        run_git(["add", f"work_{i}.txt"], path)
        run_git(["commit", "-m", f"chore: alice working hard {i}"], path)

    run_git(["checkout", "main"], path)


def generate_squash_and_backmerge():
    print("Generating repo-complex-hygiene...")
    path = create_base_repo("repo-complex-hygiene")

    # 1. A branch that was back-merged (main into feature)
    run_git(["checkout", "-b", "feature/noisy-history"], path)
    (path / "feat.txt").write_text("feat")
    run_git(["add", "feat.txt"], path)
    run_git(["commit", "-m", "feat: start working"], path)

    run_git(["checkout", "main"], path)
    (path / "main_work.txt").write_text("main")
    run_git(["add", "main_work.txt"], path)
    run_git(["commit", "-m", "chore: some main work"], path)

    run_git(["checkout", "feature/noisy-history"], path)
    run_git(
        ["merge", "main", "-m", "Merge branch 'main' into feature/noisy-history"], path
    )

    # 2. A branch intended for squashing (manual simulation)
    run_git(["checkout", "main"], path)
    run_git(["checkout", "-b", "feature/to-be-squashed"], path)
    for i in range(3):
        (path / f"part_{i}.txt").write_text(f"part {i}")
        run_git(["add", f"part_{i}.txt"], path)
        run_git(["commit", "-m", f"feat: part {i} of squashed work"], path)

    # Simulate the squash commit on main (we won't link it here, highlighter does it via PR OIDs)
    run_git(["checkout", "main"], path)
    (path / "squashed_result.txt").write_text("all parts")
    run_git(["add", "squashed_result.txt"], path)
    run_git(["commit", "-m", "feat: implementing all parts (#123)"], path)


def generate_issue_desync():
    print("Generating repo-issue-desync...")
    path = create_base_repo("repo-issue-desync")

    # 1. A branch where Git is OPEN but Issue is CLOSED (Inconsistency)
    run_git(["checkout", "-b", "feature/PROJ-456"], path)
    (path / "work.txt").write_text("work")
    run_git(["add", "work.txt"], path)
    run_git(["commit", "-m", "feat: implementing PROJ-456"], path)

    run_git(["checkout", "main"], path)


def generate_release_desync():
    print("Generating repo-release-desync...")
    path = create_base_repo("repo-release-desync")

    # Commit for a 'Released' issue that IS tagged (Correct)
    (path / "file1.txt").write_text("v1")
    run_git(["add", "file1.txt"], path)
    run_git(["commit", "-m", "feat: implementing PROJ-111"], path)
    run_git(["tag", "v1.0.0"], path)

    # Commit for a 'Released' issue that is NOT tagged (Inconsistency)
    (path / "file2.txt").write_text("v2")
    run_git(["add", "file2.txt"], path)
    run_git(["commit", "-m", "feat: implementing PROJ-222"], path)

    run_git(["checkout", "main"], path)


def generate_collaboration_gap():
    print("Generating repo-collab-gap...")
    path = create_base_repo("repo-collab-gap")

    # Alice works on a ticket assigned to Bob
    run_git(["checkout", "-b", "feature/PROJ-777"], path)
    run_git(["config", "user.name", "Alice"], path)
    run_git(["config", "user.email", "alice@example.com"], path)

    (path / "collab.txt").write_text("collab")
    run_git(["add", "collab.txt"], path)
    run_git(["commit", "-m", "feat: implementing PROJ-777"], path)

    run_git(["checkout", "main"], path)


def main():
    REPOS_DIR.mkdir(exist_ok=True)
    ASSETS_DIR.mkdir(exist_ok=True)

    generate_pristine()
    generate_messy()
    generate_features()
    generate_risk_silo()
    generate_squash_and_backmerge()
    generate_issue_desync()
    generate_release_desync()
    generate_collaboration_gap()

    print("\nDone! Demo repositories created in examples/repos/")


if __name__ == "__main__":
    main()
