"""
Provider Factory
================
Create AI providers by name.

Supported providers:
    - openai    — GPT-5 / GPT-4.1 / o-series
    - gemini    — Google Gemini 3.x / 2.5
    - claude    — Anthropic Claude 4.6 / 4.5 / 4
    - deepseek  — DeepSeek V3.2 (Chat / Reasoner)
    - qwen      — Alibaba Qwen 3 / 2.5
    - groq      — Groq (Llama, DeepSeek, Qwen) — fast!
    - together  — Together AI (Llama, Mistral)
    - mistral   — Mistral Large 3 / Medium 3.1
    - ollama    — Local models (free!)
    - openrouter — All models in one place
    - fireworks — Fireworks AI
    - perplexity — Perplexity Sonar (with internet search)
    - xai       — xAI Grok 3 / 4
    - custom    — Any OpenAI-compatible API
"""

import os
from typing import Optional
from .base import BaseProvider

# Supported provider names and their aliases
PROVIDER_ALIASES = {
    # OpenAI
    "openai": "openai", "gpt": "openai", "chatgpt": "openai", "gpt-4o": "openai",
    # Gemini
    "gemini": "gemini", "google": "gemini", "bard": "gemini",
    # Claude
    "claude": "claude", "anthropic": "claude", "sonnet": "claude", "opus": "claude",
    # DeepSeek
    "deepseek": "deepseek", "deep-seek": "deepseek",
    # Qwen
    "qwen": "qwen", "alibaba": "qwen", "dashscope": "qwen", "tongyi": "qwen",
    # Groq
    "groq": "groq",
    # Together
    "together": "together", "together-ai": "together", "togetherai": "together",
    # Mistral
    "mistral": "mistral",
    # Ollama (local)
    "ollama": "ollama", "local": "ollama",
    # LM Studio (local)
    "lmstudio": "lmstudio", "lm-studio": "lmstudio", "llmstudio": "lmstudio", "lm_studio": "lmstudio",
    # OpenRouter
    "openrouter": "openrouter", "open-router": "openrouter",
    # Fireworks
    "fireworks": "fireworks",
    # Perplexity
    "perplexity": "perplexity", "pplx": "perplexity",
    # xAI
    "xai": "xai", "grok": "xai", "x": "xai",
}

# Environment variable names for each provider's API key
ENV_KEYS = {
    "openai": ["OPENAI_API_KEY"],
    "gemini": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
    "claude": ["ANTHROPIC_API_KEY", "CLAUDE_API_KEY"],
    "deepseek": ["DEEPSEEK_API_KEY"],
    "qwen": ["DASHSCOPE_API_KEY", "QWEN_API_KEY"],
    "groq": ["GROQ_API_KEY"],
    "together": ["TOGETHER_API_KEY"],
    "mistral": ["MISTRAL_API_KEY"],
    "ollama": [],  # No key needed
    "lmstudio": [],  # No key needed
    "openrouter": ["OPENROUTER_API_KEY"],
    "fireworks": ["FIREWORKS_API_KEY"],
    "perplexity": ["PERPLEXITY_API_KEY", "PPLX_API_KEY"],
    "xai": ["XAI_API_KEY", "GROK_API_KEY"],
}


def resolve_api_key(provider: str) -> Optional[str]:
    """Try to resolve API key from environment."""
    provider = PROVIDER_ALIASES.get(provider.lower(), provider.lower())
    env_keys = ENV_KEYS.get(provider, [])
    for key in env_keys:
        val = os.environ.get(key)
        if val:
            return val
    return None


def get_provider(
    name: str,
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    base_url: Optional[str] = None,
) -> BaseProvider:
    """
    Create an AI provider by name.

    Args:
        name: Provider name (openai, gemini, claude, deepseek, qwen, groq,
              together, mistral, ollama, openrouter, fireworks, perplexity,
              xai, or custom)
        api_key: API key (if None, tries environment variables)
        model: Optional model override
        base_url: Optional custom base URL (for 'custom' provider)

    Returns:
        BaseProvider instance

    Examples:
        # Named providers — auto-resolve API key from env
        provider = get_provider("gemini")
        provider = get_provider("deepseek", model="deepseek-coder")
        provider = get_provider("ollama", model="llama3.2")

        # Custom OpenAI-compatible endpoint
        provider = get_provider("custom",
                               api_key="...",
                               base_url="https://my-api.com/v1",
                               model="my-model")
    """
    name_lower = name.lower().strip()
    canonical = PROVIDER_ALIASES.get(name_lower, name_lower)

    # Resolve API key from env if not provided
    if not api_key:
        api_key = resolve_api_key(canonical)

    # Local providers don't need a key
    if canonical in ("ollama", "lmstudio") and not api_key:
        api_key = canonical

    if not api_key and canonical not in ("ollama", "lmstudio"):
        env_keys = ENV_KEYS.get(canonical, [])
        env_hint = " or ".join(env_keys) if env_keys else "API_KEY"
        raise ValueError(
            f"API key not found for '{name}'!\n"
            f"Please do one of the following:\n"
            f"  1. Pass api_key='...' parameter\n"
            f"  2. Add to .env file: {env_hint}=your-key\n"
            f"  3. Set environment variable: export {env_hint}=your-key"
        )

    # ─── Native providers (own SDK) ───────────────

    if canonical == "openai":
        from .openai_provider import OpenAIProvider
        return OpenAIProvider(api_key=api_key, model=model)

    if canonical == "gemini":
        from .gemini_provider import GeminiProvider
        return GeminiProvider(api_key=api_key, model=model)

    if canonical == "claude":
        from .claude_provider import ClaudeProvider
        return ClaudeProvider(api_key=api_key, model=model)

    # ─── OpenAI-compatible providers ──────────────

    from .openai_compatible import OpenAICompatibleProvider, PROVIDER_PROFILES

    if canonical in PROVIDER_PROFILES:
        return OpenAICompatibleProvider.from_profile(
            profile_name=canonical,
            api_key=api_key,
            model=model,
        )

    # ─── Custom provider ─────────────────────────

    if canonical == "custom" or base_url:
        if not base_url:
            raise ValueError("Custom provider requires base_url")
        return OpenAICompatibleProvider(
            api_key=api_key or "custom",
            base_url=base_url,
            model=model,
            provider_name_str="Custom",
        )

    # ─── Unknown ─────────────────────────────────

    available = sorted(set(PROVIDER_ALIASES.values()))
    raise ValueError(
        f"Unknown AI provider: '{name}'.\n"
        f"Supported: {', '.join(available)}\n"
        f"Or use 'custom' + base_url."
    )


def list_providers() -> dict:
    """List all supported providers with their details."""
    providers = {}
    for canonical in sorted(set(PROVIDER_ALIASES.values())):
        aliases = [k for k, v in PROVIDER_ALIASES.items() if v == canonical and k != canonical]
        env_keys = ENV_KEYS.get(canonical, [])
        providers[canonical] = {
            "aliases": aliases,
            "env_keys": env_keys,
            "needs_key": canonical != "ollama",
        }
    return providers


__all__ = ["get_provider", "resolve_api_key", "list_providers", "BaseProvider"]
