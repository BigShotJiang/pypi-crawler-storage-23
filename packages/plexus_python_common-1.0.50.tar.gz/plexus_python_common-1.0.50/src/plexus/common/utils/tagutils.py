import dataclasses
import datetime
import os
import pathlib
import textwrap
import typing
from collections.abc import Generator, Mapping, Sequence
from typing import Self

import jinja2
import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.sqlite as sa_sqlite
import sqlalchemy.orm as sa_orm
from iker.common.utils.dbutils import ConnectionMaker
from iker.common.utils.funcutils import memorized, singleton
from iker.common.utils.iterutils import dicttree
from iker.common.utils.iterutils import dicttree_add, dicttree_remove
from iker.common.utils.iterutils import dicttree_children, dicttree_lineage, dicttree_subtree
from iker.common.utils.iterutils import head_or_none
from iker.common.utils.jsonutils import JsonObject, JsonType
from iker.common.utils.randutils import randomizer
from iker.common.utils.strutils import is_blank
from sqlmodel import Field, SQLModel

from plexus.common.resources.tags import predefined_tagset_specs
from plexus.common.utils.datautils import validate_bag_name, validate_dt_timezone
from plexus.common.utils.datautils import validate_colon_tag, validate_snake_case, validate_vehicle_name
from plexus.common.utils.ormutils import SequenceModelMixinProtocol
from plexus.common.utils.ormutils import clone_sequence_model_instance, make_base_model, make_sequence_model_mixin
from plexus.common.utils.sqlutils import escape_sql_like

__all__ = [
    "TagRecord",
    "BagTagRecord",
    "TagRecordTable",
    "BagTagRecordTable",
    "RichDesc",
    "Tag",
    "Tagset",
    "MutableTagset",
    "populate_tagset",
    "predefined_tagsets",
    "render_tagset_markdown_readme",
    "tag_cache_file_path",
    "TagCache",
    "tag_cache",
]

BaseModel = make_base_model()


class TagRecord(BaseModel):
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=False),
        description="Vehicle name associated with the tag record",
    )
    begin_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="Begin datetime of the tag record",
    )
    end_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="End datetime of the tag record",
    )
    tag: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(256), nullable=False),
        description="Tag name",
    )
    props: JsonType | None = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=True),
        default=None,
        description="Additional properties of the tag record in JSON format",
    )

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_dt", mode="after")
    @classmethod
    def validate_begin_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_dt", mode="after")
    @classmethod
    def validate_end_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_dt_end_dt(self) -> Self:
        if self.begin_dt > self.end_dt:
            raise ValueError(f"begin_dt '{self.begin_dt}' is greater than end_dt '{self.end_dt}'")
        return self

    @pdt.field_validator("tag", mode="after")
    @classmethod
    def validate_tag(cls, v: str) -> str:
        validate_colon_tag(v)
        return v


class BagTagRecord(BaseModel):
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=False),
        description="Vehicle name associated with the tag record",
    )
    bag_name: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(256), nullable=False),
        description="Name of the bag associated with the tag record",
    )
    begin_offset: int = Field(
        sa_column=sa.Column(sa_sqlite.INTEGER, nullable=False),
        description="Begin offset (in microseconds) of the tag record within the bag",
    )
    end_offset: int = Field(
        sa_column=sa.Column(sa_sqlite.INTEGER, nullable=False),
        description="End offset (in microseconds) of the tag record within the bag",
    )
    tag: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(256), nullable=False),
        description="Tag name",
    )
    props: JsonType | None = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=True),
        default=None,
        description="Additional properties of the tag record in JSON format",
    )

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("bag_name", mode="after")
    @classmethod
    def validate_bag_name(cls, v: str) -> str:
        validate_bag_name(v)
        return v

    @pdt.field_validator("begin_offset", mode="after")
    @classmethod
    def validate_begin_offset(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"begin_offset '{v}' is negative")
        return v

    @pdt.field_validator("end_offset", mode="after")
    @classmethod
    def validate_end_offset(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"end_offset '{v}' is negative")
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_offset_end_offset(self) -> Self:
        if self.begin_offset > self.end_offset:
            raise ValueError(f"begin offset '{self.begin_offset}' is greater than end offset '{self.end_offset}'")
        return self

    @pdt.field_validator("tag", mode="after")
    @classmethod
    def validate_tag(cls, v: str) -> str:
        validate_colon_tag(v)
        return v


class TagRecordTable(TagRecord, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "tag_record"


class BagTagRecordTable(BagTagRecord, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "bag_tag_record"


if typing.TYPE_CHECKING:
    class TagRecordTable(SQLModel, SequenceModelMixinProtocol):
        vehicle_name: sa_orm.Mapped[str] = ...
        begin_dt: sa_orm.Mapped[datetime.datetime] = ...
        end_dt: sa_orm.Mapped[datetime.datetime] = ...
        tag: sa_orm.Mapped[str] = ...
        props: sa_orm.Mapped[JsonType | None] = ...


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class RichDesc(object):
    type: str
    text: str


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class Tag(object):
    name: str
    desc: str | RichDesc | None

    @property
    def tag_parts(self) -> list[str]:
        return self.name.rsplit(":")

    @property
    def parent_tag_name(self) -> str | None:
        return head_or_none(self.name.rsplit(":", 1))

    def populate(
        self,
        vehicle_name: str,
        begin_dt: datetime.datetime,
        end_dt: datetime.datetime,
        props: JsonType,
    ) -> TagRecord:
        return TagRecord(
            vehicle_name=vehicle_name,
            begin_dt=begin_dt,
            end_dt=end_dt,
            tag=self.name,
            props=props,
        )


class Tagset(Sequence[Tag], Mapping[str, Tag]):
    def __init__(self, namespace: str, desc: str | RichDesc) -> None:
        super().__init__()
        self.namespace = namespace
        self.desc = desc
        self.tags: list[Tag] = []
        self.tags_dict: dict[str, Tag] = {}
        self.tags_tree: dicttree[str, Tag] = {}

    def __contains__(self, item: str | Tag) -> bool:
        tag_name = item.name if isinstance(item, Tag) else item
        return tag_name in self.tags_dict

    def __len__(self) -> int:
        return len(self.tags)

    def __getitem__(self, index: int) -> Tag:
        return self.tags[index]

    def keys(self):
        return self.tags_dict.keys()

    def values(self):
        return self.tags_dict.values()

    def items(self):
        return self.tags_dict.items()

    def get(self, item: str | Tag) -> Tag | None:
        tag_name = item.name if isinstance(item, Tag) else item
        return self.tags_dict.get(tag_name)

    def clone(self) -> Self:
        return clone_tagset(self)

    def mutable(self):
        return clone_mutable_tagset(self)

    def frozen(self):
        return self.clone()

    @property
    def tag_names(self) -> list[str]:
        return list(self.tags_dict.keys())

    def child_tags(self, parent: str | Tag) -> list[Tag]:
        if parent is None:
            return []
        if isinstance(parent, str):
            return self.child_tags(self.get(parent))

        subtree = dicttree_subtree(self.tags_tree, parent.tag_parts)
        return list(dicttree_children(subtree)) if subtree else []

    def parent_tags(self, child: str | Tag) -> list[Tag]:
        if child is None:
            return []
        if isinstance(child, str):
            return self.parent_tags(self.get(child))

        return list(dicttree_lineage(self.tags_tree, child.tag_parts[:-1]))


class MutableTagset(Tagset):

    def clone(self) -> Self:
        return clone_mutable_tagset(self)

    def mutable(self):
        return self.clone()

    def frozen(self):
        return clone_tagset(self)

    def add(self, tag: Tag) -> Self:
        if tag.name in self.tags_dict:
            raise ValueError(f"duplicate tag name '{tag.name}'")

        self.tags.append(tag)
        self.tags_dict[tag.name] = tag

        dicttree_add(self.tags_tree, tag.tag_parts, tag, create_prefix=True)

        return self

    def remove(self, tag_name: str) -> Self:
        tag = self.get(tag_name)
        if tag is None:
            raise ValueError(f"tag '{tag_name}' not found")

        self.tags.remove(tag)
        del self.tags_dict[tag_name]

        dicttree_remove(self.tags_tree, tag.tag_parts, recursive=True)

        return self


def clone_tagset(tagset: Tagset) -> Tagset:
    tagset = clone_mutable_tagset(tagset)
    new_tagset = Tagset(namespace=tagset.namespace, desc=tagset.desc)
    new_tagset.tags = tagset.tags
    new_tagset.tags_dict = tagset.tags_dict
    new_tagset.tags_tree = tagset.tags_tree
    return new_tagset


def clone_mutable_tagset(tagset: Tagset) -> MutableTagset:
    new_tagset = MutableTagset(namespace=tagset.namespace, desc=tagset.desc)
    for tag in tagset.tags:
        new_tagset.add(tag)
    return new_tagset


def populate_tagset(tagset_spec: JsonObject) -> Tagset:
    """
    Collect tags from tagset spec JSON object, validate the format along the way.

    :param tagset_spec: JSON object of tagset spec
    :return: Populated Tagset instance
    """

    def validate_and_collect(name: str, tag_def: JsonObject) -> Generator[Tag, None, None]:
        if not isinstance(tag_def, dict):
            raise ValueError(f"tag '{name}' definition is not a dict")

        if not is_blank(name):
            desc = tag_def.get("$desc")
            if isinstance(desc, dict):
                desc = RichDesc(**desc)

            yield Tag(name=name, desc=desc)

        for child_name, child_tag_def in tag_def.items():
            if child_name == "$desc":
                continue

            if not isinstance(child_name, str):
                raise ValueError(f"child '{child_name}' of tag '{name}' is not a string")
            try:
                validate_snake_case(child_name)
            except ValueError as e:
                raise ValueError(f"child '{child_name}' of tag '{name}' is not in snake case") from e

            child_name = name + ":" + child_name if name else child_name

            yield from validate_and_collect(child_name, child_tag_def)

    namespace = tagset_spec.get("$namespace")
    if namespace is None:
        raise ValueError("missing '$namespace' in tagset spec")
    try:
        validate_snake_case(namespace)
    except ValueError as e:
        raise ValueError(f"tagset namespace '{namespace}' is not in snake case") from e

    desc = tagset_spec.get("$desc")
    if desc is None:
        raise ValueError("missing '$desc' in tagset spec")
    if isinstance(desc, dict):
        desc = RichDesc(**desc)

    tags = tagset_spec.get("$tags")
    if tags is None:
        raise ValueError("missing '$tags' in tagset spec")

    tagset = MutableTagset(namespace=namespace, desc=desc)

    for tag in validate_and_collect("", tags):
        tagset.add(tag)

    return tagset.frozen()


@singleton
def predefined_tagsets() -> dict[str, Tagset]:
    tagsets: dict[str, Tagset] = {}
    for _, tagset_spec in predefined_tagset_specs():
        tagset = populate_tagset(tagset_spec)
        tagsets[tagset.namespace] = tagset
    return tagsets


def render_tagset_markdown_readme(tagset: Tagset) -> str:
    def render_desc(desc: str | RichDesc | None) -> str:
        if desc is None:
            return ""
        if isinstance(desc, str):
            return desc
        if isinstance(desc, RichDesc):
            return desc.text
        raise ValueError(f"unsupported desc type '{type(desc)}'")

    template_str = textwrap.dedent(
        """
        # Tagset {{ tagset.namespace }}

        {{ tagset.desc | render_desc }}

        ## Contents

        {% for tag in tagset.tags %}
        - {{ tag.name }}
        {% endfor %}

        ## Tags

        {% for tag in tagset.tags %}
        ### {{ tag.name }}

        {{ tag.desc | render_desc }}

        {% endfor %}
        """
    )

    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters["render_desc"] = render_desc

    return env.from_string(template_str).render(tagset=tagset)


@singleton
def tag_cache_file_path() -> pathlib.Path:
    return pathlib.Path.home() / ".local" / "plus" / "datahub" / "tag_cache" / f"{randomizer().random_alphanumeric(7)}.db"


class TagCache(object):
    def __init__(
        self,
        *,
        file_path: str | os.PathLike[str] | None = None,
        fail_if_exists: bool = False,
    ):
        self.file_path = pathlib.Path(file_path or tag_cache_file_path())
        if fail_if_exists and self.file_path.exists():
            raise FileExistsError(f"tag cache file '{str(self.file_path)}' already exists")
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        self.conn_maker = ConnectionMaker.from_url(f"sqlite:///{str(self.file_path.absolute())}",
                                                   engine_opts=dict(connect_args={"check_same_thread": False}))
        BaseModel.metadata.create_all(self.conn_maker.engine)

    def query(
        self,
        vehicle_name: str | None = None,
        begin_time: datetime.datetime | None = None,
        end_time: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ) -> Generator[TagRecordTable, None, None]:
        """
        Query tag records in the cache with optional filters.

        :param vehicle_name: Filter by vehicle name (exact match)
        :param begin_time: Filter by begin time (inclusive)
        :param end_time: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :return: Generator of ``TagRecordTable`` instances that match the filters
        """
        with self.conn_maker.make_session() as session:
            query = session.query(TagRecordTable)
            if vehicle_name:
                query = query.filter(TagRecordTable.vehicle_name == vehicle_name)
            if begin_time:
                query = query.filter(TagRecordTable.end_dt >= begin_time)
            if end_time:
                query = query.filter(TagRecordTable.begin_dt <= end_time)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            yield from query.all()

    def query_bag_tag(
        self,
        vehicle_name: str | None = None,
        bag_name: str | None = None,
        begin_offset: int | None = None,
        end_offset: int | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ) -> Generator[BagTagRecordTable, None, None]:
        """
        Query bag tag records in the cache with optional filters.

        :param vehicle_name: Filter by vehicle name (exact match)
        :param bag_name: Filter by bag name (exact match)
        :param begin_offset: Filter by begin offset (inclusive)
        :param end_offset: Filter by end offset (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :return: Generator of ``BagTagRecordTable`` instances that match the filters
        """
        with self.conn_maker.make_session() as session:
            query = session.query(BagTagRecordTable)
            if vehicle_name:
                query = query.filter(BagTagRecordTable.vehicle_name == vehicle_name)
            if bag_name:
                query = query.filter(BagTagRecordTable.bag_name == bag_name)
                if begin_offset:
                    query = query.filter(BagTagRecordTable.end_offset >= begin_offset)
                if end_offset:
                    query = query.filter(BagTagRecordTable.begin_offset <= end_offset)
            if tag_pattern:
                query = query.filter(BagTagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        BagTagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        BagTagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            yield from query.all()

    def add(
        self,
        vehicle_name: str,
        begin_time: datetime.datetime,
        end_time: datetime.datetime,
        tag: str | Tag,
        props: JsonType | None = None,
    ) -> Self:
        """
        Add a tag record to the cache.

        :param vehicle_name: Vehicle name associated with the tag record
        :param begin_time: Begin datetime of the tag record
        :param end_time: End datetime of the tag record
        :param tag: Tag name or Tag instance to be added (if Tag instance is provided, its name will be used)
        :param props: Additional properties of the tag record in JSON format (optional)
        :return: Self instance for chaining
        """
        with self.conn_maker.make_session() as session:
            tag_record = TagRecord(
                vehicle_name=vehicle_name,
                begin_dt=begin_time,
                end_dt=end_time,
                tag=tag.name if isinstance(tag, Tag) else tag,
                props=props,
            )
            session.add(clone_sequence_model_instance(TagRecordTable, tag_record))
            session.commit()

        return self

    def add_bag_tag(
        self,
        vehicle_name: str,
        bag_name: str,
        begin_offset: int,
        end_offset: int,
        tag: str | Tag,
        props: JsonType | None = None,
    ) -> Self:
        """
        Add a bag tag record to the cache.

        :param vehicle_name: Vehicle name associated with the tag record
        :param bag_name: Name of the bag associated with the tag record
        :param begin_offset: Begin offset (in microseconds) of the tag record within the bag (inclusive)
        :param end_offset: End offset (in microseconds) of the tag record within the bag (inclusive)
        :param tag: Tag name or Tag instance to be added (if Tag instance is provided, its name will be used)
        :param props: Additional properties of the tag record in JSON format (optional)
        :return: Self instance for chaining
        """
        with self.conn_maker.make_session() as session:
            tag_record = BagTagRecord(
                vehicle_name=vehicle_name,
                bag_name=bag_name,
                begin_offset=begin_offset,
                end_offset=end_offset,
                tag=tag.name if isinstance(tag, Tag) else tag,
                props=props,
            )
            session.add(clone_sequence_model_instance(BagTagRecordTable, tag_record))
            session.commit()

        return self

    def remove(
        self,
        vehicle_name: str | None = None,
        begin_time: datetime.datetime | None = None,
        end_time: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ) -> Self:
        """
        Remove tag records from the cache that match the specified filters.

        :param vehicle_name: Filter by vehicle name (exact match)
        :param begin_time: Filter by begin time (inclusive)
        :param end_time: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :return: Self instance for chaining
        """
        with self.conn_maker.make_session() as session:
            query = session.query(TagRecordTable)
            if vehicle_name:
                query = query.filter(TagRecordTable.vehicle_name == vehicle_name)
            if begin_time:
                query = query.filter(TagRecordTable.end_dt >= begin_time)
            if end_time:
                query = query.filter(TagRecordTable.begin_dt <= end_time)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            query.delete()
            session.commit()

        return self

    def remove_bag_tag(
        self,
        vehicle_name: str | None = None,
        bag_name: str | None = None,
        begin_offset: int | None = None,
        end_offset: int | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ) -> Self:
        """
        Remove bag tag records from the cache that match the specified filters.

        :param vehicle_name: Filter by vehicle name (exact match)
        :param bag_name: Filter by bag name (exact match)
        :param begin_offset: Filter by begin offset (inclusive)
        :param end_offset: Filter by end offset (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :return: Self instance for chaining
        """
        with self.conn_maker.make_session() as session:
            query = session.query(BagTagRecordTable)
            if vehicle_name:
                query = query.filter(BagTagRecordTable.vehicle_name == vehicle_name)
            if bag_name:
                query = query.filter(BagTagRecordTable.bag_name == bag_name)
                if begin_offset:
                    query = query.filter(BagTagRecordTable.end_offset >= begin_offset)
                if end_offset:
                    query = query.filter(BagTagRecordTable.begin_offset <= end_offset)
            if tag_pattern:
                query = query.filter(BagTagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        BagTagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        BagTagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            query.delete()
            session.commit()

        return self

    def clear(self):
        with self.conn_maker.make_session() as session:
            session.execute(sa.delete(TagRecordTable))
            session.execute(sa.delete(BagTagRecordTable))
            session.commit()

    def append_to(self, target_file_path: str, *, overwrite: bool = False):
        target_tag_cache = TagCache(file_path=target_file_path)
        if overwrite:
            target_tag_cache.clear()
        TagCache.clone_to(self, target_tag_cache)

    def merge_from(self, source_file_path: str, *, overwrite: bool = False):
        source_tag_cache = TagCache(file_path=source_file_path)
        if overwrite:
            self.clear()
        TagCache.clone_to(source_tag_cache, self)

    @staticmethod
    def clone_to(source: "TagCache", target: "TagCache"):
        target.clear()
        with source.conn_maker.make_session() as source_session, target.conn_maker.make_session() as target_session:
            target_session.add_all(
                [clone_sequence_model_instance(TagRecordTable, db_tag_record, clear_meta_fields=True)
                 for db_tag_record in source_session.query(TagRecordTable).all()],
            )
            target_session.add_all(
                [clone_sequence_model_instance(BagTagRecordTable, db_tag_record, clear_meta_fields=True)
                 for db_tag_record in source_session.query(BagTagRecordTable).all()],
            )
            target_session.commit()


@memorized
def tag_cache(identifier: str | None = None) -> TagCache:
    """
    Get a ``TagCache`` instance associated with the given identifier. If the identifier is ``None``, return a
    ``TagCache`` instance associated with a default file path. Otherwise, validate the identifier as a snake case
    string and return a ``TagCache`` instance associated with a file path derived from the identifier.

    :param identifier: An optional string identifier for the tag cache. If provided, it must be in snake case format
    and will be used to derive the file path for the tag cache. If not provided, a default file path will be used.
    :return: A ``TagCache`` instance associated with the specified or default file path.
    """
    if identifier is None:
        return TagCache(file_path=tag_cache_file_path())
    validate_snake_case(identifier)
    return TagCache(file_path=tag_cache_file_path().parent / f"{identifier}.db")
