import pathlib

__all__ = [
    "module_directory",
    "source_directory",
    "test_directory",
    "resources_directory",
    "temporary_directory",
]

module_directory: pathlib.Path = pathlib.Path(__file__).absolute().parent.parent
source_directory: pathlib.Path = module_directory / "src"
test_directory: pathlib.Path = module_directory / "test"
resources_directory: pathlib.Path = module_directory / "resources"
temporary_directory: pathlib.Path = module_directory / "tmp"
