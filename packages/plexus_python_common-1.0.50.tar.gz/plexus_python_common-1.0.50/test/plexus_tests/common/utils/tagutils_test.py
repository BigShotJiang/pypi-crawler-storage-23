import datetime
import unittest

import ddt
from iker.common.utils.dtutils import dt_parse_iso

from plexus.common.utils.tagutils import MutableTagset, Tag, TagCache, Tagset
from plexus.common.utils.tagutils import predefined_tagsets, render_tagset_markdown_readme
from plexus.common.utils.tagutils import tag_cache_file_path


@ddt.ddt
class TagUtilsTest(unittest.TestCase):

    def test_predefined_tagsets(self):
        tagsets = predefined_tagsets()
        for _, tagset in tagsets.items():
            self.assertIsInstance(tagset, Tagset)
            self.assertNotIsInstance(tagset, MutableTagset)

            for tag in tagset:
                self.assertIn(tag, tagset)
                self.assertIn(tag.name, tagset)
                self.assertEqual(tag, tagset.get(tag))
                self.assertEqual(tag, tagset.get(tag.name))

            markdown = render_tagset_markdown_readme(tagset)
            self.assertIsInstance(markdown, str)

            print(markdown)

    def test_tag_cache(self):
        tag_cache = TagCache()

        self.assertEqual(tag_cache.file_path, tag_cache_file_path())
        self.assertTrue(tag_cache.file_path.exists())

        self.assertEqual(len(list(tag_cache.query("dummy_vehicle"))), 0)

        tagset = MutableTagset(namespace="tagset", desc="A dummy tagset for testing")

        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="A dummy tag for testing"))

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]
        for i in range(1000):
            tag_cache.add(
                "dummy_vehicle",
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(seconds=i),
                dt_parse_iso("2021-01-01T00:00:00.000000+00:00") + datetime.timedelta(seconds=i + 1),
                tags[i % len(tags)],
            )
        for i in range(1000):
            tag_cache.add_bag_tag(
                "dummy_vehicle",
                f"20200101T000000-dummy_vehicle-{i // 100}.bag",
                i % 100,
                i % 100 + 1,
                tags[i % len(tags)],
            )

        self.assertEqual(len(list(tag_cache.query())), 1000)
        self.assertEqual(len(list(tag_cache.query("dummy_vehicle"))), 1000)
        self.assertEqual(len(list(tag_cache.query(tagsets=[tagset]))), 500)
        self.assertEqual(len(list(tag_cache.query(tagsets=[tagset], tagset_inverted=True))), 500)
        self.assertEqual(len(list(tag_cache.query(tagsets=[tagset], tagset_inverted=False))), 500)
        self.assertEqual(
            len(list(tag_cache.query("dummy_vehicle",
                                     dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                     dt_parse_iso("2020-01-01T00:01:00.000000+00:00")))),
            61,
        )
        self.assertEqual(
            len(list(tag_cache.query("dummy_vehicle",
                                     dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                     dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                     tag_pattern="dummy:foo"))),
            16,
        )
        self.assertEqual(
            len(list(tag_cache.query("dummy_vehicle",
                                     dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                     dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                     tag_pattern="dummy:bar"))),
            15,
        )
        self.assertEqual(
            len(list(tag_cache.query("dummy_vehicle",
                                     dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                     dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                     tag_pattern="dummy"))),
            61,
        )
        self.assertEqual(len(list(tag_cache.query("dummy_vehicle", tag_pattern="dummy:foo"))), 250)
        self.assertEqual(len(list(tag_cache.query("dummy_vehicle", tag_pattern="dummy:bar"))), 250)
        self.assertEqual(len(list(tag_cache.query("dummy_vehicle", tag_pattern="dummy"))), 1000)
        self.assertEqual(len(list(tag_cache.query("another_dummy_vehicle"))), 0)
        self.assertEqual(len(list(tag_cache.query_bag_tag())), 1000)
        self.assertEqual(len(list(tag_cache.query_bag_tag(tagsets=[tagset]))), 500)
        self.assertEqual(len(list(tag_cache.query_bag_tag(tagsets=[tagset], tagset_inverted=True))), 500)
        self.assertEqual(len(list(tag_cache.query_bag_tag(tagsets=[tagset], tagset_inverted=False))), 500)
        self.assertEqual(len(list(tag_cache.query_bag_tag("dummy_vehicle"))), 1000)
        self.assertEqual(len(list(tag_cache.query_bag_tag("dummy_vehicle",
                                                          "20200101T000000-dummy_vehicle-0.bag"))),
                         100)
        self.assertEqual(len(list(tag_cache.query_bag_tag("dummy_vehicle",
                                                          "20200101T000000-dummy_vehicle-0.bag",
                                                          0,
                                                          50))),
                         51)

        tag_cache.remove("dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                         dt_parse_iso("2020-01-01T00:01:00.000000+00:00"))
        tag_cache.remove_bag_tag("dummy_vehicle",
                                 "20200101T000000-dummy_vehicle-0.bag")

        self.assertEqual(len(list(tag_cache.query("dummy_vehicle"))), 939)
        self.assertEqual(len(list(tag_cache.query_bag_tag("dummy_vehicle"))), 900)

        tag_cache.remove(tagsets=[tagset], tagset_inverted=True)
        tag_cache.remove_bag_tag(tagsets=[tagset], tagset_inverted=True)

        self.assertEqual(len(list(tag_cache.query())), 469)
        self.assertEqual(len(list(tag_cache.query_bag_tag())), 450)

        tag_cache.clear()

        self.assertEqual(len(list(tag_cache.query())), 0)
        self.assertEqual(len(list(tag_cache.query_bag_tag())), 0)
