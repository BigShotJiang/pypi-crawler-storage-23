# API Reference: rest

```python
from brinkhaustools.rest import RestServer
```

Requires the `rest` extra: `pip install brinkhaustools[rest]`

---

## RestServer

Flask + Waitress HTTP server with standard endpoints.

```python
RestServer(
    app=app,                  # App object (reads components from it)
    host="0.0.0.0",
    port=8080,
    enable_auth=True,
    username="admin",
    default_password="admin",
    ui_path=None,             # static UI assets directory
    description_path=None,    # mainSettingsDescription.json directory
    version_path=None,        # version.json directory
)
```

Individual components can also be passed directly to override what is
read from `app`:

```python
RestServer(
    settings=my_settings,
    diagnosis=my_diagnosis,
    shutdown=my_shutdown,
    port=9090,
)
```

| Method      | Description                                        |
|-------------|----------------------------------------------------|
| `start()`   | Start server on a background daemon thread         |
| `stop()`    | Log stop (daemon thread exits with process)        |
| `flask_app` | Access underlying Flask app for custom routes      |

### Adding Custom Routes

```python
server = RestServer(app=app, port=8080)

@server.flask_app.route("/api/custom")
def custom_endpoint():
    return {"data": "hello"}

server.start()
```

### Built-in Endpoints

| Endpoint                   | Method | Description                      |
|----------------------------|--------|----------------------------------|
| `/api/login`               | POST   | Authenticate (bcrypt)            |
| `/api/password`            | POST   | Change password                  |
| `/api/getSettings`         | GET    | Full settings JSON               |
| `/api/setSettings`         | POST   | Replace settings                 |
| `/api/getDescription`      | GET    | Settings schema                  |
| `/api/version`             | GET    | version.json                     |
| `/api/logs/getServiceLog`  | GET    | Ring buffer log lines            |
| `/api/logs/getMeasuringLog`| GET    | Measuring log (placeholder)      |
| `/api/status/RuntimeTests` | GET    | Diagnosis status                 |
| `/api/status/all`          | GET    | All StatusEngine data            |
| `/api/restartApp`          | GET    | Trigger shutdown (0.5s delay)    |
