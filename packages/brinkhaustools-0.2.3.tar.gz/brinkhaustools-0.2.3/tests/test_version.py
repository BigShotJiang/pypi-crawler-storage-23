"""Tests for VersionInformation."""

import json
import os
import tempfile

from brinkhaustools.common.version import VersionInformation


def test_load_from_file():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump({"Version": "1.2.3", "Branch": "main"}, f)
        path = f.name
    v = VersionInformation(file_path=path)
    assert v.version == "1.2.3"
    assert v.data["Branch"] == "main"
    os.unlink(path)


def test_defaults_on_missing_file():
    v = VersionInformation(file_path="/nonexistent/version.json")
    assert v.version == "dev"


def test_status_source_interface():
    v = VersionInformation(file_path="/nonexistent/version.json")
    assert v.get_name() == "Version information"
    status = v.get_status()
    assert "Version" in status
