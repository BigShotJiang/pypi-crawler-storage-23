# Malva Client

[![PyPI](https://img.shields.io/pypi/v/malva-client)](https://pypi.org/project/malva-client/)
[![Documentation](https://readthedocs.org/projects/malva-client/badge/?version=latest)](https://malva-client.readthedocs.io)
[![GitHub](https://img.shields.io/badge/GitHub-malva--bio%2Fmalva__client-blue)](https://github.com/malva-bio/malva_client)

Python client for the [Malva](https://malva.bio) genomic search platform. Search genes, sequences, and natural language queries across >7,000 single-cell and spatial transcriptomics samples.

For full documentation, visit [malva-client.readthedocs.io](https://malva-client.readthedocs.io).

## Installation

```bash
pip install malva-client
```

For single-cell analysis workflows:
```bash
pip install malva-client scanpy
```

## Authentication

Generate an API token at [malva.bio](https://malva.bio) (login with ORCID, then go to Profile > Generate API Token), then configure the client:

```bash
malva_client config --server https://malva.mdc-berlin.de --token YOUR_API_TOKEN
```

## Quick Start (CLI)

```bash
malva_client search "CD3D" --output results.csv
malva_client search "ATCGATCGATCGATCGATCGATCG" --format json
malva_client search "CD4 T cells in brain tissue"
```

## Quick Start (Python)

```python
from malva_client import MalvaClient

client = MalvaClient("https://malva.mdc-berlin.de", "YOUR_API_TOKEN")

# Search for genes, sequences, or natural language queries
results = client.search("CD3D")
print(results)

# Search for sequences
results = client.search("ATCGATCGATCGCCACATGGACTTGAC")

# Natural language queries
results = client.search("cells expressing markers of neurodegeneration")
```

### Working with Results

```python
# Enrich results with metadata
results.enrich_with_metadata()
fig = results.plot_expression_summary("cell_type")

# Filter and aggregate
filtered = results.filter_by(disease='normal', organ='brain')
```

See the [tutorials](https://malva-client.readthedocs.io/en/latest/tutorials.html) for coverage analysis, dataset discovery, cell-level searches, and more.

## Indexing Your Own Data

For local indexing and quantification, see [Malva Tools](https://github.com/malva-bio/malva) (`malva` CLI).

## Citation

If you use Malva in your research, please cite:

> [TBA]

## License

The Clear BSD License - Copyright (c) 2025-2026 Malva
