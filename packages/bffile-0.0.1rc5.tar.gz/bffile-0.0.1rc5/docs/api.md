---
icon: lucide/code
---

# API Reference

::: bffile
    options:
        summary:
            attributes: false
            classes: true
            functions: true
            type_aliases: true
