"""Yet another Bio-Formats wrapper for Python."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("bffile")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "uninstalled"

from ._biofile import BioFile
from ._core_metadata import CoreMetadata, OMEShape
from ._imread import imread, open_ome_zarr_group, open_zarr_array
from ._lazy_array import LazyBioArray
from ._series import Series

__all__ = [
    "BioFile",
    "CoreMetadata",
    "LazyBioArray",
    "OMEShape",
    "Series",
    "imread",
    "open_ome_zarr_group",
    "open_zarr_array",
]
