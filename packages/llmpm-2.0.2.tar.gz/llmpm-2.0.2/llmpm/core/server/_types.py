"""Callback type aliases for server.start().

Each alias describes one category of model capability.  Backends that
don't support a given capability pass ``None``; the server returns HTTP 501
for the corresponding endpoints.
"""
from __future__ import annotations

from collections.abc import Iterator
from typing import Callable

# ── text generation ───────────────────────────────────────────────────────────
InferFn       = Callable[[list[dict[str, str]], int, float], str]
InferStreamFn = Callable[[list[dict[str, str]], int, float], Iterator[str]]
EmbedFn       = Callable[[list[str]], list[list[float]]]

# ── image generation ──────────────────────────────────────────────────────────
InferImageFn     = Callable[[str, int, "str | None"], list[str]]
InferImageEditFn = Callable[[str, bytes, int, "str | None"], list[str]]

# ── audio ─────────────────────────────────────────────────────────────────────
TranscribeFn = Callable[[bytes, "str | None"], str]
SynthesizeFn = Callable[[str, "str | None", float], bytes]
