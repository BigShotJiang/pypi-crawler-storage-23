"""Allow `python -m llmpm` invocation."""

from llmpm.cli import entry

if __name__ == "__main__":
    entry()
