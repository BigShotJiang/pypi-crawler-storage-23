"""llmpm — LLM Package Manager."""

__version__ = "2.0.2"
__author__ = "llmpm contributors"
