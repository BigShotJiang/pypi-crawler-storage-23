"""
XSDK - Python通用开发工具包

提供常用的工具类和方法，包括：
- xutil: 通用工具（字符串、日期、JSON处理等）
- template: HTML模板生成
- file_util: 文件操作工具
- config_reader: 配置文件读取
- csv_parser: CSV文件解析
- excel_util: Excel文件处理
- file_parser: 多格式文件解析
- bean_util: 对象序列化工具
- chart_util: 图表生成工具
- mysql_client: MySQL数据库客户端
- redis_client: Redis缓存客户端
- http_client: HTTP客户端
- http_proxy: HTTP代理工具
- spider_util: 网页爬虫工具
- mail_client: 邮件发送客户端
- cos_client: 腾讯云COS存储客户端
- xlog: 日志管理
"""

__version__ = "1.0.0"
__author__ = "xsdk"

# 基础工具模块（无外部依赖）
from xsdk.xutil import Xutil
from xsdk.template import HtmlTemplate
from xsdk.file_util import FileUtil
from xsdk.config_reader import ConfigReader

# 导出主要类
__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    # 基础工具
    "Xutil",
    "HtmlTemplate",
    "FileUtil",
    "ConfigReader",
]
