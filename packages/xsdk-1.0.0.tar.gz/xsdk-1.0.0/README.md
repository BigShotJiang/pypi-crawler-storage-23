# XSDK-PY
    python基础开发工具包

## 安装依赖
python3 -m pip install -r requirements.txt

## 安装构建工具（unix/macos）
python3 -m pip install --upgrade build

## 构建项目（unix/macos）
python3 -m build

## 离线安装
python3 -m pip uninstall xsdk-py
python3 -m pip install dist/xsdk-py-{version}.tar.gz


## 附录：RGB颜色编码
    https://tool.oschina.net/commons?type=3
