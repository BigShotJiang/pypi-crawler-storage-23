# awsweb

A simple FastAPI web server, installable from PyPI.

## Installation

```bash
pip install awsweb
```

## Usage

Run the server:

```bash
awsweb
```

Options:

```
awsweb --host 127.0.0.1 --port 8080 --reload
```

| Flag       | Default   | Description                     |
|------------|-----------|---------------------------------|
| `--host`   | `0.0.0.0` | Host to bind to                |
| `--port`   | `8000`    | Port to bind to                |
| `--reload` | off       | Enable auto-reload (dev mode)  |

## Endpoints

| Method | Path      | Description           |
|--------|-----------|-----------------------|
| GET    | `/`       | Welcome message       |
| GET    | `/health` | Health check          |

## Development

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT