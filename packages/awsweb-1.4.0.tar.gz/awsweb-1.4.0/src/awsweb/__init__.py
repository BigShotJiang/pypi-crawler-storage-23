"""awsweb - A simple FastAPI web server."""

__version__ = "1.4.0"

import json
import logging
import sys
from http import HTTPStatus
from pathlib import Path

from uvicorn.logging import DefaultFormatter

PACKAGE_NAME = "awsweb"
APP_DIR = Path.home() / f".{PACKAGE_NAME}"
LOCK_FILE_PATH = APP_DIR / "web.lock"


def get_lock_data():
    try:
        return json.loads(LOCK_FILE_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def get_logger():
    logger = logging.getLogger(PACKAGE_NAME)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        DefaultFormatter(
            fmt="%(levelprefix)s %(asctime)s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            use_colors=True,
        )
    )
    logger.handlers.clear()
    logger.addHandler(handler)
    return logger


RESET = "\033[0m"
BRIGHT_WHITE = "\033[97m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
BRIGHT_RED = "\033[91m"


def format_status(status_code: int) -> str:
    """Format an HTTP status code with color for log printing."""
    try:
        phrase = HTTPStatus(status_code).phrase
    except ValueError:
        phrase = "UNKNOWN"

    color = BRIGHT_WHITE
    if 200 <= status_code < 300:
        color = GREEN
    elif 300 <= status_code < 400:
        color = YELLOW
    elif 400 <= status_code < 500:
        color = RED
    elif status_code >= 500:
        color = BRIGHT_RED

    return f"{color}{status_code} {phrase}{RESET}"

def remove_none_values(d):
    return {k: v for k, v in d.items() if v is not None}
