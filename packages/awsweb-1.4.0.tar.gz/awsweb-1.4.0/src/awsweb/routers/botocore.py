"""Botocore router - service models, regions, endpoints."""


import botocore.loaders
from fastapi import APIRouter
from fastapi.responses import JSONResponse

from .. import get_logger

logger = get_logger()

router = APIRouter(prefix="/api/botocore", tags=["botocore"])

_loader = botocore.loaders.Loader()


@router.get("/services")
async def list_services():
    """List all available AWS service names."""
    try:
        services = _loader.list_available_services("service-2")
        return sorted(services)
    except Exception as e:
        logger.exception("Error listing services", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/services/{service}")
async def get_service_model(service: str, api_version: str = None):
    """Get full service model for a given service."""
    try:
        model = _loader.load_service_model(service, "service-2", api_version)
        return model
    except Exception as e:
        logger.exception(f"Error loading service model: {service}", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/services/{service}/operations")
async def list_operations(service: str, api_version: str = None):
    """List operations for a given service."""
    try:
        model = _loader.load_service_model(service, "service-2", api_version)
        operations = model.get("operations", {})
        return list(operations.keys())
    except Exception as e:
        logger.exception(f"Error listing operations for {service}", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/services/{service}/operations/{operation}")
async def get_operation(service: str, operation: str, api_version: str = None):
    """Get operation details including input/output shape."""
    try:
        model = _loader.load_service_model(service, "service-2", api_version)
        operations = model.get("operations", {})
        shapes = model.get("shapes", {})

        op = operations.get(operation)
        if op is None:
            return JSONResponse(
                status_code=404,
                content={"error": f"Operation '{operation}' not found in {service}"},
            )

        result = {**op}

        # Resolve input shape
        input_shape = op.get("input", {}).get("shape")
        if input_shape and input_shape in shapes:
            result["inputShape"] = shapes[input_shape]

        # Resolve output shape
        output_shape = op.get("output", {}).get("shape")
        if output_shape and output_shape in shapes:
            result["outputShape"] = shapes[output_shape]

        return result
    except Exception as e:
        logger.exception(
            f"Error getting operation {operation} for {service}", exc_info=e
        )
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/regions")
async def list_regions():
    """List all known AWS regions from endpoints data."""
    try:
        endpoints = _loader.load_data("endpoints")
        regions = set()
        for partition in endpoints.get("partitions", []):
            for region_name in partition.get("regions", {}):
                regions.add(region_name)
        return sorted(regions)
    except Exception as e:
        logger.exception("Error listing regions", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/endpoints")
async def get_endpoints():
    """Get full endpoints data."""
    try:
        return _loader.load_data("endpoints")
    except Exception as e:
        logger.exception("Error loading endpoints", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})
