"""System router - lock, update, restart, shutdown."""

import os
import signal
import time

import psutil
from fastapi import APIRouter
from fastapi.responses import JSONResponse

from .. import get_logger, get_lock_data, LOCK_FILE_PATH, PACKAGE_NAME, __version__

logger = get_logger()

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/version")
async def get_version():
    """Get current package version."""
    return {"version": __version__, "package": PACKAGE_NAME}


@router.get("/lock")
async def get_lock():
    """Get current lock data (PID, port)."""
    data = get_lock_data()
    if data:
        return data
    return JSONResponse(status_code=404, content={"error": "No lock file found"})

@router.post("/shutdown")
async def shutdown():
    """Shutdown the server."""
    try:
        logger.info("Shutdown requested")
        pid = os.getpid()

        # Clean up lock file
        if os.path.exists(LOCK_FILE_PATH):
            os.remove(LOCK_FILE_PATH)

        # Delayed kill to give time for response
        import threading

        def _kill():
            time.sleep(0.5)
            try:
                p = psutil.Process(pid)
                p.terminate()
            except Exception:
                os.kill(pid, signal.SIGTERM)

        threading.Thread(target=_kill, daemon=True).start()
        return {"status": "shutting down"}
    except Exception as e:
        logger.exception("Error shutting down", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.get("/processes")
async def list_processes():
    """List running awsweb processes."""
    try:
        processes = []
        for proc in psutil.process_iter(["pid", "name", "cmdline", "create_time"]):
            try:
                cmdline = proc.info.get("cmdline") or []
                cmd_str = " ".join(cmdline)
                if PACKAGE_NAME in cmd_str:
                    processes.append(
                        {
                            "pid": proc.info["pid"],
                            "name": proc.info["name"],
                            "cmdline": cmdline,
                            "create_time": proc.info["create_time"],
                        }
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return {"processes": processes}
    except Exception as e:
        logger.exception("Error listing processes", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})
