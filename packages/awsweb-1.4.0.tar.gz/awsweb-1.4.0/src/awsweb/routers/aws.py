"""AWS router - boto3 proxy, console redirect, session management."""

import asyncio
import base64
import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import boto3
from botocore.response import StreamingBody
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.exceptions import HTTPException

from .. import get_logger, remove_none_values
from aws_sso_lite.sso import AWSSSO
from ..http import send_request

logger = get_logger()

router = APIRouter(prefix="/aws", tags=["aws"])


# --- Router endpoints ---


@router.post("/{service}/{action}")
async def aws_proxy(
    service: str,
    action: str,
    request: Request,
):
    """Proxy boto3 API calls: /aws/{service}/{action}.

    All params (auth info, aws_region, API data) come from the POST body.
    """
    try:
        body = await request.json()

        auth_info = remove_none_values({
            "authentication_type": body.get("authentication_type"),
            "sso_region": body.get("sso_region"),
            "sso_start_url": body.get("sso_start_url"),
            "aws_account_id": body.get("aws_account_id"),
            "sso_role_name": body.get("sso_role_name"),
            "assumed_role_arn": body.get("assumed_role_arn"),
        })

        aws_region = body.get("aws_region")
        data = body.get("data", {})

        boto3_session = await get_boto3_session(**auth_info)
        result = await execute_aws_action(boto3_session, aws_region, service, action, data)

        return JSONResponse(
            content=json.loads(json.dumps(result, cls=BotoJSONEncoder))
        )
    except Exception as e:
        logger.exception(f"Error in AWS proxy: {service}.{action}", exc_info=e)
        return JSONResponse(
            status_code=500,
            content={"error": str(e), "__type": type(e).__name__},
        )


@router.get("/{aws_account_alias}/console")
async def aws_console_redirect(
    aws_account_alias: str,
    authentication_type: Optional[str] = Query(None),
    sso_region: Optional[str] = Query(None),
    sso_start_url: Optional[str] = Query(None),
    aws_account_id: Optional[str] = Query(None),
    sso_role_name: Optional[str] = Query(None),
    assumed_role_arn: Optional[str] = Query(None),
    aws_region: Optional[str] = Query(None),
    aws_domain: str = Query("aws.amazon.com"),
    destination: str = Query(""),
):
    """Redirect to AWS Console with federated sign-in."""
    try:
        auth_info = remove_none_values({
            "authentication_type": authentication_type,
            "sso_region": sso_region,
            "sso_start_url": sso_start_url,
            "aws_account_id": aws_account_id,
            "sso_role_name": sso_role_name,
            "assumed_role_arn": assumed_role_arn,
        })

        if sso_region is not None and sso_region.startswith("cn-"):
            aws_domain = "amazonaws.cn"

        boto3_session = await get_boto3_session(**auth_info)
        signin_token = await fetch_signin_token(aws_domain, boto3_session)

        base_console_url = f"https://{aws_region}.console.{aws_domain}"
        dest_url = f"{base_console_url}/console/home?region={aws_region}"
        if destination:
            dest_url = f"{base_console_url}/{destination}"

        login_url = (
            f"https://signin.{aws_domain}/federation?"
            + urlencode(
                {
                    "Action": "login",
                    "Issuer": "",
                    "Destination": dest_url,
                    "SigninToken": signin_token,
                }
            )
        )

        return RedirectResponse(login_url)
    except Exception as e:
        logger.exception("Error in console redirect", exc_info=e)
        return JSONResponse(status_code=500, content={"error": str(e)})


# --- boto3 session management ---


async def get_boto3_session(**authentication_info):
    b3s = boto3.session.Session()

    if authentication_info is not None:
        t = authentication_info.get("authentication_type")
        if t == "sso":
            sso_region = authentication_info.get("sso_region")
            sso_start_url = authentication_info.get("sso_start_url")
            aws_account_id = authentication_info.get("aws_account_id")
            sso_role_name = authentication_info.get("sso_role_name")
            assumed_role_arn = authentication_info.get("assumed_role_arn")

            b3s = await asyncio.get_running_loop().run_in_executor(
                None,
                lambda: AWSSSO(sso_start_url, sso_region).get_boto3_session(
                    aws_account_id, sso_role_name, assumed_role_arn
                ),
            )

    return b3s


# --- Request deduplication ---

_in_flight_requests: Dict[str, asyncio.Future] = {}
_in_flight_lock = asyncio.Lock()


def _generate_request_hash(
    boto3_session, aws_region: str, service: str, action: str, data: Any
) -> str:
    creds = boto3_session.get_credentials()

    if creds is None:
        session_id = "anonymous"
    else:
        frozen_creds = creds.get_frozen_credentials()
        session_id = f"{frozen_creds.access_key}:{frozen_creds.secret_key}:{frozen_creds.token or ''}"

    request_key = f"{session_id}:{aws_region}:{service}:{action}:{json.dumps(data, sort_keys=True)}"
    return hashlib.sha256(request_key.encode()).hexdigest()


async def execute_aws_action(
    boto3_session, aws_region: str, service: str, action: str, data: Any
):
    request_hash = _generate_request_hash(
        boto3_session, aws_region, service, action, data
    )

    async with _in_flight_lock:
        if request_hash in _in_flight_requests:
            logger.debug(
                f"Deduplicating request: {service}.{action} (hash: {request_hash[:8]}...)"
            )
            existing_future = _in_flight_requests[request_hash]
        else:
            existing_future = None
            future = asyncio.get_running_loop().create_future()
            _in_flight_requests[request_hash] = future

    if existing_future is not None:
        return await existing_future

    try:

        def _execute():
            client = boto3_session.client(
                service, **remove_none_values({"region_name": aws_region})
            )
            return getattr(client, action)(**remove_none_values(data))

        logger.debug(
            f"Executing AWS request: {service}.{action} (hash: {request_hash[:8]}...)"
        )
        result = await asyncio.get_running_loop().run_in_executor(None, _execute)
        future.set_result(result)
        return result

    except Exception as e:
        future.set_exception(e)
        raise

    finally:
        async with _in_flight_lock:
            _in_flight_requests.pop(request_hash, None)


# --- JSON encoding & sign-in token ---


class BotoJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, StreamingBody):
            return obj.read().decode("utf-8", errors="replace")
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, bytes):
            return base64.b64encode(obj).decode()
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super().default(obj)


_credentials = {}


async def fetch_signin_token(aws_domain, boto3_session):
    creds = boto3_session.get_credentials()
    key = f"signin-token-{aws_domain}-{hash(creds.access_key + creds.secret_key + creds.token)}"

    global _credentials

    if key in _credentials:
        if _credentials[key]["expiration"] > int(
            datetime.now(tz=timezone.utc).timestamp() * 1000
        ):
            return _credentials[key]["SigninToken"]
        else:
            del _credentials[key]

    encoded_session = urlencode(
        {
            "Session": json.dumps(
                {
                    "sessionId": creds.access_key,
                    "sessionKey": creds.secret_key,
                    "sessionToken": creds.token,
                }
            )
        }
    )

    get_signin_token_endpoint = f"https://signin.{aws_domain}/federation?Action=getSigninToken&{encoded_session}"
    res = await send_request("GET", get_signin_token_endpoint)

    _credentials[key] = {
        "expiration": int(datetime.now(tz=timezone.utc).timestamp() * 1000) + 600000,
        "SigninToken": res.json().get("SigninToken"),
    }

    return res.json().get("SigninToken")
