"""CLI entry point for awsweb."""

import argparse
import threading
import webbrowser

import uvicorn


def main() -> None:
    """Run the awsweb FastAPI server."""
    parser = argparse.ArgumentParser(
        prog="awsweb",
        description="A simple FastAPI web server",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=3086,
        help="Port to bind to (default: 3086)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development",
    )
    parser.add_argument(
        "--no-open",
        action="store_true",
        help="Don't auto-open browser",
    )
    args = parser.parse_args()

    if not args.no_open:
        url = f"http://{args.host}:{args.port}"
        threading.Timer(1.5, webbrowser.open, args=[url]).start()

    uvicorn.run(
        "awsweb.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
