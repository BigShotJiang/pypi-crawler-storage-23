"""FastAPI application with all API routers."""

import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__, get_logger
from .routers import auth, aws, botocore, cache, system

logger = get_logger()

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(
    title="awsweb",
    description="AWS Web Tools",
    version=__version__,
)

# --- Middleware ---

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def access_log(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = (time.time() - start) * 1000
    if not request.url.path.startswith("/assets"):
        logger.debug(
            f"{request.method} {request.url.path} -> {response.status_code} ({duration_ms:.1f}ms)"
        )
    return response


# --- Include all routers ---

app.include_router(auth.router)
app.include_router(aws.router)
app.include_router(botocore.router)
app.include_router(cache.router)
app.include_router(system.router)


# --- Core endpoints ---


@app.get("/api")
async def api_root() -> dict:
    """API root endpoint returning a welcome message."""
    return {"message": "Welcome to awsweb", "version": __version__}


@app.get("/health")
async def health() -> dict:
    """Health check endpoint."""
    return {"status": "ok"}


@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def unknown_api(path: str):
    """Catch-all for unknown API routes."""
    return JSONResponse(
        status_code=404,
        content={"error": f"Unknown API endpoint: /api/{path}"},
    )


# --- Serve React SPA ---

if STATIC_DIR.is_dir():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str) -> FileResponse:
        """Serve the React SPA for all non-API routes."""
        file_path = STATIC_DIR / full_path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(STATIC_DIR / "index.html")
