"""HTTP client utilities with retry and caching."""

import asyncio
import hashlib
import time
from typing import Any, Dict, Optional, Tuple

import httpx
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential
from urllib.parse import urlparse


def _should_retry(exc):
    if isinstance(exc, httpx.RequestError):
        return True
    return False


timeout: float = 30.0
max_retries: int = 3


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception(_should_retry),
)
async def send_request(method: str, url: str, **kwargs) -> httpx.Response:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Invalid URL scheme: {parsed.scheme}")

    validated_url = url

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.request(method.upper(), validated_url, **kwargs)
        return response


async def send_request_cached(method: str, url: str, **kwargs) -> httpx.Response:
    """Send HTTP request with promise caching - concurrent identical requests share the same result."""
    return await request_cache.get_or_fetch(
        lambda: send_request(method, url, **kwargs),
        method,
        url,
        **kwargs,
    )


class RequestCache:
    """HTTP request promise cache - deduplicates concurrent requests to the same endpoint."""

    def __init__(self, ttl: float = 300):  # 5 minutes default TTL
        self._cache: Dict[str, Tuple[Any, float]] = {}
        self._pending: Dict[str, asyncio.Event] = {}
        self._lock = asyncio.Lock()
        self.ttl = ttl

    def _get_cache_key(self, method: str, url: str, **kwargs) -> str:
        key_parts = [method.upper(), url]

        if "params" in kwargs and kwargs["params"]:
            params_str = str(sorted(kwargs["params"].items()))
            key_parts.append(params_str)

        if "json" in kwargs and kwargs["json"]:
            key_parts.append(str(kwargs["json"]))
        elif "content" in kwargs and kwargs["content"]:
            content_hash = hashlib.md5(kwargs["content"]).hexdigest()
            key_parts.append(content_hash)

        key = "|".join(key_parts)
        return hashlib.md5(key.encode()).hexdigest()

    def _is_cached(self, cache_key: str) -> bool:
        if cache_key not in self._cache:
            return False
        _, timestamp = self._cache[cache_key]
        return (time.time() - timestamp) < self.ttl

    async def get_or_fetch(self, fetch_fn, method: str, url: str, **kwargs):
        cache_key = self._get_cache_key(method, url, **kwargs)

        if self._is_cached(cache_key):
            result, _ = self._cache[cache_key]
            return result

        async with self._lock:
            if self._is_cached(cache_key):
                result, _ = self._cache[cache_key]
                return result

            if cache_key in self._pending:
                event = self._pending[cache_key]
            else:
                event = None
                new_event = asyncio.Event()
                self._pending[cache_key] = new_event

        if event is not None:
            await event.wait()
            # After wait, result is in cache
            if self._is_cached(cache_key):
                result, _ = self._cache[cache_key]
                return result
            # Fetch failed; fall through would need retry, but just raise
            raise RuntimeError(f"Pending request failed for {method} {url}")

        try:
            result = await fetch_fn()
            async with self._lock:
                self._cache[cache_key] = (result, time.time())
                new_event.set()
            return result
        except Exception:
            async with self._lock:
                new_event.set()
            raise
        finally:
            async with self._lock:
                self._pending.pop(cache_key, None)

    def clear(self):
        self._cache.clear()
        self._pending.clear()

    def invalidate(self, method: str, url: str, **kwargs):
        cache_key = self._get_cache_key(method, url, **kwargs)
        if cache_key in self._cache:
            del self._cache[cache_key]


# Global instance
request_cache = RequestCache(ttl=300)
