"""Multi-outcome event arbitrage.

When N outcomes in an event have YES prices that sum to != 1.0,
there's an arbitrage opportunity. If sum < 1 - fees: buy all.
If sum > 1 + fees: sell all.
"""

from __future__ import annotations

import logging
import time
from typing import Callable

from horizon.context import Context

from ._types import EventArbResult

logger = logging.getLogger(__name__)


def event_arb_scanner(
    event_id: str,
    min_edge: float = 0.01,
    max_size: float = 50.0,
    fee_rate: float = 0.002,
    auto_execute: bool = False,
    cooldown: float = 10.0,
    proportional: bool = True,
) -> Callable[[Context], None]:
    """Create a pipeline function that scans for multi-outcome event arbitrage.

    Args:
        event_id: Registered event ID.
        min_edge: Minimum net edge to consider actionable.
        max_size: Maximum total trade size.
        fee_rate: Fee rate per outcome trade.
        auto_execute: If True, execute event arb automatically.
        cooldown: Seconds between executions.
        proportional: If True, size inversely proportional to price.

    Returns:
        Pipeline function: (Context) -> None
    """
    from horizon._horizon import auth_require_pro
    auth_require_pro()

    last_exec_time = 0.0

    def _scanner(ctx: Context) -> None:
        nonlocal last_exec_time

        engine = ctx.params.get("engine")
        if engine is None:
            return None

        opp = engine.scan_event_arb(event_id, fee_rate)
        if opp is None or opp.net_edge < min_edge:
            return None

        ctx.params["last_event_arb"] = opp

        if auto_execute:
            now = time.monotonic()
            if now - last_exec_time >= cooldown:
                try:
                    order_ids = engine.execute_event_arb(
                        event_id,
                        opp.direction,
                        max_size,
                        proportional=proportional,
                    )
                    last_exec_time = now
                    ctx.params["last_event_arb_result"] = EventArbResult(
                        event_id=event_id,
                        direction=opp.direction,
                        price_sum=opp.price_sum,
                        net_edge=opp.net_edge,
                        size=max_size,
                        order_ids=order_ids,
                    )
                    logger.info(
                        "Event arb executed: %s dir=%s edge=%.4f legs=%d",
                        event_id, opp.direction, opp.net_edge, len(order_ids),
                    )
                except Exception as e:
                    logger.warning("Event arb execution failed for %s: %s", event_id, e)

        return None

    _scanner.__name__ = "event_arb_scanner"
    return _scanner


def event_arb_sweep(
    engine,
    event_id: str,
    min_edge: float = 0.01,
    max_size: float = 50.0,
    fee_rate: float = 0.002,
    proportional: bool = True,
) -> EventArbResult | None:
    """One-shot event arbitrage sweep.

    Args:
        engine: Horizon Engine instance.
        event_id: Registered event ID.
        min_edge: Minimum net edge.
        max_size: Maximum total trade size.
        fee_rate: Fee rate per outcome trade.
        proportional: If True, size inversely proportional to price.

    Returns:
        EventArbResult if executed, None if no opportunity found.
    """
    from horizon._horizon import auth_require_pro
    auth_require_pro()

    opp = engine.scan_event_arb(event_id, fee_rate)
    if opp is None or opp.net_edge < min_edge:
        return None

    try:
        order_ids = engine.execute_event_arb(
            event_id, opp.direction, max_size, proportional=proportional,
        )
    except Exception as e:
        logger.warning("Event arb sweep failed for %s: %s", event_id, e)
        return None

    return EventArbResult(
        event_id=event_id,
        direction=opp.direction,
        price_sum=opp.price_sum,
        net_edge=opp.net_edge,
        size=max_size,
        order_ids=order_ids,
    )
