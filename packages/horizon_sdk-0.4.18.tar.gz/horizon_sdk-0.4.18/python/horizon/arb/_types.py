"""Shared result types for all arbitrage methods."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class ArbResult:
    """Result of a cross-exchange arbitrage execution."""

    market_id: str
    buy_exchange: str
    sell_exchange: str
    buy_price: float
    sell_price: float
    size: float
    raw_edge: float
    net_edge: float
    buy_order_id: str = ""
    sell_order_id: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class EventArbResult:
    """Result of a multi-outcome event arbitrage execution."""

    event_id: str
    direction: str  # "buy_all" or "sell_all"
    price_sum: float
    net_edge: float
    size: float
    order_ids: list[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


@dataclass
class SpreadSignal:
    """Signal from spread convergence analysis."""

    market_a: str
    market_b: str
    spread: float
    spread_mean: float
    spread_std: float
    zscore: float
    signal: str  # "long_a_short_b" | "long_b_short_a" | "exit" | "hold"


@dataclass
class StatArbResult:
    """Result of a statistical arbitrage signal."""

    pair: tuple[str, str]
    hedge_ratio: float
    zscore: float
    half_life: float
    adf_stat: float
    signal: str  # "long_a_short_b" | "long_b_short_a" | "exit" | "stop" | "hold"
    timestamp: float = field(default_factory=time.time)


@dataclass
class CompositeArbResult:
    """Result of composite arbitrage scanner scoring."""

    method: str
    score: float
    net_edge: float
    capital_needed: float
    details: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
