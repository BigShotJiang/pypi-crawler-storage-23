"""Arbitrage methods for prediction market trading.

Tier progression:
    Tier 1 (Basic):    Parity Arb, Cross-Exchange Arb
    Tier 2 (Intermediate): Multi-Outcome Arb, Spread Convergence
    Tier 3 (Advanced):     Statistical Arb, Market-Making Arb
    Tier 4 (Expert):       Latency Arb, Composite Scanner

All symbols are re-exported here for backward compatibility:
    from horizon.arb import arb_scanner  # still works
"""

from horizon.arb._types import (
    ArbResult,
    CompositeArbResult,
    EventArbResult,
    SpreadSignal,
    StatArbResult,
)
from horizon.arb._cross_exchange import arb_scanner, arb_sweep
from horizon.arb._parity import parity_arb_scanner, parity_arb_sweep
from horizon.arb._multi_outcome import event_arb_scanner, event_arb_sweep
from horizon.arb._spread import spread_convergence
from horizon.arb._stat import StatArbConfig, stat_arb
from horizon.arb._mm_arb import MMArbConfig, mm_arb
from horizon.arb._latency import latency_arb
from horizon.arb._composite import ArbMethodConfig, composite_arb

__all__ = [
    # Types
    "ArbResult",
    "EventArbResult",
    "SpreadSignal",
    "StatArbResult",
    "CompositeArbResult",
    # Tier 1: Cross-Exchange (existing)
    "arb_scanner",
    "arb_sweep",
    # Tier 1: Parity
    "parity_arb_scanner",
    "parity_arb_sweep",
    # Tier 2: Multi-Outcome
    "event_arb_scanner",
    "event_arb_sweep",
    # Tier 2: Spread Convergence
    "spread_convergence",
    # Tier 3: Statistical Arb
    "StatArbConfig",
    "stat_arb",
    # Tier 3: Market-Making Arb
    "MMArbConfig",
    "mm_arb",
    # Tier 4: Latency Arb (Ultra)
    "latency_arb",
    # Tier 4: Composite Scanner (Ultra)
    "ArbMethodConfig",
    "composite_arb",
]
