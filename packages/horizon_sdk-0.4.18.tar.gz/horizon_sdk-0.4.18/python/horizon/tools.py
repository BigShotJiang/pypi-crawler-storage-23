"""Shared tool functions for MCP server and OpenClaw skill.

Thin wrappers around the Horizon Engine API that return plain dicts/lists
suitable for JSON serialization. Both the MCP server and the OpenClaw CLI
delegate to these functions.
"""

from __future__ import annotations

import math
import os
import threading
from typing import Any

from horizon._horizon import (
    Engine,
    EngineStatus,
    FeedSnapshot,
    Fill,
    Market,
    Order,
    OrderRequest,
    OrderSide,
    Position,
    Side,
    ContingentOrder,
)
from horizon.discovery import discover_markets, discover_events, top_markets
from horizon.flow import (
    get_market_trades as _get_market_trades,
    get_wallet_trades as _get_wallet_trades,
    get_wallet_positions as _get_wallet_positions,
    get_wallet_value as _get_wallet_value,
    get_top_holders as _get_top_holders,
    get_wallet_profile as _get_wallet_profile,
    analyze_market_flow as _analyze_market_flow,
)

_engine: Engine | None = None
_engine_lock = threading.Lock()


def get_engine() -> Engine:
    """Lazy-init a singleton Engine from environment variables."""
    global _engine
    if _engine is not None:
        return _engine

    with _engine_lock:
        # Double-check after acquiring lock
        if _engine is not None:
            return _engine

        exchange = os.environ.get("HORIZON_EXCHANGE", "paper")
        db_path = os.environ.get("HORIZON_DB") or None

        kwargs: dict[str, Any] = {
            "exchange_type": exchange,
            "db_path": db_path,
            "api_key": os.environ.get("HORIZON_API_KEY"),
        }

        if exchange == "polymarket":
            kwargs["exchange_key"] = os.environ.get("POLYMARKET_API_KEY")
            kwargs["exchange_secret"] = os.environ.get("POLYMARKET_API_SECRET")
            kwargs["exchange_passphrase"] = os.environ.get("POLYMARKET_API_PASSPHRASE")
            kwargs["private_key"] = os.environ.get("POLYMARKET_PRIVATE_KEY")
            kwargs["clob_url"] = os.environ.get("POLYMARKET_CLOB_URL")
        elif exchange == "kalshi":
            kwargs["email"] = os.environ.get("KALSHI_EMAIL")
            kwargs["password"] = os.environ.get("KALSHI_PASSWORD")
            kwargs["exchange_key"] = os.environ.get("KALSHI_API_KEY")
            kwargs["api_url"] = os.environ.get("KALSHI_API_URL")

        _engine = Engine(**kwargs)
        return _engine


def reset_engine() -> None:
    """Reset the singleton engine (for testing)."""
    global _engine
    with _engine_lock:
        _engine = None


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

def _status_to_dict(s: EngineStatus) -> dict:
    return {
        "running": s.running,
        "kill_switch_active": s.kill_switch_active,
        "kill_switch_reason": s.kill_switch_reason,
        "open_orders": s.open_orders,
        "active_positions": s.active_positions,
        "total_realized_pnl": round(s.total_realized_pnl, 6),
        "total_unrealized_pnl": round(s.total_unrealized_pnl, 6),
        "daily_pnl": round(s.daily_pnl, 6),
        "uptime_secs": s.uptime_secs,
    }


def _position_to_dict(p: Position) -> dict:
    return {
        "market_id": p.market_id,
        "side": "yes" if p.side == Side.Yes else "no",
        "size": round(p.size, 6),
        "avg_entry_price": round(p.avg_entry_price, 6),
        "realized_pnl": round(p.realized_pnl, 6),
        "unrealized_pnl": round(p.unrealized_pnl, 6),
        "exchange": p.exchange,
    }


def _order_to_dict(o: Order) -> dict:
    return {
        "id": o.id,
        "market_id": o.market_id,
        "side": "yes" if o.side == Side.Yes else "no",
        "order_side": "buy" if o.order_side == OrderSide.Buy else "sell",
        "price": round(o.price, 6),
        "size": round(o.size, 6),
        "filled_size": round(o.filled_size, 6),
        "remaining_size": round(o.remaining_size, 6),
        "status": str(o.status),
        "exchange": o.exchange,
        "created_at": o.created_at,
    }


def _fill_to_dict(f: Fill) -> dict:
    return {
        "fill_id": f.fill_id,
        "order_id": f.order_id,
        "market_id": f.market_id,
        "side": "yes" if f.side == Side.Yes else "no",
        "order_side": "buy" if f.order_side == OrderSide.Buy else "sell",
        "price": round(f.price, 6),
        "size": round(f.size, 6),
        "fee": round(f.fee, 6),
        "timestamp": f.timestamp,
        "exchange": f.exchange,
    }


def _feed_to_dict(name: str, s: FeedSnapshot) -> dict:
    d = {
        "name": name,
        "price": round(s.price, 6),
        "bid": round(s.bid, 6),
        "ask": round(s.ask, 6),
        "volume_24h": round(s.volume_24h, 2),
        "source": s.source,
        "timestamp": s.timestamp,
    }
    if hasattr(s, "last_trade_size"):
        d["last_trade_size"] = round(s.last_trade_size, 6)
        d["last_trade_is_buy"] = s.last_trade_is_buy
    return d


def _market_to_dict(m: Market) -> dict:
    return {
        "id": m.id,
        "name": m.name,
        "slug": m.slug,
        "exchange": m.exchange,
        "expiry": m.expiry,
        "active": m.active,
    }


def _contingent_to_dict(c: ContingentOrder) -> dict:
    return {
        "id": c.id,
        "trigger_type": str(c.trigger_type),
        "market_id": c.market_id,
        "side": "yes" if c.side == Side.Yes else "no",
        "order_side": "buy" if c.order_side == OrderSide.Buy else "sell",
        "size": round(c.size, 6),
        "trigger_price": round(c.trigger_price, 6),
        "trigger_pnl": c.trigger_pnl,
        "exchange": c.exchange,
        "triggered": c.triggered,
        "child_order_id": c.child_order_id,
    }


# ---------------------------------------------------------------------------
# Tool functions - each returns dict | list[dict] | str
# ---------------------------------------------------------------------------

def engine_status() -> dict:
    """Get trading engine status."""
    try:
        return _status_to_dict(get_engine().status())
    except Exception as e:
        return {"error": str(e)}


def list_positions() -> list[dict] | dict:
    """List all open positions."""
    try:
        return [_position_to_dict(p) for p in get_engine().positions()]
    except Exception as e:
        return {"error": str(e)}


def list_open_orders(market_id: str | None = None) -> list[dict] | dict:
    """List open orders, optionally filtered by market."""
    try:
        eng = get_engine()
        if market_id:
            orders = eng.open_orders_for_market(market_id)
        else:
            orders = eng.open_orders()
        return [_order_to_dict(o) for o in orders]
    except Exception as e:
        return {"error": str(e)}


def list_recent_fills(limit: int = 20) -> list[dict] | dict:
    """List recent fills."""
    try:
        fills = get_engine().recent_fills()
        return [_fill_to_dict(f) for f in fills[-limit:]]
    except Exception as e:
        return {"error": str(e)}


def submit_order(
    market_id: str, side: str, price: float, size: float, market_side: str = "yes",
) -> dict:
    """Submit a limit order. side: 'buy' or 'sell'. market_side: 'yes' or 'no'."""
    try:
        if not (0.0 < price < 1.0):
            return {"error": f"price must be between 0 and 1 (exclusive), got {price}"}
        if not (size > 0) or math.isnan(size):
            return {"error": f"size must be a positive number, got {size}"}
        order_side = OrderSide.Buy if side.lower() == "buy" else OrderSide.Sell
        ms = Side.Yes if market_side.lower() == "yes" else Side.No
        req = OrderRequest(
            market_id=market_id,
            side=ms,
            order_side=order_side,
            size=size,
            price=price,
        )
        order_id = get_engine().submit_order(req)
        return {
            "order_id": order_id, "market_id": market_id, "side": side,
            "market_side": market_side, "price": price, "size": size,
        }
    except Exception as e:
        return {"error": str(e)}


def cancel_order(order_id: str) -> dict:
    """Cancel a single order by ID."""
    try:
        get_engine().cancel(order_id)
        return {"canceled": order_id}
    except Exception as e:
        return {"error": str(e)}


def cancel_all_orders() -> dict:
    """Cancel all open orders."""
    try:
        count = get_engine().cancel_all()
        return {"canceled_count": count}
    except Exception as e:
        return {"error": str(e)}


def cancel_market_orders(market_id: str) -> dict:
    """Cancel all orders for a specific market."""
    try:
        count = get_engine().cancel_market(market_id)
        return {"market_id": market_id, "canceled_count": count}
    except Exception as e:
        return {"error": str(e)}


def activate_kill_switch(reason: str) -> dict:
    """Activate the kill switch - emergency stop. Cancels all orders."""
    try:
        get_engine().activate_kill_switch(reason)
        return {"kill_switch": "activated", "reason": reason}
    except Exception as e:
        return {"error": str(e)}


def deactivate_kill_switch() -> dict:
    """Deactivate the kill switch - resume trading."""
    try:
        get_engine().deactivate_kill_switch()
        return {"kill_switch": "deactivated"}
    except Exception as e:
        return {"error": str(e)}


def get_feed_snapshot(name: str) -> dict:
    """Get price/bid/ask snapshot for a named feed."""
    try:
        snap = get_engine().feed_snapshot(name)
        if snap is None:
            return {"error": f"feed not found: {name}"}
        return _feed_to_dict(name, snap)
    except Exception as e:
        return {"error": str(e)}


def list_all_feeds() -> list[dict] | dict:
    """List all feed snapshots."""
    try:
        snapshots = get_engine().all_feed_snapshots()
        return [_feed_to_dict(name, snap) for name, snap in snapshots.items()]
    except Exception as e:
        return {"error": str(e)}


def discover(
    exchange: str = "polymarket",
    query: str = "",
    limit: int = 10,
    market_type: str = "all",
    category: str = "",
) -> list[dict] | dict:
    """Search for markets on an exchange.

    market_type: "all" (default), "binary", or "multi".
    category: Tag/category filter (e.g., "crypto", "politics").
    """
    try:
        results: list[dict] = []

        if market_type in ("all", "binary"):
            markets = discover_markets(exchange=exchange, query=query, limit=limit, category=category)
            results.extend(_market_to_dict(m) for m in markets)

        if market_type in ("all", "multi") and exchange == "polymarket":
            events = discover_events(exchange="polymarket", query=query, limit=limit)
            for ev in events:
                outcomes = []
                for o in ev.outcomes:
                    outcomes.append({
                        "name": o.name,
                        "market_id": o.market_id,
                        "yes_price": round(o.yes_price, 4),
                    })
                results.append({
                    "id": ev.id,
                    "name": ev.name,
                    "type": "multi",
                    "outcome_count": len(outcomes),
                    "outcomes": outcomes,
                    "exchange": ev.exchange,
                    "condition_id": ev.condition_id,
                    "expiry": ev.expiry,
                })

        return results[:limit]
    except Exception as e:
        return {"error": str(e)}


def kelly_sizing(
    prob: float,
    price: float,
    bankroll: float = 1000.0,
    fraction: float = 0.25,
    max_size: float = 100.0,
) -> dict:
    """Compute Kelly-optimal position size."""
    try:
        from horizon._horizon import kelly_size, edge as kelly_edge

        size = kelly_size(prob, price, bankroll, fraction, max_size)
        e = kelly_edge(prob, price)
        return {
            "optimal_size": round(size, 4),
            "edge": round(e, 4),
            "prob": prob,
            "price": price,
            "bankroll": bankroll,
            "fraction": fraction,
        }
    except Exception as e:
        return {"error": str(e)}


def check_parity(market_id: str, feed_name: str | None = None) -> dict:
    """Check YES/NO price parity for a market. Optionally specify a feed_name."""
    try:
        if feed_name is not None:
            result = get_engine().parity_check(market_id, feed_name=feed_name)
        else:
            result = get_engine().parity_check(market_id)
        if result is None:
            return {"error": f"no parity data for market: {market_id}"}
        return {
            "market_id": result.market_id,
            "yes_price": round(result.yes_price, 6),
            "no_price": round(result.no_price, 6),
            "deviation": round(result.deviation, 6),
            "is_violation": result.is_violation,
            "exchange": result.exchange,
        }
    except Exception as e:
        return {"error": str(e)}


def feed_metrics(name: str) -> dict:
    """Get feed connection metrics (update count, errors, reconnects)."""
    try:
        m = get_engine().feed_metrics(name)
        if m is None:
            return {"error": f"no metrics for feed: {name}"}
        return {
            "name": name,
            "update_count": m.update_count,
            "error_count": m.error_count,
            "last_update_time": m.last_update_time,
            "last_error": m.last_error,
            "is_connected": m.is_connected,
            "reconnect_count": m.reconnect_count,
        }
    except Exception as e:
        return {"error": str(e)}


def all_feed_metrics() -> list[dict] | dict:
    """Get metrics for all active feeds."""
    try:
        metrics = get_engine().all_feed_metrics()
        return [
            {
                "name": name,
                "update_count": m.update_count,
                "error_count": m.error_count,
                "last_update_time": m.last_update_time,
                "last_error": m.last_error,
                "is_connected": m.is_connected,
                "reconnect_count": m.reconnect_count,
            }
            for name, m in metrics.items()
        ]
    except Exception as e:
        return {"error": str(e)}


def add_stop_loss(
    market_id: str,
    side: str,
    order_side: str,
    size: float,
    trigger: float,
) -> dict:
    """Add a stop-loss contingent order."""
    try:
        s = Side.Yes if side.lower() == "yes" else Side.No
        os_ = OrderSide.Buy if order_side.lower() == "buy" else OrderSide.Sell
        cid = get_engine().add_stop_loss(market_id, s, os_, size, trigger)
        return {"contingent_id": cid, "type": "stop_loss", "market_id": market_id}
    except Exception as e:
        return {"error": str(e)}


def add_take_profit(
    market_id: str,
    side: str,
    order_side: str,
    size: float,
    trigger: float,
) -> dict:
    """Add a take-profit contingent order."""
    try:
        s = Side.Yes if side.lower() == "yes" else Side.No
        os_ = OrderSide.Buy if order_side.lower() == "buy" else OrderSide.Sell
        cid = get_engine().add_take_profit(market_id, s, os_, size, trigger)
        return {"contingent_id": cid, "type": "take_profit", "market_id": market_id}
    except Exception as e:
        return {"error": str(e)}


def list_contingent_orders() -> list[dict] | dict:
    """List pending stop-loss and take-profit orders."""
    try:
        return [_contingent_to_dict(c) for c in get_engine().pending_contingent_orders()]
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Discovery tools
# ---------------------------------------------------------------------------

def discover_event(
    query: str = "",
    limit: int = 10,
    min_volume: float = 0.0,
) -> list[dict] | dict:
    """Discover multi-outcome events on Polymarket."""
    try:
        events = discover_events(
            exchange="polymarket", query=query,
            active=True, limit=limit, min_volume=min_volume,
        )
        results = []
        for ev in events:
            outcomes = []
            for o in ev.outcomes:
                outcomes.append({
                    "name": o.name,
                    "market_id": o.market_id,
                    "yes_price": round(o.yes_price, 4),
                })
            results.append({
                "id": ev.id,
                "name": ev.name,
                "outcome_count": len(outcomes),
                "outcomes": outcomes,
                "exchange": ev.exchange,
                "condition_id": ev.condition_id,
                "expiry": ev.expiry,
            })
        return results
    except Exception as e:
        return {"error": str(e)}


def market_detail(slug_or_id: str, exchange: str = "polymarket") -> dict:
    """Fetch comprehensive detail for a single market."""
    try:
        from horizon.discovery import get_market_detail
        return get_market_detail(slug_or_id, exchange=exchange)
    except Exception as e:
        return {"error": str(e)}


def get_top_markets(
    exchange: str = "polymarket",
    limit: int = 10,
    category: str = "",
) -> list[dict] | dict:
    """Get top markets by volume."""
    try:
        markets = top_markets(exchange=exchange, limit=limit, category=category)
        return [_market_to_dict(m) for m in markets]
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Wallet analytics tools
# ---------------------------------------------------------------------------

def wallet_trades(
    address: str,
    limit: int = 50,
    condition_id: str | None = None,
) -> list[dict] | dict:
    """Fetch trade history for a Polymarket wallet."""
    try:
        trades = _get_wallet_trades(address, limit=limit, condition_id=condition_id)
        return [
            {
                "wallet": t.wallet,
                "side": t.side,
                "outcome": t.outcome,
                "size": round(t.size, 4),
                "price": round(t.price, 4),
                "usdc_size": round(t.usdc_size, 2),
                "timestamp": t.timestamp,
                "market_slug": t.market_slug,
                "market_title": t.market_title,
                "pseudonym": t.pseudonym,
            }
            for t in trades
        ]
    except Exception as e:
        return {"error": str(e)}


def market_trades(
    condition_id: str,
    limit: int = 50,
    side: str | None = None,
    min_size: float = 0.0,
) -> list[dict] | dict:
    """Fetch recent trades for a Polymarket market."""
    try:
        trades = _get_market_trades(
            condition_id, limit=limit, side=side, min_size=min_size,
        )
        return [
            {
                "wallet": t.wallet,
                "side": t.side,
                "outcome": t.outcome,
                "size": round(t.size, 4),
                "price": round(t.price, 4),
                "usdc_size": round(t.usdc_size, 2),
                "timestamp": t.timestamp,
                "market_title": t.market_title,
                "pseudonym": t.pseudonym,
            }
            for t in trades
        ]
    except Exception as e:
        return {"error": str(e)}


def wallet_positions(
    address: str,
    limit: int = 50,
    sort_by: str = "CURRENT",
) -> list[dict] | dict:
    """Fetch open positions for a Polymarket wallet."""
    try:
        positions = _get_wallet_positions(address, limit=limit, sort_by=sort_by)
        return [
            {
                "market_title": p.market_title,
                "market_slug": p.market_slug,
                "outcome": p.outcome,
                "size": round(p.size, 4),
                "avg_price": round(p.avg_price, 4),
                "current_price": round(p.current_price, 4),
                "current_value": round(p.current_value, 2),
                "pnl": round(p.pnl, 2),
                "pnl_percent": round(p.pnl_percent, 2),
            }
            for p in positions
        ]
    except Exception as e:
        return {"error": str(e)}


def wallet_value(address: str) -> dict:
    """Get total USD value of a Polymarket wallet's positions."""
    try:
        value = _get_wallet_value(address)
        return {"wallet": address, "total_value_usd": round(value, 2)}
    except Exception as e:
        return {"error": str(e)}


def wallet_profile(address: str) -> dict:
    """Get public profile for a Polymarket wallet."""
    try:
        profile = _get_wallet_profile(address)
        if profile is None:
            return {"error": f"no profile found for {address}"}
        return {
            "wallet": profile.wallet,
            "pseudonym": profile.pseudonym,
            "name": profile.name,
            "bio": profile.bio,
            "profile_image": profile.profile_image,
            "x_username": profile.x_username,
            "created_at": profile.created_at,
        }
    except Exception as e:
        return {"error": str(e)}


def market_top_holders(condition_id: str, limit: int = 20) -> list[dict] | dict:
    """Get top holders for a Polymarket market."""
    try:
        holders = _get_top_holders(condition_id, limit=limit)
        return [
            {
                "wallet": h.wallet,
                "amount": round(h.amount, 4),
                "token_id": h.token_id,
                "outcome_index": h.outcome_index,
                "pseudonym": h.pseudonym,
                "name": h.name,
            }
            for h in holders
        ]
    except Exception as e:
        return {"error": str(e)}


def market_flow(
    condition_id: str,
    trade_limit: int = 500,
    top_n: int = 10,
) -> dict:
    """Analyze trade flow for a Polymarket market."""
    try:
        flow = _analyze_market_flow(
            condition_id, trade_limit=trade_limit, top_n=top_n,
        )
        return {
            "condition_id": flow.condition_id,
            "total_trades": flow.total_trades,
            "buy_volume": round(flow.buy_volume, 2),
            "sell_volume": round(flow.sell_volume, 2),
            "net_flow": round(flow.net_flow, 2),
            "unique_wallets": flow.unique_wallets,
            "top_buyers": [
                {"wallet": w, "volume": round(v, 2)} for w, v in flow.top_buyers
            ],
            "top_sellers": [
                {"wallet": w, "volume": round(v, 2)} for w, v in flow.top_sellers
            ],
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Feed health tools
# ---------------------------------------------------------------------------

def start_feed(
    name: str,
    feed_type: str,
    config_json: str | None = None,
    symbol: str | None = None,
    url: str | None = None,
    interval: float = 5.0,
) -> dict:
    """Start a live data feed on the engine.

    For newer feed types (predictit, manifold, espn, nws, rest_json_path,
    chainlink), pass structured config via ``config_json``.
    For legacy types (binance_ws, polymarket_book, kalshi_book, rest),
    use the keyword arguments.
    """
    try:
        kwargs: dict[str, Any] = {}
        if symbol is not None:
            kwargs["symbol"] = symbol
        if url is not None:
            kwargs["url"] = url
        kwargs["interval"] = interval
        if config_json is not None:
            kwargs["config_json"] = config_json
        get_engine().start_feed(name, feed_type, **kwargs)
        return {"started": name, "feed_type": feed_type}
    except Exception as e:
        return {"error": str(e)}


def check_feed_health(stale_threshold: float = 30.0) -> dict:
    """Check staleness and health of all active feeds."""
    try:
        import time
        snapshots = get_engine().all_feed_snapshots()
        now = time.time()
        feeds = {}
        stale_count = 0
        for name, snap in snapshots.items():
            age = now - snap.timestamp if snap.timestamp > 0 else float("inf")
            is_stale = age > stale_threshold or snap.timestamp <= 0
            if is_stale:
                stale_count += 1
            feeds[name] = {
                "name": name,
                "is_stale": is_stale,
                "age_secs": round(age, 1),
                "price": round(snap.price, 6),
                "bid": round(snap.bid, 6),
                "ask": round(snap.ask, 6),
            }
        return {
            "feeds": feeds,
            "total_feeds": len(feeds),
            "stale_count": stale_count,
            "all_stale": stale_count == len(feeds) and len(feeds) > 0,
            "stale_threshold_secs": stale_threshold,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Simulation tools
# ---------------------------------------------------------------------------

def simulate_portfolio(
    scenarios: int = 10000,
    seed: int | None = None,
) -> dict:
    """Run Monte Carlo simulation on the engine's current positions."""
    try:
        from horizon.simulate import simulate
        result = simulate(engine=get_engine(), scenarios=scenarios, seed=seed)
        return {
            "mean_pnl": round(result.mean_pnl, 2),
            "median_pnl": round(result.median_pnl, 2),
            "std_dev": round(result.std_dev, 2),
            "var_95": round(result.var_95, 2),
            "var_99": round(result.var_99, 2),
            "cvar_95": round(result.cvar_95, 2),
            "max_loss": round(result.max_loss, 2),
            "max_gain": round(result.max_gain, 2),
            "win_probability": round(result.win_probability, 4),
            "scenarios": scenarios,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Arbitrage tools
# ---------------------------------------------------------------------------

def execute_arb(
    market_id: str,
    buy_exchange: str,
    sell_exchange: str,
    buy_price: float,
    sell_price: float,
    size: float,
) -> dict:
    """Execute a cross-exchange arbitrage trade with atomic rollback."""
    try:
        buy_id, sell_id = get_engine().execute_arbitrage(
            market_id, buy_exchange, sell_exchange,
            buy_price=buy_price, sell_price=sell_price, size=size,
        )
        return {
            "buy_order_id": buy_id,
            "sell_order_id": sell_id,
            "market_id": market_id,
            "buy_exchange": buy_exchange,
            "sell_exchange": sell_exchange,
            "buy_price": buy_price,
            "sell_price": sell_price,
            "size": size,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Quantitative analytics tools
# ---------------------------------------------------------------------------

def compute_shannon_entropy(p: float) -> dict:
    """Compute binary Shannon entropy for a probability."""
    try:
        from horizon._horizon import shannon_entropy
        return {"entropy": round(shannon_entropy(p), 6), "probability": p}
    except Exception as e:
        return {"error": str(e)}


def compute_kl_divergence(p: list[float], q: list[float]) -> dict:
    """Compute KL divergence between two probability distributions."""
    try:
        from horizon._horizon import kl_divergence
        return {"kl_divergence": round(kl_divergence(p, q), 6)}
    except Exception as e:
        return {"error": str(e)}


def compute_hurst_exponent(prices: list[float]) -> dict:
    """Compute Hurst exponent for a price series. >0.5 trending, <0.5 mean-reverting."""
    try:
        from horizon._horizon import hurst_exponent
        h = hurst_exponent(prices)
        regime = "trending" if h > 0.55 else "mean-reverting" if h < 0.45 else "random walk"
        return {"hurst": round(h, 4), "regime": regime}
    except Exception as e:
        return {"error": str(e)}


def compute_variance_ratio(returns: list[float], period: int = 2) -> dict:
    """Variance ratio test. 1.0 = random walk."""
    try:
        from horizon._horizon import variance_ratio
        vr = variance_ratio(returns, period)
        is_efficient = 0.8 <= vr <= 1.2
        return {"variance_ratio": round(vr, 4), "period": period, "is_efficient": is_efficient}
    except Exception as e:
        return {"error": str(e)}


def compute_cornish_fisher_var(returns: list[float], confidence: float = 0.95) -> dict:
    """Cornish-Fisher VaR/CVaR (skew/kurtosis-adjusted)."""
    try:
        from horizon._horizon import cornish_fisher_var, cornish_fisher_cvar
        var = cornish_fisher_var(returns, confidence)
        cvar = cornish_fisher_cvar(returns, confidence)
        return {
            "var": round(var, 6),
            "cvar": round(cvar, 6),
            "confidence": confidence,
            "n_observations": len(returns),
        }
    except Exception as e:
        return {"error": str(e)}


def compute_prediction_greeks(
    price: float,
    size: float,
    is_yes: bool = True,
    t_hours: float = 24.0,
    vol: float = 0.2,
) -> dict:
    """Compute prediction Greeks (delta, gamma, theta, vega) for a binary market position."""
    try:
        from horizon._horizon import prediction_greeks
        g = prediction_greeks(price, size, is_yes, t_hours, vol)
        return {
            "delta": round(g.delta, 6),
            "gamma": round(g.gamma, 6),
            "theta": round(g.theta, 6),
            "vega": round(g.vega, 6),
            "price": price,
            "size": size,
        }
    except Exception as e:
        return {"error": str(e)}


def compute_deflated_sharpe(
    sharpe: float,
    n_obs: int,
    n_trials: int,
    skew: float = 0.0,
    kurt: float = 3.0,
) -> dict:
    """Deflated Sharpe Ratio: tests if observed Sharpe is statistically significant given multiple trials."""
    try:
        from horizon._horizon import deflated_sharpe, bonferroni_threshold
        p_value = deflated_sharpe(sharpe, n_obs, n_trials, skew, kurt)
        bonf = bonferroni_threshold(0.05, n_trials)
        return {
            "p_value": round(p_value, 6),
            "is_significant": p_value < 0.05,
            "bonferroni_alpha": round(bonf, 6),
            "sharpe": sharpe,
            "n_obs": n_obs,
            "n_trials": n_trials,
        }
    except Exception as e:
        return {"error": str(e)}


def run_signal_diagnostics(predictions: list[float], outcomes: list[float]) -> dict:
    """Run signal diagnostics: information coefficient, half-life, Hurst exponent."""
    try:
        from horizon.quant import signal_diagnostics
        return signal_diagnostics(predictions, outcomes)
    except Exception as e:
        return {"error": str(e)}


def run_market_efficiency(prices: list[float]) -> dict:
    """Analyze market efficiency: variance ratio, Hurst exponent, efficiency flag."""
    try:
        from horizon.quant import market_efficiency
        return market_efficiency(prices)
    except Exception as e:
        return {"error": str(e)}


def run_stress_test(
    n_simulations: int = 10000,
    seed: int | None = None,
) -> dict:
    """Run stress test on current engine positions under adverse scenarios."""
    try:
        from horizon._horizon import SimPosition
        from horizon.stress import stress_test, CORRELATION_SPIKE, ALL_RESOLVE_NO, LIQUIDITY_SHOCK, TAIL_RISK

        eng = get_engine()
        positions = eng.positions()
        if not positions:
            return {"error": "no open positions to stress test"}

        sim_positions = []
        feeds = eng.all_feed_snapshots()
        for p in positions:
            price = 0.5
            snap = feeds.get(p.market_id)
            if snap is not None:
                price = snap.price
            sim_positions.append(SimPosition(
                p.market_id,
                "yes" if p.side == Side.Yes else "no",
                p.size,
                p.avg_entry_price,
                price,
            ))

        result = stress_test(sim_positions, n_simulations=n_simulations, seed=seed)
        return {
            "worst_scenario": result.worst_scenario,
            "worst_pnl": round(result.worst_pnl, 2),
            "scenarios": [
                {
                    "name": s.scenario.name,
                    "mean_pnl": round(s.sim.mean_pnl, 2),
                    "var_95": round(s.sim.var_95, 2),
                    "worst_pnl": round(s.sim.max_loss, 2),
                }
                for s in result.scenarios
            ],
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Tearsheet tools
# ---------------------------------------------------------------------------

def generate_tearsheet_report(
    equity_curve: list[float] | None = None,
    timestamps: list[float] | None = None,
    trades: list | None = None,
    initial_capital: float = 1000.0,
) -> dict:
    """Generate a comprehensive tearsheet with monthly returns, rolling Sharpe/Sortino, drawdown analysis, and trade stats."""
    try:
        from horizon.analytics import generate_tearsheet
        # Build (timestamp, equity) tuples from separate lists
        ec = equity_curve or []
        ts_list = timestamps or []
        if ts_list and ec:
            curve = list(zip(ts_list, ec))
        else:
            curve = [(float(i), v) for i, v in enumerate(ec)]
        ts = generate_tearsheet(
            equity_curve=curve,
            trades=trades or [],
            initial_capital=initial_capital,
        )
        return {
            "monthly_returns": ts.monthly_returns,
            "avg_win": round(ts.avg_win, 4),
            "avg_loss": round(ts.avg_loss, 4),
            "largest_win": round(ts.largest_win, 4),
            "largest_loss": round(ts.largest_loss, 4),
            "avg_hold_time": round(ts.avg_hold_time, 2),
            "win_streak": ts.win_streak,
            "loss_streak": ts.loss_streak,
            "max_consecutive_wins": ts.max_consecutive_wins,
            "max_consecutive_losses": ts.max_consecutive_losses,
            "tail_ratio": round(ts.tail_ratio, 4),
            "time_of_day": {str(k): round(v, 6) for k, v in ts.time_of_day.items()},
            "drawdowns": [
                {
                    "start_ts": round(d.start_ts, 2),
                    "end_ts": round(d.end_ts, 2),
                    "recovery_ts": round(d.recovery_ts, 2) if d.recovery_ts else None,
                    "depth_pct": round(d.depth_pct, 6),
                    "duration_secs": round(d.duration_secs, 2),
                }
                for d in (ts.drawdowns or [])
            ],
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Bayesian optimization tools
# ---------------------------------------------------------------------------

def run_bayesian_optimize(
    param_space: dict[str, list[float]],
    n_iterations: int = 20,
    n_initial: int = 5,
    seed: int | None = None,
) -> dict:
    """Run Bayesian optimization (GP + Expected Improvement) to find optimal strategy parameters."""
    try:
        from horizon.bayesian_opt import bayesian_optimize
        # Create a simple quadratic objective for parameter exploration
        # In practice, users would provide their own objective via Python
        def objective(**params):
            # Default: negative sum of squared deviations from midpoint
            total = 0.0
            for name, val in params.items():
                bounds = param_space.get(name, [0, 1])
                mid = (bounds[0] + bounds[1]) / 2
                total -= (val - mid) ** 2
            return total

        result = bayesian_optimize(
            objective=objective,
            param_space=param_space,
            n_iterations=n_iterations,
            n_initial=n_initial,
            seed=seed,
        )
        return {
            "best_params": {k: round(v, 6) for k, v in result.best_params.items()},
            "best_value": round(result.best_value, 6),
            "n_iterations": result.n_iterations,
            "all_values": [round(v, 6) for v in result.all_values],
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Portfolio management tools
# ---------------------------------------------------------------------------

def get_portfolio_metrics() -> dict:
    """Get portfolio metrics: total value, PnL, diversification, concentration, Sharpe."""
    try:
        from horizon.portfolio import Portfolio
        eng = get_engine()
        portfolio = Portfolio.from_engine(eng)
        metrics = portfolio.metrics()
        return {
            "total_value": round(metrics.total_value, 2),
            "total_pnl": round(metrics.total_pnl, 2),
            "total_pnl_pct": round(metrics.total_pnl_pct, 4),
            "num_positions": metrics.num_positions,
            "long_exposure": round(metrics.long_exposure, 2),
            "short_exposure": round(metrics.short_exposure, 2),
            "net_exposure": round(metrics.net_exposure, 2),
            "gross_exposure": round(metrics.gross_exposure, 2),
            "herfindahl_index": round(metrics.herfindahl_index, 4),
            "max_concentration": round(metrics.max_concentration, 4),
        }
    except Exception as e:
        return {"error": str(e)}


def get_portfolio_weights(method: str = "equal") -> dict:
    """Compute optimal portfolio weights. method: 'equal', 'kelly', 'risk_parity', 'min_variance'."""
    try:
        from horizon.portfolio import Portfolio
        eng = get_engine()
        portfolio = Portfolio.from_engine(eng)
        if method == "kelly":
            weights = portfolio.optimize_kelly()
        elif method == "risk_parity":
            weights = portfolio.optimize_risk_parity()
        elif method == "min_variance":
            weights = portfolio.optimize_min_variance()
        else:
            weights = portfolio.optimize_equal_weight()
        return {
            "method": method,
            "weights": {k: round(v, 6) for k, v in weights.items()},
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Hot-reload parameter tools
# ---------------------------------------------------------------------------

def update_runtime_params(params: dict[str, float]) -> dict:
    """Update runtime parameters on the engine (hot-reload). Values available to pipeline via ctx.params."""
    try:
        eng = get_engine()
        eng.update_params_batch(params)
        return {"updated": list(params.keys()), "count": len(params)}
    except Exception as e:
        return {"error": str(e)}


def get_runtime_params() -> dict:
    """Get all current runtime parameters from the engine."""
    try:
        eng = get_engine()
        params = eng.get_all_params()
        return {"params": {k: round(v, 6) for k, v in params.items()}, "count": len(params)}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Hawkes process tools
# ---------------------------------------------------------------------------

def compute_hawkes_intensity(
    event_times: list[float],
    mu: float = 0.1,
    alpha: float = 0.5,
    beta: float = 1.0,
) -> dict:
    """Compute Hawkes process intensity given event timestamps. Models self-exciting trade arrival."""
    try:
        from horizon._horizon import HawkesProcess
        hp = HawkesProcess(mu=mu, alpha=alpha, beta=beta)
        for t in event_times:
            hp.add_event(t)
        now = event_times[-1] + 1e-6 if event_times else 0.0
        return {
            "intensity": round(hp.intensity(now), 6),
            "branching_ratio": round(hp.branching_ratio(), 6),
            "expected_events_1m": round(hp.expected_events(now, 60.0), 4),
            "event_count": hp.event_count(),
            "mu": mu,
            "alpha": alpha,
            "beta": beta,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Ledoit-Wolf correlation tools
# ---------------------------------------------------------------------------

def compute_correlation_matrix(
    returns: list[list[float]],
) -> dict:
    """Compute Ledoit-Wolf shrinkage covariance matrix. Input: list of observations, each a list of asset returns."""
    try:
        from horizon._horizon import ledoit_wolf_shrinkage
        matrix, shrinkage = ledoit_wolf_shrinkage(returns)
        return {
            "matrix": [[round(v, 8) for v in row] for row in matrix],
            "shrinkage_intensity": round(shrinkage, 6),
            "n_assets": len(matrix),
            "n_observations": len(returns),
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# AFML: Information-driven bars
# ---------------------------------------------------------------------------

def compute_tick_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: int,
) -> list[dict] | dict:
    """Generate tick bars (fixed number of ticks per bar)."""
    try:
        from horizon._horizon import tick_bars
        bars = tick_bars(timestamps, prices, volumes, bar_size)
        return [_bar_to_dict(b) for b in bars]
    except Exception as e:
        return {"error": str(e)}


def compute_volume_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: float,
) -> list[dict] | dict:
    """Generate volume bars (fixed total volume per bar)."""
    try:
        from horizon._horizon import volume_bars
        bars = volume_bars(timestamps, prices, volumes, bar_size)
        return [_bar_to_dict(b) for b in bars]
    except Exception as e:
        return {"error": str(e)}


def compute_dollar_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: float,
) -> list[dict] | dict:
    """Generate dollar bars (fixed total dollar value per bar)."""
    try:
        from horizon._horizon import dollar_bars
        bars = dollar_bars(timestamps, prices, volumes, bar_size)
        return [_bar_to_dict(b) for b in bars]
    except Exception as e:
        return {"error": str(e)}


def _bar_to_dict(b) -> dict:
    return {
        "timestamp": b.timestamp,
        "open": round(b.open, 6),
        "high": round(b.high, 6),
        "low": round(b.low, 6),
        "close": round(b.close, 6),
        "volume": round(b.volume, 4),
        "vwap": round(b.vwap, 6),
        "n_ticks": b.n_ticks,
    }


# ---------------------------------------------------------------------------
# AFML: Triple barrier labeling
# ---------------------------------------------------------------------------

def compute_cusum_filter(prices: list[float], threshold: float) -> list[int] | dict:
    """Run CUSUM filter for structural break detection. Returns event indices."""
    try:
        from horizon._horizon import cusum_filter
        return cusum_filter(prices, threshold)
    except Exception as e:
        return {"error": str(e)}


def compute_triple_barrier(
    prices: list[float],
    timestamps: list[float],
    events: list[int],
    pt_sl: list[float] | None = None,
    min_ret: float = 0.0,
    max_holding: int = 100,
    vol_span: int = 20,
) -> list[dict] | dict:
    """Apply triple barrier labeling to event indices."""
    try:
        from horizon._horizon import triple_barrier_labels
        labels = triple_barrier_labels(
            prices, timestamps, events,
            pt_sl=pt_sl or [1.0, 1.0],
            min_ret=min_ret, max_holding=max_holding, vol_span=vol_span,
        )
        return [
            {
                "event_idx": lb.event_idx,
                "label": lb.label,
                "ret": round(lb.ret, 6),
                "barrier": lb.barrier,
                "touch_idx": lb.touch_idx,
            }
            for lb in labels
        ]
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# AFML: Fractional differentiation
# ---------------------------------------------------------------------------

def compute_frac_diff(
    series: list[float], d: float, threshold: float = 1e-5,
) -> list[float] | dict:
    """Apply Fixed-Width Window fractional differentiation."""
    try:
        from horizon._horizon import frac_diff_ffd
        return [round(v, 8) for v in frac_diff_ffd(series, d, threshold)]
    except Exception as e:
        return {"error": str(e)}


def compute_min_frac_diff(
    series: list[float],
    p_threshold: float = 0.05,
    max_d: float = 1.0,
    n_steps: int = 10,
) -> dict:
    """Find minimum fractional differentiation d for stationarity."""
    try:
        from horizon._horizon import min_frac_diff
        d = min_frac_diff(series, p_threshold, max_d, n_steps)
        return {"d_star": round(d, 4), "p_threshold": p_threshold}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# AFML: HRP & denoising
# ---------------------------------------------------------------------------

def compute_hrp_weights(covariance: list[list[float]]) -> dict:
    """Compute Hierarchical Risk Parity weights from a covariance matrix."""
    try:
        from horizon._horizon import hrp_weights
        result = hrp_weights(covariance)
        return {
            "weights": [round(w, 6) for w in result.weights],
            "sorted_indices": list(result.sorted_indices),
            "n_assets": len(result.weights),
        }
    except Exception as e:
        return {"error": str(e)}


def compute_denoise_covariance(
    covariance: list[list[float]], n_observations: int,
) -> dict:
    """Denoise a covariance matrix using Marcenko-Pastur random matrix theory."""
    try:
        from horizon._horizon import denoise_covariance
        result = denoise_covariance(covariance, n_observations)
        return {
            "covariance": [[round(v, 8) for v in row] for row in result.covariance],
            "eigenvalues": [round(e, 8) for e in result.eigenvalues],
            "n_signals": result.n_signals,
            "n_noise": result.n_noise,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Copy-trading tools
# ---------------------------------------------------------------------------

def start_copy_trades(
    wallet: str,
    size_scale: float = 1.0,
    max_position: float = 1000.0,
    poll_interval: float = 30.0,
    exchange: str = "paper",
    inverse: bool = False,
    dry_run: bool = False,
) -> dict:
    """Start copy-trading a Polymarket wallet.

    Launches the copy-trade loop in a background thread.
    """
    try:
        from horizon.copy_trader import copy_trades
        import threading

        kwargs = {
            "wallet": wallet,
            "size_scale": size_scale,
            "max_position": max_position,
            "poll_interval": poll_interval,
            "exchange": exchange,
            "inverse": inverse,
            "dry_run": dry_run,
        }

        thread = threading.Thread(
            target=copy_trades, kwargs=kwargs, daemon=True,
        )
        thread.start()

        return {
            "started": True,
            "wallet": wallet,
            "size_scale": size_scale,
            "max_position": max_position,
            "poll_interval": poll_interval,
            "exchange": exchange,
            "inverse": inverse,
            "dry_run": dry_run,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Wallet intelligence tools
# ---------------------------------------------------------------------------

def wallet_score(address: str, limit: int = 500) -> dict:
    """Score a wallet's trading performance (win rate, Sharpe, composite score)."""
    try:
        from horizon.wallet_intel import score_wallet
        s = score_wallet(address, limit=limit)
        return {
            "wallet": s.wallet,
            "win_rate": s.win_rate,
            "avg_pnl_pct": s.avg_pnl_pct,
            "sharpe": s.sharpe,
            "total_pnl": s.total_pnl,
            "trade_count": s.trade_count,
            "position_count": s.position_count,
            "composite_score": s.composite_score,
        }
    except Exception as e:
        return {"error": str(e)}


def wallet_analysis(address: str, trade_limit: int = 500) -> dict:
    """Analyze a wallet for exploitable trading patterns."""
    try:
        from horizon.wallet_intel import analyze_wallet
        a = analyze_wallet(address, trade_limit=trade_limit)
        return {
            "wallet": a.wallet,
            "patterns": [
                {
                    "name": p.name,
                    "description": p.description,
                    "value": p.value,
                    "exploitable": p.exploitable,
                    "counter_strategy": p.counter_strategy,
                }
                for p in a.patterns
            ],
            "vulnerability_score": a.vulnerability_score,
            "counter_strategies": a.counter_strategies,
            "trade_count": a.trade_count,
            "analysis_period_hours": a.analysis_period_hours,
        }
    except Exception as e:
        return {"error": str(e)}


def wallet_profiler(address: str, trade_limit: int = 500) -> dict:
    """Generate a deep behavioral profile for a wallet with profit strategies."""
    try:
        from horizon.wallet_profiler import profile_wallet
        p = profile_wallet(address, trade_limit=trade_limit)
        return {
            "wallet": p.wallet,
            "composite_score": p.score.composite_score,
            "win_rate": p.score.win_rate,
            "total_pnl": p.score.total_pnl,
            "data_quality": p.data_quality,
            # Temporal
            "peak_hour": p.temporal.hour_distribution.peak_hour,
            "hour_entropy": round(p.temporal.hour_distribution.entropy, 4),
            "session": p.temporal.session.session,
            "is_bursty": p.temporal.burst.is_bursty,
            "burstiness": p.temporal.burst.burstiness,
            "active_days_pct": p.temporal.active_days_pct,
            "weekend_ratio": p.temporal.day_distribution.weekend_ratio,
            # Market selection
            "best_category": p.market_selection.best_category,
            "worst_category": p.market_selection.worst_category,
            "herfindahl": p.market_selection.herfindahl,
            "diversity_score": p.market_selection.diversity_score,
            "market_count": p.market_selection.market_count,
            "early_entrant_score": p.market_selection.early_entrant_score,
            "categories": [
                {"name": c.name, "trade_count": c.trade_count, "win_rate": c.win_rate}
                for c in p.market_selection.categories
            ],
            # Order flow
            "building_style": p.order_flow.building_style.style,
            "exit_style": p.order_flow.exit_style.style,
            "avg_hold_hours": p.order_flow.avg_hold_hours,
            "size_trend": p.order_flow.size_trend,
            "dip_buyer_score": p.order_flow.dip_buyer_score,
            "rip_seller_score": p.order_flow.rip_seller_score,
            # Edge
            "information_score": p.edge.information_score,
            "timing_quality": p.edge.timing_quality,
            "streak_type": p.edge.streak_type,
            "edge_bps": p.edge.edge_bps,
            "edge_confidence": p.edge.confidence,
            "win_rate_by_size": p.edge.win_rate_by_size,
            # Strategies
            "strategies": [
                {
                    "name": s.name,
                    "description": s.description,
                    "expected_edge": s.expected_edge,
                    "risk_level": s.risk_level,
                    "confidence": s.confidence,
                    "impl_type": s.impl_type,
                }
                for s in p.strategies
            ],
            "best_strategy": p.best_strategy.name if p.best_strategy else None,
            "best_strategy_confidence": p.best_strategy.confidence if p.best_strategy else None,
        }
    except Exception as e:
        return {"error": str(e)}


def market_bot_scan(
    condition_id: str,
    trade_limit: int = 1000,
    min_trades: int = 5,
) -> list[dict] | dict:
    """Scan a market to detect bot wallets with strategy classification."""
    try:
        from horizon.wallet_intel import scan_bots
        results = scan_bots(
            condition_id, trade_limit=trade_limit, min_trades=min_trades,
        )
        return [
            {
                "wallet": r.wallet,
                "is_bot": r.is_bot,
                "confidence": r.confidence,
                "strategy_type": r.strategy_type,
                "evidence": r.evidence,
                "trade_count": r.trade_count,
                "avg_interval_seconds": r.avg_interval_seconds,
                "size_regularity": r.size_regularity,
            }
            for r in results
        ]
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Stealth execution tools (Ultra)
# ---------------------------------------------------------------------------

def stealth_estimate_impact(
    market_id: str, size: float, feed_name: str | None = None,
) -> dict:
    """Estimate market impact before execution."""
    try:
        from horizon.stealth import estimate_impact
        eng = get_engine()
        est = estimate_impact(eng, market_id, size, feed_name=feed_name)
        return {
            "market_id": est.market_id,
            "size": est.size,
            "estimated_slippage_bps": est.estimated_slippage_bps,
            "kyle_lambda": est.kyle_lambda,
            "effective_spread_bps": est.effective_spread_bps,
            "volatility": est.volatility,
            "recommended_strategy": est.recommended_strategy,
            "estimated_duration_secs": est.estimated_duration_secs,
        }
    except Exception as e:
        return {"error": str(e)}


def stealth_execute_order(
    market_id: str,
    side: str,
    order_side: str,
    size: float,
    price: float,
    strategy: str = "auto",
) -> dict:
    """Execute an order using stealth algorithms (TWAP, Iceberg, Sniper)."""
    try:
        from horizon.stealth import stealth_execute
        eng = get_engine()
        s = Side.Yes if side.lower() == "yes" else Side.No
        os_ = OrderSide.Buy if order_side.lower() == "buy" else OrderSide.Sell
        plan = stealth_execute(eng, market_id, s, os_, size, price, strategy=strategy)
        return {
            "strategy": plan.strategy,
            "total_size": plan.total_size,
            "estimated_cost_bps": plan.estimated_cost_bps,
            "estimated_duration_secs": plan.estimated_duration_secs,
            "child_orders": len(plan.child_orders),
            "routes": [
                {
                    "exchange": r.exchange,
                    "size_fraction": r.size_fraction,
                    "estimated_cost_bps": r.estimated_cost_bps,
                }
                for r in plan.routes
            ],
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Sentinel risk monitoring tools (Ultra)
# ---------------------------------------------------------------------------

def get_sentinel_report() -> dict:
    """Get a comprehensive portfolio risk report."""
    try:
        from horizon.sentinel import sentinel_report
        eng = get_engine()
        r = sentinel_report(eng)
        return {
            "regime": r.regime,
            "portfolio_value": round(r.portfolio_value, 2),
            "var_95": round(r.var_95, 4),
            "cvar_95": round(r.cvar_95, 4),
            "max_position_pct": round(r.max_position_pct, 4),
            "correlation_alerts": len(r.correlation_alerts),
            "drawdown_levels": [
                {
                    "scope": d.scope,
                    "scope_id": d.scope_id,
                    "current_dd": round(d.current_dd, 4),
                    "threshold": d.threshold,
                    "action": d.action,
                    "triggered": d.triggered,
                }
                for d in r.drawdown_levels
            ],
            "hedges": [
                {
                    "market_id": h.market_id,
                    "side": h.side,
                    "size": round(h.size, 4),
                    "risk_reduction_pct": round(h.risk_reduction_pct, 2),
                    "rationale": h.rationale,
                }
                for h in r.hedges
            ],
            "risk_budget": {
                "total": round(r.risk_budget.total_budget, 2),
                "used": round(r.risk_budget.used_budget, 2),
                "usage_pct": round(r.risk_budget.usage_pct, 4),
                "regime_multiplier": r.risk_budget.regime_multiplier,
            },
            "timestamp": r.timestamp,
        }
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Oracle forecasting tools (Ultra)
# ---------------------------------------------------------------------------

def oracle_forecast_market(
    market_id: str,
    market_title: str = "",
    market_price: float = 0.0,
) -> dict:
    """Forecast a market's probability using ensemble signals."""
    try:
        from horizon.oracle import forecast_market
        fc = forecast_market(market_id, market_title=market_title, market_price=market_price)
        return {
            "market_id": fc.market_id,
            "ensemble_prob": round(fc.ensemble_prob, 4),
            "confidence_low": round(fc.confidence_low, 4),
            "confidence_high": round(fc.confidence_high, 4),
            "edge_bps": round(fc.edge_bps, 2),
            "market_price": fc.market_price,
            "signals": [
                {
                    "name": s.name,
                    "value": round(s.normalized_value, 4),
                    "weight": round(s.weight, 4),
                    "contribution": round(s.contribution, 4),
                }
                for s in fc.signals
            ],
            "timestamp": fc.timestamp,
        }
    except Exception as e:
        return {"error": str(e)}


def oracle_scan_edges(
    min_edge_bps: float = 200.0,
    max_markets: int = 30,
) -> list[dict] | dict:
    """Scan top markets for forecast edge opportunities."""
    try:
        from horizon.oracle import scan_edges
        edges = scan_edges(min_edge_bps=min_edge_bps, max_markets=max_markets)
        return [
            {
                "market_id": e.market_id,
                "market_title": e.market_title,
                "forecast_prob": round(e.forecast_prob, 4),
                "market_price": round(e.market_price, 4),
                "edge_bps": round(e.edge_bps, 2),
                "confidence": round(e.confidence, 4),
                "direction": e.direction,
                "recommended_size": round(e.recommended_size, 2),
            }
            for e in edges
        ]
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Whale galaxy tools (Ultra)
# ---------------------------------------------------------------------------

def whale_galaxy_scan(
    top_n: int = 20,
    max_markets: int = 50,
) -> dict:
    """Scan Polymarket for top/bottom wallets, clusters, and whale alerts."""
    try:
        from horizon.whale_galaxy import scan_galaxy
        snap = scan_galaxy(top_n=top_n, max_markets=max_markets)
        return {
            "scan_time": round(snap.scan_time, 2),
            "market_count": snap.market_count,
            "wallet_count": snap.wallet_count,
            "top_wallets": [
                {
                    "address": w.address,
                    "score": round(w.score, 4),
                    "win_rate": round(w.win_rate, 4),
                    "pnl": round(w.pnl, 2),
                    "edge_category": w.edge_category,
                    "trade_count": w.trade_count,
                }
                for w in snap.top_wallets
            ],
            "bottom_wallets": [
                {
                    "address": w.address,
                    "score": round(w.score, 4),
                    "edge_category": w.edge_category,
                }
                for w in snap.bottom_wallets
            ],
            "clusters": [
                {
                    "wallets": c.wallets,
                    "co_trade_count": c.co_trade_count,
                    "cluster_type": c.cluster_type,
                }
                for c in snap.clusters
            ],
            "alerts": [
                {
                    "wallet": a.wallet,
                    "pseudonym": a.pseudonym,
                    "market_id": a.market_id,
                    "action": a.action,
                    "size_usdc": round(a.size_usdc, 2),
                    "significance": round(a.significance, 4),
                }
                for a in snap.alerts
            ],
        }
    except Exception as e:
        return {"error": str(e)}
