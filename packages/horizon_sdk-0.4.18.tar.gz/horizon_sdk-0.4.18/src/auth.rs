//! API key validation with disk caching and HMAC-signed license cache.
//!
//! Validates once at engine startup, caches the result to disk,
//! and never touches the hot path again. The cache is HMAC-signed
//! by the server to prevent tampering.

use crate::error::HorizonError;
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::path::PathBuf;
use std::sync::OnceLock;
use tracing::{debug, warn};

type HmacSha256 = Hmac<Sha256>;

static CURRENT_TIER: OnceLock<String> = OnceLock::new();

/// Supabase RPC endpoint for key validation.
const SUPABASE_RPC_URL: &str =
    "https://pjhydvnnptabkiiluoji.supabase.co/rest/v1/rpc/validate_sdk_key";

/// Supabase anon key (public by design — RLS is the security layer).
const SUPABASE_ANON_KEY: &str =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqaHlkdm5ucHRhYmtpaWx1b2ppIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3NTMwMDQsImV4cCI6MjA4NjMyOTAwNH0.vwa7fwDIwDX9rJkWDq9K_mgWyCMsGqnKE3OMNOR8KOM";

/// Cache validity period: 72 hours.
const CACHE_TTL_SECS: f64 = 72.0 * 3600.0;

// ---------------------------------------------------------------------------
// HMAC signing secret — split across parts to resist casual string extraction.
// The server uses the same secret to sign; the client verifies.
// ---------------------------------------------------------------------------
const _SK_A: &str = "9a4a9913f8a929cd";
const _SK_B: &str = "19c836839c30b6c5";
const _SK_C: &str = "b70f7af02df627e5";
const _SK_D: &str = "5544fd3f86e9d691";

fn signing_key() -> Vec<u8> {
    let combined = format!("{}{}{}{}", _SK_A, _SK_B, _SK_C, _SK_D);
    hex::decode(combined).expect("invalid embedded signing key")
}

/// Compute HMAC-SHA256 over the license payload: "key_hash|tier|expires_at".
fn compute_sig(key_hash: &str, tier: &str, expires_at: f64) -> String {
    let payload = format!("{}|{}|{}", key_hash, tier, expires_at as u64);
    let mut mac =
        HmacSha256::new_from_slice(&signing_key()).expect("HMAC can take any size key");
    mac.update(payload.as_bytes());
    hex::encode(mac.finalize().into_bytes())
}

/// Verify an HMAC signature on a license cache entry.
fn verify_sig(key_hash: &str, tier: &str, expires_at: f64, sig: &str) -> bool {
    let expected = compute_sig(key_hash, tier, expires_at);
    // Constant-time comparison via HMAC verify internals
    let payload = format!("{}|{}|{}", key_hash, tier, expires_at as u64);
    let mut mac =
        HmacSha256::new_from_slice(&signing_key()).expect("HMAC can take any size key");
    mac.update(payload.as_bytes());
    let sig_bytes = match hex::decode(sig) {
        Ok(b) => b,
        Err(_) => return false,
    };
    mac.verify_slice(&sig_bytes).is_ok()
}

/// On-disk license cache. Raw key is never stored — only the SHA-256 hash.
/// The `sig` field is an HMAC-SHA256 signature over "key_hash|tier|expires_at"
/// computed by the server, preventing local tampering.
#[derive(Debug, Serialize, Deserialize)]
struct LicenseCache {
    key_hash: String,
    validated_at: f64,
    expires_at: f64,
    tier: String,
    /// HMAC-SHA256 signature from the server. Missing = legacy/unsigned cache.
    #[serde(default)]
    sig: String,
}

/// Set the current tier. Called once at Engine init.
pub fn set_tier(tier: String) {
    let _ = CURRENT_TIER.set(tier);
}

/// Get the current validated tier. Auto-initializes from env/cache if not yet set.
pub fn current_tier() -> &'static str {
    if CURRENT_TIER.get().is_none() {
        ensure_tier_initialized();
    }
    CURRENT_TIER.get().map(|s| s.as_str()).unwrap_or("free")
}

/// Bootstrap the tier from HORIZON_API_KEY env var or disk cache.
/// Called lazily when require_pro/require_ultra is invoked before Engine::new().
fn ensure_tier_initialized() {
    // Already set by Engine::new() — nothing to do
    if CURRENT_TIER.get().is_some() {
        return;
    }

    // Try env var first
    if let Ok(key) = std::env::var("HORIZON_API_KEY") {
        if !key.is_empty() {
            match validate_api_key(&key) {
                Ok(_) => return,
                Err(e) => {
                    debug!("auto-init from env failed: {}", e);
                }
            }
        }
    }

    // Fall back to valid, signed disk cache
    if let Some(cache) = read_cache() {
        if cache.expires_at > now_f64() {
            if !cache.sig.is_empty()
                && verify_sig(&cache.key_hash, &cache.tier, cache.expires_at, &cache.sig)
            {
                set_tier(cache.tier);
                return;
            }
            debug!("cache signature invalid or missing, ignoring cached tier");
        }
    }

    // No key and no valid cache — tier stays unset (will default to "free")
}

/// Tier numeric level: free=0, pro=1, ultra=2.
fn tier_level(tier: &str) -> u8 {
    match tier {
        "ultra" => 2,
        "pro" => 1,
        _ => 0,
    }
}

/// Require at least Pro tier. Returns error for Free tier.
/// Always succeeds when the `skip-auth` feature is enabled (test/dev builds).
pub fn require_pro() -> Result<(), HorizonError> {
    #[cfg(feature = "skip-auth")]
    return Ok(());

    #[cfg(not(feature = "skip-auth"))]
    {
        if tier_level(current_tier()) >= 1 {
            Ok(())
        } else {
            Err(HorizonError::Auth(
                "This feature requires a Pro or Ultra plan. Upgrade at horizon.mathematicalcompany.com".to_string()
            ))
        }
    }
}

/// Require Ultra tier. Returns error for Free and Pro tiers.
/// Always succeeds when the `skip-auth` feature is enabled (test/dev builds).
pub fn require_ultra() -> Result<(), HorizonError> {
    #[cfg(feature = "skip-auth")]
    return Ok(());

    #[cfg(not(feature = "skip-auth"))]
    {
        if tier_level(current_tier()) >= 2 {
            Ok(())
        } else {
            Err(HorizonError::Auth(
                "This feature requires an Ultra plan. Upgrade at horizon.mathematicalcompany.com".to_string()
            ))
        }
    }
}

/// Validate an API key. Called once at `Engine::new()`.
///
/// Resolution order:
/// 1. `skip-auth` feature → always Ok (test builds).
/// 2. Tier already set → return current tier (no re-validation).
/// 3. Empty key → error with signup URL.
/// 4. Disk cache hit (hash matches + not expired + valid signature) → Ok.
/// 5. Remote validation via Supabase PostgREST (sdk_keys table).
/// 6. On network failure: signed stale cache for same hash → Ok (grace period).
pub fn validate_api_key(key: &str) -> Result<String, HorizonError> {
    #[cfg(feature = "skip-auth")]
    {
        set_tier("ultra".to_string());
        return Ok("ultra".to_string());
    }

    #[cfg(not(feature = "skip-auth"))]
    {
        // If tier is already validated (e.g. by a previous Engine or cache auto-init),
        // skip re-validation — just return the current tier.
        if let Some(tier) = CURRENT_TIER.get() {
            return Ok(tier.clone());
        }

        if key.is_empty() {
            return Err(HorizonError::Auth(
                "No Horizon API key provided. Set HORIZON_API_KEY or pass \
                 api_key to hz.run(). Get your key at horizon.mathematicalcompany.com"
                    .to_string(),
            ));
        }

        let hash = sha256_hex(key);

        // Check disk cache — require valid HMAC signature
        if let Some(cache) = read_cache() {
            if cache.key_hash == hash && cache.expires_at > now_f64() {
                if !cache.sig.is_empty()
                    && verify_sig(&cache.key_hash, &cache.tier, cache.expires_at, &cache.sig)
                {
                    set_tier(cache.tier.clone());
                    debug!(tier = %cache.tier, "API key validated (signed cache hit)");
                    return Ok(cache.tier);
                }
                debug!("cache signature invalid, falling through to remote validation");
            }
        }

        // Remote validation
        match validate_remote(key) {
            Ok(result) => {
                let now = now_f64();
                // Use server-provided expiry if available, otherwise compute locally
                let expires = if result.expires_at > now {
                    result.expires_at
                } else {
                    now + CACHE_TTL_SECS
                };
                // Use server sig if provided, otherwise compute locally
                let final_sig = if result.sig.is_empty() {
                    compute_sig(&hash, &result.tier, expires)
                } else {
                    result.sig
                };
                let cache = LicenseCache {
                    key_hash: hash,
                    validated_at: now,
                    expires_at: expires,
                    tier: result.tier.clone(),
                    sig: final_sig,
                };
                write_cache(&cache);
                set_tier(result.tier.clone());
                debug!("API key validated (remote), tier={}", result.tier);
                Ok(result.tier)
            }
            Err(HorizonError::Auth(msg)) => Err(HorizonError::Auth(msg)),
            Err(_) => {
                // Network failure — allow if signed stale cache exists for same hash
                if let Some(cache) = read_cache() {
                    if cache.key_hash == hash
                        && !cache.sig.is_empty()
                        && verify_sig(
                            &cache.key_hash,
                            &cache.tier,
                            cache.expires_at,
                            &cache.sig,
                        )
                    {
                        set_tier(cache.tier.clone());
                        warn!("Remote validation failed, using signed stale cache (grace period)");
                        return Ok(cache.tier);
                    }
                }
                Err(HorizonError::Auth(
                    "Could not validate API key (network error) and no cached \
                     validation found. Check your internet connection."
                        .to_string(),
                ))
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn sha256_hex(input: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(input.as_bytes());
    hex::encode(hasher.finalize())
}

fn now_f64() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

fn cache_path() -> Option<PathBuf> {
    dirs_next().map(|home| home.join(".horizon").join("license.json"))
}

/// Minimal home-dir resolution (avoids adding a dependency).
fn dirs_next() -> Option<PathBuf> {
    std::env::var_os("HOME")
        .or_else(|| std::env::var_os("USERPROFILE"))
        .map(PathBuf::from)
}

fn read_cache() -> Option<LicenseCache> {
    let path = cache_path()?;
    let data = std::fs::read_to_string(&path).ok()?;
    serde_json::from_str(&data).ok()
}

fn write_cache(cache: &LicenseCache) {
    if let Some(path) = cache_path() {
        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
            // Set directory permissions to 0o700 (owner only) on Unix
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                let _ = std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700));
            }
        }
        match serde_json::to_string_pretty(cache) {
            Ok(json) => {
                if let Err(e) = std::fs::write(&path, &json) {
                    warn!(error = %e, "failed to write license cache");
                } else {
                    // Set file permissions to 0o600 (owner read/write only) on Unix
                    #[cfg(unix)]
                    {
                        use std::os::unix::fs::PermissionsExt;
                        let _ = std::fs::set_permissions(
                            &path,
                            std::fs::Permissions::from_mode(0o600),
                        );
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "failed to serialize license cache");
            }
        }
    }
}

/// Remote validation result.
struct RemoteResult {
    tier: String,
    sig: String,
    /// Server-provided expiry (unix timestamp). 0 = not provided.
    expires_at: f64,
}

/// Call Supabase RPC function to validate a key hash.
/// Returns tier, sig, and optionally expires_at from the server.
/// Uses a one-shot current_thread tokio runtime (the engine's
/// multi-thread runtime doesn't exist yet).
fn validate_remote(key: &str) -> Result<RemoteResult, HorizonError> {
    let hash = sha256_hex(key);

    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| HorizonError::Internal(format!("failed to create auth runtime: {e}")))?;

    rt.block_on(async move {
        let client = reqwest::Client::builder()
            .connect_timeout(std::time::Duration::from_secs(5))
            .timeout(std::time::Duration::from_secs(10))
            .build()
            .map_err(|e| HorizonError::Internal(format!("http client error: {e}")))?;

        let resp = client
            .post(SUPABASE_RPC_URL)
            .header("apikey", SUPABASE_ANON_KEY)
            .header("Authorization", format!("Bearer {}", SUPABASE_ANON_KEY))
            .json(&serde_json::json!({ "p_key_hash": hash }))
            .send()
            .await
            .map_err(|e| {
                HorizonError::Internal(format!("validation request failed: {e}"))
            })?;

        let status = resp.status();
        if !status.is_success() {
            return Err(HorizonError::Internal(format!(
                "validation server returned {status}"
            )));
        }

        #[derive(Deserialize)]
        struct RpcResponse {
            valid: bool,
            tier: Option<String>,
            #[serde(default)]
            sig: Option<String>,
            #[serde(default)]
            expires_at: Option<f64>,
            #[allow(dead_code)]
            reason: Option<String>,
        }

        let body: RpcResponse = resp.json().await.map_err(|e| {
            HorizonError::Internal(format!("invalid validation response: {e}"))
        })?;

        if !body.valid {
            return Err(HorizonError::Auth(
                "Invalid or expired API key. Check your key at horizon.mathematicalcompany.com"
                    .to_string(),
            ));
        }

        Ok(RemoteResult {
            tier: body.tier.unwrap_or_else(|| "free".to_string()),
            sig: body.sig.unwrap_or_default(),
            expires_at: body.expires_at.unwrap_or(0.0),
        })
    })
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sha256_hex() {
        let hash = sha256_hex("hello");
        assert_eq!(hash.len(), 64);
        assert!(hash.chars().all(|c| c.is_ascii_hexdigit()));
        // Known SHA-256 of "hello"
        assert_eq!(
            hash,
            "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
        );
    }

    #[test]
    fn test_empty_key_rejected() {
        let result = validate_api_key("");
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("No Horizon API key"));
        assert!(err.contains("horizon.mathematicalcompany.com"));
    }

    #[test]
    fn test_cache_roundtrip() {
        let cache = LicenseCache {
            key_hash: sha256_hex("test_key_123"),
            validated_at: 1700000000.0,
            expires_at: 1700259200.0,
            tier: "free".to_string(),
            sig: String::new(),
        };
        let json = serde_json::to_string(&cache).unwrap();
        let parsed: LicenseCache = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.key_hash, cache.key_hash);
        assert_eq!(parsed.tier, "free");
        assert!((parsed.expires_at - cache.expires_at).abs() < f64::EPSILON);
    }

    #[test]
    fn test_hmac_signature_roundtrip() {
        let key_hash = sha256_hex("test_key");
        let tier = "ultra";
        let expires_at = 1700259200.0;

        let sig = compute_sig(&key_hash, tier, expires_at);
        assert!(!sig.is_empty());
        assert!(verify_sig(&key_hash, tier, expires_at, &sig));
    }

    #[test]
    fn test_hmac_rejects_tampered_tier() {
        let key_hash = sha256_hex("test_key");
        let expires_at = 1700259200.0;

        // Sign as "free"
        let sig = compute_sig(&key_hash, "free", expires_at);

        // Tampering: verify with "ultra" should fail
        assert!(!verify_sig(&key_hash, "ultra", expires_at, &sig));
    }

    #[test]
    fn test_hmac_rejects_tampered_expiry() {
        let key_hash = sha256_hex("test_key");
        let tier = "pro";
        let expires_at = 1700259200.0;

        let sig = compute_sig(&key_hash, tier, expires_at);

        // Tampering: extend expiry
        assert!(!verify_sig(&key_hash, tier, 9999999999.0, &sig));
    }

    #[test]
    fn test_hmac_rejects_forged_sig() {
        let key_hash = sha256_hex("test_key");
        assert!(!verify_sig(&key_hash, "ultra", 9999999999.0, "deadbeef"));
    }

    #[test]
    fn test_legacy_cache_without_sig_rejected() {
        // Old caches without sig field should not be trusted for tier
        let key_hash = sha256_hex("test_key");
        assert!(!verify_sig(&key_hash, "ultra", 9999999999.0, ""));
    }
}
