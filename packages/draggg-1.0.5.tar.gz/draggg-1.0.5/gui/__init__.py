"""
GUI package for draggg setup and configuration.
"""

__version__ = "1.0.5"

