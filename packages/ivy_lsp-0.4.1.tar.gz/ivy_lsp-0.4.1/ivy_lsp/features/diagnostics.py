"""Diagnostics feature for Ivy LSP."""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any, Dict, List, Optional

from lsprotocol import types as lsp

logger = logging.getLogger(__name__)

DEBOUNCE_DELAY = 0.5  # seconds


def _convert_error_to_diagnostic(error: Any, source: str) -> lsp.Diagnostic:
    """Convert a single Ivy parse error to an LSP Diagnostic."""
    line = 0
    message = str(error)

    if hasattr(error, "lineno"):
        lineno = error.lineno
        if hasattr(lineno, "line") and isinstance(lineno.line, int) and lineno.line > 0:
            line = lineno.line - 1

    if hasattr(error, "msg"):
        message = error.msg

    lines = source.split("\n")
    line_len = len(lines[line]) if line < len(lines) else 0

    return lsp.Diagnostic(
        range=lsp.Range(
            start=lsp.Position(line=line, character=0),
            end=lsp.Position(line=line, character=line_len),
        ),
        message=message,
        severity=lsp.DiagnosticSeverity.Error,
        source="ivy",
    )


def check_structural_issues(
    source: str,
    filepath: str,
    indexer: Any = None,
) -> List[lsp.Diagnostic]:
    """Check for structural problems without full parsing."""
    diags: List[lsp.Diagnostic] = []
    lines = source.split("\n")

    # 1. Missing #lang header
    stripped = source.lstrip()
    if not stripped.startswith("#lang"):
        first_len = len(lines[0]) if lines else 0
        diags.append(
            lsp.Diagnostic(
                range=lsp.Range(
                    start=lsp.Position(0, 0),
                    end=lsp.Position(0, first_len),
                ),
                message="Missing '#lang ivy1.7' header",
                severity=lsp.DiagnosticSeverity.Warning,
                source="ivy-lsp",
            )
        )

    # 2. Unmatched braces
    depth = 0
    for i, line_text in enumerate(lines):
        # Skip comments but preserve #lang lines
        if line_text.strip().startswith("#lang"):
            code = line_text
        else:
            code = line_text.split("#")[0]
        for ch in code:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
            if depth < 0:
                diags.append(
                    lsp.Diagnostic(
                        range=lsp.Range(
                            start=lsp.Position(i, 0),
                            end=lsp.Position(i, len(line_text)),
                        ),
                        message="Unmatched closing brace",
                        severity=lsp.DiagnosticSeverity.Error,
                        source="ivy-lsp",
                    )
                )
                depth = 0
    if depth > 0:
        last = len(lines) - 1
        last_len = len(lines[last]) if lines else 0
        diags.append(
            lsp.Diagnostic(
                range=lsp.Range(
                    start=lsp.Position(last, 0),
                    end=lsp.Position(last, last_len),
                ),
                message=f"Unmatched opening brace ({depth} unclosed)",
                severity=lsp.DiagnosticSeverity.Error,
                source="ivy-lsp",
            )
        )

    # 3. Unresolved includes
    if indexer:
        for match in re.finditer(r"^include\s+(\w+)", source, re.MULTILINE):
            inc_name = match.group(1)
            resolved = indexer._resolver.resolve(inc_name, filepath)
            if resolved is None:
                line_no = source[: match.start()].count("\n")
                line_text = lines[line_no] if line_no < len(lines) else ""
                diags.append(
                    lsp.Diagnostic(
                        range=lsp.Range(
                            start=lsp.Position(line_no, 0),
                            end=lsp.Position(line_no, len(line_text)),
                        ),
                        message=f"Unresolved include: {inc_name}",
                        severity=lsp.DiagnosticSeverity.Warning,
                        source="ivy-lsp",
                    )
                )

    return diags


def compute_requirement_diagnostics(
    source: str,
    filepath: str,
    indexer: Any = None,
) -> List[lsp.Diagnostic]:
    """Compute requirement-analysis diagnostics for a source file.

    Emits diagnostics for:
    1. Include chain propagation (Info)
    2. Unmonitored actions (Hint)
    3. High-impact state variables (Info)
    """
    if indexer is None:
        return []

    graph = getattr(indexer, "_requirement_graph", None)
    include_graph = getattr(indexer, "_include_graph", None)
    if graph is None:
        return []

    import os

    diags: List[lsp.Diagnostic] = []
    abs_path = os.path.abspath(filepath)
    lines = source.split("\n")

    # 1. Include chain propagation
    if include_graph:
        for match in re.finditer(r"^include\s+(\w+)", source, re.MULTILINE):
            inc_name = match.group(1)
            line_no = source[: match.start()].count("\n")
            line_text = lines[line_no] if line_no < len(lines) else ""

            # Count requirements brought in via this include chain
            active = graph.get_active_requirements_for_file(
                abs_path, include_graph
            )
            own = graph.get_all_requirements_in_file(abs_path)
            inherited = len(active) - len(own)

            if inherited > 0:
                related = []
                for req in active:
                    if req.file != abs_path:
                        related.append(
                            lsp.DiagnosticRelatedInformation(
                                location=lsp.Location(
                                    uri=f"file://{req.file}",
                                    range=lsp.Range(
                                        start=lsp.Position(req.line, 0),
                                        end=lsp.Position(req.line, 80),
                                    ),
                                ),
                                message=f"{req.kind}: {req.formula_text[:60]}",
                            )
                        )

                diags.append(
                    lsp.Diagnostic(
                        range=lsp.Range(
                            start=lsp.Position(line_no, 0),
                            end=lsp.Position(line_no, len(line_text)),
                        ),
                        message=(
                            f"Brings {inherited} requirements into scope "
                            f"from {inc_name} (and transitive includes)"
                        ),
                        severity=lsp.DiagnosticSeverity.Information,
                        source="ivy-lsp-reqs",
                        related_information=related[:10],
                    )
                )

    # 2. Unmonitored actions (Hint)
    for match in re.finditer(
        r"^\s*action\s+([\w.]+)", source, re.MULTILINE
    ):
        action_name = match.group(1)
        line_no = source[: match.start()].count("\n")
        line_text = lines[line_no] if line_no < len(lines) else ""

        reqs = graph.get_requirements_for_action(action_name)
        if not reqs:
            diags.append(
                lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(line_no, 0),
                        end=lsp.Position(line_no, len(line_text)),
                    ),
                    message=f"Action '{action_name}' has no before/after monitors in scope",
                    severity=lsp.DiagnosticSeverity.Hint,
                    source="ivy-lsp-reqs",
                )
            )

    # 3. High-impact state variables (Info, threshold: 5+ readers)
    impact_threshold = 5
    for match in re.finditer(
        r"^\s*relation\s+([\w.]+)", source, re.MULTILINE
    ):
        var_name = match.group(1)
        line_no = source[: match.start()].count("\n")
        line_text = lines[line_no] if line_no < len(lines) else ""

        readers = graph.get_requirements_sharing_state_var(var_name)
        if len(readers) >= impact_threshold:
            files = {r.file for r in readers}
            diags.append(
                lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(line_no, 0),
                        end=lsp.Position(line_no, len(line_text)),
                    ),
                    message=(
                        f"High-impact state variable: read by "
                        f"{len(readers)} requirements across {len(files)} files"
                    ),
                    severity=lsp.DiagnosticSeverity.Information,
                    source="ivy-lsp-reqs",
                )
            )

    return diags


def compute_diagnostics(
    parser: Any,
    source: str,
    filepath: str,
    indexer: Any = None,
) -> List[lsp.Diagnostic]:
    """Compute all diagnostics for a source file."""
    diags = check_structural_issues(source, filepath, indexer)

    if parser is None:
        return diags

    result = parser.parse(source, filepath)
    if not result.success:
        for error in result.errors:
            diags.append(_convert_error_to_diagnostic(error, source))

        # Surface fallback scanner lexer errors as diagnostics.
        from ivy_lsp.parsing.fallback_scanner import fallback_scan

        _symbols, error_info = fallback_scan(source, filepath)
        if error_info is not None:
            err_line = max(0, error_info.get("line", 1) - 1)
            err_msg = error_info.get("message", "Lexer error")
            lines = source.split("\n")
            line_len = len(lines[err_line]) if err_line < len(lines) else 0
            diags.append(
                lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(line=err_line, character=0),
                        end=lsp.Position(line=err_line, character=line_len),
                    ),
                    message=f"Lexer error: {err_msg}",
                    severity=lsp.DiagnosticSeverity.Error,
                    source="ivy-lsp",
                )
            )

    # Requirement analysis diagnostics
    req_diags = compute_requirement_diagnostics(source, filepath, indexer)
    diags.extend(req_diags)

    return diags


async def run_deep_diagnostics(
    filepath: str,
    ivy_check_cmd: str = "ivy_check",
) -> List[lsp.Diagnostic]:
    """Run ivy_check as subprocess and convert output to diagnostics."""
    try:
        proc = await asyncio.create_subprocess_exec(
            ivy_check_cmd,
            filepath,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
    except FileNotFoundError:
        logger.debug("%s not found on PATH", ivy_check_cmd)
        return []
    except asyncio.TimeoutError:
        logger.warning("Deep diagnostics timed out for %s", filepath)
        return []
    except Exception:
        logger.warning("Deep diagnostics failed for %s", filepath, exc_info=True)
        return []

    diags: List[lsp.Diagnostic] = []
    output = stderr.decode("utf-8", errors="replace") + stdout.decode(
        "utf-8", errors="replace"
    )
    for line in output.splitlines():
        m = re.match(r".*?:(\d+):\s*(error|warning):\s*(.*)", line)
        if m:
            lineno = max(0, int(m.group(1)) - 1)
            severity = (
                lsp.DiagnosticSeverity.Error
                if m.group(2) == "error"
                else lsp.DiagnosticSeverity.Warning
            )
            diags.append(
                lsp.Diagnostic(
                    range=lsp.Range(
                        start=lsp.Position(lineno, 0),
                        end=lsp.Position(lineno, 999),
                    ),
                    message=m.group(3),
                    severity=severity,
                    source="ivy_check",
                )
            )
    return diags


def register(server) -> None:
    """Register diagnostic handlers for didOpen, didChange, didSave."""
    _debounce_tasks: Dict[str, asyncio.Task] = {}

    @server.feature(lsp.TEXT_DOCUMENT_DID_OPEN)
    def did_open(params: lsp.DidOpenTextDocumentParams) -> None:
        uri = params.text_document.uri
        doc = server.workspace.get_text_document(uri)
        filepath = uri.replace("file://", "")
        diags = compute_diagnostics(
            server._parser, doc.source or "", filepath, server._indexer
        )
        server.text_document_publish_diagnostics(
            lsp.PublishDiagnosticsParams(uri=uri, diagnostics=diags)
        )

    @server.feature(lsp.TEXT_DOCUMENT_DID_CHANGE)
    def did_change(params: lsp.DidChangeTextDocumentParams) -> None:
        uri = params.text_document.uri
        old_task = _debounce_tasks.pop(uri, None)
        if old_task and not old_task.done():
            old_task.cancel()

        async def _debounced():
            await asyncio.sleep(DEBOUNCE_DELAY)
            doc = server.workspace.get_text_document(uri)
            filepath = uri.replace("file://", "")
            diags = compute_diagnostics(
                server._parser, doc.source or "", filepath, server._indexer
            )
            server.text_document_publish_diagnostics(
                lsp.PublishDiagnosticsParams(uri=uri, diagnostics=diags)
            )

        loop = asyncio.get_event_loop()
        _debounce_tasks[uri] = loop.create_task(_debounced())

    @server.feature(lsp.TEXT_DOCUMENT_DID_SAVE)
    def did_save(params: lsp.DidSaveTextDocumentParams) -> None:
        uri = params.text_document.uri
        filepath = uri.replace("file://", "")
        doc = server.workspace.get_text_document(uri)
        diags = compute_diagnostics(
            server._parser, doc.source or "", filepath, server._indexer
        )
        server.text_document_publish_diagnostics(
            lsp.PublishDiagnosticsParams(uri=uri, diagnostics=diags)
        )

        async def _deep():
            deep = await run_deep_diagnostics(filepath)
            server.text_document_publish_diagnostics(
                lsp.PublishDiagnosticsParams(uri=uri, diagnostics=diags + deep)
            )

        loop = asyncio.get_event_loop()
        loop.create_task(_deep())
