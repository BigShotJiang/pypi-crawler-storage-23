:mod:`b2sdk._internal.scan.folder`
==================================

.. automodule:: b2sdk._internal.scan.folder
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
