:mod:`b2sdk._internal.scan.policies`
====================================

.. automodule:: b2sdk._internal.scan.policies
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
