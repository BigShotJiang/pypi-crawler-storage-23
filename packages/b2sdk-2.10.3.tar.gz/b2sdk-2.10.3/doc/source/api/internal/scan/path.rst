:mod:`b2sdk._internal.scan.path`
================================

.. automodule:: b2sdk._internal.scan.path
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
