:mod:`b2sdk._internal.scan.folder_parser`
=========================================

.. automodule:: b2sdk._internal.scan.folder_parser
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
