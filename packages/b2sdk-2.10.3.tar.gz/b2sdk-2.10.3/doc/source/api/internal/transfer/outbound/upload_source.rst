:mod:`b2sdk._internal.transfer.outbound.upload_source`
======================================================

.. automodule:: b2sdk._internal.transfer.outbound.upload_source
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
