:mod:`b2sdk._internal.transfer.inbound.downloader.simple` -- SimpleDownloader
=============================================================================

.. automodule:: b2sdk._internal.transfer.inbound.downloader.simple
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
