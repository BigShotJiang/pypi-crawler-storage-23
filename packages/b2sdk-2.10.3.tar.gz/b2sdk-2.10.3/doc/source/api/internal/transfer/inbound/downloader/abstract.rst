:mod:`b2sdk._internal.transfer.inbound.downloader.abstract` -- Downloader base class
====================================================================================

.. automodule:: b2sdk._internal.transfer.inbound.downloader.abstract
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
