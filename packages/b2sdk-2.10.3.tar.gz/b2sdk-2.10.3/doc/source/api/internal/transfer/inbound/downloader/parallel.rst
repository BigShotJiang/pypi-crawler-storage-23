:mod:`b2sdk._internal.transfer.inbound.downloader.parallel` -- ParallelTransferer
=================================================================================

.. automodule:: b2sdk._internal.transfer.inbound.downloader.parallel
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
