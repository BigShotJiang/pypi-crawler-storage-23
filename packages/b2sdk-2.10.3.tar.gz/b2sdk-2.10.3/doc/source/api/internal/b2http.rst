:mod:`b2sdk._internal.b2http` -- thin http client wrapper
=========================================================

.. automodule:: b2sdk._internal.b2http
