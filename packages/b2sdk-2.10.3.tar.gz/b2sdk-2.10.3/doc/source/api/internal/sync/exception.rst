:mod:`b2sdk._internal.sync.exception`
=====================================

.. automodule:: b2sdk._internal.sync.exception
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
