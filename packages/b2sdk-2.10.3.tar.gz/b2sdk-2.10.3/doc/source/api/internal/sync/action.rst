:mod:`b2sdk._internal.sync.action`
==================================

.. automodule:: b2sdk._internal.sync.action
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
