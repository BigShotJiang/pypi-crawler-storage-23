:mod:`b2sdk._internal.stream.wrapper` StreamWrapper
===================================================

.. automodule:: b2sdk._internal.stream.wrapper
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
