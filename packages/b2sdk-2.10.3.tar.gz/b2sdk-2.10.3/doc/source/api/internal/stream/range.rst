:mod:`b2sdk._internal.stream.range` RangeOfInputStream
======================================================

.. automodule:: b2sdk._internal.stream.range
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__
