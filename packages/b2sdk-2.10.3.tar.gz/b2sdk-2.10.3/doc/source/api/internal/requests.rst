:mod:`b2sdk._internal.requests` -- modified requests.models.Response class
==========================================================================

.. automodule:: b2sdk._internal.requests
