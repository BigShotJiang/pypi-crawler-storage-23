Write intent
============

.. autoclass:: b2sdk.v3.WriteIntent()
    :inherited-members:
    :special-members: __init__
