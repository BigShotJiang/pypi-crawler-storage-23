Outbound Transfer Source
========================

.. autoclass:: b2sdk.v3.OutboundTransferSource()
    :inherited-members:
    :special-members: __init__
