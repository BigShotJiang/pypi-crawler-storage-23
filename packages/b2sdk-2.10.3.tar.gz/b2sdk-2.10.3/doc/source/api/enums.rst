Enums
=====

.. autoclass:: b2sdk.v3.MetadataDirectiveMode
   :inherited-members:

.. autoclass:: b2sdk.v3.NewerFileSyncMode
   :inherited-members:

.. autoclass:: b2sdk.v3.CompareVersionMode
   :inherited-members:

.. autoclass:: b2sdk.v3.KeepOrDeleteMode
   :inherited-members:
