Exceptions
==========

.. todo::
   improve documentation of exceptions, automodule -> autoclass?

.. automodule:: b2sdk.v3.exception
    :members:
    :undoc-members:
