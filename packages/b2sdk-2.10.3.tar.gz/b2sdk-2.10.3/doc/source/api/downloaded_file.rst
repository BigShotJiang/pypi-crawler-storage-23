Downloaded File
===============

.. autoclass:: b2sdk.v3.DownloadedFile

.. autoclass:: b2sdk.v3.MtimeUpdatedFile
