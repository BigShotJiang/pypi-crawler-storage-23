B2 Bucket
=========

.. autoclass:: b2sdk.v3.Bucket()
    :inherited-members:
    :special-members: __init__
