B2 Utility functions
====================

.. autofunction:: b2sdk.v3.b2_url_encode
.. autofunction:: b2sdk.v3.b2_url_decode
.. autofunction:: b2sdk.v3.choose_part_ranges
.. autofunction:: b2sdk.v3.fix_windows_path_limit
.. autofunction:: b2sdk.v3.format_and_scale_fraction
.. autofunction:: b2sdk.v3.format_and_scale_number
.. autofunction:: b2sdk.v3.hex_sha1_of_stream
.. autofunction:: b2sdk.v3.hex_sha1_of_bytes
