python ../sqlite_account_info_schema.py > source/dot/sqlite_account_info_schema.dot
