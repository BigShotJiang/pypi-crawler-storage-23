######################################################################
#
# File: b2sdk/_internal/__init__.py
#
# Copyright 2023 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################
"""
b2sdk._internal package contains internal modules, and should not be used directly.

Please use chosen apiver package instead, e.g. b2sdk.v3
"""
