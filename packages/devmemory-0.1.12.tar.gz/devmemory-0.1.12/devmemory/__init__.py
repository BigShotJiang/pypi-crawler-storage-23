__version__ = "0.1.12"
__app_name__ = "devmemory"
