#!/usr/bin/env python3

import os
from pathlib import Path

import pexpect
from test_base import TestBase

from warnet.k8s import get_kubeconfig_value
from warnet.process import stream_command
from warnet.status import _get_deployed_scenarios as scenarios_deployed


class WargamesTest(TestBase):
    def __init__(self):
        super().__init__()
        self.wargame_dir = Path(os.path.dirname(__file__)) / "data" / "wargames"
        self.scen_src_dir = Path(os.path.dirname(__file__)).parent / "resources" / "scenarios"
        self.scen_test_dir = (
            Path(os.path.dirname(__file__)).parent / "resources" / "scenarios" / "test_scenarios"
        )
        self.initial_context = get_kubeconfig_value("{.current-context}")
        self.kconfigdir = self.tmpdir / "kubeconfigs"

    def run_test(self):
        try:
            self.setup_battlefield()
            self.setup_armies()
            self.check_scenario_permissions()
        finally:
            self.log.info("Restoring initial_context")
            stream_command(f"kubectl config use-context {self.initial_context}")
            self.cleanup()

    def setup_battlefield(self):
        self.log.info("Setting up battlefield")
        self.log.info(self.warnet(f"deploy {self.wargame_dir / 'networks' / 'battlefield'}"))
        self.wait_for_all_tanks_status(target="running")
        self.wait_for_all_edges()

    def setup_armies(self):
        self.log.info("Deploying namespaces and armadas")
        self.log.info(self.warnet(f"deploy {self.wargame_dir / 'namespaces' / 'armies'}"))
        self.log.info(
            self.warnet(f"deploy {self.wargame_dir / 'networks' / 'armada'} --to-all-users")
        )
        self.wait_for_all_tanks_status(target="running")
        self.wait_for_all_edges()

    def check_scenario_permissions(self):
        self.log.info("Admin without --admin can not command a node outside of default namespace")
        stream_command(
            f"warnet run {self.scen_test_dir / 'generate_one_allnodes.py'} --source_dir={self.scen_src_dir} --debug"
        )
        # Only miner.default and target-red.default were accesible
        assert self.warnet("bitcoin rpc miner getblockcount") == "2"

        self.log.info("Admin with --admin can command all nodes in any namespace")
        stream_command(
            f"warnet run {self.scen_test_dir / 'generate_one_allnodes.py'} --source_dir={self.scen_src_dir} --admin --debug"
        )
        # armada.wargames-red, miner.default and target-red.default were accesible
        assert self.warnet("bitcoin rpc miner getblockcount") == "5"

        self.log.info("Switch to wargames player context")
        self.log.info(self.warnet(f"admin create-kubeconfigs --kubeconfig-dir={self.kconfigdir}"))
        clicker = pexpect.spawn(
            f"warnet auth {self.kconfigdir}/warnet-user-wargames-red-kubeconfig"
        )
        while clicker.expect(["Overwrite", "Updated kubeconfig"]) == 0:
            print(clicker.before, clicker.after)
            clicker.sendline("y")
        print(clicker.before, clicker.after)

        self.log.info("Player without --admin can only command the node inside their own namespace")
        stream_command(
            f"warnet run {self.scen_test_dir / 'generate_one_allnodes.py'} --source_dir={self.scen_src_dir} --debug"
        )
        # Only armada.wargames-red was (and is) accesible
        assert self.warnet("bitcoin rpc armada getblockcount") == "6"

        self.log.info("Player attempting to use --admin is gonna have a bad time")
        stream_command(
            f"warnet run {self.scen_test_dir / 'generate_one_allnodes.py'} --source_dir={self.scen_src_dir} --admin --debug"
        )
        # Nothing was accesible
        assert self.warnet("bitcoin rpc armada getblockcount") == "6"

        self.log.info("Check pod limit per namespace")
        for _ in range(10):
            stream_command(
                f"warnet run {self.scen_test_dir / 'nothing.py'} --source_dir={self.scen_src_dir}"
            )
        assert len(scenarios_deployed()) == 2, (
            f"Unexpected scenarios deployed:{scenarios_deployed()}"
        )

        self.log.info("Restore admin context")
        stream_command(f"kubectl config use-context {self.initial_context}")
        # Sanity check
        assert self.warnet("bitcoin rpc miner getblockcount") == "6"

        self.log.info("Re-generate kubeconfigs after a scenario has been run")
        self.log.info(self.warnet(f"admin create-kubeconfigs --kubeconfig-dir={self.kconfigdir}"))
        count = 0
        for p in self.kconfigdir.iterdir():
            if p.is_file():
                print(p)
                assert "warnet-user" in str(p)
                count += 1
                assert count <= 1


if __name__ == "__main__":
    test = WargamesTest()
    test.run_test()
