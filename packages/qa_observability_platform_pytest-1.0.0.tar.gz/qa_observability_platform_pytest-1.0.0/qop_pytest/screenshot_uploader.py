"""QOP screenshot upload utilities for Python test frameworks."""

import os
import glob as glob_module
import requests
from typing import Optional, List


def upload_screenshot(
    screenshot_path: str,
    test_case_execution_id: str,
    api_key: str,
    api_base_url: str = "http://localhost:4000",
    screenshot_type: str = "failure"
) -> Optional[dict]:
    if not os.path.exists(screenshot_path):
        print(f"[QOP] Screenshot not found: {screenshot_path}")
        return None

    try:
        upload_url = f"{api_base_url}/api/screenshots/upload"

        with open(screenshot_path, 'rb') as f:
            files = {'screenshot': (os.path.basename(screenshot_path), f, 'image/png')}
            data = {
                'test_case_execution_id': test_case_execution_id,
                'screenshot_type': screenshot_type
            }
            headers = {'x-api-key': api_key}

            response = requests.post(upload_url, files=files, data=data, headers=headers, timeout=30)

            if response.status_code == 200:
                result = response.json()
                screenshot_id = result.get('screenshot', {}).get('id', 'unknown')
                print(f"[QOP] Screenshot uploaded: {screenshot_id}")
                return result
            else:
                print(f"[QOP] Screenshot upload failed: {response.status_code}")
                return None

    except Exception as e:
        print(f"[QOP] Error uploading screenshot: {e}")
        return None


def find_and_upload_screenshots(
    test_name: str,
    test_case_execution_id: str,
    api_key: str,
    screenshots_dir: str = "screenshots",
    api_base_url: str = "http://localhost:4000"
) -> int:
    if not os.path.exists(screenshots_dir):
        return 0

    try:
        uploaded_count = 0
        normalized_test_name = test_name.replace('_', '-').replace(' ', '-').lower()

        pattern = os.path.join(screenshots_dir, "**", "*.png")
        all_screenshots = glob_module.glob(pattern, recursive=True)

        for screenshot_path in all_screenshots:
            filename = os.path.basename(screenshot_path).lower()

            if normalized_test_name in filename or test_name.lower() in filename:
                result = upload_screenshot(
                    screenshot_path, test_case_execution_id,
                    api_key, api_base_url, screenshot_type='failure'
                )
                if result:
                    uploaded_count += 1

        return uploaded_count

    except Exception as e:
        print(f"[QOP] Error finding/uploading screenshots: {e}")
        return 0
