# qa-observability-platform-pytest

QOP Pytest reporter plugin — real-time test observability with WebSocket streaming.

## Installation

```bash
pip install qa-observability-platform-pytest
```

For live browser view (Selenium tests):

```bash
pip install qa-observability-platform-pytest[live-view]
```

## Usage

Set environment variables and run your tests — the plugin auto-registers via pytest11:

```bash
export QOP_API_KEY=your-api-key
export QOP_APP_KEY=your-app-key
pytest
```

## Configuration

| Environment Variable | Description | Default |
|---------------------|-------------|---------|
| `QOP_API_KEY` | API key for authentication | Required |
| `QOP_APP_KEY` | Application key | Required |
| `QOP_PROJECT_KEY` | Project identifier | `default-project` |
| `QOP_WS_URL` | WebSocket server URL | `ws://localhost:4000/ws/ingest` |

## Live Browser View

For Selenium-based tests, enable live browser streaming:

```python
from qop_pytest import LiveStreamManager

manager = LiveStreamManager(driver, run_id="your-run-id")
manager.start_streaming()
# ... run tests ...
manager.stop_streaming()
```
