# AgentResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the agent. | 
**task_id** | **str** | ID of the task that created this agent. | 
**workspace_id** | **str** | ID of the workspace that contains this agent. | 
**data_plane_id** | **str** | ID of the data plane that contains this agent. | 
**model_id** | **str** |  | [optional] 
**name** | **str** | Name of the agent. | 
**created_at** | **datetime** | Timestamp when this agent was created. | 
**updated_at** | **datetime** | Timestamp when this agent was last updated. | 
**last_fetched** | **datetime** |  | [optional] 
**is_autocreated** | **bool** | Whether this agent was auto-created. | 
**creation_source** | [**AgentCreationSource**](AgentCreationSource.md) | Information about how this agent was created. | 
**num_spans** | **int** | Number of spans associated with this agent. | 
**rules** | [**List[RuleResponse]**](RuleResponse.md) | List of rules associated with this agent. | 
**tools** | [**List[Tool]**](Tool.md) | List of tools associated with this agent. | 
**sub_agents** | [**List[SubAgent]**](SubAgent.md) | List of sub-agents associated with this agent. | 
**models** | [**List[LLMModel]**](LLMModel.md) | List of llm models associated with this agent. | 
**data_sources** | [**List[DataSource]**](DataSource.md) | List of data sources associated with this agent. | 
**infrastructure** | [**Infrastructure**](Infrastructure.md) | Infrastructure of the data plane that contains this agent. | 

## Example

```python
from arthur_client.api_bindings.models.agent_response import AgentResponse

# TODO update the JSON string below
json = "{}"
# create an instance of AgentResponse from a JSON string
agent_response_instance = AgentResponse.from_json(json)
# print the JSON string representation of the object
print(AgentResponse.to_json())

# convert the object into a dict
agent_response_dict = agent_response_instance.to_dict()
# create an instance of AgentResponse from a dict
agent_response_from_dict = AgentResponse.from_dict(agent_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


