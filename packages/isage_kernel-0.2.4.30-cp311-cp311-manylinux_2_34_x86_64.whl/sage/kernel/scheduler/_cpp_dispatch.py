"""
_cpp_dispatch — C++ hot-path scheduler dispatch with Python fallback.

Tries to import ``_isage_kernel_ext`` (compiled with
``-DISAGE_KERNEL_BUILD_CPP=ON``).  Falls back transparently to pure-Python
stubs when the extension is not available.

Usage (internal — scheduler implementations call this, not users directly)::

    from sage.kernel.scheduler._cpp_dispatch import (
        cpp_available,
        RoundRobinDispatch,
        PriorityDispatch,
        DispatchResult,
    )

    # Check at runtime whether C++ acceleration is active
    if cpp_available:
        rr = RoundRobinDispatch(cache_ttl_seconds=5.0)
    else:
        # same API, pure Python
        rr = RoundRobinDispatch(cache_ttl_seconds=5.0)

    rr.set_nodes(["node-0", "node-1"])
    result = rr.dispatch("my-task", task_is_remote=True)
    print(result.target_node)
"""

from __future__ import annotations

from dataclasses import dataclass

# ── Try to import the compiled C++ extension ──────────────────────────────
try:
    from _isage_kernel_ext import (  # type: ignore[import]
        DispatchResult,
        PriorityDispatch,
        RoundRobinDispatch,
    )

    cpp_available: bool = True
except ImportError:
    cpp_available = False

    # ── Pure-Python fallback implementations ──────────────────────────────

    @dataclass
    class DispatchResult:  # type: ignore[no-redef]
        """Fallback DispatchResult (pure Python)."""

        target_node: str | None = None
        delay_seconds: float = 0.0
        reason: str = ""
        priority: int = 5
        immediate: bool = True

    class RoundRobinDispatch:  # type: ignore[no-redef]
        """Pure-Python round-robin dispatch (fallback)."""

        def __init__(self, cache_ttl_seconds: float = 5.0) -> None:
            self._nodes: list[str] = []
            self._index: int = 0
            self._count: int = 0
            self._cache_ttl = cache_ttl_seconds

        def set_nodes(self, nodes: list[str]) -> None:
            self._nodes = list(nodes)
            if self._index >= len(self._nodes):
                self._index = 0

        def dispatch(
            self,
            task_name: str,
            task_is_remote: bool = False,
        ) -> DispatchResult:
            self._count += 1
            if not task_is_remote or not self._nodes:
                return DispatchResult(reason="local-task or no-nodes: local placement")
            node = self._nodes[self._index]
            self._index = (self._index + 1) % len(self._nodes)
            return DispatchResult(
                target_node=node,
                reason=f"RoundRobin[py]: selected {node}",
            )

        def reset(self) -> None:
            self._index = 0
            self._count = 0

        @property
        def scheduled_count(self) -> int:
            return self._count

    class PriorityDispatch:  # type: ignore[no-redef]
        """Pure-Python priority dispatch (fallback)."""

        def __init__(
            self,
            default_priority: int = 5,
            max_concurrent: int = 10,
            enable_aging: bool = True,
            aging_boost: int = 1,
            aging_threshold_s: float = 10.0,
        ) -> None:
            self._default = default_priority
            self._max_concurrent = max_concurrent
            self._active = 0
            self._count = 0
            self._nodes: list[str] = []
            self._rr = 0

        def set_nodes(self, nodes: list[str]) -> None:
            self._nodes = list(nodes)

        def dispatch(
            self,
            task_name: str,
            priority: int = -1,
            task_is_remote: bool = False,
        ) -> DispatchResult:
            eff = self._default if priority < 0 else max(1, min(10, priority))
            delay = 0.01 if self._active >= self._max_concurrent else 0.0
            self._active += 1
            self._count += 1

            target = None
            if task_is_remote and self._nodes:
                if eff <= 3:
                    target = self._nodes[self._rr % len(self._nodes)]
                    self._rr += 1
                else:
                    target = self._nodes[0]

            return DispatchResult(
                target_node=target,
                delay_seconds=delay,
                priority=eff,
                immediate=(delay == 0.0),
                reason=f"Priority[py]: p={eff} task={task_name}",
            )

        def complete_task(self) -> None:
            self._active = max(0, self._active - 1)

        def reset(self) -> None:
            self._active = 0
            self._count = 0
            self._rr = 0

        @property
        def scheduled_count(self) -> int:
            return self._count

        @property
        def active_tasks(self) -> int:
            return self._active


__all__ = [
    "cpp_available",
    "DispatchResult",
    "RoundRobinDispatch",
    "PriorityDispatch",
]
