from tuxmake.cli import main


def run():
    if __name__ == "__main__":
        main()


run()
