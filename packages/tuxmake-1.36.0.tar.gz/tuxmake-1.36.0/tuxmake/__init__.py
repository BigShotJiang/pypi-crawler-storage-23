"""
Thin wrapper to build Linux kernels
"""

__version__ = "1.36.0"
