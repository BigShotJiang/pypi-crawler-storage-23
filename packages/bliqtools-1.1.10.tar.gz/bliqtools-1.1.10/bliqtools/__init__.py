"""
A module to manipulate files and folders from Nirvana, and monitor performance of Python code.
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("bliqtools")
except PackageNotFoundError:
    __version__ = "1.1.10"
