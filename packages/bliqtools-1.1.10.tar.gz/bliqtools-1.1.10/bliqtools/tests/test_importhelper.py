from __future__ import annotations
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

from bliqtools.cheese.importhelper import Storage, RemoteStorage, ImportHelper


def make_storage(timeseries_dict):
    """Create a Storage instance with a fake timeseries dict, bypassing __init__."""
    s = Storage.__new__(Storage)
    s.root = Path("/fake/root")
    s.limit = None
    s.timeseries = {k: Path(v) for k, v in timeseries_dict.items()}
    return s


class TestResolveProbeId(unittest.TestCase):
    def test001_version_0_9_0_legacy_site(self):
        tid = "Foremost/something-2025-07-09_23-07-56"
        s = make_storage({tid: f"/data/{tid}"})
        self.assertEqual(s.resolve_probe_id(tid), "516")

    def test002_version_0_9_1_cs550_probe_id(self):
        tid = "CS-550-ABC123-2025-07-09_23-07-56"
        s = make_storage({tid: f"/data/{tid}"})
        self.assertEqual(s.resolve_probe_id(tid), "ABC123")

    def test003_version_0_9_2_site_mac(self):
        tid = "St-Albert/CheeseData-d83adde93efc-2026-02-26_15-43-37"
        s = make_storage({tid: f"/data/{tid}"})
        self.assertEqual(s.resolve_probe_id(tid), "504")

    def test004_version_0_9_3_site_cheesedata(self):
        tid = "St-Albert/CheeseData-2026-02-25_09-41-34"
        s = make_storage({tid: f"/data/{tid}"})
        self.assertEqual(s.resolve_probe_id(tid), "504")

    def test005_unknown_path_returns_none(self):
        tid = "unknown/path/no-date"
        s = make_storage({tid: "/data/unknown/path/no-date"})
        self.assertIsNone(s.resolve_probe_id(tid))

    def test006_all_sites_resolve(self):
        sites_expected = {
            "Foremost": "516",
            "St-Albert": "504",
            "St-albert-images": "504",
            "St-benoit": "517",
            "St-Laurent-vat1-new": "520",
            "St-Laurent-vat2-new": "519",
            "St-Laurent-vat1": "507b",
            "St-Laurent-vat2": "506",
            "new-st-laurent-vat1": "520",
        }
        for site, expected_probe in sites_expected.items():
            tid = f"{site}/CheeseData-2026-01-01_12-00-00"
            s = make_storage({tid: f"/data/{tid}"})
            self.assertEqual(s.resolve_probe_id(tid), expected_probe, f"Failed for site {site}")


class TestTimeseriesInfo(unittest.TestCase):
    def test010_date_extraction(self):
        tid = "St-Albert/CheeseData-2026-02-25_09-41-34"
        s = make_storage({tid: f"/data/{tid}"})
        with patch.object(s, "find_data_size", return_value=0):
            info = s.timeseries_info(tid)
        self.assertEqual(info["date"], "2026-02-25 09:41:34")
        self.assertEqual(info["probe_id"], "504")
        self.assertEqual(info["timeseries_id"], tid)

    def test011_date_extraction_with_mac(self):
        tid = "St-Albert/CheeseData-d83adde93efc-2026-02-26_15-43-37"
        s = make_storage({tid: f"/data/{tid}"})
        with patch.object(s, "find_data_size", return_value=0):
            info = s.timeseries_info(tid)
        self.assertEqual(info["date"], "2026-02-26 15:43:37")

    def test012_info_contains_size(self):
        tid = "St-Albert/CheeseData-2026-02-25_09-41-34"
        s = make_storage({tid: f"/data/{tid}"})
        with patch.object(s, "find_data_size", return_value=12345):
            info = s.timeseries_info(tid)
        self.assertEqual(info["size_kb"], 12345)


class TestStorageWithTempDir(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # Create two timeseries directories with contrast_curve.csv
        self.ts1 = "St-Albert/CheeseData-2026-01-01_10-00-00"
        self.ts2 = "St-Albert/CheeseData-2026-01-02_11-00-00"
        for ts in [self.ts1, self.ts2]:
            d = Path(self.tmpdir) / ts
            d.mkdir(parents=True)
            (d / "contrast_curve.csv").write_text("col1,col2\n1,2\n")
            (d / "Cheese.log").write_text("log data\n")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir)

    def _make_local_storage(self, limit=None):
        """Create a Storage via __new__ then run find_all_timeseries_ids manually."""
        s = Storage.__new__(Storage)
        s.root = Path(self.tmpdir)
        s.limit = limit
        s.timeseries = s.find_all_timeseries_ids()
        return s

    def test020_find_all_timeseries_ids(self):
        s = self._make_local_storage()
        self.assertEqual(len(s.timeseries), 2)
        self.assertIn(self.ts1, s.timeseries)
        self.assertIn(self.ts2, s.timeseries)

    def test021_available_files(self):
        s = self._make_local_storage()
        files = s.available_files(self.ts1)
        self.assertIn("contrast_curve.csv", files)
        self.assertIn("Cheese.log", files)

    def test022_filepath_contrast(self):
        s = self._make_local_storage()
        path = s.filepath_contrast(self.ts1)
        self.assertIsNotNone(path)
        self.assertTrue(str(path).endswith("contrast_curve.csv"))

    def test023_filepath_contrast_all_data_missing(self):
        s = self._make_local_storage()
        path = s.filepath_contrast_all_data(self.ts1)
        self.assertIsNone(path)

    def test024_filepath_contrast_all_data_present(self):
        d = Path(self.tmpdir) / self.ts1
        (d / "all_data.csv").write_text("col1\n1\n")
        s = self._make_local_storage()
        path = s.filepath_contrast_all_data(self.ts1)
        self.assertIsNotNone(path)
        self.assertTrue(str(path).endswith("all_data.csv"))

    def test025_filepath_log(self):
        s = self._make_local_storage()
        path = s.filepath_log(self.ts1)
        self.assertIsNotNone(path)
        self.assertTrue(str(path).endswith("Cheese.log"))

    def test026_limit_caps_timeseries(self):
        s = self._make_local_storage(limit=1)
        self.assertEqual(len(s.timeseries), 1)

    def test027_timeseries_ids_property(self):
        s = self._make_local_storage()
        self.assertEqual(set(s.timeseries_ids), {self.ts1, self.ts2})

    def test028_timeseries_directories_property(self):
        s = self._make_local_storage()
        dirs = s.timeseries_directories
        self.assertEqual(len(dirs), 2)
        for d in dirs:
            self.assertTrue(str(d).startswith(self.tmpdir))


class TestImportHelperURLParsing(unittest.TestCase):
    @patch("bliqtools.cheese.importhelper.CheeseDB")
    @patch("bliqtools.cheese.importhelper.RemoteStorage")
    def test030_ssh_url_parsing(self, mock_remote_cls, mock_db_cls):
        mock_storage = MagicMock()
        mock_storage.timeseries = {}
        mock_storage.find_data_size.return_value = 0
        mock_remote_cls.return_value = mock_storage

        mock_db = MagicMock()
        mock_db.timeseries_ids = iter([])
        mock_db_cls.return_value = mock_db

        helper = ImportHelper(
            root="ssh://bliq-cheese/home/bliq/cheese/cheese_data",
            databaseURL="mysql://root@127.0.0.1:3306/cheese",
        )
        mock_remote_cls.assert_called_once_with(
            ssh_host="bliq-cheese",
            root="/home/bliq/cheese/cheese_data",
            limit=None,
        )

    @patch("bliqtools.cheese.importhelper.CheeseDB")
    @patch("bliqtools.cheese.importhelper.Storage")
    def test031_local_path_uses_storage(self, mock_storage_cls, mock_db_cls):
        mock_storage = MagicMock()
        mock_storage.timeseries = {}
        mock_storage.find_data_size.return_value = 0
        mock_storage_cls.return_value = mock_storage

        mock_db = MagicMock()
        mock_db.timeseries_ids = iter([])
        mock_db_cls.return_value = mock_db

        helper = ImportHelper(
            root="/local/data",
            databaseURL="mysql://root@127.0.0.1:3306/cheese",
        )
        mock_storage_cls.assert_called_once_with(root="/local/data", limit=None)


class TestSQLGeneration(unittest.TestCase):
    """Test SQL string generation with temp files — no database needed."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.tid = "St-Albert/CheeseData-2026-02-25_09-41-34"
        d = Path(self.tmpdir) / self.tid
        d.mkdir(parents=True)
        (d / "contrast_curve.csv").write_text("col1,col2\n1,2\n")
        (d / "all_data.csv").write_text("burst_id,burst_number\n1,2\n")

        self.storage = Storage.__new__(Storage)
        self.storage.root = Path(self.tmpdir)
        self.storage.limit = None
        self.storage.timeseries = {self.tid: d}

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir)

    def _make_helper(self):
        helper = ImportHelper.__new__(ImportHelper)
        helper.storage = self.storage
        helper.db = MagicMock()
        helper.db.timeseries_ids = iter([])
        return helper

    def test040_sql_insert_timeseries(self):
        helper = self._make_helper()
        with patch.object(self.storage, "find_data_size", return_value=0):
            sql = helper.sql_insert_timeseries(self.tid)
        self.assertIn("insert into timeseries", sql)
        self.assertIn("2026-02-25 09:41:34", sql)
        self.assertIn("504", sql)
        self.assertIn(self.tid, sql)

    def test041_sql_import_contrast_data(self):
        helper = self._make_helper()
        sql = helper.sql_import_contrast_data(self.tid)
        self.assertIn("LOAD DATA LOCAL INFILE", sql)
        self.assertIn("contrast_curve.csv", sql)
        self.assertIn("col1,col2", sql)
        self.assertIn("timeseries_data", sql)
        self.assertIn(self.tid, sql)

    def test042_sql_import_contrast_data_missing_file(self):
        tid_no_contrast = "St-Albert/CheeseData-2026-03-01_10-00-00"
        d = Path(self.tmpdir) / tid_no_contrast
        d.mkdir(parents=True)
        self.storage.timeseries[tid_no_contrast] = d

        helper = self._make_helper()
        self.assertIsNone(helper.sql_import_contrast_data(tid_no_contrast))

    def test043_sql_import_contrast_all_data(self):
        helper = self._make_helper()
        sql = helper.sql_import_contrast_all_data(self.tid)
        self.assertIn("LOAD DATA LOCAL INFILE", sql)
        self.assertIn("all_data.csv", sql)
        self.assertIn("timeseries_all_data", sql)
        self.assertIn(self.tid, sql)

    def test044_sql_import_contrast_all_data_missing_file(self):
        tid_no_all = "St-Albert/CheeseData-2026-03-01_10-00-00"
        d = Path(self.tmpdir) / tid_no_all
        d.mkdir(parents=True)
        self.storage.timeseries[tid_no_all] = d

        helper = self._make_helper()
        self.assertIsNone(helper.sql_import_contrast_all_data(tid_no_all))

    def test045_sql_import_contrast_data_empty_file(self):
        tid_empty = "St-Albert/CheeseData-2026-03-02_10-00-00"
        d = Path(self.tmpdir) / tid_empty
        d.mkdir(parents=True)
        (d / "contrast_curve.csv").write_text("")
        self.storage.timeseries[tid_empty] = d

        helper = self._make_helper()
        self.assertIsNone(helper.sql_import_contrast_data(tid_empty))


class TestMissingTimeseriesId(unittest.TestCase):
    """Test missing_timeseries_id logic with mocked DB."""

    def test050_all_missing(self):
        helper = ImportHelper.__new__(ImportHelper)
        helper.storage = make_storage({
            "ts1": "/data/ts1",
            "ts2": "/data/ts2",
        })
        helper.db = MagicMock()
        helper.db.timeseries_ids = []

        missing = list(helper.missing_timeseries_id())
        self.assertEqual(set(missing), {"ts1", "ts2"})

    def test051_none_missing(self):
        helper = ImportHelper.__new__(ImportHelper)
        helper.storage = make_storage({
            "ts1": "/data/ts1",
            "ts2": "/data/ts2",
        })
        helper.db = MagicMock()
        helper.db.timeseries_ids = ["ts1", "ts2"]

        missing = list(helper.missing_timeseries_id())
        self.assertEqual(missing, [])

    def test052_partial_missing(self):
        helper = ImportHelper.__new__(ImportHelper)
        helper.storage = make_storage({
            "ts1": "/data/ts1",
            "ts2": "/data/ts2",
            "ts3": "/data/ts3",
        })
        helper.db = MagicMock()
        helper.db.timeseries_ids = ["ts1", "ts3"]

        missing = list(helper.missing_timeseries_id())
        self.assertEqual(missing, ["ts2"])


databaseURL = "mysql://root@127.0.0.1:3306/cheese"


class TestWithProductionDatabase(unittest.TestCase):
    """Read-only tests against the production database. Skipped if unavailable."""

    def setUp(self):
        try:
            from bliqtools.cheese.cheesedb import CheeseDB
            self.db = CheeseDB(databaseURL=databaseURL)
        except Exception as err:
            self.skipTest(f"No database connection: {err}")

    def test060_missing_timeseries_id_returns_subset_of_storage(self):
        """missing_timeseries_id should only yield IDs not in the DB."""
        fake_tids = list(self.db.timeseries_ids)[:3]
        novel_tid = "FAKE/CheeseData-2099-01-01_00-00-00"

        helper = ImportHelper.__new__(ImportHelper)
        helper.db = self.db
        helper.storage = make_storage(
            {tid: f"/data/{tid}" for tid in fake_tids + [novel_tid]}
        )

        missing = list(helper.missing_timeseries_id())
        self.assertIn(novel_tid, missing)
        for tid in fake_tids:
            self.assertNotIn(tid, missing)

    def test061_db_has_timeseries(self):
        """Sanity check: production DB has timeseries."""
        ids = list(self.db.timeseries_ids)
        self.assertTrue(len(ids) > 0)


if __name__ == "__main__":
    unittest.main()
