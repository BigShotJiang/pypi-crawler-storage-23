from __future__ import annotations
from dcclab.database import MySQLDatabase
import matplotlib.pyplot as plt
import numpy as np
import os
from pathlib import Path
import re
from typing import Callable, Iterable, Dict, List
import unittest
from bliqtools.cheese.cheesedb import CheeseDB

# databaseURL = "mysql://bliq@127.0.0.1:3308/cheese"
databaseURL = "mysql://root@127.0.0.1:3306/cheese"

class CheeseDBTestCases(unittest.TestCase):
    def setUp(self):
        try:
            self.db = CheeseDB(databaseURL=databaseURL)
        except Exception as err:
            print(f"No database connection: {err}")
            self.db = None


    def test001_sites(self):
        self.assertIsNotNone(self.db.sites)
        self.assertTrue(len(self.db.sites) > 1)

    def test002_locations(self):
        self.assertIsNotNone(self.db.locations)
        self.assertTrue(len(self.db.locations) > 1)

    def test003_probes(self):
        self.assertIsNotNone(self.db.probes)
        self.assertTrue(len(self.db.probes) > 15)

    def test004_timeseries(self):
        self.assertIsNotNone(self.db.timeseries)
        self.assertTrue(len(self.db.timeseries) > 1)

    def test005_timeseries_ids(self):
        self.assertIsNotNone(self.db.timeseries_ids)
        self.assertTrue(len(list(self.db.timeseries_ids)) > 1)

    def test006_contrasts(self):
        some_series = list(self.db.timeseries_ids)[0]
        self.assertIsNotNone(self.db.contrasts(timeseries_id=some_series))

    def test007_contrasts_stats(self):
        some_series = list(self.db.timeseries_ids)[0]
        self.assertIsNotNone(self.db.contrasts_stats(timeseries_id=some_series))

    @unittest.skip("Not useful now")
    def test008_git(self):
        from git import Repo
        import datetime
        import os

        def get_version_info(path=None):
            """
            Return Git commit, tag, branch, and dirty status.
            `path` should be any file or directory inside the repo.
            """
            if path is None:
                path = os.getcwd()

            repo = Repo(path, search_parent_directories=True)

            commit = repo.head.commit.hexsha
            branch = repo.active_branch.name if not repo.head.is_detached else "DETACHED"
            is_dirty = repo.is_dirty()
            
            # Try to find an exact tag referencing this commit
            tags = [t.name for t in repo.tags if t.commit == repo.head.commit]
            tag = tags[0] if tags else None

            return {
                "commit": commit,
                "branch": branch,
                "tag": tag,
                "dirty": is_dirty,
                "timestamp": datetime.datetime.now().isoformat(),
            }

        print(get_version_info())


if __name__ == "__main__":
    # importing_contrast_curves_from_gdrive()
    # unittest.main(defaultTest=['CheeseDBTestCases.test200_import_gdrive'])
    unittest.main()