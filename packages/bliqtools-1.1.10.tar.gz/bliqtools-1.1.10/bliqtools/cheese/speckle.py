import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import correlate
from numpy.fft import rfft, irfft
from enum import IntEnum

rng = np.random.default_rng(42)
default_img_shape = (100,100)


class Axes(IntEnum):
    X = 0
    Y = 1
    MODE = 2
    TIME = 3

class Field:
    """
    A 4D array: (x,y, mode, time) 

    """

    def __init__(self, img_shape=default_img_shape):

        self.values = np.zeros(shape=(*img_shape, 0, 1), dtype=complex)

        # frequency grid
        self._ky = np.fft.fftfreq(img_shape[Axes.Y])
        self._kx = np.fft.fftfreq(img_shape[Axes.X])
        self._KX, self._KY = np.meshgrid(self._kx, self._ky)
        self._k = np.sqrt(self._KX**2 + self._KY**2)
        self._H = None
        self._ksigma = None

    @classmethod
    def uniform_phase(cls, shape=default_img_shape, max_phi=2*np.pi):
        return rng.uniform(0, max_phi, size=shape)

    @classmethod
    def uniform_field(cls, shape=default_img_shape, amplitude=1.0):
        return amplitude * np.ones(shape=shape, dtype=float)

    def add_mode(self, amplitude=1, max_phi=2*np.pi):
        if self.values.shape[3] != 1:
            raise ValueError("You cannot add time_steps before adding a mode. Add the mode first.")

        img_shape = self.values.shape[0:2]
        mode_field = self.uniform_field(shape=img_shape, amplitude=amplitude) 
        mode_phase = self.uniform_phase(shape=img_shape, max_phi = max_phi)

        field = mode_field * np.exp(complex(0,1)*mode_phase)
        field = field.reshape((*img_shape, 1, 1))
        self.values = np.concat( (self.values, field), axis=Axes.MODE)

    def intensity(self, ksigma=0.15, time_bin_size=1):
        if time_bin_size is None:
            time_bin_size = self.values.shape[3]
        time_idx = np.arange(0, self.values.shape[Axes.TIME], time_bin_size)

        if self._ksigma != ksigma:
            self._H = np.exp(-(self._k / ksigma)**2)
            img_shape = self.values.shape[0:2]
            self._H = self._H.reshape((*img_shape, 1, 1))

        fourier_values = np.fft.fft2(self.values, axes=(0,1))

        single_mode_fields = np.fft.ifft2(self._H * fourier_values, axes=(0,1))

        single_mode_fields /= np.abs(single_mode_fields).max()
        single_mode_intensities = np.abs(single_mode_fields)**2

        multimode_intensity = np.sum( (255*single_mode_intensities).astype(np.uint8), keepdims=True, axis=Axes.MODE)
        multimode_intensity_time_integrated = np.add.reduceat(multimode_intensity, time_idx, axis=Axes.TIME)

        return multimode_intensity.squeeze()

    def contrast(self, ksigma=0.15, time_bin_size=1):
        """
        Always removes mode dimension
        """

        intensity = self.intensity(ksigma=ksigma, time_bin_size=time_bin_size)
        return intensity.std(axis=(0,1)) / intensity.mean(axis=(0,1))

    def show(self, prefix=None, block=True):
        if block:
            plt.ion()
        else:
            plt.ioff()

        if prefix is None:
            prefix = "Speckle intensity"

        # plt.figure(figsize=(5, 5))
        plt.imshow(self.intensity()[:,:,-1], cmap="gray", origin="lower")
        plt.title(f"{prefix} Contrast ≈ {self.contrast():.3f}")
        plt.axis("off")
        plt.tight_layout()
        plt.show(block=block)

def contrast_vs_mode_amplitude():
    R = 100
    N_a = 20
    contrasts = np.zeros(shape=(R, N_a))
    amplitudes = np.linspace(0, 1, N_a)
    for run in range(R):
        for i, amplitude_2nd_mode in enumerate(amplitudes):
            field = Field()
            field.add_mode()
            field.add_mode(amplitude=amplitude_2nd_mode)

            contrasts[run,i] = field.contrast()
    for x,y in zip(amplitudes, contrasts.mean(axis=0)):
        print(x,y)

    plt.plot(amplitudes, contrasts.mean(axis=0))
    plt.show()

def contrast_vs_modes():
    R = 100
    N_m = 20
    contrasts = np.zeros(shape=(R, N_m))
    n_modes = range(1,N_m+1)
    for run in range(R):
        field = Field()
        for i in n_modes:
            field.add_mode()

            contrasts[run,i-1] = field.contrast()

    for x,y in zip(n_modes, contrasts.mean(axis=0)):
        print(x,y)

    plt.xticks(n_modes)
    plt.plot(n_modes, contrasts.mean(axis=0))
    plt.show()

def contrast_vs_singlemode_amplitude():
    R = 30*30
    N_a = 20
    contrasts = np.zeros(shape=(R, N_a))
    amplitudes = np.linspace(0.01, 1, N_a)
    for run in range(R):
        for i, amplitude in enumerate(amplitudes):
            field = Field()
            field.add_mode(amplitude=amplitude)

            contrasts[run,i] = field.contrast()
    for x,y in zip(amplitudes, contrasts.mean(axis=0)):
        print(x,y)

    plt.plot(amplitudes, contrasts.mean(axis=0))
    plt.show()

def contrast_vs_img_shape():
    sizes = 10**(np.linspace(1,3,10))
    R = 100
    contrasts = np.zeros(shape=(R, len(sizes)))
    for r in range(R):
        for i, size in enumerate(sizes):
            field = Field(img_shape=(int(size), int(size)))
            field.add_mode()
            contrasts[r, i] = field.contrast()
        print(r)

    for x,y in zip(sizes,contrasts.mean(axis=0)):
        print(x,y)

    plt.xticks(sizes)
    plt.loglog(sizes, contrasts.mean(axis=0))
    plt.show()

def image_vs_img_shape():
    sizes = 10**(np.linspace(1,3,10))
    for i, size in enumerate(sizes):
        field = Field(img_shape=(int(size), int(size)))
        field.add_mode()
        plt.imshow(field.intensity())
        plt.show()

def contrast_vs_k():
    ks = np.linspace(0.01, 1, 100)
    R = 100
    M = 3
    contrasts = np.zeros(shape=(R, len(ks), M))
    for r in range(R):
        print(r)
        for i, ksigma in enumerate(ks):
            field = Field(img_shape=(200,200))
            for m in range(M):
                field.add_mode()
                contrasts[r, i, m] = field.contrast(ksigma=ksigma)

    for x,y,z in zip(ks,contrasts.mean(axis=0), contrasts.std(axis=0)):
        print(x,*y,*z)

    plt.semilogx(ks, contrasts.std(axis=0))
    plt.show()

def contrast_std_vs_random_M_modes():
    R = 1000
    for M in range(2,100,10):
        contrasts = np.zeros((R,))
        for i in range(R):
            field = Field()
            for j in range(M):
                field.add_mode(amplitude=np.random.random())
            contrasts[i] = field.contrast()

        mean = contrasts.mean()
        print(M, mean, contrasts.std()/mean)

def contrast_std_vs_random_M_modes():
    R = 1000
    for M in range(2,100,10):
        contrasts = np.zeros((R,))
        for i in range(R):
            field = Field()
            for j in range(M):
                field.add_mode(amplitude=np.random.random())
            contrasts[i] = field.contrast()

        mean = contrasts.mean()
        print(M, mean, contrasts.std()/mean)

if __name__ == "__main__":
    contrast_std_vs_random_M_modes()