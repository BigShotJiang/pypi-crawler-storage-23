from __future__ import annotations
import ast
import numpy as np
import os
from pathlib import Path
import re
from typing import Callable, Iterable, Dict, List
import sys
import subprocess
import socket


class Storage:
    DATE_PATTERN = r"(?P<year>20\d\d)-(?P<month>\d+)-(?P<day>\d+)_(?P<hour>\d+)-(?P<minutes>\d+)-(?P<seconds>\d+)"

    """Discovers and indexes timeseries directories on a local filesystem.

    Scans a root directory for timeseries data (identified by contrast_curve.csv files)
    and provides access to their metadata and files. Shell commands (find, ls, du) are
    executed via _run(), which subclasses can override to change execution context.

    Args:
        root: Path to the root directory containing timeseries data.
        limit: Maximum number of timeseries to index. None for all.
    """
    def __init__(self, root, limit=None):
        self.root = Path(root)
        self.limit = limit
        self.timeseries = self.find_all_timeseries_ids()
        self.report()

    def report(self):
        print(f"Total size: {self.find_data_size()/1e6:.2f} Gb")
        print(f"Timeseries on disk: {len(self.timeseries)} ")

    @property
    def timeseries_ids(self):
        return list(self.timeseries.keys())
    
    @property
    def timeseries_directories(self):
        return list(self.timeseries.values())

    def filepath_contrast(self, timeseries_id):
        for filename in self.available_files(timeseries_id):
            if filename.endswith('contrast_curve.csv'):
                return Path(self.timeseries[timeseries_id]) / filename
        return None

    def filepath_contrast_all_data(self, timeseries_id):
        for filename in self.available_files(timeseries_id):
            if filename.endswith('all_data.csv'):
                return Path(self.timeseries[timeseries_id]) / filename
        return None


    def filepath_log(self, timeseries_id):
        for filename in self.available_files(timeseries_id):
            if filename.endswith('Cheese.log'):
                return Path(self.timeseries[timeseries_id]) / filename
        return None


    def resolve_probe_id(self, timeseries_id):
        """Determine the probe_id from a timeseries path.

        Centralizes all probe identification logic. The probe_id can come from:
        - The filename itself (e.g. CS-550-<probe_id>-date in format 0_9_1)
        - The site directory name mapped through sites_to_probe_id
        - A MAC address that identifies a specific device

        Returns the probe_id string, or None if it cannot be determined.
        """
        sites_to_probe_id = {
            "Foremost": "516",
            "St-Albert": "504",
            "St-albert-images": "504",
            "St-benoit": "517",
            "St-Laurent-vat1-new": "520",
            "St-Laurent-vat2-new": "519",
            "St-Laurent-vat1": "507b",
            "St-Laurent-vat2": "506",
            "new-st-laurent-vat1": "520",
        }

        regex_sites = "|".join(sites_to_probe_id.keys())
        date = self.DATE_PATTERN

        regexes = {
            "0_9_2": rf"(?P<site>{regex_sites})/CheeseData-(?P<mac>[0-9a-f]+)-{date}",
            "0_9_3": rf"(?P<site>{regex_sites})/CheeseData-{date}",
            "0_9_1": rf"CS-550-(?P<probe_id>.+?)-{date}",
            "0_9_0": rf"(?P<site>{regex_sites}).*?{date}",
        }

        path_str = str(self.timeseries[timeseries_id])

        for version, regex in regexes.items():
            match = re.search(regex, path_str)
            if match is not None:
                f = match.groupdict()

                if 'probe_id' in f:
                    return f['probe_id']

                if 'site' in f:
                    return sites_to_probe_id.get(f['site'])

        return None

    def timeseries_info(self, timeseries_id):
        timeseries_directory = self.timeseries[timeseries_id]

        info = {"timeseries_id": timeseries_id,
                "timeseries_directory": timeseries_directory,
                "size_kb": self.find_data_size(timeseries_directory)}

        info['probe_id'] = self.resolve_probe_id(timeseries_id)

        path_str = str(timeseries_directory)
        match = re.search(self.DATE_PATTERN, path_str)
        if match is not None:
            f = match.groupdict()
            info['date'] = f"{f['year']}-{f['month']}-{f['day']} {f['hour']}:{f['minutes']}:{f['seconds']}"

        return info


    def _run(self, cmd):
        return subprocess.run(
            cmd, shell=True,
            text=True,
            capture_output=True,
            check=True,
        )

    def available_files(self, timeseries_id):
        timeseries_directory = self.timeseries[timeseries_id]
        p = self._run(f"ls {timeseries_directory}")
        return p.stdout.splitlines()

    def find_all_timeseries_ids(self):
        p = self._run(f"find {self.root} -name '*contrast_curve.csv'")

        dirs = [str(Path(line).parent.relative_to(self.root)) for line in p.stdout.splitlines()]
        timeseries_ids = [d for d in dirs if "CheeseData" in d]
        if self.limit is not None:
            timeseries_ids = timeseries_ids[:self.limit]

        timeseries = {}
        for timeseries_id in timeseries_ids:
            if timeseries_id not in timeseries:
                timeseries[timeseries_id] = self.root / timeseries_id
            else:
                raise ValueError(f"timeseries_id not unique: {timeseries_id}")

        return timeseries

    def find_data_size(self, path=None):
        if path is None:
            path = self.root
        p = self._run(f"du -k -d1 {path}")
        return sum([int(line.split('\t')[0]) for line in p.stdout.splitlines()])


class RemoteStorage(Storage):
    """Storage subclass that executes all shell commands on a remote host via SSH.

    Overrides _run() to send commands through SSH instead of running them locally.
    Requires passwordless SSH access (e.g. via ssh-agent or key-based auth).

    Args:
        ssh_host: SSH host alias or address (e.g. "bliq-cheese" or "user@host").
        root: Path to the root directory on the remote host.
        limit: Maximum number of timeseries to index. None for all.
    """
    def __init__(self, ssh_host, root, limit=None):
        self.ssh_host = ssh_host
        super().__init__(root, limit=limit)

    def _run(self, cmd):
        return subprocess.run(
            ["ssh", self.ssh_host, cmd],
            text=True,
            capture_output=True,
            check=True,
        )


class ImportHelper:
    """Compares timeseries on disk with the CheeseDB database and generates SQL
    import statements for missing data.

    Automatically selects local or remote storage based on the root URL format.

    Args:
        root: Path to the timeseries data. Use a local path (e.g. "/data/cheese")
            for local storage, or "ssh://host/path" (e.g. "ssh://bliq-cheese/home/bliq/cheese/cheese_data")
            for remote storage via SSH.
        databaseURL: MySQL connection URL in the format "mysql+ssh://sshuser@sshhost/dbuser:dbpass@dbhost/database"
            (e.g. "mysql+ssh://bliq@cafeine2.crulrg.ulaval.ca/bliq:bliq@bliqdb.local/cheese").
        limit: Maximum number of timeseries to index. None for all.
    """
    def __init__(self, root, databaseURL, limit=None):
        from bliqtools.cheese.cheesedb import CheeseDB

        if root.startswith("ssh://"):
            # ssh://host/path
            rest = root[len("ssh://"):]
            ssh_host, remote_root = rest.split("/", 1)
            self.storage = RemoteStorage(ssh_host=ssh_host, root="/" + remote_root, limit=limit)
        else:
            self.storage = Storage(root=root, limit=limit)
        self.db = CheeseDB(databaseURL=databaseURL)

        self.report()

    def report(self):
        print(f"Timeseries in database: {len(list(self.db.timeseries_ids))}")
        missing = list(self.missing_timeseries_id())
        total_size = sum(self.storage.find_data_size(self.storage.timeseries[tid]) for tid in missing)
        print(f"Timeseries to import [contrast only]: {len(missing)} [{total_size/1e6:.2f} Gb]")


    def missing_timeseries_id(self):
        timeseries_ids_in_db = list(self.db.timeseries_ids)

        for timeseries_id, timeseries_directory in self.storage.timeseries.items():
            if timeseries_id not in timeseries_ids_in_db:
                yield timeseries_id


    def sql_insert_timeseries(self, timeseries_id):
        info = self.storage.timeseries_info(timeseries_id)
        st = f"insert into timeseries (date_acquired, probe_id, timeseries_id) values('{info['date']}', '{info['probe_id']}', '{info['timeseries_id']}')"
        
        return st

    def sql_import_contrast_data(self, timeseries_id):
        filepath = self.storage.filepath_contrast(timeseries_id)
        if filepath is None:
            return

        with open(filepath, "r") as f:
            lines = [line.rstrip("\n") for line in f]
            if len(lines) == 0:
                return
            fields = lines[0]

        statement = f"""
            SET autocommit = 1;
            SELECT 'Importing contrast_data from {filepath}';

            LOAD DATA LOCAL INFILE '{filepath}'
            INTO TABLE timeseries_data
            FIELDS TERMINATED BY ','
            ENCLOSED BY '"'
            LINES TERMINATED BY '\\n'
            IGNORE 1 LINES
            ({fields})
            SET timeseries_id = '{timeseries_id}';

            SET autocommit = 0;
        """

        return statement

    def sql_import_contrast_all_data(self, timeseries_id):
        filepath = self.storage.filepath_contrast_all_data(timeseries_id)
        if filepath is None:
            return

        with open(filepath, "r") as f:
            lines = [line.rstrip("\n") for line in f]
            if len(lines) == 0:
                return
            fields = lines[0]

        statement = f"""
            SET autocommit = 1;
            SELECT 'Importing all_data from {filepath}';

            LOAD DATA LOCAL INFILE '{filepath}'
            INTO TABLE timeseries_all_data
            FIELDS TERMINATED BY ','
            ENCLOSED BY '"'
            LINES TERMINATED BY '\\n'
            IGNORE 1 LINES
            (burst_id,
             burst_number,
             image_index,
             timestamp,
             contrast_max,
             contrasts_mean,
             contrasts_std,
             image_intensity_min,
             image_intensity_mean,
             image_intensity_max,
             cheese_state)
            SET timeseries_id = '{timeseries_id}';

            SET autocommit = 0;
        """

        return statement


    def sql_populate_recipes(self):
        """Extract recipe line numbers from logs and print INSERT statements for the recipes table.

        Looks for 'Loaded analyser parameters:' lines that contain a dict with a 'name' key.
        """
        self.db.execute(
            "SELECT timeseries_id, line_number, line FROM logs WHERE line LIKE %s",
            ("%'name'%",)
        )
        rows = self.db.fetchAll()

        seen = {}
        for row in rows:
            tid = row['timeseries_id']
            if tid in seen:
                continue
            line = row['line'].strip()
            # Extract the dict portion after "Loaded analyser parameters: "
            marker = 'Loaded analyser parameters: '
            idx = line.find(marker)
            if idx == -1:
                continue
            dict_str = line[idx + len(marker):]
            try:
                d = ast.literal_eval(dict_str)
                if 'name' in d:
                    seen[tid] = row['line_number']
            except (ValueError, SyntaxError):
                continue

        for tid, line_number in seen.items():
            print(f"INSERT IGNORE INTO recipes (timeseries_id, line_number) VALUES ('{tid}', {line_number});")

    def sql_special_case_recipe_determination(self):
        """
        Recipes are important to know if the coagulation is stopped late (i.e. cheddar)
        or early (i.e. mozzarella).

        Because of the many software versions, there is no straight strategy for now.
        We look into the log of each timeseries to extract the information.

        The recipe is mentionned by number (early versions) and/or by type (cheddar, mozz)
        in the logs.  We use that information to store it in the timeseries table.

        """
        for i, timeseries_id in enumerate(self.storage.timeseries_ids):
            info = self.storage.timeseries_info(timeseries_id)
            log_path = Path(info['timeseries_directory']) / "Cheese.log"

            if log_path.exists:
                recipe = None
                p = subprocess.run(
                        ["grep", "-i", "Cheddar", "Cheese.log"],
                        cwd=info['timeseries_directory'],
                        text=True,
                        capture_output=True,                    
                        )

                if p.returncode == 0:
                    recipe = "Cheddar"

                elif p.returncode == 1:
                    p = subprocess.run(
                            ["grep", "-i", "Mozz", "Cheese.log"],
                            cwd=info['timeseries_directory'],
                            text=True,
                            capture_output=True,                    
                            )
                    if p.returncode == 0:
                        recipe = "Mozzarella"

                if recipe is not None:
                    print(f"update timeseries set recipe = '{recipe}' where timeseries_id = '{timeseries_id}';")


if __name__ == "__main__":

    helper = ImportHelper(
        root="ssh://bliq-cheese/home/bliq/cheese/cheese_data",
        databaseURL="mysql+ssh://bliq@cafeine2.crulrg.ulaval.ca/bliq:bliq@bliqdb.local/cheese",
        limit=None,
    )
    # helper.sql_special_case_recipe_determination()

