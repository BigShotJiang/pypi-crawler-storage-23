"""
Curve fitting for coagulation data.
Originally by Alina, modifgied by dccote
"""
from bliqtools.cheese.cheesedb import CheeseDB
from typing import Callable, Dict, List, Optional, Tuple
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

def stable_sigmoid(z: np.ndarray) -> np.ndarray:
    """Numerically stable sigmoid to prevent overflow in exp()."""
    return np.where(z >= 0, 1 / (1 + np.exp(-z)), np.exp(z) / (1 + np.exp(z)))

def sigmoid(x, a, b, c, d):
    """Single sigmoid: a + (b-a)/(1+exp(-c*(x-d)))."""
    z = c * (x - d)
    sigmoid_part = stable_sigmoid(z)
    return a + (b - a) * sigmoid_part


if __name__ == "__main__":
    db = CheeseDB("mysql+ssh://bliq@cafeine2.crulrg.ulaval.ca/bliq:bliq@bliqdb.local/cheese")
    db.execute(f"select timeseries_id from timeseries where timeseries_id like '%contrast%'")
    timeseries_to_analyse = [r['timeseries_id'] for r in db.fetchAll()]

    analysis_id = "something_unique"
    for timeseries_id in timeseries_to_analyse:
        contrasts = db.contrasts(timeseries_id=timeseries_id, field="contrast_spread_std")

        start_of_fit_seconds = 400

        mask_greater_than_start = contrasts[:,0] > start_of_fit_seconds
        elapsed_time = contrasts[mask_greater_than_start,0]
        contrast_values =  contrasts[mask_greater_than_start,1]

        if elapsed_time.size < 20:
            continue

        max_func_eval = 10000

        try:
            all_params = {
                "t_min_sigmoid_fit":start_of_fit_seconds,
                "a0_sigmoid_fit":0.2,
                "b0_sigmoid_fit":0.2,
                "c0_sigmoid_fit":0.001,
                "d0_sigmoid_fit":1200,
                "a_low_sigmoid_fit":0,
                "b_low_sigmoid_fit":0.01,
                "c_low_sigmoid_fit":0.0001,
                "d_low_sigmoid_fit":400,
                "a_high_sigmoid_fit":0.5,
                "b_high_sigmoid_fit":0.5,
                "c_high_sigmoid_fit":0.1,
                "d_high_sigmoid_fit":5000,
            }

            params, *_ = curve_fit(
                sigmoid,
                elapsed_time,
                contrast_values,
                p0=[all_params[k] for k in ("a0_sigmoid_fit", "b0_sigmoid_fit", "c0_sigmoid_fit","d0_sigmoid_fit")],
                bounds=([all_params[k] for k in ("a_low_sigmoid_fit", "b_low_sigmoid_fit","c_low_sigmoid_fit","d_low_sigmoid_fit")], 
                        [all_params[k] for k in ("a_high_sigmoid_fit", "b_high_sigmoid_fit", "c_high_sigmoid_fit","d_high_sigmoid_fit")]),
                maxfev=max_func_eval,
            )

            ss_res = np.sum((contrast_values - sigmoid(elapsed_time, *params))**2)
            ss_tot = np.sum((contrast_values - np.mean(contrast_values))**2)
            r2 = 1 - ss_res / ss_tot
            all_params['r2_sigmoid_fit'] = r2
            all_params['a_sigmoid_fit'] = params[0]
            all_params['b_sigmoid_fit'] = params[1]
            all_params['c_sigmoid_fit'] = params[2]
            all_params['d_sigmoid_fit'] = params[3]

            if r2 > 0.9:
                for key, value in all_params.items():
                    statement = f"""insert IGNORE into analyses_data (analysis_id, timeseries_id, property, value) values('{analysis_id}','{timeseries_id}', '{key}','{value}');"""
                    # db.execute(statement)
                    print(statement) # Import manually 

        except Exception as err:
            pass
