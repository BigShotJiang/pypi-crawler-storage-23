from __future__ import annotations
from dcclab.database import MySQLDatabase
import numpy as np
from pathlib import Path
import re
from typing import Iterable, List


class CheeseDB(MySQLDatabase):
    def __init__(self, *args, **kwargs):
        if 'databaseURL' not in kwargs:
            databaseURL = 'mysql+ssh://bliq@cafeine2.crulrg.ulaval.ca/bliq:bliq@bliqdb.local/cheese'
            kwargs['databaseURL'] = databaseURL

        super().__init__(*args, **kwargs)

    @property
    def sites(self):
        self.execute("select site_id from sites order by site_id")
        return self.fetchAll()

    @property
    def locations(self):
        self.execute("select location_id from locations order by location_id")
        return self.fetchAll()

    @property
    def probes(self):
        self.execute("select * from probes order by probe_id")
        return self.fetchAll()

    @property
    def timeseries(self):
        self.execute("select * from timeseries order by timeseries_id")
        return self.fetchAll()

    @property
    def timeseries_ids(self):
        self.execute("select timeseries_id from timeseries order by timeseries_id")
        for row in self.fetchAll():
            yield row['timeseries_id']

    def timeseries_data(self, timeseries_id, **kwargs):
        self.execute(f"select * from timeseries_data where timeseries_id='{timeseries_id}' order by timestamp")
        return self.fetchAll()

    def timeseries_with_missing_data(self):
        self.execute(f'SELECT ts.timeseries_id FROM timeseries ts WHERE ts.timeseries_id NOT IN (SELECT UNIQUE td.timeseries_id FROM timeseries_data td);')
        for record in self.fetchAll():
            yield record['timeseries_id']

    def timeseries_with_missing_logs(self):
        self.execute(f'SELECT ts.timeseries_id FROM timeseries ts WHERE ts.timeseries_id NOT IN (SELECT UNIQUE logs.timeseries_id FROM logs);')
        for record in list(self.fetchAll()):
            yield record['timeseries_id']

    def contrasts(self, timeseries_id, **kwargs):
        self.execute(f"select timestamp, contrast_mean, contrast_max from timeseries_data where timeseries_id='{timeseries_id}' order by timestamp")
        rows = self.fetchAll()

        n_rows = len(rows)
        contrasts = np.zeros(shape=(n_rows, 2, ))
        if n_rows == 0:
            return contrasts

        first_row = rows[0]
        start_timestamp = float(rows[0]['timestamp'])

        for i, row in enumerate(rows):
            contrasts[i,0] = float(row['timestamp'])-start_timestamp
            contrasts[i,1] = float(row['contrast_max'])

        return contrasts

    def contrasts_stats(self, timeseries_id, **kwargs):
        self.execute(f"select AVG(contrast_mean) as mean, STDDEV_POP(contrast_mean) as std from timeseries_data where timeseries_id='{timeseries_id}' order by timestamp")
        return self.fetchAll()

    def find_matching_files(self, root: str | Path, pattern: str, flags: int = 0, recursive: bool = True) -> Path:
        """
        Return full file paths under `root` whose POSIX-style full path matches `pattern`.
        The regex is tested against the full path (e.g., '.../dir/sub/file.csv').
        """
        root = Path(root)
        rx = re.compile(pattern, flags)
        it: Iterable[Path] = root.rglob("*") if recursive else root.iterdir()
        out: List[Path] = []
        for p in it:
            if p.is_file():
                full = p.as_posix()  # normalize separators so regex is predictable
                match = rx.search(full)
                if match is not None:
                    groups = match.groupdict()
                    groups.update({'filepath':p.resolve(),'filename':p.name})
                    out.append( groups)
        return out

    def find_acquisition_directories(self, root: str | Path) -> Path:
        """
        Yield parent directories of CSV files matching acquisition data patterns.
        """
        root = Path(root)
        matching_log_files = self.find_matching_files(root=root, pattern=r"[all_data|contrast].*?csv")
        for match in matching_log_files:
            yield Path(match['filepath']).parent
