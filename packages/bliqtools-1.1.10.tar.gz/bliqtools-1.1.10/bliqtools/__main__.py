"""
bliqtools CLI — explore cheese probe data from the command line.

Prerequisites:
    The cheese database is on a remote server behind an SSH gateway.
    Before using the 'db' or 'import' commands, open an SSH tunnel:

        ssh cafeine2.crulrg.ulaval.ca -l bliq -L3307:bliqdb.local:3306

    This forwards local port 3307 to the remote MySQL server (bliqdb:3306).
    Keep this terminal open while using the commands below.

Usage:
    python -m bliqtools db [URL]
    python -m bliqtools storage [ROOT] [--limit N]
    python -m bliqtools import [ROOT] [URL] [--limit N] [--sql]

Examples:
    # Show database summary (uses default tunnel on port 3307)
    python -m bliqtools db

    # Scan remote storage for timeseries (uses default ssh://bliq-cheese)
    python -m bliqtools storage
    python -m bliqtools storage --limit 5

    # Scan local storage instead
    python -m bliqtools storage /data/cheese/cheese_data

    # Compare disk vs database and show missing timeseries
    python -m bliqtools import

    # Generate SQL import statements for missing timeseries
    python -m bliqtools import --sql
"""

import argparse
import sys

DEFAULT_DB_URL = "mysql://bliq@127.0.0.1:3307/cheese"
DEFAULT_STORAGE_ROOT = "ssh://bliq-cheese/home/bliq/cheese/cheese_data"


def cmd_db(args):
    """Connect to CheeseDB and display a summary."""
    from bliqtools.cheese.cheesedb import CheeseDB

    try:
        db = CheeseDB(databaseURL=args.url)
    except Exception as e:
        print(f"Cannot connect to database at {args.url}: {e}", file=sys.stderr)
        print(
            "\nMake sure the SSH tunnel is open:\n"
            "  ssh cafeine2.crulrg.ulaval.ca -l bliq -L3307:bliqdb.local:3306",
            file=sys.stderr,
        )
        sys.exit(1)

    sites = db.sites
    probes = db.probes
    timeseries = list(db.timeseries_ids)

    print(f"Database: {args.url}")
    print(f"  Sites:      {len(sites)}")
    print(f"  Probes:     {len(probes)}")
    print(f"  Timeseries: {len(timeseries)}")

    if timeseries and not args.quiet:
        print(f"\nFirst 5 timeseries:")
        for tid in timeseries[:5]:
            stats = db.contrasts_stats(tid)
            if stats and stats[0]['mean'] is not None:
                mean = float(stats[0]['mean'])
                std = float(stats[0]['std'])
                print(f"  {tid}")
                print(f"    contrast mean={mean:.4f}, std={std:.4f}")
            else:
                print(f"  {tid}  (no data)")


def cmd_storage(args):
    """Scan local or remote storage and list discovered timeseries."""
    root = args.root

    if root.startswith("ssh://"):
        from bliqtools.cheese.importhelper import RemoteStorage

        rest = root[len("ssh://"):]
        ssh_host, remote_root = rest.split("/", 1)
        storage = RemoteStorage(ssh_host=ssh_host, root="/" + remote_root, limit=args.limit)
    else:
        from bliqtools.cheese.importhelper import Storage

        storage = Storage(root=root, limit=args.limit)

    ids = storage.timeseries_ids
    print(f"\nTimeseries discovered: {len(ids)}")

    if not args.quiet:
        for tid in ids[:10]:
            info = storage.timeseries_info(tid)
            probe = info.get("probe_id", "?")
            date = info.get("date", "?")
            size = info.get("size_kb", 0)
            print(f"  probe={probe}  date={date}  size={size} KB")
            print(f"    {tid}")

        if len(ids) > 10:
            print(f"  ... and {len(ids) - 10} more")


def cmd_import(args):
    """Compare storage against the database and report missing timeseries."""
    from bliqtools.cheese.importhelper import ImportHelper

    try:
        helper = ImportHelper(root=args.root, databaseURL=args.url, limit=args.limit)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        print(
            "\nMake sure the SSH tunnel is open:\n"
            "  ssh cafeine2.crulrg.ulaval.ca -l bliq -L3307:bliqdb.local:3306",
            file=sys.stderr,
        )
        sys.exit(1)

    missing = list(helper.missing_timeseries_id())
    print(f"\nMissing from database: {len(missing)}")

    if args.sql:
        for tid in missing:
            print(helper.sql_insert_timeseries(tid))
            sql = helper.sql_import_contrast_data(tid)
            if sql:
                print(sql)
    elif not args.quiet:
        for tid in missing[:10]:
            info = helper.storage.timeseries_info(tid)
            probe = info.get("probe_id", "?")
            date = info.get("date", "?")
            print(f"  {tid}")
            print(f"    probe={probe}  date={date}")

        if len(missing) > 10:
            print(f"  ... and {len(missing) - 10} more")


def main():
    parser = argparse.ArgumentParser(
        prog="python -m bliqtools",
        description="Explore cheese probe data: database, storage, and import tools.\n\n"
        "Prerequisites:\n"
        "  The database requires an SSH tunnel. Open one in a separate terminal:\n"
        "    ssh cafeine2.crulrg.ulaval.ca -l bliq -L3307:bliqdb.local:3306\n"
        "  Keep it open while using the 'db' or 'import' commands.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-q", "--quiet", action="store_true", help="Only print counts, skip details")
    sub = parser.add_subparsers(dest="command")

    # --- db ---
    p_db = sub.add_parser("db", help="Show database summary (sites, probes, timeseries)")
    p_db.add_argument("url", nargs="?", default=DEFAULT_DB_URL,
                       help=f"Database URL (default: {DEFAULT_DB_URL})")

    # --- storage ---
    p_st = sub.add_parser("storage", help="Scan local or remote storage for timeseries")
    p_st.add_argument("root", nargs="?", default=DEFAULT_STORAGE_ROOT,
                       help=f"Local path or ssh://host/path (default: {DEFAULT_STORAGE_ROOT})")
    p_st.add_argument("--limit", type=int, default=None, help="Max timeseries to scan")

    # --- import ---
    p_im = sub.add_parser("import", help="Compare storage vs database, find missing timeseries")
    p_im.add_argument("root", nargs="?", default=DEFAULT_STORAGE_ROOT,
                       help=f"Local path or ssh://host/path (default: {DEFAULT_STORAGE_ROOT})")
    p_im.add_argument("url", nargs="?", default=DEFAULT_DB_URL,
                       help=f"Database URL (default: {DEFAULT_DB_URL})")
    p_im.add_argument("--limit", type=int, default=None, help="Max timeseries to scan")
    p_im.add_argument("--sql", action="store_true", help="Print SQL import statements")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {"db": cmd_db, "storage": cmd_storage, "import": cmd_import}
    commands[args.command](args)


if __name__ == "__main__":
    main()
