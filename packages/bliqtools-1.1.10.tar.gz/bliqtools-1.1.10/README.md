# BliqTools
Cross-platform Python tools to manipulate any type of images and data from Bliq microscopes (and general).  Used by Bliq programmers internally and by the community.

# Project objectives
1. To collect often-used tools in a single package, easy to install.
2. To make manipulation of images task-oriented by removing the boiler-plate, generic code.
3. To let the community look at the code, and tailor it to their needs.

# Install as a package

See [INSTALL.md](INSTALL.md)

# Installing

Python 3.12 is the version used for development, and setuptools have evolved away from `setup.py`. The best method to install `bliqtools` is `pip`:

```shell
pip install git+https://github.com/BliqPhotonics/bliqtools.git
```

or clone and install from source:

```shell
git clone https://github.com/BliqPhotonics/bliqtools.git
cd bliqtools/
python3 -m pip install .
```

This will install with the current version of Python. You can then use it in scripts with:

```python
from bliqtools.testing import MemoryMonitor, Progress, TimeIt, Debuggable
from bliqtools.nirvana import FilePath
from bliqtools.bigimage import BigImage
from bliqtools.cheese.cheesedb import CheeseDB
from bliqtools.cheese.importhelper import ImportHelper, Storage, RemoteStorage
```

# Tools for managing metadata in Nirvana filenames
A very simple extension to `pathlib.Path`: an extension that will automatically extract all the metadata from the filename as described in Nirvana's software.
This metadata is then available using properties.  See the unittests at the end of the `nirvana.py` file.


# Cheese probe data: `CheeseDB`, `Storage`, `RemoteStorage`, and `ImportHelper`

Bliq's cheese probes continuously acquire speckle contrast data at various cheese production sites. All this data is stored in a MySQL database that tracks sites, probes, and timeseries of contrast measurements. The database is accessible via an SSH tunnel:

```shell
mysql -u bliq -pxxxxxx cheese -h bliqdb.local -P port_forward # or other IP address leading to it
```

The `bliqtools.cheese` package provides Python tools to query this database, discover timeseries data on disk (local or remote), and import new acquisitions.

## `CheeseDB`

`CheeseDB` is the main entry point to all the cheese probe data. It wraps `MySQLDatabase` to simplify access to the MySQL database without having to write SQL directly. It is still incomplete, but it already provides convenient access to the core tables:

- **`sites`**, **`locations`**, **`probes`**: list all sites, locations, and probes in the database.
- **`timeseries`** / **`timeseries_ids`**: list all recorded timeseries.
- **`contrasts(timeseries_id)`**: returns a numpy array of (time, contrast) pairs for a given timeseries.
- **`contrasts_stats(timeseries_id)`**: returns the mean and standard deviation of contrast for a timeseries.
- **`timeseries_with_missing_data()`** / **`timeseries_with_missing_logs()`**: find timeseries that are missing data or log entries.

```python
from bliqtools.cheese.cheesedb import CheeseDB

db = CheeseDB(databaseURL="mysql://bliq@127.0.0.1:3308/cheese")
print(f"Sites: {len(db.sites)}, Probes: {len(db.probes)}")

for tid in db.timeseries_ids:
    data = db.contrasts(tid)
    stats = db.contrasts_stats(tid)
    print(f"{tid}: {data.shape[0]} points, mean={stats[0]['mean']}")
```

## `Storage`

`Storage` scans a local root directory for timeseries data (identified by `contrast_curve.csv` files) and indexes them. It provides:

- **Discovery**: `find_all_timeseries_ids()` walks the directory tree and returns a dict mapping timeseries IDs to their paths.
- **Probe resolution**: `resolve_probe_id(timeseries_id)` determines which probe produced a timeseries by parsing the directory path. It supports multiple naming conventions across software versions (site-based legacy paths, CS-550 serial numbers, MAC addresses, etc.) using a versioned regex dictionary.
- **Metadata extraction**: `timeseries_info(timeseries_id)` returns a dict with the timeseries ID, directory, probe ID, date, and size on disk.
- **File access**: `filepath_contrast()`, `filepath_contrast_all_data()`, and `filepath_log()` return paths to specific data files within a timeseries directory.

```python
storage = Storage(root="/data/cheese/cheese_data", limit=10)
for tid in storage.timeseries_ids:
    info = storage.timeseries_info(tid)
    print(f"{tid}: probe={info['probe_id']}, date={info['date']}")
```

## `RemoteStorage`

`RemoteStorage` extends `Storage` to work with data on a remote host via SSH. It overrides the internal `_run()` method so that all shell commands (`find`, `ls`, `du`) are executed on the remote machine. Requires passwordless SSH access (e.g. via `ssh-agent` or key-based auth).

```python
storage = RemoteStorage(ssh_host="bliq-cheese", root="/home/bliq/cheese/cheese_data")
print(storage.timeseries_ids)  # lists timeseries on the remote host
```

## `ImportHelper`

`ImportHelper` ties together `Storage` (or `RemoteStorage`) and `CheeseDB` to find timeseries that exist on disk but are missing from the database, and generates the SQL statements needed to import them. It automatically selects local or remote storage based on the URL format.

- **`missing_timeseries_id()`**: yields timeseries IDs found on disk but absent from the database.
- **`sql_insert_timeseries(timeseries_id)`**: generates an `INSERT INTO timeseries` statement with date, probe ID, and timeseries ID.
- **`sql_import_contrast_data(timeseries_id)`**: generates a `LOAD DATA LOCAL INFILE` statement to bulk-import `contrast_curve.csv`.
- **`sql_import_contrast_all_data(timeseries_id)`**: same for `all_data.csv`.

```python
helper = ImportHelper(
    root="ssh://bliq-cheese/home/bliq/cheese/cheese_data",
    databaseURL="mysql://bliq@127.0.0.1:3308/cheese",
)

for tid in helper.missing_timeseries_id():
    print(helper.sql_insert_timeseries(tid))
    print(helper.sql_import_contrast_data(tid))
```

# Tools for very large images: `BigImage` previews

A class called `BigImage` is available to construct a very large image with small blocks.  The class will manage any memory issues and will save to disk the data if needed.  The main method is `get_preview(factor)` that provides a scaled down version for display. The construction of this preview is very fast (less than a second for a 1 GB image from 17x17 data blocks of size 2048x2048).

## Example usage
```python
from bliqtools.bigimage import BigImage

img = BigImage()
for i in range(10):
    for j in range(10):
        small_block = np.random.randint(
            0, 255, size=(2048, 2048), dtype=np.uint8
        )
        img.add_block(coords=(i * 2048, j * 2048), data=small_block)

preview = img.get_reduced_resolution_preview(factor=32)
plt.imshow(preview)
plt.show()
```


# Tools for unittesting

In `bliqtools.testing`, you will find these functions. You can also run the tests that are incorporated directly into the file by running it.

1. `Progress` is a simple class used with contextlib that can provide reasonable feedback.  The user provides total number of iterations and calls next() every iterations.
```python
        with Progress(self.total, description="Volume creation") as progress:
            for i,j,k in self.index_list:
                tile = self.tile(i,j,k)
                volume[i-1,j-1,k-1,:,:] = tile
                progress.next()
```

2. `TimeIt` is a simple class to time a small section of code:

```python
        with TimeIt(f"Get layers (single)"):
            stitcher.get_layers()
```

3. `Debuggable` can be used as a parent class to get useful debugging functions, like _dump_internals() or to see what variables have changed between calls.

```python
    def test_base_stitcher_still_working(self):
        stitcher = Stitcher(self.valid_root_dir, overlap=0.2, channel="Grayscale")
        self.assertIsNotNone(stitcher)
        # stitcher._save_state()
        stitcher.array_from_tiff_dirs()
        stitcher.make_z_stack()
        stitcher._dump_internals()
```

will print:

```
-- begin test_base_stitcher_still_working (/Users/dccote/GitHub/Stitching/stitcher.py @line 276)

   no_c_directory [<class 'str'>                           ] : /Users/dccote/Downloads/Test_maps
   app_directory  [<class 'NoneType'>                      ] : None
   overlap        [<class 'float'>                         ] : 0.2
   dtype          [<class 'numpy.dtypes.UInt8DType'>       ] : uint8
   channel        [<class 'str'>                           ] : Grayscale
   channels       [<class 'NoneType'>                      ] : None
   start_memory   [<class 'int'>                           ] : 8276803584
   save_name      [<class 'NoneType'>                      ] : None
   array_paths    [<class 'list'>                          ] : []
   sorted_files   [<class 'list'>                          ] : len=945
   use_zarr_arrays[<class 'bool'>                          ] : False
   og_arrays      [<class 'NoneType'>                      ] : None
   z_stacks       [<class 'numpy.ndarray'>                 ] : shape=(5, 740, 2780)

-- end test_base_stitcher_still_working (/Users/dccote/GitHub/Stitching/stitcher.py @line 276)
```


4. `MemoryMonitor` can monitor memory in a separate thread during a long calculation to provide insight on performance.  It will print out the time and memory available when done:

```python
        with MemoryMonitor(self.id()) as monitor:
            stitcher = ArrayStitcher(volume_kji=volume)
            with TimeIt(f"Save Zarr {volume_shape}"):
                stitcher.save("/tmp/test-zarr.tif")

```
and can be used to provide a graph of memory available vs time:

<img width="757" alt="image" src="https://github.com/user-attachments/assets/231d13d6-5202-45c8-8855-4c42bcc0c55e">

