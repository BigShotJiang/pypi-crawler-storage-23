"""
Lock management for preventing concurrent operations.

Provides two types of locks:
1. Record-level locks: Lock specific records (uses platform lm_locks table)
2. Operation-level locks: Lock entire operations globally (requires custom collection)

Available functions:
    claim_record_locks()    - Lock specific records for processing
    release_record_locks()  - Release previously claimed record locks
    acquire_operation_lock() - Lock an entire operation (NOT YET IMPLEMENTED)
    release_operation_lock() - Release operation lock (NOT YET IMPLEMENTED)
    operation_lock()        - Context manager for operation locks (NOT YET IMPLEMENTED)

Example:
    >>> from lumera import locks
    >>> result = locks.claim_record_locks("export", "deposits", ["dep_1", "dep_2"])
    >>> for id in result["claimed"]:
    ...     process(id)
    >>> locks.release_record_locks("export", record_ids=result["claimed"])
"""

__all__ = [
    "claim_record_locks",
    "release_record_locks",
    "acquire_operation_lock",
    "release_operation_lock",
    "operation_lock",
]

from contextlib import contextmanager
from typing import Any, Iterator

# Import platform lock primitives from the main SDK module
from .sdk import claim_locks as _claim_locks
from .sdk import release_locks as _release_locks


def claim_record_locks(
    job_type: str,
    collection: str,
    record_ids: list[str],
    *,
    ttl_seconds: int = 900,
    job_id: str | None = None,
) -> dict[str, Any]:
    """Claim record-level locks (using platform lm_locks).

    Prevents multiple workers from processing the same records concurrently.
    Uses the platform's built-in lm_locks table.

    Args:
        job_type: Workflow name (e.g., "deposit_processing")
        collection: Collection name
        record_ids: List of record IDs to lock
        ttl_seconds: Lock duration in seconds (default 900 = 15 minutes)
        job_id: Optional job identifier for grouping locks

    Returns:
        {
            "claimed": ["id1", "id2"],  # Successfully locked
            "skipped": ["id3"],         # Already locked by another process
            "ttl_seconds": 900
        }

    Example:
        >>> result = claim_record_locks(
        ...     job_type="export",
        ...     collection="deposits",
        ...     record_ids=["dep_1", "dep_2", "dep_3"]
        ... )
        >>> for dep_id in result["claimed"]:
        ...     process(dep_id)
        >>> # Release when done
        >>> release_record_locks("export", record_ids=result["claimed"])
    """
    return _claim_locks(
        job_type=job_type,
        collection=collection,
        record_ids=record_ids,
        ttl_seconds=ttl_seconds,
        job_id=job_id,
    )


def release_record_locks(
    job_type: str,
    *,
    collection: str | None = None,
    record_ids: list[str] | None = None,
    job_id: str | None = None,
) -> int:
    """Release record-level locks.

    Args:
        job_type: Workflow name (required)
        collection: Optional collection filter
        record_ids: Optional specific records to release
        job_id: Optional job identifier filter

    Returns:
        Number of locks released

    Example:
        >>> released = release_record_locks(
        ...     job_type="export",
        ...     record_ids=["dep_1", "dep_2"]
        ... )
        >>> print(f"Released {released} locks")
    """
    return _release_locks(
        job_type=job_type, collection=collection, record_ids=record_ids, job_id=job_id
    )


# Operation-level locks (simple key-value locks)
# Note: These would need a custom collection like "export_locks" to be implemented
# For now, providing the interface that should be implemented


def acquire_operation_lock(
    lock_name: str, *, ttl_seconds: int = 600, wait: bool = False, wait_timeout: int = 30
) -> bool:
    """Acquire an operation-level lock.

    For preventing concurrent execution of entire operations (like exports).
    Uses a simple key-value lock, not tied to specific records.

    Note: This requires a custom locks collection to be created.
    See the Charter Impact export_locks collection as an example.

    Args:
        lock_name: Unique lock identifier (e.g., "csv_export")
        ttl_seconds: Lock duration in seconds (default 600 = 10 minutes)
        wait: If True, wait for lock to become available
        wait_timeout: Max seconds to wait (if wait=True)

    Returns:
        True if lock acquired, False if already held (when wait=False)

    Raises:
        TimeoutError: If wait=True and timeout exceeded
        NotImplementedError: If operation locks collection doesn't exist

    Example:
        >>> if acquire_operation_lock("csv_export"):
        ...     try:
        ...         perform_export()
        ...     finally:
        ...         release_operation_lock("csv_export")
        ... else:
        ...     print("Export already in progress")
    """
    raise NotImplementedError(
        "Operation-level locks require a custom locks collection. "
        "Create a collection like 'operation_locks' with fields: "
        "lock_name (text, unique), held_by (text), acquired_at (date), expires_at (date). "
        "Then implement acquire/release using pb.search/create/delete."
    )


def release_operation_lock(lock_name: str) -> bool:
    """Release an operation-level lock.

    Args:
        lock_name: Lock identifier

    Returns:
        True if lock was released, False if wasn't held

    Raises:
        NotImplementedError: If operation locks collection doesn't exist

    Example:
        >>> release_operation_lock("csv_export")
    """
    raise NotImplementedError(
        "Operation-level locks require a custom locks collection. "
        "See acquire_operation_lock() for details."
    )


@contextmanager
def operation_lock(
    lock_name: str, *, ttl_seconds: int = 600, wait: bool = False, wait_timeout: int = 30
) -> Iterator[None]:
    """Context manager for operation locks.

    Args:
        lock_name: Lock identifier
        ttl_seconds: Lock duration in seconds
        wait: Wait for lock if held
        wait_timeout: Max wait time in seconds

    Raises:
        NotImplementedError: If operation locks collection doesn't exist
        TimeoutError: If wait=True and timeout exceeded

    Example:
        >>> with operation_lock("csv_export"):
        ...     perform_export()
        ...     # Lock automatically released on exit
    """
    # This would acquire the lock
    acquired = acquire_operation_lock(
        lock_name, ttl_seconds=ttl_seconds, wait=wait, wait_timeout=wait_timeout
    )

    if not acquired:
        raise RuntimeError(f"Failed to acquire lock: {lock_name}")

    try:
        yield
    finally:
        # Always release the lock
        release_operation_lock(lock_name)
