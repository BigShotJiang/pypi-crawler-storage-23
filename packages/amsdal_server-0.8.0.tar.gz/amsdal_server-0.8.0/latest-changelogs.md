## [v0.8.0](https://pypi.org/project/amsdal_server/0.8.0/) - 2026-02-25

### Added

- PII decryption support: `decrypt_pii` query parameter for object create, update, partial update, detail, and list endpoints

### Changed

- Update `amsdal` dependency to `0.8.*`