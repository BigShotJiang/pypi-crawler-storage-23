# Permissions System (Server)

## Overview

Server provides infrastructure for permission checking through an event-based architecture. Server doesn't contain checking logic - it only emits events and reacts to results. Specific implementation is delegated to plugins (e.g., auth plugin).

## Core Concepts

### Authentication vs Authorization

- **Authentication** - user identification (who are you?)
- **Authorization** - access rights verification (what can you do?)

### Permission Levels

#### Class-level (resource level)

Checks whether user can perform action on this resource type.

**Examples:**
- Can read `Post` models?
- Can execute `CreateOrder` transaction?

#### Object-level (object level)

Checks whether user can perform action on a specific object.

**Examples:**
- Can edit this specific `Post`?
- Can delete this `Comment`?

## Enums

### Action

```python
from enum import Enum

class Action(str, Enum):
    """Actions checked by the permissions system."""

    # For models and transactions
    READ = "read"        # list + detail

    # Models only
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

    # Transactions only
    EXECUTE = "execute"
```

### ResourceType

```python
class ResourceType(str, Enum):
    """Resource types."""

    MODELS = "models"
    TRANSACTIONS = "transactions"
```

## Events

### ClassAuthorizeEvent

Class/resource level authorization check.

```python
class ClassAuthorizeContext(EventContext):
    """Context for class-level authorization event."""

    request: Request                  # Starlette Request (user, auth, headers, client, ...)
    resource_type: ResourceType       # "models" or "transactions"
    resource_name: str                # Resource name ("Post", "CreateOrder")
    action: Action                    # Action (read, create, execute, ...)
    authorized: bool = True           # Check result
    error_message: str | None = None  # Custom error message (optional)

    class Config:
        arbitrary_types_allowed = True


class ClassAuthorizeEvent(Event[ClassAuthorizeContext]):
    """Event for class-level authorization check.

    Listeners use create_next() to modify context:

        return next_fn(context.create_next(
            listener_id=self.listener_id,
            authorized=False,
            error_message="Custom message",
        ))

    Available data from request:
    - request.user - user object
    - request.auth.scopes - scopes list
    - request.client.host - client IP address
    - request.headers - HTTP headers
    """
    pass
```

### ObjectAuthorizeEvent

Specific object level authorization check.

```python
class ObjectAuthorizeContext(EventContext):
    """Context for object-level authorization event."""

    request: Request                  # Starlette Request
    obj: Model                        # Object to check
    action: Action                    # Action (create, read, update, delete)
    update_data: dict | None = None   # Data being updated (for UPDATE action)
    authorized: bool = True           # Check result
    error_message: str | None = None  # Custom error message (optional)

    class Config:
        arbitrary_types_allowed = True


class ObjectAuthorizeEvent(Event[ObjectAuthorizeContext]):
    """Event for object-level authorization check.

    Listeners use create_next() to modify context:

        return next_fn(context.create_next(
            listener_id=self.listener_id,
            authorized=False,
            error_message="Custom message",
        ))

    Available data:
    - request.user - user object
    - request.auth.scopes - scopes list
    - obj - specific object to check
    - update_data - data being updated (for UPDATE action)
    """
    pass
```

## Server Behavior

### Without listeners (no auth plugin)

If no listeners are subscribed to the event:
- `authorized` remains `True` (default)
- Public mode - everything is allowed

### When authorized=False

| Operation | Behavior |
|-----------|----------|
| List (models/transactions) | Resource is filtered from the list |
| Detail (models/transactions) | HTTP 404 Not Found |
| Create | HTTP 403 Forbidden |
| Update | HTTP 403 Forbidden |
| Delete | HTTP 403 Forbidden |
| Execute (transaction) | HTTP 403 Forbidden |

### error_message

If listener set `context.error_message`, this message will be used in the 403 response.
If `error_message` is not set, default is used: `"Permission denied"`.

```python
# Example in server
if not result.authorized:
    message = result.error_message or "Permission denied"
    raise HTTPException(status_code=403, detail=message)
```

### Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     REQUEST                                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Server: Emit ClassAuthorizeEvent                            │
│    context = ClassAuthorizeContext(                          │
│        request=request,                                      │
│        resource_type=ResourceType.MODELS,                    │
│        resource_name="Post",                                 │
│        action=Action.READ,                                   │
│        authorized=True                                       │
│    )                                                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Plugin Listeners (middleware chain)                         │
│    - Check permissions                                       │
│    - Use create_next() to modify authorized/error_message   │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Server: Check result                                        │
│    if not context.authorized:                                │
│        - List: filter out                                    │
│        - Detail: raise 404                                   │
│        - Other: raise 403                                    │
└─────────────────────────────────────────────────────────────┘
```

## Models - CRUD Operations

### Operations to Actions Mapping

| HTTP Method | Endpoint | Action |
|-------------|----------|--------|
| GET | /classes/ | READ (list) |
| GET | /classes/{name}/ | READ (detail) |
| GET | /objects/ | READ (list) |
| GET | /objects/{id}/ | READ (detail) |
| POST | /objects/ | CREATE |
| PUT/PATCH | /objects/{id}/ | UPDATE |
| DELETE | /objects/{id}/ | DELETE |

### Class-level Check

Performed for all operations:

```python
# Example for list
context = ClassAuthorizeContext(
    request=request,
    resource_type=ResourceType.MODELS,
    resource_name="Post",
    action=Action.READ,
)
result = EventBus.emit(ClassAuthorizeEvent, context)

if not result.authorized:
    # For list - filter out
    # For detail/create/update/delete - 403
```

### Object-level Check

Performed for operations with specific object (create, detail, update, delete):

| Operation | Object-level check |
|-----------|-------------------|
| Create    | Yes (before save) |
| Detail    | Yes               |
| Update    | Yes               |
| Delete    | Yes               |

#### Create (before save)

```python
# Example for create (object check before save)
object_item = model_class(**data)  # Object not yet saved
context = ObjectAuthorizeContext(
    request=request,
    obj=object_item,
    action=Action.CREATE,
)
result = EventBus.emit(ObjectAuthorizeEvent, context)

if not result.authorized:
    raise HTTPException(status_code=403, detail=result.error_message or "Permission denied")

# Only save if authorized
object_item.save()
```

#### Update

```python
# Example for update
context = ObjectAuthorizeContext(
    request=request,
    obj=post_instance,
    action=Action.UPDATE,
    update_data={"title": "New Title"},  # Data being updated
)
result = EventBus.emit(ObjectAuthorizeEvent, context)

if not result.authorized:
    raise HTTPException(status_code=403, detail=result.error_message or "Permission denied")
```

## Transactions

### Operations to Actions Mapping

| Endpoint | Action |
|----------|--------|
| GET /transactions/ | READ (list) |
| GET /transactions/{name}/ | READ (detail) |
| POST /transactions/{name}/execute/ | EXECUTE |

### Authorization

Transaction list and detail endpoints use `TransactionApi` with `PermissionsMixin` to perform class-level authorization checks, following the same pattern as models.

#### List Filtering

During list operation, each transaction is checked via `authorize_class(is_silent=True)`. Unauthorized transactions are silently filtered out — only those the user has access to are shown.

#### Detail

Detail endpoint also uses `authorize_class(is_silent=True)`. If the user is not authorized for a transaction, `authorize_class` returns `False`, the transaction is skipped, and a `TransactionNotFoundError` is raised — resulting in **HTTP 404 Not Found** (hides resource existence from unauthorized users).

#### Execute

Execute endpoint uses `authorize_class()` without `is_silent` (defaults to `False`). If the user is not authorized, `AmsdalAuthorizationError` is raised — resulting in **HTTP 403 Forbidden**.

### @allow_any Decorator

Transactions can be marked as publicly accessible using the `@allow_any` decorator from the auth plugin. This sets `__scopes__ = []` on the transaction function, which the `ClassAuthorizeListener` interprets as "no scope required" (public resource).

```python
from amsdal.contrib.auth.decorators import allow_any

@allow_any
def public_transaction():
    """Available to anyone, even without authentication."""
    return "public data"
```

`@require_auth` sets `__require_auth__ = True` on the transaction function. `ClassAuthorizeListener` checks this flag: authenticated users are allowed (scope not required), unauthenticated users are denied (same behavior as missing scope — filtered from list, 404 for detail, 403 for execute).

See the auth plugin documentation for details on `@allow_any`, `@require_auth`, and `@require_scopes` decorators.

## Model-level Object Permissions

Models can implement `has_object_permission` method to define custom object-level authorization logic:

```python
class Post(Model):
    user: User
    title: str

    def has_object_permission(
        self,
        user: Any,
        action: str,  # "create", "read", "update", "delete"
        update_data: dict | None = None,
    ) -> bool:
        """Check if user has permission on this specific object.

        Args:
            user: The user making the request
            action: The action being performed (create, read, update, delete)
            update_data: Data being updated (for UPDATE action)

        Returns:
            True if permission granted, False otherwise
        """
        if action == "create":
            # Check if user can create object with this data
            return self.user == user
        if action == "read":
            return True  # Anyone can read
        # Only owner can update/delete
        return self.user == user
```

## Data-level Validation

Business logic data validation (e.g., "post author must equal current user") is performed through `pre_save` / `post_save` model hooks. This is **not part of the permission system**.

```python
class Post(Model):
    user: User
    title: str

    def pre_save(self):
        # Business logic validation
        current_user = get_current_user()
        if self.user != current_user:
            raise ValidationError("Cannot create/edit post for another user")
```

## Plugin Integration

### What Plugin Should Implement

1. **Listener for ClassAuthorizeEvent**
   - Class-level authorization check
   - Use `create_next()` to set `authorized` and `error_message`

2. **Listener for ObjectAuthorizeEvent**
   - Object-level authorization check
   - Can call `obj.has_object_permission(user, action, update_data=update_data)` if method exists
   - Use `create_next()` to set `authorized` and `error_message`

3. **Permission Storage Mechanism** (optional)
   - How user permissions are stored
   - Permission format (scopes, roles, etc.)

### Middleware Pattern

Listeners work via middleware pattern:

```
Event emitted
    │
    ▼
Listener 1 ──► next_fn() ──► Listener 2 ──► next_fn() ──► ... ──► Result
```

Each listener can:
- Create new context with `create_next()` modifying `authorized`/`error_message`
- Call `next_fn(context)` to pass forward
- Stop chain (don't call `next_fn`) or raise exception

## Errors

### AmsdalAuthorizationError

```python
class AmsdalAuthorizationError(Exception):
    """Raised when user doesn't have permission for action."""

    def __init__(
        self,
        action: Action,
        resource_name: str,
        error_message: str | None = None,
    ):
        self.action = action
        self.resource_name = resource_name
        self.error_message = error_message
        message = error_message or f"Permission denied for {action.value} on {resource_name}"
        super().__init__(message)
```

## Usage Example in Server

```python
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin


class PermissionsMixin:
    """Mixin for permission checks in endpoints."""

    @classmethod
    async def authorize_class(
        cls,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
    ) -> None:
        """Class-level authorization check.

        Raises:
            AmsdalAuthorizationError: If not authorized
        """
        ...

    @classmethod
    async def authorize_object(
        cls,
        obj: Model,
        action: Action,
        *,
        is_silent: bool = False,
        update_data: dict | None = None,
    ) -> bool:
        """Object-level authorization check.

        Args:
            obj: The object being accessed
            action: The action being performed
            is_silent: If True, return bool instead of raising exception
            update_data: Data being updated (for UPDATE action)

        Returns:
            True if authorized, False if not (when is_silent=True)

        Raises:
            AmsdalAuthorizationError: If not authorized and is_silent=False
        """
        ...
```