"""Registry for plugin-extended response models.

This module provides a mechanism for plugins to register extended versions
of base response models, enabling SOLID-compliant extensibility without
coupling the core server to plugin-specific fields.

Usage:
    # In plugin's on_setup():
    ResponseModelRegistry.register('ColumnInfo', ExtendedColumnInfo)

    # In server code (column_response.py):
    ColumnInfo = ResponseModelRegistry.get('ColumnInfo', ColumnInfo)
"""

from typing import ClassVar
from typing import TypeVar

from pydantic import BaseModel

TModel = TypeVar('TModel', bound=BaseModel)


class ResponseModelRegistry:
    """Registry for plugins to register extended response models.

    Plugins can register extended versions of base models during initialization
    (in on_setup() hook). The server code retrieves the extended model if available,
    or falls back to the base model.

    This pattern allows plugins to extend response schemas without modifying
    core server code, while ensuring proper OpenAPI documentation generation.
    """

    _models: ClassVar[dict[str, type[BaseModel]]] = {}

    @classmethod
    def register(cls, name: str, model: type[BaseModel]) -> None:
        """Register an extended model.

        Args:
            name: Unique identifier for the model (e.g., 'ColumnInfo')
            model: Extended Pydantic model class
        """
        cls._models[name] = model

    @classmethod
    def get(cls, name: str, default: type[TModel]) -> type[TModel]:
        """Get registered model or return default.

        Args:
            name: Model identifier
            default: Default model class to use if not registered

        Returns:
            Registered extended model or default base model
        """
        return cls._models.get(name, default)  # type: ignore[return-value]

    @classmethod
    def is_registered(cls, name: str) -> bool:
        """Check if a model is registered.

        Args:
            name: Model identifier

        Returns:
            True if model is registered, False otherwise
        """
        return name in cls._models

    @classmethod
    def clear(cls) -> None:
        """Clear all registered models.

        Primarily used for testing purposes.
        """
        cls._models.clear()
