"""Test client with authentication helpers."""

from typing import Any
from unittest import mock

from fastapi.testclient import TestClient
from starlette.authentication import AuthCredentials
from starlette.authentication import BaseUser
from starlette.authentication import SimpleUser


class AuthenticatedUser(SimpleUser):
    """Test user with authentication flag."""

    @property
    def is_authenticated(self) -> bool:
        return True


class AmsdalTestClient(TestClient):
    """Test client with authentication helpers.

    Example:
        client = AmsdalTestClient(app)

        # Login as admin with full access
        client.login_as_admin()
        response = client.get('/api/users/')

        # Login with specific scopes
        client.force_authenticate(user='editor', scopes=['models.Post:read', 'models.Post:create'])
        response = client.get('/api/posts/')

        # Logout
        client.logout()
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._auth_patcher: Any = None
        self._force_user: BaseUser | None = None
        self._force_scopes: list[str] = []

    def force_authenticate(
        self,
        user: BaseUser | str | None = None,
        scopes: list[str] | None = None,
    ) -> None:
        """Force authentication with given user and scopes.

        Args:
            user: User object or username string. If None, clears authentication.
            scopes: List of scopes for authorization. Use ['*:*'] for full access.

        Example:
            client.force_authenticate(user='admin', scopes=['*:*'])
            client.force_authenticate(user=my_user, scopes=['models.Post:read'])
        """
        # Stop previous patcher
        if self._auth_patcher is not None:
            self._auth_patcher.stop()
            self._auth_patcher = None

        if user is None:
            self._force_user = None
            self._force_scopes = []
            return

        # Set user
        if isinstance(user, str):
            self._force_user = AuthenticatedUser(user)
        else:
            self._force_user = user

        self._force_scopes = scopes or []

        # Patch authentication backend
        force_user = self._force_user
        force_scopes = self._force_scopes

        async def mock_authenticate(
            self_backend: Any,  # noqa: ARG001
            conn: Any,  # noqa: ARG001
        ) -> tuple[AuthCredentials, BaseUser]:
            return AuthCredentials(force_scopes), force_user

        from amsdal_server.apps.common.authentication import AmsdalAuthenticationBackend

        self._auth_patcher = mock.patch.object(
            AmsdalAuthenticationBackend,
            'authenticate',
            mock_authenticate,
        )
        self._auth_patcher.start()

    def login_as_admin(self) -> None:
        """Login as admin with full access (scope *:*).

        Shortcut for force_authenticate(user='admin', scopes=['*:*']).
        """
        self.force_authenticate(user='admin', scopes=['*:*'])

    def login_as(
        self,
        user: BaseUser | str,
        scopes: list[str] | None = None,
    ) -> None:
        """Login as specific user with given scopes.

        Args:
            user: User object or username string.
            scopes: List of scopes. If None, user has no special permissions.
        """
        self.force_authenticate(user=user, scopes=scopes)

    def logout(self) -> None:
        """Clear authentication.

        Shortcut for force_authenticate(user=None).
        """
        self.force_authenticate(user=None)

    def __del__(self) -> None:
        """Cleanup patcher on deletion."""
        if self._auth_patcher is not None:
            self._auth_patcher.stop()
