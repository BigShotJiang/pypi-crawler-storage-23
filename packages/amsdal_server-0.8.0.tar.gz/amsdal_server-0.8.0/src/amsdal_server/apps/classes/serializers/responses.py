"""Response serializers for classes endpoints."""

from typing import TYPE_CHECKING

from amsdal_server.apps.common.serializers.table_response import _TableResponse
from amsdal_server.registry import ResponseModelRegistry

if TYPE_CHECKING:
    from amsdal_server.apps.common.serializers.column_response import ColumnInfo  # noqa: F401


class _ClassListResponse(_TableResponse):
    """Response for class list endpoint."""

    pass


ClassListResponse: type[_ClassListResponse] = ResponseModelRegistry.get('ClassListResponse', _ClassListResponse)
