"""Pre-response events for classes endpoints."""

from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from fastapi import Request

from amsdal_server.apps.classes.serializers.class_info import ClassInfo
from amsdal_server.apps.classes.serializers.responses import _ClassListResponse


class ClassListPreResponseContext(EventContext):
    """Context for class list pre-response event."""

    request: Request
    response: _ClassListResponse

    class Config:
        arbitrary_types_allowed = True


class ClassListPreResponseEvent(Event[ClassListPreResponseContext]):
    """Emitted before returning class list response."""

    pass


class ClassDetailPreResponseContext(EventContext):
    """Context for class detail pre-response event."""

    request: Request
    class_name: str
    response: ClassInfo

    class Config:
        arbitrary_types_allowed = True


class ClassDetailPreResponseEvent(Event[ClassDetailPreResponseContext]):
    """Emitted before returning class detail response."""

    pass
