from typing import Any

from fastapi import Depends
from fastapi import Response

from amsdal_server.apps.classes.events.pre_response import ClassListPreResponseContext
from amsdal_server.apps.classes.events.pre_response import ClassListPreResponseEvent
from amsdal_server.apps.classes.router import router
from amsdal_server.apps.classes.serializers.responses import ClassListResponse
from amsdal_server.apps.classes.services.classes_api import ClassesApi
from amsdal_server.apps.common.etag_cache import CacheContext
from amsdal_server.apps.common.etag_cache import get_cache
from amsdal_server.apps.common.event_utils import emit_event
from amsdal_server.apps.common.serializers.column_format import ColumnFormat
from amsdal_server.apps.common.serializers.column_response import ColumnInfo


@router.get('/api/classes/', response_model_exclude_none=True, response_model=ClassListResponse)
async def class_list(cache: CacheContext = Depends(get_cache)) -> Response:
    async def build() -> dict[str, Any]:
        class_items = await ClassesApi.get_classes()
        response = ClassListResponse(
            columns=[
                ColumnInfo(
                    key='class',
                    label='Class',
                    column_format=ColumnFormat(cellTemplate='ClassLinkTemplate'),
                ),
                ColumnInfo(key='count', label='Count'),
                ColumnInfo(key='properties', label='Properties'),
            ],
            total=len(class_items),
            rows=class_items,
        )

        context = ClassListPreResponseContext(
            request=cache.request,
            response=response,
        )
        result = await emit_event(ClassListPreResponseEvent, context)

        return result.response.model_dump()

    return await cache.resolve(build)
