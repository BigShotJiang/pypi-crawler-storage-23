from typing import Any

from fastapi import Depends
from fastapi import Response

from amsdal_server.apps.classes.events.pre_response import ClassDetailPreResponseContext
from amsdal_server.apps.classes.events.pre_response import ClassDetailPreResponseEvent
from amsdal_server.apps.classes.router import router
from amsdal_server.apps.classes.serializers.class_info import ClassInfo
from amsdal_server.apps.classes.services.classes_api import ClassesApi
from amsdal_server.apps.common.etag_cache import CacheContext
from amsdal_server.apps.common.etag_cache import get_cache
from amsdal_server.apps.common.event_utils import emit_event


@router.get('/api/classes/{class_name}/', response_model=ClassInfo)
async def get_class(
    class_name: str,
    cache: CacheContext = Depends(get_cache),
) -> Response:
    async def build() -> dict[str, Any]:
        response = await ClassesApi.get_class_by_name(class_name)

        context = ClassDetailPreResponseContext(
            request=cache.request,
            class_name=class_name,
            response=response,
        )
        result = await emit_event(ClassDetailPreResponseEvent, context)

        return result.response.model_dump()

    return await cache.resolve(build, key=class_name)
