from amsdal_models.classes.model import Model
from amsdal_utils.config.manager import AmsdalConfigManager

from amsdal_server.apps.classes.errors import ClassNotFoundError
from amsdal_server.apps.classes.mixins.column_info_mixin import ColumnInfoMixin
from amsdal_server.apps.classes.mixins.model_class_info import ModelClassMixin
from amsdal_server.apps.classes.serializers.class_info import ClassInfo
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_server.apps.common.utils import get_api_manager


class ClassesApi(PermissionsMixin, ModelClassMixin, ColumnInfoMixin):
    @classmethod
    def _is_async_mode(cls) -> bool:
        return AmsdalConfigManager().get_config().async_mode

    @classmethod
    async def get_classes(cls) -> list[ClassInfo]:
        if cls._is_async_mode():
            classes: list[Model] = await cls.get_class_objects_qs().aexecute()
        else:
            classes = cls.get_class_objects_qs().filter().execute()

        result: list[ClassInfo] = []
        for class_item in classes:
            class_info = await cls._build_class_info(class_item)
            if class_info:
                result.append(class_info)

        return result

    @classmethod
    async def get_class_by_name(cls, class_name: str) -> ClassInfo:
        if cls._is_async_mode():
            class_item = await cls.get_class_objects_qs().filter(_address__object_id=class_name).first().aexecute()
        else:
            class_item = cls.get_class_objects_qs().filter(_address__object_id=class_name).first().execute()

        if not class_item:
            msg = f'Class not found: {class_name}'
            raise ClassNotFoundError(class_name, msg)

        class_info = await cls._build_class_info(class_item)
        if not class_info:
            msg = f'Class not found: {class_name}'
            raise ClassNotFoundError(class_name, msg)

        return class_info

    @classmethod
    async def _build_class_info(cls, class_item: Model) -> ClassInfo | None:
        authorized = await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_item.object_id,
            action=Action.READ,
            is_silent=True,
        )
        if not authorized:
            return None

        model_class = cls.get_model_class(class_item)

        api_manager = get_api_manager(model_class)
        if cls._is_async_mode():
            class_properties = await cls.aget_class_properties_by_class_and_meta(class_item)
            count = await api_manager.latest().filter(_metadata__is_deleted=False).count().aexecute()
        else:
            class_properties = cls.get_class_properties_by_class_object(class_item)
            count = api_manager.latest().filter(_metadata__is_deleted=False).count().execute()

        return ClassInfo(
            **{
                'class': class_item.object_id,
                'count': count,
                'properties': class_properties,
            }
        )
