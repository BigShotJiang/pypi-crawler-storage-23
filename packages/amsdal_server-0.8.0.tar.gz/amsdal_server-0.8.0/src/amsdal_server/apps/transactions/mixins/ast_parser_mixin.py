import ast
import types
from collections.abc import Generator
from importlib.machinery import SourceFileLoader
from pathlib import Path
from typing import Any

from amsdal.configs.main import settings
from amsdal_utils.models.data_models.enums import CoreTypes

from amsdal_server.apps.transactions.serializers.transaction_item import TransactionItemSerializer
from amsdal_server.apps.transactions.serializers.transaction_property import DictTypeSerializer
from amsdal_server.apps.transactions.serializers.transaction_property import TransactionPropertySerializer
from amsdal_server.apps.transactions.serializers.transaction_property import TypeSerializer
from amsdal_server.apps.transactions.utils import is_transaction


class AstParserMixin:
    @classmethod
    def _get_type_name(cls, node: ast.expr) -> str | None:
        """Extract type name from AST node, handling both Name and Attribute nodes.

        - Name nodes (e.g., `List`) have an `id` attribute
        - Attribute nodes (e.g., `typing.List`) have an `attr` attribute
        """
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return node.attr
        return None

    @classmethod
    def get_transaction_definitions(cls) -> Generator[tuple[ast.FunctionDef | ast.AsyncFunctionDef, Path], None, None]:
        # Scan main transactions path
        transactions_path: Path = cls._get_transactions_path()
        yield from cls._iterate_module(transactions_path)

        # Scan contrib module transaction paths
        for contrib_path in cls._get_contrib_transaction_paths():
            yield from cls._iterate_module(contrib_path)

    @classmethod
    def _iterate_module(
        cls, module_path: Path
    ) -> Generator[tuple[ast.FunctionDef | ast.AsyncFunctionDef, Path], None, None]:
        if not module_path.exists():
            return

        elif module_path.is_dir():
            for file in module_path.iterdir():
                yield from cls._iterate_module(file)
        elif module_path.suffix == '.py':
            yield from cls._iterate_file(module_path)

    @classmethod
    def _iterate_file(
        cls, file_path: Path
    ) -> Generator[tuple[ast.FunctionDef | ast.AsyncFunctionDef, Path], None, None]:
        transactions_content = file_path.read_text()
        tree = ast.parse(transactions_content)

        for definition in ast.walk(tree):
            if not is_transaction(definition):
                continue

            yield definition, file_path  # type: ignore[misc]

    @classmethod
    def build_transaction_item(
        cls,
        definition: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> TransactionItemSerializer:
        transaction_item = TransactionItemSerializer(
            title=definition.name,
            properties={},
        )

        for arg in definition.args.args:
            if hasattr(arg.annotation, 'id'):
                transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                    title=arg.arg,
                    type=cls._normalize_type(arg.annotation.id),  # type: ignore[union-attr]
                )
            elif hasattr(arg.annotation, 'value'):
                type_name = cls._get_type_name(arg.annotation.value)  # type: ignore[union-attr]
                if type_name is not None and type_name.lower() == 'list':
                    slice_type_name = cls._get_type_name(arg.annotation.slice)  # type: ignore[union-attr]
                    transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                        title=arg.arg,
                        type=CoreTypes.ARRAY.value,
                        items=TypeSerializer(
                            type=cls._normalize_type(slice_type_name) if slice_type_name else CoreTypes.ANYTHING.value,
                        ),
                    )
                elif type_name is not None and type_name.lower() == 'dict':
                    key_type_name = cls._get_type_name(arg.annotation.slice.elts[0])  # type: ignore[union-attr]
                    value_type_name = cls._get_type_name(arg.annotation.slice.elts[1])  # type: ignore[union-attr]
                    key_type = cls._normalize_type(key_type_name) if key_type_name else CoreTypes.ANYTHING.value
                    val_type = cls._normalize_type(value_type_name) if value_type_name else CoreTypes.ANYTHING.value
                    transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                        title=arg.arg,
                        type=CoreTypes.DICTIONARY.value,
                        items=DictTypeSerializer(
                            key=TypeSerializer(type=key_type),
                            value=TypeSerializer(type=val_type),
                        ),
                    )
                elif type_name is not None and type_name.lower() == 'optional':
                    transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                        title=arg.arg,
                        type=CoreTypes.ANYTHING.value,
                    )
                else:
                    # Fallback for other complex annotations (e.g., qualified types like datetime.date)
                    transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                        title=arg.arg,
                        type=CoreTypes.ANYTHING.value,
                    )
            else:
                transaction_item.properties[arg.arg] = TransactionPropertySerializer(
                    title=arg.arg,
                    type=CoreTypes.ANYTHING.value,
                )

        return transaction_item

    @classmethod
    def _get_transactions_path(cls) -> Path:
        return settings.transactions_root_path

    @classmethod
    def _get_contrib_transaction_paths(cls) -> Generator[Path, None, None]:
        """
        Yields transaction directories from installed contrib modules.

        This method iterates through the configured contrib modules and yields
        their transaction directories if they exist.
        """
        import importlib

        for contrib_config in settings.CONTRIBS:
            # Extract package name from config (e.g., 'amsdal.contrib.auth.app.AuthAppConfig')
            # by removing '.app.ConfigClass' suffix
            package_name = contrib_config.rsplit('.', 2)[0]

            try:
                contrib_module = importlib.import_module(package_name)
                if hasattr(contrib_module, '__path__'):
                    contrib_package_path = Path(contrib_module.__path__[0])
                    transactions_path = contrib_package_path / 'transactions'

                    if transactions_path.exists() and transactions_path.is_dir():
                        yield transactions_path
            except ImportError:
                continue

    @classmethod
    def _normalize_type(cls, json_or_py_type: str) -> str:
        json_switcher = {
            CoreTypes.STRING.value: 'str',
            CoreTypes.NUMBER.value: 'float',
            CoreTypes.ANYTHING.value: 'Any',
            CoreTypes.BOOLEAN.value: 'bool',
            CoreTypes.BINARY.value: 'bytes',
            CoreTypes.ARRAY.value: 'list',
        }
        py_switcher = {
            'str': CoreTypes.STRING.value,
            'int': CoreTypes.NUMBER.value,
            'float': CoreTypes.NUMBER.value,
            'Any': CoreTypes.ANYTHING.value,
            'bool': CoreTypes.BOOLEAN.value,
            'bytes': CoreTypes.BINARY.value,
            'List': CoreTypes.ARRAY.value,
            'list': CoreTypes.ARRAY.value,
        }

        return json_switcher.get(json_or_py_type, py_switcher.get(json_or_py_type, json_or_py_type))

    @classmethod
    def load_transaction_function(
        cls,
        definition: ast.FunctionDef | ast.AsyncFunctionDef,
        file_path: Path,
    ) -> Any:
        """Load and return the transaction function from a file.

        Args:
            definition: AST function definition
            file_path: Path to the file containing the transaction

        Returns:
            The loaded transaction function
        """
        loader = SourceFileLoader(file_path.stem, str(file_path.absolute()))
        transaction_module = types.ModuleType(loader.name)
        loader.exec_module(transaction_module)
        return getattr(transaction_module, definition.name)
