"""Response serializers for transactions endpoints."""

from typing import TYPE_CHECKING

from amsdal_server.apps.common.serializers.table_response import _BaseTableResponse
from amsdal_server.apps.common.serializers.table_response import _TableResponse
from amsdal_server.registry import ResponseModelRegistry

if TYPE_CHECKING:
    from amsdal_server.apps.common.serializers.column_response import ColumnInfo  # noqa: F401


class _TransactionListResponse(_TableResponse):
    """Response for transaction list endpoint."""

    pass


class _TransactionDetailResponse(_BaseTableResponse):
    """Response for transaction detail endpoint.

    Note: Does not include 'total' field.
    Plugin can extend to add 'control' field via registry.
    """

    pass


TransactionListResponse: type[_TransactionListResponse] = ResponseModelRegistry.get(
    'TransactionListResponse',
    _TransactionListResponse,
)
TransactionDetailResponse: type[_TransactionDetailResponse] = ResponseModelRegistry.get(
    'TransactionDetailResponse',
    _TransactionDetailResponse,
)
