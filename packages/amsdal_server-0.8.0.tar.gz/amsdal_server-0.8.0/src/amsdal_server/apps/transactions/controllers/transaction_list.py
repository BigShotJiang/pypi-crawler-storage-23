from typing import Any

from fastapi import Depends
from fastapi import Response

from amsdal_server.apps.common.etag_cache import CacheContext
from amsdal_server.apps.common.etag_cache import get_cache
from amsdal_server.apps.common.event_utils import emit_event
from amsdal_server.apps.transactions.events.pre_response import TransactionDetailPreResponseContext
from amsdal_server.apps.transactions.events.pre_response import TransactionDetailPreResponseEvent
from amsdal_server.apps.transactions.events.pre_response import TransactionListPreResponseContext
from amsdal_server.apps.transactions.events.pre_response import TransactionListPreResponseEvent
from amsdal_server.apps.transactions.router import router
from amsdal_server.apps.transactions.serializers.responses import TransactionDetailResponse
from amsdal_server.apps.transactions.serializers.responses import TransactionListResponse
from amsdal_server.apps.transactions.services.transaction_api import TransactionApi


@router.get('/api/transactions/', response_model=TransactionListResponse)
async def transaction_list(cache: CacheContext = Depends(get_cache)) -> Response:
    async def build() -> dict[str, Any]:
        response = await TransactionApi.get_transactions()

        context = TransactionListPreResponseContext(
            request=cache.request,
            response=response,
        )
        result = await emit_event(TransactionListPreResponseEvent, context)

        return result.response.model_dump()

    return await cache.resolve(build)


@router.get('/api/transactions/{transaction_name}/', response_model=TransactionDetailResponse)
async def transaction_detail(
    transaction_name: str,
    cache: CacheContext = Depends(get_cache),
) -> Response:
    async def build() -> dict[str, Any]:
        response = await TransactionApi.get_transaction(transaction_name)

        context = TransactionDetailPreResponseContext(
            request=cache.request,
            transaction_name=transaction_name,
            response=response,
        )
        result = await emit_event(TransactionDetailPreResponseEvent, context)

        return result.response.model_dump()

    return await cache.resolve(build, key=transaction_name)
