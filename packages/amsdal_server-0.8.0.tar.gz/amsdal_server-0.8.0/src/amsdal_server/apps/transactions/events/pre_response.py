"""Pre-response events for transactions endpoints."""

from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from fastapi import Request

from amsdal_server.apps.transactions.serializers.responses import _TransactionDetailResponse
from amsdal_server.apps.transactions.serializers.responses import _TransactionListResponse


class TransactionListPreResponseContext(EventContext):
    """Context for transaction list pre-response event."""

    request: Request
    response: _TransactionListResponse

    class Config:
        arbitrary_types_allowed = True


class TransactionListPreResponseEvent(Event[TransactionListPreResponseContext]):
    """Emitted before returning transaction list response."""

    pass


class TransactionDetailPreResponseContext(EventContext):
    """Context for transaction detail pre-response event."""

    request: Request
    transaction_name: str
    response: _TransactionDetailResponse

    class Config:
        arbitrary_types_allowed = True


class TransactionDetailPreResponseEvent(Event[TransactionDetailPreResponseContext]):
    """Emitted before returning transaction detail response."""

    pass
