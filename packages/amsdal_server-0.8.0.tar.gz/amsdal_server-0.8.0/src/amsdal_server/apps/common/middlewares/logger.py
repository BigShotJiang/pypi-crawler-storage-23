import logging
import time
from collections.abc import MutableMapping
from typing import Any

from starlette.requests import Request
from starlette.routing import Match
from starlette.types import ASGIApp
from starlette.types import Receive
from starlette.types import Scope
from starlette.types import Send

logger = logging.getLogger('amsdal_server.http')


class LoggerMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return

        before_time = time.perf_counter()
        status_code = -1

        async def send_wrapper(message: MutableMapping[str, Any]) -> None:
            nonlocal status_code
            if message['type'] == 'http.response.start' and status_code == -1:
                status_code = message['status']
            await send(message)

        error: BaseException | None = None

        try:
            await self.app(scope, receive, send_wrapper)
        except BaseException as exc:
            error = exc
            raise
        finally:
            after_time = time.perf_counter()
            request = Request(scope)
            log = logger.error if error else logger.info
            log(
                'method=%s path=%s status=%s time=%.3f user=%s host=%s',
                request.method,
                _get_path_template(request),
                status_code,
                after_time - before_time,
                scope.get('user'),
                request.client.host if request.client else None,
            )


def _get_path_template(request: Request) -> str:
    for route in request.app.routes:
        match, _ = route.matches(request.scope)
        if match == Match.FULL:
            return route.path
    return request.url.path
