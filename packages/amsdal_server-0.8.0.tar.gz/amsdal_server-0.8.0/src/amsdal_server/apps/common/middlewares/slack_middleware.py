import asyncio
import logging
import traceback
from collections.abc import MutableMapping
from datetime import UTC
from datetime import datetime
from typing import Any

import httpx
from asgi_correlation_id.context import correlation_id
from starlette.requests import Request
from starlette.types import ASGIApp
from starlette.types import Receive
from starlette.types import Scope
from starlette.types import Send

logger = logging.getLogger(__name__)


class SlackNotificationMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        slack_webhook_url: str | None = None,
        environment: str = 'production',
        excluded_paths: list[str] | None = None,
        *,
        include_request_body: bool | None = None,
    ) -> None:
        self.app = app

        from amsdal_server.configs.main import settings

        self.slack_webhook_url = slack_webhook_url or settings.SLACK_WEBHOOK_URL
        self.environment = environment or settings.ENVIRONMENT
        self.include_request_body = (
            include_request_body if include_request_body is not None else settings.SLACK_INCLUDE_REQUEST_BODY
        )
        self.excluded_paths = excluded_paths or ['/health', '/metrics']
        self.app_name = settings.APP_NAME

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return

        if self.slack_webhook_url and self.include_request_body:
            body_chunks: list[bytes] = []

            async def buffered_receive() -> MutableMapping[str, Any]:
                message = await receive()

                if message['type'] == 'http.request':
                    body_chunks.append(message.get('body', b''))

                return message

            wrapped_receive: Receive = buffered_receive
        else:
            body_chunks = []
            wrapped_receive = receive

        try:
            await self.app(scope, wrapped_receive, send)
        except Exception as exc:
            request = Request(scope, receive=receive)
            request._body = b''.join(body_chunks)

            if not any(path in str(request.url) for path in self.excluded_paths):
                if self.slack_webhook_url:
                    asyncio.create_task(self._send_slack_notification(request, exc))  # noqa: RUF006

            raise

    async def _send_slack_notification(self, request: Request, exception: Exception) -> None:
        if not self.slack_webhook_url:
            return

        try:
            request_body = ''
            if self.include_request_body:
                try:
                    body = await request.body()
                    request_body = body.decode('utf-8')[:1000]
                except Exception:
                    logger.exception('Failed to read request body')
                    request_body = 'Could not read request body'

            exception_details = {
                'type': type(exception).__name__,
                'message': str(exception),
                'traceback': traceback.format_exc(),
            }

            def grab(hdr: str, default: str = 'unknown', max_len: int = 500) -> str:
                return request.headers.get(hdr, default)[:max_len]

            xff = request.headers.get('x-original-forwarded-for') or request.headers.get('x-forwarded-for')
            client_ip = xff.split(',')[0].strip() if xff else getattr(request.client, 'host', 'unknown')

            slack_message: dict[str, Any] = {
                'attachments': [
                    {
                        'color': 'danger',
                        'title': f'\U0001f6a8 Exception in {self.app_name} [{self.environment}]',
                        'fields': [
                            {'title': 'Environment', 'value': self.environment, 'short': True},
                            {
                                'title': 'Timestamp',
                                'value': datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S UTC'),
                                'short': True,
                            },
                            {'title': 'Method', 'value': request.method, 'short': True},
                            {'title': 'URL', 'value': str(request.url), 'short': True},
                            {'title': 'Exception Type', 'value': exception_details['type'], 'short': True},
                            {
                                'title': 'Exception Message',
                                'value': exception_details['message'][:500],
                                'short': False,
                            },
                            {'title': 'Client IP', 'value': client_ip, 'short': True},
                            {'title': 'User-Agent', 'value': grab('User-Agent'), 'short': False},
                            {'title': 'Referer', 'value': grab('Referer', default='none'), 'short': False},
                            {'title': 'Host Header', 'value': grab('Host', default='none'), 'short': True},
                            {'title': 'Request ID', 'value': correlation_id.get() or 'unknown', 'short': True},
                        ],
                    },
                    {
                        'color': 'warning',
                        'title': 'Traceback',
                        'text': f'```{exception_details["traceback"][:2000]}```',
                        'mrkdwn_in': ['text'],
                    },
                ]
            }

            if self.include_request_body and request_body:
                slack_message['attachments'][0]['fields'].append(
                    {'title': 'Request Body', 'value': f'```{request_body}```', 'short': False}
                )

            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.post(
                    self.slack_webhook_url, json=slack_message, headers={'Content-Type': 'application/json'}
                )
                if response.status_code != 200:  # noqa: PLR2004
                    logger.error('Failed to send Slack notification: %s', response.status_code)

        except Exception:
            logger.exception('Error sending Slack notification')
