from amsdal.context.manager import AmsdalContextManager
from starlette.requests import Request
from starlette.types import ASGIApp
from starlette.types import Receive
from starlette.types import Scope
from starlette.types import Send


class RequestContextMiddleware:
    """Stores the current request in AmsdalContextManager for use by authorization logic."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return

        AmsdalContextManager().add_to_context('request', Request(scope, receive=receive))
        await self.app(scope, receive, send)
