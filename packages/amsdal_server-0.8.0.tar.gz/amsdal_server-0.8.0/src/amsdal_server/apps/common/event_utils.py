"""Event utilities for emitting events based on async mode."""

from typing import TypeVar

from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import EventBus
from amsdal_utils.events.context import EventContext
from amsdal_utils.events.event import Event

TContext = TypeVar('TContext', bound=EventContext)


async def emit_event(event: type[Event[TContext]], context: TContext) -> TContext:
    """
    Emit an event using the appropriate method based on async mode.

    In async mode, uses EventBus.aemit() which calls ahandle() on listeners.
    In sync mode, uses EventBus.emit() which calls handle() on listeners.

    Args:
        event: The event class to emit
        context: The event context

    Returns:
        The resulting context after all listeners have processed it
    """
    if AmsdalConfigManager().get_config().async_mode:
        return await EventBus.aemit(event, context)

    return EventBus.emit(event, context)
