from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from fastapi import FastAPI


class RouterSetupContext(EventContext):
    app: FastAPI


class RouterSetupEvent(Event[RouterSetupContext]):
    """Event emitted after standard routes are registered.

    Use this event to:
    - Register custom routes via app.include_router()
    - Modify existing routes by replacing them in app.routes
    - Add route-related configuration

    Note: This event is always emitted synchronously via EventBus.emit(),
    so listeners must implement the sync handle() method.
    """

    pass


class MiddlewareSetupContext(EventContext):
    app: FastAPI


class MiddlewareSetupEvent(Event[MiddlewareSetupContext]):
    """Event emitted after standard middlewares are registered.

    Use this event to:
    - Add custom middleware via app.add_middleware()
    - Modify existing middleware configuration
    - Add middleware-related setup

    Note: This event is always emitted synchronously via EventBus.emit(),
    so listeners must implement the sync handle() method.
    """

    pass


class ServerStartupContext(EventContext):
    app: FastAPI


class ServerStartupEvent(Event[ServerStartupContext]):
    """Event emitted when the server starts up (in lifespan context).

    Use this event for initialization tasks like setting up database connections,
    loading configuration, or performing startup checks.

    Note: The event will be emitted via EventBus.emit() or EventBus.aemit()
    depending on async_mode, so implement the appropriate handler method.
    """

    pass


class ServerShutdownContext(EventContext):
    app: FastAPI


class ServerShutdownEvent(Event[ServerShutdownContext]):
    """Event emitted when the server shuts down (in lifespan context).

    Use this event for cleanup tasks like closing database connections,
    flushing caches, or performing graceful shutdown procedures.

    Note: The event will be emitted via EventBus.emit() or EventBus.aemit()
    depending on async_mode, so implement the appropriate handler method.
    """

    pass
