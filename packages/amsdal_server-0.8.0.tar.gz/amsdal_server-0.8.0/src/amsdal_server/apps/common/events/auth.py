from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from pydantic import Field
from starlette.authentication import BaseUser
from starlette.requests import HTTPConnection


class AuthenticateContext(EventContext):
    """Context for authentication event."""

    auth_header: str
    connection: HTTPConnection
    user: BaseUser | None = None
    scopes: list[str] = Field(default_factory=list)

    class Config:
        arbitrary_types_allowed = True


class AuthenticateEvent(Event[AuthenticateContext]):
    """Event emitted when authentication is requested.

    Listeners should:
    1. Decode the auth_header (e.g., JWT token)
    2. Find the corresponding user
    3. Set context.user to the authenticated user (or None if authentication fails)

    The connection is also available for accessing other request data if needed.
    """

    pass
