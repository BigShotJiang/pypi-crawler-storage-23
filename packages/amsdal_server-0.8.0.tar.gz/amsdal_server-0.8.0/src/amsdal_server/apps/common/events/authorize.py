from typing import Any

from amsdal_models.classes.model import Model
from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from starlette.requests import Request

from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType


class ClassAuthorizeContext(EventContext):
    """Context for class-level authorization event."""

    request: Request
    resource_type: ResourceType
    resource_name: str
    action: Action
    authorized: bool = True
    error_message: str | None = None

    class Config:
        arbitrary_types_allowed = True


class ClassAuthorizeEvent(Event[ClassAuthorizeContext]):
    """Event emitted when class-level authorization is requested.

    Listeners should:
    1. Check if the user has permission for the requested action on the resource
    2. Set context.authorized to False if permission is denied
    3. Optionally set context.error_message with a reason

    The request contains user information via request.user and scopes via request.auth.scopes.
    """

    pass


class ObjectAuthorizeContext(EventContext):
    """Context for object-level authorization event."""

    request: Request
    obj: Model
    action: Action
    update_data: dict[str, Any] | None = None
    authorized: bool = True
    error_message: str | None = None

    class Config:
        arbitrary_types_allowed = True


class ObjectAuthorizeEvent(Event[ObjectAuthorizeContext]):
    """Event emitted when object-level authorization is requested.

    Listeners should:
    1. Check if the user has permission for the requested action on the specific object
    2. Set context.authorized to False if permission is denied
    3. Optionally set context.error_message with a reason

    Object-level authorization typically calls has_object_permission() on the model.
    """

    pass
