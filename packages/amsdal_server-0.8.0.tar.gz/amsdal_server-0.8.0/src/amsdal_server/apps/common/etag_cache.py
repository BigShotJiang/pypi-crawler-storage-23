"""ETag-based caching with stale-while-revalidate pattern.

Usage:
    from amsdal_server.apps.common.etag_cache import CacheContext, get_cache

    @router.get('/api/items/')
    async def item_list(cache: CacheContext = Depends(get_cache)) -> Response:
        async def build():
            return ItemsResponse(...).model_dump()

        return await cache.resolve(build)

    @router.get('/api/items/{item_id}/')
    async def item_detail(item_id: str, cache: CacheContext = Depends(get_cache)) -> Response:
        async def build():
            return ItemResponse(...).model_dump()

        return await cache.resolve(build, key=item_id)
"""

import json
from collections import OrderedDict
from collections.abc import Awaitable
from collections.abc import Callable
from hashlib import md5
from typing import Any

from fastapi import BackgroundTasks
from fastapi import Query
from fastapi import Request
from fastapi import Response

from amsdal_server.apps.common.response import AmsdalJSONResponse


class EtagCache:
    """Per-endpoint cache storage with LRU eviction."""

    def __init__(self, max_size: int = 100) -> None:
        self.entries: OrderedDict[str, tuple[dict[str, Any], str]] = OrderedDict()
        self.refreshing: set[str] = set()
        self.max_size = max_size

    def get(self, key: str) -> tuple[dict[str, Any], str] | None:
        if key in self.entries:
            self.entries.move_to_end(key)
            return self.entries[key]
        return None

    def set(self, key: str, data: dict[str, Any], etag: str) -> None:
        if key in self.entries:
            self.entries.move_to_end(key)
        self.entries[key] = (data, etag)

        while len(self.entries) > self.max_size:
            self.entries.popitem(last=False)


class CacheContext:
    """Per-request cache context."""

    def __init__(
        self,
        cache: EtagCache,
        request: Request,
        background_tasks: BackgroundTasks,
        cache_control: int | None,
        route_path: str,
    ) -> None:
        self.request = request
        self._cache = cache
        self._background_tasks = background_tasks
        self._cache_control = cache_control
        self._route_path = route_path

    async def resolve(
        self,
        build_fn: Callable[[], Awaitable[dict[str, Any]]],
        key: str | None = None,
    ) -> Response:
        cache_key = f'{self._route_path}:{key}' if key else self._route_path
        request_etag = self.request.headers.get('if-none-match')

        cached = self._cache.get(cache_key)
        if cached is not None:
            _, stored_etag = cached
            if request_etag == stored_etag:
                if cache_key not in self._cache.refreshing:
                    self._cache.refreshing.add(cache_key)
                    self._background_tasks.add_task(self._refresh, cache_key, build_fn)
                return Response(status_code=304)

        data, etag = await self._build(cache_key, build_fn)

        headers: dict[str, str] = {'ETag': etag}
        if self._cache_control:
            headers['Cache-Control'] = f'public, max-age={self._cache_control}'

        return AmsdalJSONResponse(content=data, headers=headers)

    async def _build(
        self,
        cache_key: str,
        build_fn: Callable[[], Awaitable[dict[str, Any]]],
    ) -> tuple[dict[str, Any], str]:
        data = await build_fn()
        content_bytes = json.dumps(data, default=str).encode('utf-8')
        etag = md5(content_bytes).hexdigest()  # noqa: S324
        self._cache.set(cache_key, data, etag)
        return data, etag

    async def _refresh(
        self,
        cache_key: str,
        build_fn: Callable[[], Awaitable[dict[str, Any]]],
    ) -> None:
        try:
            await self._build(cache_key, build_fn)
        finally:
            self._cache.refreshing.discard(cache_key)


_caches: dict[str, EtagCache] = {}


async def get_cache(
    request: Request,
    background_tasks: BackgroundTasks,
    cache_control: int | None = Query(
        default=None,
        description='Cache-Control max-age value',
    ),
) -> CacheContext:
    """FastAPI dependency that provides cache context for the current request."""
    route = request.scope.get('route')
    route_path = route.path if route else request.url.path

    if route_path not in _caches:
        _caches[route_path] = EtagCache()

    return CacheContext(
        cache=_caches[route_path],
        request=request,
        background_tasks=background_tasks,
        cache_control=cache_control,
        route_path=route_path,
    )
