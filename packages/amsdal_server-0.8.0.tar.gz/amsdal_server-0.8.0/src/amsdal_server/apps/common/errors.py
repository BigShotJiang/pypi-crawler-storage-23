from amsdal_utils.errors import AmsdalError

from amsdal_server.apps.common.permissions.enums import Action


class AmsdalAuthorizationError(AmsdalError):
    def __init__(
        self,
        action: Action,
        resource_name: str,
        error_message: str | None = None,
    ) -> None:
        self.action = action
        self.resource_name = resource_name
        self.error_message = error_message

    def __str__(self) -> str:
        if self.error_message:
            return self.error_message
        return f'Authorization denied for {self.action.value} on {self.resource_name}'


class AmsdalTransactionError(AmsdalError):
    def __init__(self, transaction_name: str, error_message: str) -> None:
        self.transaction_name = transaction_name
        self.error_message = error_message

    def __str__(self) -> str:
        return self.error_message
