from enum import Enum


class Action(str, Enum):
    READ = 'read'
    CREATE = 'create'
    UPDATE = 'update'
    DELETE = 'delete'
    EXECUTE = 'execute'


class ResourceType(str, Enum):
    MODELS = 'models'
    TRANSACTIONS = 'transactions'
