import logging

from fastapi import Request
from fastapi import status
from fastapi.responses import JSONResponse

from amsdal_server.apps.common.errors import AmsdalAuthorizationError

logger = logging.getLogger(__name__)


async def authorization_error_handler(
    request: Request,  # noqa: ARG001
    exc: AmsdalAuthorizationError,
) -> JSONResponse:
    logger.info('Authorization error: %s', exc)

    return JSONResponse(
        status_code=status.HTTP_403_FORBIDDEN,
        content={'detail': str(exc)},
    )
