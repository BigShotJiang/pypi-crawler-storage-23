from amsdal.contrib.auth.errors import AuthenticationError as AmsdalAuthenticationError
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import EventBus
from starlette.authentication import AuthCredentials
from starlette.authentication import AuthenticationBackend
from starlette.authentication import AuthenticationError as StarletteAuthenticationError
from starlette.authentication import BaseUser
from starlette.authentication import UnauthenticatedUser
from starlette.requests import HTTPConnection
from starlette.responses import JSONResponse
from starlette.responses import Response

from amsdal_server.apps.common.events.auth import AuthenticateContext
from amsdal_server.apps.common.events.auth import AuthenticateEvent
from amsdal_server.configs.main import settings


class _AmsdalAuthError(StarletteAuthenticationError):
    def __init__(self, exc: AmsdalAuthenticationError) -> None:
        super().__init__(str(exc))
        self.code = type(exc).__name__
        self.is_mfa_required = type(exc).__name__ == 'MFARequiredError'


class AuthenticationErrorHandler:
    def __call__(self, conn: HTTPConnection, exc: StarletteAuthenticationError) -> Response:  # noqa: ARG002
        if isinstance(exc, _AmsdalAuthError):
            return JSONResponse(
                status_code=401,
                content={
                    'detail': str(exc),
                    'code': exc.code,
                    'is_mfa_required': exc.is_mfa_required,
                },
            )
        return JSONResponse(
            status_code=403,
            content={'detail': str(exc)},
        )


class AmsdalAuthenticationBackend(AuthenticationBackend):
    async def authenticate(self, conn: HTTPConnection) -> tuple[AuthCredentials, BaseUser] | None:
        credentials = AuthCredentials([])
        user: BaseUser = UnauthenticatedUser()

        if settings.AUTHORIZATION_HEADER in conn.headers:
            auth = conn.headers[settings.AUTHORIZATION_HEADER]
            context = AuthenticateContext(auth_header=auth, connection=conn)

            try:
                if AmsdalConfigManager().get_config().async_mode:
                    result = await EventBus.aemit(AuthenticateEvent, context)
                else:
                    result = EventBus.emit(AuthenticateEvent, context)
            except AmsdalAuthenticationError as exc:
                raise _AmsdalAuthError(exc) from exc

            if result.user:
                credentials = AuthCredentials(result.scopes)
                user = result.user

        return credentials, user
