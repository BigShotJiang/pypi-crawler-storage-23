import asyncio
from typing import Any

from amsdal.context.manager import AmsdalContextManager
from amsdal_models.classes.model import Model
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import EventBus
from starlette.requests import Request

from amsdal_server.apps.common.errors import AmsdalAuthorizationError
from amsdal_server.apps.common.events.authorize import ClassAuthorizeContext
from amsdal_server.apps.common.events.authorize import ClassAuthorizeEvent
from amsdal_server.apps.common.events.authorize import ObjectAuthorizeContext
from amsdal_server.apps.common.events.authorize import ObjectAuthorizeEvent
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType


class PermissionsMixin:
    @classmethod
    async def authorize_class(
        cls,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
        *,
        is_silent: bool = False,
    ) -> bool:
        """Check class-level authorization.

        Args:
            resource_type: The type of resource being accessed.
            resource_name: The name of the resource.
            action: The action being performed.
            is_silent: If True, return bool instead of raising exception.

        Returns:
            True if authorized, False if not authorized (when is_silent=True).
            Always returns True when authorized or no request context.

        Raises:
            AmsdalAuthorizationError: If not authorized and is_silent=False.
        """
        request = AmsdalContextManager().get_context().get('request')
        if not request:
            return True

        if AmsdalConfigManager().get_config().async_mode:
            authorized, error_message = await cls.acheck_class_authorization(
                request=request,
                resource_type=resource_type,
                resource_name=resource_name,
                action=action,
            )
        else:
            authorized, error_message = cls.check_class_authorization(
                request=request,
                resource_type=resource_type,
                resource_name=resource_name,
                action=action,
            )

        if not authorized:
            if is_silent:
                return False
            raise AmsdalAuthorizationError(
                action=action,
                resource_name=resource_name,
                error_message=error_message,
            )

        return True

    @classmethod
    async def authorize_object(
        cls,
        obj: Model,
        action: Action,
        *,
        is_silent: bool = False,
        update_data: dict[str, Any] | None = None,
    ) -> bool:
        """Check object-level authorization.

        Args:
            obj: The object being accessed.
            action: The action being performed.
            is_silent: If True, return bool instead of raising exception.
            update_data: Data being updated (for UPDATE actions). Can be mutated by has_object_permission.

        Returns:
            True if authorized, False if not authorized (when is_silent=True).
            Always returns True when authorized or no request context.

        Raises:
            AmsdalAuthorizationError: If not authorized and is_silent=False.
        """
        request = AmsdalContextManager().get_context().get('request')
        if not request:
            return True

        if AmsdalConfigManager().get_config().async_mode:
            authorized, error_message = await cls.acheck_object_authorization(
                request=request,
                obj=obj,
                action=action,
                update_data=update_data,
            )
        else:
            authorized, error_message = cls.check_object_authorization(
                request=request,
                obj=obj,
                action=action,
                update_data=update_data,
            )

        if not authorized:
            if is_silent:
                return False
            display_name = obj.display_name
            if asyncio.iscoroutine(display_name):
                display_name = await display_name
            raise AmsdalAuthorizationError(
                action=action,
                resource_name=display_name,
                error_message=error_message,
            )

        return True

    @classmethod
    def check_class_authorization(
        cls,
        request: Request,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
    ) -> tuple[bool, str | None]:
        context = ClassAuthorizeContext(
            request=request,
            resource_type=resource_type,
            resource_name=resource_name,
            action=action,
        )
        result = EventBus.emit(ClassAuthorizeEvent, context)
        return result.authorized, result.error_message

    @classmethod
    async def acheck_class_authorization(
        cls,
        request: Request,
        resource_type: ResourceType,
        resource_name: str,
        action: Action,
    ) -> tuple[bool, str | None]:
        context = ClassAuthorizeContext(
            request=request,
            resource_type=resource_type,
            resource_name=resource_name,
            action=action,
        )
        result = await EventBus.aemit(ClassAuthorizeEvent, context)
        return result.authorized, result.error_message

    @classmethod
    def check_object_authorization(
        cls,
        request: Request,
        obj: Model,
        action: Action,
        update_data: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        context = ObjectAuthorizeContext(
            request=request,
            obj=obj,
            action=action,
            update_data=update_data,
        )
        result = EventBus.emit(ObjectAuthorizeEvent, context)
        return result.authorized, result.error_message

    @classmethod
    async def acheck_object_authorization(
        cls,
        request: Request,
        obj: Model,
        action: Action,
        update_data: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        context = ObjectAuthorizeContext(
            request=request,
            obj=obj,
            action=action,
            update_data=update_data,
        )
        result = await EventBus.aemit(ObjectAuthorizeEvent, context)
        return result.authorized, result.error_message
