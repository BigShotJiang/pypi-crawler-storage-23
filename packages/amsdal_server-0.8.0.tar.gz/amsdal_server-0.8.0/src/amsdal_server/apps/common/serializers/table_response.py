"""Base table response models for API endpoints."""

from typing import Any

from amsdal_server.apps.common.serializers.base_serializer import SkipNoneBaseModel
from amsdal_server.apps.common.serializers.column_response import ColumnInfo
from amsdal_server.registry import ResponseModelRegistry


class _BaseTableResponse(SkipNoneBaseModel):
    """Base table response with columns and rows."""

    columns: list[ColumnInfo]  # type: ignore[valid-type]
    rows: list[Any]


class _TableResponse(_BaseTableResponse):
    """Table response with total count."""

    total: int


BaseTableResponse: type[_BaseTableResponse] = ResponseModelRegistry.get('BaseTableResponse', _BaseTableResponse)
TableResponse: type[_TableResponse] = ResponseModelRegistry.get('TableResponse', _TableResponse)
