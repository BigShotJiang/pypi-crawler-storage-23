"""Column info models with plugin extensibility support.

This module provides column information serializers with support for
plugin-based model extension through ResponseModelRegistry.
"""

from amsdal_server.apps.common.serializers.base_column_info import ColumnInfo as _ColumnInfo
from amsdal_server.registry import ResponseModelRegistry

# ColumnInfo can be extended by plugins through ResponseModelRegistry.
# Plugins register their extended model in on_setup():
#   ResponseModelRegistry.register('ColumnInfo', ExtendedColumnInfo)
ColumnInfo: type[_ColumnInfo] = ResponseModelRegistry.get('ColumnInfo', _ColumnInfo)
