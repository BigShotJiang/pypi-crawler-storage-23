"""Column info model for API responses.

This module defines the column information structure used by the server.
Plugins can extend this model via ResponseModelRegistry to add additional fields.
"""

from enum import Enum
from typing import Any

from amsdal_server.apps.common.serializers.base_serializer import SkipNoneBaseModel
from amsdal_server.apps.common.serializers.column_format import ColumnFormat
from amsdal_server.apps.common.serializers.option import Option
from amsdal_server.apps.common.serializers.validator import Validator


class FieldFilterInputType(str, Enum):
    SINGLE_SELECT = 'single_select'
    SINGLE_SELECT2 = 'single_select2'
    MULTI_SELECT = 'multi_select'
    MULTI_SELECT2 = 'multi_select2'
    TEXT = 'text'
    DATE = 'date'
    DATE_TIME = 'dateTime'
    NUMBER = 'number'


class FieldFilterControl(SkipNoneBaseModel):
    key: str
    type: FieldFilterInputType
    label: str | None = None
    placeholder: str | None = None
    value: Any | None = None
    options: list[Any] | None = None


class FieldFilter(SkipNoneBaseModel):
    type: str
    control: FieldFilterControl


class ColumnFilter(SkipNoneBaseModel):
    """Column filter configuration for filtering controls."""

    name: str | None = None
    label: str | None = None
    tooltip: str | None = None
    filters: list[FieldFilter] | None = None


class ColumnInfo(SkipNoneBaseModel):
    """Column information for API responses.

    Plugins can extend this model via ResponseModelRegistry
    to add additional fields (e.g., control for frontend_configs).
    """

    # Core metadata
    type: str | None = None
    key: str | None = None
    label: str | None = None
    description: str | None = None
    order: int | None = None

    # Options and validation
    options: list[Option] | None = None
    validation: list[Validator] | None = None

    # Display configuration
    column_format: ColumnFormat | None = None
    filters: ColumnFilter | None = None

    # Complex types support
    items: dict[str, Any] | None = None

    # Field properties
    read_only: bool | None = None
    required: bool | None = None

    value: str | None = None
    next_control: str | None = None
    head_control: str | None = None
    attributes: list['ColumnInfo'] | None = None
    array_type: str | None = None
    dict_type: str | None = None
    item_format: 'ColumnInfo | None' = None
