# mypy: disable-error-code="call-arg,arg-type"
import base64
from typing import Any

from amsdal_data.transactions.decorators import async_transaction
from amsdal_data.transactions.decorators import transaction
from amsdal_models.classes.class_manager import ClassManager
from amsdal_models.classes.errors import AmsdalUniquenessError
from amsdal_models.classes.errors import ObjectAlreadyExistsError
from amsdal_models.classes.fields.pii import get_crypto_service
from amsdal_models.classes.fields.pii import get_pii_fields
from amsdal_models.classes.model import Model
from amsdal_models.classes.relationships.constants import FOREIGN_KEYS
from amsdal_models.classes.relationships.constants import MANY_TO_MANY_FIELDS
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.models.data_models.address import Address
from amsdal_utils.models.data_models.reference import Reference
from pydantic import BaseModel

from amsdal_server.apps.classes.errors import ClassNotFoundError
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_server.apps.common.utils import import_class_model
from amsdal_server.apps.objects.mixins.object_data_mixin import ObjectDataMixin
from amsdal_server.apps.objects.utils import normalize_address


class BulkAddressBody(BaseModel):
    address: str


class BulkUpdateBody(BulkAddressBody):
    data: dict[str, Any]


class ObjectApi(PermissionsMixin, ObjectDataMixin):
    @classmethod
    def _is_async_mode(cls) -> bool:
        return AmsdalConfigManager().get_config().async_mode

    @classmethod
    async def create_object(
        cls,
        base_url: str,
        class_name: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
        decrypt_pii: bool = False,
    ) -> dict[str, Any]:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.CREATE,
        )

        model_class = cls._get_model_class(class_name)
        _data = cls._decode_bytes(data)
        object_item = model_class(**_data)

        await cls.authorize_object(object_item, Action.CREATE)
        await cls._authorize_nested_fields(object_item)

        try:
            if cls._is_async_mode():
                await object_item.asave(force_insert=True)
            else:
                object_item.save(force_insert=True)
        except ObjectAlreadyExistsError as e:
            msg = 'Object with the same ID already exists'
            raise ValueError(msg) from e
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        if decrypt_pii:
            await cls._decrypt_pii_single(object_item)

        return await cls.build_object_data(
            object_item,
            base_url=base_url,
            load_references=load_references,
            include_metadata=True,
        )

    @classmethod
    async def bulk_create_objects(
        cls,
        base_url: str,
        class_name: str,
        data: list[dict[str, Any]],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.CREATE,
        )

        model_class = cls._get_model_class(class_name)
        _data = cls._decode_bytes(data)

        object_items = []
        for object_data in _data:
            if '_object_id' in object_data:
                msg = 'Object ID cannot be provided for bulk create'
                raise ValueError(msg)
            object_items.append(model_class(**object_data))

        for object_item in object_items:
            await cls.authorize_object(object_item, Action.CREATE)
            await cls._authorize_nested_fields(object_item)

        try:
            if cls._is_async_mode():
                await model_class.objects.bulk_acreate(object_items, force_insert=True)
            else:
                model_class.objects.bulk_create(object_items, force_insert=True)
        except ObjectAlreadyExistsError as e:
            msg = 'Object with the same ID already exists'
            raise ValueError(msg) from e
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        return [
            await cls.build_object_data(
                object_item,
                base_url=base_url,
                load_references=load_references,
                include_metadata=True,
            )
            for object_item in object_items
        ]

    @classmethod
    async def validate_object(
        cls,
        class_name: str,
        data: dict[str, Any],
    ) -> None:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=class_name,
            action=Action.READ,
        )
        model_class = cls._get_model_class(class_name=class_name)
        model_class(**data)

    @classmethod
    async def update_object(
        cls,
        base_url: str,
        address: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
        decrypt_pii: bool = False,
    ) -> dict[str, Any]:
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.UPDATE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
            _metadata = await object_item.aget_metadata()
        else:
            object_item = qs.execute()
            _metadata = object_item.get_metadata()

        _data = cls._decode_bytes(data)
        await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

        updated_item = model_class(
            **_data,
            _metadata=_metadata,
            _object_id=object_item.object_id,
        )
        await cls._authorize_nested_fields(updated_item)

        try:
            if cls._is_async_mode():
                await updated_item.asave()
            else:
                updated_item.save()
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        if decrypt_pii:
            await cls._decrypt_pii_single(updated_item)

        return await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)

    @classmethod
    async def bulk_update_objects(
        cls,
        base_url: str,
        data: list[BulkUpdateBody],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        objects_to_update: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.UPDATE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_update.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )

            if cls._is_async_mode():
                object_item = await qs.aexecute()
                _metadata = await object_item.aget_metadata()
            else:
                object_item = qs.execute()
                _metadata = object_item.get_metadata()

            _data = cls._decode_bytes(data_item.data)
            await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

            _updated_item = model_class(
                **_data,
                _metadata=_metadata,
                _object_id=object_item.object_id,
            )
            await cls._authorize_nested_fields(_updated_item)
            objects_to_update[_address.class_name].append(_updated_item)

        if cls._is_async_mode():
            result_objects = await cls._async_bulk_update(objects_to_update)
        else:
            result_objects = cls._sync_bulk_update(objects_to_update)

        return [
            await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)
            for updated_item in result_objects
        ]

    @classmethod
    @transaction
    def _sync_bulk_update(cls, objects_to_update: dict[str, list[Model]]) -> list[Model]:
        result_objects = []
        for class_name, objects in objects_to_update.items():
            model_class = ClassManager().import_class(class_name)
            model_class.objects.bulk_update(objects)
            result_objects.extend(objects)
        return result_objects

    @classmethod
    @async_transaction
    async def _async_bulk_update(cls, objects_to_update: dict[str, list[Model]]) -> list[Model]:
        result_objects = []
        for class_name, objects in objects_to_update.items():
            model_class = ClassManager().import_class(class_name)
            await model_class.objects.bulk_aupdate(objects)
            result_objects.extend(objects)
        return result_objects

    @classmethod
    async def partial_update_object(
        cls,
        base_url: str,
        address: str,
        data: dict[str, Any],
        *,
        load_references: bool = False,
        decrypt_pii: bool = False,
    ) -> dict[str, Any]:
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.UPDATE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
        else:
            object_item = qs.execute()

        _data = cls._decode_bytes(data)
        await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

        for _field, _value in _data.items():
            if hasattr(object_item, _field):
                setattr(object_item, _field, _value)

        await cls._authorize_nested_fields(object_item)

        try:
            if cls._is_async_mode():
                await object_item.asave()
            else:
                object_item.save()
        except AmsdalUniquenessError as e:
            raise ValueError(str(e)) from e

        if decrypt_pii:
            await cls._decrypt_pii_single(object_item)

        return await cls.build_object_data(object_item, base_url=base_url, load_references=load_references)

    @classmethod
    async def bulk_partial_update_objects(
        cls,
        base_url: str,
        data: list[BulkUpdateBody],
        *,
        load_references: bool = False,
    ) -> list[dict[str, Any]]:
        objects_to_update: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.UPDATE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_update.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )

            if cls._is_async_mode():
                object_item = await qs.aexecute()
            else:
                object_item = qs.execute()

            _data = cls._decode_bytes(data_item.data)
            await cls.authorize_object(object_item, Action.UPDATE, update_data=_data)

            for _field, _value in _data.items():
                if hasattr(object_item, _field):
                    setattr(object_item, _field, _value)

            await cls._authorize_nested_fields(object_item)
            objects_to_update[_address.class_name].append(object_item)

        if cls._is_async_mode():
            result_objects = await cls._async_bulk_update(objects_to_update)
        else:
            result_objects = cls._sync_bulk_update(objects_to_update)

        return [
            await cls.build_object_data(updated_item, base_url=base_url, load_references=load_references)
            for updated_item in result_objects
        ]

    @classmethod
    async def delete_object(
        cls,
        address: str,
    ) -> None:
        address = normalize_address(address)
        _address = Address.from_string(address)

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.DELETE,
        )

        model_class = cls._get_model_class(_address.class_name)
        qs = model_class.objects.get(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if cls._is_async_mode():
            object_item = await qs.aexecute()
        else:
            object_item = qs.execute()

        await cls.authorize_object(object_item, Action.DELETE)

        if cls._is_async_mode():
            await object_item.adelete()
        else:
            object_item.delete()

    @classmethod
    async def bulk_delete_objects(cls, data: list[BulkAddressBody]) -> None:
        objects_to_delete: dict[str, list[Model]] = {}

        for data_item in data:
            _address = Address.from_string(data_item.address)
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=_address.class_name,
                action=Action.DELETE,
            )
            model_class = cls._get_model_class(_address.class_name)
            objects_to_delete.setdefault(_address.class_name, [])

            qs = model_class.objects.get(
                _metadata__is_deleted=False,
                _address__object_id=_address.object_id,
                _address__class_version=_address.class_version,
                _address__object_version=_address.object_version,
            )
            if cls._is_async_mode():
                object_item = await qs.aexecute()
            else:
                object_item = qs.execute()

            await cls.authorize_object(object_item, Action.DELETE)
            objects_to_delete[_address.class_name].append(object_item)

        if cls._is_async_mode():
            await cls._async_bulk_delete(objects_to_delete)
        else:
            cls._sync_bulk_delete(objects_to_delete)

    @classmethod
    @transaction
    def _sync_bulk_delete(cls, objects_to_delete: dict[str, list[Model]]) -> None:
        for class_name, objects in objects_to_delete.items():
            model_class = ClassManager().import_class(class_name)
            model_class.objects.bulk_delete(objects)

    @classmethod
    @async_transaction
    async def _async_bulk_delete(cls, objects_to_delete: dict[str, list[Model]]) -> None:
        for class_name, objects in objects_to_delete.items():
            model_class = ClassManager().import_class(class_name)
            await model_class.objects.bulk_adelete(objects)

    @classmethod
    async def _decrypt_pii_single(cls, obj: Model) -> None:
        service = get_crypto_service()
        pii_fields = get_pii_fields(type(obj))
        if not service or not pii_fields:
            return

        values = []
        field_names = []
        for field_name in pii_fields:
            value = getattr(obj, field_name, None)
            if value is not None:
                values.append(value)
                field_names.append(field_name)

        if values:
            decrypted = await service.adecrypt(values)
            for field_name, dec_value in zip(field_names, decrypted, strict=False):
                object.__setattr__(obj, field_name, dec_value)

    @classmethod
    def _get_model_class(cls, class_name: str) -> type[Model]:
        try:
            return import_class_model(class_name)
        except ImportError as e:
            raise ClassNotFoundError(class_name) from e

    @classmethod
    async def _authorize_nested_fields(cls, obj: Model) -> None:
        """Recursively authorize nested objects and references before save."""
        model_class = obj.__class__
        obj_dict = obj.__dict__

        fk_fields = set(getattr(model_class, FOREIGN_KEYS, []))

        # FK fields — access via __dict__ to bypass __getattribute__ auto-loading
        for fk in fk_fields:
            raw = obj_dict.get(fk)
            if raw is not None:
                await cls._authorize_nested_value(raw)

        # M2M fields
        for m2m_name in getattr(model_class, MANY_TO_MANY_FIELDS, None) or {}:
            values = obj_dict.get(f'_{m2m_name}_value')
            if values:
                for item in values:
                    await cls._authorize_nested_value(item)

        # Other fields that might contain nested models (dict/list with model values)
        for field_name in obj.model_fields_set:
            if field_name in fk_fields:
                continue
            raw = obj_dict.get(field_name)
            if raw is not None and isinstance(raw, (dict, list, set, tuple)):
                await cls._authorize_nested_value(raw)

    @classmethod
    async def _authorize_nested_value(cls, value: Any) -> None:
        """Recursively check a single value for nested Model/Reference instances."""
        if isinstance(value, Model):
            # Nested object → authorize CREATE + recurse
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=value.__class__.__name__,
                action=Action.CREATE,
            )
            await cls.authorize_object(value, Action.CREATE)
            await cls._authorize_nested_fields(value)

        elif isinstance(value, Reference):
            # Reference → authorize READ on referenced class + object
            class_name = value.ref.class_name
            await cls.authorize_class(
                resource_type=ResourceType.MODELS,
                resource_name=class_name,
                action=Action.READ,
            )
            # Load referenced object and check object-level permission
            if cls._is_async_mode():
                ref_obj = await value.aload()
            else:
                ref_obj = value.load()
            await cls.authorize_object(ref_obj, Action.READ)

        elif isinstance(value, (list, set, tuple)):
            for item in value:
                await cls._authorize_nested_value(item)

        elif isinstance(value, dict):
            for v in value.values():
                await cls._authorize_nested_value(v)

    @classmethod
    def _decode_bytes(cls, data: Any) -> Any:
        if isinstance(data, dict):
            return {key: cls._decode_bytes(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [cls._decode_bytes(item) for item in data]
        elif isinstance(data, str) and data.startswith('data:binary;base64, '):
            return base64.b64decode(data.replace('data:binary;base64, ', '').encode('utf-8'))
        return data
