from amsdal_models.classes.constants import FILE_CLASS_NAME
from amsdal_models.classes.model import Model
from amsdal_models.querysets.executor import LAKEHOUSE_DB_ALIAS
from amsdal_utils.config.manager import AmsdalConfigManager

from amsdal_server.apps.classes.mixins.model_class_info import ModelClassMixin
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_server.apps.common.utils import get_api_manager


class ObjectFileApi(PermissionsMixin, ModelClassMixin):
    @classmethod
    def _is_async_mode(cls) -> bool:
        return AmsdalConfigManager().get_config().async_mode

    @classmethod
    async def get_file(cls, object_id: str, object_version: str) -> Model | None:
        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=FILE_CLASS_NAME,
            action=Action.READ,
        )

        if cls._is_async_mode():
            model_class = await cls.async_get_model_class_by_name(FILE_CLASS_NAME)
        else:
            model_class = cls.get_model_class_by_name(FILE_CLASS_NAME)
        qs = get_api_manager(model_class).filter(_address__object_id=object_id)

        if object_version:
            qs = qs.using(LAKEHOUSE_DB_ALIAS).filter(_address__object_version=object_version)

        if cls._is_async_mode():
            obj = await qs.get_or_none().aexecute()
        else:
            obj = qs.get_or_none().execute()

        if obj:
            await cls.authorize_object(obj, Action.READ)

        return obj
