from amsdal_models.classes.class_manager import ClassManager
from amsdal_models.classes.constants import FILE_CLASS_NAME
from amsdal_models.classes.errors import AmsdalClassError
from amsdal_models.classes.model import Model
from amsdal_models.querysets.executor import LAKEHOUSE_DB_ALIAS
from amsdal_models.schemas.object_schema import model_to_object_schema
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.models.data_models.address import Address

from amsdal_server.apps.classes.errors import ClassNotFoundError
from amsdal_server.apps.classes.mixins.column_info_mixin import ColumnInfoMixin
from amsdal_server.apps.common.mixins.permissions_mixin import PermissionsMixin
from amsdal_server.apps.common.permissions.enums import Action
from amsdal_server.apps.common.permissions.enums import ResourceType
from amsdal_server.apps.common.utils import get_api_manager
from amsdal_server.apps.objects.mixins.object_data_mixin import ObjectDataMixin
from amsdal_server.apps.objects.serializers.responses import ObjectDetailResponse
from amsdal_server.apps.objects.utils import apply_version_to_address


class ObjectVersionsApi(PermissionsMixin, ColumnInfoMixin, ObjectDataMixin):
    @classmethod
    def _is_async_mode(cls) -> bool:
        return AmsdalConfigManager().get_config().async_mode

    @classmethod
    async def get_object_versions(
        cls,
        base_url: str,
        address: str,
        version_id: str = '',
        *,
        all_versions: bool = False,
        include_metadata: bool = True,
        file_optimized: bool = False,
        decrypt_pii: bool = False,
        select_related: list[str] | None = None,
    ) -> ObjectDetailResponse:  # type: ignore[valid-type]
        _address = Address.from_string(address)

        try:
            model_class = ClassManager().import_class(_address.class_name)
        except (AmsdalClassError, ImportError) as e:
            raise ClassNotFoundError(_address.class_name) from e

        await cls.authorize_class(
            resource_type=ResourceType.MODELS,
            resource_name=_address.class_name,
            action=Action.READ,
        )

        if cls._is_async_mode():
            class_properties = await cls.aget_class_properties(model_to_object_schema(model_class))
        else:
            class_properties = cls.get_class_properties(model_to_object_schema(model_class))

        _address = apply_version_to_address(
            _address,
            version_id=version_id or _address.object_version,
            all_versions=all_versions,
        )

        qs = get_api_manager(model_class).filter(
            _metadata__is_deleted=False,
            _address__object_id=_address.object_id,
            _address__class_version=_address.class_version,
            _address__object_version=_address.object_version,
        )

        if all_versions:
            qs = qs.using(LAKEHOUSE_DB_ALIAS)
            qs._select_related = False  # prevent schema version multiplication of LEFT JOINs

        if select_related:
            qs = qs.select_related(*select_related)

        is_optimized_file = model_class.__name__ == FILE_CLASS_NAME and file_optimized

        if is_optimized_file:
            qs = qs.only(['filename', 'size'])

        if decrypt_pii:
            qs = qs.decrypt_pii()

        if cls._is_async_mode():
            items: list[Model] = await qs.order_by('-_metadata__updated_at').aexecute()
        else:
            items = qs.order_by('-_metadata__updated_at').execute()

        if items:
            await cls.authorize_object(items[0], Action.READ)

        rows = []
        for item in items:
            rows.append(
                await cls.build_object_data(
                    item,
                    base_url=base_url,
                    include_metadata=include_metadata,
                    is_file_object=is_optimized_file,
                    is_from_lakehouse=all_versions,
                ),
            )

        return ObjectDetailResponse(
            columns=class_properties,
            rows=rows,
            total=len(rows),
        )
