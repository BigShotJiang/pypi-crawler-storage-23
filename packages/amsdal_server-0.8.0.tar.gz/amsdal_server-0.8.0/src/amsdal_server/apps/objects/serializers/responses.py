"""Response serializers for objects endpoints."""

from typing import TYPE_CHECKING

from amsdal_server.apps.common.serializers.table_response import _TableResponse
from amsdal_server.registry import ResponseModelRegistry

if TYPE_CHECKING:
    from amsdal_server.apps.common.serializers.column_response import ColumnInfo  # noqa: F401


class _ObjectListResponse(_TableResponse):
    """Response for object list endpoint."""

    pass


class _ObjectDetailResponse(_TableResponse):
    """Response for object detail endpoint."""

    pass


ObjectListResponse: type[_ObjectListResponse] = ResponseModelRegistry.get('ObjectListResponse', _ObjectListResponse)
ObjectDetailResponse: type[_ObjectDetailResponse] = ResponseModelRegistry.get(
    'ObjectDetailResponse',
    _ObjectDetailResponse,
)
