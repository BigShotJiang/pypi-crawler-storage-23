import urllib.parse
from typing import Any

from amsdal_utils.models.data_models.address import Address
from fastapi import Depends
from fastapi import Query
from fastapi import Response

from amsdal_server.apps.common.etag_cache import CacheContext
from amsdal_server.apps.common.etag_cache import get_cache
from amsdal_server.apps.common.event_utils import emit_event
from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseContext
from amsdal_server.apps.objects.events.pre_response import ObjectDetailPreResponseEvent
from amsdal_server.apps.objects.router import router
from amsdal_server.apps.objects.serializers.responses import ObjectDetailResponse
from amsdal_server.apps.objects.services.object_versions_api import ObjectVersionsApi
from amsdal_server.apps.objects.utils import normalize_address


@router.get('/api/objects/{address:path}/', response_model=ObjectDetailResponse)
async def object_detail(
    address: str,
    cache: CacheContext = Depends(get_cache),
    version_id: str = '',
    *,
    all_versions: bool = False,
    include_metadata: bool = True,
    file_optimized: bool = False,
    decrypt_pii: bool = False,
    select_related: str | None = Query(
        default=None,
        description='Comma-separated list of related fields to fetch',
        examples=['field1', 'field1,field2'],
    ),
) -> Response:
    normalized_address = normalize_address(urllib.parse.unquote(address))

    async def build() -> dict[str, Any]:
        _select_related = select_related.split(',') if select_related else None
        response = await ObjectVersionsApi.get_object_versions(
            base_url=str(cache.request.base_url),
            address=normalized_address,
            version_id=version_id,
            all_versions=all_versions,
            include_metadata=include_metadata,
            file_optimized=file_optimized,
            decrypt_pii=decrypt_pii,
            select_related=_select_related,
        )

        context = ObjectDetailPreResponseContext(
            request=cache.request,
            class_name=Address.from_string(normalized_address).class_name,
            address=normalized_address,
            response=response,
        )
        result = await emit_event(ObjectDetailPreResponseEvent, context)

        return result.response.model_dump()

    cache_key = f'{address}:{cache.request.url.query}'
    return await cache.resolve(build, key=cache_key)
