from typing import Any

from fastapi import Depends
from fastapi import Query
from fastapi import Response

from amsdal_server.apps.common.depends import get_fields_restrictions
from amsdal_server.apps.common.depends import get_filters
from amsdal_server.apps.common.etag_cache import CacheContext
from amsdal_server.apps.common.etag_cache import get_cache
from amsdal_server.apps.common.event_utils import emit_event
from amsdal_server.apps.common.serializers.fields_restriction import FieldsRestriction
from amsdal_server.apps.common.serializers.filter import Filter
from amsdal_server.apps.objects.events.pre_response import ObjectListPreResponseContext
from amsdal_server.apps.objects.events.pre_response import ObjectListPreResponseEvent
from amsdal_server.apps.objects.router import router
from amsdal_server.apps.objects.serializers.responses import ObjectListResponse
from amsdal_server.apps.objects.services.object_list_api import ObjectListApi


@router.get('/api/objects/', response_model_exclude_none=True, response_model=ObjectListResponse)
async def object_list(
    class_name: str,
    cache: CacheContext = Depends(get_cache),
    *,
    include_metadata: bool = True,
    include_subclasses: bool = False,
    load_references: bool = False,
    all_versions: bool = False,
    file_optimized: bool = False,
    decrypt_pii: bool = False,
    fields_restrictions: dict[str, FieldsRestriction] = Depends(get_fields_restrictions),
    filters: list[Filter] = Depends(get_filters),
    page: int = 1,
    page_size: int | None = Query(default=None),
    ordering: list[str] | None = Query(default=None),
    select_related: str | None = Query(
        default=None,
        description='Comma-separated list of related fields to fetch',
        examples=['field1', 'field1,field2'],
    ),
) -> Response:
    async def build() -> dict[str, Any]:
        _select_related = select_related.split(',') if select_related else None
        response = await ObjectListApi.fetch_objects(
            base_url=str(cache.request.base_url),
            class_name=class_name,
            filters=filters,
            fields_restrictions=fields_restrictions,
            include_metadata=include_metadata,
            include_subclasses=include_subclasses,
            load_references=load_references,
            all_versions=all_versions,
            file_optimized=file_optimized,
            decrypt_pii=decrypt_pii,
            page=page,
            page_size=page_size,
            ordering=ordering,
            select_related=_select_related,
        )

        context = ObjectListPreResponseContext(
            request=cache.request,
            class_name=class_name,
            response=response,
        )
        result = await emit_event(ObjectListPreResponseEvent, context)

        return result.response.model_dump()

    return await cache.resolve(build, key=str(cache.request.url.query))
