"""Pre-response events for objects endpoints."""

from amsdal_utils.events import Event
from amsdal_utils.events import EventContext
from fastapi import Request

from amsdal_server.apps.objects.serializers.responses import _ObjectDetailResponse
from amsdal_server.apps.objects.serializers.responses import _ObjectListResponse


class ObjectListPreResponseContext(EventContext):
    """Context for object list pre-response event."""

    request: Request
    class_name: str
    response: _ObjectListResponse

    class Config:
        arbitrary_types_allowed = True


class ObjectListPreResponseEvent(Event[ObjectListPreResponseContext]):
    """Emitted before returning object list response."""

    pass


class ObjectDetailPreResponseContext(EventContext):
    """Context for object detail pre-response event."""

    request: Request
    class_name: str
    address: str
    response: _ObjectDetailResponse

    class Config:
        arbitrary_types_allowed = True


class ObjectDetailPreResponseEvent(Event[ObjectDetailPreResponseContext]):
    """Emitted before returning object detail response."""

    pass
