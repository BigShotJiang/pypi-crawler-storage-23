import torch
import torch.nn as nn
from .b_spline import b_spline_basis, extend_grid

class LearnableActivation(nn.Module):
    """
    Learnable Activation Function parameterized by B-splines.
    This acts as a drop-in replacement for standard activation functions like ReLU or SiLU,
    but allows the network to learn arbitrary univariate functions per neuron.
    
    Formula: phi(x) = w_b * base_activation(x) + w_s * sum(c_k * B_k(x))
    """
    def __init__(self, num_features, grid_size=5, spline_order=3, base_activation=nn.SiLU, grid_range=[-1, 1]):
        super().__init__()
        self.num_features = num_features
        self.grid_size = grid_size
        self.spline_order = spline_order
        
        # Base activation
        self.base_activation = base_activation()
        self.base_weight = nn.Parameter(torch.ones(num_features))
        
        # Spline parameters
        self.spline_weight = nn.Parameter(torch.ones(num_features))
        
        # Initialize grid
        grid = torch.linspace(grid_range[0], grid_range[1], steps=grid_size + 1)
        grid = grid.unsqueeze(0).expand(num_features, grid_size + 1)
        grid = extend_grid(grid, k_extend=spline_order)
        self.register_buffer('grid', grid)
        
        # Spline coefficients: [num_features, grid_size + spline_order]
        # Initialized with small random values
        self.spline_coefs = nn.Parameter(torch.randn(num_features, grid_size + spline_order) * 0.1)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, num_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, num_features)
        """
        # Base activation pathway
        base_out = self.base_weight * self.base_activation(x)
        
        # Spline pathway
        # b_splines shape: (batch_size, num_features, grid_size + spline_order)
        b_splines = b_spline_basis(x, self.grid, k=self.spline_order)
        
        # Compute spline output: sum over basis functions
        # spline_coefs shape: (num_features, grid_size + spline_order)
        spline_out = torch.einsum('bfk,fk->bf', b_splines, self.spline_coefs)
        spline_out = self.spline_weight * spline_out
        
        return base_out + spline_out
