import torch

def extend_grid(grid, k_extend=0):
    """
    Extend the grid by k_extend points on both ends for B-spline evaluation.
    
    Args:
        grid (torch.Tensor): 2D tensor of shape (in_dim, G+1)
        k_extend (int): Number of points to extend on each side.
        
    Returns:
        torch.Tensor: Extended grid of shape (in_dim, G+1+2*k_extend)
    """
    h = (grid[:, [-1]] - grid[:, [0]]) / (grid.shape[1] - 1)
    
    for i in range(k_extend):
        grid = torch.cat([grid[:, [0]] - h, grid], dim=1)
        grid = torch.cat([grid, grid[:, [-1]] + h], dim=1)
        
    return grid

def b_spline_basis(x, grid, k=0):
    """
    Evaluate x on B-spline bases.
    
    Args:
        x (torch.Tensor): 2D tensor of shape (batch_size, in_dim)
        grid (torch.Tensor): 2D tensor of shape (in_dim, G+1+2k)
        k (int): Spline order.
        
    Returns:
        torch.Tensor: 3D tensor of shape (batch_size, in_dim, G+k)
    """
    x = x.unsqueeze(dim=2)
    grid = grid.unsqueeze(dim=0)
    
    if k == 0:
        value = (x >= grid[:, :, :-1]) * (x < grid[:, :, 1:])
    else:
        B_km1 = b_spline_basis(x[:, :, 0], grid=grid[0], k=k - 1)
        
        term1 = (x - grid[:, :, :-(k + 1)]) / (grid[:, :, k:-1] - grid[:, :, :-(k + 1)]) * B_km1[:, :, :-1]
        term2 = (grid[:, :, k + 1:] - x) / (grid[:, :, k + 1:] - grid[:, :, 1:(-k)]) * B_km1[:, :, 1:]
        value = term1 + term2
        
    value = torch.nan_to_num(value)
    return value
