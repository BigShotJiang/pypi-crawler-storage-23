import torch
import torch.nn as nn
from ..layers.pph_layer import PPHLayer

class PPHNet(nn.Module):
    """
    Parallel Pathway Hybrid Network (PPH-Net).
    A hybrid architecture that processes inputs through parallel KAN and MLP pathways,
    fusing them via a learned gating mechanism.
    """
    def __init__(self, in_features, hidden_features, out_features, num_layers=3, grid_size=5, spline_order=3):
        super().__init__()
        self.layers = nn.ModuleList()
        
        # Input layer
        self.layers.append(PPHLayer(in_features, hidden_features[0], grid_size, spline_order))
        
        # Hidden layers
        for i in range(num_layers - 2):
            self.layers.append(PPHLayer(hidden_features[i], hidden_features[i+1], grid_size, spline_order))
            
        # Output layer (typically linear without activation for regression/logits)
        self.output_layer = nn.Linear(hidden_features[-1], out_features)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        for layer in self.layers:
            x = layer(x)
        return self.output_layer(x)
