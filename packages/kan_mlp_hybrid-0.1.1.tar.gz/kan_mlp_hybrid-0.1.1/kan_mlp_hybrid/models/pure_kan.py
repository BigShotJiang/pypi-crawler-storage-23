import torch
import torch.nn as nn
from ..layers.kan_layer import SimpleKANLayer

class PureKAN(nn.Module):
    """
    Pure Kolmogorov-Arnold Network (KAN).
    Uses only learnable spline-based activation functions on edges, with no linear weight matrices.
    """
    def __init__(self, in_features, hidden_features, out_features, num_layers=3, grid_size=5, spline_order=3):
        super().__init__()
        self.layers = nn.ModuleList()
        
        # Input layer
        self.layers.append(SimpleKANLayer(in_features, hidden_features[0], grid_size, spline_order))
        
        # Hidden layers
        for i in range(num_layers - 2):
            self.layers.append(SimpleKANLayer(hidden_features[i], hidden_features[i+1], grid_size, spline_order))
            
        # Output layer
        self.layers.append(SimpleKANLayer(hidden_features[-1], out_features, grid_size, spline_order))

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        for layer in self.layers:
            x = layer(x)
        return x
