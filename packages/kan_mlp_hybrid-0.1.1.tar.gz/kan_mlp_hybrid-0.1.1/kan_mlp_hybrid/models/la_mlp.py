import torch
import torch.nn as nn
from ..layers.la_linear import LALinear

class LAMLP(nn.Module):
    """
    Learnable Activation Multi-Layer Perceptron (LA-MLP).
    A hybrid architecture that replaces fixed activation functions in an MLP
    with learnable, spline-based univariate functions.
    """
    def __init__(self, in_features, hidden_features, out_features, num_layers=3, grid_size=5, spline_order=3):
        super().__init__()
        self.layers = nn.ModuleList()
        
        # Input layer
        self.layers.append(LALinear(in_features, hidden_features[0], grid_size, spline_order))
        
        # Hidden layers
        for i in range(num_layers - 2):
            self.layers.append(LALinear(hidden_features[i], hidden_features[i+1], grid_size, spline_order))
            
        # Output layer (typically linear without activation for regression/logits)
        self.output_layer = nn.Linear(hidden_features[-1], out_features)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        for layer in self.layers:
            x = layer(x)
        return self.output_layer(x)
