import torch
import torch.nn as nn
from ..layers.moe_layer import MoEKANMLPLayer

class MoEKANMLP(nn.Module):
    """
    Mixture-of-Experts KAN-MLP Network.
    A sparsely gated architecture containing a heterogeneous pool of KAN and MLP experts.
    """
    def __init__(self, in_features, hidden_features, out_features, num_layers=3, num_experts=4, top_k=2, grid_size=5, spline_order=3):
        super().__init__()
        self.layers = nn.ModuleList()
        
        # Input layer
        self.layers.append(MoEKANMLPLayer(in_features, hidden_features[0], num_experts, top_k, grid_size, spline_order))
        
        # Hidden layers
        for i in range(num_layers - 2):
            self.layers.append(MoEKANMLPLayer(hidden_features[i], hidden_features[i+1], num_experts, top_k, grid_size, spline_order))
            
        # Output layer (typically linear without activation for regression/logits)
        self.output_layer = nn.Linear(hidden_features[-1], out_features)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        for layer in self.layers:
            x = layer(x)
        return self.output_layer(x)
