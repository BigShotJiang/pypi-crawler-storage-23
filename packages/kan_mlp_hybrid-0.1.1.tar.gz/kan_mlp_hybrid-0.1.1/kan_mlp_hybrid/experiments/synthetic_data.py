import torch
from torch.utils.data import Dataset, DataLoader

class MixedCharacteristicDataset(Dataset):
    """
    Synthetic dataset combining properties favorable to both KANs and MLPs.
    Formula: h(x) = exp(x_1 * x_2) + ReLU(x_3 - x_4) + sin(pi * x_5)
    """
    def __init__(self, num_samples=10000, num_features=5, noise_std=0.1):
        super().__init__()
        self.num_samples = num_samples
        self.num_features = num_features
        self.noise_std = noise_std
        
        # Generate random input features in range [-1, 1]
        self.X = torch.rand(num_samples, num_features) * 2 - 1
        
        # Compute target values
        self.y = self._compute_target(self.X)
        
        # Add noise
        self.y += torch.randn_like(self.y) * noise_std

    def _compute_target(self, x):
        """
        Compute the target function h(x).
        """
        # exp(x_1 * x_2)
        term1 = torch.exp(x[:, 0] * x[:, 1])
        
        # ReLU(x_3 - x_4)
        term2 = torch.relu(x[:, 2] - x[:, 3])
        
        # sin(pi * x_5)
        term3 = torch.sin(torch.pi * x[:, 4])
        
        return (term1 + term2 + term3).unsqueeze(1)

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

def get_dataloaders(batch_size=64, num_samples=10000, num_features=5, noise_std=0.1, train_split=0.8):
    """
    Get train and test dataloaders for the synthetic dataset.
    """
    dataset = MixedCharacteristicDataset(num_samples, num_features, noise_std)
    
    train_size = int(train_split * len(dataset))
    test_size = len(dataset) - train_size
    
    train_dataset, test_dataset = torch.utils.data.random_split(dataset, [train_size, test_size])
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    return train_loader, test_loader
