import torch
import torch.nn as nn
import torch.optim as optim

def train_and_evaluate(model, train_loader, test_loader, task_type, num_epochs=20, lr=1e-3, device='cpu'):
    """
    Unified training and evaluation loop for both regression and classification tasks.
    """
    model = model.to(device)
    
    if task_type == 'classification':
        criterion = nn.CrossEntropyLoss()
    else:
        criterion = nn.MSELoss()
        
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    for epoch in range(num_epochs):
        model.train()
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            
            # For classification, targets should be 1D. For regression, 2D.
            if task_type == 'classification' and targets.dim() > 1:
                targets = targets.squeeze()
                
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
    # Evaluation Phase
    model.eval()
    total_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            
            if task_type == 'classification' and targets.dim() > 1:
                targets = targets.squeeze()
                
            loss = criterion(outputs, targets)
            total_loss += loss.item() * inputs.size(0)
            
            if task_type == 'classification':
                _, predicted = torch.max(outputs.data, 1)
                total += targets.size(0)
                correct += (predicted == targets).sum().item()
            else:
                total += targets.size(0)
                
    avg_loss = total_loss / total
    metric = (correct / total) if task_type == 'classification' else avg_loss
    
    return avg_loss, metric
