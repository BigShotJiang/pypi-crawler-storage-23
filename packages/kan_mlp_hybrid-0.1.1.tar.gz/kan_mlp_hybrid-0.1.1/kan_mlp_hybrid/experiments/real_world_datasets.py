import torch
from torch.utils.data import DataLoader, TensorDataset
from sklearn.datasets import fetch_california_housing, load_breast_cancer, load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

def create_dataloader(X, y, batch_size, task_type):
    """Helper to create PyTorch DataLoaders from numpy arrays."""
    X_tensor = torch.FloatTensor(X)
    if task_type == 'classification':
        y_tensor = torch.LongTensor(y)
    else:
        y_tensor = torch.FloatTensor(y).unsqueeze(1)
        
    dataset = TensorDataset(X_tensor, y_tensor)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True)

def get_california_housing(batch_size=128):
    """Regression Task: Predict house prices based on 8 features."""
    data = fetch_california_housing()
    X_train, X_test, y_train, y_test = train_test_split(data.data, data.target, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    return (create_dataloader(X_train, y_train, batch_size, 'regression'),
            create_dataloader(X_test, y_test, batch_size, 'regression'),
            X_train.shape[1], 1, 'regression')

def get_breast_cancer(batch_size=128):
    """Tabular Classification Task: Predict malignant/benign based on 30 features."""
    data = load_breast_cancer()
    X_train, X_test, y_train, y_test = train_test_split(data.data, data.target, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    return (create_dataloader(X_train, y_train, batch_size, 'classification'),
            create_dataloader(X_test, y_test, batch_size, 'classification'),
            X_train.shape[1], 2, 'classification')

def get_digits_cv(batch_size=128):
    """Computer Vision Task: Classify 8x8 images of handwritten digits (flattened to 64 features)."""
    data = load_digits()
    X_train, X_test, y_train, y_test = train_test_split(data.data, data.target, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    return (create_dataloader(X_train, y_train, batch_size, 'classification'),
            create_dataloader(X_test, y_test, batch_size, 'classification'),
            X_train.shape[1], 10, 'classification')

def get_huggingface_ag_news(batch_size=128, max_features=200):
    """NLP Task: Classify news articles into 4 categories using TF-IDF features."""
    from datasets import load_dataset
    # Load a small subset to keep benchmark fast
    dataset = load_dataset("ag_news", split='train[:10000]')
    test_dataset = load_dataset("ag_news", split='test[:2000]')
    
    vectorizer = TfidfVectorizer(max_features=max_features, stop_words='english')
    X_train = vectorizer.fit_transform(dataset['text']).toarray()
    X_test = vectorizer.transform(test_dataset['text']).toarray()
    
    y_train = np.array(dataset['label'])
    y_test = np.array(test_dataset['label'])
    
    return (create_dataloader(X_train, y_train, batch_size, 'classification'),
            create_dataloader(X_test, y_test, batch_size, 'classification'),
            max_features, 4, 'classification')

def get_time_series(batch_size=128, seq_len=10):
    """Time Series Task: Auto-regressive forecasting on a complex synthetic signal."""
    t = np.linspace(0, 100, 10000)
    # Complex signal: two sine waves + noise
    y = np.sin(t) + 0.5 * np.sin(3 * t) + 0.1 * np.random.randn(len(t))
    
    X, Y = [], []
    for i in range(len(y) - seq_len):
        X.append(y[i:i+seq_len])
        Y.append(y[i+seq_len])
        
    X = np.array(X)
    Y = np.array(Y)
    
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, shuffle=False)
    
    return (create_dataloader(X_train, y_train, batch_size, 'regression'),
            create_dataloader(X_test, y_test, batch_size, 'regression'),
            seq_len, 1, 'regression')
