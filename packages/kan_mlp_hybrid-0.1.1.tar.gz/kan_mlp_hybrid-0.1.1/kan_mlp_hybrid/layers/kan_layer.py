import torch
import torch.nn as nn
from ..core.b_spline import b_spline_basis, extend_grid

class SimpleKANLayer(nn.Module):
    """
    A simplified, standalone implementation of a Kolmogorov-Arnold Network (KAN) layer.
    Replaces linear weights with learnable 1D functions on edges.
    """
    def __init__(self, in_dim, out_dim, grid_size=5, spline_order=3, base_activation=nn.SiLU, grid_range=[-1, 1]):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.grid_size = grid_size
        self.spline_order = spline_order
        
        # Base activation
        self.base_activation = base_activation()
        self.base_weight = nn.Parameter(torch.ones(out_dim, in_dim))
        
        # Spline parameters
        self.spline_weight = nn.Parameter(torch.ones(out_dim, in_dim))
        
        # Initialize grid
        grid = torch.linspace(grid_range[0], grid_range[1], steps=grid_size + 1)
        grid = grid.unsqueeze(0).expand(in_dim, grid_size + 1)
        grid = extend_grid(grid, k_extend=spline_order)
        self.register_buffer('grid', grid)
        
        # Spline coefficients: [out_dim, in_dim, grid_size + spline_order]
        self.spline_coefs = nn.Parameter(torch.randn(out_dim, in_dim, grid_size + spline_order) * 0.1)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_dim)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_dim)
        """
        # Base activation pathway
        # x: (batch_size, in_dim) -> base_out: (batch_size, out_dim, in_dim)
        base_out = self.base_weight * self.base_activation(x).unsqueeze(1)
        
        # Spline pathway
        # b_splines shape: (batch_size, in_dim, grid_size + spline_order)
        b_splines = b_spline_basis(x, self.grid, k=self.spline_order)
        
        # Compute spline output: sum over basis functions
        # spline_coefs shape: (out_dim, in_dim, grid_size + spline_order)
        # Result shape: (batch_size, out_dim, in_dim)
        spline_out = torch.einsum('bik,oik->boi', b_splines, self.spline_coefs)
        spline_out = self.spline_weight * spline_out
        
        # Combine and sum over input dimension
        # Final shape: (batch_size, out_dim)
        return torch.sum(base_out + spline_out, dim=2)
