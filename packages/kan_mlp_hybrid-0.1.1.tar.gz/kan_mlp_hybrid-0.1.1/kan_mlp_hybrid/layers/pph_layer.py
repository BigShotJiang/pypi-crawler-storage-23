import torch
import torch.nn as nn
from .kan_layer import SimpleKANLayer

class PPHLayer(nn.Module):
    """
    Parallel Pathway Hybrid (PPH) Layer.
    Processes inputs through parallel KAN and MLP pathways, fusing them via a learned gating mechanism.
    """
    def __init__(self, in_features, out_features, grid_size=5, spline_order=3):
        super().__init__()
        
        # MLP Pathway
        self.mlp_path = nn.Sequential(
            nn.Linear(in_features, out_features),
            nn.SiLU()
        )
        
        # KAN Pathway
        self.kan_path = SimpleKANLayer(
            in_dim=in_features,
            out_dim=out_features,
            grid_size=grid_size,
            spline_order=spline_order
        )
        
        # Gating Mechanism
        self.gate = nn.Linear(out_features * 2, out_features)

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        y_mlp = self.mlp_path(x)
        y_kan = self.kan_path(x)
        
        # Compute gating weights
        gate_input = torch.cat([y_mlp, y_kan], dim=-1)
        alpha = torch.sigmoid(self.gate(gate_input))
        
        # Fuse pathways
        return alpha * y_kan + (1 - alpha) * y_mlp
