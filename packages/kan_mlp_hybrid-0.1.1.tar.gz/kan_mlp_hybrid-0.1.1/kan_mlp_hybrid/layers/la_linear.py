import torch
import torch.nn as nn
from ..core.activations import LearnableActivation

class LALinear(nn.Module):
    """
    Learnable Activation Linear Layer.
    Combines a standard linear transformation with a learnable activation function.
    
    Formula: y = phi(W * x + b)
    """
    def __init__(self, in_features, out_features, grid_size=5, spline_order=3, base_activation=nn.SiLU):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.act = LearnableActivation(
            num_features=out_features,
            grid_size=grid_size,
            spline_order=spline_order,
            base_activation=base_activation
        )

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        return self.act(self.linear(x))
