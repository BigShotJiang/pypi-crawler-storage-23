import torch
import torch.nn as nn
import torch.nn.functional as F
from .kan_layer import SimpleKANLayer

class MoEKANMLPLayer(nn.Module):
    """
    Mixture-of-Experts KAN-MLP Layer.
    A sparsely gated layer containing a heterogeneous pool of KAN and MLP experts.
    """
    def __init__(self, in_features, out_features, num_experts=4, top_k=2, grid_size=5, spline_order=3):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k
        
        # Router network
        self.router = nn.Linear(in_features, num_experts)
        
        # Heterogeneous pool of experts
        self.experts = nn.ModuleList()
        for i in range(num_experts):
            if i % 2 == 0:
                # KAN Expert
                self.experts.append(SimpleKANLayer(
                    in_dim=in_features,
                    out_dim=out_features,
                    grid_size=grid_size,
                    spline_order=spline_order
                ))
            else:
                # MLP Expert
                self.experts.append(nn.Sequential(
                    nn.Linear(in_features, out_features),
                    nn.SiLU()
                ))

    def forward(self, x):
        """
        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_features)
            
        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_features)
        """
        batch_size = x.size(0)
        
        # Compute routing probabilities
        # router_logits shape: (batch_size, num_experts)
        router_logits = self.router(x)
        
        # Get top-k experts and their weights
        # top_k_logits, top_k_indices shape: (batch_size, top_k)
        top_k_logits, top_k_indices = torch.topk(router_logits, self.top_k, dim=-1)
        top_k_weights = F.softmax(top_k_logits, dim=-1)
        
        # Initialize output tensor
        out = torch.zeros(batch_size, self.experts[0].out_dim if hasattr(self.experts[0], 'out_dim') else self.experts[0][0].out_features, device=x.device)
        
        # Compute expert outputs and combine
        for i in range(self.top_k):
            expert_idx = top_k_indices[:, i]
            expert_weight = top_k_weights[:, i].unsqueeze(-1)
            
            # We need to process each sample with its assigned expert
            # For simplicity and efficiency in PyTorch, we can iterate over experts
            # and process the samples assigned to them.
            for expert_id in range(self.num_experts):
                # Find samples assigned to this expert at this top-k position
                mask = (expert_idx == expert_id)
                if mask.any():
                    expert_input = x[mask]
                    expert_output = self.experts[expert_id](expert_input)
                    out[mask] += expert_weight[mask] * expert_output
                    
        return out
