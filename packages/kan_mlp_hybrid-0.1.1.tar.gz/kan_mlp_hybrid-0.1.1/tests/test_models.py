import torch
import pytest
from kan_mlp_hybrid import LAMLP, PPHNet, MoEKANMLP, PureKAN

def test_lamlp_forward():
    model = LAMLP(in_features=5, hidden_features=[16, 16], out_features=2)
    x = torch.randn(4, 5)
    y = model(x)
    assert y.shape == (4, 2)
    assert not torch.isnan(y).any()

def test_pphnet_forward():
    model = PPHNet(in_features=5, hidden_features=[16, 16], out_features=1)
    x = torch.randn(8, 5)
    y = model(x)
    assert y.shape == (8, 1)
    assert not torch.isnan(y).any()

def test_moe_kan_mlp_forward():
    model = MoEKANMLP(in_features=4, hidden_features=[8, 8], out_features=3, num_experts=2, top_k=1)
    x = torch.randn(2, 4)
    y = model(x)
    assert y.shape == (2, 3)
    assert not torch.isnan(y).any()

def test_pure_kan_forward():
    model = PureKAN(in_features=3, hidden_features=[8, 8], out_features=1)
    x = torch.randn(5, 3)
    y = model(x)
    assert y.shape == (5, 1)
    assert not torch.isnan(y).any()
