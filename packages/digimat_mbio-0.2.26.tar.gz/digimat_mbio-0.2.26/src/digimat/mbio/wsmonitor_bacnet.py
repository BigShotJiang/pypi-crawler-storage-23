import json

from .wsmonitor_html import HtmlPage


class MBIOWsMonitorBACnetMixin:
    def _hasBacnetTasks(self):
        """Check if any MBIOTaskBacnet instances exist."""
        return len(self._getBacnetTasks()) > 0

    def _bacnetNavHtml(self):
        """Return BACnet nav link HTML, or empty string if no BACnet tasks."""
        if self._hasBacnetTasks():
            return ' / <a href="/bacnet">BACnet</a>'
        return ''

    def _getBacnetTasks(self):
        """Return all MBIOTaskBacnet instances."""
        try:
            from .bacnet import MBIOTaskBacnet
        except ImportError:
            return []
        mbio = self.getMBIO()
        return [t for t in mbio.tasks.all() if isinstance(t, MBIOTaskBacnet)]

    def cb_getbacnetdevices(self, handler, params):
        """Retrieve BACnet devices discovered on the network.
        GET /api/v1/getbacnetdevices[?task=&lt;taskkey&gt;]
          task (optional) : filter to a specific MBIOTaskBacnet key
        Returns {"data": [{"task", "deviceId", "address", "name", "vendor"}, ...]}
        The local BACnet server appears with deviceId="local".
        """
        items = []
        task_filter = params.get('task')
        for task in self._getBacnetTasks():
            if task_filter and task.key != task_filter:
                continue
            client = task.client()
            if not client:
                continue
            # Nœud local (serveur BACnet de cette instance MBIO)
            iface = client.interface
            if iface and iface.is_healthy():
                items.append({
                    'task': task.key,
                    'deviceId': 'local',
                    'address': '%s:%s' % (iface.ip_address, iface.port),
                    'name': iface.device_name or 'Local',
                    'vendor': '',
                    'local': True,
                })
            devices = client.retrieveDevices(cached=True) or []
            for d in devices:
                items.append({
                    'task': task.key,
                    'deviceId': d.get('deviceId', ''),
                    'address': d.get('address', ''),
                    'name': d.get('name', ''),
                    'vendor': d.get('vendor', ''),
                })
        self.cb_write_json(handler, {'data': items})
        return True

    def cb_getbacnetobjects(self, handler, params):
        """Retrieve all BACnet objects of a given device.
        GET /api/v1/getbacnetobjects?task=&lt;taskkey&gt;&amp;device=&lt;deviceId&gt;
          task   : MBIOTaskBacnet key
          device : numeric deviceId or "local" for the local BACnet server
        Returns {"data": [{"deviceId", "type", "instance", "name",
                            "value", "unit", "description", "labels"}, ...]}
        "labels" is a list of state names for binary/multistate objects, or null.
        """
        task_key = params.get('task')
        device_id = params.get('device')
        if not task_key or device_id is None:
            return self.cb_write_failure(handler)

        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)

        client = task.client()
        if not client:
            return self.cb_write_failure(handler)

        items = []
        if device_id == 'local':
            for o in (client.retrieveLocalObjects() or []):
                items.append({
                    'deviceId': device_id,
                    'type': o.get('type', ''),
                    'instance': o.get('instance', ''),
                    'name': o.get('name', ''),
                    'value': o.get('value', ''),
                    'unit': o.get('unit', ''),
                    'writable': o.get('writable', False),
                    'description': o.get('description', ''),
                    'labels': o.get('labels'),
                })
        else:
            try:
                dev = client.device(int(device_id))
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
            if dev:
                for o in (dev.retrieveObjects(cached=False) or []):
                    items.append({
                        'deviceId': device_id,
                        'type': o.get('type', ''),
                        'instance': o.get('instance', ''),
                        'name': o.get('name', ''),
                        'value': o.get('value', ''),
                        'unit': o.get('unit', ''),
                        'description': o.get('description', ''),
                        'labels': o.get('labels'),
                    })

        self.cb_write_json(handler, {'data': items})
        return True

    def cb_refreshbacnet(self, handler, params):
        """Trigger a BACnet network refresh (re-scan devices or reload object cache).
        GET /api/v1/refreshbacnet[?task=&lt;taskkey&gt;][&amp;device=&lt;deviceId&gt;]
          task   (optional) : limit refresh to a specific MBIOTaskBacnet
          device (optional) : limit to a specific device (numeric deviceId); if omitted, refresh all
        """
        task_key = params.get('task')
        device_id = params.get('device')
        for task in self._getBacnetTasks():
            if task_key and task.key != task_key:
                continue
            client = task.client()
            if not client:
                continue
            if device_id:
                try:
                    dev = client.device(int(device_id))
                    if dev:
                        dev.refresh()
                except (ValueError, TypeError):
                    pass
            else:
                client.refreshDevices()
        self.cb_write_success(handler)
        return True

    def cb_getbacnetobjectproperties(self, handler, params):
        """Retrieve all properties of a BACnet object, plus priority array if commandable.
        GET /api/v1/getbacnetobjectproperties?task=&lt;taskkey&gt;&amp;device=&lt;deviceId&gt;&amp;type=&lt;type&gt;&amp;instance=&lt;instance&gt;
          task     : MBIOTaskBacnet key
          device   : numeric deviceId or "local"
          type     : BACnet object type (e.g. analog-value, binary-input, multi-state-value)
          instance : BACnet object instance number
        Returns {"data": [{"property", "value"}, ...],
                 "priority_array": [null|float|int|bool x16] or null,
                 "commandable": bool,
                 "out_of_service": bool,
                 "labels": [str, ...] or null}
        Key properties are returned first (presentValue, units, description, statusFlags, ...).
        Priority array is provided only if the object exposes a priorityArray property.
        """
        task_key = params.get('task')
        device_id = params.get('device')
        obj_type = params.get('type')
        obj_instance = params.get('instance')
        if not task_key or device_id is None or not obj_type or obj_instance is None:
            return self.cb_write_failure(handler)

        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)

        client = task.client()
        if not client:
            return self.cb_write_failure(handler)

        object_id = '%s,%s' % (obj_type, obj_instance)

        if device_id == 'local':
            props, priority_array = client.retrieveLocalObjectProperties(object_id)
            props = props or {}
        else:
            try:
                dev = client.device(int(device_id))
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
            if not dev:
                return self.cb_write_failure(handler)

            props = dev.retrieveObjectProperties(object_id, cached=False) or {}

            # Certains devices n'incluent pas les propriétés texte dans propertyList.
            # Les lire explicitement si absentes (comme le fait _read_object_summary_safe).
            type_lower_check = obj_type.lower()
            if 'binary' in type_lower_check:
                for prop_name in ('activeText', 'inactiveText'):
                    if prop_name not in props:
                        try:
                            val = dev.read(object_id, prop_name)
                            if val is not None:
                                props[prop_name] = str(val)
                        except Exception:
                            pass
            elif 'multi-state' in type_lower_check:
                if 'stateText' not in props:
                    try:
                        val = dev.read(object_id, 'stateText')
                        if val is not None:
                            props['stateText'] = val
                    except Exception:
                        pass

            priority_array = None
            if 'priorityArray' in props:
                try:
                    pa = dev.retrievePriorityArray(object_id)
                    if pa is not None:
                        priority_array = pa
                except Exception:
                    pass

        def _serialize(k, v):
            # stateText AVANT le passthrough list (ArrayOf(CharacterString) peut être sous-classe de list)
            if k == 'stateText':
                try:
                    return [str(s) for s in v]
                except (TypeError, AttributeError):
                    return str(v)
            if isinstance(v, (str, int, float, bool, type(None), list, dict)):
                return v
            if k == 'statusFlags':
                try:
                    return {
                        'inAlarm': bool(v.inAlarm),
                        'fault': bool(v.fault),
                        'overridden': bool(v.overridden),
                        'outOfService': bool(v.outOfService),
                    }
                except AttributeError:
                    pass
            return str(v)

        PRIORITY_KEYS = ['presentValue', 'units', 'description', 'statusFlags',
                         'outOfService', 'eventState', 'reliability', 'relinquishDefault',
                         'inactiveText', 'activeText', 'stateText']
        items = []
        for k in PRIORITY_KEYS:
            if k in props:
                items.append({'property': k, 'value': _serialize(k, props[k])})
        for k in sorted(props.keys()):
            if k not in PRIORITY_KEYS:
                items.append({'property': k, 'value': _serialize(k, props[k])})

        # Labels for BV/MSV (pour le rendu JS)
        # Ne définir les labels que si le device expose réellement les propriétés texte
        labels = None
        type_lower = obj_type.lower()
        if 'binary' in type_lower:
            inactive = props.get('inactiveText')
            active = props.get('activeText')
            if inactive is not None or active is not None:
                labels = [
                    str(inactive) if inactive is not None else 'Off',
                    str(active) if active is not None else 'On',
                ]
        elif 'multi-state' in type_lower:
            st = props.get('stateText')
            if st is not None:
                try:
                    labels = [str(s) for s in st]
                except Exception:
                    pass

        oos = props.get('outOfService', False)
        self.cb_write_json(handler, {
            'data': items,
            'priority_array': priority_array,
            'commandable': priority_array is not None,
            'out_of_service': bool(oos) if oos is not None else False,
            'labels': labels,
        })
        return True

    def cb_bacnetwriteproperty(self, handler, params, data=None):
        """Write a BACnet object property directly (no priority array).
        POST /api/v1/bacnetwriteproperty
        Body: {"task": &lt;taskkey&gt;, "device": &lt;deviceId&gt;, "type": &lt;type&gt;,
               "instance": &lt;instance&gt;, "property": &lt;propertyName&gt;, "value": &lt;value&gt;}
          property : BACnet property name to write (e.g. outOfService, description, presentValue)
          value    : new property value (type must match the BACnet property)
        Typical use: toggle outOfService, update description or any writable property.
        """
        try:
            payload = json.loads(data) if isinstance(data, str) else (data or {})
        except (json.JSONDecodeError, TypeError):
            return self.cb_write_failure(handler)

        task_key = payload.get('task')
        device_id = payload.get('device')
        obj_type = payload.get('type')
        obj_instance = payload.get('instance')
        property_name = payload.get('property')
        value = payload.get('value')

        if not all([task_key, device_id, obj_type, obj_instance, property_name]):
            return self.cb_write_failure(handler)

        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)

        client = task.client()
        if not client:
            return self.cb_write_failure(handler)

        if str(device_id) == 'local':
            try:
                ok = client.writeLocalProperty(obj_type, int(obj_instance), property_name, value, priority=None)
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
        else:
            try:
                dev = client.device(int(device_id))
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
            if not dev:
                return self.cb_write_failure(handler)
            object_id = '%s,%s' % (obj_type, obj_instance)
            ok = dev.write(object_id, value, propertyName=property_name, priority=None)

        if ok:
            return self.cb_write_success(handler)
        return self.cb_write_failure(handler)

    def cb_bacnetwritepriority(self, handler, params, data=None):
        """Write or release a priority-array slot of a commandable BACnet object.
        POST /api/v1/bacnetwritepriority
        Body: {"task": &lt;taskkey&gt;, "device": &lt;deviceId&gt;, "type": &lt;type&gt;,
               "instance": &lt;instance&gt;, "priority": &lt;1-16&gt;, "value": &lt;value|null&gt;}
          priority : BACnet command priority 1 (highest) to 16 (lowest/default); default 8
          value    : numeric/bool value to write, or null to release (relinquish) the slot
        Common priorities: 1=Manual Life Safety, 2=Auto Life Safety, 5=Critical Equipment,
          6=Minimum On/Off, 8=Manual Operator (default), 16=relinquishDefault.
        """
        try:
            payload = json.loads(data) if isinstance(data, str) else (data or {})
        except (json.JSONDecodeError, TypeError):
            return self.cb_write_failure(handler)

        task_key = payload.get('task')
        device_id = payload.get('device')
        obj_type = payload.get('type')
        obj_instance = payload.get('instance')
        priority = payload.get('priority', 8)
        value = payload.get('value')

        if not task_key or device_id is None or not obj_type or obj_instance is None:
            return self.cb_write_failure(handler)

        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)

        client = task.client()
        if not client:
            return self.cb_write_failure(handler)

        try:
            priority = int(priority)
        except (ValueError, TypeError):
            return self.cb_write_failure(handler)

        if str(device_id) == 'local':
            try:
                ok = client.writeLocalProperty(obj_type, int(obj_instance), 'presentValue', value, priority=priority)
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
        else:
            try:
                dev = client.device(int(device_id))
            except (ValueError, TypeError):
                return self.cb_write_failure(handler)
            if not dev:
                return self.cb_write_failure(handler)
            object_id = '%s,%s' % (obj_type, obj_instance)
            if value is None:
                ok = dev.release(object_id, priority=priority)
            else:
                ok = dev.write(object_id, value, priority=priority)

        if ok:
            return self.cb_write_success(handler)
        return self.cb_write_failure(handler)

    def _bacnetaction_declare(self, task, device_id, items, params):
        """Handle 'declare' action on selected BACnet objects.
        Returns True to clear selection, False to keep it.
        """
        device_id=int(device_id)
        startInstance = int(params.get('startInstance', 0))

        self.logger.info('BACnet declare: task=%s device=%s items=%d startInstance=%s' % (task.key, device_id, len(items), startInstance))

        # items: [{'type': 'analog-input', 'instance': 13062, 'name': 'r_112_1_cio_13062_0'}, ...]
        # params: {'startInstance': 50}

        btypes={'analog-input': 'AI', 'analog-output': 'AO',
                'binary-input': 'BI', 'binary-output': 'BO',
                'analog-value': 'AV', 'binary-value': 'BV',
                'multistate-value': 'MSV',
                'multistate-input': 'MSI', 'multistate-output': 'MSO'}

        mbio=self.getMBIO()
        notifier=mbio._cpuNotifier

        try:
            if items and notifier:
                link=notifier._link
                if link:
                    for item in items:
                        # self.logger.debug(item)
                        btype=btypes.get(item['type'])
                        instance=int(item['instance'])
                        unit=mbio.units.getByName(item['unit'])
                        link.declareBacnetItem(device_id, btype, instance, unit, startInstance)
                    return True
        except:
            self.logger.exception('e')

        return False

    def cb_bacnetaction(self, handler, params, data=None):
        """Execute a named action on a selection of BACnet objects.
        POST /api/v1/bacnetaction
        Body: {"action": &lt;name&gt;, "task": &lt;taskkey&gt;, "device": &lt;deviceId&gt;,
               "items": [{"type", "instance", "name", "unit"}, ...],
               "params": {&lt;action-specific params&gt;}}
        Supported actions:
          declare — declare selected objects as MBIO values via the link notifier
                    params: {"startInstance": &lt;int&gt;}  (base instance offset, default 0)
          copy    — copy selected rows to clipboard (client-side only, no server call)
          unmark  — clear the current selection (client-side only)
        """
        if not data:
            return self.cb_write_failure(handler)
        try:
            payload = json.loads(data) if isinstance(data, str) else data
        except (json.JSONDecodeError, TypeError):
            return self.cb_write_failure(handler)

        action = payload.get('action')
        task_key = payload.get('task')
        device_id = payload.get('device')
        items = payload.get('items', [])
        action_params = payload.get('params', {})

        if not action or not task_key or not items:
            return self.cb_write_failure(handler)

        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)

        method = getattr(self, '_bacnetaction_%s' % action, None)
        if method is None:
            return self.cb_write_failure(handler)

        result = method(task, device_id, items, action_params)
        if result:
            self.cb_write_success(handler)
        else:
            self.cb_write_failure(handler)
        return True

    def cb_bacnet(self, handler, params):
        """BACnet devices list page.
        GET /bacnet
        Lists all BACnet devices discovered by all MBIOTaskBacnet instances.
        Click a row to navigate to /bacnetobjects for that device.
        """
        mbio = self.getMBIO()
        h = HtmlPage('Digimat MBIO - BACnet Devices', handler)
        h.variable('mbio.version', mbio.version)
        h.variable('main.nav', self._navHtml())
        h.variable('bacnet.nav', self._bacnetNavHtml())
        h.variable('auth.logout', self._logoutHtml())

        data = """
            <div class="page container-fluid">
            <div class="card p-4 p-lg-5">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
            <div>
            <h1 class="h3 mb-1">BACnet Devices</h1>
            <p class="text-secondary mb-0"><b>BACnet</b> / devices</p>
            </div>
            <div class="text-muted small">{mbio.version} /
            {main.nav}
            <span class="ms-2">
            <button id="btn-refresh" class="btn btn-sm btn-outline-secondary">Refresh</button>
            </span>{auth.logout}
            </div>
            </div>
            <table id="items" class="display nowrap" style="width:100%">
            <thead>
            <tr>
            <th data-priority="2">Task</th>
            <th data-priority="1">DeviceID</th>
            <th data-priority="1">Address</th>
            <th data-priority="1">Name</th>
            <th data-priority="2">Vendor</th>
            </tr>
            </thead>
            </table>
            </div>
            </div>
        """
        h.write(data)

        data = """
        <script>
        $(function () {
            const table = new DataTable('#items', {
            responsive: true,
            paging: false,
            searching: true,
            ordering: true,
            info: false,
            search: { smart: true, regex: false, caseInsensitive: true, boundary: false },
            ajax: { url: "/api/v1/getbacnetdevices", dataSrc: "data" },
            columns: [
                { data: "task" },
                { data: "deviceId" },
                { data: "address" },
                { data: "name" },
                { data: "vendor" }
            ]
            });

            setInterval(function () {
                table.ajax.reload(null, false);
            }, 5000);

            $('#btn-refresh').on('click', async function() {
                await fetch('/api/v1/refreshbacnet');
                table.ajax.reload();
            });

            $('#items').on('click', 'tr', function(e) {
                var data = table.row(this).data();
                if (data) {
                    window.location.href = "/bacnetobjects?task=" + encodeURIComponent(data.task)
                        + "&device=" + encodeURIComponent(data.deviceId);
                }
            });

            $(document).on('keydown', function (e) {
                if ($(e.target).is('input, textarea')) return;
                if (e.key === 'c' && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) {
                    e.preventDefault();
                    copyDataTableToClipboard(table);
                    return;
                }
                if (!e.ctrlKey && !e.metaKey && !e.altKey && e.key === '/') {
                    e.preventDefault();
                    const searchInput = $('#dt-search-0.dt-input');
                    searchInput.focus();
                    searchInput.select();
                }
            });
        });
        </script>
        """
        h.write(data)
        h.flush()

    def cb_bacnetobjects(self, handler, params):
        """BACnet object list page for a given device.
        GET /bacnetobjects?task=&lt;taskkey&gt;&amp;device=&lt;deviceId&gt;
          task   : MBIOTaskBacnet key
          device : numeric deviceId or "local"
        Displays type, instance, name, current value, unit and description.
        Checkbox or SPACE = select row. CTRL+K / CTRL+SHIFT+K = select/deselect all visible.
        CTRL+C = copy selection (or all visible) to clipboard as TSV.
        Click a row (outside checkbox) to navigate to /bacnetobjectproperties.
        Action bar: Declare (via link notifier), Copy, Unmark.
        """
        mbio = self.getMBIO()
        task_key = params.get('task', '')
        device_id = params.get('device', '')

        h = HtmlPage('BACnet Objects - Device %s' % device_id, handler)
        h.variable('mbio.version', mbio.version)
        h.variable('main.nav', self._navHtml())
        h.variable('bacnet.nav', self._bacnetNavHtml())
        h.variable('auth.logout', self._logoutHtml())
        h.variable('task', task_key)
        h.variable('device', device_id)

        data = """
            <style>
            #items tbody tr.selected { background-color: #cfe2ff !important; }
            #action-bar { display: none; }
            #action-bar.active { display: inline-flex; }
            @keyframes flash-yellow {
                0%   { background-color: #fff3cd; }
                100% { background-color: transparent; }
            }
            #items tbody tr.value-changed:not(.selected) {
                animation: flash-yellow 1.5s ease-out;
            }
            #items tbody tr { cursor: pointer; }
            #items tbody td.dt-select { cursor: default; }
            #items thead th.dt-select { width: 1px; }
            </style>
            <div class="page container-fluid">
            <div class="card p-4 p-lg-5">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
            <div>
            <h1 class="h3 mb-1">BACnet Objects</h1>
            <p class="text-secondary mb-0"><a href="/bacnet">BACnet</a> / device {device}</p>
            </div>
            <div class="text-muted small">{mbio.version} /
            {main.nav} / <a href="/bacnet">BACnet Devices</a>
            <span class="ms-2">
            <div id="action-bar" class="btn-group btn-group-sm me-2">
            <button id="btn-action" type="button" class="btn btn-primary">Declare <span id="sel-count" class="badge bg-light text-primary ms-1">0</span></button>
            <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"></button>
            <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item active" href="#" data-action="declare">Declare</a></li>
            <li><a class="dropdown-item" href="#" data-action="copy">Copy</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#" data-action="unmark">Unmark</a></li>
            </ul>
            </div>
            <button id="btn-refresh" class="btn btn-sm btn-outline-secondary">Refresh</button>
            </span>{auth.logout}
            </div>
            </div>
            <table id="items" class="display nowrap" style="width:100%%">
            <thead>
            <tr>
            <th class="dt-select" data-priority="1"><input type="checkbox" id="check-all" class="form-check-input"></th>
            <th data-priority="1">Type</th>
            <th data-priority="1">Instance</th>
            <th data-priority="1">Name</th>
            <th data-priority="1">Value</th>
            <th data-priority="3">Unit</th>
            <th data-priority="4">Description</th>
            <th data-priority="2" class="dt-no-copy dt-action"></th>
            </tr>
            </thead>
            </table>
            </div>
            </div>

            <!-- Action params modal -->
            <div class="modal fade" id="actionModal" tabindex="-1">
            <div class="modal-dialog modal-sm modal-dialog-centered">
            <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title" id="actionModalTitle">Parameters</h6>
                <button type="button" class="btn-close btn-close-sm" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-2" id="actionModalBody"></div>
            <div class="modal-footer py-1">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-primary" id="actionModalOk">OK</button>
            </div>
            </div>
            </div>
            </div>

        """
        h.write(data)

        data = """
        <script>
        $(function () {
            const taskKey = "{task}";
            const deviceId = "{device}";
            const apiUrl = "/api/v1/getbacnetobjects?task=" + encodeURIComponent(taskKey)
                         + "&device=" + encodeURIComponent(deviceId);

            const selected = new Set();
            const prevValues = new Map();
            let currentAction = "declare";
            let table = null;
            let hoveredRow = null;

            const actionParams = {
                declare: {
                    label: "Declare",
                    params: [
                        { name: "startInstance", label: "Start Instance", type: "number", default: 0 }
                    ]
                }
            };

            function itemKey(d) { return d.type + ":" + d.instance; }

            function valueChanged(a, b) {
                if (a === undefined) return false;
                if (typeof a === 'number' && typeof b === 'number') {
                    return Math.abs(a - b) > 0.05;
                }
                return a !== b;
            }

            function updateActionBar() {
                const n = selected.size;
                $('#sel-count').text(n);
                if (n > 0) { $('#action-bar').addClass('active'); }
                else { $('#action-bar').removeClass('active'); }
            }

            function applySelection() {
                if (!table) return;
                table.rows().every(function () {
                    const d = this.data();
                    if (!d) return;
                    const k = itemKey(d);
                    const $row = $(this.node());
                    const isSel = selected.has(k);
                    if (isSel) { $row.addClass('selected'); }
                    else { $row.removeClass('selected'); }
                    $row.find('.row-check').prop('checked', isSel);
                    const prev = prevValues.get(k);
                    if (valueChanged(prev, d.value)) {
                        $row.removeClass('value-changed');
                        void $row[0].offsetWidth;
                        $row.addClass('value-changed');
                    }
                    prevValues.set(k, d.value);
                });
            }

            table = new DataTable('#items', {
            responsive: true,
            paging: false,
            searching: true,
            ordering: true,
            info: false,
            search: { smart: true, regex: false, caseInsensitive: true, boundary: false },
            ajax: { url: apiUrl, dataSrc: "data" },
            columns: [
                { data: null, orderable: false, searchable: false, className: 'dt-select text-center',
                  render: function() { return '<input type="checkbox" class="form-check-input row-check">'; } },
                { data: "type" },
                { data: "instance" },
                { data: "name" },
                { data: "value", className: 'text-end', render: function(v, type, row) {
                    if (type !== 'display') return v === null || v === undefined ? '' : String(v);
                    const fmt = typeof v === 'number' && !Number.isInteger(v) ? v.toFixed(1) : String(v === null || v === undefined ? '' : v);
                    return '<strong>' + fmt + '</strong>';
                }},
                { data: "unit", render: function(v, type, row) {
                    if (type !== 'display') return v || '';
                    if (row.labels && row.labels.length > 0) {
                        const val = row.value;
                        let idx;
                        if (typeof val === 'boolean') { idx = val ? 1 : 0; }
                        else if (typeof val === 'number') { idx = val - 1; }
                        else { return v || ''; }
                        const lbl = row.labels[idx];
                        if (lbl !== undefined) return '<span class="fst-italic opacity-75">' + lbl + '</span>';
                    }
                    return v || '';
                }},
                { data: "description" },
                { data: null, orderable: false, searchable: false, className: 'text-center dt-action',
                  render: function(v, type, row) {
                    if (type !== 'display') return '';
                    if (row.type === 'schedule' && row.deviceId === 'local') {
                        return '<button class="btn btn-sm btn-outline-primary py-0 px-1 edit-sched-btn" style="font-size:.75rem">Edit</button>';
                    }
                    return '';
                  }}
            ],
            drawCallback: function () { applySelection(); }
            });

            setInterval(function () {
                table.ajax.reload(null, false);
            }, 10000);

            // Suivi de la ligne sous le curseur (pour SPACE)
            $('#items').on('mouseenter', 'tbody tr', function () {
                hoveredRow = this;
            }).on('mouseleave', 'tbody tr', function () {
                hoveredRow = null;
            });

            // Case à cocher : toggle sélection
            $('#items').on('click', '.row-check', function (e) {
                e.stopPropagation();
                const $row = $(this).closest('tr');
                const d = table.row($row).data();
                if (!d) return;
                const k = itemKey(d);
                if (selected.has(k)) { selected.delete(k); $row.removeClass('selected'); $(this).prop('checked', false); }
                else { selected.add(k); $row.addClass('selected'); $(this).prop('checked', true); }
                updateActionBar();
            });

            // Bouton Edit : naviguer vers l'éditeur de schedule
            $('#items').on('click', '.edit-sched-btn', function (e) {
                e.stopPropagation();
                var d = table.row($(this).closest('tr')).data();
                if (!d) return;
                window.location.href = '/bacnetschedule?task=' + encodeURIComponent(taskKey)
                    + '&name=' + encodeURIComponent(d.name);
            });

            // Clic sur la ligne (hors checkbox et hors colonne action) : navigation vers les propriétés
            $('#items').on('click', 'td:not(.dt-select):not(.dt-action)', function (e) {
                var data = table.row($(this).closest('tr')).data();
                if (!data) return;
                window.location.href = '/bacnetobjectproperties?task=' + encodeURIComponent(taskKey)
                    + '&device=' + encodeURIComponent(deviceId)
                    + '&type=' + encodeURIComponent(data.type)
                    + '&instance=' + encodeURIComponent(data.instance);
            });

            // Case "select all" dans le header
            $('#check-all').on('change', function () {
                const checked = $(this).prop('checked');
                table.rows({ search: 'applied' }).every(function () {
                    const d = this.data();
                    if (!d) return;
                    const k = itemKey(d);
                    if (checked) { selected.add(k); $(this.node()).addClass('selected'); }
                    else { selected.delete(k); $(this.node()).removeClass('selected'); }
                    $(this.node()).find('.row-check').prop('checked', checked);
                });
                updateActionBar();
            });

            $('#btn-refresh').on('click', async function() {
                await fetch('/api/v1/refreshbacnet?task=' + encodeURIComponent(taskKey)
                          + '&device=' + encodeURIComponent(deviceId));
                table.ajax.reload();
            });

            // action menu
            $('.dropdown-menu').on('click', '.dropdown-item', function (e) {
                e.preventDefault();
                currentAction = $(this).data('action');
                $('.dropdown-menu .dropdown-item').removeClass('active');
                $(this).addClass('active');
                $('#btn-action').contents().first()[0].textContent = $(this).text() + ' ';
            });

            function collectSelectedItems() {
                const items = [];
                table.rows().every(function () {
                    const d = this.data();
                    if (d && selected.has(itemKey(d))) {
                    items.push({ type: d.type, instance: d.instance, name: d.name, unit: d.unit });
                    }
                });
                return items;
            }

            async function executeAction(action, items, params) {
                const btn = $('#btn-action');
                btn.prop('disabled', true);
                try {
                    const resp = await fetch('/api/v1/bacnetaction', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            action: action,
                            task: taskKey,
                            device: deviceId,
                            items: items,
                            params: params || {}
                        })
                    });
                    const result = await resp.json();
                    if (result.success) {
                        items.forEach(function (it) {
                            selected.delete(it.type + ":" + it.instance);
                        });
                        updateActionBar();
                        table.draw(false);
                        showToast(action.charAt(0).toUpperCase() + action.slice(1) + ': ' + items.length + ' object' + (items.length !== 1 ? 's' : ''), 'success');
                    } else {
                        showToast(action.charAt(0).toUpperCase() + action.slice(1) + ' failed', 'danger');
                    }
                } catch (e) {
                    showToast('Error: ' + e.message, 'danger');
                } finally {
                    btn.prop('disabled', false);
                }
            }

            function buildModalForm(config) {
                let html = '';
                (config.params || []).forEach(function (p) {
                    const id = 'ap-' + p.name;
                    if (p.type === 'select') {
                        html += '<div class="mb-2"><label class="form-label small mb-0" for="' + id + '">' + p.label + '</label>';
                        html += '<select class="form-select form-select-sm action-param" id="' + id + '" data-name="' + p.name + '">';
                        (p.options || []).forEach(function (opt) {
                            const sel = opt == p.default ? ' selected' : '';
                            html += '<option value="' + opt + '"' + sel + '>' + opt + '</option>';
                        });
                        html += '</select></div>';
                    } else {
                        const inputType = p.type === 'number' ? 'number' : 'text';
                        html += '<div class="mb-2"><label class="form-label small mb-0" for="' + id + '">' + p.label + '</label>';
                        html += '<input type="' + inputType + '" class="form-control form-control-sm action-param" id="' + id + '" data-name="' + p.name + '" value="' + (p.default !== undefined ? p.default : '') + '"></div>';
                    }
                });
                return html;
            }

            function collectModalParams() {
                const params = {};
                $('#actionModalBody .action-param').each(function () {
                    const $el = $(this);
                    const name = $el.data('name');
                    const val = $el.val();
                    if ($el.attr('type') === 'number') {
                        params[name] = val !== '' ? Number(val) : null;
                    } else {
                        params[name] = val;
                    }
                });
                return params;
            }

            const actionModal = new bootstrap.Modal('#actionModal');

            $('#btn-action').on('click', function () {
                if (selected.size === 0) return;
                if (currentAction === 'copy') {
                    copyDataTableToClipboard(table, {
                        selector: selected.size > 0 ? '.selected' : {search: 'applied'},
                        extraColumns: [{header: 'DeviceId', getValue: function(d) { return d.deviceId !== undefined ? String(d.deviceId) : ''; }}]
                    });
                    return;
                }
                if (currentAction === 'unmark') {
                    selected.clear();
                    table.rows().every(function () {
                        $(this.node()).removeClass('selected');
                    });
                    updateActionBar();
                    return;
                }
                const config = actionParams[currentAction];
                if (config && config.params && config.params.length > 0) {
                    $('#actionModalTitle').text(config.label || currentAction);
                    $('#actionModalBody').html(buildModalForm(config));
                    actionModal.show();
                } else {
                    executeAction(currentAction, collectSelectedItems(), {});
                }
            });

            $('#actionModalOk').on('click', function () {
                const params = collectModalParams();
                actionModal.hide();
                executeAction(currentAction, collectSelectedItems(), params);
            });

            $('#actionModal').on('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    $('#actionModalOk').click();
                }
            });

            $(document).on('keydown', function (e) {
                if (e.key === ' ' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                    const tag = document.activeElement && document.activeElement.tagName;
                    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
                    if (!hoveredRow || !table) return;
                    e.preventDefault();
                    const $row = $(hoveredRow);
                    const d = table.row($row).data();
                    if (!d) return;
                    const k = itemKey(d);
                    if (selected.has(k)) {
                        selected.delete(k);
                        $row.removeClass('selected');
                        $row.find('.row-check').prop('checked', false);
                    } else {
                        selected.add(k);
                        $row.addClass('selected');
                        $row.find('.row-check').prop('checked', true);
                    }
                    updateActionBar();
                    return;
                }
                if (e.key === 'c' && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) {
                    const tag = document.activeElement && document.activeElement.tagName;
                    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
                    e.preventDefault();
                    const sel = table.rows('.selected').count();
                    const selector = sel > 0 ? '.selected' : {search: 'applied'};
                    copyDataTableToClipboard(table, {
                        selector: selector,
                        extraColumns: [{header: 'DeviceId', getValue: function(d) { return d.deviceId !== undefined ? String(d.deviceId) : ''; }}]
                    });
                    return;
                }
                if (!e.ctrlKey && !e.metaKey && !e.altKey && e.key === '/') {
                    e.preventDefault();
                    const searchInput = $('#dt-search-0.dt-input');
                    searchInput.focus();
                    searchInput.select();
                    return;
                }
                if (e.key.toLowerCase() === 'k' && (e.ctrlKey || e.metaKey) && !e.altKey) {
                    e.preventDefault();
                    if (e.shiftKey) {
                        table.rows({ search: 'applied' }).every(function () {
                            const d = this.data();
                            if (!d) return;
                            selected.delete(itemKey(d));
                            $(this.node()).removeClass('selected');
                            $(this.node()).find('.row-check').prop('checked', false);
                        });
                    } else {
                        table.rows({ search: 'applied' }).every(function () {
                            const d = this.data();
                            if (!d) return;
                            selected.add(itemKey(d));
                            $(this.node()).addClass('selected');
                            $(this.node()).find('.row-check').prop('checked', true);
                        });
                    }
                    updateActionBar();
                }
            });
        });
        </script>
        """
        h.write(data)
        h.flush()

    def cb_bacnetobjectproperties(self, handler, params):
        """BACnet object properties detail page.
        GET /bacnetobjectproperties?task=&lt;taskkey&gt;&amp;device=&lt;deviceId&gt;&amp;type=&lt;type&gt;&amp;instance=&lt;instance&gt;
          task     : MBIOTaskBacnet key
          device   : numeric deviceId or "local"
          type     : BACnet object type (e.g. analog-value, binary-input)
          instance : BACnet object instance number
        Displays all BACnet properties (key properties first) with auto-refresh every 5 s.
        Flash animation on value change. Live trend chart for presentValue (analog/digital).
        For commandable objects: priority array table with write/release per slot,
        plus a quick-force bar. Out-of-service toggle button.
        """
        mbio = self.getMBIO()
        task_key = params.get('task', '')
        device_id = params.get('device', '')
        obj_type = params.get('type', '')
        obj_instance = params.get('instance', '')

        h = HtmlPage('BACnet Object Properties', handler)
        h.variable('mbio.version', mbio.version)
        h.variable('main.nav', self._navHtml())
        h.variable('bacnet.nav', self._bacnetNavHtml())
        h.variable('auth.logout', self._logoutHtml())
        h.variable('task', task_key)
        h.variable('device', device_id)
        h.variable('objtype', obj_type)
        h.variable('objinstance', obj_instance)

        data = """
            <style>
            @keyframes flash-yellow {
                0%   { background-color: #fff3cd; }
                100% { background-color: transparent; }
            }
            #props tbody tr.value-changed {
                animation: flash-yellow 1.5s ease-out;
            }
            .pa-table td { vertical-align: middle; }
            .pa-row-active { background-color: rgba(13,110,253,.06) !important; border-left: 3px solid #0d6efd; }
            .pa-row-idle { opacity: .5; }
            .pa-row-idle:hover { opacity: 1; transition: opacity .15s; }
            .pa-priority-num { min-width: 2rem; font-size: .8rem; font-weight: 600; }
            .pa-name-cell { font-size: .875rem; min-width: 11rem; }
            .pa-row-active .pa-name-cell { font-weight: 600; color: #0d6efd; }
            .pa-ctrl-cell .input-group { max-width: 200px; }
            .pa-ctrl-cell { white-space: nowrap; }
            /* Status flags pills */
            .sf-pill { font-size: .75rem; padding: .2em .6em; border-radius: 999px; margin-right: .2em;
                       display: inline-block; font-weight: 500; }
            .sf-inactive { background-color: #e9ecef; color: #adb5bd; }
            </style>
            <div class="page container-fluid">
            <div class="card p-4 p-lg-5">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
            <div>
            <h1 class="h3 mb-1">BACnet Object Properties</h1>
            <p class="text-secondary mb-0">
                <a href="/bacnet">BACnet</a> /
                <a href="/bacnetobjects?task={task}&amp;device={device}">device {device}</a> /
                <b>{objtype} / {objinstance}</b>
            </p>
            </div>
            <div class="text-muted small">{mbio.version} /
            {main.nav} / <a href="/bacnet">BACnet Devices</a>
            <span class="ms-2 d-inline-flex gap-2 align-items-center">
            <button id="oos-btn" class="btn btn-sm btn-outline-secondary" title="Basculer outOfService">Out of Service</button>
            <button id="btn-refresh" class="btn btn-sm btn-outline-secondary">Refresh</button>
            </span>{auth.logout}
            </div>
            </div>
            <table id="props" class="display nowrap" style="width:100%%">
            <thead>
            <tr>
            <th data-priority="1">Property</th>
            <th data-priority="1">Value</th>
            </tr>
            </thead>
            </table>
            </div>

            <div id="trend-section" class="card p-3 mt-3" style="display:none">
            <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="fw-semibold small text-secondary">Tendance — presentValue</span>
            <span class="d-flex align-items-center gap-2">
            <span id="trend-duration" class="text-muted" style="font-size:.75rem"></span>
            <button id="trend-clear" class="btn btn-outline-secondary" style="font-size:.7rem;padding:.1rem .5rem;line-height:1.4">Effacer</button>
            </span>
            </div>
            <div style="height:110px;position:relative">
            <canvas id="trend-chart"></canvas>
            </div>
            </div>


            <div id="pa-section" class="card p-4 p-lg-5 mt-3" style="display:none">
            <h2 class="h5 mb-3">Priority Array</h2>
            <table class="table table-sm pa-table">
            <thead><tr>
                <th style="width:3rem" class="text-center">#</th>
                <th>Name</th>
                <th>Value</th>
                <th></th>
            </tr></thead>
            <tbody id="pa-body"></tbody>
            </table>
            </div>
            </div>
        """
        h.write(data)

        data = """
        <script>
        $(function () {
            const taskKey = "{task}";
            const deviceId = "{device}";
            const objType = "{objtype}";
            const objInstance = "{objinstance}";
            const apiUrl = "/api/v1/getbacnetobjectproperties?task=" + encodeURIComponent(taskKey)
                         + "&device=" + encodeURIComponent(deviceId)
                         + "&type=" + encodeURIComponent(objType)
                         + "&instance=" + encodeURIComponent(objInstance);

            const PA_NAMES = {
                1: "Manual Life Safety",
                2: "Automatic Life Safety",
                3: "Available",
                4: "Available",
                5: "Critical Equipment Control",
                6: "Minimum On/Off",
                7: "Available",
                8: "Manual Operator",
                9: "Available",
                10: "Available",
                11: "Available",
                12: "Available",
                13: "Available",
                14: "Available",
                15: "Available",
                16: "Default (relinquishDefault)"
            };

            const prevValues = new Map();
            let oosValue = false;
            let objLabels = null;

            // --- Tendance presentValue ---
            const TREND_MAX = 120;
            const trendLabels = [];
            const trendData = [];
            let trendChart = null;
            const isDigital   = objType.startsWith('binary-');
            const isMultiState = objType.startsWith('multi-state-');
            const isStepped   = isDigital || isMultiState;

            function nowLabel() {
                const d = new Date();
                return d.getHours().toString().padStart(2,'0') + ':'
                     + d.getMinutes().toString().padStart(2,'0') + ':'
                     + d.getSeconds().toString().padStart(2,'0');
            }

            function toTrendValue(v) {
                if (typeof v === 'boolean') return v ? 1 : 0;
                if (typeof v === 'number')  return v;
                return null;
            }

            function initTrendChart() {
                const ctx = document.getElementById('trend-chart').getContext('2d');
                const yScale = isDigital
                    ? { min: -0.1, max: 1.1,
                        ticks: { stepSize: 1, font: { size: 10 },
                                 callback: function(v) { return v === 0 ? 'OFF' : v === 1 ? 'ON' : ''; } },
                        grid: { color: 'rgba(0,0,0,.04)' } }
                    : { ticks: { font: { size: 10 } }, grid: { color: 'rgba(0,0,0,.04)' } };
                trendChart = new Chart(ctx, {
                    type: 'line',
                    data: { labels: trendLabels, datasets: [{
                        data: trendData,
                        borderColor: '#0d6efd',
                        backgroundColor: 'rgba(13,110,253,.07)',
                        borderWidth: 1.5,
                        pointRadius: 0,
                        pointHoverRadius: 3,
                        stepped: isStepped ? 'before' : false,
                        tension: isStepped ? 0 : 0.3,
                        fill: true,
                    }]},
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: { duration: 0 },
                        plugins: { legend: { display: false },
                                   tooltip: { mode: 'index', intersect: false } },
                        scales: {
                            x: { ticks: { maxTicksLimit: 8, font: { size: 10 } },
                                 grid: { color: 'rgba(0,0,0,.04)' } },
                            y: yScale
                        }
                    }
                });
            }

            function pushTrendPoint(value) {
                trendLabels.push(nowLabel());
                trendData.push(value);
                if (trendLabels.length > TREND_MAX) { trendLabels.shift(); trendData.shift(); }
                $('#trend-section').show();         // visible AVANT init (dimensions non nulles)
                if (!trendChart) initTrendChart();
                else trendChart.update();
                if (trendLabels.length >= 2)
                    $('#trend-duration').text(trendLabels[0] + ' \u2192 ' + trendLabels[trendLabels.length - 1]);
            }

            function updateTrend() {
                if (!table) return;
                const rows = table.rows().data().toArray();
                for (let i = 0; i < rows.length; i++) {
                    if (rows[i] && rows[i].property === 'presentValue') {
                        const tv = toTrendValue(rows[i].value);
                        if (tv !== null) pushTrendPoint(tv);
                        break;
                    }
                }
            }

            $('#trend-clear').on('click', function () {
                trendLabels.length = 0;
                trendData.length = 0;
                if (trendChart) trendChart.update();
                $('#trend-section').hide();
                $('#trend-duration').text('');
            });

            // --- Rendus visuels spéciaux ---
            function renderStatusFlags(v) {
                if (typeof v !== 'object' || v === null) return String(v);
                const defs = [
                    { key: 'inAlarm',      label: 'inAlarm',      cls: 'bg-danger text-white' },
                    { key: 'fault',        label: 'fault',         cls: 'bg-danger text-white' },
                    { key: 'overridden',   label: 'overridden',    cls: 'bg-warning text-dark' },
                    { key: 'outOfService', label: 'outOfService',  cls: 'bg-secondary text-white' },
                ];
                return defs.map(function(d) {
                    const cls = v[d.key] === true ? 'sf-pill ' + d.cls : 'sf-pill sf-inactive';
                    return '<span class="' + cls + '">' + d.label + '</span>';
                }).join('');
            }
            function renderReliability(v) {
                const s = String(v === null || v === undefined ? '' : v);
                const ok = s === 'no-fault-detected' || s === 'no-fault' || s === '';
                return '<span class="badge ' + (ok ? 'bg-success' : 'bg-danger') + '">' + (s || 'no-fault-detected') + '</span>';
            }
            function renderEventState(v) {
                const s = String(v === null || v === undefined ? 'normal' : v);
                const ok = s === 'normal';
                return '<span class="badge ' + (ok ? 'bg-success' : 'bg-warning text-dark') + '">' + s + '</span>';
            }
            function renderOutOfService(v) {
                return v === true
                    ? '<span class="badge bg-warning text-dark">out-of-service</span>'
                    : '<span class="badge bg-success">normal</span>';
            }

            function updateOosButton(oos) {
                oosValue = oos;
                const btn = $('#oos-btn');
                if (oos) {
                    btn.removeClass('btn-outline-secondary').addClass('btn-warning');
                    btn.html('Out of Service <span class="badge bg-dark ms-1">ON</span>');
                } else {
                    btn.removeClass('btn-warning').addClass('btn-outline-secondary');
                    btn.text('Out of Service');
                }
            }

            function applyFlash() {
                if (!table) return;
                table.rows().every(function () {
                    const d = this.data();
                    if (!d) return;
                    const k = d.property;
                    const prev = prevValues.get(k);
                    const curr = d.value;
                    let changed = false;
                    if (prev !== undefined) {
                        if (typeof prev === 'number' && typeof curr === 'number') {
                            changed = Math.abs(prev - curr) > 0.001;
                        } else {
                            changed = String(prev) !== String(curr);
                        }
                    }
                    prevValues.set(k, curr);
                    if (changed) {
                        const $row = $(this.node());
                        $row.removeClass('value-changed');
                        void $row[0].offsetWidth;
                        $row.addClass('value-changed');
                    }
                });
            }

            let table = null;
            table = new DataTable('#props', {
                responsive: true,
                paging: false,
                searching: false,
                ordering: false,
                info: false,
                ajax: { url: apiUrl, dataSrc: function(json) {
                    if (json.labels !== undefined) objLabels = json.labels;
                    return json.data;
                }},
                columns: [
                    { data: "property" },
                    { data: "value", render: function(v, type, row) {
                        if (type !== 'display') {
                            return v === null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v));
                        }
                        const prop = row.property;
                        if (prop === 'statusFlags') return renderStatusFlags(v);
                        if (prop === 'reliability') return renderReliability(v);
                        if (prop === 'eventState') return renderEventState(v);
                        if (prop === 'outOfService') return renderOutOfService(v);
                        if (v === null || v === undefined) return '<span class="text-muted">&mdash;</span>';
                        if (prop === 'presentValue') {
                            const fmt = typeof v === 'number' && !Number.isInteger(v) ? v.toFixed(3) : String(v);
                            let html = '<strong>' + fmt + '</strong>';
                            if (objLabels && objLabels.length > 0) {
                                let lbl = null;
                                if (typeof v === 'boolean') { lbl = objLabels[v ? 1 : 0]; }
                                else if (typeof v === 'number') { lbl = objLabels[Math.round(v) - 1]; }
                                if (lbl !== undefined && lbl !== null)
                                    html += '<br><small class="text-secondary fst-italic">' + lbl + '</small>';
                            }
                            return html;
                        }
                        if (prop === 'stateText' && Array.isArray(v)) {
                            return v.map(function(s, i) {
                                return '<span class="badge bg-light text-dark border me-1 mb-1">' + (i + 1) + ' &nbsp;' + s + '</span>';
                            }).join('');
                        }
                        if (prop === 'activeText') return '<span class="badge bg-success">' + String(v) + '</span>';
                        if (prop === 'inactiveText') return '<span class="badge bg-secondary">' + String(v) + '</span>';
                        if (typeof v === 'number' && !Number.isInteger(v)) return v.toFixed(3);
                        if (Array.isArray(v)) return v.join(', ');
                        if (typeof v === 'object') return JSON.stringify(v);
                        return String(v);
                    }}
                ],
                drawCallback: function () { applyFlash(); updateTrend(); }
            });

            function isUserEditing() {
                return $('input:focus, select:focus, textarea:focus').length > 0;
            }

            setInterval(function () {
                if (!isUserEditing()) table.ajax.reload(null, false);
            }, 5000);

            // Priority Array
            let paCommandable = false;

            function priorityBadgeClass(p) {
                if (p <= 2) return 'bg-danger';
                if (p === 5 || p === 6) return 'bg-warning text-dark';
                if (p === 8) return 'bg-primary';
                if (p === 16) return 'bg-secondary';
                return 'bg-light text-dark border';
            }

            function renderPriorityArray(pa) {
                const tbody = $('#pa-body');
                tbody.empty();
                pa.forEach(function (val, idx) {
                    const priority = idx + 1;
                    const isActive = val !== null && val !== undefined;
                    const displayVal = isActive
                        ? (typeof val === 'boolean' ? (val ? 1 : 0) : String(val))
                        : '';
                    const rowClass = isActive ? 'pa-row-active' : 'pa-row-idle';
                    const row = $('<tr id="pa-row-' + priority + '" class="' + rowClass + '">');

                    // Badge priorité
                    const badgeTd = $('<td class="text-center">');
                    badgeTd.append($('<span class="badge rounded-pill pa-priority-num ' + priorityBadgeClass(priority) + '">').text(priority));
                    row.append(badgeTd);

                    // Nom
                    row.append($('<td class="pa-name-cell">').text(PA_NAMES[priority] || ''));

                    // Input-group valeur + bouton write
                    const ctrlTd = $('<td class="pa-ctrl-cell">');
                    const ig = $('<div class="input-group input-group-sm">');
                    const input = $('<input type="text" class="form-control" id="pa-input-' + priority + '" placeholder="—">').val(displayVal);
                    const btnWrite = $('<button class="btn btn-outline-success" type="button" title="Ecrire">&#10003;</button>');
                    ig.append(input).append(btnWrite);
                    ctrlTd.append(ig);
                    row.append(ctrlTd);

                    // Bouton Release
                    const relTd = $('<td>');
                    const btnRelease = $('<button class="btn btn-sm btn-outline-danger pa-release" type="button">Release</button>');
                    if (!isActive) btnRelease.hide();
                    relTd.append(btnRelease);
                    row.append(relTd);

                    input.on('keydown', function (e) {
                        if (e.key === 'Enter') { e.preventDefault(); btnWrite.trigger('click'); }
                    });
                    btnWrite.on('click', function () {
                        const rawVal = input.val().trim();
                        if (rawVal === '') return;
                        const numVal = parseFloat(rawVal);
                        writePriority(priority, isNaN(numVal) ? rawVal : numVal);
                    });
                    btnRelease.on('click', function () {
                        writePriority(priority, null);
                    });

                    tbody.append(row);
                });
            }

            async function writePriority(priority, value) {
                let ok = false;
                try {
                    const resp = await fetch('/api/v1/bacnetwritepriority', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            task: taskKey, device: deviceId,
                            type: objType, instance: objInstance,
                            priority: priority,
                            value: value
                        })
                    });
                    const result = await resp.json();
                    ok = result.success === true;
                } catch (err) { }
                if (value === null) {
                    showToast(ok ? 'P' + priority + ' released' : 'Release P' + priority + ' failed', ok ? 'success' : 'danger');
                } else {
                    showToast(ok ? 'P' + priority + ' \u2190 ' + value : 'Write P' + priority + ' failed', ok ? 'success' : 'danger');
                }
                table.ajax.reload(null, false);
                loadPriorityArray();
            }

            async function loadPriorityArray() {
                try {
                    const resp = await fetch(apiUrl);
                    const json = await resp.json();
                    // Mise à jour bouton OOS
                    if (json.out_of_service !== undefined) updateOosButton(json.out_of_service);
                    if (json.labels !== undefined) objLabels = json.labels;
                    if (!json.commandable || !json.priority_array) {
                        $('#pa-section').hide();
                        return;
                    }
                    $('#pa-section').show();
                    paCommandable = true;
                    const focusedId = document.activeElement ? document.activeElement.id : null;
                    const savedVal = focusedId ? $('#' + CSS.escape(focusedId)).val() : null;
                    renderPriorityArray(json.priority_array);
                    if (focusedId && savedVal !== null) {
                        const $el = $('#' + CSS.escape(focusedId));
                        if ($el.length) { $el.val(savedVal).focus(); }
                    }
                } catch (err) {
                    $('#pa-section').hide();
                }
            }

            loadPriorityArray();
            setInterval(function () {
                if (paCommandable && !isUserEditing()) loadPriorityArray();
            }, 10000);

            // --- Out of Service ---
            $('#oos-btn').on('click', async function () {
                const newOos = !oosValue;
                let ok = false;
                try {
                    const resp = await fetch('/api/v1/bacnetwriteproperty', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            task: taskKey, device: deviceId,
                            type: objType, instance: objInstance,
                            property: 'outOfService', value: newOos
                        })
                    });
                    const result = await resp.json();
                    ok = result.success === true;
                } catch (e) {}
                showToast(ok ? 'Out of Service ' + (newOos ? 'enabled' : 'disabled') : 'Out of Service write failed', ok ? 'success' : 'danger');
                table.ajax.reload(null, false);
                loadPriorityArray();
            });


            $('#btn-refresh').on('click', async function () {
                await fetch('/api/v1/refreshbacnet?task=' + encodeURIComponent(taskKey)
                          + '&device=' + encodeURIComponent(deviceId));
                table.ajax.reload();
                loadPriorityArray();
            });

            $(document).on('keydown', function (e) {
                if ($(e.target).is('input, textarea, select')) return;
                if (e.key === 'c' && (e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey) {
                    e.preventDefault();
                    if (table) copyDataTableToClipboard(table);
                }
            });
        });
        </script>
        """
        h.write(data)
        h.flush()

    # -------------------------------------------------------------------------
    # BACnet Schedule API + editor
    # -------------------------------------------------------------------------

    def cb_getbacnetschedules(self, handler, params):
        """List all locally declared Schedule objects for a BACnet task.
        GET /api/v1/getbacnetschedules?task=&lt;taskkey&gt;
        Returns {"data": [{"name", "instance", "description", "presentValue",
                            "scheduleDefault"}, ...]}
        """
        task_key = params.get('task')
        if not task_key:
            return self.cb_write_failure(handler)
        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)
        client = task.client()
        if not client:
            return self.cb_write_failure(handler)
        schedules = client.retrieveLocalSchedules() or []
        self.cb_write_json(handler, {'data': schedules})
        return True

    def cb_getschedule(self, handler, params):
        """Read the full data of a local Schedule object.
        GET /api/v1/getschedule?task=&lt;taskkey&gt;&amp;name=&lt;objectName&gt;
        Returns {"weeklySchedule", "exceptionSchedule", "scheduleDefault",
                 "description", "presentValue"}.
        weeklySchedule is a list of 7 day-lists (index 0 = Monday).
        Each day-list contains {"time": [h,m,s,cs], "value": {"t","v"}} entries.
        """
        task_key = params.get('task')
        name = params.get('name')
        if not task_key or not name:
            return self.cb_write_failure(handler)
        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)
        client = task.client()
        if not client:
            return self.cb_write_failure(handler)
        data = client.getScheduleData(name)
        if data is None:
            return self.cb_write_failure(handler)
        self.cb_write_json(handler, data)
        return True

    def cb_writeschedule(self, handler, params, data=None):
        """Write weeklySchedule and/or scheduleDefault of a local Schedule object.
        POST /api/v1/writeschedule
        Body: {"task": &lt;taskkey&gt;, "name": &lt;objectName&gt;,
               "weeklySchedule": [...],   (optional)
               "scheduleDefault": {...}}  (optional)
        Triggers BACnet persistence after the write.
        """
        try:
            payload = json.loads(data) if isinstance(data, str) else (data or {})
        except (json.JSONDecodeError, TypeError):
            return self.cb_write_failure(handler)
        task_key = payload.get('task')
        name = payload.get('name')
        weekly = payload.get('weeklySchedule')
        sched_default = payload.get('scheduleDefault')
        if not task_key or not name:
            return self.cb_write_failure(handler)
        mbio = self.getMBIO()
        task = mbio.task(task_key)
        if not task:
            return self.cb_write_failure(handler)
        client = task.client()
        if not client:
            return self.cb_write_failure(handler)
        ok = client.writeScheduleData(name, weekly=weekly, sched_default=sched_default)
        if ok:
            return self.cb_write_success(handler)
        return self.cb_write_failure(handler)

    def cb_bacnetschedule(self, handler, params):
        """BACnet Schedule visual editor (FullCalendar).
        GET /bacnetschedule?task=&lt;taskkey&gt;&amp;name=&lt;objectName&gt;
          task : MBIOTaskBacnet key
          name : Schedule object name (local device only)
        Displays a FullCalendar timeGridWeek view on a fixed reference week
        (Mon 6 Jan 2025).  Drag-and-drop to move events, click to edit values,
        click on an empty slot to add a new event.  Save writes the result back
        to the BACnet server via POST /api/v1/writeschedule.
        """
        mbio = self.getMBIO()
        task_key = params.get('task', '')
        sched_name = params.get('name', '')

        h = HtmlPage('Schedule Editor - %s' % sched_name, handler)
        h.header('<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet">')
        h.variable('mbio.version', mbio.version)
        h.variable('main.nav', self._navHtml())
        h.variable('bacnet.nav', self._bacnetNavHtml())
        h.variable('auth.logout', self._logoutHtml())
        h.variable('task', task_key)
        h.variable('schedname', sched_name)

        data = """
            <style>
            #calendar { min-height: 600px; }
            .fc-event { cursor: pointer; border-radius: 4px !important; border: none !important; }
            .fc-event-title { font-weight: 600; font-size: .8rem; }
            .fc-timegrid-slot { height: 1.8em !important; }
            .fc-timegrid-slot-minor { border-top-style: dotted !important; }
            .fc-col-header-cell { background: #f8f9fa; border-bottom: 2px solid #dee2e6 !important; }
            .fc-col-header-cell.fc-day-sat,
            .fc-col-header-cell.fc-day-sun { background: #e9ecef; }
            .fc-timegrid-col.fc-day-sat,
            .fc-timegrid-col.fc-day-sun { background: rgba(0,0,0,.018); }
            .fc-col-header-cell-cushion {
                font-size: .75rem; font-weight: 700; letter-spacing: .06em;
                text-transform: uppercase; color: #495057; text-decoration: none !important;
            }
            .fc-timegrid-axis { font-size: .72rem; color: #6c757d; }
            .fc-scrollgrid { border-radius: 6px; overflow: hidden; }
            </style>
            <div class="page container-fluid">
            <div class="card p-4 p-lg-5">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
            <div>
            <h1 class="h3 mb-1">Schedule Editor</h1>
            <p class="text-secondary mb-0">
                <a href="/bacnet">BACnet</a> /
                <a href="/bacnetobjects?task={task}&amp;device=local">device local</a> /
                <b>{schedname}</b>
            </p>
            </div>
            <div class="text-muted small">{mbio.version} /
            {main.nav} / <a href="/bacnet">BACnet Devices</a>
            {auth.logout}
            </div>
            </div>
            <div class="d-flex align-items-center gap-3 mb-3 flex-wrap">
            <span class="small text-muted">Default: <b id="sched-default-val">&mdash;</b>
            <button id="btn-edit-default" class="btn btn-link btn-sm p-0 ms-1" style="font-size:.75rem;vertical-align:baseline" title="Edit default value">edit</button></span>
            <span class="small text-muted">Current: <b id="sched-current-val">&mdash;</b></span>
            <span class="small text-muted fst-italic" id="sched-description"></span>
            <div class="ms-auto d-flex gap-2">
            <button id="btn-reload" class="btn btn-sm btn-outline-secondary">Reload</button>
            <button id="btn-save" class="btn btn-sm btn-primary">Save</button>
            </div>
            </div>
            <div id="calendar"></div>
            </div>
            </div>

            <!-- Modal edition/creation d'un evenement -->
            <div class="modal fade" id="evModal" tabindex="-1">
            <div class="modal-dialog modal-sm modal-dialog-centered">
            <div class="modal-content">
            <div class="modal-header py-2">
                <h6 class="modal-title" id="evModalTitle">Event</h6>
                <button type="button" class="btn-close btn-close-sm" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-2">
                <div class="mb-2" id="ev-time-row">
                <label class="form-label small mb-0">Start time (HH:MM)</label>
                <input type="text" id="ev-time" class="form-control form-control-sm" placeholder="HH:MM" maxlength="5">
                </div>
                <div class="mb-2" id="ev-endtime-row">
                <label class="form-label small mb-0">End time (HH:MM, optional)</label>
                <input type="text" id="ev-endtime" class="form-control form-control-sm" placeholder="HH:MM" maxlength="5">
                </div>
                <div>
                <label class="form-label small mb-0">Value</label>
                <div id="ev-value-wrap"></div>
                </div>
            </div>
            <div class="modal-footer py-1 justify-content-between">
                <button type="button" class="btn btn-sm btn-outline-danger" id="ev-delete">Delete</button>
                <div class="d-flex gap-2">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-sm btn-primary" id="evModalOk">OK</button>
                </div>
            </div>
            </div>
            </div>
            </div>
        """
        h.write(data)

        h.write('<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>')

        data = """
        <script>
        $(function () {
            const taskKey = "{task}";
            const schedName = "{schedname}";
            const REF_DATES = [
                '2025-01-06','2025-01-07','2025-01-08','2025-01-09',
                '2025-01-10','2025-01-11','2025-01-12'
            ];

            let schedDefault = null;
            let calendar = null;
            let _editingEvent = null;
            let _createDate = null;
            let _editingDefault = false;

            // --- Helpers ---

            function fmtTime(t) {
                return String(t[0]).padStart(2,'0') + ':' + String(t[1]).padStart(2,'0') + ':' + String(t[2]).padStart(2,'0');
            }

            function localDateStr(d) {
                return d.getFullYear() + '-'
                    + String(d.getMonth() + 1).padStart(2,'0') + '-'
                    + String(d.getDate()).padStart(2,'0');
            }

            function fmtValue(vdata) {
                if (!vdata) return '?';
                if (vdata.t === 'real') return String(parseFloat(vdata.v.toFixed(3)));
                if (vdata.t === 'unsigned') return String(vdata.v);
                if (vdata.t === 'enum' || vdata.t === 'bool') return vdata.v ? 'ON' : 'OFF';
                return '?';
            }

            function eventColor(vdata) {
                if (!vdata) return '#6c757d';
                if (vdata.t === 'enum' || vdata.t === 'bool') {
                    return vdata.v ? '#198754' : '#adb5bd';
                }
                const palette = ['#0d6efd','#dc3545','#fd7e14','#20c997','#6610f2','#d63384','#0dcaf0','#ffc107'];
                const v = typeof vdata.v === 'number' ? Math.round(Math.abs(vdata.v)) : 0;
                return palette[v % palette.length];
            }

            function buildValueData(rawVal) {
                if (!schedDefault) return null;
                const t = schedDefault.t;
                if (t === 'real') {
                    const v = parseFloat(rawVal);
                    return isNaN(v) ? null : {t: 'real', v: v};
                }
                if (t === 'unsigned') {
                    const v = parseInt(rawVal);
                    return (isNaN(v) || v < 0) ? null : {t: 'unsigned', v: v};
                }
                if (t === 'enum') {
                    return {t: 'enum', v: (rawVal === '1' || rawVal === true) ? 1 : 0};
                }
                if (t === 'bool') {
                    return {t: 'bool', v: (rawVal === '1' || rawVal === true)};
                }
                return null;
            }

            function valueInputHtml(currentVdata) {
                const t = schedDefault ? schedDefault.t : 'real';
                const v = currentVdata ? currentVdata.v : (schedDefault ? schedDefault.v : 0);
                if (t === 'real') {
                    return '<input type="number" step="0.1" id="ev-value" class="form-control form-control-sm" value="' + (v !== undefined ? v : 0) + '">';
                }
                if (t === 'unsigned') {
                    return '<input type="number" step="1" min="0" id="ev-value" class="form-control form-control-sm" value="' + (v !== undefined ? v : 0) + '">';
                }
                const sel0 = (!v || v === 0 || v === false) ? ' selected' : '';
                const sel1 = (v === 1 || v === true) ? ' selected' : '';
                return '<select id="ev-value" class="form-select form-select-sm">'
                    + '<option value="0"' + sel0 + '>OFF (0)</option>'
                    + '<option value="1"' + sel1 + '>ON (1)</option>'
                    + '</select>';
            }

            // --- Conversion weeklySchedule <-> FullCalendar events ---

            function isDefaultValue(vdata) {
                if (!schedDefault || !vdata) return false;
                return vdata.t === schedDefault.t && vdata.v === schedDefault.v;
            }

            function weeklyToEvents(weekly) {
                const events = [];
                for (let d = 0; d < 7; d++) {
                    const day = weekly[d] || [];
                    const dayEvents = [];
                    for (let i = 0; i < day.length; i++) {
                        const tv = day[i];
                        if (isDefaultValue(tv.value)) {
                            // Filler event — marks the explicit end of the previous real event
                            if (dayEvents.length > 0) {
                                const last = dayEvents[dayEvents.length - 1];
                                if (last.extendedProps.endTime === null) {
                                    last.end = REF_DATES[d] + 'T' + fmtTime(tv.time);
                                    last.extendedProps.endTime = [tv.time[0], tv.time[1], tv.time[2]];
                                }
                            }
                        } else {
                            const startStr = REF_DATES[d] + 'T' + fmtTime(tv.time);
                            dayEvents.push({
                                start: startStr,
                                end: REF_DATES[d] + 'T23:59:00',
                                title: fmtValue(tv.value),
                                color: eventColor(tv.value),
                                extendedProps: {valueData: tv.value, endTime: null}
                            });
                        }
                    }
                    // Events without explicit endTime: use next event start as visual end
                    for (let i = 0; i < dayEvents.length - 1; i++) {
                        if (dayEvents[i].extendedProps.endTime === null) {
                            dayEvents[i].end = dayEvents[i + 1].start;
                        }
                    }
                    dayEvents.forEach(function (ev) { events.push(ev); });
                }
                return events;
            }

            function eventsToWeekly() {
                const days = [[],[],[],[],[],[],[]];
                calendar.getEvents().forEach(function (ev) {
                    const start = ev.start;
                    const dateStr = localDateStr(start);
                    const dayIdx = REF_DATES.indexOf(dateStr);
                    if (dayIdx === -1) return;
                    days[dayIdx].push({
                        startSecs: start.getHours() * 3600 + start.getMinutes() * 60 + start.getSeconds(),
                        startArr: [start.getHours(), start.getMinutes(), start.getSeconds(), 0],
                        endTime: ev.extendedProps.endTime,
                        value: ev.extendedProps.valueData
                    });
                });
                const result = [[],[],[],[],[],[],[]];
                days.forEach(function (dayEvs, d) {
                    dayEvs.sort(function (a, b) { return a.startSecs - b.startSecs; });
                    dayEvs.forEach(function (ev, i) {
                        result[d].push({time: ev.startArr, value: ev.value});
                        // Insert filler at explicit end time if there's a gap before next event
                        if (ev.endTime && schedDefault) {
                            const endSecs = ev.endTime[0] * 3600 + ev.endTime[1] * 60 + (ev.endTime[2] || 0);
                            const nextSecs = (i + 1 < dayEvs.length) ? dayEvs[i + 1].startSecs : Infinity;
                            if (endSecs < nextSecs) {
                                result[d].push({
                                    time: [ev.endTime[0], ev.endTime[1], ev.endTime[2] || 0, 0],
                                    value: schedDefault
                                });
                            }
                        }
                    });
                });
                return result;
            }

            // --- FullCalendar init ---

            function initCalendar(events) {
                const calEl = document.getElementById('calendar');
                calendar = new FullCalendar.Calendar(calEl, {
                    initialView: 'timeGridWeek',
                    initialDate: '2025-01-06',
                    firstDay: 1,
                    headerToolbar: false,
                    dayHeaderContent: function (arg) {
                        const names = ['SUN','MON','TUE','WED','THU','FRI','SAT'];
                        return names[arg.date.getDay()];
                    },
                    slotDuration: '00:15:00',
                    snapDuration: '00:15:00',
                    scrollTime: '06:00:00',
                    slotLabelFormat: {hour: '2-digit', minute: '2-digit', hour12: false},
                    eventTimeFormat: {hour: '2-digit', minute: '2-digit', hour12: false},
                    allDaySlot: false,
                    editable: true,
                    selectable: true,
                    height: 'auto',
                    events: events,
                    eventClick: function (info) { openEditModal(info.event); },
                    select: function (info) {
                        _createDate = info.start;
                        const ts = String(info.start.getHours()).padStart(2,'0') + ':'
                                 + String(info.start.getMinutes()).padStart(2,'0');
                        const te = String(info.end.getHours()).padStart(2,'0') + ':'
                                 + String(info.end.getMinutes()).padStart(2,'0');
                        openCreateModal(ts, te);
                        calendar.unselect();
                    },
                    eventDrop: function (info) {
                        const newDate = localDateStr(info.event.start);
                        const newDay = REF_DATES.indexOf(newDate);
                        if (newDay !== -1) info.event.setExtendedProp('day', newDay);
                        // Maintain explicit end time after drop (preserve duration)
                        if (info.event.extendedProps.endTime !== null) {
                            const end = info.event.end;
                            if (end) info.event.setExtendedProp('endTime',
                                [end.getHours(), end.getMinutes(), end.getSeconds()]);
                        }
                    },
                    eventResize: function (info) {
                        const end = info.event.end;
                        if (end) info.event.setExtendedProp('endTime',
                            [end.getHours(), end.getMinutes(), end.getSeconds()]);
                    },
                });
                calendar.render();
            }

            // --- Modal ---

            const evModal = new bootstrap.Modal('#evModal');

            function openEditModal(event) {
                _editingEvent = event;
                _createDate = null;
                _editingDefault = false;
                $('#ev-time-row').show();
                $('#ev-endtime-row').show();
                $('#evModalTitle').text('Edit event');
                const start = event.start;
                $('#ev-time').val(String(start.getHours()).padStart(2,'0') + ':'
                               + String(start.getMinutes()).padStart(2,'0'));
                const et = event.extendedProps.endTime;
                $('#ev-endtime').val(et
                    ? String(et[0]).padStart(2,'0') + ':' + String(et[1]).padStart(2,'0')
                    : '');
                $('#ev-value-wrap').html(valueInputHtml(event.extendedProps.valueData));
                $('#ev-delete').show();
                evModal.show();
            }

            function openCreateModal(timeStr, endTimeStr) {
                _editingEvent = null;
                _editingDefault = false;
                $('#ev-time-row').show();
                $('#ev-endtime-row').show();
                $('#evModalTitle').text('New event');
                $('#ev-time').val(timeStr || '08:00');
                $('#ev-endtime').val(endTimeStr || '');
                $('#ev-value-wrap').html(valueInputHtml(null));
                $('#ev-delete').hide();
                evModal.show();
            }

            function openDefaultModal() {
                _editingEvent = null;
                _createDate = null;
                _editingDefault = true;
                $('#ev-time-row').hide();
                $('#ev-endtime-row').hide();
                $('#evModalTitle').text('Edit default value');
                $('#ev-value-wrap').html(valueInputHtml(schedDefault));
                $('#ev-delete').hide();
                evModal.show();
            }

            $('#evModalOk').on('click', function () {
                const rawVal = $('#ev-value').val();
                const vdata = buildValueData(rawVal);
                if (vdata === null) { showToast('Invalid value', 'danger'); return; }

                if (_editingDefault) {
                    schedDefault = vdata;
                    $('#sched-default-val').text(fmtValue(vdata));
                    evModal.hide();
                    _editingDefault = false;
                    return;
                }

                const tp = ($('#ev-time').val() || '00:00').split(':');
                const hh = parseInt(tp[0]) || 0, mm = parseInt(tp[1]) || 0;
                const etRaw = ($('#ev-endtime').val() || '').trim();
                let endTime = null;
                if (etRaw) {
                    const ep = etRaw.split(':');
                    const eh = parseInt(ep[0]) || 0, em = parseInt(ep[1]) || 0;
                    endTime = [eh, em, 0];
                }

                if (_editingEvent) {
                    const newStart = new Date(_editingEvent.start);
                    newStart.setHours(hh, mm, 0, 0);
                    let newEnd;
                    if (endTime) {
                        newEnd = new Date(newStart);
                        newEnd.setHours(endTime[0], endTime[1], 0, 0);
                        if (newEnd <= newStart) newEnd = new Date(newStart.getTime() + 30 * 60000);
                    } else {
                        newEnd = new Date(newStart.getTime() + 30 * 60000);
                    }
                    _editingEvent.setStart(newStart);
                    _editingEvent.setEnd(newEnd);
                    _editingEvent.setExtendedProp('valueData', vdata);
                    _editingEvent.setExtendedProp('endTime', endTime);
                    _editingEvent.setProp('title', fmtValue(vdata));
                    _editingEvent.setProp('color', eventColor(vdata));
                } else {
                    const base = _createDate || new Date('2025-01-06T00:00:00');
                    const newStart = new Date(base);
                    newStart.setHours(hh, mm, 0, 0);
                    let newEnd;
                    if (endTime) {
                        newEnd = new Date(newStart);
                        newEnd.setHours(endTime[0], endTime[1], 0, 0);
                        if (newEnd <= newStart) newEnd = new Date(newStart.getTime() + 30 * 60000);
                    } else {
                        newEnd = new Date(newStart.getTime() + 30 * 60000);
                    }
                    calendar.addEvent({
                        start: newStart, end: newEnd,
                        title: fmtValue(vdata), color: eventColor(vdata),
                        extendedProps: {valueData: vdata, endTime: endTime}
                    });
                }
                evModal.hide();
                _editingEvent = null;
            });

            $('#ev-delete').on('click', function () {
                if (_editingEvent) { _editingEvent.remove(); _editingEvent = null; }
                evModal.hide();
            });

            $('#evModal').on('keydown', function (e) {
                if (e.key === 'Enter') { e.preventDefault(); $('#evModalOk').click(); }
            });

            // --- Load / Save ---

            async function loadSchedule() {
                try {
                    const resp = await fetch('/api/v1/getschedule?task=' + encodeURIComponent(taskKey)
                        + '&name=' + encodeURIComponent(schedName));
                    if (!resp.ok) throw new Error('HTTP ' + resp.status);
                    const d = await resp.json();
                    schedDefault = d.scheduleDefault;
                    $('#sched-default-val').text(schedDefault ? fmtValue(schedDefault) : '?');
                    $('#sched-current-val').text(
                        (d.presentValue !== null && d.presentValue !== undefined) ? String(d.presentValue) : '\u2014'
                    );
                    $('#sched-description').text(d.description || '');
                    const events = weeklyToEvents(d.weeklySchedule || [[],[],[],[],[],[],[]]);
                    if (calendar) {
                        calendar.removeAllEvents();
                        events.forEach(function (ev) { calendar.addEvent(ev); });
                    } else {
                        initCalendar(events);
                    }
                } catch (e) {
                    showToast('Load error: ' + e.message, 'danger');
                }
            }

            $('#btn-edit-default').on('click', function () { openDefaultModal(); });

            $('#btn-save').on('click', async function () {
                const btn = $(this).prop('disabled', true);
                try {
                    const resp = await fetch('/api/v1/writeschedule', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            task: taskKey,
                            name: schedName,
                            weeklySchedule: eventsToWeekly(),
                            scheduleDefault: schedDefault
                        })
                    });
                    const result = await resp.json();
                    if (result.success) showToast('Saved', 'success');
                    else showToast('Save error', 'danger');
                } catch (e) {
                    showToast('Error: ' + e.message, 'danger');
                } finally {
                    btn.prop('disabled', false);
                }
            });

            $('#btn-reload').on('click', function () { loadSchedule(); });

            loadSchedule();
        });
        </script>
        """
        h.write(data)
        h.flush()

