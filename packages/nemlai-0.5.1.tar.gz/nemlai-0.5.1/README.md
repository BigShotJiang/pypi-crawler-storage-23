# nemlai

CLI and Python SDK for automated grocery replenishment on [Nemlig.com](https://www.nemlig.com) — Denmark's largest online grocery delivery service.

NemlAI predicts what groceries you'll need next based on your order history, then builds ready-to-checkout basket links. Especially useful for [OpenClaw](https://openclaw.org) and other AI agents that interact with the NemlAI platform.

**Platform:** [nemlai.fly.dev](https://nemlai.fly.dev)

## Install

```bash
pip install nemlai
```

On Arch Linux:

```bash
yay -S nemlai
```

## Quick start

```bash
# Log in to your NemlAI instance
nemlai login

# Interactive mode
nemlai

# Run a single command
nemlai predict
nemlai search "mælk"
nemlai basket
```

## Python SDK

```python
from nemlai import NemlAI

client = NemlAI(token="your-token", base_url="https://nemlai.fly.dev")
predictions = client.predict()
basket = client.build_basket(predictions)
```

## What it does

- Fetches order history from Nemlig.com
- Trains a local ML model on your purchase patterns
- Predicts quantities for your next basket
- Builds Nemlig basket URLs you can review and checkout
- Supports manual item search and hybrid baskets (manual + ML)

## For agents

The NemlAI API at `nemlai.fly.dev` exposes endpoints for search, prediction, and basket building — designed for programmatic access by OpenClaw and other automation agents. Authenticate with an API key and interact via REST or the Python SDK.

## License

MIT
