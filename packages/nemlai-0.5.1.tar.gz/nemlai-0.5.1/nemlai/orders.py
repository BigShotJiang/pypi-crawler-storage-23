"""Orders resource for the NemlAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nemlai.client import NemlAI


class OrdersResource:
    """Manage order history."""

    def __init__(self, client: "NemlAI") -> None:
        self._client = client

    def refresh(self, password: str, email: str = "") -> str:
        """POST ``/cli/api/orders/refresh`` -- refresh Nemlig order history."""
        payload: dict = {"password": password}
        if email:
            payload["email"] = email
        return self._client._post("/cli/api/orders/refresh", json=payload)
