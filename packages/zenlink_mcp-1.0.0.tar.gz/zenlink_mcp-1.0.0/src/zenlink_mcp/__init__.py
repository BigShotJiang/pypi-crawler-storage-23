"""ZenLink MCP - Browser automation for Claude Desktop via ZenLink."""
__version__ = "1.0.0"