from phylogenie.generators.msa.alisim import AliSimGenerator

MSAGeneratorConfig = AliSimGenerator

__all__ = ["MSAGeneratorConfig"]
