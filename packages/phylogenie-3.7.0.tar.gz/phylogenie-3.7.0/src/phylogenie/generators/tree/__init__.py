from phylogenie.generators.tree.phylogenie import PhylogenieGeneratorConfig

TreeGeneratorConfig = PhylogenieGeneratorConfig

__all__ = ["TreeGeneratorConfig"]
