from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

import phylogenie._typings as pgt


class StrictBaseModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Distribution(BaseModel):
    type: str
    model_config = ConfigDict(extra="allow")

    @property
    def args(self) -> dict[str, Any]:
        assert self.model_extra is not None
        return self.model_extra


Context = dict[str, str | Distribution]
Integer = str | int
Scalar = str | pgt.Scalar
ManyScalars = str | pgt.Many[Scalar]
OneOrManyScalars = Scalar | pgt.Many[Scalar]
OneOrMany2DScalars = Scalar | pgt.Many2D[Scalar]


class SkylineParameterModel(StrictBaseModel):
    value: ManyScalars
    change_times: ManyScalars


class SkylineVectorModel(StrictBaseModel):
    value: str | pgt.Many[OneOrManyScalars]
    change_times: ManyScalars


class SkylineMatrixModel(StrictBaseModel):
    value: str | pgt.Many[OneOrMany2DScalars]
    change_times: ManyScalars


SkylineParameter = Scalar | SkylineParameterModel
SkylineVector = str | pgt.Scalar | pgt.Many[SkylineParameter] | SkylineVectorModel
SkylineMatrix = str | pgt.Scalar | pgt.Many[SkylineVector] | SkylineMatrixModel | None


class TimedEventType(str, Enum):
    SAMPLING = "sampling"
    DEATH = "death"


class TimedEventModel(StrictBaseModel):
    times: ManyScalars
    firings: Scalar


class TimedSamplingModel(TimedEventModel):
    type: Literal[TimedEventType.SAMPLING]
    state: str | None = None
    removal: bool


class TimedDeathModel(TimedEventModel):
    type: Literal[TimedEventType.DEATH]
    state: str | None = None


TimedEvent = Annotated[
    TimedSamplingModel | TimedDeathModel, Field(discriminator="type")
]
