"""Custom build hook to generate lookup tables during build.

This hook runs during wheel builds (not sdist) to download dp.js from
dpcalc.org and generate the tables.py module. This ensures lookup tables
are never redistributed — they are generated on the user's machine at
install time.
"""

import logging
import sys
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

logger = logging.getLogger(__name__)


class CustomBuildHook(BuildHookInterface):  # type: ignore[misc]
    """Generate preservationeval lookup tables at build time."""

    PLUGIN_NAME = "custom"

    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        """Generate tables.py before building the wheel.

        Args:
            version: Build version type ("standard" or "editable").
            build_data: Mutable dict for controlling build output.
        """
        # Only generate for wheel builds (not sdist — IP protection)
        if self.target_name != "wheel":
            return

        src_path = str(Path(self.root) / "src")
        sys.path.insert(0, src_path)
        try:
            from preservationeval.utils.logging import (  # noqa: PLC0415
                Environment,
                setup_logging,
            )

            setup_logging(__name__, env=Environment.INSTALL)

            logger.info("Generating preservationeval lookup tables...")

            from preservationeval.install.generate_tables import (  # noqa: PLC0415
                generate_tables,
            )

            generate_tables()
        except Exception as exc:
            msg = (
                "Failed to generate lookup tables. This requires network "
                "access to download dp.js from dpcalc.org. "
                "See https://github.com/petter-b/preservationeval for details."
            )
            raise RuntimeError(msg) from exc
        finally:
            sys.path.pop(0)

        # For editable installs, Hatchling picks up tables.py from the source
        # tree directly; no force_include needed.
        if version == "editable":
            return

        # For standard builds, inject via force_include
        tables_path = str(Path(src_path) / "preservationeval" / "tables.py")
        build_data["force_include"][tables_path] = "preservationeval/tables.py"
