# CHANGELOG

<!-- version list -->

## v1.10.0 (2026-03-05)

### Features

- **split**: Add split/unsplit operations for all dataset formats
  ([#65](https://github.com/pirnerjonas/argus/pull/65),
  [`db3a199`](https://github.com/pirnerjonas/argus/commit/db3a1993055ad63b22b890bd99cb65ff602ca920))


## v1.9.0 (2026-03-05)

### Features

- **convert**: Add roboflow-coco-rle conversion target
  ([#64](https://github.com/pirnerjonas/argus/pull/64),
  [`19d2bcf`](https://github.com/pirnerjonas/argus/commit/19d2bcf9018ca8b72a5d0124c70448ef7c12c16d))


## v1.8.3 (2026-03-05)

### Bug Fixes

- **view**: Match COCO images when file_name contains a relative path
  ([#63](https://github.com/pirnerjonas/argus/pull/63),
  [`89bc24b`](https://github.com/pirnerjonas/argus/commit/89bc24b7a543adcee37410c195fb331ba17a1eae))


## v1.8.2 (2026-03-05)

### Bug Fixes

- **view**: Match COCO images with path prefixes in file_name
  ([#62](https://github.com/pirnerjonas/argus/pull/62),
  [`c2dba5a`](https://github.com/pirnerjonas/argus/commit/c2dba5a7c85d1243d3ac4435365682685476c56d))


## v1.8.1 (2026-03-04)

### Bug Fixes

- Correct filter spinner progress for COCO datasets
  ([#61](https://github.com/pirnerjonas/argus/pull/61),
  [`398b074`](https://github.com/pirnerjonas/argus/commit/398b07431d1a989a08318b0e95ecb53fae9785ce))

- **filter**: Correct spinner progress for COCO datasets
  ([#61](https://github.com/pirnerjonas/argus/pull/61),
  [`398b074`](https://github.com/pirnerjonas/argus/commit/398b07431d1a989a08318b0e95ecb53fae9785ce))


## v1.8.0 (2026-03-04)

### Features

- **convert**: Add YOLO-seg to Roboflow COCO conversion
  ([#58](https://github.com/pirnerjonas/argus/pull/58),
  [`08505ee`](https://github.com/pirnerjonas/argus/commit/08505ee7200afd4155bf427203ddfaf2b6fb978b))

- **split**: Preserve roboflow coco layout on split
  ([#58](https://github.com/pirnerjonas/argus/pull/58),
  [`08505ee`](https://github.com/pirnerjonas/argus/commit/08505ee7200afd4155bf427203ddfaf2b6fb978b))

### Refactoring

- **cli**: Share path helpers and simplify view flow
  ([#56](https://github.com/pirnerjonas/argus/pull/56),
  [`d531dbc`](https://github.com/pirnerjonas/argus/commit/d531dbcf3a634835625cf7f7d671a3338c840786))

- **cli**: Split monolithic CLI into modules ([#56](https://github.com/pirnerjonas/argus/pull/56),
  [`d531dbc`](https://github.com/pirnerjonas/argus/commit/d531dbcf3a634835625cf7f7d671a3338c840786))


## v1.7.0 (2026-03-04)

### Bug Fixes

- Handle unsplit datasets and polygon holes in YOLO-to-COCO conversion and viewer
  ([#55](https://github.com/pirnerjonas/argus/pull/55),
  [`1a0e149`](https://github.com/pirnerjonas/argus/commit/1a0e149e71606f0d3d4f5e68a562fd447c317f93))

### Features

- Add YOLO segmentation to COCO format conversion
  ([#55](https://github.com/pirnerjonas/argus/pull/55),
  [`1a0e149`](https://github.com/pirnerjonas/argus/commit/1a0e149e71606f0d3d4f5e68a562fd447c317f93))


## v1.6.0 (2026-02-23)

### Bug Fixes

- Prevent opencv-python-headless from being installed via uv override
  ([#54](https://github.com/pirnerjonas/argus/pull/54),
  [`40f4f30`](https://github.com/pirnerjonas/argus/commit/40f4f30beec8508b3c71a6a93e9259f390556a71))

### Features

- Add COCO RLE segmentation support in view command
  ([#54](https://github.com/pirnerjonas/argus/pull/54),
  [`40f4f30`](https://github.com/pirnerjonas/argus/commit/40f4f30beec8508b3c71a6a93e9259f390556a71))


## v1.5.5 (2026-02-13)

### Bug Fixes

- Update documentation workflow to use uv for dependency management
  ([`4be8fa9`](https://github.com/pirnerjonas/argus/commit/4be8fa99bd387672bc5055b9dad263d8dbe24172))


## v1.5.4 (2026-02-09)

### Bug Fixes

- Support Roboflow YOLO directory layout in filter and stats
  ([#39](https://github.com/pirnerjonas/argus/pull/39),
  [`d585e98`](https://github.com/pirnerjonas/argus/commit/d585e980c3545b865c5191ec61b2bff7c2d42b8e))


## v1.5.3 (2026-02-03)

### Bug Fixes

- Handle "valid" directory name for YOLO datasets
  ([`9ba112c`](https://github.com/pirnerjonas/argus/commit/9ba112c6b1baf2fd4977aa78edfee5bbfa057d45))


## v1.5.2 (2026-02-03)

### Bug Fixes

- Prevent double counting in COCO stats
  ([`90436b1`](https://github.com/pirnerjonas/argus/commit/90436b13d64a50821a39ee3bb9468bfa59e8e0ea))


## v1.5.1 (2026-01-28)

### Bug Fixes

- Add missing documentation for filter command
  ([`dc41fbb`](https://github.com/pirnerjonas/argus/commit/dc41fbb724faf2024ec9f1430e2af0a6af000d21))


## v1.5.0 (2026-01-28)

### Features

- Support Roboflow COCO format and improve YOLO classification detection
  ([`902a59f`](https://github.com/pirnerjonas/argus/commit/902a59fbb506aa586d8677312d21ae240585b511))


## v1.4.0 (2026-01-26)

### Features

- **view**: Show polygon vertices and hide bbox for segmentation
  ([`03b34f7`](https://github.com/pirnerjonas/argus/commit/03b34f78fdafefd35a8b2594bf1296007716d6c9))


## v1.3.0 (2026-01-24)

### Features

- Add MaskDataset class for semantic segmentation masks
  ([`bbba4f2`](https://github.com/pirnerjonas/argus/commit/bbba4f2c9d476d426b6c805ad2120eca9c38c855))


## v1.2.0 (2026-01-15)

### Code Style

- Fix ruff linting errors
  ([`b2d5ea2`](https://github.com/pirnerjonas/argus/commit/b2d5ea2c4d0715a474d4ffaa5be60d0499d200a2))

- Remove unused pytest import in test_classification.py
  ([`e22175a`](https://github.com/pirnerjonas/argus/commit/e22175a7378276dd2840754e672c7d4d1ed0e067))

### Features

- Add classification dataset support with grid viewer
  ([`8089bd3`](https://github.com/pirnerjonas/argus/commit/8089bd3367ede4c288b0276ac3da4d3ef9960c4d))


## v1.1.0 (2026-01-14)

### Code Style

- Fix line too long in _get_display_image
  ([`7a56904`](https://github.com/pirnerjonas/argus/commit/7a569049baa4e90956e089d970e192eb159a57e0))

### Features

- Add toggle for annotation overlay in view command
  ([`65fb239`](https://github.com/pirnerjonas/argus/commit/65fb23942d53947df57b6e4c12d11e5dd1aa98f3))


## v1.0.1 (2026-01-12)

### Bug Fixes

- Rename CLI command from argus to argus-cv
  ([`325ef2a`](https://github.com/pirnerjonas/argus/commit/325ef2acfad88d179ab5b4c5e2d2621e34f9fa7e))


## v1.0.0 (2026-01-12)


## v0.1.0 (2026-01-12)

- Initial Release
