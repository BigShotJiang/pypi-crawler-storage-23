"""WebSocket connection to the Snippbot daemon with automatic reconnection."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Awaitable

import websockets
import websockets.client
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    ConnectionClosedOK,
    InvalidStatusCode,
)

logger = logging.getLogger(__name__)

RECONNECT_DELAYS = [1, 2, 5, 10, 30, 60]


class MessageType(str, Enum):
    """Types of messages exchanged between device and daemon."""

    AUTHENTICATE = "authenticate"
    AUTH_RESULT = "auth_result"
    HEARTBEAT = "heartbeat"
    HEARTBEAT_ACK = "heartbeat_ack"
    TOOL_REQUEST = "tool_request"
    TOOL_RESULT = "tool_result"
    CAPABILITY_REPORT = "capability_report"
    ERROR = "error"
    SHUTDOWN = "shutdown"
    PAIR_REQUEST = "pair_request"
    PAIR_RESULT = "pair_result"
    STATUS_REQUEST = "status_request"
    STATUS_RESPONSE = "status_response"


@dataclass
class DeviceMessage:
    """A message exchanged between device agent and daemon."""

    type: MessageType
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: float = 0.0
    message_id: str = ""

    def __post_init__(self) -> None:
        if self.timestamp == 0.0:
            self.timestamp = time.time()
        if not self.message_id:
            import uuid
            self.message_id = str(uuid.uuid4())

    def to_json(self) -> str:
        """Serialize the message to a JSON string."""
        return json.dumps({
            "type": self.type.value if isinstance(self.type, MessageType) else self.type,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "message_id": self.message_id,
        })

    @classmethod
    def from_json(cls, raw: str) -> DeviceMessage:
        """Deserialize a JSON string into a DeviceMessage."""
        data = json.loads(raw)
        msg_type = data.get("type", "error")
        try:
            msg_type = MessageType(msg_type)
        except ValueError:
            logger.warning("Unknown message type: %s", msg_type)
            msg_type = MessageType.ERROR
        return cls(
            type=msg_type,
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", time.time()),
            message_id=data.get("message_id", ""),
        )


class DeviceConnection:
    """WebSocket client that connects to the Snippbot daemon.

    Handles automatic reconnection with exponential backoff using
    the delay sequence: 1, 2, 5, 10, 30, 60 seconds.
    """

    def __init__(
        self,
        ws_url: str,
        device_id: str,
        device_token: str,
        on_message: Callable[[DeviceMessage], Awaitable[None]] | None = None,
    ) -> None:
        self._ws_url = ws_url
        self._device_id = device_id
        self._device_token = device_token
        self._on_message = on_message

        self._ws: websockets.client.WebSocketClientProtocol | None = None
        self._connected = False
        self._authenticated = False
        self._should_run = False
        self._reconnect_attempt = 0
        self._receive_task: asyncio.Task[None] | None = None
        self._lock = asyncio.Lock()

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def authenticated(self) -> bool:
        return self._authenticated

    async def connect(self) -> bool:
        """Establish a WebSocket connection to the daemon.

        Returns True if the connection succeeded, False otherwise.
        """
        try:
            logger.info("Connecting to %s ...", self._ws_url)
            self._ws = await websockets.client.connect(
                self._ws_url,
                ping_interval=20,
                ping_timeout=10,
                close_timeout=5,
                max_size=10 * 1024 * 1024,  # 10 MB max message
            )
            self._connected = True
            self._reconnect_attempt = 0
            logger.info("WebSocket connection established")
            return True
        except (OSError, InvalidStatusCode, ConnectionRefusedError) as exc:
            logger.error("Connection failed: %s", exc)
            self._connected = False
            return False

    async def authenticate(self) -> bool:
        """Send authentication message and wait for result."""
        if not self._ws or not self._connected:
            logger.error("Cannot authenticate: not connected")
            return False

        auth_msg = DeviceMessage(
            type=MessageType.AUTHENTICATE,
            payload={
                "device_id": self._device_id,
                "device_token": self._device_token,
            },
        )
        await self.send(auth_msg)

        try:
            raw = await asyncio.wait_for(self._ws.recv(), timeout=10.0)
            response = DeviceMessage.from_json(raw)

            if response.type == MessageType.AUTH_RESULT:
                success = response.payload.get("success", False)
                if success:
                    self._authenticated = True
                    logger.info("Authentication successful")
                else:
                    reason = response.payload.get("reason", "unknown")
                    logger.error("Authentication failed: %s", reason)
                    self._authenticated = False
                return success
            else:
                logger.error("Unexpected response type during auth: %s", response.type)
                return False
        except asyncio.TimeoutError:
            logger.error("Authentication timed out")
            return False

    async def send(self, message: DeviceMessage) -> bool:
        """Send a message over the WebSocket connection.

        Returns True if the message was sent, False otherwise.
        """
        if not self._ws or not self._connected:
            logger.warning("Cannot send message: not connected")
            return False

        try:
            await self._ws.send(message.to_json())
            logger.debug("Sent message: type=%s id=%s", message.type, message.message_id)
            return True
        except ConnectionClosed as exc:
            logger.warning("Connection closed while sending: %s", exc)
            self._connected = False
            self._authenticated = False
            return False

    async def receive(self) -> DeviceMessage | None:
        """Receive a single message from the WebSocket.

        Returns None if the connection is closed or an error occurs.
        """
        if not self._ws or not self._connected:
            return None

        try:
            raw = await self._ws.recv()
            message = DeviceMessage.from_json(raw)
            logger.debug("Received message: type=%s id=%s", message.type, message.message_id)
            return message
        except ConnectionClosedOK:
            logger.info("Connection closed normally")
            self._connected = False
            self._authenticated = False
            return None
        except ConnectionClosedError as exc:
            logger.warning("Connection closed with error: %s", exc)
            self._connected = False
            self._authenticated = False
            return None
        except Exception as exc:
            logger.error("Error receiving message: %s", exc)
            return None

    async def start_receive_loop(self) -> None:
        """Start the background receive loop that dispatches messages."""
        self._should_run = True

        while self._should_run:
            if not self._connected:
                reconnected = await self._reconnect()
                if not reconnected:
                    continue

            message = await self.receive()
            if message is None:
                if self._should_run:
                    await self._reconnect()
                continue

            if self._on_message:
                try:
                    await self._on_message(message)
                except Exception as exc:
                    logger.error("Error in message handler: %s", exc, exc_info=True)

    async def _reconnect(self) -> bool:
        """Attempt to reconnect with exponential backoff.

        Uses the delay sequence: 1, 2, 5, 10, 30, 60 (stays at 60 thereafter).
        Returns True if reconnection and re-authentication succeeded.
        """
        if not self._should_run:
            return False

        delay_index = min(self._reconnect_attempt, len(RECONNECT_DELAYS) - 1)
        delay = RECONNECT_DELAYS[delay_index]

        logger.info(
            "Reconnecting in %d seconds (attempt %d)...",
            delay,
            self._reconnect_attempt + 1,
        )
        await asyncio.sleep(delay)
        self._reconnect_attempt += 1

        if not self._should_run:
            return False

        connected = await self.connect()
        if not connected:
            return False

        if self._device_token:
            authenticated = await self.authenticate()
            if not authenticated:
                await self.disconnect()
                return False

        return True

    async def disconnect(self) -> None:
        """Close the WebSocket connection gracefully."""
        self._should_run = False
        self._connected = False
        self._authenticated = False

        if self._ws:
            try:
                await self._ws.close()
                logger.info("WebSocket disconnected")
            except Exception as exc:
                logger.debug("Error during disconnect: %s", exc)
            finally:
                self._ws = None

    async def send_pair_request(self, pairing_code: str) -> DeviceMessage | None:
        """Send a pairing request with the given code and return the result."""
        if not self._ws or not self._connected:
            logger.error("Cannot pair: not connected")
            return None

        pair_msg = DeviceMessage(
            type=MessageType.PAIR_REQUEST,
            payload={"pairing_code": pairing_code},
        )
        await self.send(pair_msg)

        try:
            raw = await asyncio.wait_for(self._ws.recv(), timeout=30.0)
            return DeviceMessage.from_json(raw)
        except asyncio.TimeoutError:
            logger.error("Pairing request timed out")
            return None
