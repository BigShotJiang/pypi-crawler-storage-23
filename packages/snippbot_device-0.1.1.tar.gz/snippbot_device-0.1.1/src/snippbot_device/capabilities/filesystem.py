"""Filesystem capability - read, write, and transfer files with path validation."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Any, ClassVar

from snippbot_device.capabilities import BaseCapability, CapabilityResult

logger = logging.getLogger(__name__)

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_OUTPUT_SIZE = 1 * 1024 * 1024  # 1 MB for inline content


class FilesystemCapability(BaseCapability):
    """Read, write, list, and transfer files with path validation.

    Only operates on paths that fall under the configured allowed_paths list.
    """

    name: ClassVar[str] = "filesystem"
    description: ClassVar[str] = "Read, write, and list filesystem entries"

    def __init__(self, allowed_paths: list[str] | None = None) -> None:
        self._allowed_paths = allowed_paths or [str(Path.home())]

    def is_available(self) -> bool:
        """Filesystem operations are always available."""
        return True

    def get_metadata(self) -> dict[str, Any]:
        base = super().get_metadata()
        base["allowed_paths"] = self._allowed_paths
        base["max_file_size_mb"] = MAX_FILE_SIZE // (1024 * 1024)
        return base

    def _is_path_allowed(self, target: str) -> bool:
        """Check whether target falls under an allowed path prefix."""
        resolved = str(Path(target).resolve())
        for allowed in self._allowed_paths:
            allowed_resolved = str(Path(allowed).resolve())
            if resolved == allowed_resolved or resolved.startswith(allowed_resolved + os.sep):
                return True
        return False

    async def execute(self, action: str, params: dict[str, Any]) -> CapabilityResult:
        """Execute a filesystem action.

        Supported actions:
          - "read": read a file's content
          - "write": write content to a file
          - "list": list directory contents
          - "stat": get file/directory metadata
          - "copy": copy a file or directory
          - "move": move/rename a file or directory
          - "delete": delete a file or empty directory
          - "mkdir": create a directory tree
        """
        handlers = {
            "read": self._read,
            "write": self._write,
            "list": self._list,
            "stat": self._stat,
            "copy": self._copy,
            "move": self._move,
            "delete": self._delete,
            "mkdir": self._mkdir,
        }
        handler = handlers.get(action)
        if handler is None:
            return CapabilityResult(
                success=False,
                error=f"Unknown filesystem action: {action}. Available: {', '.join(handlers)}",
                exit_code=1,
            )
        try:
            return await handler(params)
        except PermissionError as exc:
            return CapabilityResult(success=False, error=f"Permission denied: {exc}", exit_code=1)
        except Exception as exc:
            logger.error("filesystem.%s failed: %s", action, exc, exc_info=True)
            return CapabilityResult(success=False, error=str(exc), exit_code=1)

    async def _read(self, params: dict[str, Any]) -> CapabilityResult:
        """Read a file's contents."""
        start = time.monotonic()
        file_path = params.get("path", "")
        if not file_path:
            return CapabilityResult(success=False, error="No path provided", exit_code=1)

        if not self._is_path_allowed(file_path):
            return CapabilityResult(success=False, error=f"Path not allowed: {file_path}", exit_code=1)

        resolved = Path(file_path).resolve()
        if not resolved.exists():
            return CapabilityResult(success=False, error=f"File not found: {file_path}", exit_code=1)
        if not resolved.is_file():
            return CapabilityResult(success=False, error=f"Not a file: {file_path}", exit_code=1)

        size = resolved.stat().st_size
        if size > MAX_FILE_SIZE:
            return CapabilityResult(
                success=False,
                error=f"File too large ({size} bytes, max {MAX_FILE_SIZE})",
                exit_code=1,
            )

        encoding = params.get("encoding", "utf-8")
        content = await asyncio.get_event_loop().run_in_executor(
            None, lambda: resolved.read_text(encoding=encoding, errors="replace")
        )

        return CapabilityResult(
            success=True,
            output=content[:MAX_OUTPUT_SIZE],
            metadata={"path": str(resolved), "size": size, "encoding": encoding},
            duration=time.monotonic() - start,
        )

    async def _write(self, params: dict[str, Any]) -> CapabilityResult:
        """Write content to a file."""
        start = time.monotonic()
        file_path = params.get("path", "")
        content = params.get("content", "")
        if not file_path:
            return CapabilityResult(success=False, error="No path provided", exit_code=1)

        if not self._is_path_allowed(file_path):
            return CapabilityResult(success=False, error=f"Path not allowed: {file_path}", exit_code=1)

        content_bytes = content.encode("utf-8")
        if len(content_bytes) > MAX_FILE_SIZE:
            return CapabilityResult(
                success=False,
                error=f"Content too large ({len(content_bytes)} bytes, max {MAX_FILE_SIZE})",
                exit_code=1,
            )

        resolved = Path(file_path).resolve()

        def _do_write() -> int:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content, encoding="utf-8")
            return len(content_bytes)

        written = await asyncio.get_event_loop().run_in_executor(None, _do_write)

        return CapabilityResult(
            success=True,
            output=f"Written {written} bytes to {resolved}",
            metadata={"path": str(resolved), "size": written},
            duration=time.monotonic() - start,
        )

    async def _list(self, params: dict[str, Any]) -> CapabilityResult:
        """List contents of a directory."""
        start = time.monotonic()
        dir_path = params.get("path", ".")
        if not self._is_path_allowed(dir_path):
            return CapabilityResult(success=False, error=f"Path not allowed: {dir_path}", exit_code=1)

        resolved = Path(dir_path).resolve()
        if not resolved.exists():
            return CapabilityResult(success=False, error=f"Directory not found: {dir_path}", exit_code=1)
        if not resolved.is_dir():
            return CapabilityResult(success=False, error=f"Not a directory: {dir_path}", exit_code=1)

        show_hidden = params.get("show_hidden", False)

        entries: list[str] = []
        for entry in sorted(resolved.iterdir()):
            if not show_hidden and entry.name.startswith("."):
                continue
            kind = "dir" if entry.is_dir() else "file"
            try:
                size = entry.stat().st_size if entry.is_file() else 0
            except OSError:
                size = 0
            entries.append(f"{kind}\t{size}\t{entry.name}")

        return CapabilityResult(
            success=True,
            output="\n".join(entries),
            metadata={"path": str(resolved), "count": len(entries)},
            duration=time.monotonic() - start,
        )

    async def _stat(self, params: dict[str, Any]) -> CapabilityResult:
        """Get metadata about a file or directory."""
        start = time.monotonic()
        target_path = params.get("path", "")
        if not target_path:
            return CapabilityResult(success=False, error="No path provided", exit_code=1)

        if not self._is_path_allowed(target_path):
            return CapabilityResult(success=False, error=f"Path not allowed: {target_path}", exit_code=1)

        resolved = Path(target_path).resolve()
        if not resolved.exists():
            return CapabilityResult(success=False, error=f"Path not found: {target_path}", exit_code=1)

        stat = resolved.stat()
        info = {
            "path": str(resolved),
            "name": resolved.name,
            "is_file": resolved.is_file(),
            "is_dir": resolved.is_dir(),
            "is_symlink": resolved.is_symlink(),
            "size": stat.st_size,
            "mode": oct(stat.st_mode),
            "uid": stat.st_uid,
            "gid": stat.st_gid,
            "atime": stat.st_atime,
            "mtime": stat.st_mtime,
            "ctime": stat.st_ctime,
        }

        lines = [f"{k}: {v}" for k, v in info.items()]
        return CapabilityResult(
            success=True,
            output="\n".join(lines),
            metadata=info,
            duration=time.monotonic() - start,
        )

    async def _copy(self, params: dict[str, Any]) -> CapabilityResult:
        """Copy a file or directory."""
        start = time.monotonic()
        src = params.get("source", "")
        dst = params.get("destination", "")
        if not src or not dst:
            return CapabilityResult(success=False, error="source and destination are required", exit_code=1)

        if not self._is_path_allowed(src):
            return CapabilityResult(success=False, error=f"Source path not allowed: {src}", exit_code=1)
        if not self._is_path_allowed(dst):
            return CapabilityResult(success=False, error=f"Destination path not allowed: {dst}", exit_code=1)

        src_resolved = Path(src).resolve()
        dst_resolved = Path(dst).resolve()

        if not src_resolved.exists():
            return CapabilityResult(success=False, error=f"Source not found: {src}", exit_code=1)

        def _do_copy() -> str:
            if src_resolved.is_dir():
                shutil.copytree(str(src_resolved), str(dst_resolved))
                return f"Copied directory {src_resolved} -> {dst_resolved}"
            else:
                dst_resolved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src_resolved), str(dst_resolved))
                return f"Copied file {src_resolved} -> {dst_resolved}"

        result = await asyncio.get_event_loop().run_in_executor(None, _do_copy)
        return CapabilityResult(
            success=True,
            output=result,
            metadata={"source": str(src_resolved), "destination": str(dst_resolved)},
            duration=time.monotonic() - start,
        )

    async def _move(self, params: dict[str, Any]) -> CapabilityResult:
        """Move or rename a file or directory."""
        start = time.monotonic()
        src = params.get("source", "")
        dst = params.get("destination", "")
        if not src or not dst:
            return CapabilityResult(success=False, error="source and destination are required", exit_code=1)

        if not self._is_path_allowed(src):
            return CapabilityResult(success=False, error=f"Source path not allowed: {src}", exit_code=1)
        if not self._is_path_allowed(dst):
            return CapabilityResult(success=False, error=f"Destination path not allowed: {dst}", exit_code=1)

        src_resolved = Path(src).resolve()
        dst_resolved = Path(dst).resolve()

        if not src_resolved.exists():
            return CapabilityResult(success=False, error=f"Source not found: {src}", exit_code=1)

        def _do_move() -> str:
            dst_resolved.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_resolved), str(dst_resolved))
            return f"Moved {src_resolved} -> {dst_resolved}"

        result = await asyncio.get_event_loop().run_in_executor(None, _do_move)
        return CapabilityResult(
            success=True,
            output=result,
            metadata={"source": str(src_resolved), "destination": str(dst_resolved)},
            duration=time.monotonic() - start,
        )

    async def _delete(self, params: dict[str, Any]) -> CapabilityResult:
        """Delete a file or empty directory."""
        start = time.monotonic()
        target = params.get("path", "")
        if not target:
            return CapabilityResult(success=False, error="No path provided", exit_code=1)

        if not self._is_path_allowed(target):
            return CapabilityResult(success=False, error=f"Path not allowed: {target}", exit_code=1)

        resolved = Path(target).resolve()
        if not resolved.exists():
            return CapabilityResult(success=False, error=f"Path not found: {target}", exit_code=1)

        recursive = params.get("recursive", False)

        def _do_delete() -> str:
            if resolved.is_file() or resolved.is_symlink():
                resolved.unlink()
                return f"Deleted file: {resolved}"
            elif resolved.is_dir():
                if recursive:
                    shutil.rmtree(str(resolved))
                    return f"Deleted directory (recursive): {resolved}"
                else:
                    resolved.rmdir()  # Only works if empty
                    return f"Deleted empty directory: {resolved}"
            else:
                raise ValueError(f"Cannot delete: {resolved}")

        result = await asyncio.get_event_loop().run_in_executor(None, _do_delete)
        return CapabilityResult(
            success=True,
            output=result,
            metadata={"path": str(resolved)},
            duration=time.monotonic() - start,
        )

    async def _mkdir(self, params: dict[str, Any]) -> CapabilityResult:
        """Create a directory, including parents if needed."""
        start = time.monotonic()
        dir_path = params.get("path", "")
        if not dir_path:
            return CapabilityResult(success=False, error="No path provided", exit_code=1)

        if not self._is_path_allowed(dir_path):
            return CapabilityResult(success=False, error=f"Path not allowed: {dir_path}", exit_code=1)

        resolved = Path(dir_path).resolve()
        resolved.mkdir(parents=True, exist_ok=True)

        return CapabilityResult(
            success=True,
            output=f"Created directory: {resolved}",
            metadata={"path": str(resolved)},
            duration=time.monotonic() - start,
        )
