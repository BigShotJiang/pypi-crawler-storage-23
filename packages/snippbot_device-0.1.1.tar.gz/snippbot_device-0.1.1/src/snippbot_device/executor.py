"""Device executor - runs tool requests locally with security constraints."""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import psutil

from snippbot_device.config import DeviceConfig

logger = logging.getLogger(__name__)

# Hard limits for safety
MAX_BASH_TIMEOUT = 300  # 5 minutes
MAX_OUTPUT_SIZE = 1 * 1024 * 1024  # 1 MB
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_MEMORY_MB = 2048  # 2 GB per subprocess


class ExecutionResult:
    """Result of executing a tool request."""

    def __init__(
        self,
        success: bool,
        output: str = "",
        error: str = "",
        exit_code: int = 0,
        duration: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.success = success
        self.output = output
        self.error = error
        self.exit_code = exit_code
        self.duration = duration
        self.metadata = metadata or {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "exit_code": self.exit_code,
            "duration": self.duration,
            "metadata": self.metadata,
        }


class DeviceExecutor:
    """Executes tool requests on the local machine.

    Provides bash execution, Python execution, filesystem operations,
    and system information retrieval while respecting security constraints
    from the DeviceConfig.
    """

    def __init__(self, config: DeviceConfig) -> None:
        self._config = config
        self._active_processes: dict[str, subprocess.Popen[bytes]] = {}
        self._semaphore = asyncio.Semaphore(config.max_concurrent_tasks)

    async def execute(self, tool_name: str, params: dict[str, Any]) -> ExecutionResult:
        """Route a tool request to the appropriate handler."""
        async with self._semaphore:
            handler_map: dict[str, Any] = {
                "bash": self.execute_bash,
                "python": self.execute_python,
                "read_file": self.read_file,
                "write_file": self.write_file,
                "list_directory": self.list_directory,
                "system_info": self.get_system_info,
            }

            handler = handler_map.get(tool_name)
            if handler is None:
                return ExecutionResult(
                    success=False,
                    error=f"Unknown tool: {tool_name}",
                    exit_code=1,
                )

            try:
                return await handler(params)
            except Exception as exc:
                logger.error("Execution error for tool %s: %s", tool_name, exc, exc_info=True)
                return ExecutionResult(
                    success=False,
                    error=f"Internal execution error: {exc}",
                    exit_code=1,
                )

    def _sanitize_env(self) -> dict[str, str]:
        """Build an environment dictionary with sensitive variables stripped."""
        env = dict(os.environ)
        removed: list[str] = []
        for key in list(env.keys()):
            if self._config.is_env_var_blocked(key):
                del env[key]
                removed.append(key)
        if removed:
            logger.debug("Stripped %d sensitive env vars: %s", len(removed), removed)
        return env

    def _apply_resource_limits(self) -> None:
        """Apply resource limits to the current subprocess (Unix only).

        Called as a preexec_fn inside subprocess.Popen so the limits apply
        to the child, not the agent itself.
        """
        if sys.platform == "win32":
            return

        import resource

        # Limit virtual memory
        mem_bytes = MAX_MEMORY_MB * 1024 * 1024
        try:
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        except (ValueError, resource.error):
            pass

        # Limit CPU time (soft=timeout, hard=timeout+10 as grace)
        try:
            resource.setrlimit(resource.RLIMIT_CPU, (MAX_BASH_TIMEOUT, MAX_BASH_TIMEOUT + 10))
        except (ValueError, resource.error):
            pass

        # No core dumps
        try:
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except (ValueError, resource.error):
            pass

    async def execute_bash(self, params: dict[str, Any]) -> ExecutionResult:
        """Execute a bash command via subprocess with timeout and resource limits."""
        command = params.get("command", "")
        if not command:
            return ExecutionResult(success=False, error="No command provided", exit_code=1)

        timeout = min(params.get("timeout", 60), MAX_BASH_TIMEOUT)
        working_dir = params.get("working_directory")

        if working_dir and not self._config.is_path_allowed(working_dir):
            return ExecutionResult(
                success=False,
                error=f"Working directory not allowed: {working_dir}",
                exit_code=1,
            )

        env = self._sanitize_env()
        start = time.monotonic()

        preexec = self._apply_resource_limits if sys.platform != "win32" else None

        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env=env,
                    cwd=working_dir,
                    preexec_fn=preexec,
                ),
            )

            task_id = str(id(proc))
            self._active_processes[task_id] = proc

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    asyncio.get_event_loop().run_in_executor(
                        None, lambda: proc.communicate()
                    ),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._kill_process(proc)
                duration = time.monotonic() - start
                return ExecutionResult(
                    success=False,
                    error=f"Command timed out after {timeout}s",
                    exit_code=-1,
                    duration=duration,
                )
            finally:
                self._active_processes.pop(task_id, None)

            duration = time.monotonic() - start
            stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]
            stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]

            return ExecutionResult(
                success=proc.returncode == 0,
                output=stdout,
                error=stderr,
                exit_code=proc.returncode or 0,
                duration=duration,
            )

        except FileNotFoundError:
            return ExecutionResult(
                success=False,
                error="Shell not found",
                exit_code=127,
                duration=time.monotonic() - start,
            )

    async def execute_python(self, params: dict[str, Any]) -> ExecutionResult:
        """Execute a Python script via subprocess."""
        code = params.get("code", "")
        if not code:
            return ExecutionResult(success=False, error="No code provided", exit_code=1)

        timeout = min(params.get("timeout", 60), MAX_BASH_TIMEOUT)
        env = self._sanitize_env()
        start = time.monotonic()

        preexec = self._apply_resource_limits if sys.platform != "win32" else None

        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.Popen(
                    [sys.executable, "-c", code],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env=env,
                    preexec_fn=preexec,
                ),
            )

            task_id = str(id(proc))
            self._active_processes[task_id] = proc

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    asyncio.get_event_loop().run_in_executor(
                        None, lambda: proc.communicate()
                    ),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._kill_process(proc)
                duration = time.monotonic() - start
                return ExecutionResult(
                    success=False,
                    error=f"Python script timed out after {timeout}s",
                    exit_code=-1,
                    duration=duration,
                )
            finally:
                self._active_processes.pop(task_id, None)

            duration = time.monotonic() - start
            stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]
            stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE]

            return ExecutionResult(
                success=proc.returncode == 0,
                output=stdout,
                error=stderr,
                exit_code=proc.returncode or 0,
                duration=duration,
            )

        except FileNotFoundError:
            return ExecutionResult(
                success=False,
                error="Python interpreter not found",
                exit_code=127,
                duration=time.monotonic() - start,
            )

    async def read_file(self, params: dict[str, Any]) -> ExecutionResult:
        """Read a file from the filesystem, respecting allowed paths."""
        file_path = params.get("path", "")
        if not file_path:
            return ExecutionResult(success=False, error="No path provided", exit_code=1)

        if not self._config.is_path_allowed(file_path):
            return ExecutionResult(
                success=False,
                error=f"Path not allowed: {file_path}",
                exit_code=1,
            )

        resolved = Path(file_path).resolve()
        if not resolved.exists():
            return ExecutionResult(success=False, error=f"File not found: {file_path}", exit_code=1)
        if not resolved.is_file():
            return ExecutionResult(success=False, error=f"Not a file: {file_path}", exit_code=1)
        if resolved.stat().st_size > MAX_FILE_SIZE:
            return ExecutionResult(
                success=False,
                error=f"File too large (max {MAX_FILE_SIZE // 1024 // 1024}MB): {file_path}",
                exit_code=1,
            )

        try:
            content = await asyncio.get_event_loop().run_in_executor(
                None, lambda: resolved.read_text(encoding="utf-8", errors="replace")
            )
            return ExecutionResult(
                success=True,
                output=content[:MAX_OUTPUT_SIZE],
                metadata={"path": str(resolved), "size": resolved.stat().st_size},
            )
        except PermissionError:
            return ExecutionResult(success=False, error=f"Permission denied: {file_path}", exit_code=1)

    async def write_file(self, params: dict[str, Any]) -> ExecutionResult:
        """Write content to a file on the filesystem, respecting allowed paths."""
        file_path = params.get("path", "")
        content = params.get("content", "")
        if not file_path:
            return ExecutionResult(success=False, error="No path provided", exit_code=1)

        if not self._config.is_path_allowed(file_path):
            return ExecutionResult(
                success=False,
                error=f"Path not allowed: {file_path}",
                exit_code=1,
            )

        if len(content.encode("utf-8")) > MAX_FILE_SIZE:
            return ExecutionResult(
                success=False,
                error=f"Content too large (max {MAX_FILE_SIZE // 1024 // 1024}MB)",
                exit_code=1,
            )

        resolved = Path(file_path).resolve()

        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: resolved.write_text(content, encoding="utf-8")
            )
            return ExecutionResult(
                success=True,
                output=f"Written {len(content)} bytes to {resolved}",
                metadata={"path": str(resolved), "size": len(content)},
            )
        except PermissionError:
            return ExecutionResult(success=False, error=f"Permission denied: {file_path}", exit_code=1)

    async def list_directory(self, params: dict[str, Any]) -> ExecutionResult:
        """List contents of a directory."""
        dir_path = params.get("path", ".")
        if not self._config.is_path_allowed(dir_path):
            return ExecutionResult(
                success=False,
                error=f"Path not allowed: {dir_path}",
                exit_code=1,
            )

        resolved = Path(dir_path).resolve()
        if not resolved.exists():
            return ExecutionResult(success=False, error=f"Directory not found: {dir_path}", exit_code=1)
        if not resolved.is_dir():
            return ExecutionResult(success=False, error=f"Not a directory: {dir_path}", exit_code=1)

        try:
            entries: list[str] = []
            for entry in sorted(resolved.iterdir()):
                kind = "dir" if entry.is_dir() else "file"
                try:
                    size = entry.stat().st_size if entry.is_file() else 0
                except OSError:
                    size = 0
                entries.append(f"{kind}\t{size}\t{entry.name}")

            return ExecutionResult(
                success=True,
                output="\n".join(entries),
                metadata={"path": str(resolved), "count": len(entries)},
            )
        except PermissionError:
            return ExecutionResult(success=False, error=f"Permission denied: {dir_path}", exit_code=1)

    async def get_system_info(self, params: dict[str, Any]) -> ExecutionResult:
        """Gather system information using psutil."""
        try:
            cpu_percent = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("/")

            info: dict[str, Any] = {
                "platform": platform.system(),
                "platform_release": platform.release(),
                "platform_version": platform.version(),
                "architecture": platform.machine(),
                "hostname": platform.node(),
                "python_version": platform.python_version(),
                "cpu_count_physical": psutil.cpu_count(logical=False),
                "cpu_count_logical": psutil.cpu_count(logical=True),
                "cpu_percent": cpu_percent,
                "memory_total_gb": round(mem.total / (1024 ** 3), 2),
                "memory_available_gb": round(mem.available / (1024 ** 3), 2),
                "memory_percent": mem.percent,
                "disk_total_gb": round(disk.total / (1024 ** 3), 2),
                "disk_free_gb": round(disk.free / (1024 ** 3), 2),
                "disk_percent": disk.percent,
                "boot_time": psutil.boot_time(),
                "pid": os.getpid(),
            }

            # Format as readable output
            lines = [f"{k}: {v}" for k, v in info.items()]
            return ExecutionResult(
                success=True,
                output="\n".join(lines),
                metadata=info,
            )
        except Exception as exc:
            return ExecutionResult(success=False, error=f"Failed to gather system info: {exc}", exit_code=1)

    def _kill_process(self, proc: subprocess.Popen[bytes]) -> None:
        """Kill a subprocess and all its children."""
        try:
            parent = psutil.Process(proc.pid)
            children = parent.children(recursive=True)
            for child in children:
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            parent.kill()
            proc.wait(timeout=5)
        except (psutil.NoSuchProcess, subprocess.TimeoutExpired, OSError):
            try:
                proc.kill()
            except OSError:
                pass

    async def cancel_all(self) -> int:
        """Kill all active processes. Returns the number of processes killed."""
        count = 0
        for task_id, proc in list(self._active_processes.items()):
            self._kill_process(proc)
            self._active_processes.pop(task_id, None)
            count += 1
        logger.info("Cancelled %d active processes", count)
        return count
