from beamflow_lib.decorators import integration_task
from beamflow_lib.queue.backend import Schedule




@integration_task(integration="demo", integration_pipeline="demo", default_schedule=Schedule(cron="* * * * *"))
def demo_task(user_id: int):
    """
    Task to process a user by ID.
    """
    print(f"Processing user {user_id}...")
    
    
    