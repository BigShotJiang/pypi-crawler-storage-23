# for llm agents

this is a python library for interfacing with nssurge's http api (/Users/tsca/testdir/surge-docs/manual/manual.nssurge.com/others/http-api.md , or https://manual.nssurge.com/others/http-api.html).

when user talk about the cli, he means the nssurge-cli project / the `nsg` command (see below)

## surge

### encoding 

aiohttp encodes spaces as + in query parameters, but the Surge API only accepts %20. The encoded URL is:                                                                                                                            
  ?policy_name=%F0%9F%87%BA%F0%9F%87%B2+%E7%BE%8E%E5%9B%BD+02                                                                                                                                                                                   
  But Surge expects %20 for spaces, not +

## docs

surge docs: ../surge-docs

sister project this relies on this repo: ../nssurge-cli

`uv` docs: ../uv

`tddschn-utils` module docs: ../tddschn-utils

`aiohttp` docs: ../aiohttp

## testing

### nssurge-cli

to test `nsg` command, run `envchain surge /Users/tsca/testdir/nssurge-cli/.venv/bin/nsg` instead of just `nsg`.


DO NOT run commands like `envchain surge env`, never see the values of credntials yourself!! use  SURGE_HTTP_API_ENDPOINT=127.0.0.1:9999, it's injected by envchain 

for debugging http api directly, running something like this is allowed:

```bash
envchain surge bash -c 'curl -s -H "X-Key: $SURGE_HTTP_API_KEY" "http://$SURGE_HTTP_API_ENDPOINT/v1/policies/detail?policy_name=<policy_name_here>"'
```