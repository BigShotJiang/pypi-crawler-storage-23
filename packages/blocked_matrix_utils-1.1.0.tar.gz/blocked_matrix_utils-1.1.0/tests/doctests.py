import doctest
import util.full
import util.subblocked

doctest.testmod(util.full)
doctest.testmod(util.subblocked)
