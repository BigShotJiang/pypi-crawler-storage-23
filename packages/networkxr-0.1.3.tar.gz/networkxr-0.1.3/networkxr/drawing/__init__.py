"""networkxr.drawing — graph visualization with Plotly."""

from __future__ import annotations

from networkxr.drawing.nx_plotly import draw

__all__ = ["draw"]
