# Changelog

All notable changes are documented here.
This project follows [Semantic Versioning](https://semver.org/).

---

### Style

- cargo fmt

### 📦 Miscellaneous

- bump version to 0.1.2, sync docs

### 🔄 CI/CD

- merge release workflow into ci.yml for PyPI trusted publishing

### 🚀 Features

- add faker-powered graph generators

### 🚀 Features

- networkxr with Rust SIMD, Rayon parallelism, FxHashMap — 10x-100x faster than NetworkX
- Implement interactive graph plotting functionality using Plotly with new documentation and tests.
- add Plotly drawing support + cookbook + README examples

