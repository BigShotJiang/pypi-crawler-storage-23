"""Fully local meeting transcription and summarization CLI."""
