from ..helper_service import crm_lead_create
from ..sc_test_case import SCTestCase


class TestCRMLeadAddMobileLine(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner_id = self.browse_ref("somconnexio.res_partner_2_demo")

    def test_create_line(self):
        """
        Test creating a new mobile lead line from wizard.
        In this case, the wizard creates the mobile.isp.info record and
        adds it to a new crm.lead.line record.
        """
        fiber_crm_lead = crm_lead_create(
            self.env, self.partner_id, "fiber", portability=False
        )

        self.assertFalse(fiber_crm_lead.has_mobile_lead_lines)

        wizard_vals = {
            "product_id": self.env.ref("somconnexio.TrucadesIllimitades20GB").id,
            "icc": "1234ICC",
            "type": "new",
            "bank_id": self.partner_id.bank_ids.id,
        }
        wizard = (
            self.env["crm.lead.add.mobile.line.wizard"]
            .with_context(active_id=fiber_crm_lead.id, default_mode="create")
            .create(wizard_vals)
        )

        self.assertEqual(wizard.mode, "create")

        wizard.button_create()

        self.assertTrue(fiber_crm_lead.has_mobile_lead_lines)
        self.assertEqual(len(fiber_crm_lead.mobile_lead_line_ids), 1)

        crm_lead_line = fiber_crm_lead.mobile_lead_line_ids[0]

        self.assertEqual(
            crm_lead_line.product_id.id,
            wizard_vals["product_id"],
        )
        self.assertEqual(
            crm_lead_line.iban,
            self.partner_id.bank_ids.sanitized_acc_number,
        )
        self.assertEqual(
            crm_lead_line.mobile_isp_info.icc,
            wizard_vals["icc"],
        )
        self.assertEqual(
            crm_lead_line.mobile_isp_info.type,
            wizard_vals["type"],
        )

    def test_update_line(self):
        """
        Test updating an existing mobile lead line from wizard.
        In this case, the mobile.isp.info record is missing and
        the wizard updates the lead line to add the isp info model.
        """
        mobile_crm_lead = crm_lead_create(
            self.env, self.partner_id, "mobile", portability=False
        )
        self.assertTrue(mobile_crm_lead.has_mobile_lead_lines)
        mobile_lead_line = mobile_crm_lead.mobile_lead_line_ids[0]
        mobile_lead_line.mobile_isp_info = False

        wizard_vals = {
            "icc": "1234ICC",
            "type": "new",
        }
        wizard = (
            self.env["crm.lead.add.mobile.line.wizard"]
            .with_context(
                crm_lead_line_id=mobile_lead_line.id,
                default_bank_id=self.partner_id.bank_ids.id,
                default_mode="update",
            )
            .create(wizard_vals)
        )

        self.assertEqual(wizard.mode, "update")
        self.assertFalse(mobile_lead_line.mobile_isp_info)

        wizard.button_update()

        self.assertTrue(mobile_lead_line.mobile_isp_info)
        self.assertEqual(len(mobile_crm_lead.mobile_lead_line_ids), 1)
        self.assertEqual(
            mobile_lead_line.iban,
            self.partner_id.bank_ids.sanitized_acc_number,
        )
        self.assertEqual(
            mobile_lead_line.mobile_isp_info.icc,
            wizard_vals["icc"],
        )
        self.assertEqual(
            mobile_lead_line.mobile_isp_info.type,
            wizard_vals["type"],
        )
