from ..helper_service import crm_lead_create
from ..sc_test_case import SCTestCase


class TestCRMLeadAddBroadbandIspInfo(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner_id = self.browse_ref("somconnexio.res_partner_2_demo")
        self.broadband_crm_lead = crm_lead_create(
            self.env, self.partner_id, "fiber", portability=False
        )
        self.service_address = {
            "service_street": "Street 123",
            "service_zip_code": "08001",
            "service_city": "City",
            "service_state_id": self.browse_ref("base.state_es_b").id,
        }

    def test_update_line(self):
        """
        Test updating a broadband line from wizard.
        In this case, the broadband.isp.info record is missing and
        the wizard updates the lead line to add the isp info model.
        """
        self.assertTrue(self.broadband_crm_lead.has_broadband_lead_lines)
        broadband_lead_line = self.broadband_crm_lead.broadband_lead_line_ids[0]
        broadband_lead_line.broadband_isp_info = False
        invoice_address = {
            "invoice_street": "Street 123",
            "invoice_zip_code": "08001",
            "invoice_city": "City",
            "invoice_state_id": self.browse_ref("base.state_es_b").id,
            "invoice_country_id": self.browse_ref("base.es").id,
        }
        delivery_address = {
            "delivery_street": "Street 123",
            "delivery_zip_code": "08001",
            "delivery_city": "City",
            "delivery_state_id": self.browse_ref("base.state_es_b").id,
            "delivery_country_id": self.browse_ref("base.es").id,
        }

        wizard_vals = {
            "type": "new",
            **self.service_address,
            **invoice_address,
            **delivery_address,
        }
        wizard = (
            self.env["crm.lead.add.broadband.isp.info.wizard"]
            .with_context(
                default_crm_lead_line_id=broadband_lead_line.id,
                default_bank_id=self.partner_id.bank_ids.id,
            )
            .create(wizard_vals)
        )

        self.assertFalse(broadband_lead_line.broadband_isp_info)

        wizard.button_update()

        self.assertTrue(broadband_lead_line.broadband_isp_info)
        self.assertEqual(len(self.broadband_crm_lead.broadband_lead_line_ids), 1)
        self.assertEqual(
            broadband_lead_line.iban,
            self.partner_id.bank_ids.sanitized_acc_number,
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.type,
            wizard_vals["type"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.service_street,
            wizard_vals["service_street"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.service_zip_code,
            wizard_vals["service_zip_code"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.service_city,
            wizard_vals["service_city"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.service_state_id.id,
            wizard_vals["service_state_id"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.service_country_id.id,
            self.browse_ref("base.es").id,
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.delivery_street,
            wizard_vals["delivery_street"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.delivery_zip_code,
            wizard_vals["delivery_zip_code"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.delivery_city,
            wizard_vals["delivery_city"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.delivery_state_id.id,
            wizard_vals["delivery_state_id"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.invoice_street,
            wizard_vals["invoice_street"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.invoice_zip_code,
            wizard_vals["invoice_zip_code"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.invoice_city,
            wizard_vals["invoice_city"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.invoice_state_id.id,
            wizard_vals["invoice_state_id"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.invoice_country_id.id,
            self.browse_ref("base.es").id,
        )

    def test_update_line_portability(self):
        """
        Test updating a broadband line from wizard.
        In this case, the broadband.isp.info record is missing and
        the wizard updates the lead line to add the isp info model.
        Use portability data.
        """

        self.assertTrue(self.broadband_crm_lead.has_broadband_lead_lines)
        broadband_lead_line = self.broadband_crm_lead.broadband_lead_line_ids[0]
        broadband_lead_line.broadband_isp_info = False
        wizard_vals = {
            "type": "portability",
            "landline": "972972972",
            "previous_owner_vat_number": "52736216E",
            "previous_owner_first_name": "Test",
            "previous_owner_name": "Test",
            "keep_landline": True,
            "previous_BA_service": "fiber",
            "previous_BA_provider": self.ref("somconnexio.previousprovider3"),
            **self.service_address,
        }
        wizard = (
            self.env["crm.lead.add.broadband.isp.info.wizard"]
            .with_context(
                default_crm_lead_line_id=broadband_lead_line.id,
                default_bank_id=self.partner_id.bank_ids.id,
            )
            .create(wizard_vals)
        )

        self.assertFalse(broadband_lead_line.broadband_isp_info)

        wizard.button_update()

        self.assertTrue(broadband_lead_line.broadband_isp_info)
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.phone_number,
            wizard_vals["landline"],
        )
        self.assertTrue(broadband_lead_line.broadband_isp_info.keep_phone_number)
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.type,
            wizard_vals["type"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.previous_owner_vat_number,
            f"ES{wizard_vals['previous_owner_vat_number']}",
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.previous_owner_first_name,
            wizard_vals["previous_owner_first_name"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.previous_owner_name,
            wizard_vals["previous_owner_name"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.previous_service,
            wizard_vals["previous_BA_service"],
        )
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.previous_provider.id,
            wizard_vals["previous_BA_provider"],
        )

    def test_update_line_without_landline(self):
        """
        Test updating a broadband line from wizard.
        In this case, the broadband.isp.info record is missing and
        the wizard updates the lead line to add the isp info model.
        Use portability data.
        """
        broadband_lead_line = self.broadband_crm_lead.broadband_lead_line_ids[0]
        broadband_lead_line.broadband_isp_info = False
        broadband_lead_line.product_id.without_fix = True

        wizard_vals = {
            "type": "new",
            **self.service_address,
        }
        wizard = (
            self.env["crm.lead.add.broadband.isp.info.wizard"]
            .with_context(
                default_crm_lead_line_id=broadband_lead_line.id,
                default_bank_id=self.partner_id.bank_ids.id,
            )
            .create(wizard_vals)
        )

        self.assertFalse(broadband_lead_line.broadband_isp_info)

        wizard.button_update()

        self.assertTrue(broadband_lead_line.broadband_isp_info)
        self.assertEqual(
            broadband_lead_line.broadband_isp_info.phone_number,
            "-",
        )
