from ..sc_test_case import SCTestCase


class TestPartnerCompensationWizard(SCTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.contract = self.browse_ref("somconnexio.contract_mobile_il_20")
        self.partner = self.contract.partner_id
        self.product = self.contract.tariff_product
        self.pricelist = self.browse_ref("somconnexio.pricelist_without_IVA")
        self.price = self.pricelist._compute_price_rule(self.product, 1)[
            self.product.id
        ][0]
        self.days_without_service = 2.0

    def test_compensate_exact_amount(self):
        wizard = (
            self.env["partner.compensation.wizard"]
            .with_context(active_id=self.partner.id)
            .create(
                {
                    "contract_ids": [(6, 0, [self.contract.id])],
                    "partner_id": self.partner.id,
                    "type": "exact_amount",
                    "exact_amount": self.days_without_service,
                }
            )
        )
        ctx = wizard.button_compensate()["context"]
        self.assertEqual(
            ctx["default_summary"],
            "The amount to compensate is %.2f €" % self.days_without_service,
        )
        self.assertEqual(
            ctx["default_activity_type_id"],
            self.ref("somconnexio.mail_activity_type_sc_compensation"),
        )
        self.assertEqual(ctx["default_res_id"], self.contract.id)
        self.assertEqual(
            ctx["default_res_model_id"], self.ref("contract.model_contract_contract")
        )

    def test_compensate_days_without_service_terminated_contract(self):
        self.contract.is_terminated = True
        wizard = (
            self.env["partner.compensation.wizard"]
            .with_context(active_id=self.partner.id)
            .create(
                {
                    "contract_ids": [(6, 0, [self.contract.id])],
                    "partner_id": self.partner.id,
                    "type": "days_without_service",
                    "days_without_service": self.days_without_service,
                }
            )
        )
        ctx = wizard.button_compensate()["context"]
        self.assertEqual(
            ctx["default_summary"],
            "The amount to compensate is %.2f €"
            % (self.price / 30.0 * self.days_without_service),
        )
        self.assertEqual(
            ctx["default_activity_type_id"],
            self.ref("somconnexio.mail_activity_type_sc_compensation"),
        )
        self.assertEqual(ctx["default_res_id"], self.contract.id)
        self.assertEqual(
            ctx["default_res_model_id"], self.ref("contract.model_contract_contract")
        )
