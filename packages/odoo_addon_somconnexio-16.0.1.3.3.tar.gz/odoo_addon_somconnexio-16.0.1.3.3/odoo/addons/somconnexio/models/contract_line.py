from odoo import api, fields, models


class ContractLine(models.Model):
    _inherit = "contract.line"

    is_mobile_tariff_service = fields.Boolean(
        compute="_compute_is_mobile_tariff",
    )
    product_id = fields.Many2one(
        "product.product",
        ondelete="restrict",
        required=True,
        index=True,
    )

    @api.depends("product_id")
    def _compute_is_mobile_tariff(self):
        mobile_tariff_service = self.env.ref("somconnexio.mobile_service")
        for record in self:
            record.is_mobile_tariff_service = (
                record.product_id.categ_id == mobile_tariff_service
            )

    def cancel(self):
        """
        Set date_end to cancelled contract_lines
        """
        retult = super().cancel()
        self.write({"date_end": self.date_start})
        return retult
