from odoo import fields, models


class ContractTerminateUserReason(models.Model):
    _name = "contract.terminate.user.reason"
    _description = "Contract Termination User Reason"
    _order = "sequence"

    name = fields.Char(required=True)
    sequence = fields.Integer(string="Sequence")
    code = fields.Char(string="Code")
    parent_id = fields.Many2one(
        "contract.terminate.user.reason",
        string="Main category",
        index=True,
        ondelete="cascade",
    )
    child_id = fields.One2many(
        "contract.terminate.user.reason", "parent_id", string="Subcategories"
    )
    terminate_user_comment_required = fields.Boolean(
        string="Comment required",
        default=False,
        help="If true, the user must provide a comment when terminating the contract",  # noqa
    )
