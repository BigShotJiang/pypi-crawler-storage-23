from odoo import api, fields, models


class CRMLeadAddBroadbandISPInfo(models.TransientModel):
    _name = "crm.lead.add.broadband.isp.info.wizard"
    _description = "Wizard to add broadband ISP info to a CRM lead line"

    crm_lead_line_id = fields.Many2one("crm.lead.line")
    partner_id = fields.Many2one("res.partner", related="crm_lead_line_id.partner_id")
    bank_id = fields.Many2one(
        "res.partner.bank",
        string="Bank Account",
        required=True,
    )
    product_id = fields.Many2one(
        "product.product",
        string="Requested product",
        related="crm_lead_line_id.product_id",
    )
    type = fields.Selection(
        [("portability", "Portability"), ("new", "New")],
        string="Type",
        required=True,
    )
    previous_contract_type = fields.Selection(
        [("contract", "Contract"), ("prepaid", "Prepaid")],
        string="Previous Contract Type",
    )
    landline = fields.Char(string="Phone Number")
    previous_BA_provider = fields.Many2one(
        "previous.provider", string="Previous Provider"
    )
    previous_BA_service = fields.Selection(
        selection=[("fiber", "Fiber"), ("adsl", "ADSL"), ("4G", "4G")],
        string="Previous Service",
    )
    previous_owner_vat_number = fields.Char(string="Previous Owner VatNumber")
    previous_owner_first_name = fields.Char(string="Previous Owner First Name")
    previous_owner_name = fields.Char(string="Previous Owner Name")
    keep_landline = fields.Boolean(
        string="Keep Phone Number",
        default=False,
    )
    without_landline = fields.Boolean(related="product_id.without_fix")

    # Addresses
    service_street = fields.Char(string="Service Street", required=True)
    service_zip_code = fields.Char(string="Service ZIP", required=True)
    service_city = fields.Char(string="Service City", required=True)
    service_state_id = fields.Many2one(
        "res.country.state",
        string="Service State",
        required=True,
    )
    service_country_id = fields.Many2one(
        "res.country",
        string="Service Country",
        required=True,
    )
    delivery_street = fields.Char(string="Delivery Street")
    delivery_zip_code = fields.Char(string="Delivery ZIP")
    delivery_city = fields.Char(string="Delivery City")
    delivery_state_id = fields.Many2one(
        "res.country.state",
        string="Delivery State",
    )
    delivery_country_id = fields.Many2one(
        "res.country",
        string="Delivery Country",
    )
    invoice_street = fields.Char(string="Invoice Street")
    invoice_zip_code = fields.Char(string="Invoice ZIP")
    invoice_city = fields.Char(string="Invoice City")
    invoice_state_id = fields.Many2one(
        "res.country.state",
        string="Invoice State",
    )
    invoice_country_id = fields.Many2one(
        "res.country",
        string="Invoice Country",
    )

    def button_update(self):
        self.ensure_one()
        broadband_isp_info = self._create_broadband_isp_info()

        self.crm_lead_line_id.write(
            {
                "broadband_isp_info": broadband_isp_info.id,
            }
        )

        return True

    @api.model
    def default_get(self, fields_list):
        defaults = super().default_get(fields_list)
        spain_country_id = self.env["res.country"].search([("code", "=", "ES")]).id
        defaults["service_country_id"] = spain_country_id

        return defaults

    def _create_broadband_isp_info(self):
        """Create broadband.isp.info record from wizard data."""
        self.ensure_one()

        broadband_isp_info_params = {
            "type": self.type,
            "keep_phone_number": self.keep_landline,
            "phone_number": self.landline if not self.product_id.without_fix else "-",
            "service_street": self.service_street,
            "service_zip_code": self.service_zip_code,
            "service_city": self.service_city,
            "service_state_id": self.service_state_id.id,
            "service_country_id": self.service_country_id.id,
            "delivery_street": self.delivery_street,
            "delivery_zip_code": self.delivery_zip_code,
            "delivery_city": self.delivery_city,
            "delivery_state_id": self.delivery_state_id.id,
            "invoice_street": self.invoice_street,
            "invoice_zip_code": self.invoice_zip_code,
            "invoice_city": self.invoice_city,
            "invoice_state_id": self.invoice_state_id.id,
            "invoice_country_id": self.invoice_country_id.id,
        }
        if self.type == "portability":
            broadband_isp_info_params.update(
                {
                    "previous_phone_number": self.landline
                    if self.product_id.without_fix
                    else False,
                    "previous_provider": self.previous_BA_provider.id,
                    "previous_service": self.previous_BA_service,
                    "previous_owner_vat_number": self.previous_owner_vat_number,
                    "previous_owner_name": self.previous_owner_name,
                    "previous_owner_first_name": self.previous_owner_first_name,
                }
            )

        return self.env["broadband.isp.info"].create(broadband_isp_info_params)
