from datetime import date
from odoo import api, fields, models, _
from odoo.tools.misc import clean_context
from odoo.exceptions import ValidationError


class ContractCompensationWizard(models.TransientModel):
    _name = "contract.compensation.wizard"

    contract_id = fields.Many2one("contract.contract")
    type = fields.Selection(
        [
            ("days_without_service", "Days without Service"),
            ("exact_amount", "Exact Amount"),
        ],
        "Compensation Type",
    )
    product_id = fields.Many2one(
        "product.product", "Product", related="contract_id.current_tariff_product"
    )
    days_without_service = fields.Integer("Days without Service")
    exact_amount = fields.Float("Exact Amount")

    state = fields.Selection(
        [
            ("details", "details"),
            ("load", "load"),
        ],
        default="load",
    )

    days_without_service_import = fields.Float("Compensation amount")
    operation_date = fields.Date("Compensation date", default=fields.Date.context_today)
    description = fields.Char("Description", default=_("Compensació"))

    @api.model
    def default_get(self, fields_list):
        defaults = super().default_get(fields_list)
        contract = self.env["contract.contract"].browse(self.env.context["active_id"])
        defaults.update(
            {
                "contract_id": contract.id,
                "product_id": contract.current_tariff_product.id,
            }
        )
        return defaults

    def _calculate_compensation_amount(self):
        if self.type == "days_without_service":
            if self.days_without_service <= 0.0:
                raise ValidationError(
                    _("The amount of days without service must be greater than zero")
                )
            tariff_product = self.product_id
            pricelist = self.env["product.pricelist"].search([("code", "=", "0IVA")])
            amount = (
                pricelist._compute_price_rule(tariff_product, 1)[tariff_product.id][0]
                / 30.0
                * self.days_without_service
            )
            self.exact_amount = amount
        else:
            if self.exact_amount <= 0.0:
                raise ValidationError(_("The amount must be greater than zero €"))

    def button_compensate(self):
        self._calculate_compensation_amount()
        # Create Activity
        summary = _("The amount to compensate is %.2f €") % self.exact_amount
        note = (
            _(
                "Cal aplicar manualment una compensació de %.2f € IVA no inclòs. Utilitzeu aquest camp de text per explicar-ne les circumstàncies"  # noqa
            )
            % self.exact_amount
        )
        activity_type_id = self.env.ref("somconnexio.mail_activity_type_invoicing")
        state = "planned"
        return self.create_activity(summary, note, activity_type_id, state)

    def create_activity(self, summary, note, activity_type_id, state):
        ctx = dict(
            clean_context(self.env.context),
            default_activity_type_id=activity_type_id.id,
            default_res_id=self.contract_id.id,
            default_res_model_id=self.env.ref("contract.model_contract_contract").id,
            default_summary=summary,
            default_note=note,
            default_confirmation=True,
            default_state=state,
            default_done=True if state == "done" else False,
            default_date_done=date.today() if state == "done" else False,
        )
        return {
            "name": _("Schedule an Activity"),
            "context": ctx,
            "view_type": "form",
            "view_mode": "form",
            "res_model": "mail.activity",
            "views": [(False, "form")],
            "type": "ir.actions.act_window",
            "target": "new",
        }
