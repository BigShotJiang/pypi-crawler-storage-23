# Copyright 2025 Coopdevs Treball SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
from openupgradelib import openupgrade
import logging

_logger = logging.getLogger(__name__)


@openupgrade.migrate()
def migrate(env, version):
    """
    Set no-update to True to Fibra_product_template_Community_Number_attribute_line
    """

    model_data = env["ir.model.data"].search(
        [
            ("name", "=", "Fibra_product_template_Community_Number_attribute_line"),
            ("model", "=", "product.template.attribute.line"),
        ]
    )
    if model_data:
        _logger.info(
            "Setting no_update to True for Fibra_product_template_Community_Number_attribute_line"  # noqa E501
        )
        model_data.write({"noupdate": True})
    else:
        _logger.warning(
            "Fibra_product_template_Community_Number_attribute_line not found, skipping update."  # noqa E501
        )
