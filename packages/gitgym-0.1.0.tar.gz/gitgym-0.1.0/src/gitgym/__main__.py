from gitgym.cli import main

main()
