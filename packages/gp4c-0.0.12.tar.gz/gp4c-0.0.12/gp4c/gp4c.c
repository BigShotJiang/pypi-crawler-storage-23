#include "gp4c.h"
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

double rbf_kernel(double x, double xp, double sigma2, double ell) {
    double r = x - xp;
    return sigma2 * exp(-0.5 * r * r / (ell * ell));
}

double cross_covariance(double x, double y, double sigma2, double ell) {
    // K_fg(x, y) = integral_0^y k_ff(x, t) dt
    double sqrt_2 = sqrt(2.0);
    double sqrt_pi_2 = sqrt(M_PI / 2.0);

    double erf_1 = erf(x / (sqrt_2 * ell));
    double erf_2 = erf((x - y) / (sqrt_2 * ell));

    return sigma2 * ell * sqrt_pi_2 * (erf_1 - erf_2);
}

double integrated_rbf_kernel(double y, double yp, double sigma2, double ell) {
    // K_gg(y, y') = integral_0^y integral_0^y' k_ff(t, s) ds dt
    double sqrt_2 = sqrt(2.0);
    double sqrt_pi_2 = sqrt(M_PI / 2.0);
    double ell2 = ell * ell;

    // Error function terms
    double erf_y = erf(y / (sqrt_2 * ell));
    double erf_yp = erf(yp / (sqrt_2 * ell));
    double erf_diff = erf((y - yp) / (sqrt_2 * ell));

    // Exponential terms
    double exp_y = exp(-y*y / (2.0*ell2));
    double exp_yp = exp(-yp*yp / (2.0*ell2));
    double exp_diff = exp(-(y-yp)*(y-yp) / (2.0*ell2));

    // Full formula: two terms
    double term1 = sigma2 * ell * sqrt_pi_2 * (y * erf_y + yp * erf_yp - (y - yp) * erf_diff);
    double term2 = sigma2 * ell2 * (exp_y + exp_yp - exp_diff - 1.0);

    return term1 + term2;
}

// K_hh: Cov[f'(x), f'(x')] - derivative of derivative
double derivative_rbf_kernel(double x, double xp, double sigma2, double ell) {
    double r = x - xp;
    double r2 = r * r;
    double ell2 = ell * ell;
    return (sigma2 / ell2) * (1.0 - r2 / ell2) * exp(-0.5 * r2 / ell2);
}

// K_fh: Cov[f(x), f'(x')] - anti-symmetric!
double cross_covariance_f_h(double x, double xp, double sigma2, double ell) {
    double r = x - xp;
    double ell2 = ell * ell;
    return (sigma2 / ell2) * r * exp(-0.5 * r * r / ell2);
}

// K_gh: Cov[g(y), f'(x)] = integral_0^y K_fh(t, x) dt
double cross_covariance_g_h(double y, double x, double sigma2, double ell) {
    double ell2 = ell * ell;
    double exp_x = exp(-x*x / (2.0*ell2));
    double exp_diff = exp(-(y-x)*(y-x) / (2.0*ell2));
    return sigma2 * (exp_x - exp_diff);
}

// =============================================================================
// Matérn 5/2 Kernel Functions
// =============================================================================
// Base kernel: k(r) = σ² (1 + √5r/ℓ + 5r²/(3ℓ²)) exp(-√5r/ℓ)
// Matérn 5/2 is twice differentiable, making it suitable for derivative GPs.

#define SQRT5 2.2360679774997896964091736687747632

// K_ff for Matérn 5/2: k(x, x') = σ² (1 + √5r/ℓ + 5r²/(3ℓ²)) exp(-√5r/ℓ)
double matern52_kernel(double x, double xp, double sigma2, double ell) {
    double r = fabs(x - xp);
    double r_over_ell = r / ell;
    double sqrt5_r_ell = SQRT5 * r_over_ell;
    double r2_ell2 = r_over_ell * r_over_ell;

    return sigma2 * (1.0 + sqrt5_r_ell + (5.0/3.0) * r2_ell2) * exp(-sqrt5_r_ell);
}

// K_hh for Matérn 5/2: Cov[f'(x), f'(x')] = -d²k/dr² for stationary kernel
// Formula: (5σ²/3ℓ²) (1 + √5r/ℓ - 5r²/ℓ²) exp(-√5r/ℓ)
// Note: At r=0, this equals 5σ²/(3ℓ²)
double matern52_derivative_kernel(double x, double xp, double sigma2, double ell) {
    double r = fabs(x - xp);
    double ell2 = ell * ell;
    double r_over_ell = r / ell;
    double sqrt5_r_ell = SQRT5 * r_over_ell;
    double r2_ell2 = r_over_ell * r_over_ell;

    // (5σ²/3ℓ²) (1 + √5r/ℓ - 5r²/ℓ²) exp(-√5r/ℓ)
    double factor = (5.0 * sigma2) / (3.0 * ell2);
    double bracket = 1.0 + sqrt5_r_ell - 5.0 * r2_ell2;

    return factor * bracket * exp(-sqrt5_r_ell);
}

// K_fh for Matérn 5/2: Cov[f(x), f'(x')] = -dk/dx' (derivative w.r.t. second argument)
// Formula: (5σ²(x-x')/(3ℓ²)) (1 + √5r/ℓ) exp(-√5r/ℓ)
// Note: Anti-symmetric in argument swap: k_fh(x', x) = -k_fh(x, x')
double matern52_cross_covariance_f_h(double x, double xp, double sigma2, double ell) {
    double diff = x - xp;  // signed difference (NOT abs)
    double r = fabs(diff);
    double ell2 = ell * ell;
    double r_over_ell = r / ell;
    double sqrt5_r_ell = SQRT5 * r_over_ell;

    // (5σ²(x-x')/(3ℓ²)) (1 + √5r/ℓ) exp(-√5r/ℓ)
    double factor = (5.0 * sigma2 * diff) / (3.0 * ell2);
    double bracket = 1.0 + sqrt5_r_ell;

    return factor * bracket * exp(-sqrt5_r_ell);
}

// Helper: Antiderivative of Matérn 5/2 kernel for u >= 0
// F(u) = -σ²ℓ/(3√5) × (8 + 5√5u/ℓ + 5u²/ℓ²) × exp(-√5u/ℓ)
static double matern52_antideriv_positive(double u, double sigma2, double ell) {
    double ell2 = ell * ell;
    double ell_over_3sqrt5 = ell / (3.0 * SQRT5);
    double sqrt5_u_ell = SQRT5 * u / ell;
    double u2_ell2 = u * u / ell2;
    return -sigma2 * ell_over_3sqrt5 * (8.0 + 5.0 * sqrt5_u_ell + 5.0 * u2_ell2) * exp(-sqrt5_u_ell);
}

// Helper: Single integral of Matérn 5/2 kernel
// I(x, a, b) = ∫_a^b k_ff(x, t) dt
static double matern52_single_integral(double x, double a, double b, double sigma2, double ell) {
    // Using substitution u = t - x:
    // ∫_a^b k_ff(x,t) dt = ∫_{a-x}^{b-x} k_ff(0, u) du
    // Since k_ff only depends on |u| (symmetric kernel), we use:
    // For symmetric k(|u|): ∫_{a}^{b} k(|u|) du where a < 0 < b equals
    // [F(-a) - F(0)] + [F(b) - F(0)] = F(-a) + F(b) - 2*F(0)

    double ua = a - x;
    double ub = b - x;
    double result = 0.0;

    if (ua >= 0) {
        // Both ua and ub >= 0
        result = matern52_antideriv_positive(ub, sigma2, ell) - matern52_antideriv_positive(ua, sigma2, ell);
    } else if (ub <= 0) {
        // Both ua and ub <= 0, use symmetry: ∫_{ua}^{ub} k(|u|) du = ∫_{-ub}^{-ua} k(v) dv
        result = matern52_antideriv_positive(-ua, sigma2, ell) - matern52_antideriv_positive(-ub, sigma2, ell);
    } else {
        // ua < 0 < ub, split at 0
        // ∫_{ua}^{ub} k(|u|) du = [F(-ua) - F(0)] + [F(ub) - F(0)]
        double F0 = matern52_antideriv_positive(0.0, sigma2, ell);
        result = (matern52_antideriv_positive(-ua, sigma2, ell) - F0) + (matern52_antideriv_positive(ub, sigma2, ell) - F0);
    }

    return result;
}

// K_fg for Matérn 5/2: Cov[f(x), g(y)] = ∫_0^y k_ff(x, t) dt
double matern52_cross_covariance(double x, double y, double sigma2, double ell) {
    return matern52_single_integral(x, 0.0, y, sigma2, ell);
}

// Helper for double integral: ∫_0^y ∫_0^y' k_ff(s, t) ds dt
// This is the K_gg kernel for Matérn 5/2
// We compute this by first integrating over s (giving the single integral formula),
// then integrating over t.
//
// Actually, let's use a more direct approach via the formula:
// K_gg(y, y') = ∫_0^y ∫_0^y' k_ff(s, t) ds dt
// = ∫_0^y K_fg(t, y') dt  (where K_fg(t, y') = ∫_0^y' k_ff(t, s) ds)
//
// For numerical stability and clarity, we'll compute this using the closed-form
// double integral.

double matern52_integrated_kernel(double y, double yp, double sigma2, double ell) {
    // K_gg(y, y') = ∫_0^y ∫_0^y' k_ff(s, t) ds dt
    // We need the antiderivative of ∫_0^y' k_ff(s, t) ds with respect to t

    // This is complex. Let's use a different approach.
    // For the Matérn 5/2, the double integral can be computed analytically.
    //
    // The general formula involves:
    // 1. Breaking into regions based on relative positions of y and y'
    // 2. Computing exponential and polynomial terms

    // For simplicity and correctness, we use numerical quadrature for the
    // double integral initially, which we can optimize later with closed forms.
    // However, this would be slow. Let me derive the closed form.

    // Actually, let's compute K_gg by noting:
    // K_gg(y, y') = ∫_0^y ∫_0^y' k_ff(s, t) ds dt
    //
    // Define I(y) = ∫_0^y k_fg(t, y') dt = ∫_0^y (∫_0^y' k_ff(t, s) ds) dt
    // By Fubini: = ∫_0^y' (∫_0^y k_ff(t, s) dt) ds = ∫_0^y' k_fg(s, y) ds

    // So K_gg(y, y') = ∫_0^y' K_fg(s, y) ds

    // Given K_fg involves the antiderivative of k_ff, we need the double antiderivative.

    // Let me use the formula for the double integral of Matérn 5/2.
    // The closed form is known but complex. For now, let's use quadrature
    // with 20 points for reasonable accuracy.

    // Gauss-Legendre 20-point quadrature
    static const double gl_nodes[] = {
        -0.9931285991850949, -0.9639719272779138, -0.9122344282513259,
        -0.8391169718222188, -0.7463319064601508, -0.6360536807265150,
        -0.5108670019508271, -0.3737060887154196, -0.2277858511416451,
        -0.0765265211334973,  0.0765265211334973,  0.2277858511416451,
         0.3737060887154196,  0.5108670019508271,  0.6360536807265150,
         0.7463319064601508,  0.8391169718222188,  0.9122344282513259,
         0.9639719272779138,  0.9931285991850949
    };
    static const double gl_weights[] = {
        0.0176140071391521, 0.0406014298003869, 0.0626720483341091,
        0.0832767415767048, 0.1019301198172404, 0.1181945319615184,
        0.1316886384491766, 0.1420961093183820, 0.1491729864726037,
        0.1527533871307258, 0.1527533871307258, 0.1491729864726037,
        0.1420961093183820, 0.1316886384491766, 0.1181945319615184,
        0.1019301198172404, 0.0832767415767048, 0.0626720483341091,
        0.0406014298003869, 0.0176140071391521
    };

    // Transform from [-1, 1] to [0, y] and [0, y']
    double result = 0.0;
    double half_y = 0.5 * y;
    double half_yp = 0.5 * yp;

    for (int i = 0; i < 20; i++) {
        double s = half_y * (1.0 + gl_nodes[i]);
        for (int j = 0; j < 20; j++) {
            double t = half_yp * (1.0 + gl_nodes[j]);
            result += gl_weights[i] * gl_weights[j] * matern52_kernel(s, t, sigma2, ell);
        }
    }

    result *= half_y * half_yp;  // Jacobian of transformation
    return result;
}

// Helper: Antiderivative of u*(1 + √5u/ℓ)*exp(-√5u/ℓ) for u >= 0
// This is used for computing K_gh
static double matern52_kfh_antideriv_positive(double u, double sigma2, double ell) {
    double sqrt5_ell = SQRT5 / ell;
    double ell2 = ell * ell;
    double coeff = 5.0 * sigma2 / (3.0 * ell2);
    double alpha = sqrt5_ell;

    if (u < 1e-12) {
        // At u=0: F+(0) = coeff × [-(ℓ²/5) - (√5/ℓ)(2ℓ³/(5√5))] = -σ²
        return -sigma2;
    }

    double exp_term = exp(-alpha * u);
    // ∫ u exp(-αu) du = -(u/α + 1/α²) exp(-αu)
    double int_u = -(u/alpha + 1.0/(alpha*alpha)) * exp_term;
    // ∫ u² exp(-αu) du = -(u²/α + 2u/α² + 2/α³) exp(-αu)
    double int_u2 = -(u*u/alpha + 2.0*u/(alpha*alpha) + 2.0/(alpha*alpha*alpha)) * exp_term;
    // F+(u) = coeff × [int_u + (√5/ℓ) int_u2]
    return coeff * (int_u + sqrt5_ell * int_u2);
}

// K_gh for Matérn 5/2: Cov[g(y), h(x)] = ∫_0^y k_fh(t, x) dt
double matern52_cross_covariance_g_h(double y, double x, double sigma2, double ell) {
    // Let u = t - x, then:
    // ∫_{-x}^{y-x} (5σ²u/(3ℓ²)) (1 + √5|u|/ℓ) exp(-√5|u|/ℓ) du
    // The integrand is odd in u.

    double ua = -x;
    double ub = y - x;
    double result = 0.0;

    if (ua >= 0) {
        // Both limits positive
        result = matern52_kfh_antideriv_positive(ub, sigma2, ell) - matern52_kfh_antideriv_positive(ua, sigma2, ell);
    } else if (ub <= 0) {
        // Both limits negative: use odd function property
        // For odd f: ∫_{ua}^{ub} f(u) du = -∫_{-ub}^{-ua} f(v) dv = F+(-ub) - F+(-ua)
        result = matern52_kfh_antideriv_positive(-ub, sigma2, ell) - matern52_kfh_antideriv_positive(-ua, sigma2, ell);
    } else {
        // ua < 0 < ub: split at 0
        // ∫_{ua}^{0} f(u) du: for odd f, this equals -(∫_{0}^{-ua} f(v) dv) = -[F+(-ua) - F+(0)]
        // ∫_{0}^{ub} f(u) du = F+(ub) - F+(0)
        double F0 = matern52_kfh_antideriv_positive(0.0, sigma2, ell);
        double neg_part = -(matern52_kfh_antideriv_positive(-ua, sigma2, ell) - F0);
        double pos_part = matern52_kfh_antideriv_positive(ub, sigma2, ell) - F0;
        result = neg_part + pos_part;
    }

    return result;
}

// =============================================================================
// Matérn 3/2 Kernel Functions
// =============================================================================
// Base kernel: k(r) = σ² (1 + √3r/ℓ) exp(-√3r/ℓ)
// Matérn 3/2 is only once differentiable, so derivative (h) sampling is NOT supported.

#define SQRT3 1.7320508075688772935274463415058724

// K_ff for Matérn 3/2: k(x, x') = σ² (1 + √3r/ℓ) exp(-√3r/ℓ)
double matern32_kernel(double x, double xp, double sigma2, double ell) {
    double r = fabs(x - xp);
    double sqrt3_r_ell = SQRT3 * r / ell;
    return sigma2 * (1.0 + sqrt3_r_ell) * exp(-sqrt3_r_ell);
}

// Helper: Antiderivative of Matérn 3/2 kernel for u >= 0
// F(u) = -σ²(2ℓ/√3 + u) exp(-√3u/ℓ)
static double matern32_antideriv_positive(double u, double sigma2, double ell) {
    double sqrt3_u_ell = SQRT3 * u / ell;
    double two_ell_sqrt3 = 2.0 * ell / SQRT3;
    return -sigma2 * (two_ell_sqrt3 + u) * exp(-sqrt3_u_ell);
}

// Helper: Single integral of Matérn 3/2 kernel
// I(x, a, b) = ∫_a^b k_ff(x, t) dt
static double matern32_single_integral(double x, double a, double b, double sigma2, double ell) {
    double ua = a - x;
    double ub = b - x;
    double result = 0.0;

    if (ua >= 0) {
        // Both ua and ub >= 0
        result = matern32_antideriv_positive(ub, sigma2, ell) - matern32_antideriv_positive(ua, sigma2, ell);
    } else if (ub <= 0) {
        // Both ua and ub <= 0, use symmetry
        result = matern32_antideriv_positive(-ua, sigma2, ell) - matern32_antideriv_positive(-ub, sigma2, ell);
    } else {
        // ua < 0 < ub, split at 0
        double F0 = matern32_antideriv_positive(0.0, sigma2, ell);
        result = (matern32_antideriv_positive(-ua, sigma2, ell) - F0) + (matern32_antideriv_positive(ub, sigma2, ell) - F0);
    }

    return result;
}

// K_fg for Matérn 3/2: Cov[f(x), g(y)] = ∫_0^y k_ff(x, t) dt
double matern32_cross_covariance(double x, double y, double sigma2, double ell) {
    return matern32_single_integral(x, 0.0, y, sigma2, ell);
}

// K_gg for Matérn 3/2: double integral using Gauss-Legendre quadrature
double matern32_integrated_kernel(double y, double yp, double sigma2, double ell) {
    // Gauss-Legendre 20-point quadrature (same as Matérn 5/2)
    static const double gl_nodes[] = {
        -0.9931285991850949, -0.9639719272779138, -0.9122344282513259,
        -0.8391169718222188, -0.7463319064601508, -0.6360536807265150,
        -0.5108670019508271, -0.3737060887154196, -0.2277858511416451,
        -0.0765265211334973,  0.0765265211334973,  0.2277858511416451,
         0.3737060887154196,  0.5108670019508271,  0.6360536807265150,
         0.7463319064601508,  0.8391169718222188,  0.9122344282513259,
         0.9639719272779138,  0.9931285991850949
    };
    static const double gl_weights[] = {
        0.0176140071391521, 0.0406014298003869, 0.0626720483341091,
        0.0832767415767048, 0.1019301198172404, 0.1181945319615184,
        0.1316886384491766, 0.1420961093183820, 0.1491729864726037,
        0.1527533871307258, 0.1527533871307258, 0.1491729864726037,
        0.1420961093183820, 0.1316886384491766, 0.1181945319615184,
        0.1019301198172404, 0.0832767415767048, 0.0626720483341091,
        0.0406014298003869, 0.0176140071391521
    };

    double result = 0.0;
    double half_y = 0.5 * y;
    double half_yp = 0.5 * yp;

    for (int i = 0; i < 20; i++) {
        double s = half_y * (1.0 + gl_nodes[i]);
        for (int j = 0; j < 20; j++) {
            double t = half_yp * (1.0 + gl_nodes[j]);
            result += gl_weights[i] * gl_weights[j] * matern32_kernel(s, t, sigma2, ell);
        }
    }

    result *= half_y * half_yp;
    return result;
}

// =============================================================================
// Kernel Dispatch Functions
// =============================================================================

static inline double compute_k_ff(double x, double xp, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_kernel(x, xp, sigma2, ell);
        case KERNEL_MATERN32: return matern32_kernel(x, xp, sigma2, ell);
        default: return rbf_kernel(x, xp, sigma2, ell);
    }
}

static inline double compute_k_gg(double y, double yp, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_integrated_kernel(y, yp, sigma2, ell);
        case KERNEL_MATERN32: return matern32_integrated_kernel(y, yp, sigma2, ell);
        default: return integrated_rbf_kernel(y, yp, sigma2, ell);
    }
}

static inline double compute_k_hh(double x, double xp, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_derivative_kernel(x, xp, sigma2, ell);
        default: return derivative_rbf_kernel(x, xp, sigma2, ell);
    }
}

static inline double compute_k_fg(double x, double y, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_cross_covariance(x, y, sigma2, ell);
        case KERNEL_MATERN32: return matern32_cross_covariance(x, y, sigma2, ell);
        default: return cross_covariance(x, y, sigma2, ell);
    }
}

static inline double compute_k_fh(double x, double xp, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_cross_covariance_f_h(x, xp, sigma2, ell);
        default: return cross_covariance_f_h(x, xp, sigma2, ell);
    }
}

static inline double compute_k_gh(double y, double x, double sigma2, double ell, KernelType kernel) {
    switch (kernel) {
        case KERNEL_MATERN52: return matern52_cross_covariance_g_h(y, x, sigma2, ell);
        default: return cross_covariance_g_h(y, x, sigma2, ell);
    }
}

// =============================================================================
// Mean Function Helpers
// =============================================================================

/**
 * Evaluate mean function for f at a single point
 * For constant mean c: m_f(x) = c
 */
static double eval_mean_f(double x, const GPMeanSpec *mean) {
    if (mean == NULL || mean->type == MEAN_ZERO) {
        return 0.0;
    }
    
    switch (mean->type) {
        case MEAN_CONSTANT:
            return mean->params.constant.value;
        default:
            return 0.0;
    }
}

/**
 * Evaluate mean function for g=∫f at a single point
 * For constant c: m_g(x) = ∫₀ˣ c dt = c*x
 */
static double eval_mean_g(double x, const GPMeanSpec *mean) {
    if (mean == NULL || mean->type == MEAN_ZERO) {
        return 0.0;
    }
    
    switch (mean->type) {
        case MEAN_CONSTANT:
            return mean->params.constant.value * x;
        default:
            return 0.0;
    }
}

/**
 * Evaluate mean function for h=f' at a single point
 * For constant c: m_h(x) = dc/dx = 0
 */
static double eval_mean_h(double x, const GPMeanSpec *mean) {
    if (mean == NULL || mean->type == MEAN_ZERO) {
        return 0.0;
    }
    
    switch (mean->type) {
        case MEAN_CONSTANT:
            return 0.0;  // Derivative of constant is zero
        default:
            return 0.0;
    }
}

// =============================================================================
// Sampling Functions
// =============================================================================

int draw_joint_gp_samples(
    const double *x_f, int n_f,
    const double *x_g, int n_g,
    double sigma2, double ell,
    KernelType kernel,
    int n_samples, unsigned long seed,
    double *f_samples,
    double *g_samples,
    const GPMeanSpec *mean
) {
    int n_total = n_f + n_g;

    // Initialize random number generator
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    gsl_rng_set(rng, seed);

    // Allocate joint covariance matrix
    gsl_matrix *K = gsl_matrix_alloc(n_total, n_total);

    // Build K_ff block (top-left: n_f × n_f)
    for (int i = 0; i < n_f; i++) {
        for (int j = 0; j < n_f; j++) {
            double k_val = compute_k_ff(x_f[i], x_f[j], sigma2, ell, kernel);
            gsl_matrix_set(K, i, j, k_val);
        }
    }

    // Build K_gg block (bottom-right: n_g × n_g)
    for (int i = 0; i < n_g; i++) {
        for (int j = 0; j < n_g; j++) {
            double k_val = compute_k_gg(x_g[i], x_g[j], sigma2, ell, kernel);
            gsl_matrix_set(K, n_f + i, n_f + j, k_val);
        }
    }

    // Build K_fg and K_gf blocks (cross-covariance, symmetric)
    for (int i = 0; i < n_f; i++) {
        for (int j = 0; j < n_g; j++) {
            double k_val = compute_k_fg(x_f[i], x_g[j], sigma2, ell, kernel);
            gsl_matrix_set(K, i, n_f + j, k_val);        // K_fg
            gsl_matrix_set(K, n_f + j, i, k_val);        // K_gf (transpose)
        }
    }
    
    // Add jitter for numerical stability (block-specific)
    // f block: use default jitter (1e-8) for standard numerical stability
    for (int i = 0; i < n_f; i++) {
        double diag_val = gsl_matrix_get(K, i, i);
        gsl_matrix_set(K, i, i, diag_val + GP_JITTER_DEFAULT);
    }
    // g block: use higher jitter (1e-5) due to K_gg quadrature error
    for (int i = 0; i < n_g; i++) {
        double diag_val = gsl_matrix_get(K, n_f + i, n_f + i);
        gsl_matrix_set(K, n_f + i, n_f + i, diag_val + GP_JITTER_INTEGRAL);
    }

    // Cholesky decomposition: K = L * L^T
    int chol_status = gsl_linalg_cholesky_decomp1(K);
    if (chol_status != 0) {
        fprintf(stderr, "Cholesky decomposition failed (status %d)\n", chol_status);
        gsl_matrix_free(K);
        gsl_rng_free(rng);
        return -1;
    }
    
    // Allocate vectors for sampling
    gsl_vector *z = gsl_vector_alloc(n_total);      // Standard normal samples
    gsl_vector *sample = gsl_vector_alloc(n_total); // GP sample = L * z
    
    // Draw samples
    for (int s = 0; s < n_samples; s++) {
        // Draw standard normal samples z ~ N(0, I)
        for (int i = 0; i < n_total; i++) {
            double z_i = gsl_ran_gaussian(rng, 1.0);
            gsl_vector_set(z, i, z_i);
        }
        
        // Compute sample = L * z (using lower triangular matrix)
        gsl_vector_memcpy(sample, z);
        gsl_blas_dtrmv(CblasLower, CblasNoTrans, CblasNonUnit, K, sample);
        
        // Extract f samples (first n_f elements) and add mean
        for (int i = 0; i < n_f; i++) {
            double centered_sample = gsl_vector_get(sample, i);
            double mean_value = eval_mean_f(x_f[i], mean);
            f_samples[s * n_f + i] = centered_sample + mean_value;
        }
        
        // Extract g samples (next n_g elements) and add mean
        for (int i = 0; i < n_g; i++) {
            double centered_sample = gsl_vector_get(sample, n_f + i);
            double mean_value = eval_mean_g(x_g[i], mean);
            g_samples[s * n_g + i] = centered_sample + mean_value;
        }
    }
    
    // Cleanup
    gsl_vector_free(z);
    gsl_vector_free(sample);
    gsl_matrix_free(K);
    gsl_rng_free(rng);

    return 0;
}

int draw_gp_samples_flexible(
    const GPSamplingSpec *spec,
    double sigma2, double ell,
    KernelType kernel,
    int n_samples, unsigned long seed,
    double *f_samples, double *g_samples, double *h_samples,
    const GPMeanSpec *mean
) {
    // Extract dimensions based on flags
    int n_f = (spec->flags & GP_SAMPLE_F) ? spec->n_f : 0;
    int n_g = (spec->flags & GP_SAMPLE_G) ? spec->n_g : 0;
    int n_h = (spec->flags & GP_SAMPLE_H) ? spec->n_h : 0;
    int n_total = n_f + n_g + n_h;

    if (n_total == 0) {
        fprintf(stderr, "No samples requested (all flags zero or counts zero)\n");
        return -1;
    }

    // Initialize random number generator
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    gsl_rng_set(rng, seed);

    // Allocate joint covariance matrix
    gsl_matrix *K = gsl_matrix_alloc(n_total, n_total);

    // Index offsets for each block
    int offset_f = 0;
    int offset_g = n_f;
    int offset_h = n_f + n_g;

    // Build K_ff block (n_f × n_f)
    if (n_f > 0) {
        for (int i = 0; i < n_f; i++) {
            for (int j = 0; j < n_f; j++) {
                double k_val = compute_k_ff(spec->x_f[i], spec->x_f[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_f + i, offset_f + j, k_val);
            }
        }
    }

    // Build K_gg block (n_g × n_g)
    if (n_g > 0) {
        for (int i = 0; i < n_g; i++) {
            for (int j = 0; j < n_g; j++) {
                double k_val = compute_k_gg(spec->x_g[i], spec->x_g[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_g + i, offset_g + j, k_val);
            }
        }
    }

    // Build K_hh block (n_h × n_h)
    if (n_h > 0) {
        for (int i = 0; i < n_h; i++) {
            for (int j = 0; j < n_h; j++) {
                double k_val = compute_k_hh(spec->x_h[i], spec->x_h[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_h + i, offset_h + j, k_val);
            }
        }
    }

    // Build K_fg and K_gf blocks (symmetric cross-covariance)
    if (n_f > 0 && n_g > 0) {
        for (int i = 0; i < n_f; i++) {
            for (int j = 0; j < n_g; j++) {
                double k_val = compute_k_fg(spec->x_f[i], spec->x_g[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_f + i, offset_g + j, k_val);  // K_fg
                gsl_matrix_set(K, offset_g + j, offset_f + i, k_val);  // K_gf (transpose)
            }
        }
    }

    // Build K_fh and K_hf blocks
    // Note: K_fh is NOT symmetric in general. However, Cov[f(x), f'(x')] evaluated
    // at (x,x') gives the same value as Cov[f'(x'), f(x)] by covariance symmetry,
    // so K_hf[j,i] = K_fh[i,j] (transpose relationship holds).
    if (n_f > 0 && n_h > 0) {
        for (int i = 0; i < n_f; i++) {
            for (int j = 0; j < n_h; j++) {
                double k_val = compute_k_fh(spec->x_f[i], spec->x_h[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_f + i, offset_h + j, k_val);  // K_fh
                gsl_matrix_set(K, offset_h + j, offset_f + i, k_val);  // K_hf = K_fh^T (covariance symmetry)
            }
        }
    }

    // Build K_gh and K_hg blocks (symmetric: K_gh = K_ff(y, x))
    if (n_g > 0 && n_h > 0) {
        for (int i = 0; i < n_g; i++) {
            for (int j = 0; j < n_h; j++) {
                double k_val = compute_k_gh(spec->x_g[i], spec->x_h[j], sigma2, ell, kernel);
                gsl_matrix_set(K, offset_g + i, offset_h + j, k_val);  // K_gh
                gsl_matrix_set(K, offset_h + j, offset_g + i, k_val);  // K_hg (transpose, symmetric)
            }
        }
    }

    // Add jitter for numerical stability (block-specific)
    // Each block gets appropriate jitter based on its numerical requirements
    // f block: default jitter (1e-8)
    if (n_f > 0) {
        for (int i = 0; i < n_f; i++) {
            double diag_val = gsl_matrix_get(K, offset_f + i, offset_f + i);
            gsl_matrix_set(K, offset_f + i, offset_f + i, diag_val + GP_JITTER_DEFAULT);
        }
    }
    // g block: higher jitter (1e-5) due to K_gg quadrature error
    if (n_g > 0) {
        for (int i = 0; i < n_g; i++) {
            double diag_val = gsl_matrix_get(K, offset_g + i, offset_g + i);
            gsl_matrix_set(K, offset_g + i, offset_g + i, diag_val + GP_JITTER_INTEGRAL);
        }
    }
    // h block: intermediate jitter (1e-6) for derivative O(1/ell^2) variance
    if (n_h > 0) {
        for (int i = 0; i < n_h; i++) {
            double diag_val = gsl_matrix_get(K, offset_h + i, offset_h + i);
            gsl_matrix_set(K, offset_h + i, offset_h + i, diag_val + GP_JITTER_DERIVATIVE);
        }
    }

    // Cholesky decomposition: K = L * L^T
    int chol_status = gsl_linalg_cholesky_decomp1(K);
    if (chol_status != 0) {
        fprintf(stderr, "Cholesky decomposition failed (status %d)\n", chol_status);
        gsl_matrix_free(K);
        gsl_rng_free(rng);
        return -1;
    }

    // Allocate vectors for sampling
    gsl_vector *z = gsl_vector_alloc(n_total);
    gsl_vector *sample = gsl_vector_alloc(n_total);

    // Draw samples
    for (int s = 0; s < n_samples; s++) {
        // Draw standard normal samples z ~ N(0, I)
        for (int i = 0; i < n_total; i++) {
            double z_i = gsl_ran_gaussian(rng, 1.0);
            gsl_vector_set(z, i, z_i);
        }

        // Compute sample = L * z (using lower triangular matrix)
        gsl_vector_memcpy(sample, z);
        gsl_blas_dtrmv(CblasLower, CblasNoTrans, CblasNonUnit, K, sample);

        // Extract f samples and add mean
        if (n_f > 0 && f_samples != NULL) {
            for (int i = 0; i < n_f; i++) {
                double centered_sample = gsl_vector_get(sample, offset_f + i);
                double mean_value = eval_mean_f(spec->x_f[i], mean);
                f_samples[s * n_f + i] = centered_sample + mean_value;
            }
        }

        // Extract g samples and add mean
        if (n_g > 0 && g_samples != NULL) {
            for (int i = 0; i < n_g; i++) {
                double centered_sample = gsl_vector_get(sample, offset_g + i);
                double mean_value = eval_mean_g(spec->x_g[i], mean);
                g_samples[s * n_g + i] = centered_sample + mean_value;
            }
        }

        // Extract h samples and add mean
        if (n_h > 0 && h_samples != NULL) {
            for (int i = 0; i < n_h; i++) {
                double centered_sample = gsl_vector_get(sample, offset_h + i);
                double mean_value = eval_mean_h(spec->x_h[i], mean);
                h_samples[s * n_h + i] = centered_sample + mean_value;
            }
        }
    }

    // Cleanup
    gsl_vector_free(z);
    gsl_vector_free(sample);
    gsl_matrix_free(K);
    gsl_rng_free(rng);

    return 0;
}

// Helper function to fill a covariance block between two sets of points
// Uses GPFunctionType enum for type safety instead of magic integers
static void fill_covariance_block(
    gsl_matrix *K,
    int row_offset, int col_offset,
    const double *x1, int n1, GPFunctionType type1,
    const double *x2, int n2, GPFunctionType type2,
    double sigma2, double ell,
    KernelType kernel
) {
    for (int i = 0; i < n1; i++) {
        for (int j = 0; j < n2; j++) {
            double k_val = 0.0;

            if (type1 == GP_TYPE_F && type2 == GP_TYPE_F) {
                // K_ff
                k_val = compute_k_ff(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_G && type2 == GP_TYPE_G) {
                // K_gg
                k_val = compute_k_gg(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_H && type2 == GP_TYPE_H) {
                // K_hh
                k_val = compute_k_hh(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_F && type2 == GP_TYPE_G) {
                // K_fg
                k_val = compute_k_fg(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_G && type2 == GP_TYPE_F) {
                // K_gf = K_fg^T
                k_val = compute_k_fg(x2[j], x1[i], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_F && type2 == GP_TYPE_H) {
                // K_fh
                k_val = compute_k_fh(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_H && type2 == GP_TYPE_F) {
                // K_hf = K_fh^T (transpose by covariance symmetry: Cov[A,B] = Cov[B,A])
                k_val = compute_k_fh(x2[j], x1[i], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_G && type2 == GP_TYPE_H) {
                // K_gh
                k_val = compute_k_gh(x1[i], x2[j], sigma2, ell, kernel);
            } else if (type1 == GP_TYPE_H && type2 == GP_TYPE_G) {
                // K_hg = K_gh^T
                k_val = compute_k_gh(x2[j], x1[i], sigma2, ell, kernel);
            }

            gsl_matrix_set(K, row_offset + i, col_offset + j, k_val);
        }
    }
}

/**
 * Add noise covariance to a block of the observation covariance matrix.
 *
 * Supports three noise types:
 *   - NOISE_SCALAR: Single variance σ² added to diagonal (noise_cov points to 1 double)
 *   - NOISE_DIAGONAL: Per-observation variances (noise_cov points to n doubles)
 *   - NOISE_FULL: Full covariance matrix (noise_cov points to n×n doubles, row-major)
 *
 * @param K          The covariance matrix to modify (in place)
 * @param offset     Row/column offset for the block
 * @param noise_cov  Pointer to noise data
 * @param noise_type How to interpret noise_cov
 * @param n          Number of observations in this block
 */
static void add_noise_covariance(
    gsl_matrix *K,
    int offset,
    const double *noise_cov,
    NoiseType noise_type,
    int n
) {
    if (n <= 0 || noise_cov == NULL) {
        return;
    }

    switch (noise_type) {
        case NOISE_SCALAR:
            // Add σ² to diagonal elements
            for (int i = 0; i < n; i++) {
                double val = gsl_matrix_get(K, offset + i, offset + i);
                gsl_matrix_set(K, offset + i, offset + i, val + noise_cov[0]);
            }
            break;

        case NOISE_DIAGONAL:
            // Add σᵢ² to each diagonal element
            for (int i = 0; i < n; i++) {
                double val = gsl_matrix_get(K, offset + i, offset + i);
                gsl_matrix_set(K, offset + i, offset + i, val + noise_cov[i]);
            }
            break;

        case NOISE_FULL:
            // Add full covariance matrix (row-major storage)
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    double k_val = gsl_matrix_get(K, offset + i, offset + j);
                    double noise_val = noise_cov[i * n + j];
                    gsl_matrix_set(K, offset + i, offset + j, k_val + noise_val);
                }
            }
            break;
    }
}

int draw_gp_posterior_samples(
    const GPObservations *obs,
    const GPSamplingSpec *pred,
    double sigma2, double ell,
    KernelType kernel,
    int n_samples, unsigned long seed,
    double *f_samples, double *g_samples, double *h_samples,
    double *f_mean, double *g_mean, double *h_mean,
    double *f_std, double *g_std, double *h_std,
    const GPMeanSpec *mean
) {
    // Get observation counts
    int n_obs_f = (obs->x_f != NULL && obs->y_f != NULL) ? obs->n_f : 0;
    int n_obs_g = (obs->x_g != NULL && obs->y_g != NULL) ? obs->n_g : 0;
    int n_obs_h = (obs->x_h != NULL && obs->y_h != NULL) ? obs->n_h : 0;
    int n_obs = n_obs_f + n_obs_g + n_obs_h;

    // Get prediction counts
    int n_pred_f = (pred->flags & GP_SAMPLE_F) ? pred->n_f : 0;
    int n_pred_g = (pred->flags & GP_SAMPLE_G) ? pred->n_g : 0;
    int n_pred_h = (pred->flags & GP_SAMPLE_H) ? pred->n_h : 0;
    int n_pred = n_pred_f + n_pred_g + n_pred_h;

    if (n_obs == 0) {
        fprintf(stderr, "No observations provided\n");
        return -1;
    }
    if (n_pred == 0) {
        fprintf(stderr, "No prediction points provided\n");
        return -2;
    }

    // Initialize random number generator
    gsl_rng *rng = gsl_rng_alloc(gsl_rng_mt19937);
    gsl_rng_set(rng, seed);

    // Offsets for observation blocks
    int obs_offset_f = 0;
    int obs_offset_g = n_obs_f;
    int obs_offset_h = n_obs_f + n_obs_g;

    // Offsets for prediction blocks
    int pred_offset_f = 0;
    int pred_offset_g = n_pred_f;
    int pred_offset_h = n_pred_f + n_pred_g;

    // =========================================================================
    // 1. Build K_obs (n_obs × n_obs) - covariance of observations
    // =========================================================================
    gsl_matrix *K_obs = gsl_matrix_alloc(n_obs, n_obs);

    // Diagonal blocks
    if (n_obs_f > 0) {
        fill_covariance_block(K_obs, obs_offset_f, obs_offset_f,
                              obs->x_f, n_obs_f, GP_TYPE_F, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_obs_g > 0) {
        fill_covariance_block(K_obs, obs_offset_g, obs_offset_g,
                              obs->x_g, n_obs_g, GP_TYPE_G, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }
    if (n_obs_h > 0) {
        fill_covariance_block(K_obs, obs_offset_h, obs_offset_h,
                              obs->x_h, n_obs_h, GP_TYPE_H, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
    }

    // Off-diagonal blocks (symmetric)
    if (n_obs_f > 0 && n_obs_g > 0) {
        fill_covariance_block(K_obs, obs_offset_f, obs_offset_g,
                              obs->x_f, n_obs_f, GP_TYPE_F, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
        fill_covariance_block(K_obs, obs_offset_g, obs_offset_f,
                              obs->x_g, n_obs_g, GP_TYPE_G, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_obs_f > 0 && n_obs_h > 0) {
        fill_covariance_block(K_obs, obs_offset_f, obs_offset_h,
                              obs->x_f, n_obs_f, GP_TYPE_F, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
        fill_covariance_block(K_obs, obs_offset_h, obs_offset_f,
                              obs->x_h, n_obs_h, GP_TYPE_H, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_obs_g > 0 && n_obs_h > 0) {
        fill_covariance_block(K_obs, obs_offset_g, obs_offset_h,
                              obs->x_g, n_obs_g, GP_TYPE_G, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
        fill_covariance_block(K_obs, obs_offset_h, obs_offset_g,
                              obs->x_h, n_obs_h, GP_TYPE_H, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }

    // Add observation noise covariance (supports scalar, diagonal, or full covariance)
    add_noise_covariance(K_obs, obs_offset_f, obs->noise_f_cov, obs->noise_f_type, n_obs_f);
    add_noise_covariance(K_obs, obs_offset_g, obs->noise_g_cov, obs->noise_g_type, n_obs_g);
    add_noise_covariance(K_obs, obs_offset_h, obs->noise_h_cov, obs->noise_h_type, n_obs_h);

    // =========================================================================
    // 2. Build K_pred (n_pred × n_pred) - prior covariance of predictions
    // =========================================================================
    gsl_matrix *K_pred = gsl_matrix_alloc(n_pred, n_pred);

    // Diagonal blocks
    if (n_pred_f > 0) {
        fill_covariance_block(K_pred, pred_offset_f, pred_offset_f,
                              pred->x_f, n_pred_f, GP_TYPE_F, pred->x_f, n_pred_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_g > 0) {
        fill_covariance_block(K_pred, pred_offset_g, pred_offset_g,
                              pred->x_g, n_pred_g, GP_TYPE_G, pred->x_g, n_pred_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }
    if (n_pred_h > 0) {
        fill_covariance_block(K_pred, pred_offset_h, pred_offset_h,
                              pred->x_h, n_pred_h, GP_TYPE_H, pred->x_h, n_pred_h, GP_TYPE_H,
                              sigma2, ell, kernel);
    }

    // Off-diagonal blocks
    if (n_pred_f > 0 && n_pred_g > 0) {
        fill_covariance_block(K_pred, pred_offset_f, pred_offset_g,
                              pred->x_f, n_pred_f, GP_TYPE_F, pred->x_g, n_pred_g, GP_TYPE_G,
                              sigma2, ell, kernel);
        fill_covariance_block(K_pred, pred_offset_g, pred_offset_f,
                              pred->x_g, n_pred_g, GP_TYPE_G, pred->x_f, n_pred_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_f > 0 && n_pred_h > 0) {
        fill_covariance_block(K_pred, pred_offset_f, pred_offset_h,
                              pred->x_f, n_pred_f, GP_TYPE_F, pred->x_h, n_pred_h, GP_TYPE_H,
                              sigma2, ell, kernel);
        fill_covariance_block(K_pred, pred_offset_h, pred_offset_f,
                              pred->x_h, n_pred_h, GP_TYPE_H, pred->x_f, n_pred_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_g > 0 && n_pred_h > 0) {
        fill_covariance_block(K_pred, pred_offset_g, pred_offset_h,
                              pred->x_g, n_pred_g, GP_TYPE_G, pred->x_h, n_pred_h, GP_TYPE_H,
                              sigma2, ell, kernel);
        fill_covariance_block(K_pred, pred_offset_h, pred_offset_g,
                              pred->x_h, n_pred_h, GP_TYPE_H, pred->x_g, n_pred_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }

    // =========================================================================
    // 3. Build K_pred_obs (n_pred × n_obs) - cross-covariance
    // =========================================================================
    gsl_matrix *K_pred_obs = gsl_matrix_alloc(n_pred, n_obs);

    // All 9 possible blocks
    if (n_pred_f > 0 && n_obs_f > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_f, obs_offset_f,
                              pred->x_f, n_pred_f, GP_TYPE_F, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_f > 0 && n_obs_g > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_f, obs_offset_g,
                              pred->x_f, n_pred_f, GP_TYPE_F, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }
    if (n_pred_f > 0 && n_obs_h > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_f, obs_offset_h,
                              pred->x_f, n_pred_f, GP_TYPE_F, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
    }
    if (n_pred_g > 0 && n_obs_f > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_g, obs_offset_f,
                              pred->x_g, n_pred_g, GP_TYPE_G, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_g > 0 && n_obs_g > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_g, obs_offset_g,
                              pred->x_g, n_pred_g, GP_TYPE_G, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }
    if (n_pred_g > 0 && n_obs_h > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_g, obs_offset_h,
                              pred->x_g, n_pred_g, GP_TYPE_G, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
    }
    if (n_pred_h > 0 && n_obs_f > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_h, obs_offset_f,
                              pred->x_h, n_pred_h, GP_TYPE_H, obs->x_f, n_obs_f, GP_TYPE_F,
                              sigma2, ell, kernel);
    }
    if (n_pred_h > 0 && n_obs_g > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_h, obs_offset_g,
                              pred->x_h, n_pred_h, GP_TYPE_H, obs->x_g, n_obs_g, GP_TYPE_G,
                              sigma2, ell, kernel);
    }
    if (n_pred_h > 0 && n_obs_h > 0) {
        fill_covariance_block(K_pred_obs, pred_offset_h, obs_offset_h,
                              pred->x_h, n_pred_h, GP_TYPE_H, obs->x_h, n_obs_h, GP_TYPE_H,
                              sigma2, ell, kernel);
    }

    // =========================================================================
    // 4. Concatenate observation values into y_obs vector and subtract mean
    // =========================================================================
    gsl_vector *y_obs = gsl_vector_alloc(n_obs);
    int idx = 0;
    // f observations: subtract mean
    for (int i = 0; i < n_obs_f; i++) {
        double y = obs->y_f[i];
        double m = eval_mean_f(obs->x_f[i], mean);
        gsl_vector_set(y_obs, idx++, y - m);
    }
    // g observations: subtract mean
    for (int i = 0; i < n_obs_g; i++) {
        double y = obs->y_g[i];
        double m = eval_mean_g(obs->x_g[i], mean);
        gsl_vector_set(y_obs, idx++, y - m);
    }
    // h observations: subtract mean
    for (int i = 0; i < n_obs_h; i++) {
        double y = obs->y_h[i];
        double m = eval_mean_h(obs->x_h[i], mean);
        gsl_vector_set(y_obs, idx++, y - m);
    }

    // =========================================================================
    // 5. Cholesky decompose K_obs
    // =========================================================================
    int chol_status = gsl_linalg_cholesky_decomp1(K_obs);
    if (chol_status != 0) {
        fprintf(stderr, "Cholesky decomposition of K_obs failed (status %d)\n", chol_status);
        gsl_matrix_free(K_obs);
        gsl_matrix_free(K_pred);
        gsl_matrix_free(K_pred_obs);
        gsl_vector_free(y_obs);
        gsl_rng_free(rng);
        return -3;
    }

    // =========================================================================
    // 6. Solve for alpha = K_obs^{-1} @ y_obs
    // =========================================================================
    gsl_vector *alpha = gsl_vector_alloc(n_obs);
    gsl_vector_memcpy(alpha, y_obs);
    gsl_linalg_cholesky_svx(K_obs, alpha);  // alpha = K_obs^{-1} @ y_obs

    // =========================================================================
    // 7. Compute posterior mean: mu_post = K_pred_obs @ alpha, then add m(x_pred)
    // =========================================================================
    gsl_vector *mu_post = gsl_vector_alloc(n_pred);
    gsl_blas_dgemv(CblasNoTrans, 1.0, K_pred_obs, alpha, 0.0, mu_post);

    // Copy posterior means to output arrays and add mean function
    if (f_mean != NULL && n_pred_f > 0) {
        for (int i = 0; i < n_pred_f; i++) {
            double centered = gsl_vector_get(mu_post, pred_offset_f + i);
            double m = eval_mean_f(pred->x_f[i], mean);
            f_mean[i] = centered + m;
        }
    }
    if (g_mean != NULL && n_pred_g > 0) {
        for (int i = 0; i < n_pred_g; i++) {
            double centered = gsl_vector_get(mu_post, pred_offset_g + i);
            double m = eval_mean_g(pred->x_g[i], mean);
            g_mean[i] = centered + m;
        }
    }
    if (h_mean != NULL && n_pred_h > 0) {
        for (int i = 0; i < n_pred_h; i++) {
            double centered = gsl_vector_get(mu_post, pred_offset_h + i);
            double m = eval_mean_h(pred->x_h[i], mean);
            h_mean[i] = centered + m;
        }
    }

    // =========================================================================
    // 8. Compute posterior covariance: K_post = K_pred - K_pred_obs @ K_obs^{-1} @ K_pred_obs^T
    // =========================================================================
    // First solve v = L^{-1} @ K_pred_obs^T where L is lower Cholesky of K_obs
    gsl_matrix *v = gsl_matrix_alloc(n_obs, n_pred);
    for (int j = 0; j < n_pred; j++) {
        for (int i = 0; i < n_obs; i++) {
            gsl_matrix_set(v, i, j, gsl_matrix_get(K_pred_obs, j, i));
        }
    }
    // Solve L @ v = K_pred_obs^T column by column
    for (int j = 0; j < n_pred; j++) {
        gsl_vector_view col = gsl_matrix_column(v, j);
        gsl_blas_dtrsv(CblasLower, CblasNoTrans, CblasNonUnit, K_obs, &col.vector);
    }

    // K_post = K_pred - v^T @ v
    gsl_matrix *K_post = gsl_matrix_alloc(n_pred, n_pred);
    gsl_matrix_memcpy(K_post, K_pred);
    gsl_blas_dgemm(CblasTrans, CblasNoTrans, -1.0, v, v, 1.0, K_post);

    // =========================================================================
    // 9. Extract posterior standard deviations from K_post diagonal (before jitter)
    // =========================================================================
    if (f_std != NULL && n_pred_f > 0) {
        for (int i = 0; i < n_pred_f; i++) {
            double var = gsl_matrix_get(K_post, pred_offset_f + i, pred_offset_f + i);
            f_std[i] = sqrt(fmax(var, 0.0));  // Clamp to avoid sqrt of negative due to numerical error
        }
    }
    if (g_std != NULL && n_pred_g > 0) {
        for (int i = 0; i < n_pred_g; i++) {
            double var = gsl_matrix_get(K_post, pred_offset_g + i, pred_offset_g + i);
            g_std[i] = sqrt(fmax(var, 0.0));
        }
    }
    if (h_std != NULL && n_pred_h > 0) {
        for (int i = 0; i < n_pred_h; i++) {
            double var = gsl_matrix_get(K_post, pred_offset_h + i, pred_offset_h + i);
            h_std[i] = sqrt(fmax(var, 0.0));
        }
    }

    // Add jitter for numerical stability (block-specific)
    // Each block gets appropriate jitter based on its numerical requirements
    // f block: default jitter (1e-8)
    if (n_pred_f > 0) {
        for (int i = 0; i < n_pred_f; i++) {
            double val = gsl_matrix_get(K_post, pred_offset_f + i, pred_offset_f + i);
            gsl_matrix_set(K_post, pred_offset_f + i, pred_offset_f + i, val + GP_JITTER_DEFAULT);
        }
    }
    // g block: higher jitter (1e-5) due to K_gg quadrature error
    if (n_pred_g > 0) {
        for (int i = 0; i < n_pred_g; i++) {
            double val = gsl_matrix_get(K_post, pred_offset_g + i, pred_offset_g + i);
            gsl_matrix_set(K_post, pred_offset_g + i, pred_offset_g + i, val + GP_JITTER_INTEGRAL);
        }
    }
    // h block: intermediate jitter (1e-6) for derivative O(1/ell^2) variance
    if (n_pred_h > 0) {
        for (int i = 0; i < n_pred_h; i++) {
            double val = gsl_matrix_get(K_post, pred_offset_h + i, pred_offset_h + i);
            gsl_matrix_set(K_post, pred_offset_h + i, pred_offset_h + i, val + GP_JITTER_DERIVATIVE);
        }
    }

    // =========================================================================
    // 10. Cholesky decompose K_post and sample
    // =========================================================================
    chol_status = gsl_linalg_cholesky_decomp1(K_post);
    if (chol_status != 0) {
        fprintf(stderr, "Cholesky decomposition of K_post failed (status %d)\n", chol_status);
        gsl_matrix_free(K_obs);
        gsl_matrix_free(K_pred);
        gsl_matrix_free(K_pred_obs);
        gsl_matrix_free(K_post);
        gsl_matrix_free(v);
        gsl_vector_free(y_obs);
        gsl_vector_free(alpha);
        gsl_vector_free(mu_post);
        gsl_rng_free(rng);
        return -4;
    }

    // Sample from posterior
    gsl_vector *z = gsl_vector_alloc(n_pred);
    gsl_vector *sample = gsl_vector_alloc(n_pred);

    for (int s = 0; s < n_samples; s++) {
        // Draw standard normal samples
        for (int i = 0; i < n_pred; i++) {
            gsl_vector_set(z, i, gsl_ran_gaussian(rng, 1.0));
        }

        // sample = mu_post + L_post @ z
        gsl_vector_memcpy(sample, z);
        gsl_blas_dtrmv(CblasLower, CblasNoTrans, CblasNonUnit, K_post, sample);
        gsl_vector_add(sample, mu_post);

        // Extract samples to output arrays and add mean function
        if (f_samples != NULL && n_pred_f > 0) {
            for (int i = 0; i < n_pred_f; i++) {
                double centered = gsl_vector_get(sample, pred_offset_f + i);
                double m = eval_mean_f(pred->x_f[i], mean);
                f_samples[s * n_pred_f + i] = centered + m;
            }
        }
        if (g_samples != NULL && n_pred_g > 0) {
            for (int i = 0; i < n_pred_g; i++) {
                double centered = gsl_vector_get(sample, pred_offset_g + i);
                double m = eval_mean_g(pred->x_g[i], mean);
                g_samples[s * n_pred_g + i] = centered + m;
            }
        }
        if (h_samples != NULL && n_pred_h > 0) {
            for (int i = 0; i < n_pred_h; i++) {
                double centered = gsl_vector_get(sample, pred_offset_h + i);
                double m = eval_mean_h(pred->x_h[i], mean);
                h_samples[s * n_pred_h + i] = centered + m;
            }
        }
    }

    // Cleanup
    gsl_matrix_free(K_obs);
    gsl_matrix_free(K_pred);
    gsl_matrix_free(K_pred_obs);
    gsl_matrix_free(K_post);
    gsl_matrix_free(v);
    gsl_vector_free(y_obs);
    gsl_vector_free(alpha);
    gsl_vector_free(mu_post);
    gsl_vector_free(z);
    gsl_vector_free(sample);
    gsl_rng_free(rng);

    return 0;
}
