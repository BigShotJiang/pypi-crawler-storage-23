"""gp4c - Fast joint GP sampling with integral and derivative relationships.

This package provides efficient sampling from joint Gaussian Processes where:
- f(x) is a GP with RBF kernel
- g(x) = integral of f from 0 to x
- h(x) = f'(x), the derivative

All functions maintain exact covariance structure through analytically-derived
cross-covariance kernels.
"""

from ._core import (
    sample_prior,
    sample_posterior,
)
from .types import (
    MeanSpec,
    SamplingSpec,
    GPSamples,
    Observations,
    PosteriorSamples,
)

__version__ = "2.0.0"
__all__ = [
    "sample_prior",
    "sample_posterior",
    "MeanSpec",
    "SamplingSpec",
    "GPSamples",
    "Observations",
    "PosteriorSamples",
]
