# Tests for GP joint sampler
