
#Reliabitity Data:
#Generic dictionary for sensors:

def rd_fr_sensor_analog_transmitter_generic():
    return {"name": "Generic Analog Transmitter",       "λ_du":     2e-7, "λ_dd":   1.8e-6, "λ_su":     2e-7, "λ_sd":   1.8e-6, "Type": "B", "SC": 3, "β": 0.040, "βd": 0.020, "HTF": 0, "MTTR": 160}

def rd_fr_sensor_mechanical_switch():
    return {"name": "Generic Mechanical Switch",        "λ_du":     4e-6, "λ_dd":        0, "λ_su":     4e-6, "λ_sd":    4e-13, "Type": "A", "SC": 2, "β": 0.050, "βd": 0.025, "HTF": 0, "MTTR": 100}

#Generic dictionary for Logic Solver:
def rd_fr_ls_sil3_certified_plc_generic():
    return {"name": "Generic SIL3 Certified PLC",       "λ_du":  6.77e-9, "λ_dd":        0, "λ_su":  1.85e-7, "λ_sd":        0, "Type": "B", "SC": 3, "β": 0.050, "βd": 0.025, "HTF": 1, "MTTR": 100}

#Generifc dictionary for final element:

def rd_fr_fe_valve_onoff_generic():
    return {"name": "Generic ON-OFF Failsafe Valve",    "λ_du":  3.37e-6, "λ_dd":        0, "λ_su":  1.38e-6, "λ_sd":        0, "Type": "A", "SC": 3, "β": 0.050, "βd": 0.025, "HTF": 0, "MTTR": 100}

def rd_fr_st_IEC61508_Tableb9():
    return {"name": "IEC61508-6 Table B9",              "λ_du":   0.5e-5, "λ_dd":        0, "λ_su":        0, "λ_sd":        0, "Type": "A", "SC": 3, "β": 0.100, "βd": 0.050, "HTF": 0, "MTTR":   8}

#Generic data for testing:
def rd_pt_sensor_analog_AGAN():
    return {"name":"As Good As New Test", "PTC": 1}

def rd_pt_sensor_analog_transmitter_DeciceMunicator():
    return {"name":"Device Communication Test", "PTC": 0.54 }

def rd_pt_valve_inline_test():
    return {"name":"Inline test and tightness", "PTC": 0.8 }

def rd_pt_partial_stroke_test():
    return {"name":"Partial stroke test", "PTC": 0.7 }

