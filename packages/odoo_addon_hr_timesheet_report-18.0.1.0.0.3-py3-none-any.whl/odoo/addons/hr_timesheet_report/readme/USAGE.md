To create report using Timesheet Report Wizard on a specific set of
Timesheet entries:

1.  Go to *Timesheets \> My Timesheets* or *Timesheets \> All
    timesheets*.
2.  Select entries that should be used in the report
3.  Press the *Action \> Generate Timesheet Report* button
4.  Configure the report and export it in one of the formats

To create report using Timesheet Report Wizard on a generic set of
Timesheet entries:

1.  Go to *Timesheets \> Reporting \> Timesheet Report Wizard*.
2.  Configure the report and export it in one of the formats
