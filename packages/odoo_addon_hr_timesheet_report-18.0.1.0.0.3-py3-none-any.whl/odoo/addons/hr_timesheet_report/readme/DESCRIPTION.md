This module allows to generate configurable Timesheet Report from Task
Logs.

Features:

> - Select reported fields
> - Select and reorder report line grouping
> - Configure time format (HH:MM, HH:MM:SS, or decimal)
> - View in browser, export in PDF and XLSX formats
