# Changelog

Alle wesentlichen Änderungen an diesem Projekt werden hier dokumentiert.
Format basiert auf [Keep a Changelog](https://keepachangelog.com/de/1.1.0/).

## [Unreleased]

## [0.2.4] - 2026-03-06

### Hinzugefügt
- CHANGELOG.md und RELEASING.md für einheitlichen Release-Prozess
- CLAUDE.md: Sister-Projects-Übersicht, Internal-Documentation-Verweis, Conventions-Sektion

## [0.2.3] - 2026-03-01

_Versionsbump, keine funktionalen Änderungen._

## [0.2.2] - 2026-03-01

### Hinzugefügt
- Config-Retry und Client-Rekonfiguration für späte Fleet-Config-Verfügbarkeit
- Tests für send_snapshot und StatusSource ABC Compliance

## [0.2.1] - 2026-03-01

### Hinzugefügt
- Vollständiges Status-Snapshot-Reporting an Fleet Management

## [0.2.0] - 2026-03-01

### Geändert
- StatusSource-Implementierungen erben jetzt von ABC

## [0.1.2] - 2026-02-28

### Hinzugefügt
- PEP 561 py.typed Marker für Inline-Type-Annotations

### Geändert
- GitLab Package Registry entfernt, nur noch PyPI

## [0.1.1] - 2026-02-28

### Hinzugefügt
- PyPI README und Dokumentation der Version-Locations
- Fleet Management Dokumentation: Config-Format, Token, Endpunkte

### Geändert
- MQTT-Referenzen durch HTTPS ersetzt
