import dataframely as dy


class SignalsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    signal = dy.Float(nullable=True)


class ScoresSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    score = dy.Float(nullable=True)


class AlphasSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    alpha = dy.Float(nullable=True)


class UniverseSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()


class BenchmarkWeightsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    weight = dy.Float()


class ReturnsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    return_ = dy.Float(alias="return")


class FactorLoadingsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    factor = dy.String()
    loading = dy.Float()


class FactorCovariancesSchema(dy.Schema):
    date = dy.Date()
    factor_1 = dy.String()
    factor_2 = dy.String()
    covariance = dy.Float()


class IdioVolSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    idio_vol = dy.Float()


class PortfolioWeightsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    weight = dy.Float()


class PositionResultsSchema(dy.Schema):
    date = dy.Date()
    ticker = dy.String()
    weight = dy.Float()
    value = dy.Float()
    return_ = dy.Float(alias="return")
    pnl = dy.Float()


class PortfolioReturnsSchema(dy.Schema):
    date = dy.Date()
    portfolio_value = dy.Float()
    portfolio_return = dy.Float()


class BenchmarkReturnsSchema(dy.Schema):
    date = dy.Date()
    benchmark_return = dy.Float()


class ActiveReturnsSchema(dy.Schema):
    date = dy.Date()
    active_return = dy.Float()


class PerformanceSummarySchema(dy.Schema):
    annualized_return_pct = dy.Float()
    annualized_volatility_pct = dy.Float()
    sharpe_ratio = dy.Float()
    max_drawdown_pct = dy.Float()
    active_return_pct = dy.Float(nullable=True)
    tracking_error_pct = dy.Float(nullable=True)
    information_ratio = dy.Float(nullable=True)
    relative_max_drawdown_pct = dy.Float(nullable=True)
