const usePaperStore = defineStore('paper', () => {
    const recentPapers = ref([]);
    const loadingRecent = ref(true);
    const loadingProgress = ref(0);
    const loadingTotal = ref(0);
    const loadingController = ref(null);
    const updatingRecent = ref(false);
    const recentLogs = ref([]);
    const recentDays = ref('7');
    const recentNeedSync = ref(true);
    const recentSelectedIds = ref([]);
    const recentSearchQuery = ref('');
    const recentSearching = ref(false);
    const recentUseAiSearch = ref(true);
    const recentOriginalPapers = ref([]);
    
    const homeQuery = ref('');
    const homeSearching = ref(false);
    const homeLogs = ref([]);
    const homeResults = ref([]);
    const homeSelectedIds = ref([]);
    const homeController = ref(null);
    const homeLogsContainer = ref(null);
    const homeUserScrolledUp = ref(false);
    
    const searchQuery = ref('');
    const searching = ref(false);
    const searchLogs = ref([]);
    const searchResults = ref([]);
    const searchSelectedIds = ref([]);
    
    const paperCart = ref([]);
    const showCart = ref(false);
    const cartExportLoading = ref(false);
    const cartPosition = ref({ x: window.innerWidth - 424, y: window.innerHeight - 520 });
    const cartPanelRef = ref(null);
    const cartZIndex = ref(1000);
    
    const stats = ref(null);
    const fieldStats = ref([]);
    
    function toggleRecentSelection(paperId) {
        const idx = recentSelectedIds.value.indexOf(paperId);
        if (idx >= 0) {
            recentSelectedIds.value.splice(idx, 1);
        } else {
            recentSelectedIds.value.push(paperId);
        }
    }
    
    function toggleAllRecent() {
        if (recentSelectedIds.value.length !== recentPapers.value.length) {
            recentSelectedIds.value = recentPapers.value.map(p => p.id);
        } else {
            recentSelectedIds.value = [];
        }
    }
    
    function toggleSearchSelection(paperId) {
        const idx = searchSelectedIds.value.indexOf(paperId);
        if (idx >= 0) {
            searchSelectedIds.value.splice(idx, 1);
        } else {
            searchSelectedIds.value.push(paperId);
        }
    }
    
    function toggleAllSearch() {
        if (searchSelectedIds.value.length !== searchResults.value.length) {
            searchSelectedIds.value = searchResults.value.map(p => p.id);
        } else {
            searchSelectedIds.value = [];
        }
    }
    
    function toggleHomeSelection(paperId) {
        const idx = homeSelectedIds.value.indexOf(paperId);
        if (idx >= 0) {
            homeSelectedIds.value.splice(idx, 1);
        } else {
            homeSelectedIds.value.push(paperId);
        }
    }
    
    function addToCart(paper) {
        if (!paperCart.value.find(p => p.arxiv_id === paper.arxiv_id)) {
            paperCart.value.push(paper);
        }
    }
    
    function removeFromCart(arxivId) {
        const idx = paperCart.value.findIndex(p => p.arxiv_id === arxivId);
        if (idx >= 0) {
            paperCart.value.splice(idx, 1);
        }
    }
    
    function clearCart() {
        paperCart.value = [];
    }
    
    function isInCart(arxivId) {
        return paperCart.value.some(p => p.arxiv_id === arxivId);
    }
    
    function exportCart(format, configStore) {
        if (paperCart.value.length === 0) return;
        
        const papersWithId = paperCart.value.filter(p => p.id);
        const filename = `papers_export_${Date.now()}`;
        const isZh = configStore?.currentLang === 'zh';
        
        if (format === 'pdf') {
            if (papersWithId.length === 0) {
                ElementPlus.ElMessage.warning(isZh ? 'PDF 导出需要论文已保存到数据库，请先同步论文' : 'PDF export requires papers saved in database. Please sync first');
                return;
            }
            const loadingMsg = ElementPlus.ElMessage({
                message: isZh ? '正在生成汇总 PDF，请耐心等待...' : 'Generating summary PDF, please wait...',
                type: 'info',
                duration: 0
            });
            API.export.papers({ 
                paper_ids: papersWithId.map(p => p.id), 
                format: 'pdf',
                include_summary: true,
                language: isZh ? 'zh' : 'en'
            }).then(res => {
                if (res.ok) {
                    return res.blob();
                }
                throw new Error('Export failed');
            }).then(blob => {
                loadingMsg.close();
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${filename}.pdf`;
                a.click();
                URL.revokeObjectURL(url);
                ElementPlus.ElMessage.success(isZh ? 'PDF 导出成功' : 'PDF exported successfully');
            }).catch(() => {
                loadingMsg.close();
                ElementPlus.ElMessage.error(isZh ? '导出失败' : 'Export failed');
            });
            return;
        }
        
        if (format === 'pdf_original') {
            ElementPlus.ElMessage.info(isZh ? `开始下载 ${paperCart.value.length} 个 PDF 原文...` : `Downloading ${paperCart.value.length} original PDFs...`);
            let successCount = 0;
            const downloadNext = async (index) => {
                if (index >= paperCart.value.length) {
                    if (successCount > 0) {
                        ElementPlus.ElMessage.success(`已下载 ${successCount} 个 PDF 原文`);
                    } else {
                        ElementPlus.ElMessage.error('下载失败');
                    }
                    return;
                }
                const paper = paperCart.value[index];
                try {
                    const res = await API.papers.pdf(paper.arxiv_id);
                    if (res.ok) {
                        const blob = await res.blob();
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        const safeId = paper.arxiv_id.replace(/[\/\\]/g, '_');
                        a.download = `${safeId}.pdf`;
                        a.click();
                        URL.revokeObjectURL(url);
                        successCount++;
                        await new Promise(r => setTimeout(r, 300));
                    }
                } catch (e) {
                    console.error(`Failed to download ${paper.arxiv_id}:`, e);
                }
                downloadNext(index + 1);
            };
            downloadNext(0);
            return;
        }
        
        const downloadFile = (content, filename, mimeType) => {
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
        };
        
        if (format === 'markdown' || format === 'csv' || format === 'bibtex') {
            if (papersWithId.length === 0) {
                ElementPlus.ElMessage.warning(isZh ? '导出需要论文已保存到数据库，请先同步论文' : 'Export requires papers saved in database. Please sync first');
                return;
            }
            API.export.papers({ 
                paper_ids: papersWithId.map(p => p.id), 
                format: format,
                include_summary: true,
                language: isZh ? 'zh' : 'en'
            }).then(async res => {
                if (!res.ok) throw new Error('Export failed');
                const content = await res.text();
                const ext = format === 'markdown' ? 'md' : format === 'bibtex' ? 'bib' : format;
                downloadFile(content, `${filename}.${ext}`, format === 'markdown' ? 'text/markdown' : format === 'csv' ? 'text/csv' : 'application/x-bibtex');
                ElementPlus.ElMessage.success(isZh ? '导出成功' : 'Export successful');
            }).catch(() => {
                ElementPlus.ElMessage.error(isZh ? '导出失败' : 'Export failed');
            });
        }
    }
    
    function copyCartLinks() {
        if (paperCart.value.length === 0) return;
        const links = paperCart.value.map(p => `https://arxiv.org/abs/${p.arxiv_id}`).join('\n');
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(links).then(() => {
                ElementPlus.ElMessage.success(`已复制 ${paperCart.value.length} 个链接`);
            }).catch(() => {
                const textarea = document.createElement('textarea');
                textarea.value = links;
                textarea.style.position = 'fixed';
                textarea.style.left = '-9999px';
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                ElementPlus.ElMessage.success(`已复制 ${paperCart.value.length} 个链接`);
            });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = links;
            textarea.style.position = 'fixed';
            textarea.style.left = '-9999px';
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            ElementPlus.ElMessage.success(`已复制 ${paperCart.value.length} 个链接`);
        }
    }
    
    async function fetchStats() {
        try {
            const res = await API.stats.get();
            stats.value = await res.json();
        } catch (e) {
            console.error('Failed to fetch stats:', e);
        }
    }
    
    async function fetchFieldStats() {
        try {
            const res = await API.stats.fields();
            const data = await res.json();
            fieldStats.value = data.fields || [];
        } catch (e) {
            console.error('Failed to fetch field stats:', e);
        }
    }
    
    async function fetchRecentCache() {
        loadingRecent.value = true;
        loadingProgress.value = 0;
        loadingTotal.value = 0;
        recentPapers.value = [];
        
        const controller = new AbortController();
        loadingController.value = controller;
        
        try {
            const response = await API.papers.recentCacheStream('');
            response.body.cancel = () => controller.abort();
            
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.type === 'log') {
                                recentLogs.value.push({ type: 'info', message: data.message });
                            } else if (data.type === 'paper') {
                                recentPapers.value.push(data.paper);
                                loadingProgress.value++;
                            } else if (data.type === 'total') {
                                loadingTotal.value = data.total;
                            } else if (data.type === 'done') {
                                recentNeedSync.value = data.need_sync || false;
                                if (recentPapers.value.length === 0) {
                                    recentLogs.value.push({ type: 'info', message: '暂无数据，请先同步论文' });
                                }
                            } else if (data.type === 'error') {
                                recentLogs.value.push({ type: 'error', message: data.message });
                            }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {
            if (e.name !== 'AbortError') {
                console.error('Failed to fetch recent papers:', e);
                recentLogs.value.push({ type: 'error', message: `加载失败: ${e.message}` });
            }
        } finally {
            loadingRecent.value = false;
        }
    }
    
    async function updateRecentPapers(configStore) {
        updatingRecent.value = true;
        recentLogs.value = [];
        recentOriginalPapers.value = [];
        recentSearchQuery.value = '';
        
        try {
            const params = new URLSearchParams({
                days: recentDays.value,
                limit: configStore.settingsConfig.recent_papers_limit || 50
            });
            
            const response = await API.papers.recentUpdate(params.toString());
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.type === 'log') {
                                recentLogs.value.push({ type: 'info', message: data.message });
                            } else if (data.type === 'paper') {
                                recentPapers.value.unshift(data.paper);
                            } else if (data.type === 'done') {
                                recentNeedSync.value = false;
                                recentLogs.value.push({ type: 'success', message: configStore?.currentLang === 'zh' ? '更新完成' : 'Update completed' });
                            } else if (data.type === 'error') {
                                recentLogs.value.push({ type: 'error', message: data.message });
                            }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {
            recentLogs.value.push({ type: 'error', message: `更新失败: ${e.message}` });
        } finally {
            updatingRecent.value = false;
        }
    }
    
    function resetRecentSearch() {
        if (recentOriginalPapers.value.length > 0) {
            recentPapers.value = [...recentOriginalPapers.value];
            recentOriginalPapers.value = [];
        }
        recentSearchQuery.value = '';
        recentSearching.value = false;
    }
    
    async function searchRecentPapers(configStore) {
        if (!recentSearchQuery.value.trim()) {
            resetRecentSearch();
            return;
        }
        
        if (recentOriginalPapers.value.length === 0) {
            recentOriginalPapers.value = recentPapers.value.map((p, idx) => ({ ...p, _originalIndex: idx }));
        }
        
        if (recentUseAiSearch.value) {
            recentSearching.value = true;
            
            try {
                const paperIds = recentOriginalPapers.value.map(p => p.id);
                const res = await API.papers.aiFilter({
                    query: recentSearchQuery.value,
                    paper_ids: paperIds
                });
                
                if (res.ok) {
                    const data = await res.json();
                    recentPapers.value = data.papers || [];
                    if (data.papers && data.papers.length === 0) {
                        ElementPlus.ElMessage.info(configStore?.currentLang === 'zh' ? '未找到匹配的论文' : 'No matching papers found');
                    }
                } else {
                    const errData = await res.json();
                    ElementPlus.ElMessage.error(errData.detail || (configStore?.currentLang === 'zh' ? 'AI 搜索失败' : 'AI search failed'));
                }
            } catch (e) {
                console.error('AI search failed:', e);
                ElementPlus.ElMessage.error(configStore?.currentLang === 'zh' ? 'AI 搜索失败' : 'AI search failed');
            } finally {
                recentSearching.value = false;
            }
        } else {
            const query = recentSearchQuery.value.toLowerCase();
            recentPapers.value = recentOriginalPapers.value.filter(p => 
                (p.title && p.title.toLowerCase().includes(query)) ||
                (p.abstract && p.abstract.toLowerCase().includes(query)) ||
                (p.authors && p.authors.some(a => a.name && a.name.toLowerCase().includes(query)))
            );
        }
    }
    
    async function searchPapers(configStore) {
        if (!searchQuery.value.trim()) return;
        
        searching.value = true;
        searchLogs.value = [];
        searchResults.value = [];
        searchSelectedIds.value = [];
        
        try {
            const params = new URLSearchParams({
                q: searchQuery.value,
                limit: configStore.settingsConfig.search_limit || 20
            });
            
            const response = await API.papers.searchStream(params.toString());
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.type === 'log') {
                                searchLogs.value.push({ type: 'info', message: data.message });
                            } else if (data.type === 'result') {
                                searchResults.value.push(data.paper);
                            } else if (data.type === 'done') {
                                if (data.total === 0) {
                                    searchLogs.value.push({ type: 'info', message: '未找到匹配的论文' });
                                }
                            } else if (data.type === 'error') {
                                searchLogs.value.push({ type: 'error', message: data.message });
                            }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {
            searchLogs.value.push({ type: 'error', message: `搜索失败: ${e.message}` });
        } finally {
            searching.value = false;
        }
    }
    
    function scrollHomeLogsToBottom() {
        if (homeLogsContainer.value && !homeUserScrolledUp.value) {
            homeLogsContainer.value.scrollTop = homeLogsContainer.value.scrollHeight;
        }
    }
    
    function stopHomeSearch() {
        if (homeController.value) {
            homeController.value.abort();
            homeController.value = null;
        }
        homeSearching.value = false;
    }
    
    async function startHomeSearch(configStore) {
        if (!homeQuery.value.trim()) return;
        
        if (homeSearching.value) {
            const isZh = configStore?.currentLang === 'zh';
            ElementPlus.ElMessage.warning(isZh ? '前序搜索任务进行中...' : 'Previous search is in progress...');
            return;
        }
        
        homeSearching.value = true;
        homeLogs.value = [];
        homeResults.value = [];
        homeSelectedIds.value = [];
        homeUserScrolledUp.value = false;
        homeController.value = new AbortController();
        
        try {
            const params = new URLSearchParams({ q: homeQuery.value });
            const response = await API.papers.quick(params.toString(), homeController.value.signal);
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.type === 'log') {
                                homeLogs.value.push({ type: 'info', message: data.message });
                            } else if (data.type === 'result') {
                                homeResults.value.push(data.paper);
                            } else if (data.type === 'done') {
                                if (data.total === 0) {
                                    homeLogs.value.push({ type: 'info', message: configStore?.currentLang === 'zh' ? '未找到匹配的论文' : 'No matching papers found' });
                                }
                                homeLogs.value.push({ type: 'success', message: configStore?.currentLang === 'zh' ? '搜索完成' : 'Search completed' });
                            } else if (data.type === 'error') {
                                homeLogs.value.push({ type: 'error', message: data.message });
                            }
                        } catch (e) {}
                    }
                }
            }
        } catch (e) {
            if (e.name === 'AbortError') {
                homeLogs.value.push({ type: 'info', message: configStore?.currentLang === 'zh' ? '搜索已取消' : 'Search cancelled' });
            } else {
                homeLogs.value.push({ type: 'error', message: `搜索失败: ${e.message}` });
            }
        } finally {
            homeSearching.value = false;
            homeController.value = null;
        }
    }
    
    async function exportPapers(paperIds, format, configStore) {
        try {
            const res = await API.export.papers({
                paper_ids: paperIds,
                format: format,
                include_summary: true
            });
            if (!res.ok) throw new Error('Export failed');
            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const ext = format === 'markdown' ? 'md' : format === 'bibtex' ? 'bib' : format;
            a.download = `papers.${ext}`;
            a.click();
            window.URL.revokeObjectURL(url);
            ElementPlus.ElMessage.success(`已导出 ${paperIds.length} 篇论文`);
        } catch (e) {
            ElementPlus.ElMessage.error('导出失败');
        }
    }
    
    function updatePaperCollectionIds(paperIds, collectionId, add = true) {
        const idSet = new Set(paperIds);
        const updateArray = (arr) => {
            arr.forEach(paper => {
                if (idSet.has(paper.id)) {
                    if (!paper.collection_ids) paper.collection_ids = [];
                    if (add && !paper.collection_ids.includes(collectionId)) {
                        paper.collection_ids.push(collectionId);
                    } else if (!add) {
                        paper.collection_ids = paper.collection_ids.filter(id => id !== collectionId);
                    }
                }
            });
        };
        updateArray(recentPapers.value);
        updateArray(searchResults.value);
        updateArray(homeResults.value);
        updateArray(paperCart.value);
    }
    
    return {
        recentPapers, loadingRecent, loadingProgress, loadingTotal, loadingController,
        updatingRecent, recentLogs, recentDays, recentNeedSync, recentSelectedIds,
        recentSearchQuery, recentSearching, recentUseAiSearch, recentOriginalPapers,
        homeQuery, homeSearching, homeLogs, homeResults, homeSelectedIds, homeController, homeLogsContainer, homeUserScrolledUp,
        searchQuery, searching, searchLogs, searchResults, searchSelectedIds,
        paperCart, showCart, cartExportLoading, cartPosition, cartPanelRef, cartZIndex,
        stats, fieldStats,
        toggleRecentSelection, toggleAllRecent, toggleSearchSelection, toggleAllSearch,
        toggleHomeSelection, addToCart, removeFromCart, clearCart, isInCart, exportCart, copyCartLinks,
        fetchStats, fetchFieldStats, fetchRecentCache, updateRecentPapers,
        searchRecentPapers, resetRecentSearch,
        searchPapers, startHomeSearch, stopHomeSearch, exportPapers, updatePaperCollectionIds
    };
});
