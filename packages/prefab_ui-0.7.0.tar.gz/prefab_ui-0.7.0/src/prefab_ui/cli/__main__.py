"""Prefab CLI as a runnable package."""

from prefab_ui.cli.cli import app

app()
