from collections.abc import Iterable, Sequence
from Crypto.PublicKey.RSA import RsaKey
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field
from typing import Annotated, Generic, Self, TypeVar, overload
from uuid import UUID
from nexo.crypto.token import decode, encode
from nexo.enums.expiration import Expiration
from nexo.types.datetime import OptDatetime
from nexo.types.integer import DoubleInts
from nexo.types.misc import BytesOrStr
from nexo.types.string import OptStr


class Token(BaseModel):
    iss: Annotated[OptStr, Field(None, description="Issuer")] = None
    sub: Annotated[UUID, Field(..., description="Subject")]
    aud: Annotated[OptStr, Field(None, description="Audience")] = None
    exp: Annotated[int, Field(..., description="Expired at")]
    iat: Annotated[int, Field(..., description="Issued at")]

    @classmethod
    def new_timestamp(
        cls, iat_dt: OptDatetime = None, exp_in: Expiration = Expiration.EXP_15MN
    ) -> DoubleInts:
        if iat_dt is None:
            iat_dt = datetime.now(tz=timezone.utc)
        exp_dt = iat_dt + timedelta(seconds=exp_in.value)
        return int(iat_dt.timestamp()), int(exp_dt.timestamp())

    @classmethod
    def new(
        cls,
        *,
        iss: OptStr = None,
        sub: UUID,
        aud: OptStr = None,
        iat_dt: OptDatetime = None,
        exp_in: Expiration = Expiration.EXP_15MN,
    ) -> Self:
        iat, exp = cls.new_timestamp(iat_dt, exp_in)
        return cls(iss=iss, sub=sub, aud=aud, exp=exp, iat=iat)

    @classmethod
    def from_string(
        cls,
        token: str,
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> Self:
        obj = decode(
            token,
            key=key,
            audience=audience,
            subject=subject,
            issuer=issuer,
            leeway=leeway,
        )
        return cls.model_validate(obj)

    @overload
    def to_string(
        self,
        key: RsaKey,
    ) -> str: ...
    @overload
    def to_string(
        self,
        key: BytesOrStr,
        *,
        password: OptStr = None,
    ) -> str: ...
    @overload
    def to_string(
        self,
        key: BytesOrStr | RsaKey,
        *,
        password: OptStr = None,
    ) -> str: ...
    def to_string(
        self,
        key: BytesOrStr | RsaKey,
        *,
        password: OptStr = None,
    ) -> str:
        if isinstance(key, RsaKey):
            return encode(
                payload=self.model_dump(mode="json", exclude_none=True),
                key=key,
            )
        else:
            return encode(
                payload=self.model_dump(mode="json", exclude_none=True),
                key=key,
                password=password,
            )


TokenT = TypeVar("TokenT", bound=Token)
OptToken = Token | None
OptTokenT = TypeVar("OptTokenT", bound=OptToken)


class TokenMixin(BaseModel, Generic[OptTokenT]):
    token: OptTokenT = Field(..., description="Token")
