from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated, Generic, Sequence, TypeVar
from nexo.types.string import ListOfStrs


class Domain(StrEnum):
    PERSONAL = "personal"
    SYSTEM = "system"
    TENANT = "tenant"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


DomainT = TypeVar("DomainT", bound=Domain)
OptDomain = Domain | None
OptDomainT = TypeVar("OptDomainT", bound=OptDomain)


class DomainMixin(BaseModel, Generic[OptDomainT]):
    domain: Annotated[OptDomainT, Field(..., description="Domain")]


ListOfDomains = list[Domain]
ListOfDomainsT = TypeVar("ListOfDomainsT", bound=ListOfDomains)
OptListOfDomains = ListOfDomains | None
OptListOfDomainsT = TypeVar("OptListOfDomainsT", bound=OptListOfDomains)


class DomainsMixin(BaseModel, Generic[OptListOfDomainsT]):
    domains: Annotated[OptListOfDomainsT, Field(..., description="Domains")]


SeqOfDomains = Sequence[Domain]
SeqOfDomainsT = TypeVar("SeqOfDomainsT", bound=SeqOfDomains)
OptSeqOfDomains = SeqOfDomains | None
OptSeqOfDomainsT = TypeVar("OptSeqOfDomainsT", bound=OptSeqOfDomains)


class RolePrefix(StrEnum):
    MEDICAL = "medical"
    SYSTEM = "system"
    TENANT = "tenant"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]
