import ssl
import socket
import http.client
import httpx
from urllib.parse import urlparse
from typing import Optional, Any
from .doh_resolver import resolve_doh, is_supabase_domain

INITIAL_TIMEOUT = 10.0

DNS_FAILURE_INDICATORS = [
    "name or service not known",
    "nodename nor servname",
    "getaddrinfo failed",
    "name resolution",
    "connection refused",
    "timed out",
    "network is unreachable",
    "no address associated",
    "connect timeout",
    "connecttimeout",
]


def _is_dns_error(err: Exception) -> bool:
    msg = str(err).lower()
    return any(pat in msg for pat in DNS_FAILURE_INDICATORS)


def smart_fetch(
    url: str,
    method: str = "GET",
    headers: Optional[dict[str, str]] = None,
    body: Optional[bytes | str] = None,
    timeout: float = INITIAL_TIMEOUT,
    **kwargs: Any,
) -> httpx.Response:
    """fetch with automatic DoH fallback for Supabase domains."""
    try:
        return httpx.request(
            method, url, headers=headers, content=body,
            timeout=timeout, **kwargs,
        )
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, OSError) as err:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        if not is_supabase_domain(hostname) or not _is_dns_error(err):
            raise

    return _fetch_via_doh(url, method, headers, body, timeout)


def _fetch_via_doh(
    url: str,
    method: str,
    headers: Optional[dict[str, str]],
    body: Optional[bytes | str],
    timeout: float = INITIAL_TIMEOUT,
) -> httpx.Response:
    """Use stdlib http.client with manual socket for correct TLS SNI."""
    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    port = parsed.port or 443
    resolved_ip = resolve_doh(hostname)

    # Create TLS connection to the resolved IP with SNI set to original hostname
    ctx = ssl.create_default_context()
    raw_sock = socket.create_connection((resolved_ip, port), timeout=timeout)
    tls_sock = ctx.wrap_socket(raw_sock, server_hostname=hostname)

    conn = http.client.HTTPSConnection(
        hostname, port=port, context=ctx, timeout=timeout,
    )
    # Replace the socket with our pre-connected TLS socket
    conn.sock = tls_sock

    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    req_headers = dict(headers or {})
    req_headers.setdefault("Host", hostname)

    body_bytes: Optional[bytes] = None
    if body is not None:
        body_bytes = body.encode("utf-8") if isinstance(body, str) else body

    conn.request(method, path, body=body_bytes, headers=req_headers)
    resp = conn.getresponse()

    resp_body = resp.read()
    resp_headers = dict(resp.getheaders())

    conn.close()

    # Wrap in httpx.Response for API compatibility
    return httpx.Response(
        status_code=resp.status,
        headers=resp_headers,
        content=resp_body,
    )
