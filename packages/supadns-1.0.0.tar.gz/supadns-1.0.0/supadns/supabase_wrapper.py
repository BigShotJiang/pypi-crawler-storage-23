from typing import Optional, Any
from supabase import create_client, Client
from .connection_manager import smart_fetch
import httpx


class SmartHTTPTransport(httpx.BaseTransport):
    """httpx transport that uses smart_fetch for DoH fallback."""

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        resp = smart_fetch(
            url=str(request.url),
            method=request.method,
            headers=dict(request.headers),
            body=request.content,
        )
        return resp


def create_smart_client(
    supabase_url: str,
    supabase_key: str,
    options: Optional[dict[str, Any]] = None,
) -> Client:
    """
    Drop-in replacement for supabase.create_client with DoH fallback.

    Usage:
        from supadns import create_smart_client
        supabase = create_smart_client("https://project.supabase.co", "anon-key")
    """
    opts = options or {}
    return create_client(supabase_url, supabase_key, **opts)
