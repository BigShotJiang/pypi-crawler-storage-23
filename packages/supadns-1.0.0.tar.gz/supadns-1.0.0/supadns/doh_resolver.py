import struct
import time
import httpx
from typing import Optional

DOH_ENDPOINTS = [
    "https://dns.quad9.net/dns-query",
    "https://cloudflare-dns.com/dns-query",
]

DOH_TIMEOUT = 5.0
MIN_TTL_SECONDS = 30

_cache: dict[str, tuple[str, float]] = {}  # hostname -> (ip, expires_at)


def get_cached(hostname: str) -> Optional[str]:
    entry = _cache.get(hostname)
    if not entry:
        return None
    ip, expires_at = entry
    if time.time() > expires_at:
        del _cache[hostname]
        return None
    return ip


def set_cache(hostname: str, ip: str, ttl: int) -> None:
    effective_ttl = max(ttl, MIN_TTL_SECONDS)
    _cache[hostname] = (ip, time.time() + effective_ttl)


def clear_cache() -> None:
    _cache.clear()


def encode_dns_query(hostname: str) -> bytes:
    # Header: ID=1, RD=1, QDCOUNT=1
    header = struct.pack("!HHHHHH", 1, 0x0100, 1, 0, 0, 0)

    question = b""
    for label in hostname.split("."):
        question += struct.pack("!B", len(label)) + label.encode("ascii")
    question += b"\x00"           # root
    question += struct.pack("!HH", 1, 1)  # QTYPE=A, QCLASS=IN

    return header + question


def decode_dns_response(data: bytes) -> Optional[tuple[str, int]]:
    """Returns (ip, ttl) or None."""
    offset = 12  # skip header

    qdcount = struct.unpack("!H", data[4:6])[0]
    for _ in range(qdcount):
        while data[offset] != 0:
            if (data[offset] & 0xC0) == 0xC0:
                offset += 2
                break
            offset += data[offset] + 1
        else:
            offset += 1
        offset += 4  # QTYPE + QCLASS

    ancount = struct.unpack("!H", data[6:8])[0]
    for _ in range(ancount):
        if (data[offset] & 0xC0) == 0xC0:
            offset += 2
        else:
            while data[offset] != 0:
                offset += data[offset] + 1
            offset += 1

        rtype, rclass, ttl, rdlength = struct.unpack("!HHIH", data[offset:offset + 10])
        offset += 10

        if rtype == 1 and rdlength == 4:
            ip = ".".join(str(b) for b in data[offset:offset + 4])
            return ip, ttl

        offset += rdlength

    return None


def resolve_doh(hostname: str) -> str:
    """Resolve hostname to IPv4 via DoH. Quad9 first, Cloudflare fallback."""
    cached = get_cached(hostname)
    if cached:
        return cached

    query = encode_dns_query(hostname)
    errors: list[str] = []

    for endpoint in DOH_ENDPOINTS:
        try:
            resp = httpx.post(
                endpoint,
                content=query,
                headers={
                    "Content-Type": "application/dns-message",
                    "Accept": "application/dns-message",
                },
                timeout=DOH_TIMEOUT,
            )
            resp.raise_for_status()

            result = decode_dns_response(resp.content)
            if not result:
                raise ValueError(f"No A record from {endpoint}")

            ip, ttl = result
            set_cache(hostname, ip, ttl)
            return ip

        except Exception as e:
            errors.append(str(e))

    raise RuntimeError(
        f"All DoH endpoints failed for {hostname}: {'; '.join(errors)}"
    )


def is_supabase_domain(hostname: str) -> bool:
    return hostname.endswith(".supabase.co") or hostname == "supabase.co"
