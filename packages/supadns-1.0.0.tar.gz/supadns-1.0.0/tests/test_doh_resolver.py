import pytest
from supadns.doh_resolver import (
    encode_dns_query,
    decode_dns_response,
    get_cached,
    set_cache,
    clear_cache,
    is_supabase_domain,
)
import struct
import time


class TestEncodeDnsQuery:
    def test_basic_encoding(self):
        result = encode_dns_query("example.com")
        assert len(result) > 12
        # Check header: ID=1, flags=0x0100, QDCOUNT=1
        assert struct.unpack("!H", result[0:2])[0] == 1
        assert struct.unpack("!H", result[2:4])[0] == 0x0100
        assert struct.unpack("!H", result[4:6])[0] == 1

    def test_multi_label(self):
        result = encode_dns_query("my.project.supabase.co")
        assert len(result) > 12


class TestDecodeDnsResponse:
    def test_no_answers(self):
        buf = bytearray([
            0x00, 0x01, 0x81, 0x80,
            0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        ])
        # question: example.com A IN
        buf += b"\x07example\x03com\x00\x00\x01\x00\x01"
        assert decode_dns_response(bytes(buf)) is None

    def test_valid_a_record(self):
        buf = bytearray([
            0x00, 0x01, 0x81, 0x80,
            0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
        ])
        buf += b"\x07example\x03com\x00\x00\x01\x00\x01"
        # answer: pointer, A, IN, TTL=300, 93.184.216.34
        buf += bytes([
            0xC0, 0x0C,
            0x00, 0x01, 0x00, 0x01,
            0x00, 0x00, 0x01, 0x2C,
            0x00, 0x04,
            93, 184, 216, 34,
        ])
        result = decode_dns_response(bytes(buf))
        assert result is not None
        assert result[0] == "93.184.216.34"
        assert result[1] == 300


class TestCache:
    def setup_method(self):
        clear_cache()

    def test_uncached(self):
        assert get_cached("unknown.supabase.co") is None

    def test_set_and_get(self):
        set_cache("test.supabase.co", "1.2.3.4", 600)
        assert get_cached("test.supabase.co") == "1.2.3.4"

    def test_min_ttl(self):
        set_cache("test.supabase.co", "1.2.3.4", 1)
        assert get_cached("test.supabase.co") == "1.2.3.4"


class TestIsSupabaseDomain:
    def test_matches(self):
        assert is_supabase_domain("myproject.supabase.co") is True
        assert is_supabase_domain("supabase.co") is True

    def test_no_match(self):
        assert is_supabase_domain("google.com") is False
        assert is_supabase_domain("supabase.com") is False
        assert is_supabase_domain("notsupabase.co") is False
