# SupaDNS (Python)

**Bypass blocked DNS for Supabase using DNS-over-HTTPS (DoH).**

If your ISP blocks `*.supabase.co` via DNS poisoning, standard Supabase libraries will fail with connection errors. `supadns` provides a drop-in replacement that detects these failures and transparently routes the connection through DNS-over-HTTPS (Quad9 and Cloudflare) while preserving strict TLS SNI validation.

## Install

```bash
pip install supadns
```

## Quick Start (with `supabase-py`)

SupaDNS provides a `create_smart_client` that acts exactly like the standard `create_client`, but it injects a custom `httpx` transport.

```python
from supadns import create_smart_client

# This is a standard supabase.Client instance
supabase = create_smart_client(
    "https://myproject.supabase.co",
    "your-anon-key",
)

# All APIs work transparently: Auth, REST, Storage, Functions
data = supabase.table("todos").select("*").execute()
print(data)
```

## Using with standard `httpx`

If you are just making raw HTTP requests to Supabase, you can use the `smart_fetch` wrapper:

```python
from supadns import smart_fetch

headers = {"apikey": "your-anon-key", "Authorization": "Bearer your-anon-key"}
resp = smart_fetch(
    "https://myproject.supabase.co/rest/v1/todos?select=*",
    headers=headers
)
print(resp.json())
```

## Standalone DoH Resolution

If you just need to bypass DNS and get the IPv4 address:

```python
from supadns import resolve_doh

ip = resolve_doh("myproject.supabase.co")
# → "104.18.x.x"
```

## How It Works

1. **System DNS First**: Always tries standard DNS resolution first. If it works, overhead is ~0ms.
2. **Failure Detection**: Catches `httpx.ConnectError` and `socket.gaierror` specifically for `*.supabase.co` domains.
3. **DoH Fallback**: Resolves the IPv4 address via `https://dns.quad9.net/dns-query` (RFC 1035 wire-format).
4. **TLS SNI**: Connects a raw TCP socket to the resolved IP, then upgrades it to TLS using `ssl.create_default_context().wrap_socket(server_hostname=original_host)`. This ensures Cloudflare's strict edge SSL terminates correctly.

## Requirements

- Python ≥ 3.9
- `httpx`
- `supabase-py` (if using the Supabase client wrapper)

## License
MIT
