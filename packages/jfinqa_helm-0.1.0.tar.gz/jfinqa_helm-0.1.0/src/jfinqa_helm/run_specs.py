"""Run spec for JFinQA HELM plugin."""

from helm.benchmark.adaptation.common_adapter_specs import get_generation_adapter_spec
from helm.benchmark.metrics.common_metric_specs import get_basic_metric_specs
from helm.benchmark.run_spec import RunSpec, run_spec_function
from helm.benchmark.scenarios.scenario import ScenarioSpec


@run_spec_function("jfinqa")
def get_jfinqa_spec() -> RunSpec:
    scenario_spec = ScenarioSpec(
        class_name="jfinqa_helm.scenario.JFinQAScenario", args={}
    )
    adapter_spec = get_generation_adapter_spec(
        instructions=(
            "以下の財務データを読み、質問に正確な数値で答えてください。\n"
            "Read the following financial data and answer the question with the exact numeric value.\n"
        ),
        input_noun=None,
        output_noun="Answer",
        max_tokens=50,
    )
    metric_specs = get_basic_metric_specs([])
    return RunSpec(
        name="jfinqa",
        scenario_spec=scenario_spec,
        adapter_spec=adapter_spec,
        metric_specs=metric_specs,
        groups=["jfinqa"],
    )
