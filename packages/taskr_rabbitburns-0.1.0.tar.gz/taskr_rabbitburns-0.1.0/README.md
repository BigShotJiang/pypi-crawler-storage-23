# taskr

A simple task manager CLI with built-in telemetry.

## Install

```
pip install taskr
```

## Usage

```
taskr add "Buy milk"          # add a task
taskr list                    # list all tasks
taskr list --pending          # only incomplete tasks
taskr list --done             # only completed tasks
taskr done 1                  # mark task #1 complete
taskr delete 1                # delete task #1
taskr stats                   # show usage metrics + latency histograms
taskr log                     # show recent telemetry log
taskr log --last 50           # show last 50 entries
taskr log --command add       # filter by command
taskr log --outcome not_found # filter by outcome
```

## Data

All data is stored in `~/.taskr/`:
- `tasks.db` — SQLite task database
- `metrics.json` — per-command duration stats
- `taskr.log` — structured NDJSON event log
