from .version import __version__
name = "MeiTingTrunk(梅亭箱)"
