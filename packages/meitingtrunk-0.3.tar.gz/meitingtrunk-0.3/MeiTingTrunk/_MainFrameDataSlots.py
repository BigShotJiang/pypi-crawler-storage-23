'''
Handles data updating, including updates of the in-memory data dictionary from
editings in  the meta data tabs and from DOI querying; adding docs to folders,
and saving the in-memory data to sqlite database.


MeiTing Trunk
An open source reference management tool developed in PyQt5 and Python3.

Copyright 2018-2026 Guang-zhi XU

This file is distributed under the terms of the
GPLv3 licence. See the LICENSE file for details.
You may use, distribute and modify this code under the
terms of the GPLv3 license.
'''

from datetime import datetime
import os
from PyQt5.QtCore import Qt, pyqtSlot
from PyQt5.QtGui import QBrush
from PyQt5 import QtWidgets
from .lib import sqlitedb
from .lib import widgets
from .lib import tools
from .lib import bibparse
from .lib import risparse
from .lib.widgets.zim_dialog import saveToZimNote


class MainFrameDataSlots:

    def threadedFuncCall2(self, func, joblist, show_message='', max_threads=4,
                          get_results=False, close_on_finish=True, progressbar_style='classic'):
        '''Call function in another thread.
        See threadrun_dialog.py for more details
        NOT in use any more.
        '''

        thread_run_dialog = widgets.ThreadRunDialog(func, joblist,
                                                    show_message, max_threads, get_results, close_on_finish,
                                                    progressbar_style, parent=self)
        thread_run_dialog.exec_()
        if get_results:
            return thread_run_dialog.results
        else:
            return

    #######################################################################
    #                      Meta data update functions                      #
    #######################################################################

    def updateTableData(self, docid, meta_dict, field_list=None):
        """Update the in-memory dictionary self.meta_dict

        Args:
            docid (int): id of doc to update.
            meta_dict (DocMeta dict): dict containing the updated meta data for
                                      doc with id = <docid>.
        Kwargs:
            field_list (None or list): if list of str, giving the keys in
                                       <meta_dict> that needs update.
                                       if None, adding a new doc (<docid> not in
                                       self.meta_dict).

        Returns:
            docid (int): id assigned to added doc. If <docid> was None, this
                         gives the id assigned to it. Otherwise it return
                         <docid>.
        """

        if docid is None:

            if len(self.meta_dict) == 0:
                docid = 1
            else:
                docid = max(self.meta_dict.keys())+1

            self.logger.info('Add new doc. Given id=%s' % docid)

            # update folder_data
            foldername, folderid = self._current_folder
            if folderid not in ['-1', '-2', '-3']:
                self.folder_data[folderid].append(docid)

                if (folderid, foldername) not in meta_dict['folders_l']:
                    meta_dict['folders_l'].append((folderid, foldername))
                    self.logger.debug('Add new doc to folder %s. meta_dict["folders_l"]=%s'
                                      % (foldername, meta_dict['folders_l']))

            # update meta_dict
            self.meta_dict[docid] = meta_dict
            meta_dict['id'] = docid
            # add to needs review folder
            self.folder_data['-2'].append(docid)
            # scroll to and select row in doc table
            self.doc_table.scrollToBottom()
            self.loadDocTable(docids=self._current_docids+[docid,],
                              sel_row=None, sortidx=False)

            # use sortidx=False to signal don't do sorting. This is
            # for adding new docs to the folder and I want the new docs to
            # appear at the end, so scrolling to and selecting them is easier,
            # and makes sense.

            # xx=self.doc_table.model().rowCount(None)
            # NOTE that the below method may not work when table was empty before
            # adding, as I connected doc_table.currentChanged to selDoc.
            # When table was empty, the index for previous current isnt defined
            # UPDATE: never mind the above.
            self.doc_table.selectRow(self.doc_table.model().rowCount(None)-1)

        else:
            if docid in self.meta_dict:
                self.logger.info('Updating existing doc. docid=%s' % docid)

                for kk in field_list:
                    if kk == 'authors_l':
                        self.meta_dict[docid]['firstNames_l'] = meta_dict['firstNames_l']
                        self.meta_dict[docid]['lastName_l'] = meta_dict['lastName_l']
                    else:
                        self.meta_dict[docid][kk] = meta_dict[kk]
            else:
                self.logger.debug('wtf?')

                self.meta_dict[docid] = meta_dict

            # reload doc table
            self.loadDocTable(docids=self._current_docids,
                              sel_row=self.doc_table.currentIndex().row(),
                              sortidx=False)

        self.changed_doc_ids.append(docid)

        return docid

    @pyqtSlot(sqlitedb.DocMeta)
    def updateByDOI(self, meta_dict):
        """update in-memory dictionary self.meta_dict via doi query

        args:
            meta_dict (docmeta dict): new dict containing meta data from doi
                                      query.
        """

        docid = self._current_doc
        self.logger.info('Update doc %s by doi' % docid)

        if docid:
            self.meta_dict[docid] = meta_dict
            self.changed_doc_ids.append(docid)
            self.loadDocTable(docids=self._current_docids,
                              sortidx=False,
                              sel_row=self.doc_table.currentIndex().row())

        return

    @pyqtSlot(bool)
    def updateNotes(self, docid, note_text, save_to_zim):
        """update notes in the in-memory dictionary

        Args:
            docid (int): id of doc to update.
            note_text (str): new note texts.
            save_to_zim (bool): if True and use_zim_default==True, save note
                                to associated zim file.
        """

        if docid is None:
            return

        self.meta_dict[docid]['notes'] = note_text
        self.changed_doc_ids.append(docid)
        self.logger.info('New notes for docid=%s: %s' % (docid, note_text))

        use_zim_default = self.settings.value(
            'saving/use_zim_default', type=bool)

        #######################################################################
        #                       Disable use_zim_default                       #
        use_zim_default = False
        #######################################################################

        if use_zim_default and save_to_zim:
            self.logger.debug('Call saveToZimNote on update of doc %s' % docid)
            saveToZimNote(self._zim_folder, self.meta_dict, self._current_doc,
                          overwrite=True)

        return

    @pyqtSlot(int, str)
    def addDocToFolder(self, docid, folderid):
        """Add a doc to a folder

        Args:
            docid (int): id of doc.
            folderid (str): id of folder to accept doc.
        """

        self.logger.info('docid=%s, folderid=%s' % (docid, folderid))

        # ----------Add folder to doc's folders_l----------
        docfolders = self.meta_dict[docid]['folders_l']
        # note folderid here is an int
        newfolder = (int(folderid), self.folder_dict[folderid][0])
        if newfolder not in docfolders:
            docfolders.append(newfolder)
            self.meta_dict[docid]['folders_l'] = docfolders

        # -------------Add docid to folder_data-------------
        if docid not in self.folder_data[folderid]:
            self.folder_data[folderid].append(docid)

        self.logger.debug('Updated meta_dict["folders_l"] = %s'
                          % self.meta_dict[docid]['folders_l'])
        self.logger.debug('Updated folder_data = %s' %
                          self.folder_data[folderid])

        # -------------Restoring a trashed doc-------------
        current_folderid = self._current_folder[1]
        trashed_folders = self._trashed_folder_ids+['-3']
        if current_folderid in trashed_folders and folderid not in trashed_folders:
            self.logger.info('Restoring a trashed doc.')
            self.logger.debug('Updated deletionPending = %s'
                              % self.meta_dict[docid]['deletionPending'])
            self.meta_dict[docid]['deletionPending'] == 'false'

            # remove doc from current folder when restoring
            if docid in self.folder_data[current_folderid]:
                self.folder_data[current_folderid].remove(docid)
                self.loadDocTable(folder=self._current_folder,
                                  sel_row=None, sortidx=None)

        # add highlight to folder
        hi_color = self.settings.value('display/folder/highlight_color_br',
                                       QBrush)

        mii = self.libtree.findItems(folderid, Qt.MatchExactly | Qt.MatchRecursive,
                                     column=1)
        if len(mii) > 0:
            for mjj in mii:
                mjj.setBackground(0, hi_color)

        self.changed_doc_ids.append(docid)

        return

    @pyqtSlot()
    def saveToDatabase(self):
        """Save in-memory data to sqlite file

        self.changed_folder_ids contains ids of folder to update.
        self.changed_doc_ids contains ids of docs to update.
        Clear these two after saving.
        """

        mtime = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.logger.info('Save called. %s' % mtime)

        if len(self.changed_folder_ids) == 0 and len(self.changed_doc_ids) == 0:
            return

        # remove duplicates
        self.changed_folder_ids = list(set(self.changed_folder_ids))
        self.changed_doc_ids = list(set(self.changed_doc_ids))

        self.logger.debug('Folders to save: %s' % self.changed_folder_ids)
        self.logger.debug('Docs to save: %s' % self.changed_doc_ids)

        self.status_bar.setVisible(True)
        self.status_bar.showMessage('Saving. Please standby ...')
        # progressbar doesn't work in the main thread?
        self.progressbar.setVisible(True)
        self.progressbar.setMaximum(0)
        QtWidgets.QApplication.processEvents()

        # ----------------Save folders first----------------
        if len(self.changed_folder_ids) > 0:

            sqlitedb.saveFoldersToDatabase(self.db,
                                           self.changed_folder_ids, self.folder_dict,
                                           self.settings.value('saving/current_lib_folder'))

            self.changed_folder_ids = []
            self.logger.info('Folder changes saved to database.')

        # --------------------Save docs--------------------
        any_reload_doc = False
        for docid in self.changed_doc_ids:
            self.logger.info('Saving doc %s' % docid)
            rec, reload_doc = sqlitedb.metaDictToDatabase(self.db, docid,
                                                          self.meta_dict,
                                                          self.meta_dict.get(
                                                              docid),
                                                          self.settings.value(
                                                              'saving/current_lib_folder'),
                                                          self.settings.value(
                                                              'saving/rename_files', type=int),
                                                          self.settings.value(
                                                              'saving/file_move_manner', type=str)
                                                          )
            any_reload_doc = any_reload_doc or reload_doc

        self.changed_doc_ids = []
        self.settings.sync()
        self.status_bar.clearMessage()
        self.progressbar.setVisible(False)

        self.logger.info('Saving completed.')

        # current_folder=self._current_folder
        current_doc_ids = self._current_docids
        # if any_reload_doc and current_folder is not None:
        if any_reload_doc and current_doc_ids:
            current_row = self.doc_table.currentIndex().row()
            self.logger.debug(
                'Reloading doc table after save. current_row = %s' % (current_row))
            self.loadDocTable(docids=current_doc_ids, sortidx=False,
                              sel_row=current_row)

        return


    @pyqtSlot()
    def syncToBibRIS(self, bib_or_ris):
        '''Sync meta data to bibtex or RIS in background

        Args:
            bib_or_ris (str): 'bib' or 'ris'
        '''

        self.sig_status_message.emit(f'Syncing to {bib_or_ris}. Please standby ...')
        self.sig_progress_visible.emit(True)
        self.sig_progress_busy.emit()

        mtime = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.logger.info('Sync to bib called. %s' % mtime)

        # ---------------Get selected folders---------------
        folders = self.settings.value(f'sync/{bib_or_ris}/folders', type=list)

        if len(folders) == 0:
            self.sig_status_clear.emit()
            self.sig_progress_visible.emit(False)
            return

        # ------------Get saving location------------
        fname = self.settings.value(f'sync/{bib_or_ris}/target_loc')
        manner = self.settings.value(f'sync/{bib_or_ris}/manner')

        # ------------------Get path type------------------
        path_type = self.settings.value(f'sync/{bib_or_ris}/path_type')
        if path_type == 'Absolute':
            prefix = self.settings.value('saving/current_lib_folder', str)
        elif path_type == 'Relative':
            prefix = ''

        #------------------Get omit keys------------------
        if bib_or_ris == 'bib':
            omit_keys = self.settings.value(f'sync/{bib_or_ris}/omit_fields')
        else:
            omit_keys = None

        self.logger.info('Selected folders = %s' % folders)
        self.logger.info('Saving manner = %s' % manner)
        self.logger.info('Chosen bib file = %s' % fname)
        self.logger.info('path_prefix = %s' % prefix)
        self.logger.debug('omit keys = %s' % omit_keys)

        # -----------------Prepare job list-----------------
        folder_data = self.folder_data
        meta_dict = self.meta_dict

        job_list, citationkeys = tools.createBibRISExportJobList(meta_dict,
                                                                 folders,
                                                                 folder_data,
                                                                 manner,
                                                                 omit_keys,
                                                                 prefix)

        self.logger.info(f'{len(job_list)=}')


        if bib_or_ris == 'bib':
            # convert metadata to bib format
            results = [bibparse.metaDictToBib(*jobii) for jobii in job_list]
            # save bib file
            self.saveBib(results, folders, manner, fname, folder_data, meta_dict, citationkeys)
        else:
            # convert metadata to RIS format
            results = [risparse.metaDictToRIS(*jobii) for jobii in job_list]
            self.saveRIS(results, folders, manner, fname, folder_data, meta_dict, citationkeys)

        self.sig_status_clear.emit()
        self.sig_progress_visible.emit(False)

        self.logger.info(f'Syncing to {bib_or_ris} completed.')

        return


    def saveBib(self, results, folders, manner, fname, folder_data, meta_dict,
                citationkeys):
        """Save exported bibtex text to files

        Args:
            results (list): return values of metaDictToBib().
            folders (list): list of folders in the format [(name, folderid), ].
            manner (str): saving manner, 'All in one': save all bib entries
                          in a single file.
                          'Per folder': group by folder.
                          'Per document': per doc.
            fname (str): if manner=='All in one', the abspath to the output
                         bib file. Otherwise, the abspath to folder to save
                         output bib files.
            folder_data (dict): documents in each folder. keys: folder id in str,
                                values: list of doc ids. To determine when
                                a folder gets all its docs exported.
            meta_dict (dict): meta data of all documents. keys: docid,
                              values: DocMeta dict.
            citationkeys (list): list of the citationkeys for each doc. Used
                                 as the file name in 'Per document' mode.

        NOTE: there is much duplicated code with export_dialog.saveBib().
        """
        dirname = os.path.dirname(fname)
        os.makedirs(dirname, exist_ok=True)

        faillist = []

        if manner == 'All in one':
            text = ''
            for recii, jobii, textii, docii in results:
                if recii == 0:
                    text = text+textii+'\n'
                elif recii == 1:
                    faillist.append(docii)

            with open(fname, 'w') as fout:
                fout.write(text)

            self.logger.info('Saved combined outputs to file %s' % fname)

        elif manner == 'Per document':
            for recii, jobii, textii, docii in results:
                if recii == 0:
                    citationkey = citationkeys[jobii]
                    fnameii = '%s.bib' % citationkey
                    fnameii = os.path.join(fname, fnameii)
                    #fnameii = tools.autoRename(fnameii)

                    dirname = os.path.dirname(fnameii)
                    os.makedirs(dirname, exist_ok=True)

                    with open(fnameii, 'w') as fout:
                        fout.write(textii)

                    self.logger.info('Saved per doc output to file %s' % fnameii)

                elif recii == 1:
                    faillist.append(docii)

        elif manner == 'Per folder':

            # -------------Prepare result counting-------------
            folder_counts = {}
            folder_results = {}
            for foldernameii, fidii in folders:
                folder_results[fidii] = []
                folder_counts[fidii] = 0

            for recii, jobii, textii, docii in results:
                if recii == 1:
                    faillist.append(docii)

                for fnamejj, fidjj in folders:
                    if docii in folder_data[fidjj]:
                        folder_counts[fidjj] += 1
                        if recii == 0:
                            folder_results[fidjj].append(textii)

                        if folder_counts[fidjj] == len(folder_data[fidjj]):
                            self.logger.debug(
                                'folder %s got all data. Save.' % fnamejj)

                            fnamejj = os.path.join(fname, '%s.bib' % fnamejj)
                            text = '\n'.join(folder_results[fidjj])

                            dirname = os.path.dirname(fnamejj)
                            os.makedirs(dirname, exist_ok=True)

                            with open(fnamejj, 'w') as fout:
                                fout.write(text)

                            self.logger.info(
                                'Saved per folder output to file %s' % fnamejj)

        # -----------------Show failed jobs-----------------
        if len(faillist) > 0:

            fail_entries = []
            for docii in faillist:
                metaii = meta_dict[docii]
                entryii = '* %s_%s_%s' % (', '.join(metaii['authors_l']),
                                          metaii['year'],
                                          metaii['title'])

                self.logger.warning('Failed export job: %s' % entryii)

                fail_entries.append(entryii)

        return


    def saveRIS(self, results, folders, manner, fname, folder_data, meta_dict,
                citationkeys):
        """Save exported RIS text to files

        Args:
            results (list): return values of metaDictToRiIS().
            folders (list): list of folders in the format [(name, folderid), ].
            manner (str): saving manner, 'All in one': save all RIS entries
                          in a single file.
                          'Per folder': group by folder.
                          'Per document': per doc.
            fname (str): if manner=='All in one', the abspath to the output
                         ris file. Otherwise, the abspath to folder to save
                         output ris files.
            folder_data (dict): documents in each folder. keys: folder id in str,
                                values: list of doc ids. To determine when
                                a folder gets all its docs exported.
            meta_dict (dict): meta data of all documents. keys: docid,
                              values: DocMeta dict.
            citationkeys (list): list of the citationkeys for each doc. Used
                                 as the file name in 'Per document' mode.

        NOTE: there is much duplicated code with export_dialog.saveRIS().
        """
        dirname = os.path.dirname(fname)
        os.makedirs(dirname, exist_ok=True)
        faillist = []

        if manner == 'All in one':
            text = ''
            for recii, jobii, textii, docii in results:
                if recii == 0:
                    text = text+textii
                elif recii == 1:
                    faillist.append(docii)

            with open(fname, 'w') as fout:
                fout.write(text)

            self.logger.info('Saved combined outputs to file %s' % fname)

        elif manner == 'Per document':
            for recii, jobii, textii, docii in results:
                if recii == 0:
                    citationkey = citationkeys[jobii]
                    fnameii = '%s.ris' % citationkey
                    fnameii = os.path.join(fname, fnameii)
                    #fnameii = tools.autoRename(fnameii)
                    dirname = os.path.dirname(fnameii)
                    os.makedirs(dirname, exist_ok=True)

                    with open(fnameii, 'w') as fout:
                        fout.write(textii)

                    self.logger.info('Saved per doc output to file %s' % fnameii)

                elif recii == 1:
                    faillist.append(docii)

        elif manner == 'Per folder':

            # -------------Prepare result counting-------------
            folder_counts = {}
            folder_results = {}
            for foldernameii, fidii in folders:
                folder_results[fidii] = []
                folder_counts[fidii] = 0

            for recii, jobii, textii, docii in results:
                if recii == 1:
                    faillist.append(docii)

                for fnamejj, fidjj in folders:
                    if docii in folder_data[fidjj]:
                        folder_counts[fidjj] += 1
                        if recii == 0:
                            folder_results[fidjj].append(textii)

                        # save if folder got all its doc processed, even if failed
                        if folder_counts[fidjj] == len(folder_data[fidjj]):

                            fnamejj = os.path.join(fname, '%s.ris' % fnamejj)
                            text = '\n'.join(folder_results[fidjj])

                            dirname = os.path.dirname(fnamejj)
                            os.makedirs(dirname, exist_ok=True)

                            with open(fnamejj, 'w') as fout:
                                fout.write(text)

                            self.logger.info('Folder %s got all data. Saved.'
                                        % fnamejj)

        # -----------------Show failed jobs-----------------
        if len(faillist) > 0:
            fail_entries = []
            for docii in faillist:
                metaii = meta_dict[docii]
                entryii = '* %s_%s_%s' % (', '.join(metaii['authors_l']),
                                          metaii['year'],
                                          metaii['title'])
                fail_entries.append(entryii)

                self.logger.warning('Failed export job %s' % entryii)

        return


    @pyqtSlot()
    def createFailFolder(self, show_text, docids):
        """Show in the doc table docs in a failed task

        Args:
            show_text (str): info texts to show in the label describing the task.
            docids (list): list of doc ids (int) to load in the doc table.

        NOTE: this is a misnomer, no folder is created. rename later
        """

        self.clear_filter_label.setText('Failed tasks in %s' % show_text)
        self.clear_filter_frame.setVisible(True)
        self.loadDocTable(docids=docids)

        return

    @pyqtSlot(sqlitedb.DocMeta)
    def addDocFromDuplicateMerge(self, meta_dict):

        docid = max(self.meta_dict.keys())+1
        self.logger.info('Add new doc. Given id=%s' % docid)

        # update folder_data
        folders = meta_dict['folders_l']
        for folderid, foldername in folders:
            self.folder_data[folderid].append(docid)

        # add to needs review folder
        self.folder_data['-2'].append(docid)

        # update meta_dict
        self.meta_dict[docid] = meta_dict

        self.changed_doc_ids.append(docid)

        msg = QtWidgets.QMessageBox()
        msg.resize(600, 500)
        msg.setIcon(QtWidgets.QMessageBox.Information)
        msg.setWindowTitle('Merge completed')
        msg.setText('                New document created.                  ')
        msg.setInformativeText('''
        New document has been created from duplicate merge, <br/>
        and added to folder(s): <br/>
        <br/>
            <span style="font: bold;"> %s </span>
        ''' % (', '.join([fii[1] for fii in folders])))
        msg.exec_()

        return
