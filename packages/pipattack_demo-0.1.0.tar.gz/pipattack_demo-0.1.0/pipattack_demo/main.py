import ctypes
import pyautogui

def main_function():
    # Your pyautogui logic here (mouse movement, etc.)
    print("PoC Running...")

    # Native Windows Alert (No Tkinter required!)
    # 0x40 = Information Icon, 0x1 = OK/Cancel buttons
    ctypes.windll.user32.MessageBoxW(0, "Security Audit: PoC Active", "System Notice", 0x40)

if __name__ == "__main__":
    main_function()
