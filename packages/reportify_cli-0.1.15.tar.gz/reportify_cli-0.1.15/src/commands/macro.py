"""Macro module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Macro economic data", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.MACRO_COMMODITIES_PARAMS,
        [
            'reportify-cli macro commodities --input \'{"type": "oil", "start_date": "2026-02-01", "end_date": "2026-02-09"}\'',
            'reportify-cli macro commodities --input \'{"type": "gold", "start_date": "2026-02-01", "end_date": "2026-02-09"}\'',
        ],
    )
)
def commodities(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get commodity prices: oil, gold, gas, silver, platinum"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.macro.commodities(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
