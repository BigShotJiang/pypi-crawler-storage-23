---
name: reportify-ai
description: Access Reportify financial data API via command line. Search documents, get stock data, financial statements, market quotes, quantitative analysis, manage follow groups, and more. Use when the user needs to query financial information, stock data, company reports, perform quantitative analysis, or manage follow groups on China A-shares, Hong Kong, or US markets.
metadata:
  author: reportify-ai
  version: "1.0"
---

# Reportify AI

A command-line tool for accessing Reportify SDK's financial data capabilities.

## When to use this skill

Use this skill when the user needs to:
- Search financial documents (news, reports, filings, transcripts)
- Get stock market data (quotes, prices, financial statements)
- Query company information and shareholder data
- Perform quantitative analysis (indicators, factors, backtesting)
- Access knowledge base search
- Get market timelines and concept dynamics
- Chat with AI agents for analysis and workflows
- Manage follow groups (create, update, delete, and retrieve documents from follow groups)

## Command Structure

```bash
reportify-cli <module> <command> --input '<json_params>' [--format <output_format>]
```

### Output Formats
- `json` (default) - JSON format
- `table` - Table format
- `csv` - CSV format
- `markdown` or `md` - Markdown table

## Best Practice: Save Large Results to File

When fetching data with potentially large results (e.g., historical prices, batch data, screening results), **always redirect output to a file first**, then read a small portion to verify:

```bash
# Save large dataset to file
reportify-cli stock prices --input '{"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-12-31"}' --format json > AAPL_prices_2025.json

# Then read first few lines to verify
head -50 AAPL_prices_2025.json

# Or for CSV format
reportify-cli quant ohlcv_batch --input '{"symbols": ["600519", "000858", "002304"]}' --format csv > cn_stocks_ohlcv.csv
head -20 cn_stocks_ohlcv.csv
```

This approach:
- Prevents terminal overflow with large datasets
- Preserves complete data for further analysis
- Allows incremental inspection of results

## Available Modules

| Module | Description | Commands |
|--------|-------------|----------|
| `search` | Document search | 9 commands |
| `docs` | Document management | 13 commands |
| `stock` | Stock data | 13 commands |
| `timeline` | Market timelines | 5 commands |
| `channels` | Channel management | 5 commands |
| `kb` | Knowledge base | 1 command |
| `user` | User data | 3 commands |
| `quant` | Quantitative analysis | 12 commands |
| `macro` | Macro economic data | 1 command |
| `concepts` | Concept dynamics | 2 commands |
| `agent` | Agent conversations | 7 commands |
| `following` | Follow group management | 9 commands |

## Common Usage Examples

### Search Documents
```bash
# Search all document types
reportify-cli search query --input '{"query": "Tesla", "num": 10}'

# Search news only
reportify-cli search news --input '{"query": "AI chip", "num": 5}'

# Search reports with filters
reportify-cli search reports --input '{"query": "liquor", "symbols": ["SH:600519"]}'
```

### Get Stock Data
```bash
# Get company overview
reportify-cli stock overview --input '{"symbols": "AAPL,00700"}'

# Get real-time quote
reportify-cli stock quote --input '{"symbol": "600519"}' --format table

# Get index quote
reportify-cli stock index_quote --input '{"symbol": "000300"}'
```

### Financial Statements
```bash
# Income statement
reportify-cli stock income_statement --input '{"symbol": "600519", "period": "annual"}'

# Balance sheet
reportify-cli stock balance_sheet --input '{"symbol": "00700", "period": "quarterly"}'

# Cash flow statement
reportify-cli stock cashflow_statement --input '{"symbol": "AAPL"}'
```

### Quantitative Analysis
```bash
# Compute technical indicators
reportify-cli quant indicators_compute --input '{"symbols": ["600519"], "formula": "RSI(14)"}'

# Stock screening
reportify-cli quant factors_screen --input '{"formula": "(PE_TTM() < 20) & (ROE() > 15)", "market": "cn"}'

# Get OHLCV data
reportify-cli quant ohlcv --input '{"symbol": "600519", "start_date": "2025-01-01", "end_date": "2025-12-31"}'

# Get 1-minute kline data
reportify-cli quant kline_1m --input '{"symbol": "600519", "start_datetime": "2025-01-01 09:30:00", "end_datetime": "2025-01-01 15:00:00"}'

# Batch 1-minute kline data (save to file)
reportify-cli quant kline_1m_batch --input '{"symbols": ["600519", "000858", "002304"], "start_datetime": "2025-01-01 09:30:00", "end_datetime": "2025-01-01 15:00:00"}' --format csv > kline_1m_20250101.csv

# Get minute data
reportify-cli quant minute --input '{"symbol": "600519", "start_datetime": "2025-01-01 09:30:00", "end_datetime": "2025-01-01 15:00:00"}'

# Batch minute data
reportify-cli quant minute_batch --input '{"symbols": ["600519", "000858"], "start_datetime": "2025-01-01 09:30:00", "end_datetime": "2025-01-01 15:00:00"}'

# Backtesting
reportify-cli quant backtest --input '{"symbol": "600519", "start_date": "2025-01-01", "end_date": "2025-12-31", "entry_formula": "CROSS(MA(CLOSE, 5), MA(CLOSE, 20))"}'
```

### Macro Economic Data
```bash
# Get crude oil prices
reportify-cli macro commodities --input '{"type": "oil", "start_date": "2026-02-01", "end_date": "2026-02-09"}'

# Get gold prices
reportify-cli macro commodities --input '{"type": "gold", "start_date": "2026-02-01", "end_date": "2026-02-09"}'
```

**Return fields by type:**
- **oil**: `wti_co_sp` (WTI, USD/barrel), `brent_co_sp` (Brent, USD/barrel)
- **gold**: `lbma_pm_usd` (London gold, USD/oz), `sge_pm_cny` (Shanghai gold, CNY)
- **gas**: `hh_ng_sp` (Henry Hub, USD/MMBtu)
- **silver**: `si_eur` (London silver, USD/oz)
- **platinum**: `pl_usd` (London platinum, USD/oz)

### Agent Conversations
```bash
# Create a conversation
reportify-cli agent create_conversation --input '{"agent_id": 11887655289749510}'

# Chat with agent
reportify-cli agent chat --input '{"conversation_id": 123456, "message": "Analyze NVIDIA"}'

# Chat with background mode (returns immediately)
reportify-cli agent chat --input '{"conversation_id": 123456, "message": "Run analysis", "background": true}'

# Get message events
reportify-cli agent get_message_events --input '{"conversation_id": 123456, "assistant_message_id": "msg_abc123"}'
```

### Follow Group Management
```bash
# Create a follow group
reportify-cli following create_follow_group --input '{"name": "My Stocks", "follow_values": [{"follow_type": 1, "follow_value": "US:AAPL"}]}'

# Get all follow groups
reportify-cli following get_follow_groups

# Get a specific follow group
reportify-cli following get_follow_group --input '{"group_id": "123"}'

# Update a follow group name
reportify-cli following update_follow_group --input '{"group_id": "123", "name": "Updated Name"}'

# Add follows to a group
reportify-cli following add_follows_to_group --input '{"group_id": "123", "follow_values": [{"follow_type": 1, "follow_value": "US:TSLA"}]}'

# Remove follows from a group
reportify-cli following remove_follows_from_group --input '{"group_id": "123", "follow_values": ["AAPL", "MSFT"]}'

# Set all follows for a group (replace)
reportify-cli following set_group_follows --input '{"group_id": "123", "follow_values": [{"follow_type": 1, "follow_value": "US:AAPL"}, {"follow_type": 1, "follow_value": "US:MSFT"}]}'

# Get documents from a follow group
reportify-cli following get_follow_group_docs --input '{"group_id": "123", "page_num": 1, "page_size": 20}'

# Delete a follow group
reportify-cli following delete_follow_group --input '{"group_id": "123"}'
```

## Getting Help

```bash
# List all modules
reportify-cli --help

# List commands in a module
reportify-cli stock --help

# Get command details with parameters
reportify-cli stock income_statement --help
```

## Symbol Format

- **China A-shares**: `SH:600519` or `600519`
- **Hong Kong**: `HK:00700` or `00700`
- **US stocks**: `US:AAPL` or `AAPL`

## Reference Documentation

For detailed parameter information, see:
- [API Reference](references/API_REFERENCE.md) - Complete API documentation
- [Module Commands](references/COMMANDS.md) - All available commands and parameters
