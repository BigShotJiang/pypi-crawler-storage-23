"""
Sinth — the CLI for AIM. Synthesize intent into reality.
"""

__version__ = "0.1.0"
__author__ = "Juice d.o.o"
__copyright__ = "Copyright (c) 2026 Juice d.o.o (https://juice.com.hr)"
__license__ = "MIT"
__description__ = "Sinth — the CLI for AIM. Synthesize intent into reality."
