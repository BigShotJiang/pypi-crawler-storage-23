"""Allow running aim_cli as a module: python -m aim_cli"""

from aim_cli.cli import main

if __name__ == '__main__':
    main()
