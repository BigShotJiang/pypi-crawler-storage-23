"""Strategy Simulator TUI Package"""
