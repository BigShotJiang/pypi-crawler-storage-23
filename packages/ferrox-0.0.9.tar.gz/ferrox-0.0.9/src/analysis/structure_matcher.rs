//! Structure matching algorithm.
//!
//! This module provides `StructureMatcher` for comparing crystal structures,
//! implementing the same algorithm as pymatgen's StructureMatcher.

use crate::element::Element;
use crate::error::OnError;
use crate::lattice::Lattice;
use crate::pbc::{is_coord_subset_pbc, pbc_shortest_vectors, wrap_frac_coords_pbc};
use crate::species::Species;
use crate::structure::Structure;
use itertools::Itertools;
use nalgebra::{Matrix3, Vector3};
use pathfinding::kuhn_munkres::kuhn_munkres_min;
use pathfinding::matrix::Matrix as PathMatrix;
use std::collections::{HashMap, HashSet};
use std::f64::consts::PI;

// Constants for structure distance calculation
/// Penalty (squared distance) added for each unmatched source site
const UNMATCHED_SOURCE_PENALTY: f64 = 10.0;
/// Penalty (squared distance) added for each unmatched target site
const UNMATCHED_TARGET_PENALTY: f64 = 5.0;
/// Weight applied to composition (Jaccard) distance in combined metric
const COMPOSITION_WEIGHT: f64 = 5.0;
/// Distance returned when structures have completely disjoint element sets
const DISJOINT_COMPOSITION_DISTANCE: f64 = 11.0;
/// Maximum finite distance returned when comparing empty vs non-empty structure
const EMPTY_STRUCTURE_DISTANCE: f64 = 1e9;
/// Minimum lattice volume to avoid division by zero in normalization
const MIN_LATTICE_VOLUME: f64 = 1e-12;
/// Highest atomic number supported by `Element::from_atomic_number()` (includes pseudo-elements).
const MAX_SUPPORTED_ATOMIC_NUMBER: u8 = 121;

/// Type of comparator to use for species matching.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ComparatorType {
    /// Exact species match (element + oxidation state).
    #[default]
    Species,
    /// Element-only matching (ignores oxidation state).
    Element,
}

/// Predefined element-to-class mappings for anonymous prototype matching.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AnonymousClassMapping {
    /// ACX mapping: A (anions), C (cations), X (halides).
    Acx,
    /// CEA mapping: C (alkali/alkaline), E (electropositive), A (anions).
    Cea,
    /// Metal vs non-metal mapping.
    MetalNonMetal,
}

/// Anonymous matching mode for `fit_anonymous`.
#[derive(Debug, Clone, Copy)]
pub enum AnonymousMatchMode<'a> {
    /// Original pymatgen-style anonymous matching via one-to-one element permutation.
    ElementPermutation,
    /// Class-based matching using one of the predefined mapping families.
    Predefined(AnonymousClassMapping),
    /// Class-based matching using a custom element -> class label mapping.
    Custom(&'a HashMap<Element, String>),
}

impl AnonymousClassMapping {
    /// Parse a mapping name from user input.
    ///
    /// Accepted values:
    /// - `ACX`
    /// - `CEA`
    /// - `Metal/Non-metal` (also `metal_nonmetal`, `metal_non_metal`)
    pub fn from_name(mapping_name: &str) -> Option<Self> {
        let normalized_name = mapping_name.trim().to_ascii_lowercase();
        match normalized_name.as_str() {
            "acx" => Some(Self::Acx),
            "cea" => Some(Self::Cea),
            "metal/non-metal" | "metal_nonmetal" | "metal_non_metal" => Some(Self::MetalNonMetal),
            _ => None,
        }
    }

    /// Return the class label for an element under this mapping.
    fn class_for_element(&self, element: Element) -> Option<&'static str> {
        match self {
            Self::Acx => match element {
                Element::Si
                | Element::Ge
                | Element::Sn
                | Element::Sb
                | Element::Bi
                | Element::S
                | Element::Se
                | Element::Te => Some("A"),
                Element::Al
                | Element::Ga
                | Element::In
                | Element::Sc
                | Element::Y
                | Element::Li
                | Element::Na
                | Element::K
                | Element::Rb
                | Element::Cs
                | Element::Mg
                | Element::Ca
                | Element::Sr
                | Element::Ba => Some("C"),
                Element::Cl | Element::Br | Element::I => Some("X"),
                _ => None,
            },
            Self::Cea => match element {
                Element::Si
                | Element::Ge
                | Element::Sn
                | Element::Sb
                | Element::Bi
                | Element::S
                | Element::Se
                | Element::Te => Some("A"),
                Element::Al | Element::Ga | Element::In | Element::Sc | Element::Y => Some("E"),
                Element::Li
                | Element::Na
                | Element::K
                | Element::Rb
                | Element::Cs
                | Element::Mg
                | Element::Ca
                | Element::Sr
                | Element::Ba => Some("C"),
                _ => None,
            },
            Self::MetalNonMetal => {
                if element.is_metal() {
                    Some("M")
                } else {
                    Some("X")
                }
            }
        }
    }
}

/// Configuration and state for structure matching.
#[derive(Debug, Clone)]
pub struct StructureMatcher {
    /// Fractional length tolerance for lattice vectors.
    pub latt_len_tol: f64,
    /// Site position tolerance (normalized).
    pub site_pos_tol: f64,
    /// Angle tolerance in degrees.
    pub angle_tol: f64,
    /// Whether to reduce to primitive cell first.
    pub primitive_cell: bool,
    /// Whether to scale volumes to match.
    pub scale: bool,
    /// Whether to attempt supercell matching.
    pub attempt_supercell: bool,
    /// The comparator type to use for species matching.
    pub comparator_type: ComparatorType,
    /// Error handling behavior.
    pub on_error: OnError,
}

impl Default for StructureMatcher {
    fn default() -> Self {
        Self {
            latt_len_tol: 0.2,
            site_pos_tol: 0.3,
            angle_tol: 5.0,
            // Match pymatgen's default: reduce to primitive cell before matching
            primitive_cell: true,
            scale: true,
            attempt_supercell: false,
            comparator_type: ComparatorType::Species,
            on_error: OnError::Skip,
        }
    }
}

impl StructureMatcher {
    /// Create a new StructureMatcher with default settings.
    pub fn new() -> Self {
        Self::default()
    }

    /// Builder method to set lattice length tolerance.
    pub fn with_latt_len_tol(mut self, latt_len_tol: f64) -> Self {
        self.latt_len_tol = latt_len_tol;
        self
    }

    /// Builder method to set site position tolerance.
    pub fn with_site_pos_tol(mut self, site_pos_tol: f64) -> Self {
        self.site_pos_tol = site_pos_tol;
        self
    }

    /// Builder method to set angle tolerance.
    pub fn with_angle_tol(mut self, angle_tol: f64) -> Self {
        self.angle_tol = angle_tol;
        self
    }

    /// Builder method to set primitive cell reduction.
    pub fn with_primitive_cell(mut self, primitive_cell: bool) -> Self {
        self.primitive_cell = primitive_cell;
        self
    }

    /// Builder method to set volume scaling.
    pub fn with_scale(mut self, scale: bool) -> Self {
        self.scale = scale;
        self
    }

    /// Builder method to set supercell matching.
    pub fn with_attempt_supercell(mut self, attempt_supercell: bool) -> Self {
        self.attempt_supercell = attempt_supercell;
        self
    }

    /// Builder method to set the comparator type.
    pub fn with_comparator(mut self, comparator_type: ComparatorType) -> Self {
        self.comparator_type = comparator_type;
        self
    }

    /// Builder method to set error handling.
    pub fn with_on_error(mut self, on_error: OnError) -> Self {
        self.on_error = on_error;
        self
    }

    /// Build a predefined element-to-class mapping.
    pub fn predefined_class_mapping(
        mapping_kind: AnonymousClassMapping,
    ) -> HashMap<Element, String> {
        let mut class_mapping = HashMap::new();
        for atomic_number in 1..=MAX_SUPPORTED_ATOMIC_NUMBER {
            if let Some(element) = Element::from_atomic_number(atomic_number)
                && let Some(class_label) = mapping_kind.class_for_element(element)
            {
                class_mapping.insert(element, class_label.to_string());
            }
        }
        class_mapping
    }

    /// Return elements present in the inputs that are not covered by a predefined mapping.
    pub fn missing_predefined_mapping_elements(
        struct1: &Structure,
        struct2: &Structure,
        mapping_kind: AnonymousClassMapping,
    ) -> Vec<Element> {
        let mut missing_elements = HashSet::new();
        for structure in [struct1, struct2] {
            for species in structure.species() {
                if mapping_kind.class_for_element(species.element).is_none() {
                    missing_elements.insert(species.element);
                }
            }
        }
        let mut sorted_missing: Vec<_> = missing_elements.into_iter().collect();
        sorted_missing.sort_unstable();
        sorted_missing
    }

    /// Check if two species are equal according to the comparator.
    fn species_equal(&self, sp1: &Species, sp2: &Species) -> bool {
        match self.comparator_type {
            ComparatorType::Species => sp1 == sp2,
            ComparatorType::Element => sp1.element == sp2.element,
        }
    }

    /// Get composition hash for prefiltering, aligned with comparator semantics.
    ///
    /// For `ComparatorType::Element`, oxidation states are ignored.
    /// For `ComparatorType::Species`, full species information is used.
    pub fn composition_hash(&self, structure: &Structure) -> u64 {
        match self.comparator_type {
            ComparatorType::Element => structure.composition().formula_hash(),
            ComparatorType::Species => structure.species_composition().species_hash(),
        }
    }

    fn compositions_equal(&self, struct1: &Structure, struct2: &Structure) -> bool {
        match self.comparator_type {
            ComparatorType::Element => {
                struct1.composition().reduced_composition()
                    == struct2.composition().reduced_composition()
            }
            ComparatorType::Species => {
                struct1.species_composition().reduced_composition()
                    == struct2.species_composition().reduced_composition()
            }
        }
    }

    /// Get reduced structure (Niggli reduced, optionally primitive).
    ///
    /// Matches pymatgen's `_get_reduced_structure` behavior:
    /// 1. Niggli reduction on the lattice
    /// 2. If `primitive_cell` is true, reduce to primitive cell via symmetry analysis
    ///
    /// Properties from the original structure are preserved.
    fn has_oxidation_states(structure: &Structure) -> bool {
        structure.site_occupancies.iter().any(|site_occ| {
            site_occ
                .species
                .iter()
                .any(|(species, _)| species.oxidation_state.is_some())
        })
    }

    fn should_skip_primitive_reduction(&self, structure: &Structure) -> bool {
        self.comparator_type == ComparatorType::Species && Self::has_oxidation_states(structure)
    }

    fn niggli_reduce_structure(structure: &Structure) -> Structure {
        let mut reduced_structure = structure.clone();
        // Do Niggli reduction on the lattice
        if let Ok(niggli_lattice) = reduced_structure.lattice.get_niggli_reduced(1e-5) {
            // Transform coordinates to new lattice
            let original_cart_coords = reduced_structure.cart_coords();
            let original_pbc = reduced_structure.lattice.pbc;
            reduced_structure.lattice = niggli_lattice;
            reduced_structure.lattice.pbc = original_pbc;
            reduced_structure.frac_coords = reduced_structure
                .lattice
                .get_fractional_coords(&original_cart_coords);
            // Wrap to [0, 1)
            for frac_coord in &mut reduced_structure.frac_coords {
                *frac_coord = wrap_frac_coords_pbc(frac_coord, reduced_structure.lattice.pbc);
            }
        }
        reduced_structure
    }

    fn try_get_reduced_structure(&self, structure: &Structure) -> crate::error::Result<Structure> {
        let mut result = Self::niggli_reduce_structure(structure);

        // Reduce to primitive cell if requested (skip empty structures)
        if self.primitive_cell
            && result.num_sites() > 0
            && !self.should_skip_primitive_reduction(&result)
        {
            let original_pbc = result.lattice.pbc;
            let mut prim = result.get_primitive(1e-4)?;
            // Preserve properties from original structure
            prim.properties = result.properties.clone();
            prim.lattice.pbc = original_pbc;
            result = prim;
        }

        Ok(result)
    }

    fn get_reduced_structure_with_on_error(
        &self,
        structure: &Structure,
        operation_name: &str,
    ) -> Structure {
        match self.try_get_reduced_structure(structure) {
            Ok(reduced_structure) => reduced_structure,
            Err(error) => {
                if self.on_error.should_fail() {
                    panic!(
                        "StructureMatcher::{operation_name} failed to reduce structure: {error}"
                    );
                }
                tracing::warn!(
                    operation_name,
                    error = %error,
                    "StructureMatcher skipping primitive reduction after error"
                );
                Self::niggli_reduce_structure(structure)
            }
        }
    }

    fn has_integer_supercell_ratio(site_count_a: usize, site_count_b: usize) -> bool {
        site_count_a > 0
            && site_count_b > 0
            && (site_count_a.is_multiple_of(site_count_b)
                || site_count_b.is_multiple_of(site_count_a))
    }

    pub(crate) fn reduce_structure_for_batch(
        &self,
        structure: &Structure,
    ) -> crate::error::Result<Structure> {
        self.try_get_reduced_structure(structure)
    }

    /// Preprocess structures for matching (reduces then prepares pair).
    ///
    /// Returns (struct1, struct2, supercell_factor, s1_supercell)
    fn preprocess(
        &self,
        struct1: &Structure,
        struct2: &Structure,
    ) -> (Structure, Structure, usize, bool) {
        let s1 = self.get_reduced_structure_with_on_error(struct1, "preprocess");
        let s2 = self.get_reduced_structure_with_on_error(struct2, "preprocess");
        self.preprocess_pair(s1, s2)
    }

    /// Prepare already-reduced structures for matching.
    ///
    /// Computes supercell factor and scales volumes. Use when structures have
    /// already been reduced via `reduce_structure`.
    ///
    /// Returns (struct1, struct2, supercell_factor, s1_supercell)
    fn preprocess_pair(
        &self,
        mut s1: Structure,
        mut s2: Structure,
    ) -> (Structure, Structure, usize, bool) {
        let (supercell_factor, s1_supercell) = if self.attempt_supercell {
            // Guard against division by zero
            if s1.num_sites() == 0 || s2.num_sites() == 0 {
                (1, true)
            } else if s2.num_sites() >= s1.num_sites() {
                if s2.num_sites().is_multiple_of(s1.num_sites()) {
                    (s2.num_sites() / s1.num_sites(), true)
                } else {
                    (1, true)
                }
            } else if s1.num_sites().is_multiple_of(s2.num_sites()) {
                (s1.num_sites() / s2.num_sites(), false)
            } else {
                (1, true)
            }
        } else {
            (1, true)
        };

        let mult = if s1_supercell {
            supercell_factor as f64
        } else {
            1.0 / supercell_factor as f64
        };

        // Scale lattices to same volume (skip if empty or degenerate to avoid division by zero)
        let v1 = s1.lattice.volume();
        let v2 = s2.lattice.volume();
        if self.scale && v1 > f64::EPSILON && v2 > f64::EPSILON {
            // PBC consistency check - prevents silent drift when scaling overwrites pbc
            debug_assert_eq!(
                s1.lattice.pbc, s2.lattice.pbc,
                "PBC mismatch in preprocess_pair"
            );
            let pbc = s1.lattice.pbc;
            let ratio = (v2 / (v1 * mult)).powf(1.0 / 6.0);
            s1.lattice = Lattice::new(*s1.lattice.matrix() * ratio);
            s1.lattice.pbc = pbc;
            s2.lattice = Lattice::new(*s2.lattice.matrix() / ratio);
            s2.lattice.pbc = pbc;
        }

        (s1, s2, supercell_factor, s1_supercell)
    }

    /// Create a mask for species matching.
    ///
    /// mask[i][j] = true means s2[i] cannot match s1[j]
    fn get_mask(&self, struct1: &Structure, struct2: &Structure) -> Vec<Vec<bool>> {
        let n1 = struct1.num_sites();
        let n2 = struct2.num_sites();
        let mut mask = vec![vec![false; n1]; n2];

        let species1 = struct1.species();
        let species2 = struct2.species();
        for (idx2, sp2) in species2.iter().enumerate() {
            for (idx1, sp1) in species1.iter().enumerate() {
                mask[idx2][idx1] = !self.species_equal(sp1, sp2);
            }
        }

        mask
    }

    /// Find translation indices for matching.
    fn get_translation_indices(&self, mask: &[Vec<bool>]) -> (Vec<usize>, usize) {
        if mask.is_empty() {
            return (vec![], 0);
        }

        // Find the row with the most masked (incompatible) entries
        // Note: mask is guaranteed non-empty (checked at line 230), so unwrap is safe
        let (best_row, _) = mask
            .iter()
            .enumerate()
            .max_by_key(|(_, row)| row.iter().filter(|&&x| x).count())
            .unwrap();

        // Find unmasked indices in struct1 for this row
        let s1_inds: Vec<usize> = mask[best_row]
            .iter()
            .enumerate()
            .filter(|&(_, &masked)| !masked)
            .map(|(idx, _)| idx)
            .collect();

        (s1_inds, best_row)
    }

    /// Get lattice mappings for matching.
    fn get_lattices(
        &self,
        target_lattice: &Lattice,
        source: &Structure,
        supercell_size: usize,
    ) -> Vec<(Lattice, Matrix3<i32>)> {
        source
            .lattice
            .find_all_mappings_with_determinant(
                target_lattice,
                self.latt_len_tol,
                self.angle_tol,
                true,
                supercell_size,
            )
            .into_iter()
            .map(|(latt, _, scale_m)| (latt, scale_m))
            .collect()
    }

    fn sorted_lattice_candidates(
        &self,
        target_lattice: &Lattice,
        source: &Structure,
        supercell_size: usize,
    ) -> Vec<(Lattice, Matrix3<i32>)> {
        let mut lattice_candidates = self.get_lattices(target_lattice, source, supercell_size);
        lattice_candidates.sort_by(|(lattice_a, _), (lattice_b, _)| {
            let score_a = Self::lattice_similarity_score(lattice_a, target_lattice);
            let score_b = Self::lattice_similarity_score(lattice_b, target_lattice);
            score_a.total_cmp(&score_b)
        });
        lattice_candidates
    }

    fn lattice_similarity_score(candidate_lattice: &Lattice, target_lattice: &Lattice) -> f64 {
        let candidate_lengths = candidate_lattice.lengths();
        let target_lengths = target_lattice.lengths();
        let candidate_angles = candidate_lattice.angles();
        let target_angles = target_lattice.angles();

        let mut score = 0.0;
        for axis_idx in 0..3 {
            let length_norm = target_lengths[axis_idx].abs().max(f64::EPSILON);
            score += (candidate_lengths[axis_idx] - target_lengths[axis_idx]).abs() / length_norm;
            score += (candidate_angles[axis_idx] - target_angles[axis_idx]).abs() / 180.0;
        }
        score
    }

    /// Compute average lattice from two lattices.
    fn average_lattice(l1: &Lattice, l2: &Lattice) -> Lattice {
        let params1 = l1.lengths();
        let params2 = l2.lengths();
        let angles1 = l1.angles();
        let angles2 = l2.angles();

        let mut avg_lattice = Lattice::from_parameters(
            (params1[0] + params2[0]) / 2.0,
            (params1[1] + params2[1]) / 2.0,
            (params1[2] + params2[2]) / 2.0,
            (angles1[0] + angles2[0]) / 2.0,
            (angles1[1] + angles2[1]) / 2.0,
            (angles1[2] + angles2[2]) / 2.0,
        );
        debug_assert_eq!(l1.pbc, l2.pbc, "PBC mismatch in average_lattice");
        avg_lattice.pbc = l1.pbc;
        avg_lattice
    }

    /// Compute Cartesian distances using Hungarian algorithm.
    ///
    /// Returns (distances, translation, mapping)
    fn cart_dists(
        &self,
        s1_fc: &[Vector3<f64>],
        s2_fc: &[Vector3<f64>],
        avg_lattice: &Lattice,
        mask: &[Vec<bool>],
        normalization: f64,
    ) -> Option<(Vec<f64>, Vector3<f64>, Vec<usize>)> {
        let n1 = s1_fc.len();
        let n2 = s2_fc.len();

        if n2 > n1 || n2 == 0 {
            return None;
        }

        // Get shortest vectors
        let (vecs, d2, _) = pbc_shortest_vectors(avg_lattice, s2_fc, s1_fc, Some(mask), None);

        // Solve linear assignment problem
        // Convert to integer costs (multiply by large factor for precision)
        let scale = 1e10;
        let mut cost_matrix = PathMatrix::new(n2, n1, i64::MAX / 2);

        for idx in 0..n2 {
            for jdx in 0..n1 {
                if !mask[idx][jdx] {
                    // Clamp to avoid overflow (masked cells already have i64::MAX / 2)
                    cost_matrix[(idx, jdx)] =
                        (d2[idx][jdx] * scale).min(i64::MAX as f64 / 2.0) as i64;
                }
            }
        }

        let (_total_cost, assignment) = kuhn_munkres_min(&cost_matrix);
        let mapping: Vec<usize> = assignment.to_vec();

        // Compute translation and distances
        let mut short_vecs = Vec::with_capacity(n2);
        for (idx, &jdx) in mapping.iter().enumerate() {
            if jdx < vecs[idx].len() {
                short_vecs.push(vecs[idx][jdx]);
            } else {
                return None;
            }
        }

        // Translation is mean of short vectors (guard against empty vector)
        if short_vecs.is_empty() {
            return None;
        }
        let translation: Vector3<f64> =
            short_vecs.iter().fold(Vector3::zeros(), |acc, v| acc + v) / short_vecs.len() as f64;

        // Distances after translation adjustment
        let distances: Vec<f64> = short_vecs
            .iter()
            .map(|v| (v - translation).norm() * normalization)
            .collect();

        let f_translation = avg_lattice.get_fractional_coords(&[translation])[0];

        Some((distances, f_translation, mapping))
    }

    /// Check if two fractional coordinate sets match within tolerance.
    fn cmp_fstruct(
        s1_fc: &[Vector3<f64>],
        s2_fc: &[Vector3<f64>],
        frac_tol: [f64; 3],
        mask: &[Vec<bool>],
        pbc: [bool; 3],
    ) -> bool {
        is_coord_subset_pbc(s2_fc, s1_fc, frac_tol, mask, pbc)
    }

    /// Strict matching - s1 should contain all sites in s2.
    fn strict_match(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        supercell_factor: usize,
        break_on_match: bool,
        use_rms: bool,
    ) -> Option<(f64, Vec<f64>, Vec<usize>)> {
        if struct1.lattice.pbc != struct2.lattice.pbc {
            return None;
        }

        let mask = self.get_mask(struct1, struct2);

        if mask.is_empty() {
            return None;
        }

        let (struct1_translation_indices, struct2_translation_idx) =
            self.get_translation_indices(&mask);

        // Check dimensions
        if struct2.num_sites() > struct1.num_sites() {
            return None;
        }

        // Check that a valid matching is possible
        for row in &mask {
            if row.iter().all(|&x| x) {
                return None;
            }
        }

        let mut best_match: Option<(f64, Vec<f64>, Vec<usize>)> = None;

        // For non-periodic matching, avoid enumerating periodic lattice mappings.
        let lattices = if struct1.lattice.pbc.iter().any(|&is_periodic| is_periodic) {
            self.sorted_lattice_candidates(&struct2.lattice, struct1, supercell_factor)
        } else {
            vec![(struct2.lattice.clone(), Matrix3::identity())]
        };

        if lattices.is_empty() {
            return None;
        }

        // Loop over all lattice mappings
        for (latt, _scale_m) in &lattices {
            let avg_lattice = Self::average_lattice(latt, &struct2.lattice);

            // Compute fractional coordinate tolerance
            let normalization = (struct1.num_sites() as f64 / avg_lattice.volume()).powf(1.0 / 3.0);
            let recip_lengths = avg_lattice.reciprocal().lengths();
            let scale = self.site_pos_tol / (PI * normalization);
            let frac_coord_tol = [
                recip_lengths[0] * scale,
                recip_lengths[1] * scale,
                recip_lengths[2] * scale,
            ];

            // Get fractional coords in the aligned lattice
            let s1_cart = struct1.cart_coords();
            let mut s1_fc = latt.get_fractional_coords(&s1_cart);
            // Wrap to [0, 1)
            for coord in &mut s1_fc {
                *coord = wrap_frac_coords_pbc(coord, struct1.lattice.pbc);
            }

            let s2_fc = &struct2.frac_coords;

            // Try different translations
            for &s1i in &struct1_translation_indices {
                if s1i >= s1_fc.len() || struct2_translation_idx >= s2_fc.len() {
                    continue;
                }

                let mut translation = s1_fc[s1i] - s2_fc[struct2_translation_idx];
                for axis in 0..3 {
                    if !struct1.lattice.pbc[axis] {
                        translation[axis] = 0.0;
                    }
                }
                let translated_s2_fc: Vec<Vector3<f64>> =
                    s2_fc.iter().map(|frac| frac + translation).collect();

                // Check if fractional coords match
                if Self::cmp_fstruct(
                    &s1_fc,
                    &translated_s2_fc,
                    frac_coord_tol,
                    &mask,
                    struct1.lattice.pbc,
                ) {
                    // Compute distances
                    if let Some((distances, _adjusted_translation, mapping)) = self.cart_dists(
                        &s1_fc,
                        &translated_s2_fc,
                        &avg_lattice,
                        &mask,
                        normalization,
                    ) {
                        let val = if use_rms {
                            let sum_sq: f64 = distances.iter().map(|d| d * d).sum();
                            (sum_sq / distances.len() as f64).sqrt()
                        } else {
                            distances.iter().copied().fold(0.0, f64::max)
                        };

                        if best_match.as_ref().is_none_or(|m| val < m.0) {
                            best_match = Some((val, distances.clone(), mapping));

                            if (break_on_match || val < 1e-5) && val < self.site_pos_tol {
                                return best_match;
                            }
                        }
                    }
                }
            }
        }

        best_match.filter(|m| m.0 < self.site_pos_tol)
    }

    /// Internal match function.
    fn match_internal(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        supercell_factor: usize,
        s1_supercell: bool,
        break_on_match: bool,
        use_rms: bool,
    ) -> Option<(f64, Vec<f64>, Vec<usize>)> {
        let ratio = if s1_supercell {
            supercell_factor as f64
        } else {
            1.0 / supercell_factor as f64
        };

        if (struct1.num_sites() as f64 * ratio) >= struct2.num_sites() as f64 {
            self.strict_match(struct1, struct2, supercell_factor, break_on_match, use_rms)
        } else {
            self.strict_match(struct2, struct1, supercell_factor, break_on_match, use_rms)
        }
    }

    fn explicit_supercell_matrices(supercell_factor: usize) -> Vec<[[i32; 3]; 3]> {
        let mut scaling_matrices = Vec::new();
        for factor_a in 1..=supercell_factor {
            if !supercell_factor.is_multiple_of(factor_a) {
                continue;
            }
            let remaining_after_a = supercell_factor / factor_a;
            for factor_d in 1..=remaining_after_a {
                if !remaining_after_a.is_multiple_of(factor_d) {
                    continue;
                }
                let factor_f = remaining_after_a / factor_d;
                let Some(factor_a_i32) = i32::try_from(factor_a).ok() else {
                    continue;
                };
                let Some(factor_d_i32) = i32::try_from(factor_d).ok() else {
                    continue;
                };
                let Some(factor_f_i32) = i32::try_from(factor_f).ok() else {
                    continue;
                };

                // Enumerate upper-triangular Hermite-like matrices with determinant n.
                for offset_b in 0..factor_d {
                    let Some(offset_b_i32) = i32::try_from(offset_b).ok() else {
                        continue;
                    };
                    for offset_c in 0..factor_f {
                        let Some(offset_c_i32) = i32::try_from(offset_c).ok() else {
                            continue;
                        };
                        for offset_e in 0..factor_f {
                            let Some(offset_e_i32) = i32::try_from(offset_e).ok() else {
                                continue;
                            };
                            scaling_matrices.push([
                                [factor_a_i32, offset_b_i32, offset_c_i32],
                                [0, factor_d_i32, offset_e_i32],
                                [0, 0, factor_f_i32],
                            ]);
                        }
                    }
                }
            }
        }
        scaling_matrices
    }

    fn match_with_explicit_supercell(&self, struct1: &Structure, struct2: &Structure) -> bool {
        let (smaller_structure, larger_structure) = if struct1.num_sites() <= struct2.num_sites() {
            (struct1, struct2)
        } else {
            (struct2, struct1)
        };

        if smaller_structure.num_sites() == 0 || larger_structure.num_sites() == 0 {
            return false;
        }
        if larger_structure.num_sites() % smaller_structure.num_sites() != 0 {
            return false;
        }

        let exact_supercell_factor = larger_structure.num_sites() / smaller_structure.num_sites();
        if exact_supercell_factor <= 1 {
            return false;
        }

        for scaling_matrix in Self::explicit_supercell_matrices(exact_supercell_factor) {
            let Ok(expanded_structure) = smaller_structure.make_supercell(scaling_matrix) else {
                continue;
            };
            if self
                .match_internal(&expanded_structure, larger_structure, 1, true, true, false)
                .is_some_and(|(match_value, _, _)| match_value <= self.site_pos_tol)
            {
                return true;
            }
        }

        false
    }

    /// Check if two structures match.
    ///
    /// # Returns
    ///
    /// `true` if the structures are equivalent within the specified tolerances.
    ///
    /// # Note
    ///
    /// Empty structures (with no sites) always return `false` since there are no
    /// atoms to compare for structural equivalence.
    pub fn fit(&self, struct1: &Structure, struct2: &Structure) -> bool {
        // Reduce structures then delegate to fit_preprocessed
        self.fit_preprocessed(
            &self.get_reduced_structure_with_on_error(struct1, "fit"),
            &self.get_reduced_structure_with_on_error(struct2, "fit"),
        )
    }

    /// Get the RMS distance between two structures.
    ///
    /// # Returns
    ///
    /// `Some((rms, max_dist))` if structures match, `None` otherwise.
    pub fn get_rms_dist(&self, struct1: &Structure, struct2: &Structure) -> Option<(f64, f64)> {
        if struct1.lattice.pbc != struct2.lattice.pbc {
            return None;
        }
        let (s1, s2, supercell_factor, s1_supercell) = self.preprocess(struct1, struct2);
        self.match_internal(&s1, &s2, supercell_factor, s1_supercell, false, true)
            .map(|(rms, distances, _)| {
                let max_dist = distances.iter().cloned().fold(0.0, f64::max);
                (rms, max_dist)
            })
    }

    /// Compute a universal distance between any two crystal structures.
    ///
    /// Unlike `get_rms_dist` which may return `None` for incompatible structures,
    /// this method always returns a finite distance value, making it suitable for
    /// consistent ranking of structures by similarity.
    ///
    /// # Properties
    ///
    /// - d(x, y) ≥ 0 (non-negative)
    /// - d(x, x) = 0 (identity)
    /// - d(x, y) = d(y, x) (symmetric)
    /// - Always finite (empty vs non-empty returns `EMPTY_STRUCTURE_DISTANCE`)
    ///
    /// Note: Triangle inequality is not guaranteed due to greedy matching.
    ///
    /// # Algorithm
    ///
    /// The distance is a weighted sum of:
    /// 1. **Geometric distance**: RMS of greedy-matched site positions (both structures
    ///    normalized to unit total volume for consistent comparison)
    /// 2. **Composition distance**: Jaccard distance on element sets
    ///
    /// # Returns
    ///
    /// Finite distance in [0, 1e9]. Identical structures return 0.0.
    pub fn get_structure_distance(&self, struct1: &Structure, struct2: &Structure) -> f64 {
        let n1 = struct1.num_sites();
        let n2 = struct2.num_sites();

        // Handle edge cases - always return finite values
        if n1 == 0 && n2 == 0 {
            return 0.0;
        }
        if n1 == 0 || n2 == 0 {
            return EMPTY_STRUCTURE_DISTANCE;
        }

        // Composition distance (Jaccard distance on element sets)
        let elements1: HashSet<_> = struct1.species().iter().map(|s| s.element).collect();
        let elements2: HashSet<_> = struct2.species().iter().map(|s| s.element).collect();

        let intersection = elements1.intersection(&elements2).count();
        if intersection == 0 {
            return DISJOINT_COMPOSITION_DISTANCE;
        }

        let union = elements1.union(&elements2).count();
        let composition_distance = 1.0 - (intersection as f64 / union as f64);

        // Use non-panicking reduction fallback here so this method always returns
        // a finite distance, independent of the on_error policy.
        let s1_reduced = self
            .try_get_reduced_structure(struct1)
            .unwrap_or_else(|_| Self::niggli_reduce_structure(struct1));
        let s2_reduced = self
            .try_get_reduced_structure(struct2)
            .unwrap_or_else(|_| Self::niggli_reduce_structure(struct2));
        let n1_reduced = s1_reduced.num_sites();
        let n2_reduced = s2_reduced.num_sites();

        // Symmetrize geometric distance when REDUCED sizes are equal (greedy matching is order-dependent)
        // Must use reduced sizes since compute_geometric_distance operates on reduced structures
        let geometric_distance = if n1_reduced == n2_reduced {
            let d1 = self.compute_geometric_distance_inner(&s1_reduced, &s2_reduced);
            let d2 = self.compute_geometric_distance_inner(&s2_reduced, &s1_reduced);
            (d1 + d2) / 2.0
        } else {
            self.compute_geometric_distance_inner(&s1_reduced, &s2_reduced)
        };
        geometric_distance + COMPOSITION_WEIGHT * composition_distance
    }

    /// Compute geometric distance between two already-reduced structures.
    ///
    /// Normalizes both structures to unit total volume (1 Å³), converts each to Cartesian
    /// in this common frame, then computes RMS distance via greedy element-constrained matching.
    ///
    /// Note: Expects pre-reduced structures (call get_reduced_structure first).
    fn compute_geometric_distance_inner(&self, s1: &Structure, s2: &Structure) -> f64 {
        let n1 = s1.num_sites();
        let n2 = s2.num_sites();

        if n1 == 0 || n2 == 0 {
            return EMPTY_STRUCTURE_DISTANCE;
        }

        // Guard against zero/degenerate volumes to avoid inf/NaN in normalization
        let vol1 = s1.lattice.volume();
        let vol2 = s2.lattice.volume();
        if vol1 <= MIN_LATTICE_VOLUME || vol2 <= MIN_LATTICE_VOLUME {
            return EMPTY_STRUCTURE_DISTANCE; // Degenerate lattice treated as incomparable
        }

        // Normalize BOTH lattices to unit total volume (1 Å³). This ensures distances
        // are comparable regardless of the original cell sizes.
        let scale1 = (1.0 / vol1).powf(1.0 / 3.0);
        let scale2 = (1.0 / vol2).powf(1.0 / 3.0);
        let mut lattice1 = Lattice::new(*s1.lattice.matrix() * scale1);
        let mut lattice2 = Lattice::new(*s2.lattice.matrix() * scale2);
        lattice1.pbc = s1.lattice.pbc;
        lattice2.pbc = s2.lattice.pbc;

        let frac1 = &s1.frac_coords;
        let frac2 = &s2.frac_coords;

        let elem1: Vec<_> = s1.species().iter().map(|s| s.element).collect();
        let elem2: Vec<_> = s2.species().iter().map(|s| s.element).collect();

        // Use smaller as source, larger as target (for consistent matching direction)
        let (
            source_frac,
            target_frac,
            source_elem,
            target_elem,
            source_latt,
            target_latt,
            n_source,
            n_target,
        ) = if n1 <= n2 {
            (frac1, frac2, &elem1, &elem2, &lattice1, &lattice2, n1, n2)
        } else {
            (frac2, frac1, &elem2, &elem1, &lattice2, &lattice1, n2, n1)
        };

        // Greedy matching: for each source site, find nearest compatible target site
        let mut total_sq_dist = 0.0;
        let mut used_target = vec![false; n_target];

        for (src_idx, src_frac) in source_frac.iter().enumerate() {
            let src_elem = source_elem[src_idx];
            let mut best_dist = f64::INFINITY;
            let mut best_target = None;

            for (tgt_idx, tgt_frac) in target_frac.iter().enumerate() {
                if used_target[tgt_idx] || target_elem[tgt_idx] != src_elem {
                    continue;
                }

                // Minimum image distance handling different lattices:
                // 1. Convert each site to Cartesian using its OWN lattice
                // 2. Compute Cartesian difference
                // 3. Convert to fractional (using source_latt) for PBC wrapping
                // 4. Wrap to [-0.5, 0.5] and convert back to Cartesian
                let src_cart = source_latt.get_cartesian_coords(&[*src_frac])[0];
                let tgt_cart = target_latt.get_cartesian_coords(&[*tgt_frac])[0];
                let cart_diff = tgt_cart - src_cart;

                // Convert to fractional for minimum-image wrapping (source lattice
                // as reference). Only wrap along periodic axes.
                let frac_diff = source_latt.get_fractional_coords(&[cart_diff])[0];
                let pbc = source_latt.pbc;
                let wrap = |val: f64, periodic: bool| {
                    if periodic { val - val.round() } else { val }
                };
                let wrapped_frac = Vector3::new(
                    wrap(frac_diff.x, pbc[0]),
                    wrap(frac_diff.y, pbc[1]),
                    wrap(frac_diff.z, pbc[2]),
                );
                let wrapped_cart_diff = source_latt.get_cartesian_coords(&[wrapped_frac])[0];
                let dist = wrapped_cart_diff.norm();

                if dist < best_dist {
                    best_dist = dist;
                    best_target = Some(tgt_idx);
                }
            }

            if let Some(tgt_idx) = best_target {
                used_target[tgt_idx] = true;
                total_sq_dist += best_dist * best_dist;
            } else {
                total_sq_dist += UNMATCHED_SOURCE_PENALTY;
            }
        }

        let matched = used_target.iter().filter(|&&u| u).count();
        let unmatched_targets = n_target - matched;
        total_sq_dist += unmatched_targets as f64 * UNMATCHED_TARGET_PENALTY;

        let total_sites = n_source + unmatched_targets;
        (total_sq_dist / total_sites as f64).sqrt()
    }

    /// Check if two structures match under any species permutation.
    ///
    /// This is useful for comparing structures where the identity of species
    /// is not important, only the arrangement. For example, NaCl and MgO both
    /// have the rocksalt structure, so `fit_anonymous` would return true.
    ///
    /// # Algorithm (matches pymatgen's fit_anonymous)
    ///
    /// 1. Get unique elements from both structures in order of first appearance
    /// 2. If different number of unique elements, return false
    /// 3. For each permutation of struct2's elements:
    ///    - Create mapping: struct1.elements[i] -> permuted_elements[i]
    ///    - Compute mapped composition from struct1
    ///    - If mapped composition hash != struct2 composition hash, skip (fast pruning)
    ///    - Otherwise, remap struct1's species and call fit()
    /// 4. Return true on first match
    ///
    /// # Note
    ///
    /// This method always uses element-only matching (ignores oxidation states),
    /// regardless of the matcher's `comparator_type` setting. This matches pymatgen's
    /// behavior where anonymous matching only considers elemental identity.
    pub fn fit_anonymous(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        match_mode: Option<AnonymousMatchMode<'_>>,
    ) -> bool {
        match match_mode.unwrap_or(AnonymousMatchMode::ElementPermutation) {
            AnonymousMatchMode::ElementPermutation => {
                self.fit_anonymous_by_element_permutation(struct1, struct2)
            }
            AnonymousMatchMode::Predefined(mapping_kind) => {
                if !Self::missing_predefined_mapping_elements(struct1, struct2, mapping_kind)
                    .is_empty()
                {
                    return false;
                }
                let class_mapping = Self::predefined_class_mapping(mapping_kind);
                self.fit_anonymous_with_class_mapping(struct1, struct2, &class_mapping)
            }
            AnonymousMatchMode::Custom(class_mapping) => {
                self.fit_anonymous_with_class_mapping(struct1, struct2, class_mapping)
            }
        }
    }

    fn fit_anonymous_by_element_permutation(
        &self,
        struct1: &Structure,
        struct2: &Structure,
    ) -> bool {
        // Get unique elements in order of first appearance
        let elements1 = struct1.unique_elements();
        let elements2 = struct2.unique_elements();

        // Different number of unique elements -> no match possible
        if elements1.len() != elements2.len() {
            return false;
        }

        // Handle empty structures
        if elements1.is_empty() {
            return false;
        }

        // Get compositions for fast pruning (compute once, outside loop)
        // Use element_composition() since fit_anonymous ignores oxidation states
        let comp1 = struct1.composition();
        let comp2 = struct2.composition();
        let comp2_hash = comp2.element_composition().formula_hash();

        // Create element-only matcher once (used for all permutations)
        let element_matcher = Self {
            comparator_type: ComparatorType::Element,
            ..self.clone()
        };

        // Try all permutations of elements2
        for perm in elements2.iter().permutations(elements2.len()) {
            // Create mapping: elements1[i] -> perm[i]
            let mapping: HashMap<Element, Element> = elements1
                .iter()
                .zip(perm.iter())
                .map(|(&e1, &&e2)| (e1, e2))
                .collect();

            // Fast composition hash check before expensive structure matching
            let mapped_comp = comp1.remap_elements(&mapping);
            if mapped_comp.element_composition().formula_hash() != comp2_hash {
                continue;
            }

            // Composition matches - do full structure comparison
            let remapped_struct1 = struct1.remap_species(&mapping);
            if element_matcher.fit(&remapped_struct1, struct2) {
                return true;
            }
        }

        false
    }

    fn fit_anonymous_with_class_mapping(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        class_mapping: &HashMap<Element, String>,
    ) -> bool {
        let Some((mapped_struct1, mapped_struct2)) =
            self.remap_structures_for_class_matching(struct1, struct2, class_mapping)
        else {
            return false;
        };
        let element_matcher = Self {
            comparator_type: ComparatorType::Element,
            ..self.clone()
        };
        element_matcher.fit(&mapped_struct1, &mapped_struct2)
    }

    /// Compute structure distance after applying class-based anonymous mapping.
    ///
    /// Returns `None` if any element in either structure is not present in
    /// `class_mapping`.
    pub fn get_structure_distance_anonymous_mapped(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        class_mapping: &HashMap<Element, String>,
    ) -> Option<f64> {
        let (mapped_struct1, mapped_struct2) =
            self.remap_structures_for_class_matching(struct1, struct2, class_mapping)?;
        let element_matcher = Self {
            comparator_type: ComparatorType::Element,
            ..self.clone()
        };
        Some(element_matcher.get_structure_distance(&mapped_struct1, &mapped_struct2))
    }

    /// Compute structure distance after applying a predefined class-based mapping.
    pub fn get_structure_distance_anonymous_predefined(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        mapping_kind: AnonymousClassMapping,
    ) -> Option<f64> {
        let class_mapping = Self::predefined_class_mapping(mapping_kind);
        self.get_structure_distance_anonymous_mapped(struct1, struct2, &class_mapping)
    }

    fn remap_structures_for_class_matching(
        &self,
        struct1: &Structure,
        struct2: &Structure,
        class_mapping: &HashMap<Element, String>,
    ) -> Option<(Structure, Structure)> {
        let mut class_labels = HashSet::new();
        let mut unique_elements = HashSet::new();
        for structure in [struct1, struct2] {
            for species in structure.species() {
                let element = species.element;
                unique_elements.insert(element);
                let class_label = class_mapping.get(&element)?;
                class_labels.insert(class_label.clone());
            }
        }

        if class_labels.len() > usize::from(MAX_SUPPORTED_ATOMIC_NUMBER) {
            return None;
        }

        let mut sorted_class_labels: Vec<_> = class_labels.into_iter().collect();
        sorted_class_labels.sort_unstable();

        let mut placeholder_by_class = HashMap::new();
        for (class_idx, class_label) in sorted_class_labels.into_iter().enumerate() {
            let placeholder = Element::from_atomic_number((class_idx + 1) as u8)?;
            placeholder_by_class.insert(class_label, placeholder);
        }

        let mut element_remap = HashMap::new();
        for element in unique_elements {
            let class_label = class_mapping.get(&element)?;
            let placeholder_element = *placeholder_by_class.get(class_label)?;
            element_remap.insert(element, placeholder_element);
        }

        let mapped_struct1 = struct1.remap_species(&element_remap);
        let mapped_struct2 = struct2.remap_species(&element_remap);
        Some((mapped_struct1, mapped_struct2))
    }

    /// Check if two already-reduced structures match.
    ///
    /// This is an optimization for batch operations where structures have already
    /// been preprocessed with `reduce_structure`. Skips redundant Niggli reduction
    /// and primitive cell reduction.
    ///
    /// # Arguments
    ///
    /// * `reduced1` - First structure (already Niggli reduced + primitive cell if enabled)
    /// * `reduced2` - Second structure (already preprocessed)
    ///
    /// # Note
    ///
    /// Use this when you've already called `reduce_structure` on both inputs.
    /// For general use, prefer `fit` which handles preprocessing automatically.
    pub fn fit_preprocessed(&self, reduced1: &Structure, reduced2: &Structure) -> bool {
        if reduced1.lattice.pbc != reduced2.lattice.pbc {
            return false;
        }

        // Use preprocess_pair to handle supercell factor and volume scaling
        let (s1, s2, supercell_factor, s1_supercell) =
            self.preprocess_pair(reduced1.clone(), reduced2.clone());

        // Composition check
        if self.composition_hash(&s1) != self.composition_hash(&s2) {
            return false;
        }
        if !self.compositions_equal(&s1, &s2) {
            return false;
        }

        // Site count check (without supercell)
        if !self.attempt_supercell && s1.num_sites() != s2.num_sites() {
            return false;
        }
        if self.attempt_supercell
            && s1.num_sites() != s2.num_sites()
            && !Self::has_integer_supercell_ratio(s1.num_sites(), s2.num_sites())
        {
            return false;
        }

        if self
            .match_internal(&s1, &s2, supercell_factor, s1_supercell, true, false)
            .is_some_and(|(val, _, _)| val <= self.site_pos_tol)
        {
            return true;
        }

        self.attempt_supercell
            && s1.num_sites() != s2.num_sites()
            && self.match_with_explicit_supercell(&s1, &s2)
    }

    /// Apply Niggli reduction and optionally primitive cell reduction.
    ///
    /// Use this to preprocess structures before calling `fit_preprocessed`.
    pub fn reduce_structure(&self, structure: &Structure) -> Structure {
        self.get_reduced_structure_with_on_error(structure, "reduce_structure")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::element::Element;

    // Helper: single atom at origin in cubic cell
    fn make_simple_cubic(element: Element, a: f64) -> Structure {
        Structure::new(
            Lattice::cubic(a),
            vec![Species::neutral(element)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        )
    }

    // Helper: two atoms in BCC-like positions
    fn make_bcc(element: Element, a: f64) -> Structure {
        Structure::new(
            Lattice::cubic(a),
            vec![Species::neutral(element), Species::neutral(element)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        )
    }

    fn make_nacl() -> Structure {
        Structure::new(
            Lattice::cubic(5.64),
            vec![Species::neutral(Element::Na), Species::neutral(Element::Cl)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        )
    }

    fn make_nacl_shifted() -> Structure {
        Structure::new(
            Lattice::cubic(5.64),
            vec![Species::neutral(Element::Na), Species::neutral(Element::Cl)],
            vec![Vector3::new(0.01, 0.0, 0.0), Vector3::new(0.51, 0.5, 0.5)],
        )
    }

    fn make_degenerate_lattice_structure(element: Element) -> Structure {
        let degenerate_lattice =
            Lattice::new(Matrix3::new(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0));
        Structure::new(
            degenerate_lattice,
            vec![Species::neutral(element)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        )
    }

    #[test]
    fn test_builder() {
        let matcher = StructureMatcher::new()
            .with_latt_len_tol(0.1)
            .with_site_pos_tol(0.2)
            .with_angle_tol(3.0);

        assert!((matcher.latt_len_tol - 0.1).abs() < 1e-10);
        assert!((matcher.site_pos_tol - 0.2).abs() < 1e-10);
        assert!((matcher.angle_tol - 3.0).abs() < 1e-10);
    }

    #[test]
    fn test_fit_identical() {
        let s = make_nacl();
        let matcher = StructureMatcher::new();
        assert!(matcher.fit(&s, &s));
    }

    #[test]
    fn test_fit_shifted() {
        let s1 = make_nacl();
        let s2 = make_nacl_shifted();
        let matcher = StructureMatcher::new();
        // Should match within default tolerance
        assert!(matcher.fit(&s1, &s2));
    }

    #[test]
    fn test_fit_different_composition() {
        let s1 = make_nacl();
        // KCl instead of NaCl
        let lattice = Lattice::cubic(5.64);
        let species = vec![Species::neutral(Element::K), Species::neutral(Element::Cl)];
        let frac_coords = vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)];
        let s2 = Structure::new(lattice, species, frac_coords);

        let matcher = StructureMatcher::new();
        // Different composition should not match
        assert!(!matcher.fit(&s1, &s2));
    }

    #[test]
    fn test_get_rms_dist() {
        let s1 = make_nacl();
        let s2 = make_nacl_shifted();
        let matcher = StructureMatcher::new();

        let result = matcher.get_rms_dist(&s1, &s2);
        assert!(result.is_some());

        let (rms, max_dist) = result.unwrap();
        // RMS should be small for slightly shifted structure
        assert!(rms < 0.1, "RMS {rms} too large");
        assert!(max_dist < 0.2, "max_dist {max_dist} too large");
    }

    #[test]
    fn test_fit_different_sites() {
        // Different number of sites
        let lattice = Lattice::cubic(5.64);
        let s1 = Structure::new(
            lattice.clone(),
            vec![Species::neutral(Element::Na)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let s2 = Structure::new(
            lattice,
            vec![Species::neutral(Element::Na), Species::neutral(Element::Na)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );

        let matcher = StructureMatcher::new();
        // Different number of sites should not match (without supercell)
        assert!(!matcher.fit(&s1, &s2));
    }

    #[test]
    fn test_fit_with_scale_true() {
        // Structures with same shape but different volumes should match with scale=true
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let s2 = make_simple_cubic(Element::Fe, 6.0); // 50% larger

        let matcher = StructureMatcher::new().with_scale(true);
        assert!(
            matcher.fit(&s1, &s2),
            "Same structure at different scales should match"
        );
    }

    #[test]
    fn test_fit_with_scale_false() {
        // With scale=false and tight len_tol, very different volumes should not match
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let s2 = make_simple_cubic(Element::Fe, 6.0); // 50% larger, ratio=1.5 well outside len_tol=0.2

        let matcher = StructureMatcher::new().with_scale(false);
        assert!(
            !matcher.fit(&s1, &s2),
            "Very different volumes should not match with scale=false"
        );
    }

    // Helper: single atom at origin with custom lattice
    fn make_single_site(lattice: Lattice, element: Element) -> Structure {
        Structure::new(
            lattice,
            vec![Species::neutral(element)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        )
    }

    // Helper: FCC conventional cell (4 atoms)
    fn make_fcc_conventional(element: Element, a: f64) -> Structure {
        Structure::new(
            Lattice::cubic(a),
            vec![
                Species::neutral(element),
                Species::neutral(element),
                Species::neutral(element),
                Species::neutral(element),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.0),
                Vector3::new(0.5, 0.0, 0.5),
                Vector3::new(0.0, 0.5, 0.5),
            ],
        )
    }

    #[test]
    fn test_fit_angle_tolerance() {
        let s1 = make_single_site(
            Lattice::from_parameters(5.0, 5.0, 5.0, 90.0, 90.0, 90.0),
            Element::Si,
        );
        let matcher = StructureMatcher::new().with_angle_tol(5.0);
        // (gamma, should_match)
        for (gamma, should_match) in [(93.0, true), (110.0, false)] {
            let s2 = make_single_site(
                Lattice::from_parameters(5.0, 5.0, 5.0, 90.0, 90.0, gamma),
                Element::Si,
            );
            assert_eq!(matcher.fit(&s1, &s2), should_match, "gamma={gamma}");
        }
    }

    #[test]
    fn test_fit_site_tolerance_strict() {
        // Use multi-atom structure where relative positions matter
        // Disable primitive_cell since BCC (2 atoms) reduces to primitive (1 atom),
        // which would make the displaced structure also 1 atom and they'd trivially match
        let s1 = make_bcc(Element::Fe, 5.0);
        // Displace second atom significantly (relative to first)
        let s2 = Structure::new(
            Lattice::cubic(5.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.8)], // z displaced by 0.3
        );

        let matcher_strict = StructureMatcher::new()
            .with_site_pos_tol(0.01)
            .with_primitive_cell(false);
        assert!(
            !matcher_strict.fit(&s1, &s2),
            "Large relative displacement should fail with strict site_pos_tol"
        );

        let matcher_lenient = StructureMatcher::new()
            .with_site_pos_tol(0.5)
            .with_primitive_cell(false);
        assert!(
            matcher_lenient.fit(&s1, &s2),
            "Large relative displacement should pass with lenient site_pos_tol"
        );
    }

    #[test]
    fn test_get_rms_dist_no_match() {
        // Completely different structures
        let s1 = make_simple_cubic(Element::Na, 5.0);
        let s2 = make_simple_cubic(Element::Cl, 5.0); // Different element

        let matcher = StructureMatcher::new();
        let result = matcher.get_rms_dist(&s1, &s2);
        assert!(
            result.is_none(),
            "Different compositions should return None for RMS"
        );
    }

    #[test]
    fn test_matcher_builder_chain() {
        let matcher = StructureMatcher::new()
            .with_latt_len_tol(0.1)
            .with_site_pos_tol(0.2)
            .with_angle_tol(3.0)
            .with_scale(true)
            .with_attempt_supercell(false)
            .with_comparator(ComparatorType::Element);

        assert!((matcher.latt_len_tol - 0.1).abs() < 1e-10);
        assert!((matcher.site_pos_tol - 0.2).abs() < 1e-10);
        assert!((matcher.angle_tol - 3.0).abs() < 1e-10);
        assert!(matcher.scale);
        assert!(!matcher.attempt_supercell);
    }

    #[test]
    fn test_group_edge_cases() {
        let matcher = StructureMatcher::new();
        // Empty input
        assert!(matcher.group(&[]).unwrap().is_empty());
        // Single structure
        let s = make_simple_cubic(Element::Fe, 5.0);
        let groups = matcher.group(&[s]).unwrap();
        assert_eq!(groups.len(), 1);
        assert_eq!(groups[&0], vec![0]);
    }

    #[test]
    fn test_group_identical_structures() {
        let s = make_simple_cubic(Element::Fe, 5.0);
        let structures = vec![s.clone(), s.clone(), s.clone()];
        let matcher = StructureMatcher::new();
        let groups = matcher.group(&structures).unwrap();

        // All three should be in one group
        assert_eq!(groups.len(), 1);
        assert_eq!(groups[&0].len(), 3);
    }

    #[test]
    fn test_group_different_compositions() {
        let structures = vec![
            make_simple_cubic(Element::Fe, 5.0),
            make_simple_cubic(Element::Cu, 5.0),
            make_simple_cubic(Element::Ni, 5.0),
        ];

        let matcher = StructureMatcher::new();
        let groups = matcher.group(&structures).unwrap();

        // Each should be its own group
        assert_eq!(
            groups.len(),
            3,
            "Different compositions should be in different groups"
        );
    }

    #[test]
    fn test_deduplicate_preserves_order() {
        let s1 = make_simple_cubic(Element::Fe, 5.0);
        let s2 = make_simple_cubic(Element::Cu, 5.0);

        // s1, s2, s1_copy, s2_copy
        let structures = vec![s1.clone(), s2.clone(), s1.clone(), s2.clone()];
        let matcher = StructureMatcher::new();
        let mapping = matcher.deduplicate(&structures).unwrap().parents;

        // Index 0 -> 0 (first Fe)
        // Index 1 -> 1 (first Cu)
        // Index 2 -> 0 (maps to first Fe)
        // Index 3 -> 1 (maps to first Cu)
        assert_eq!(mapping[0], 0);
        assert_eq!(mapping[1], 1);
        assert_eq!(mapping[2], 0);
        assert_eq!(mapping[3], 1);
    }

    #[test]
    fn test_fit_triclinic_structures() {
        let lattice = Lattice::from_parameters(3.0, 4.0, 5.0, 75.0, 85.0, 95.0);
        let s1 = Structure::new(
            lattice.clone(),
            vec![Species::neutral(Element::Ca), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let s2 = s1.clone();

        let matcher = StructureMatcher::new();
        assert!(
            matcher.fit(&s1, &s2),
            "Identical triclinic structures should match"
        );
    }

    #[test]
    fn test_fit_hexagonal_structures() {
        let lattice = Lattice::hexagonal(3.0, 5.0);
        let s1 = Structure::new(
            lattice.clone(),
            vec![Species::neutral(Element::Ti), Species::neutral(Element::Ti)],
            vec![
                Vector3::new(1.0 / 3.0, 2.0 / 3.0, 0.25),
                Vector3::new(2.0 / 3.0, 1.0 / 3.0, 0.75),
            ],
        );
        let s2 = s1.clone();

        let matcher = StructureMatcher::new();
        assert!(
            matcher.fit(&s1, &s2),
            "Identical hexagonal structures should match"
        );
    }

    #[test]
    fn test_fit_anonymous_identical() {
        let s = make_nacl();
        let matcher = StructureMatcher::new();
        assert!(matcher.fit_anonymous(&s, &s, None));
    }

    #[test]
    fn test_fit_anonymous_swapped_species() {
        // NaCl with swapped species order should match
        let nacl = make_nacl();
        let clna = Structure::new(
            Lattice::cubic(5.64),
            vec![Species::neutral(Element::Cl), Species::neutral(Element::Na)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        assert!(StructureMatcher::new().fit_anonymous(&nacl, &clna, None));
    }

    #[test]
    fn test_fit_anonymous_same_prototype() {
        // NaCl and MgO have the same rocksalt prototype
        let nacl = make_nacl();
        let mgo = Structure::new(
            Lattice::cubic(4.21),
            vec![Species::neutral(Element::Mg), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        assert!(StructureMatcher::new().fit_anonymous(&nacl, &mgo, None));
    }

    #[test]
    fn test_fit_anonymous_different_stoichiometry() {
        // AB vs A2B3 stoichiometry should not match
        let nacl = make_nacl();
        let a2b3 = Structure::new(
            Lattice::cubic(5.0),
            vec![
                Species::neutral(Element::Fe),
                Species::neutral(Element::Fe),
                Species::neutral(Element::O),
                Species::neutral(Element::O),
                Species::neutral(Element::O),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
                Vector3::new(0.75, 0.75, 0.75),
                Vector3::new(0.25, 0.75, 0.25),
            ],
        );
        assert!(!StructureMatcher::new().fit_anonymous(&nacl, &a2b3, None));
    }

    #[test]
    fn test_fit_anonymous_single_element() {
        let fe = make_simple_cubic(Element::Fe, 4.0);
        let cu = make_simple_cubic(Element::Cu, 4.0);
        let matcher = StructureMatcher::new();
        assert!(matcher.fit_anonymous(&fe, &cu, None));
    }

    #[test]
    fn test_fit_anonymous_different_num_elements() {
        let nacl = make_nacl();
        let fe = make_simple_cubic(Element::Fe, 4.0);
        let matcher = StructureMatcher::new();
        assert!(!matcher.fit_anonymous(&nacl, &fe, None));
    }

    #[test]
    fn test_empty_structures() {
        let lattice = Lattice::cubic(4.0);
        let s1 = Structure::new(lattice.clone(), vec![], vec![]);
        let s2 = Structure::new(lattice, vec![], vec![]);

        let matcher = StructureMatcher::new();
        // Empty structures don't match (early exit when n_sites == 0)
        assert!(!matcher.fit(&s1, &s2));
    }

    #[test]
    fn test_single_site_structure() {
        let s1 = make_simple_cubic(Element::Cu, 4.0);
        let s2 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Cu)],
            vec![Vector3::new(0.01, 0.01, 0.01)], // slightly shifted
        );

        let matcher = StructureMatcher::new();
        assert!(matcher.fit(&s1, &s2));
    }

    #[test]
    fn test_fit_with_primitive_cell_option() {
        // Two conventional FCC cells at slightly different scales
        let fcc_conv1 = make_fcc_conventional(Element::Cu, 3.6);
        let fcc_conv2 = make_fcc_conventional(Element::Cu, 3.65); // 1.4% larger

        // Without primitive_cell, both have 4 atoms so they can match (with scale=true)
        let matcher_no_prim = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            matcher_no_prim.fit(&fcc_conv1, &fcc_conv2),
            "Same FCC at different scales should match with scale=true"
        );

        // With primitive_cell=true (default), reduction happens first then matching
        let matcher_with_prim = StructureMatcher::new().with_primitive_cell(true);
        assert!(
            matcher_with_prim.fit(&fcc_conv1, &fcc_conv2),
            "Same FCC at different scales should match with primitive_cell=true"
        );

        // Verify that primitive_cell=true reduces site count
        // (implicitly tested by the get_primitive tests in structure.rs)

        // Same structure should always match
        assert!(
            matcher_no_prim.fit(&fcc_conv1, &fcc_conv1),
            "Same structure should match"
        );
    }

    #[test]
    fn test_primitive_cell_reduces_conventional_to_primitive() {
        // Create FCC conventional (4 atoms) and get its moyo-produced primitive (1 atom)
        let fcc_conv = make_fcc_conventional(Element::Cu, 3.6);
        let fcc_prim = fcc_conv.get_primitive(1e-4).unwrap();

        assert_eq!(fcc_conv.num_sites(), 4);
        assert_eq!(fcc_prim.num_sites(), 1);

        // Without primitive_cell, different site counts means no match
        let matcher_no_prim = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            !matcher_no_prim.fit(&fcc_conv, &fcc_prim),
            "4 sites vs 1 site should not match without primitive_cell"
        );

        // With primitive_cell=true, conventional reduces to primitive and should match
        let matcher_with_prim = StructureMatcher::new().with_primitive_cell(true);
        assert!(
            matcher_with_prim.fit(&fcc_conv, &fcc_prim),
            "FCC conventional and its primitive should match with primitive_cell=true"
        );
    }

    #[test]
    fn test_on_error_behavior() {
        // Test that on_error setting is stored correctly
        let matcher_fail = StructureMatcher::new().with_on_error(crate::error::OnError::Fail);
        assert!(matcher_fail.on_error.should_fail());

        let matcher_skip = StructureMatcher::new().with_on_error(crate::error::OnError::Skip);
        assert!(!matcher_skip.on_error.should_fail());
    }

    #[test]
    #[should_panic(expected = "StructureMatcher::fit failed to reduce structure")]
    fn test_on_error_fail_panics_in_fit() {
        let invalid_structure = make_degenerate_lattice_structure(Element::Fe);
        let matcher = StructureMatcher::new()
            .with_primitive_cell(true)
            .with_on_error(crate::error::OnError::Fail);
        let _ = matcher.fit(&invalid_structure, &invalid_structure);
    }

    #[test]
    fn test_on_error_skip_does_not_panic_in_fit() {
        let invalid_structure = make_degenerate_lattice_structure(Element::Fe);
        let matcher = StructureMatcher::new()
            .with_primitive_cell(true)
            .with_on_error(crate::error::OnError::Skip);
        let result =
            std::panic::catch_unwind(|| matcher.fit(&invalid_structure, &invalid_structure));
        assert!(result.is_ok());
    }

    #[test]
    fn test_comparator_type_element() {
        // Test that element comparator ignores oxidation states
        // Use primitive_cell=false to preserve oxidation states (moyo strips them)
        let s1 = Structure::new(
            Lattice::cubic(5.64),
            vec![
                Species::new(Element::Fe, Some(2)),
                Species::new(Element::O, Some(-2)),
            ],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let s2 = Structure::new(
            Lattice::cubic(5.64),
            vec![
                Species::new(Element::Fe, Some(3)), // different oxidation state
                Species::new(Element::O, Some(-2)),
            ],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );

        // Species comparator should NOT match (different oxidation states)
        // Use primitive_cell=false since moyo's primitive reduction loses oxidation states
        let matcher_species = StructureMatcher::new()
            .with_comparator(ComparatorType::Species)
            .with_primitive_cell(false);
        assert!(!matcher_species.fit(&s1, &s2));

        // Element comparator should match (same elements)
        let matcher_element = StructureMatcher::new()
            .with_comparator(ComparatorType::Element)
            .with_primitive_cell(false);
        assert!(matcher_element.fit(&s1, &s2));
    }

    #[test]
    fn test_large_perturbation_no_match() {
        let s1 = make_nacl();
        let s2 = Structure::new(
            Lattice::cubic(5.64),
            vec![Species::neutral(Element::Na), Species::neutral(Element::Cl)],
            vec![
                Vector3::new(0.3, 0.3, 0.3), // large shift
                Vector3::new(0.5, 0.5, 0.5),
            ],
        );

        let matcher = StructureMatcher::new().with_site_pos_tol(0.1);
        assert!(
            !matcher.fit(&s1, &s2),
            "Large perturbation should not match"
        );
    }

    // =========================================================================
    // Degenerate lattice tests
    // =========================================================================

    #[test]
    fn test_fit_degenerate_lattice_zero_volume() {
        // Coplanar vectors - zero volume (degenerate)
        let lattice = Lattice::new(Matrix3::new(
            1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, // third vector in same plane
        ));
        let s = Structure::new(
            lattice,
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::zeros()],
        );
        let matcher = StructureMatcher::new();

        // Should return false gracefully (not panic) for degenerate lattice
        assert!(
            !matcher.fit(&s, &s),
            "Degenerate lattice (zero volume) should return false"
        );
    }

    #[test]
    fn test_fit_near_degenerate_lattice() {
        // Very flat lattice (small c parameter)
        let lattice = Lattice::from_parameters(5.0, 5.0, 0.1, 90.0, 90.0, 90.0);
        let s = Structure::new(
            lattice,
            vec![Species::neutral(Element::C)],
            vec![Vector3::zeros()],
        );
        let matcher = StructureMatcher::new().with_primitive_cell(false);

        // Near-degenerate but non-singular lattice should still self-match deterministically.
        assert!(
            matcher.fit(&s, &s),
            "Near-degenerate lattice should match itself"
        );
    }

    // =========================================================================
    // fit_preprocessed() direct tests
    // =========================================================================

    #[test]
    fn test_fit_preprocessed_skips_reduction() {
        let s1 = make_fcc_conventional(Element::Cu, 3.6);
        let s2 = make_fcc_conventional(Element::Cu, 3.65);
        let matcher = StructureMatcher::new();

        // Manually reduce
        let r1 = matcher.reduce_structure(&s1);
        let r2 = matcher.reduce_structure(&s2);

        // fit_preprocessed should work on already-reduced structures
        assert!(
            matcher.fit_preprocessed(&r1, &r2),
            "Preprocessed FCC structures should match"
        );
    }

    #[test]
    fn test_reduce_structure_produces_niggli_cell() {
        let fcc = make_fcc_conventional(Element::Cu, 3.6);
        let matcher = StructureMatcher::new();
        let reduced = matcher.reduce_structure(&fcc);

        // Reduced cell should have fewer or equal sites (FCC -> primitive)
        assert!(
            reduced.num_sites() <= fcc.num_sites(),
            "Reduced structure should have <= sites"
        );
        // Volume should be preserved or reduced by integer factor
        let vol_ratio = fcc.lattice.volume() / reduced.lattice.volume();
        assert!(
            (vol_ratio.round() - vol_ratio).abs() < 0.01,
            "Volume ratio should be close to integer: {vol_ratio}"
        );
    }

    #[test]
    fn test_reduce_structure_idempotent() {
        let s = make_bcc(Element::Fe, 2.87);
        let matcher = StructureMatcher::new();
        let r1 = matcher.reduce_structure(&s);
        let r2 = matcher.reduce_structure(&r1);

        // Reducing twice should give same result
        assert_eq!(
            r1.num_sites(),
            r2.num_sites(),
            "Reducing twice should preserve site count"
        );
        assert!(
            (r1.lattice.volume() - r2.lattice.volume()).abs() < 1e-6,
            "Reducing twice should preserve volume"
        );
    }

    // =========================================================================
    // Extreme tolerance tests
    // =========================================================================

    #[test]
    fn test_fit_very_small_site_tolerance_strict() {
        // Use multi-atom structure (BCC) so relative positions matter
        let s1 = make_bcc(Element::Fe, 4.0);
        // Create perturbed structure with significant relative shift
        let s2 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.7)], // shifted from 0.5
        );
        let matcher = StructureMatcher::new()
            .with_site_pos_tol(0.01)
            .with_primitive_cell(false); // keep multi-atom structure

        // Small tolerance should reject significant perturbation
        assert!(
            !matcher.fit(&s1, &s2),
            "Small tolerance should reject perturbation"
        );
        // Identical should still match
        assert!(
            matcher.fit(&s1, &s1),
            "Identical structures should match with small tolerance"
        );
    }

    #[test]
    fn test_fit_very_large_tolerance_permissive() {
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let s2 = make_simple_cubic(Element::Fe, 6.0); // 50% larger

        let matcher = StructureMatcher::new()
            .with_site_pos_tol(1.0)
            .with_latt_len_tol(0.5)
            .with_scale(false); // Don't scale volumes

        // Very large tolerance might match very different structures - tests boundary behavior
        let _ = matcher.fit(&s1, &s2);
    }

    #[test]
    fn test_fit_zero_angle_tolerance() {
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let s2 = Structure::new(
            Lattice::from_parameters(4.0, 4.0, 4.0, 90.0, 90.0, 91.0), // 1° off
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::zeros()],
        );
        let matcher = StructureMatcher::new().with_angle_tol(0.0);

        // Zero angle tolerance should reject 1° deviation
        assert!(
            !matcher.fit(&s1, &s2),
            "Zero angle tolerance should reject 1° deviation"
        );
    }

    // =========================================================================
    // fit_anonymous() edge cases
    // =========================================================================

    #[test]
    fn test_fit_anonymous_many_elements_stress() {
        // 7 elements = 5040 permutations (moderate stress test)
        let lattice = Lattice::cubic(14.0);
        let elements = [
            Element::Li,
            Element::Na,
            Element::K,
            Element::Rb,
            Element::Cs,
            Element::Fr,
            Element::Be,
        ];
        let species: Vec<_> = elements.iter().map(|&e| Species::neutral(e)).collect();
        let coords: Vec<_> = (0..7)
            .map(|i| Vector3::new(i as f64 * 0.14, 0.0, 0.0))
            .collect();
        let s1 = Structure::new(lattice.clone(), species.clone(), coords.clone());

        // Same structure with elements reversed (permuted)
        let species2: Vec<_> = elements
            .iter()
            .rev()
            .map(|&e| Species::neutral(e))
            .collect();
        let s2 = Structure::new(lattice, species2, coords);

        let matcher = StructureMatcher::new().with_primitive_cell(false);
        // Should find a matching permutation within reasonable time
        assert!(
            matcher.fit_anonymous(&s1, &s2, None),
            "fit_anonymous should handle 7 elements (5040 permutations)"
        );
    }

    #[test]
    fn test_fit_anonymous_works_with_any_comparator() {
        // fit_anonymous should work regardless of matcher's comparator_type setting
        let s = make_simple_cubic(Element::Fe, 4.0);

        // Works with default Species comparator
        let matcher_species = StructureMatcher::new();
        assert!(matcher_species.fit_anonymous(&s, &s, None));

        // Works with Element comparator too
        let matcher_element = StructureMatcher::new().with_comparator(ComparatorType::Element);
        assert!(matcher_element.fit_anonymous(&s, &s, None));
    }

    #[test]
    fn test_fit_anonymous_ignores_oxidation_states() {
        // fit_anonymous should ignore oxidation states and match based on elements only
        // Use primitive_cell=false to preserve oxidation states through processing
        let s1 = Structure::new(
            Lattice::cubic(5.64),
            vec![
                Species::new(Element::Na, Some(1)),
                Species::new(Element::Cl, Some(-1)),
            ],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let s2 = Structure::new(
            Lattice::cubic(5.64),
            vec![
                Species::new(Element::Mg, Some(2)), // Different oxidation state
                Species::new(Element::O, Some(-2)), // Different oxidation state
            ],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );

        // Should match anonymously (same rocksalt prototype)
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            matcher.fit_anonymous(&s1, &s2, None),
            "fit_anonymous should ignore oxidation states and match NaCl with MgO"
        );
    }

    #[test]
    fn test_fit_anonymous_predefined_metal_nonmetal() {
        let nacl = make_nacl();
        let mgo = Structure::new(
            Lattice::cubic(4.21),
            vec![Species::neutral(Element::Mg), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(matcher.fit_anonymous(
            &nacl,
            &mgo,
            Some(AnonymousMatchMode::Predefined(
                AnonymousClassMapping::MetalNonMetal,
            ))
        ));
    }

    #[test]
    fn test_fit_anonymous_mapped_custom_classes() {
        let first_structure = Structure::new(
            Lattice::cubic(5.0),
            vec![
                Species::neutral(Element::Ca),
                Species::neutral(Element::Al),
                Species::neutral(Element::Cl),
                Species::neutral(Element::Cl),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
                Vector3::new(0.75, 0.75, 0.75),
            ],
        );
        let second_structure = Structure::new(
            Lattice::cubic(5.2),
            vec![
                Species::neutral(Element::Li),
                Species::neutral(Element::Li),
                Species::neutral(Element::Br),
                Species::neutral(Element::Br),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
                Vector3::new(0.75, 0.75, 0.75),
            ],
        );

        let class_mapping = HashMap::from([
            (Element::Ca, "C".to_string()),
            (Element::Al, "C".to_string()),
            (Element::Cl, "X".to_string()),
            (Element::Li, "C".to_string()),
            (Element::Br, "X".to_string()),
        ]);
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            !matcher.fit_anonymous(&first_structure, &second_structure, None),
            "Element-permutation mode should fail for 3 elements vs 2 elements",
        );
        assert!(matcher.fit_anonymous(
            &first_structure,
            &second_structure,
            Some(AnonymousMatchMode::Custom(&class_mapping)),
        ));
    }

    #[test]
    fn test_fit_anonymous_mapped_fails_when_element_unmapped() {
        let class_mapping = HashMap::from([(Element::Na, "C".to_string())]);
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(!matcher.fit_anonymous(
            &make_nacl(),
            &make_nacl(),
            Some(AnonymousMatchMode::Custom(&class_mapping)),
        ));
    }

    #[test]
    fn test_get_structure_distance_anonymous_mapped_returns_none_for_unmapped() {
        let class_mapping = HashMap::from([(Element::Na, "C".to_string())]);
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            matcher
                .get_structure_distance_anonymous_mapped(&make_nacl(), &make_nacl(), &class_mapping)
                .is_none()
        );
    }

    #[test]
    fn test_fit_anonymous_explicit_element_permutation_mode_matches_default() {
        let nacl = make_nacl();
        let mgo = Structure::new(
            Lattice::cubic(4.21),
            vec![Species::neutral(Element::Mg), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        let default_result = matcher.fit_anonymous(&nacl, &mgo, None);
        let explicit_mode_result =
            matcher.fit_anonymous(&nacl, &mgo, Some(AnonymousMatchMode::ElementPermutation));
        assert_eq!(default_result, explicit_mode_result);
        assert!(default_result);
    }

    #[test]
    fn test_anonymous_class_mapping_from_name_aliases() {
        assert_eq!(
            AnonymousClassMapping::from_name("ACX"),
            Some(AnonymousClassMapping::Acx)
        );
        assert_eq!(
            AnonymousClassMapping::from_name("cea"),
            Some(AnonymousClassMapping::Cea)
        );
        assert_eq!(
            AnonymousClassMapping::from_name("metal/non-metal"),
            Some(AnonymousClassMapping::MetalNonMetal)
        );
        assert_eq!(
            AnonymousClassMapping::from_name("metal_nonmetal"),
            Some(AnonymousClassMapping::MetalNonMetal)
        );
        assert_eq!(
            AnonymousClassMapping::from_name("metal_non_metal"),
            Some(AnonymousClassMapping::MetalNonMetal)
        );
        assert_eq!(AnonymousClassMapping::from_name("unknown"), None);
    }

    #[test]
    fn test_fit_anonymous_predefined_acx_fails_for_uncovered_elements() {
        let fe = make_simple_cubic(Element::Fe, 4.0);
        let cu = make_simple_cubic(Element::Cu, 4.0);
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(!matcher.fit_anonymous(
            &fe,
            &cu,
            Some(AnonymousMatchMode::Predefined(AnonymousClassMapping::Acx)),
        ));
    }

    #[test]
    fn test_fit_anonymous_predefined_metal_nonmetal_covers_isotopes() {
        let h2o = Structure::new(
            Lattice::cubic(5.0),
            vec![
                Species::neutral(Element::H),
                Species::neutral(Element::H),
                Species::neutral(Element::O),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
            ],
        );
        let d2o = Structure::new(
            Lattice::cubic(5.0),
            vec![
                Species::neutral(Element::D),
                Species::neutral(Element::D),
                Species::neutral(Element::O),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
            ],
        );
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        assert!(matcher.fit_anonymous(
            &h2o,
            &d2o,
            Some(AnonymousMatchMode::Predefined(
                AnonymousClassMapping::MetalNonMetal,
            )),
        ));
    }

    // =========================================================================
    // Pymatgen Edge Case Tests (ported from pymatgen test suite)
    // =========================================================================

    #[test]
    fn test_matching_edge_cases() {
        let matcher = StructureMatcher::new().with_primitive_cell(false);

        // Out-of-cell sites: 0.98 ≈ -0.02 (wrapped)
        let s1 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.98, 0.0, 0.0)],
        );
        let s2 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(-0.02, 0.0, 0.0)],
        );
        assert!(matcher.fit(&s1, &s2), "Wrapped coords should match");

        // Site shuffling: order shouldn't matter
        let s3 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::O)],
            vec![Vector3::zeros(), Vector3::new(0.5, 0.5, 0.5)],
        );
        let s4 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::O), Species::neutral(Element::Fe)],
            vec![Vector3::new(0.5, 0.5, 0.5), Vector3::zeros()],
        );
        assert!(matcher.fit(&s3, &s4), "Site order shouldn't matter");

        // Large translation should fail
        let s5 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![Vector3::zeros(), Vector3::new(0.5, 0.5, 0.5)],
        );
        let s6 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![Vector3::zeros(), Vector3::new(0.9, 0.9, 0.7)],
        );
        assert!(
            !matcher.with_site_pos_tol(0.3).fit(&s5, &s6),
            "Large shift should fail"
        );
    }

    #[test]
    fn test_scaling_and_comparators() {
        // scale=false is more restrictive
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let s2 = make_simple_cubic(Element::Fe, 4.5);
        let fit_scale = StructureMatcher::new().fit(&s1, &s2);
        let fit_no_scale = StructureMatcher::new().with_scale(false).fit(&s1, &s2);
        assert!(!fit_no_scale || fit_scale, "no_scale more restrictive");

        // Element comparator ignores oxidation states
        let s3 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::new(Element::Fe, Some(2))],
            vec![Vector3::zeros()],
        );
        let s4 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::new(Element::Fe, Some(3))],
            vec![Vector3::zeros()],
        );
        let m_species = StructureMatcher::new().with_primitive_cell(false);
        let m_elem = m_species.clone().with_comparator(ComparatorType::Element);
        assert!(
            !m_species.fit(&s3, &s4),
            "Species comparator rejects diff oxi"
        );
        assert!(m_elem.fit(&s3, &s4), "Element comparator accepts same elem");
    }

    #[test]
    fn test_supercell_matching() {
        let s1 = make_simple_cubic(Element::Fe, 4.0);
        let coords: Vec<_> = (0..8)
            .map(|i| {
                Vector3::new(
                    (i & 1) as f64 * 0.5,
                    ((i >> 1) & 1) as f64 * 0.5,
                    ((i >> 2) & 1) as f64 * 0.5,
                )
            })
            .collect();
        let s2 = Structure::new(
            Lattice::cubic(8.0),
            vec![Species::neutral(Element::Fe); 8],
            coords,
        );

        assert!(
            !StructureMatcher::new()
                .with_primitive_cell(false)
                .fit(&s1, &s2)
        );
        assert!(
            StructureMatcher::new()
                .with_primitive_cell(true)
                .fit(&s1, &s2)
        );
    }

    #[test]
    fn test_attempt_supercell_matches_in_core_paths() {
        let primitive = make_simple_cubic(Element::Fe, 4.0);
        let supercell_coords: Vec<_> = (0..8)
            .map(|idx| {
                Vector3::new(
                    (idx & 1) as f64 * 0.5,
                    ((idx >> 1) & 1) as f64 * 0.5,
                    ((idx >> 2) & 1) as f64 * 0.5,
                )
            })
            .collect();
        let supercell = Structure::new(
            Lattice::cubic(8.0),
            vec![Species::neutral(Element::Fe); 8],
            supercell_coords,
        );

        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);

        assert!(
            matcher.fit(&primitive, &supercell),
            "attempt_supercell should match primitive and supercell in fit() path"
        );

        let reduced_primitive = matcher.reduce_structure(&primitive);
        let reduced_supercell = matcher.reduce_structure(&supercell);
        assert!(
            matcher.fit_preprocessed(&reduced_primitive, &reduced_supercell),
            "attempt_supercell should match primitive and supercell in fit_preprocessed() path"
        );
    }

    #[test]
    fn test_attempt_supercell_matches_nondiagonal_supercell() {
        let primitive = make_simple_cubic(Element::Fe, 4.0);
        let nondiagonal_supercell = primitive
            .make_supercell([[2, 1, 0], [0, 2, 0], [0, 0, 1]])
            .unwrap();
        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);

        assert!(
            matcher.fit(&primitive, &nondiagonal_supercell),
            "attempt_supercell should match non-diagonal supercells"
        );
    }

    #[test]
    fn test_attempt_supercell_matches_factor_above_ten() {
        let primitive = make_simple_cubic(Element::Fe, 4.0);
        let larger_supercell = primitive.make_supercell_diag([11, 1, 1]);
        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);

        assert!(
            matcher.fit(&primitive, &larger_supercell),
            "attempt_supercell should match valid supercells even when factor > 10"
        );
    }

    #[test]
    fn test_attempt_supercell_is_symmetric_for_large_factor() {
        let primitive = make_simple_cubic(Element::Fe, 4.0);
        let larger_supercell = primitive.make_supercell_diag([11, 1, 1]);
        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);

        assert!(matcher.fit(&primitive, &larger_supercell));
        assert!(matcher.fit(&larger_supercell, &primitive));
    }

    #[test]
    fn test_attempt_supercell_rejects_non_integer_site_ratio() {
        let two_site_structure = make_bcc(Element::Fe, 2.87);
        let three_site_structure = Structure::new(
            Lattice::cubic(4.0),
            vec![
                Species::neutral(Element::Fe),
                Species::neutral(Element::Fe),
                Species::neutral(Element::Fe),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.0),
                Vector3::new(0.5, 0.0, 0.5),
            ],
        );
        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);

        assert!(!matcher.fit(&two_site_structure, &three_site_structure));
    }

    #[test]
    fn test_fit_preprocessed_rejects_non_integer_site_ratio() {
        let two_site_structure = make_bcc(Element::Fe, 2.87);
        let three_site_structure = Structure::new(
            Lattice::cubic(4.0),
            vec![
                Species::neutral(Element::Fe),
                Species::neutral(Element::Fe),
                Species::neutral(Element::Fe),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.0),
                Vector3::new(0.5, 0.0, 0.5),
            ],
        );
        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_attempt_supercell(true);
        let reduced_two_site = matcher.reduce_structure(&two_site_structure);
        let reduced_three_site = matcher.reduce_structure(&three_site_structure);

        assert!(!matcher.fit_preprocessed(&reduced_two_site, &reduced_three_site));
    }

    #[test]
    fn test_rms_distance() {
        let s = make_simple_cubic(Element::Fe, 4.0);
        let matcher = StructureMatcher::new().with_primitive_cell(false);
        // Identical → RMS ≈ 0
        if let Some((rms, _)) = matcher.get_rms_dist(&s, &s) {
            assert!(rms < 1e-10);
        }
        // Small perturbation → small RMS
        let s2 = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.01, 0.0, 0.0)],
        );
        if let Some((rms, _)) = matcher.with_site_pos_tol(0.5).get_rms_dist(&s, &s2) {
            assert!(rms < 0.1);
        }
    }

    #[test]
    fn test_composition_hash_respects_comparator_type() {
        // Create two structures: same elements, different oxidation states
        let fe2 = Species::new(Element::Fe, Some(2));
        let fe3 = Species::new(Element::Fe, Some(3));
        let o2 = Species::new(Element::O, Some(-2));

        // FeO with Fe2+
        let s1 = Structure::new(
            Lattice::cubic(4.0),
            vec![fe2, o2],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        // FeO with Fe3+
        let s2 = Structure::new(
            Lattice::cubic(4.0),
            vec![fe3, o2],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );

        // Element comparator: same hash (oxidation states ignored)
        let elem_matcher = StructureMatcher::new().with_comparator(ComparatorType::Element);
        assert_eq!(
            elem_matcher.composition_hash(&s1),
            elem_matcher.composition_hash(&s2),
            "Element comparator should give same hash for same elements"
        );

        // Species comparator: different hash (oxidation states matter)
        let species_matcher = StructureMatcher::new().with_comparator(ComparatorType::Species);
        assert_ne!(
            species_matcher.composition_hash(&s1),
            species_matcher.composition_hash(&s2),
            "Species comparator should give different hash for different oxidation states"
        );
    }

    // =========================================================================
    // get_structure_distance() tests
    // =========================================================================

    #[test]
    fn test_structure_distance_basic_properties() {
        // Tests: identical=0, symmetry, ranking (identical < shifted)
        // Disable primitive_cell since moyo standardizes NaCl to canonical Wyckoff
        // positions, erasing the rigid-body shift and producing distance=0
        let s1 = make_nacl();
        let s2 = make_nacl_shifted();
        let matcher = StructureMatcher::new().with_primitive_cell(false);

        let d_self = matcher.get_structure_distance(&s1, &s1);
        let d12 = matcher.get_structure_distance(&s1, &s2);
        let d21 = matcher.get_structure_distance(&s2, &s1);

        assert!(d_self < 1e-10, "d(s,s) should be ~0, got {d_self}");
        assert!(
            (d12 - d21).abs() < 1e-10,
            "Should be symmetric: {d12} vs {d21}"
        );
        assert!(
            d_self < d12,
            "Identical ({d_self}) should be < shifted ({d12})"
        );
        assert!(
            d12 < 1.0,
            "Similar structures should have small distance: {d12}"
        );
    }

    #[test]
    fn test_structure_distance_composition() {
        // Different compositions should return finite distance, larger than same composition
        let nacl = make_nacl();
        let fe = make_simple_cubic(Element::Fe, 4.0);
        let cuo = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Cu), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        // NaBr with SAME geometry as NaCl (tests composition_weight in isolation)
        let nabr_same_geom = Structure::new(
            Lattice::cubic(5.64), // Same as NaCl
            vec![Species::neutral(Element::Na), Species::neutral(Element::Br)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );
        let matcher = StructureMatcher::new();

        let d_same = matcher.get_structure_distance(&nacl, &nacl);
        let d_disjoint = matcher.get_structure_distance(&nacl, &cuo);
        let d_partial = matcher.get_structure_distance(&nacl, &nabr_same_geom);
        let d_no_overlap = matcher.get_structure_distance(&nacl, &fe);

        assert!(d_disjoint.is_finite() && d_disjoint > d_same);
        assert!(d_no_overlap.is_finite() && d_no_overlap > 0.0);
        // Same geometry but partial overlap: composition_distance = 1 - 1/3 ≈ 0.667
        // With COMPOSITION_WEIGHT = 5.0, expected contribution ≈ 3.33
        // Geometric distance is small but non-zero (~2.2) due to normalization
        assert!(
            d_partial > 3.0,
            "Same geometry + partial overlap should have composition penalty: {d_partial}"
        );
        // Partial should be less than disjoint (DISJOINT_COMPOSITION_DISTANCE = 1e9)
        assert!(
            d_partial < d_disjoint,
            "Partial ({d_partial}) < disjoint ({d_disjoint})"
        );
    }

    #[test]
    fn test_structure_distance_empty() {
        let empty = Structure::new(Lattice::cubic(4.0), vec![], vec![]);
        let non_empty = make_simple_cubic(Element::Fe, 4.0);
        let matcher = StructureMatcher::new();

        assert!(matcher.get_structure_distance(&empty, &empty) < 1e-10);
        let d = matcher.get_structure_distance(&empty, &non_empty);
        assert!((d - EMPTY_STRUCTURE_DISTANCE).abs() < 1e-10, "Got {d}");
    }

    #[test]
    fn test_structure_distance_on_error_fail_returns_finite_for_degenerate_structures() {
        let degenerate = make_degenerate_lattice_structure(Element::Fe);
        let matcher_fail = StructureMatcher::new()
            .with_primitive_cell(true)
            .with_on_error(crate::error::OnError::Fail);
        let matcher_skip = StructureMatcher::new()
            .with_primitive_cell(true)
            .with_on_error(crate::error::OnError::Skip);

        let result = std::panic::catch_unwind(|| {
            matcher_fail.get_structure_distance(&degenerate, &degenerate)
        });
        assert!(
            result.is_ok(),
            "get_structure_distance should not panic even when on_error=Fail"
        );
        let distance = result.unwrap();
        let distance_skip = matcher_skip.get_structure_distance(&degenerate, &degenerate);
        assert!(
            distance.is_finite(),
            "distance should be finite, got {distance}"
        );
        assert!(
            (distance - distance_skip).abs() < 1e-10,
            "on_error policy should not affect get_structure_distance: fail={distance}, skip={distance_skip}"
        );
    }

    #[test]
    fn test_structure_distance_pbc_wrapping() {
        // Atom at (0.95,0.95,0.95) should be CLOSER to origin than (0.3,0.3,0.3) via PBC
        let lattice = Lattice::cubic(4.0);
        let at_origin = Structure::new(
            lattice.clone(),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let near_corner = Structure::new(
            lattice.clone(),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.95, 0.95, 0.95)],
        );
        let at_030 = Structure::new(
            lattice,
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.3, 0.3, 0.3)],
        );
        let matcher = StructureMatcher::new();

        let d_corner = matcher.get_structure_distance(&at_origin, &near_corner);
        let d_030 = matcher.get_structure_distance(&at_origin, &at_030);

        assert!(
            d_corner < d_030,
            "PBC failed: {d_corner} should be < {d_030}"
        );
    }

    #[test]
    fn test_structure_distance_hexagonal_pbc() {
        // Non-orthogonal lattice (hexagonal, gamma=120°) - PBC must work correctly
        let a = 3.0;
        let hex = Matrix3::new(
            a,
            0.0,
            0.0,
            -a / 2.0,
            a * 3.0_f64.sqrt() / 2.0,
            0.0,
            0.0,
            0.0,
            5.0,
        );
        let species = vec![Species::neutral(Element::Mg), Species::neutral(Element::O)];
        let o_pos = Vector3::new(0.333, 0.667, 0.5);

        let hex_origin = Structure::new(
            Lattice::new(hex),
            species.clone(),
            vec![Vector3::new(0.0, 0.0, 0.0), o_pos],
        );
        let hex_boundary = Structure::new(
            Lattice::new(hex),
            species,
            vec![Vector3::new(0.95, 0.0, 0.0), o_pos], // Near periodic boundary
        );
        let matcher = StructureMatcher::new();

        // Identical should be 0
        assert!(matcher.get_structure_distance(&hex_origin, &hex_origin) < 1e-10);

        // Boundary atom should wrap to be close (fractional 0.95 wraps to -0.05)
        let d = matcher.get_structure_distance(&hex_origin, &hex_boundary);
        assert!(d < 1.0, "Hexagonal PBC failed: {d} should be < 1.0");

        // Symmetry must hold
        let d_rev = matcher.get_structure_distance(&hex_boundary, &hex_origin);
        assert!((d - d_rev).abs() < 1e-10, "Asymmetric: {d} vs {d_rev}");
    }

    #[test]
    fn test_structure_distance_symmetry_various_cases() {
        // Tests d(A,B) = d(B,A) across: equal sizes, unequal sizes, different lattice shapes
        let matcher = StructureMatcher::new();

        // Case 1: Different lattice shapes (cubic vs tetragonal)
        let cubic = make_simple_cubic(Element::Fe, 4.0);
        let tetragonal = Structure::new(
            Lattice::new(Matrix3::new(4.0, 0.0, 0.0, 0.0, 4.0, 0.0, 0.0, 0.0, 6.0)),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );

        // Case 2: Unequal sizes (1 vs 3 sites, same lattice)
        let large = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe); 3],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.0, 0.0),
                Vector3::new(0.0, 0.5, 0.0),
            ],
        );

        // Case 3: Different lattices + unequal sizes (most rigorous)
        let hex_large = Structure::new(
            Lattice::new(Matrix3::new(4.0, 0.0, 0.0, -2.0, 3.464, 0.0, 0.0, 0.0, 6.0)),
            vec![Species::neutral(Element::Fe); 2],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.333, 0.667, 0.5)],
        );

        for (name, s1, s2) in [
            ("cubic-tetragonal", &cubic, &tetragonal),
            ("equal-unequal", &cubic, &large),
            ("cubic-hexagonal", &cubic, &hex_large),
        ] {
            let d12 = matcher.get_structure_distance(s1, s2);
            let d21 = matcher.get_structure_distance(s2, s1);
            assert!(d12.is_finite() && d12 >= 0.0, "{name}: non-negative");
            assert!((d12 - d21).abs() < 1e-10, "{name}: {d12} != {d21}");
        }
    }

    #[test]
    fn test_structure_distance_different_lattices_same_frac_coords() {
        // Regression test: structures with identical fractional coordinates but different
        // lattice shapes should NOT have zero geometric distance.
        // Before the fix, subtracting fractional coords directly gave zero distance
        // because frac_diff = (0,0,0) - (0,0,0) = (0,0,0) regardless of lattice shape.
        let matcher = StructureMatcher::new();

        // Same fractional coords (0,0,0) but different lattices
        let cubic = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let tetragonal = Structure::new(
            Lattice::new(Matrix3::new(4.0, 0.0, 0.0, 0.0, 4.0, 0.0, 0.0, 0.0, 8.0)), // c = 2a
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );

        // Both have atom at origin -> same Cartesian position -> distance should be ~0
        let d_origin = matcher.get_structure_distance(&cubic, &tetragonal);
        assert!(
            d_origin < 0.1,
            "Origin atoms should have small distance: {d_origin}"
        );

        // Now test with atom at (0.5, 0.5, 0.5) in each
        // Cubic: Cartesian = (2, 2, 2)
        // Tetragonal: Cartesian = (2, 2, 4) - different!
        let cubic_center = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.5, 0.5, 0.5)],
        );
        let tetragonal_center = Structure::new(
            Lattice::new(Matrix3::new(4.0, 0.0, 0.0, 0.0, 4.0, 0.0, 0.0, 0.0, 8.0)),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.5, 0.5, 0.5)],
        );

        let d_center = matcher.get_structure_distance(&cubic_center, &tetragonal_center);
        // Cartesian diff = (0, 0, 2) Å between the two center positions.
        // After PBC wrapping and normalization, expect meaningful non-zero distance.
        // Before the fix, subtracting frac coords directly gave ~0 distance.
        assert!(
            d_center > 0.1,
            "Same frac coords in different lattices should have non-zero distance: {d_center}"
        );

        // Verify symmetry holds
        let d_center_rev = matcher.get_structure_distance(&tetragonal_center, &cubic_center);
        assert!(
            (d_center - d_center_rev).abs() < 1e-10,
            "Distance should be symmetric: {d_center} vs {d_center_rev}"
        );
    }

    // =========================================================================
    // pymatgen-compatible Oxidation State Tests
    // =========================================================================

    #[test]
    fn test_oxi_state_matching_pymatgen_compatible() {
        // Matches pymatgen test_oxi: same structure with different oxidation states
        // Species comparator should NOT match, Element comparator SHOULD match

        // Li2O antifluorite: Li at (1/4, 1/4, 1/4) etc., O at (0,0,0)
        let lattice = Lattice::cubic(4.619);
        let coords = vec![
            Vector3::new(0.25, 0.25, 0.25),
            Vector3::new(0.75, 0.75, 0.75),
            Vector3::new(0.0, 0.0, 0.0),
        ];

        let li2o_neutral = Structure::new(
            lattice.clone(),
            vec![
                Species::neutral(Element::Li),
                Species::neutral(Element::Li),
                Species::neutral(Element::O),
            ],
            coords.clone(),
        );
        let li2o_charged = Structure::new(
            lattice,
            vec![
                Species::new(Element::Li, Some(1)),
                Species::new(Element::Li, Some(1)),
                Species::new(Element::O, Some(-2)),
            ],
            coords,
        );

        // Species comparator: should NOT match (different oxidation states)
        let species_matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_comparator(ComparatorType::Species);
        assert!(
            !species_matcher.fit(&li2o_neutral, &li2o_charged),
            "Species comparator should reject different oxidation states"
        );

        // Element comparator: SHOULD match (same elements, ignores oxidation states)
        let element_matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_comparator(ComparatorType::Element);
        assert!(
            element_matcher.fit(&li2o_neutral, &li2o_charged),
            "Element comparator should match same elements regardless of oxidation state"
        );
    }

    #[test]
    fn test_primitive_cell_supercell_matching_pymatgen() {
        // Matches pymatgen test_primitive: primitive cell should match its supercell
        let primitive = make_simple_cubic(Element::Fe, 4.0);

        // Create a 2x2x2 supercell using itertools-style iteration
        let (supercell_species, supercell_coords): (Vec<_>, Vec<_>) = (0..8)
            .map(|idx| {
                let (idx_x, idx_y, idx_z) = (idx / 4, (idx / 2) % 2, idx % 2);
                (
                    Species::neutral(Element::Fe),
                    Vector3::new(idx_x as f64 * 0.5, idx_y as f64 * 0.5, idx_z as f64 * 0.5),
                )
            })
            .unzip();
        let supercell = Structure::new(Lattice::cubic(8.0), supercell_species, supercell_coords);

        // Without primitive cell reduction, they shouldn't match
        let no_prim = StructureMatcher::new().with_primitive_cell(false);
        assert!(
            !no_prim.fit(&primitive, &supercell),
            "Without primitive_cell, different sizes shouldn't match directly"
        );

        // With primitive cell reduction, they should match
        let with_prim = StructureMatcher::new().with_primitive_cell(true);
        assert!(
            with_prim.fit(&primitive, &supercell),
            "With primitive_cell, supercell should reduce to match primitive"
        );
    }

    #[test]
    fn test_species_comparator_default_primitive_cell_keeps_oxidation_semantics() {
        let lattice = Lattice::cubic(4.0);
        let s_fe2 = Structure::new(
            lattice.clone(),
            vec![Species::new(Element::Fe, Some(2))],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let s_fe3 = Structure::new(
            lattice,
            vec![Species::new(Element::Fe, Some(3))],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );

        let matcher = StructureMatcher::new().with_comparator(ComparatorType::Species);
        assert!(
            !matcher.fit(&s_fe2, &s_fe3),
            "Species comparator must reject different oxidation states even with primitive_cell=true"
        );
    }

    #[test]
    fn test_non_periodic_matching_does_not_wrap_coordinates() {
        let mut non_periodic_lattice = Lattice::cubic(4.0);
        non_periodic_lattice.pbc = [false, false, false];

        let site_origin = Structure::new(
            non_periodic_lattice.clone(),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let site_shifted = Structure::new(
            non_periodic_lattice,
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(1.0, 0.0, 0.0)],
        );
        assert!((site_origin.frac_coords[0].x - 0.0).abs() < 1e-12);
        assert!((site_shifted.frac_coords[0].x - 1.0).abs() < 1e-12);

        let matcher = StructureMatcher::new()
            .with_primitive_cell(false)
            .with_site_pos_tol(1e-3);
        assert!(
            !matcher.fit(&site_origin, &site_shifted),
            "Non-periodic matching should not wrap coordinates across unit boundaries"
        );
    }

    #[test]
    fn test_primitive_reduction_preserves_non_periodic_pbc() {
        let mut non_periodic_lattice = Lattice::cubic(4.0);
        non_periodic_lattice.pbc = [false, false, false];

        let site_origin = Structure::new(
            non_periodic_lattice.clone(),
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(0.0, 0.0, 0.0)],
        );
        let site_shifted = Structure::new(
            non_periodic_lattice,
            vec![Species::neutral(Element::Fe)],
            vec![Vector3::new(1.0, 0.0, 0.0)],
        );

        let matcher = StructureMatcher::new()
            .with_primitive_cell(true)
            .with_site_pos_tol(1e-3);
        let reduced_origin = matcher.reduce_structure(&site_origin);
        assert_eq!(reduced_origin.lattice.pbc, [false, false, false]);
        assert!(
            !matcher.fit(&site_origin, &site_shifted),
            "primitive reduction must preserve non-periodic PBC semantics"
        );
    }

    /// Single-atom structure at given fractional position.
    fn atom_at(latt: Lattice, elem: Element, frac: Vector3<f64>) -> Structure {
        Structure::new(latt, vec![Species::neutral(elem)], vec![frac])
    }

    #[test]
    fn test_structure_distance_respects_non_periodic_pbc() {
        // Frac coords 0.0 and 0.9 in 10 Å cell: periodic wraps (1 Å), non-periodic doesn't (9 Å)
        let periodic_latt = Lattice::cubic(10.0);
        let mut non_periodic_latt = Lattice::cubic(10.0);
        non_periodic_latt.pbc = [false, false, false];
        let origin = Vector3::new(0.0, 0.0, 0.0);
        let shifted = Vector3::new(0.9, 0.0, 0.0);

        let matcher = StructureMatcher::new().with_primitive_cell(false);
        let dist_periodic = matcher.get_structure_distance(
            &atom_at(periodic_latt.clone(), Element::Fe, origin),
            &atom_at(periodic_latt, Element::Fe, shifted),
        );
        let dist_non_periodic = matcher.get_structure_distance(
            &atom_at(non_periodic_latt.clone(), Element::Fe, origin),
            &atom_at(non_periodic_latt, Element::Fe, shifted),
        );

        assert!(
            dist_non_periodic > dist_periodic * 3.0,
            "Non-periodic distance ({dist_non_periodic:.4}) should be much larger than \
             periodic distance ({dist_periodic:.4}) — wrapping must be disabled for pbc=false"
        );
    }

    #[test]
    fn test_structure_distance_mixed_pbc_per_axis() {
        // Periodic in x only: x-shift wraps (small), y-shift doesn't (large)
        let mut latt = Lattice::cubic(10.0);
        latt.pbc = [true, false, false];
        let origin = Vector3::new(0.0, 0.0, 0.0);

        let matcher = StructureMatcher::new().with_primitive_cell(false);
        let base = atom_at(latt.clone(), Element::Cu, origin);
        let dist_x = matcher.get_structure_distance(
            &base,
            &atom_at(latt.clone(), Element::Cu, Vector3::new(0.9, 0.0, 0.0)),
        );
        let dist_y = matcher.get_structure_distance(
            &base,
            &atom_at(latt, Element::Cu, Vector3::new(0.0, 0.9, 0.0)),
        );

        assert!(
            dist_y > dist_x * 3.0,
            "Non-periodic y distance ({dist_y:.4}) should be much larger than \
             periodic x distance ({dist_x:.4})"
        );
    }

    #[test]
    fn test_structure_distance_asymmetric_pbc_is_order_independent() {
        // s1 is periodic, s2 is non-periodic. The distance must be the same
        // regardless of argument order so the source/target swap uses the
        // correct structure's PBC for wrapping.
        let mut periodic_latt = Lattice::cubic(10.0);
        periodic_latt.pbc = [true, true, true];
        let mut non_periodic_latt = Lattice::cubic(10.0);
        non_periodic_latt.pbc = [false, false, false];

        let shifted = Vector3::new(0.9, 0.0, 0.0);
        let origin = Vector3::new(0.0, 0.0, 0.0);

        let pbc_struct = Structure::new(
            periodic_latt,
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![origin, shifted],
        );
        let nopbc_struct = Structure::new(
            non_periodic_latt,
            vec![Species::neutral(Element::Fe), Species::neutral(Element::Fe)],
            vec![origin, shifted],
        );

        let matcher = StructureMatcher::new().with_primitive_cell(false);
        let dist_ab = matcher.get_structure_distance(&pbc_struct, &nopbc_struct);
        let dist_ba = matcher.get_structure_distance(&nopbc_struct, &pbc_struct);

        assert!(
            (dist_ab - dist_ba).abs() < 1e-10,
            "Distance must be order-independent: d(A,B)={dist_ab:.6} vs d(B,A)={dist_ba:.6}"
        );
    }

    #[test]
    fn test_anonymous_matching_different_stoichiometry() {
        // Anonymous matching should fail for different stoichiometries
        let matcher = StructureMatcher::new().with_primitive_cell(false);

        // AB structure (FeO-like)
        let ab = Structure::new(
            Lattice::cubic(4.0),
            vec![Species::neutral(Element::Fe), Species::neutral(Element::O)],
            vec![Vector3::new(0.0, 0.0, 0.0), Vector3::new(0.5, 0.5, 0.5)],
        );

        // A2B structure (Cu2S-like)
        let a2b = Structure::new(
            Lattice::cubic(4.0),
            vec![
                Species::neutral(Element::Cu),
                Species::neutral(Element::Cu),
                Species::neutral(Element::S),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
            ],
        );

        // AB2 structure (TiO2-like)
        let ab2 = Structure::new(
            Lattice::cubic(4.0),
            vec![
                Species::neutral(Element::Ti),
                Species::neutral(Element::O),
                Species::neutral(Element::O),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.25, 0.25, 0.0),
                Vector3::new(0.75, 0.75, 0.0),
            ],
        );

        // ABC structure (ternary)
        let abc = Structure::new(
            Lattice::cubic(4.0),
            vec![
                Species::neutral(Element::Li),
                Species::neutral(Element::Mn),
                Species::neutral(Element::O),
            ],
            vec![
                Vector3::new(0.0, 0.0, 0.0),
                Vector3::new(0.5, 0.5, 0.5),
                Vector3::new(0.25, 0.25, 0.25),
            ],
        );

        // Test all pairwise combinations of different stoichiometries
        let cases = [
            (&ab, &a2b, "AB vs A2B"),
            (&ab, &ab2, "AB vs AB2"),
            (&a2b, &ab2, "A2B vs AB2"),
            (&ab, &abc, "AB vs ABC"),
            (&a2b, &abc, "A2B vs ABC"),
        ];

        for (struct1, struct2, label) in cases {
            assert!(
                !matcher.fit_anonymous(struct1, struct2, None),
                "{label} should not match anonymously"
            );
        }
    }
}
