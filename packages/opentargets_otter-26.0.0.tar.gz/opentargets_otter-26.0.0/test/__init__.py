"""Tests for the Otter framework."""
