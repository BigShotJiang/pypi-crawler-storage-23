"""Synchronous storage backends and handle."""
