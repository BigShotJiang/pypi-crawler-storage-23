# Clouvel Pro: AI를 위한 문서 가이드라인

**Version:** 1.1 (2026-Q1 업데이트)
**Purpose:** AI 코딩 어시스턴트가 프로젝트를 완벽히 이해하도록 하는 문서 작성 가이드
**Philosophy:** "AI는 추측하지 않는다. 명시되지 않으면 할루시네이션한다."

---

## Q1 2026 변경사항

- **Skills 시스템**: Claude Code 2.1+ Skills frontmatter + hooks 지원
- **@include 규칙**: 바이너리 파일 자동 제외
- **크로스 플랫폼**: AGENTS.md AAIF 표준화 (60,000+ 프로젝트)
- **MCP Tool Search**: Lazy loading 도입

---

## 목차

1. [PRD (Product Requirements Document)](#1-prd-product-requirements-document)
2. [CLAUDE.md / AGENTS.md](#2-claudemd--agentsmd)
3. [README.md](#3-readmemd)
4. [ARCHITECTURE.md](#4-architecturemd)
5. [ADR (Architecture Decision Records)](#5-adr-architecture-decision-records)
6. [TECH_STACK.md](#6-tech_stackmd)
7. [API_SPEC.md](#7-api_specmd)
8. [TEST_PLAN.md](#8-test_planmd)
9. [ERROR_LOG.md](#9-error_logmd)
10. [CHANGELOG.md](#10-changelogmd)
11. [SECURITY.md](#11-securitymd)
12. [DEPLOYMENT.md](#12-deploymentmd)
13. [PROGRESS.md](#13-progressmd)
14. [문서 간 연결 규칙](#14-문서-간-연결-규칙)
15. [MCP 서버 설정 가이드](#15-mcp-서버-설정-가이드-v21)

---

# 1. PRD (Product Requirements Document)

## 1.1 목적

PRD는 AI에게 **"무엇을 만들어야 하는가"**를 알려주는 핵심 문서입니다.

```
PRD 없이 코딩 = 목적지 없이 운전
PRD가 모호함 = 잘못된 목적지로 운전
PRD가 명확함 = 정확한 네비게이션
```

## 1.2 AI가 PRD를 읽는 방식

```yaml
AI 처리 순서:
  1. "한 줄 정의" → 전체 맥락 파악
  2. "타겟 사용자" → 코드 복잡도/UX 수준 결정
  3. "기능 요구사항" → 함수/API 시그니처 도출
  4. "Out of Scope" → 구현하지 말아야 할 것 확인
  5. "비기능 요구사항" → 성능/보안 기준 적용
  6. "검증 기준" → 테스트 코드 생성
```

## 1.3 필수 섹션 + AI 행동

### 섹션 1: 메타 정보

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 버전 | ✅ | 변경 추적 불가, 이전 버전과 충돌 가능 |
| 상태 | ✅ | Draft인지 Approved인지 모름, 확정되지 않은 요구사항 구현 |
| 작성일 | ⚠️ | 정보의 최신성 판단 불가 |

```markdown
## 메타 정보
- **버전:** 1.2
- **상태:** Approved ← AI는 Approved만 구현
- **작성일:** 2026-02-01
- **최종 수정:** 2026-02-01
```

### 섹션 2: 한 줄 정의

**목적**: AI가 전체 프로젝트 맥락을 한 문장으로 파악

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 타겟 | ✅ | 사용자 수준 추측 (초보자? 전문가?) |
| 솔루션 | ✅ | 핵심 기능 범위 불명확 |
| 가치 | ✅ | 우선순위 판단 불가 |

```markdown
## DO ✅
> **[베트남 라이브커머스 셀러]**를 위한 **[AI 비디오 하이라이트 추출 도구]**로
> **[4시간 편집 → 30분으로 단축]**하는 가치를 제공한다.

## DON'T ❌
> 비디오 편집 도구입니다.
→ 누구를 위한? 무슨 가치? AI가 모든 걸 추측해야 함
```

### 섹션 3: 기능 요구사항

**목적**: AI가 정확한 함수 시그니처, 입출력, 에러 처리를 생성

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 기능 ID | ✅ | 참조/추적 불가 |
| 입력 스펙 | ✅ | 파라미터 타입 추측 → 런타임 에러 |
| 출력 스펙 | ✅ | 리턴 타입 추측 → 타입 불일치 |
| 에러 케이스 | ✅ | try-catch 누락, 에러 핸들링 없음 |
| 검증 기준 | ✅ | 테스트 코드 생성 불가 |

```markdown
## DO ✅ - 기능 상세 명세

### F001: 사용자 로그인

**입력:**
| 필드 | 타입 | 제약 | 필수 |
|------|------|------|------|
| email | string | RFC 5322, max 254자 | ✅ |
| password | string | 8-128자, 특수문자 1개 이상 | ✅ |
| remember_me | boolean | default: false | ❌ |

**출력 (성공):**
```json
{
  "access_token": "JWT, 15분 만료",
  "refresh_token": "UUID v4, 7일 만료",
  "user": {
    "id": "UUID",
    "email": "string",
    "created_at": "ISO 8601"
  }
}
```

**에러 케이스:**
| 코드 | 조건 | 응답 |
|------|------|------|
| 400 | 이메일 형식 오류 | `{"error": "INVALID_EMAIL_FORMAT"}` |
| 401 | 잘못된 자격증명 | `{"error": "INVALID_CREDENTIALS"}` ← 구체적 이유 노출 금지 |
| 429 | 5회/분 초과 | `{"error": "RATE_LIMITED", "retry_after": 60}` |
| 423 | 계정 잠금 (10회 실패) | `{"error": "ACCOUNT_LOCKED", "unlock_at": "ISO 8601"}` |

**검증 기준:**
- [ ] 유효한 자격증명 → 200 + 토큰 반환
- [ ] 잘못된 비밀번호 → 401 (구체적 이유 없이)
- [ ] 10회 연속 실패 → 423 + 30분 잠금
- [ ] 잠금 해제 후 → 정상 로그인 가능
- [ ] 응답 시간 < 200ms (p95)


## DON'T ❌

### 로그인 기능
- 이메일과 비밀번호로 로그인
- 로그인 실패 시 에러 메시지 표시
- 빠르게 응답해야 함

→ AI 결과: 에러 코드 임의 지정, 보안 고려 없음, 성능 기준 없음
```

### 섹션 4: 비기능 요구사항

**목적**: AI가 성능, 보안, 확장성 기준을 코드에 반영

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 성능 기준 | ✅ | 최적화 없음, N+1 쿼리 가능 |
| 보안 기준 | ✅ | 기본 보안만, 취약점 가능 |
| 확장성 기준 | ⚠️ | 현재 규모만 고려 |

```markdown
## DO ✅

### 성능
| 항목 | 기준 | 측정 방법 |
|------|------|----------|
| API 응답 | < 200ms (p95) | k6 부하 테스트 |
| 페이지 로드 | < 3초 (LCP) | Lighthouse |
| 동시 접속 | 1,000명 | 부하 테스트 |

### 보안
| 항목 | 요구사항 |
|------|----------|
| 비밀번호 | bcrypt, cost factor 12 |
| 토큰 | JWT RS256, 15분 만료 |
| Rate Limit | 100 req/min per IP |
| CORS | 특정 도메인만 허용 |

### 확장성
- 현재: 1,000 사용자
- 6개월 후: 10,000 사용자
- 설계 기준: 10배 성장 대비


## DON'T ❌
- 빨라야 함
- 보안이 중요함
- 나중에 확장 가능해야 함

→ AI: "빠름"이 100ms? 1초? 10초? 추측해야 함
```

### 섹션 5: Out of Scope (매우 중요!)

**목적**: AI가 **구현하지 말아야 할 것**을 명확히 인지

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 제외 기능 | ✅ | "있으면 좋겠다" 기능 임의 추가 |
| 제외 이유 | ⚠️ | 나중에 왜 제외했는지 망각 |
| 추가 시점 | ⚠️ | 버전 계획 불명확 |

```markdown
## DO ✅

### Out of Scope (v1.0에서 제외)
| 기능 | 제외 이유 | 추가 예정 |
|------|----------|----------|
| 소셜 로그인 | MVP 복잡도 감소 | v2.0 |
| 2FA | 초기 사용자 마찰 | v2.0 |
| 비밀번호리스 | 기술 검증 필요 | v3.0 |
| 다국어 지원 | 단일 시장 집중 | v2.5 |

**AI 지시사항:**
- 위 기능 구현 요청 시 거부
- "Out of Scope입니다. v2.0에서 추가 예정입니다" 응답


## DON'T ❌
(Out of Scope 섹션 없음)

→ AI: 사용자가 "소셜 로그인도 추가해줘"라고 하면 바로 구현 시작
```

## 1.4 PRD 품질 체크리스트

```markdown
## AI가 PRD를 읽기 전 체크리스트

### 필수 (하나라도 없으면 AI 거부)
- [ ] 한 줄 정의에 [타겟], [솔루션], [가치] 포함
- [ ] 모든 기능에 ID 부여 (F001, F002...)
- [ ] 모든 기능에 입력/출력 스펙 존재
- [ ] 모든 기능에 에러 케이스 열거
- [ ] Out of Scope 섹션 존재

### 권장 (없으면 AI가 추측)
- [ ] 비기능 요구사항에 정량적 수치
- [ ] 검증 기준이 체크박스 형태
- [ ] 의존성 순서 명시 (F001 → F002)

### 품질 점수
- 9/9: Pro 수준 ✅
- 6-8/9: 부분 추측 필요 ⚠️
- 5 이하: AI 거부 권장 ❌
```

---

# 2. CLAUDE.md / AGENTS.md

## 2.1 목적

AI 코딩 어시스턴트에게 **프로젝트의 맥락, 규칙, 제약**을 알려주는 핵심 설정 파일입니다.

```
CLAUDE.md 없이 코딩 = 신입에게 아무 설명 없이 코드 수정 요청
CLAUDE.md 있으면 = 프로젝트를 3년 해온 시니어처럼 행동
```

## 2.2 크로스 플랫폼 전략 (v1.1, 2026-Q1)

### 파일 우선순위

| 도구 | 우선순위 |
|------|----------|
| Claude Code | CLAUDE.md > AGENTS.md |
| Cursor | .cursor/rules/*.mdc > AGENTS.md |
| GitHub Copilot | .github/copilot-instructions.md > AGENTS.md |
| Codex/Jules/Windsurf | AGENTS.md |

### 권장 설정

```bash
# AGENTS.md를 소스로 사용
ln -s AGENTS.md CLAUDE.md
cp AGENTS.md .github/copilot-instructions.md

# Cursor는 별도 관리 (frontmatter 필요)
```

### AGENTS.md 표준 (AAIF, 60,000+ 프로젝트 채택)

```markdown
# AGENTS.md 권장 구조
# Build & Test
# Architecture Overview
# Security
# Git Workflows
# Conventions & Patterns
```

## 2.3 AI가 CLAUDE.md를 읽는 방식

```yaml
AI 처리 순서:
  1. 프로젝트 루트에서 CLAUDE.md 탐색
  2. 하위 디렉토리의 CLAUDE.md 탐색 (오버라이드)
  3. @include 지시문 처리 (바이너리 자동 제외)
  4. 지시사항 로딩 (세션 시작 시)
  5. 모든 응답에 적용
```

## 2.4 Skills 시스템 (Claude Code 2.1+)

### 디렉토리 구조

```
.claude/
└── skills/           # 통합됨! /로 호출 가능
    ├── my-skill/
    │   └── SKILL.md  # frontmatter에 hooks 포함 가능
    └── another-skill/
        └── SKILL.md
```

### SKILL.md frontmatter 형식

```markdown
---
name: my-skill
description: 스킬 설명
user-invocable: true  # /로 호출 가능 (기본값 true)
hooks:
  - event: onFileChange
    pattern: "*.ts"
---

# 스킬 내용
```

### @include 규칙 (v2.1+)

- 바이너리 파일 (이미지, PDF 등) 자동 제외됨
- 텍스트 파일만 포함됨
- `--add-dir` 플래그로 다중 CLAUDE.md 로딩 가능

## 2.5 필수 섹션 + AI 행동

### 섹션 1: 프로젝트 개요

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 한 줄 설명 | ✅ | 매번 "이 프로젝트가 뭔가요?" 질문 |
| 기술 스택 | ✅ | 잘못된 라이브러리/문법 사용 |
| 주요 명령어 | ✅ | 빌드/테스트 방법 모름 |

```markdown
## DO ✅

# 프로젝트 개요

Clouvel - Claude Code를 위한 PRD 강제 도구

## 기술 스택
- Runtime: Node.js 20+
- Language: TypeScript 5.3+
- Package Manager: pnpm
- Test: Vitest
- Lint: ESLint + Prettier

## 주요 명령어
```bash
pnpm install      # 의존성 설치
pnpm dev          # 개발 서버
pnpm build        # 프로덕션 빌드
pnpm test         # 테스트 실행
pnpm lint         # 린트 검사
```


## DON'T ❌

# My Project
A cool project.

→ AI: 기술 스택 추측, npm/yarn/pnpm 모름, 테스트 명령어 모름
```

### 섹션 2: 코드 스타일 규칙

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 네이밍 규칙 | ✅ | 일관성 없는 네이밍 |
| 파일 구조 | ✅ | 임의 위치에 파일 생성 |
| 금지 패턴 | ✅ | 안티패턴 사용 가능 |

```markdown
## DO ✅

## 코드 스타일

### 네이밍 규칙
- 파일명: kebab-case (`user-service.ts`)
- 클래스: PascalCase (`UserService`)
- 함수/변수: camelCase (`getUserById`)
- 상수: SCREAMING_SNAKE_CASE (`MAX_RETRY_COUNT`)
- 타입/인터페이스: PascalCase + 접두사 없음 (`User`, not `IUser`)

### 파일 구조
```
src/
├── commands/     # CLI 명령어
├── services/     # 비즈니스 로직
├── utils/        # 유틸리티 함수
├── types/        # 타입 정의
└── index.ts      # 진입점
```

### 금지 패턴 ❌
- `any` 타입 사용 금지 (unknown 사용)
- console.log 금지 (logger 사용)
- 상대 경로 3단계 이상 금지 (`../../../` ❌)
- default export 금지 (named export 사용)


## DON'T ❌

일관된 코드 스타일을 유지하세요.

→ AI: "일관된"이 뭔지 정의 없음, 자기 스타일 사용
```

### 섹션 3: 프로젝트 특화 규칙

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 도메인 용어 | ⚠️ | 일반적인 용어 사용 |
| 아키텍처 규칙 | ✅ | 레이어 위반 가능 |
| 외부 API 정보 | ⚠️ | 잘못된 API 호출 |

```markdown
## DO ✅

## 프로젝트 규칙

### 도메인 용어
| 용어 | 의미 |
|------|------|
| Spec | PRD 또는 기술 명세 |
| Gate | 코드 품질 검증 단계 |
| Vibe Coding | AI 협업 코딩 방식 |

### 아키텍처 규칙
- Commands → Services → Utils (단방향)
- Services는 다른 Services 직접 호출 금지
- 모든 외부 API는 services/external/에 래핑

### 중요한 컨텍스트
- PRD 파일 위치: `docs/prd/`
- 이 프로젝트는 CLI 도구임, UI 없음
- Node.js 20+ 필수 (ES2022 문법 사용)
```

### 섹션 4: 명시적 금지사항

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 하지 말 것 | ✅ | 원치 않는 동작 수행 |
| 건드리지 말 것 | ✅ | 중요 파일 수정 |

```markdown
## DO ✅

## 절대 금지 🚫

### 하지 말 것
- package.json의 dependencies 임의 추가 금지
- 기존 테스트 삭제/수정 금지 (추가만 가능)
- .env 파일 수정 금지
- main 브랜치 직접 커밋 금지

### 건드리지 말 것
- `src/core/` - 핵심 로직, 변경 시 반드시 리뷰
- `scripts/` - 배포 스크립트
- `.github/workflows/` - CI/CD 파이프라인

### 의존성 추가 규칙
새 패키지 추가 전 반드시 확인:
1. 이미 유사 기능 있는지 확인
2. 번들 사이즈 영향 검토
3. 라이선스 확인 (MIT/Apache만)
```

## 2.6 CLAUDE.md 품질 체크리스트

```markdown
## 체크리스트

### 필수 (150줄 이하 권장)
- [ ] 프로젝트 한 줄 설명
- [ ] 기술 스택 명시
- [ ] 주요 명령어 (install, dev, build, test)
- [ ] 네이밍 규칙
- [ ] 파일 구조
- [ ] 금지 패턴

### 권장
- [ ] 도메인 용어 정의
- [ ] 아키텍처 규칙
- [ ] 의존성 추가 규칙
- [ ] 관련 문서 링크

### 고급
- [ ] 하위 디렉토리별 오버라이드
- [ ] 에러 패턴 및 해결책
- [ ] 자주 하는 실수 목록
```

---

# 3. README.md

## 3.1 목적

프로젝트의 **첫인상**이자 **빠른 시작 가이드**. AI는 README로 프로젝트 구조와 사용법을 파악합니다.

## 3.2 AI가 README를 읽는 방식

```yaml
AI 처리 순서:
  1. 프로젝트 이름/설명 → 목적 파악
  2. 설치 명령어 → 환경 설정 방법
  3. 사용법 → API/CLI 인터페이스
  4. 프로젝트 구조 → 파일 위치 파악
```

## 3.3 필수 섹션 + AI 행동

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 프로젝트 설명 | ✅ | 목적 추측 필요 |
| 설치 방법 | ✅ | 환경 설정 실패 |
| 사용법/예시 | ✅ | API 사용법 모름 |
| 프로젝트 구조 | ⚠️ | 파일 위치 추측 |
| 환경 변수 | ⚠️ | 설정 누락 |

---

# 4. ARCHITECTURE.md

## 4.1 목적

시스템의 **전체 구조와 설계 결정**을 문서화. AI가 코드 수정 시 아키텍처 일관성을 유지하도록 합니다.

## 4.2 AI가 ARCHITECTURE를 읽는 방식

```yaml
AI 처리 순서:
  1. 시스템 다이어그램 → 컴포넌트 관계 파악
  2. 레이어 구조 → 의존성 방향 확인
  3. 데이터 플로우 → 처리 순서 이해
  4. 기술 결정 → 왜 이 기술인지 이해
```

## 4.3 필수 섹션 + AI 행동

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 시스템 개요 | ✅ | 전체 그림 없이 부분만 봄 |
| 레이어 구조 | ✅ | 의존성 방향 위반 |
| 컴포넌트 설명 | ✅ | 역할 구분 없이 코드 작성 |
| 데이터 플로우 | ⚠️ | 처리 순서 오류 |

---

# 5. ADR (Architecture Decision Records)

## 5.1 목적

**왜 이런 기술/설계 결정을 했는지** 기록. AI가 과거 결정을 이해하고 일관된 선택을 하도록 합니다.

## 5.2 ADR 템플릿

```markdown
# ADR-001: 데이터베이스 선택

## 상태
Accepted ← AI는 이것만 적용

## 날짜
2026-02-01

## 컨텍스트
- 사용자 데이터 저장 필요
- 솔로 개발자로 운영 부담 최소화 필요

## 고려한 옵션
### 옵션 1: PostgreSQL (Self-hosted)
### 옵션 2: Supabase (Managed PostgreSQL)
### 옵션 3: SQLite

## 결정
**Supabase 선택**

## 이유
1. 솔로 개발자로 운영 부담 최소화 우선
2. 무료 티어로 10,000 사용자까지 충분

## AI 지시사항
- 데이터베이스 관련 코드는 Supabase 클라이언트 사용
```

---

# 6. TECH_STACK.md

## 6.1 목적

사용하는 **모든 기술과 버전, 선택 이유**를 명시. AI가 올바른 문법과 API를 사용하도록 합니다.

## 6.2 필수 섹션

| 요소 | 필수 | 없을 때 AI 행동 |
|------|------|----------------|
| 언어/런타임 버전 | ✅ | 잘못된 문법 사용 |
| 프레임워크 버전 | ✅ | API 호환성 오류 |
| 금지 기술 | ✅ | 불필요한 라이브러리 추가 |

---

# 7. API_SPEC.md

## 7.1 목적

API 엔드포인트의 **정확한 인터페이스**를 정의. AI가 올바른 요청/응답 형식을 생성하도록 합니다.

---

# 8. TEST_PLAN.md

## 8.1 목적

테스트 **전략, 범위, 방법**을 정의. AI가 적절한 테스트 코드를 생성하도록 합니다.

---

# 9. ERROR_LOG.md

## 9.1 목적

반복되는 **에러 패턴과 해결책**을 기록. AI가 같은 실수를 반복하지 않도록 합니다.

---

# 10. CHANGELOG.md

## 10.1 목적

버전별 **변경 사항**을 기록. AI가 버전 호환성과 변경 이력을 이해하도록 합니다.

---

# 11. SECURITY.md

## 11.1 목적

**보안 요구사항과 취약점 보고 절차**를 정의. AI가 보안 고려사항을 반영하도록 합니다.

---

# 12. DEPLOYMENT.md

## 12.1 목적

**배포 절차와 환경 설정**을 정의. AI가 배포 관련 코드를 올바르게 작성하도록 합니다.

---

# 13. PROGRESS.md

## 13.1 목적

**현재 진행 상황과 다음 작업**을 추적. AI가 컨텍스트를 유지하도록 합니다.

---

# 14. 문서 간 연결 규칙

## 14.1 문서 의존성 그래프

```
PRD (What)
  │
  ├──→ ARCHITECTURE (How - 구조)
  │       │
  │       └──→ ADR (Why - 결정 이유)
  │
  ├──→ API_SPEC (How - 인터페이스)
  │
  ├──→ TEST_PLAN (검증 방법)
  │
  └──→ SECURITY (제약 조건)

CLAUDE.md (AI 지시)
  │
  ├──→ PRD 요약
  ├──→ TECH_STACK 요약
  └──→ ERROR_LOG 규칙
```

---

# 부록: 문서 품질 총점 체크리스트

```markdown
## Clouvel Pro 문서 품질 점수

### 필수 문서 (50점)
- [ ] PRD 완전성 (15점)
- [ ] CLAUDE.md 완전성 (15점)
- [ ] README 완전성 (10점)
- [ ] TECH_STACK 완전성 (10점)

### 권장 문서 (30점)
- [ ] ARCHITECTURE (10점)
- [ ] API_SPEC (10점)
- [ ] TEST_PLAN (10점)

### 고급 문서 (20점)
- [ ] ADR 시스템 (5점)
- [ ] ERROR_LOG (5점)
- [ ] SECURITY (5점)
- [ ] DEPLOYMENT (5점)

### 점수 해석
- 90-100: Pro 수준 ✅ - AI 최적 성능
- 70-89: Good ⚠️ - 일부 추측 필요
- 50-69: Basic - 기본 동작만
- 50 미만: Insufficient ❌ - AI 거부 권장
```

---

# 15. MCP 서버 설정 가이드 (v2.1+)

## 15.1 Tool Search (Lazy Loading)

Claude Code 2.1+에서는 MCP 도구가 많을 경우 자동으로 lazy loading됩니다.

```yaml
이전:
  - 모든 MCP 도구 정의가 context에 미리 로딩
  - 도구 많으면 context 10%+ 소모

이후 (Tool Search):
  - 도구 정의 10% 초과 시 자동으로 lazy loading
  - 필요할 때만 도구 정의 로딩
  - server_instructions 필드가 중요해짐
```

## 15.2 server_instructions 중요성

Tool Search 활성화 시, `server_instructions`가 도구 검색의 핵심 메타데이터가 됩니다.

```json
{
  "name": "my-mcp-server",
  "server_instructions": "파일 시스템 작업용. 파일 읽기/쓰기/삭제 시 이 서버 사용."
}
```

## 15.3 MCP 설정 체크리스트

```markdown
### 필수
- [ ] server_instructions에 서버 용도 명확히 기술
- [ ] 도구별 description 충분히 작성
- [ ] 도구 수 최적화 (불필요한 도구 제거)

### 권장
- [ ] 도구 그룹화 (관련 기능 묶기)
- [ ] 에러 메시지 명확히
- [ ] 타임아웃 설정 (긴 작업)
```

---

*Last Updated: 2026-02-01*
*Clouvel Pro Documentation Guidelines v1.1*
