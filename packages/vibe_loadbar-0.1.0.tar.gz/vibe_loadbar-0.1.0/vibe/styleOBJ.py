class Style:
    def __init__(self, bar_fil, end, bar_unfil):
        self.bar_fil = bar_fil
        self.end = end
        self.bar_unfil = bar_unfil