##Vibe Loader
is a lightweight alternative to TQDM in less tham 250 lines of code.

It uses an event based function called update to update the value.

#Features:
100+ Styles, that are passed into the Loading OBJ.
Zero foreign dependencies.
MARGIN that helps with small terminals.
Dynamic resizing with terminal width.
Supports request streams.
It supports with statements.
All variables are public and changeable.
Custom styles.