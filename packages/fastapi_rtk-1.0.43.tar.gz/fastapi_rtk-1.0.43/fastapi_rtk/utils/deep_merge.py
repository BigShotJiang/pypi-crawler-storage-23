import copy
import typing

__all__ = ["deep_merge"]


def deep_merge(
    *data: typing.Dict[str, typing.Any],
    rules: typing.Dict[str, typing.Callable[[typing.Any, typing.Any], bool]]
    | None = None,
    merge_dicts=True,
    merge_lists=True,
    _prefix="",
):
    """
    Recursively merges multiple dictionaries into the first one.

    - If the key does not exist in the previous dictionary, it will be directly added.
    - If `rules` is provided and the key exists in `rules`, it will apply the corresponding rule to determine if the value should be overwritten.
    - If `merge_dicts` is True and both the previous and next values are dictionaries, it will recursively merge them.
    - If `merge_lists` is True and both the previous and next values are lists, it will concatenate the lists while ensuring no duplicates are added.

    Args:
        data (typing.Dict[str, typing.Any]): A variable number of dictionaries to be merged. The first dictionary will be the base into which the others are merged.
        rules (typing.Dict[str, typing.Callable[[typing.Any, typing.Any], bool]] | None, optional): A dictionary of rules where the key is a string representing the path to the value (using dot notation for nested keys) and the value is a callable that takes the existing value and the new value, returning True if the new value should overwrite the existing one. Defaults to None.
        merge_dicts (bool, optional): Whether to recursively merge dictionaries. Defaults to True.
        merge_lists (bool, optional): Whether to concatenate lists while ensuring no duplicates. Defaults to True.
        _prefix (str, optional): A prefix used internally for constructing rule keys. Defaults to "".

    Returns:
        typing.Dict[str, typing.Any]: The merged dictionary resulting from the deep merge of the input dictionaries.

    Notes:
        - Rules are applied before merging. If a rule is defined for a key, it will determine whether the new value should overwrite the existing value based on the logic provided in the rule's callable. If no rule is defined for a key, the function will proceed with the default merging behavior (merging dictionaries or concatenating lists if enabled, or simply overwriting values).
    """
    base_data, *data = data
    base_data = copy.deepcopy(base_data)
    for dat in data:
        for key, value in dat.items():
            if key not in base_data:
                base_data[key] = value
                continue

            rules_key = _prefix + key
            if rules and rules_key in rules:
                if rules[rules_key](base_data[key], value):
                    base_data[key] = value
                continue

            if (
                merge_dicts
                and isinstance(value, dict)
                and isinstance(base_data[key], dict)
            ):
                base_data[key] = deep_merge(
                    base_data[key], value, rules=rules, _prefix=_prefix + key + "."
                )
                continue

            if (
                merge_lists
                and isinstance(value, list)
                and isinstance(base_data[key], list)
            ):
                base_data[key].extend(x for x in value if x not in base_data[key])
                continue

            base_data[key] = value

    return base_data
