import asyncio
import contextvars
import dataclasses
import functools
import inspect
import queue
import secrets
import traceback as tb
import typing

from .formatter import prettify_dict
from .use_default_when_none import use_default_when_none

__all__ = ["AsyncTaskRunner"]

T = typing.TypeVar("T")


@dataclasses.dataclass
class CallerInfo:
    """
    Represents information about the caller of a function.
    This is used to capture the context in which an async task was added.
    """

    filename: str
    lineno: int
    name: str

    def __repr__(self):
        return f'File "{self.filename}", line {self.lineno}, in {self.name}'


class AsyncTaskRunnerException(Exception):
    """
    Base exception for AsyncTaskRunner-related errors.
    """


class AsyncTaskException(AsyncTaskRunnerException):
    def __init__(
        self, *args, original_exception: Exception, caller: CallerInfo | None = None
    ):
        super().__init__(*args)
        self.original_exception = original_exception
        self.caller = caller


class DuplicateRunnerIDException(AsyncTaskRunnerException):
    def __init__(self, id: str, existing_runner: "AsyncTaskRunner"):
        super().__init__(
            f"An AsyncTaskRunner with id '{id}' already exists in the current context. Runner IDs must be unique within the same context stack. Existing runner: {existing_runner}"
        )
        self.id = id
        self.existing_runner = existing_runner


class ResultAccessor(typing.Generic[T]):
    """Helper class that can be awaited OR accessed directly."""

    def __init__(self, task: "AsyncTask[T]"):
        self._task = task

    def __await__(self):
        """Allow awaiting: await task.result"""
        return self._task.__await__()

    def __repr__(self) -> str:
        """Direct access without await - returns value or raises error."""
        return repr(self._ensure_result())

    def __str__(self) -> str:
        """Direct access without await - returns value or raises error."""
        return str(self._ensure_result())

    # Make it behave like the actual value when accessed
    def __getattr__(self, name):
        return getattr(self._ensure_result(), name)

    def _ensure_result(self):
        if not hasattr(self._task, "_result"):
            raise RuntimeError(
                "Task has not been executed yet. Await the task to get the result."
            )
        return self._task._result


class AsyncTask(typing.Generic[T]):
    """
    Represents a task to be run asynchronously.

    This is a callable that returns an awaitable (coroutine) or a coroutine directly.
    """

    def __init__(
        self,
        task: typing.Callable[..., typing.Awaitable[T]] | typing.Awaitable[T],
        /,
        caller: CallerInfo | None = None,
        tags: list[str] | None = None,
    ):
        self.task = task
        self.caller = caller
        self.tags = tags or []

    @property
    def result(self):
        """
        Provides access to the result of the task.

        Returns:
            ResultAccessor[T]: An accessor that can be awaited or accessed directly.
        """
        return ResultAccessor(self)

    def __call__(self):
        return self._run()

    def __await__(self):
        return self._run().__await__()

    async def _run(self):
        """
        Runs the task and caches the result.

        Returns:
            T: The result of the task.
        """
        if hasattr(self, "_result"):
            return self._result

        try:
            coro = self.task
            if callable(coro):
                coro = coro()
            self._result = await coro
            return self._result
        except Exception as e:
            raise AsyncTaskException(
                str(e), original_exception=e, caller=self.caller
            ) from e


class AsyncTaskRunner:
    """
    A context manager for queuing and running async tasks at the end of an async with block.

    Supports nested contexts and is safe in multithreaded async environments.

    You can add either a callable that returns an awaitable (coroutine), a normal function, or a coroutine directly. But a callable is preferred
    to avoid warning about "coroutine was never awaited" in case the task fails to run.

    Example:

    Some async function that you want to run at the end of the context:
    ```python
    async def some_async_function():
        # Some asynchronous operation
        await asyncio.sleep(1)
        print("Task completed")
    ```

    Using the AsyncTaskRunner class:
    ```python
    from fastapi_rtk import AsyncTaskRunner

    # Using the AsyncTaskRunner class directly
    async with AsyncTaskRunner():
        AsyncTaskRunner.add_task(lambda: some_async_function())
        # The task will be executed when exiting the context
    ```

    Using the AsyncTaskRunner class with a variable:
    ```python
    from fastapi_rtk import AsyncTaskRunner

    # Using the AsyncTaskRunner class with a variable
    async with AsyncTaskRunner() as runner:
        runner.add_task(lambda: some_async_function())
        # The task will be executed when exiting the context

    # Using the AsyncTaskRunner class with a variable and nested context
    async with AsyncTaskRunner() as runner:
        runner.add_task(lambda: some_async_function())
        async with AsyncTaskRunner() as nested_runner:
            nested_runner.add_task(lambda: some_async_function())
            # The task will be executed when exiting the nested context
    # The task will be executed when exiting the outer context
    ```
    """

    parent: "AsyncTaskRunner | None" = None
    """
    Reference to the parent AsyncTaskRunner in case of nested contexts. This allows tasks in nested runners to access and modify the task list of their parent runner if needed.
    """
    child: "AsyncTaskRunner | None" = None
    """
    Reference to the child AsyncTaskRunner in case of nested contexts. This allows the parent runner to access and modify the task list of its child runner if needed.
    """

    GET_TASK_TIMEOUT = 10  # Timeout in seconds for getting task from the queue

    _stack: contextvars.ContextVar[typing.Optional[list["AsyncTaskRunner"]]] = (
        contextvars.ContextVar("_stack", default=None)
    )

    def __init__(self, id: str | None = None, run_tasks_even_if_exception=False):
        """
        Initializes the AsyncTaskRunner.

        Args:
            id (str | None, optional): An optional identifier for the runner instance. Defaults to None.
            run_tasks_even_if_exception (bool, optional): Whether to run tasks even if an exception occurs in the context. Defaults to False.
        """
        self.id = use_default_when_none(id, secrets.token_hex(8))
        self.run_tasks_even_if_exception = run_tasks_even_if_exception
        self.task_queue = queue.Queue[AsyncTask[T]]()
        self.frozen = False

        # Check whether runner with the same id already exists in the current stack
        try:
            existing_runner = self.get_runner(self.id)
            raise DuplicateRunnerIDException(self.id, existing_runner)
        except (ValueError, RuntimeError):
            pass  # No existing runner with the same id or no stack exists yet, which is expected

    def __repr__(self):
        return f"<AsyncTaskRunner id={self.id} tasks={self.task_queue.qsize()} frozen={self.frozen}>"

    @typing.overload
    @classmethod
    def add_task(
        cls,
        task: typing.Callable[..., typing.Awaitable[T]]
        | typing.Awaitable[T]
        | AsyncTask[T],
        *,
        tags: list[str] | None = None,
        instance: "AsyncTaskRunner | None" = None,
    ) -> AsyncTask[T]: ...

    @typing.overload
    @classmethod
    def add_task(
        cls,
        task1: typing.Callable[..., typing.Awaitable[T]]
        | typing.Awaitable[T]
        | AsyncTask[T],
        task2: typing.Callable[..., typing.Awaitable[T]]
        | typing.Awaitable[T]
        | AsyncTask[T],
        *tasks: typing.Callable[..., typing.Awaitable[T]]
        | typing.Awaitable[T]
        | AsyncTask[T],
        tags: list[str] | None = None,
        instance: "AsyncTaskRunner | None" = None,
    ) -> list[AsyncTask[T]]: ...
    @classmethod
    def add_task(
        cls,
        *tasks: typing.Callable[..., typing.Awaitable[T]]
        | typing.Awaitable[T]
        | AsyncTask[T],
        tags: list[str] | None = None,
        instance: "AsyncTaskRunner | None" = None,
    ):
        """
        Adds one or more tasks to the current runner's task list. The tasks will be executed when exiting the context.

        Args:
            tags (list[str] | None, optional): Tags to associate with the tasks. Defaults to None.
            instance (AsyncTaskRunner | None, optional): The AsyncTaskRunner instance to add tasks to. If not given, it will add to the current runner instance in the context. Defaults to None.

        Returns:
            AsyncTask[T] | list[AsyncTask[T]]: The added task(s).
        """
        if not instance:
            return cls.add_task(*tasks, tags=tags, instance=cls.get_current_runner())

        # Get caller info - skip frames: add_task -> (possibly recursive call) -> actual caller
        frame = inspect.currentframe()
        if frame:
            # Skip internal frames to get the actual caller
            frames = inspect.getouterframes(frame, 2)
            # frames[0] is current frame (add_task)
            # frames[1] is the caller (could be recursive add_task call or actual caller)
            # frames[2] is the original caller if frames[1] was recursive
            caller_frame = (
                frames[2]
                if len(frames) > 2 and "add_task" in frames[1].function
                else frames[1]
            )

            caller = CallerInfo(
                filename=caller_frame.filename,
                lineno=caller_frame.lineno,
                name=caller_frame.function,
            )
        else:
            caller = CallerInfo(
                filename="<unknown>",
                lineno=0,
                name="<unknown>",
            )

        if instance.frozen:
            raise RuntimeError(
                prettify_dict(
                    {
                        "message": "Cannot add task to AsyncTaskRunner after it has been exited.",
                        "runner": instance,
                        "caller": caller,
                        "possible_causes": [
                            "Trying to add a task after the context has been exited.",
                            "Trying to add a task in an asynchronous callback after the context has been exited.",
                        ],
                        "suggestions": [
                            "Ensure that tasks are added before exiting the context.",
                            "If adding tasks in async callbacks, ensure the context is still active.",
                        ],
                    }
                )
            )

        async_tasks: list[AsyncTask[T]] = [
            AsyncTask(task, caller=caller, tags=tags)
            if not isinstance(task, AsyncTask)
            else task
            for task in tasks
        ]
        for async_task in async_tasks:
            instance.task_queue.put(async_task, timeout=cls.GET_TASK_TIMEOUT)
        return async_tasks if len(async_tasks) > 1 else async_tasks[0]

    @classmethod
    def remove_tasks_by_tag(
        cls, tag: str, *, instance: "AsyncTaskRunner | None" = None
    ):
        """
        Removes tasks with the specified tag from the current runner's task list.

        Args:
            tag (str): The tag to filter tasks by.
            instance (AsyncTaskRunner | None, optional): The AsyncTaskRunner instance to remove tasks from. If not given, it will remove from the current runner instance in the context. Defaults to None.
        """
        if not instance:
            return cls.remove_tasks_by_tag(tag, instance=cls.get_current_runner())
        new_queue = queue.Queue[AsyncTask[T]]()
        while not instance.task_queue.empty():
            try:
                task = instance.task_queue.get(timeout=cls.GET_TASK_TIMEOUT)
                if tag not in task.tags:
                    new_queue.put(task)
                instance.task_queue.task_done()
            except queue.Empty:
                break
        instance.task_queue = new_queue

    @classmethod
    def get_current_runner(cls):
        """
        Retrieves the current AsyncTaskRunner instance from the context stack.

        Raises:
            RuntimeError: If called outside of a context.

        Returns:
            AsyncTaskRunner: The current AsyncTaskRunner instance.
        """
        stack = cls._get_current_stack("get_current_runner")
        if not stack:
            raise RuntimeError(
                f"No AsyncTaskRunner found in the current context. "
                f"Use `async with {cls.__name__}():` to create a context before calling this."
            )
        return stack[-1]

    @classmethod
    def get_runner(cls, id: str):
        """
        Retrieves the AsyncTaskRunner instance with the specified ID from the context stack.

        Args:
            id (str): The ID of the AsyncTaskRunner to retrieve.

        Raises:
            RuntimeError: If called outside of a context.
            ValueError: If no AsyncTaskRunner with the specified ID is found.

        Returns:
            AsyncTaskRunner: The AsyncTaskRunner instance with the specified ID.
        """
        stack = cls._get_current_stack("get_runner_by_id")
        for runner in reversed(stack):
            if runner.id == id:
                return runner
        raise ValueError(
            f"No AsyncTaskRunner with id '{id}' found in the current context."
        )

    async def __aenter__(self):
        self._on_enter()
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        try:
            if exc_type and not self.run_tasks_even_if_exception:
                return

            exceptions_with_index = list[tuple[AsyncTaskException, int]]()
            index = 0
            while not self.task_queue.empty():
                tasks = list[AsyncTask[T]]()
                while not self.task_queue.empty():
                    tasks.append(self.task_queue.get(timeout=self.GET_TASK_TIMEOUT))
                    self.task_queue.task_done()

                from ..setting import Setting

                if Setting.DEBUG:
                    from ..const import logger

                    logger.debug(
                        prettify_dict(
                            {
                                "message": f"Running {len(tasks)} task(s)",
                                "runner": self,
                                "tasks": {
                                    f"Task {index + i + 1}": task.caller
                                    for i, task in enumerate(tasks)
                                },
                            }
                        )
                    )

                futures = await asyncio.gather(
                    *(task() for task in tasks), return_exceptions=True
                )
                for future in futures:
                    if isinstance(future, AsyncTaskException):
                        # Handle exceptions from tasks
                        exceptions_with_index.append((future, index))
                    index += 1

            if exceptions_with_index:
                raise AsyncTaskRunnerException(
                    f"\n{
                        prettify_dict(
                            {
                                'message': 'One or more tasks failed.',
                                'runner': self,
                                'exceptions': {
                                    f'Task {index + 1}': {
                                        'message': str(exc),
                                        'caller': exc.caller,
                                        'traceback': ''.join(
                                            tb.format_exception(exc.original_exception)
                                        ),
                                    }
                                    for exc, index in exceptions_with_index
                                },
                            }
                        )
                    }"
                )
        finally:
            self.frozen = True  # Freeze the runner to prevent new tasks
            self._on_exit()

    @classmethod
    def _get_current_stack(cls, func_name: str):
        """
        Retrieves the current runner stack from the context variable.

        Args:
            func_name (str): The name of the function requesting the runner stack.

        Raises:
            RuntimeError: If called outside of a context.

        Returns:
            list[AsyncTaskRunner]: The current runner stack.
        """
        stack = cls._stack.get()
        if stack is None:
            raise RuntimeError(
                f"{cls.__name__}.{func_name}() called outside of context. "
                f"Use `async with {cls.__name__}():` before calling this."
            )
        return stack

    def _on_enter(self):
        """
        Logic to run when entering the context.

        - Creates a new runner stack if it doesn't exist, or uses the existing one.
        - Pushes this instance to the runner stack.
        - Modifies instance methods to bind self.
        """
        # Create a new stack if it doesn't exist, or use the existing one
        try:
            stack = self._get_current_stack("_on_enter")
        except RuntimeError:
            self._stack.set(list["AsyncTaskRunner"]())
            stack = self._get_current_stack("_on_enter")
        stack.append(self)  # Push this instance to the runner stack

        # Set parent and child references for nested contexts
        if len(stack) > 1:
            self.parent = stack[-2]
            self.parent.child = self

        # Modify instance methods to bind self
        self.add_task = functools.partial(self.__class__.add_task, instance=self)
        self.remove_tasks_by_tag = functools.partial(
            self.__class__.remove_tasks_by_tag, instance=self
        )

    def _on_exit(self):
        """
        Logic to run when exiting the context.

        - Removes this instance from the runner stack (regardless of position).
        - If this is the last instance, resets the context variable to clean up.
        """
        stack = self._get_current_stack("_on_exit")

        try:
            stack.remove(self)
        except ValueError:
            raise RuntimeError(
                prettify_dict(
                    {
                        "message": "Runner instance not found in stack.",
                        "runner": self,
                        "current_stack": stack,
                        "possible_causes": [
                            "Instance was already removed from the stack.",
                            "Instance was never added to the stack.",
                        ],
                        "suggestions": [
                            "Ensure that the context manager is used correctly.",
                            "Check for nested contexts and their management.",
                        ],
                    }
                )
            )

        # Last one out cleans up - reset context var if stack is now empty
        if not stack:
            self._stack.set(None)
