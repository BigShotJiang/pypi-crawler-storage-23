import pickle
import weakref
from collections.abc import MutableSequence
from typing import TypeVar

from redis import Redis

T = TypeVar("T")


class RedisList(MutableSequence[T]):
    def __init__(self, redis: Redis, redis_key: str = None, persist: bool = False, overwrite: bool = True,
                 *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.redis = redis
        self.redis_key = \
            (redis_key if ":" in redis_key else f"redis_list:{redis_key}") \
            if redis_key is not None else f"redis_list:{id(self)}"

        if self.redis.exists(self.redis_key):
            if overwrite:
                self.redis.delete(self.redis_key)
            else:
                raise ValueError(f"Redis key '{self.redis_key}' already exists and overwrite is set to False.")
        if not persist:
            weakref.finalize(self, self.redis.delete, self.redis_key)

    def insert(self, index: int, value: T):
        length = len(self)
        value = pickle.dumps(value)

        # append if index is out of bounds
        if index >= length:
            self.redis.rpush(self.redis_key, value)
            return

        # insert at the beginning
        if index <= 0:
            self.redis.lpush(self.redis_key, value)
            return

        # insert in the middle
        pivot = self.redis.lindex(self.redis_key, index)
        if pivot is None:
            raise IndexError("insert index out of range")

        self.redis.linsert(self.redis_key, "BEFORE", pivot, value)

    def __getitem__(self, index: int) -> T:
        item = self.redis.lindex(self.redis_key, index)
        if item is None:
            raise IndexError("list index out of range")
        return pickle.loads(item)

    def __setitem__(self, index: int, value: T):
        self.redis.lset(self.redis_key, index, pickle.dumps(value))

    def __delitem__(self, index: int):
        # Redis does not support direct deletion of list items by index, so we need to use a workaround
        # We can mark the item as deleted and then remove it from the list
        marker = b"__DELETED__"
        self.redis.lset(self.redis_key, index, marker)
        self.redis.lrem(self.redis_key, 1, marker)

    def __len__(self) -> int:
        return self.redis.llen(self.redis_key)

    def __repr__(self):
        return f"RedisList({list(self)})"
