import pickle
import weakref
from collections.abc import MutableMapping
from typing import TypeVar

from redis import Redis

K = TypeVar("K")
V = TypeVar("V")


class RedisDict(MutableMapping[K, V]):
    def __init__(self, redis: Redis, redis_key: str = None, persist: bool = False, overwrite: bool = True,
                 *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.redis = redis
        self.redis_key = \
            (redis_key if ":" in redis_key else f"redis_dict:{redis_key}") \
            if redis_key is not None else f"redis_dict:{id(self)}"

        if self.redis.exists(self.redis_key):
            if overwrite:
                self.redis.delete(self.redis_key)
            else:
                raise ValueError(f"Redis key '{self.redis_key}' already exists and overwrite is set to False.")
        if not persist:
            weakref.finalize(self, self.redis.delete, self.redis_key)

    @staticmethod
    def __key(key: K) -> bytes:
        return pickle.dumps(key)

    @staticmethod
    def __value(value: V) -> bytes:
        return pickle.dumps(value)

    @staticmethod
    def __decode_key(key: bytes) -> K:
        return pickle.loads(key)

    @staticmethod
    def __decode_value(value: bytes) -> V:
        return pickle.loads(value)

    def __setitem__(self, key: K, value: V):
        self.redis.hset(self.redis_key, self.__key(key), self.__value(value))

    def __delitem__(self, key: K):
        self.redis.hdel(self.redis_key, self.__key(key))

    def __getitem__(self, key: K) -> V:
        value = self.redis.hget(self.redis_key, self.__key(key))
        if value is None:
            raise KeyError(key)
        return self.__decode_value(value)

    def __contains__(self, key: K) -> bool:
        return self.redis.hexists(self.redis_key, self.__key(key))

    def __len__(self):
        return self.redis.hlen(self.redis_key)

    def __iter__(self):
        for key in self.redis.hkeys(self.redis_key):
            yield self.__decode_key(key)

    def __repr__(self):
        return f"RedisDict(redis_key={self.redis_key}) [{', '.join(f'{k}: {v}' for k, v in self.items())}]"
