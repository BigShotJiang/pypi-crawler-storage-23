class DuplicatedName(Exception):
    pass