# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-28

### Added

#### Compare Feature
- **Sheet comparison**: Detects and reports sheets that exist in one file but not the other
- **Structure analysis**: Identifies differences in row and column counts between sheets
- **Cell-by-cell comparison**: Compares every cell value and reports exact differences with location (sheet name, row, column)
- **Exit codes**: Returns appropriate exit codes for CI/CD integration
  - Exit code 0: Files are identical
  - Exit code 1: Differences detected
  - Exit code 2: Error occurred

#### Merge Feature
- **Intelligent sheet merging**: Automatically merges sheets that exist in both files
- **Row appending**: Appends data rows from the second file to the first file
- **Header row handling**: Automatically skips duplicate header rows (configurable via `--no-skip-header`)
- **Sheet preservation**: Copies sheets that exist only in one file to the output
- **Format flexibility**: Supports both legacy .xls and modern .xlsx formats
- **Output format control**: Output format determined by output file extension

#### Command-Line Interface
- **Compare command**: `excel-util-tools compare` or `excel-util-tools --compare`
  - Supports quiet mode for scripting (`--quiet`, `-q`)
  - Detailed difference reporting
- **Merge command**: `excel-util-tools merge` or `excel-util-tools --merge`
  - Configurable header row handling
  - Progress messages (can be suppressed with `--quiet`)
- **Unified interface**: Single command-line tool for both operations

#### Python API
- **`compare_excel_files()` function**: Programmatic file comparison
  - Returns boolean indicating if differences were found
  - Optional verbose output
- **`merge_excel_files()` function**: Programmatic file merging
  - Configurable header row skipping
  - Optional progress messages
  - Returns output file path

#### Format Support
- **.xlsx files**: Full support for Excel 2007+ format
- **.xls files**: Full support for Excel 97-2003 format
- **Mixed formats**: Can compare and merge files of different formats

#### Error Handling
- Comprehensive error messages for missing files
- Clear error messages for unsupported formats
- Helpful messages when required libraries are missing
