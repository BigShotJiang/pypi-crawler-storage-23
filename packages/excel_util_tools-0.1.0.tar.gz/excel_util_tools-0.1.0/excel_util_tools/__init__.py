"""
Excel Tools - Compare and merge Excel files (.xls, .xlsx)
"""

__version__ = "0.1.0"

from .compare import compare_excel_files
from .merge import merge_excel_files

__all__ = ["compare_excel_files", "merge_excel_files"]
