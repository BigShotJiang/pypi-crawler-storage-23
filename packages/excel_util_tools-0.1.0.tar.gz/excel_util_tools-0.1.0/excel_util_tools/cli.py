"""
Command-line interface for Excel Tools
"""

import sys
import argparse
from pathlib import Path

from .compare import compare_excel_files
from .merge import merge_excel_files


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Excel Tools - Compare and merge Excel files (.xls, .xlsx)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Compare two Excel files
  excel-util-tools --compare file1.xlsx file2.xlsx
  excel-util-tools compare file1.xlsx file2.xlsx

  # Merge two Excel files
  excel-util-tools --merge file1.xlsx file2.xlsx output.xlsx
  excel-util-tools merge file1.xlsx file2.xlsx output.xlsx

  # Merge without skipping header row
  excel-util-tools --merge file1.xlsx file2.xlsx output.xlsx --no-skip-header
        """
    )

    # Support both subcommands and legacy flags
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Compare subcommand
    compare_parser = subparsers.add_parser(
        "compare",
        aliases=["c"],
        help="Compare two Excel files"
    )
    compare_parser.add_argument("file1", help="First Excel file to compare")
    compare_parser.add_argument("file2", help="Second Excel file to compare")
    compare_parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress output, only return exit code"
    )

    # Merge subcommand
    merge_parser = subparsers.add_parser(
        "merge",
        aliases=["m"],
        help="Merge two Excel files"
    )
    merge_parser.add_argument("file1", help="First Excel file")
    merge_parser.add_argument("file2", help="Second Excel file")
    merge_parser.add_argument("output", help="Output file path")
    merge_parser.add_argument(
        "--no-skip-header",
        action="store_true",
        help="Include header row from second file (default: skip header row)"
    )
    merge_parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress progress messages"
    )

    # Legacy --compare and --merge flags
    parser.add_argument("--compare", nargs=2, metavar=("FILE1", "FILE2"), 
                       help="Compare two Excel files (legacy flag)")
    parser.add_argument("--merge", nargs=3, metavar=("FILE1", "FILE2", "OUTPUT"), 
                       help="Merge two Excel files (legacy flag)")
    parser.add_argument("--no-skip-header", action="store_true", 
                       help="Include header row from second file when merging")
    parser.add_argument("--quiet", "-q", action="store_true", 
                       help="Suppress output")

    args = parser.parse_args()

    # Handle legacy --compare and --merge flags
    if args.compare:
        file1 = Path(args.compare[0])
        file2 = Path(args.compare[1])

        if not file1.exists():
            print(f"Error: File not found: {file1}", file=sys.stderr)
            sys.exit(2)

        if not file2.exists():
            print(f"Error: File not found: {file2}", file=sys.stderr)
            sys.exit(2)

        try:
            differences = compare_excel_files(file1, file2, verbose=not args.quiet)
            
            if differences:
                if not args.quiet:
                    print("\nDifferences detected.")
                sys.exit(1)
            else:
                if not args.quiet:
                    print("\nNo differences found.")
                sys.exit(0)

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.merge:
        file1 = Path(args.merge[0])
        file2 = Path(args.merge[1])
        output = Path(args.merge[2])

        if not file1.exists():
            print(f"Error: File not found: {file1}", file=sys.stderr)
            sys.exit(2)

        if not file2.exists():
            print(f"Error: File not found: {file2}", file=sys.stderr)
            sys.exit(2)

        try:
            skip_header = not args.no_skip_header
            merge_excel_files(file1, file2, output, skip_header_row=skip_header, verbose=not args.quiet)
            sys.exit(0)

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    # Handle subcommands
    elif args.command == "compare":
        file1 = Path(args.file1)
        file2 = Path(args.file2)

        if not file1.exists():
            print(f"Error: File not found: {file1}", file=sys.stderr)
            sys.exit(2)

        if not file2.exists():
            print(f"Error: File not found: {file2}", file=sys.stderr)
            sys.exit(2)

        try:
            differences = compare_excel_files(file1, file2, verbose=not args.quiet)
            
            if differences:
                if not args.quiet:
                    print("\nDifferences detected.")
                sys.exit(1)
            else:
                if not args.quiet:
                    print("\nNo differences found.")
                sys.exit(0)

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    elif args.command == "merge":
        file1 = Path(args.file1)
        file2 = Path(args.file2)
        output = Path(args.output)

        if not file1.exists():
            print(f"Error: File not found: {file1}", file=sys.stderr)
            sys.exit(2)

        if not file2.exists():
            print(f"Error: File not found: {file2}", file=sys.stderr)
            sys.exit(2)

        try:
            skip_header = not args.no_skip_header
            merge_excel_files(file1, file2, output, skip_header_row=skip_header, verbose=not args.quiet)
            sys.exit(0)

        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
