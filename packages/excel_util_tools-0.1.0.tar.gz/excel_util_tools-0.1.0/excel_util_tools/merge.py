"""
Excel file merging functionality
"""

from pathlib import Path

try:
    import openpyxl
except ImportError:
    openpyxl = None

try:
    import xlrd
except ImportError:
    xlrd = None

try:
    import xlwt
except ImportError:
    xlwt = None

SUPPORTED_EXTENSIONS = [".xls", ".xlsx"]


def load_workbook(file_path):
    """Load an Excel workbook using the appropriate library."""
    ext = Path(file_path).suffix.lower()

    if ext == ".xlsx":
        if not openpyxl:
            raise ImportError("openpyxl is required for .xlsx files. Install with: pip install openpyxl")
        return openpyxl.load_workbook(file_path, data_only=True), "openpyxl"

    elif ext == ".xls":
        if not xlrd:
            raise ImportError("xlrd is required for .xls files. Install with: pip install xlrd")
        return xlrd.open_workbook(file_path), "xlrd"

    else:
        raise ValueError(f"Unsupported file type: {ext}. Supported: {SUPPORTED_EXTENSIONS}")


def merge_excel_files(file1, file2, output_file, skip_header_row=True, verbose=True):
    """
    Merge two Excel files by combining sheets and rows.
    
    Args:
        file1: Path to first Excel file
        file2: Path to second Excel file
        output_file: Path to output merged file
        skip_header_row: If True, skip header row from second file when merging
        verbose: If True, print progress messages
        
    Returns:
        str: Path to the output file
    """
    wb1, engine1 = load_workbook(file1)
    wb2, engine2 = load_workbook(file2)

    sheets1 = wb1.sheetnames if engine1 == "openpyxl" else wb1.sheet_names()
    sheets2 = wb2.sheetnames if engine2 == "openpyxl" else wb2.sheet_names()

    # Determine output format based on output_file extension
    output_ext = Path(output_file).suffix.lower()
    
    if output_ext == ".xlsx":
        if not openpyxl:
            raise ImportError("openpyxl is required for .xlsx output. Install with: pip install openpyxl")
        merged_wb = openpyxl.Workbook()
        merged_wb.remove(merged_wb.active)  # Remove default sheet
        use_openpyxl = True
    elif output_ext == ".xls":
        if not xlwt:
            raise ImportError("xlwt is required for .xls output. Install with: pip install xlwt")
        merged_wb = xlwt.Workbook()
        use_openpyxl = False
    else:
        # Default to .xlsx if no extension
        if not openpyxl:
            raise ImportError("openpyxl is required. Install with: pip install openpyxl")
        merged_wb = openpyxl.Workbook()
        merged_wb.remove(merged_wb.active)
        output_file = str(Path(output_file).with_suffix(".xlsx"))
        use_openpyxl = True

    # Process sheets from file1
    for sheet_name in sheets1:
        if use_openpyxl:
            merged_sheet = merged_wb.create_sheet(sheet_name)
        else:
            merged_sheet = merged_wb.add_sheet(sheet_name)

        # Get sheet1 data
        if engine1 == "openpyxl":
            ws1 = wb1[sheet_name]
            rows1, cols1 = ws1.max_row, ws1.max_column
        else:
            ws1 = wb1.sheet_by_name(sheet_name)
            rows1, cols1 = ws1.nrows, ws1.ncols

        # Copy content from file1
        for r in range(rows1):
            for c in range(cols1):
                if engine1 == "openpyxl":
                    val = ws1.cell(row=r + 1, column=c + 1).value
                    merged_sheet.cell(row=r + 1, column=c + 1, value=val)
                else:
                    val = ws1.cell_value(r, c)
                    if use_openpyxl:
                        merged_sheet.cell(row=r + 1, column=c + 1, value=val)
                    else:
                        merged_sheet.write(r, c, val)

        # If sheet exists in file2, merge it
        if sheet_name in sheets2:
            if verbose:
                print(f"Merging sheet: {sheet_name}")

            # Get sheet2 data
            if engine2 == "openpyxl":
                ws2 = wb2[sheet_name]
                rows2, cols2 = ws2.max_row, ws2.max_column
            else:
                ws2 = wb2.sheet_by_name(sheet_name)
                rows2, cols2 = ws2.nrows, ws2.ncols

            # Determine start row for appending data from file2
            # For openpyxl: rows are 1-indexed, start from rows1+1
            # For xlwt: rows are 0-indexed, start from rows1
            if skip_header_row:
                # Skip header row (row 0/index 0), start appending from row 1
                start_row_file2 = 1
                start_row_merged = rows1  # Append after all rows from file1
            else:
                # Include all rows, append starting from rows1
                start_row_file2 = 0
                start_row_merged = rows1

            # Copy content from file2
            for r in range(start_row_file2, rows2):
                for c in range(min(cols1, cols2) if cols1 > 0 else cols2):
                    if engine2 == "openpyxl":
                        val = ws2.cell(row=r + 1, column=c + 1).value
                    else:
                        val = ws2.cell_value(r, c)

                    # Calculate target row in merged sheet
                    target_row = start_row_merged + (r - start_row_file2)
                    
                    if use_openpyxl:
                        merged_sheet.cell(row=target_row + 1, column=c + 1, value=val)
                    else:
                        merged_sheet.write(target_row, c, val)
        else:
            if verbose:
                print(f"Sheet '{sheet_name}' only in file1")

    # Process sheets from file2 that don't exist in file1
    for sheet_name in sheets2:
        if sheet_name not in sheets1:
            if verbose:
                print(f"Adding sheet '{sheet_name}' from file2")

            if use_openpyxl:
                merged_sheet = merged_wb.create_sheet(sheet_name)
            else:
                merged_sheet = merged_wb.add_sheet(sheet_name)

            # Get sheet2 data
            if engine2 == "openpyxl":
                ws2 = wb2[sheet_name]
                rows2, cols2 = ws2.max_row, ws2.max_column
            else:
                ws2 = wb2.sheet_by_name(sheet_name)
                rows2, cols2 = ws2.nrows, ws2.ncols

            # Copy content from file2
            for r in range(rows2):
                for c in range(cols2):
                    if engine2 == "openpyxl":
                        val = ws2.cell(row=r + 1, column=c + 1).value
                        merged_sheet.cell(row=r + 1, column=c + 1, value=val)
                    else:
                        val = ws2.cell_value(r, c)
                        if use_openpyxl:
                            merged_sheet.cell(row=r + 1, column=c + 1, value=val)
                        else:
                            merged_sheet.write(r, c, val)

    # Save the merged workbook
    if use_openpyxl:
        merged_wb.save(output_file)
    else:
        merged_wb.save(output_file)

    if verbose:
        print(f"\nMerged file saved to: {output_file}")

    return output_file
