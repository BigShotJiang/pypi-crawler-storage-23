"""
Excel file comparison functionality
"""

from pathlib import Path

try:
    import openpyxl
except ImportError:
    openpyxl = None

try:
    import xlrd
except ImportError:
    xlrd = None

SUPPORTED_EXTENSIONS = [".xls", ".xlsx"]


def load_workbook(file_path):
    """Load an Excel workbook using the appropriate library."""
    ext = Path(file_path).suffix.lower()

    if ext == ".xlsx":
        if not openpyxl:
            raise ImportError("openpyxl is required for .xlsx files. Install with: pip install openpyxl")
        return openpyxl.load_workbook(file_path, data_only=True), "openpyxl"

    elif ext == ".xls":
        if not xlrd:
            raise ImportError("xlrd is required for .xls files. Install with: pip install xlrd")
        return xlrd.open_workbook(file_path), "xlrd"

    else:
        raise ValueError(f"Unsupported file type: {ext}. Supported: {SUPPORTED_EXTENSIONS}")


def compare_excel_files(file1, file2, verbose=True):
    """
    Compare two Excel files and report differences.
    
    Args:
        file1: Path to first Excel file
        file2: Path to second Excel file
        verbose: If True, print detailed differences
        
    Returns:
        bool: True if differences found, False otherwise
    """
    differences_found = False

    wb1, engine1 = load_workbook(file1)
    wb2, engine2 = load_workbook(file2)

    sheets1 = wb1.sheetnames if engine1 == "openpyxl" else wb1.sheet_names()
    sheets2 = wb2.sheetnames if engine2 == "openpyxl" else wb2.sheet_names()

    if verbose:
        print(f"\nComparing:\n  FILE1  : {file1}\n  FILE2  : {file2}\n")

    # Check missing sheets
    for sheet in sheets1:
        if sheet not in sheets2:
            if verbose:
                print(f"Sheet missing in FILE2: {sheet}")
            differences_found = True

    for sheet in sheets2:
        if sheet not in sheets1:
            if verbose:
                print(f"Sheet missing in FILE1: {sheet}")
            differences_found = True

    # Compare common sheets
    for sheet in set(sheets1).intersection(sheets2):

        if engine1 == "openpyxl":
            ws1 = wb1[sheet]
            ws2 = wb2[sheet]
            rows1, cols1 = ws1.max_row, ws1.max_column
            rows2, cols2 = ws2.max_row, ws2.max_column
        else:
            ws1 = wb1.sheet_by_name(sheet)
            ws2 = wb2.sheet_by_name(sheet)
            rows1, cols1 = ws1.nrows, ws1.ncols
            rows2, cols2 = ws2.nrows, ws2.ncols

        # Row/Column count check
        if rows1 != rows2 or cols1 != cols2:
            if verbose:
                print(
                    f"Structure mismatch in '{sheet}' "
                    f"(FILE1: {rows1}x{cols1}, FILE2: {rows2}x{cols2})"
                )
            differences_found = True

        # Cell comparison
        min_rows = min(rows1, rows2)
        min_cols = min(cols1, cols2)

        for r in range(min_rows):
            for c in range(min_cols):

                if engine1 == "openpyxl":
                    val1 = ws1.cell(row=r + 1, column=c + 1).value
                    val2 = ws2.cell(row=r + 1, column=c + 1).value
                else:
                    val1 = ws1.cell_value(r, c)
                    val2 = ws2.cell_value(r, c)

                if val1 != val2:
                    if verbose:
                        print(
                            f"Cell mismatch [{sheet}] "
                            f"Row {r+1}, Col {c+1} | "
                            f"FILE1='{val1}' vs FILE2='{val2}'"
                        )
                    differences_found = True

    return differences_found
