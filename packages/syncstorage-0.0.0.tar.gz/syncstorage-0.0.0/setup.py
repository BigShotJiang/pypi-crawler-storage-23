"""
Empty setup.py for syncstorage
Target: HackerOne Bug Bounty - mozilla-services
"""
from setuptools import setup

setup(
    name="syncstorage",
    version="0.0.0",
    description="Empty placeholder package - reserved for mozilla-services",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
