"""
Google Workspace Admin SDK integration for user and group synchronization.

This module provides a client for syncing Google Workspace users and groups
to Django's user management and tenant access control systems.

Usage:
    from lightwave.integrations.google_workspace import (
        GoogleWorkspaceClient,
        get_workspace_client,
    )

    client = get_workspace_client()
    users = client.list_users()
    groups = client.list_groups()
    members = client.get_group_members("admins@example.com")
"""

from lightwave.integrations.google_workspace.client import (
    GoogleWorkspaceClient,
    get_workspace_client,
)

__all__ = [
    "GoogleWorkspaceClient",
    "get_workspace_client",
]
