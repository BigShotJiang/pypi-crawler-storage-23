"""QuickBooks Online integration for LightWave applications.

Provides a pure Python client for QuickBooks API operations.
OAuth token storage is handled by the consuming application.

Usage:
    from lightwave.integrations.quickbooks import QuickBooksClient

    client = QuickBooksClient(
        client_id="your_client_id",
        client_secret="your_client_secret",
        access_token="stored_access_token",
        refresh_token="stored_refresh_token",
        realm_id="company_id",
    )

    # Get customers
    customers = client.get_customers()

    # Create invoice
    invoice = client.create_invoice(
        customer_id="123",
        line_items=[{"description": "Service", "amount": 1000}],
    )
"""

from lightwave.integrations.quickbooks.client import QuickBooksClient
from lightwave.integrations.quickbooks.oauth import (
    QB_AUTHORIZATION_URL,
    QB_SCOPES,
    QB_TOKEN_URL,
    build_authorization_url,
    exchange_code_for_tokens,
    refresh_access_token,
    revoke_token,
)

__all__ = [
    "QuickBooksClient",
    "QB_AUTHORIZATION_URL",
    "QB_TOKEN_URL",
    "QB_SCOPES",
    "build_authorization_url",
    "exchange_code_for_tokens",
    "refresh_access_token",
    "revoke_token",
]
