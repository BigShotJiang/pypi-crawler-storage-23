"""
Stripe Integration Package

Provides typed Pydantic contracts and utilities for Stripe integration.
Contracts are generated from Stripe's OpenAPI specification.

Usage:
    from lightwave.integrations.stripe import (
        StripeClient,
        verify_webhook_signature,
    )

    from lightwave.integrations.stripe.contracts import (
        StripeEvent,
        parse_event,
        CheckoutSessionCompletedEvent,
    )

    from lightwave.integrations.stripe.webhooks import (
        WebhookDispatcher,
    )
"""

from lightwave.integrations.stripe.client import (
    StripeClient,
    get_stripe_client,
    verify_webhook_signature,
)

__all__ = [
    "StripeClient",
    "get_stripe_client",
    "verify_webhook_signature",
]
