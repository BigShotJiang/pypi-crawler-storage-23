"""
Stripe Contracts - Auto-Generated

DO NOT EDIT - This file is generated from Stripe's OpenAPI specification.
Regenerate with: python scripts/stripe/generate_contracts.py resources

Generated: 2026-01-29T21:20:37.300586+00:00
Stripe API Version: 2026-01-28.clover
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# Forward references for type hints
# Customer
# Product
# Price
# Subscription
# SubscriptionItem
# Invoice
# PaymentIntent
# PaymentMethod
# Charge
# CheckoutSession
# Plan
# BillingPortalSession
# BillingPortalConfiguration
# TaxRate
# Coupon
# PromotionCode
# Discount


class Customer(BaseModel):
    """This object represents a customer of your business. Use it to [create recurring charges](https://docs.stripe.com/invoicing/customer), [save payment](https://docs.stripe.com/payments/save-during-payment) and contact information,
    and track payments that belong to the same customer."""

    object: Literal["customer"] = "customer"

    address: Any | None = Field(description="The customer's address.", default=None)
    balance: int = Field(
        description="The current balance, if any, that's stored on the customer in their default currency. If negative, the customer has credit to apply to their next invoice. If positive, the customer has an amount owed that's added to their next invoice. The balance only considers amounts that Stripe hasn't successfully applied to any invoice. It doesn't reflect unpaid invoices. This balance is only taken into account after invoices finalize. For multi-currency balances, see [invoice_credit_balance](https://docs.stripe.com/api/customers/object#customer_object-invoice_credit_balance).",
        default=None,
    )
    business_name: str = Field(description="The customer's business name.", default=None)
    cash_balance: Any | None = Field(
        description='The current funds being held by Stripe on behalf of the customer. You can apply these funds towards payment intents when the source is "cash_balance". The `settings[reconciliation_mode]` field describes if these funds apply to these payment intents manually or automatically.',
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str | None = Field(
        description="Three-letter [ISO code for the currency](https://stripe.com/docs/currencies) the customer can be charged in for recurring billing purposes.",
        default=None,
    )
    customer_account: str | None = Field(
        description="The ID of an Account representing a customer. You can use this ID with any v1 API that accepts a customer_account parameter.",
        default=None,
    )
    default_source: str | Any | None = Field(
        description="ID of the default payment source for the customer.  If you use payment methods created through the PaymentMethods API, see the [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) field instead.",
        default=None,
    )
    delinquent: bool | None = Field(
        description="Tracks the most recent state change on any invoice belonging to the customer. Paying an invoice or marking it uncollectible via the API will set this field to false. An automatic payment failure or passing the `invoice.due_date` will set this field to `true`.  If an invoice becomes uncollectible by [dunning](https://docs.stripe.com/billing/automatic-collection), `delinquent` doesn't reset to `false`.  If you care whether the customer has paid their most recent subscription invoice, use `subscription.status` instead. Paying or marking uncollectible any customer invoice regardless of whether it is the latest invoice for a subscription will always set this field to `false`.",
        default=None,
    )
    description: str | None = Field(
        description="An arbitrary string attached to the object. Often useful for displaying to users.", default=None
    )
    discount: Discount | None = Field(
        description="Describes the current discount active on the customer, if there is one.", default=None
    )
    email: str | None = Field(description="The customer's email address.", default=None)
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    individual_name: str = Field(description="The customer's individual name.", default=None)
    invoice_credit_balance: dict[str, int] = Field(
        description="The current multi-currency balances, if any, that's stored on the customer. If positive in a currency, the customer has a credit to apply to their next invoice denominated in that currency. If negative, the customer has an amount owed that's added to their next invoice denominated in that currency. These balances don't apply to unpaid invoices. They solely track amounts that Stripe hasn't successfully applied to any invoice. Stripe only applies a balance in a specific currency to an invoice after that invoice (which is in the same currency) finalizes.",
        default=None,
    )
    invoice_prefix: str | None = Field(
        description="The prefix for the customer used to generate unique invoice numbers.", default=None
    )
    invoice_settings: Any = Field(default=None)
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    name: str | None = Field(description="The customer's full name or business name.", default=None)
    next_invoice_sequence: int = Field(
        description="The suffix of the customer's next invoice number (for example, 0001). When the account uses account level sequencing, this parameter is ignored in API requests and the field omitted in API responses.",
        default=None,
    )
    object_: Literal["customer"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    phone: str | None = Field(description="The customer's phone number.", default=None)
    preferred_locales: list[str] | None = Field(
        description="The customer's preferred locales (languages), ordered by preference.", default=None
    )
    shipping: Any | None = Field(
        description="Mailing and shipping address for the customer. Appears on invoices emailed to this customer.",
        default=None,
    )
    sources: dict[str, Any] = Field(description="The customer's payment sources, if any.", default=None)
    subscriptions: dict[str, Any] = Field(description="The customer's current subscriptions, if any.", default=None)
    tax: Any = Field(default=None)
    tax_exempt: Literal["exempt", "none", "reverse"] | None = Field(
        description='Describes the customer\'s tax exemption status, which is `none`, `exempt`, or `reverse`. When set to `reverse`, invoice and receipt PDFs include the following text: **"Reverse charge"**.',
        default=None,
    )
    tax_ids: dict[str, Any] = Field(description="The customer's tax IDs.", default=None)
    test_clock: str | Any | None = Field(
        description="ID of the test clock that this customer belongs to.", default=None
    )


class Product(BaseModel):
    """Products describe the specific goods or services you offer to your customers.
    For example, you might offer a Standard and Premium version of your goods or service; each version would be a separate Product.
    They can be used in conjunction with [Prices](https://api.stripe.com#prices) to configure pricing in Payment Links, Checkout, and Subscriptions.

    Related guides: [Set up a subscription](https://docs.stripe.com/billing/subscriptions/set-up-subscription),
    [share a Payment Link](https://docs.stripe.com/payment-links),
    [accept payments with Checkout](https://docs.stripe.com/payments/accept-a-payment#create-product-prices-upfront),
    and more about [Products and Prices](https://docs.stripe.com/products-prices/overview)"""

    object: Literal["product"] = "product"

    active: bool = Field(description="Whether the product is currently available for purchase.")
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    default_price: str | Price | None = Field(
        description="The ID of the [Price](https://docs.stripe.com/api/prices) object that is the default price for this product.",
        default=None,
    )
    description: str | None = Field(
        description="The product's description, meant to be displayable to the customer. Use this field to optionally store a long form explanation of the product being sold for your own rendering purposes.",
        default=None,
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    images: list[str] = Field(
        description="A list of up to 8 URLs of images for this product, meant to be displayable to the customer."
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    marketing_features: list[Any] = Field(
        description="A list of up to 15 marketing features for this product. These are displayed in [pricing tables](https://docs.stripe.com/payments/checkout/pricing-table)."
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format."
    )
    name: str = Field(description="The product's name, meant to be displayable to the customer.")
    object_: Literal["product"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    package_dimensions: Any | None = Field(
        description="The dimensions of this product for shipping purposes.", default=None
    )
    shippable: bool | None = Field(description="Whether this product is shipped (i.e., physical goods).", default=None)
    statement_descriptor: str | None = Field(
        description="Extra information about a product which will appear on your customer's credit card statement. In the case that multiple products are billed at once, the first statement descriptor will be used. Only used for subscription payments.",
        default=None,
    )
    tax_code: str | Any | None = Field(
        description="A [tax code](https://docs.stripe.com/tax/tax-categories) ID.", default=None
    )
    unit_label: str | None = Field(
        description="A label that represents units of this product. When set, this will be included in customers' receipts, invoices, Checkout, and the customer portal.",
        default=None,
    )
    updated: int = Field(
        description="Time at which the object was last updated. Measured in seconds since the Unix epoch."
    )
    url: str | None = Field(description="A URL of a publicly-accessible webpage for this product.", default=None)


class Price(BaseModel):
    """Prices define the unit cost, currency, and (optional) billing cycle for both recurring and one-time purchases of products.
    [Products](https://api.stripe.com#products) help you track inventory or provisioning, and prices help you track payment terms. Different physical goods or levels of service should be represented by products, and pricing options should be represented by prices. This approach lets you change prices without having to change your provisioning scheme.

    For example, you might have a single "gold" product that has prices for $10/month, $100/year, and €9 once.

    Related guides: [Set up a subscription](https://docs.stripe.com/billing/subscriptions/set-up-subscription), [create an invoice](https://docs.stripe.com/billing/invoices/create), and more about [products and prices](https://docs.stripe.com/products-prices/overview)."""

    object: Literal["price"] = "price"

    active: bool = Field(description="Whether the price can be used for new purchases.")
    billing_scheme: Literal["per_unit", "tiered"] = Field(
        description="Describes how to compute the price per period. Either `per_unit` or `tiered`. `per_unit` indicates that the fixed amount (specified in `unit_amount` or `unit_amount_decimal`) will be charged per unit in `quantity` (for prices with `usage_type=licensed`), or per unit of total usage (for prices with `usage_type=metered`). `tiered` indicates that the unit pricing will be computed using a tiering strategy as defined using the `tiers` and `tiers_mode` attributes."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies)."
    )
    currency_options: dict[str, Any] = Field(
        description="Prices defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).",
        default=None,
    )
    custom_unit_amount: Any | None = Field(
        description="When set, provides configuration for the amount to be adjusted by the customer during Checkout Sessions and Payment Links.",
        default=None,
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    lookup_key: str | None = Field(
        description="A lookup key used to retrieve prices dynamically from a static string. This may be up to 200 characters.",
        default=None,
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format."
    )
    nickname: str | None = Field(description="A brief description of the price, hidden from customers.", default=None)
    object_: Literal["price"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    product: str | Product | Any = Field(description="The ID of the product this price is associated with.")
    recurring: Any | None = Field(
        description="The recurring components of a price such as `interval` and `usage_type`.", default=None
    )
    tax_behavior: Literal["exclusive", "inclusive", "unspecified"] | None = Field(
        description="Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.",
        default=None,
    )
    tiers: list[Any] = Field(
        description="Each element represents a pricing tier. This parameter requires `billing_scheme` to be set to `tiered`. See also the documentation for `billing_scheme`.",
        default=None,
    )
    tiers_mode: Literal["graduated", "volume"] | None = Field(
        description="Defines if the tiering price should be `graduated` or `volume` based. In `volume`-based tiering, the maximum quantity within a period determines the per unit price. In `graduated` tiering, pricing can change as the quantity grows.",
        default=None,
    )
    transform_quantity: Any | None = Field(
        description="Apply a transformation to the reported usage or set quantity before computing the amount billed. Cannot be combined with `tiers`.",
        default=None,
    )
    type_: Literal["one_time", "recurring"] = Field(
        alias="type",
        description="One of `one_time` or `recurring` depending on whether the price is for a one-time purchase or a recurring (subscription) purchase.",
    )
    unit_amount: int | None = Field(
        description="The unit amount in cents (or local equivalent) to be charged, represented as a whole integer if possible. Only set if `billing_scheme=per_unit`.",
        default=None,
    )
    unit_amount_decimal: str | None = Field(
        description="The unit amount in cents (or local equivalent) to be charged, represented as a decimal string with at most 12 decimal places. Only set if `billing_scheme=per_unit`.",
        default=None,
    )


class Subscription(BaseModel):
    """Subscriptions allow you to charge a customer on a recurring basis.

    Related guide: [Creating subscriptions](https://docs.stripe.com/billing/subscriptions/creating)"""

    object: Literal["subscription"] = "subscription"

    application: str | Any | None = Field(
        description="ID of the Connect Application that created the subscription.", default=None
    )
    application_fee_percent: float | None = Field(
        description="A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account.",
        default=None,
    )
    automatic_tax: Any
    billing_cycle_anchor: int = Field(
        description="The reference point that aligns future [billing cycle](https://docs.stripe.com/subscriptions/billing-cycle) dates. It sets the day of week for `week` intervals, the day of month for `month` and `year` intervals, and the month of year for `year` intervals. The timestamp is in UTC format."
    )
    billing_cycle_anchor_config: Any | None = Field(
        description="The fixed values used to calculate the `billing_cycle_anchor`.", default=None
    )
    billing_mode: Any
    billing_thresholds: Any | None = Field(
        description="Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period",
        default=None,
    )
    cancel_at: int | None = Field(
        description="A date in the future at which the subscription will automatically get canceled", default=None
    )
    cancel_at_period_end: bool = Field(
        description="Whether this subscription will (if `status=active`) or did (if `status=canceled`) cancel at the end of the current billing period."
    )
    canceled_at: int | None = Field(
        description="If the subscription has been canceled, the date of that cancellation. If the subscription was canceled with `cancel_at_period_end`, `canceled_at` will reflect the time of the most recent update request, not the end of the subscription period when the subscription is automatically moved to a canceled state.",
        default=None,
    )
    cancellation_details: Any | None = Field(
        description="Details about why this subscription was cancelled", default=None
    )
    collection_method: Literal["charge_automatically", "send_invoice"] = Field(
        description="Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this subscription at the end of the cycle using the default source attached to the customer. When sending an invoice, Stripe will email your customer an invoice with payment instructions and mark the subscription as `active`."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies)."
    )
    customer: str | Customer | Any = Field(description="ID of the customer who owns the subscription.")
    customer_account: str | None = Field(
        description="ID of the account representing the customer who owns the subscription.", default=None
    )
    days_until_due: int | None = Field(
        description="Number of days a customer has to pay invoices generated by this subscription. This value will be `null` for subscriptions where `collection_method=charge_automatically`.",
        default=None,
    )
    default_payment_method: str | PaymentMethod | None = Field(
        description="ID of the default payment method for the subscription. It must belong to the customer associated with the subscription. This takes precedence over `default_source`. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).",
        default=None,
    )
    default_source: str | Any | None = Field(
        description="ID of the default payment source for the subscription. It must belong to the customer associated with the subscription and be in a chargeable state. If `default_payment_method` is also set, `default_payment_method` will take precedence. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).",
        default=None,
    )
    default_tax_rates: list[TaxRate] | None = Field(
        description="The tax rates that will apply to any subscription item that does not have `tax_rates` set. Invoices created will have their `default_tax_rates` populated from the subscription.",
        default=None,
    )
    description: str | None = Field(
        description="The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.",
        default=None,
    )
    discounts: list[str | Discount] = Field(
        description="The discounts applied to the subscription. Subscription item discounts are applied before subscription discounts. Use `expand[]=discounts` to expand each discount."
    )
    ended_at: int | None = Field(
        description="If the subscription has ended, the date the subscription ended.", default=None
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    invoice_settings: Any
    items: dict[str, Any] = Field(description="List of subscription items, each with an attached price.")
    latest_invoice: str | Invoice | None = Field(
        description="The most recent invoice this subscription has generated over its lifecycle (for example, when it cycles or is updated).",
        default=None,
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format."
    )
    next_pending_invoice_item_invoice: int | None = Field(
        description="Specifies the approximate timestamp on which any pending invoice items will be billed according to the schedule provided at `pending_invoice_item_interval`.",
        default=None,
    )
    object_: Literal["subscription"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    on_behalf_of: str | Any | None = Field(
        description="The account (if any) the charge was made on behalf of for charges associated with this subscription. See the [Connect documentation](https://docs.stripe.com/connect/subscriptions#on-behalf-of) for details.",
        default=None,
    )
    pause_collection: Any | None = Field(
        description="If specified, payment collection for this subscription will be paused. Note that the subscription status will be unchanged and will not be updated to `paused`. Learn more about [pausing collection](https://docs.stripe.com/billing/subscriptions/pause-payment).",
        default=None,
    )
    payment_settings: Any | None = Field(
        description="Payment settings passed on to invoices created by the subscription.", default=None
    )
    pending_invoice_item_interval: Any | None = Field(
        description="Specifies an interval for how often to bill for any pending invoice items. It is analogous to calling [Create an invoice](https://docs.stripe.com/api#create_invoice) for the given subscription at the specified interval.",
        default=None,
    )
    pending_setup_intent: str | Any | None = Field(
        description="You can use this [SetupIntent](https://docs.stripe.com/api/setup_intents) to collect user authentication when creating a subscription without immediate payment or updating a subscription's payment method, allowing you to optimize for off-session payments. Learn more in the [SCA Migration Guide](https://docs.stripe.com/billing/migration/strong-customer-authentication#scenario-2).",
        default=None,
    )
    pending_update: Any | None = Field(
        description="If specified, [pending updates](https://docs.stripe.com/billing/subscriptions/pending-updates) that will be applied to the subscription once the `latest_invoice` has been paid.",
        default=None,
    )
    schedule: str | Any | None = Field(description="The schedule attached to the subscription", default=None)
    start_date: int = Field(
        description="Date when the subscription was first created. The date might differ from the `created` date due to backdating."
    )
    status: Literal[
        "active", "canceled", "incomplete", "incomplete_expired", "past_due", "paused", "trialing", "unpaid"
    ] = Field(
        description="Possible values are `incomplete`, `incomplete_expired`, `trialing`, `active`, `past_due`, `canceled`, `unpaid`, or `paused`.   For `collection_method=charge_automatically` a subscription moves into `incomplete` if the initial payment attempt fails. A subscription in this status can only have metadata and default_source updated. Once the first invoice is paid, the subscription moves into an `active` status. If the first invoice is not paid within 23 hours, the subscription transitions to `incomplete_expired`. This is a terminal status, the open invoice will be voided and no further invoices will be generated.   A subscription that is currently in a trial period is `trialing` and moves to `active` when the trial period is over.   A subscription can only enter a `paused` status [when a trial ends without a payment method](https://docs.stripe.com/billing/subscriptions/trials#create-free-trials-without-payment). A `paused` subscription doesn't generate invoices and can be resumed after your customer adds their payment method. The `paused` status is different from [pausing collection](https://docs.stripe.com/billing/subscriptions/pause-payment), which still generates invoices and leaves the subscription's status unchanged.   If subscription `collection_method=charge_automatically`, it becomes `past_due` when payment is required but cannot be paid (due to failed payment or awaiting additional user actions). Once Stripe has exhausted all payment retry attempts, the subscription will become `canceled` or `unpaid` (depending on your subscriptions settings).   If subscription `collection_method=send_invoice` it becomes `past_due` when its invoice is not paid by the due date, and `canceled` or `unpaid` if it is still not paid by an additional deadline after that. Note that when a subscription has a status of `unpaid`, no subsequent invoices will be attempted (invoices will be created, but then immediately automatically closed). After receiving updated payment information from a customer, you may choose to reopen and pay their closed invoices."
    )
    test_clock: str | Any | None = Field(description="ID of the test clock this subscription belongs to.", default=None)
    transfer_data: Any | None = Field(
        description="The account (if any) the subscription's payments will be attributed to for tax reporting, and where funds from each payment will be transferred to for each of the subscription's invoices.",
        default=None,
    )
    trial_end: int | None = Field(description="If the subscription has a trial, the end of that trial.", default=None)
    trial_settings: Any | None = Field(description="Settings related to subscription trials.", default=None)
    trial_start: int | None = Field(
        description="If the subscription has a trial, the beginning of that trial.", default=None
    )


class SubscriptionItem(BaseModel):
    """Subscription items allow you to create customer subscriptions with more than
    one plan, making it easy to represent complex billing relationships."""

    object: Literal["subscription_item"] = "subscription_item"

    billing_thresholds: Any | None = Field(
        description="Define thresholds at which an invoice will be sent, and the related subscription advanced to a new billing period",
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    current_period_end: int = Field(description="The end time of this subscription item's current billing period.")
    current_period_start: int = Field(description="The start time of this subscription item's current billing period.")
    discounts: list[str | Discount] = Field(
        description="The discounts applied to the subscription item. Subscription item discounts are applied before subscription discounts. Use `expand[]=discounts` to expand each discount."
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format."
    )
    object_: Literal["subscription_item"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    price: Price
    quantity: int = Field(
        description="The [quantity](https://docs.stripe.com/subscriptions/quantities) of the plan to which the customer should be subscribed.",
        default=None,
    )
    subscription: str = Field(description="The `subscription` this `subscription_item` belongs to.")
    tax_rates: list[TaxRate] | None = Field(
        description="The tax rates which apply to this `subscription_item`. When set, the `default_tax_rates` on the subscription do not apply to this `subscription_item`.",
        default=None,
    )


class Invoice(BaseModel):
    """Invoices are statements of amounts owed by a customer, and are either
    generated one-off, or generated periodically from a subscription.

    They contain [invoice items](https://api.stripe.com#invoiceitems), and proration adjustments
    that may be caused by subscription upgrades/downgrades (if necessary).

    If your invoice is configured to be billed through automatic charges,
    Stripe automatically finalizes your invoice and attempts payment. Note
    that finalizing the invoice,
    [when automatic](https://docs.stripe.com/invoicing/integration/automatic-advancement-collection), does
    not happen immediately as the invoice is created. Stripe waits
    until one hour after the last webhook was successfully sent (or the last
    webhook timed out after failing). If you (and the platforms you may have
    connected to) have no webhooks configured, Stripe waits one hour after
    creation to finalize the invoice.

    If your invoice is configured to be billed by sending an email, then based on your
    [email settings](https://dashboard.stripe.com/account/billing/automatic),
    Stripe will email the invoice to your customer and await payment. These
    emails can contain a link to a hosted page to pay the invoice.

    Stripe applies any customer credit on the account before determining the
    amount due for the invoice (i.e., the amount that will be actually
    charged). If the amount due for the invoice is less than Stripe's [minimum allowed charge
    per currency](/docs/currencies#minimum-and-maximum-charge-amounts), the
    invoice is automatically marked paid, and we add the amount due to the
    customer's credit balance which is applied to the next invoice.

    More details on the customer's credit balance are
    [here](https://docs.stripe.com/billing/customer/balance).

    Related guide: [Send invoices to customers](https://docs.stripe.com/billing/invoices/sending)"""

    object: Literal["invoice"] = "invoice"

    account_country: str | None = Field(
        description="The country of the business associated with this invoice, most often the business creating the invoice.",
        default=None,
    )
    account_name: str | None = Field(
        description="The public name of the business associated with this invoice, most often the business creating the invoice.",
        default=None,
    )
    account_tax_ids: list[str | Any] | None = Field(
        description="The account tax IDs associated with the invoice. Only editable when the invoice is a draft.",
        default=None,
    )
    amount_due: int = Field(
        description="Final amount due at this time for this invoice. If the invoice's total is smaller than the minimum charge amount, for example, or if there is account credit that can be applied to the invoice, the `amount_due` may be 0. If there is a positive `starting_balance` for the invoice (the customer owes money), the `amount_due` will also take that into account. The charge that gets generated for the invoice will be for the amount specified in `amount_due`."
    )
    amount_overpaid: int = Field(
        description="Amount that was overpaid on the invoice. The amount overpaid is credited to the customer's credit balance."
    )
    amount_paid: int = Field(description="The amount, in cents (or local equivalent), that was paid.")
    amount_remaining: int = Field(
        description="The difference between amount_due and amount_paid, in cents (or local equivalent)."
    )
    amount_shipping: int = Field(description="This is the sum of all the shipping amounts.")
    application: str | Any | None = Field(
        description="ID of the Connect Application that created the invoice.", default=None
    )
    attempt_count: int = Field(
        description="Number of payment attempts made for this invoice, from the perspective of the payment retry schedule. Any payment attempt counts as the first attempt, and subsequently only automatic retries increment the attempt count. In other words, manual payment attempts after the first attempt do not affect the retry schedule. If a failure is returned with a non-retryable return code, the invoice can no longer be retried unless a new payment method is obtained. Retries will continue to be scheduled, and attempt_count will continue to increment, but retries will only be executed if a new payment method is obtained."
    )
    attempted: bool = Field(
        description="Whether an attempt has been made to pay the invoice. An invoice is not attempted until 1 hour after the `invoice.created` webhook, for example, so you might not want to display that invoice as unpaid to your users."
    )
    auto_advance: bool = Field(
        description="Controls whether Stripe performs [automatic collection](https://docs.stripe.com/invoicing/integration/automatic-advancement-collection) of the invoice. If `false`, the invoice's state doesn't automatically advance without an explicit action."
    )
    automatic_tax: Any
    automatically_finalizes_at: int | None = Field(
        description="The time when this invoice is currently scheduled to be automatically finalized. The field will be `null` if the invoice is not scheduled to finalize in the future. If the invoice is not in the draft state, this field will always be `null` - see `finalized_at` for the time when an already-finalized invoice was finalized.",
        default=None,
    )
    billing_reason: (
        Literal[
            "automatic_pending_invoice_item_invoice",
            "manual",
            "quote_accept",
            "subscription",
            "subscription_create",
            "subscription_cycle",
            "subscription_threshold",
            "subscription_update",
            "upcoming",
        ]
        | None
    ) = Field(
        description="Indicates the reason why the invoice was created.  * `manual`: Unrelated to a subscription, for example, created via the invoice editor. * `subscription`: No longer in use. Applies to subscriptions from before May 2018 where no distinction was made between updates, cycles, and thresholds. * `subscription_create`: A new subscription was created. * `subscription_cycle`: A subscription advanced into a new period. * `subscription_threshold`: A subscription reached a billing threshold. * `subscription_update`: A subscription was updated. * `upcoming`: Reserved for upcoming invoices created through the Create Preview Invoice API or when an `invoice.upcoming` event is generated for an upcoming invoice on a subscription.",
        default=None,
    )
    collection_method: Literal["charge_automatically", "send_invoice"] = Field(
        description="Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this invoice using the default source attached to the customer. When sending an invoice, Stripe will email this invoice to the customer with payment instructions."
    )
    confirmation_secret: Any | None = Field(
        description="The confirmation secret associated with this invoice. Currently, this contains the client_secret of the PaymentIntent that Stripe creates during invoice finalization.",
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies)."
    )
    custom_fields: list[Any] | None = Field(description="Custom fields displayed on the invoice.", default=None)
    customer: str | Customer | Any = Field(description="The ID of the customer to bill.")
    customer_account: str | None = Field(
        description="The ID of the account representing the customer to bill.", default=None
    )
    customer_address: Any | None = Field(
        description="The customer's address. Until the invoice is finalized, this field will equal `customer.address`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_email: str | None = Field(
        description="The customer's email. Until the invoice is finalized, this field will equal `customer.email`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_name: str | None = Field(
        description="The customer's name. Until the invoice is finalized, this field will equal `customer.name`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_phone: str | None = Field(
        description="The customer's phone number. Until the invoice is finalized, this field will equal `customer.phone`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_shipping: Any | None = Field(
        description="The customer's shipping information. Until the invoice is finalized, this field will equal `customer.shipping`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_tax_exempt: Literal["exempt", "none", "reverse"] | None = Field(
        description="The customer's tax exempt status. Until the invoice is finalized, this field will equal `customer.tax_exempt`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    customer_tax_ids: list[Any] | None = Field(
        description="The customer's tax IDs. Until the invoice is finalized, this field will contain the same tax IDs as `customer.tax_ids`. Once the invoice is finalized, this field will no longer be updated.",
        default=None,
    )
    default_payment_method: str | PaymentMethod | None = Field(
        description="ID of the default payment method for the invoice. It must belong to the customer associated with the invoice. If not set, defaults to the subscription's default payment method, if any, or to the default payment method in the customer's invoice settings.",
        default=None,
    )
    default_source: str | Any | None = Field(
        description="ID of the default payment source for the invoice. It must belong to the customer associated with the invoice and be in a chargeable state. If not set, defaults to the subscription's default source, if any, or to the customer's default source.",
        default=None,
    )
    default_tax_rates: list[TaxRate] = Field(description="The tax rates applied to this invoice, if any.")
    description: str | None = Field(
        description="An arbitrary string attached to the object. Often useful for displaying to users. Referenced as 'memo' in the Dashboard.",
        default=None,
    )
    discounts: list[str | Discount | Any] = Field(
        description="The discounts applied to the invoice. Line item discounts are applied before invoice discounts. Use `expand[]=discounts` to expand each discount."
    )
    due_date: int | None = Field(
        description="The date on which payment for this invoice is due. This value will be `null` for invoices where `collection_method=charge_automatically`.",
        default=None,
    )
    effective_at: int | None = Field(
        description="The date when this invoice is in effect. Same as `finalized_at` unless overwritten. When defined, this value replaces the system-generated 'Date of issue' printed on the invoice PDF and receipt.",
        default=None,
    )
    ending_balance: int | None = Field(
        description="Ending customer balance after the invoice is finalized. Invoices are finalized approximately an hour after successful webhook delivery or when payment collection is attempted for the invoice. If the invoice has not been finalized yet, this will be null.",
        default=None,
    )
    footer: str | None = Field(description="Footer displayed on the invoice.", default=None)
    from_invoice: Any | None = Field(
        description="Details of the invoice that was cloned. See the [revision documentation](https://docs.stripe.com/invoicing/invoice-revisions) for more details.",
        default=None,
    )
    hosted_invoice_url: str | None = Field(
        description="The URL for the hosted invoice page, which allows customers to view and pay an invoice. If the invoice has not been finalized yet, this will be null.",
        default=None,
    )
    id_: str = Field(
        alias="id",
        description="Unique identifier for the object. For preview invoices created using the [create preview](https://stripe.com/docs/api/invoices/create_preview) endpoint, this id will be prefixed with `upcoming_in`.",
    )
    invoice_pdf: str | None = Field(
        description="The link to download the PDF for the invoice. If the invoice has not been finalized yet, this will be null.",
        default=None,
    )
    issuer: Any
    last_finalization_error: Any | None = Field(
        description="The error encountered during the previous attempt to finalize the invoice. This field is cleared when the invoice is successfully finalized.",
        default=None,
    )
    latest_revision: str | Invoice | None = Field(
        description="The ID of the most recent non-draft revision of this invoice", default=None
    )
    lines: dict[str, Any] = Field(
        description="The individual line items that make up the invoice. `lines` is sorted as follows: (1) pending invoice items (including prorations) in reverse chronological order, (2) subscription items in reverse chronological order, and (3) invoice items added after invoice creation in chronological order."
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    next_payment_attempt: int | None = Field(
        description="The time at which payment will next be attempted. This value will be `null` for invoices where `collection_method=send_invoice`.",
        default=None,
    )
    number: str | None = Field(
        description="A unique, identifying string that appears on emails sent to the customer for this invoice. This starts with the customer's unique invoice_prefix if it is specified.",
        default=None,
    )
    object_: Literal["invoice"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    on_behalf_of: str | Any | None = Field(
        description="The account (if any) for which the funds of the invoice payment are intended. If set, the invoice will be presented with the branding and support information of the specified account. See the [Invoices with Connect](https://docs.stripe.com/billing/invoices/connect) documentation for details.",
        default=None,
    )
    parent: Any | None = Field(description="The parent that generated this invoice", default=None)
    payment_settings: Any
    payments: dict[str, Any] = Field(description="Payments for this invoice", default=None)
    period_end: int = Field(
        description="End of the usage period during which invoice items were added to this invoice. This looks back one period for a subscription invoice. Use the [line item period](/api/invoices/line_item#invoice_line_item_object-period) to get the service period for each price."
    )
    period_start: int = Field(
        description="Start of the usage period during which invoice items were added to this invoice. This looks back one period for a subscription invoice. Use the [line item period](/api/invoices/line_item#invoice_line_item_object-period) to get the service period for each price."
    )
    post_payment_credit_notes_amount: int = Field(
        description="Total amount of all post-payment credit notes issued for this invoice."
    )
    pre_payment_credit_notes_amount: int = Field(
        description="Total amount of all pre-payment credit notes issued for this invoice."
    )
    receipt_number: str | None = Field(
        description="This is the transaction number that appears on email receipts sent for this invoice.", default=None
    )
    rendering: Any | None = Field(
        description="The rendering-related settings that control how the invoice is displayed on customer-facing surfaces such as PDF and Hosted Invoice Page.",
        default=None,
    )
    shipping_cost: Any | None = Field(
        description="The details of the cost of shipping, including the ShippingRate applied on the invoice.",
        default=None,
    )
    shipping_details: Any | None = Field(
        description="Shipping details for the invoice. The Invoice PDF will use the `shipping_details` value if it is set, otherwise the PDF will render the shipping address from the customer.",
        default=None,
    )
    starting_balance: int = Field(
        description="Starting customer balance before the invoice is finalized. If the invoice has not been finalized yet, this will be the current customer balance. For revision invoices, this also includes any customer balance that was applied to the original invoice."
    )
    statement_descriptor: str | None = Field(
        description="Extra information about an invoice for the customer's credit card statement.", default=None
    )
    status: Literal["draft", "open", "paid", "uncollectible", "void"] | None = Field(
        description="The status of the invoice, one of `draft`, `open`, `paid`, `uncollectible`, or `void`. [Learn more](https://docs.stripe.com/billing/invoices/workflow#workflow-overview)",
        default=None,
    )
    status_transitions: Any
    subtotal: int = Field(
        description="Total of all subscriptions, invoice items, and prorations on the invoice before any invoice level discount or exclusive tax is applied. Item discounts are already incorporated"
    )
    subtotal_excluding_tax: int | None = Field(
        description="The integer amount in cents (or local equivalent) representing the subtotal of the invoice before any invoice level discount or tax is applied. Item discounts are already incorporated",
        default=None,
    )
    test_clock: str | Any | None = Field(description="ID of the test clock this invoice belongs to.", default=None)
    threshold_reason: Any = Field(default=None)
    total: int = Field(description="Total after discounts and taxes.")
    total_discount_amounts: list[Any] | None = Field(
        description="The aggregate amounts calculated per discount across all line items.", default=None
    )
    total_excluding_tax: int | None = Field(
        description="The integer amount in cents (or local equivalent) representing the total amount of the invoice including all discounts but excluding all tax.",
        default=None,
    )
    total_pretax_credit_amounts: list[Any] | None = Field(
        description="Contains pretax credit amounts (ex: discount, credit grants, etc) that apply to this invoice. This is a combined list of total_pretax_credit_amounts across all invoice line items.",
        default=None,
    )
    total_taxes: list[Any] | None = Field(description="The aggregate tax information of all line items.", default=None)
    webhooks_delivered_at: int | None = Field(
        description="Invoices are automatically paid or sent 1 hour after webhooks are delivered, or until all webhook delivery attempts have [been exhausted](https://docs.stripe.com/billing/webhooks#understand). This field tracks the time when webhooks for this invoice were successfully delivered. If the invoice had no webhooks to deliver, this will be set while the invoice is being created.",
        default=None,
    )


class PaymentIntent(BaseModel):
    """A PaymentIntent guides you through the process of collecting a payment from your customer.
    We recommend that you create exactly one PaymentIntent for each order or
    customer session in your system. You can reference the PaymentIntent later to
    see the history of payment attempts for a particular session.

    A PaymentIntent transitions through
    [multiple statuses](/payments/paymentintents/lifecycle)
    throughout its lifetime as it interfaces with Stripe.js to perform
    authentication flows and ultimately creates at most one successful charge.

    Related guide: [Payment Intents API](https://docs.stripe.com/payments/payment-intents)"""

    object: Literal["payment_intent"] = "payment_intent"

    amount: int = Field(
        description="Amount intended to be collected by this PaymentIntent. A positive integer representing how much to charge in the [smallest currency unit](https://docs.stripe.com/currencies#zero-decimal) (e.g., 100 cents to charge $1.00 or 100 to charge ¥100, a zero-decimal currency). The minimum amount is $0.50 US or [equivalent in charge currency](https://docs.stripe.com/currencies#minimum-and-maximum-charge-amounts). The amount value supports up to eight digits (e.g., a value of 99999999 for a USD charge of $999,999.99).",
        default=None,
    )
    amount_capturable: int = Field(description="Amount that can be captured from this PaymentIntent.", default=None)
    amount_details: Any = Field(default=None)
    amount_received: int = Field(description="Amount that this PaymentIntent collects.", default=None)
    application: str | Any | None = Field(
        description="ID of the Connect application that created the PaymentIntent.", default=None
    )
    application_fee_amount: int | None = Field(
        description="The amount of the application fee (if any) that will be requested to be applied to the payment and transferred to the application owner's Stripe account. The amount of the application fee collected will be capped at the total amount captured. For more information, see the PaymentIntents [use case for connected accounts](https://docs.stripe.com/payments/connected-accounts).",
        default=None,
    )
    automatic_payment_methods: Any | None = Field(
        description="Settings to configure compatible payment methods from the [Stripe Dashboard](https://dashboard.stripe.com/settings/payment_methods)",
        default=None,
    )
    canceled_at: int | None = Field(
        description="Populated when `status` is `canceled`, this is the time at which the PaymentIntent was canceled. Measured in seconds since the Unix epoch.",
        default=None,
    )
    cancellation_reason: (
        Literal[
            "abandoned",
            "automatic",
            "duplicate",
            "expired",
            "failed_invoice",
            "fraudulent",
            "requested_by_customer",
            "void_invoice",
        ]
        | None
    ) = Field(
        description="Reason for cancellation of this PaymentIntent, either user-provided (`duplicate`, `fraudulent`, `requested_by_customer`, or `abandoned`) or generated by Stripe internally (`failed_invoice`, `void_invoice`, `automatic`, or `expired`).",
        default=None,
    )
    capture_method: Literal["automatic", "automatic_async", "manual"] = Field(
        description="Controls when the funds will be captured from the customer's account.", default=None
    )
    client_secret: str | None = Field(
        description="The client secret of this PaymentIntent. Used for client-side retrieval using a publishable key.   The client secret can be used to complete a payment from your frontend. It should not be stored, logged, or exposed to anyone other than the customer. Make sure that you have TLS enabled on any page that includes the client secret.  Refer to our docs to [accept a payment](https://docs.stripe.com/payments/accept-a-payment?ui=elements) and learn about how `client_secret` should be handled.",
        default=None,
    )
    confirmation_method: Literal["automatic", "manual"] = Field(
        description="Describes whether we can confirm this PaymentIntent automatically, or if it requires customer action to confirm the payment.",
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).",
        default=None,
    )
    customer: str | Customer | Any | None = Field(
        description="ID of the Customer this PaymentIntent belongs to, if one exists.  Payment methods attached to other Customers cannot be used with this PaymentIntent.  If [setup_future_usage](https://api.stripe.com#payment_intent_object-setup_future_usage) is set and this PaymentIntent's payment method is not `card_present`, then the payment method attaches to the Customer after the PaymentIntent has been confirmed and any required actions from the user are complete. If the payment method is `card_present` and isn't a digital wallet, then a [generated_card](https://docs.stripe.com/api/charges/object#charge_object-payment_method_details-card_present-generated_card) payment method representing the card is created and attached to the Customer instead.",
        default=None,
    )
    customer_account: str | None = Field(
        description="ID of the Account representing the customer that this PaymentIntent belongs to, if one exists.  Payment methods attached to other Accounts cannot be used with this PaymentIntent.  If [setup_future_usage](https://api.stripe.com#payment_intent_object-setup_future_usage) is set and this PaymentIntent's payment method is not `card_present`, then the payment method attaches to the Account after the PaymentIntent has been confirmed and any required actions from the user are complete. If the payment method is `card_present` and isn't a digital wallet, then a [generated_card](https://docs.stripe.com/api/charges/object#charge_object-payment_method_details-card_present-generated_card) payment method representing the card is created and attached to the Account instead.",
        default=None,
    )
    description: str | None = Field(
        description="An arbitrary string attached to the object. Often useful for displaying to users.", default=None
    )
    excluded_payment_method_types: (
        list[
            Literal[
                "acss_debit",
                "affirm",
                "afterpay_clearpay",
                "alipay",
                "alma",
                "amazon_pay",
                "au_becs_debit",
                "bacs_debit",
                "bancontact",
                "billie",
                "blik",
                "boleto",
                "card",
                "cashapp",
                "crypto",
                "customer_balance",
                "eps",
                "fpx",
                "giropay",
                "grabpay",
                "ideal",
                "kakao_pay",
                "klarna",
                "konbini",
                "kr_card",
                "mb_way",
                "mobilepay",
                "multibanco",
                "naver_pay",
                "nz_bank_account",
                "oxxo",
                "p24",
                "pay_by_bank",
                "payco",
                "paynow",
                "paypal",
                "payto",
                "pix",
                "promptpay",
                "revolut_pay",
                "samsung_pay",
                "satispay",
                "sepa_debit",
                "sofort",
                "swish",
                "twint",
                "us_bank_account",
                "wechat_pay",
                "zip",
            ]
        ]
        | None
    ) = Field(description="The list of payment method types to exclude from use with this payment.", default=None)
    hooks: Any = Field(default=None)
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    last_payment_error: Any | None = Field(
        description="The payment error encountered in the previous PaymentIntent confirmation. It will be cleared if the PaymentIntent is later updated for any reason.",
        default=None,
    )
    latest_charge: str | Charge | None = Field(
        description="ID of the latest [Charge object](https://docs.stripe.com/api/charges) created by this PaymentIntent. This property is `null` until PaymentIntent confirmation is attempted.",
        default=None,
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Learn more about [storing information in metadata](https://docs.stripe.com/payments/payment-intents/creating-payment-intents#storing-information-in-metadata).",
        default=None,
    )
    next_action: Any | None = Field(
        description="If present, this property tells you what actions you need to take in order for your customer to fulfill a payment using the provided source.",
        default=None,
    )
    object_: Literal["payment_intent"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    on_behalf_of: str | Any | None = Field(
        description="You can specify the settlement merchant as the connected account using the `on_behalf_of` attribute on the charge. See the PaymentIntents [use case for connected accounts](/payments/connected-accounts) for details.",
        default=None,
    )
    payment_details: Any = Field(default=None)
    payment_method: str | PaymentMethod | None = Field(
        description="ID of the payment method used in this PaymentIntent.", default=None
    )
    payment_method_configuration_details: Any | None = Field(
        description="Information about the [payment method configuration](https://docs.stripe.com/api/payment_method_configurations) used for this PaymentIntent.",
        default=None,
    )
    payment_method_options: Any | None = Field(
        description="Payment-method-specific configuration for this PaymentIntent.", default=None
    )
    payment_method_types: list[str] = Field(
        description="The list of payment method types (e.g. card) that this PaymentIntent is allowed to use. A comprehensive list of valid payment method types can be found [here](https://docs.stripe.com/api/payment_methods/object#payment_method_object-type).",
        default=None,
    )
    presentment_details: Any = Field(default=None)
    processing: Any | None = Field(
        description="If present, this property tells you about the processing state of the payment.", default=None
    )
    receipt_email: str | None = Field(
        description="Email address that the receipt for the resulting payment will be sent to. If `receipt_email` is specified for a payment in live mode, a receipt will be sent regardless of your [email settings](https://dashboard.stripe.com/account/emails).",
        default=None,
    )
    review: str | Any | None = Field(
        description="ID of the review associated with this PaymentIntent, if any.", default=None
    )
    setup_future_usage: Literal["off_session", "on_session"] | None = Field(
        description="Indicates that you intend to make future payments with this PaymentIntent's payment method.  If you provide a Customer with the PaymentIntent, you can use this parameter to [attach the payment method](/payments/save-during-payment) to the Customer after the PaymentIntent is confirmed and the customer completes any required actions. If you don't provide a Customer, you can still [attach](/api/payment_methods/attach) the payment method to a Customer after the transaction completes.  If the payment method is `card_present` and isn't a digital wallet, Stripe creates and attaches a [generated_card](/api/charges/object#charge_object-payment_method_details-card_present-generated_card) payment method representing the card to the Customer instead.  When processing card payments, Stripe uses `setup_future_usage` to help you comply with regional legislation and network rules, such as [SCA](/strong-customer-authentication).",
        default=None,
    )
    shipping: Any | None = Field(description="Shipping information for this PaymentIntent.", default=None)
    statement_descriptor: str | None = Field(
        description="Text that appears on the customer's statement as the statement descriptor for a non-card charge. This value overrides the account's default statement descriptor. For information about requirements, including the 22-character limit, see [the Statement Descriptor docs](https://docs.stripe.com/get-started/account/statement-descriptors).  Setting this value for a card charge returns an error. For card charges, set the [statement_descriptor_suffix](https://docs.stripe.com/get-started/account/statement-descriptors#dynamic) instead.",
        default=None,
    )
    statement_descriptor_suffix: str | None = Field(
        description="Provides information about a card charge. Concatenated to the account's [statement descriptor prefix](https://docs.stripe.com/get-started/account/statement-descriptors#static) to form the complete statement descriptor that appears on the customer's statement.",
        default=None,
    )
    status: Literal[
        "canceled",
        "processing",
        "requires_action",
        "requires_capture",
        "requires_confirmation",
        "requires_payment_method",
        "succeeded",
    ] = Field(
        description="Status of this PaymentIntent, one of `requires_payment_method`, `requires_confirmation`, `requires_action`, `processing`, `requires_capture`, `canceled`, or `succeeded`. Read more about each PaymentIntent [status](https://docs.stripe.com/payments/intents#intent-statuses)."
    )
    transfer_data: Any | None = Field(
        description="The data that automatically creates a Transfer after the payment finalizes. Learn more about the [use case for connected accounts](https://docs.stripe.com/payments/connected-accounts).",
        default=None,
    )
    transfer_group: str | None = Field(
        description="A string that identifies the resulting payment as part of a group. Learn more about the [use case for connected accounts](https://docs.stripe.com/connect/separate-charges-and-transfers).",
        default=None,
    )


class PaymentMethod(BaseModel):
    """PaymentMethod objects represent your customer's payment instruments.
    You can use them with [PaymentIntents](https://docs.stripe.com/payments/payment-intents) to collect payments or save them to
    Customer objects to store instrument details for future payments.

    Related guides: [Payment Methods](https://docs.stripe.com/payments/payment-methods) and [More Payment Scenarios](https://docs.stripe.com/payments/more-payment-scenarios)."""

    object: Literal["payment_method"] = "payment_method"

    acss_debit: Any = Field(default=None)
    affirm: Any = Field(default=None)
    afterpay_clearpay: Any = Field(default=None)
    alipay: Any = Field(default=None)
    allow_redisplay: Literal["always", "limited", "unspecified"] = Field(
        description="This field indicates whether this payment method can be shown again to its customer in a checkout flow. Stripe products such as Checkout and Elements use this field to determine whether a payment method can be shown as a saved payment method in a checkout flow. The field defaults to “unspecified”.",
        default=None,
    )
    alma: Any = Field(default=None)
    amazon_pay: Any = Field(default=None)
    au_becs_debit: Any = Field(default=None)
    bacs_debit: Any = Field(default=None)
    bancontact: Any = Field(default=None)
    billie: Any = Field(default=None)
    billing_details: Any
    blik: Any = Field(default=None)
    boleto: Any = Field(default=None)
    card: Any = Field(default=None)
    card_present: Any = Field(default=None)
    cashapp: Any = Field(default=None)
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    crypto: Any = Field(default=None)
    custom: Any = Field(default=None)
    customer: str | Customer | None = Field(
        description="The ID of the Customer to which this PaymentMethod is saved. This will not be set when the PaymentMethod has not been saved to a Customer.",
        default=None,
    )
    customer_account: str | None = Field(default=None)
    customer_balance: Any = Field(default=None)
    eps: Any = Field(default=None)
    fpx: Any = Field(default=None)
    giropay: Any = Field(default=None)
    grabpay: Any = Field(default=None)
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    ideal: Any = Field(default=None)
    interac_present: Any = Field(default=None)
    kakao_pay: Any = Field(default=None)
    klarna: Any = Field(default=None)
    konbini: Any = Field(default=None)
    kr_card: Any = Field(default=None)
    link: Any = Field(default=None)
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    mb_way: Any = Field(default=None)
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    mobilepay: Any = Field(default=None)
    multibanco: Any = Field(default=None)
    naver_pay: Any = Field(default=None)
    nz_bank_account: Any = Field(default=None)
    object_: Literal["payment_method"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    oxxo: Any = Field(default=None)
    p24: Any = Field(default=None)
    pay_by_bank: Any = Field(default=None)
    payco: Any = Field(default=None)
    paynow: Any = Field(default=None)
    paypal: Any = Field(default=None)
    payto: Any = Field(default=None)
    pix: Any = Field(default=None)
    promptpay: Any = Field(default=None)
    radar_options: Any = Field(default=None)
    revolut_pay: Any = Field(default=None)
    samsung_pay: Any = Field(default=None)
    satispay: Any = Field(default=None)
    sepa_debit: Any = Field(default=None)
    sofort: Any = Field(default=None)
    swish: Any = Field(default=None)
    twint: Any = Field(default=None)
    type_: Literal[
        "acss_debit",
        "affirm",
        "afterpay_clearpay",
        "alipay",
        "alma",
        "amazon_pay",
        "au_becs_debit",
        "bacs_debit",
        "bancontact",
        "billie",
        "blik",
        "boleto",
        "card",
        "card_present",
        "cashapp",
        "crypto",
        "custom",
        "customer_balance",
        "eps",
        "fpx",
        "giropay",
        "grabpay",
        "ideal",
        "interac_present",
        "kakao_pay",
        "klarna",
        "konbini",
        "kr_card",
        "link",
        "mb_way",
        "mobilepay",
        "multibanco",
        "naver_pay",
        "nz_bank_account",
        "oxxo",
        "p24",
        "pay_by_bank",
        "payco",
        "paynow",
        "paypal",
        "payto",
        "pix",
        "promptpay",
        "revolut_pay",
        "samsung_pay",
        "satispay",
        "sepa_debit",
        "sofort",
        "swish",
        "twint",
        "us_bank_account",
        "wechat_pay",
        "zip",
    ] = Field(
        alias="type",
        description="The type of the PaymentMethod. An additional hash is included on the PaymentMethod with a name matching this value. It contains additional information specific to the PaymentMethod type.",
    )
    us_bank_account: Any = Field(default=None)
    wechat_pay: Any = Field(default=None)
    zip: Any = Field(default=None)


class Charge(BaseModel):
    """The `Charge` object represents a single attempt to move money into your Stripe account.
    PaymentIntent confirmation is the most common way to create Charges, but [Account Debits](https://docs.stripe.com/connect/account-debits) may also create Charges.
    Some legacy payment flows create Charges directly, which is not recommended for new integrations."""

    object: Literal["charge"] = "charge"

    amount: int = Field(
        description="Amount intended to be collected by this payment. A positive integer representing how much to charge in the [smallest currency unit](https://docs.stripe.com/currencies#zero-decimal) (e.g., 100 cents to charge $1.00 or 100 to charge ¥100, a zero-decimal currency). The minimum amount is $0.50 US or [equivalent in charge currency](https://docs.stripe.com/currencies#minimum-and-maximum-charge-amounts). The amount value supports up to eight digits (e.g., a value of 99999999 for a USD charge of $999,999.99)."
    )
    amount_captured: int = Field(
        description="Amount in cents (or local equivalent) captured (can be less than the amount attribute on the charge if a partial capture was made)."
    )
    amount_refunded: int = Field(
        description="Amount in cents (or local equivalent) refunded (can be less than the amount attribute on the charge if a partial refund was issued)."
    )
    application: str | Any | None = Field(
        description="ID of the Connect application that created the charge.", default=None
    )
    application_fee: str | Any | None = Field(
        description="The application fee (if any) for the charge. [See the Connect documentation](https://docs.stripe.com/connect/direct-charges#collect-fees) for details.",
        default=None,
    )
    application_fee_amount: int | None = Field(
        description="The amount of the application fee (if any) requested for the charge. [See the Connect documentation](https://docs.stripe.com/connect/direct-charges#collect-fees) for details.",
        default=None,
    )
    balance_transaction: str | Any | None = Field(
        description="ID of the balance transaction that describes the impact of this charge on your account balance (not including refunds or disputes).",
        default=None,
    )
    billing_details: Any
    calculated_statement_descriptor: str | None = Field(
        description="The full statement descriptor that is passed to card networks, and that is displayed on your customers' credit card and bank statements. Allows you to see what the statement descriptor looks like after the static and dynamic portions are combined. This value only exists for card payments.",
        default=None,
    )
    captured: bool = Field(
        description="If the charge was created without capturing, this Boolean represents whether it is still uncaptured or has since been captured."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies)."
    )
    customer: str | Customer | Any | None = Field(
        description="ID of the customer this charge is for if one exists.", default=None
    )
    description: str | None = Field(
        description="An arbitrary string attached to the object. Often useful for displaying to users.", default=None
    )
    disputed: bool = Field(description="Whether the charge has been disputed.")
    failure_balance_transaction: str | Any | None = Field(
        description="ID of the balance transaction that describes the reversal of the balance on your account due to payment failure.",
        default=None,
    )
    failure_code: str | None = Field(
        description="Error code explaining reason for charge failure if available (see [the errors section](https://docs.stripe.com/error-codes) for a list of codes).",
        default=None,
    )
    failure_message: str | None = Field(
        description="Message to user further explaining reason for charge failure if available.", default=None
    )
    fraud_details: Any | None = Field(description="Information on fraud assessments for the charge.", default=None)
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format."
    )
    object_: Literal["charge"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    on_behalf_of: str | Any | None = Field(
        description="The account (if any) the charge was made on behalf of without triggering an automatic transfer. See the [Connect documentation](https://docs.stripe.com/connect/separate-charges-and-transfers) for details.",
        default=None,
    )
    outcome: Any | None = Field(
        description="Details about whether the payment was accepted, and why. See [understanding declines](https://docs.stripe.com/declines) for details.",
        default=None,
    )
    paid: bool = Field(description="`true` if the charge succeeded, or was successfully authorized for later capture.")
    payment_intent: str | PaymentIntent | None = Field(
        description="ID of the PaymentIntent associated with this charge, if one exists.", default=None
    )
    payment_method: str | None = Field(description="ID of the payment method used in this charge.", default=None)
    payment_method_details: Any | None = Field(
        description="Details about the payment method at the time of the transaction.", default=None
    )
    presentment_details: Any = Field(default=None)
    radar_options: Any = Field(default=None)
    receipt_email: str | None = Field(
        description="This is the email address that the receipt for this charge was sent to.", default=None
    )
    receipt_number: str | None = Field(
        description="This is the transaction number that appears on email receipts sent for this charge. This attribute will be `null` until a receipt has been sent.",
        default=None,
    )
    receipt_url: str | None = Field(
        description="This is the URL to view the receipt for this charge. The receipt is kept up-to-date to the latest state of the charge, including any refunds. If the charge is for an Invoice, the receipt will be stylized as an Invoice receipt.",
        default=None,
    )
    refunded: bool = Field(
        description="Whether the charge has been fully refunded. If the charge is only partially refunded, this attribute will still be false."
    )
    refunds: dict[str, Any] | None = Field(
        description="A list of refunds that have been applied to the charge.", default=None
    )
    review: str | Any | None = Field(
        description="ID of the review associated with this charge if one exists.", default=None
    )
    shipping: Any | None = Field(description="Shipping information for the charge.", default=None)
    source_transfer: str | Any | None = Field(
        description="The transfer ID which created this charge. Only present if the charge came from another Stripe account. [See the Connect documentation](https://docs.stripe.com/connect/destination-charges) for details.",
        default=None,
    )
    statement_descriptor: str | None = Field(
        description="For a non-card charge, text that appears on the customer's statement as the statement descriptor. This value overrides the account's default statement descriptor. For information about requirements, including the 22-character limit, see [the Statement Descriptor docs](https://docs.stripe.com/get-started/account/statement-descriptors).  For a card charge, this value is ignored unless you don't specify a `statement_descriptor_suffix`, in which case this value is used as the suffix.",
        default=None,
    )
    statement_descriptor_suffix: str | None = Field(
        description="Provides information about a card charge. Concatenated to the account's [statement descriptor prefix](https://docs.stripe.com/get-started/account/statement-descriptors#static) to form the complete statement descriptor that appears on the customer's statement. If the account has no prefix value, the suffix is concatenated to the account's statement descriptor.",
        default=None,
    )
    status: Literal["failed", "pending", "succeeded"] = Field(
        description="The status of the payment is either `succeeded`, `pending`, or `failed`."
    )
    transfer: str | Any = Field(
        description="ID of the transfer to the `destination` account (only applicable if the charge was created using the `destination` parameter).",
        default=None,
    )
    transfer_data: Any | None = Field(
        description="An optional dictionary including the account to automatically transfer to as part of a destination charge. [See the Connect documentation](https://docs.stripe.com/connect/destination-charges) for details.",
        default=None,
    )
    transfer_group: str | None = Field(
        description="A string that identifies this transaction as part of a group. See the [Connect documentation](https://docs.stripe.com/connect/separate-charges-and-transfers#transfer-options) for details.",
        default=None,
    )


class CheckoutSession(BaseModel):
    """A Checkout Session represents your customer's session as they pay for
    one-time purchases or subscriptions through [Checkout](https://docs.stripe.com/payments/checkout)
    or [Payment Links](https://docs.stripe.com/payments/payment-links). We recommend creating a
    new Session each time your customer attempts to pay.

    Once payment is successful, the Checkout Session will contain a reference
    to the [Customer](https://docs.stripe.com/api/customers), and either the successful
    [PaymentIntent](https://docs.stripe.com/api/payment_intents) or an active
    [Subscription](https://docs.stripe.com/api/subscriptions).

    You can create a Checkout Session on your server and redirect to its URL
    to begin Checkout.

    Related guide: [Checkout quickstart](https://docs.stripe.com/checkout/quickstart)"""

    object: Literal["checkout.session"] = "checkout.session"

    adaptive_pricing: Any | None = Field(
        description="Settings for price localization with [Adaptive Pricing](https://docs.stripe.com/payments/checkout/adaptive-pricing).",
        default=None,
    )
    after_expiration: Any | None = Field(
        description="When set, provides configuration for actions to take if this Checkout Session expires.",
        default=None,
    )
    allow_promotion_codes: bool | None = Field(description="Enables user redeemable promotion codes.", default=None)
    amount_subtotal: int | None = Field(
        description="Total of all items before discounts or taxes are applied.", default=None
    )
    amount_total: int | None = Field(
        description="Total of all items after discounts and taxes are applied.", default=None
    )
    automatic_tax: Any
    billing_address_collection: Literal["auto", "required"] | None = Field(
        description="Describes whether Checkout should collect the customer's billing address. Defaults to `auto`.",
        default=None,
    )
    branding_settings: Any = Field(default=None)
    cancel_url: str | None = Field(
        description="If set, Checkout displays a back button and customers will be directed to this URL if they decide to cancel payment and return to your website.",
        default=None,
    )
    client_reference_id: str | None = Field(
        description="A unique string to reference the Checkout Session. This can be a customer ID, a cart ID, or similar, and can be used to reconcile the Session with your internal systems.",
        default=None,
    )
    client_secret: str | None = Field(
        description="The client secret of your Checkout Session. Applies to Checkout Sessions with `ui_mode: embedded` or `ui_mode: custom`. For `ui_mode: embedded`, the client secret is to be used when initializing Stripe.js embedded checkout.  For `ui_mode: custom`, use the client secret with [initCheckout](https://docs.stripe.com/js/custom_checkout/init) on your front end.",
        default=None,
    )
    collected_information: Any | None = Field(
        description="Information about the customer collected within the Checkout Session.", default=None
    )
    consent: Any | None = Field(description="Results of `consent_collection` for this session.", default=None)
    consent_collection: Any | None = Field(
        description="When set, provides configuration for the Checkout Session to gather active consent from customers.",
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str | None = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).",
        default=None,
    )
    currency_conversion: Any | None = Field(
        description="Currency conversion details for [Adaptive Pricing](https://docs.stripe.com/payments/checkout/adaptive-pricing) sessions created before 2025-03-31.",
        default=None,
    )
    custom_fields: list[Any] = Field(
        description="Collect additional information from your customer using custom fields. Up to 3 fields are supported. You can't set this parameter if `ui_mode` is `custom`."
    )
    custom_text: Any
    customer: str | Customer | Any | None = Field(
        description="The ID of the customer for this Session. For Checkout Sessions in `subscription` mode or Checkout Sessions with `customer_creation` set as `always` in `payment` mode, Checkout will create a new customer object based on information provided during the payment flow unless an existing customer was provided when the Session was created.",
        default=None,
    )
    customer_account: str | None = Field(description="The ID of the account for this Session.", default=None)
    customer_creation: Literal["always", "if_required"] | None = Field(
        description="Configure whether a Checkout Session creates a Customer when the Checkout Session completes.",
        default=None,
    )
    customer_details: Any | None = Field(
        description="The customer details including the customer's tax exempt status and the customer's tax IDs. Customer's address details are not present on Sessions in `setup` mode.",
        default=None,
    )
    customer_email: str | None = Field(
        description="If provided, this value will be used when the Customer object is created. If not provided, customers will be asked to enter their email address. Use this parameter to prefill customer data if you already have an email on file. To access information about the customer once the payment flow is complete, use the `customer` attribute.",
        default=None,
    )
    discounts: list[Any] | None = Field(
        description="List of coupons and promotion codes attached to the Checkout Session.", default=None
    )
    excluded_payment_method_types: list[str] = Field(
        description="A list of the types of payment methods (e.g., `card`) that should be excluded from this Checkout Session. This should only be used when payment methods for this Checkout Session are managed through the [Stripe Dashboard](https://dashboard.stripe.com/settings/payment_methods).",
        default=None,
    )
    expires_at: int = Field(description="The timestamp at which the Checkout Session will expire.")
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    invoice: str | Invoice | None = Field(
        description="ID of the invoice created by the Checkout Session, if it exists.", default=None
    )
    invoice_creation: Any | None = Field(
        description="Details on the state of invoice creation for the Checkout Session.", default=None
    )
    line_items: dict[str, Any] = Field(description="The line items purchased by the customer.", default=None)
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    locale: (
        Literal[
            "auto",
            "bg",
            "cs",
            "da",
            "de",
            "el",
            "en",
            "en-GB",
            "es",
            "es-419",
            "et",
            "fi",
            "fil",
            "fr",
            "fr-CA",
            "hr",
            "hu",
            "id",
            "it",
            "ja",
            "ko",
            "lt",
            "lv",
            "ms",
            "mt",
            "nb",
            "nl",
            "pl",
            "pt",
            "pt-BR",
            "ro",
            "ru",
            "sk",
            "sl",
            "sv",
            "th",
            "tr",
            "vi",
            "zh",
            "zh-HK",
            "zh-TW",
        ]
        | None
    ) = Field(
        description="The IETF language tag of the locale Checkout is displayed in. If blank or `auto`, the browser's locale is used.",
        default=None,
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    mode: Literal["payment", "setup", "subscription"] = Field(description="The mode of the Checkout Session.")
    name_collection: Any = Field(default=None)
    object_: Literal["checkout.session"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    optional_items: list[Any] | None = Field(
        description="The optional items presented to the customer at checkout.", default=None
    )
    origin_context: Literal["mobile_app", "web"] | None = Field(
        description="Where the user is coming from. This informs the optimizations that are applied to the session.",
        default=None,
    )
    payment_intent: str | PaymentIntent | None = Field(
        description="The ID of the PaymentIntent for Checkout Sessions in `payment` mode. You can't confirm or cancel the PaymentIntent for a Checkout Session. To cancel, [expire the Checkout Session](https://docs.stripe.com/api/checkout/sessions/expire) instead.",
        default=None,
    )
    payment_link: str | Any | None = Field(
        description="The ID of the Payment Link that created this Session.", default=None
    )
    payment_method_collection: Literal["always", "if_required"] | None = Field(
        description="Configure whether a Checkout Session should collect a payment method. Defaults to `always`.",
        default=None,
    )
    payment_method_configuration_details: Any | None = Field(
        description="Information about the payment method configuration used for this Checkout session if using dynamic payment methods.",
        default=None,
    )
    payment_method_options: Any | None = Field(
        description="Payment-method-specific configuration for the PaymentIntent or SetupIntent of this CheckoutSession.",
        default=None,
    )
    payment_method_types: list[str] = Field(
        description="A list of the types of payment methods (e.g. card) this Checkout Session is allowed to accept."
    )
    payment_status: Literal["no_payment_required", "paid", "unpaid"] = Field(
        description="The payment status of the Checkout Session, one of `paid`, `unpaid`, or `no_payment_required`. You can use this value to decide when to fulfill your customer's order."
    )
    permissions: Any | None = Field(
        description="This property is used to set up permissions for various actions (e.g., update) on the CheckoutSession object.  For specific permissions, please refer to their dedicated subsections, such as `permissions.update_shipping_details`.",
        default=None,
    )
    phone_number_collection: Any = Field(default=None)
    presentment_details: Any = Field(default=None)
    recovered_from: str | None = Field(
        description="The ID of the original expired Checkout Session that triggered the recovery flow.", default=None
    )
    redirect_on_completion: Literal["always", "if_required", "never"] = Field(
        description="This parameter applies to `ui_mode: embedded`. Learn more about the [redirect behavior](https://docs.stripe.com/payments/checkout/custom-success-page?payment-ui=embedded-form) of embedded sessions. Defaults to `always`.",
        default=None,
    )
    return_url: str = Field(
        description="Applies to Checkout Sessions with `ui_mode: embedded` or `ui_mode: custom`. The URL to redirect your customer back to after they authenticate or cancel their payment on the payment method's app or site.",
        default=None,
    )
    saved_payment_method_options: Any | None = Field(
        description="Controls saved payment method settings for the session. Only available in `payment` and `subscription` mode.",
        default=None,
    )
    setup_intent: str | Any | None = Field(
        description="The ID of the SetupIntent for Checkout Sessions in `setup` mode. You can't confirm or cancel the SetupIntent for a Checkout Session. To cancel, [expire the Checkout Session](https://docs.stripe.com/api/checkout/sessions/expire) instead.",
        default=None,
    )
    shipping_address_collection: Any | None = Field(
        description="When set, provides configuration for Checkout to collect a shipping address from a customer.",
        default=None,
    )
    shipping_cost: Any | None = Field(
        description="The details of the customer cost of shipping, including the customer chosen ShippingRate.",
        default=None,
    )
    shipping_options: list[Any] = Field(description="The shipping rate options applied to this Session.")
    status: Literal["complete", "expired", "open"] | None = Field(
        description="The status of the Checkout Session, one of `open`, `complete`, or `expired`.", default=None
    )
    submit_type: Literal["auto", "book", "donate", "pay", "subscribe"] | None = Field(
        description="Describes the type of transaction being performed by Checkout in order to customize relevant text on the page, such as the submit button. `submit_type` can only be specified on Checkout Sessions in `payment` mode. If blank or `auto`, `pay` is used.",
        default=None,
    )
    subscription: str | Subscription | None = Field(
        description="The ID of the [Subscription](https://docs.stripe.com/api/subscriptions) for Checkout Sessions in `subscription` mode.",
        default=None,
    )
    success_url: str | None = Field(
        description="The URL the customer will be directed to after the payment or subscription creation is successful.",
        default=None,
    )
    tax_id_collection: Any = Field(default=None)
    total_details: Any | None = Field(
        description="Tax and discount details for the computed total amount.", default=None
    )
    ui_mode: Literal["custom", "embedded", "hosted"] | None = Field(
        description="The UI mode of the Session. Defaults to `hosted`.", default=None
    )
    url: str | None = Field(
        description="The URL to the Checkout Session. Applies to Checkout Sessions with `ui_mode: hosted`. Redirect customers to this URL to take them to Checkout. If you’re using [Custom Domains](https://docs.stripe.com/payments/checkout/custom-domains), the URL will use your subdomain. Otherwise, it’ll use `checkout.stripe.com.` This value is only present when the session is active.",
        default=None,
    )
    wallet_options: Any | None = Field(
        description="Wallet-specific configuration for this Checkout Session.", default=None
    )


class Plan(BaseModel):
    """You can now model subscriptions more flexibly using the [Prices API](https://api.stripe.com#prices). It replaces the Plans API and is backwards compatible to simplify your migration.

    Plans define the base price, currency, and billing cycle for recurring purchases of products.
    [Products](https://api.stripe.com#products) help you track inventory or provisioning, and plans help you track pricing. Different physical goods or levels of service should be represented by products, and pricing options should be represented by plans. This approach lets you change prices without having to change your provisioning scheme.

    For example, you might have a single "gold" product that has plans for $10/month, $100/year, €9/month, and €90/year.

    Related guides: [Set up a subscription](https://docs.stripe.com/billing/subscriptions/set-up-subscription) and more about [products and prices](https://docs.stripe.com/products-prices/overview)."""

    object: Literal["plan"] = "plan"

    active: bool = Field(description="Whether the plan can be used for new purchases.")
    amount: int | None = Field(
        description="The unit amount in cents (or local equivalent) to be charged, represented as a whole integer if possible. Only set if `billing_scheme=per_unit`.",
        default=None,
    )
    amount_decimal: str | None = Field(
        description="The unit amount in cents (or local equivalent) to be charged, represented as a decimal string with at most 12 decimal places. Only set if `billing_scheme=per_unit`.",
        default=None,
    )
    billing_scheme: Literal["per_unit", "tiered"] = Field(
        description="Describes how to compute the price per period. Either `per_unit` or `tiered`. `per_unit` indicates that the fixed amount (specified in `amount`) will be charged per unit in `quantity` (for plans with `usage_type=licensed`), or per unit of total usage (for plans with `usage_type=metered`). `tiered` indicates that the unit pricing will be computed using a tiering strategy as defined using the `tiers` and `tiers_mode` attributes."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str = Field(
        description="Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies)."
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    interval: Literal["day", "month", "week", "year"] = Field(
        description="The frequency at which a subscription is billed. One of `day`, `week`, `month` or `year`."
    )
    interval_count: int = Field(
        description="The number of intervals (specified in the `interval` attribute) between subscription billings. For example, `interval=month` and `interval_count=3` bills every 3 months."
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    meter: str | None = Field(description="The meter tracking the usage of a metered price", default=None)
    nickname: str | None = Field(description="A brief description of the plan, hidden from customers.", default=None)
    object_: Literal["plan"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    product: str | Product | Any | None = Field(
        description="The product whose pricing this plan determines.", default=None
    )
    tiers: list[Any] = Field(
        description="Each element represents a pricing tier. This parameter requires `billing_scheme` to be set to `tiered`. See also the documentation for `billing_scheme`.",
        default=None,
    )
    tiers_mode: Literal["graduated", "volume"] | None = Field(
        description="Defines if the tiering price should be `graduated` or `volume` based. In `volume`-based tiering, the maximum quantity within a period determines the per unit price. In `graduated` tiering, pricing can change as the quantity grows.",
        default=None,
    )
    transform_usage: Any | None = Field(
        description="Apply a transformation to the reported usage or set quantity before computing the amount billed. Cannot be combined with `tiers`.",
        default=None,
    )
    trial_period_days: int | None = Field(
        description="Default number of trial days when subscribing a customer to this plan using [`trial_from_plan=true`](https://docs.stripe.com/api#create_subscription-trial_from_plan).",
        default=None,
    )
    usage_type: Literal["licensed", "metered"] = Field(
        description="Configures how the quantity per period should be determined. Can be either `metered` or `licensed`. `licensed` automatically bills the `quantity` set when adding it to a subscription. `metered` aggregates the total usage based on usage records. Defaults to `licensed`."
    )


class BillingPortalSession(BaseModel):
    """The Billing customer portal is a Stripe-hosted UI for subscription and
    billing management.

    A portal configuration describes the functionality and features that you
    want to provide to your customers through the portal.

    A portal session describes the instantiation of the customer portal for
    a particular customer. By visiting the session's URL, the customer
    can manage their subscriptions and billing details. For security reasons,
    sessions are short-lived and will expire if the customer does not visit the URL.
    Create sessions on-demand when customers intend to manage their subscriptions
    and billing details.

    Related guide: [Customer management](/customer-management)"""

    object: Literal["billing_portal.session"] = "billing_portal.session"

    configuration: str | BillingPortalConfiguration = Field(
        description="The configuration used by this session, describing the features available."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    customer: str = Field(description="The ID of the customer for this session.")
    customer_account: str | None = Field(description="The ID of the account for this session.", default=None)
    flow: Any | None = Field(
        description="Information about a specific flow for the customer to go through. See the [docs](https://docs.stripe.com/customer-management/portal-deep-links) to learn more about using customer portal deep links and flows.",
        default=None,
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    locale: (
        Literal[
            "auto",
            "bg",
            "cs",
            "da",
            "de",
            "el",
            "en",
            "en-AU",
            "en-CA",
            "en-GB",
            "en-IE",
            "en-IN",
            "en-NZ",
            "en-SG",
            "es",
            "es-419",
            "et",
            "fi",
            "fil",
            "fr",
            "fr-CA",
            "hr",
            "hu",
            "id",
            "it",
            "ja",
            "ko",
            "lt",
            "lv",
            "ms",
            "mt",
            "nb",
            "nl",
            "pl",
            "pt",
            "pt-BR",
            "ro",
            "ru",
            "sk",
            "sl",
            "sv",
            "th",
            "tr",
            "vi",
            "zh",
            "zh-HK",
            "zh-TW",
        ]
        | None
    ) = Field(
        description="The IETF language tag of the locale Customer Portal is displayed in. If blank or auto, the customer’s `preferred_locales` or browser’s locale is used.",
        default=None,
    )
    object_: Literal["billing_portal.session"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    on_behalf_of: str | None = Field(
        description="The account for which the session was created on behalf of. When specified, only subscriptions and invoices with this `on_behalf_of` account appear in the portal. For more information, see the [docs](https://docs.stripe.com/connect/separate-charges-and-transfers#settlement-merchant). Use the [Accounts API](https://docs.stripe.com/api/accounts/object#account_object-settings-branding) to modify the `on_behalf_of` account's branding settings, which the portal displays.",
        default=None,
    )
    return_url: str | None = Field(
        description="The URL to redirect customers to when they click on the portal's link to return to your website.",
        default=None,
    )
    url: str = Field(
        description="The short-lived URL of the session that gives customers access to the customer portal."
    )


class BillingPortalConfiguration(BaseModel):
    """A portal configuration describes the functionality and behavior you embed in a portal session. Related guide: [Configure the customer portal](/customer-management/configure-portal)."""

    object: Literal["billing_portal.configuration"] = "billing_portal.configuration"

    active: bool = Field(description="Whether the configuration is active and can be used to create portal sessions.")
    application: str | Any | None = Field(
        description="ID of the Connect Application that created the configuration.", default=None
    )
    business_profile: Any
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    default_return_url: str | None = Field(
        description="The default URL to redirect customers to when they click on the portal's link to return to your website. This can be [overriden](https://docs.stripe.com/api/customer_portal/sessions/create#create_portal_session-return_url) when creating the session.",
        default=None,
    )
    features: Any
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    is_default: bool = Field(
        description="Whether the configuration is the default. If `true`, this configuration can be managed in the Dashboard and portal sessions will use this configuration unless it is overriden when creating the session."
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    login_page: Any
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    name: str | None = Field(description="The name of the configuration.", default=None)
    object_: Literal["billing_portal.configuration"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    updated: int = Field(
        description="Time at which the object was last updated. Measured in seconds since the Unix epoch."
    )


class TaxRate(BaseModel):
    """Tax rates can be applied to [invoices](/invoicing/taxes/tax-rates), [subscriptions](/billing/taxes/tax-rates) and [Checkout Sessions](/payments/checkout/use-manual-tax-rates) to collect tax.

    Related guide: [Tax rates](/billing/taxes/tax-rates)"""

    object: Literal["tax_rate"] = "tax_rate"

    active: bool = Field(
        description="Defaults to `true`. When set to `false`, this tax rate cannot be used with new applications or Checkout Sessions, but will still work for subscriptions and invoices that already have it set."
    )
    country: str | None = Field(
        description="Two-letter country code ([ISO 3166-1 alpha-2](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2)).",
        default=None,
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    description: str | None = Field(
        description="An arbitrary string attached to the tax rate for your internal use only. It will not be visible to your customers.",
        default=None,
    )
    display_name: str = Field(
        description="The display name of the tax rates as it will appear to your customer on their receipt email, PDF, and the hosted invoice page."
    )
    effective_percentage: float | None = Field(
        description="Actual/effective tax rate percentage out of 100. For tax calculations with automatic_tax[enabled]=true, this percentage reflects the rate actually used to calculate tax based on the product's taxability and whether the user is registered to collect taxes in the corresponding jurisdiction.",
        default=None,
    )
    flat_amount: Any | None = Field(
        description="The amount of the tax rate when the `rate_type` is `flat_amount`. Tax rates with `rate_type` `percentage` can vary based on the transaction, resulting in this field being `null`. This field exposes the amount and currency of the flat tax rate.",
        default=None,
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    inclusive: bool = Field(description="This specifies if the tax rate is inclusive or exclusive.")
    jurisdiction: str | None = Field(
        description="The jurisdiction for the tax rate. You can use this label field for tax reporting purposes. It also appears on your customer’s invoice.",
        default=None,
    )
    jurisdiction_level: Literal["city", "country", "county", "district", "multiple", "state"] | None = Field(
        description="The level of the jurisdiction that imposes this tax rate. Will be `null` for manually defined tax rates.",
        default=None,
    )
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    object_: Literal["tax_rate"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    percentage: float = Field(
        description="Tax rate percentage out of 100. For tax calculations with automatic_tax[enabled]=true, this percentage includes the statutory tax rate of non-taxable jurisdictions."
    )
    rate_type: Literal["flat_amount", "percentage"] | None = Field(
        description="Indicates the type of tax rate applied to the taxable amount. This value can be `null` when no tax applies to the location. This field is only present for TaxRates created by Stripe Tax.",
        default=None,
    )
    state: str | None = Field(
        description='[ISO 3166-2 subdivision code](https://en.wikipedia.org/wiki/ISO_3166-2), without country prefix. For example, "NY" for New York, United States.',
        default=None,
    )
    tax_type: (
        Literal[
            "amusement_tax",
            "communications_tax",
            "gst",
            "hst",
            "igst",
            "jct",
            "lease_tax",
            "pst",
            "qst",
            "retail_delivery_fee",
            "rst",
            "sales_tax",
            "service_tax",
            "vat",
        ]
        | None
    ) = Field(description="The high-level tax type, such as `vat` or `sales_tax`.", default=None)


class Coupon(BaseModel):
    """A coupon contains information about a percent-off or amount-off discount you
    might want to apply to a customer. Coupons may be applied to [subscriptions](https://api.stripe.com#subscriptions), [invoices](https://api.stripe.com#invoices),
    [checkout sessions](https://docs.stripe.com/api/checkout/sessions), [quotes](https://api.stripe.com#quotes), and more. Coupons do not work with conventional one-off [charges](https://api.stripe.com#create_charge) or [payment intents](https://docs.stripe.com/api/payment_intents)."""

    object: Literal["coupon"] = "coupon"

    amount_off: int | None = Field(
        description="Amount (in the `currency` specified) that will be taken off the subtotal of any invoices for this customer.",
        default=None,
    )
    applies_to: Any = Field(default=None)
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    currency: str | None = Field(
        description="If `amount_off` has been set, the three-letter [ISO code for the currency](https://stripe.com/docs/currencies) of the amount to take off.",
        default=None,
    )
    currency_options: dict[str, Any] = Field(
        description="Coupons defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).",
        default=None,
    )
    duration: Literal["forever", "once", "repeating"] = Field(
        description="One of `forever`, `once`, or `repeating`. Describes how long a customer who applies this coupon will get the discount."
    )
    duration_in_months: int | None = Field(
        description="If `duration` is `repeating`, the number of months the coupon applies. Null if coupon `duration` is `forever` or `once`.",
        default=None,
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    max_redemptions: int | None = Field(
        description="Maximum number of times this coupon can be redeemed, in total, across all customers, before it is no longer valid.",
        default=None,
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    name: str | None = Field(
        description="Name of the coupon displayed to customers on for instance invoices or receipts.", default=None
    )
    object_: Literal["coupon"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    percent_off: float | None = Field(
        description="Percent that will be taken off the subtotal of any invoices for this customer for the duration of the coupon. For example, a coupon with percent_off of 50 will make a $ (or local equivalent)100 invoice $ (or local equivalent)50 instead.",
        default=None,
    )
    redeem_by: int | None = Field(description="Date after which the coupon can no longer be redeemed.", default=None)
    times_redeemed: int = Field(description="Number of times this coupon has been applied to a customer.")
    valid: bool = Field(
        description="Taking account of the above properties, whether this coupon can still be applied to a customer."
    )


class PromotionCode(BaseModel):
    """A Promotion Code represents a customer-redeemable code for an underlying promotion.
    You can create multiple codes for a single promotion.

    If you enable promotion codes in your [customer portal configuration](https://docs.stripe.com/customer-management/configure-portal), then customers can redeem a code themselves when updating a subscription in the portal.
    Customers can also view the currently active promotion codes and coupons on each of their subscriptions in the portal."""

    object: Literal["promotion_code"] = "promotion_code"

    active: bool = Field(
        description="Whether the promotion code is currently active. A promotion code is only active if the coupon is also valid."
    )
    code: str = Field(
        description="The customer-facing code. Regardless of case, this code must be unique across all active promotion codes for each customer. Valid characters are lower case letters (a-z), upper case letters (A-Z), and digits (0-9)."
    )
    created: int = Field(description="Time at which the object was created. Measured in seconds since the Unix epoch.")
    customer: str | Customer | Any | None = Field(
        description="The customer who can use this promotion code.", default=None
    )
    customer_account: str | None = Field(
        description="The account representing the customer who can use this promotion code.", default=None
    )
    expires_at: int | None = Field(
        description="Date at which the promotion code can no longer be redeemed.", default=None
    )
    id_: str = Field(alias="id", description="Unique identifier for the object.")
    livemode: bool = Field(
        description="Has the value `true` if the object exists in live mode or the value `false` if the object exists in test mode."
    )
    max_redemptions: int | None = Field(
        description="Maximum number of times this promotion code can be redeemed.", default=None
    )
    metadata: dict[str, str] | None = Field(
        description="Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.",
        default=None,
    )
    object_: Literal["promotion_code"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    promotion: Any
    restrictions: Any
    times_redeemed: int = Field(description="Number of times this promotion code has been used.")


class Discount(BaseModel):
    """A discount represents the actual application of a [coupon](https://api.stripe.com#coupons) or [promotion code](https://api.stripe.com#promotion_codes).
    It contains information about when the discount began, when it will end, and what it is applied to.

    Related guide: [Applying discounts to subscriptions](https://docs.stripe.com/billing/subscriptions/discounts)"""

    object: Literal["discount"] = "discount"

    checkout_session: str | None = Field(
        description="The Checkout session that this coupon is applied to, if it is applied to a particular session in payment mode. Will not be present for subscription mode.",
        default=None,
    )
    customer: str | Customer | Any | None = Field(
        description="The ID of the customer associated with this discount.", default=None
    )
    customer_account: str | None = Field(
        description="The ID of the account representing the customer associated with this discount.", default=None
    )
    end: int | None = Field(
        description="If the coupon has a duration of `repeating`, the date that this discount will end. If the coupon has a duration of `once` or `forever`, this attribute will be null.",
        default=None,
    )
    id_: str = Field(
        alias="id",
        description="The ID of the discount object. Discounts cannot be fetched by ID. Use `expand[]=discounts` in API calls to expand discount IDs in an array.",
    )
    invoice: str | None = Field(
        description="The invoice that the discount's coupon was applied to, if it was applied directly to a particular invoice.",
        default=None,
    )
    invoice_item: str | None = Field(
        description="The invoice item `id` (or invoice line item `id` for invoice line items of type='subscription') that the discount's coupon was applied to, if it was applied directly to a particular invoice item or invoice line item.",
        default=None,
    )
    object_: Literal["discount"] = Field(
        alias="object",
        description="String representing the object's type. Objects of the same type share the same value.",
    )
    promotion_code: str | PromotionCode | None = Field(
        description="The promotion code applied to create this discount.", default=None
    )
    source: Any
    start: int = Field(description="Date that the coupon was applied.")
    subscription: str | None = Field(
        description="The subscription that this coupon is applied to, if it is applied to a particular subscription.",
        default=None,
    )
    subscription_item: str | None = Field(
        description="The subscription item that this coupon is applied to, if it is applied to a particular subscription item.",
        default=None,
    )
