"""
Stripe Contracts Package

Generated Pydantic contracts from Stripe's OpenAPI specification.
Import from here for type-safe Stripe integration.

Usage:
    from lightwave.integrations.stripe.contracts import (
        Customer,
        Product,
        Subscription,
        StripeEvent,
        parse_event,
    )
"""

from lightwave.integrations.stripe.contracts._generated_events import (
    EVENT_TYPE_MAP,
    # Individual event types
    CheckoutSessionCompletedEvent,
    CheckoutSessionExpiredEvent,
    CustomerCreatedEvent,
    CustomerDeletedEvent,
    CustomerSubscriptionCreatedEvent,
    CustomerSubscriptionDeletedEvent,
    CustomerSubscriptionPausedEvent,
    CustomerSubscriptionResumedEvent,
    CustomerSubscriptionTrialWillEndEvent,
    CustomerSubscriptionUpdatedEvent,
    CustomerUpdatedEvent,
    InvoiceCreatedEvent,
    InvoiceFinalizedEvent,
    InvoicePaidEvent,
    InvoicePaymentFailedEvent,
    InvoicePaymentSucceededEvent,
    InvoiceUpcomingEvent,
    PaymentIntentPaymentFailedEvent,
    PaymentIntentSucceededEvent,
    PaymentMethodAttachedEvent,
    PaymentMethodDetachedEvent,
    PriceCreatedEvent,
    PriceDeletedEvent,
    PriceUpdatedEvent,
    ProductCreatedEvent,
    ProductDeletedEvent,
    ProductUpdatedEvent,
    StripeEvent,
    StripeEventData,
    SupportedEventType,
    parse_event,
)

__all__ = [
    # Event base
    "EVENT_TYPE_MAP",
    "StripeEvent",
    "StripeEventData",
    "SupportedEventType",
    "parse_event",
    # Typed events
    "CheckoutSessionCompletedEvent",
    "CheckoutSessionExpiredEvent",
    "CustomerCreatedEvent",
    "CustomerUpdatedEvent",
    "CustomerDeletedEvent",
    "CustomerSubscriptionCreatedEvent",
    "CustomerSubscriptionUpdatedEvent",
    "CustomerSubscriptionDeletedEvent",
    "CustomerSubscriptionPausedEvent",
    "CustomerSubscriptionResumedEvent",
    "CustomerSubscriptionTrialWillEndEvent",
    "InvoiceCreatedEvent",
    "InvoiceFinalizedEvent",
    "InvoicePaidEvent",
    "InvoicePaymentFailedEvent",
    "InvoicePaymentSucceededEvent",
    "InvoiceUpcomingEvent",
    "PaymentIntentSucceededEvent",
    "PaymentIntentPaymentFailedEvent",
    "PaymentMethodAttachedEvent",
    "PaymentMethodDetachedEvent",
    "ProductCreatedEvent",
    "ProductUpdatedEvent",
    "ProductDeletedEvent",
    "PriceCreatedEvent",
    "PriceUpdatedEvent",
    "PriceDeletedEvent",
]
