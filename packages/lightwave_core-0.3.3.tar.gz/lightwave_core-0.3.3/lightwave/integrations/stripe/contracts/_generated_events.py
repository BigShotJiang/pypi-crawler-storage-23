"""
Stripe Contracts - Auto-Generated

DO NOT EDIT - This file is generated from Stripe's OpenAPI specification.
Regenerate with: python scripts/stripe/generate_contracts.py events

Generated: 2026-01-29T21:20:37.302052+00:00
Stripe API Version: 2026-01-28.clover
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class StripeEventData(BaseModel):
    """Wrapper for event data object."""

    model_config = ConfigDict(extra="allow")

    object: dict[str, Any]


class StripeEvent(BaseModel):
    """
    Base Stripe webhook event.

    All webhook events share this structure.
    """

    model_config = ConfigDict(extra="allow")

    id: str = Field(description="Unique identifier for the event")
    object: Literal["event"] = "event"
    api_version: str | None = Field(default=None, description="API version used")
    created: int = Field(description="Unix timestamp when created")
    data: StripeEventData = Field(description="Event data containing the object")
    livemode: bool = Field(description="Whether this is a live mode event")
    pending_webhooks: int = Field(description="Number of pending webhooks")
    request: dict[str, Any] | None = Field(default=None, description="Request info")
    type: str = Field(description="Event type string")


class CheckoutSessionCompletedEvent(StripeEvent):
    """Typed event for checkout.session.completed."""

    type: Literal["checkout.session.completed"] = "checkout.session.completed"


class CheckoutSessionExpiredEvent(StripeEvent):
    """Typed event for checkout.session.expired."""

    type: Literal["checkout.session.expired"] = "checkout.session.expired"


class CustomerCreatedEvent(StripeEvent):
    """Typed event for customer.created."""

    type: Literal["customer.created"] = "customer.created"


class CustomerUpdatedEvent(StripeEvent):
    """Typed event for customer.updated."""

    type: Literal["customer.updated"] = "customer.updated"


class CustomerDeletedEvent(StripeEvent):
    """Typed event for customer.deleted."""

    type: Literal["customer.deleted"] = "customer.deleted"


class CustomerSubscriptionCreatedEvent(StripeEvent):
    """Typed event for customer.subscription.created."""

    type: Literal["customer.subscription.created"] = "customer.subscription.created"


class CustomerSubscriptionUpdatedEvent(StripeEvent):
    """Typed event for customer.subscription.updated."""

    type: Literal["customer.subscription.updated"] = "customer.subscription.updated"


class CustomerSubscriptionDeletedEvent(StripeEvent):
    """Typed event for customer.subscription.deleted."""

    type: Literal["customer.subscription.deleted"] = "customer.subscription.deleted"


class CustomerSubscriptionPausedEvent(StripeEvent):
    """Typed event for customer.subscription.paused."""

    type: Literal["customer.subscription.paused"] = "customer.subscription.paused"


class CustomerSubscriptionResumedEvent(StripeEvent):
    """Typed event for customer.subscription.resumed."""

    type: Literal["customer.subscription.resumed"] = "customer.subscription.resumed"


class CustomerSubscriptionTrial_will_endEvent(StripeEvent):
    """Typed event for customer.subscription.trial_will_end."""

    type: Literal["customer.subscription.trial_will_end"] = "customer.subscription.trial_will_end"


class InvoiceCreatedEvent(StripeEvent):
    """Typed event for invoice.created."""

    type: Literal["invoice.created"] = "invoice.created"


class InvoiceFinalizedEvent(StripeEvent):
    """Typed event for invoice.finalized."""

    type: Literal["invoice.finalized"] = "invoice.finalized"


class InvoicePaidEvent(StripeEvent):
    """Typed event for invoice.paid."""

    type: Literal["invoice.paid"] = "invoice.paid"


class InvoicePayment_failedEvent(StripeEvent):
    """Typed event for invoice.payment_failed."""

    type: Literal["invoice.payment_failed"] = "invoice.payment_failed"


class InvoicePayment_succeededEvent(StripeEvent):
    """Typed event for invoice.payment_succeeded."""

    type: Literal["invoice.payment_succeeded"] = "invoice.payment_succeeded"


class InvoiceUpcomingEvent(StripeEvent):
    """Typed event for invoice.upcoming."""

    type: Literal["invoice.upcoming"] = "invoice.upcoming"


class Payment_intentSucceededEvent(StripeEvent):
    """Typed event for payment_intent.succeeded."""

    type: Literal["payment_intent.succeeded"] = "payment_intent.succeeded"


class Payment_intentPayment_failedEvent(StripeEvent):
    """Typed event for payment_intent.payment_failed."""

    type: Literal["payment_intent.payment_failed"] = "payment_intent.payment_failed"


class Payment_methodAttachedEvent(StripeEvent):
    """Typed event for payment_method.attached."""

    type: Literal["payment_method.attached"] = "payment_method.attached"


class Payment_methodDetachedEvent(StripeEvent):
    """Typed event for payment_method.detached."""

    type: Literal["payment_method.detached"] = "payment_method.detached"


class ProductCreatedEvent(StripeEvent):
    """Typed event for product.created."""

    type: Literal["product.created"] = "product.created"


class ProductUpdatedEvent(StripeEvent):
    """Typed event for product.updated."""

    type: Literal["product.updated"] = "product.updated"


class ProductDeletedEvent(StripeEvent):
    """Typed event for product.deleted."""

    type: Literal["product.deleted"] = "product.deleted"


class PriceCreatedEvent(StripeEvent):
    """Typed event for price.created."""

    type: Literal["price.created"] = "price.created"


class PriceUpdatedEvent(StripeEvent):
    """Typed event for price.updated."""

    type: Literal["price.updated"] = "price.updated"


class PriceDeletedEvent(StripeEvent):
    """Typed event for price.deleted."""

    type: Literal["price.deleted"] = "price.deleted"


# Event type to class mapping
EVENT_TYPE_MAP: dict[str, type[StripeEvent]] = {
    "checkout.session.completed": CheckoutSessionCompletedEvent,
    "checkout.session.expired": CheckoutSessionExpiredEvent,
    "customer.created": CustomerCreatedEvent,
    "customer.updated": CustomerUpdatedEvent,
    "customer.deleted": CustomerDeletedEvent,
    "customer.subscription.created": CustomerSubscriptionCreatedEvent,
    "customer.subscription.updated": CustomerSubscriptionUpdatedEvent,
    "customer.subscription.deleted": CustomerSubscriptionDeletedEvent,
    "customer.subscription.paused": CustomerSubscriptionPausedEvent,
    "customer.subscription.resumed": CustomerSubscriptionResumedEvent,
    "customer.subscription.trial_will_end": CustomerSubscriptionTrial_will_endEvent,
    "invoice.created": InvoiceCreatedEvent,
    "invoice.finalized": InvoiceFinalizedEvent,
    "invoice.paid": InvoicePaidEvent,
    "invoice.payment_failed": InvoicePayment_failedEvent,
    "invoice.payment_succeeded": InvoicePayment_succeededEvent,
    "invoice.upcoming": InvoiceUpcomingEvent,
    "payment_intent.succeeded": Payment_intentSucceededEvent,
    "payment_intent.payment_failed": Payment_intentPayment_failedEvent,
    "payment_method.attached": Payment_methodAttachedEvent,
    "payment_method.detached": Payment_methodDetachedEvent,
    "product.created": ProductCreatedEvent,
    "product.updated": ProductUpdatedEvent,
    "product.deleted": ProductDeletedEvent,
    "price.created": PriceCreatedEvent,
    "price.updated": PriceUpdatedEvent,
    "price.deleted": PriceDeletedEvent,
}

# All supported event types as Literal
SupportedEventType = Literal[
    "checkout.session.completed",
    "checkout.session.expired",
    "customer.created",
    "customer.updated",
    "customer.deleted",
    "customer.subscription.created",
    "customer.subscription.updated",
    "customer.subscription.deleted",
    "customer.subscription.paused",
    "customer.subscription.resumed",
    "customer.subscription.trial_will_end",
    "invoice.created",
    "invoice.finalized",
    "invoice.paid",
    "invoice.payment_failed",
    "invoice.payment_succeeded",
    "invoice.upcoming",
    "payment_intent.succeeded",
    "payment_intent.payment_failed",
    "payment_method.attached",
    "payment_method.detached",
    "product.created",
    "product.updated",
    "product.deleted",
    "price.created",
    "price.updated",
    "price.deleted",
]


def parse_event(raw_event: dict[str, Any]) -> StripeEvent:
    """
    Parse a raw webhook event into a typed event class.

    Args:
        raw_event: Raw event data from Stripe webhook

    Returns:
        Typed StripeEvent subclass based on event type
    """
    event_type = raw_event.get("type", "")
    event_class = EVENT_TYPE_MAP.get(event_type, StripeEvent)
    return event_class.model_validate(raw_event)
