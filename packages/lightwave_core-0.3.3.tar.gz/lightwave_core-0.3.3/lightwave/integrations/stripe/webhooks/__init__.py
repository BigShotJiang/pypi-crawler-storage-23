"""
Stripe Webhooks Package

Provides typed webhook dispatching for Stripe events.

Usage:
    from lightwave.integrations.stripe.webhooks import (
        WebhookDispatcher,
        register_handler,
    )

    @register_handler("checkout.session.completed")
    def handle_checkout(event: CheckoutSessionCompletedEvent) -> None:
        session = event.data.object
        # Fully typed!
"""

from lightwave.integrations.stripe.webhooks.dispatcher import (
    WebhookDispatcher,
    dispatch_event,
    register_handler,
)

__all__ = [
    "WebhookDispatcher",
    "register_handler",
    "dispatch_event",
]
