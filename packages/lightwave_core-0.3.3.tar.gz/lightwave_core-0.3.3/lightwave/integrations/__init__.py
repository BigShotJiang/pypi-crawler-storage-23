"""Third-party integrations for LightWave applications.

Available integrations:
- stripe: Stripe billing and subscription management
- quickbooks: QuickBooks Online API client
- google_workspace: Google Workspace Admin SDK for user/group sync
- plaid: (future) Plaid banking integration

Stripe Integration:
    from lightwave.integrations.stripe import StripeClient, get_stripe_client
    from lightwave.integrations.stripe.contracts import StripeEvent, parse_event
    from lightwave.integrations.stripe.webhooks import WebhookDispatcher

Google Workspace Integration:
    from lightwave.integrations.google_workspace import (
        GoogleWorkspaceClient,
        get_workspace_client,
    )
"""
