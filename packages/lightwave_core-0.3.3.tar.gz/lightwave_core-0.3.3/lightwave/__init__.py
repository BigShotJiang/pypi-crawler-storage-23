"""LightWave Core - Shared Django utilities for LightWave Media projects."""

__version__ = "0.1.0"
