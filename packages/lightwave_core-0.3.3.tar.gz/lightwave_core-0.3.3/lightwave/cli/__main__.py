"""
Entry point for `python -m lightwave.cli`.

Usage:
    python -m lightwave.cli <domain> <command> [args...]

Example:
    python -m lightwave.cli test run apps/users/tests
    python -m lightwave.cli schema validate
    python -m lightwave.cli dj migrate
"""

from lightwave.cli.runner import main

if __name__ == "__main__":
    main()
