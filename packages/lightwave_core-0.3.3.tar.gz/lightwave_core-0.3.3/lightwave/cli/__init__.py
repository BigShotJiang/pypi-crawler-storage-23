"""
LightWave CLI - Python runtime commands.

This module provides Python-native CLI commands for the `lw` tool.
It is invoked by the Go binary for commands that require Python runtime:
- test: pytest execution, coverage, adversarial testing
- spec: SST test specifications
- schema: Pydantic SST validation
- security: Attack drills
- package: PyPI publishing
- dj: Django management commands (migrate, check, shell)
- docker: Docker development stack (up, down, logs, rebuild, shell)
- db: Database management (shell, dump, restore, reset)
- quality: Code quality (lint, format, ci, pre-commit)

SST Reference: packages/lightwave-core/lightwave/schema/definitions/cli.yaml
"""

from lightwave.cli.runner import main, run_command

__all__ = ["main", "run_command"]
