"""LightWave AI - Shared AI agents and utilities for LightWave Media projects.

This module provides:
- Brand context and voice models for copywriting
- Copywriter agent factory
- Embeddings and semantic similarity
- Constitution service for dynamic agent context
- Second brain knowledge management
- Shared tools (weather, email, admin_db)
- Permission helpers and event handlers
- Common types for agent dependencies
- Base agent factory and utilities
"""

from lightwave.ai.base import (
    add_user_email,
    add_user_name,
    convert_openai_to_pydantic_messages,
    create_agent,
    create_agent_with_constitution,
    current_datetime,
    run_agent,
    run_agent_streaming,
)
from lightwave.ai.brand_context import (
    BrandContext,
    VoiceModel,
    get_brand_context,
)
from lightwave.ai.constitution import (
    ConstitutionService,
    compose_constitution,
    format_constitution_prompt,
)
from lightwave.ai.copywriter import (
    COPYWRITER_SYSTEM_PROMPT,
    get_copywriter_agent,
)
from lightwave.ai.embeddings import (
    EmbeddingService,
    compute_embedding,
    compute_embeddings_batch,
    extract_entity_text,
    find_duplicates,
    find_similar_entities,
)
from lightwave.ai.handlers import agent_event_stream_handler
from lightwave.ai.permissions import tool_requires_superuser
from lightwave.ai.second_brain import (
    SecondBrainService,
    query_second_brain,
)
from lightwave.ai.types import UserDependencies

__all__ = [
    # Brand & Copywriter
    "BrandContext",
    "VoiceModel",
    "get_brand_context",
    "COPYWRITER_SYSTEM_PROMPT",
    "get_copywriter_agent",
    # Constitution & Second Brain
    "ConstitutionService",
    "compose_constitution",
    "format_constitution_prompt",
    "SecondBrainService",
    "query_second_brain",
    # Embeddings & Similarity
    "EmbeddingService",
    "compute_embedding",
    "compute_embeddings_batch",
    "find_similar_entities",
    "find_duplicates",
    "extract_entity_text",
    # Shared infrastructure
    "UserDependencies",
    "tool_requires_superuser",
    "agent_event_stream_handler",
    # Base utilities
    "add_user_name",
    "add_user_email",
    "current_datetime",
    "convert_openai_to_pydantic_messages",
    "run_agent",
    "run_agent_streaming",
    "create_agent",
    "create_agent_with_constitution",
]
