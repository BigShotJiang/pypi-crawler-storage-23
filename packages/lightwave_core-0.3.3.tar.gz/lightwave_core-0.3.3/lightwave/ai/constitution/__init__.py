"""
Constitution Service for dynamic AI agent context.

The constitution system composes personalized agent context from multiple layers:

**Original ConstitutionService (User-Based):**
1. Base Constitution (YAML) - LightWave core principles
2. User Identity (Django) - Legal/financial/professional context
3. User Principles (Django) - Personal values and preferences
4. Second Brain (Django) - Weighted knowledge with semantic search

**DatabaseConstitutionService (Database-Driven with Token Budgeting):**
1. Prompts (Database) - Programmable prompt templates
2. Rules (Database) - Behavioral constraints
3. References (Database) - Reference documentation
4. Test Breadcrumbs (Database) - Context from failed tests
5. Task Context (Database) - Active task information

Usage:
    from lightwave.ai.constitution import ConstitutionService, compose_constitution

    # User-based service (original)
    service = ConstitutionService(user, tenant_schema)
    constitution = service.compose(
        agent_type="v_accountant",
        query_context="Help me with quarterly taxes",
    )
    system_prompt = service.to_system_prompt(constitution)

    # Database-driven service with token budgeting (new)
    from lightwave.ai.constitution import DatabaseConstitutionService

    service = DatabaseConstitutionService(site, max_tokens=100000)
    context = service.assemble(
        agent_type="software-architect",
        task_id="abc123",
        file_paths=["apps/users/views.py"],
    )
    system_prompt = service.to_system_prompt(context)
"""

from lightwave.ai.constitution.database_service import (
    AssembledContext,
    ConstitutionItem,
    DatabaseConstitutionService,
    TokenBudget,
)
from lightwave.ai.constitution.database_service import (
    assemble_constitution as assemble_database_constitution,
)
from lightwave.ai.constitution.formatters import (
    format_constitution_prompt,
    format_identity_section,
    format_knowledge_section,
    format_principles_section,
)
from lightwave.ai.constitution.service import (
    ConstitutionService,
    compose_constitution,
)

__all__ = [
    # Original User-Based Service
    "ConstitutionService",
    "compose_constitution",
    # Database-Driven Service (Phase 5)
    "DatabaseConstitutionService",
    "assemble_database_constitution",
    "AssembledContext",
    "ConstitutionItem",
    "TokenBudget",
    # Formatters
    "format_constitution_prompt",
    "format_identity_section",
    "format_principles_section",
    "format_knowledge_section",
]
