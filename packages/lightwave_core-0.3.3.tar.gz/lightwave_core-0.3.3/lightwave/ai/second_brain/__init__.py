"""
Second Brain Service - Semantic knowledge management.

The Second Brain is a weighted knowledge base that influences AI agent behavior.
It supports:
- Two-layer scoping (personal + tenant-specific)
- Semantic search via embeddings
- Weight decay over time
- Usage tracking and analytics

Usage:
    from lightwave.ai.second_brain import SecondBrainService

    service = SecondBrainService(user, "tenant_schema")

    # Query knowledge
    entries = service.query(
        query="tax planning strategies",
        max_results=10,
    )

    # Add new entry
    entry = service.add_entry(
        title="Tax Deduction Tips",
        content="...",
        entry_type="insight",
        tags=["tax", "accounting"],
        tenant=None,  # Personal entry
    )

    # Update embeddings for all entries
    service.update_embeddings()
"""

from lightwave.ai.second_brain.service import (
    SecondBrainService,
    query_second_brain,
    update_entry_embedding,
)

__all__ = [
    "SecondBrainService",
    "query_second_brain",
    "update_entry_embedding",
]
