"""
Session context system for Claude Code.

This package provides comprehensive context gathering for AI-driven development workflows.
It aggregates Git state, task information from createOS, implementation plans, sprint context,
and knowledge graph references into a structured Pydantic model that can be injected into
Claude Code sessions.

Usage:
    from lightwave.context import SessionContext, build_session_context

    # Build context for current working directory
    context = build_session_context()

    # Export to markdown for Claude consumption
    markdown = context.to_markdown()

    # Validate current state
    warnings = context.validate_state()
"""

from lightwave.context.context_models import (
    Document,
    EnvironmentContext,
    Epic,
    GitContext,
    ImplementationPlan,
    KnowledgeContext,
    PlanContext,
    SessionContext,
    Sprint,
    SprintContext,
    Task,
    TaskContext,
    UserStory,
)
from lightwave.context.precomputer import (
    ContextPrecomputer,
    get_session_context,
    invalidate_context,
    invalidate_context_for_model,
    warm_context_cache,
)
from lightwave.context.session import build_session_context

__all__ = [
    "SessionContext",
    "TaskContext",
    "PlanContext",
    "SprintContext",
    "GitContext",
    "KnowledgeContext",
    "EnvironmentContext",
    "Task",
    "Epic",
    "Sprint",
    "UserStory",
    "Document",
    "ImplementationPlan",
    "build_session_context",
    # Precomputer
    "ContextPrecomputer",
    "get_session_context",
    "invalidate_context",
    "invalidate_context_for_model",
    "warm_context_cache",
]
