"""
CLI entrypoint for session context.

Usage:
    python -m lightwave.context --format json
    python -m lightwave.context --format markdown
    python -m lightwave.context --validate
"""

import argparse
import json
import sys
from pathlib import Path

from lightwave.context.session import build_session_context


def main():
    """Main CLI entrypoint."""
    parser = argparse.ArgumentParser(description="Build session context for Claude Code")
    parser.add_argument(
        "--format",
        choices=["json", "markdown"],
        default="json",
        help="Output format (default: json)",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Validate current state and show warnings",
    )
    parser.add_argument(
        "--cwd",
        type=Path,
        default=Path.cwd(),
        help="Current working directory (default: current directory)",
    )

    args = parser.parse_args()

    try:
        # Build session context
        context = build_session_context(cwd=args.cwd)

        # Validation mode
        if args.validate:
            warnings = context.validate_state()
            if warnings:
                print("⚠️  Validation Warnings:", file=sys.stderr)
                for warning in warnings:
                    print(f"  - {warning}", file=sys.stderr)
                sys.exit(1)
            else:
                print("✓ All validation checks passed", file=sys.stderr)
                sys.exit(0)

        # Output mode
        if args.format == "markdown":
            print(context.to_markdown())
        else:  # json
            print(json.dumps(context.to_json_dict(), indent=2, default=str))

    except Exception as e:
        print(f"Error building session context: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
