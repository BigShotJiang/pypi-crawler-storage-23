"""LightWave Notifications - Alert delivery and notification management.

This module provides:
- NotificationService: Send alerts via multiple channels
- Channel handlers for Slack, email, webhook, in-app
- Throttling and aggregation support
- Quiet hours enforcement

Usage:
    from lightwave.notifications import NotificationService, send_alert

    # Send a single alert
    service = NotificationService()
    service.send(alert)

    # Or use the convenience function
    send_alert(
        alert_type="sprint_at_risk",
        title="Sprint Alpha at risk",
        data={"sprint_name": "Alpha", "completion_percentage": 45},
    )
"""

from lightwave.notifications.service import (
    NotificationService,
    send_alert,
    send_email,
    send_slack_message,
)

__all__ = [
    "NotificationService",
    "send_alert",
    "send_slack_message",
    "send_email",
]
