"""
LightWave Schema - Single Source of Truth Configuration System.

This module provides YAML-based configuration that serves as the ideal state
definition for the LightWave platform. YAML files define WHAT SHOULD EXIST,
and the reconciliation system ensures reality matches the definition.

Architecture:
    YAML Files (Ideal State) → Pydantic Schemas → Reconciler → Database (Runtime State)

Pydantic schemas in pydantic/sst/ are the AUTHORITATIVE typed representations.
All validation happens against YAML at runtime - no hardcoded enums.

Usage:
    # Raw YAML loading
    from lightwave.schema import load_schema
    layouts = load_schema('layouts')

    # Typed loading (preferred)
    from lightwave.schema import load_layouts, get_layout
    layouts = load_layouts()  # Returns list[LayoutSchema]
    web = get_layout("web")  # Returns LayoutSchema

    # SST Pydantic schemas
    from lightwave.schema import LayoutSchema, PageSchemaDefinition
    layouts = LayoutSchema.get_all_from_sst()

    # Field validation
    from lightwave.schema import FieldOptions
    FieldOptions.validate("page_statuses", "published")

    # Reconcile database to match YAML
    from lightwave.schema import reconcile
    report = reconcile('layouts', check_only=True)
"""

# Raw YAML loading (returns dicts)
# Django model validators - for clean() method integration
from lightwave.schema.core.types import (
    CrossReferenceReport,
    PlatformRegistry,
    ValidationIssue,
)

# Typed loading (returns Pydantic schema instances)
from lightwave.schema.loaders.base import (
    SchemaLoader,
    get_blueprint,
    get_layout,
    get_required_pages_for_site_type,
    get_schema_path,
    get_site_type_blueprint,
    load_blueprints,
    load_layouts,
    load_navigation,
    load_pages,
    load_schema,
    load_site_type_blueprints,
    validate_schema,
)

# Field options validator - runtime validation against field_options.yaml
from lightwave.schema.pydantic.core.validators import (
    FieldOptions,
    FieldOptionsError,
    get_field_default,
    get_field_values,
    validate_field_option,
)

# CMS JSONField schemas - for Django model validation
from lightwave.schema.pydantic.models.cms import (
    # Agent permissions
    AgentPermissionsSchema,
    # Outbox payloads
    PageCreationPayloadSchema,
    PageDeletionPayloadSchema,
    PageUpdatePayloadSchema,
    PageVersionDataSchema,
    # Site settings
    SiteSettingsSchema,
)
from lightwave.schema.pydantic.models.cms import (
    # Page schemas
    PageMetadataSchema as CMSPageMetadataSchema,  # Alias to avoid conflict with SST PageMetadataSchema
)

# SST Pydantic schemas - authoritative typed representations
from lightwave.schema.pydantic.sst import (
    BlogInterviewConfig,
    CLICommandSchema,
    # CLI schemas
    CLIConfig,
    CLIDomainSchema,
    ContentAuditConfig,
    # Content Automation schemas
    ContentAutomationConfig,
    # Core schemas
    DjangoSettings,
    IslandConfig,
    LayoutSchema,
    MenuLocationConfig,
    NavItemSchema,
    NewsletterConfig,
    PageMetadataSchema,
    PageSchemaDefinition,
    PageSeedSchema,
    get_cli_config,
    get_content_automation_config,
)

# Reconciler
from lightwave.schema.tools.reconcile import (
    DriftReport,
    DriftStatus,
    Reconciler,
    reconcile,
)

# Cross-reference validation
from lightwave.schema.validation.cross_validator import CrossReferenceValidator

# Django validators (optional - only available when Django is installed)
_HAS_DJANGO = False
try:
    from lightwave.schema.validation.django import (
        # Mixins
        FieldOptionsValidatorMixin,
        JSONFieldValidator,
        SSTBlueprintValidator,
        # SST Validators
        SSTLayoutValidator,
        SSTNavItemValidator,
        get_field_choices,
        # Choice helpers
        get_layout_choices,
        validate_auth_mode,
        validate_block_type,
        validate_content_status,
        validate_outbox_item_type,
        validate_page_status,
        # Field validators
        validate_page_type,
    )

    _HAS_DJANGO = True
except ImportError:
    # Django not installed - validators not available
    pass

__all__ = [
    # Raw YAML Loader
    "SchemaLoader",
    "load_schema",
    "validate_schema",
    "get_schema_path",
    # Typed Loading (Pydantic instances)
    "load_layouts",
    "load_blueprints",
    "load_navigation",
    "load_pages",
    "get_layout",
    "get_blueprint",
    # Site Type Blueprints
    "load_site_type_blueprints",
    "get_site_type_blueprint",
    "get_required_pages_for_site_type",
    # Reconciler
    "Reconciler",
    "DriftReport",
    "DriftStatus",
    "reconcile",
    # SST Pydantic Schemas
    "DjangoSettings",
    "LayoutSchema",
    "PageSchemaDefinition",
    "IslandConfig",
    "NavItemSchema",
    "MenuLocationConfig",
    "PageSeedSchema",
    "PageMetadataSchema",
    # CLI
    "CLIConfig",
    "CLICommandSchema",
    "CLIDomainSchema",
    "get_cli_config",
    # Content Automation
    "ContentAutomationConfig",
    "BlogInterviewConfig",
    "NewsletterConfig",
    "ContentAuditConfig",
    "get_content_automation_config",
    # Field Options Validation
    "FieldOptions",
    "FieldOptionsError",
    "validate_field_option",
    "get_field_values",
    "get_field_default",
    # CMS JSONField Schemas
    "SiteSettingsSchema",
    "CMSPageMetadataSchema",
    "PageVersionDataSchema",
    "PageCreationPayloadSchema",
    "PageUpdatePayloadSchema",
    "PageDeletionPayloadSchema",
    "AgentPermissionsSchema",
    # Cross-reference Validation
    "CrossReferenceValidator",
    "CrossReferenceReport",
    "PlatformRegistry",
    "ValidationIssue",
]

# Conditionally add Django validators to __all__ if Django is installed
if _HAS_DJANGO:
    __all__.extend(
        [
            # Django Model Validators
            "FieldOptionsValidatorMixin",
            "SSTLayoutValidator",
            "SSTBlueprintValidator",
            "SSTNavItemValidator",
            "JSONFieldValidator",
            "validate_page_type",
            "validate_page_status",
            "validate_content_status",
            "validate_outbox_item_type",
            "validate_block_type",
            "validate_auth_mode",
            "get_layout_choices",
            "get_field_choices",
        ]
    )
