"""
Pydantic schemas for LightWave platform.

This package provides type-safe Pydantic schemas for:
- SST YAML validation (sst/) - validate against Single Source of Truth
- API request/response (api/) - django-ninja request/response schemas
- Django model JSONFields (models/) - typed validation for JSONField data
- App-mirrored schemas (apps/) - schemas organized by Django app structure
- Custom validators (validators/) - reusable validation utilities

All schemas use Pydantic v2 and are designed for full type safety
from YAML → Pydantic → Django → API → TypeScript.

Type Lineage:
    YAML (SST) → Pydantic → Django Model → Ninja API → TypeScript → React UI
        ↓           ↓            ↓             ↓            ↓          ↓
     DEFINES    VALIDATES    STORES      SERIALIZES    TYPES      RENDERS

Schema Locations (Three-Tier Architecture):
    Tier 1: pydantic/models/    - Truly shared infrastructure schemas
    Tier 2: pydantic/apps/      - App-mirrored schemas (PREFERRED for app-specific)
    Tier 3: Django app schemas/ - Local extensions (optional)

Usage:
    from lightwave.schema.pydantic import (
        LightwaveBaseSchema,
        SSTSchema,
        JSONFieldSchema,
        APIRequestSchema,
        APIResponseSchema,
    )

    # SST schemas (authoritative type definitions)
    from lightwave.schema.pydantic.sst import LayoutSchema, PageSchemaDefinition

    # Field validation against field_options.yaml
    from lightwave.schema.pydantic.core.validators import FieldOptions

    # App-mirrored schemas (PREFERRED for app-specific)
    from lightwave.schema.pydantic.domains.platform.createos import PersonaSchema
    from lightwave.schema.pydantic.domains.core.user import UserProfileSchema

    # Model JSONField schemas (deprecated path, use apps/ instead)
    from lightwave.schema.pydantic.models import SiteSettingsSchema, PageMetadataSchema

    # API schemas
    from lightwave.schema.pydantic.contracts.api import PageCreateRequest, PageResponse
"""

# Domain-mirrored schemas (import subpackage for access)
from lightwave.schema.pydantic import domains
from lightwave.schema.pydantic.core.base import (
    APIRequestSchema,
    APIResponseSchema,
    AuditMixin,
    ErrorDetail,
    ErrorResponse,
    JSONFieldSchema,
    LightwaveBaseSchema,
    PaginatedResponse,
    SoftDeleteMixin,
    SSTSchema,
    TimestampMixin,
)

# Re-export validators for convenience
from lightwave.schema.pydantic.core.validators import (
    FieldOptions,
    FieldOptionsError,
    get_field_default,
    get_field_values,
    validate_field_option,
)

# Re-export model JSONField schemas (createOS)
from lightwave.schema.pydantic.models import (
    AcceptanceCriterionSchema,
    CriticalFileSchema,
    DebriefInsightSchema,
    DependencySchema,
    EdgeCaseSchema,
    ImplementationPlanRiskSchema,
    InterviewMessageSchema,
    PastAchievementSchema,
    PatternSchema,
    PersonaSchema,
    RBACRequirementSchema,
    RoadmapMilestoneSchema,
    TechnicalConstraintSchema,
    TestScenarioSchema,
    UserFlowSchema,
)

# Re-export SST schemas for convenience
from lightwave.schema.pydantic.sst import (
    IslandConfig,
    LayoutSchema,
    MenuLocationConfig,
    NavItemSchema,
    PageMetadataSchema,
    PageSchemaDefinition,
    PageSeedSchema,
)

__all__ = [
    # Domain-mirrored subpackage
    "domains",
    # Base classes
    "LightwaveBaseSchema",
    "SSTSchema",
    "APIRequestSchema",
    "APIResponseSchema",
    "JSONFieldSchema",
    # Response wrappers
    "PaginatedResponse",
    "ErrorDetail",
    "ErrorResponse",
    # Mixins
    "TimestampMixin",
    "SoftDeleteMixin",
    "AuditMixin",
    # SST Schemas (authoritative type definitions)
    "LayoutSchema",
    "PageSchemaDefinition",
    "IslandConfig",
    "NavItemSchema",
    "MenuLocationConfig",
    "PageSeedSchema",
    "PageMetadataSchema",
    # Field Options Validation
    "FieldOptions",
    "FieldOptionsError",
    "validate_field_option",
    "get_field_values",
    "get_field_default",
    # createOS Model JSONField Schemas
    "PersonaSchema",
    "UserFlowSchema",
    "EdgeCaseSchema",
    "TechnicalConstraintSchema",
    "RBACRequirementSchema",
    "InterviewMessageSchema",
    "AcceptanceCriterionSchema",
    "TestScenarioSchema",
    "RoadmapMilestoneSchema",
    "PastAchievementSchema",
    "CriticalFileSchema",
    "DependencySchema",
    "ImplementationPlanRiskSchema",
    "PatternSchema",
    "DebriefInsightSchema",
]
