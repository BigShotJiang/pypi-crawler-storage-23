"""
Pydantic schemas for Payload CMS Hook types.

AUTO-GENERATED FROM payload-manifest.json - DO NOT EDIT MANUALLY
"""

from __future__ import annotations

from typing import Any, Callable, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field

# Generic type for document data
TData = TypeVar("TData", bound=dict[str, Any])


class FieldHookArgs(BaseModel):
    """Payload CMS FieldHookArgs type."""

    block_data: dict[str, Any] | None = Field(
        default=None,
        alias="blockData",
        description="The data of the nearest parent block. If the field is not within a block, `blockData` will be equ...",
    )
    collection: Any = Field(
        description="The collection which the field belongs to. If the field belongs to a global, this will be null."
    )
    context: dict[str, Any]
    current_depth: int | float | None = Field(
        default=None, alias="currentDepth", description="Only available in `afterRead` hooks"
    )
    data: dict[str, Any] | None = Field(default=None, description="Only available in `afterRead` hooks")
    depth: int | float | None = Field(default=None, description="Only available in the `afterRead` hook.")
    draft: bool | None = Field(default=None)
    field: Any = Field(description="The field which the hook is running against.")
    find_many: bool | None = Field(
        default=None,
        alias="findMany",
        description="Boolean to denote if this hook is running against finding one, or finding many within the afterRe...",
    )
    global_: Any = Field(
        alias="global",
        description="The global which the field belongs to. If the field belongs to a collection, this will be null.",
    )
    index_path: list[int | float] = Field(alias="indexPath")
    operation: Literal["create", "delete", "read", "update"] | None = Field(
        default=None,
        description="A string relating to which operation the field type is currently executing within. Useful within ...",
    )
    original_doc: Any | None = Field(
        default=None,
        alias="originalDoc",
        description="The full original document in `update` operations. In the `afterChange` hook, this is the resulti...",
    )
    override_access: bool | None = Field(default=None, alias="overrideAccess")
    path: list[Any] = Field(
        description='The path of the field, e.g. ["group", "myArray", 1, "textField"]. The path is the schemaPat...'
    )
    previous_doc: Any | None = Field(
        default=None,
        alias="previousDoc",
        description="The document before changes were applied, only in `afterChange` hooks.",
    )
    previous_sibling_doc: Any | None = Field(
        default=None,
        alias="previousSiblingDoc",
        description="The sibling data of the document before changes being applied, only in `beforeChange`, `beforeVal...",
    )
    previous_value: Any | None = Field(
        default=None,
        alias="previousValue",
        description="The previous value of the field, before changes, only in `beforeChange`, `afterChange`, `beforeDu...",
    )
    req: dict[str, Any] = Field(description="The Express request object. It is mocked for Local API operations.")
    schema_path: list[str] = Field(
        alias="schemaPath",
        description='The schemaPath of the field, e.g. ["group", "myArray", "textField"]. The schemaPath is the ...',
    )
    show_hidden_fields: bool | None = Field(
        default=None, alias="showHiddenFields", description="Only available in the `afterRead` hook."
    )
    sibling_data: dict[str, Any] = Field(
        alias="siblingData", description="The sibling data passed to a field that the hook is running against."
    )
    sibling_doc_with_locales: dict[str, Any] | None = Field(
        default=None,
        alias="siblingDocWithLocales",
        description="The original siblingData with locales (not modified by any hooks). Only available in `beforeChang...",
    )
    sibling_fields: list[Any] = Field(
        alias="siblingFields", description="The sibling fields of the field which the hook is running against."
    )
    value: Any | None = Field(default=None, description="The value of the field.")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


# AfterChangeHook
AfterChangeHook = Callable[[dict[str, Any]], Any]

# AfterChangeHook
AfterChangeHook = Callable[[dict[str, Any]], Any]

# AfterDeleteHook
AfterDeleteHook = Callable[[dict[str, Any]], Any]

# AfterErrorHook
AfterErrorHook = Callable[[dict[str, Any]], Any]

# AfterErrorHook
AfterErrorHook = Callable[[dict[str, Any]], Any]

# AfterForgotPasswordHook
AfterForgotPasswordHook = Callable[[dict[str, Any]], Any]

# AfterLoginHook
AfterLoginHook = Callable[[dict[str, Any]], Any]

# AfterLogoutHook
AfterLogoutHook = Callable[[dict[str, Any]], Any]

# AfterMeHook
AfterMeHook = Callable[[dict[str, Any]], Any]

# AfterOperationHook
AfterOperationHook = Callable[[dict[str, Any]], Any]

# AfterReadHook
AfterReadHook = Callable[[dict[str, Any]], Any]

# AfterReadHook
AfterReadHook = Callable[[dict[str, Any]], Any]

# AfterRefreshHook
AfterRefreshHook = Callable[[dict[str, Any]], Any]

# BeforeChangeHook
BeforeChangeHook = Callable[[dict[str, Any]], Any]

# BeforeChangeHook
BeforeChangeHook = Callable[[dict[str, Any]], Any]

# BeforeDeleteHook
BeforeDeleteHook = Callable[[dict[str, Any]], Any]

# BeforeLoginHook
BeforeLoginHook = Callable[[dict[str, Any]], Any]

# BeforeOperationHook
BeforeOperationHook = Callable[[dict[str, Any]], Any]

# BeforeOperationHook
BeforeOperationHook = Callable[[dict[str, Any]], Any]

# BeforeReadHook
BeforeReadHook = Callable[[dict[str, Any]], Any]

# BeforeReadHook
BeforeReadHook = Callable[[dict[str, Any]], Any]

# BeforeValidateHook
BeforeValidateHook = Callable[[dict[str, Any]], Any]

# BeforeValidateHook
BeforeValidateHook = Callable[[dict[str, Any]], Any]

# FieldHook
FieldHook = Callable[[dict[str, Any]], Any]

# MeHook
MeHook = Callable[[dict[str, Any]], Any]

# RefreshHook
RefreshHook = Callable[[dict[str, Any]], Any]
