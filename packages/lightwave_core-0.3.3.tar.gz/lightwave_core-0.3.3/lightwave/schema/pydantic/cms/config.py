"""
Pydantic schemas for Payload CMS Config types.

AUTO-GENERATED FROM payload-manifest.json - DO NOT EDIT MANUALLY
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class Access(BaseModel):
    """Access function runs on the server
    and is sent to the client allowing the dashboard to show accessible data and actions."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class AccessArgs(BaseModel):
    """Payload CMS AccessArgs type."""

    data: Any | None = Field(
        default=None,
        description="The relevant resource that is being accessed.  `data` is null when a list is requested",
    )
    id_: str | int | float | None = Field(default=None, alias="id", description="ID of the resource being accessed")
    is_reading_static_file: bool | None = Field(
        default=None, alias="isReadingStaticFile", description="If true, the request is for a static file"
    )
    req: dict[str, Any] = Field(description="The original request that requires an access check")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class AccessResult(BaseModel):
    """This result is calculated on the server
    and then sent to the client allowing the dashboard to show accessible data and actions.

    If the result is `true`, the user has access.
    If the result is an object, it is interpreted as a MongoDB query."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class BaseDocumentViewConfig(BaseModel):
    """Payload CMS BaseDocumentViewConfig type."""

    actions: list[Any] | None = Field(default=None)
    meta: Any | None = Field(default=None)
    tab: Any | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class BaseLocalizationConfig(BaseModel):
    """Payload CMS BaseLocalizationConfig type."""

    default_locale: str = Field(
        alias="defaultLocale",
        description="Locale for users that have not expressed their preference for a specific locale",
    )
    default_locale_publish_option: Literal["active", "all"] | None = Field(
        default="all",
        alias="defaultLocalePublishOption",
        description="Change the locale used by the default Publish button. If set to `all`, all locales will be publis...",
    )
    fallback: bool | None = Field(
        default=True,
        description="Set to `true` to let missing values in localised fields fall back to the values in `defaultLocale...",
    )
    filter_available_locales: list[Any] | None = Field(
        default=None,
        alias="filterAvailableLocales",
        description="Define a function to filter the locales made available in Payload admin UI based on user.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class BinScriptConfig(BaseModel):
    """Payload CMS BinScriptConfig type."""

    key: str
    script_path: str = Field(alias="scriptPath")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CORSConfig(BaseModel):
    """Payload CMS CORSConfig type."""

    headers: list[str] | None = Field(default=None)
    origins: Literal["*"]

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ClientUploadsConfig(BaseModel):
    """Payload CMS ClientUploadsConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CollectionConfig(BaseModel):
    """Manage all aspects of a data collection"""

    sanitized: bool | None = Field(
        default=None,
        alias="_sanitized",
        description="Do not set this property manually. This is set to true during sanitization, to avoid sanitizing t...",
    )
    access: Any | None = Field(default=None, description="Access control")
    admin: Any | None = Field(default=None, description="Collection admin options")
    auth: bool | Any | None = Field(
        default=None, description="Collection login options  Use `true` to enable with default options"
    )
    custom: Any | None = Field(default=None, description="Configuration for bulk operations")
    db_name: str | Any | None = Field(
        default=None,
        alias="dbName",
        description="Used to override the default naming of the database table or collection with your using a functio...",
    )
    default_populate: Any | None = Field(default=None, alias="defaultPopulate")
    default_sort: str | Any | None = Field(
        default=None, alias="defaultSort", description="Default field to sort by in collection list view"
    )
    disable_bulk_edit: bool | None = Field(
        default=None,
        alias="disableBulkEdit",
        description="Disable the bulk edit operation for the collection in the admin panel and the API",
    )
    disable_duplicate: bool | None = Field(
        default=None,
        alias="disableDuplicate",
        description='When true, do not show the "Duplicate" button while editing documents within this collection an...',
    )
    enable_query_presets: bool | None = Field(
        default=None, alias="enableQueryPresets", description="Opt-in to enable query presets for this collection."
    )
    endpoints: bool | Any | None = Field(
        default=None,
        description="Custom rest api endpoints, set false to disable all rest endpoints for this collection.",
    )
    fields: list[Any]
    folders: bool | Any | None = Field(default=None, description="Enables folders for this collection")
    force_select: Any | None = Field(
        default=None,
        alias="forceSelect",
        description="Specify which fields should be selected always, regardless of the `select` query which can be use...",
    )
    graph_ql: bool | Any | None = Field(default=None, alias="graphQL", description="GraphQL configuration")
    hooks: Any | None = Field(default=None, description="Hooks to modify Payload functionality")
    indexes: list[Any] | None = Field(
        default="[]",
        description="Define compound indexes for this collection. This can be used to either speed up querying/sorting...",
    )
    labels: Any | None = Field(default=None, description="Label configuration")
    lock_documents: bool | Any | None = Field(
        default=True,
        alias="lockDocuments",
        description="Enables / Disables the ability to lock documents while editing",
    )
    orderable: bool | None = Field(
        default=False,
        description="If true, enables custom ordering for the collection, and documents in the listView can be reorder...",
    )
    slug: str
    timestamps: bool | None = Field(default=True, description="Add `createdAt`, `deletedAt` and `updatedAt` fields")
    trash: bool | None = Field(
        default=False,
        description="Enables trash support for this collection.  When enabled, documents will include a `deletedAt` ti...",
    )
    typescript: Any | None = Field(default=None, description="Options used in typescript generation")
    upload: bool | Any | None = Field(
        default="false // disable uploads", description="Customize the handling of incoming file uploads"
    )
    versions: bool | Any | None = Field(
        default="false // disable versioning",
        description="Enable versioning. Set it to true to enable default versions settings, or customize versions opti...",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Config(BaseModel):
    """This is the central configuration"""

    admin: str | dict[str, Any] | None = Field(default=None, description="Configure admin dashboard")
    auth: list[Any] | None = Field(default=None, description="Configure authentication-related Payload-wide settings.")
    bin: list[Any] | None = Field(
        default=None, description="Custom Payload bin scripts can be injected via the config."
    )
    blocks: list[Any] | None = Field(default=None)  # Block from fields.py
    body_parser: Any | None = Field(
        default=None,
        alias="bodyParser",
        description="Pass additional options to the parser used to process `multipart/form-data` requests. For example...",
    )
    collections: list[Any] | None = Field(default=None, description="Manage the datamodel of your application")
    compatibility: Any | None = Field(default=None, description="Compatibility flags for prior Payload versions")
    cookie_prefix: str | None = Field(
        default="payload", alias="cookiePrefix", description="Prefix a string to all cookies that Payload sets."
    )
    cors: Literal["*"] | None = Field(
        default=None,
        description="Either a whitelist array of URLS to allow CORS requests from, or a wildcard string ('*') to accep...",
    )
    csrf: list[str] | None = Field(
        default=None,
        description="A whitelist array of URLs to allow Payload cookies to be accepted from as a form of CSRF protection.",
    )
    custom: dict[str, Any] | None = Field(
        default=None, description="Extension point to add your custom data. Server only."
    )
    db: Any = Field(description="Pass in a database adapter for use on this project.")
    debug: bool | None = Field(default=None, description="Enable to expose more detailed error information.")
    default_depth: int | float | None = Field(
        default=2,
        alias="defaultDepth",
        description="If a user does not specify `depth` while requesting a resource, this depth will be used.",
    )
    default_max_text_length: int | float | None = Field(
        default=40000,
        alias="defaultMaxTextLength",
        description="The maximum allowed depth to be permitted application-wide. This setting helps prevent against ma...",
    )
    editor: Any | None = Field(default=None, description="Default richtext editor to use for richText fields")
    email: Any | None = Field(default=None, description="Email Adapter")
    endpoints: list[Any] | None = Field(default=None, description="Custom REST endpoints")
    experimental: Any | None = Field(
        default=None, description="Experimental features may be unstable or change in future versions."
    )
    folders: bool | Any | None = Field(default=None, description="Options for folder view within the admin panel")
    globals: list[Any] | None = Field(default=None)
    graph_ql: Any | None = Field(
        default=None,
        alias="graphQL",
        description="Manage the GraphQL API  You can add your own GraphQL queries and mutations to Payload, making use...",
    )
    hooks: list[Any] | None = Field(default=None, description="Tap into Payload-wide hooks.")
    i18n: Any | None = Field(default=None, description="i18n config settings")
    index_sortable_fields: bool | None = Field(
        default=None,
        alias="indexSortableFields",
        description="Automatically index all sortable top-level fields in the database to improve sort performance and...",
    )
    jobs: Any | None = Field(default=None)
    kv: Any | None = Field(default=None, description="Pass in a KV adapter for use on this project.")
    localization: bool | dict[str, Any] | None = Field(
        default="false // disable localization", description="Translate your content to different languages/locales."
    )
    logger: Any | None = Field(
        default=None,
        description="Logger options, logger options with a destination stream, or an instantiated logger instance.  Se...",
    )
    logging_levels: dict[str, Any] | None = Field(
        default=None,
        alias="loggingLevels",
        description="Override the log level of errors for Payload's error handler or disable logging with `false`. Lev...",
    )
    max_depth: int | float | None = Field(
        default=10,
        alias="maxDepth",
        description="The maximum allowed depth to be permitted application-wide. This setting helps prevent against ma...",
    )
    on_init: Any | None = Field(
        default=None,
        alias="onInit",
        description="A function that is called immediately following startup that receives the Payload instance as its...",
    )
    plugins: list[Any] | None = Field(default=None, description="An array of Payload plugins.")
    query_presets: Any | None = Field(
        default=None,
        alias="queryPresets",
        description="Allow you to save and share filters, columns, and sort orders for your collections.",
    )
    routes: Any | None = Field(default=None, description="Control the routing structure that Payload binds itself to.")
    secret: str = Field(description="Secure string that Payload will use for any encryption workflows")
    server_url: str | None = Field(
        default=None,
        alias="serverURL",
        description="Define the absolute URL of your app including the protocol, for example `https://example.org`. No...",
    )
    sharp: Any | None = Field(default=None, description="Pass in a local copy of Sharp if you'd like to use it.")
    telemetry: bool | None = Field(default=None, description="Send anonymous telemetry data about general usage.")
    typescript: Any | None = Field(
        default=None, description="Control how typescript interfaces are generated from your collections."
    )
    upload: Any | None = Field(
        default=None,
        description="Customize the handling of incoming file uploads for collections that have uploads enabled.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CustomDocumentViewConfig(BaseModel):
    """Payload CMS CustomDocumentViewConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class DashboardConfig(BaseModel):
    """Payload CMS DashboardConfig type."""

    default_layout: Any | None = Field(default=None, alias="defaultLayout")
    widgets: list[Any]

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class DateFieldTimezoneConfig(BaseModel):
    """Payload CMS DateFieldTimezoneConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class DefaultDocumentViewConfig(BaseModel):
    """Payload CMS DefaultDocumentViewConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class DocumentViewConfig(BaseModel):
    """Payload CMS DocumentViewConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class EditConfig(BaseModel):
    """Payload CMS EditConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class EditViewConfig(BaseModel):
    """Payload CMS EditViewConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class GlobalConfig(BaseModel):
    """Payload CMS GlobalConfig type."""

    sanitized: bool | None = Field(
        default=None,
        alias="_sanitized",
        description="Do not set this property manually. This is set to true during sanitization, to avoid sanitizing t...",
    )
    access: Any | None = Field(default=None)
    admin: Any | None = Field(default=None)
    custom: Any | None = Field(default=None, description="Extension point to add your custom data. Server only.")
    db_name: str | Any | None = Field(default=None, alias="dbName", description="Customize the SQL table name")
    endpoints: bool | Any | None = Field(default=None)
    fields: list[Any]
    force_select: Any | None = Field(
        default=None,
        alias="forceSelect",
        description="Specify which fields should be selected always, regardless of the `select` query which can be use...",
    )
    graph_ql: bool | Any | None = Field(default=None, alias="graphQL")
    hooks: Any | None = Field(default=None)
    label: str | Any | None = Field(default=None)
    lock_documents: bool | Any | None = Field(
        default=True,
        alias="lockDocuments",
        description="Enables / Disables the ability to lock documents while editing",
    )
    slug: str
    typescript: Any | None = Field(default=None, description="Options used in typescript generation")
    versions: bool | Any | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class LivePreviewConfig(BaseModel):
    """Payload CMS LivePreviewConfig type."""

    breakpoints: list[Any] | None = Field(
        default=None,
        description="Device breakpoints to use for the `iframe` of the Live Preview window.    Options are displayed i...",
    )
    url: str | dict[str, Any] | None = Field(
        default=None,
        description="The URL of the frontend application. This will be rendered within an `iframe` as its `src`. Paylo...",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class LocalizationConfig(BaseModel):
    """Payload CMS LocalizationConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class MetaConfig(BaseModel):
    """Payload CMS MetaConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class OGImageConfig(BaseModel):
    """Payload CMS OGImageConfig type."""

    alt: str | None = Field(default=None)
    height: str | int | float | None = Field(default=None)
    type_: str | None = Field(default=None, alias="type")
    url: str
    width: str | int | float | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Permission(BaseModel):
    """A permission object that can be used to determine if a user has access to a specific operation."""

    permission: bool
    where: dict[str, Any] | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Permissions(BaseModel):
    """Payload CMS Permissions type."""

    can_access_admin: bool = Field(alias="canAccessAdmin")
    collections: dict[str, Any] | None = Field(default=None)
    globals: dict[str, Any] | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class RootLivePreviewConfig(BaseModel):
    """Payload CMS RootLivePreviewConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedCollectionConfig(BaseModel):
    """Payload CMS SanitizedCollectionConfig type."""

    admin: Any
    auth: Any
    endpoints: bool | Any
    fields: list[Any]
    flattened_fields: list[Any] = Field(
        alias="flattenedFields",
        description="Fields in the database schema structure Rows / collapsible / tabs w/o name `fields` merged to top...",
    )
    folders: bool | Any = Field(description="Object of collections to join 'Join Fields object keyed by collection")
    joins: Any
    polymorphic_joins: list[Any] = Field(alias="polymorphicJoins", description="List of all polymorphic join fields")
    sanitized_indexes: list[Any] = Field(alias="sanitizedIndexes")
    slug: str
    upload: Any
    versions: Any | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedConfig(BaseModel):
    """Payload CMS SanitizedConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedDashboardConfig(BaseModel):
    """Payload CMS SanitizedDashboardConfig type."""

    widgets: list[dict[str, Any]]

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedGlobalConfig(BaseModel):
    """Payload CMS SanitizedGlobalConfig type."""

    endpoints: bool | Any
    fields: list[Any]
    flattened_fields: list[Any] = Field(
        alias="flattenedFields",
        description="Fields in the database schema structure Rows / collapsible / tabs w/o name `fields` merged to top...",
    )
    slug: str
    versions: Any | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedLocalizationConfig(BaseModel):
    """Payload CMS SanitizedLocalizationConfig type."""

    default_locale: str = Field(
        alias="defaultLocale",
        description="Locale for users that have not expressed their preference for a specific locale",
    )
    default_locale_publish_option: Literal["active", "all"] | None = Field(
        default="all",
        alias="defaultLocalePublishOption",
        description="Change the locale used by the default Publish button. If set to `all`, all locales will be publis...",
    )
    fallback: bool | None = Field(
        default=True,
        description="Set to `true` to let missing values in localised fields fall back to the values in `defaultLocale...",
    )
    filter_available_locales: list[Any] | None = Field(
        default=None,
        alias="filterAvailableLocales",
        description="Define a function to filter the locales made available in Payload admin UI based on user.",
    )
    locale_codes: list[str] = Field(alias="localeCodes", description="List of supported locales")
    locales: list[Any] = Field(description="List of supported locales with labels")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedTimezoneConfig(BaseModel):
    """Payload CMS SanitizedTimezoneConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SanitizedUploadConfig(BaseModel):
    """Payload CMS SanitizedUploadConfig type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class TimezonesConfig(BaseModel):
    """Payload CMS TimezonesConfig type."""

    default_timezone: str | None = Field(
        default=None, alias="defaultTimezone", description="The default timezone to use for the admin panel."
    )
    supported_timezones: Any | None = Field(
        default=None,
        alias="supportedTimezones",
        description="Provide your own list of supported timezones for the admin panel  Values should be IANA timezone ...",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class UploadConfig(BaseModel):
    """Payload CMS UploadConfig type."""

    adapter: str | None = Field(
        default="undefined", description="The adapter name to use for uploads. Used for storage adapter telemetry."
    )
    admin: Any | None = Field(default=None, description="The admin configuration for the upload field.")
    admin_thumbnail: str | Any | None = Field(
        default=None,
        alias="adminThumbnail",
        description="Represents an admin thumbnail, which can be either a React component or a string. - If a string, ...",
    )
    allow_restricted_file_types: bool | None = Field(
        default=False,
        alias="allowRestrictedFileTypes",
        description="Allow restricted file types known to be problematic. - If set to `true`, it will allow all file t...",
    )
    bulk_upload: bool | None = Field(
        default=True, alias="bulkUpload", description="Enables bulk upload of files from the list view."
    )
    cache_tags: bool | None = Field(
        default=True,
        alias="cacheTags",
        description="Appends a cache tag to the image URL when fetching the thumbnail in the admin panel. It may be de...",
    )
    constructor_options: Any | None = Field(
        default=None,
        alias="constructorOptions",
        description="Sharp constructor options to be passed to the uploaded file.",
    )
    crop: bool | None = Field(default=True, description="Enables cropping of images.")
    disable_local_storage: bool | None = Field(
        default=False, alias="disableLocalStorage", description="Disable the ability to save files to disk."
    )
    display_preview: bool | None = Field(
        default=False,
        alias="displayPreview",
        description="Enable displaying preview of the uploaded file in Upload fields related to this Collection. Can b...",
    )
    external_file_header_filter: Any | None = Field(
        default="undefined",
        alias="externalFileHeaderFilter",
        description="Accepts existing headers and returns the headers after filtering or modifying. If using this opti...",
    )
    filename_compound_index: list[str] | None = Field(
        default=None,
        alias="filenameCompoundIndex",
        description="Field slugs to use for a compound index instead of the default filename index.",
    )
    files_required_on_create: bool | None = Field(
        default=True,
        alias="filesRequiredOnCreate",
        description="Require files to be uploaded when creating a document.",
    )
    focal_point: bool | None = Field(
        default=False, alias="focalPoint", description="Enables focal point positioning for image manipulation."
    )
    format_options: Any | None = Field(
        default=None,
        alias="formatOptions",
        description="Format options for the uploaded file. Formatting image sizes needs to be done within each formatO...",
    )
    handlers: Any | None = Field(
        default="undefined",
        description="Custom handlers to run when a file is fetched.  - If a handler returns a Response, the response w...",
    )
    hide_file_input_on_create: bool | None = Field(
        default=None,
        alias="hideFileInputOnCreate",
        description="Set to `true` to prevent the admin UI from showing file inputs during document creation, useful f...",
    )
    hide_remove_file: bool | None = Field(
        default=None,
        alias="hideRemoveFile",
        description="Set to `true` to prevent the admin UI having a way to remove an existing file while editing.",
    )
    image_sizes: list[Any] | None = Field(default=None, alias="imageSizes")
    mime_types: list[str] | None = Field(
        default="undefined",
        alias="mimeTypes",
        description="Restrict mimeTypes in the file picker. Array of valid mime types or mimetype wildcards",
    )
    modify_response_headers: Any | None = Field(
        default="undefined",
        alias="modifyResponseHeaders",
        description="Ability to modify the response headers fetching a file.",
    )
    paste_url: bool | Any | None = Field(
        default="true (client-side fetching enabled)",
        alias="pasteURL",
        description="Controls the behavior of pasting/uploading files from URLs. If set to `false`, fetching from remo...",
    )
    resize_options: Any | None = Field(
        default="undefined", alias="resizeOptions", description="Sharp resize options for the original image."
    )
    skip_safe_fetch: bool | Any | None = Field(
        default=False,
        alias="skipSafeFetch",
        description="Skip safe fetch when using server-side fetching for external files from these URLs.",
    )
    static_dir: str | None = Field(
        default="undefined",
        alias="staticDir",
        description="The directory to serve static files from. Defaults to collection slug.",
    )
    trim_options: Any | None = Field(default=None, alias="trimOptions")
    with_metadata: bool | Any | None = Field(
        default=False,
        alias="withMetadata",
        description="Optionally append metadata to the image during processing.  Can be a boolean or a function.  If t...",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class VerifyConfig(BaseModel):
    """Payload CMS VerifyConfig type."""

    generate_email_html: Any | None = Field(default=None, alias="generateEmailHTML")
    generate_email_subject: Any | None = Field(default=None, alias="generateEmailSubject")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )
