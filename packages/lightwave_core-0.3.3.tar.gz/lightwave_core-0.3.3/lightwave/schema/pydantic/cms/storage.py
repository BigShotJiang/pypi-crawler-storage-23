"""
Pydantic schemas for Payload CMS Storage and Upload types.

AUTO-GENERATED FROM payload-manifest.json - DO NOT EDIT MANUALLY

Enhanced with LightWave multi-tier storage types for:
- Tier 0 (Hot): Local SSD - active project files
- Tier 1 (Archive): NAS - cold storage for large files
- Tier 2 (CDN): S3 + Cloudflare - public delivery
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class FileBuffer(BaseModel):
    """File with raw buffer data (upload context)."""

    buffer: bytes = Field(description="The raw file data as bytes.")
    client_upload_context: Any | None = Field(
        default=None,
        alias="clientUploadContext",
        description="Client-provided context during upload.",
    )
    filename: str = Field(description="Original filename.")
    filesize: int | float = Field(description="File size in bytes.")
    mime_type: str = Field(alias="mimeType", description="MIME type of the file.")
    temp_file_path: str | None = Field(
        default=None,
        alias="tempFilePath",
        description="Temporary file path during processing.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class File(BaseModel):
    """Payload CMS File type - simplified file reference."""

    data: bytes = Field(description="The buffer of the file.")
    mimetype: str = Field(description="The mimetype of the file.")
    name: str = Field(description="The name of the file.")
    size: int | float = Field(description="The size of the file in bytes.")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FileSize(BaseModel):
    """Payload CMS FileSize type."""

    filename: str
    filesize: int | float
    height: int | float
    mime_type: str = Field(alias="mimeType")
    url: str | None = Field(default=None)
    width: int | float

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FileSizes(BaseModel):
    """
    Payload CMS FileSizes type - container for generated size variants.

    This is a dynamic model where keys are size names (e.g., 'thumbnail', 'card', 'hero')
    and values are FileSize objects with metadata about each variant.
    """

    # Common preset sizes (all optional, custom sizes via extra="allow")
    thumbnail: FileSize | None = Field(default=None, description="Small thumbnail (typically 100-200px).")
    card: FileSize | None = Field(default=None, description="Card preview size (typically 300-400px).")
    hero: FileSize | None = Field(default=None, description="Hero/banner size (typically 1200-1920px).")

    model_config = ConfigDict(
        extra="allow",  # Allow custom size names
        populate_by_name=True,
    )


class FileData(BaseModel):
    """
    Payload CMS FileData type - complete file metadata.

    Contains all metadata about an uploaded file including dimensions,
    focal point for smart cropping, generated sizes, and EXIF data.
    """

    # Core file info
    filename: str = Field(description="Stored filename (may be sanitized from original).")
    filesize: int | float = Field(description="File size in bytes.")
    mime_type: str = Field(alias="mimeType", description="MIME type (e.g., 'image/jpeg').")
    url: str | None = Field(default=None, description="Public URL for the file.")
    temp_file_path: str | None = Field(
        default=None,
        alias="tempFilePath",
        description="Temporary path during upload processing.",
    )

    # Image dimensions
    width: int | float = Field(description="Image width in pixels.")
    height: int | float = Field(description="Image height in pixels.")

    # Focal point (for smart cropping)
    focal_x: int | float | None = Field(
        default=None,
        alias="focalX",
        description="Focal point X coordinate (0-100 percentage from left).",
    )
    focal_y: int | float | None = Field(
        default=None,
        alias="focalY",
        description="Focal point Y coordinate (0-100 percentage from top).",
    )

    # Generated sizes
    sizes: FileSizes | dict[str, FileSize] | None = Field(
        default=None,
        description="Generated image size variants.",
    )

    # Extended metadata (LightWave additions)
    original_filename: str | None = Field(
        default=None,
        alias="originalFilename",
        description="Original filename before sanitization.",
    )
    storage_tier: Literal["hot", "archive", "cdn"] | None = Field(
        default=None,
        alias="storageTier",
        description="Current storage tier.",
    )
    storage_path: str | None = Field(
        default=None,
        alias="storagePath",
        description="Full path in storage backend.",
    )
    checksum: str | None = Field(
        default=None,
        description="File checksum (MD5 or SHA256) for integrity verification.",
    )
    exif: ExifData | None = Field(
        default=None,
        description="Extracted EXIF metadata for images.",
    )
    video_metadata: VideoMetadata | None = Field(
        default=None,
        alias="videoMetadata",
        description="Video-specific metadata (duration, codec, etc.).",
    )
    created_at: str | None = Field(
        default=None,
        alias="createdAt",
        description="ISO 8601 timestamp of upload.",
    )
    updated_at: str | None = Field(
        default=None,
        alias="updatedAt",
        description="ISO 8601 timestamp of last modification.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ExifData(BaseModel):
    """Extracted EXIF metadata from images."""

    # Camera info
    make: str | None = Field(default=None, description="Camera manufacturer.")
    model: str | None = Field(default=None, description="Camera model.")
    lens_model: str | None = Field(default=None, alias="lensModel", description="Lens model.")

    # Capture settings
    exposure_time: str | None = Field(
        default=None,
        alias="exposureTime",
        description="Exposure time (e.g., '1/250').",
    )
    f_number: float | None = Field(
        default=None,
        alias="fNumber",
        description="Aperture f-number (e.g., 2.8).",
    )
    iso: int | None = Field(default=None, description="ISO sensitivity.")
    focal_length: float | None = Field(
        default=None,
        alias="focalLength",
        description="Focal length in mm.",
    )
    focal_length_35mm: float | None = Field(
        default=None,
        alias="focalLength35mm",
        description="35mm equivalent focal length.",
    )

    # Date/time
    date_time_original: str | None = Field(
        default=None,
        alias="dateTimeOriginal",
        description="Original capture date/time.",
    )

    # Location
    gps_latitude: float | None = Field(
        default=None,
        alias="gpsLatitude",
        description="GPS latitude in decimal degrees.",
    )
    gps_longitude: float | None = Field(
        default=None,
        alias="gpsLongitude",
        description="GPS longitude in decimal degrees.",
    )
    gps_altitude: float | None = Field(
        default=None,
        alias="gpsAltitude",
        description="GPS altitude in meters.",
    )

    # Image properties
    orientation: int | None = Field(
        default=None,
        description="EXIF orientation tag (1-8).",
    )
    color_space: str | None = Field(
        default=None,
        alias="colorSpace",
        description="Color space (sRGB, Adobe RGB, etc.).",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class VideoMetadata(BaseModel):
    """Video-specific metadata."""

    duration: float = Field(description="Duration in seconds.")
    codec: str | None = Field(default=None, description="Video codec (e.g., 'h264', 'vp9').")
    audio_codec: str | None = Field(
        default=None,
        alias="audioCodec",
        description="Audio codec (e.g., 'aac', 'opus').",
    )
    bitrate: int | None = Field(default=None, description="Video bitrate in bits per second.")
    framerate: float | None = Field(default=None, description="Frames per second.")
    has_audio: bool | None = Field(
        default=None,
        alias="hasAudio",
        description="Whether video has audio track.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ImageSize(BaseModel):
    """
    Payload CMS ImageSize type - Sharp image resize configuration.

    Used to define responsive image sizes and format conversions.
    Maps to Sharp.js resize options for server-side image processing.
    """

    name: str = Field(description="Unique identifier for this size variant.")
    width: int | None = Field(
        default=None,
        description="Target width in pixels. If only width is set, height is calculated to maintain aspect ratio.",
    )
    height: int | None = Field(
        default=None,
        description="Target height in pixels. If only height is set, width is calculated to maintain aspect ratio.",
    )
    fit: Literal["cover", "contain", "fill", "inside", "outside"] | None = Field(
        default="cover",
        description="How the image should be resized to fit the target dimensions (Sharp fit option).",
    )
    position: (
        Literal[
            "top",
            "right top",
            "right",
            "right bottom",
            "bottom",
            "left bottom",
            "left",
            "left top",
            "center",
            "centre",
            "entropy",
            "attention",
        ]
        | None
    ) = Field(
        default="center",
        description="Position/gravity when cropping (Sharp position option).",
    )
    format_options: ImageFormatOptions | None = Field(
        default=None,
        alias="formatOptions",
        description="Output format and quality settings.",
    )
    crop: ImageCropData | None = Field(
        default=None,
        description="Manual crop region if specified.",
    )
    with_without_enlargement: bool | None = Field(
        default=True,
        alias="withoutEnlargement",
        description="Prevent upscaling smaller images (Sharp withoutEnlargement).",
    )
    background: str | None = Field(
        default=None,
        description="Background color for padding (when fit is 'contain').",
    )
    generate: bool | None = Field(
        default=True,
        description="Whether to generate this size variant.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ImageFormatOptions(BaseModel):
    """Sharp output format options for image conversion."""

    format: Literal["jpeg", "png", "webp", "avif", "gif", "tiff"] | None = Field(
        default=None,
        description="Output format. If not specified, preserves original format.",
    )
    quality: int | None = Field(
        default=80,
        ge=1,
        le=100,
        description="Compression quality (1-100). Higher = better quality, larger file.",
    )
    progressive: bool | None = Field(
        default=True,
        description="Use progressive encoding for JPEG/PNG.",
    )
    lossless: bool | None = Field(
        default=False,
        description="Use lossless compression for WebP/AVIF.",
    )
    effort: int | None = Field(
        default=4,
        ge=0,
        le=10,
        description="Compression effort (0-10). Higher = smaller file, slower encoding.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ImageCropData(BaseModel):
    """Manual crop region data."""

    x: int | float = Field(description="X offset from left edge in pixels.")
    y: int | float = Field(description="Y offset from top edge in pixels.")
    width: int | float = Field(description="Crop region width in pixels.")
    height: int | float = Field(description="Crop region height in pixels.")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Adapter(BaseModel):
    """
    Payload CMS Adapter type - base storage adapter configuration.

    Adapters abstract storage backends (local, S3, GCS, Azure, etc.)
    enabling pluggable storage with consistent interface.
    """

    name: str = Field(description="Unique adapter identifier.")
    type: Literal["local", "s3", "gcs", "azure", "nas", "cdn"] | None = Field(
        default=None,
        description="Storage backend type.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CollectionOptions(BaseModel):
    """Payload CMS CollectionOptions type."""

    adapter: Any
    disable_local_storage: bool | None = Field(default=None, alias="disableLocalStorage")
    disable_payload_access_control: Any | None = Field(default=None, alias="disablePayloadAccessControl")
    generate_file_url: Any | None = Field(default=None, alias="generateFileURL")
    prefix: str | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class GenerateURL(BaseModel):
    """
    URL generation configuration for storage adapters.

    Defines how public URLs are constructed for stored files,
    including CDN prefixes, signed URLs, and expiration.
    """

    prefix: str | None = Field(
        default=None,
        description="URL prefix (e.g., CDN domain or bucket path).",
    )
    expires_in: int | None = Field(
        default=None,
        alias="expiresIn",
        description="Signed URL expiration in seconds (for private storage).",
    )
    use_signed_urls: bool | None = Field(
        default=False,
        alias="useSignedUrls",
        description="Whether to generate signed/presigned URLs.",
    )
    cdn_domain: str | None = Field(
        default=None,
        alias="cdnDomain",
        description="Custom CDN domain to use instead of storage origin.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class HandleUploadArgs(BaseModel):
    """Arguments passed to upload handler functions."""

    file: FileBuffer = Field(description="The file being uploaded.")
    collection: str = Field(description="Collection slug the file belongs to.")
    prefix: str | None = Field(default=None, description="Storage path prefix.")
    filename: str = Field(description="Target filename.")
    mime_type: str = Field(alias="mimeType", description="File MIME type.")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class HandleDeleteArgs(BaseModel):
    """Arguments passed to delete handler functions."""

    filename: str = Field(description="Filename to delete.")
    collection: str = Field(description="Collection slug.")
    prefix: str | None = Field(default=None, description="Storage path prefix.")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class HandleUpload(BaseModel):
    """
    Upload handler result - returned after successful upload.

    Contains the storage path and any adapter-specific metadata.
    """

    path: str = Field(description="Full storage path where file was saved.")
    url: str | None = Field(default=None, description="Public URL if immediately available.")
    storage_tier: Literal["hot", "archive", "cdn"] | None = Field(
        default=None,
        alias="storageTier",
        description="Which storage tier the file was placed in.",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Adapter-specific metadata (e.g., S3 ETag, version ID).",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class HandleDelete(BaseModel):
    """
    Delete handler result - returned after deletion.

    Confirms deletion and provides cleanup information.
    """

    deleted: bool = Field(description="Whether deletion was successful.")
    path: str = Field(description="Path that was deleted.")
    versions_deleted: int | None = Field(
        default=None,
        alias="versionsDeleted",
        description="Number of versions deleted (if versioning enabled).",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class GeneratedAdapter(BaseModel):
    """
    Payload CMS GeneratedAdapter type - full storage adapter interface.

    This is the complete adapter configuration that Payload uses internally.
    It defines how files are uploaded, deleted, and served for a collection.

    LightWave uses this pattern for multi-tier storage:
    - Tier 0 (hot): Local SSD adapter for active files
    - Tier 1 (archive): NAS adapter for cold storage
    - Tier 2 (cdn): S3 + Cloudflare adapter for public delivery
    """

    name: str = Field(description="Unique adapter name (e.g., 'local', 's3-cdn', 'nas-archive').")
    client_uploads: bool | ClientUploadConfig | None = Field(
        default=None,
        alias="clientUploads",
        description="Enable direct client-to-storage uploads (bypassing server).",
    )
    fields: list[Any] | None = Field(
        default=None,
        description="Additional fields to inject into collection schema.",
    )
    generate_url: GenerateURL | None = Field(
        default=None,
        alias="generateURL",
        description="URL generation configuration.",
    )
    handle_delete: str | None = Field(
        default=None,
        alias="handleDelete",
        description="Handler function identifier for deletion.",
    )
    handle_upload: str | None = Field(
        default=None,
        alias="handleUpload",
        description="Handler function identifier for uploads.",
    )
    on_init: str | None = Field(
        default=None,
        alias="onInit",
        description="Initialization hook function identifier.",
    )
    static_handler: str | None = Field(
        default=None,
        alias="staticHandler",
        description="Static file serving handler identifier.",
    )
    storage_tier: Literal["hot", "archive", "cdn"] | None = Field(
        default=None,
        alias="storageTier",
        description="LightWave storage tier this adapter serves.",
    )
    max_file_size: int | None = Field(
        default=None,
        alias="maxFileSize",
        description="Maximum file size in bytes for this adapter.",
    )
    allowed_mime_types: list[str] | None = Field(
        default=None,
        alias="allowedMimeTypes",
        description="Allowed MIME types (e.g., ['image/*', 'video/*']).",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ClientUploadConfig(BaseModel):
    """Configuration for direct client-to-storage uploads."""

    enabled: bool = Field(default=True, description="Whether client uploads are enabled.")
    max_file_size: int | None = Field(
        default=None,
        alias="maxFileSize",
        description="Maximum file size for client uploads.",
    )
    presigned_url_expiry: int | None = Field(
        default=3600,
        alias="presignedUrlExpiry",
        description="Presigned URL expiry in seconds.",
    )
    allowed_origins: list[str] | None = Field(
        default=None,
        alias="allowedOrigins",
        description="CORS allowed origins for uploads.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class PluginOptions(BaseModel):
    """Payload CMS PluginOptions type."""

    always_insert_fields: bool | None = Field(
        default=False,
        alias="alwaysInsertFields",
        description="When enabled, fields (like the prefix field) will always be inserted into the collection schema r...",
    )
    collections: dict[str, Any]
    enabled: bool | None = Field(default=None, description="Whether or not to enable the plugin  Default: true")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class StaticHandler(BaseModel):
    """
    Static file serving handler configuration.

    Defines how static files are served - either directly from storage,
    via a CDN, or through a custom handler with access control.
    """

    type: Literal["direct", "cdn", "proxy", "custom"] | None = Field(
        default="direct",
        description="Handler type: direct from storage, CDN redirect, or proxy through server.",
    )
    cache_control: str | None = Field(
        default=None,
        alias="cacheControl",
        description="Cache-Control header value (e.g., 'public, max-age=31536000').",
    )
    content_disposition: Literal["inline", "attachment"] | None = Field(
        default="inline",
        alias="contentDisposition",
        description="Content-Disposition header for downloads.",
    )
    require_auth: bool | None = Field(
        default=False,
        alias="requireAuth",
        description="Whether authentication is required to access files.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


# =============================================================================
# LightWave Multi-Tier Storage Types
# =============================================================================


class StorageTierConfig(BaseModel):
    """
    Configuration for a single storage tier in the LightWave media pipeline.

    LightWave uses a 3-tier storage architecture:
    - Tier 0 (Hot): Local SSD - active project files, ~1ms access
    - Tier 1 (Archive): NAS via SMB/Bonjour - cold storage for large files
    - Tier 2 (CDN): S3 + Cloudflare - public delivery only
    """

    tier: Literal["hot", "archive", "cdn"] = Field(description="Storage tier identifier.")
    name: str = Field(description="Human-readable tier name.")
    adapter: str = Field(description="Adapter identifier (e.g., 'local', 'smb', 's3').")
    path_prefix: str | None = Field(
        default=None,
        alias="pathPrefix",
        description="Path prefix for files in this tier.",
    )
    max_file_size: int | None = Field(
        default=None,
        alias="maxFileSize",
        description="Maximum file size in bytes for this tier.",
    )
    allowed_mime_types: list[str] | None = Field(
        default=None,
        alias="allowedMimeTypes",
        description="Allowed MIME types (e.g., ['image/*', 'video/*']).",
    )
    auto_migrate_after_days: int | None = Field(
        default=None,
        alias="autoMigrateAfterDays",
        description="Automatically migrate to next tier after N days of inactivity.",
    )
    is_public: bool = Field(
        default=False,
        alias="isPublic",
        description="Whether files in this tier are publicly accessible.",
    )
    generate_sizes: bool = Field(
        default=True,
        alias="generateSizes",
        description="Whether to generate size variants for images.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class LocalSSDConfig(StorageTierConfig):
    """
    Tier 0 (Hot) - Local SSD storage configuration.

    For active project files with fastest access times.
    """

    tier: Literal["hot"] = "hot"
    adapter: Literal["local"] = "local"
    base_path: str = Field(
        alias="basePath",
        description="Absolute path to storage directory on local SSD.",
    )
    disk_usage_warning_threshold: float = Field(
        default=0.8,
        alias="diskUsageWarningThreshold",
        description="Warn when disk usage exceeds this percentage (0-1).",
    )
    disk_usage_critical_threshold: float = Field(
        default=0.95,
        alias="diskUsageCriticalThreshold",
        description="Block uploads when disk usage exceeds this percentage.",
    )


class NASArchiveConfig(StorageTierConfig):
    """
    Tier 1 (Archive) - NAS storage configuration.

    Personal archive via SMB/Bonjour for cold storage of large files.
    """

    tier: Literal["archive"] = "archive"
    adapter: Literal["smb"] = "smb"
    nas_host: str = Field(
        alias="nasHost",
        description="NAS hostname or IP (supports Bonjour .local names).",
    )
    share_name: str = Field(
        alias="shareName",
        description="SMB share name.",
    )
    username: str | None = Field(
        default=None,
        description="SMB username (if authentication required).",
    )
    mount_point: str | None = Field(
        default=None,
        alias="mountPoint",
        description="Local mount point for NAS share.",
    )
    connection_timeout: int = Field(
        default=30,
        alias="connectionTimeout",
        description="Connection timeout in seconds.",
    )


class CDNConfig(StorageTierConfig):
    """
    Tier 2 (CDN) - S3 + Cloudflare storage configuration.

    Public delivery only via cdn.lightwave-media.ltd
    """

    tier: Literal["cdn"] = "cdn"
    adapter: Literal["s3"] = "s3"
    is_public: bool = True
    bucket: str = Field(description="S3 bucket name.")
    region: str = Field(description="AWS region.")
    cloudflare_zone_id: str | None = Field(
        default=None,
        alias="cloudflareZoneId",
        description="Cloudflare zone ID for cache purging.",
    )
    cdn_domain: str = Field(
        alias="cdnDomain",
        description="CDN domain (e.g., 'cdn.lightwave-media.ltd').",
    )
    cache_ttl: int = Field(
        default=31536000,
        alias="cacheTtl",
        description="Cache TTL in seconds (default: 1 year).",
    )
    use_signed_urls: bool = Field(
        default=False,
        alias="useSignedUrls",
        description="Use signed URLs for private content.",
    )
    signed_url_expiry: int = Field(
        default=3600,
        alias="signedUrlExpiry",
        description="Signed URL expiry in seconds.",
    )


class MultiTierStorageConfig(BaseModel):
    """
    Complete multi-tier storage configuration.

    Defines all storage tiers and migration policies.
    """

    tiers: list[StorageTierConfig] = Field(description="Storage tier configurations in priority order.")
    default_tier: Literal["hot", "archive", "cdn"] = Field(
        default="hot",
        alias="defaultTier",
        description="Default tier for new uploads.",
    )
    enable_auto_migration: bool = Field(
        default=True,
        alias="enableAutoMigration",
        description="Enable automatic migration between tiers.",
    )
    migration_check_interval: int = Field(
        default=86400,
        alias="migrationCheckInterval",
        description="How often to check for files to migrate (seconds).",
    )
    preserve_hot_copy: bool = Field(
        default=False,
        alias="preserveHotCopy",
        description="Keep a copy in hot tier when migrating to archive.",
    )
    cdn_on_first_public_access: bool = Field(
        default=True,
        alias="cdnOnFirstPublicAccess",
        description="Automatically push to CDN when file is first accessed publicly.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class MediaAsset(BaseModel):
    """
    Complete media asset record with multi-tier storage tracking.

    This is the Django model schema for tracking files across storage tiers.
    """

    id: str = Field(description="Unique asset identifier (UUID).")
    file_data: FileData = Field(
        alias="fileData",
        description="Complete file metadata.",
    )
    current_tier: Literal["hot", "archive", "cdn"] = Field(
        alias="currentTier",
        description="Current primary storage tier.",
    )
    tier_locations: dict[str, str] = Field(
        default_factory=dict,
        alias="tierLocations",
        description="Map of tier to storage path for each copy.",
    )
    cdn_url: str | None = Field(
        default=None,
        alias="cdnUrl",
        description="Public CDN URL if published.",
    )
    access_count: int = Field(
        default=0,
        alias="accessCount",
        description="Number of times asset has been accessed.",
    )
    last_accessed_at: str | None = Field(
        default=None,
        alias="lastAccessedAt",
        description="ISO 8601 timestamp of last access.",
    )
    migrated_at: str | None = Field(
        default=None,
        alias="migratedAt",
        description="ISO 8601 timestamp of last tier migration.",
    )
    is_archived: bool = Field(
        default=False,
        alias="isArchived",
        description="Whether asset is in archive tier.",
    )
    is_published: bool = Field(
        default=False,
        alias="isPublished",
        description="Whether asset is published to CDN.",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )
