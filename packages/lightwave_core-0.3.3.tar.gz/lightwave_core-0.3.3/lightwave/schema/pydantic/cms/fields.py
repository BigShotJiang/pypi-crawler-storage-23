"""
Pydantic schemas for Payload CMS Field types.

AUTO-GENERATED FROM payload-manifest.json - DO NOT EDIT MANUALLY
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class FieldBase(BaseModel):
    """Payload CMS FieldBase type."""

    sanitized: bool | None = Field(
        default=None,
        alias="_sanitized",
        description="Do not set this property manually. This is set to true during sanitization, to avoid sanitizing t...",
    )
    access: Any | None = Field(default=None)
    admin: Any | None = Field(default=None)
    custom: Any | None = Field(default=None, description="Extension point to add your custom data. Server only.")
    default_value: str | int | float | bool | dict[str, Any] | None = Field(default=None, alias="defaultValue")
    hidden: bool | None = Field(default=None)
    hooks: Any | None = Field(default=None)
    index: bool | None = Field(default=None)
    label: str | bool | Any | None = Field(default=None)
    localized: bool | None = Field(default=None)
    name: str = Field(
        description="The name of the field. Must be alphanumeric and cannot contain ' . '  Must not be one of reserved..."
    )
    required: bool | None = Field(default=None)
    save_to_jwt: str | bool | None = Field(default=None, alias="saveToJWT")
    typescript_schema: list[Any] | None = Field(
        default=None,
        alias="typescriptSchema",
        description="Allows you to modify the base JSON schema that is generated during generate:types for this field....",
    )
    unique: bool | None = Field(default=None)
    validate_: Any | None = Field(default=None, alias="validate")
    virtual: str | bool | None = Field(
        default=None,
        description="Pass `true` to disable field in the DB for [Virtual Fields](https://payloadcms.com/blog/learn-how...",
    )

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FieldAdmin(BaseModel):
    """Payload CMS FieldAdmin type."""

    class_name: str | None = Field(default=None, alias="className")
    components: Any | None = Field(default=None)
    condition: Any | None = Field(
        default=None,
        description="You can programmatically show / hide fields based on what other fields are doing. This is also ru...",
    )
    custom: dict[str, Any] | None = Field(
        default=None, description="Extension point to add your custom data. Available in server and client."
    )
    description: str | Any | None = Field(
        default=None,
        description="The field description will be displayed next to the field in the admin UI. Additionally, we use t...",
    )
    disable_bulk_edit: bool | None = Field(default=None, alias="disableBulkEdit")
    disable_group_by: bool | None = Field(
        default=None,
        alias="disableGroupBy",
        description="Shows / hides fields from appearing in the list view groupBy options.",
    )
    disable_list_column: bool | None = Field(
        default=None,
        alias="disableListColumn",
        description="Shows / hides fields from appearing in the list view column selector.",
    )
    disable_list_filter: bool | None = Field(
        default=None,
        alias="disableListFilter",
        description="Shows / hides fields from appearing in the list view filter options.",
    )
    disabled: bool | None = Field(default=None)
    hidden: bool | None = Field(default=None)
    position: Literal["sidebar"] | None = Field(default=None)
    read_only: bool | None = Field(default=None, alias="readOnly")
    style: Any | None = Field(default=None)
    width: Any | None = Field(default=None)

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Block(BaseModel):
    """Payload CMS Block type."""

    sanitized: bool | None = Field(
        default=None,
        alias="_sanitized",
        description="Do not set this property manually. This is set to true during sanitization, to avoid sanitizing t...",
    )
    admin: Any | None = Field(default=None)
    custom: dict[str, Any] | None = Field(
        default=None, description="Extension point to add your custom data. Server only."
    )
    db_name: str | Any | None = Field(default=None, alias="dbName", description="Customize the SQL table name")
    fields: list[Any]
    graph_ql: Any | None = Field(default=None, alias="graphQL")
    image_alt_text: str | None = Field(default=None, alias="imageAltText")
    image_url: str | None = Field(
        default=None, alias="imageURL", description="Preferred aspect ratio of the image is 3 : 2"
    )
    interface_name: str | None = Field(
        default=None,
        alias="interfaceName",
        description="Customize generated GraphQL and Typescript schema names. The slug is used by default.  This is us...",
    )
    jsx: Any | None = Field(default=None)
    labels: Any | None = Field(default=None)
    slug: str

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ArrayField(BaseModel):
    """Payload CMS ArrayField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class BlocksField(BaseModel):
    """Payload CMS BlocksField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CheckboxField(BaseModel):
    """Payload CMS CheckboxField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class ClientField(BaseModel):
    """Payload CMS ClientField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CodeField(BaseModel):
    """Payload CMS CodeField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class CollapsibleField(BaseModel):
    """Payload CMS CollapsibleField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class DateField(BaseModel):
    """Payload CMS DateField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class EmailField(BaseModel):
    """Payload CMS EmailField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class Field(BaseModel):
    """Payload CMS Field type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedArrayField(BaseModel):
    """Payload CMS FlattenedArrayField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedBlocksField(BaseModel):
    """Payload CMS FlattenedBlocksField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedField(BaseModel):
    """Payload CMS FlattenedField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedGroupField(BaseModel):
    """Payload CMS FlattenedGroupField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedJoinField(BaseModel):
    """Payload CMS FlattenedJoinField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class FlattenedTabAsField(BaseModel):
    """Payload CMS FlattenedTabAsField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class GroupField(BaseModel):
    """Payload CMS GroupField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class JSONField(BaseModel):
    """Payload CMS JSONField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class JoinField(BaseModel):
    """A virtual field that loads in related collections by querying a relationship or upload field."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class NamedGroupField(BaseModel):
    """Payload CMS NamedGroupField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class NonPresentationalField(BaseModel):
    """Payload CMS NonPresentationalField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class NumberField(BaseModel):
    """Payload CMS NumberField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class PointField(BaseModel):
    """Payload CMS PointField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class PolymorphicRelationshipField(BaseModel):
    """Payload CMS PolymorphicRelationshipField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class PolymorphicUploadField(BaseModel):
    """Payload CMS PolymorphicUploadField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class RadioField(BaseModel):
    """Payload CMS RadioField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class RelationshipField(BaseModel):
    """Payload CMS RelationshipField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class RichTextField(BaseModel):
    """Payload CMS RichTextField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class RowField(BaseModel):
    """Payload CMS RowField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SelectField(BaseModel):
    """Payload CMS SelectField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SingleRelationshipField(BaseModel):
    """Payload CMS SingleRelationshipField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class SingleUploadField(BaseModel):
    """Payload CMS SingleUploadField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class TabAsField(BaseModel):
    """Payload CMS TabAsField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class TabsField(BaseModel):
    """Payload CMS TabsField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class TextField(BaseModel):
    """Payload CMS TextField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class TextareaField(BaseModel):
    """Payload CMS TextareaField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class UIField(BaseModel):
    """Payload CMS UIField type."""

    admin: dict[str, Any] | None = Field(default=None)
    custom: dict[str, Any] | None = Field(
        default=None, description="Extension point to add your custom data. Server only."
    )
    label: str | Any | None = Field(default=None)
    name: str
    type_: Any = Field(alias="type")

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class UnnamedGroupField(BaseModel):
    """Payload CMS UnnamedGroupField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )


class UploadField(BaseModel):
    """Payload CMS UploadField type."""

    pass

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
    )
