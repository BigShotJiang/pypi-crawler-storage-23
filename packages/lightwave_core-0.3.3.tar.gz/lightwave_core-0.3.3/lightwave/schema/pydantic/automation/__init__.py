"""
Automation schemas - Script definitions and registry.

Derived from: definitions/automation/scripts/schema.yaml
"""

from lightwave.schema.pydantic.automation.scripts import (
    CLIArgument,
    CLIFlag,
    ScriptBehavior,
    ScriptCLI,
    ScriptDefinition,
    ScriptDomain,
    ScriptImplementation,
    ScriptOperation,
    ScriptRegistry,
)

__all__ = [
    "ScriptDefinition",
    "ScriptRegistry",
    "ScriptOperation",
    "ScriptDomain",
    "ScriptBehavior",
    "ScriptCLI",
    "ScriptImplementation",
    "CLIArgument",
    "CLIFlag",
]
