"""
WebSocket message Pydantic schemas.

These schemas provide type-safe message validation for all WebSocket
channels including AI chat, notifications, sync, presence, and collaboration.

Modules:
- base: Base message classes and common types
- chat: AI chat messages
- sync: PowerSync/realtime sync messages
- notifications: Real-time notifications
- presence: User presence and typing indicators
- collaboration: Real-time collaborative editing
- config: WebSocket configuration from websockets.yaml

Usage:
    from lightwave.schema.pydantic.contracts.websockets import (
        # Base
        WSMessage, WSErrorMessage,
        # Chat
        ChatMessageInbound, ChatResponseOutbound, ChatStreamOutbound,
        # Sync
        SyncUpdateOutbound, SyncConflictOutbound,
        # Notifications
        NotificationNewOutbound,
        # Presence
        PresenceUpdateInbound, UserJoinedOutbound,
    )

    # Parse incoming message
    raw = json.loads(websocket_data)
    if raw["type"] == "chat.message":
        msg = ChatMessageInbound.model_validate(raw)
        process_chat_message(msg)

    # Create outgoing message
    response = ChatResponseOutbound(
        content="Hello!",
        conversation_id="...",
        message_id="...",
    )
    await websocket.send(response.model_dump_json())
"""

from lightwave.schema.pydantic.contracts.websockets.base import (
    MessageDirection,
    WSAckMessage,
    WSChannel,
    WSEnvelope,
    WSErrorCode,
    WSErrorMessage,
    WSMessage,
    WSMessageType,
)
from lightwave.schema.pydantic.contracts.websockets.chat import (
    ChatCompleteOutbound,
    ChatErrorOutbound,
    ChatFeedbackInbound,
    ChatMessageInbound,
    ChatResponseOutbound,
    ChatStopInbound,
    ChatStreamOutbound,
    ChatTypingMessage,
)
from lightwave.schema.pydantic.contracts.websockets.collaboration import (
    CollabConflictOutbound,
    CollabCursorMessage,
    CollabLockDeniedOutbound,
    CollabLockGrantedOutbound,
    CollabLockRequestInbound,
    CollabOperationMessage,
    CollabSelectionMessage,
    CollabUnlockInbound,
)
from lightwave.schema.pydantic.contracts.websockets.config import (
    ChannelConfig,
    ConnectionConfig,
    MessageTypeConfig,
    WebSocketsConfigSchema,
)
from lightwave.schema.pydantic.contracts.websockets.notifications import (
    NotificationAckInbound,
    NotificationBatchOutbound,
    NotificationDismissInbound,
    NotificationMarkReadInbound,
    NotificationNewOutbound,
    NotificationPriority,
    NotificationType,
    NotificationUpdateOutbound,
)
from lightwave.schema.pydantic.contracts.websockets.presence import (
    PresenceAwayInbound,
    PresenceRosterOutbound,
    PresenceStatus,
    PresenceSubscribeInbound,
    PresenceTypingInbound,
    PresenceUpdateInbound,
    TypingContext,
    UserAwayOutbound,
    UserJoinedOutbound,
    UserLeftOutbound,
    UserTypingOutbound,
)
from lightwave.schema.pydantic.contracts.websockets.sync import (
    SyncAckInbound,
    SyncBatchOutbound,
    SyncCheckpointAckOutbound,
    SyncCheckpointInbound,
    SyncConflictOutbound,
    SyncConflictResolution,
    SyncDeleteOutbound,
    SyncOperation,
    SyncSubscribeInbound,
    SyncUnsubscribeInbound,
    SyncUpdateOutbound,
)
from lightwave.schema.pydantic.contracts.websockets.system import (
    SystemBroadcastOutbound,
    SystemHealthOutbound,
    SystemMaintenanceOutbound,
    SystemPingInbound,
    SystemPongOutbound,
    SystemSubscribeInbound,
)

__all__ = [
    # Base
    "MessageDirection",
    "WSAckMessage",
    "WSChannel",
    "WSEnvelope",
    "WSErrorCode",
    "WSErrorMessage",
    "WSMessage",
    "WSMessageType",
    # Config
    "ChannelConfig",
    "ConnectionConfig",
    "MessageTypeConfig",
    "WebSocketsConfigSchema",
    # Chat
    "ChatCompleteOutbound",
    "ChatErrorOutbound",
    "ChatFeedbackInbound",
    "ChatMessageInbound",
    "ChatResponseOutbound",
    "ChatStopInbound",
    "ChatStreamOutbound",
    "ChatTypingMessage",
    # Notifications
    "NotificationAckInbound",
    "NotificationBatchOutbound",
    "NotificationDismissInbound",
    "NotificationMarkReadInbound",
    "NotificationNewOutbound",
    "NotificationPriority",
    "NotificationType",
    "NotificationUpdateOutbound",
    # Sync
    "SyncAckInbound",
    "SyncBatchOutbound",
    "SyncCheckpointAckOutbound",
    "SyncCheckpointInbound",
    "SyncConflictOutbound",
    "SyncConflictResolution",
    "SyncDeleteOutbound",
    "SyncOperation",
    "SyncSubscribeInbound",
    "SyncUnsubscribeInbound",
    "SyncUpdateOutbound",
    # Presence
    "PresenceAwayInbound",
    "PresenceRosterOutbound",
    "PresenceStatus",
    "PresenceSubscribeInbound",
    "PresenceTypingInbound",
    "PresenceUpdateInbound",
    "TypingContext",
    "UserAwayOutbound",
    "UserJoinedOutbound",
    "UserLeftOutbound",
    "UserTypingOutbound",
    # Collaboration
    "CollabConflictOutbound",
    "CollabCursorMessage",
    "CollabLockDeniedOutbound",
    "CollabLockGrantedOutbound",
    "CollabLockRequestInbound",
    "CollabOperationMessage",
    "CollabSelectionMessage",
    "CollabUnlockInbound",
    # System
    "SystemBroadcastOutbound",
    "SystemHealthOutbound",
    "SystemMaintenanceOutbound",
    "SystemPingInbound",
    "SystemPongOutbound",
    "SystemSubscribeInbound",
]
