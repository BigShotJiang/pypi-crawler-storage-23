"""
Middleware configuration schemas.

This package provides typed Pydantic models for Django middleware configuration
loaded from middleware.yaml SST definition.

Usage:
    from lightwave.schema.pydantic.contracts.middleware import MiddlewareConfig, get_middleware_config

    config = get_middleware_config()
    stack = config.get_middleware_stack()
    print(f"Middleware stack has {len(stack)} entries")

    # Get Django MIDDLEWARE setting
    MIDDLEWARE = config.get_middleware_paths("production")
"""

from lightwave.schema.pydantic.contracts.middleware.middleware import (
    # Auth middleware
    APIAuthConfig,
    AuthMiddlewareConfig,
    # Rate limit middleware
    ClientIdentificationConfig,
    CrossTenantAuthConfig,
    # Security middleware
    CSPOverride,
    # Environment config
    DebugToolbarConfig,
    # Tenant middleware
    DomainMatchingConfig,
    EnvironmentConfig,
    EnvironmentCORSConfig,
    # Literal types
    EnvironmentName,
    EnvironmentRateLimitConfig,
    # Health checks
    HealthChecksConfig,
    HTTPSConfig,
    # Logging middleware
    LoggingMiddlewareConfig,
    LogLevel,
    # Main config
    MiddlewareConfig,
    MiddlewareConfigMeta,
    MiddlewarePhase,
    # Middleware stack
    MiddlewareStackEntry,
    OrderValidationConfig,
    PerformanceMonitoringConfig,
    RateLimitBackendConfig,
    RateLimitBackendType,
    RateLimitExemptionsConfig,
    RateLimitMiddlewareConfig,
    RateLimitResponseConfig,
    RequestValidationConfig,
    ResolutionStrategy,
    SecurityMiddlewareConfig,
    SSOConfig,
    StartupChecksConfig,
    TenantContextConfig,
    TenantErrorConfig,
    TenantMiddlewareConfig,
    TenantRateLimitOverride,
    TenantResolutionConfig,
    TenantSchemaConfig,
    UnknownDomainAction,
    # Convenience function
    get_middleware_config,
)

__all__ = [
    # Literal types
    "EnvironmentName",
    "LogLevel",
    "MiddlewarePhase",
    "RateLimitBackendType",
    "ResolutionStrategy",
    "UnknownDomainAction",
    # Middleware stack
    "MiddlewareStackEntry",
    # Tenant middleware
    "DomainMatchingConfig",
    "TenantContextConfig",
    "TenantErrorConfig",
    "TenantMiddlewareConfig",
    "TenantResolutionConfig",
    "TenantSchemaConfig",
    # Security middleware
    "CSPOverride",
    "HTTPSConfig",
    "RequestValidationConfig",
    "SecurityMiddlewareConfig",
    # Rate limit middleware
    "ClientIdentificationConfig",
    "RateLimitBackendConfig",
    "RateLimitExemptionsConfig",
    "RateLimitMiddlewareConfig",
    "RateLimitResponseConfig",
    "TenantRateLimitOverride",
    # Auth middleware
    "APIAuthConfig",
    "AuthMiddlewareConfig",
    "CrossTenantAuthConfig",
    "SSOConfig",
    # Logging middleware
    "LoggingMiddlewareConfig",
    # Environment config
    "DebugToolbarConfig",
    "EnvironmentConfig",
    "EnvironmentCORSConfig",
    "EnvironmentRateLimitConfig",
    # Health checks
    "HealthChecksConfig",
    "OrderValidationConfig",
    "PerformanceMonitoringConfig",
    "StartupChecksConfig",
    # Main config
    "MiddlewareConfig",
    "MiddlewareConfigMeta",
    # Convenience function
    "get_middleware_config",
]
