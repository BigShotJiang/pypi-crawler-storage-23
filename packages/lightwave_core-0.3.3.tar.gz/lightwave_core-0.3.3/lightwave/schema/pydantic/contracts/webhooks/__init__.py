"""
Webhook payload Pydantic schemas.

These schemas validate incoming webhook payloads from external services
like QuickBooks Online and Stripe. They ensure type safety for webhook
handlers and provide structured access to payload data.

Modules:
- quickbooks: QBO data change notifications
- stripe: Stripe payment events

Usage:
    from lightwave.schema.pydantic.contracts.webhooks import (
        QBOWebhookPayload,
        StripeEventSchema,
    )

    @router.post("/webhooks/qbo/")
    def handle_qbo_webhook(request):
        payload = QBOWebhookPayload.model_validate_json(request.body)
        for notification in payload.event_notifications:
            process_qbo_notification(notification)

    @router.post("/webhooks/stripe/")
    def handle_stripe_webhook(request):
        event = StripeEventSchema.model_validate_json(request.body)
        if event.type == "checkout.session.completed":
            handle_checkout_complete(event)
"""

from lightwave.schema.pydantic.contracts.webhooks.quickbooks import (
    QBODataChangeEvent,
    QBOEntityChange,
    QBOEventNotification,
    QBOWebhookPayload,
)
from lightwave.schema.pydantic.contracts.webhooks.stripe import (
    StripeCheckoutSession,
    StripeCustomer,
    StripeEventSchema,
    StripeInvoice,
    StripePaymentIntent,
    StripeSubscription,
)

__all__ = [
    # QuickBooks
    "QBODataChangeEvent",
    "QBOEntityChange",
    "QBOEventNotification",
    "QBOWebhookPayload",
    # Stripe
    "StripeCheckoutSession",
    "StripeCustomer",
    "StripeEventSchema",
    "StripeInvoice",
    "StripePaymentIntent",
    "StripeSubscription",
]
