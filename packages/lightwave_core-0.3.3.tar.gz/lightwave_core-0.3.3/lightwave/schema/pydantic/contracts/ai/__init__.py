"""
AI Contract Schemas for Agent Orchestration.

This module provides typed contracts for communication between the Elixir
orchestrator and Django agents. All requests and responses are validated
against these schemas.

Usage:
    from lightwave.schema.pydantic.contracts.ai import (
        AgentRequest,
        AgentResponse,
        StreamEvent,
        AgentError,
    )

    # Validate incoming request
    request = AgentRequest(**request_data)

    # Create response
    response = AgentResponse(
        request_id=request.request_id,
        agent_type=request.agent_type,
        status="success",
        response="Here is my response...",
    )
"""

from .agent_error import (
    AgentError,
    ErrorCategory,
    ErrorCode,
)
from .agent_request import (
    AgentContext,
    AgentRequest,
    AgentType,
    HandoffContext,
    HistoryMessage,
    MessageRole,
    RequestPriority,
)
from .agent_response import (
    AgentResponse,
    ResponseStatus,
    ToolCallRecord,
    ToolCallStatus,
    UsageStats,
)
from .stream_event import (
    ChunkData,
    EndData,
    ErrorData,
    EventType,
    HandoffData,
    ProgressData,
    StartData,
    StatusData,
    StreamEvent,
    StreamStatus,
    ToolCallEndData,
    ToolCallStartData,
)

__all__ = [
    # Request
    "AgentRequest",
    "AgentType",
    "AgentContext",
    "HistoryMessage",
    "HandoffContext",
    "MessageRole",
    "RequestPriority",
    # Response
    "AgentResponse",
    "ResponseStatus",
    "ToolCallRecord",
    "ToolCallStatus",
    "UsageStats",
    # Stream
    "StreamEvent",
    "EventType",
    "StreamStatus",
    "ChunkData",
    "StatusData",
    "ToolCallStartData",
    "ToolCallEndData",
    "HandoffData",
    "ProgressData",
    "ErrorData",
    "StartData",
    "EndData",
    # Error
    "AgentError",
    "ErrorCode",
    "ErrorCategory",
]
