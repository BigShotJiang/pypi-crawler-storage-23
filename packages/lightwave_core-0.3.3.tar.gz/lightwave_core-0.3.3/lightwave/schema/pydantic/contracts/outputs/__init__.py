"""
Output Contract Schemas for vWrite/vSpeak.

This module provides typed contracts for the vWrite/vSpeak output system.
vWrite produces written, documented output; vSpeak produces conversational.

Usage:
    from lightwave.schema.pydantic.contracts.outputs import (
        VWriteOutput,
        VSpeakOutput,
        ToneModel,
        OutputFormat,
        OutputMode,
        get_platform_defaults,
    )

    # Create formatted output
    output = VWriteOutput(
        content="Report content...",
        tone="lightwave_authentic",
        format="markdown",
        agent_type="v_accountant",
    )
"""

from .v_output import (
    PLATFORM_DEFAULTS,
    TONE_CHARACTERISTICS,
    FormatOutputRequest,
    FormatOutputResponse,
    OutputFormat,
    OutputMetadata,
    OutputMode,
    Platform,
    PlatformDefaults,
    ToneCharacteristics,
    ToneModel,
    VSpeakOutput,
    VWriteOutput,
    get_platform_defaults,
)

__all__ = [
    # Types
    "OutputMode",
    "ToneModel",
    "OutputFormat",
    "Platform",
    # Models
    "ToneCharacteristics",
    "OutputMetadata",
    "VWriteOutput",
    "VSpeakOutput",
    "PlatformDefaults",
    # Request/Response
    "FormatOutputRequest",
    "FormatOutputResponse",
    # Data
    "TONE_CHARACTERISTICS",
    "PLATFORM_DEFAULTS",
    # Functions
    "get_platform_defaults",
]
