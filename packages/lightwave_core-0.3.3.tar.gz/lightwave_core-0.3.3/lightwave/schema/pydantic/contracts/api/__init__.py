"""
API request/response Pydantic schemas.

These schemas provide type-safe request and response validation
for all API endpoints. They extend the base schemas in base.py.

Modules:
- common: Universal schemas (pagination, webhooks, bulk operations)
- accounting: QuickBooks connection and sync schemas
- platform: Platform info, UI config, feature flags
- emails: Email template and rendering schemas
- auth: Authentication and token verification schemas

Usage:
    from lightwave.schema.pydantic.contracts.api import (
        PaginationParams,
        WebhookResponse,
        QBOConnectionSchema,
        PlatformInfoResponse,
        EmailRenderResponse,
        TokenVerifyResponse,
    )

    # In django-ninja view
    @router.get("/connections/", response=list[QBOConnectionSchema])
    def list_connections(request, pagination: PaginationParams = Query(...)):
        ...
"""

from lightwave.schema.pydantic.contracts.api.accounting import (
    QBOConnectionListResponse,
    QBOConnectionSchema,
    QBOEntitySyncRequest,
    QBOSyncResponse,
    QBOSyncStatus,
)
from lightwave.schema.pydantic.contracts.api.auth import (
    TokenVerifyError,
    TokenVerifyResponse,
)
from lightwave.schema.pydantic.contracts.api.common import (
    BulkOperationResponse,
    HealthCheckResponse,
    PaginationParams,
    WebhookResponse,
)
from lightwave.schema.pydantic.contracts.api.emails import (
    EmailRenderRequest,
    EmailRenderResponse,
    EmailSendRequest,
    EmailSendResponse,
    EmailTemplateListResponse,
    EmailTemplateSchema,
)
from lightwave.schema.pydantic.contracts.api.platform import (
    FeatureFlagSchema,
    PlatformInfoResponse,
    TenantInfoResponse,
    UIConfigResponse,
)

# Re-export base schemas for convenience
from lightwave.schema.pydantic.core.base import (
    ErrorDetail,
    ErrorResponse,
    PaginatedResponse,
)

__all__ = [
    # Base (re-exported)
    "ErrorDetail",
    "ErrorResponse",
    "PaginatedResponse",
    # Common
    "BulkOperationResponse",
    "HealthCheckResponse",
    "PaginationParams",
    "WebhookResponse",
    # Accounting
    "QBOConnectionListResponse",
    "QBOConnectionSchema",
    "QBOEntitySyncRequest",
    "QBOSyncResponse",
    "QBOSyncStatus",
    # Platform
    "FeatureFlagSchema",
    "PlatformInfoResponse",
    "TenantInfoResponse",
    "UIConfigResponse",
    # Emails
    "EmailRenderRequest",
    "EmailRenderResponse",
    "EmailSendRequest",
    "EmailSendResponse",
    "EmailTemplateListResponse",
    "EmailTemplateSchema",
    # Auth
    "TokenVerifyError",
    "TokenVerifyResponse",
]
