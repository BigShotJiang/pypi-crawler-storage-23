"""
Platform API schemas.

These schemas provide type-safe structures for platform-level
information, tenant configuration, and UI settings.

Usage:
    from lightwave.schema.pydantic.contracts.api.platform import (
        PlatformInfoResponse,
        TenantInfoResponse,
        UIConfigResponse,
    )

    @router.get("/platform/info/", response=PlatformInfoResponse)
    def get_platform_info(request):
        return PlatformInfoResponse(
            platform="lightwave",
            version=settings.VERSION,
            ...
        )
"""

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import (
    APIResponseSchema,
    LightwaveBaseSchema,
)

# =============================================================================
# Feature Flags
# =============================================================================


class FeatureFlagSchema(LightwaveBaseSchema):
    """
    Feature flag configuration.

    Defines whether a feature is enabled and any associated configuration.
    """

    name: str = Field(..., description="Feature flag identifier")
    enabled: bool = Field(..., description="Whether feature is enabled")
    rollout_percentage: int = Field(100, ge=0, le=100, description="Percentage of users with feature")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Feature-specific configuration")


# =============================================================================
# Platform Info
# =============================================================================


class PlatformInfoResponse(APIResponseSchema):
    """
    Platform information response.

    Provides version, environment, and capability information.
    Used by clients to determine available features.

    Example response:
        {
            "platform": "lightwave",
            "version": "1.2.3",
            "environment": "production",
            "api_version": "v1",
            "features": {
                "qbo_integration": true,
                "ai_assistant": true,
                "powerSync": false
            }
        }
    """

    id: int | None = None  # Override
    created_at: datetime | None = None  # Override
    updated_at: datetime | None = None  # Override

    platform: str = Field("lightwave", description="Platform identifier")
    version: str = Field(..., description="Platform version")
    environment: Literal["development", "staging", "production"] = Field(..., description="Deployment environment")
    api_version: str = Field("v1", description="Current API version")
    features: dict[str, bool] = Field(default_factory=dict, description="Feature availability map")
    supported_locales: list[str] = Field(default_factory=lambda: ["en"], description="Supported locales")
    maintenance_mode: bool = Field(False, description="Whether platform is in maintenance")
    maintenance_message: str | None = Field(None, description="Maintenance message")


# =============================================================================
# Tenant Info
# =============================================================================


class TenantInfoResponse(APIResponseSchema):
    """
    Tenant (site) information response.

    Provides tenant-specific configuration including branding,
    enabled features, and settings.

    Example response:
        {
            "tenant_id": "cineos",
            "display_name": "cineOS",
            "domain": "cineos.io",
            "features": {...},
            "branding": {...}
        }
    """

    id: int | None = None  # Override
    created_at: datetime | None = None  # Override
    updated_at: datetime | None = None  # Override

    tenant_id: str = Field(..., description="Tenant identifier (slug)")
    display_name: str = Field(..., description="Tenant display name")
    domain: str = Field(..., description="Primary domain")
    domains: list[str] = Field(default_factory=list, description="All associated domains")
    features: dict[str, bool] = Field(default_factory=dict, description="Tenant-specific feature flags")
    branding: dict[str, Any] = Field(default_factory=dict, description="Branding configuration")
    timezone: str = Field("UTC", description="Default timezone")
    locale: str = Field("en", description="Default locale")


# =============================================================================
# UI Configuration
# =============================================================================


class NavItemConfigSchema(LightwaveBaseSchema):
    """
    Navigation item for UI rendering.

    Represents a single navigation item with label, path, and optional icon.
    """

    label: str = Field(..., description="Display label")
    path: str = Field(..., description="Navigation path")
    icon: str | None = Field(None, description="Icon identifier")
    badge: str | None = Field(None, description="Optional badge text")
    is_external: bool = Field(False, description="Opens in new tab")
    children: list["NavItemConfigSchema"] = Field(default_factory=list, description="Nested items")
    permissions: list[str] = Field(default_factory=list, description="Required permissions")


class ThemeConfigSchema(LightwaveBaseSchema):
    """
    Theme configuration for UI.

    Provides color tokens and theme settings for the frontend.
    """

    mode: Literal["light", "dark", "system"] = Field("system", description="Theme mode")
    primary_color: str = Field("#3B82F6", description="Primary brand color")
    accent_color: str = Field("#8B5CF6", description="Accent color")
    background_color: str = Field("#FFFFFF", description="Background color")
    text_color: str = Field("#1F2937", description="Primary text color")
    custom_css: str | None = Field(None, description="Custom CSS overrides")


class UIConfigResponse(APIResponseSchema):
    """
    UI configuration response.

    Provides all configuration needed to render the UI including
    navigation, theme, and feature flags.

    Example response:
        {
            "navigation": [...],
            "theme": {...},
            "feature_flags": [...],
            "user_preferences": {...}
        }
    """

    id: int | None = None  # Override
    created_at: datetime | None = None  # Override
    updated_at: datetime | None = None  # Override

    navigation: list[NavItemConfigSchema] = Field(default_factory=list, description="Navigation structure")
    theme: ThemeConfigSchema = Field(default_factory=ThemeConfigSchema, description="Theme settings")
    feature_flags: list[FeatureFlagSchema] = Field(default_factory=list, description="Active feature flags")
    user_preferences: dict[str, Any] = Field(default_factory=dict, description="User-specific preferences")
    sidebar_collapsed: bool = Field(False, description="Sidebar default state")
    show_breadcrumbs: bool = Field(True, description="Show breadcrumb navigation")
    default_page_size: int = Field(20, description="Default pagination size")
