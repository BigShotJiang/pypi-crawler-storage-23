"""Django app configuration for the schema module."""

from django.apps import AppConfig


class SchemaConfig(AppConfig):
    """Configuration for the lightwave.schema Django app."""

    name = "lightwave.schema"
    label = "lightwave_schema"
    verbose_name = "LightWave Schema"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        """Initialize the schema module when Django starts."""
        # Pre-load schema definitions for faster access
        # This is optional but improves performance
        pass
