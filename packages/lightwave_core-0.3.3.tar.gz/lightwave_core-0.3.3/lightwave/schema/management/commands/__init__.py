"""Schema management commands for Django."""
