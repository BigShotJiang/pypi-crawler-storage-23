"""
Data Quality module for LightWave.

This module provides tools for:
- Computing QualityDelta between ideal and actual data states
- Persisting KnowledgeGraph edges to Django KnowledgeLink model
- Computing weight scores based on graph connectivity
- Generating coaching advice from data quality gaps
- Unified coaching combining QualityDelta and V-Emergence insights

Usage:
    from lightwave.data_quality import (
        # Quality computation
        compute_task_quality,
        compute_sprint_quality,
        compute_document_quality,
        # Knowledge graph
        batch_edges_to_links,
        compute_node_weight,
        # Unified coaching
        CoachingEngine,
        generate_unified_coaching,
        generate_sprint_coaching,
    )
"""

from lightwave.data_quality.coaching import (
    CoachingCategory,
    CoachingEngine,
    CoachingReport,
    CoachingUrgency,
    UnifiedCoachingAdvice,
    generate_sprint_coaching,
    generate_unified_coaching,
)
from lightwave.data_quality.emergence_service import (
    EmergenceService,
    discover_edges,
    discover_patterns,
    entities_to_nodes,
    run_emergence_cycle,
)
from lightwave.data_quality.knowledge_graph import (
    EDGE_TO_LINK_TYPE_MAP,
    EdgeType,
    KnowledgeEdge,
    KnowledgeEdgeLike,
    KnowledgeGraphConfig,
    KnowledgeLinkDTO,
    KnowledgeNode,
    KnowledgeNodeLike,
    LinkType,
    batch_edges_to_links,
    compute_node_weight,
    deduplicate_links,
    edge_to_link_dto,
    find_high_weight_nodes,
    map_edge_to_link_type,
    parse_node_id,
    persist_links_to_django,
)
from lightwave.data_quality.quality_service import (
    batch_compute_quality,
    compute_document_quality,
    compute_sprint_quality,
    compute_task_quality,
    generate_batch_coaching,
    get_unhealthy_entities,
)
from lightwave.schema.pydantic.models.knowledge_graph import (
    EmergencePattern,
    EmergenceResult,
)

__all__ = [
    # Typed Schemas (SST-driven)
    "KnowledgeNode",
    "KnowledgeEdge",
    "KnowledgeGraphConfig",
    "EmergencePattern",
    "EmergenceResult",
    # Protocols (backwards compatibility)
    "KnowledgeNodeLike",
    "KnowledgeEdgeLike",
    # Knowledge Graph Persistence
    "KnowledgeLinkDTO",
    "LinkType",
    "EdgeType",
    "EDGE_TO_LINK_TYPE_MAP",
    "parse_node_id",
    "map_edge_to_link_type",
    "edge_to_link_dto",
    "batch_edges_to_links",
    "deduplicate_links",
    "compute_node_weight",
    "find_high_weight_nodes",
    "persist_links_to_django",
    # Emergence Discovery
    "EmergenceService",
    "run_emergence_cycle",
    "entities_to_nodes",
    "discover_edges",
    "discover_patterns",
    # Quality Service
    "compute_task_quality",
    "compute_sprint_quality",
    "compute_document_quality",
    "batch_compute_quality",
    "get_unhealthy_entities",
    "generate_batch_coaching",
    # Unified Coaching
    "CoachingCategory",
    "CoachingUrgency",
    "UnifiedCoachingAdvice",
    "CoachingReport",
    "CoachingEngine",
    "generate_unified_coaching",
    "generate_sprint_coaching",
]
