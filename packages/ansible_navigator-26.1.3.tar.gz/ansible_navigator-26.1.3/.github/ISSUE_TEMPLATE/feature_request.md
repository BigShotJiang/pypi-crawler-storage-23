---
name: "✨ Feature request"
about: Suggest an idea for this project
labels: enhancement, new
---

<!-- Issues are for **concrete, actionable bugs and feature requests** only - if you're just asking for debugging help or technical support, please use:

TODO: Add ansible-navigator specific channels

We have to limit this because of limited volunteer time to respond to issues! -->

##### ISSUE TYPE

- Feature Idea

##### SUMMARY

<!-- Briefly describe the problem or desired enhancement. -->
