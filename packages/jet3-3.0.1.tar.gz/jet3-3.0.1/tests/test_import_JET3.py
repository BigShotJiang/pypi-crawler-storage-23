def test_import_JET3():
    import JET3
