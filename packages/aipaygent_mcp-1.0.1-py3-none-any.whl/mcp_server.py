"""
AiPayGent MCP Server

Exposes all 37 AiPayGent endpoints as MCP tools so any MCP-compatible
client (Claude Desktop, Cursor, etc.) can call them without x402 payment.
Run with: python mcp_server.py
"""

import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from mcp.server.fastmcp import FastMCP
from app import (
    research_inner, summarize_inner, analyze_inner, translate_inner,
    social_inner, write_inner, code_inner, extract_inner, qa_inner,
    classify_inner, sentiment_inner, keywords_inner, compare_inner,
    transform_inner, chat_inner, plan_inner, decide_inner, proofread_inner,
    explain_inner, questions_inner, outline_inner, email_inner, sql_inner,
    regex_inner, mock_inner, score_inner, timeline_inner, action_inner,
    pitch_inner, debate_inner, headline_inner, fact_inner, rewrite_inner,
    tag_inner, pipeline_inner, BATCH_HANDLERS,
)

mcp = FastMCP(
    "AiPayGent",
    instructions=(
        "AiPayGent provides 36 Claude-powered AI tools: research, write, code, translate, "
        "analyze, summarize, score, debate, pitch, headline, fact-check, rewrite, tag, "
        "timeline, action items, pipeline chaining, and more. All tools call Claude directly."
    ),
    host="127.0.0.1",
    port=5002,
)


@mcp.tool()
def research(topic: str) -> dict:
    """Research a topic. Returns structured summary, key points, and sources to check."""
    return research_inner(topic)


@mcp.tool()
def summarize(text: str, length: str = "short") -> dict:
    """Summarize long text. length: short | medium | detailed"""
    return summarize_inner(text, length)


@mcp.tool()
def analyze(content: str, question: str = "Provide a structured analysis") -> dict:
    """Deep structured analysis of content. Returns conclusion, findings, sentiment, confidence."""
    return analyze_inner(content, question)


@mcp.tool()
def translate(text: str, language: str = "Spanish") -> dict:
    """Translate text to any language."""
    return translate_inner(text, language)


@mcp.tool()
def social(topic: str, platforms: list[str] = None, tone: str = "engaging") -> dict:
    """Generate platform-optimized social media posts for Twitter, LinkedIn, Instagram, etc."""
    return social_inner(topic, platforms or ["twitter", "linkedin", "instagram"], tone)


@mcp.tool()
def write(spec: str, type: str = "article") -> dict:
    """Write articles, copy, or content to your specification. type: article | post | copy"""
    return write_inner(spec, type)


@mcp.tool()
def code(description: str, language: str = "Python") -> dict:
    """Generate production-ready code in any language from a plain-English description."""
    return code_inner(description, language)


@mcp.tool()
def extract(text: str, fields: list[str] = None, schema: str = "") -> dict:
    """Extract structured data from unstructured text. Define fields or a schema."""
    return extract_inner(text, schema, fields or [])


@mcp.tool()
def qa(context: str, question: str) -> dict:
    """Q&A over a document. Returns answer, confidence score, and source quote."""
    return qa_inner(context, question)


@mcp.tool()
def classify(text: str, categories: list[str]) -> dict:
    """Classify text into your defined categories with per-category confidence scores."""
    return classify_inner(text, categories)


@mcp.tool()
def sentiment(text: str) -> dict:
    """Deep sentiment analysis: polarity, score, emotions, confidence, key phrases."""
    return sentiment_inner(text)


@mcp.tool()
def keywords(text: str, max_keywords: int = 10) -> dict:
    """Extract keywords, topics, and tags from any text."""
    return keywords_inner(text, max_keywords)


@mcp.tool()
def compare(text_a: str, text_b: str, focus: str = "") -> dict:
    """Compare two texts: similarities, differences, similarity score, recommendation."""
    return compare_inner(text_a, text_b, focus)


@mcp.tool()
def transform(text: str, instruction: str) -> dict:
    """Transform text with any instruction: rewrite, reformat, expand, condense, change tone."""
    return transform_inner(text, instruction)


@mcp.tool()
def chat(messages: list[dict], system: str = "") -> dict:
    """Stateless multi-turn chat. Send full message history, get Claude reply."""
    return chat_inner(messages, system)


@mcp.tool()
def plan(goal: str, context: str = "", steps: int = 7) -> dict:
    """Step-by-step action plan for any goal with effort estimate and first action."""
    return plan_inner(goal, context, steps)


@mcp.tool()
def decide(decision: str, options: list[str] = None, criteria: str = "") -> dict:
    """Decision framework: pros, cons, risks, recommendation, and confidence score."""
    return decide_inner(decision, options, criteria)


@mcp.tool()
def proofread(text: str, style: str = "professional") -> dict:
    """Grammar and clarity corrections with tracked changes and writing quality score."""
    return proofread_inner(text, style)


@mcp.tool()
def explain(concept: str, level: str = "beginner", analogy: bool = True) -> dict:
    """Explain any concept at beginner, intermediate, or expert level with analogy."""
    return explain_inner(concept, level, analogy)


@mcp.tool()
def questions(content: str, type: str = "faq", count: int = 5) -> dict:
    """Generate questions + answers from any content. type: faq | interview | quiz | comprehension"""
    return questions_inner(content, type, count)


@mcp.tool()
def outline(topic: str, depth: int = 2, sections: int = 6) -> dict:
    """Generate a hierarchical outline with headings, summaries, and subsections."""
    return outline_inner(topic, depth, sections)


@mcp.tool()
def email(purpose: str, tone: str = "professional", context: str = "", recipient: str = "", length: str = "medium") -> dict:
    """Compose a professional email. Returns subject line and body."""
    return email_inner(purpose, tone, context, recipient, length)


@mcp.tool()
def sql(description: str, dialect: str = "postgresql", schema: str = "") -> dict:
    """Natural language to SQL. Returns query, explanation, and notes."""
    return sql_inner(description, dialect, schema)


@mcp.tool()
def regex(description: str, language: str = "python", flags: str = "") -> dict:
    """Generate a regex pattern from a plain-English description with examples."""
    return regex_inner(description, language, flags)


@mcp.tool()
def mock(description: str, count: int = 5, format: str = "json") -> dict:
    """Generate realistic mock data records. format: json | csv | list"""
    return mock_inner(description, min(count, 50), format)


@mcp.tool()
def score(content: str, criteria: list[str] = None, scale: int = 10) -> dict:
    """Score content on a custom rubric. Returns per-criterion scores, strengths, and weaknesses."""
    return score_inner(content, criteria or ["clarity", "accuracy", "engagement"], scale)


@mcp.tool()
def timeline(text: str, direction: str = "chronological") -> dict:
    """Extract or reconstruct a timeline from text. Returns dated events with significance."""
    return timeline_inner(text, direction)


@mcp.tool()
def action(text: str) -> dict:
    """Extract action items, tasks, owners, and due dates from meeting notes or any text."""
    return action_inner(text)


@mcp.tool()
def pitch(product: str, audience: str = "general", length: str = "30s") -> dict:
    """Generate an elevator pitch: hook, value prop, call to action, full script. length: 15s | 30s | 60s"""
    return pitch_inner(product, audience, length)


@mcp.tool()
def debate(topic: str, perspective: str = "balanced") -> dict:
    """Arguments for and against any position with strength ratings and verdict."""
    return debate_inner(topic, perspective)


@mcp.tool()
def headline(content: str, count: int = 5, style: str = "engaging") -> dict:
    """Generate headline variations with type labels and a best pick."""
    return headline_inner(content, count, style)


@mcp.tool()
def fact(text: str, count: int = 10) -> dict:
    """Extract factual claims with verifiability scores and source hints."""
    return fact_inner(text, count)


@mcp.tool()
def rewrite(text: str, audience: str = "general audience", tone: str = "neutral") -> dict:
    """Rewrite text for a specific audience, reading level, or brand voice."""
    return rewrite_inner(text, audience, tone)


@mcp.tool()
def tag(text: str, taxonomy: list[str] = None, max_tags: int = 10) -> dict:
    """Auto-tag content using a taxonomy or free-form. Returns tags, primary tag, categories."""
    return tag_inner(text, taxonomy, max_tags)


@mcp.tool()
def pipeline(steps: list[dict]) -> dict:
    """
    Chain up to 5 operations sequentially. Each step can reference the previous
    output using the string '{{prev}}' as a field value in its input.

    Example steps:
    [
      {"endpoint": "research", "input": {"topic": "quantum computing"}},
      {"endpoint": "summarize", "input": {"text": "{{prev}}", "length": "short"}},
      {"endpoint": "headline", "input": {"content": "{{prev}}", "count": 3}}
    ]
    """
    return pipeline_inner(steps)


@mcp.tool()
def batch(operations: list[dict]) -> dict:
    """
    Run up to 5 independent operations in one call.

    Each operation: {"endpoint": "research", "input": {"topic": "AI"}}
    Valid endpoints: research, summarize, analyze, translate, social, write, code,
    extract, qa, classify, sentiment, keywords, compare, transform, chat, plan,
    decide, proofread, explain, questions, outline, email, sql, regex, mock,
    score, timeline, action, pitch, debate, headline, fact, rewrite, tag
    """
    if not operations or not isinstance(operations, list):
        return {"error": "operations array required"}
    if len(operations) > 5:
        return {"error": "max 5 operations per batch"}
    results = []
    for op in operations:
        endpoint = op.get("endpoint", "").lstrip("/")
        inp = op.get("input", {})
        handler = BATCH_HANDLERS.get(endpoint)
        if not handler:
            results.append({"endpoint": endpoint, "error": f"unknown endpoint '{endpoint}'"})
        else:
            try:
                results.append({"endpoint": endpoint, **handler(inp)})
            except Exception as e:
                results.append({"endpoint": endpoint, "error": str(e)})
    return {"results": results, "count": len(results)}


def main():
    import sys
    if "--http" in sys.argv:
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
