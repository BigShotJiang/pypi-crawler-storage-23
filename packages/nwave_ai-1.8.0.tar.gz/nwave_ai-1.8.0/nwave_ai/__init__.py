"""nwave-ai: CLI installer for the nWave methodology framework."""

__version__ = "1.8.0"
