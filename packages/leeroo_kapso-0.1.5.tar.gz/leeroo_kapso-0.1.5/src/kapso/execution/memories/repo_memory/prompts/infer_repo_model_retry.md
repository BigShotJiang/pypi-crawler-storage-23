# This prompt is deprecated.
# Line-number-based evidence does not require validation or retry.
# The infer_repo_model_initial.md prompt is used directly.
