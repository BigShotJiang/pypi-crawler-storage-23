"""PQC key lifecycle management."""

import base64
from typing import Optional

from qpher.http_client import _HttpClient
from qpher.types import KeyInfo, KeyListResult, RotateResult, GenerateResult, RetireResult


class KeysModule:
    """PQC key lifecycle management."""

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def generate(self, algorithm: str) -> GenerateResult:
        """Generate a new PQC key pair.

        Args:
            algorithm: "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".

        Returns:
            GenerateResult with version, status, and public key.

        Raises:
            ValidationError: If algorithm is invalid.
        """
        resp = self._http.post(
            "/api/v1/kms/keys/generate", json={"algorithm": algorithm}
        )
        data = resp["data"]
        return GenerateResult(
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            status=data["status"],
            public_key=base64.b64decode(data["public_key"]),
            created_at=data["created_at"],
            request_id=resp["request_id"],
        )

    def rotate(self, algorithm: str) -> RotateResult:
        """Rotate to a new key version. The old active key becomes retired.

        Args:
            algorithm: "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".

        Returns:
            RotateResult with new key info and old key version.

        Raises:
            ValidationError: If algorithm is invalid.
            NotFoundError: If no active key exists to rotate.
        """
        resp = self._http.post(
            "/api/v1/kms/keys/rotate", json={"algorithm": algorithm}
        )
        data = resp["data"]
        return RotateResult(
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            public_key=base64.b64decode(data["public_key"]),
            old_key_version=data["old_key_version"],
            request_id=resp["request_id"],
        )

    def get_active(self, algorithm: str) -> KeyInfo:
        """Get the currently active key for an algorithm.

        Args:
            algorithm: "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".

        Returns:
            KeyInfo for the active key.

        Raises:
            ValidationError: If algorithm is invalid.
            NotFoundError: If no active key exists.
        """
        resp = self._http.get(
            "/api/v1/kms/keys/active", params={"algorithm": algorithm}
        )
        return self._parse_key_info(resp["data"])

    def get(self, algorithm: str, key_version: int) -> KeyInfo:
        """Get a specific key version.

        Args:
            algorithm: "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".
            key_version: Version number to retrieve.

        Returns:
            KeyInfo for the specified version.

        Raises:
            ValidationError: If algorithm is invalid.
            NotFoundError: If key version not found.
        """
        resp = self._http.get(
            f"/api/v1/kms/keys/{key_version}",
            params={"algorithm": algorithm},
        )
        return self._parse_key_info(resp["data"])

    def list(
        self,
        algorithm: Optional[str] = None,
        status: Optional[str] = None,
    ) -> KeyListResult:
        """List all PQC keys, optionally filtered.

        Args:
            algorithm: Filter by "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".
            status: Filter by "active", "retired", or "archived".

        Returns:
            KeyListResult with list of keys and total count.
        """
        params = {}
        if algorithm:
            params["algorithm"] = algorithm
        if status:
            params["status"] = status

        resp = self._http.get("/api/v1/kms/keys", params=params if params else None)
        data = resp["data"]
        keys = [self._parse_key_info(k) for k in data["keys"]]
        return KeyListResult(
            keys=keys, total=data["total"], request_id=resp["request_id"]
        )

    def retire(self, algorithm: str, key_version: int) -> RetireResult:
        """Retire a key. Retired keys can decrypt/verify but not encrypt/sign.

        Args:
            algorithm: "Kyber768", "Dilithium3", "X-Wing", or "Composite-ML-DSA".
            key_version: Version to retire.

        Returns:
            RetireResult with updated status.

        Raises:
            ValidationError: If algorithm is invalid.
            NotFoundError: If key version not found.
        """
        resp = self._http.post(
            "/api/v1/kms/keys/retire",
            json={"algorithm": algorithm, "key_version": key_version},
        )
        data = resp["data"]
        return RetireResult(
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            status=data["status"],
            public_key=base64.b64decode(data["public_key"]),
            created_at=data["created_at"],
            request_id=resp["request_id"],
        )

    @staticmethod
    def _parse_key_info(data: dict) -> KeyInfo:
        return KeyInfo(
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            status=data["status"],
            public_key=base64.b64decode(data["public_key"]),
            created_at=data["created_at"],
        )
