"""Key management commands."""

from __future__ import annotations

import click

from qpher.cli.config import load_config
from qpher.cli.errors import require_auth, api_error_handler
from qpher.cli.output import print_table, print_json, print_success
from qpher.cli._api import CliApiClient


@click.group("keys")
def keys_group() -> None:
    """Manage PQC encryption keys."""


@keys_group.command("list")
@click.option(
    "--algorithm", "-a", type=click.Choice(["Kyber768", "Dilithium3"]),
    help="Filter by algorithm",
)
@click.option(
    "--format", "out_format", default="table", type=click.Choice(["table", "json"]),
    help="Output format",
)
@require_auth
@api_error_handler
def list_keys(algorithm: str | None, out_format: str) -> None:
    """List all PQC keys."""
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.list_keys(algorithm)

    keys = result.get("keys", [])

    if out_format == "json":
        print_json(result)
        return

    headers = ["VERSION", "ALGORITHM", "STATUS", "CREATED"]
    rows = []
    for key in keys:
        rows.append([
            str(key.get("key_version", "")),
            key.get("algorithm", ""),
            key.get("status", ""),
            key.get("created_at", "")[:10] if key.get("created_at") else "",
        ])

    click.echo()
    print_table(headers, rows)
    click.echo()
    click.echo(f"  Total: {result.get('total', len(keys))} keys", err=True)


@keys_group.command("generate")
@click.option(
    "--algorithm", "-a", required=True, type=click.Choice(["Kyber768", "Dilithium3"]),
    help="Algorithm for the new key",
)
@require_auth
@api_error_handler
def generate_key(algorithm: str) -> None:
    """Generate a new PQC keypair."""
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.generate_key(algorithm)

    version = result.get("key_version", "?")
    pub_key = result.get("public_key", "")
    preview = pub_key[:32] + "..." if len(pub_key) > 32 else pub_key

    print_success(f"Generated {algorithm} key (version {version})")
    click.echo(f"  Public key: {preview}")


@keys_group.command("rotate")
@click.option(
    "--algorithm", "-a", required=True, type=click.Choice(["Kyber768", "Dilithium3"]),
    help="Algorithm to rotate",
)
@require_auth
@api_error_handler
def rotate_key(algorithm: str) -> None:
    """Rotate key (retire current, generate new)."""
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.rotate_key(algorithm)

    new_version = result.get("key_version", "?")
    old_version = result.get("old_key_version", "?")

    print_success(f"Rotated {algorithm}: v{old_version} (retired) \u2192 v{new_version} (active)")


@keys_group.command("retire")
@click.option(
    "--algorithm", "-a", required=True, type=click.Choice(["Kyber768", "Dilithium3"]),
    help="Algorithm of the key",
)
@click.option("--version", "-v", "key_version", required=True, type=int, help="Key version")
@click.confirmation_option(prompt="Are you sure you want to retire this key?")
@require_auth
@api_error_handler
def retire_key(algorithm: str, key_version: int) -> None:
    """Retire a specific key version."""
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    client.retire_key(algorithm, key_version)

    print_success(f"Retired {algorithm} key version {key_version}")
