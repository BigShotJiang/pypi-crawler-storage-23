"""Sign and verify commands."""

from __future__ import annotations

import base64
import sys
from pathlib import Path

import click

from qpher.cli.config import load_config
from qpher.cli.errors import require_auth, api_error_handler
from qpher.cli.output import print_success
from qpher.cli._api import CliApiClient

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


@click.command("sign")
@click.option("--text", "-t", help="Message to sign")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="File to sign")
@click.option("--key-version", "-k", required=True, type=int, help="PQC key version")
@click.option("--output", "-o", type=click.Path(), help="Output file for signature")
@require_auth
@api_error_handler
def sign_cmd(
    text: str | None,
    file_path: str | None,
    key_version: int,
    output: str | None,
) -> None:
    """Sign data using Dilithium3.

    Provide either --text or --file (not both).
    """
    if text and file_path:
        raise click.ClickException("Provide either --text or --file, not both.")
    if not text and not file_path:
        raise click.ClickException("Provide --text or --file.")

    # Read input
    if text:
        message_bytes = text.encode("utf-8")
    else:
        path = Path(file_path)  # type: ignore[arg-type]
        if path.stat().st_size > MAX_FILE_SIZE:
            raise click.ClickException(
                f"File too large ({path.stat().st_size / 1024 / 1024:.1f} MB). "
                f"Maximum is {MAX_FILE_SIZE / 1024 / 1024:.0f} MB."
            )
        message_bytes = path.read_bytes()

    message_b64 = base64.b64encode(message_bytes).decode("ascii")

    # Call API via SDK
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.sign(message_b64, key_version)

    signature = result["signature"]

    # Output
    if output:
        Path(output).write_text(signature)
        print_success(f"Signature written to {output}")
    elif file_path:
        out_path = file_path + ".sig"
        Path(out_path).write_text(signature)
        print_success(f"Signature written to {out_path}")
    else:
        click.echo(signature)

    click.echo(
        f"  algorithm: {result.get('algorithm', 'Dilithium3')}, "
        f"key_version: {result.get('key_version', key_version)}",
        err=True,
    )


@click.command("verify")
@click.option("--text", "-t", help="Original message")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="Original file")
@click.option("--signature", "-s", help="Base64 signature")
@click.option(
    "--signature-file", type=click.Path(exists=True), help="Signature file",
)
@click.option("--key-version", "-k", required=True, type=int, help="PQC key version")
@require_auth
@api_error_handler
def verify_cmd(
    text: str | None,
    file_path: str | None,
    signature: str | None,
    signature_file: str | None,
    key_version: int,
) -> None:
    """Verify a Dilithium3 signature.

    Returns exit code 0 if valid, 1 if invalid.
    """
    # Validate message input
    if text and file_path:
        raise click.ClickException("Provide either --text or --file, not both.")
    if not text and not file_path:
        raise click.ClickException("Provide --text or --file.")

    # Validate signature input
    if signature and signature_file:
        raise click.ClickException("Provide either --signature or --signature-file, not both.")
    if not signature and not signature_file:
        raise click.ClickException("Provide --signature or --signature-file.")

    # Read message
    if text:
        message_bytes = text.encode("utf-8")
    else:
        message_bytes = Path(file_path).read_bytes()  # type: ignore[arg-type]

    # Read signature
    if signature_file:
        signature = Path(signature_file).read_text().strip()

    message_b64 = base64.b64encode(message_bytes).decode("ascii")

    # Call API via SDK
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.verify(message_b64, signature, key_version)  # type: ignore[arg-type]

    is_valid = result.get("valid", False)

    if is_valid:
        click.echo(click.style("Signature valid \u2713", fg="green"))
        sys.exit(0)
    else:
        click.echo(click.style("Signature INVALID \u2717", fg="red"))
        sys.exit(1)
