"""Qpher CLI — Post-Quantum Cryptography from the command line."""

from __future__ import annotations

import click

from qpher._version import __version__
from qpher.cli.auth import auth_group
from qpher.cli.encrypt import encrypt_cmd, decrypt_cmd
from qpher.cli.sign import sign_cmd, verify_cmd
from qpher.cli.keys import keys_group
from qpher.cli.status import status_cmd


@click.group()
@click.version_option(version=__version__, prog_name="qpher")
def cli() -> None:
    """Qpher — Post-Quantum Cryptography CLI.

    Encrypt, sign, and manage PQC keys from the terminal.

    Get started:

      qpher auth set-key <your-api-key>

      qpher encrypt --text "Hello" --key-version 1

      qpher keys list
    """


cli.add_command(auth_group)
cli.add_command(encrypt_cmd)
cli.add_command(decrypt_cmd)
cli.add_command(sign_cmd)
cli.add_command(verify_cmd)
cli.add_command(keys_group)
cli.add_command(status_cmd)
