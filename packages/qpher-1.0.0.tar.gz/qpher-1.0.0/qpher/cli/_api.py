"""CLI-specific API client wrapping SDK's _HttpClient."""

from __future__ import annotations

from typing import Any, Optional

from qpher.http_client import _HttpClient


class CliApiClient:
    """Thin wrapper around SDK's _HttpClient for CLI use.

    Returns raw dicts from API responses (unwraps the {"data": ...} envelope).
    Inherits retries, auth, and error handling from the SDK's HTTP client.
    """

    def __init__(self, api_key: str, base_url: str = "https://api.qpher.ai") -> None:
        self._http = _HttpClient(
            api_key=api_key,
            base_url=base_url.rstrip("/"),
            timeout=30,
            max_retries=3,
        )

    def _unwrap(self, resp: dict[str, Any]) -> dict[str, Any]:
        return resp.get("data", resp)

    # --- KEM operations ---

    def encrypt(
        self,
        plaintext_b64: str,
        key_version: int,
        mode: str = "standard",
        salt: Optional[str] = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "plaintext": plaintext_b64,
            "key_version": key_version,
            "mode": mode,
        }
        if salt is not None:
            payload["salt"] = salt
        return self._unwrap(self._http.post("/api/v1/kem/encrypt", json=payload))

    def decrypt(self, ciphertext_b64: str, key_version: int) -> dict[str, Any]:
        return self._unwrap(
            self._http.post(
                "/api/v1/kem/decrypt",
                json={"ciphertext": ciphertext_b64, "key_version": key_version},
            )
        )

    # --- Signature operations ---

    def sign(self, message_b64: str, key_version: int) -> dict[str, Any]:
        return self._unwrap(
            self._http.post(
                "/api/v1/signature/sign",
                json={"message": message_b64, "key_version": key_version},
            )
        )

    def verify(
        self, message_b64: str, signature_b64: str, key_version: int
    ) -> dict[str, Any]:
        return self._unwrap(
            self._http.post(
                "/api/v1/signature/verify",
                json={
                    "message": message_b64,
                    "signature": signature_b64,
                    "key_version": key_version,
                },
            )
        )

    # --- Key management ---

    def list_keys(self, algorithm: Optional[str] = None) -> dict[str, Any]:
        params = {"algorithm": algorithm} if algorithm else None
        return self._unwrap(self._http.get("/api/v1/kms/keys", params=params))

    def generate_key(self, algorithm: str) -> dict[str, Any]:
        return self._unwrap(
            self._http.post("/api/v1/kms/keys/generate", json={"algorithm": algorithm})
        )

    def rotate_key(self, algorithm: str) -> dict[str, Any]:
        return self._unwrap(
            self._http.post("/api/v1/kms/keys/rotate", json={"algorithm": algorithm})
        )

    def retire_key(self, algorithm: str, key_version: int) -> dict[str, Any]:
        return self._unwrap(
            self._http.post(
                "/api/v1/kms/keys/retire",
                json={"algorithm": algorithm, "key_version": key_version},
            )
        )

    # --- Account ---

    def get_status(self) -> dict[str, Any]:
        return self._unwrap(self._http.get("/api/v1/tenants/me"))
