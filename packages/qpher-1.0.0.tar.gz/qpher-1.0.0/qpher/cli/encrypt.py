"""Encrypt and decrypt commands."""

from __future__ import annotations

import base64
from pathlib import Path

import click

from qpher.cli.config import load_config
from qpher.cli.errors import require_auth, api_error_handler
from qpher.cli.output import print_success
from qpher.cli._api import CliApiClient

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


@click.command("encrypt")
@click.option("--text", "-t", help="Text to encrypt")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="File to encrypt")
@click.option("--key-version", "-k", required=True, type=int, help="PQC key version to use")
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option(
    "--mode", default="standard", type=click.Choice(["standard", "deterministic"]),
    help="Encryption mode",
)
@click.option("--salt", help="Salt for deterministic mode")
@require_auth
@api_error_handler
def encrypt_cmd(
    text: str | None,
    file_path: str | None,
    key_version: int,
    output: str | None,
    mode: str,
    salt: str | None,
) -> None:
    """Encrypt data using Kyber768 KEM.

    Provide either --text or --file (not both).
    """
    # Validate input
    if text and file_path:
        raise click.ClickException("Provide either --text or --file, not both.")
    if not text and not file_path:
        raise click.ClickException("Provide --text or --file.")
    if mode == "deterministic" and not salt:
        raise click.ClickException("--salt is required for deterministic mode.")

    # Read input
    if text:
        plaintext_bytes = text.encode("utf-8")
    else:
        path = Path(file_path)  # type: ignore[arg-type]
        if path.stat().st_size > MAX_FILE_SIZE:
            raise click.ClickException(
                f"File too large ({path.stat().st_size / 1024 / 1024:.1f} MB). "
                f"Maximum is {MAX_FILE_SIZE / 1024 / 1024:.0f} MB."
            )
        plaintext_bytes = path.read_bytes()

    plaintext_b64 = base64.b64encode(plaintext_bytes).decode("ascii")

    # Call API via SDK
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.encrypt(plaintext_b64, key_version, mode, salt)

    ciphertext = result["ciphertext"]

    # Output
    if output:
        Path(output).write_text(ciphertext)
        print_success(f"Encrypted output written to {output}")
    elif file_path:
        out_path = file_path + ".enc"
        Path(out_path).write_text(ciphertext)
        print_success(f"Encrypted output written to {out_path}")
    else:
        click.echo(ciphertext)

    # Metadata to stderr
    click.echo(
        f"  algorithm: {result.get('algorithm', 'Kyber768')}, "
        f"key_version: {result.get('key_version', key_version)}",
        err=True,
    )


@click.command("decrypt")
@click.option("--text", "-t", help="Base64 ciphertext to decrypt")
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="File to decrypt")
@click.option("--key-version", "-k", required=True, type=int, help="PQC key version")
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@require_auth
@api_error_handler
def decrypt_cmd(
    text: str | None,
    file_path: str | None,
    key_version: int,
    output: str | None,
) -> None:
    """Decrypt data using Kyber768 KEM.

    Provide either --text or --file (not both).
    """
    if text and file_path:
        raise click.ClickException("Provide either --text or --file, not both.")
    if not text and not file_path:
        raise click.ClickException("Provide --text or --file.")

    # Read ciphertext
    if text:
        ciphertext_b64 = text
    else:
        ciphertext_b64 = Path(file_path).read_text().strip()  # type: ignore[arg-type]

    # Call API via SDK
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.decrypt(ciphertext_b64, key_version)

    plaintext_bytes = base64.b64decode(result["plaintext"])

    # Output
    if output:
        Path(output).write_bytes(plaintext_bytes)
        print_success(f"Decrypted output written to {output}")
    elif file_path and file_path.endswith(".enc"):
        out_path = file_path[:-4]
        Path(out_path).write_bytes(plaintext_bytes)
        print_success(f"Decrypted output written to {out_path}")
    else:
        click.echo(plaintext_bytes.decode("utf-8", errors="replace"))

    click.echo(
        f"  algorithm: {result.get('algorithm', 'Kyber768')}, "
        f"key_version: {result.get('key_version', key_version)}",
        err=True,
    )
