"""CLI-friendly error display."""

from __future__ import annotations

import functools
from typing import Callable, TypeVar, Any

import click

from qpher.errors import QpherError
from qpher.cli.config import load_config

F = TypeVar("F", bound=Callable[..., Any])

_STATUS_MESSAGES = {
    401: "Authentication failed. Run: qpher auth set-key <your-key>",
    403: "Access denied. Your plan may not support this operation.",
    404: "Resource not found. Check the key version or algorithm.",
    429: "Rate limit exceeded. Wait a moment and retry.",
    503: "Service unavailable. Check status.qpher.ai",
}


def handle_api_error(error: QpherError) -> None:
    """Convert API errors to user-friendly CLI messages."""
    msg = _STATUS_MESSAGES.get(error.status_code, f"API error: {error.message}")
    if error.request_id:
        msg += f"\n  Request ID: {error.request_id}"
    raise click.ClickException(msg)


def require_auth(func: F) -> F:
    """Decorator that ensures API key is configured before running command."""

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        config = load_config()
        if not config.api_key:
            raise click.ClickException(
                "No API key configured.\n"
                "Run: qpher auth set-key <your-api-key>\n"
                "Or set: export QPHER_API_KEY=<your-key>"
            )
        return func(*args, **kwargs)

    return wrapper  # type: ignore[return-value]


def api_error_handler(func: F) -> F:
    """Decorator that catches QpherError and displays friendly message."""

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except QpherError as e:
            handle_api_error(e)

    return wrapper  # type: ignore[return-value]
