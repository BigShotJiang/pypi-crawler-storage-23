"""Manage Qpher CLI configuration stored at ~/.qpher/config.toml."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

import click

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]

import tomli_w


CONFIG_DIR = Path.home() / ".qpher"
CONFIG_FILE = CONFIG_DIR / "config.toml"


@dataclass
class QpherConfig:
    """CLI configuration."""

    api_key: str | None = None
    api_url: str = "https://api.qpher.ai"
    default_format: str = "table"


def load_config() -> QpherConfig:
    """Load config from file, env vars, and defaults.

    Priority (highest first):
    1. Environment variables: QPHER_API_KEY, QPHER_API_URL
    2. Config file: ~/.qpher/config.toml
    3. Defaults
    """
    config = QpherConfig()

    # Load from config file
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "rb") as f:
                data = tomllib.load(f)
            auth = data.get("auth", {})
            api = data.get("api", {})
            output = data.get("output", {})
            if auth.get("api_key"):
                config.api_key = auth["api_key"]
            if api.get("url"):
                config.api_url = api["url"]
            if output.get("format"):
                config.default_format = output["format"]
        except Exception:
            pass  # Malformed config — use defaults

    # Environment variables override config file
    env_key = os.environ.get("QPHER_API_KEY")
    if env_key:
        config.api_key = env_key

    env_url = os.environ.get("QPHER_API_URL")
    if env_url:
        config.api_url = env_url

    return config


def save_config(config: QpherConfig) -> None:
    """Save config to ~/.qpher/config.toml.

    Creates directory with 700 permissions.
    Creates file with 600 permissions.
    """
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)

    data: dict = {
        "auth": {},
        "api": {"url": config.api_url},
        "output": {"format": config.default_format},
    }
    if config.api_key:
        data["auth"]["api_key"] = config.api_key

    with open(CONFIG_FILE, "wb") as f:
        tomli_w.dump(data, f)

    # Set restrictive permissions on the config file
    CONFIG_FILE.chmod(0o600)


def get_api_key() -> str:
    """Get API key from config. Raises ClickException if not set."""
    config = load_config()
    if not config.api_key:
        raise click.ClickException(
            "No API key configured.\n"
            "Run: qpher auth set-key <your-api-key>\n"
            "Or set: export QPHER_API_KEY=<your-key>"
        )
    return config.api_key
