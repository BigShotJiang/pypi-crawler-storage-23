"""Auth commands: set-key, whoami, logout."""

from __future__ import annotations

import click

from qpher.cli.config import load_config, save_config
from qpher.cli.output import print_success, print_key_value, mask_api_key
from qpher.cli.errors import api_error_handler


@click.group("auth")
def auth_group() -> None:
    """Manage authentication."""


@auth_group.command("set-key")
@click.argument("api_key")
def set_key(api_key: str) -> None:
    """Store your Qpher API key.

    The key is saved to ~/.qpher/config.toml (permissions 600).
    You can also set QPHER_API_KEY environment variable.
    """
    # Validate key format
    if not api_key.startswith("qph_") or len(api_key) < 12:
        raise click.ClickException(
            "Invalid API key format. Keys start with 'qph_' and are at least 12 characters."
        )

    # Save to config
    config = load_config()
    config.api_key = api_key
    save_config(config)
    print_success("API key saved. You're ready to go!")
    click.echo(f"  Key: {mask_api_key(api_key)}")
    click.echo("  Stored in: ~/.qpher/config.toml")


@auth_group.command("whoami")
@api_error_handler
def whoami() -> None:
    """Show current authentication status."""
    config = load_config()
    if not config.api_key:
        raise click.ClickException(
            "No API key configured.\n"
            "Run: qpher auth set-key <your-api-key>"
        )

    click.echo()
    click.echo("  Qpher Authentication")
    click.echo("  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500")
    print_key_value("API Key", mask_api_key(config.api_key))
    print_key_value("API URL", config.api_url)
    print_key_value("Format", config.default_format)
    click.echo()


@auth_group.command("logout")
def logout() -> None:
    """Remove stored API key."""
    config = load_config()
    if not config.api_key:
        click.echo("No API key to remove.")
        return

    config.api_key = None
    save_config(config)
    print_success("API key removed.")
