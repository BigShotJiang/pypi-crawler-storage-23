"""Output formatting helpers for CLI commands."""

from __future__ import annotations

import json

import click


def print_table(headers: list[str], rows: list[list[str]]) -> None:
    """Print a formatted table with aligned columns."""
    if not rows:
        click.echo("  (no results)")
        return

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    # Header
    header_line = "  ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    click.echo(header_line)
    click.echo("  ".join("-" * w for w in widths))

    # Rows
    for row in rows:
        line = "  ".join(
            (row[i] if i < len(row) else "").ljust(widths[i]) for i in range(len(headers))
        )
        click.echo(line)


def print_json(data: dict | list) -> None:
    """Print formatted JSON to stdout."""
    click.echo(json.dumps(data, indent=2, default=str))


def print_success(message: str) -> None:
    """Print green success message to stderr."""
    click.echo(click.style(message, fg="green"), err=True)


def print_error(message: str) -> None:
    """Print red error message to stderr."""
    click.echo(click.style(f"Error: {message}", fg="red"), err=True)


def print_warning(message: str) -> None:
    """Print yellow warning message to stderr."""
    click.echo(click.style(f"Warning: {message}", fg="yellow"), err=True)


def print_key_value(key: str, value: str, key_width: int = 15) -> None:
    """Print aligned key-value pair."""
    click.echo(f"  {key + ':':<{key_width}} {value}")


def progress_bar(current: int, total: int, width: int = 20) -> str:
    """Return a text progress bar string."""
    if total == 0:
        return "\u2591" * width + " 0.0%"
    ratio = current / total
    filled = int(width * ratio)
    bar = "\u2588" * filled + "\u2591" * (width - filled)
    pct = ratio * 100
    return f"{bar} {pct:.1f}%"


def mask_api_key(key: str) -> str:
    """Mask API key: show prefix and last 4 chars."""
    if not key:
        return "(not set)"
    if len(key) <= 12:
        return key[:4] + "****"
    return key[:8] + "****" + key[-4:]
