"""Status command — account info, plan, usage, quota."""

from __future__ import annotations

import click

from qpher.cli.config import load_config
from qpher.cli.errors import require_auth, api_error_handler
from qpher.cli.output import print_key_value, progress_bar, mask_api_key
from qpher.cli._api import CliApiClient


@click.command("status")
@require_auth
@api_error_handler
def status_cmd() -> None:
    """Show account status, plan, and usage."""
    config = load_config()
    client = CliApiClient(config.api_key, config.api_url)  # type: ignore[arg-type]
    result = client.get_status()

    tenant = result.get("tenant_name", "Unknown")
    plan = result.get("plan", {})
    plan_name = plan.get("name", "Unknown")
    plan_price = plan.get("price", "")
    usage = result.get("usage", {})
    limits = result.get("limits", {})
    renews = result.get("renews_at", "")

    click.echo()
    click.echo("  Qpher Account Status")
    click.echo("  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500")
    print_key_value("Tenant", tenant)

    plan_display = plan_name
    if plan_price:
        plan_display += f" ({plan_price})"
    print_key_value("Plan", plan_display)
    print_key_value("API Key", mask_api_key(config.api_key or ""))
    click.echo()

    # Usage
    api_calls = usage.get("api_calls", 0)
    api_limit = limits.get("api_calls", 0)
    if api_limit > 0:
        click.echo("  Usage (this month):")
        pct = api_calls / api_limit * 100 if api_limit else 0
        click.echo(f"    API Calls:   {api_calls:,} / {api_limit:,} ({pct:.1f}%)")
        click.echo(f"    {progress_bar(api_calls, api_limit)}")
        click.echo()

    kem_keys = usage.get("kem_keys", 0)
    kem_limit = limits.get("kem_keys", 0)
    sig_keys = usage.get("sig_keys", 0)
    sig_limit = limits.get("sig_keys", 0)
    api_keys_count = usage.get("api_keys", 0)
    api_keys_limit = limits.get("api_keys", 0)

    if kem_limit > 0:
        print_key_value("KEM Keys", f"{kem_keys} / {kem_limit}", key_width=17)
    if sig_limit > 0:
        print_key_value("Sig Keys", f"{sig_keys} / {sig_limit}", key_width=17)
    if api_keys_limit > 0:
        print_key_value("API Keys", f"{api_keys_count} / {api_keys_limit}", key_width=17)

    if renews:
        click.echo()
        print_key_value("Renews", renews[:10])

    click.echo()
