"""KEM encrypt/decrypt operations (Kyber768, X-Wing)."""

import base64
import os
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from qpher._util import _zero_bytes
from qpher.http_client import _HttpClient
from qpher.types import (
    DecapsulateResult,
    DecryptResult,
    EncapsulateResult,
    EncryptedEnvelope,
    EncryptResult,
)

VALID_KEM_ALGORITHMS = frozenset({"Kyber768", "X-Wing"})


class KEMModule:
    """KEM encrypt/decrypt operations.

    Supports Kyber768 (PQC-only) and X-Wing (hybrid PQC + classical).
    All binary data (plaintext, ciphertext) is automatically
    base64-encoded for the wire and decoded in results.
    """

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def encrypt(
        self,
        plaintext: bytes,
        key_version: int,
        mode: str = "standard",
        salt: Optional[bytes] = None,
        algorithm: Optional[str] = None,
    ) -> EncryptResult:
        """Encrypt data using KEM.

        Args:
            plaintext: Data to encrypt (max 1MB).
            key_version: Active key version to use.
            mode: "standard" (default) or "deterministic".
            salt: Required if mode="deterministic" (min 32 bytes).
            algorithm: "Kyber768" (default) or "X-Wing" (hybrid).
                If None, defaults to Kyber768.

        Returns:
            EncryptResult with ciphertext bytes and metadata.

        Raises:
            ValueError: If algorithm is not a valid KEM algorithm.
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        if algorithm is not None and algorithm not in VALID_KEM_ALGORITHMS:
            raise ValueError(
                f"Invalid KEM algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_KEM_ALGORITHMS))}"
            )

        body = {
            "plaintext": base64.b64encode(plaintext).decode("ascii"),
            "key_version": key_version,
            "mode": mode,
        }
        if salt is not None:
            body["salt"] = base64.b64encode(salt).decode("ascii")
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/kem/encrypt", json=body)
        data = resp["data"]

        return EncryptResult(
            ciphertext=base64.b64decode(data["ciphertext"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def decrypt(
        self,
        ciphertext: bytes,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> DecryptResult:
        """Decrypt data using KEM.

        Args:
            ciphertext: Encrypted data from encrypt().
            key_version: Key version used during encryption.
            algorithm: "Kyber768" (default) or "X-Wing" (hybrid).
                If None, defaults to Kyber768.

        Returns:
            DecryptResult with plaintext bytes and metadata.

        Raises:
            ValueError: If algorithm is not a valid KEM algorithm.
            ValidationError: If ciphertext is invalid.
            NotFoundError: If key_version not found.
        """
        if algorithm is not None and algorithm not in VALID_KEM_ALGORITHMS:
            raise ValueError(
                f"Invalid KEM algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_KEM_ALGORITHMS))}"
            )

        body = {
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
            "key_version": key_version,
        }
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/kem/decrypt", json=body)
        data = resp["data"]

        return DecryptResult(
            plaintext=base64.b64decode(data["plaintext"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def encapsulate(
        self,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> EncapsulateResult:
        """Encapsulate a shared secret using tenant's KEM public key.

        The shared secret can be used as an AES-256-GCM key for local encryption.
        Plaintext never leaves your environment.

        Args:
            key_version: Active key version to use.
            algorithm: "Kyber768" (default) or "X-Wing" (hybrid).

        Returns:
            EncapsulateResult with kem_ciphertext and shared_secret.
        """
        if algorithm is not None and algorithm not in VALID_KEM_ALGORITHMS:
            raise ValueError(
                f"Invalid KEM algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_KEM_ALGORITHMS))}"
            )

        body: dict = {"key_version": key_version}
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/kem/encapsulate", json=body)
        data = resp["data"]

        return EncapsulateResult(
            kem_ciphertext=base64.b64decode(data["kem_ciphertext"]),
            shared_secret=base64.b64decode(data["shared_secret"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def decapsulate(
        self,
        kem_ciphertext: bytes,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> DecapsulateResult:
        """Decapsulate a shared secret using tenant's KEM private key.

        Args:
            kem_ciphertext: KEM ciphertext from encapsulate().
            key_version: Key version used during encapsulate.
            algorithm: "Kyber768" (default) or "X-Wing" (hybrid).

        Returns:
            DecapsulateResult with shared_secret.
        """
        if algorithm is not None and algorithm not in VALID_KEM_ALGORITHMS:
            raise ValueError(
                f"Invalid KEM algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_KEM_ALGORITHMS))}"
            )

        body: dict = {
            "kem_ciphertext": base64.b64encode(kem_ciphertext).decode("ascii"),
            "key_version": key_version,
        }
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/kem/decapsulate", json=body)
        data = resp["data"]

        return DecapsulateResult(
            shared_secret=base64.b64decode(data["shared_secret"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def encrypt_local(
        self,
        plaintext: bytes,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> EncryptedEnvelope:
        """Client-side encryption: encapsulate + local AES-256-GCM.

        Plaintext NEVER leaves your environment. Only the KEM encapsulate
        request (no plaintext) is sent to Qpher.

        Args:
            plaintext: Data to encrypt (no size limit — local encryption).
            key_version: Active key version to use.
            algorithm: "Kyber768" (default) or "X-Wing" (hybrid).

        Returns:
            EncryptedEnvelope containing all data needed for decryption.
        """
        result = self.encapsulate(key_version, algorithm)

        try:
            iv = os.urandom(12)
            aesgcm = AESGCM(result.shared_secret)
            aes_ciphertext = aesgcm.encrypt(iv, plaintext, result.kem_ciphertext)
        finally:
            _zero_bytes(result.shared_secret)

        return EncryptedEnvelope(
            kem_ciphertext=result.kem_ciphertext,
            iv=iv,
            aes_ciphertext=aes_ciphertext,
            key_version=result.key_version,
            algorithm=result.algorithm,
            request_id=result.request_id,
        )

    def decrypt_local(
        self,
        envelope: EncryptedEnvelope,
    ) -> bytes:
        """Client-side decryption: decapsulate + local AES-256-GCM.

        Only the KEM decapsulate request (KEM ciphertext, no plaintext)
        is sent to Qpher.

        Args:
            envelope: EncryptedEnvelope from encrypt_local().

        Returns:
            Original plaintext bytes.
        """
        result = self.decapsulate(
            envelope.kem_ciphertext,
            envelope.key_version,
            envelope.algorithm,
        )

        try:
            aesgcm = AESGCM(result.shared_secret)
            plaintext = aesgcm.decrypt(
                envelope.iv, envelope.aes_ciphertext, envelope.kem_ciphertext,
            )
        finally:
            _zero_bytes(result.shared_secret)

        return plaintext
