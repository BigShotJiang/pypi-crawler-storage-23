"""Internal utilities for Qpher SDK."""

import ctypes


def _zero_bytes(data: bytes) -> None:
    """Zero memory for a bytes object. Best-effort — Python bytes are immutable."""
    if data and len(data) > 0:
        ctypes.memset(id(data) + bytes.__basicsize__ - 1, 0, len(data))
