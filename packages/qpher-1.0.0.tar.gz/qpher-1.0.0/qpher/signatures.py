"""Digital signature operations (Dilithium3, Composite ML-DSA)."""

import base64
from typing import Optional

from qpher.http_client import _HttpClient
from qpher.types import SignResult, VerifyResult

VALID_SIG_ALGORITHMS = frozenset({"Dilithium3", "Composite-ML-DSA"})


class SignaturesModule:
    """Digital signature operations.

    Supports Dilithium3 (PQC-only) and Composite ML-DSA (hybrid PQC + classical).
    """

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def sign(
        self,
        message: bytes,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> SignResult:
        """Sign a message.

        Args:
            message: Message to sign (max 1MB).
            key_version: Active signing key version.
            algorithm: "Dilithium3" (default) or "Composite-ML-DSA" (hybrid).
                If None, defaults to Dilithium3.

        Returns:
            SignResult with signature bytes.

        Raises:
            ValueError: If algorithm is not a valid signature algorithm.
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        if algorithm is not None and algorithm not in VALID_SIG_ALGORITHMS:
            raise ValueError(
                f"Invalid signature algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_SIG_ALGORITHMS))}"
            )

        body = {
            "message": base64.b64encode(message).decode("ascii"),
            "key_version": key_version,
        }
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/signature/sign", json=body)
        data = resp["data"]

        return SignResult(
            signature=base64.b64decode(data["signature"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def verify(
        self,
        message: bytes,
        signature: bytes,
        key_version: int,
        algorithm: Optional[str] = None,
    ) -> VerifyResult:
        """Verify a signature.

        Args:
            message: Original message.
            signature: Signature to verify.
            key_version: Key version used during signing.
            algorithm: "Dilithium3" (default) or "Composite-ML-DSA" (hybrid).
                If None, defaults to Dilithium3.

        Returns:
            VerifyResult with valid=True/False.

        Raises:
            ValueError: If algorithm is not a valid signature algorithm.
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        if algorithm is not None and algorithm not in VALID_SIG_ALGORITHMS:
            raise ValueError(
                f"Invalid signature algorithm: {algorithm!r}. "
                f"Must be one of: {', '.join(sorted(VALID_SIG_ALGORITHMS))}"
            )

        body = {
            "message": base64.b64encode(message).decode("ascii"),
            "signature": base64.b64encode(signature).decode("ascii"),
            "key_version": key_version,
        }
        if algorithm is not None:
            body["algorithm"] = algorithm

        resp = self._http.post("/api/v1/signature/verify", json=body)
        data = resp["data"]

        return VerifyResult(
            valid=data["valid"],
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )
