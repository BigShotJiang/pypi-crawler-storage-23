"""Qpher SDK error classes."""

from typing import Optional

import requests


class QpherError(Exception):
    """Base exception for all Qpher API errors.

    Attributes:
        message: Human-readable error description.
        error_code: Machine-readable code like "ERR_KEM_005".
        status_code: HTTP status code.
        request_id: Request UUID for support inquiries.
    """

    def __init__(
        self,
        message: str,
        error_code: str,
        status_code: int,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.request_id = request_id

    def __repr__(self) -> str:
        return (
            f"QpherError(error_code={self.error_code!r}, "
            f"status_code={self.status_code}, message={self.message!r})"
        )


class AuthenticationError(QpherError):
    """Raised when the API key is invalid or missing (HTTP 401)."""

    pass


class ValidationError(QpherError):
    """Raised when request parameters are invalid (HTTP 400)."""

    pass


class NotFoundError(QpherError):
    """Raised when a resource is not found (HTTP 404)."""

    pass


class ForbiddenError(QpherError):
    """Raised when an operation is not allowed (HTTP 403)."""

    pass


class RateLimitError(QpherError):
    """Raised when the rate limit is exceeded (HTTP 429)."""

    pass


class ServerError(QpherError):
    """Raised for server-side errors (HTTP 500+)."""

    pass


class TimeoutError(QpherError):
    """Raised when a request times out."""

    pass


class ConnectionError(QpherError):
    """Raised when connection to the API fails."""

    pass


_STATUS_TO_ERROR = {
    400: ValidationError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: NotFoundError,
    429: RateLimitError,
}


def _parse_error_response(response: requests.Response) -> QpherError:
    """Parse an API error response into a typed QpherError."""
    try:
        body = response.json()
        error_data = body.get("error", {})
        error_code = error_data.get("error_code", f"ERR_UNKNOWN_{response.status_code}")
        message = error_data.get("message", response.text)
        request_id = body.get("request_id")
    except (ValueError, KeyError):
        error_code = f"ERR_UNKNOWN_{response.status_code}"
        message = response.text or f"HTTP {response.status_code}"
        request_id = None

    error_cls = _STATUS_TO_ERROR.get(response.status_code, ServerError)
    return error_cls(
        message=message,
        error_code=error_code,
        status_code=response.status_code,
        request_id=request_id,
    )
