"""Response dataclasses for Qpher SDK."""

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class EncryptResult:
    """Result of a KEM encrypt operation."""

    ciphertext: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class DecryptResult:
    """Result of a KEM decrypt operation."""

    plaintext: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class SignResult:
    """Result of a signature sign operation."""

    signature: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class VerifyResult:
    """Result of a signature verify operation."""

    valid: bool
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class KeyInfo:
    """Information about a PQC key."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str


@dataclass(frozen=True)
class KeyListResult:
    """Result of a key list operation."""

    keys: List[KeyInfo]
    total: int
    request_id: str


@dataclass(frozen=True)
class RotateResult:
    """Result of a key rotation operation."""

    key_version: int
    algorithm: str
    public_key: bytes
    old_key_version: int
    request_id: str


@dataclass(frozen=True)
class GenerateResult:
    """Result of a key generation operation."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str
    request_id: str


@dataclass(frozen=True)
class RetireResult:
    """Result of a key retire operation."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str
    request_id: str


@dataclass(frozen=True)
class EncapsulateResult:
    """Result of a KEM encapsulate-only operation."""

    kem_ciphertext: bytes
    shared_secret: bytes  # 32 bytes — EPHEMERAL, zero after use
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class DecapsulateResult:
    """Result of a KEM decapsulate-only operation."""

    shared_secret: bytes  # 32 bytes — EPHEMERAL, zero after use
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class EncryptedEnvelope:
    """Client-side encrypted data envelope.

    Contains all information needed to decrypt locally:
    - kem_ciphertext: send to /kem/decapsulate to recover shared_secret
    - iv + aes_ciphertext: decrypt locally with shared_secret
    - key_version + algorithm: metadata for key lookup
    """

    kem_ciphertext: bytes
    iv: bytes              # 12 bytes (AES-GCM nonce)
    aes_ciphertext: bytes  # Plaintext + 16-byte GCM tag
    key_version: int
    algorithm: str
    request_id: str

    def to_bytes(self) -> bytes:
        """Serialize envelope to bytes for storage.

        Format: [2-byte kem_ct_len][kem_ct][12-byte iv][aes_ct]
        key_version and algorithm stored separately (e.g., in DB column).
        """
        import struct

        return (
            struct.pack(">H", len(self.kem_ciphertext))
            + self.kem_ciphertext
            + self.iv
            + self.aes_ciphertext
        )

    @classmethod
    def from_bytes(
        cls,
        data: bytes,
        key_version: int,
        algorithm: str = "Kyber768",
    ) -> "EncryptedEnvelope":
        """Deserialize envelope from bytes."""
        import struct

        kem_ct_len = struct.unpack(">H", data[:2])[0]
        kem_ct = data[2 : 2 + kem_ct_len]
        iv = data[2 + kem_ct_len : 2 + kem_ct_len + 12]
        aes_ct = data[2 + kem_ct_len + 12 :]
        return cls(
            kem_ciphertext=kem_ct,
            iv=iv,
            aes_ciphertext=aes_ct,
            key_version=key_version,
            algorithm=algorithm,
            request_id="",
        )
