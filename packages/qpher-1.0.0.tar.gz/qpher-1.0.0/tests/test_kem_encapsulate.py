"""Tests for KEM encapsulate/decapsulate and client-side encrypt operations."""

import base64
import json
import os

import pytest
import responses

from qpher import Qpher
from qpher.types import (
    DecapsulateResult,
    EncapsulateResult,
    EncryptedEnvelope,
)


SHARED_SECRET = os.urandom(32)
KEM_CIPHERTEXT = os.urandom(1088)


class TestEncapsulate:
    """Tests for KEM encapsulate operation."""

    @responses.activate
    def test_encapsulate_returns_valid_result(self, base_url, sample_request_id):
        """Encapsulate should return EncapsulateResult on success."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encapsulate",
            json={
                "data": {
                    "kem_ciphertext": base64.b64encode(KEM_CIPHERTEXT).decode(),
                    "shared_secret": base64.b64encode(SHARED_SECRET).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.kem.encapsulate(key_version=1)

        assert isinstance(result, EncapsulateResult)
        assert result.kem_ciphertext == KEM_CIPHERTEXT
        assert result.shared_secret == SHARED_SECRET
        assert result.key_version == 1
        assert result.algorithm == "Kyber768"
        assert result.request_id == sample_request_id

    @responses.activate
    def test_encapsulate_sends_correct_request(self, base_url):
        """Encapsulate should send key_version and algorithm."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encapsulate",
            json={
                "data": {
                    "kem_ciphertext": base64.b64encode(KEM_CIPHERTEXT).decode(),
                    "shared_secret": base64.b64encode(SHARED_SECRET).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.encapsulate(key_version=1)

        assert len(responses.calls) == 1
        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["key_version"] == 1
        # No plaintext in the request
        assert "plaintext" not in request_body

    def test_encapsulate_invalid_algorithm(self, base_url):
        """Encapsulate should reject invalid algorithm."""
        client = Qpher(api_key="qph_test_key", base_url=base_url)
        with pytest.raises(ValueError, match="Invalid KEM algorithm"):
            client.kem.encapsulate(key_version=1, algorithm="InvalidAlgo")


class TestDecapsulate:
    """Tests for KEM decapsulate operation."""

    @responses.activate
    def test_decapsulate_returns_shared_secret(self, base_url, sample_request_id):
        """Decapsulate should return DecapsulateResult with shared secret."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decapsulate",
            json={
                "data": {
                    "shared_secret": base64.b64encode(SHARED_SECRET).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.kem.decapsulate(
            kem_ciphertext=KEM_CIPHERTEXT, key_version=1,
        )

        assert isinstance(result, DecapsulateResult)
        assert result.shared_secret == SHARED_SECRET
        assert result.key_version == 1

    @responses.activate
    def test_decapsulate_sends_correct_request(self, base_url):
        """Decapsulate should send kem_ciphertext as base64."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decapsulate",
            json={
                "data": {
                    "shared_secret": base64.b64encode(SHARED_SECRET).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.decapsulate(kem_ciphertext=KEM_CIPHERTEXT, key_version=1)

        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["kem_ciphertext"] == base64.b64encode(KEM_CIPHERTEXT).decode()
        assert request_body["key_version"] == 1
        # No plaintext in the request
        assert "plaintext" not in request_body


class TestEncryptLocal:
    """Tests for client-side encrypt_local / decrypt_local."""

    @responses.activate
    def test_encrypt_local_decrypt_local_roundtrip(self, base_url):
        """encrypt_local → decrypt_local should recover original plaintext."""
        ss = os.urandom(32)
        kem_ct = os.urandom(1088)

        # Mock encapsulate
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encapsulate",
            json={
                "data": {
                    "kem_ciphertext": base64.b64encode(kem_ct).decode(),
                    "shared_secret": base64.b64encode(ss).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-enc",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        # Mock decapsulate (returns same shared secret)
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decapsulate",
            json={
                "data": {
                    "shared_secret": base64.b64encode(ss).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-dec",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        plaintext = b"Secret data that never leaves the client"
        envelope = client.kem.encrypt_local(plaintext=plaintext, key_version=1)

        assert isinstance(envelope, EncryptedEnvelope)
        assert envelope.key_version == 1
        assert envelope.algorithm == "Kyber768"
        assert len(envelope.iv) == 12

        recovered = client.kem.decrypt_local(envelope)
        assert recovered == plaintext

    @responses.activate
    def test_encrypt_local_plaintext_not_in_request(self, base_url):
        """encrypt_local should NOT send plaintext to the API."""
        ss = os.urandom(32)
        kem_ct = os.urandom(1088)

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encapsulate",
            json={
                "data": {
                    "kem_ciphertext": base64.b64encode(kem_ct).decode(),
                    "shared_secret": base64.b64encode(ss).decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-enc",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        plaintext = b"This should NEVER appear in the HTTP request"
        client.kem.encrypt_local(plaintext=plaintext, key_version=1)

        # Verify no plaintext in the API request
        request_body = json.loads(responses.calls[0].request.body)
        assert "plaintext" not in request_body
        plaintext_b64 = base64.b64encode(plaintext).decode()
        assert plaintext_b64 not in json.dumps(request_body)

    @responses.activate
    def test_encrypt_local_with_xwing(self, base_url):
        """encrypt_local should support X-Wing algorithm."""
        ss = os.urandom(32)
        kem_ct = os.urandom(1120)  # X-Wing ciphertext size

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encapsulate",
            json={
                "data": {
                    "kem_ciphertext": base64.b64encode(kem_ct).decode(),
                    "shared_secret": base64.b64encode(ss).decode(),
                    "key_version": 1,
                    "algorithm": "X-Wing",
                },
                "request_id": "req-enc",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decapsulate",
            json={
                "data": {
                    "shared_secret": base64.b64encode(ss).decode(),
                    "key_version": 1,
                    "algorithm": "X-Wing",
                },
                "request_id": "req-dec",
                "timestamp": "2026-03-04T10:00:00Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        envelope = client.kem.encrypt_local(
            plaintext=b"X-Wing local encrypt", key_version=1, algorithm="X-Wing",
        )
        assert envelope.algorithm == "X-Wing"

        recovered = client.kem.decrypt_local(envelope)
        assert recovered == b"X-Wing local encrypt"


class TestEncryptedEnvelope:
    """Tests for EncryptedEnvelope serialization."""

    def test_envelope_to_bytes_from_bytes_roundtrip(self):
        """to_bytes() → from_bytes() should preserve all fields."""
        kem_ct = os.urandom(1088)
        iv = os.urandom(12)
        aes_ct = os.urandom(64)

        envelope = EncryptedEnvelope(
            kem_ciphertext=kem_ct,
            iv=iv,
            aes_ciphertext=aes_ct,
            key_version=3,
            algorithm="Kyber768",
            request_id="req-ser",
        )

        data = envelope.to_bytes()
        restored = EncryptedEnvelope.from_bytes(data, key_version=3, algorithm="Kyber768")

        assert restored.kem_ciphertext == kem_ct
        assert restored.iv == iv
        assert restored.aes_ciphertext == aes_ct
        assert restored.key_version == 3
        assert restored.algorithm == "Kyber768"

    def test_envelope_serialization_format(self):
        """Envelope wire format: [2-byte len][kem_ct][12-byte iv][aes_ct]."""
        import struct

        kem_ct = os.urandom(1088)
        iv = os.urandom(12)
        aes_ct = os.urandom(48)

        envelope = EncryptedEnvelope(
            kem_ciphertext=kem_ct,
            iv=iv,
            aes_ciphertext=aes_ct,
            key_version=1,
            algorithm="Kyber768",
            request_id="",
        )

        data = envelope.to_bytes()
        expected_len = 2 + len(kem_ct) + 12 + len(aes_ct)
        assert len(data) == expected_len

        # First 2 bytes should be kem_ct length
        stored_len = struct.unpack(">H", data[:2])[0]
        assert stored_len == len(kem_ct)
