"""Tests for KEM encrypt/decrypt operations."""

import base64
import json

import pytest
import responses

from qpher import Qpher, NotFoundError, ValidationError
from qpher.types import EncryptResult, DecryptResult


class TestKEMEncrypt:
    """Tests for KEM encrypt operation."""

    @responses.activate
    def test_encrypt_success(self, base_url, sample_request_id):
        """Encrypt should return EncryptResult on success."""
        plaintext = b"Hello, Quantum World!"
        ciphertext_b64 = base64.b64encode(b"encrypted_data").decode()

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "data": {
                    "ciphertext": ciphertext_b64,
                    "key_version": 2,
                    "algorithm": "Kyber768",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.kem.encrypt(plaintext=plaintext, key_version=2)

        assert isinstance(result, EncryptResult)
        assert result.ciphertext == b"encrypted_data"
        assert result.key_version == 2
        assert result.algorithm == "Kyber768"
        assert result.request_id == sample_request_id

    @responses.activate
    def test_encrypt_sends_correct_request(self, base_url):
        """Encrypt should send properly formatted request."""
        plaintext = b"Test data"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "data": {
                    "ciphertext": base64.b64encode(b"ct").decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.encrypt(plaintext=plaintext, key_version=1)

        assert len(responses.calls) == 1
        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["plaintext"] == base64.b64encode(plaintext).decode()
        assert request_body["key_version"] == 1
        assert request_body["mode"] == "standard"

    @responses.activate
    def test_encrypt_with_deterministic_mode(self, base_url):
        """Encrypt should support deterministic mode with salt."""
        plaintext = b"Test data"
        salt = b"a" * 32  # 32-byte salt

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "data": {
                    "ciphertext": base64.b64encode(b"ct").decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.encrypt(plaintext=plaintext, key_version=1, mode="deterministic", salt=salt)

        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["mode"] == "deterministic"
        assert request_body["salt"] == base64.b64encode(salt).decode()

    @responses.activate
    def test_encrypt_key_not_found(self, base_url):
        """Encrypt should raise NotFoundError when key version not found."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "error": {
                    "error_code": "ERR_KEM_005",
                    "message": "Key version 99 not found",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=404,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(NotFoundError) as exc_info:
            client.kem.encrypt(plaintext=b"data", key_version=99)

        assert exc_info.value.error_code == "ERR_KEM_005"
        assert "Key version 99 not found" in exc_info.value.message

    @responses.activate
    def test_encrypt_validation_error(self, base_url):
        """Encrypt should raise ValidationError for invalid input."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "error": {
                    "error_code": "ERR_KEM_001",
                    "message": "Invalid plaintext encoding",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=400,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(ValidationError) as exc_info:
            client.kem.encrypt(plaintext=b"data", key_version=1)

        assert exc_info.value.error_code == "ERR_KEM_001"


class TestKEMDecrypt:
    """Tests for KEM decrypt operation."""

    @responses.activate
    def test_decrypt_success(self, base_url, sample_request_id):
        """Decrypt should return DecryptResult on success."""
        ciphertext = b"encrypted_data"
        plaintext_b64 = base64.b64encode(b"Hello, Quantum World!").decode()

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decrypt",
            json={
                "data": {
                    "plaintext": plaintext_b64,
                    "key_version": 2,
                    "algorithm": "Kyber768",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.kem.decrypt(ciphertext=ciphertext, key_version=2)

        assert isinstance(result, DecryptResult)
        assert result.plaintext == b"Hello, Quantum World!"
        assert result.key_version == 2
        assert result.algorithm == "Kyber768"
        assert result.request_id == sample_request_id

    @responses.activate
    def test_decrypt_sends_correct_request(self, base_url):
        """Decrypt should send properly formatted request."""
        ciphertext = b"encrypted_data"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decrypt",
            json={
                "data": {
                    "plaintext": base64.b64encode(b"pt").decode(),
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.decrypt(ciphertext=ciphertext, key_version=1)

        assert len(responses.calls) == 1
        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["ciphertext"] == base64.b64encode(ciphertext).decode()
        assert request_body["key_version"] == 1

    @responses.activate
    def test_decrypt_invalid_ciphertext(self, base_url):
        """Decrypt should raise ValidationError for invalid ciphertext."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/decrypt",
            json={
                "error": {
                    "error_code": "ERR_KEM_003",
                    "message": "Invalid ciphertext",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=400,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(ValidationError) as exc_info:
            client.kem.decrypt(ciphertext=b"invalid", key_version=1)

        assert exc_info.value.error_code == "ERR_KEM_003"
