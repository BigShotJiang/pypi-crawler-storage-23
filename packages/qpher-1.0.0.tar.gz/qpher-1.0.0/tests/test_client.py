"""Tests for Qpher client initialization and configuration."""

import pytest

from qpher import Qpher
from qpher.kem import KEMModule
from qpher.signatures import SignaturesModule
from qpher.keys import KeysModule


class TestClientInit:
    """Tests for Qpher client initialization."""

    def test_init_with_valid_api_key(self):
        """Client should initialize with a valid API key."""
        client = Qpher(api_key="qph_live_abc123")
        assert client is not None
        assert isinstance(client.kem, KEMModule)
        assert isinstance(client.signatures, SignaturesModule)
        assert isinstance(client.keys, KeysModule)

    def test_init_with_test_api_key(self):
        """Client should accept test API keys."""
        client = Qpher(api_key="qph_test_xyz789")
        assert client is not None

    def test_init_with_empty_api_key_raises_error(self):
        """Client should raise ValueError for empty API key."""
        with pytest.raises(ValueError, match="api_key is required"):
            Qpher(api_key="")

    def test_init_with_none_api_key_raises_error(self):
        """Client should raise ValueError for None API key."""
        with pytest.raises(ValueError, match="api_key is required"):
            Qpher(api_key=None)  # type: ignore

    def test_init_with_invalid_prefix_raises_error(self):
        """Client should raise ValueError for API key without qph_ prefix."""
        with pytest.raises(ValueError, match="api_key must start with 'qph_'"):
            Qpher(api_key="invalid_key_12345")

    def test_init_with_custom_base_url(self):
        """Client should accept custom base URL."""
        client = Qpher(
            api_key="qph_live_abc123",
            base_url="https://custom.api.qpher.ai",
        )
        assert client._http._base_url == "https://custom.api.qpher.ai"

    def test_init_strips_trailing_slash_from_base_url(self):
        """Client should strip trailing slash from base URL."""
        client = Qpher(
            api_key="qph_live_abc123",
            base_url="https://api.qpher.ai/",
        )
        assert client._http._base_url == "https://api.qpher.ai"

    def test_init_with_custom_timeout(self):
        """Client should accept custom timeout."""
        client = Qpher(api_key="qph_live_abc123", timeout=60)
        assert client._http._timeout == 60

    def test_init_with_custom_max_retries(self):
        """Client should accept custom max retries."""
        client = Qpher(api_key="qph_live_abc123", max_retries=5)
        assert client._http._max_retries == 5

    def test_default_base_url(self):
        """Client should use default base URL if not specified."""
        client = Qpher(api_key="qph_live_abc123")
        assert client._http._base_url == "https://api.qpher.ai"

    def test_default_timeout(self):
        """Client should use default timeout if not specified."""
        client = Qpher(api_key="qph_live_abc123")
        assert client._http._timeout == 30

    def test_default_max_retries(self):
        """Client should use default max retries if not specified."""
        client = Qpher(api_key="qph_live_abc123")
        assert client._http._max_retries == 3


class TestClientModules:
    """Tests for Qpher client module access."""

    def test_kem_module_accessible(self, client):
        """KEM module should be accessible from client."""
        assert hasattr(client, "kem")
        assert isinstance(client.kem, KEMModule)

    def test_signatures_module_accessible(self, client):
        """Signatures module should be accessible from client."""
        assert hasattr(client, "signatures")
        assert isinstance(client.signatures, SignaturesModule)

    def test_keys_module_accessible(self, client):
        """Keys module should be accessible from client."""
        assert hasattr(client, "keys")
        assert isinstance(client.keys, KeysModule)
