"""Tests for HTTP client functionality."""

import time
from unittest.mock import patch

import pytest
import responses
import requests

from qpher import Qpher, RateLimitError, ServerError
from qpher.errors import TimeoutError, ConnectionError
from qpher.http_client import _HttpClient


class TestHttpClientAuth:
    """Tests for HTTP client authentication."""

    @responses.activate
    def test_api_key_header_sent(self, base_url):
        """HTTP client should send x-api-key header."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": "cHVibGljX2tleQ==",
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_secret_key", base_url=base_url)
        client.keys.get_active(algorithm="Kyber768")

        assert responses.calls[0].request.headers["x-api-key"] == "qph_test_secret_key"

    @responses.activate
    def test_user_agent_header_sent(self, base_url):
        """HTTP client should send User-Agent header."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": "cHVibGljX2tleQ==",
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.keys.get_active(algorithm="Kyber768")

        assert "qpher-python" in responses.calls[0].request.headers["User-Agent"]

    @responses.activate
    def test_content_type_header_sent(self, base_url):
        """HTTP client should send Content-Type header."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "data": {
                    "ciphertext": "Y3Q=",
                    "key_version": 1,
                    "algorithm": "Kyber768",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.kem.encrypt(plaintext=b"data", key_version=1)

        assert responses.calls[0].request.headers["Content-Type"] == "application/json"


class TestHttpClientRetries:
    """Tests for HTTP client retry behavior."""

    @responses.activate
    def test_retries_on_429(self, base_url):
        """HTTP client should retry on 429 status."""
        # First two calls return 429, third succeeds
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "error": {"error_code": "ERR_RATE_001", "message": "Rate limited"},
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=429,
        )
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "error": {"error_code": "ERR_RATE_001", "message": "Rate limited"},
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=429,
        )
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": "cHVibGljX2tleQ==",
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        with patch.object(_HttpClient, "_backoff", return_value=None):
            client = Qpher(api_key="qph_test_key", base_url=base_url, max_retries=3)
            result = client.keys.get_active(algorithm="Kyber768")

        assert len(responses.calls) == 3
        assert result.key_version == 1

    @responses.activate
    def test_retries_on_503(self, base_url):
        """HTTP client should retry on 503 status."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "error": {"error_code": "ERR_SERVICE_001", "message": "Service unavailable"},
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=503,
        )
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": "cHVibGljX2tleQ==",
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        with patch.object(_HttpClient, "_backoff", return_value=None):
            client = Qpher(api_key="qph_test_key", base_url=base_url)
            result = client.keys.get_active(algorithm="Kyber768")

        assert len(responses.calls) == 2

    @responses.activate
    def test_no_retry_on_400(self, base_url):
        """HTTP client should NOT retry on 400 status."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kem/encrypt",
            json={
                "error": {"error_code": "ERR_INVALID_001", "message": "Invalid input"},
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=400,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(Exception):
            client.kem.encrypt(plaintext=b"data", key_version=1)

        assert len(responses.calls) == 1

    @responses.activate
    def test_no_retry_on_401(self, base_url):
        """HTTP client should NOT retry on 401 status."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "error": {"error_code": "ERR_AUTH_001", "message": "Invalid API key"},
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=401,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(Exception):
            client.keys.get_active(algorithm="Kyber768")

        assert len(responses.calls) == 1

    @responses.activate
    def test_max_retries_exceeded(self, base_url):
        """HTTP client should raise error after max retries exceeded."""
        for _ in range(4):  # 1 initial + 3 retries
            responses.add(
                responses.GET,
                f"{base_url}/api/v1/kms/keys/active",
                json={
                    "error": {"error_code": "ERR_RATE_001", "message": "Rate limited"},
                    "request_id": "req-123",
                    "timestamp": "2026-02-15T10:30:45.123Z",
                },
                status=429,
            )

        with patch.object(_HttpClient, "_backoff", return_value=None):
            client = Qpher(api_key="qph_test_key", base_url=base_url, max_retries=3)

            with pytest.raises(RateLimitError):
                client.keys.get_active(algorithm="Kyber768")

        assert len(responses.calls) == 4  # 1 initial + 3 retries


class TestHttpClientTimeout:
    """Tests for HTTP client timeout handling."""

    @responses.activate
    def test_timeout_raises_error(self, base_url):
        """HTTP client should raise TimeoutError on timeout."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            body=requests.exceptions.Timeout(),
        )

        with patch.object(_HttpClient, "_backoff", return_value=None):
            client = Qpher(api_key="qph_test_key", base_url=base_url, max_retries=0)

            with pytest.raises(TimeoutError) as exc_info:
                client.keys.get_active(algorithm="Kyber768")

            assert exc_info.value.error_code == "ERR_TIMEOUT_001"

    @responses.activate
    def test_connection_error_raises(self, base_url):
        """HTTP client should raise ConnectionError on connection failure."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            body=requests.exceptions.ConnectionError(),
        )

        with patch.object(_HttpClient, "_backoff", return_value=None):
            client = Qpher(api_key="qph_test_key", base_url=base_url, max_retries=0)

            with pytest.raises(ConnectionError) as exc_info:
                client.keys.get_active(algorithm="Kyber768")

            assert exc_info.value.error_code == "ERR_SERVICE_001"


class TestHttpClientBackoff:
    """Tests for HTTP client exponential backoff."""

    def test_backoff_delays(self):
        """Backoff should use exponential delays."""
        with patch("time.sleep") as mock_sleep:
            _HttpClient._backoff(0)
            mock_sleep.assert_called_with(0.5)

            _HttpClient._backoff(1)
            mock_sleep.assert_called_with(1.0)

            _HttpClient._backoff(2)
            mock_sleep.assert_called_with(2.0)

    def test_backoff_max_delay(self):
        """Backoff should cap at 10 seconds."""
        with patch("time.sleep") as mock_sleep:
            _HttpClient._backoff(10)  # Would be 512s without cap
            mock_sleep.assert_called_with(10)
