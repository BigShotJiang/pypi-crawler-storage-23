"""Tests for status command."""

from __future__ import annotations

from qpher.cli.main import cli


class TestStatus:
    def test_shows_account_info(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        assert result.exit_code == 0
        assert "My Company" in result.output
        assert "Growth" in result.output

    def test_shows_usage(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        assert "12,450" in result.output
        assert "30,000" in result.output

    def test_shows_progress_bar(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        # Should have progress bar characters
        assert "\u2588" in result.output or "\u2591" in result.output

    def test_shows_key_counts(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        assert "KEM Keys" in result.output
        assert "Sig Keys" in result.output

    def test_shows_masked_key(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        assert "****" in result.output

    def test_shows_renewal_date(self, configured_runner, temp_config, mock_status_api):
        result = configured_runner.invoke(cli, ["status"])
        assert "2026-03-17" in result.output

    def test_no_auth_error(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["status"])
        assert result.exit_code != 0
        assert "No API key" in result.output
