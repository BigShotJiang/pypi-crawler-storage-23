"""Tests for sign/verify commands."""

from __future__ import annotations

from pathlib import Path

from qpher.cli.main import cli


class TestSign:
    def test_sign_text(self, configured_runner, temp_config, mock_sign_api):
        result = configured_runner.invoke(
            cli, ["sign", "--text", "Invoice #1234", "--key-version", "1"]
        )
        assert result.exit_code == 0
        assert "c2lnbmF0dXJlX2RhdGE=" in result.output

    def test_sign_file(self, configured_runner, temp_config, mock_sign_api, tmp_path):
        test_file = tmp_path / "contract.pdf"
        test_file.write_bytes(b"contract data")
        result = configured_runner.invoke(
            cli, ["sign", "--file", str(test_file), "--key-version", "1"]
        )
        assert result.exit_code == 0
        sig_file = Path(str(test_file) + ".sig")
        assert sig_file.exists()

    def test_sign_to_output(self, configured_runner, temp_config, mock_sign_api, tmp_path):
        out_file = tmp_path / "my.sig"
        result = configured_runner.invoke(
            cli,
            ["sign", "--text", "msg", "--key-version", "1", "--output", str(out_file)],
        )
        assert result.exit_code == 0
        assert out_file.exists()

    def test_sign_both_text_and_file_error(self, configured_runner, temp_config, tmp_path):
        f = tmp_path / "f.txt"
        f.write_text("data")
        result = configured_runner.invoke(
            cli, ["sign", "--text", "msg", "--file", str(f), "--key-version", "1"]
        )
        assert result.exit_code != 0

    def test_sign_neither_text_nor_file_error(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["sign", "--key-version", "1"])
        assert result.exit_code != 0

    def test_sign_requires_key_version(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["sign", "--text", "msg"])
        assert result.exit_code != 0

    def test_sign_shows_metadata(self, configured_runner, temp_config, mock_sign_api):
        result = configured_runner.invoke(
            cli, ["sign", "--text", "msg", "--key-version", "1"]
        )
        assert "Dilithium3" in result.output

    def test_sign_no_auth_error(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["sign", "--text", "msg", "--key-version", "1"])
        assert result.exit_code != 0
        assert "No API key" in result.output


class TestVerify:
    def test_verify_valid(self, configured_runner, temp_config, mock_verify_valid_api):
        result = configured_runner.invoke(
            cli,
            [
                "verify",
                "--text",
                "Invoice #1234",
                "--signature",
                "c2lnbmF0dXJlX2RhdGE=",
                "--key-version",
                "1",
            ],
        )
        assert "valid" in result.output.lower()

    def test_verify_invalid(self, configured_runner, temp_config, mock_verify_invalid_api):
        result = configured_runner.invoke(
            cli,
            [
                "verify",
                "--text",
                "tampered",
                "--signature",
                "bad_sig",
                "--key-version",
                "1",
            ],
        )
        assert "INVALID" in result.output

    def test_verify_file_with_sig_file(
        self, configured_runner, temp_config, mock_verify_valid_api, tmp_path
    ):
        f = tmp_path / "contract.pdf"
        f.write_bytes(b"contract data")
        sig = tmp_path / "contract.pdf.sig"
        sig.write_text("c2lnbmF0dXJlX2RhdGE=")
        result = configured_runner.invoke(
            cli,
            [
                "verify",
                "--file",
                str(f),
                "--signature-file",
                str(sig),
                "--key-version",
                "1",
            ],
        )
        assert "valid" in result.output.lower()

    def test_verify_requires_signature(self, configured_runner, temp_config):
        result = configured_runner.invoke(
            cli, ["verify", "--text", "msg", "--key-version", "1"]
        )
        assert result.exit_code != 0

    def test_verify_requires_message(self, configured_runner, temp_config):
        result = configured_runner.invoke(
            cli, ["verify", "--signature", "sig", "--key-version", "1"]
        )
        assert result.exit_code != 0
