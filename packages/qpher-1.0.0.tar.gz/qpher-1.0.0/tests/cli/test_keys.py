"""Tests for key management commands."""

from __future__ import annotations

import json

from qpher.cli.main import cli


class TestListKeys:
    def test_list_all_keys(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(cli, ["keys", "list"])
        assert result.exit_code == 0
        assert "Kyber768" in result.output
        assert "Dilithium3" in result.output
        assert "active" in result.output

    def test_list_json_format(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(cli, ["keys", "list", "--format", "json"])
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert "keys" in parsed
        assert len(parsed["keys"]) == 3

    def test_list_shows_total(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(cli, ["keys", "list"])
        assert "3" in result.output

    def test_list_no_auth_error(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["keys", "list"])
        assert result.exit_code != 0
        assert "No API key" in result.output


class TestGenerateKey:
    def test_generate_kyber768(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(
            cli, ["keys", "generate", "--algorithm", "Kyber768"]
        )
        assert result.exit_code == 0
        assert "Generated Kyber768" in result.output
        assert "version 4" in result.output

    def test_generate_requires_algorithm(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["keys", "generate"])
        assert result.exit_code != 0

    def test_generate_invalid_algorithm(self, configured_runner, temp_config):
        result = configured_runner.invoke(
            cli, ["keys", "generate", "--algorithm", "RSA2048"]
        )
        assert result.exit_code != 0


class TestRotateKey:
    def test_rotate_key(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(
            cli, ["keys", "rotate", "--algorithm", "Kyber768"]
        )
        assert result.exit_code == 0
        assert "Rotated Kyber768" in result.output
        assert "v3" in result.output  # old
        assert "v4" in result.output  # new


class TestRetireKey:
    def test_retire_key_with_confirmation(self, configured_runner, temp_config, mock_keys_api):
        result = configured_runner.invoke(
            cli,
            ["keys", "retire", "--algorithm", "Kyber768", "--version", "2", "--yes"],
        )
        assert result.exit_code == 0
        assert "Retired" in result.output

    def test_retire_requires_version(self, configured_runner, temp_config):
        result = configured_runner.invoke(
            cli, ["keys", "retire", "--algorithm", "Kyber768"]
        )
        assert result.exit_code != 0
