"""Tests for encrypt/decrypt commands."""

from __future__ import annotations

from pathlib import Path

from qpher.cli.main import cli


class TestEncrypt:
    def test_encrypt_text(self, configured_runner, temp_config, mock_encrypt_api):
        result = configured_runner.invoke(
            cli, ["encrypt", "--text", "Hello World", "--key-version", "1"]
        )
        assert result.exit_code == 0
        assert "dGVzdF9jaXBoZXJ0ZXh0" in result.output

    def test_encrypt_file(self, configured_runner, temp_config, mock_encrypt_api, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello World")
        result = configured_runner.invoke(
            cli, ["encrypt", "--file", str(test_file), "--key-version", "1"]
        )
        assert result.exit_code == 0
        enc_file = Path(str(test_file) + ".enc")
        assert enc_file.exists()

    def test_encrypt_to_output_file(
        self, configured_runner, temp_config, mock_encrypt_api, tmp_path
    ):
        out_file = tmp_path / "output.enc"
        result = configured_runner.invoke(
            cli,
            ["encrypt", "--text", "Hello", "--key-version", "1", "--output", str(out_file)],
        )
        assert result.exit_code == 0
        assert out_file.exists()
        assert "dGVzdF9jaXBoZXJ0ZXh0" in out_file.read_text()

    def test_encrypt_both_text_and_file_error(self, configured_runner, temp_config, tmp_path):
        test_file = tmp_path / "test.txt"
        test_file.write_text("data")
        result = configured_runner.invoke(
            cli,
            ["encrypt", "--text", "hello", "--file", str(test_file), "--key-version", "1"],
        )
        assert result.exit_code != 0
        assert "not both" in result.output

    def test_encrypt_neither_text_nor_file_error(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["encrypt", "--key-version", "1"])
        assert result.exit_code != 0
        assert "--text or --file" in result.output

    def test_encrypt_requires_key_version(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["encrypt", "--text", "hello"])
        assert result.exit_code != 0

    def test_encrypt_deterministic_requires_salt(self, configured_runner, temp_config):
        result = configured_runner.invoke(
            cli,
            ["encrypt", "--text", "hello", "--key-version", "1", "--mode", "deterministic"],
        )
        assert result.exit_code != 0
        assert "salt" in result.output.lower()

    def test_encrypt_no_auth_error(self, cli_runner, temp_config):
        result = cli_runner.invoke(
            cli, ["encrypt", "--text", "hello", "--key-version", "1"]
        )
        assert result.exit_code != 0
        assert "No API key" in result.output

    def test_encrypt_shows_metadata(self, configured_runner, temp_config, mock_encrypt_api):
        result = configured_runner.invoke(
            cli, ["encrypt", "--text", "Hello", "--key-version", "1"]
        )
        assert "Kyber768" in result.output
        assert "key_version" in result.output

    def test_encrypt_large_file_error(self, configured_runner, temp_config, tmp_path):
        # Create a file larger than 10MB
        large_file = tmp_path / "large.bin"
        large_file.write_bytes(b"x" * (11 * 1024 * 1024))
        result = configured_runner.invoke(
            cli, ["encrypt", "--file", str(large_file), "--key-version", "1"]
        )
        assert result.exit_code != 0
        assert "too large" in result.output.lower()


class TestDecrypt:
    def test_decrypt_text(self, configured_runner, temp_config, mock_decrypt_api):
        result = configured_runner.invoke(
            cli, ["decrypt", "--text", "dGVzdF9jaXBoZXJ0ZXh0", "--key-version", "1"]
        )
        assert result.exit_code == 0
        assert "Hello World" in result.output

    def test_decrypt_file(self, configured_runner, temp_config, mock_decrypt_api, tmp_path):
        enc_file = tmp_path / "test.txt.enc"
        enc_file.write_text("dGVzdF9jaXBoZXJ0ZXh0")
        result = configured_runner.invoke(
            cli, ["decrypt", "--file", str(enc_file), "--key-version", "1"]
        )
        assert result.exit_code == 0
        decrypted_file = tmp_path / "test.txt"
        assert decrypted_file.exists()

    def test_decrypt_to_output_file(
        self, configured_runner, temp_config, mock_decrypt_api, tmp_path
    ):
        out_file = tmp_path / "decrypted.txt"
        result = configured_runner.invoke(
            cli,
            [
                "decrypt",
                "--text",
                "dGVzdF9jaXBoZXJ0ZXh0",
                "--key-version",
                "1",
                "--output",
                str(out_file),
            ],
        )
        assert result.exit_code == 0
        assert out_file.exists()

    def test_decrypt_both_text_and_file_error(self, configured_runner, temp_config, tmp_path):
        enc_file = tmp_path / "test.enc"
        enc_file.write_text("ciphertext")
        result = configured_runner.invoke(
            cli,
            [
                "decrypt",
                "--text",
                "cipher",
                "--file",
                str(enc_file),
                "--key-version",
                "1",
            ],
        )
        assert result.exit_code != 0

    def test_decrypt_requires_key_version(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["decrypt", "--text", "cipher"])
        assert result.exit_code != 0
