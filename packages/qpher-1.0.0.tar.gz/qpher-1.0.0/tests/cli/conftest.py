"""Test fixtures for Qpher CLI tests."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
import responses
from click.testing import CliRunner


API_BASE = "https://api.qpher.ai"
TEST_API_KEY = "qph_test_key_1234567890abcdef"


@pytest.fixture
def temp_config(tmp_path, monkeypatch):
    """Temp config directory for tests."""
    config_dir = tmp_path / ".qpher"
    monkeypatch.setattr("qpher.cli.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("qpher.cli.config.CONFIG_FILE", config_dir / "config.toml")
    return config_dir


@pytest.fixture
def cli_runner():
    """Click test runner."""
    return CliRunner()


@pytest.fixture
def configured_runner(cli_runner, temp_config, monkeypatch):
    """CLI runner with API key pre-configured."""
    monkeypatch.setenv("QPHER_API_KEY", TEST_API_KEY)
    return cli_runner


def make_api_response(data: dict, request_id: str = "test-req-001") -> dict:
    """Build standard API success envelope."""
    return {
        "data": data,
        "request_id": request_id,
        "timestamp": "2026-02-17T10:00:00Z",
    }


def make_error_response(
    error_code: str, message: str, request_id: str = "test-req-err"
) -> dict:
    """Build standard API error envelope."""
    return {
        "error": {"error_code": error_code, "message": message},
        "request_id": request_id,
        "timestamp": "2026-02-17T10:00:00Z",
    }


@pytest.fixture
def mock_encrypt_api():
    """Mock KEM encrypt endpoint."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/kem/encrypt",
            json=make_api_response({
                "ciphertext": "dGVzdF9jaXBoZXJ0ZXh0",
                "key_version": 1,
                "algorithm": "Kyber768",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_decrypt_api():
    """Mock KEM decrypt endpoint."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/kem/decrypt",
            json=make_api_response({
                "plaintext": "SGVsbG8gV29ybGQ=",  # "Hello World"
                "key_version": 1,
                "algorithm": "Kyber768",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_sign_api():
    """Mock signature sign endpoint."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/signature/sign",
            json=make_api_response({
                "signature": "c2lnbmF0dXJlX2RhdGE=",
                "key_version": 1,
                "algorithm": "Dilithium3",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_verify_valid_api():
    """Mock signature verify endpoint — valid signature."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/signature/verify",
            json=make_api_response({
                "valid": True,
                "key_version": 1,
                "algorithm": "Dilithium3",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_verify_invalid_api():
    """Mock signature verify endpoint — invalid signature."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/signature/verify",
            json=make_api_response({
                "valid": False,
                "key_version": 1,
                "algorithm": "Dilithium3",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_keys_api():
    """Mock KMS endpoints."""
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(
            responses.GET,
            f"{API_BASE}/api/v1/kms/keys",
            json=make_api_response({
                "keys": [
                    {
                        "key_version": 3,
                        "algorithm": "Kyber768",
                        "status": "active",
                        "created_at": "2026-02-17T10:00:00Z",
                    },
                    {
                        "key_version": 2,
                        "algorithm": "Kyber768",
                        "status": "retired",
                        "created_at": "2026-02-10T10:00:00Z",
                    },
                    {
                        "key_version": 1,
                        "algorithm": "Dilithium3",
                        "status": "active",
                        "created_at": "2026-02-01T10:00:00Z",
                    },
                ],
                "total": 3,
            }),
            status=200,
        )
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/kms/keys/generate",
            json=make_api_response({
                "public_key": "ABCDEF1234567890" * 4,
                "key_version": 4,
                "algorithm": "Kyber768",
                "status": "active",
            }),
            status=200,
        )
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/kms/keys/rotate",
            json=make_api_response({
                "public_key": "NEWKEY1234567890" * 4,
                "key_version": 4,
                "old_key_version": 3,
                "algorithm": "Kyber768",
            }),
            status=200,
        )
        rsps.add(
            responses.POST,
            f"{API_BASE}/api/v1/kms/keys/retire",
            json=make_api_response({
                "key_version": 2,
                "status": "retired",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_status_api():
    """Mock tenants/me endpoint."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            f"{API_BASE}/api/v1/tenants/me",
            json=make_api_response({
                "tenant_name": "My Company",
                "plan": {"name": "Growth", "price": "$179/mo"},
                "usage": {
                    "api_calls": 12450,
                    "kem_keys": 3,
                    "sig_keys": 2,
                    "api_keys": 2,
                },
                "limits": {
                    "api_calls": 30000,
                    "kem_keys": 5,
                    "sig_keys": 5,
                    "api_keys": 5,
                },
                "renews_at": "2026-03-17T00:00:00Z",
            }),
            status=200,
        )
        yield rsps


@pytest.fixture
def mock_401_api():
    """Mock 401 unauthorized."""
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.GET,
            f"{API_BASE}/api/v1/kms/keys",
            json=make_error_response("ERR_AUTH_001", "Invalid API key"),
            status=401,
        )
        yield rsps
