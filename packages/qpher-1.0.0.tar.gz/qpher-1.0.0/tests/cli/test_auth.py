"""Tests for auth commands."""

from __future__ import annotations

from qpher.cli.main import cli


class TestSetKey:
    def test_saves_valid_key(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["auth", "set-key", "qph_valid_key_1234567890"])
        assert result.exit_code == 0
        assert "API key saved" in result.output

    def test_rejects_invalid_format(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["auth", "set-key", "invalid_key"])
        assert result.exit_code != 0
        assert "Invalid API key format" in result.output

    def test_rejects_short_key(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["auth", "set-key", "qph_short"])
        assert result.exit_code != 0

    def test_key_persisted_to_file(self, cli_runner, temp_config):
        cli_runner.invoke(cli, ["auth", "set-key", "qph_persist_key_12345"])
        config_file = temp_config / "config.toml"
        assert config_file.exists()
        content = config_file.read_text()
        assert "qph_persist_key_12345" in content


class TestWhoami:
    def test_shows_configured_key(self, configured_runner, temp_config):
        result = configured_runner.invoke(cli, ["auth", "whoami"])
        assert result.exit_code == 0
        assert "qph_test" in result.output

    def test_error_when_no_key(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["auth", "whoami"])
        assert result.exit_code != 0
        assert "No API key configured" in result.output


class TestLogout:
    def test_removes_key(self, cli_runner, temp_config):
        # First set a key
        cli_runner.invoke(cli, ["auth", "set-key", "qph_logout_test_1234"])
        # Then logout
        result = cli_runner.invoke(cli, ["auth", "logout"])
        assert result.exit_code == 0
        assert "removed" in result.output

    def test_logout_without_key(self, cli_runner, temp_config):
        result = cli_runner.invoke(cli, ["auth", "logout"])
        assert result.exit_code == 0
        assert "No API key" in result.output
