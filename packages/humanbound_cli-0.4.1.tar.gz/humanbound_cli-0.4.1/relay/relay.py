"""
Humanbound Relay Service

Lightweight reverse-proxy tunnel that bridges HTTP requests to WebSocket-connected
CLI clients. The backend probes a user's locally-running bot by sending HTTP requests
to the relay, which forwards them through the WebSocket to the CLI, which forwards
to localhost.

Flow:
    CLI ──WSS──> Relay <──HTTP── Backend (probe)
    CLI ──HTTP──> localhost:8000 (user's bot)

Deployment:
    uvicorn relay:app --host 0.0.0.0 --port 8080

Environment variables:
    AUTH0_DOMAIN        Auth0 tenant domain (default: aiandme.eu.auth0.com)
    AUTH0_AUDIENCE      Auth0 API audience (default: https://api.aiandme.io/api)
    RELAY_PUBLIC_BASE   Public base URL (default: https://relay.humanbound.ai)
    TUNNEL_TTL_SECONDS  Max tunnel lifetime (default: 900 = 15 min)
    REQUEST_TIMEOUT     Per-request timeout in seconds (default: 60)
"""

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Response
from fastapi.responses import JSONResponse
import jwt
from jwt import PyJWKClient

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

AUTH0_DOMAIN = os.getenv("AUTH0_DOMAIN", "aiandme.eu.auth0.com")
# Comma-separated audiences (accept both staging and production tokens)
AUTH0_AUDIENCE = os.getenv("AUTH0_AUDIENCE", "https://api.aiandme.io/api,https://staging.api.aiandme.io/api")
RELAY_PUBLIC_BASE = os.getenv("RELAY_PUBLIC_BASE", "https://relay.humanbound.ai")
TUNNEL_TTL_SECONDS = int(os.getenv("TUNNEL_TTL_SECONDS", "900"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "60"))
SKIP_AUTH = os.getenv("RELAY_SKIP_AUTH", "").lower() in ("1", "true")  # local dev only
PING_INTERVAL = 30  # seconds

JWKS_URL = f"https://{AUTH0_DOMAIN}/.well-known/jwks.json"
ALGORITHMS = ["RS256"]

log = logging.getLogger("relay")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


@dataclass
class Tunnel:
    """An active CLI tunnel connection."""

    client_id: str
    ws: WebSocket
    created_at: float = field(default_factory=time.time)
    pending: dict[str, asyncio.Future] = field(default_factory=dict)


# client_id → Tunnel
tunnels: dict[str, Tunnel] = {}

# JWKS client (cached)
jwks_client: Optional[PyJWKClient] = None


def _get_jwks_client() -> PyJWKClient:
    global jwks_client
    if jwks_client is None:
        jwks_client = PyJWKClient(JWKS_URL, cache_keys=True)
    return jwks_client


# ---------------------------------------------------------------------------
# JWT Validation
# ---------------------------------------------------------------------------


def validate_token(token: str) -> Optional[dict]:
    """Validate a JWT against Auth0 JWKS. Returns claims or None.

    Tries each configured audience (staging + production) since CLI clients
    may authenticate against either environment.
    """
    audiences = [a.strip() for a in AUTH0_AUDIENCE.split(",") if a.strip()]
    client = _get_jwks_client()

    try:
        signing_key = client.get_signing_key_from_jwt(token)
    except Exception as e:
        log.warning("JWT validation failed (JWKS): %s", e)
        return None

    for aud in audiences:
        try:
            claims = jwt.decode(
                token,
                signing_key.key,
                algorithms=ALGORITHMS,
                audience=aud,
                issuer=f"https://{AUTH0_DOMAIN}/",
            )
            return claims
        except jwt.InvalidAudienceError:
            continue
        except Exception as e:
            log.warning("JWT validation failed: %s", e)
            return None

    log.warning("JWT validation failed: audience mismatch (tried %s)", audiences)
    return None


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------


async def cleanup_stale_tunnels():
    """Remove tunnels that have exceeded their TTL."""
    now = time.time()
    stale = [
        cid
        for cid, t in tunnels.items()
        if now - t.created_at > TUNNEL_TTL_SECONDS
    ]
    for cid in stale:
        tunnel = tunnels.pop(cid, None)
        if tunnel:
            log.info("Expiring tunnel %s (TTL exceeded)", cid)
            # Cancel any pending requests
            for fut in tunnel.pending.values():
                if not fut.done():
                    fut.set_exception(TimeoutError("Tunnel expired"))
            try:
                await tunnel.ws.close(1000, "Tunnel TTL expired")
            except Exception:
                pass


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------

app = FastAPI(title="Humanbound Relay", docs_url=None, redoc_url=None)


@app.get("/health")
async def health():
    return {"status": "ok", "tunnels": len(tunnels)}


# ---------------------------------------------------------------------------
# WebSocket Tunnel Endpoint
# ---------------------------------------------------------------------------


@app.websocket("/tunnel")
async def tunnel_endpoint(ws: WebSocket):
    """Accept a CLI tunnel connection."""

    # Authenticate via Authorization header
    if SKIP_AUTH:
        claims = {"sub": "local-dev"}
    else:
        auth_header = ws.headers.get("authorization", "")
        if not auth_header.startswith("Bearer "):
            await ws.close(4001, "Missing Authorization header")
            return

        token = auth_header[7:]
        claims = validate_token(token)
        if claims is None:
            await ws.close(4003, "Invalid token")
            return

    await ws.accept()

    # Wait for registration message
    try:
        raw = await asyncio.wait_for(ws.receive_text(), timeout=15)
        msg = json.loads(raw)
    except Exception:
        await ws.close(4000, "Expected register message")
        return

    if msg.get("type") != "register":
        await ws.send_text(json.dumps({
            "type": "error",
            "message": "Expected register message",
        }))
        await ws.close(4000)
        return

    # Create tunnel
    client_id = uuid.uuid4().hex[:12]
    public_url = f"{RELAY_PUBLIC_BASE}/t/{client_id}"
    tunnel = Tunnel(client_id=client_id, ws=ws)
    tunnels[client_id] = tunnel

    log.info("Tunnel registered: %s (user: %s)", client_id, claims.get("sub", "?"))

    # Send registration confirmation
    await ws.send_text(json.dumps({
        "type": "registered",
        "public_url": public_url,
    }))

    # Main loop: read responses from CLI, dispatch pings
    try:
        last_ping = time.time()

        while True:
            # Periodic cleanup + ping
            now = time.time()
            if now - last_ping > PING_INTERVAL:
                await ws.send_text(json.dumps({"type": "ping"}))
                last_ping = now
                await cleanup_stale_tunnels()

            # Read message from CLI (non-blocking with timeout for ping loop)
            try:
                raw = await asyncio.wait_for(ws.receive_text(), timeout=5)
            except asyncio.TimeoutError:
                continue

            try:
                msg = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                continue

            msg_type = msg.get("type")

            if msg_type == "response":
                # Resolve pending HTTP request
                req_id = msg.get("id")
                fut = tunnel.pending.pop(req_id, None)
                if fut and not fut.done():
                    fut.set_result(msg)

            elif msg_type == "pong":
                pass  # keepalive acknowledged

    except WebSocketDisconnect:
        log.info("Tunnel disconnected: %s", client_id)
    except Exception as e:
        log.warning("Tunnel error %s: %s", client_id, e)
    finally:
        # Cancel any pending requests
        for fut in tunnel.pending.values():
            if not fut.done():
                fut.set_exception(ConnectionError("Tunnel disconnected"))
        tunnels.pop(client_id, None)


# ---------------------------------------------------------------------------
# HTTP Proxy Endpoint
# ---------------------------------------------------------------------------


@app.api_route(
    "/t/{client_id}/{path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
)
async def proxy(client_id: str, path: str, request: Request):
    """Forward an HTTP request through the tunnel to the CLI's local server."""

    tunnel = tunnels.get(client_id)
    if not tunnel:
        return JSONResponse(
            {"error": "Tunnel not found or expired"},
            status_code=502,
        )

    # Build request message
    req_id = uuid.uuid4().hex[:16]
    body = await request.body()

    req_msg = {
        "type": "request",
        "id": req_id,
        "method": request.method,
        "path": f"/{path}" if not path.startswith("/") else path,
        "headers": dict(request.headers),
        "body": body.decode("utf-8", errors="replace") if body else None,
    }

    # Create a future for the response
    fut: asyncio.Future = asyncio.get_event_loop().create_future()
    tunnel.pending[req_id] = fut

    # Send through WebSocket
    try:
        await tunnel.ws.send_text(json.dumps(req_msg))
    except Exception:
        tunnel.pending.pop(req_id, None)
        return JSONResponse(
            {"error": "Failed to send to tunnel"},
            status_code=502,
        )

    # Wait for response
    try:
        resp_msg = await asyncio.wait_for(fut, timeout=REQUEST_TIMEOUT)
    except asyncio.TimeoutError:
        tunnel.pending.pop(req_id, None)
        return JSONResponse(
            {"error": "Tunnel request timed out"},
            status_code=504,
        )
    except (ConnectionError, Exception) as e:
        tunnel.pending.pop(req_id, None)
        return JSONResponse(
            {"error": f"Tunnel error: {e}"},
            status_code=502,
        )

    # Build HTTP response
    status = resp_msg.get("status", 200)
    resp_headers = resp_msg.get("headers", {})
    resp_body = resp_msg.get("body", "")

    # Filter hop-by-hop headers
    skip_headers = {"transfer-encoding", "connection", "keep-alive"}
    filtered = {
        k: v
        for k, v in resp_headers.items()
        if k.lower() not in skip_headers
    }

    return Response(
        content=resp_body,
        status_code=status,
        headers=filtered,
    )
