# Removed - scan functionality moved to init --endpoint
