"""Platform connectors for AI service discovery."""
