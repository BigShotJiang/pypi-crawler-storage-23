from maxo.types.base import MaxoType


class VideoThumbnail(MaxoType):
    """
    Args:
        url: URL изображения
    """

    url: str
    """URL изображения"""
