from maxo.types.base import MaxoType


class MessageStat(MaxoType):
    """
    Статистика сообщения

    Args:
        views:
    """

    views: int
