from logging import getLogger

dispatcher = getLogger("maxo.dispatcher")
long_polling = getLogger("maxo.long_polling")
update_context = getLogger("maxo.routing.update_context")
utils = getLogger("maxo.utils")
bot_session = getLogger("maxo.bot.session")
