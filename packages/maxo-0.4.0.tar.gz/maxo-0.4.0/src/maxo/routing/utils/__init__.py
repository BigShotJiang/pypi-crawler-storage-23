from maxo.routing.utils.collect_used_updates import collect_used_updates

__all__ = ("collect_used_updates",)
