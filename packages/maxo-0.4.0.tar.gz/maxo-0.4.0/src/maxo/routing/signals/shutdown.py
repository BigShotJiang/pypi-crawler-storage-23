from maxo.routing.signals.base import BaseSignal


class BeforeShutdown(BaseSignal):
    pass


class AfterShutdown(BaseSignal):
    pass
