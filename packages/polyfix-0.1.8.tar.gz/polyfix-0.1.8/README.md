# polyfix

### Geometry conventions

- Polygonal domains can be specified using coordinate in either a clockwise or counterclockwise direction.
- After the coordinates are normalized, they will have a clockwise direction, starting from the bottom left. This comes from Shapely's defaults for normalizing
