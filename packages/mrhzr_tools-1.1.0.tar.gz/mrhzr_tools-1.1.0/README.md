# mrhzr-tools

習作を兼ねた使い回し用のツール群。

Reusable utility tools developed for learning purposes.

## インストール方法 / Installation
```bash
pip install mrhzr-tools
```

## 構成 / Structure

以下の構成図に示す通り、各モジュールは `mrhzr.tools` ディレクトリ配下に整理されています。

Modules are organized under the `mrhzr.tools` directory, as shown in the structure below:

```
└── 📁mrhzr
    └── 📁tools
        ├── __init__.py
        ├── config_manager.py
        └── log.py
```

## 使用方法 / Usage

### config_manager

YAML 形式のコンフィグファイルを読み込み、セクションごとの設定を返す。
コンフィグファイルの読み込みは一度だけ。

Reads YAML config files and retrieves settings for each section.
Load the configuration file only once.

```python
from mrhzr.tools import config_manager

config_manager.init_config("config.yaml")

config = config_manager.get_config("section", default=None)

```

### log

システム全体のログの管理。

Centralized system logging.

```python
from mrhzr.tools import log

# if config=None, use config_manager.get_config("logging", None)
log.init_log(config=None)

logger = log.get_logger(__name__)
```

## 依存関係 / Requirements

このパッケージは以下の環境での動作確認をしています:

Confirmed to work in the following environments:
- Python 3.8+
- PyYAML 6.0.3+

## ライセンス / License

このライブラリは [MIT ライセンス](LICENSE)のもとで公開されています。

This library is released under the [MIT License](LICENSE).