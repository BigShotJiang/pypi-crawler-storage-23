import logging
import logging.config

from . import config_manager

def init_log(config=None):
    """ログの初期設定"""
    try:
        if config is None:
            config = config_manager.get_config("logging", None)
        logging.config.dictConfig(config)
        logging.info("Success dictConfig")
    except Exception as e:
        logging.basicConfig(level=logging.WARNING)
        logging.error(f"Failed to apply dictConfig: {e}")

def get_logger(name: str):
    """ロガーの取得"""
    return logging.getLogger(name)