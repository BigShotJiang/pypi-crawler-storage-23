import yaml
from pathlib import Path

_config = None

def init_config(path="config.yaml"):
    """コンフィグファイル（yaml）を読み込む"""
    global _config

    cf_path = Path(path)

    if not cf_path.exists():
        print(f"Error: Config file is not found at {cf_path.absolute()}")
        _config = {}
        return _config

    try:
        with cf_path.open('r', encoding="utf-8") as f:
            _config = yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        print(f"Error: YAML parse failed: {e}")
        _config = {}
    except Exception as e:
        print(f"Error: Unexpected error: {e}")
        _config = {}
    
    return _config

def get_config(section=None, default=None):
    """コンフィグを取得する"""
    global _config

    if _config is None:
        init_config()

    if section:
        return _config.get(section, default)
    
    return _config
