"""Core abstractions for LangCore.

This package contains the foundational base models and types used throughout
LangCore. Each module can be imported independently for fine-grained
dependency management in build systems.
"""

from __future__ import annotations

__all__ = [
    "base_model",
    "data",
    "exceptions",
    "schema",
    "tokenizer",
    "types",
]
