"""Generate the code for conversion from and to Protocol Buffers."""
