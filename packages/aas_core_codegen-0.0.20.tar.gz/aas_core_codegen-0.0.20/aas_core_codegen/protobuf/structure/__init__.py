"""Generate C# data structures to represent an AAS."""

from aas_core_codegen.protobuf.structure import _generate

verify = _generate.verify
generate = _generate.generate
