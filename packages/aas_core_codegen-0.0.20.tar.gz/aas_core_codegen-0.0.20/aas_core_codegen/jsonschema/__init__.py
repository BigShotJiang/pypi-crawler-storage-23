"""Generate JSON schema corresponding to the meta-model."""
