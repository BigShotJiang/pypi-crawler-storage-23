"""Run a smoke-test as a preliminary test that a meta-model is ready for generation."""
