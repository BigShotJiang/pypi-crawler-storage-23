"""Generate Java code for enhancing model classes."""
from aas_core_codegen.java.enhancing import _generate

generate = _generate.generate
