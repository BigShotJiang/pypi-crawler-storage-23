"""Generate Java code for de/serialization of AAS classes from and to XML."""
from aas_core_codegen.java.xmlization import _generate

generate = _generate.generate
