"""Generate builders for the AAS data structures."""

from aas_core_codegen.java.generation import _generate

generate = _generate.generate
