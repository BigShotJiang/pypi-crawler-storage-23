"""Generate java code for reporting errors."""
from aas_core_codegen.java.reporting import _generate

generate = _generate.generate
