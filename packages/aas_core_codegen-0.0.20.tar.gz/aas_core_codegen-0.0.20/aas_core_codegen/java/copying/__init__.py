"""Generate Java code for making shallow and deep copies."""
from aas_core_codegen.java.copying import _generate

generate = _generate.generate
