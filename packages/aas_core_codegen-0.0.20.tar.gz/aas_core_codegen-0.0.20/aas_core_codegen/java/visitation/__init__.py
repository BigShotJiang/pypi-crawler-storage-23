"""Generate the Java code for visiting the model instances."""

from aas_core_codegen.java.visitation import _generate

generate = _generate.generate
