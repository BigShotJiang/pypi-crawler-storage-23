"""Generate JSON-LD context corresponding to the meta-model."""
