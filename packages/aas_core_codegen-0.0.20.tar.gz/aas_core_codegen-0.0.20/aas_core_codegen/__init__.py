"""Generate implementations and schemas based on an AAS meta-model."""

__version__ = "0.0.20"
__author__ = "Marko Ristin, Nico Braunisch"
__license__ = "License :: OSI Approved :: MIT License"
__status__ = "Production/Stable"
