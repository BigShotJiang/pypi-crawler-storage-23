"""Generate C++ code for common functions."""

from aas_core_codegen.cpp.aas_common import _generate

generate_header = _generate.generate_header
generate_implementation = _generate.generate_implementation
