"""Generate the Golang code for de/serialization of AAS classes from and to XML."""
from aas_core_codegen.golang.xmlization import _generate

generate = _generate.generate
