"""Generate Golang code for de-serialization of enumerations from strings."""
from aas_core_codegen.golang.stringification import _generate

generate = _generate.generate
