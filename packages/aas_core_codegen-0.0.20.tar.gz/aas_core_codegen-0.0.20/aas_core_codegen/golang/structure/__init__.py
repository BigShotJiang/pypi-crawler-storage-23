"""Generate Golang data structures to represent, iterate and transform an AAS."""

from aas_core_codegen.golang.structure import _generate

verify = _generate.verify
generate = _generate.generate
