"""Generate Golang code for reporting errors."""
from aas_core_codegen.golang.reporting import _generate

generate = _generate.generate
