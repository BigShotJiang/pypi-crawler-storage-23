"""
JSONL (JSON Lines) output format handler
"""

import json
from typing import Dict, Any, Iterator, TextIO

from .base import OutputFormat


class JSONLFormat(OutputFormat):
    """Handler for JSONL (JSON Lines) output format"""

    def __init__(self, file_handle: TextIO, **kwargs):
        super().__init__(file_handle)
        # Ignore kwargs - JSONL doesn't need additional options

    def write_row(self, row: Dict[str, Any]) -> None:
        """Write a single row as a JSON line"""
        # Remove _row_num column if present (internal use)
        if '_row_num' in row:
            row = {k: v for k, v in row.items() if k != '_row_num'}

        self.file_handle.write(json.dumps(row, ensure_ascii=False) + '\n')
        self._row_count += 1

    def write_rows(self, rows: Iterator[Dict[str, Any]]) -> int:
        """Write multiple rows as JSON lines"""
        count = 0
        for row in rows:
            self.write_row(row)
            count += 1
        return count

    def finalize(self) -> None:
        """No finalization needed for JSONL"""
        pass
