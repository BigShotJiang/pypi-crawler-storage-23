"""
JSON output format handler
"""

import json
from typing import Dict, Any, Iterator, TextIO

from .base import OutputFormat


class JSONFormat(OutputFormat):
    """Handler for JSON array output format"""

    def __init__(self, file_handle: TextIO, **kwargs):
        super().__init__(file_handle)
        self._first_row = True
        # Ignore kwargs - JSON doesn't need additional options

    def write_row(self, row: Dict[str, Any]) -> None:
        """Write a single row to JSON array"""
        # Remove _row_num column if present
        if '_row_num' in row:
            row = {k: v for k, v in row.items() if k != '_row_num'}

        # Start array on first row
        if self._first_row:
            self.file_handle.write('[\n')
            self._first_row = False
        else:
            self.file_handle.write(',\n')

        self.file_handle.write('  ' + json.dumps(row, ensure_ascii=False))
        self._row_count += 1

    def write_rows(self, rows: Iterator[Dict[str, Any]]) -> int:
        """Write multiple rows to JSON array"""
        count = 0
        for row in rows:
            self.write_row(row)
            count += 1
        return count

    def finalize(self) -> None:
        """Close the JSON array"""
        if self._first_row:
            # No rows written, write empty array
            self.file_handle.write('[]')
        else:
            self.file_handle.write('\n]')
