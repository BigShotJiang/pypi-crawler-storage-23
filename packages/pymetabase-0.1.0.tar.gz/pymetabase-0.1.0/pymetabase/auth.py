"""
Authentication module for Metabase
"""

import logging
import requests
from typing import Optional, Dict, TYPE_CHECKING

from .exceptions import AuthenticationError, ConnectionError

if TYPE_CHECKING:
    from .remotes import RemoteManager

logger = logging.getLogger(__name__)


class MetabaseAuth:
    """Handles authentication with Metabase server"""

    def __init__(
        self,
        url: str,
        username: str,
        password: str,
        timeout: int = 30,
        remote_name: Optional[str] = None,
        remote_manager: Optional["RemoteManager"] = None,
    ):
        self.url = url.rstrip('/')
        self.username = username
        self.password = password
        self.timeout = timeout
        self.session_token: Optional[str] = None
        self._remote_name = remote_name
        self._remote_manager = remote_manager

        # Warn if using HTTP (credentials sent in cleartext)
        if self.url.startswith('http://'):
            logger.warning(
                "Using HTTP (not HTTPS). Credentials will be sent in cleartext. "
                "Consider using HTTPS for security."
            )

    def _try_stored_token(self) -> bool:
        """
        Try to use a stored token if available and valid.

        Returns:
            True if stored token is valid, False otherwise
        """
        if not self._remote_manager or not self._remote_name:
            return False

        stored_token = self._remote_manager.get_token(self._remote_name)
        if not stored_token:
            logger.debug("No stored token found")
            return False

        # Validate the stored token
        self.session_token = stored_token
        if self.validate_session():
            logger.info("Using stored session token")
            return True

        # Token is invalid, clear it
        logger.debug("Stored token is invalid, will re-authenticate")
        self.session_token = None
        self._remote_manager.clear_token(self._remote_name)
        return False

    def _save_token(self) -> None:
        """Save current token to storage if remote manager is configured"""
        if self._remote_manager and self._remote_name and self.session_token:
            self._remote_manager.save_token(self._remote_name, self.session_token)
            logger.debug("Session token saved for reuse")

    def login(self) -> str:
        """
        Authenticate with Metabase and get session token.

        First tries to use a stored token if available and valid.
        Falls back to username/password authentication if needed.

        Returns:
            Session token string

        Raises:
            AuthenticationError: If authentication fails
            ConnectionError: If cannot connect to server
        """
        # Try stored token first
        if self._try_stored_token():
            return self.session_token

        # Fall back to username/password authentication
        try:
            response = requests.post(
                f"{self.url}/api/session",
                json={
                    "username": self.username,
                    "password": self.password
                },
                timeout=self.timeout
            )

            if response.status_code == 200:
                self.session_token = response.json().get('id')
                logger.info("Successfully authenticated with Metabase")
                # Save token for future use
                self._save_token()
                return self.session_token
            else:
                try:
                    error_data = response.json()
                    error_msg = error_data.get('errors', {}).get('password', 'Invalid credentials')
                except (ValueError, KeyError):
                    error_msg = f"HTTP {response.status_code}"
                logger.error(f"Authentication failed: {error_msg}")
                raise AuthenticationError(f"Authentication failed: {error_msg}")

        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            raise ConnectionError(f"Failed to connect to Metabase at {self.url}: {e}")
        except requests.exceptions.Timeout as e:
            logger.error(f"Connection timeout: {e}")
            raise ConnectionError(f"Connection timeout to {self.url}: {e}")

    def logout(self, clear_stored_token: bool = True) -> None:
        """
        Logout and invalidate session token.

        Args:
            clear_stored_token: Whether to clear the stored token as well (default: True).
                               If False, the session is kept alive on the server for reuse.
        """
        if self.session_token:
            # Only invalidate server session if we're also clearing the stored token
            # Otherwise keep the session alive for reuse
            if clear_stored_token:
                try:
                    requests.delete(
                        f"{self.url}/api/session",
                        headers=self.get_headers(),
                        timeout=self.timeout
                    )
                    logger.info("Successfully logged out")
                except Exception as e:
                    logger.warning(f"Error during logout: {e}")

                # Clear stored token
                if self._remote_manager and self._remote_name:
                    self._remote_manager.clear_token(self._remote_name)
                    logger.debug("Cleared stored session token")
            else:
                logger.debug("Keeping session alive for reuse")

            self.session_token = None

    def get_headers(self) -> Dict[str, str]:
        """Get headers with session token for API requests"""
        if not self.session_token:
            raise AuthenticationError("Not authenticated. Call login() first.")

        return {
            "X-Metabase-Session": self.session_token,
            "Content-Type": "application/json"
        }

    def is_authenticated(self) -> bool:
        """Check if currently authenticated"""
        return self.session_token is not None

    def ensure_authenticated(self) -> None:
        """Ensure we're authenticated, login if not"""
        if not self.is_authenticated():
            self.login()

    def validate_session(self) -> bool:
        """Validate that current session is still valid"""
        if not self.session_token:
            return False

        try:
            response = requests.get(
                f"{self.url}/api/user/current",
                headers=self.get_headers(),
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception:
            return False
