"""
Tests for main Metabase client
"""

import pytest
import json
import tempfile
import os
import requests
from unittest.mock import patch, Mock, MagicMock, call
from pathlib import Path

from pymetabase.client import Metabase, ExportResult
from pymetabase.exceptions import (
    DatabaseNotFoundError,
    AuthenticationError,
    QueryError,
    ChunkError,
    APIError,
    NotFoundError,
)


class TestMetabaseInit:
    """Tests for Metabase client initialization"""

    def test_init_with_direct_params(self):
        """Test initialization with direct parameters"""
        mb = Metabase(
            url="https://test.com",
            username="user",
            password="pass"
        )

        assert mb.config.url == "https://test.com"
        assert mb.config.username == "user"
        assert mb.config.password == "pass"

    def test_init_with_kwargs_override(self):
        """Test that kwargs override config defaults"""
        mb = Metabase(
            url="https://test.com",
            username="user",
            password="pass",
            chunk_size=100000,
            max_retries=5
        )

        assert mb.config.chunk_size == 100000
        assert mb.config.max_retries == 5

    def test_init_with_credentials_file(self):
        """Test initialization with credentials file"""
        creds = [{
            "SERVER_NAME": "https://cred.com",
            "USERNAME": "creduser",
            "PASSWORD": "credpass"
        }]

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(creds, f)
            f.flush()

            mb = Metabase(credentials_file=f.name)

            assert mb.config.url == "https://cred.com"
            assert mb.config.username == "creduser"

        os.unlink(f.name)


class TestMetabaseContextManager:
    """Tests for context manager functionality"""

    @patch('pymetabase.auth.MetabaseAuth.login')
    @patch('pymetabase.auth.MetabaseAuth.logout')
    def test_context_manager(self, mock_logout, mock_login):
        """Test context manager connects and disconnects"""
        mock_login.return_value = "test-token"

        mb = Metabase(
            url="https://test.com",
            username="user",
            password="pass"
        )

        with mb:
            mock_login.assert_called_once()

        mock_logout.assert_called_once()

    @patch('pymetabase.auth.MetabaseAuth.login')
    @patch('pymetabase.auth.MetabaseAuth.logout')
    def test_context_manager_returns_self(self, mock_logout, mock_login):
        """Test context manager returns client instance"""
        mock_login.return_value = "test-token"

        mb = Metabase(
            url="https://test.com",
            username="user",
            password="pass"
        )

        with mb as client:
            assert client is mb


class TestMetabaseDatabaseOperations:
    """Tests for database operations"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_list_databases(self, mock_get, mock_auth):
        """Test listing databases"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [
                {'id': 1, 'name': 'Database1'},
                {'id': 2, 'name': 'Database2'}
            ]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        databases = mb.list_databases()

        assert len(databases) == 2
        assert databases[0]['name'] == 'Database1'

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_list_databases_caching(self, mock_get, mock_auth):
        """Test that databases are cached"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [{'id': 1, 'name': 'DB1'}]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        # First call
        mb.list_databases()
        # Second call (should use cache)
        mb.list_databases()

        # Should only call API once
        assert mock_get.call_count == 1

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_list_databases_refresh(self, mock_get, mock_auth):
        """Test that refresh=True bypasses cache"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [{'id': 1, 'name': 'DB1'}]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        mb.list_databases()
        mb.list_databases(refresh=True)

        assert mock_get.call_count == 2

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_get_database_id_by_name(self, mock_get, mock_auth):
        """Test getting database ID by name"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [
                {'id': 1, 'name': 'TestDB'},
                {'id': 2, 'name': 'OtherDB'}
            ]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        db_id = mb.get_database_id("TestDB")

        assert db_id == 1

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_get_database_id_case_insensitive(self, mock_get, mock_auth):
        """Test that database name lookup is case insensitive"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [{'id': 1, 'name': 'TestDB'}]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        assert mb.get_database_id("testdb") == 1
        assert mb.get_database_id("TESTDB") == 1

    def test_get_database_id_by_int(self):
        """Test getting database ID when already an int"""
        mb = Metabase(url="https://test.com", username="user", password="pass")

        assert mb.get_database_id(42) == 42

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    def test_get_database_id_not_found(self, mock_get, mock_auth):
        """Test error when database not found"""
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [{'id': 1, 'name': 'Other'}]}
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"

        with pytest.raises(DatabaseNotFoundError):
            mb.get_database_id("NonExistent")


class TestExportTable:
    """Tests for export_table method"""

    @patch.object(Metabase, 'export')
    def test_export_table_basic(self, mock_export):
        """Test basic table export"""
        mock_export.return_value = ExportResult(
            total_rows=100,
            chunks=1,
            duration_seconds=1.0,
            output_file="test.jsonl",
            rate_per_second=100.0,
            format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")

        result = mb.export_table(
            table="users",
            output="users.jsonl",
            database="TestDB"
        )

        # Check the query passed to export
        call_kwargs = mock_export.call_args[1]
        assert "SELECT * FROM users" in call_kwargs['query']

    @patch.object(Metabase, 'export')
    def test_export_table_with_columns(self, mock_export):
        """Test table export with specific columns"""
        mock_export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.jsonl", rate_per_second=100.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")

        mb.export_table(
            table="users",
            output="users.jsonl",
            database="TestDB",
            columns=["id", "name", "email"]
        )

        call_kwargs = mock_export.call_args[1]
        assert "id, name, email" in call_kwargs['query']

    @patch.object(Metabase, 'export')
    def test_export_table_with_where(self, mock_export):
        """Test table export with WHERE clause"""
        mock_export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.jsonl", rate_per_second=100.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")

        mb.export_table(
            table="users",
            output="users.jsonl",
            database="TestDB",
            where="active = true"
        )

        call_kwargs = mock_export.call_args[1]
        assert "WHERE active = true" in call_kwargs['query']

    @patch.object(Metabase, 'export')
    def test_export_table_with_order_by(self, mock_export):
        """Test table export with ORDER BY"""
        mock_export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.jsonl", rate_per_second=100.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")

        mb.export_table(
            table="users",
            output="users.jsonl",
            database="TestDB",
            order_by="created_at DESC"
        )

        call_kwargs = mock_export.call_args[1]
        assert "ORDER BY created_at DESC" in call_kwargs['query']

    @patch.object(Metabase, 'export')
    def test_export_table_with_limit(self, mock_export):
        """Test table export with LIMIT"""
        mock_export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.jsonl", rate_per_second=100.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")

        mb.export_table(
            table="users",
            output="users.jsonl",
            database="TestDB",
            limit=1000
        )

        call_kwargs = mock_export.call_args[1]
        assert "LIMIT 1000" in call_kwargs['query']


class TestExportFormatDetection:
    """Tests for format auto-detection"""

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_bulk_export')
    def test_auto_detect_jsonl(self, mock_bulk, mock_count, mock_db, mock_conn):
        """Test auto-detection of JSONL format"""
        mock_db.return_value = 1
        mock_count.return_value = 100
        mock_bulk.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.jsonl", rate_per_second=100.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb.export(query="SELECT * FROM test", output="test.jsonl", database=1)

        # Check format passed to bulk export
        call_args = mock_bulk.call_args[0]
        assert call_args[3] == "jsonl"

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_bulk_export')
    def test_auto_detect_csv(self, mock_bulk, mock_count, mock_db, mock_conn):
        """Test auto-detection of CSV format"""
        mock_db.return_value = 1
        mock_count.return_value = 100
        mock_bulk.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="test.csv", rate_per_second=100.0, format="csv"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb.export(query="SELECT * FROM test", output="test.csv", database=1)

        call_args = mock_bulk.call_args[0]
        assert call_args[3] == "csv"


class TestChunkingDecision:
    """Tests for chunking decision logic"""

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_bulk_export')
    def test_bulk_export_under_threshold(self, mock_bulk, mock_count, mock_db, mock_conn):
        """Test that bulk export is used when under threshold"""
        mock_db.return_value = 1
        mock_count.return_value = 500000  # Under default 1M threshold
        mock_bulk.return_value = ExportResult(
            total_rows=500000, chunks=1, duration_seconds=10.0,
            output_file="test.jsonl", rate_per_second=50000.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb.export(query="SELECT * FROM test", output="test.jsonl", database=1)

        mock_bulk.assert_called_once()

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_chunked_export')
    def test_chunked_export_over_threshold(self, mock_chunked, mock_count, mock_db, mock_conn):
        """Test that chunked export is used when over threshold"""
        mock_db.return_value = 1
        mock_count.return_value = 2000000  # Over default 1M threshold
        mock_chunked.return_value = ExportResult(
            total_rows=2000000, chunks=4, duration_seconds=60.0,
            output_file="test.jsonl", rate_per_second=33333.0, format="jsonl"
        )

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb.export(query="SELECT * FROM test", output="test.jsonl", database=1)

        mock_chunked.assert_called_once()


class TestExportResult:
    """Tests for ExportResult dataclass"""

    def test_export_result_fields(self):
        """Test ExportResult has correct fields"""
        result = ExportResult(
            total_rows=1000,
            chunks=2,
            duration_seconds=5.5,
            output_file="output.jsonl",
            rate_per_second=181.8,
            format="jsonl"
        )

        assert result.total_rows == 1000
        assert result.chunks == 2
        assert result.duration_seconds == 5.5
        assert result.output_file == "output.jsonl"
        assert result.rate_per_second == 181.8
        assert result.format == "jsonl"


class TestCheckpointResume:
    """Tests for checkpoint and resume functionality"""

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_export_chunk_with_retry')
    def test_checkpoint_created(self, mock_chunk, mock_count, mock_db, mock_conn):
        """Test that checkpoint file is created during export"""
        mock_db.return_value = 1
        mock_count.return_value = 1500000  # Will need 3 chunks
        mock_chunk.return_value = 500000

        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "output.jsonl")
            checkpoint_file = os.path.join(tmpdir, "checkpoint.json")

            mb = Metabase(url="https://test.com", username="user", password="pass")

            # Simulate failure after first chunk
            mock_chunk.side_effect = [500000, ChunkError("Failed")]

            with pytest.raises(ChunkError):
                mb.export(
                    query="SELECT * FROM test",
                    output=output_file,
                    database=1,
                    checkpoint_file=checkpoint_file
                )

            # Checkpoint should exist
            assert os.path.exists(checkpoint_file)

            with open(checkpoint_file) as f:
                checkpoint = json.load(f)
                assert checkpoint['next_chunk'] == 2
                assert checkpoint['total_count'] == 500000

    @patch.object(Metabase, '_ensure_connected')
    @patch.object(Metabase, 'get_database_id')
    @patch.object(Metabase, '_get_row_count')
    @patch.object(Metabase, '_export_chunk_with_retry')
    def test_checkpoint_removed_on_success(self, mock_chunk, mock_count, mock_db, mock_conn):
        """Test that checkpoint is removed after successful export"""
        mock_db.return_value = 1
        mock_count.return_value = 1500000
        mock_chunk.return_value = 500000

        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "output.jsonl")
            checkpoint_file = os.path.join(tmpdir, "checkpoint.json")

            mb = Metabase(url="https://test.com", username="user", password="pass")

            mb.export(
                query="SELECT * FROM test",
                output=output_file,
                database=1,
                checkpoint_file=checkpoint_file
            )

            # Checkpoint should be removed
            assert not os.path.exists(checkpoint_file)


class TestRetryLogic:
    """Tests for retry logic in chunk export"""

    @patch('requests.post')
    def test_retry_on_failure(self, mock_post):
        """Test that chunks are retried on failure"""
        # First two calls fail, third succeeds
        mock_post.side_effect = [
            requests.exceptions.ConnectionError("Network error"),
            requests.exceptions.Timeout("Timeout"),
            Mock(
                status_code=200,
                text="id,name\n1,Alice\n",
                raise_for_status=lambda: None
            )
        ]

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"
        mb.config.retry_delay = 0.01  # Fast retry for testing

        import io
        from pymetabase.formats import get_format_handler
        output = io.StringIO()
        formatter = get_format_handler('jsonl', output)

        count = mb._export_chunk_with_retry(1, "SELECT * FROM test", formatter)

        assert count == 1
        assert mock_post.call_count == 3

    @patch('requests.post')
    def test_max_retries_exceeded(self, mock_post):
        """Test that error is raised after max retries"""
        mock_post.side_effect = requests.exceptions.ConnectionError("Persistent failure")

        mb = Metabase(url="https://test.com", username="user", password="pass")
        mb._auth.session_token = "test-token"
        mb.config.max_retries = 3
        mb.config.retry_delay = 0.01

        import io
        from pymetabase.formats import get_format_handler
        output = io.StringIO()
        formatter = get_format_handler('jsonl', output)

        with pytest.raises(ChunkError):
            mb._export_chunk_with_retry(1, "SELECT * FROM test", formatter)

        assert mock_post.call_count == 3


def _make_mb():
    """Helper to create a Metabase client for testing."""
    mb = Metabase(url="https://test.com", username="user", password="pass")
    mb._auth.session_token = "test-token"
    return mb


class TestGenericAPIRequest:
    """Tests for generic API methods (get/post/put/delete)"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'[{"id":1}]',
            json=lambda: [{"id": 1}],
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.get('/api/card')
        assert result == [{"id": 1}]
        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0] == ('get', 'https://test.com/api/card')

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_post(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1}',
            json=lambda: {"id": 1},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.post('/api/card', json={"name": "test"})
        assert result == {"id": 1}

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_put(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1}',
            json=lambda: {"id": 1, "name": "updated"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.put('/api/card/1', json={"name": "updated"})
        assert result["name"] == "updated"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_delete_resource(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=204,
            content=b'',
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.delete_resource('/api/card/1')
        assert result is None

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_404_raises_not_found(self, mock_request, mock_auth):
        mock_request.return_value = Mock(status_code=404)
        mb = _make_mb()
        with pytest.raises(NotFoundError):
            mb.get('/api/card/999')

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_500_raises_api_error(self, mock_request, mock_auth):
        resp = Mock(status_code=500)
        resp.raise_for_status.side_effect = requests.exceptions.HTTPError("500 Server Error", response=resp)
        mock_request.return_value = resp
        mb = _make_mb()
        with pytest.raises(APIError) as exc_info:
            mb.get('/api/card')
        assert exc_info.value.status_code == 500

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_connection_error_raises_api_error(self, mock_request, mock_auth):
        mock_request.side_effect = requests.exceptions.ConnectionError("refused")
        mb = _make_mb()
        with pytest.raises(APIError):
            mb.get('/api/card')

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_endpoint_auto_prepend_slash(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'[]',
            json=lambda: [],
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        mb.get('api/card')  # no leading slash
        call_args = mock_request.call_args
        assert call_args[0][1] == 'https://test.com/api/card'


class TestCardsAPI:
    """Tests for Cards/Questions API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_list_cards(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'[{"id":1,"name":"Q1"}]',
            json=lambda: [{"id": 1, "name": "Q1"}],
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        cards = mb.list_cards()
        assert len(cards) == 1
        assert cards[0]["name"] == "Q1"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_card(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"Q1"}',
            json=lambda: {"id": 1, "name": "Q1"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        card = mb.get_card(1)
        assert card["id"] == 1

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_create_card(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":10}',
            json=lambda: {"id": 10},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        card = mb.create_card(
            name="New Question",
            dataset_query={"database": 1, "type": "native", "native": {"query": "SELECT 1"}},
            collection_id=5,
            description="test card",
        )
        assert card["id"] == 10
        call_kwargs = mock_request.call_args[1]
        body = call_kwargs['json']
        assert body["name"] == "New Question"
        assert body["collection_id"] == 5

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_update_card(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"Updated"}',
            json=lambda: {"id": 1, "name": "Updated"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        card = mb.update_card(1, name="Updated")
        assert card["name"] == "Updated"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_delete_card(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"archived":true}',
            json=lambda: {"id": 1, "archived": True},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        mb.delete_card(1)
        call_kwargs = mock_request.call_args[1]
        assert call_kwargs['json'] == {"archived": True}

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_execute_card(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":{"rows":[[1]]}}',
            json=lambda: {"data": {"rows": [[1]]}},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.execute_card(1)
        assert result["data"]["rows"] == [[1]]

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_execute_card_with_params(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":{"rows":[]}}',
            json=lambda: {"data": {"rows": []}},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        mb.execute_card(1, parameters={"category": "electronics"})
        call_kwargs = mock_request.call_args[1]
        assert call_kwargs['json'] == {"parameters": {"category": "electronics"}}


class TestDashboardsAPI:
    """Tests for Dashboards API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_list_dashboards(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'[{"id":1,"name":"Dash1"}]',
            json=lambda: [{"id": 1, "name": "Dash1"}],
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        dashboards = mb.list_dashboards()
        assert len(dashboards) == 1

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_dashboard(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"Dash1"}',
            json=lambda: {"id": 1, "name": "Dash1", "dashcards": []},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        dash = mb.get_dashboard(1)
        assert dash["name"] == "Dash1"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_create_dashboard(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":5}',
            json=lambda: {"id": 5},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        dash = mb.create_dashboard("New Dashboard", collection_id=3, description="test")
        assert dash["id"] == 5
        body = mock_request.call_args[1]['json']
        assert body["name"] == "New Dashboard"
        assert body["collection_id"] == 3

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_delete_dashboard(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"archived":true}',
            json=lambda: {"id": 1, "archived": True},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        mb.delete_dashboard(1)
        body = mock_request.call_args[1]['json']
        assert body == {"archived": True}


class TestCollectionsAPI:
    """Tests for Collections API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_list_collections(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'[{"id":1,"name":"Coll1"}]',
            json=lambda: [{"id": 1, "name": "Coll1"}],
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        collections = mb.list_collections()
        assert len(collections) == 1

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_collection(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"Coll1"}',
            json=lambda: {"id": 1, "name": "Coll1"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        coll = mb.get_collection(1)
        assert coll["name"] == "Coll1"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_collection_items(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":[{"id":1,"model":"card"}]}',
            json=lambda: {"data": [{"id": 1, "model": "card"}]},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        items = mb.get_collection_items(1)
        assert len(items) == 1
        assert items[0]["model"] == "card"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_create_collection(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":10}',
            json=lambda: {"id": 10},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        coll = mb.create_collection("New Coll", parent_id=1, color="#AABBCC")
        assert coll["id"] == 10
        body = mock_request.call_args[1]['json']
        assert body["name"] == "New Coll"
        assert body["parent_id"] == 1
        assert body["color"] == "#AABBCC"


class TestSearchAPI:
    """Tests for Search API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_search(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":[{"id":1,"name":"Result","model":"card"}]}',
            json=lambda: {"data": [{"id": 1, "name": "Result", "model": "card"}]},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        results = mb.search("users")
        assert len(results) == 1
        assert results[0]["name"] == "Result"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_search_with_models(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":[]}',
            json=lambda: {"data": []},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        mb.search("test", models=["card", "dashboard"])
        call_kwargs = mock_request.call_args[1]
        assert "card" in call_kwargs['params']['models']


class TestUsersAPI:
    """Tests for Users API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_current_user(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"email":"test@test.com"}',
            json=lambda: {"id": 1, "email": "test@test.com"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        user = mb.get_current_user()
        assert user["email"] == "test@test.com"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_list_users(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"data":[{"id":1},{"id":2}]}',
            json=lambda: {"data": [{"id": 1}, {"id": 2}]},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        users = mb.list_users()
        assert len(users) == 2

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_user(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1}',
            json=lambda: {"id": 1},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        user = mb.get_user(1)
        assert user["id"] == 1


class TestTablesFieldsAPI:
    """Tests for Tables/Fields API"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_table(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"users"}',
            json=lambda: {"id": 1, "name": "users"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        table = mb.get_table(1)
        assert table["name"] == "users"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_field(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"id":1,"name":"email"}',
            json=lambda: {"id": 1, "name": "email"},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        field = mb.get_field(1)
        assert field["name"] == "email"

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.request')
    def test_get_field_values(self, mock_request, mock_auth):
        mock_request.return_value = Mock(
            status_code=200,
            content=b'{"values":[["a"],["b"]]}',
            json=lambda: {"values": [["a"], ["b"]]},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        vals = mb.get_field_values(1)
        assert len(vals["values"]) == 2


class TestQueryMethod:
    """Tests for the query() method"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    @patch('requests.post')
    def test_query_basic(self, mock_post, mock_get, mock_auth):
        # Mock list_databases for get_database_id
        mock_get.return_value = Mock(
            status_code=200,
            json=lambda: {'data': [{'id': 1, 'name': 'TestDB'}]},
        )
        mock_post.return_value = Mock(
            status_code=200,
            json=lambda: {'data': {'rows': [[1, 'Alice']], 'cols': [{'name': 'id'}, {'name': 'name'}]}},
            raise_for_status=lambda: None,
        )

        mb = _make_mb()
        result = mb.query("SELECT * FROM users", database="TestDB")
        assert result['data']['rows'] == [[1, 'Alice']]

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.post')
    def test_query_with_parameters(self, mock_post, mock_auth):
        mock_post.return_value = Mock(
            status_code=200,
            json=lambda: {'data': {'rows': [[30, 'Bob']]}},
            raise_for_status=lambda: None,
        )

        mb = _make_mb()
        result = mb.query(
            "SELECT * FROM users WHERE age > {{min_age}}",
            database=1,
            parameters={"min_age": 30},
        )
        # Check query payload includes parameters
        call_kwargs = mock_post.call_args[1]
        payload = call_kwargs['json']
        assert "min_age" in payload['native']['template-tags']
        assert len(payload['parameters']) == 1
        assert payload['parameters'][0]['value'] == 30


class TestBuildQueryPayload:
    """Tests for _build_query_payload"""

    def test_no_parameters(self):
        mb = _make_mb()
        payload = mb._build_query_payload(1, "SELECT * FROM users")
        assert payload['database'] == 1
        assert payload['native']['query'] == "SELECT * FROM users"
        assert payload['native']['template-tags'] == {}
        assert payload['parameters'] == []

    def test_with_number_param(self):
        mb = _make_mb()
        payload = mb._build_query_payload(
            1,
            "SELECT * FROM users WHERE age > {{min_age}}",
            parameters={"min_age": 25},
        )
        assert "min_age" in payload['native']['template-tags']
        assert payload['native']['template-tags']['min_age']['type'] == 'number'
        assert payload['parameters'][0]['value'] == 25

    def test_with_text_param(self):
        mb = _make_mb()
        payload = mb._build_query_payload(
            1,
            "SELECT * FROM users WHERE name = {{username}}",
            parameters={"username": "Alice"},
        )
        assert payload['native']['template-tags']['username']['type'] == 'text'
        assert payload['parameters'][0]['value'] == "Alice"

    def test_with_multiple_params(self):
        mb = _make_mb()
        payload = mb._build_query_payload(
            1,
            "SELECT * FROM users WHERE age > {{min_age}} AND name = {{username}}",
            parameters={"min_age": 20, "username": "Bob"},
        )
        assert len(payload['native']['template-tags']) == 2
        assert len(payload['parameters']) == 2

    def test_ignores_missing_params(self):
        mb = _make_mb()
        payload = mb._build_query_payload(
            1,
            "SELECT * FROM users WHERE age > {{min_age}}",
            parameters={"other_param": 42},
        )
        # min_age is in query but not in parameters dict, so no template tags
        assert len(payload['native']['template-tags']) == 0
        assert len(payload['parameters']) == 0


class TestQueryErrorHandling:
    """Tests for Metabase-level error handling in query responses"""

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.post')
    def test_query_raises_on_metabase_error(self, mock_post, mock_auth):
        """Metabase returns 200 for SQL errors — we should raise QueryError"""
        mock_post.return_value = Mock(
            status_code=200,
            json=lambda: {
                'status': 'failed',
                'error': 'ERROR: column "foo" does not exist',
            },
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        with pytest.raises(QueryError, match="column.*foo.*does not exist"):
            mb.query("SELECT foo FROM bar", database=1)

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.post')
    def test_query_success_returns_result(self, mock_post, mock_auth):
        mock_post.return_value = Mock(
            status_code=200,
            json=lambda: {
                'status': 'completed',
                'data': {'rows': [[42]], 'cols': [{'name': 'cnt'}]},
            },
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb.query("SELECT count(*) as cnt FROM users", database=1)
        assert result['data']['rows'] == [[42]]

    @patch('pymetabase.auth.MetabaseAuth.ensure_authenticated')
    @patch('requests.get')
    @patch('requests.post')
    def test_get_row_count_returns_none_on_metabase_error(self, mock_post, mock_get, mock_auth):
        """_get_row_count should return None (not crash) on Metabase query errors"""
        mock_post.return_value = Mock(
            status_code=200,
            json=lambda: {'status': 'failed', 'error': 'syntax error'},
            raise_for_status=lambda: None,
        )
        mb = _make_mb()
        result = mb._get_row_count(1, "INVALID SQL")
        assert result is None
