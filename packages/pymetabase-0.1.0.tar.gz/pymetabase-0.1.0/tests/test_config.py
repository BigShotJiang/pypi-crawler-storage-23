"""
Tests for configuration module
"""

import os
import json
import tempfile
import pytest
from pathlib import Path

from pymetabase.config import MetabaseConfig, load_config
from pymetabase.exceptions import ConfigurationError


class TestMetabaseConfig:
    """Tests for MetabaseConfig class"""

    def test_default_values(self):
        """Test default configuration values"""
        config = MetabaseConfig()
        assert config.chunk_size == 500000
        assert config.auto_chunk_threshold == 1000000
        assert config.output_format == "jsonl"
        assert config.max_retries == 3
        assert config.log_level == "INFO"

    def test_from_dict(self):
        """Test creating config from dictionary"""
        data = {
            "metabase": {
                "url": "https://test.com",
                "username": "user",
                "password": "pass"
            },
            "defaults": {
                "chunk_size": 100000,
                "format": "csv"
            }
        }
        config = MetabaseConfig.from_dict(data)
        assert config.url == "https://test.com"
        assert config.username == "user"
        assert config.password == "pass"
        assert config.chunk_size == 100000
        assert config.output_format == "csv"

    def test_from_credentials_file_array(self):
        """Test loading from credentials file with array format"""
        creds = [
            {
                "SERVER_NAME": "https://test.com",
                "USERNAME": "user",
                "PASSWORD": "pass"
            }
        ]

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(creds, f)
            f.flush()

            config = MetabaseConfig.from_credentials_file(f.name)
            assert config.url == "https://test.com"
            assert config.username == "user"
            assert config.password == "pass"

        os.unlink(f.name)

    def test_from_credentials_file_not_found(self):
        """Test error when credentials file not found"""
        with pytest.raises(ConfigurationError):
            MetabaseConfig.from_credentials_file("/nonexistent/file.json")

    def test_from_env(self):
        """Test loading from environment variables"""
        os.environ['METABASE_URL'] = "https://env.com"
        os.environ['METABASE_USERNAME'] = "envuser"
        os.environ['METABASE_PASSWORD'] = "envpass"

        config = MetabaseConfig.from_env()
        assert config.url == "https://env.com"
        assert config.username == "envuser"
        assert config.password == "envpass"

        # Cleanup
        del os.environ['METABASE_URL']
        del os.environ['METABASE_USERNAME']
        del os.environ['METABASE_PASSWORD']


class TestLoadConfig:
    """Tests for load_config function"""

    def test_kwargs_override(self):
        """Test that kwargs override other sources"""
        config = load_config(
            url="https://kwarg.com",
            username="kwarguser",
            password="kwargpass"
        )
        assert config.url == "https://kwarg.com"
        assert config.username == "kwarguser"

    def test_config_priority(self):
        """Test configuration priority"""
        # Set env var
        os.environ['METABASE_URL'] = "https://env.com"

        # Load with kwarg override
        config = load_config(url="https://override.com")
        assert config.url == "https://override.com"

        # Cleanup
        del os.environ['METABASE_URL']
