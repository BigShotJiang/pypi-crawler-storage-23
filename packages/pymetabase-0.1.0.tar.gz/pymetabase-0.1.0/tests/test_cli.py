"""
Tests for CLI module
"""

import pytest
import sys
from unittest.mock import patch, Mock, MagicMock
from io import StringIO

from pymetabase.cli import main
from pymetabase.client import ExportResult
from pymetabase.remotes import Remote


def mock_remote_manager():
    """Create a mock RemoteManager with a default remote"""
    manager = MagicMock()
    default_remote = Remote(
        name="default",
        url="https://test.com",
        username="testuser",
        password="testpass"
    )
    manager.get_default_remote.return_value = default_remote
    manager.get_default_remote_name.return_value = "default"
    manager.has_remotes.return_value = True
    manager.get_remote.return_value = default_remote
    manager.list_remotes.return_value = ["default"]
    return manager


class TestCLIExport:
    """Tests for export command"""

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_command(self, mock_metabase_class, mock_manager_class):
        """Test basic export command"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=100,
            chunks=1,
            duration_seconds=1.0,
            output_file="output.jsonl",
            rate_per_second=100.0,
            format="jsonl"
        )

        test_args = [
            'pymetabase', 'export',
            '--database', 'TestDB',
            '--query', 'SELECT * FROM users',
            '--output', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        mock_client.export.assert_called_once()
        call_kwargs = mock_client.export.call_args[1]
        assert call_kwargs['database'] == 'TestDB'
        assert call_kwargs['query'] == 'SELECT * FROM users'
        assert call_kwargs['output'] == 'output.jsonl'

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_with_format(self, mock_metabase_class, mock_manager_class):
        """Test export with explicit format"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="output.csv", rate_per_second=100.0, format="csv"
        )

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '-q', 'SELECT * FROM users',
            '-o', 'output.csv',
            '-f', 'csv'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export.call_args[1]
        assert call_kwargs['format'] == 'csv'

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_with_chunk_size(self, mock_metabase_class, mock_manager_class):
        """Test export with custom chunk size"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="output.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '-q', 'SELECT * FROM users',
            '-o', 'output.jsonl',
            '--chunk-size', '100000'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export.call_args[1]
        assert call_kwargs['chunk_size'] == 100000

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_with_query_file(self, mock_metabase_class, mock_manager_class, tmp_path):
        """Test export with SQL query from file"""
        mock_manager_class.return_value = mock_remote_manager()

        # Create a SQL file
        sql_file = tmp_path / "query.sql"
        sql_content = """SELECT
    id,
    name,
    email
FROM users
WHERE active = true
ORDER BY created_at DESC"""
        sql_file.write_text(sql_content)

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="output.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '--query-file', str(sql_file),
            '-o', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export.call_args[1]
        assert call_kwargs['query'] == sql_content

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_with_query_file_txt(self, mock_metabase_class, mock_manager_class, tmp_path):
        """Test export with SQL query from .txt file"""
        mock_manager_class.return_value = mock_remote_manager()

        # Create a txt file
        txt_file = tmp_path / "query.txt"
        txt_file.write_text("SELECT * FROM orders")

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=50, chunks=1, duration_seconds=0.5,
            output_file="output.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '-Q', str(txt_file),
            '-o', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export.call_args[1]
        assert call_kwargs['query'] == "SELECT * FROM orders"

    @patch('pymetabase.cli.RemoteManager')
    def test_export_query_file_not_found(self, mock_manager_class):
        """Test export with non-existent query file"""
        mock_manager_class.return_value = mock_remote_manager()

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '--query-file', '/nonexistent/query.sql',
            '-o', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_query_file_empty(self, mock_metabase_class, mock_manager_class, tmp_path):
        """Test export with empty query file"""
        mock_manager_class.return_value = mock_remote_manager()

        # Create an empty file
        empty_file = tmp_path / "empty.sql"
        empty_file.write_text("   ")  # Just whitespace

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)

        test_args = [
            'pymetabase', 'export',
            '-d', 'TestDB',
            '--query-file', str(empty_file),
            '-o', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1

    @patch('pymetabase.cli.Metabase')
    def test_export_with_credentials_file(self, mock_metabase_class):
        """Test export with credentials file"""
        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="output.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase',
            '-c', 'creds.json',
            'export',
            '-d', 'TestDB',
            '-q', 'SELECT * FROM users',
            '-o', 'output.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        # Check that credentials_file was passed
        call_kwargs = mock_metabase_class.call_args[1]
        assert call_kwargs['credentials_file'] == 'creds.json'


class TestCLIExportTable:
    """Tests for export-table command"""

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_table_basic(self, mock_metabase_class, mock_manager_class):
        """Test basic export-table command"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export_table.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="users.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export-table',
            '-d', 'TestDB',
            '-t', 'users',
            '-o', 'users.jsonl'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export_table.call_args[1]
        assert call_kwargs['database'] == 'TestDB'
        assert call_kwargs['table'] == 'users'
        assert call_kwargs['output'] == 'users.jsonl'

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_table_with_columns(self, mock_metabase_class, mock_manager_class):
        """Test export-table with specific columns"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export_table.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="users.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export-table',
            '-d', 'TestDB',
            '-t', 'users',
            '-o', 'users.jsonl',
            '--columns', 'id,name,email'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export_table.call_args[1]
        assert call_kwargs['columns'] == ['id', 'name', 'email']

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_table_with_filters(self, mock_metabase_class, mock_manager_class):
        """Test export-table with WHERE, ORDER BY, LIMIT"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export_table.return_value = ExportResult(
            total_rows=50, chunks=1, duration_seconds=0.5,
            output_file="users.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export-table',
            '-d', 'TestDB',
            '-t', 'users',
            '-o', 'users.jsonl',
            '--where', 'active = true',
            '--order-by', 'created_at DESC',
            '--limit', '50'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export_table.call_args[1]
        assert call_kwargs['where'] == 'active = true'
        assert call_kwargs['order_by'] == 'created_at DESC'
        assert call_kwargs['limit'] == 50

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_export_table_with_chunk_size(self, mock_metabase_class, mock_manager_class):
        """Test export-table with custom chunk size"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.export_table.return_value = ExportResult(
            total_rows=100, chunks=1, duration_seconds=1.0,
            output_file="users.jsonl", rate_per_second=100.0, format="jsonl"
        )

        test_args = [
            'pymetabase', 'export-table',
            '-d', 'TestDB',
            '-t', 'users',
            '-o', 'users.jsonl',
            '--chunk-size', '50000'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_client.export_table.call_args[1]
        assert call_kwargs['chunk_size'] == 50000


class TestCLIListDatabases:
    """Tests for list-databases command"""

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_list_databases(self, mock_metabase_class, mock_manager_class):
        """Test list-databases command"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.list_databases.return_value = [
            {'id': 1, 'name': 'Database1', 'engine': 'postgres'},
            {'id': 2, 'name': 'Database2', 'engine': 'mysql'}
        ]

        test_args = ['pymetabase', 'list-databases']

        with patch.object(sys, 'argv', test_args):
            main()

        mock_client.list_databases.assert_called_once()


class TestCLIListTables:
    """Tests for list-tables command"""

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_list_tables(self, mock_metabase_class, mock_manager_class):
        """Test list-tables command"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.list_tables.return_value = [
            {'name': 'users', 'rows': 1000},
            {'name': 'orders', 'rows': 5000}
        ]

        test_args = ['pymetabase', 'list-tables', '-d', 'TestDB']

        with patch.object(sys, 'argv', test_args):
            main()

        mock_client.list_tables.assert_called_once_with('TestDB')


class TestCLIErrorHandling:
    """Tests for CLI error handling"""

    def test_no_command_shows_help(self):
        """Test that no command shows help and exits"""
        test_args = ['pymetabase']

        with patch.object(sys, 'argv', test_args):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1

    @patch('pymetabase.cli.Metabase')
    def test_error_exits_with_code_1(self, mock_metabase_class):
        """Test that errors exit with code 1"""
        mock_metabase_class.side_effect = Exception("Connection failed")

        test_args = [
            'pymetabase', 'list-databases'
        ]

        with patch.object(sys, 'argv', test_args):
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1


class TestCLIGlobalOptions:
    """Tests for global CLI options"""

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_url_option(self, mock_metabase_class, mock_manager_class):
        """Test --url option"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.list_databases.return_value = []

        test_args = [
            'pymetabase',
            '--url', 'https://custom.com',
            '--username', 'user',
            '--password', 'pass',
            'list-databases'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_metabase_class.call_args[1]
        assert call_kwargs['url'] == 'https://custom.com'

    @patch('pymetabase.cli.RemoteManager')
    @patch('pymetabase.cli.Metabase')
    def test_username_password_options(self, mock_metabase_class, mock_manager_class):
        """Test --username and --password options"""
        mock_manager_class.return_value = mock_remote_manager()

        mock_client = MagicMock()
        mock_metabase_class.return_value = mock_client
        mock_client.__enter__ = Mock(return_value=mock_client)
        mock_client.__exit__ = Mock(return_value=False)
        mock_client.list_databases.return_value = []

        test_args = [
            'pymetabase',
            '--url', 'https://test.com',
            '--username', 'testuser',
            '--password', 'testpass',
            'list-databases'
        ]

        with patch.object(sys, 'argv', test_args):
            main()

        call_kwargs = mock_metabase_class.call_args[1]
        assert call_kwargs['username'] == 'testuser'
        assert call_kwargs['password'] == 'testpass'
