"""
Tests for authentication module
"""

import pytest
from unittest.mock import patch, Mock, MagicMock
import requests

from pymetabase.auth import MetabaseAuth
from pymetabase.exceptions import AuthenticationError, ConnectionError


class TestMetabaseAuth:
    """Tests for MetabaseAuth class"""

    def test_init(self):
        """Test initialization"""
        auth = MetabaseAuth(
            url="https://test.com/",
            username="user",
            password="pass",
            timeout=60
        )
        assert auth.url == "https://test.com"  # trailing slash stripped
        assert auth.username == "user"
        assert auth.password == "pass"
        assert auth.timeout == 60
        assert auth.session_token is None

    def test_url_trailing_slash_stripped(self):
        """Test that trailing slash is stripped from URL"""
        auth = MetabaseAuth(
            url="https://test.com///",
            username="user",
            password="pass"
        )
        assert auth.url == "https://test.com"

    @patch('requests.post')
    def test_login_success(self, mock_post):
        """Test successful login"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'id': 'test-session-token'}
        mock_post.return_value = mock_response

        auth = MetabaseAuth("https://test.com", "user", "pass")
        token = auth.login()

        assert token == "test-session-token"
        assert auth.session_token == "test-session-token"
        mock_post.assert_called_once_with(
            "https://test.com/api/session",
            json={"username": "user", "password": "pass"},
            timeout=30
        )

    @patch('requests.post')
    def test_login_invalid_credentials(self, mock_post):
        """Test login with invalid credentials"""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.json.return_value = {
            'errors': {'password': 'Invalid password'}
        }
        mock_post.return_value = mock_response

        auth = MetabaseAuth("https://test.com", "user", "wrongpass")

        with pytest.raises(AuthenticationError) as exc_info:
            auth.login()

        assert "Invalid password" in str(exc_info.value)

    @patch('requests.post')
    def test_login_connection_error(self, mock_post):
        """Test login with connection error"""
        mock_post.side_effect = requests.exceptions.ConnectionError("Cannot connect")

        auth = MetabaseAuth("https://test.com", "user", "pass")

        with pytest.raises(ConnectionError) as exc_info:
            auth.login()

        assert "Failed to connect" in str(exc_info.value)

    @patch('requests.post')
    def test_login_timeout(self, mock_post):
        """Test login with timeout"""
        mock_post.side_effect = requests.exceptions.Timeout("Timeout")

        auth = MetabaseAuth("https://test.com", "user", "pass", timeout=5)

        with pytest.raises(ConnectionError) as exc_info:
            auth.login()

        assert "timeout" in str(exc_info.value).lower()

    @patch('requests.delete')
    def test_logout_success(self, mock_delete):
        """Test successful logout"""
        mock_delete.return_value = Mock(status_code=200)

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "test-token"
        auth.logout()

        assert auth.session_token is None
        mock_delete.assert_called_once()

    def test_logout_without_token(self):
        """Test logout when not logged in"""
        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.logout()  # Should not raise
        assert auth.session_token is None

    @patch('requests.delete')
    def test_logout_error_handled(self, mock_delete):
        """Test logout handles errors gracefully"""
        mock_delete.side_effect = Exception("Network error")

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "test-token"
        auth.logout()  # Should not raise

        assert auth.session_token is None

    def test_get_headers_authenticated(self):
        """Test getting headers when authenticated"""
        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "test-token"

        headers = auth.get_headers()

        assert headers["X-Metabase-Session"] == "test-token"
        assert headers["Content-Type"] == "application/json"

    def test_get_headers_not_authenticated(self):
        """Test getting headers when not authenticated"""
        auth = MetabaseAuth("https://test.com", "user", "pass")

        with pytest.raises(AuthenticationError) as exc_info:
            auth.get_headers()

        assert "Not authenticated" in str(exc_info.value)

    def test_is_authenticated(self):
        """Test is_authenticated method"""
        auth = MetabaseAuth("https://test.com", "user", "pass")

        assert auth.is_authenticated() is False

        auth.session_token = "test-token"
        assert auth.is_authenticated() is True

    @patch('requests.post')
    def test_ensure_authenticated_already_logged_in(self, mock_post):
        """Test ensure_authenticated when already logged in"""
        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "existing-token"

        auth.ensure_authenticated()

        mock_post.assert_not_called()

    @patch('requests.post')
    def test_ensure_authenticated_login_required(self, mock_post):
        """Test ensure_authenticated when login is needed"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'id': 'new-token'}
        mock_post.return_value = mock_response

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.ensure_authenticated()

        assert auth.session_token == "new-token"
        mock_post.assert_called_once()

    @patch('requests.get')
    def test_validate_session_valid(self, mock_get):
        """Test validating a valid session"""
        mock_get.return_value = Mock(status_code=200)

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "valid-token"

        assert auth.validate_session() is True
        mock_get.assert_called_once_with(
            "https://test.com/api/user/current",
            headers=auth.get_headers(),
            timeout=30
        )

    @patch('requests.get')
    def test_validate_session_invalid(self, mock_get):
        """Test validating an invalid session"""
        mock_get.return_value = Mock(status_code=401)

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "invalid-token"

        assert auth.validate_session() is False

    @patch('requests.get')
    def test_validate_session_error(self, mock_get):
        """Test validating session with network error"""
        mock_get.side_effect = Exception("Network error")

        auth = MetabaseAuth("https://test.com", "user", "pass")
        auth.session_token = "test-token"

        assert auth.validate_session() is False

    def test_validate_session_no_token(self):
        """Test validating session without token"""
        auth = MetabaseAuth("https://test.com", "user", "pass")
        assert auth.validate_session() is False


class TestMetabaseAuthWithTokenPersistence:
    """Tests for MetabaseAuth with token persistence via RemoteManager"""

    @patch('requests.get')
    def test_login_uses_stored_token_if_valid(self, mock_get):
        """Test that login uses stored token if it's still valid"""
        from pymetabase.remotes import RemoteManager
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.save_token("myremote", "stored-valid-token")

            # Mock validate_session to return True
            mock_get.return_value = Mock(status_code=200)

            auth = MetabaseAuth(
                url="https://test.com",
                username="user",
                password="pass",
                remote_name="myremote",
                remote_manager=manager,
            )

            token = auth.login()

            assert token == "stored-valid-token"
            assert auth.session_token == "stored-valid-token"
            # Should have called validate, not login
            mock_get.assert_called_once()

    @patch('requests.get')
    @patch('requests.post')
    def test_login_falls_back_to_password_if_token_invalid(self, mock_post, mock_get):
        """Test that login uses password auth if stored token is invalid"""
        from pymetabase.remotes import RemoteManager
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.save_token("myremote", "stored-invalid-token")

            # Mock validate_session to return False
            mock_get.return_value = Mock(status_code=401)

            # Mock login to succeed
            mock_post.return_value = Mock(status_code=200, json=lambda: {'id': 'new-token'})

            auth = MetabaseAuth(
                url="https://test.com",
                username="user",
                password="pass",
                remote_name="myremote",
                remote_manager=manager,
            )

            token = auth.login()

            assert token == "new-token"
            mock_post.assert_called_once()  # Should have done password auth

    @patch('requests.post')
    def test_login_saves_token_after_password_auth(self, mock_post):
        """Test that login saves token after successful password auth"""
        from pymetabase.remotes import RemoteManager
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)

            mock_post.return_value = Mock(status_code=200, json=lambda: {'id': 'new-session-token'})

            auth = MetabaseAuth(
                url="https://test.com",
                username="user",
                password="pass",
                remote_name="myremote",
                remote_manager=manager,
            )

            auth.login()

            # Token should be saved
            assert manager.get_token("myremote") == "new-session-token"

    @patch('requests.delete')
    def test_logout_clears_stored_token_by_default(self, mock_delete):
        """Test that logout clears stored token by default"""
        from pymetabase.remotes import RemoteManager
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.save_token("myremote", "stored-token")

            mock_delete.return_value = Mock(status_code=200)

            auth = MetabaseAuth(
                url="https://test.com",
                username="user",
                password="pass",
                remote_name="myremote",
                remote_manager=manager,
            )
            auth.session_token = "stored-token"

            auth.logout(clear_stored_token=True)

            assert manager.get_token("myremote") is None

    @patch('requests.delete')
    def test_logout_preserves_stored_token_when_requested(self, mock_delete):
        """Test that logout can preserve stored token"""
        from pymetabase.remotes import RemoteManager
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            manager = RemoteManager(config_dir=tmpdir)
            manager.save_token("myremote", "stored-token")

            mock_delete.return_value = Mock(status_code=200)

            auth = MetabaseAuth(
                url="https://test.com",
                username="user",
                password="pass",
                remote_name="myremote",
                remote_manager=manager,
            )
            auth.session_token = "stored-token"

            auth.logout(clear_stored_token=False)

            # Token should still be in storage
            assert manager.get_token("myremote") == "stored-token"

    def test_auth_without_remote_manager_works(self):
        """Test that auth works without remote manager (no persistence)"""
        auth = MetabaseAuth(
            url="https://test.com",
            username="user",
            password="pass",
        )

        # Should not have remote manager
        assert auth._remote_manager is None
        assert auth._remote_name is None

    @patch('requests.post')
    def test_auth_without_remote_manager_login(self, mock_post):
        """Test login without remote manager still works"""
        mock_post.return_value = Mock(status_code=200, json=lambda: {'id': 'token'})

        auth = MetabaseAuth(
            url="https://test.com",
            username="user",
            password="pass",
        )

        token = auth.login()

        assert token == "token"
        mock_post.assert_called_once()
