# pysrat 0.2.1

- add `truncate` method to `NHPPData` for truncating data at a specified time

