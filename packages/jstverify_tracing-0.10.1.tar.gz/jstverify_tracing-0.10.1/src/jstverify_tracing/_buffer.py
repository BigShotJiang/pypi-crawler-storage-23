"""Thread-safe span buffer with daemon flush thread."""

import logging
import threading
from typing import List, Optional

from ._transport import Transport
from ._types import SpanData

logger = logging.getLogger("jstverify_tracing")


class SpanBuffer:
    def __init__(
        self,
        transport: Transport,
        flush_interval: float = 5.0,
        max_queue_size: int = 200,
        max_batch_size: int = 50,
        sanitize_pii: bool = True,
    ):
        self._transport = transport
        self._sanitize = sanitize_pii
        self._flush_interval = flush_interval
        self._max_queue_size = max_queue_size
        self._max_batch_size = max_batch_size
        self._queue: List[SpanData] = []
        self._lock = threading.Lock()
        self._flush_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self) -> None:
        """Start the daemon flush thread."""
        self._stop_event.clear()
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()

    def stop(self) -> None:
        """Stop the flush thread and do a final flush."""
        self._stop_event.set()
        if self._flush_thread and self._flush_thread.is_alive():
            self._flush_thread.join(timeout=self._flush_interval + 2)
        self._flush()

    def enqueue(self, span: SpanData) -> None:
        """Add a span to the buffer. Drops oldest if full. No-op if transport is blocked."""
        if self._transport.permanently_blocked:
            return
        if self._sanitize:
            from ._sanitizer import sanitize_span
            sanitize_span(span)
        with self._lock:
            if len(self._queue) >= self._max_queue_size:
                self._queue.pop(0)
            self._queue.append(span)

    def _flush_loop(self) -> None:
        while not self._stop_event.wait(timeout=self._flush_interval):
            self._flush()

    def flush_all(self) -> None:
        """Synchronously flush all queued spans. Used by Lambda integration."""
        while True:
            with self._lock:
                if not self._queue:
                    return
            self._flush()
            # If transport is blocked or backing off, don't spin
            if self._transport.permanently_blocked:
                return
            with self._lock:
                if not self._queue:
                    return
                # If flush put spans back (failure), stop to avoid infinite loop
                break

    def _flush(self) -> None:
        if self._transport.permanently_blocked:
            with self._lock:
                self._queue.clear()
            return

        with self._lock:
            if not self._queue:
                return
            batch = self._queue[: self._max_batch_size]
            self._queue = self._queue[self._max_batch_size :]

        success = self._transport.send(batch)
        if not success and not self._transport.permanently_blocked:
            # Put spans back at front for retry
            with self._lock:
                self._queue = batch + self._queue
                # Trim to max size if needed
                if len(self._queue) > self._max_queue_size:
                    self._queue = self._queue[-self._max_queue_size :]
