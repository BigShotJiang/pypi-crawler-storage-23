"""HTTP transport for sending span batches with exponential backoff."""

import json
import logging
import random
import time
from typing import List

import requests

from ._types import SpanData

logger = logging.getLogger("jstverify_tracing")


class Transport:
    def __init__(self, endpoint: str, api_key: str):
        self._endpoint = endpoint
        self._api_key = api_key
        self._failure_count = 0
        self._next_retry_time = 0.0
        self.permanently_blocked = False
        # Use a dedicated session with unpatched send to avoid recursion
        self._session = requests.Session()
        self._original_send = requests.Session.send

    def send(self, spans: List[SpanData]) -> bool:
        """Send a batch of spans. Returns True on success."""
        if self.permanently_blocked:
            return False

        now = time.time()
        if now < self._next_retry_time:
            return False

        try:
            req = requests.Request(
                "POST",
                self._endpoint,
                json={"spans": spans},
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self._api_key,
                },
            )
            prepared = self._session.prepare_request(req)
            response = self._original_send(self._session, prepared, timeout=10)

            if response.ok:
                self._failure_count = 0
                self._next_retry_time = 0.0
                return True
            elif response.status_code == 403:
                self.permanently_blocked = True
                logger.warning(
                    "jstverify-tracing: 403 received — tracing disabled for this API key"
                )
                return False
            else:
                self._record_retry_delay()
                return False
        except Exception:
            self._record_retry_delay()
            return False

    def _record_retry_delay(self) -> None:
        """Exponential backoff: min(1000 * 2^failures, 300000ms) + 25% jitter."""
        self._failure_count += 1
        base_delay_ms = min(1000 * (2 ** self._failure_count), 300_000)
        jitter_ms = base_delay_ms * 0.25 * random.random()
        delay_s = (base_delay_ms + jitter_ms) / 1000.0
        self._next_retry_time = time.time() + delay_s
