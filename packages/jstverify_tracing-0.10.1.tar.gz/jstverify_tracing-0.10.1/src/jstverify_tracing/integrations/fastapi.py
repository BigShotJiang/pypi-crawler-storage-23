"""FastAPI / Starlette middleware for JstVerify distributed tracing."""

import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .._context import set_root_context, pop_context, clear_context, set_session_id, get_session_id
from .._config import JstVerifyTracing


class JstVerifyTracingMiddleware(BaseHTTPMiddleware):
    """Starlette-based middleware for auto-tracing incoming requests.

    Usage:
        from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware
        app.add_middleware(JstVerifyTracingMiddleware)
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return await call_next(request)

        trace_id = request.headers.get("x-jstverify-trace-id") or str(uuid.uuid4())
        parent_span_id = request.headers.get("x-jstverify-parent-span-id")
        session_id = request.headers.get("x-jstverify-session-id")
        set_session_id(session_id)

        ctx = set_root_context(trace_id, parent_span_id)
        start_time = int(time.time() * 1000)
        status_code = 500

        # Pre-initialize the relay buffer so the mutable list reference is
        # shared with threads spawned by BaseHTTPMiddleware for sync handlers.
        if instance.is_relay:
            from .._relay_buffer import _get_or_create_buffer
            _get_or_create_buffer()

        try:
            response = await call_next(request)
            status_code = response.status_code
            return response
        except Exception:
            raise
        finally:
            end_time = int(time.time() * 1000)
            session_id = get_session_id()
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": f"{request.method} {request.url.path}",
                "serviceName": instance.service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "httpMethod": request.method,
                "httpUrl": request.url.path,
                "httpStatusCode": status_code,
            }
            if session_id:
                span["sessionId"] = session_id

            if instance.is_relay:
                from .._relay_buffer import (
                    enqueue_relay_span, drain_relay_spans,
                    encode_relay_header, HEADER_NAME,
                )
                enqueue_relay_span(span)
                spans = drain_relay_spans()
                header_value = encode_relay_header(spans)
                if header_value is not None:
                    response.headers[HEADER_NAME] = header_value
                    response.headers["Access-Control-Expose-Headers"] = HEADER_NAME
            else:
                instance._buffer.enqueue(span)

            pop_context()
            clear_context()
