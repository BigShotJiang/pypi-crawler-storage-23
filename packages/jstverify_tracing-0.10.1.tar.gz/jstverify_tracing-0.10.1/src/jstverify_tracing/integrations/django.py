"""Django middleware for JstVerify distributed tracing."""

import time
import uuid

from .._context import set_root_context, pop_context, clear_context, set_session_id, get_session_id
from .._config import JstVerifyTracing


class JstVerifyTracingMiddleware:
    """Django middleware for auto-tracing incoming requests.

    Usage (settings.py):
        MIDDLEWARE = [
            "jstverify_tracing.integrations.django.JstVerifyTracingMiddleware",
            ...
        ]
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return self.get_response(request)

        # Django normalises headers: X-JstVerify-Trace-Id → HTTP_X_JSTVERIFY_TRACE_ID
        trace_id = request.META.get("HTTP_X_JSTVERIFY_TRACE_ID") or str(uuid.uuid4())
        parent_span_id = request.META.get("HTTP_X_JSTVERIFY_PARENT_SPAN_ID")
        session_id = request.META.get("HTTP_X_JSTVERIFY_SESSION_ID")
        set_session_id(session_id)

        ctx = set_root_context(trace_id, parent_span_id)
        start_time = int(time.time() * 1000)

        try:
            response = self.get_response(request)
        except Exception:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": f"{request.method} {request.path}",
                "serviceName": instance.service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": 500,
                "httpMethod": request.method,
                "httpUrl": request.path,
                "httpStatusCode": 500,
            }
            if session_id:
                span["sessionId"] = session_id
            if instance.is_relay:
                from .._relay_buffer import drain_relay_spans
                drain_relay_spans()  # prevent stale spans leaking
            else:
                instance._buffer.enqueue(span)
            raise
        finally:
            clear_context()

        end_time = int(time.time() * 1000)
        span = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": ctx.parent_span_id,
            "operationName": f"{request.method} {request.path}",
            "serviceName": instance.service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": response.status_code,
            "httpMethod": request.method,
            "httpUrl": request.path,
            "httpStatusCode": response.status_code,
        }
        if session_id:
            span["sessionId"] = session_id

        if instance.is_relay:
            from .._relay_buffer import (
                enqueue_relay_span, drain_relay_spans,
                encode_relay_header, HEADER_NAME,
            )
            enqueue_relay_span(span)
            spans = drain_relay_spans()
            header_value = encode_relay_header(spans)
            if header_value is not None:
                response[HEADER_NAME] = header_value
                response["Access-Control-Expose-Headers"] = HEADER_NAME
        else:
            instance._buffer.enqueue(span)

        pop_context()

        return response
