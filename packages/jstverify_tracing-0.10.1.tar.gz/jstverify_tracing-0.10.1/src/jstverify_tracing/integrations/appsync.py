"""AWS AppSync Lambda resolver middleware for JstVerify distributed tracing.

AppSync Lambda resolvers receive a different event structure than API Gateway:
- Headers live at ``event["request"]["headers"]``
- Operation info at ``event["info"]["parentTypeName"]`` and ``event["info"]["fieldName"]``
- Return values are raw data (not HTTP response dicts)

Relay mode is **not supported** for AppSync because GraphQL responses have no
mechanism for injecting custom HTTP headers.

Two spans are emitted per invocation:

1. **AppSync parent span** — synthetic, represents the GraphQL resolver layer.
   Uses a deterministic ``spanId`` (``uuid5`` of the trace ID) so that all
   pipeline steps produce the same span and DynamoDB ``put_item`` deduplicates.
2. **Lambda child span** — the actual Lambda execution, with ``serviceName``
   from ``AWS_LAMBDA_FUNCTION_NAME`` so each function appears as its own node
   in the service map.
"""

import logging
import os
import time
import uuid
from functools import wraps

from .._context import set_root_context, pop_context, clear_context, set_session_id
from .._config import JstVerifyTracing
from .._source_location import from_code_object

logger = logging.getLogger("jstverify_tracing")

_FLUSH_HEADROOM_MS = 2000


def _get_remaining_ms(context):
    """Return milliseconds left in the Lambda invocation, or *None*."""
    if context is None:
        return None
    fn = getattr(context, "get_remaining_time_in_millis", None)
    return fn() if fn else None


class JstVerifyAppSyncMiddleware:
    """Decorator for AppSync Lambda resolver functions.

    Extracts trace context from ``event["stash"]`` (pipeline resolvers) or
    ``event["request"]["headers"]``, emits a synthetic AppSync parent span and
    a Lambda child span, and flushes synchronously before returning.

    Only direct transport mode is supported.  If the SDK was initialised in
    relay mode the decorator logs a warning and passes through without tracing.

    Usage::

        from jstverify_tracing.integrations.appsync import JstVerifyAppSyncMiddleware

        @JstVerifyAppSyncMiddleware
        def handler(event, context):
            return [{"id": "1", "name": "Alice"}]
    """

    def __init__(self, func):
        self._func = func
        wraps(func)(self)

    def __call__(self, event, context):
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return self._func(event, context)

        if instance.is_relay:
            logger.warning(
                "jstverify-tracing: relay transport is not supported for AppSync "
                "Lambda resolvers — GraphQL responses cannot carry custom HTTP "
                "headers. Skipping tracing."
            )
            return self._func(event, context)

        trace_id, original_parent_span_id, session_id = _extract_trace_context(event)
        set_session_id(session_id)
        appsync_span_id = str(uuid.uuid5(uuid.NAMESPACE_URL, trace_id))

        ctx = set_root_context(trace_id, parent_span_id=appsync_span_id)
        start_time = int(time.time() * 1000)

        operation = _build_operation_name(event, self._func)
        lambda_service_name = os.environ.get(
            "AWS_LAMBDA_FUNCTION_NAME", instance.service_name
        )

        status_code = 200
        status_message = None
        try:
            result = self._func(event, context)
            return result
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)

            # Synthetic AppSync parent span (deterministic spanId for dedup)
            appsync_span = {
                "traceId": ctx.trace_id,
                "spanId": appsync_span_id,
                "parentSpanId": original_parent_span_id,
                "operationName": operation,
                "serviceName": os.environ.get(
                    "APPSYNC_SERVICE_NAME",
                    f"{os.environ.get('ENVIRONMENT', 'unknown')}-{os.environ.get('PROJECTNAME', 'app')}-appsync",
                ),
                "serviceType": "appsync",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "statusMessage": status_message,
            }
            if session_id:
                appsync_span["sessionId"] = session_id

            # Lambda child span (with source location)
            lambda_span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": appsync_span_id,
                "operationName": operation,
                "serviceName": lambda_service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "statusMessage": status_message,
            }
            if session_id:
                lambda_span["sessionId"] = session_id
            lambda_span.update(from_code_object(self._func.__code__))

            instance._buffer.enqueue(appsync_span)
            instance._buffer.enqueue(lambda_span)
            remaining = _get_remaining_ms(context)
            if remaining is not None and remaining < _FLUSH_HEADROOM_MS:
                logger.debug(
                    "jstverify-tracing: skipping flush — %dms remaining",
                    remaining,
                )
            else:
                instance.flush()

            pop_context()
            clear_context()


def _extract_trace_context(event):
    """Extract trace ID and parent span ID from AppSync event.

    Priority order for trace ID:
    1. ``event["stash"]["jstverifyTraceId"]`` — pipeline resolvers share a
       trace ID via the VTL stash.
    2. ``event["request"]["headers"]["x-jstverify-trace-id"]`` — from an
       upstream frontend SDK.
    3. Auto-generated UUID.
    """
    # Priority 1: stash (pipeline resolvers share traceId via stash)
    stash = event.get("stash") or {}
    trace_id = stash.get("jstverifyTraceId")

    # Priority 2: HTTP headers (e.g., from frontend SDK)
    if not trace_id:
        request = event.get("request") or {}
        headers = request.get("headers") or {}
        normalized = {k.lower(): v for k, v in headers.items()}
        trace_id = normalized.get("x-jstverify-trace-id")

    # Priority 3: auto-generate
    if not trace_id:
        trace_id = str(uuid.uuid4())

    # Parent span and session ID from headers
    request = event.get("request") or {}
    headers = request.get("headers") or {}
    normalized = {k.lower(): v for k, v in headers.items()}
    parent_span_id = normalized.get("x-jstverify-parent-span-id")

    # Session ID: stash (pipeline) or headers (direct)
    session_id = stash.get("jstverifySessionId") or normalized.get("x-jstverify-session-id")

    return trace_id, parent_span_id, session_id


def _build_operation_name(event, func):
    """Build operation name from AppSync ``info`` field.

    Returns ``"ParentTypeName.fieldName"`` (e.g. ``"Query.listUsers"``),
    falling back to the function's ``__name__``.
    """
    info = event.get("info") or {}
    parent_type = info.get("parentTypeName")
    field_name = info.get("fieldName")
    if parent_type and field_name:
        return f"{parent_type}.{field_name}"
    return getattr(func, "__name__", "handler")
