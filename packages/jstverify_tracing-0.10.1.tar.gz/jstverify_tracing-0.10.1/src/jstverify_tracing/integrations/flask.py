"""Flask middleware for JstVerify distributed tracing."""

import time
import uuid

from .._context import set_root_context, pop_context, clear_context, set_session_id, get_session_id
from .._config import JstVerifyTracing


class JstVerifyTracingMiddleware:
    """Attach to a Flask app to auto-trace incoming requests.

    Usage:
        from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
        JstVerifyTracingMiddleware(app)
    """

    def __init__(self, app):
        self.app = app
        app.before_request(self._before_request)
        app.after_request(self._after_request)
        app.teardown_request(self._teardown_request)

    @staticmethod
    def _before_request():
        from flask import request, g

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return

        trace_id = request.headers.get("X-JstVerify-Trace-Id") or str(uuid.uuid4())
        parent_span_id = request.headers.get("X-JstVerify-Parent-Span-Id")
        session_id = request.headers.get("X-JstVerify-Session-Id")
        set_session_id(session_id)

        ctx = set_root_context(trace_id, parent_span_id)
        g._jstverify_ctx = ctx
        g._jstverify_start_time = int(time.time() * 1000)

    @staticmethod
    def _after_request(response):
        from flask import request, g

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return response

        ctx = getattr(g, "_jstverify_ctx", None)
        start_time = getattr(g, "_jstverify_start_time", None)
        if ctx is None or start_time is None:
            return response

        end_time = int(time.time() * 1000)
        session_id = get_session_id()
        span = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": ctx.parent_span_id,
            "operationName": f"{request.method} {request.path}",
            "serviceName": instance.service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": response.status_code,
            "httpMethod": request.method,
            "httpUrl": request.path,
            "httpStatusCode": response.status_code,
        }
        if session_id:
            span["sessionId"] = session_id

        if instance.is_relay:
            from .._relay_buffer import (
                enqueue_relay_span, drain_relay_spans,
                encode_relay_header, HEADER_NAME,
            )
            enqueue_relay_span(span)
            spans = drain_relay_spans()
            header_value = encode_relay_header(spans)
            if header_value is not None:
                response.headers[HEADER_NAME] = header_value
                response.headers["Access-Control-Expose-Headers"] = HEADER_NAME
        else:
            instance._buffer.enqueue(span)

        pop_context()
        return response

    @staticmethod
    def _teardown_request(exc):
        clear_context()
