"""PII sanitization for span data."""

import re
from typing import Optional

from ._types import SpanData

# Pre-compiled patterns
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b")
_PHONE_RE = re.compile(
    r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
)
_CC_RE = re.compile(r"\b(?:\d[ -]*?){13,16}\b")

_ALL_PATTERNS = [_SSN_RE, _EMAIL_RE, _PHONE_RE, _CC_RE]
_REDACTED = "[REDACTED]"


def sanitize_text(value: Optional[str]) -> Optional[str]:
    """Apply all PII patterns to a string, replacing matches with [REDACTED]."""
    if not value:
        return value
    for pattern in _ALL_PATTERNS:
        value = pattern.sub(_REDACTED, value)
    return value


def strip_url_query(url: Optional[str]) -> Optional[str]:
    """Remove query string and fragment from a URL, keeping only the path."""
    if not url:
        return url
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.path or "/"
    except Exception:
        return url


def sanitize_span(span: SpanData) -> None:
    """Sanitize PII from a span dict in-place."""
    if "statusMessage" in span and span["statusMessage"]:
        span["statusMessage"] = sanitize_text(span["statusMessage"])
    if "httpUrl" in span and span["httpUrl"]:
        span["httpUrl"] = strip_url_query(span["httpUrl"])
    if "operationName" in span and span["operationName"] and "?" in span["operationName"]:
        span["operationName"] = span["operationName"].split("?")[0]
