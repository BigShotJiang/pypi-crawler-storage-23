"""@trace decorator, trace_span() context manager, and trace_dynamodb() helper."""

import os
import time
import logging
from contextlib import contextmanager
from functools import wraps
from typing import Any, Optional

from ._context import start_child_context, pop_context, get_session_id
from ._source_location import from_code_object, from_caller
from ._types import SpanData

logger = logging.getLogger("jstverify_tracing")


def _enqueue(instance, span):
    """Route span to relay buffer or global buffer based on transport mode."""
    session_id = get_session_id()
    if session_id and "sessionId" not in span:
        span["sessionId"] = session_id
    if instance.is_relay:
        from ._relay_buffer import enqueue_relay_span
        enqueue_relay_span(span)
    else:
        instance._buffer.enqueue(span)


class SpanHandle:
    """Mutable handle yielded by trace_span for setting metadata."""

    def __init__(self):
        self.status_code: Optional[int] = None
        self.status_message: Optional[str] = None
        self.http_method: Optional[str] = None
        self.http_url: Optional[str] = None
        self.http_status_code: Optional[int] = None

    def set_status(self, code: int, message: Optional[str] = None) -> None:
        self.status_code = code
        self.status_message = message

    def set_http_metadata(
        self,
        method: Optional[str] = None,
        url: Optional[str] = None,
        status_code: Optional[int] = None,
    ) -> None:
        if method is not None:
            self.http_method = method
        if url is not None:
            self.http_url = url
        if status_code is not None:
            self.http_status_code = status_code


def trace(func_or_name=None):
    """Decorator that wraps a function in a traced span.

    Supports both bare and parameterized usage::

        @trace
        def my_func():
            ...

        @trace("custom operation name")
        def my_func():
            ...
    """

    def _make_wrapper(func, op_name):
        location = from_code_object(func.__code__)

        @wraps(func)
        def wrapper(*args, **kwargs):
            from ._config import JstVerifyTracing

            instance = JstVerifyTracing.get_instance()
            if instance is None:
                return func(*args, **kwargs)

            ctx = start_child_context()
            start_time = int(time.time() * 1000)
            status_code = 200
            status_message = None

            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                status_code = 500
                status_message = str(e)
                raise
            finally:
                end_time = int(time.time() * 1000)
                service_name = os.environ.get(
                    "AWS_LAMBDA_FUNCTION_NAME", instance.service_name
                )
                span: SpanData = {
                    "traceId": ctx.trace_id,
                    "spanId": ctx.span_id,
                    "parentSpanId": ctx.parent_span_id,
                    "operationName": op_name,
                    "serviceName": service_name,
                    "serviceType": instance.service_type,
                    "startTime": start_time,
                    "endTime": end_time,
                    "duration": end_time - start_time,
                    "statusCode": status_code,
                    "statusMessage": status_message,
                }
                span.update(location)
                _enqueue(instance, span)
                pop_context()

        return wrapper

    if callable(func_or_name):
        # Bare usage: @trace
        return _make_wrapper(func_or_name, func_or_name.__name__)

    # Parameterized usage: @trace("name")
    op_name = func_or_name

    def decorator(func):
        return _make_wrapper(func, op_name or func.__name__)

    return decorator


@contextmanager
def trace_span(operation_name: str):
    """Context manager that creates a traced span."""
    from ._config import JstVerifyTracing

    instance = JstVerifyTracing.get_instance()
    if instance is None:
        handle = SpanHandle()
        yield handle
        return

    location = from_caller(depth=2)
    ctx = start_child_context()
    start_time = int(time.time() * 1000)
    handle = SpanHandle()

    try:
        yield handle
    except Exception as e:
        if handle.status_code is None:
            handle.status_code = 500
        if handle.status_message is None:
            handle.status_message = str(e)
        raise
    finally:
        end_time = int(time.time() * 1000)
        service_name = os.environ.get(
            "AWS_LAMBDA_FUNCTION_NAME", instance.service_name
        )
        span: SpanData = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": ctx.parent_span_id,
            "operationName": operation_name,
            "serviceName": service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
        }
        if handle.status_code is not None:
            span["statusCode"] = handle.status_code
        if handle.status_message is not None:
            span["statusMessage"] = handle.status_message
        if handle.http_method is not None:
            span["httpMethod"] = handle.http_method
        if handle.http_url is not None:
            span["httpUrl"] = handle.http_url
        if handle.http_status_code is not None:
            span["httpStatusCode"] = handle.http_status_code
        span.update(location)
        _enqueue(instance, span)
        pop_context()


def trace_dynamodb(operation: str, table: Any, **kwargs) -> Any:
    """Wrap a DynamoDB operation in a traced span.

    Args:
        operation: DynamoDB operation name (e.g. "GetItem", "Query", "PutItem").
        table: boto3 DynamoDB Table resource.
        **kwargs: Arguments passed to the DynamoDB operation.

    Returns:
        The DynamoDB response.
    """
    from ._config import JstVerifyTracing

    instance = JstVerifyTracing.get_instance()

    # Resolve the boto3 method name (e.g. "GetItem" → "get_item")
    method_name = _to_method_name(operation)
    op_method = getattr(table, method_name, None)
    if op_method is None:
        raise AttributeError(f"Table has no method for operation: {operation}")

    if instance is None:
        return op_method(**kwargs)

    location = from_caller(depth=1)
    table_name = getattr(table, "table_name", str(table))
    ctx = start_child_context()
    start_time = int(time.time() * 1000)
    status_code = 200
    status_message = None

    from ._boto_patch import set_manual_dynamodb_trace

    try:
        set_manual_dynamodb_trace(True)
        result = op_method(**kwargs)
        return result
    except Exception as e:
        status_code = 500
        status_message = str(e)
        raise
    finally:
        set_manual_dynamodb_trace(False)
        end_time = int(time.time() * 1000)
        span: SpanData = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": ctx.parent_span_id,
            "operationName": f"{operation} {table_name}",
            "serviceName": table_name,
            "serviceType": "dynamodb",
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": status_code,
            "statusMessage": status_message,
        }
        span.update(location)
        _enqueue(instance, span)
        pop_context()


def _to_method_name(operation: str) -> str:
    """Convert DynamoDB operation name to boto3 method name.
    e.g. 'GetItem' -> 'get_item', 'Query' -> 'query'
    """
    result = []
    for i, c in enumerate(operation):
        if c.isupper() and i > 0:
            result.append("_")
        result.append(c.lower())
    return "".join(result)
