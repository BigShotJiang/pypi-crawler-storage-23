import json
from unittest.mock import MagicMock
import responses
import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing.integrations.awslambda import JstVerifyTracingMiddleware


@responses.activate
def test_lambda_middleware_creates_span_and_flushes():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200, "body": json.dumps({"msg": "ok"})}

    result = handler({"headers": {}}, None)
    assert result["statusCode"] == 200

    # Spans should have been flushed synchronously
    assert len(responses.calls) == 1
    payload = json.loads(responses.calls[0].request.body)
    assert len(payload["spans"]) == 1
    span = payload["spans"][0]
    assert span["operationName"] == "handler"
    assert span["serviceName"] == "my-lambda"
    assert span["serviceType"] == "lambda"
    assert span["statusCode"] == 200


@responses.activate
def test_lambda_middleware_propagates_trace_context():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    event = {
        "headers": {
            "X-JstVerify-Trace-Id": "trace-from-frontend",
            "X-JstVerify-Parent-Span-Id": "parent-from-frontend",
        }
    }
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    span = payload["spans"][0]
    assert span["traceId"] == "trace-from-frontend"
    assert span["parentSpanId"] == "parent-from-frontend"


@responses.activate
def test_lambda_middleware_case_insensitive_headers():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    # API Gateway may lowercase headers
    event = {
        "headers": {
            "x-jstverify-trace-id": "trace-lower",
            "x-jstverify-parent-span-id": "parent-lower",
        }
    }
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    span = payload["spans"][0]
    assert span["traceId"] == "trace-lower"
    assert span["parentSpanId"] == "parent-lower"


@responses.activate
def test_lambda_middleware_generates_trace_id_when_absent():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    handler({"headers": {}}, None)

    payload = json.loads(responses.calls[0].request.body)
    span = payload["spans"][0]
    assert span["traceId"]  # auto-generated UUID
    assert span["parentSpanId"] is None


@responses.activate
def test_lambda_middleware_captures_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        raise ValueError("boom")

    try:
        handler({"headers": {}}, None)
    except ValueError:
        pass

    payload = json.loads(responses.calls[0].request.body)
    span = payload["spans"][0]
    assert span["statusCode"] == 500
    assert span["statusMessage"] == "boom"


@responses.activate
def test_lambda_middleware_extracts_status_from_result():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 404, "body": "not found"}

    handler({"headers": {}}, None)

    payload = json.loads(responses.calls[0].request.body)
    span = payload["spans"][0]
    assert span["statusCode"] == 404


@responses.activate
def test_lambda_middleware_no_headers_key():
    """Lambda events may not have a headers key at all."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    # Event with no headers key (e.g. SQS trigger, scheduled event)
    handler({}, None)

    payload = json.loads(responses.calls[0].request.body)
    assert len(payload["spans"]) == 1


@responses.activate
def test_lambda_middleware_noop_without_init():
    """When SDK is not initialized, decorator is transparent."""

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    result = handler({"headers": {}}, None)
    assert result["statusCode"] == 200


@responses.activate
def test_lambda_middleware_with_child_spans():
    """Verify nested @trace spans inside a Lambda handler get correct parent-child links."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        with jstverify_tracing.trace_span("do-work") as span:
            span.set_status(200)
        return {"statusCode": 200}

    handler({"headers": {"X-JstVerify-Trace-Id": "t1"}}, None)

    payload = json.loads(responses.calls[0].request.body)
    spans = payload["spans"]
    assert len(spans) == 2

    child = spans[0]
    root = spans[1]
    assert child["operationName"] == "do-work"
    assert root["operationName"] == "handler"
    assert child["parentSpanId"] == root["spanId"]
    assert child["traceId"] == "t1"
    assert root["traceId"] == "t1"


@responses.activate
def test_lambda_middleware_skips_flush_when_low_remaining_time():
    """When Lambda has <2s remaining, span is enqueued but flush is skipped."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    instance = jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-lambda",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    ctx = MagicMock()
    ctx.get_remaining_time_in_millis.return_value = 500  # 500ms left

    handler({"headers": {}}, ctx)

    # No HTTP call should have been made
    assert len(responses.calls) == 0
    # But the span should be in the buffer
    assert len(instance._buffer._queue) == 1
