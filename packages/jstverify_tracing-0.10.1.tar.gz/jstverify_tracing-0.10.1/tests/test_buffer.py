import time
import responses

from jstverify_tracing._buffer import SpanBuffer
from jstverify_tracing._transport import Transport


def _make_span(op="test-op"):
    return {
        "traceId": "t1",
        "spanId": "s1",
        "parentSpanId": None,
        "operationName": op,
        "serviceName": "test",
        "serviceType": "http",
        "startTime": 1000,
        "endTime": 2000,
        "duration": 1000,
    }


@responses.activate
def test_enqueue_and_flush():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    transport = Transport("https://example.com/spans", "key")
    buf = SpanBuffer(transport, flush_interval=60, max_queue_size=10, max_batch_size=5)

    buf.enqueue(_make_span())
    assert len(buf._queue) == 1

    buf._flush()
    assert len(buf._queue) == 0
    assert len(responses.calls) == 1


@responses.activate
def test_circular_buffer_drops_oldest():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    transport = Transport("https://example.com/spans", "key")
    buf = SpanBuffer(transport, flush_interval=60, max_queue_size=3, max_batch_size=50)

    for i in range(5):
        buf.enqueue(_make_span(f"op-{i}"))

    assert len(buf._queue) == 3
    assert buf._queue[0]["operationName"] == "op-2"
    assert buf._queue[2]["operationName"] == "op-4"


@responses.activate
def test_batch_size_limit():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    transport = Transport("https://example.com/spans", "key")
    buf = SpanBuffer(transport, flush_interval=60, max_queue_size=100, max_batch_size=3)

    for i in range(7):
        buf.enqueue(_make_span(f"op-{i}"))

    buf._flush()
    # Should have sent first 3, leaving 4
    assert len(buf._queue) == 4
    assert len(responses.calls) == 1

    body = responses.calls[0].request.body
    import json
    payload = json.loads(body)
    assert len(payload["spans"]) == 3


def test_enqueue_noop_when_blocked():
    transport = Transport("https://example.com/spans", "key")
    transport.permanently_blocked = True
    buf = SpanBuffer(transport, flush_interval=60, max_queue_size=10, max_batch_size=5)

    buf.enqueue(_make_span())
    assert len(buf._queue) == 0


@responses.activate
def test_failed_flush_puts_back_spans():
    responses.add(responses.POST, "https://example.com/spans", status=500)
    transport = Transport("https://example.com/spans", "key")
    buf = SpanBuffer(transport, flush_interval=60, max_queue_size=10, max_batch_size=5)

    buf.enqueue(_make_span("op-1"))
    buf.enqueue(_make_span("op-2"))
    buf._flush()

    # Spans should be put back
    assert len(buf._queue) == 2


@responses.activate
def test_daemon_flush_thread():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    transport = Transport("https://example.com/spans", "key")
    buf = SpanBuffer(transport, flush_interval=0.1, max_queue_size=10, max_batch_size=50)

    buf.start()
    buf.enqueue(_make_span())
    time.sleep(0.3)  # Wait for flush thread
    buf.stop()

    assert len(responses.calls) >= 1
