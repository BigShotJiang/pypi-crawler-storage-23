import responses

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context
from jstverify_tracing._requests_patch import unpatch_requests


@responses.activate
def test_requests_patch_injects_headers():
    # Mock both the tracing endpoint and the target
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    responses.add(responses.GET, "https://api.example.com/data", json={"result": 1})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=True,
    )
    set_root_context("t1")

    import requests
    resp = requests.get("https://api.example.com/data")
    assert resp.status_code == 200

    # Check trace headers were injected
    target_call = responses.calls[0]
    assert target_call.request.headers["X-JstVerify-Trace-Id"] == "t1"
    assert "X-JstVerify-Parent-Span-Id" in target_call.request.headers


@responses.activate
def test_requests_patch_skips_tracing_endpoint():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=True,
    )
    set_root_context("t1")

    import requests
    # This should not add trace headers (it's the tracing endpoint itself)
    requests.post("https://example.com/spans", json={"spans": []})

    call = responses.calls[0]
    assert "X-JstVerify-Trace-Id" not in call.request.headers


@responses.activate
def test_requests_patch_skips_without_context():
    responses.add(responses.GET, "https://api.example.com/data", json={"result": 1})
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=True,
    )
    # Do NOT set root context

    import requests
    from jstverify_tracing._context import clear_context
    clear_context()
    resp = requests.get("https://api.example.com/data")
    assert resp.status_code == 200

    call = responses.calls[0]
    assert "X-JstVerify-Trace-Id" not in call.request.headers


@responses.activate
def test_requests_patch_records_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    responses.add(responses.GET, "https://api.example.com/users", json=[])

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=True,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    import requests
    requests.get("https://api.example.com/users")

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "GET /users"
        assert span["serviceType"] == "http"
        assert span["httpMethod"] == "GET"
        assert span["httpUrl"] == "/users"
        assert span["httpStatusCode"] == 200


@responses.activate
def test_unpatch_restores_original():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    responses.add(responses.GET, "https://api.example.com/data", json={})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=True,
    )
    unpatch_requests()
    set_root_context("t1")

    import requests
    requests.get("https://api.example.com/data")

    call = responses.calls[0]
    # After unpatch, no trace headers should be injected
    assert "X-JstVerify-Trace-Id" not in call.request.headers
