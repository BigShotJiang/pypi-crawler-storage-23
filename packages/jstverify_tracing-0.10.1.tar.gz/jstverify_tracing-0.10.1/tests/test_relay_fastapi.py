"""Tests for FastAPI middleware in relay transport mode."""

import base64
import json

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._relay_buffer import HEADER_NAME


def _init_relay():
    jstverify_tracing.init(
        api_key="key",
        service_name="fastapi-relay",
        transport="relay",
        patch_requests=False,
    )


def _make_app():
    app = FastAPI()
    from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware
    app.add_middleware(JstVerifyTracingMiddleware)
    return app


def test_relay_header_attached():
    _init_relay()
    app = _make_app()

    @app.get("/test")
    def test_view():
        return {"msg": "ok"}

    client = TestClient(app)
    resp = client.get("/test")
    assert resp.status_code == 200
    assert HEADER_NAME in resp.headers
    raw = resp.headers[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 1
    assert spans[0]["operationName"] == "GET /test"
    assert spans[0]["serviceName"] == "fastapi-relay"


def test_relay_no_http_calls():
    _init_relay()
    instance = JstVerifyTracing.get_instance()
    assert instance._buffer is None
    assert instance._transport is None


def test_relay_child_spans_included():
    _init_relay()
    app = _make_app()

    @app.get("/work")
    def work_view():
        with jstverify_tracing.trace_span("async-child") as span:
            span.set_status(200)
        return {"msg": "done"}

    client = TestClient(app)
    resp = client.get("/work")
    raw = resp.headers[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 2
    ops = [s["operationName"] for s in spans]
    assert "async-child" in ops
    assert "GET /work" in ops


def test_relay_cors_header():
    _init_relay()
    app = _make_app()

    @app.get("/test")
    def test_view():
        return {"msg": "ok"}

    client = TestClient(app)
    resp = client.get("/test")
    assert resp.headers.get("Access-Control-Expose-Headers") == HEADER_NAME


def test_relay_propagates_trace_id():
    _init_relay()
    app = _make_app()

    @app.get("/traced")
    def traced_view():
        return {"msg": "ok"}

    client = TestClient(app)
    resp = client.get("/traced", headers={
        "x-jstverify-trace-id": "relay-trace-fastapi",
        "x-jstverify-parent-span-id": "parent-fastapi",
    })
    raw = resp.headers[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert spans[0]["traceId"] == "relay-trace-fastapi"
    assert spans[0]["parentSpanId"] == "parent-fastapi"
