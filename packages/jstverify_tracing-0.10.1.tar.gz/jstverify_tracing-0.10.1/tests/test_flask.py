import json
import responses
import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing


@responses.activate
def test_flask_middleware_creates_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from flask import Flask

    app = Flask(__name__)

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="flask-svc",
        patch_requests=False,
    )

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/test")
    def test_view():
        return "ok"

    instance = JstVerifyTracing.get_instance()

    with app.test_client() as client:
        resp = client.get("/test")
        assert resp.status_code == 200

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "GET /test"
        assert span["serviceName"] == "flask-svc"
        assert span["statusCode"] == 200
        assert span["httpMethod"] == "GET"
        assert span["httpUrl"] == "/test"


@responses.activate
def test_flask_middleware_propagates_trace_id():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from flask import Flask

    app = Flask(__name__)

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="flask-svc",
        patch_requests=False,
    )

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/traced")
    def traced_view():
        return "ok"

    instance = JstVerifyTracing.get_instance()

    with app.test_client() as client:
        resp = client.get("/traced", headers={
            "X-JstVerify-Trace-Id": "incoming-trace-123",
            "X-JstVerify-Parent-Span-Id": "parent-span-456",
        })
        assert resp.status_code == 200

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["traceId"] == "incoming-trace-123"
        assert span["parentSpanId"] == "parent-span-456"


@responses.activate
def test_flask_middleware_generates_trace_id_when_absent():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from flask import Flask

    app = Flask(__name__)

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="flask-svc",
        patch_requests=False,
    )

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/no-trace")
    def view():
        return "ok"

    instance = JstVerifyTracing.get_instance()

    with app.test_client() as client:
        client.get("/no-trace")

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["traceId"]  # should have auto-generated
        assert span["parentSpanId"] is None
