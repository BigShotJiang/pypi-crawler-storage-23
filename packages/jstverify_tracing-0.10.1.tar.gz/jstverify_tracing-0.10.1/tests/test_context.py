from jstverify_tracing._context import (
    set_root_context,
    start_child_context,
    pop_context,
    get_current_context,
    clear_context,
)


def test_root_context_sets_trace_id():
    ctx = set_root_context("trace-abc", "parent-1")
    assert ctx.trace_id == "trace-abc"
    assert ctx.parent_span_id == "parent-1"
    assert ctx.span_id  # generated UUID


def test_root_context_generates_span_id():
    ctx = set_root_context("t1")
    assert len(ctx.span_id) == 36  # UUID format


def test_child_inherits_trace_id():
    root = set_root_context("t1")
    child = start_child_context()
    assert child.trace_id == "t1"
    assert child.parent_span_id == root.span_id


def test_nested_children():
    root = set_root_context("t1")
    child1 = start_child_context()
    child2 = start_child_context()
    assert child2.parent_span_id == child1.span_id
    assert child2.trace_id == "t1"


def test_pop_returns_and_removes_top():
    set_root_context("t1")
    child = start_child_context()
    popped = pop_context()
    assert popped.span_id == child.span_id
    current = get_current_context()
    assert current.trace_id == "t1"


def test_clear_empties_stack():
    set_root_context("t1")
    start_child_context()
    clear_context()
    assert get_current_context() is None


def test_root_context_resets_stack():
    set_root_context("t1")
    start_child_context()
    ctx = set_root_context("t2", "new-parent")
    assert ctx.trace_id == "t2"
    assert get_current_context().trace_id == "t2"


def test_child_without_root_creates_new_trace():
    clear_context()
    child = start_child_context()
    assert child.trace_id  # auto-generated
    assert child.parent_span_id is None


def test_pop_empty_returns_none():
    clear_context()
    assert pop_context() is None
