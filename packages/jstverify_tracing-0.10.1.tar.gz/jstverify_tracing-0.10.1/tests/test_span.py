import jstverify_tracing
from jstverify_tracing import trace, trace_span
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context

import pytest
import responses


@responses.activate
def test_trace_decorator_enqueues_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    @trace("my-op")
    def my_func():
        return 42

    result = my_func()
    assert result == 42

    # Check span was enqueued
    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "my-op"
        assert span["serviceName"] == "test-svc"
        assert span["serviceType"] == "http"
        assert span["traceId"] == "t1"
        assert span["statusCode"] == 200
        assert span["duration"] >= 0


@responses.activate
def test_trace_decorator_records_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    @trace("failing-op")
    def bad_func():
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        bad_func()

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["statusCode"] == 500
        assert span["statusMessage"] == "boom"


@responses.activate
def test_trace_span_context_manager():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    with trace_span("my-span") as span:
        span.set_status(201)
        span.set_http_metadata(method="POST", url="/api/test", status_code=201)

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        s = instance._buffer._queue[0]
        assert s["operationName"] == "my-span"
        assert s["statusCode"] == 201
        assert s["httpMethod"] == "POST"
        assert s["httpUrl"] == "/api/test"
        assert s["httpStatusCode"] == 201


@responses.activate
def test_trace_span_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    with pytest.raises(RuntimeError, match="fail"):
        with trace_span("err-span") as span:
            raise RuntimeError("fail")

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        s = instance._buffer._queue[0]
        assert s["statusCode"] == 500
        assert s["statusMessage"] == "fail"


@responses.activate
def test_nested_spans_parent_child():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="test-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    root = set_root_context("t1")

    @trace("outer")
    def outer():
        with trace_span("inner") as span:
            span.set_status(200)

    outer()

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 2
        inner_span = instance._buffer._queue[0]
        outer_span = instance._buffer._queue[1]
        assert inner_span["operationName"] == "inner"
        assert outer_span["operationName"] == "outer"
        # inner's parent should be outer's span
        assert inner_span["parentSpanId"] == outer_span["spanId"]
        # outer's parent should be root
        assert outer_span["parentSpanId"] == root.span_id


def test_trace_decorator_noop_without_init():
    """When SDK is not initialized, @trace should be transparent."""

    @trace("my-op")
    def my_func():
        return 99

    assert my_func() == 99


def test_trace_span_noop_without_init():
    """When SDK is not initialized, trace_span should be transparent."""
    with trace_span("my-span") as span:
        span.set_status(200)
    # No exception, no span recorded
