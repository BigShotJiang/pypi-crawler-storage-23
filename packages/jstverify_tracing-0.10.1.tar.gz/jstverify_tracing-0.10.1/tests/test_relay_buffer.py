"""Tests for the relay buffer module."""

import base64
import json
import threading

from jstverify_tracing._relay_buffer import (
    enqueue_relay_span,
    drain_relay_spans,
    encode_relay_header,
    MAX_HEADER_BYTES,
    HEADER_NAME,
    _relay_spans,
)


def _make_span(op="test-op", span_id="s1", parent_span_id=None, trace_id="t1"):
    return {
        "traceId": trace_id,
        "spanId": span_id,
        "parentSpanId": parent_span_id,
        "operationName": op,
        "serviceName": "test-svc",
        "serviceType": "http",
        "startTime": 1000,
        "endTime": 2000,
        "duration": 1000,
        "statusCode": 200,
    }


def test_enqueue_and_drain():
    span = _make_span()
    enqueue_relay_span(span)
    spans = drain_relay_spans()
    assert len(spans) == 1
    assert spans[0]["operationName"] == "test-op"


def test_drain_clears_buffer():
    enqueue_relay_span(_make_span())
    drain_relay_spans()
    assert drain_relay_spans() == []


def test_drain_empty_returns_empty_list():
    assert drain_relay_spans() == []


def test_encode_empty_returns_none():
    assert encode_relay_header([]) is None


def test_encode_single_span():
    span = _make_span()
    result = encode_relay_header([span])
    assert result is not None
    # Decode and verify
    padded = result + "=" * ((4 - len(result) % 4) % 4)
    decoded = json.loads(base64.urlsafe_b64decode(padded))
    assert len(decoded) == 1
    assert decoded[0]["operationName"] == "test-op"


def test_encode_is_base64url_no_padding():
    span = _make_span()
    result = encode_relay_header([span])
    assert "=" not in result
    assert "+" not in result
    assert "/" not in result


def test_encode_within_size_limit():
    spans = [_make_span(span_id=f"s{i}", parent_span_id="root") for i in range(5)]
    root = _make_span(op="root-op", span_id="root")
    result = encode_relay_header([root] + spans)
    assert result is not None
    assert len(result) <= MAX_HEADER_BYTES


def test_encode_truncation_drops_oldest_children():
    """When encoding exceeds limit, oldest children are dropped first."""
    root = _make_span(op="root-op", span_id="root")
    # Create many children to blow the limit
    children = [
        _make_span(op=f"child-{'x' * 200}-{i}", span_id=f"c{i}", parent_span_id="root")
        for i in range(100)
    ]
    result = encode_relay_header([root] + children)
    if result is not None:
        assert len(result) <= MAX_HEADER_BYTES
        padded = result + "=" * ((4 - len(result) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(padded))
        # Root should always be present
        ops = [s["operationName"] for s in decoded]
        assert "root-op" in ops


def test_encode_returns_none_when_root_exceeds_limit():
    """If even the root span alone exceeds the limit, return None."""
    root = _make_span(op="x" * 20000, span_id="root")
    assert encode_relay_header([root]) is None


def test_multiple_enqueue():
    enqueue_relay_span(_make_span(span_id="s1"))
    enqueue_relay_span(_make_span(span_id="s2"))
    enqueue_relay_span(_make_span(span_id="s3"))
    spans = drain_relay_spans()
    assert len(spans) == 3


def test_thread_isolation():
    """Spans enqueued in different threads (without shared ContextVar) are isolated."""
    results = {}

    def worker(name):
        enqueue_relay_span(_make_span(op=name))
        results[name] = drain_relay_spans()

    t1 = threading.Thread(target=worker, args=("thread-1",))
    t2 = threading.Thread(target=worker, args=("thread-2",))
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    assert len(results["thread-1"]) == 1
    assert results["thread-1"][0]["operationName"] == "thread-1"
    assert len(results["thread-2"]) == 1
    assert results["thread-2"][0]["operationName"] == "thread-2"


def test_header_name_constant():
    assert HEADER_NAME == "X-JstVerify-Spans"
