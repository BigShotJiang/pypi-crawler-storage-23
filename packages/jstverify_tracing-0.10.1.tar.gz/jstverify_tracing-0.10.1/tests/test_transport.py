import time
import responses

from jstverify_tracing._transport import Transport


def _make_spans():
    return [
        {
            "traceId": "t1",
            "spanId": "s1",
            "parentSpanId": None,
            "operationName": "test",
            "serviceName": "test",
            "serviceType": "http",
            "startTime": 1000,
            "endTime": 2000,
            "duration": 1000,
        }
    ]


@responses.activate
def test_send_success():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    transport = Transport("https://example.com/spans", "test-key")

    result = transport.send(_make_spans())
    assert result is True
    assert transport._failure_count == 0
    assert not transport.permanently_blocked

    # Verify request
    req = responses.calls[0].request
    assert req.headers["X-API-Key"] == "test-key"
    assert req.headers["Content-Type"] == "application/json"


@responses.activate
def test_send_403_permanently_blocks():
    responses.add(responses.POST, "https://example.com/spans", status=403)
    transport = Transport("https://example.com/spans", "test-key")

    result = transport.send(_make_spans())
    assert result is False
    assert transport.permanently_blocked is True

    # Subsequent sends return False immediately
    result2 = transport.send(_make_spans())
    assert result2 is False
    assert len(responses.calls) == 1  # no second request made


@responses.activate
def test_send_500_triggers_backoff():
    responses.add(responses.POST, "https://example.com/spans", status=500)
    transport = Transport("https://example.com/spans", "test-key")

    result = transport.send(_make_spans())
    assert result is False
    assert transport._failure_count == 1
    assert transport._next_retry_time > time.time()
    assert not transport.permanently_blocked


@responses.activate
def test_backoff_prevents_immediate_retry():
    responses.add(responses.POST, "https://example.com/spans", status=500)
    transport = Transport("https://example.com/spans", "test-key")

    transport.send(_make_spans())
    # Second send should be skipped (retry time not reached)
    result = transport.send(_make_spans())
    assert result is False
    assert len(responses.calls) == 1  # only first request made


@responses.activate
def test_success_resets_backoff():
    responses.add(responses.POST, "https://example.com/spans", status=500)
    transport = Transport("https://example.com/spans", "test-key")

    transport.send(_make_spans())
    assert transport._failure_count == 1

    # Reset retry time to allow immediate retry
    transport._next_retry_time = 0
    responses.reset()
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    result = transport.send(_make_spans())
    assert result is True
    assert transport._failure_count == 0
    assert transport._next_retry_time == 0


@responses.activate
def test_network_error_triggers_backoff():
    responses.add(responses.POST, "https://example.com/spans", body=ConnectionError("fail"))
    transport = Transport("https://example.com/spans", "test-key")

    result = transport.send(_make_spans())
    assert result is False
    assert transport._failure_count == 1
