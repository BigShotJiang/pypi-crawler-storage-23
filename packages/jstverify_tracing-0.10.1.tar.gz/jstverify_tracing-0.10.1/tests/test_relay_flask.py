"""Tests for Flask middleware in relay transport mode."""

import base64
import json

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._relay_buffer import HEADER_NAME


def _init_relay():
    jstverify_tracing.init(
        api_key="key",
        service_name="flask-relay",
        transport="relay",
        patch_requests=False,
    )


def test_relay_header_attached():
    from flask import Flask

    app = Flask(__name__)
    _init_relay()

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/test")
    def test_view():
        return "ok"

    with app.test_client() as client:
        resp = client.get("/test")
        assert resp.status_code == 200
        assert HEADER_NAME in resp.headers
        # Decode and verify span
        raw = resp.headers[HEADER_NAME]
        padded = raw + "=" * ((4 - len(raw) % 4) % 4)
        spans = json.loads(base64.urlsafe_b64decode(padded))
        assert len(spans) == 1
        assert spans[0]["operationName"] == "GET /test"
        assert spans[0]["serviceName"] == "flask-relay"


def test_relay_no_http_calls_made():
    """In relay mode, no outbound HTTP calls should be made to the ingestion endpoint."""
    from flask import Flask

    app = Flask(__name__)
    _init_relay()

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/test")
    def test_view():
        return "ok"

    instance = JstVerifyTracing.get_instance()
    assert instance._buffer is None
    assert instance._transport is None

    with app.test_client() as client:
        resp = client.get("/test")
        assert resp.status_code == 200


def test_relay_child_spans_included():
    """Child spans created via @trace should be included in the relay header."""
    from flask import Flask

    app = Flask(__name__)
    _init_relay()

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/work")
    def work_view():
        with jstverify_tracing.trace_span("do-work") as span:
            span.set_status(200)
        return "done"

    with app.test_client() as client:
        resp = client.get("/work")
        assert resp.status_code == 200
        raw = resp.headers[HEADER_NAME]
        padded = raw + "=" * ((4 - len(raw) % 4) % 4)
        spans = json.loads(base64.urlsafe_b64decode(padded))
        assert len(spans) == 2
        ops = [s["operationName"] for s in spans]
        assert "do-work" in ops
        assert "GET /work" in ops


def test_relay_cors_header_set():
    from flask import Flask

    app = Flask(__name__)
    _init_relay()

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/test")
    def test_view():
        return "ok"

    with app.test_client() as client:
        resp = client.get("/test")
        assert resp.headers.get("Access-Control-Expose-Headers") == HEADER_NAME


def test_relay_propagates_trace_id():
    from flask import Flask

    app = Flask(__name__)
    _init_relay()

    from jstverify_tracing.integrations.flask import JstVerifyTracingMiddleware
    JstVerifyTracingMiddleware(app)

    @app.route("/traced")
    def traced_view():
        return "ok"

    with app.test_client() as client:
        resp = client.get("/traced", headers={
            "X-JstVerify-Trace-Id": "relay-trace-123",
            "X-JstVerify-Parent-Span-Id": "parent-456",
        })
        raw = resp.headers[HEADER_NAME]
        padded = raw + "=" * ((4 - len(raw) % 4) % 4)
        spans = json.loads(base64.urlsafe_b64decode(padded))
        assert spans[0]["traceId"] == "relay-trace-123"
        assert spans[0]["parentSpanId"] == "parent-456"
