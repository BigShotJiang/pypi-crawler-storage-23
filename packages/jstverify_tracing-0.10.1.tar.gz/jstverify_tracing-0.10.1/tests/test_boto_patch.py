import responses
import pytest
import boto3
from botocore.stub import Stubber
from botocore.exceptions import ClientError

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context
from jstverify_tracing._boto_patch import patch_boto, unpatch_boto


def _init_sdk(**overrides):
    defaults = dict(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
        patch_boto=False,
    )
    defaults.update(overrides)
    return jstverify_tracing.init(**defaults)


def _get_spans(instance):
    with instance._buffer._lock:
        return list(instance._buffer._queue)


# ── 1. DynamoDB GetItem → correct span ──


@responses.activate
def test_dynamodb_get_item_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    patch_boto(True)
    client = boto3.client("dynamodb", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {"UserID": {"S": "123"}}},
            {"TableName": "users", "Key": {"UserID": {"S": "123"}}},
        )
        client.get_item(TableName="users", Key={"UserID": {"S": "123"}})

    spans = _get_spans(instance)
    assert len(spans) == 1
    span = spans[0]
    assert span["operationName"] == "DynamoDB.GetItem users"
    assert span["serviceName"] == "users"
    assert span["serviceType"] == "dynamodb"
    assert span["traceId"] == "t1"
    assert span["statusCode"] == 200
    assert span["duration"] >= 0


# ── 2. S3 GetObject → serviceType="aws", serviceName=bucket ──


@responses.activate
def test_s3_get_object_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    patch_boto(True)
    client = boto3.client("s3", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_response(
            "get_object",
            {"Body": "data", "ContentLength": 4, "ContentType": "text/plain"},
            {"Bucket": "my-assets", "Key": "file.txt"},
        )
        client.get_object(Bucket="my-assets", Key="file.txt")

    spans = _get_spans(instance)
    assert len(spans) == 1
    span = spans[0]
    assert span["operationName"] == "S3.GetObject my-assets"
    assert span["serviceName"] == "my-assets"
    assert span["serviceType"] == "aws"


# ── 3. Skips without active trace context ──


@responses.activate
def test_skips_without_trace_context():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    # Do NOT set root context

    patch_boto(True)
    client = boto3.client("dynamodb", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})

    spans = _get_spans(instance)
    assert len(spans) == 0


# ── 4. Skips when SDK uninitialized ──


def test_skips_when_sdk_uninitialized():
    patch_boto(True)
    client = boto3.client("dynamodb", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        result = client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})
        assert "Item" in result


# ── 5. Service filter → only traces specified services ──


@responses.activate
def test_service_filter_dynamodb_only():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    patch_boto(["dynamodb"])
    ddb_client = boto3.client("dynamodb", region_name="us-east-1")
    s3_client = boto3.client("s3", region_name="us-east-1")

    with Stubber(ddb_client) as ddb_stub, Stubber(s3_client) as s3_stub:
        ddb_stub.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        s3_stub.add_response(
            "get_object",
            {"Body": "x", "ContentLength": 1, "ContentType": "text/plain"},
            {"Bucket": "my-bucket", "Key": "k"},
        )

        ddb_client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})
        s3_client.get_object(Bucket="my-bucket", Key="k")

    spans = _get_spans(instance)
    assert len(spans) == 1
    assert spans[0]["serviceType"] == "dynamodb"


# ── 6. Error capture → Stubber ClientError → statusMessage set ──


@responses.activate
def test_error_capture():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    patch_boto(True)
    client = boto3.client("dynamodb", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_client_error(
            "get_item",
            service_error_code="ResourceNotFoundException",
            service_message="Requested resource not found",
        )
        with pytest.raises(ClientError):
            client.get_item(TableName="missing-table", Key={"ID": {"S": "1"}})

    spans = _get_spans(instance)
    assert len(spans) == 1
    span = spans[0]
    assert span["statusCode"] == 500
    assert "ResourceNotFoundException" in span["statusMessage"] or "not found" in span["statusMessage"]


# ── 7. No double-trace → patch_boto=True + trace_dynamodb() = one span ──


@responses.activate
def test_no_double_trace_with_trace_dynamodb():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    patch_boto(True)

    ddb = boto3.resource("dynamodb", region_name="us-east-1")
    table = ddb.Table("users")

    with Stubber(ddb.meta.client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {"UserID": {"S": "123"}}},
            {"TableName": "users", "Key": {"UserID": {"S": "123"}}},
        )
        jstverify_tracing.trace_dynamodb(
            "GetItem", table, Key={"UserID": {"S": "123"}}
        )

    spans = _get_spans(instance)
    # Only the manual trace_dynamodb span should exist, NOT the auto-patch span
    assert len(spans) == 1
    assert spans[0]["operationName"] == "GetItem users"


# ── 8. Unpatch restores originals ──


@responses.activate
def test_unpatch_restores_originals():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    original_client_fn = boto3.client
    patch_boto(True)
    assert boto3.client is not original_client_fn

    unpatch_boto()
    assert boto3.client is original_client_fn

    # After unpatch, new clients should not be instrumented
    client = boto3.client("dynamodb", region_name="us-east-1")
    with Stubber(client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})

    spans = _get_spans(instance)
    assert len(spans) == 0


# ── 9. Parent-child linking → parentSpanId correct ──


@responses.activate
def test_parent_child_linking():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk()
    instance = JstVerifyTracing.get_instance()
    root = set_root_context("t1")

    patch_boto(True)
    client = boto3.client("dynamodb", region_name="us-east-1")

    with Stubber(client) as stubber:
        stubber.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})

    spans = _get_spans(instance)
    assert len(spans) == 1
    assert spans[0]["parentSpanId"] == root.span_id
    assert spans[0]["traceId"] == "t1"


# ── 10. patch_boto=True via init() instruments all services ──


@responses.activate
def test_init_patch_boto_true_instruments_all():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    _init_sdk(patch_boto=True)
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    ddb_client = boto3.client("dynamodb", region_name="us-east-1")
    s3_client = boto3.client("s3", region_name="us-east-1")

    with Stubber(ddb_client) as ddb_stub, Stubber(s3_client) as s3_stub:
        ddb_stub.add_response(
            "get_item",
            {"Item": {}},
            {"TableName": "test-tbl", "Key": {"ID": {"S": "1"}}},
        )
        s3_stub.add_response(
            "list_buckets",
            {"Buckets": [], "Owner": {"DisplayName": "test", "ID": "123"}},
            {},
        )

        ddb_client.get_item(TableName="test-tbl", Key={"ID": {"S": "1"}})
        s3_client.list_buckets()

    spans = _get_spans(instance)
    assert len(spans) == 2
    service_types = {s["serviceType"] for s in spans}
    assert "dynamodb" in service_types
    assert "aws" in service_types
