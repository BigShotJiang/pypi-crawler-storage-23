"""Tests for Django middleware in relay transport mode."""

import base64
import json

import django
from django.conf import settings
from django.http import HttpResponse
from django.test import RequestFactory

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._relay_buffer import HEADER_NAME

# Minimal Django setup
if not settings.configured:
    settings.configure(
        DEBUG=True,
        DATABASES={},
        ROOT_URLCONF=__name__,
        MIDDLEWARE=[],
    )
    django.setup()


def _init_relay():
    jstverify_tracing.init(
        api_key="key",
        service_name="django-relay",
        transport="relay",
        patch_requests=False,
    )


def _simple_view(request):
    return HttpResponse("ok")


def _error_view(request):
    raise ValueError("boom")


def test_relay_header_attached():
    _init_relay()
    from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware

    middleware = JstVerifyTracingMiddleware(_simple_view)
    factory = RequestFactory()
    request = factory.get("/test")

    response = middleware(request)
    assert response.status_code == 200
    assert HEADER_NAME in response
    raw = response[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 1
    assert spans[0]["operationName"] == "GET /test"
    assert spans[0]["serviceName"] == "django-relay"


def test_relay_no_http_calls():
    _init_relay()
    instance = JstVerifyTracing.get_instance()
    assert instance._buffer is None
    assert instance._transport is None


def test_relay_child_spans_included():
    _init_relay()
    from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware

    def view_with_child(request):
        with jstverify_tracing.trace_span("child-op") as span:
            span.set_status(200)
        return HttpResponse("ok")

    middleware = JstVerifyTracingMiddleware(view_with_child)
    factory = RequestFactory()
    request = factory.get("/work")

    response = middleware(request)
    raw = response[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 2
    ops = [s["operationName"] for s in spans]
    assert "child-op" in ops
    assert "GET /work" in ops


def test_relay_cors_header():
    _init_relay()
    from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware

    middleware = JstVerifyTracingMiddleware(_simple_view)
    factory = RequestFactory()
    response = middleware(factory.get("/test"))
    assert response.get("Access-Control-Expose-Headers") == HEADER_NAME


def test_relay_exception_drains_buffer():
    """On exception, relay buffer is drained to prevent stale spans."""
    _init_relay()
    from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware

    middleware = JstVerifyTracingMiddleware(_error_view)
    factory = RequestFactory()

    try:
        middleware(factory.get("/err"))
    except ValueError:
        pass

    # Buffer should be empty after exception
    from jstverify_tracing._relay_buffer import drain_relay_spans
    assert drain_relay_spans() == []


def test_relay_propagates_trace_id():
    _init_relay()
    from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware

    middleware = JstVerifyTracingMiddleware(_simple_view)
    factory = RequestFactory()
    request = factory.get(
        "/traced",
        HTTP_X_JSTVERIFY_TRACE_ID="relay-trace-django",
        HTTP_X_JSTVERIFY_PARENT_SPAN_ID="parent-django",
    )

    response = middleware(request)
    raw = response[HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert spans[0]["traceId"] == "relay-trace-django"
    assert spans[0]["parentSpanId"] == "parent-django"
