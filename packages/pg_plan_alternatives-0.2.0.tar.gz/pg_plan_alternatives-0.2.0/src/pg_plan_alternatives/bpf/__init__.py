"""
BPF code package for pg_plan_alternatives
Contains eBPF C code for instrumenting PostgreSQL
"""
