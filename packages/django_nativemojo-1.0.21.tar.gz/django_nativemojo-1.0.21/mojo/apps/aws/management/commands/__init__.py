"""
Management commands for mojo.apps.aws.

This file marks the commands directory as a Python package so Django can
discover bundled management commands.
"""