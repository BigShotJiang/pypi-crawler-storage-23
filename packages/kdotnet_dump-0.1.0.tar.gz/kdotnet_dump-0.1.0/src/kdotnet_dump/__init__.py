"""kdotnet-dump: CLI tool for creating .NET dumps from Kubernetes pods"""

from .cli import main

__all__ = ["main"]
