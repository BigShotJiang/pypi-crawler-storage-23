# vagary

Lightweight VM-based GUI testing

> [!CAUTION]
> This project is in early planning stage. APIs and configuration format will change.

A lightweight command-line tool for automated GUI testing in VMs.
Write test scenarios in YAML, run against Vagrant boxes using VNC and SSH.

## Usage

See examples in `examples` directory for scenario syntax and patterns.

## License

MIT
