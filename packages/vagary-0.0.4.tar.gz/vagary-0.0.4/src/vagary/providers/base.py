from abc import ABC, abstractmethod


class BaseProvider(ABC):
    vnc_host: str = "127.0.0.1"
    vnc_port: int = 5900

    @abstractmethod
    def start(self) -> None: ...

    @abstractmethod
    def stop(self) -> None: ...

    def get_ssh_config(self) -> dict | None:
        """Return SSH connection parameters or None if SSH is not supported."""
        return None
