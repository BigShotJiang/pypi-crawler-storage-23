from pathlib import Path
import typer
from vagary.runner import Runner
from vagary.schemas import Scenario

app = typer.Typer()

@app.command()
def main(
    scenario_path: Path = typer.Argument(
        help="Path to the scenario YAML file",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
    )
):
    """
    Run a test scenario from a YAML configuration file.
    """
    sc = None
    with open(scenario_path) as f:
        sc = Scenario.from_yaml(f)

    runner = Runner(sc, base_path=scenario_path.parent)

    try:
        runner.run()
    except Exception as e:
        typer.echo(f"\nError: {e}", err=True)
        raise typer.Exit(code=1)
    finally:
        try:
            runner.mm.close()
        except Exception:
            pass


def entry_point() -> None:
    typer.run(main)

if __name__ == "__main__":
    entry_point()
