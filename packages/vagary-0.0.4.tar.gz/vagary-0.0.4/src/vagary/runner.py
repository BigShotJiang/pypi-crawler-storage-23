import time
import urllib.request
import yaml
from pathlib import Path
from typing import List
from urllib.parse import urlparse

from pydantic import TypeAdapter

import vagary.schemas as schemas
from vagary.schemas import Scenario
from vagary.machine_manager import MachineManager

_steps_adapter = TypeAdapter(List[schemas.Step])


class Runner:
    def __init__(self, scenario: Scenario, base_path: Path = Path(".")):
        self.scenario = scenario
        self.base_path = base_path
        self.mm = MachineManager(scenario.machine)

    def run(self):
        self._run_setup()
        self._run_steps()
        self._run_teardown()

    def _run_setup(self):
        print("\n=== SETUP ===")
        self.mm.start()
        self.mm.connect_ssh()
        self.mm.connect_vnc()

    def _run_step(self, step: schemas.Step, indent: int = 0):
        print(step.format_step(indent))

        if isinstance(step, schemas.ScreenshotStep):
            self.mm.vnc_screenshot(step.path)
        if isinstance(step, schemas.ExpectRegionStep):
            self.mm.vnc_expect_region(step.path, step.pos.x, step.pos.y, maxrms=step.maxrms)
        if isinstance(step, schemas.KeyStep):
            self.mm.vnc_key(step.key)
        if isinstance(step, schemas.TypeStep):
            self.mm.vnc_type(step.text)
        if isinstance(step, schemas.ShellStep):
            self.mm.exec(step.run)
        if isinstance(step, schemas.ClickStep):
            self.mm.vnc_click(step.pos.x, step.pos.y)
        if isinstance(step, schemas.MoveStep):
            self.mm.vnc_move(step.pos.x, step.pos.y)
        if isinstance(step, schemas.GroupStep):
            for s in step.steps:
                self._run_step(s, indent=indent + 1)
        if isinstance(step, schemas.IncludeStep):
            self._run_include(step, indent)
        if isinstance(step, schemas.SleepStep):
            time.sleep(step.time)
        time.sleep(self.scenario.settings.sleep_between_steps)

    def _load_include_content(self, path: str) -> str:
        parsed = urlparse(path)
        if parsed.scheme in ("http", "https"):
            with urllib.request.urlopen(path) as response:
                return response.read().decode("utf-8")
        local = Path(path)
        if not local.is_absolute():
            local = self.base_path / local
        return local.read_text()

    def _run_include(self, step: schemas.IncludeStep, indent: int = 0):
        content = self._load_include_content(step.path)
        data = yaml.safe_load(content)
        steps = _steps_adapter.validate_python(data)
        for s in steps:
            self._run_step(s, indent=indent + 1)

    def _run_steps(self):
        print("\n=== STEPS ===")

        for step in self.scenario.steps:
            self._run_step(step)

    def _run_teardown(self):

        print("\n=== TEARDOWN ===")
        self.mm.close()
