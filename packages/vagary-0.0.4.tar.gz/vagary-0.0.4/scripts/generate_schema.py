#!/usr/bin/env python3
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))

from pydantic import TypeAdapter

from vagary.schemas import Scenario

adapter = TypeAdapter(Scenario)
schema = adapter.json_schema()

output = ROOT / "schema.json"
output.write_text(json.dumps(schema, indent=2) + "\n")

subprocess.run(["git", "add", str(output)], check=True, cwd=ROOT)
