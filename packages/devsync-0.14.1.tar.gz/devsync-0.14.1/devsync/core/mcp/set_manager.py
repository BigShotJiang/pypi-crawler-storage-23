"""MCP set activation and management."""
