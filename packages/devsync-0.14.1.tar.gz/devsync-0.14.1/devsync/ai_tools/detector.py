"""AI tool detection and auto-discovery."""

from typing import Optional

from devsync.ai_tools.aider import AiderTool
from devsync.ai_tools.amazonq import AmazonQTool
from devsync.ai_tools.amp import AmpTool
from devsync.ai_tools.anteroom import AnteroomTool
from devsync.ai_tools.antigravity import AntigravityTool
from devsync.ai_tools.augment import AugmentTool
from devsync.ai_tools.base import AITool
from devsync.ai_tools.claude import ClaudeTool
from devsync.ai_tools.cline import ClineTool
from devsync.ai_tools.codex import CodexTool
from devsync.ai_tools.continuedev import ContinueTool
from devsync.ai_tools.copilot import CopilotTool
from devsync.ai_tools.cursor import CursorTool
from devsync.ai_tools.gemini import GeminiTool
from devsync.ai_tools.jetbrains import JetBrainsTool
from devsync.ai_tools.junie import JunieTool
from devsync.ai_tools.kiro import KiroTool
from devsync.ai_tools.opencode import OpenCodeTool
from devsync.ai_tools.openhands import OpenHandsTool
from devsync.ai_tools.roo import RooTool
from devsync.ai_tools.tabnine import TabnineTool
from devsync.ai_tools.trae import TraeTool
from devsync.ai_tools.winsurf import WinsurfTool
from devsync.ai_tools.zed import ZedTool
from devsync.core.models import AIToolType


class AIToolDetector:
    """Detect and manage AI coding tools."""

    def __init__(self) -> None:
        """Initialize detector with all supported tools."""
        self.tools: dict[AIToolType, AITool] = {
            AIToolType.CURSOR: CursorTool(),
            AIToolType.COPILOT: CopilotTool(),
            AIToolType.WINSURF: WinsurfTool(),
            AIToolType.CLAUDE: ClaudeTool(),
            AIToolType.KIRO: KiroTool(),
            AIToolType.CLINE: ClineTool(),
            AIToolType.ROO: RooTool(),
            AIToolType.CODEX: CodexTool(),
            AIToolType.GEMINI: GeminiTool(),
            AIToolType.ANTIGRAVITY: AntigravityTool(),
            AIToolType.AMAZONQ: AmazonQTool(),
            AIToolType.JETBRAINS: JetBrainsTool(),
            AIToolType.JUNIE: JunieTool(),
            AIToolType.ZED: ZedTool(),
            AIToolType.CONTINUE: ContinueTool(),
            AIToolType.AIDER: AiderTool(),
            AIToolType.TRAE: TraeTool(),
            AIToolType.AUGMENT: AugmentTool(),
            AIToolType.TABNINE: TabnineTool(),
            AIToolType.OPENHANDS: OpenHandsTool(),
            AIToolType.AMP: AmpTool(),
            AIToolType.OPENCODE: OpenCodeTool(),
            AIToolType.ANTEROOM: AnteroomTool(),
        }

    def detect_installed_tools(self) -> list[AITool]:
        """
        Detect all installed AI coding tools.

        Returns:
            List of installed AITool instances
        """
        installed = []
        for tool in self.tools.values():
            if tool.is_installed():
                installed.append(tool)
        return installed

    def get_tool_by_name(self, name: str) -> Optional[AITool]:
        """
        Get AI tool instance by name.

        Args:
            name: Tool name (cursor, copilot, winsurf, claude)

        Returns:
            AITool instance or None if not found
        """
        try:
            tool_type = AIToolType(name.lower())
            return self.tools.get(tool_type)
        except ValueError:
            return None

    def get_tool_by_type(self, tool_type: AIToolType) -> Optional[AITool]:
        """
        Get AI tool instance by type.

        Args:
            tool_type: AIToolType enum value

        Returns:
            AITool instance
        """
        return self.tools.get(tool_type)

    def get_primary_tool(self) -> Optional[AITool]:
        """
        Get the primary (first detected) AI tool.

        Priority order: Cursor, Copilot, Winsurf, Claude Code

        Returns:
            First installed AITool or None if none installed
        """
        # Check in priority order
        priority = [
            AIToolType.CURSOR,
            AIToolType.COPILOT,
            AIToolType.WINSURF,
            AIToolType.CLAUDE,
            AIToolType.KIRO,
            AIToolType.CLINE,
            AIToolType.ROO,
            AIToolType.CODEX,
            AIToolType.GEMINI,
            AIToolType.ANTIGRAVITY,
            AIToolType.AMAZONQ,
            AIToolType.JETBRAINS,
            AIToolType.JUNIE,
            AIToolType.ZED,
            AIToolType.CONTINUE,
            AIToolType.AIDER,
            AIToolType.TRAE,
            AIToolType.AUGMENT,
            AIToolType.TABNINE,
            AIToolType.OPENHANDS,
            AIToolType.AMP,
            AIToolType.OPENCODE,
            AIToolType.ANTEROOM,
        ]

        for tool_type in priority:
            tool = self.tools[tool_type]
            if tool.is_installed():
                return tool

        return None

    def is_any_tool_installed(self) -> bool:
        """
        Check if any AI coding tool is installed.

        Returns:
            True if at least one tool is detected
        """
        return len(self.detect_installed_tools()) > 0

    def get_tool_names(self) -> list[str]:
        """
        Get list of all supported tool names.

        Returns:
            List of tool name strings
        """
        return [tool_type.value for tool_type in self.tools.keys()]

    def validate_tool_name(self, name: str) -> bool:
        """
        Validate if tool name is supported.

        Args:
            name: Tool name to validate

        Returns:
            True if tool is supported
        """
        return name.lower() in self.get_tool_names()

    def get_detection_summary(self) -> dict[str, bool]:
        """
        Get detection summary for all tools.

        Returns:
            Dictionary mapping tool names to installation status
        """
        return {tool_type.value: tool.is_installed() for tool_type, tool in self.tools.items()}

    def format_detection_summary(self) -> str:
        """
        Format detection summary as human-readable string.

        Returns:
            Formatted summary string
        """
        summary = self.get_detection_summary()
        lines = ["AI Coding Tools Detection:"]

        for tool_name, is_installed in summary.items():
            status = "✓ Installed" if is_installed else "✗ Not found"
            lines.append(f"  {tool_name.capitalize()}: {status}")

        return "\n".join(lines)


# Singleton instance for convenience
_detector_instance: Optional[AIToolDetector] = None


def get_detector() -> AIToolDetector:
    """
    Get singleton AIToolDetector instance.

    Returns:
        AIToolDetector instance
    """
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = AIToolDetector()
    return _detector_instance
