"""Track active MCP sets per project."""
