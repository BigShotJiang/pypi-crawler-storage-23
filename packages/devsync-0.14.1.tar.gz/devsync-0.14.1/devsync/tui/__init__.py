"""TUI (Text User Interface) components for DevSync."""
