"""phykit.__main__: executed when phykit is called as script"""

from .phykit import Phykit

Phykit()
