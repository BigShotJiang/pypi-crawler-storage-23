"""Browser automation helpers."""
