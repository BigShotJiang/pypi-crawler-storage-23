from ._rm import rm

__all__ = ["rm"]
