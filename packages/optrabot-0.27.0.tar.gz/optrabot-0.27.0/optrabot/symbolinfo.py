from dataclasses import dataclass
from typing import Dict
import pytz

@dataclass
class SymbolInfo:
	"""
	The Symbol Info class is a data class that holds the information of a symbol.
	Broker Connectors can add their specific information to this class.
	"""
	symbol: str
	strike_interval: float
	quote_step: float
	option_symbol_suffix: str
	timezone: pytz.tzinfo
	sanity_price_lower: float  # OTB-361: Lower limit for price sanity check
	sanity_price_upper: float  # OTB-361: Upper limit for price sanity check

	def __init__(self, symbol: str, option_symbol_suffix: str, strike_interval: float, quote_step: float, multiplier: float, exchange: str, trading_class: str, timezone: str, sanity_price_lower: float = 0, sanity_price_upper: float = float('inf')) -> None:
		self.symbol = symbol
		self.strike_interval = strike_interval
		self.quote_step = quote_step
		self.multiplier = multiplier
		self.option_symbol_suffix = option_symbol_suffix
		self.exchange = exchange
		self.trading_class = trading_class
		self.timezone = pytz.timezone(timezone)
		self.sanity_price_lower = sanity_price_lower
		self.sanity_price_upper = sanity_price_upper
		pass

def initialize_symbol_infos() -> Dict[str, SymbolInfo]:
	symbol_info_dict = {
		# OTB-361: Added sanity price limits for each symbol
		"SPX" : SymbolInfo("SPX", "W", 5, 0.05, 100, "SMART", "SPXW", "US/Eastern", sanity_price_lower=1000, sanity_price_upper=20000),
		"VIX" : SymbolInfo("VIX", "W", 1, 0.05, 1000, "SMART", "VIXW", "US/Eastern", sanity_price_lower=5, sanity_price_upper=150),
	}
	return symbol_info_dict

symbol_infos = initialize_symbol_infos()