from loguru import logger
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import models, schemas


#########################################
#### Acount							 ####
#########################################
def create_account(session: Session, account: schemas.AccountCreate) -> models.Account:
	""" Create a new account in the database
	"""
	db_account = models.Account(id=account.id, name=account.name, broker=account.broker, pdt=account.pdt)
	session.add(db_account)
	session.commit()
	return db_account

def update_account(session: Session, account: models.Account) -> models.Account:
	""" Updates the account in the database
	"""
	session.merge(account)
	session.commit()
	return account

def get_account(session: Session, id: str) -> models.Account:
	""" Fetches the data of the given account based on the ID.
	"""
	statement = select(models.Account).filter_by(id=id)
	account = session.scalars(statement).first()
	return account

def get_accounts(session: Session, skip: int = 0, limit: int = 100):
	stmnt = select(models.Account)
	accounts = session.scalars(stmnt).all()
	
	return accounts

#########################################
#### Trade							 ####
#########################################
def create_trade(session: Session, newTrade: schemas.TradeCreate) -> models.Trade:
	""" Create a new trade in the database
	"""
	dbTrade = models.Trade(
		account=newTrade.account, 
		symbol=newTrade.symbol, 
		strategy=newTrade.strategy,
		template_name=newTrade.template_name  # OTB-253: Store template name for recovery
	)
	session.add(dbTrade)
	session.commit()
	session.flush()
	logger.debug('Created new trade: {}', dbTrade)
	return dbTrade

def getTrade(session: Session, tradeId: int) -> models.Trade:
	""" Get a trade by it's id
	"""
	return session.get(models.Trade, tradeId)

def update_trade(session: Session, trade: models.Trade) -> models.Trade:
	""" Updates the trade in the database
	"""
	session.merge(trade)
	session.commit()
	session.flush()
	logger.debug('Updated trade: {}', trade)
	return trade

def delete_trade(session: Session, deleteTrade: models.Trade):
	""" Deletes the trade from the database
	"""
	# Reload trade from session to ensure proper session binding
	# This avoids issues with detached objects and their relationships
	trade_to_delete = session.get(models.Trade, deleteTrade.id)
	if trade_to_delete is not None:
		session.delete(trade_to_delete)
		session.commit()
		logger.debug('Deleted trade: {}', deleteTrade.id)
	else:
		logger.warning('Trade {} not found in database, nothing to delete', deleteTrade.id)
	return

#########################################
#### Transaction					 ####
#########################################
def getMaxTransactionId(session: Session, tradeId: int) -> int:
	statement = select(func.max(models.Transaction.id)).filter_by(tradeid=tradeId)
	maxId = session.scalar(statement)
	if maxId == None:
		maxId = 0
	return maxId

def getTransactionById(session: Session, tradeId: int, transactionId: int) -> models.Transaction:
	""" Fetches the transaction based on the Trade ID and Transaction ID
	"""
	statement = select(models.Transaction).filter_by(tradeid=tradeId, id=transactionId)
	transaction = session.scalars(statement).first()
	return transaction

def get_transaction_by_execution_id(session: Session, trade_id: int, execution_id: str) -> models.Transaction:
	""" Fetches the transaction based on the execution ID
	"""
	statement = select(models.Transaction).filter_by(tradeid=trade_id, exec_id=execution_id)
	transaction = session.scalars(statement).first()
	return transaction

def createTransaction(session: Session, newTransaction: schemas.TransactionCreate) -> models.Transaction:
	""" Creates a new transaction record for the given trade
	"""
	db_transaction = models.Transaction(tradeid=newTransaction.tradeid, id=newTransaction.id,
									type=newTransaction.type,
									sectype=newTransaction.sectype,
									timestamp=newTransaction.timestamp,
									expiration=newTransaction.expiration,
									strike=newTransaction.strike,
									contracts=newTransaction.contracts,
									price=newTransaction.price,
									fee=newTransaction.fee,
									commission=newTransaction.commission,
									notes=newTransaction.notes,
									exec_id=newTransaction.exec_id)
	session.add(db_transaction)
	session.commit()
	return db_transaction


#########################################
#### Settings						 ####
#########################################
def get_setting(session: Session, key: str) -> models.Setting:
	"""Get a setting by its key"""
	statement = select(models.Setting).filter_by(key=key)
	return session.scalars(statement).first()

def get_setting_value(session: Session, key: str, default: str = None) -> str:
	"""Get a setting value by its key, return default if not found"""
	setting = get_setting(session, key)
	return setting.value if setting else default

def set_setting(session: Session, key: str, value: str, description: str = None) -> models.Setting:
	"""Set a setting value (create or update)"""
	from datetime import datetime

	import pytz
	
	setting = get_setting(session, key)
	if setting:
		setting.value = value
		setting.updated_at = datetime.now(pytz.UTC)
		if description:
			setting.description = description
	else:
		setting = models.Setting(
			key=key,
			value=value,
			description=description,
			updated_at=datetime.now(pytz.UTC)
		)
		session.add(setting)
	
	session.commit()
	return setting

def delete_setting(session: Session, key: str) -> bool:
	"""Delete a setting by its key"""
	setting = get_setting(session, key)
	if setting:
		session.delete(setting)
		session.commit()
		return True
	return False


#########################################
#### Economic Calendar (OTB-387)	 ####
#########################################
def upsert_economic_events(session: Session, events: list[models.EconomicEvent],
                           from_date, to_date) -> None:
	"""Replace economic events only for dates that appear in the new data.

	Instead of blindly deleting the entire from_date..to_date range
	(which would wipe out previously cached days that the API didn't
	return data for), we only delete+replace dates that are actually
	present in the new event list.
	"""
	if not events:
		return

	# Determine which dates are covered by the new data
	new_dates = {e.event_date for e in events}

	# Delete existing events only for those specific dates
	session.query(models.EconomicEvent).filter(
		models.EconomicEvent.event_date.in_(new_dates),
	).delete(synchronize_session='fetch')

	# Insert new events
	for event in events:
		session.add(event)
	session.commit()


def get_economic_events(session: Session, from_date, to_date,
                        countries: list[str] | None = None,
                        importances: list[int] | None = None) -> list[models.EconomicEvent]:
	"""Query economic events with optional filters."""
	query = session.query(models.EconomicEvent).filter(
		models.EconomicEvent.event_date >= from_date,
		models.EconomicEvent.event_date <= to_date,
	)
	if countries:
		countries_lower = [c.lower() for c in countries]
		query = query.filter(func.lower(models.EconomicEvent.country).in_(countries_lower))
	if importances:
		query = query.filter(models.EconomicEvent.importance.in_(importances))

	return query.order_by(
		models.EconomicEvent.event_date,
		models.EconomicEvent.time,
		models.EconomicEvent.importance.desc()
	).all()


def get_cached_event_dates(session: Session, from_date, to_date) -> set:
	"""Return the set of distinct dates that have cached events in the given range."""
	rows = session.query(models.EconomicEvent.event_date).filter(
		models.EconomicEvent.event_date >= from_date,
		models.EconomicEvent.event_date <= to_date,
	).distinct().all()
	return {row[0] for row in rows}


def delete_old_economic_events(session: Session, before_date) -> int:
	"""Delete economic events older than the given date. Returns count of deleted rows."""
	count = session.query(models.EconomicEvent).filter(
		models.EconomicEvent.event_date < before_date,
	).delete()
	session.commit()
	return count
