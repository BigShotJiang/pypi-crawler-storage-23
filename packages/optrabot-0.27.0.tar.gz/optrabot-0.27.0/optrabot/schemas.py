from datetime import date, datetime

from pydantic import BaseModel


class AccountBase(BaseModel):
	id: str
	name: str
	broker: str
	pdt: bool

class AccountCreate(AccountBase):
	pass

class Account(AccountBase):
	class Config:
		from_attributes = True

class TransactionBase(BaseModel):
	tradeid: int
	id: int
	type: str
	sectype: str
	timestamp: datetime
	expiration: date
	strike: float
	contracts: int
	price: float
	fee: float
	commission: float
	notes: str
	exec_id: str

class TransactionCreate(TransactionBase):
	pass

class Transaction(TransactionBase):
	class Config:
		from_attributes = True

class TradeBase(BaseModel):
	account: str
	symbol: str
	strategy: str
	template_name: str | None = None  # OTB-253: Optional for backward compatibility

class TradeCreate(TradeBase):
	pass

class Trade(TradeBase):
	id: int
	status: str
	realizedPNL: float
	status: str 
	transactions: list[Transaction] = []

	class Config:
		from_attributes = True


# ══════════════════════════════════════════════════════════════════════════════
# Economic Calendar (OTB-387)
# ══════════════════════════════════════════════════════════════════════════════

class EconomicEventResponse(BaseModel):
	"""Single economic calendar event."""
	id: int
	event_date: date
	time: str | None = None
	currency: str | None = None
	country: str | None = None
	importance: int  # 1=low, 2=medium, 3=high
	event_name: str
	actual: str | None = None
	forecast: str | None = None
	previous: str | None = None

	class Config:
		from_attributes = True


class CalendarEventsResponse(BaseModel):
	"""Response containing a list of economic events."""
	from_date: date
	to_date: date
	events: list[EconomicEventResponse]
	total: int
	source_timezone: str = 'America/New_York'  # IANA timezone of event times


class CalendarSettingsResponse(BaseModel):
	"""Current calendar settings."""
	dashboard_countries: list[str]
	dashboard_importance: list[str]
	source_timezone: str = 'America/New_York'  # IANA timezone of event times


class CalendarSettingsRequest(BaseModel):
	"""Request to update calendar settings."""
	dashboard_countries: list[str] | None = None
	dashboard_importance: list[str] | None = None