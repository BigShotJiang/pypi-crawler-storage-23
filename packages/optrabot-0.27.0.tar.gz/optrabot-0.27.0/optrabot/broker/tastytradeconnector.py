import asyncio
import re
import ssl
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Tuple

import certifi
import pytz
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from httpx import ConnectError
from loguru import logger
from pydantic import ValidationError
from websockets.exceptions import ConnectionClosedOK

import optrabot.config as optrabotcfg
import optrabot.symbolinfo as symbolInfo
from optrabot.broker.brokerconnector import (BrokerConnector, ChartInterval,
                                             OHLCBar, SymbolData)
from optrabot.broker.optionpricedata import (OptionStrikeData,
                                             OptionStrikePriceData)
from optrabot.broker.order import Execution
from optrabot.broker.order import Leg as GenericOrderLeg
from optrabot.broker.order import OptionRight
from optrabot.broker.order import Order as GenericOrder
from optrabot.broker.order import OrderAction as GenericOrderAction
from optrabot.broker.order import OrderStatus as GenericOrderStatus
from optrabot.broker.order import PriceEffect
from optrabot.broker.tastytrade import (Account, AlertStreamer, DXLinkStreamer,
                                        Session)
from optrabot.broker.tastytrade.account import Transaction
from optrabot.broker.tastytrade.dxfeed import Candle, Greeks, Quote
from optrabot.broker.tastytrade.instruments import (NestedOptionChain, Option,
                                                    OptionType, Strike)
from optrabot.broker.tastytrade.order import (NewComplexOrder, NewOrder,
                                              OrderAction, OrderStatus,
                                              OrderTimeInForce, OrderType,
                                              PlacedOrder)
from optrabot.broker.tastytrade.utils import TastytradeError
from optrabot.exceptions.orderexceptions import (PlaceOrderException,
                                                 PrepareOrderException)
from optrabot.managedtrade import ManagedTrade
from optrabot.models import Account as ModelAccount
from optrabot.optionhelper import OptionHelper
from optrabot.tradetemplate.templatefactory import Template


@dataclass
class TastySymbolData(SymbolData):
	def __init__(self) -> None:
		super().__init__()
		self.tastySymbol: str = None
		self.chain: NestedOptionChain = None

class TastytradeConnector(BrokerConnector):
	task_listen_quotes: asyncio.Task = None

	def __init__(self) -> None:
		super().__init__()
		self._client_secret = ''
		self._refresh_token = ''
		self._sandbox = False
		self._initialize()
		self.id = 'TASTY'
		self.broker = 'TASTY'
		self._orders: List[GenericOrder] = []
		self._replacedOrders: List[PlacedOrder] = []
		self._processed_transaction_ids: List[int] = []
		self._is_disconnecting = False
		self._is_reconnecting_alert_streamer = False  # Guard against multiple simultaneous reconnects
		self._session: Session = None
		self._streamer: DXLinkStreamer = None
		self._alert_streamer: AlertStreamer = None
		self._quote_symbols = []
		self._candle_symbols = []
		self._greeks_symbols = []
		self._tasty_accounts: List[Account] = []
		self._symbolReverseLookup: Dict[str, str] = {}		# maps tastytrade symbol to generic symbol

		self.task_listen_quotes = None
		self.task_listen_accounts = None
		self.task_listen_greeks = None
		self.task_listen_candle = None

		# OTB-335: Track old streamers to avoid zombie tasks
		# When a streamer is replaced, add the old one to this set so we can
		# ignore disconnect callbacks from old streamers
		self._closed_streamer_ids: set = set()

		self._backgroundScheduler = AsyncIOScheduler()

		# OTB-373: Cache for chart data (price history)
		# Key: (symbol, interval), Value: (timestamp, List[OHLCBar])
		self._chart_cache: Dict[Tuple[str, str], Tuple[datetime, List[OHLCBar]]] = {}
		self._chart_cache_ttl = timedelta(minutes=1)  # Cache TTL: 1 minute

	def _stop_background_scheduler(self) -> None:
		"""
		OTB-335: Safely stop the background scheduler.
		Handles SchedulerNotRunningError which can occur if shutdown is called multiple times.
		"""
		try:
			if self._backgroundScheduler.running:
				self._backgroundScheduler.remove_all_jobs()
				self._backgroundScheduler.shutdown(wait=False)
				logger.debug('Background scheduler stopped')
		except Exception as e:
			# SchedulerNotRunningError or other exceptions during shutdown
			logger.debug(f'Background scheduler already stopped or error during shutdown: {e}')

	def _initialize(self) -> None:
		"""
		Initialize the Tastytrade connector from the configuration
		"""
		if not optrabotcfg.appConfig:
			return
		
		config :optrabotcfg.Config = optrabotcfg.appConfig
		try:
			config.get('broker.tastytrade')
		except KeyError:
			logger.debug('No Tastytrade connection configured')
			return
		
		try:
			self._client_secret = config.get('broker.tastytrade.client_secret')
		except KeyError:
			logger.error('Tastytrade client_secret not configured')
			return
		
		try:
			self._refresh_token = config.get('broker.tastytrade.refresh_token')
		except KeyError:
			logger.error('Tastytrade refresh_token not configured')
			return
		
		try:
			self._sandbox = config.get('broker.tastytrade.sandbox')
		except KeyError:
			pass
		self._initialized = True

	async def cancel_order(self, order: GenericOrder) -> None:
		""" 
		Cancels the given order
		"""
		await super().cancel_order(order)
		tasty_order: PlacedOrder = order.brokerSpecific['order']
		account: Account = order.brokerSpecific['account']
		logger.debug(f'Cancelling order {tasty_order.id}')
		try:
			account.delete_order(self._session, str(tasty_order.id))
		except TastytradeError as tastyErr:
			logger.error(f'Error cancelling order {tasty_order.id}: {tastyErr}')
			raise

	async def connect(self) -> None:
		await super().connect()
		self._is_disconnecting = False
		self._is_reconnecting_alert_streamer = False  # Reset reconnect guard on new connection
		# OTB-335: Clear old streamer tracking set on fresh connection to prevent memory leak
		# Old streamer IDs are no longer relevant after a full reconnect
		self._closed_streamer_ids.clear()
		try:
			#self._session = Session(self._username, self._password, is_test=self._sandbox)
			self._session = Session(provider_secret=self._client_secret, refresh_token=self._refresh_token, is_test=self._sandbox)
			await self.set_trading_enabled(True, 'Broker connected')
			
			# I Sandbox mode, there are SPX optins only
			if self._sandbox:
				spx_symbol_information = symbolInfo.symbol_infos['SPX']
				spx_symbol_information.trading_class = 'SPX'
				spx_symbol_information.option_symbol_suffix = ''

			# OTB-xxx: Verify session is ready by attempting to retrieve accounts
			# This prevents race conditions where connectedEvent is emitted before
			# the session is fully initialized and ready to handle API calls.
			# If successful, accounts are cached for subsequent getAccounts() calls.
			max_retries = 3
			session_ready = False
			for attempt in range(max_retries):
				try:
					self._tasty_accounts = Account.get(self._session)
					if len(self._tasty_accounts) > 0:
						logger.debug(f'Session verified - {len(self._tasty_accounts)} account(s) accessible')
						session_ready = True
						break
					else:
						logger.debug(f'Session not ready - no accounts found (attempt {attempt + 1}/{max_retries})')
				except Exception as e:
					logger.debug(f'Session verification failed (attempt {attempt + 1}/{max_retries}): {e}')

				if attempt < max_retries - 1:
					await asyncio.sleep(0.2)  # Brief delay between retries
			
			if not session_ready:
				logger.warning('Session created but verification failed after 3 attempts - proceeding with caution')
			
			# Convert tasty accounts to managed accounts immediately after verification
			# This ensures getAccounts() returns valid data when called from _onBrokerConnected
			# before the streamer is initialized (which affects isConnected())
			if session_ready and len(self._tasty_accounts) > 0:
				for tastyAccount in self._tasty_accounts:
					account = ModelAccount(
						id=tastyAccount.account_number, 
						name=tastyAccount.nickname, 
						broker=self.id, 
						pdt=not tastyAccount.day_trader_status
					)
					self._managedAccounts.append(account)
				logger.debug(f'Converted {len(self._managedAccounts)} accounts to managed accounts')

			# OTB-335: Handle scheduler lifecycle for reconnects
			# After shutdown(), a scheduler cannot be restarted - we need a new instance
			if self._backgroundScheduler.running:
				logger.debug('Background scheduler already running, removing old jobs')
				self._backgroundScheduler.remove_all_jobs()
			else:
				# Scheduler was shutdown or never started - create new instance
				try:
					self._backgroundScheduler.start()
				except Exception as e:
					# If start fails (e.g., scheduler was shutdown), create new scheduler
					logger.debug(f'Creating new scheduler instance: {e}')
					self._backgroundScheduler = AsyncIOScheduler()
					self._backgroundScheduler.start()
			
			self._backgroundScheduler.add_job(self._perform_periodic_updates, 'interval', seconds=10, misfire_grace_time=None)

			self._emitConnectedEvent()
		except TastytradeError as tastyErr:
			logger.error('Failed to connect to Tastytrade: {}', tastyErr)
			self._emitConnectFailedEvent()
		except ConnectError:
			logger.debug('Failed to connect to Tastytrade - network connection error')
			self._emitConnectFailedEvent()

	async def _disconnect_internal(self) -> None:
		"""
		Perform the operations for disconnecting from Tastytrade
		"""
		# Note: _is_disconnecting should already be set to True before calling this method
		logger.debug('Starting _disconnect_internal')
		await self.set_trading_enabled(False, 'Broker disconnected')
		
		# OTB-335: Stop the background scheduler first to prevent periodic updates during disconnect
		self._stop_background_scheduler()

		# OTB-335: Store references and clear them BEFORE closing
		# This prevents the disconnect callbacks from trying to do anything
		# when they are triggered by the close() calls
		streamer_to_close = self._streamer
		alert_streamer_to_close = self._alert_streamer
		
		# OTB-335: Mark these streamers as closed to ignore future callbacks
		if streamer_to_close:
			self._closed_streamer_ids.add(id(streamer_to_close))
		if alert_streamer_to_close:
			self._closed_streamer_ids.add(id(alert_streamer_to_close))
		
		self._streamer = None
		self._alert_streamer = None
		logger.debug('Cleared streamer references before closing')

		# FIRST: Close streamers gracefully to stop their internal _connect tasks
		# The disconnect callbacks will see _is_disconnecting=True and exit early
		if streamer_to_close:
			try:
				logger.debug('Closing DXLink streamer')
				await asyncio.wait_for(streamer_to_close.close(), timeout=2.0)
				logger.debug('DXLink streamer closed')
			except asyncio.TimeoutError:
				logger.warning('Timeout closing DXLink streamer')
			except asyncio.CancelledError:
				logger.debug('DXLink streamer close was cancelled')
			except Exception as e:
				logger.debug(f'Error closing DXLink streamer: {e}')
		
		if alert_streamer_to_close:
			try:
				logger.debug('Closing Alert streamer')
				await asyncio.wait_for(alert_streamer_to_close.close(), timeout=2.0)
				logger.debug('Alert streamer closed')
			except asyncio.TimeoutError:
				logger.warning('Timeout closing Alert streamer')
			except asyncio.CancelledError:
				logger.debug('Alert streamer close was cancelled')
			except Exception as e:
				logger.debug(f'Error closing Alert streamer: {e}')

		# SECOND: Now cancel our listener tasks (which should already be stopping)
		tasks_to_cancel = [
			task for task in [
				self.task_listen_quotes,
				self.task_listen_greeks,
				self.task_listen_candle,
				self.task_listen_accounts
			] if task and not task.done()
		]

		if tasks_to_cancel:
			logger.debug(f'Cancelling {len(tasks_to_cancel)} listener tasks')
			for task in tasks_to_cancel:
				task.cancel()
			
			# OTB-335: Wait for tasks to complete cancellation properly to avoid
			# "Task was destroyed but it is pending!" warnings
			try:
				await asyncio.wait_for(
					asyncio.gather(*tasks_to_cancel, return_exceptions=True),
					timeout=3.0
				)
				logger.debug('All listener tasks cancelled successfully')
			except asyncio.TimeoutError:
				logger.warning('Timeout waiting for listener tasks to cancel - some tasks may still be pending')
			except asyncio.CancelledError:
				logger.debug('Task cancellation was itself cancelled')
			except Exception as e:
				logger.debug(f'Error waiting for listener tasks to cancel: {e}')

		# THIRD: Let event loop clean up cancelled tasks
		# (streamer references were already cleared before closing)
		if tasks_to_cancel:
			logger.debug('Listener tasks cancelled - will be cleaned up by event loop')
		
		# Give event loop time to process cancellations
		try:
			await asyncio.sleep(0.1)
		except asyncio.CancelledError:
			logger.debug('Sleep was cancelled during disconnect')

		# Clear task references
		self.task_listen_quotes = None
		self.task_listen_greeks = None
		self.task_listen_candle = None
		self.task_listen_accounts = None

		# Close session
		self._session = None
		
		# Clear cached account data
		self._tasty_accounts = []
		
		self._emitDisconnectedEvent()

	async def disconnect(self):
		"""
		Disconnect from Tastytrade broker.
		Sets _is_disconnecting flag BEFORE starting disconnect operations to prevent
		reconnect attempts from disconnect callbacks.
		"""
		await super().disconnect()
		# Set flag BEFORE calling _disconnect_internal to prevent reconnect attempts
		self._is_disconnecting = True
		await self._disconnect_internal()

	def getAccounts(self) -> List[ModelAccount]:
		"""
		Returns the Tastytrade accounts and starts the account update task for listening to updates on orders.
		Uses cached account data from connect() if available.
		"""
		# Accounts are now loaded during connect(), so we just need to start the listener task
		# if it hasn't been started yet
		if len(self._managedAccounts) > 0 and self.task_listen_accounts is None and self._session is not None:
			# Start account update listener task
			self.task_listen_accounts = asyncio.create_task(self._request_account_updates())
		
		# Fallback: If accounts were not loaded during connect() for some reason
		if len(self._managedAccounts) == 0 and self._session is not None:
			# If accounts were not already loaded in connect(), load them now
			if len(self._tasty_accounts) == 0:
				self._tasty_accounts = Account.get(self._session)
			
			for tastyAccount in self._tasty_accounts:
				account = ModelAccount(id=tastyAccount.account_number, name=tastyAccount.nickname, broker=self.id, pdt=not tastyAccount.day_trader_status)
				self._managedAccounts.append(account)

			# Store the task reference so we can cancel it during disconnect
			if self.task_listen_accounts is None:
				self.task_listen_accounts = asyncio.create_task(self._request_account_updates())
		return self._managedAccounts
	
	def isConnected(self) -> bool:
		# Check session exists AND streamer is connected (not just session)
		# When streamer disconnects unexpectedly, session remains but streamer is None
		return self._session is not None and self._streamer is not None
		
	async def prepareOrder(self, order: GenericOrder, need_valid_price_data: bool = True) -> None:
		"""
		Prepares the given order for execution

		Args:
			order: The order to prepare
			need_valid_price_data: If True, validates price data availability and freshness.
								   If False, creates order legs without price validation (e.g., for trade recovery)

		Raises:
			PrepareOrderException: If the order preparation fails with a specific reason.
		"""
		symbolData = self._symbolData[order.symbol]
		comboLegs: list[GenericOrderLeg] = []
		for leg in order.legs:
			optionInstrument: Option = None
			
			if need_valid_price_data:
				# Normal order flow: use price data with validation
				try:
					optionPriceData = symbolData.optionPriceData[leg.expiration]
				except KeyError as keyErr:
					raise PrepareOrderException(f'No option price data for expiration date {leg.expiration} available!', order)

				try:
					priceData: OptionStrikePriceData = optionPriceData.strikeData[leg.strike]
					if not priceData.is_outdated():
						if leg.right == OptionRight.CALL:
							leg.askPrice = float(priceData.callAsk)
							if leg.askPrice == None:
								leg.askPrice = 0
							leg.bidPrice = float(priceData.callBid)
							if leg.bidPrice == None:
								leg.bidPrice = 0
							optionInstrument = Option.get(self._session, priceData.brokerSpecific['call_option'])
						elif leg.right == OptionRight.PUT:
							leg.askPrice = float(priceData.putAsk)
							if leg.askPrice == None:
								leg.askPrice = 0
							leg.bidPrice = float(priceData.putBid)
							if leg.bidPrice == None:
								leg.bidPrice = 0
							optionInstrument = Option.get(self._session, priceData.brokerSpecific['put_option'])
					else:
						raise PrepareOrderException(f'Price data for strike {leg.strike} is outdated or not available!', order)

				except KeyError as keyErr:
					# No data for strike available
					raise PrepareOrderException(f'No option price data for strike {leg.strike} available!', order)
				except Exception as excp:
					raise PrepareOrderException(f'Error preparing order: {excp}', order)
			else:
				# Trade recovery flow: create option instrument without price data validation
				try:
					# Use the cached option chain from symbolData
					if symbolData.chain is None:
						raise PrepareOrderException(
							f'No option chain available for {order.symbol} - symbol data may not be initialized', 
							order
						)
					
					# Find the specific option in the cached chain
					for expiration in symbolData.chain.expirations:
						if expiration.expiration_date == leg.expiration:
							for strike in expiration.strikes:
								if abs(float(strike.strike_price) - leg.strike) < 0.01:  # Float comparison tolerance
									if leg.right == OptionRight.CALL and strike.call is not None:
										optionInstrument = Option.get(self._session, strike.call)
										leg.askPrice = 0
										leg.bidPrice = 0
										break
									elif leg.right == OptionRight.PUT and strike.put is not None:
										optionInstrument = Option.get(self._session, strike.put)
										leg.askPrice = 0
										leg.bidPrice = 0
										break
							if optionInstrument:
								break
					
					if optionInstrument is None:
						raise PrepareOrderException(
							f'Could not find option instrument for {order.symbol} {leg.expiration} {leg.strike} {leg.right}', 
							order
						)
				except PrepareOrderException:
					raise
				except Exception as e:
					raise PrepareOrderException(f'Error creating option instrument for trade recovery: {e}', order)
			
			# Build the leg for the tasty trade order
			mapped_action = self._mappedOrderAction(order.action, leg.action)
			logger.debug(f'Mapping order.action={order.action} leg.action={leg.action} -> mapped_action={mapped_action}')
			comboLeg = optionInstrument.build_leg(quantity=Decimal(leg.quantity * order.quantity), action=mapped_action)
			comboLegs.append(comboLeg)
			leg.brokerSpecific['tasty_symbol'] = comboLeg.symbol  # Memorize the tastytrade symbol identifier for later transaction processing

		order.brokerSpecific['comboLegs'] = comboLegs
		order.determine_price_effect()
		return True
	
	def _transform_generic_order(self, generic_order: GenericOrder) -> NewOrder:
		"""
		Transforms the given generic order to a tastytrade order
		"""
		new_order_legs = generic_order.brokerSpecific['comboLegs']
		price = abs(generic_order.price)
		tasty_price = Decimal(price * -1 if generic_order.price_effect == PriceEffect.DEBIT else price)
		rounded_tasty_price: Decimal = round(tasty_price, 2)
		new_order = None
		if generic_order.type == OrderType.LIMIT:
			new_order = NewOrder(
				time_in_force=OrderTimeInForce.DAY,
				order_type=generic_order.type,	
				legs=new_order_legs,
				price=rounded_tasty_price
			)
		elif generic_order.type == OrderType.STOP:
			if len(generic_order.legs) == 1:
				new_order = NewOrder(
					time_in_force=OrderTimeInForce.DAY,
					order_type=generic_order.type,	
					legs=new_order_legs,
					stop_trigger=rounded_tasty_price
				)
			else:
				# Stop Orders with multiple legs must be Stop Limit Orders
				calculated_limit_price = OptionHelper.roundToTickSize(round(rounded_tasty_price * Decimal('1.25'), 2))  # Round to the nearest tick size
				tasty_limit_price: Decimal = Decimal(calculated_limit_price)
				
				new_order = NewOrder(
					time_in_force=OrderTimeInForce.DAY,
					order_type=OrderType.STOP_LIMIT,
					legs=new_order_legs,
					stop_trigger=Decimal(abs(rounded_tasty_price)),
					price=tasty_limit_price
				)
		return new_order
	
	async def placeOrder(self, managed_trade: ManagedTrade, order: GenericOrder, parent_order: GenericOrder = None) -> None:
		""" 
		Places the given order for a managed account via the broker connection.
		
		Raises:
			PlaceOrderException: If the order placement fails with a specific reason.
		"""
		account = Account.get(self._session, managed_trade.template.account)
		newOrder = self._transform_generic_order(order)
		try:
			response = account.place_order(self._session, newOrder, dry_run=False)
			#placedComplexOrders = account.get_live_complex_orders(session=self._session)
			#placedOrders = account.get_live_orders(session=self._session)
			#for order in placedOrders:
			#	logger.debug(f'Live order: {order.id} underlying: {order.underlying_symbol}')
			#	#account.delete_order(session=self._session, order_id=order.id)
			logger.debug(f'Response of place Order: {response}')
			if response.errors:
				for errorMessage in response.errors:
					raise PlaceOrderException(errorMessage, order=order)
			if response.warnings:
				for warningMessage in response.warnings:
					logger.warning(f'Warning placing order: {warningMessage}')
			
			order.brokerSpecific['order'] = response.order
			order.brokerSpecific['account'] = account
			self._orders.append(order)
			logger.debug(f'Order {response.order.id} placed successfully')
		except TastytradeError as tastyErr:
			raise PlaceOrderException(f'{tastyErr}', order=order)
		except ValidationError as valErr:
			logger.error(f'Validation error placing order: {valErr}')
			err = valErr.errors()[0]
			logger.error(err)
		except Exception as exc:
			raise PlaceOrderException(f'{exc}', order=order)

	async def place_complex_order(self, take_profit_order: GenericOrder, stop_loss_order: GenericOrder, template: Template) -> bool:
		"""
		Places the Take Profit and Stop Loss Order as complex order
		"""
		account = Account.get(self._session, template.account)
		new_order_tp = self._transform_generic_order(take_profit_order)
		new_order_sl = self._transform_generic_order(stop_loss_order)
		oco_order = NewComplexOrder( orders=[ new_order_tp, new_order_sl ] )
		try:
			dry_run = False
			response = account.place_complex_order(self._session, oco_order, dry_run=dry_run)
			logger.debug(f'Response of place_complex_order: {response}')
			if response.errors:
				for errorMessage in response.errors:
					logger.error(f'Error placing order: {errorMessage}')
					return False
			if response.warnings:
				for warningMessage in response.warnings:
					logger.warning(f'Warning placing order: {warningMessage}')
			
			try:
				take_profit_order.brokerSpecific['order'] = response.complex_order.orders[0]
				take_profit_order.brokerSpecific['account'] = account
				self._orders.append(take_profit_order)
			except IndexError as indexErr:
				logger.error(f'Error complex order. Take Profit order not found in complex order response!')
				return False

			try: 
				stop_loss_order.brokerSpecific['order'] = response.complex_order.orders[1]
				stop_loss_order.brokerSpecific['account'] = account
				self._orders.append(stop_loss_order)
			except IndexError as indexErr:
				logger.error(f'Error complex order. Stop Loss order not found in complex order response!')
				return False

			logger.debug(f'Complex Order {response.complex_order.id} placed successfully')
			return True
		except TastytradeError as tastyErr:
			logger.error(f'Error placing order: {tastyErr}')
		except ValidationError as valErr:
			logger.error(f'Validation error placing order: {valErr}')
			err = valErr.errors()[0]
			logger.error(err)
			#logger.error(repr(valErr.errors()[0]['type']))
		except Exception as exc:
			logger.error(f'Unexpected exception placing order: {exc}')
			
		return False		
		
	async def adjustOrder(self, managed_trade: ManagedTrade, order: GenericOrder, price: float) -> bool:
		""" 
		Adjusts the given order with the given new price
		"""
		if order.status == GenericOrderStatus.FILLED:
			logger.info('Order {} is already filled. Adjustment not required.', order)
			return True
		try:
			tasty_order: PlacedOrder = order.brokerSpecific['order']
		except KeyError as keyErr:
			logger.error(f'Order {order.broker_order_id} not prepared for adjustment. Cannot adjust order.')
			return False
		
		account: Account = order.brokerSpecific['account']
		logger.debug(f'Adjusting order {tasty_order.id} to price {price}')

		order.price = price
		replacement_order = self._transform_generic_order(order)

		#new_order_legs = order.brokerSpecific['comboLegs']
		#new_price = abs(price)
		#tasty_price = Decimal(new_price * -1 if order.price_effect == PriceEffect.DEBIT else new_price)

		# if order.type == OrderType.LIMIT:
		# 	replacement_order = NewOrder(
		# 		time_in_force=OrderTimeInForce.DAY,
		# 		order_type=order.type,	
		# 		legs=new_order_legs,
		# 		price=tasty_price
		# 	)
		# elif order.type == OrderType.STOP:
		# 	replacement_order = NewOrder(
		# 		time_in_force=OrderTimeInForce.DAY,
		# 		order_type=order.type,	
		# 		legs=new_order_legs,
		# 		stop_trigger=tasty_price
		# 	)
		# elif order.type == OrderType.MARKET:
		# 	replacement_order = NewOrder(
		# 		time_in_force=OrderTimeInForce.DAY,
		# 		order_type=order.type,	
		# 		legs=new_order_legs
		# 	)

		try:
			self._replacedOrders.append(tasty_order)  # Merken für das Cancel Event dieser Order
			response: PlacedOrder = account.replace_order(session=self._session, old_order_id=tasty_order.id, new_order=replacement_order)
			# OTB-378: Keep track of replaced order IDs for order matching
			# This allows us to match FILLED events for the original order
			if 'replaced_order_ids' not in order.brokerSpecific:
				order.brokerSpecific['replaced_order_ids'] = []
			order.brokerSpecific['replaced_order_ids'].append(tasty_order.id)
			order.brokerSpecific['order'] = response
			#self._replacedOrders.append(response) # Auch die neue Order zu den zu ignorierenden Orders hinzufügen
			logger.debug(f'Replacment order {response.id} submitted successfully')
			return True
		
		except TastytradeError as tastyErr:
			logger.error(f'Error adjusting order: {tastyErr}')
			return False
		except ValidationError as valErr:
			logger.error(f'Validation error adjusting order: {valErr}')
			err = valErr.errors()[0]
			logger.error(err)
			return False 

	async def _perform_periodic_updates(self) -> None:
		"""
		Background job for fetching new transactions from Tastytrade for order executions.
		This is required for getting the commission and fee data.
		Additionally it checks if the access token needs to be refreshed.
		
		OTB-335: Improved error handling for connection issues and timeouts.
		"""
		try:
			if not self.isConnected():
				return
			
			# OTB-335: Skip if we're in the process of disconnecting
			if self._is_disconnecting:
				logger.debug('Skipping periodic updates - disconnect in progress')
				return
			
			# Check if access token needs to be refreshed
			from optrabot.broker.tastytrade.utils import now_in_new_york
			if self._session.session_expiration < now_in_new_york() + timedelta(seconds=25):
				logger.debug('Access token is about to expire, refreshing...')
				try:
					# OTB-335: Run session refresh in executor with timeout to prevent blocking
					await asyncio.wait_for(
						asyncio.get_event_loop().run_in_executor(None, self._session.refresh),
						timeout=10.0
					)
				except asyncio.TimeoutError:
					logger.warning('Session token refresh timed out after 10s')
					return  # Skip this iteration if token refresh times out
				except Exception as refresh_err:
					logger.warning(f'Failed to refresh session token: {refresh_err}')
					return  # Skip this iteration if token refresh fails

			for tasty_account in self._tasty_accounts:
				try:
					# OTB-335: Add timeout for transaction fetch to prevent blocking
					transactions = await asyncio.wait_for(
						asyncio.get_event_loop().run_in_executor(
							None, 
							lambda: tasty_account.get_history(self._session, start_date=date.today())
						),
						timeout=8.0  # 8 second timeout per account
					)
					for transaction in transactions:
						if transaction.transaction_type != 'Trade' or transaction.id in self._processed_transaction_ids:
							continue
						self._processed_transaction_ids.append(transaction.id)
						await self._process_transaction(tasty_account, transaction)
				except asyncio.CancelledError:
					# Exit gracefully - don't re-raise to APScheduler
					logger.debug('Periodic updates task cancelled')
					return
				except asyncio.TimeoutError:
					logger.warning(f'Timeout fetching transactions for account {tasty_account.account_number}')
					# Don't break the loop - try other accounts
				except Exception as account_err:
					logger.warning(f'Error fetching transactions for account {tasty_account.account_number}: {account_err}')
		
		except asyncio.CancelledError:
			logger.debug('Periodic updates task cancelled')
			return  # Exit gracefully - don't re-raise to APScheduler
		except Exception as e:
			logger.error(f'Error in periodic updates: {e}')

	async def _process_transaction(self, account: Account, transaction: Transaction) -> None:
		"""
		Process a transaction from Tastytrade and report the fill and commission report events.
		"""
		logger.debug(f'Processing transaction {transaction.id}')

		# Find the corresponding generic order
		generic_order: GenericOrder = None
		tasty_order: PlacedOrder = None
		for order in self._orders:
			tasty_order = order.brokerSpecific['order']
			if tasty_order.id == transaction.order_id:
				generic_order = order
				break
		if generic_order is None:
			logger.debug(f'No matching generic order found for transaction {transaction.id} (order ID {transaction.order_id})')
			return

		# Emit a order execution details event for the transaction
		action = OrderAction.BUY if transaction.transaction_sub_type in ['Buy to Open', 'Buy to Close'] else OrderAction.SELL
		
		# Determine the matching leg of the order based on the tastytrade symbol
		matching_leg = None
		for leg in generic_order.legs:
			tasty_symbol = leg.brokerSpecific.get('tasty_symbol', None)
			if tasty_symbol == transaction.symbol:
				matching_leg = leg
				break
		if matching_leg is None:
			logger.error(f'Unexpected Error: No matching leg found in order {tasty_order.id} for transaction symbol {transaction.symbol}')
			return
		
		sec_type = 'C' if matching_leg.right == OptionRight.CALL else 'P'

		execution = Execution(
			id=str(transaction.id),
			action=action,
			sec_type=sec_type,
			strike=matching_leg.strike,
			amount=int(transaction.quantity),
			price=float(transaction.price),
			expiration=matching_leg.expiration,
			timestamp=transaction.executed_at
			)
		logger.debug(f'Emitting execution details for Tastytrade order {tasty_order.id}: {matching_leg.symbol} {matching_leg.right} {matching_leg.strike} qty={execution.amount} @ ${execution.price}')
		self._emitOrderExecutionDetailsEvent(generic_order, execution)

		# Calculate total fees and commission and emit commission report event
		commission: float = abs(float(transaction.commission))
		fee: float = float(abs(transaction.regulatory_fees) + abs(transaction.clearing_fees) + abs(transaction.proprietary_index_option_fees))
		self._emitCommissionReportEvent(order=generic_order, execution_id=str(transaction.id), commission=commission, fee=fee)

	async def _on_alert_streamer_disconnect(self, streamer: AlertStreamer):
		"""
		Callback method which is called when the Tastytrade alert streamer disconnects.
		Reconnects only the alert streamer without affecting the DXLink streamer.
		
		OTB-xxx: Added guard against multiple simultaneous reconnect attempts.
		The disconnect callback can be called multiple times during KEEPALIVE timeout
		scenarios, leading to RecursionError and multiple Alert Streamers being created.
		"""
		try:
			logger.debug("Tastytrade Alert Streamer disconnected.")
			
			# Check if we're already disconnecting the entire connection
			if self._is_disconnecting:
				logger.debug("Already disconnecting, skipping Alert Streamer reconnect")
				return
			
			# OTB-335: Check if event loop is still running to avoid RuntimeError during shutdown
			try:
				loop = asyncio.get_running_loop()  # noqa: F841
			except RuntimeError as e:
				logger.debug(f'Event loop not running, ignoring alert streamer disconnect callback: {e}')
				return
			
			# Guard against multiple simultaneous reconnect attempts
			# This is critical to prevent RecursionError and multiple streamers
			if self._is_reconnecting_alert_streamer:
				logger.debug("Alert Streamer reconnect already in progress, skipping duplicate callback")
				return
			
			# Set the reconnect flag immediately to block any other callbacks
			self._is_reconnecting_alert_streamer = True
			
			try:
				if self._streamer is None:
					logger.debug("DXLink streamer is also disconnected (None) - this is a full disconnect, not an Alert Streamer reconnect scenario")
					return
				
				logger.warning("Alert Streamer disconnected unexpectedly. Reconnecting Alert Streamer...")
				
				# CRITICAL: Close the old alert streamer FIRST to stop the async for loop
				# This prevents the old task from receiving events after being cancelled
				old_streamer = self._alert_streamer
				old_streamer_id = id(old_streamer) if old_streamer else None
				self._alert_streamer = None  # Clear reference immediately to prevent race conditions
				logger.debug(f'Set _alert_streamer to None (old streamer was {old_streamer_id})')
				
				if old_streamer:
					try:
						logger.debug(f'Closing old alert streamer {old_streamer_id}')
						await asyncio.wait_for(old_streamer.close(), timeout=2.0)
						logger.debug(f'Old alert streamer {old_streamer_id} closed successfully')
					except asyncio.TimeoutError:
						logger.warning(f'Timeout while closing old alert streamer {old_streamer_id} - continuing anyway')
					except asyncio.CancelledError:
						logger.warning(f'Close operation cancelled for alert streamer {old_streamer_id} - continuing anyway')
					except Exception as exc:
						logger.warning(f'Error closing old alert streamer {old_streamer_id}: {exc} - continuing anyway')
				
				# Now cancel the account listening task (it should exit cleanly now)
				old_task = self.task_listen_accounts
				old_task_id = id(old_task) if old_task else None
				current_task = asyncio.current_task()
				current_task_id = id(current_task) if current_task else None
				
				# Clear the reference before cancelling to prevent self-referencing issues
				self.task_listen_accounts = None
				
				# Check if we're trying to cancel ourselves (which would cause recursion)
				if old_task and old_task is current_task:
					logger.debug(f'Task {old_task_id} is the current task, skipping self-cancel')
				elif old_task and not old_task.done():
					logger.debug(f'Cancelling account listening task {old_task_id} (current task is {current_task_id})')
					old_task.cancel()
					# Wait for the task using shield and gather to avoid propagating CancelledError
					try:
						# Use return_exceptions=True to prevent exceptions from being raised
						await asyncio.wait_for(
							asyncio.gather(old_task, return_exceptions=True),
							timeout=2.0
						)
						logger.debug(f'Account listening task {old_task_id} cancelled successfully')
					except asyncio.TimeoutError:
						logger.warning(f'Timeout waiting for account listening task {old_task_id} to cancel - continuing anyway')
					except Exception as exc:
						logger.warning(f'Error waiting for account listening task to cancel: {exc} - continuing anyway')
				else:
					logger.debug(f'Account listening task already done or None, no need to cancel')
				
				# Small delay to ensure everything is cleaned up
				logger.debug('Waiting 0.5s for cleanup before reconnecting')
				await asyncio.sleep(0.5)
				
				# Restart the account updates task which will create a new alert streamer
				try:
					# Check if event loop is still running before creating new task
					loop = asyncio.get_event_loop()
					if loop.is_running():
						self.task_listen_accounts = asyncio.create_task(self._request_account_updates())
						new_task_id = id(self.task_listen_accounts)
						logger.info(f"Alert Streamer reconnected successfully (new task {new_task_id})")
					else:
						logger.debug("Event loop not running, skipping Alert Streamer reconnect")
				except RuntimeError as runtime_err:
					logger.warning(f'Cannot reconnect Alert Streamer: {runtime_err}')
				except Exception as exc:
					logger.error(f'Error reconnecting Alert Streamer: {exc}')
			finally:
				# Always reset the reconnect flag when done
				self._is_reconnecting_alert_streamer = False
		except Exception as e:
			self._is_reconnecting_alert_streamer = False
			logger.error(f"Critical error in _on_alert_streamer_disconnect: {e}", exc_info=True)

	async def _handle_alert_streamer_error(self, error: Exception):
		"""
		Handle fatal errors from the AlertStreamer (e.g., AUTH timeout).
		
		OTB-264/OTB-335: When the AlertStreamer encounters a fatal error, we trigger
		a FULL broker reconnection. AUTH timeouts typically indicate network issues
		that affect both the AlertStreamer AND the DXLink streamer.
		
		This handles cases like:
		- "The timeout for waiting for AUTH has been reached"
		- Connection errors during streaming
		"""
		try:
			logger.warning(f'AlertStreamer fatal error: {error}. Triggering full broker reconnection...')
			
			# Check if we should attempt reconnect
			if self._is_disconnecting:
				logger.debug('Already disconnecting, skipping reconnect after fatal error')
				return
			
			# OTB-335: For AUTH timeout errors, always trigger a full reconnection
			# The DXLink streamer is likely also affected by the same network issues
			# A full reconnect ensures both streamers are properly re-established
			
			# OTB-335: Mark streamers as closed FIRST to prevent callbacks from doing anything
			old_alert_streamer = self._alert_streamer
			old_streamer = self._streamer
			
			if old_alert_streamer:
				self._closed_streamer_ids.add(id(old_alert_streamer))
			if old_streamer:
				self._closed_streamer_ids.add(id(old_streamer))
			
			# Clear references before any close operations
			self._alert_streamer = None
			self._streamer = None
			
			# Close streamers without triggering callbacks (refs are already cleared, IDs tracked)
			if old_alert_streamer:
				try:
					await asyncio.wait_for(old_alert_streamer.close(), timeout=2.0)
				except Exception:
					pass  # Ignore errors during cleanup
			
			if old_streamer:
				try:
					await asyncio.wait_for(old_streamer.close(), timeout=2.0)
				except Exception:
					pass  # Ignore errors during cleanup
			
			# Cancel any running streamer tasks - don't wait, just cancel
			for task in [self.task_listen_accounts, self.task_listen_quotes, 
						 self.task_listen_greeks, self.task_listen_candle]:
				if task and not task.done():
					task.cancel()
			
			self.task_listen_accounts = None
			self.task_listen_quotes = None
			self.task_listen_greeks = None
			self.task_listen_candle = None
			
			# Trigger full broker reconnection via the brokerfactory reconnect mechanism
			self._emitDisconnectedEvent()
			logger.info('Full broker reconnection triggered after AlertStreamer fatal error')
			
		except Exception as e:
			logger.error(f'Error handling AlertStreamer error: {e}', exc_info=True)
			# Still try to emit disconnect event as last resort
			try:
				self._emitDisconnectedEvent()
			except Exception:
				pass

	async def _on_streamer_reconnect(self, streamer: DXLinkStreamer):
		"""
		OTB-365: Callback method which is called when the Tastytrade streamer reconnects
		after a temporary disconnect. This method restores the data subscriptions.
		
		This is called by the websockets library's auto-reconnect mechanism when it
		successfully re-establishes the WebSocket connection.
		"""
		try:
			logger.info('DXLink streamer reconnected - restoring subscriptions...')
			
			# Re-subscribe to the data feeds
			await self._subscribe_data()
			
			logger.info('DXLink streamer subscriptions restored successfully')
		except Exception as e:
			logger.error(f'Error restoring subscriptions after reconnect: {e}', exc_info=True)
			# If we can't restore subscriptions, trigger a full disconnect/reconnect
			try:
				await self._on_streamer_disconnect(streamer)
			except Exception as inner_e:
				logger.error(f'Error in disconnect fallback: {inner_e}')

	async def _on_streamer_disconnect(self, streamer: DXLinkStreamer):
		"""
		Callback method which is called when the Tastytrade streamer disconnects.
		
		OTB-236: This callback may be invoked by the tastytrade library during shutdown
		when the event loop is already closing. We need to:
		1. Check if event loop is still running
		2. Avoid calling _disconnect_internal() which would try to close the streamer again (recursion!)
		3. Handle unexpected disconnects without causing infinite loops
		"""
		try:
			streamer_id = id(streamer) if streamer else None
			logger.debug(f'Tastytrade Streamer disconnect callback triggered (streamer={streamer_id}, _is_disconnecting={self._is_disconnecting})')
			
			# OTB-335: Check if this is a callback from an old, already-closed streamer
			# This happens when streamers accumulate over time (e.g., midnight reconnects)
			# and their internal tasks eventually get cleaned up by the event loop
			if streamer_id in self._closed_streamer_ids:
				logger.debug(f'Ignoring disconnect callback from old/closed streamer {streamer_id}')
				return
			
			# OTB-335: Check if this streamer is still our active streamer
			# If not, it's a zombie callback from an old streamer
			if self._streamer is not None and id(self._streamer) != streamer_id:
				logger.debug(f'Ignoring disconnect callback from non-current streamer {streamer_id} (current is {id(self._streamer)})')
				return
			
			# OTB-335: Stop the background scheduler
			self._stop_background_scheduler()

			# Check if we're already in the process of disconnecting
			if self._is_disconnecting:
				logger.debug('Already disconnecting, ignoring streamer disconnect callback')
				return
			
			# OTB-236: Check if event loop is still running to avoid RuntimeError during shutdown
			try:
				loop = asyncio.get_running_loop()  # noqa: F841
				# Note: is_closing() is not available in Python 3.11, only check if loop exists
				logger.debug('Event loop is running')
			except RuntimeError as e:
				logger.debug(f'Event loop not running, ignoring streamer disconnect callback (shutdown in progress): {e}')
				return
			
			# Handle unexpected disconnect (not during our controlled shutdown)
			logger.warning('Unexpected DXLink streamer disconnect detected. Initiating full reconnection...')
			logger.debug(f'Streamer: {id(self._streamer) if self._streamer else None}, Alert Streamer: {id(self._alert_streamer) if self._alert_streamer else None}')
			
			# OTB-236: Set flag BEFORE any operations to prevent recursive calls
			self._is_disconnecting = True
			
			# OTB-236: Don't call _disconnect_internal() here as it will try to close the streamer again!
			# Instead, manually clean up and trigger reconnection via the disconnected event
			
			# Disable trading immediately
			await self.set_trading_enabled(False, 'Streamer disconnected unexpectedly')
			
			# Cancel streaming tasks - use gather with return_exceptions to avoid recursion
			tasks_to_cancel = [
				task for task in [
					self.task_listen_quotes,
					self.task_listen_greeks,
					self.task_listen_candle,
					self.task_listen_accounts
				] if task and not task.done()
			]
			
			if tasks_to_cancel:
				# Cancel all tasks
				for task in tasks_to_cancel:
					task.cancel()
				
				# Wait for cancellation to complete
				try:
					await asyncio.wait_for(
						asyncio.gather(*tasks_to_cancel, return_exceptions=True),
						timeout=2.0
					)
					logger.debug(f'All {len(tasks_to_cancel)} streaming tasks cancelled')
				except asyncio.TimeoutError:
					logger.debug(f'Timeout waiting for streaming tasks to cancel')
				except Exception as e:
					logger.debug(f'Error waiting for streaming tasks to cancel: {e}')
			
			# Clear task references
			self.task_listen_quotes = None
			self.task_listen_greeks = None
			self.task_listen_candle = None
			self.task_listen_accounts = None
			
			# Clear streamer references (don't call close() - it's already closing!)
			self._streamer = None
			self._alert_streamer = None
			
			# Emit the disconnected event to trigger reconnection logic
			self._emitDisconnectedEvent()
		except Exception as e:
			logger.error(f'Unexpected error in _on_streamer_disconnect: {e}', exc_info=True)
	
	async def _subscribe_data(self) -> None:
		"""
		Subscribe to the required data
		"""
		logger.debug('Subscribing to streaming data')
		await self._streamer.subscribe(Quote, self._quote_symbols)
		await self._streamer.subscribe(Greeks, self._greeks_symbols)
		start_time = datetime.now() - timedelta(days=1)
		await self._streamer.subscribe_candle(self._candle_symbols, interval='1m', start_time=start_time)

	def _is_streamer_connected(self) -> bool:
		"""
		OTB-335: Check if the DXLink streamer is still connected.
		The streamer may have been closed by Tastytrade (e.g., at midnight day change).
		
		Returns:
			True if the streamer is connected and ready to use, False otherwise.
		"""
		if self._streamer is None:
			return False
		
		# Check if the streamer is in closing state
		if hasattr(self._streamer, '_closing') and self._streamer._closing:
			logger.debug('Streamer is in closing state')
			return False
		
		# Check if the websocket is closed
		if hasattr(self._streamer, '_websocket') and self._streamer._websocket is not None:
			ws = self._streamer._websocket
			# websockets library: check if the connection is closed
			if hasattr(ws, 'closed') and ws.closed:
				logger.debug('Streamer websocket is closed')
				return False
			# Alternative: check the state
			if hasattr(ws, 'state'):
				from websockets.protocol import State
				if ws.state == State.CLOSED or ws.state == State.CLOSING:
					logger.debug(f'Streamer websocket state is {ws.state}')
					return False
		
		return True

	async def requestTickerData(self, symbols: List[str]) -> None:
		""" 
		Request ticker data for the given symbols and their options
		"""
		# Check if this is the first call (initial setup) or a reconnect/re-subscription
		# OTB-xxx: Use _symbolData to distinguish between initial setup and reconnect
		# After a reconnect, _streamer is None but _symbolData still contains the previous data
		is_initial_setup = self._streamer is None and len(self._symbolData) == 0
		is_reconnect = self._streamer is None and len(self._symbolData) > 0
		
		# OTB-335: Check if the existing streamer is still connected
		# At midnight, Tastytrade closes the WebSocket connection (Close 1000 "Bye")
		# In this case, we need to create a new streamer instead of re-subscribing
		if not is_initial_setup and not is_reconnect and not self._is_streamer_connected():
			logger.debug('Existing streamer is disconnected - treating as reconnect')
			# Close the old streamer cleanly if it exists
			if self._streamer is not None:
				old_streamer = self._streamer
				old_streamer_id = id(old_streamer)
				# Mark this streamer as closed so we ignore future callbacks from it
				self._closed_streamer_ids.add(old_streamer_id)
				# Clear reference BEFORE closing to prevent callbacks from doing anything
				self._streamer = None
				logger.debug(f'Marked streamer {old_streamer_id} as closed, closing it now')
				try:
					await asyncio.wait_for(old_streamer.close(), timeout=3.0)
					logger.debug(f'Old streamer {old_streamer_id} closed successfully')
				except asyncio.TimeoutError:
					logger.debug(f'Timeout closing old streamer {old_streamer_id} - will be cleaned up by GC')
				except Exception as e:
					logger.debug(f'Error closing old streamer {old_streamer_id}: {e}')
				# Small delay to let internal tasks clean up
				await asyncio.sleep(0.2)
			is_reconnect = True
		
		if is_initial_setup or is_reconnect:
			ssl_context = ssl.create_default_context(cafile=certifi.where())
			# OTB-365: Pass reconnect_fn to restore subscriptions after websocket reconnects
			self._streamer = await DXLinkStreamer(
				self._session, 
				ssl_context=ssl_context, 
				disconnect_fn=self._on_streamer_disconnect,
				reconnect_fn=self._on_streamer_reconnect
			)

		if is_initial_setup:
			# Initial setup: Create new symbolData objects
			self._quote_symbols = []
			self._candle_symbols = []
			self._greeks_symbols = symbols

			for symbol in symbols:
				match symbol:
					case 'SPX':
						symbolData = TastySymbolData()
						symbolData.symbol = symbol
						symbolData.tastySymbol = 'SPX'
						self._quote_symbols.append('SPX')
						self._symbolData[symbol] = symbolData
						self._symbolReverseLookup[symbolData.tastySymbol] = symbol
					case 'VIX':
						symbolData = TastySymbolData()
						symbolData.symbol = symbol
						symbolData.tastySymbol = 'VIX'
						symbolData.trade_options = False  # No options for VIX
						self._candle_symbols.append('VIX')
						self._symbolData[symbol] = symbolData
						self._symbolReverseLookup[symbolData.tastySymbol] = symbol
					case _:
						logger.error(f'Symbol {symbol} currently not supported by Tastytrade Connector!')
						continue

			# Request option chains and expirations for symbols with options trading enable
			current_date = date.today()
			for item in self._symbolData.values():
				symbol_data: TastySymbolData = item
				desired_chain = None
				if symbol_data.trade_options:
					# If options are enabled, request the option chain and expirations
					symbol_information = symbolInfo.symbol_infos[symbol_data.symbol]
					chains = NestedOptionChain.get(self._session, symbol_data.tastySymbol)
					for chain in chains:
						if chain.root_symbol == symbol_information.trading_class:
							desired_chain = chain
							break
					if not desired_chain:
						logger.error(f'No option chain found for symbol {symbol_data.symbol} with trading class {symbol_information.trading_class}!')
						continue
					symbol_data.chain = desired_chain

					got_strikes = False
					for expiration in desired_chain.expirations:
						if expiration.expiration_date < current_date:
							continue
						symbol_data.expirations.append(expiration.expiration_date)
						if not got_strikes:
							# Obtain strikes of the first expiration only
							for strike in expiration.strikes:
								symbol_data.strikes.append(float(strike.strike_price))
							got_strikes = True

					# Initialize dte_expiration_map early so it's available for template processing
					self._determine_relevant_expirations(symbol_data)

					if current_date > symbol_data.expirations[0]:
						logger.warning(f'There are no {symbol_data.symbol} options expiring today!')

			# OTB-253: Symbol data is now ready for trade recovery to use
			# Start subscribe operations in background (don't await - they can take 2+ seconds)
			# This prevents blocking trade recovery which needs symbol data but not live streaming yet
			logger.debug('Symbol data loaded, starting streaming subscriptions in background')
			
			# Start subscribe and streaming tasks in background
			asyncio.create_task(self._start_streaming_async())
		elif is_reconnect:
			# OTB-xxx: Reconnect after disconnect - keep existing symbolData with optionPriceData
			# but re-create the streamer and re-subscribe to data
			logger.debug('Reconnecting to ticker data (keeping existing symbolData with price data)')
			
			# Start subscribe and streaming tasks in background
			asyncio.create_task(self._start_streaming_async())
		else:
			# Re-subscription after EOD settlement: Keep existing symbolData, just re-subscribe
			logger.debug('Re-subscribing to ticker data after EOD settlement (keeping existing symbolData)')
			
			# Re-subscribe to base symbols (SPX, VIX) - these should still be in the lists
			await self._subscribe_data()
			
			# Mark ticker data as subscribed again
			self._subscribed_ticker_data = True
			logger.debug('Ticker data re-subscription completed')

	async def _start_streaming_async(self) -> None:
		"""
		OTB-253: Start streaming subscriptions and tasks asynchronously.
		This method runs in the background to avoid blocking trade recovery.
		"""
		try:
			# Subscribe to data (this can take 2+ seconds due to network calls)
			await self._subscribe_data()
			self._subscribed_ticker_data = True
			
			# OTB-xxx: Start streaming tasks but don't wait for them (they run indefinitely)
			# These tasks will be cancelled during disconnect via _disconnect_internal()
			if self.task_listen_quotes is None:
				self.task_listen_quotes = asyncio.create_task(self._update_quotes())
				self.task_listen_greeks = asyncio.create_task(self._update_greeks())
				self.task_listen_candle = asyncio.create_task(self._update_candle())
				logger.debug('Started streaming tasks for quotes, greeks, and candles')
		except Exception as e:
			logger.error(f'Failed to start streaming: {e}', exc_info=True)

	async def _update_accounts(self):
		"""
		Task for listening to account updates
		"""
		logger.debug(f'_update_accounts started, alert_streamer={id(self._alert_streamer) if self._alert_streamer else None}')
		try:
			# Check if streamer is still valid before entering the loop
			if self._alert_streamer is None:
				logger.debug('Alert streamer is None, cannot start account updates loop')
				return
			
			streamer_id = id(self._alert_streamer)
			logger.debug(f'Starting async for loop with streamer {streamer_id}')
			async for order in self._alert_streamer.listen(PlacedOrder):
				logger.debug(f'Received order event in loop (streamer {streamer_id}): {order.id} status {order.status}')
				additional_info = ''
				if order.status == OrderStatus.REJECTED:
					additional_info = f'Reason: {order.reject_reason}'
				logger.debug(f'Update on order {order.id} status {order.status} {additional_info}')			
				ignore_order_event = False
				
				# OTB-378: Ignore REJECTED replacement orders when original order was filled
				# When a replacement order is rejected because the original was filled,
				# we should ignore this event - the FILLED event for the original will arrive
				if order.status == OrderStatus.REJECTED and order.reject_reason:
					if 'fill on the original order' in order.reject_reason.lower():
						logger.debug('Ignoring REJECTED replacement order - original order was filled')
						ignore_order_event = True
				
				# Cancel Events von Preisanpassungen ignorieren, da sie kein echtes Cancel sind
				for replaced_order in self._replacedOrders:
					if replaced_order.id == order.id and order.status == OrderStatus.CANCELLED:
						#self._replacedOrders.remove(replaced_order)
						ignore_order_event = True
						logger.debug('Ignoring cancel event for replaced order')
						continue
					if replaced_order.id == order.id and (order.status == OrderStatus.ROUTED or order.status == OrderStatus.LIVE):
						if order.status == OrderStatus.LIVE:
							self._replacedOrders.remove(replaced_order)
						ignore_order_event = True
						logger.debug('Ignoring placement of new replacement order')
						continue
		
				if not ignore_order_event:
					relevantOrder: GenericOrder = None
					for managedOrder in self._orders:
						broker_specific_order: PlacedOrder = managedOrder.brokerSpecific['order']
						if broker_specific_order.id == order.id:
							relevantOrder = managedOrder
							break
						# OTB-378: Also check replaced order IDs for FILLED events
						# When a replacement order is submitted but the original fills,
						# we need to match the FILLED event for the original order
						replaced_ids = managedOrder.brokerSpecific.get('replaced_order_ids', [])
						if order.id in replaced_ids and order.status == OrderStatus.FILLED:
							logger.debug(f'Matched FILLED event for replaced order {order.id}')
							relevantOrder = managedOrder
							break
				
					if relevantOrder == None:
						logger.debug(f'No managed order matched the status event')
					else:
						relevantOrder.brokerSpecific['order'] = order
						filledAmount = int(order.size)
						relevantOrder.filledQuantity = filledAmount  # Track filled quantity for partial fill handling
						relevantOrder.averageFillPrice = abs(float(order.price)) if order.price != None else 0
						order_status =	self._genericOrderStatus(order.status)
						if order_status and order_status != relevantOrder.status:
							self._emitOrderStatusEvent(relevantOrder, order_status, filledAmount)
							# Emit execution details when order is filled
							#if order.status == OrderStatus.FILLED:
							#	logger.debug(f'Order {order.id} is filled, emitting execution details')
							#	self._emit_execution_details_for_order(relevantOrder, order)
						else:
							logger.debug(f'Order status {order.status} not mapped to generic order status')
		except asyncio.CancelledError:
			logger.debug(f'Account updates task cancelled, stopping order listener (streamer {id(self._alert_streamer) if self._alert_streamer else None})')
			raise  # Re-raise to allow proper task cancellation
		except Exception as exc:
			logger.error(f'Unexpected error in _update_accounts: {exc}', exc_info=True)
		finally:
			logger.debug(f'_update_accounts exiting (streamer {id(self._alert_streamer) if self._alert_streamer else None})')

	async def _update_quotes(self):
		"""
		OTB-335: Added exception handling for WebSocket disconnects.
		"""
		try:
			async for e in self._streamer.listen(Quote):
				logger.trace(f'Received Quote: {e.event_symbol} bid price: {e.bid_price} ask price: {e.ask_price}')
				# Preisdaten speichern if the broker is subscribed to ticker data
				if self._subscribed_ticker_data is None:
					continue

				if not e.event_symbol.startswith('.'):
					# Symbol ist ein Basiswert
					try:
						genericSymbol = self._symbolReverseLookup[e.event_symbol]
						symbolData: TastySymbolData  = self._symbolData[genericSymbol]
						# OTB-361: Validate bid/ask prices before calculating midPrice
						bid_price = e.bid_price if e.bid_price is not None and not OptionHelper.isNan(e.bid_price) and e.bid_price > 0 else None
						ask_price = e.ask_price if e.ask_price is not None and not OptionHelper.isNan(e.ask_price) and e.ask_price > 0 else None
						if bid_price is None or ask_price is None:
							logger.trace(f'Invalid quote for {e.event_symbol}: bid={e.bid_price}, ask={e.ask_price}. Keeping previous lastPrice.')
							continue
						midPrice = float((bid_price + ask_price) / 2)
						# OTB-361: Sanity check using symbol-specific limits
						symbol_information = symbolInfo.symbol_infos.get(genericSymbol)
						if symbol_information and (midPrice < symbol_information.sanity_price_lower or midPrice > symbol_information.sanity_price_upper):
							logger.warning(f'Quote for {e.event_symbol}: midPrice={midPrice} is outside sanity range [{symbol_information.sanity_price_lower}, {symbol_information.sanity_price_upper}]. Ignoring.')
							continue
						atmStrike = OptionHelper.roundToStrikePrice(midPrice)
						symbolData.lastPrice = midPrice
						if symbolData.lastAtmStrike != atmStrike:  # Check for missing Option Data only if ATM Strike has changed
							symbolData.lastAtmStrike = atmStrike
							asyncio.create_task(self._requestMissingOptionData(symbolData, atmStrike))
						
					except KeyError as keyErr:
						logger.error(f'No generic symbol found for tastytrade symbol {e.event_symbol}')
				else:
					# Symbol ist eine Option
					try:
						symbol, optionType, expiration, strike = self._getOptionInfos(e.event_symbol)
						symbol_information = symbolInfo.symbol_infos[symbol]
						symbolData = self._symbolData[symbol]
						optionStrikeData = symbolData.optionPriceData[expiration]
						optionStrikePriceData = optionStrikeData.strikeData[strike]
						if optionType == OptionType.CALL:
							optionStrikePriceData.callBid = float(e.bid_price)
							optionStrikePriceData.callAsk = float(e.ask_price)
						else:
							optionStrikePriceData.putBid = float(e.bid_price)
							optionStrikePriceData.putAsk = float(e.ask_price)
						optionStrikePriceData.lastUpdated = datetime.now(symbol_information.timezone)
						self._last_option_price_update_time = optionStrikePriceData.lastUpdated
						await self._monitor_bid_ask_spread(optionStrikePriceData, genericSymbol, strike)
					except KeyError:
						# This can happen after unsubscribe when quotes for unsubscribed expirations still arrive
						logger.trace(f'Received quote for unsubscribed option: {e.event_symbol}')
					except Exception as exc:
						logger.error(f'Error processing option quote {e.event_symbol}: {exc}')
		except asyncio.CancelledError:
			logger.debug('Quote updates task cancelled')
			raise
		except Exception as e:
			logger.debug(f'Quote streaming ended: {e}')
	
	async def _update_greeks(self):
		"""
		OTB-335: Added exception handling for WebSocket disconnects.
		"""
		try:
			async for e in self._streamer.listen(Greeks):
				logger.trace(f'Received Greeks: {e.event_symbol} delta: {e.delta}')
				if e.event_symbol.startswith('.'):
					# Symbol ist eine Option
					try:
						symbol, optionType, expiration, strike = self._getOptionInfos(e.event_symbol)
						symbol_information = symbolInfo.symbol_infos[symbol]
						symbolData = self._symbolData[symbol]
						optionStrikeData = symbolData.optionPriceData[expiration]
						optionStrikePriceData = optionStrikeData.strikeData[strike]
						if optionType == OptionType.CALL:
							optionStrikePriceData.callDelta = float(e.delta)
						else:
							optionStrikePriceData.putDelta = float(e.delta)

					except KeyError:
						# This can happen after unsubscribe when greeks for unsubscribed expirations still arrive
						logger.trace(f'Received greeks for unsubscribed option: {e.event_symbol}')
					except Exception as exc:
						logger.error(f'Error processing option greeks {e.event_symbol}: {exc}')
		except asyncio.CancelledError:
			logger.debug('Greeks updates task cancelled')
			raise
		except Exception as e:
			logger.debug(f'Greeks streaming ended: {e}')

	async def _update_candle(self):
		"""
		OTB-335: Added exception handling for WebSocket disconnects.
		"""
		try:
			async for e in self._streamer.listen(Candle):
				logger.trace(f'Received Candle: {e.event_symbol} close: {e.close}')
				if not e.event_symbol.startswith('.'):
					# Symbol ist ein Basiswert
					try:
						symbol = e.event_symbol.split('{')[0]
						genericSymbol = self._symbolReverseLookup[symbol]
						symbolData: TastySymbolData  = self._symbolData[genericSymbol]
						# OTB-361: Validate candle close price before updating lastPrice
						close_price = e.close
						if close_price is None or OptionHelper.isNan(close_price) or close_price <= 0:
							logger.trace(f'Invalid candle close for {e.event_symbol}: close={close_price}. Keeping previous lastPrice.')
							continue
						# OTB-361: Sanity check using symbol-specific limits
						symbol_information = symbolInfo.symbol_infos.get(genericSymbol)
						if symbol_information and (close_price < symbol_information.sanity_price_lower or close_price > symbol_information.sanity_price_upper):
							logger.warning(f'Candle for {e.event_symbol}: close={close_price} is outside sanity range [{symbol_information.sanity_price_lower}, {symbol_information.sanity_price_upper}]. Ignoring.')
							continue
						symbolData.lastPrice = float(close_price)
					except KeyError as keyErr:
						logger.error(f'No generic symbol found for tastytrade symbol {e.event_symbol}')
		except asyncio.CancelledError:
			logger.debug('Candle updates task cancelled')
			raise
		except Exception as e:
			logger.debug(f'Candle streaming ended: {e}')

	async def eod_settlement_tasks(self) -> None:
		"""
		Perform End of Day settlement tasks
		"""
		await super().eod_settlement_tasks()

	async def get_price_history(
		self,
		symbol: str,
		interval: ChartInterval = ChartInterval.ONE_DAY,
		start: datetime = None,
		end: datetime = None,
		bars: int = 100
	) -> List[OHLCBar]:
		"""
		OTB-373: Returns historical price data (OHLC bars) for the given symbol using DXLink Candle events.
		
		Uses the DXLink streamer to subscribe to Candle events for the specified time range
		and collects the historical data.
		
		Args:
			symbol: The trading symbol (e.g., 'SPX', 'SPY')
			interval: Bar interval (default: ChartInterval.ONE_DAY)
			start: Start datetime (optional). If not provided, calculated from bars.
			end: End datetime (optional, defaults to now)
			bars: Number of bars to return if start not specified (default: 100)
			
		Returns:
			List of OHLCBar objects sorted by timestamp ascending.
		"""
		if not self.isConnected():
			logger.warning('Tastytrade not connected for price history request')
			return []
		
		# Check if symbol is available
		if symbol not in self._symbolData:
			logger.warning(f'Symbol {symbol} not found in symbol data')
			return []
		
		symbol_data: TastySymbolData = self._symbolData[symbol]
		streamer_symbol = symbol_data.tastySymbol
		
		# Map ChartInterval to DXLink interval format
		interval_map = {
			ChartInterval.ONE_MINUTE: '1m',
			ChartInterval.FIVE_MINUTES: '5m',
			ChartInterval.FIFTEEN_MINUTES: '15m',
			ChartInterval.ONE_HOUR: '1h',
			ChartInterval.ONE_DAY: '1d',
		}
		dxlink_interval = interval_map.get(interval, '5m')
		
		# Check cache first
		cache_key = (symbol, dxlink_interval)
		if cache_key in self._chart_cache:
			cache_time, cached_bars = self._chart_cache[cache_key]
			if datetime.now() - cache_time < self._chart_cache_ttl:
				logger.debug(f'Returning {len(cached_bars)} cached bars for {symbol} ({dxlink_interval})')
				# Return the requested number of bars (most recent)
				if len(cached_bars) > bars:
					return cached_bars[-bars:]
				return cached_bars
		
		# Calculate start time if not provided
		if start is None:
			start = self._calculate_chart_start_time(interval, bars)
		
		try:
			# Fetch candle history using dedicated method
			candles = await self._fetch_candle_history(
				streamer_symbol,
				dxlink_interval,
				start,
				timeout=10  # 10 seconds timeout as specified
			)
			
			if not candles:
				logger.warning(f'No candle data received for {symbol}')
				return []
			
			# Convert candles to OHLCBar format
			ohlc_bars = self._convert_candles_to_ohlc_bars(candles)
			
			# Sort by timestamp
			ohlc_bars.sort(key=lambda x: x.timestamp)
			
			# Cache the results
			self._chart_cache[cache_key] = (datetime.now(), ohlc_bars)
			
			# Return the requested number of bars (most recent)
			if len(ohlc_bars) > bars:
				ohlc_bars = ohlc_bars[-bars:]
			
			logger.debug(f'Returning {len(ohlc_bars)} historical bars for {symbol} ({dxlink_interval})')
			return ohlc_bars
			
		except Exception as e:
			logger.error(f'Error fetching price history for {symbol}: {e}')
			return []

	def _calculate_chart_start_time(self, interval: ChartInterval, bars: int) -> datetime:
		"""
		OTB-373: Calculate the start time for chart data based on the interval and number of bars.
		
		Takes into account trading hours and weekends to ensure enough data is available.
		"""
		now = datetime.now()
		
		# Calculate approximate time span needed
		if interval == ChartInterval.ONE_MINUTE:
			# ~390 trading minutes per day
			days_needed = (bars // 390) + 2
		elif interval == ChartInterval.FIVE_MINUTES:
			# ~78 5-minute bars per day
			days_needed = (bars // 78) + 2
		elif interval == ChartInterval.FIFTEEN_MINUTES:
			# ~26 15-minute bars per day
			days_needed = (bars // 26) + 2
		elif interval == ChartInterval.ONE_HOUR:
			# ~6.5 hourly bars per day
			days_needed = (bars // 7) + 2
		else:  # ONE_DAY
			# Add extra for weekends
			days_needed = int(bars * 1.5)
		
		return now - timedelta(days=days_needed)

	async def _fetch_candle_history(
		self,
		streamer_symbol: str,
		interval: str,
		start_time: datetime,
		timeout: int = 10
	) -> List[Candle]:
		"""
		OTB-373: Fetch historical candle data from DXLink.
		
		Creates a dedicated temporary DXLink streamer for chart data to avoid
		interference with the main streamer's candle subscriptions.
		
		Args:
			streamer_symbol: The DXLink symbol (e.g., 'SPX')
			interval: The candle interval (e.g., '5m', '1h', '1d')
			start_time: The start time for historical data
			timeout: Maximum time to wait for data in seconds
			
		Returns:
			List of Candle events
		"""
		if self._session is None:
			logger.warning('Tastytrade session not available for candle history request')
			return []
		
		candles: List[Candle] = []
		candle_symbol = f'{streamer_symbol}{{={interval},tho=true}}'  # tho=true excludes extended hours
		
		logger.debug(f'Subscribing to candle history: {candle_symbol} from {start_time}')
		
		# Create a dedicated temporary streamer for chart data
		# This avoids conflicts with the main streamer's candle queue
		chart_streamer: DXLinkStreamer = None
		
		try:
			# Create a new DXLink streamer just for this chart request
			ssl_context = ssl.create_default_context(cafile=certifi.where())
			chart_streamer = await DXLinkStreamer(self._session, ssl_context=ssl_context)
			
			# Subscribe to candle data with the specified start time
			await chart_streamer.subscribe_candle(
				symbols=[streamer_symbol],
				interval=interval,
				start_time=start_time,
				extended_trading_hours=False  # RTH only
			)
			
			# Collect candle events with timeout
			start_collect_time = datetime.now()
			last_candle_time = datetime.now()
			no_new_data_timeout = 2  # Stop if no new data for 2 seconds
			
			while True:
				# Check overall timeout
				if (datetime.now() - start_collect_time).total_seconds() > timeout:
					logger.debug(f'Candle collection timeout reached ({timeout}s)')
					break
				
				# Try to get a candle event without blocking
				try:
					candle = chart_streamer.get_event_nowait(Candle)
					if candle:
						# Filter for our symbol and interval
						if candle.event_symbol.startswith(streamer_symbol):
							candles.append(candle)
							last_candle_time = datetime.now()
					else:
						# No candle available, check if we should stop waiting
						if candles and (datetime.now() - last_candle_time).total_seconds() > no_new_data_timeout:
							logger.debug(f'No new candles for {no_new_data_timeout}s, stopping collection')
							break
						# Short sleep to avoid busy waiting
						await asyncio.sleep(0.1)
				except Exception as e:
					logger.trace(f'Error getting candle event: {e}')
					await asyncio.sleep(0.1)
			
			logger.debug(f'Collected {len(candles)} candles for {streamer_symbol}')
			return candles
			
		except Exception as e:
			logger.error(f'Error fetching candle history: {e}')
			return []
		finally:
			# Always close the temporary streamer
			if chart_streamer is not None:
				try:
					await chart_streamer.close()
				except Exception as e:
					logger.debug(f'Error closing chart streamer: {e}')

	def _convert_candles_to_ohlc_bars(self, candles: List[Candle]) -> List[OHLCBar]:
		"""
		OTB-373: Convert DXLink Candle events to OHLCBar objects.
		
		Args:
			candles: List of Candle events from DXLink
			
		Returns:
			List of OHLCBar objects
		"""
		ohlc_bars = []
		seen_times = set()  # Avoid duplicates
		
		# Use US Eastern timezone for conversion (exchange timezone)
		eastern_tz = pytz.timezone('US/Eastern')
		
		for candle in candles:
			try:
				# Candle time is in milliseconds
				candle_timestamp = candle.time / 1000
				
				# Skip duplicates (same timestamp)
				if candle_timestamp in seen_times:
					continue
				seen_times.add(candle_timestamp)
				
				# Convert timestamp to datetime (candle times are in UTC)
				candle_dt = datetime.fromtimestamp(candle_timestamp, tz=pytz.UTC)
				
				# Validate OHLC values
				open_price = float(candle.open) if candle.open else 0
				high_price = float(candle.high) if candle.high else 0
				low_price = float(candle.low) if candle.low else 0
				close_price = float(candle.close) if candle.close else 0
				
				# Skip invalid candles
				if open_price <= 0 or high_price <= 0 or low_price <= 0 or close_price <= 0:
					continue
				
				volume = int(candle.volume) if candle.volume else 0
				
				ohlc_bar = OHLCBar(
					timestamp=candle_dt,
					open=open_price,
					high=high_price,
					low=low_price,
					close=close_price,
					volume=volume
				)
				ohlc_bars.append(ohlc_bar)
				
			except Exception as e:
				logger.trace(f'Error converting candle to OHLCBar: {e}')
				continue
		
		return ohlc_bars

	def get_option_strike_data(self, symbol: str, expiration: date) -> OptionStrikeData:
		""" 
		Returns the option strike data for the given symbol and expiration. It is including
		prices and greeks.
		"""
		symbolData = self._symbolData[symbol]
		try:
			return symbolData.optionPriceData[expiration]
		except KeyError:
			raise ValueError(f'No option strike data for symbol {symbol} and expiration {expiration} found!')

	def get_option_strike_price_data(self, symbol: str, expiration: date, strike: float) -> OptionStrikePriceData:
		""" 
		Returns the option strike price data for the given symbol, expiration date, strike price and right.
		Returns None if no price data is available for the expiration date or strike.
		"""
		symbolData = self._symbolData[symbol]
		try:
			optionStrikeData = symbolData.optionPriceData[expiration]
		except KeyError:
			# No price data available for this expiration date (e.g., after trade recovery)
			return None
		
		if strike in optionStrikeData.strikeData.keys():
			return optionStrikeData.strikeData[strike]
		else:
			return None

	def get_strike_by_delta(self, symbol: str, right: str, delta: int) -> float:
		"""
		Returns the strike price based on the given delta based on the buffered option price data
		"""
		symbolData = self._symbolData[symbol]
		current_date = date.today()
		option_price_data: OptionStrikeData= symbolData.optionPriceData[current_date]
		previous_delta = 0
		previous_strike = 0
		reverse = True if right == OptionRight.PUT else False
		sorted_strikes = dict(sorted(option_price_data.strikeData.items(), reverse=reverse))
		for strike, price_data in sorted_strikes.items():
			if right == OptionRight.PUT:
				if price_data.putDelta == None:
					continue
				adjusted_delta = price_data.putDelta * -100
			else:
				if price_data.callDelta == None:
					continue
				adjusted_delta = price_data.callDelta * 100
			if adjusted_delta <= delta:
				if OptionHelper.closest_number(delta, previous_delta, adjusted_delta) == adjusted_delta:
					return strike
				else:
					return previous_strike
			previous_delta = adjusted_delta
			previous_strike = strike

		raise ValueError(f'No strike price found for delta {delta} in symbol {symbol}!')
	
	def get_strike_by_price(self, symbol: str, right: str, price: float) -> float:
		""" 
		Returns the strike price based on the given premium price based on the buffered option price data
		"""
		# TODO: Implement in base class, because TWS Connector got the same code
		symbolData = self._symbolData[symbol]
		current_date = date.today()
		option_price_data: OptionStrikeData= symbolData.optionPriceData[current_date]
		previous_price = 0
		previous_strike = 0
		reverse = True if right == OptionRight.PUT else False
		sorted_strikes = dict(sorted(option_price_data.strikeData.items(), reverse=reverse))
		for strike, price_data in sorted_strikes.items():
			if right == OptionRight.PUT:
				current_strike_price = price_data.getPutMidPrice()
				if current_strike_price == None:
					continue
			elif right == OptionRight.CALL:
				current_strike_price = price_data.getCallMidPrice()
				if current_strike_price == None:
					continue
			if current_strike_price > 0 and current_strike_price <= price:
				if OptionHelper.closest_number(price, previous_price, current_strike_price) == current_strike_price:
					return strike
				else:
					return previous_strike
			previous_price = current_strike_price
			previous_strike = strike
		raise ValueError(f'No strike price found for price {price} in symbol {symbol}!')

	def getFillPrice(self, order: GenericOrder) -> float:
		""" 
		Returns the fill price of the given order if it is filled
		"""
		try:
			tastyOrder: PlacedOrder = order.brokerSpecific['order']
			if tastyOrder.status == OrderStatus.FILLED:
				return abs(float(tastyOrder.price))
			else:
				return 0
		except KeyError as keyErr:
			logger.error(f'No fill price available for order {order}')
	
	def getLastPrice(self, symbol: str) -> float:
		""" 
		Returns the last price of the given symbol
		"""
		try:
			symbolData = self._symbolData[symbol]
			return symbolData.lastPrice
		except KeyError as keyErr:
			logger.error(f'No last price available for symbol {symbol}')
			return 0

	def oco_as_complex_order(self) -> bool:
		"""
		With Tastytrade, the OCO orders have to be placed as one complex order
		"""
		return True
	
	def uses_oco_orders(self) -> bool:
		""" 
		The TWS Connector uses OCO orders for take profit and stop loss orders
		"""
		return True
	
	async def unsubscribe_ticker_data(self):
		"""
		Unsubscribe from ticker data - including base symbols and all options
		"""
		await super().unsubscribe_ticker_data()
		
		# First, unsubscribe from all option symbols
		for symbolData in self._symbolData.values():
			try:
				for day_option_price_data in symbolData.optionPriceData.values():
					streamer_symbols = []
					for value in day_option_price_data.strikeData.values():
						option_price_data: OptionStrikePriceData = value
						
						try:
							call_streamer_symbol = option_price_data.brokerSpecific['call_streamer_symbol']
							streamer_symbols.append(call_streamer_symbol)
							self._quote_symbols.remove(call_streamer_symbol)
						except KeyError:
							pass

						try:
							put_streamer_symbol = option_price_data.brokerSpecific['put_streamer_symbol']
							streamer_symbols.append(put_streamer_symbol)
							self._quote_symbols.remove(put_streamer_symbol)
						except KeyError:
							pass

					if streamer_symbols:
						try:
							await self._streamer.unsubscribe(Quote, streamer_symbols)
							await self._streamer.unsubscribe(Greeks, streamer_symbols)
						except ConnectionClosedOK:
							logger.debug('Streamer already closed, ignore')
							pass
				symbolData.optionPriceData.clear()
				symbolData.lastAtmStrike = 0
				symbolData.lastPrice = 0
			except KeyError:
				pass
		
		# Now unsubscribe from base symbols (SPX, VIX, etc.)
		# This ensures a clean state for re-subscription at new day start
		if self._quote_symbols:
			logger.debug(f'Unsubscribing from {len(self._quote_symbols)} base quote symbols')
			await self._streamer.unsubscribe(Quote, self._quote_symbols)
		if self._greeks_symbols:
			logger.debug(f'Unsubscribing from {len(self._greeks_symbols)} base greeks symbols')
			await self._streamer.unsubscribe(Greeks, self._greeks_symbols)
		if self._candle_symbols:
			logger.debug(f'Unsubscribing from {len(self._candle_symbols)} base candle symbols')
			await self._streamer.unsubscribe(Candle, self._candle_symbols)

	async def _requestMissingOptionData(self, symbolData: TastySymbolData, atmStrike: float):
		"""
		Request option data for the given symbol and expiration date
		"""
		relevant_expirations = self._determine_relevant_expirations(symbolData)
		symbolInformation = symbolInfo.symbol_infos[symbolData.symbol]
		strikes_of_interest = self._determine_strikes_of_interest(symbolData, atmStrike)	
	
		for relevant_expiration in relevant_expirations:
			# Optain saved options data for the expiration date
			try:
				#expiration_date_str = relevant_expiration.strftime('%Y%m%d')
				optionStrikeData = symbolData.optionPriceData[relevant_expiration]
			except KeyError as keyErr:
				# Wenn noch keine Optionsdaten für das Verfallsdatum vorhanden sind, dann bei Tasty anfragen ob es Optionsdaten gibt

				optionStrikeData = OptionStrikeData()
				symbolData.optionPriceData[relevant_expiration] = optionStrikeData

			for chain_at_expiration in symbolData.chain.expirations:
				if chain_at_expiration.expiration_date >= relevant_expiration:
					break
			if chain_at_expiration == None or chain_at_expiration.expiration_date != relevant_expiration:
				logger.error(f'No options available for symbol {symbolData.tastySymbol} and expiration date {relevant_expiration}')
				continue
			
			# Convert the available strikes to a list of decimal numbers
			# if not done yet
			try:
				available_strikes = chain_at_expiration._optrabot_strikes
			except AttributeError as attrErr:
				chain_at_expiration._optrabot_strikes = []
				available_strikes = chain_at_expiration._optrabot_strikes
				for strike in chain_at_expiration.strikes:
					available_strikes.append(strike.strike_price)

			options_to_be_requested = []
			for strike_price in strikes_of_interest:	
				try:
					optionStrikeData.strikeData[strike_price]
				except KeyError as keyErr:
					option_strike_price_data = OptionStrikePriceData()
					optionStrikeData.strikeData[strike_price] = option_strike_price_data
					options_to_be_requested.append(strike_price)

			if len(options_to_be_requested) > 0:
				streamer_symbols = []
				for item in chain_at_expiration.strikes:
					strike: Strike = item
					if strike.strike_price in options_to_be_requested:
						option_strike_data = optionStrikeData.strikeData[strike.strike_price]
						option_strike_data.brokerSpecific['call_option'] = strike.call
						option_strike_data.brokerSpecific['call_streamer_symbol'] = strike.call_streamer_symbol
						option_strike_data.brokerSpecific['put_option'] =  strike.put
						option_strike_data.brokerSpecific['put_streamer_symbol']  = strike.put_streamer_symbol
						streamer_symbols.append(strike.call_streamer_symbol)
						streamer_symbols.append(strike.put_streamer_symbol)
						self._quote_symbols.append(strike.call_streamer_symbol)
						self._quote_symbols.append(strike.put_streamer_symbol)
				await self._streamer.subscribe(Quote, streamer_symbols)
				await self._streamer.subscribe(Greeks, streamer_symbols)
		
	def _getOptionInfos(self, tastySymbol: str) -> tuple:
		"""
		Extracts the generic symbol and expiration date, strike and option side from the tastytrade option symbol.
		If the option symbol information cannot be parsed as expected, a ValueError exception is raised.
		"""
		error = False
		pattern = r'^.(?P<optionsymbol>[A-Z]+)(?P<expiration>[0-9]+)(?P<type>[CP])(?P<strike>[0-9]+)'
		compiledPattern = re.compile(pattern)
		match = compiledPattern.match(tastySymbol)
		try:
			if match:
				optionSymbol = match.group('optionsymbol')
				for symbol, symbol_info in symbolInfo.symbol_infos.items():
					if symbol_info.symbol + symbol_info.option_symbol_suffix == optionSymbol:
						genericSymbol = symbol_info.symbol
						break
				expirationDate = datetime.strptime(match.group('expiration'), '%y%m%d').date()
				strike = float(match.group('strike'))
				optionType = OptionType.CALL if match.group('type') == 'C' else OptionType.PUT
		except IndexError as indexErr:
			logger.error(f'Invalid option symbol {tastySymbol}')
			error = True
		except ValueError as valueErr:
			logger.error(f'Invalid option symbol {tastySymbol}')
			error = True
		if genericSymbol == None or error == True:
			raise ValueError(f'Invalid option symbol {tastySymbol}')
		return genericSymbol, optionType, expirationDate, strike
	
	def _mappedOrderAction(self, orderAction: GenericOrderAction, legAction: GenericOrderAction) -> OrderAction:
		"""
		Maps the general order action to the Tasty specific order action
		For Closing orders, the leg actions need to be inverted
		eg. BUY -> SELL_TO_CLOSE
		eg. SELL -> BUY_TO_CLOSE
		"""
		match orderAction:
			case GenericOrderAction.BUY_TO_OPEN:
				if legAction == GenericOrderAction.BUY:
					return OrderAction.BUY_TO_OPEN
				if legAction == GenericOrderAction.SELL:
					return OrderAction.SELL_TO_OPEN
				else:
					raise ValueError(f'Unknown leg action: {legAction}')
			case GenericOrderAction.SELL_TO_OPEN:
				if legAction == GenericOrderAction.SELL:
					return OrderAction.SELL_TO_OPEN
				elif legAction == GenericOrderAction.BUY:
					return OrderAction.BUY_TO_OPEN
				else:
					raise ValueError(f'Unknown leg action: {legAction}')
			case GenericOrderAction.BUY_TO_CLOSE:
				if legAction == GenericOrderAction.BUY:
					return OrderAction.BUY_TO_CLOSE
				if legAction == GenericOrderAction.SELL:
					return OrderAction.SELL_TO_CLOSE
				else:
					raise ValueError(f'Unknown leg action: {legAction}')
			case GenericOrderAction.SELL_TO_CLOSE:
				if legAction == GenericOrderAction.SELL:
					return OrderAction.SELL_TO_CLOSE
				elif legAction == GenericOrderAction.BUY:
					return OrderAction.BUY_TO_CLOSE
				else:
					raise ValueError(f'Unknown leg action for SELL_TO_CLOSE: {legAction}')
			case _:
				raise ValueError(f'Unknown order action: {orderAction}')
			
	async def _request_account_updates(self):
		"""
		Request Account Updates - runs as a background task.
		
		If the AlertStreamer encounters a fatal error (e.g., AUTH timeout),
		this method will attempt to reconnect automatically.
		"""
		task_id = id(asyncio.current_task())
		logger.debug(f'_request_account_updates started (task {task_id})')
		try:
			self._alert_streamer = await AlertStreamer(self._session, disconnect_fn=self._on_alert_streamer_disconnect)
			streamer_id = id(self._alert_streamer)
			logger.debug(f'Created alert streamer {streamer_id} (task {task_id})')
			await self._alert_streamer.subscribe_accounts(self._tasty_accounts)
			
			# Start the update loop directly without creating nested tasks
			logger.debug(f'Starting _update_accounts (task {task_id}, streamer {streamer_id})')
			await self._update_accounts()
		except asyncio.CancelledError:
			logger.debug(f'Cancelled listening to account updates (task {task_id})')
			raise  # Re-raise to allow proper task cancellation
		except Exception as exc:
			logger.error(f'Error in account updates (task {task_id}): {exc}')
			# OTB-264: Attempt to reconnect the AlertStreamer on fatal errors
			# (e.g., "The timeout for waiting for AUTH has been reached")
			await self._handle_alert_streamer_error(exc)
		finally:
			logger.debug(f'_request_account_updates exiting (task {task_id})')

	def _genericOrderStatus(self, status: OrderStatus) -> GenericOrderStatus:
		"""
		Maps the Tastytrade order status to the generic order status
		"""
		match status:
			case OrderStatus.RECEIVED:
				return GenericOrderStatus.OPEN
			case OrderStatus.LIVE:
				return GenericOrderStatus.OPEN
			case OrderStatus.CONTINGENT:
				return GenericOrderStatus.OPEN
			case OrderStatus.CANCELLED:
				return GenericOrderStatus.CANCELLED
			case OrderStatus.FILLED:
				return GenericOrderStatus.FILLED
			case OrderStatus.REJECTED:
				return GenericOrderStatus.CANCELLED
			case _:
				return None

	async def request_additional_strikes(
		self, 
		symbol: str, 
		expiration: date, 
		direction: str,
		count: int = 10
	) -> bool:
		"""
		Dynamically request additional strike data for Tastytrade.
		
		Tastytrade uses streaming data via DXLink, so we need to:
		1. Find additional strikes from the option chain
		2. Subscribe to Quote and Greeks for these strikes
		
		Args:
			symbol: The underlying symbol (e.g., 'SPX')
			expiration: The expiration date for the options
			direction: 'higher' for higher strikes, 'lower' for lower strikes
			count: Number of additional strikes to load
			
		Returns:
			True if strikes were loaded, False otherwise
		"""
		if symbol not in self._symbolData:
			logger.warning(f'Symbol {symbol} not found in symbol data')
			return False
			
		symbol_data: TastySymbolData = self._symbolData[symbol]
		
		# Get current option strike data
		try:
			option_strike_data = symbol_data.optionPriceData[expiration]
		except KeyError:
			logger.warning(f'No option data for {symbol} expiration {expiration}')
			return False
		
		current_strikes = sorted(option_strike_data.strikeData.keys())
		if not current_strikes:
			logger.warning(f'No strikes loaded for {symbol}')
			return False
		
		# Find the chain for this expiration
		chain_at_expiration = None
		for chain_exp in symbol_data.chain.expirations:
			if chain_exp.expiration_date == expiration:
				chain_at_expiration = chain_exp
				break
		
		if not chain_at_expiration:
			logger.warning(f'No option chain found for expiration {expiration}')
			return False
		
		# Get available strikes from chain
		available_strikes = []
		for strike in chain_at_expiration.strikes:
			available_strikes.append(strike.strike_price)
		available_strikes = sorted(available_strikes)
		
		# Determine new strikes to request
		new_strikes_to_request = []
		
		if direction == 'higher':
			max_current = max(current_strikes)
			for strike_price in available_strikes:
				if strike_price > max_current and strike_price not in current_strikes:
					new_strikes_to_request.append(strike_price)
					if len(new_strikes_to_request) >= count:
						break
		else:  # direction == 'lower'
			min_current = min(current_strikes)
			for strike_price in reversed(available_strikes):
				if strike_price < min_current and strike_price not in current_strikes:
					new_strikes_to_request.append(strike_price)
					if len(new_strikes_to_request) >= count:
						break
		
		if not new_strikes_to_request:
			logger.debug(f'No additional strikes available in direction {direction}')
			return False
		
		logger.debug(f'Requesting {len(new_strikes_to_request)} additional strikes for {symbol}: {new_strikes_to_request}')
		
		# Find strike objects and subscribe to streaming
		streamer_symbols = []
		for strike_price in new_strikes_to_request:
			# Find strike object in chain
			strike_obj = None
			for strike in chain_at_expiration.strikes:
				if strike.strike_price == strike_price:
					strike_obj = strike
					break
			
			if not strike_obj:
				continue
			
			# Create strike data entry
			option_strike_price_data = OptionStrikePriceData()
			option_strike_data.strikeData[strike_price] = option_strike_price_data
			
			option_strike_price_data.brokerSpecific['call_option'] = strike_obj.call
			option_strike_price_data.brokerSpecific['call_streamer_symbol'] = strike_obj.call_streamer_symbol
			option_strike_price_data.brokerSpecific['put_option'] = strike_obj.put
			option_strike_price_data.brokerSpecific['put_streamer_symbol'] = strike_obj.put_streamer_symbol
			
			streamer_symbols.append(strike_obj.call_streamer_symbol)
			streamer_symbols.append(strike_obj.put_streamer_symbol)
			self._quote_symbols.append(strike_obj.call_streamer_symbol)
			self._quote_symbols.append(strike_obj.put_streamer_symbol)
		
		if not streamer_symbols:
			return False
		
		# Subscribe to streaming data
		try:
			await self._streamer.subscribe(Quote, streamer_symbols)
			await self._streamer.subscribe(Greeks, streamer_symbols)
			logger.info(f'Successfully subscribed to {len(new_strikes_to_request)} additional strikes for {symbol}')
			return True
		except Exception as e:
			logger.error(f'Error subscribing to additional strikes: {e}')
			return False