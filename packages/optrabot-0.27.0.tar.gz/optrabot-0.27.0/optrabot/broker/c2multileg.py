"""
Multileg Order Handler for Collective2 Connector

This module handles the execution of multi-leg option orders (e.g., Iron Condors, Spreads)
through the Collective2 API, which only supports single-leg orders.

The handler splits multileg orders into individual leg orders and executes them
in the correct sequence to avoid margin issues:
- Credit trades: Long legs first, then short legs
- Debit trades: Short legs first, then long legs

Each leg is adjusted independently using the template's adjustment parameters.
"""

import asyncio
import datetime as dt
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, List, Tuple

import httpx
from fastapi import status
from loguru import logger

import optrabot.symbolinfo as symbol_info
from optrabot.broker.order import Leg
from optrabot.broker.order import Order as GenericOrder
from optrabot.broker.order import OrderAction, OrderStatus, OrderType
from optrabot.managedtrade import ManagedTrade
from optrabot.optionhelper import OptionHelper

if TYPE_CHECKING:
    from optrabot.broker.c2connector import C2Connector, C2Order


class LegExecutionStatus(str, Enum):
    """Status of a single leg execution"""
    PENDING = 'pending'
    SUBMITTED = 'submitted'
    ADJUSTING = 'adjusting'
    FILLED = 'filled'
    FAILED = 'failed'
    CANCELLED = 'cancelled'
    SUBMIT_TIMEOUT = 'submit_timeout'  # Submission timed out, order status uncertain


@dataclass
class LegOrder:
    """Represents a single leg order for C2 execution"""
    leg: Leg
    c2_order: 'C2Order' = None
    initial_price: float = 0.0          # Mid-Price of the leg
    current_price: float = 0.0          # Current price (after adjustments)
    adjustment_count: int = 0
    signal_id: int = None
    previous_signal_ids: list = field(default_factory=list)  # Track all previous SignalIds for fill detection
    status: LegExecutionStatus = LegExecutionStatus.PENDING
    fill_price: float = None
    error_message: str = None
    submission_time: dt.datetime = None  # OTB-356: Track when order was submitted for grace period
    cannot_cross_count: int = 0          # Track consecutive "Cannot cross" failures for recovery
    
    @property
    def is_long_leg(self) -> bool:
        """Returns True if this is a long (buy) leg"""
        return self.leg.action in [OrderAction.BUY, OrderAction.BUY_TO_OPEN, OrderAction.BUY_TO_CLOSE]
    
    @property
    def is_short_leg(self) -> bool:
        """Returns True if this is a short (sell) leg"""
        return self.leg.action in [OrderAction.SELL, OrderAction.SELL_TO_OPEN, OrderAction.SELL_TO_CLOSE]


@dataclass
class MultilegExecutionResult:
    """Result of a multileg order execution"""
    success: bool
    filled_legs: List[LegOrder] = field(default_factory=list)
    failed_legs: List[LegOrder] = field(default_factory=list)
    total_fill_price: float = 0.0
    error_message: str = None
    rollback_performed: bool = False
    
    @property
    def partial_fill(self) -> bool:
        """Returns True if some but not all legs were filled"""
        return len(self.filled_legs) > 0 and len(self.failed_legs) > 0


class MultilegOrderHandler:
    """
    Handles execution of multi-leg orders through C2 API.
    
    The handler:
    1. Splits the multileg order into individual leg orders
    2. Executes legs in the correct sequence (long first for credit, short first for debit)
    3. Adjusts prices for each leg independently until filled or max adjustments reached
    4. Performs rollback if any leg fails (closes already filled legs)
    5. Aggregates results and emits combined order status events
    """
    
    # Default configuration values
    DEFAULT_LEG_EXECUTION_TIMEOUT = 120  # seconds
    DEFAULT_MIN_DELAY_BETWEEN_REQUESTS = 0.5  # seconds (for rate limiting)
    DEFAULT_ADJUSTMENT_INTERVAL = 5  # seconds between price adjustments
    DEFAULT_DELAY_BETWEEN_LEG_GROUPS = 10  # seconds to wait between leg groups (OTB-333)
    DEFAULT_GRACE_PERIOD_BEFORE_ADJUST = 5  # OTB-356: seconds to wait before first adjustment to allow subscriber fills
    
    def __init__(self, c2_connector: 'C2Connector') -> None:
        self._connector = c2_connector
        self._leg_execution_timeout = self.DEFAULT_LEG_EXECUTION_TIMEOUT
        self._min_delay_between_requests = self.DEFAULT_MIN_DELAY_BETWEEN_REQUESTS
        self._adjustment_interval = self.DEFAULT_ADJUSTMENT_INTERVAL
        self._delay_between_leg_groups = self.DEFAULT_DELAY_BETWEEN_LEG_GROUPS
        self._grace_period_before_adjust = self.DEFAULT_GRACE_PERIOD_BEFORE_ADJUST
        self._load_config()
    
    def _load_config(self) -> None:
        """Load multileg configuration from app config"""
        import optrabot.config as optrabotcfg
        config = optrabotcfg.appConfig
        
        try:
            multileg_config = config.get('c2.multileg')
            if multileg_config:
                self._leg_execution_timeout = multileg_config.get('leg_execution_timeout', self.DEFAULT_LEG_EXECUTION_TIMEOUT)
                self._min_delay_between_requests = multileg_config.get('min_delay_between_requests', self.DEFAULT_MIN_DELAY_BETWEEN_REQUESTS)
                self._adjustment_interval = multileg_config.get('adjustment_interval', self.DEFAULT_ADJUSTMENT_INTERVAL)
                self._delay_between_leg_groups = multileg_config.get('delay_between_leg_groups', self.DEFAULT_DELAY_BETWEEN_LEG_GROUPS)
                self._grace_period_before_adjust = multileg_config.get('grace_period_before_adjust', self.DEFAULT_GRACE_PERIOD_BEFORE_ADJUST)
                logger.debug(f'Multileg config loaded: timeout={self._leg_execution_timeout}s, '
                           f'min_delay={self._min_delay_between_requests}s, adjustment_interval={self._adjustment_interval}s, '
                           f'delay_between_leg_groups={self._delay_between_leg_groups}s, '
                           f'grace_period_before_adjust={self._grace_period_before_adjust}s')
        except KeyError:
            logger.debug('No multileg configuration found, using defaults')
    
    async def execute_multileg_order(
        self, 
        managed_trade: ManagedTrade,
        order: GenericOrder
    ) -> MultilegExecutionResult:
        """
        Execute a multileg order by splitting it into individual leg orders.
        
        Args:
            managed_trade: The managed trade containing template configuration
            order: The multileg order to execute
            
        Returns:
            MultilegExecutionResult with success status and execution details
        """
        logger.info(f'Starting multileg order execution for {len(order.legs)} legs')
        
        # Create LegOrder objects for each leg
        leg_orders = self._create_leg_orders(order, managed_trade)
        
        # Store leg_orders in order.brokerSpecific so cancel_order can access them during execution
        order.brokerSpecific['active_leg_orders'] = leg_orders
        
        # Determine execution order based on price effect (credit vs debit)
        is_credit_trade = managed_trade.template.is_credit_trade()
        long_legs, short_legs = self._split_legs_by_side(leg_orders)
        
        if is_credit_trade:
            # Credit trade: Long legs first (buy protection), then short legs (sell premium)
            first_group = long_legs
            second_group = short_legs
            logger.info('Credit trade detected - executing long legs first, then short legs')
        else:
            # Debit trade: Short legs first (close short positions), then long legs
            first_group = short_legs
            second_group = long_legs
            logger.info('Debit trade detected - executing short legs first, then long legs')
        
        result = MultilegExecutionResult(success=False)
        
        try:
            # Execute first group of legs
            if first_group:
                group_success = await self._execute_leg_group(
                    first_group, managed_trade, order, 'first'
                )
                if not group_success:
                    # OTB-355: Before rolling back, do a final comprehensive check on "failed" legs
                    failed_legs = [leg for leg in first_group if leg.status in [LegExecutionStatus.FAILED, LegExecutionStatus.CANCELLED]]
                    recovered_legs = await self._final_fill_check_before_rollback(failed_legs, managed_trade)
                    
                    if len(recovered_legs) == len(failed_legs):
                        # All "failed" legs were actually filled - continue to second group
                        logger.info(f'All {len(recovered_legs)} "failed" first group legs were actually filled - continuing')
                    else:
                        result.error_message = 'Failed to execute first leg group'
                        result.failed_legs = [leg for leg in first_group if leg.status in [LegExecutionStatus.FAILED, LegExecutionStatus.CANCELLED]]
                        # Rollback any filled legs from first group
                        filled_first = [leg for leg in first_group if leg.status == LegExecutionStatus.FILLED]
                        if filled_first:
                            await self._rollback_filled_legs(filled_first, managed_trade, order)
                            result.rollback_performed = True
                        return result
            
            # OTB-333: Wait between leg groups to ensure first group orders are executed at subscribers
            if first_group and second_group:
                logger.info(f'Waiting {self._delay_between_leg_groups}s between leg groups for subscriber order execution')
                await asyncio.sleep(self._delay_between_leg_groups)
            
            # Execute second group of legs
            if second_group:
                group_success = await self._execute_leg_group(
                    second_group, managed_trade, order, 'second'
                )
                if not group_success:
                    # OTB-355: Before rolling back, do a final comprehensive check on "failed" legs
                    # This catches race conditions where a leg was filled but we didn't detect it
                    failed_legs = [leg for leg in second_group if leg.status in [LegExecutionStatus.FAILED, LegExecutionStatus.CANCELLED]]
                    recovered_legs = await self._final_fill_check_before_rollback(failed_legs, managed_trade)
                    
                    if len(recovered_legs) == len(failed_legs):
                        # All "failed" legs were actually filled - no rollback needed!
                        logger.info(f'All {len(recovered_legs)} "failed" legs were actually filled - no rollback needed')
                        # Continue to success path
                    else:
                        # Some legs truly failed - need to rollback
                        result.error_message = 'Failed to execute second leg group'
                        result.failed_legs = [leg for leg in second_group if leg.status in [LegExecutionStatus.FAILED, LegExecutionStatus.CANCELLED]]
                        # Rollback all filled legs (both groups)
                        all_filled = [leg for leg in leg_orders if leg.status == LegExecutionStatus.FILLED]
                        if all_filled:
                            await self._rollback_filled_legs(all_filled, managed_trade, order)
                            result.rollback_performed = True
                        return result
            
            # All legs executed successfully
            result.success = True
            result.filled_legs = leg_orders
            result.total_fill_price = self._calculate_total_fill_price(leg_orders, is_credit_trade)
            
            # Update the original order with aggregated fill information
            order.averageFillPrice = round(result.total_fill_price, 2)
            order.status = OrderStatus.FILLED
            
            logger.info(f'Multileg order executed successfully. Total fill price: ${result.total_fill_price:.2f}')
        
        except asyncio.CancelledError:
            logger.warning('Multileg order execution cancelled (shutdown in progress)')
            result.error_message = 'Execution cancelled due to shutdown'
            
            # Cancel any pending leg signals that were submitted but not filled
            pending_legs = [leg for leg in leg_orders if leg.status in [LegExecutionStatus.SUBMITTED, LegExecutionStatus.ADJUSTING]]
            if pending_legs:
                logger.info(f'Cancelling {len(pending_legs)} pending leg signals due to shutdown')
                for leg_order in pending_legs:
                    if leg_order.signal_id:
                        try:
                            await self._cancel_leg_signal(leg_order)
                            leg_order.status = LegExecutionStatus.CANCELLED
                        except Exception as e:
                            logger.warning(f'Failed to cancel leg signal {leg_order.signal_id}: {e}')
            
            # On cancellation, attempt rollback of any filled legs
            all_filled = [leg for leg in leg_orders if leg.status == LegExecutionStatus.FILLED]
            if all_filled:
                logger.info(f'Rolling back {len(all_filled)} filled legs due to cancellation')
                try:
                    await self._rollback_filled_legs(all_filled, managed_trade, order)
                    result.rollback_performed = True
                except asyncio.CancelledError:
                    logger.warning('Rollback also cancelled - manual cleanup may be required')
            raise  # Re-raise to propagate cancellation
            
        except Exception as e:
            logger.error(f'Unexpected error during multileg execution: {e}')
            result.error_message = str(e)
            # Attempt rollback
            all_filled = [leg for leg in leg_orders if leg.status == LegExecutionStatus.FILLED]
            if all_filled:
                await self._rollback_filled_legs(all_filled, managed_trade, order)
                result.rollback_performed = True
        
        return result
    
    def _create_leg_orders(self, order: GenericOrder, managed_trade: ManagedTrade) -> List[LegOrder]:
        """Create LegOrder objects from the order's legs with initial prices"""
        leg_orders = []
        symbol = order.symbol
        
        for leg in order.legs:
            # Calculate mid price for the leg, rounded to tick size
            mid_price = self._calculate_leg_mid_price(leg, symbol)
            
            leg_order = LegOrder(
                leg=leg,
                initial_price=mid_price,
                current_price=mid_price
            )
            leg_orders.append(leg_order)
            logger.debug(f'Created leg order: {leg.action} {leg.strike} {leg.right} @ ${mid_price:.2f}')
        
        return leg_orders
    
    def _round_to_tick_size(self, price: float, symbol: str) -> float:
        """
        Round a price to the valid tick size based on the price level.
        
        The tick size depends on the option price:
        - Price < $3.00: tick size is $0.05 (round_base = 5)
        - Price >= $3.00: tick size is $0.10 (round_base = 10)
        
        Args:
            price: The price to round
            symbol: The underlying symbol (e.g., 'SPX')
            
        Returns:
            The price rounded to the nearest valid tick
        """
        # Get the price-dependent tick size from the broker connector
        tick_size = self._connector.get_min_price_increment(price)
        
        # Get symbol info for multiplier
        symbol_information = symbol_info.symbol_infos.get(symbol)
        if symbol_information is None:
            logger.warning(f'No symbol info for {symbol}, using default multiplier of 100')
            multiplier = 100
        else:
            multiplier = symbol_information.multiplier
        
        # Convert tick size to round_base for OptionHelper (e.g., 0.05 -> 5, 0.10 -> 10)
        round_base = int(tick_size * multiplier)
        return OptionHelper.roundToTickSize(price, round_base)
    
    def _calculate_leg_mid_price(self, leg: Leg, symbol: str) -> float:
        """Calculate the mid price for a leg based on bid/ask, rounded to tick size"""
        if leg.midPrice is not None and leg.midPrice > 0:
            mid = leg.midPrice
        else:
            bid = leg.bidPrice if leg.bidPrice is not None and leg.bidPrice >= 0 else 0
            ask = leg.askPrice if leg.askPrice is not None and leg.askPrice >= 0 else 0
            
            if bid > 0 and ask > 0:
                mid = (bid + ask) / 2
            elif ask > 0:
                mid = ask
            elif bid > 0:
                mid = bid
            else:
                logger.warning(f'No valid price data for leg {leg.strike} {leg.right}, using 0')
                return 0
        
        # Round to tick size for the symbol (e.g., $0.05 for SPX options)
        return self._round_to_tick_size(mid, symbol)
    
    def _split_legs_by_side(self, leg_orders: List[LegOrder]) -> Tuple[List[LegOrder], List[LegOrder]]:
        """Split legs into long and short groups"""
        long_legs = [lo for lo in leg_orders if lo.is_long_leg]
        short_legs = [lo for lo in leg_orders if lo.is_short_leg]
        return long_legs, short_legs
    
    async def _execute_leg_group(
        self,
        leg_orders: List[LegOrder],
        managed_trade: ManagedTrade,
        parent_order: GenericOrder,
        group_name: str
    ) -> bool:
        """
        Execute a group of legs (all long or all short).
        Legs are submitted with a small delay to respect rate limits,
        then all are monitored and adjusted in parallel.
        
        Returns True if all legs in the group were filled successfully.
        """
        from optrabot.broker.brokerfactory import BrokerFactory
        
        logger.info(f'Executing {group_name} leg group with {len(leg_orders)} legs')
        
        # Check if shutdown is in progress before starting
        if BrokerFactory().is_shutting_down() or not self._connector.isTradingEnabled():
            logger.warning(f'{group_name} leg group execution aborted - shutdown in progress')
            raise asyncio.CancelledError('Shutdown in progress')
        
        # Prepare and submit all legs with rate limit delay
        for leg_order in leg_orders:
            # Check shutdown status before each leg submission
            if BrokerFactory().is_shutting_down() or not self._connector.isTradingEnabled():
                logger.warning(f'{group_name} leg group execution aborted during submission - shutdown in progress')
                raise asyncio.CancelledError('Shutdown in progress')
            
            await self._prepare_leg_order(leg_order, parent_order, managed_trade)
            await self._submit_leg_order(leg_order, managed_trade)
            await asyncio.sleep(self._min_delay_between_requests)
        
        # Monitor and adjust all legs until filled or timeout
        adjustment_step = managed_trade.template.adjustmentStep
        max_adjustments = managed_trade.template.maxEntryAdjustments
        
        start_time = dt.datetime.now()
        timeout = dt.timedelta(seconds=self._leg_execution_timeout)
        
        while True:
            # Check for shutdown in progress
            if BrokerFactory().is_shutting_down() or not self._connector.isTradingEnabled():
                logger.warning(f'{group_name} leg group execution aborted during monitoring - shutdown in progress')
                raise asyncio.CancelledError('Shutdown in progress')
            
            # Check for timeout
            if dt.datetime.now() - start_time > timeout:
                logger.warning(f'Leg group execution timeout after {self._leg_execution_timeout}s')
                for leg_order in leg_orders:
                    if leg_order.status not in [LegExecutionStatus.FILLED, LegExecutionStatus.FAILED]:
                        leg_order.status = LegExecutionStatus.FAILED
                        leg_order.error_message = 'Execution timeout'
                return False
            
            # Check status of all legs
            all_filled = True
            any_failed = False
            
            for leg_order in leg_orders:
                if leg_order.status == LegExecutionStatus.FAILED:
                    any_failed = True
                    continue
                
                # Check if leg was cancelled externally
                if leg_order.status == LegExecutionStatus.CANCELLED:
                    logger.warning(f'Leg {leg_order.leg.strike} {leg_order.leg.right} was cancelled externally')
                    any_failed = True
                    continue
                
                if leg_order.status == LegExecutionStatus.FILLED:
                    continue
                
                all_filled = False
                
                # Handle SUBMIT_TIMEOUT: Check if order exists at C2 despite timeout
                if leg_order.status == LegExecutionStatus.SUBMIT_TIMEOUT:
                    order_found, signal_id, is_filled, fill_price = await self._find_order_at_c2(
                        leg_order, managed_trade
                    )
                    if order_found:
                        leg_order.signal_id = signal_id
                        if is_filled:
                            leg_order.status = LegExecutionStatus.FILLED
                            leg_order.fill_price = fill_price
                            logger.info(f'Leg {leg_order.leg.strike} {leg_order.leg.right} found at C2 and filled @ ${fill_price:.2f}')
                        else:
                            leg_order.status = LegExecutionStatus.SUBMITTED
                            logger.info(f'Leg {leg_order.leg.strike} {leg_order.leg.right} found at C2 with signal ID {signal_id}')
                        continue
                    else:
                        # Order not found at C2 after timeout - treat as failed
                        leg_order.status = LegExecutionStatus.FAILED
                        leg_order.error_message = 'Order not found at C2 after timeout'
                        logger.error(f'Leg {leg_order.leg.strike} {leg_order.leg.right} not found at C2 after timeout')
                        any_failed = True
                        continue
                
                # Check if leg was filled via C2 API
                filled, fill_price = await self._check_leg_fill_status(leg_order, managed_trade)
                if filled:
                    leg_order.status = LegExecutionStatus.FILLED
                    leg_order.fill_price = fill_price
                    logger.info(f'Leg {leg_order.leg.strike} {leg_order.leg.right} filled @ ${fill_price:.2f}')
                    continue
                
                # Check if leg was cancelled (detected during status check)
                if leg_order.status == LegExecutionStatus.CANCELLED:
                    logger.warning(f'Leg {leg_order.leg.strike} {leg_order.leg.right} was cancelled')
                    any_failed = True
                    continue
                
                # Check if we should adjust the price
                if max_adjustments is not None and leg_order.adjustment_count >= max_adjustments:
                    leg_order.status = LegExecutionStatus.FAILED
                    leg_order.error_message = f'Max adjustments ({max_adjustments}) reached'
                    any_failed = True
                    continue
                
                # OTB-356: Grace period before first adjustment
                # Wait at least grace_period seconds after submission before adjusting
                # This allows C2 to propagate the order to subscribers and gives them time to fill
                if leg_order.adjustment_count == 0 and leg_order.submission_time:
                    time_since_submission = (dt.datetime.now() - leg_order.submission_time).total_seconds()
                    if time_since_submission < self._grace_period_before_adjust:
                        remaining = self._grace_period_before_adjust - time_since_submission
                        logger.debug(f'Leg {leg_order.leg.strike} {leg_order.leg.right}: Grace period active, '
                                   f'{remaining:.1f}s remaining before first adjustment')
                        continue  # Skip adjustment, wait for next cycle
                
                # Adjust the leg price
                adjustment_success = await self._adjust_leg_price(leg_order, adjustment_step, managed_trade)
                
                # If adjustment failed and leg is now cancelled, mark as failed
                if not adjustment_success and leg_order.status == LegExecutionStatus.CANCELLED:
                    any_failed = True
            
            if all_filled:
                logger.info(f'{group_name} leg group fully executed')
                return True
            
            if any_failed:
                logger.warning(f'{group_name} leg group has failed legs')
                return False
            
            # Wait before next adjustment cycle
            try:
                await asyncio.sleep(self._adjustment_interval)
            except asyncio.CancelledError:
                logger.warning(f'{group_name} leg group execution interrupted by shutdown')
                raise
        
        return False
    
    async def _find_order_at_c2(
        self,
        leg_order: LegOrder,
        managed_trade: ManagedTrade
    ) -> Tuple[bool, int | None, bool, float]:
        """
        Search for an order at C2 by matching leg characteristics.
        Used when submission timed out but order may have been received.
        
        Returns:
            Tuple of (order_found, signal_id, is_filled, fill_price)
        """
        import pytz
        
        leg = leg_order.leg
        start_date = self._connector._start_date.astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        query = {
            'StrategyId': managed_trade.template.account,
            'StartDate': start_date
        }
        
        try:
            response = httpx.get(
                self._connector._base_url + '/Strategies/GetStrategyHistoricalOrders',
                headers=self._connector._http_headers,
                params=query,
                timeout=15.0
            )
            
            if response.status_code != status.HTTP_200_OK:
                logger.debug(f'Failed to search for order at C2: {response.text}')
                return False, None, False, 0.0
            
            json_data = json.loads(response.text)
            results = json_data.get('Results', [])
            
            # Search for matching order by symbol characteristics
            for result in results:
                exchange_symbol = result.get('ExchangeSymbol', {})
                
                # Match by strike, put/call, and expiration
                strike_matches = exchange_symbol.get('StrikePrice') == leg.strike
                # PutOrCall: 0 = Put, 1 = Call
                from optrabot.broker.order import OptionRight
                expected_put_or_call = 0 if leg.right == OptionRight.PUT else 1
                right_matches = exchange_symbol.get('PutOrCall') == expected_put_or_call
                
                # Check expiration (format: YYYYMMDD)
                expected_expiration = leg.expiration.strftime('%Y%m%d')
                expiration_matches = exchange_symbol.get('MaturityMonthYear') == expected_expiration
                
                if strike_matches and right_matches and expiration_matches:
                    signal_id = result.get('SignalId')
                    order_status = result.get('OrderStatus')
                    is_filled = order_status == '2'  # 2 = Filled
                    fill_price = result.get('AvgFillPrice', 0.0) if is_filled else 0.0
                    
                    logger.debug(f'Found matching order at C2: SignalId={signal_id}, Status={order_status}, '
                               f'Strike={leg.strike}, Right={leg.right}')
                    return True, signal_id, is_filled, fill_price
            
            return False, None, False, 0.0
            
        except Exception as e:
            logger.debug(f'Exception searching for order at C2: {e}')
            return False, None, False, 0.0

    async def _prepare_leg_order(
        self, 
        leg_order: LegOrder, 
        parent_order: GenericOrder,
        managed_trade: ManagedTrade
    ) -> None:
        """Prepare a C2Order for the leg"""
        import optrabot.symbolinfo as symbol_info_module
        from optrabot.broker.c2connector import C2ExchangeSymbol, C2Order
        
        leg = leg_order.leg
        symbol_info = symbol_info_module.symbol_infos[parent_order.symbol]
        
        c2_order = C2Order(
            order_type=self._connector._map_order_type(parent_order.type),
            side=self._connector._map_order_side(leg.action)
        )
        c2_order.StrategyId = managed_trade.template.account
        c2_order.OrderQuantity = parent_order.quantity
        c2_order.ExchangeSymbol = C2ExchangeSymbol(
            symbol_info.trading_class, 
            'OPT', 
            leg.right, 
            leg.strike
        )
        c2_order.ExchangeSymbol.MaturityMonthYear = leg.expiration.strftime('%Y%m%d')
        
        # Set initial price - cap at bid/ask to avoid "Cannot cross" error
        if parent_order.type == OrderType.LIMIT:
            initial_price = leg_order.current_price
            
            # Get current bid/ask to ensure we don't cross the market
            bid = leg.bidPrice if leg.bidPrice is not None and leg.bidPrice >= 0 else None
            ask = leg.askPrice if leg.askPrice is not None and leg.askPrice >= 0 else None
            
            # For BUY orders (long leg), cap price at ask
            if leg_order.is_long_leg and ask is not None and ask > 0 and initial_price > ask:
                logger.debug(f'Leg {leg.strike} {leg.right}: Initial BUY price ${initial_price:.2f} exceeds ask ${ask:.2f}, capping at ask')
                initial_price = ask
            # For SELL orders (short leg), floor price at bid
            elif leg_order.is_short_leg and bid is not None and bid > 0 and initial_price < bid:
                logger.debug(f'Leg {leg.strike} {leg.right}: Initial SELL price ${initial_price:.2f} below bid ${bid:.2f}, flooring at bid')
                initial_price = bid
            
            # Round to valid tick size for this symbol
            initial_price = self._round_to_tick_size(initial_price, parent_order.symbol)
            
            leg_order.current_price = initial_price
            c2_order.Limit = str(initial_price)
        
        leg_order.c2_order = c2_order
        logger.debug(f'Prepared C2Order for leg {leg.strike} {leg.right} @ ${leg_order.current_price:.2f}')
    
    async def _submit_leg_order(self, leg_order: LegOrder, managed_trade: ManagedTrade) -> None:
        """
        Submit a single leg order to C2.
        
        On timeout exceptions, the order status is set to SUBMIT_TIMEOUT instead of FAILED
        because the order may have been received by C2 despite the timeout. The monitoring
        loop will then check if the order exists at C2 and update the status accordingly.
        """
        c2_order = leg_order.c2_order
        
        data = {'Order': c2_order.to_dict()}
        logger.debug(f'Submitting leg order: {data}')
        
        try:
            response = httpx.post(
                self._connector._base_url + '/Strategies/NewStrategyOrder',
                headers=self._connector._http_headers,
                json=data,
                timeout=30.0  # Explicit timeout
            )
            
            if response.status_code != status.HTTP_200_OK:
                leg_order.status = LegExecutionStatus.FAILED
                leg_order.error_message = f'HTTP Error: {response.text}'
                logger.error(f'Failed to submit leg order: {response.text}')
                return
            
            json_data = json.loads(response.text)
            response_status = json_data.get('ResponseStatus')
            
            if response_status.get('ErrorCode') != str(status.HTTP_200_OK):
                leg_order.status = LegExecutionStatus.FAILED
                leg_order.error_message = f"API Error: {response_status.get('Message')}"
                logger.error(f'Failed to submit leg order: {response_status.get("Message")}')
                return
            
            result = json_data.get('Results')[0]
            leg_order.signal_id = result.get('SignalId')
            leg_order.status = LegExecutionStatus.SUBMITTED
            leg_order.submission_time = dt.datetime.now()  # OTB-356: Track submission time for grace period
            
            logger.info(f'Leg order submitted. Signal ID: {leg_order.signal_id}')
            
        except (httpx.TimeoutException, httpx.ReadTimeout) as e:
            # Timeout means we don't know if the order was received by C2
            # Set status to SUBMIT_TIMEOUT so monitoring loop can check
            leg_order.status = LegExecutionStatus.SUBMIT_TIMEOUT
            leg_order.error_message = f'Timeout: {e}'
            logger.warning(f'Timeout submitting leg order for {leg_order.leg.strike} {leg_order.leg.right} - '
                          f'will check if order exists at C2')
            
        except Exception as e:
            leg_order.status = LegExecutionStatus.FAILED
            leg_order.error_message = str(e)
            logger.error(f'Exception submitting leg order: {e}')
    
    async def _check_leg_fill_status(
        self, 
        leg_order: LegOrder, 
        managed_trade: ManagedTrade
    ) -> Tuple[bool, float]:
        """
        Check if a leg order has been filled via C2 API.
        
        This method checks both by SignalId and by matching leg characteristics
        (strike, expiration, right) to handle cases where the order was replaced
        and has a new SignalId.
        
        If Autotrade API is enabled, it also checks subscriber fill status and uses
        the Limit price from Autotrade as fill price (better approximation than
        simulated Strategy AvgFillPrice).
        
        Returns (is_filled, fill_price)
        """
        # Query C2 for order status
        import pytz
        
        start_date = self._connector._start_date.astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        query = {
            'StrategyId': managed_trade.template.account,
            'StartDate': start_date
        }
        
        try:
            response = httpx.get(
                self._connector._base_url + '/Strategies/GetStrategyHistoricalOrders',
                headers=self._connector._http_headers,
                params=query
            )
            
            if response.status_code != status.HTTP_200_OK:
                logger.debug(f'Failed to check leg status: {response.text}')
                return False, 0.0
            
            json_data = json.loads(response.text)
            results = json_data.get('Results', [])
            
            leg = leg_order.leg
            
            # Collect all SignalIds to check (current + previous ones from replacements)
            signal_ids_to_check = []
            if leg_order.signal_id:
                signal_ids_to_check.append(leg_order.signal_id)
            signal_ids_to_check.extend(leg_order.previous_signal_ids)
            
            # First, try to find by any known SignalId (current or previous)
            for signal_id in signal_ids_to_check:
                for result in results:
                    if result.get('SignalId') == signal_id:
                        order_status = result.get('OrderStatus')
                        if order_status == '2':  # Filled
                            # Try to get fill price from Autotrade API first (actual subscriber fill)
                            fill_price = self._get_autotrade_fill_price(signal_id, managed_trade)
                            if fill_price == 0.0:
                                # Fall back to Strategy API AvgFillPrice (simulated)
                                fill_price = result.get('AvgFillPrice', 0)
                                logger.debug(f'Leg {leg.strike} {leg.right} using Strategy AvgFillPrice: {fill_price}')
                            else:
                                logger.debug(f'Leg {leg.strike} {leg.right} using Autotrade Limit price: {fill_price}')
                            
                            logger.debug(f'Leg {leg.strike} {leg.right} found FILLED by SignalId {signal_id}')
                            # Update the signal_id to the filled one if it was a previous one
                            if signal_id != leg_order.signal_id:
                                logger.info(f'Leg {leg.strike} {leg.right} was filled with previous SignalId {signal_id} (current was {leg_order.signal_id})')
                                leg_order.signal_id = signal_id
                            return True, float(fill_price)
                        elif order_status == '4':  # Cancelled
                            # Order cancelled - continue checking other SignalIds or leg characteristics
                            logger.debug(f'Leg {leg.strike} {leg.right} SignalId {signal_id} is cancelled, checking for replacement order...')
                            break  # Continue to next signal_id or leg characteristics
            
            # Search by leg characteristics (strike, expiration, option type, side)
            # This handles cases where the order was replaced and has a new SignalId
            from optrabot.broker.order import OptionRight
            expected_put_or_call = 0 if leg.right == OptionRight.PUT else 1
            expected_side = '2' if leg_order.leg.action in [OrderAction.SELL, OrderAction.SELL_TO_OPEN] else '1'
            
            # Get the minimum SignalId we should consider (orders created before this one are not relevant)
            # This prevents matching orders from completely different trades
            min_signal_id = min(signal_ids_to_check) if signal_ids_to_check else 0
            
            # Look for a filled order matching this leg that was created around the same time
            # (SignalId should be close to or greater than our original SignalId)
            for result in results:
                exchange_symbol = result.get('ExchangeSymbol', {})
                result_strike = exchange_symbol.get('StrikePrice')
                result_put_or_call = exchange_symbol.get('PutOrCall')
                result_side = result.get('Side')
                order_status = result.get('OrderStatus')
                result_signal_id = result.get('SignalId')
                
                if (result_strike == leg.strike and 
                    result_put_or_call == expected_put_or_call and
                    result_side == expected_side and
                    order_status == '2' and  # Filled
                    result_signal_id and
                    result_signal_id not in signal_ids_to_check and  # Not already checked
                    result_signal_id >= min_signal_id):  # Created at or after our original order
                    # Try to get fill price from Autotrade API first
                    fill_price = self._get_autotrade_fill_price(result_signal_id, managed_trade)
                    if fill_price == 0.0:
                        fill_price = result.get('AvgFillPrice', 0)
                    
                    logger.debug(f'Leg {leg.strike} {leg.right} found FILLED by leg match (SignalId {result_signal_id}, '
                                f'min_signal_id was {min_signal_id})')
                    # Update signal_id to the filled one
                    if result_signal_id != leg_order.signal_id:
                        logger.info(f'Leg {leg.strike} {leg.right} SignalId updated: {leg_order.signal_id} -> {result_signal_id}')
                        leg_order.signal_id = result_signal_id
                    return True, float(fill_price)
            
            return False, 0.0
            
        except Exception as e:
            logger.debug(f'Exception checking leg status: {e}')
            return False, 0.0
    
    def _get_autotrade_fill_price(self, signal_id: int, managed_trade: ManagedTrade) -> float:
        """
        Get the fill price from Autotrade API for a given SignalId.
        
        The Autotrade API provides subscriber broker execution data. For Limit orders,
        the Limit price is used as the fill price (actual fills are at Limit or better).
        
        Args:
            signal_id: The C2 SignalId
            managed_trade: The managed trade (for strategy ID)
            
        Returns:
            Fill price from Autotrade API, or 0.0 if not available/not configured
        """
        if not self._connector.is_autotrade_enabled():
            return 0.0
        
        try:
            strategy_id = int(managed_trade.template.account)
            is_filled, fill_price, order_status, reject_msg = self._connector.get_autotrade_fill_info(
                signal_id, strategy_id
            )
            
            if is_filled and fill_price > 0:
                return fill_price
            
            # Check for rejected orders in Autotrade
            if order_status == '8' and reject_msg:
                logger.debug(f'Autotrade order {signal_id} was rejected: {reject_msg}')
            
            return 0.0
            
        except Exception as e:
            logger.debug(f'Exception getting Autotrade fill price: {e}')
            return 0.0
    
    async def _comprehensive_fill_check(
        self,
        leg_order: LegOrder,
        managed_trade: ManagedTrade
    ) -> Tuple[bool, float, bool]:
        """
        Perform a comprehensive check for whether a leg order was filled.
        
        This is called when a "Unable to cancel/replace" error is received,
        which indicates the order can no longer be modified - it's either filled
        or cancelled. This method performs multiple retries and searches by both
        SignalId AND leg characteristics to catch cases where:
        
        1. The order was filled with a replacement SignalId we don't know about
        2. There's a propagation delay in C2's order status updates
        3. The order was filled between the adjustment attempt and the error response
        4. OTB-356: The order is still OPEN (not filled, not cancelled)
        
        The method also scans for any recent filled order matching the leg's
        characteristics (strike, right, expiration, side) to catch replacement
        orders that were not properly tracked.
        
        Returns:
            Tuple of (is_filled, fill_price, is_still_open)
            - is_filled: True if the order was filled
            - fill_price: The fill price (if filled)
            - is_still_open: True if the order is still open (not filled, not cancelled)
        """
        leg = leg_order.leg
        
        # Log the comprehensive search for debugging
        signal_ids = [leg_order.signal_id] if leg_order.signal_id else []
        signal_ids.extend(leg_order.previous_signal_ids)
        logger.debug(f'Starting comprehensive fill check for leg {leg.strike} {leg.right}. '
                    f'Known SignalIds: {signal_ids}')
        
        # Retry multiple times with increasing wait times to account for propagation delay
        retry_wait_times = [1.0, 1.5, 2.0, 2.5, 3.0]  # Total max wait: 10 seconds
        
        for retry, wait_time in enumerate(retry_wait_times):
            await asyncio.sleep(wait_time)
            
            # Use the standard check which already searches by SignalId and leg characteristics
            filled, fill_price = await self._check_leg_fill_status(leg_order, managed_trade)
            if filled:
                logger.info(f'Comprehensive check: Leg {leg.strike} {leg.right} found FILLED on retry {retry + 1}')
                return True, fill_price, False
            
            # Additional check: Search for any recently filled order matching leg characteristics
            # This catches replacement orders with SignalIds we may not have tracked
            filled, fill_price = await self._search_filled_by_characteristics(leg_order, managed_trade)
            if filled:
                logger.info(f'Comprehensive check: Leg {leg.strike} {leg.right} found FILLED by characteristics search on retry {retry + 1}')
                return True, fill_price, False
            
            # OTB-356: Check if order is still OPEN
            # If the order is still open, we should NOT mark it as cancelled
            is_open, current_signal_id = await self._check_order_still_open(leg_order, managed_trade)
            if is_open:
                logger.info(f'Comprehensive check: Leg {leg.strike} {leg.right} is still OPEN (SignalId: {current_signal_id})')
                # Update the signal_id if it changed (due to replacement)
                if current_signal_id and current_signal_id != leg_order.signal_id:
                    logger.info(f'Leg {leg.strike} {leg.right}: SignalId updated from {leg_order.signal_id} to {current_signal_id}')
                    if leg_order.signal_id:
                        leg_order.previous_signal_ids.append(leg_order.signal_id)
                    leg_order.signal_id = current_signal_id
                return False, 0.0, True  # Not filled, but still open
            
            if retry < len(retry_wait_times) - 1:
                logger.debug(f'Comprehensive check retry {retry + 1}/{len(retry_wait_times)}: '
                           f'Leg {leg.strike} {leg.right} not yet showing as filled, waiting {retry_wait_times[retry + 1]}s...')
        
        logger.warning(f'Comprehensive fill check exhausted for leg {leg.strike} {leg.right} - order not found as filled')
        return False, 0.0, False
    
    async def _check_order_still_open(
        self,
        leg_order: LegOrder,
        managed_trade: ManagedTrade
    ) -> Tuple[bool, int | None]:
        """
        Check if a leg order is still open (not filled, not cancelled).
        
        This is used to detect cases where the "Unable to cancel" error was due to
        a race condition in C2's API, but the order is actually still open and waiting
        to be filled.
        
        Returns:
            Tuple of (is_open, current_signal_id)
            - is_open: True if an order matching this leg is still open
            - current_signal_id: The SignalId of the open order (may differ from original)
        """
        import pytz

        from optrabot.broker.order import OptionRight
        
        leg = leg_order.leg
        
        start_date = self._connector._start_date.astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        query = {
            'StrategyId': managed_trade.template.account,
            'StartDate': start_date
        }
        
        try:
            response = httpx.get(
                self._connector._base_url + '/Strategies/GetStrategyHistoricalOrders',
                headers=self._connector._http_headers,
                params=query,
                timeout=15.0
            )
            
            if response.status_code != status.HTTP_200_OK:
                logger.debug(f'Failed to check if order is still open: {response.text}')
                return False, None
            
            json_data = json.loads(response.text)
            results = json_data.get('Results', [])
            
            # Collect all SignalIds to check
            signal_ids_to_check = []
            if leg_order.signal_id:
                signal_ids_to_check.append(leg_order.signal_id)
            signal_ids_to_check.extend(leg_order.previous_signal_ids)
            
            # First check by known SignalIds
            for signal_id in signal_ids_to_check:
                for result in results:
                    if result.get('SignalId') == signal_id:
                        order_status = result.get('OrderStatus')
                        # OrderStatus: '0' = New/Open, '1' = PartiallyFilled, '2' = Filled, '4' = Cancelled
                        if order_status in ['0', '1']:  # Open or Partially Filled
                            logger.debug(f'Leg {leg.strike} {leg.right} SignalId {signal_id} is still OPEN (status={order_status})')
                            return True, signal_id
            
            # Also search by leg characteristics for any open order
            expected_put_or_call = 0 if leg.right == OptionRight.PUT else 1
            expected_side = '2' if leg_order.leg.action in [OrderAction.SELL, OrderAction.SELL_TO_OPEN] else '1'
            min_signal_id = min(signal_ids_to_check) if signal_ids_to_check else 0
            
            for result in results:
                exchange_symbol = result.get('ExchangeSymbol', {})
                result_strike = exchange_symbol.get('StrikePrice')
                result_put_or_call = exchange_symbol.get('PutOrCall')
                result_side = result.get('Side')
                order_status = result.get('OrderStatus')
                result_signal_id = result.get('SignalId')
                
                if (result_strike == leg.strike and 
                    result_put_or_call == expected_put_or_call and
                    result_side == expected_side and
                    order_status in ['0', '1'] and  # Open or Partially Filled
                    result_signal_id and
                    result_signal_id >= min_signal_id):
                    logger.debug(f'Leg {leg.strike} {leg.right} found OPEN by characteristics (SignalId {result_signal_id})')
                    return True, result_signal_id
            
            return False, None
            
        except Exception as e:
            logger.debug(f'Exception checking if order is still open: {e}')
            return False, None
    
    async def _search_filled_by_characteristics(
        self,
        leg_order: LegOrder,
        managed_trade: ManagedTrade
    ) -> Tuple[bool, float]:
        """
        Search for a filled order matching the leg's characteristics.
        
        This is a more aggressive search that looks for ANY filled order matching:
        - Strike price
        - Option type (put/call)
        - Expiration
        - Side (buy/sell)
        
        It's used as a fallback when SignalId-based searches fail, which can happen
        when replacement orders are created but their SignalIds aren't properly tracked.
        
        The method is time-bounded by looking only at orders created after the leg_order's
        earliest known SignalId, to avoid matching orders from completely different trades.
        
        Returns:
            Tuple of (is_filled, fill_price)
        """
        import pytz

        from optrabot.broker.order import OptionRight
        
        leg = leg_order.leg
        
        start_date = self._connector._start_date.astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        query = {
            'StrategyId': managed_trade.template.account,
            'StartDate': start_date
        }
        
        try:
            response = httpx.get(
                self._connector._base_url + '/Strategies/GetStrategyHistoricalOrders',
                headers=self._connector._http_headers,
                params=query,
                timeout=15.0
            )
            
            if response.status_code != status.HTTP_200_OK:
                logger.debug(f'Failed to search orders by characteristics: {response.text}')
                return False, 0.0
            
            json_data = json.loads(response.text)
            results = json_data.get('Results', [])
            
            # Determine expected values
            expected_put_or_call = 0 if leg.right == OptionRight.PUT else 1
            expected_side = '2' if leg_order.leg.action in [OrderAction.SELL, OrderAction.SELL_TO_OPEN] else '1'
            expected_expiration = leg.expiration.strftime('%Y%m%d')
            
            # Get all known SignalIds to avoid re-checking them
            known_signal_ids = set()
            if leg_order.signal_id:
                known_signal_ids.add(leg_order.signal_id)
            known_signal_ids.update(leg_order.previous_signal_ids)
            
            # Get the minimum SignalId as a time boundary (orders before this are not relevant)
            min_signal_id = min(known_signal_ids) if known_signal_ids else 0
            
            # Collect all matching filled orders
            matching_filled_orders = []
            
            for result in results:
                exchange_symbol = result.get('ExchangeSymbol', {})
                result_signal_id = result.get('SignalId')
                order_status = result.get('OrderStatus')
                
                # Skip if not filled or already checked
                if order_status != '2':  # Not filled
                    continue
                if result_signal_id in known_signal_ids:
                    continue
                if result_signal_id and result_signal_id < min_signal_id:
                    continue  # Too old
                
                # Check if characteristics match
                if (exchange_symbol.get('StrikePrice') == leg.strike and
                    exchange_symbol.get('PutOrCall') == expected_put_or_call and
                    exchange_symbol.get('MaturityMonthYear') == expected_expiration and
                    result.get('Side') == expected_side):
                    
                    fill_price = result.get('AvgFillPrice', 0)
                    matching_filled_orders.append({
                        'signal_id': result_signal_id,
                        'fill_price': float(fill_price),
                        'order_status': order_status
                    })
            
            if matching_filled_orders:
                # If multiple matches found, take the one with the highest SignalId (most recent)
                matching_filled_orders.sort(key=lambda x: x['signal_id'] or 0, reverse=True)
                best_match = matching_filled_orders[0]
                
                logger.info(f'Found {len(matching_filled_orders)} matching filled orders for leg {leg.strike} {leg.right}. '
                           f'Using most recent: SignalId={best_match["signal_id"]}, FillPrice=${best_match["fill_price"]:.2f}')
                
                # Update the leg_order with the found signal_id
                if leg_order.signal_id and leg_order.signal_id not in known_signal_ids:
                    leg_order.previous_signal_ids.append(leg_order.signal_id)
                leg_order.signal_id = best_match['signal_id']
                
                return True, best_match['fill_price']
            
            return False, 0.0
            
        except Exception as e:
            logger.debug(f'Exception in characteristics search: {e}')
            return False, 0.0

    async def _final_fill_check_before_rollback(
        self,
        failed_legs: List[LegOrder],
        managed_trade: ManagedTrade
    ) -> List[LegOrder]:
        """
        Perform a final comprehensive check on "failed" legs before initiating rollback.
        
        This is a safeguard against false negatives where a leg order was actually filled
        but wasn't detected due to timing issues or API propagation delays. Before rolling
        back filled legs (which would create unwanted positions), we do one more thorough
        check with additional wait time.
        
        This method is called when a leg group execution appears to have failed, but before
        any rollback is executed.
        
        Args:
            failed_legs: List of legs marked as FAILED or CANCELLED
            managed_trade: The managed trade for API queries
            
        Returns:
            List of legs that were found to be actually filled (recovered)
        """
        if not failed_legs:
            return []
        
        logger.info(f'Performing final fill check on {len(failed_legs)} "failed" legs before rollback')
        
        recovered_legs = []
        
        # Give C2 some extra time to update order statuses
        await asyncio.sleep(2.0)
        
        for leg_order in failed_legs:
            leg = leg_order.leg
            logger.debug(f'Final check for leg {leg.strike} {leg.right} (current status: {leg_order.status})')
            
            # Try comprehensive fill check
            filled, fill_price, is_still_open = await self._comprehensive_fill_check(leg_order, managed_trade)
            
            if filled:
                logger.info(f'🔄 Leg {leg.strike} {leg.right} recovered: Was marked as {leg_order.status} but found FILLED @ ${fill_price:.2f}')
                leg_order.status = LegExecutionStatus.FILLED
                leg_order.fill_price = fill_price
                recovered_legs.append(leg_order)
            elif is_still_open:
                # OTB-356: The order is still open - this is a problem because we're about to rollback
                # Log a warning but don't recover it since it's not filled
                logger.warning(f'⚠️ Leg {leg.strike} {leg.right} is still OPEN but was marked as {leg_order.status}. '
                             f'This may result in orphaned orders at C2!')
            else:
                logger.debug(f'Leg {leg.strike} {leg.right} confirmed as not filled after final check')
        
        if recovered_legs:
            logger.warning(f'Recovered {len(recovered_legs)}/{len(failed_legs)} legs that were incorrectly marked as failed')
        
        return recovered_legs

    def _get_current_market_mid_price(
        self,
        leg: Leg,
        symbol: str
    ) -> float | None:
        """
        Get the current mid price from live market data for a leg.
        
        Returns:
            The current mid price, or None if market data is unavailable/outdated
        """
        _, _, mid = self._get_current_market_prices(leg, symbol)
        return mid
    
    def _get_current_market_prices(
        self,
        leg: Leg,
        symbol: str
    ) -> tuple[float | None, float | None, float | None]:
        """
        Get the current bid, ask, and mid prices from live market data for a leg.
        
        Returns:
            Tuple of (bid, ask, mid) - any may be None if unavailable
        """
        try:
            strike_data = self._connector._broker_connector.get_option_strike_price_data(
                symbol, leg.expiration, leg.strike
            )
            
            if strike_data is None or strike_data.is_outdated():
                logger.debug(f'No current market data available for {leg.strike} {leg.right}')
                return None, None, None
            
            # Get bid/ask for the correct option type (put or call)
            from optrabot.broker.order import OptionRight
            if leg.right == OptionRight.PUT:
                bid = strike_data.putBid
                ask = strike_data.putAsk
            else:
                bid = strike_data.callBid
                ask = strike_data.callAsk
            
            mid = None
            if bid is not None and ask is not None and bid > 0 and ask > 0:
                mid = (bid + ask) / 2
            elif ask is not None and ask > 0:
                mid = ask
            elif bid is not None and bid > 0:
                mid = bid
            
            return bid, ask, mid
        except Exception as e:
            logger.debug(f'Error fetching market data for {leg.strike} {leg.right}: {e}')
            return None, None, None

    async def _adjust_leg_price(
        self, 
        leg_order: LegOrder, 
        adjustment_step: float,
        managed_trade: ManagedTrade
    ) -> bool:
        """
        Adjust the leg price toward the market to improve fill probability.
        
        The method ensures that the new limit price is never worse than the current
        market mid price, preventing the order from lagging behind fast-moving markets.
        
        For long legs (buy): new price = max(current_price + step, market_mid_price), capped at ask
        For short legs (sell): new price = min(current_price - step, market_mid_price), floored at bid
        
        IMPORTANT: The limit price must not "cross" the market:
        - BUY orders: limit price must not exceed the ask price
        - SELL orders: limit price must not go below the bid price
        
        Returns:
            True if adjustment was successful, False if it failed (order may no longer exist)
        """
        leg = leg_order.leg
        symbol = managed_trade.entryOrder.symbol
        
        # Get current market prices (bid, ask, mid)
        market_bid, market_ask, market_mid_price = self._get_current_market_prices(leg, symbol)
        
        # Determine adjustment direction based on leg side
        # Long legs (buy): Adjust UP toward ask price - must be at least at market mid
        # Short legs (sell): Adjust DOWN toward bid price - must be at least at market mid
        if leg_order.is_long_leg:
            step_adjusted_price = leg_order.current_price + adjustment_step
            direction = 'up'
            
            # For buy orders, use the higher of step-adjusted price or market mid
            # This ensures we don't lag behind a rising market
            if market_mid_price is not None and market_mid_price > step_adjusted_price:
                new_price = market_mid_price
                logger.debug(f'Leg {leg.strike} {leg.right}: Market moved up, using mid price ${market_mid_price:.2f} '
                           f'instead of step-adjusted ${step_adjusted_price:.2f}')
            else:
                new_price = step_adjusted_price
            
            # CRITICAL: For BUY orders, limit price must NOT reach or exceed the ask price
            # C2 API returns "Cannot cross" error even when limit == ask
            if market_ask is not None and market_ask > 0 and new_price >= market_ask:
                tick_size = self._connector.get_min_price_increment(market_ask)
                capped_price = market_ask - tick_size
                if capped_price > 0:
                    logger.debug(f'Leg {leg.strike} {leg.right}: Capping BUY price at ask-tick ${capped_price:.2f} '
                               f'(was ${new_price:.2f}, ask=${market_ask:.2f}, tick=${tick_size:.2f})')
                    new_price = capped_price
                else:
                    logger.debug(f'Leg {leg.strike} {leg.right}: Cannot cap below ask (ask=${market_ask:.2f}, tick=${tick_size:.2f}), using ask')
                    new_price = market_ask
        else:
            step_adjusted_price = leg_order.current_price - adjustment_step
            direction = 'down'
            
            # For sell orders, use the lower of step-adjusted price or market mid
            # This ensures we don't lag behind a falling market
            if market_mid_price is not None and market_mid_price < step_adjusted_price:
                new_price = market_mid_price
                logger.debug(f'Leg {leg.strike} {leg.right}: Market moved down, using mid price ${market_mid_price:.2f} '
                           f'instead of step-adjusted ${step_adjusted_price:.2f}')
            else:
                new_price = step_adjusted_price
            
            # CRITICAL: For SELL orders, limit price must NOT go below the bid price
            # Otherwise C2 API returns "Cannot cross" error
            # Note: Unlike BUY orders (where limit==ask is rejected by C2), SELL at bid is accepted.
            if market_bid is not None and market_bid > 0 and new_price < market_bid:
                logger.debug(f'Leg {leg.strike} {leg.right}: Flooring SELL price at bid ${market_bid:.2f} '
                           f'(was ${new_price:.2f})')
                new_price = market_bid
        
        # Ensure price doesn't go negative
        if new_price < 0.01:
            new_price = 0.01
        
        # Round to valid tick size for this symbol (e.g., $0.05 for SPX)
        symbol = managed_trade.entryOrder.symbol
        new_price = self._round_to_tick_size(new_price, symbol)
        
        # Post-rounding market crossing check
        # Rounding can push the price to the ask (BUY) or below bid (SELL),
        # e.g. mid=$2.275 rounds UP to $2.30=ask, which C2 rejects as "Cannot cross"
        if leg_order.is_long_leg and market_ask is not None and market_ask > 0 and new_price >= market_ask:
            tick_size = self._connector.get_min_price_increment(new_price)
            corrected = market_ask - tick_size
            corrected = self._round_to_tick_size(corrected, symbol)
            if corrected > leg_order.current_price:
                logger.debug(f'Leg {leg.strike} {leg.right}: Post-rounding BUY price ${new_price:.2f} '
                           f'crosses ask ${market_ask:.2f}, correcting to ${corrected:.2f}')
                new_price = corrected
            else:
                logger.debug(f'Leg {leg.strike} {leg.right}: Post-rounding BUY price ${new_price:.2f} '
                           f'crosses ask ${market_ask:.2f} but correction ${corrected:.2f} <= '
                           f'current ${leg_order.current_price:.2f}, skipping adjustment')
                return True
        elif not leg_order.is_long_leg and market_bid is not None and market_bid > 0 and new_price < market_bid:
            corrected = market_bid
            corrected = self._round_to_tick_size(corrected, symbol)
            if corrected < leg_order.current_price:
                logger.debug(f'Leg {leg.strike} {leg.right}: Post-rounding SELL price ${new_price:.2f} '
                           f'below bid ${market_bid:.2f}, correcting to ${corrected:.2f}')
                new_price = corrected
            else:
                logger.debug(f'Leg {leg.strike} {leg.right}: Post-rounding SELL price ${new_price:.2f} '
                           f'below bid ${market_bid:.2f} but correction ${corrected:.2f} >= '
                           f'current ${leg_order.current_price:.2f}, skipping adjustment')
                return True
        
        # Skip adjustment if price hasn't changed (after rounding to tick size)
        if abs(new_price - leg_order.current_price) < 0.005:  # Less than half a cent
            logger.debug(f'Leg {leg.strike} {leg.right}: Price unchanged after tick size rounding, skipping adjustment')
            return True
        
        logger.debug(f'Adjusting leg {leg.strike} {leg.right} {direction}: ${leg_order.current_price:.2f} -> ${new_price:.2f}'
                    f'{f" (market: bid=${market_bid:.2f} ask=${market_ask:.2f})" if market_bid and market_ask else ""}'
                    f'{f" (mid: ${market_mid_price:.2f})" if market_mid_price and not (market_bid and market_ask) else ""}')
        
        # Update the C2 order via cancel-replace
        c2_order = leg_order.c2_order
        previous_signal_id = leg_order.signal_id
        
        c2_order.Limit = str(new_price)
        c2_order.CancelReplaceSignalId = previous_signal_id
        
        data = {'Order': c2_order.to_dict()}
        
        # Retry logic for transient network errors (timeouts, connection issues)
        max_retries = 3
        last_exception = None
        
        for attempt in range(max_retries):
            try:
                response = httpx.put(
                    self._connector._base_url + '/Strategies/ReplaceStrategyOrder',
                    headers=self._connector._http_headers,
                    json=data,
                    timeout=10.0  # Explicit timeout
                )
                
                if response.status_code != status.HTTP_200_OK:
                    logger.warning(f'Failed to adjust leg order: {response.text}')
                    
                    # Check for "Cannot cross" error (ErrorCode 2010) - limit price at or beyond market
                    if 'Cannot cross' in response.text or '2010' in response.text:
                        leg_order.cannot_cross_count += 1
                        
                        # After repeated failures, the cancel-replace mechanism may be stuck.
                        # C2 may use different market data, or the order is in an inconsistent state.
                        # Recovery: cancel the existing order and place a fresh one.
                        max_cannot_cross_retries = 3
                        if leg_order.cannot_cross_count >= max_cannot_cross_retries:
                            logger.warning(f'Leg {leg.strike} {leg.right}: "Cannot cross" #{leg_order.cannot_cross_count} - '
                                          f'cancel-replace appears stuck. Initiating cancel-and-resubmit recovery.')
                            return await self._cancel_and_resubmit_leg(leg_order, managed_trade)
                        
                        logger.info(f'Leg {leg.strike} {leg.right}: "Cannot cross" #{leg_order.cannot_cross_count} - '
                                   f'adjustment rejected, original order still active at '
                                   f'${leg_order.current_price:.2f}. Will retry on next cycle.')
                        return True  # Order still open, continue monitoring for fill
                    
                    # Check if order no longer exists - could be cancelled OR filled
                    if 'Unable to cancel' in response.text or 'xrpeplace' in response.text.lower():
                        # OTB-355/OTB-356: The order cannot be modified - check if filled, still open, or cancelled
                        filled, fill_price, is_still_open = await self._comprehensive_fill_check(leg_order, managed_trade)
                        if filled:
                            logger.info(f'Leg {leg.strike} {leg.right} was filled @ ${fill_price:.2f} (detected during adjustment via comprehensive check)')
                            leg_order.status = LegExecutionStatus.FILLED
                            leg_order.fill_price = fill_price
                            return True  # Return True because the leg is successfully filled
                        
                        # OTB-356: If order is still open, return True to continue the adjustment loop
                        if is_still_open:
                            logger.info(f'Leg {leg.strike} {leg.right} is still OPEN - continuing adjustment loop')
                            return True  # Return True to continue trying
                        
                        # After comprehensive check, if not filled and not open, it was cancelled
                        logger.warning(f'Leg {leg.strike} {leg.right} appears to be cancelled externally (comprehensive check failed)')
                        leg_order.status = LegExecutionStatus.CANCELLED
                        leg_order.error_message = 'Order cancelled externally'
                    return False
                
                json_data = json.loads(response.text)
                response_status = json_data.get('ResponseStatus')
                
                if response_status.get('ErrorCode') != str(status.HTTP_200_OK):
                    error_message = response_status.get('Message', '')
                    logger.warning(f'Failed to adjust leg order: {response.text}')
                    
                    # Check for "Cannot cross" error (ErrorCode 2010) - limit price at or beyond market
                    errors = response_status.get('Errors', [])
                    for error in errors:
                        if error.get('ErrorCode') == '2010' or 'Cannot cross' in error.get('Message', ''):
                            leg_order.cannot_cross_count += 1
                            
                            # After repeated failures, cancel-replace may be stuck.
                            # Recovery: cancel the existing order and place a fresh one.
                            max_cannot_cross_retries = 3
                            if leg_order.cannot_cross_count >= max_cannot_cross_retries:
                                logger.warning(f'Leg {leg.strike} {leg.right}: "Cannot cross" (ErrorCode 2010) '
                                              f'#{leg_order.cannot_cross_count} - cancel-replace appears stuck. '
                                              f'Initiating cancel-and-resubmit recovery.')
                                return await self._cancel_and_resubmit_leg(leg_order, managed_trade)
                            
                            logger.info(f'Leg {leg.strike} {leg.right}: "Cannot cross" (ErrorCode 2010) '
                                       f'#{leg_order.cannot_cross_count} - adjustment rejected, '
                                       f'original order still active at '
                                       f'${leg_order.current_price:.2f}. Will retry on next cycle.')
                            return True  # Order still open, continue monitoring for fill
                    
                    # Check for specific error indicating order no longer exists
                    for error in errors:
                        if 'Unable to cancel' in error.get('Message', '') or 'xrpeplace' in error.get('Message', '').lower():
                            # OTB-355/OTB-356: The order cannot be modified - check if filled, still open, or cancelled
                            filled, fill_price, is_still_open = await self._comprehensive_fill_check(leg_order, managed_trade)
                            if filled:
                                logger.info(f'Leg {leg.strike} {leg.right} was filled @ ${fill_price:.2f} (detected during adjustment via comprehensive check)')
                                leg_order.status = LegExecutionStatus.FILLED
                                leg_order.fill_price = fill_price
                                return True  # Return True because the leg is successfully filled
                            
                            # OTB-356: If order is still open, return True to continue the adjustment loop
                            if is_still_open:
                                logger.info(f'Leg {leg.strike} {leg.right} is still OPEN - continuing adjustment loop')
                                return True  # Return True to continue trying
                            
                            # After comprehensive check, if not filled and not open, it was cancelled
                            logger.warning(f'Leg {leg.strike} {leg.right} appears to be cancelled externally (comprehensive check failed)')
                            leg_order.status = LegExecutionStatus.CANCELLED
                            leg_order.error_message = 'Order cancelled externally'
                            return False
                    return False
                
                results = json_data.get('Results', [])
                if not results:
                    logger.warning(f'Leg {leg.strike} {leg.right}: No results in adjustment response: {response.text}')
                    return False
                
                result = results[0]
                new_signal_id = result.get('SignalId')
                
                if not new_signal_id:
                    logger.warning(f'Leg {leg.strike} {leg.right}: No SignalId in adjustment response: {response.text}')
                    return False
                
                # Store the previous SignalId for fill detection after failed adjustments
                previous_signal_id = leg_order.signal_id
                if leg_order.signal_id and leg_order.signal_id != new_signal_id:
                    logger.debug(f'Leg {leg.strike} {leg.right}: SignalId changed from {leg_order.signal_id} to {new_signal_id}')
                    leg_order.previous_signal_ids.append(leg_order.signal_id)
                
                leg_order.signal_id = new_signal_id
                leg_order.current_price = new_price
                leg_order.adjustment_count += 1
                leg_order.status = LegExecutionStatus.ADJUSTING
                leg_order.cannot_cross_count = 0  # Reset on successful adjustment
                
                logger.info(f'Leg {leg.strike} {leg.right} adjusted to ${new_price:.2f} '
                           f'(adjustment #{leg_order.adjustment_count}, SignalId: {new_signal_id})')
                
                # OTB-358: Verify the previous order was properly cancelled
                # This prevents race conditions where the original order fills
                # right before the replacement is processed
                if previous_signal_id and previous_signal_id != new_signal_id:
                    await self._verify_previous_order_cancelled(
                        leg_order, previous_signal_id, managed_trade, managed_trade.entryOrder
                    )
                
                return True
                
            except (httpx.TimeoutException, httpx.ConnectError, httpx.ReadTimeout) as e:
                last_exception = e
                if attempt < max_retries - 1:
                    wait_time = (attempt + 1) * 2  # Exponential backoff: 2s, 4s
                    logger.warning(f'Timeout adjusting leg order (attempt {attempt + 1}/{max_retries}): {e}. '
                                  f'Retrying in {wait_time}s...')
                    await asyncio.sleep(wait_time)
                else:
                    logger.warning(f'Failed to adjust leg order after {max_retries} attempts: {e}')
                    
            except Exception as e:
                logger.warning(f'Exception adjusting leg order: {e}')
                return False
        
        # All retries exhausted for timeout errors
        logger.warning(f'All {max_retries} adjustment attempts failed due to timeouts')
        return False
    
    async def _rollback_filled_legs(
        self,
        filled_legs: List[LegOrder],
        managed_trade: ManagedTrade,
        original_order: GenericOrder
    ) -> None:
        """
        Rollback filled legs by creating closing orders.
        This is called when the multileg execution fails partially.
        
        Uses limit orders instead of market orders because C2/OCC rejects
        market orders when there is no bid for the instrument (common for
        far out-of-the-money options).
        """
        logger.warning(f'Rolling back {len(filled_legs)} filled legs')
        
        for leg_order in filled_legs:
            try:
                # Create opposite order to close the position
                closing_action = self._get_closing_action(leg_order.leg.action)
                
                import optrabot.symbolinfo as symbol_info_module
                from optrabot.broker.c2connector import (C2ExchangeSymbol,
                                                         C2Order)
                
                leg = leg_order.leg
                symbol_info = symbol_info_module.symbol_infos[original_order.symbol]
                
                # Determine limit price for rollback order
                # For selling (closing long positions): use bid or minimum price
                # For buying (closing short positions): use ask or aggressive price
                rollback_limit_price = self._calculate_rollback_limit_price(
                    leg_order, original_order.symbol, closing_action
                )
                
                c2_order = C2Order(
                    order_type=self._connector._map_order_type(OrderType.LIMIT),
                    side=self._connector._map_order_side(closing_action)
                )
                c2_order.StrategyId = managed_trade.template.account
                c2_order.OrderQuantity = original_order.quantity
                c2_order.Limit = str(rollback_limit_price)
                c2_order.ExchangeSymbol = C2ExchangeSymbol(
                    symbol_info.trading_class,
                    'OPT',
                    leg.right,
                    leg.strike
                )
                c2_order.ExchangeSymbol.MaturityMonthYear = leg.expiration.strftime('%Y%m%d')
                
                data = {'Order': c2_order.to_dict()}
                logger.info(f'Submitting rollback limit order for leg {leg.strike} {leg.right} @ ${rollback_limit_price:.2f}')
                
                # Retry logic for rollback - this is critical so we try harder
                max_retries = 3
                rollback_success = False
                
                for attempt in range(max_retries):
                    try:
                        response = httpx.post(
                            self._connector._base_url + '/Strategies/NewStrategyOrder',
                            headers=self._connector._http_headers,
                            json=data,
                            timeout=10.0
                        )
                        
                        if response.status_code == status.HTTP_200_OK:
                            logger.info(f'Rollback order submitted for leg {leg.strike} {leg.right}')
                            rollback_success = True
                            break
                        else:
                            logger.error(f'Failed to submit rollback order: {response.text}')
                            break  # Don't retry on API errors, only on network issues
                            
                    except (httpx.TimeoutException, httpx.ConnectError, httpx.ReadTimeout) as e:
                        if attempt < max_retries - 1:
                            wait_time = (attempt + 1) * 2
                            logger.warning(f'Timeout submitting rollback order (attempt {attempt + 1}/{max_retries}): {e}. '
                                          f'Retrying in {wait_time}s...')
                            await asyncio.sleep(wait_time)
                        else:
                            logger.error(f'Failed to submit rollback order after {max_retries} attempts: {e}')
                
                if not rollback_success:
                    logger.error(f'CRITICAL: Rollback failed for leg {leg.strike} {leg.right} - manual intervention required!')
                
                await asyncio.sleep(self._min_delay_between_requests)
                
            except Exception as e:
                logger.error(f'Exception during rollback of leg {leg_order.leg.strike}: {e}')
    
    def _calculate_rollback_limit_price(
        self, 
        leg_order: LegOrder, 
        symbol: str, 
        closing_action: OrderAction
    ) -> float:
        """
        Calculate an aggressive limit price for rollback orders.
        
        For selling (closing long positions): 
            Use the bid price, or $0.05 minimum if no bid available.
        For buying (closing short positions):
            Use the ask price with a small buffer.
        """
        min_option_price = 0.05  # Minimum price for options
        leg = leg_order.leg
        
        # Try to get current market data for the leg via broker connector
        try:
            from optrabot.broker.order import OptionRight
            
            price_data = self._connector._broker_connector.get_option_strike_price_data(
                symbol, leg.expiration, leg.strike
            )
            
            if price_data:
                # Get the appropriate bid/ask based on option right (call or put)
                if leg.right == OptionRight.CALL:
                    bid = price_data.callBid
                    ask = price_data.callAsk
                    mid = price_data.getCallMidPrice()
                else:
                    bid = price_data.putBid
                    ask = price_data.putAsk
                    mid = price_data.getPutMidPrice()
                
                if closing_action in [OrderAction.SELL, OrderAction.SELL_TO_CLOSE]:
                    # Selling: use bid or minimum price
                    if bid and bid > 0:
                        return max(bid, min_option_price)
                    else:
                        # No bid available - use minimum price to get filled
                        return min_option_price
                else:
                    # Buying: use ask with small buffer
                    if ask and ask > 0:
                        return ask + 0.05
                    elif mid and mid > 0:
                        return mid * 1.1  # 10% above mid
                    else:
                        return 0.10  # Default aggressive buy price
        except Exception as e:
            logger.warning(f'Could not get price data for rollback: {e}')
        
        # Fallback: use the fill price from the leg order
        if leg_order.fill_price and leg_order.fill_price > 0:
            if closing_action in [OrderAction.SELL, OrderAction.SELL_TO_CLOSE]:
                return max(leg_order.fill_price * 0.9, min_option_price)  # 10% below fill
            else:
                return leg_order.fill_price * 1.1  # 10% above fill
        
        # Ultimate fallback
        if closing_action in [OrderAction.SELL, OrderAction.SELL_TO_CLOSE]:
            return min_option_price
        else:
            return 0.10
    
    def _get_closing_action(self, opening_action: OrderAction) -> OrderAction:
        """Get the closing action for an opening action"""
        match opening_action:
            case OrderAction.BUY | OrderAction.BUY_TO_OPEN:
                return OrderAction.SELL_TO_CLOSE
            case OrderAction.SELL | OrderAction.SELL_TO_OPEN:
                return OrderAction.BUY_TO_CLOSE
            case OrderAction.BUY_TO_CLOSE:
                return OrderAction.SELL_TO_OPEN
            case OrderAction.SELL_TO_CLOSE:
                return OrderAction.BUY_TO_OPEN
            case _:
                return OrderAction.SELL_TO_CLOSE
    
    def _calculate_total_fill_price(self, leg_orders: List[LegOrder], is_credit_trade: bool) -> float:
        """
        Calculate the total fill price from all legs.
        For credit trades: sum of sold premiums - sum of bought premiums
        For debit trades: sum of bought premiums - sum of sold premiums
        """
        total = 0.0
        
        for leg_order in leg_orders:
            if leg_order.fill_price is None:
                continue
            
            if leg_order.is_long_leg:
                total -= leg_order.fill_price  # Paid premium (debit)
            else:
                total += leg_order.fill_price  # Received premium (credit)
        
        # For credit trades, result should be positive (credit received)
        # For debit trades, result should be negative (debit paid)
        return total
    
    async def _cancel_leg_signal(self, leg_order: LegOrder) -> bool:
        """
        Cancels a pending leg signal at C2.
        
        Args:
            leg_order: The leg order with a signal_id to cancel
            
        Returns:
            True if cancellation was successful
        """
        if leg_order.signal_id is None:
            logger.warning('Cannot cancel leg - no signal ID')
            return False
        
        data = {
            'SignalId': leg_order.signal_id
        }
        
        try:
            logger.debug(f'Sending cancel request for signal {leg_order.signal_id} to C2 API')
            response = httpx.post(
                self._connector._base_url + '/Strategies/CancelStrategySignal',
                headers=self._connector._http_headers,
                json=data
            )
            
            logger.debug(f'Cancel response: status={response.status_code}, body={response.text}')
            
            if response.status_code != status.HTTP_200_OK:
                logger.warning(f'Failed to cancel leg signal {leg_order.signal_id}: HTTP {response.status_code} - {response.text}')
                return False
            
            json_data = json.loads(response.text)
            response_status = json_data.get('ResponseStatus')
            
            if response_status.get('ErrorCode') != str(status.HTTP_200_OK):
                error_msg = response_status.get('Message', 'Unknown error')
                logger.warning(f'Failed to cancel leg signal {leg_order.signal_id}: {error_msg}')
                return False
            
            logger.info(f'Leg signal {leg_order.signal_id} for {leg_order.leg.strike} {leg_order.leg.right} cancelled')
            return True
            
        except Exception as e:
            logger.warning(f'Exception cancelling leg signal {leg_order.signal_id}: {e}')
            return False

    async def _cancel_and_resubmit_leg(
        self,
        leg_order: LegOrder,
        managed_trade: ManagedTrade
    ) -> bool:
        """
        Cancel an existing leg order and resubmit as a fresh order at the current market price.
        
        This is the recovery mechanism when cancel-replace repeatedly fails with "Cannot cross".
        Instead of trying to modify the existing order, we cancel it and place a completely new one.
        
        The C2 ReplaceStrategyOrder API can get stuck rejecting cancel-replace requests even for
        valid prices, possibly due to C2 using different market data or internal state issues.
        By cancelling and placing a fresh NewStrategyOrder, we bypass the cancel-replace mechanism.
        
        Returns:
            True if resubmit was successful or order was already filled, False on failure
        """
        leg = leg_order.leg
        symbol = managed_trade.entryOrder.symbol
        
        logger.info(f'Leg {leg.strike} {leg.right}: Initiating cancel-and-resubmit recovery '
                    f'after {leg_order.cannot_cross_count} consecutive "Cannot cross" failures')
        
        # Step 1: Check if the order was filled in the meantime
        filled, fill_price, is_still_open = await self._comprehensive_fill_check(leg_order, managed_trade)
        if filled:
            logger.info(f'Leg {leg.strike} {leg.right}: Order was filled @ ${fill_price:.2f} during recovery check')
            leg_order.status = LegExecutionStatus.FILLED
            leg_order.fill_price = fill_price
            leg_order.cannot_cross_count = 0
            return True
        
        if not is_still_open:
            # Order is gone (neither filled nor open) - just resubmit fresh
            logger.warning(f'Leg {leg.strike} {leg.right}: Order is neither filled nor open at C2 - '
                          f'submitting fresh order')
        else:
            # Step 2: Cancel the existing order
            logger.info(f'Leg {leg.strike} {leg.right}: Cancelling existing order (SignalId: {leg_order.signal_id})')
            cancel_success = await self._cancel_leg_signal(leg_order)
            if not cancel_success:
                # Cancel failed - order might have been filled or is in a weird state
                # Re-check fill status
                filled2, fill_price2, _ = await self._comprehensive_fill_check(leg_order, managed_trade)
                if filled2:
                    logger.info(f'Leg {leg.strike} {leg.right}: Order was filled @ ${fill_price2:.2f} '
                              f'(detected after cancel attempt)')
                    leg_order.status = LegExecutionStatus.FILLED
                    leg_order.fill_price = fill_price2
                    leg_order.cannot_cross_count = 0
                    return True
                # Cancel failed and not filled - return True to keep monitoring
                # The order might still be active, let the next adjustment cycle try again
                logger.warning(f'Leg {leg.strike} {leg.right}: Cancel failed and order not filled. '
                              f'Continuing monitoring.')
                leg_order.cannot_cross_count = 0  # Reset counter to allow more cancel-replace attempts
                return True
            
            # Small delay to let C2 process the cancel
            await asyncio.sleep(0.5)
        
        # Step 3: Calculate a new conservative price
        market_bid, market_ask, market_mid_price = self._get_current_market_prices(leg, symbol)
        
        if market_mid_price is not None and market_mid_price > 0:
            new_price = market_mid_price
        elif market_bid and market_ask:
            new_price = (market_bid + market_ask) / 2
        else:
            new_price = leg_order.current_price
        
        # Cap/floor the price safely
        if leg_order.is_long_leg and market_ask is not None and market_ask > 0:
            tick_size = self._connector.get_min_price_increment(market_ask)
            max_buy_price = market_ask - tick_size
            if new_price >= market_ask:
                new_price = max_buy_price
        elif leg_order.is_short_leg and market_bid is not None and market_bid > 0:
            if new_price < market_bid:
                new_price = market_bid
        
        new_price = self._round_to_tick_size(new_price, symbol)
        
        # Final safety: post-rounding cap for BUY orders
        if leg_order.is_long_leg and market_ask is not None and market_ask > 0 and new_price >= market_ask:
            tick_size = self._connector.get_min_price_increment(new_price)
            new_price = market_ask - tick_size
            new_price = self._round_to_tick_size(new_price, symbol)
        
        if new_price < 0.01:
            new_price = 0.01
        
        logger.info(f'Leg {leg.strike} {leg.right}: Resubmitting fresh order @ ${new_price:.2f} '
                    f'(market: bid=${market_bid if market_bid else 0:.2f} '
                    f'ask=${market_ask if market_ask else 0:.2f})')
        
        # Step 4: Prepare the c2_order for fresh submission (no CancelReplaceSignalId)
        c2_order = leg_order.c2_order
        c2_order.Limit = str(new_price)
        # Clear the CancelReplaceSignalId so it's treated as a new order
        if hasattr(c2_order, 'CancelReplaceSignalId'):
            c2_order.CancelReplaceSignalId = None
        
        # Track old signal ID
        if leg_order.signal_id:
            leg_order.previous_signal_ids.append(leg_order.signal_id)
        
        # Step 5: Submit as a fresh new order
        await self._submit_leg_order(leg_order, managed_trade)
        
        if leg_order.status == LegExecutionStatus.SUBMITTED:
            leg_order.current_price = new_price
            leg_order.cannot_cross_count = 0  # Reset counter
            logger.info(f'Leg {leg.strike} {leg.right}: Fresh order submitted successfully '
                       f'(new SignalId: {leg_order.signal_id}, price: ${new_price:.2f})')
            return True
        else:
            logger.error(f'Leg {leg.strike} {leg.right}: Fresh order submission failed: {leg_order.error_message}')
            leg_order.cannot_cross_count = 0  # Reset counter even on failure
            return False

    async def _cancel_signal_by_id(self, signal_id: int) -> bool:
        """
        Cancels a C2 signal by its ID.
        
        Args:
            signal_id: The SignalId to cancel
            
        Returns:
            True if cancellation was successful or if order is already cancelled/filled
        """
        data = {'SignalId': signal_id}
        
        try:
            logger.debug(f'Sending cancel request for signal {signal_id} to C2 API')
            response = httpx.post(
                self._connector._base_url + '/Strategies/CancelStrategySignal',
                headers=self._connector._http_headers,
                json=data
            )
            
            # HTTP 405 (Method Not Allowed) often means the order is already cancelled
            # or in a terminal state at C2 - treat this as success
            if response.status_code == 405:
                logger.debug(f'Signal {signal_id} cancel returned HTTP 405 - order likely already cancelled/filled')
                return True
            
            if response.status_code != status.HTTP_200_OK:
                logger.warning(f'Failed to cancel signal {signal_id}: HTTP {response.status_code}')
                return False
            
            json_data = json.loads(response.text)
            response_status = json_data.get('ResponseStatus')
            
            if response_status.get('ErrorCode') != str(status.HTTP_200_OK):
                error_msg = response_status.get('Message', 'Unknown error')
                # Check if error indicates order is already in terminal state
                if 'unable to cancel' in error_msg.lower() or 'already' in error_msg.lower():
                    logger.debug(f'Signal {signal_id} appears to be already cancelled/filled: {error_msg}')
                    return True
                logger.warning(f'Failed to cancel signal {signal_id}: {error_msg}')
                return False
            
            logger.info(f'Signal {signal_id} cancelled successfully')
            return True
            
        except Exception as e:
            logger.warning(f'Exception cancelling signal {signal_id}: {e}')
            return False

    async def _verify_previous_order_cancelled(
        self,
        leg_order: LegOrder,
        previous_signal_id: int,
        managed_trade: ManagedTrade,
        original_order: GenericOrder
    ) -> None:
        """
        OTB-358: Verify that the previous order was properly cancelled after a replacement.
        
        This prevents race conditions where:
        1. Order A is submitted at price X
        2. Replacement creates Order B at price Y
        3. Order A was already being filled when replacement arrived
        4. Both Order A and Order B get filled -> duplicate position!
        
        If the previous order was filled instead of cancelled, this method
        creates a closing order to reverse the duplicate fill.
        
        If the previous order is still OPEN (cancel failed), this method
        attempts to manually cancel it.
        
        Args:
            leg_order: The current leg order (with new SignalId)
            previous_signal_id: The SignalId that was replaced
            managed_trade: The managed trade for context
            original_order: The original multileg order
        """
        leg = leg_order.leg
        
        # OTB-358: Use retry logic with increasing wait times for C2 propagation delay
        # C2 may take 1-3 seconds to propagate order status changes after replacement
        retry_wait_times = [1.0, 1.5, 2.0]  # Total max wait: ~4.5 seconds
        
        for retry, wait_time in enumerate(retry_wait_times):
            await asyncio.sleep(wait_time)
            
            # Query C2 for the status of the previous order
            import pytz
            start_date = self._connector._start_date.astimezone(pytz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
            query = {
                'StrategyId': managed_trade.template.account,
                'StartDate': start_date
            }
            
            try:
                response = httpx.get(
                    self._connector._base_url + '/Strategies/GetStrategyHistoricalOrders',
                    headers=self._connector._http_headers,
                    params=query
                )
                
                if response.status_code != status.HTTP_200_OK:
                    logger.warning(f'OTB-358: Failed to verify previous order {previous_signal_id}: {response.text}')
                    continue
                
                json_data = json.loads(response.text)
                results = json_data.get('Results', [])
                
                # Find the previous order
                previous_order = None
                for result in results:
                    if result.get('SignalId') == previous_signal_id:
                        previous_order = result
                        break
                
                if previous_order is None:
                    logger.debug(f'OTB-358: Previous order {previous_signal_id} not found in historical orders')
                    return
                
                order_status = previous_order.get('OrderStatus')
                # OrderStatus: "0" = Open, "2" = Filled, "4" = Cancelled, "8" = Rejected
                
                if order_status == '4':
                    # Order was properly cancelled - all good
                    logger.debug(f'OTB-358: Previous order {previous_signal_id} was properly cancelled')
                    return
                
                if order_status == '8':
                    # Order was rejected - also fine
                    logger.debug(f'OTB-358: Previous order {previous_signal_id} was rejected')
                    return
                
                if order_status == '0':
                    # Order still shows as OPEN - may be propagation delay
                    if retry < len(retry_wait_times) - 1:
                        logger.debug(f'OTB-358: Previous order {previous_signal_id} still shows OPEN, '
                                   f'retry {retry + 1}/{len(retry_wait_times)}...')
                        continue
                    
                    # Final retry - attempt manual cancel (may already be cancelled, hence soft warning)
                    logger.warning(f'OTB-358: Previous order {previous_signal_id} still showing OPEN after '
                                 f'{sum(retry_wait_times)}s - attempting manual cancellation...')
                    cancelled = await self._cancel_signal_by_id(previous_signal_id)
                    if cancelled:
                        logger.info(f'OTB-358: Orphaned order {previous_signal_id} handled successfully')
                    else:
                        # This is now a softer warning since HTTP 405 means order was likely already processed
                        logger.warning(f'OTB-358: Could not cancel order {previous_signal_id} - '
                                     f'likely already cancelled by C2')
                    return
                
                if order_status == '2':
                    # ORDER WAS FILLED! This is a duplicate execution!
                    fill_price = float(previous_order.get('AvgFillPrice', 0))
                    fill_qty = previous_order.get('FillQuantity', original_order.quantity)
                    
                    logger.error(f'OTB-358: DUPLICATE FILL DETECTED! Previous order {previous_signal_id} '
                                f'was FILLED @ ${fill_price:.2f} (qty={fill_qty}) instead of cancelled!')
                    logger.error(f'OTB-358: Leg {leg.strike} {leg.right} now has duplicate position. '
                                f'Creating closing order to reverse the duplicate...')
                    
                    # Create a closing order to reverse the duplicate fill
                    await self._close_duplicate_fill(
                        leg_order, previous_signal_id, fill_price, fill_qty, 
                        managed_trade, original_order
                    )
                    return
                    
            except Exception as e:
                logger.warning(f'OTB-358: Exception verifying previous order {previous_signal_id}: {e}')
                if retry < len(retry_wait_times) - 1:
                    continue
                return

    async def _close_duplicate_fill(
        self,
        leg_order: LegOrder,
        duplicate_signal_id: int,
        duplicate_fill_price: float,
        duplicate_qty: int,
        managed_trade: ManagedTrade,
        original_order: GenericOrder
    ) -> None:
        """
        OTB-358: Close a duplicate fill caused by a race condition during order replacement.
        
        This creates a closing order to reverse the unintended fill from the
        previous order that was supposed to be cancelled but got filled instead.
        
        Args:
            leg_order: The leg order that was being adjusted
            duplicate_signal_id: The SignalId of the duplicate fill
            duplicate_fill_price: The price at which the duplicate was filled
            duplicate_qty: The quantity of the duplicate fill
            managed_trade: The managed trade for context
            original_order: The original multileg order
        """
        leg = leg_order.leg
        
        # Determine the closing action (opposite of the original)
        closing_action = self._get_closing_action(leg.action)
        
        import optrabot.symbolinfo as symbol_info_module
        from optrabot.broker.c2connector import C2ExchangeSymbol, C2Order
        
        symbol_info = symbol_info_module.symbol_infos[original_order.symbol]
        
        # Calculate an aggressive limit price to ensure quick fill
        # We want to close this position ASAP to minimize risk
        close_limit_price = self._calculate_rollback_limit_price(
            leg_order, original_order.symbol, closing_action
        )
        
        c2_order = C2Order(
            order_type=self._connector._map_order_type(OrderType.LIMIT),
            side=self._connector._map_order_side(closing_action)
        )
        c2_order.StrategyId = managed_trade.template.account
        c2_order.OrderQuantity = duplicate_qty
        c2_order.Limit = str(close_limit_price)
        c2_order.ExchangeSymbol = C2ExchangeSymbol(
            symbol_info.trading_class,
            'OPT',
            leg.right,
            leg.strike
        )
        c2_order.ExchangeSymbol.MaturityMonthYear = leg.expiration.strftime('%Y%m%d')
        
        data = {'Order': c2_order.to_dict()}
        
        logger.warning(f'OTB-358: Submitting CORRECTION order to close duplicate fill: '
                      f'{closing_action.value} {duplicate_qty}x {leg.strike} {leg.right} @ ${close_limit_price:.2f}')
        
        try:
            response = httpx.post(
                self._connector._base_url + '/Strategies/SubmitStrategyOrder',
                headers=self._connector._http_headers,
                json=data
            )
            
            if response.status_code != status.HTTP_200_OK:
                logger.error(f'OTB-358: Failed to submit correction order: {response.text}')
                logger.error(f'OTB-358: MANUAL INTERVENTION REQUIRED! '
                            f'Close {duplicate_qty}x {leg.strike} {leg.right} manually!')
                return
            
            json_data = json.loads(response.text)
            response_status = json_data.get('ResponseStatus')
            
            if response_status.get('ErrorCode') != str(status.HTTP_200_OK):
                error_msg = response_status.get('Message', 'Unknown error')
                logger.error(f'OTB-358: Correction order rejected: {error_msg}')
                logger.error(f'OTB-358: MANUAL INTERVENTION REQUIRED! '
                            f'Close {duplicate_qty}x {leg.strike} {leg.right} manually!')
                return
            
            results = json_data.get('Results', [])
            if results:
                correction_signal_id = results[0].get('SignalId')
                logger.warning(f'OTB-358: Correction order submitted successfully. '
                              f'SignalId: {correction_signal_id}. '
                              f'The duplicate fill from {duplicate_signal_id} will be reversed.')
            else:
                logger.warning(f'OTB-358: Correction order submitted but no SignalId returned')
                
        except Exception as e:
            logger.error(f'OTB-358: Exception submitting correction order: {e}')
            logger.error(f'OTB-358: MANUAL INTERVENTION REQUIRED! '
                        f'Close {duplicate_qty}x {leg.strike} {leg.right} manually!')

