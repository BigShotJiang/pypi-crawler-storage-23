"""
Custom exceptions for the Tradier API client.
"""

from __future__ import annotations


class TradierError(Exception):
    """
    Base exception for all Tradier API errors.
    """

    pass


class TradierAPIError(TradierError):
    """
    Exception raised when the Tradier API returns an error response.
    
    :param message: The error message from the API.
    :param status_code: The HTTP status code of the response.
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message

    def __repr__(self) -> str:
        return f"TradierAPIError(message={self.message!r}, status_code={self.status_code!r})"


class TradierAuthenticationError(TradierAPIError):
    """
    Exception raised when authentication fails.
    """

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message=message, status_code=401)


class TradierRateLimitError(TradierAPIError):
    """
    Exception raised when the API rate limit is exceeded.
    """

    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__(message=message, status_code=429)


class TradierNotFoundError(TradierAPIError):
    """
    Exception raised when a requested resource is not found.
    """

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message=message, status_code=404)
