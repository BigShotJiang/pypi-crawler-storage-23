"""
Tradier API Client - Integrated into OptraBot

A modern, fully-typed Python client for the Tradier Brokerage API.
Originally based on the tradier SDK, now integrated directly into OptraBot
for native loguru logging support.
"""

# API Configuration
API_URL = "https://api.tradier.com/v1"
SANDBOX_URL = "https://sandbox.tradier.com/v1"
STREAM_URL = "https://stream.tradier.com/v1"

VERSION = "0.2.0"
__version__ = VERSION

from optrabot.broker.tradier.account import Account
from optrabot.broker.tradier.exceptions import TradierAPIError, TradierError
from optrabot.broker.tradier.markets import (Greeks, Quote, get_quotes,
                                             get_quotes_sync)
from optrabot.broker.tradier.options import (Expiration, ExpirationType,
                                             OptionChain, OptionRight,
                                             OptionType, Strike,
                                             get_option_symbols,
                                             get_option_symbols_sync,
                                             lookup_option_symbols,
                                             lookup_option_symbols_sync)
from optrabot.broker.tradier.orders import (NewOrderLeg, OrderClass,
                                            OrderDuration, OrderLeg,
                                            OrderResponse, OrderSide,
                                            OrderStatus, OrderType,
                                            PlacedOrder, a_cancel_order,
                                            a_get_order, a_get_orders,
                                            a_modify_order,
                                            a_place_multileg_order,
                                            a_place_option_order, cancel_order,
                                            get_order, get_orders,
                                            modify_order, place_multileg_order,
                                            place_option_order)
from optrabot.broker.tradier.session import Session
from optrabot.broker.tradier.streaming import (MarketDataStreamer,
                                               StreamFilter, StreamingSession,
                                               Summary, Timesale, Trade,
                                               Tradex, create_market_session,
                                               create_market_session_sync)

__all__ = [
    # Core
    "Account",
    "Session",
    # Markets
    "Greeks",
    "Quote",
    "get_quotes",
    "get_quotes_sync",
    # Options
    "OptionChain",
    "Expiration",
    "ExpirationType",
    "OptionRight",
    "OptionType",
    "Strike",
    "get_option_symbols",
    "get_option_symbols_sync",
    "lookup_option_symbols",
    "lookup_option_symbols_sync",
    # Orders
    "PlacedOrder",
    "OrderResponse",
    "OrderLeg",
    "NewOrderLeg",
    "OrderClass",
    "OrderSide",
    "OrderType",
    "OrderDuration",
    "OrderStatus",
    "place_option_order",
    "a_place_option_order",
    "place_multileg_order",
    "a_place_multileg_order",
    "modify_order",
    "a_modify_order",
    "cancel_order",
    "a_cancel_order",
    "get_orders",
    "a_get_orders",
    "get_order",
    "a_get_order",
    # Streaming
    "MarketDataStreamer",
    "StreamingSession",
    "StreamFilter",
    "Trade",
    "Tradex",
    "Summary",
    "Timesale",
    "create_market_session",
    "create_market_session_sync",
    # Exceptions
    "TradierError",
    "TradierAPIError",
    # Constants
    "API_URL",
    "SANDBOX_URL",
    "STREAM_URL",
    "VERSION",
]
