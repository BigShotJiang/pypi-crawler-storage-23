"""
Flow Configuration Data Classes

This module defines the data structures for flow configurations
loaded from the config.yaml file.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from .flowevent import FlowEventType


@dataclass
class FlowTimeSpec:
    """
    Specification for time in flow actions.
    
    Supports two modes:
    - Absolute time: A specific time with timezone (e.g. "15:45 EST")
    - Relative time: Offset from market close (e.g. "T-0:10:00" = 10 minutes before close)
    
    Relative time formats supported:
    - T-H:MM:SS or T-HH:MM:SS (e.g. "T-0:10:00", "T-00:10:00")
    - T-Xh, T-Xm, T-Xs (e.g. "T-10m", "T-1h", "T-30s", "T-1h30m")
    """
    is_relative: bool
    # For absolute time: datetime with timezone
    # For relative time: timedelta offset before market close
    value: Union[datetime, timedelta]
    original_string: str  # Original config string for logging/display


class FlowActionType(str, Enum):
    """Enumeration of available flow action types"""
    SEND_NOTIFICATION = "send_notification"
    PROCESS_TEMPLATE = "process_template"


@dataclass
class FlowEventConfig:
    """Configuration for a flow event trigger"""
    type: FlowEventType
    template: str  # Required: Template name that must trigger this flow


@dataclass
class SendNotificationAction:
    """Configuration for send_notification action"""
    message: str
    type: str = "INFO"  # Default notification type


@dataclass
class ProcessTemplateAction:
    """Configuration for process_template action"""
    template: str
    amount: Any  # Can be int or expression string
    premium: Any  # Can be float or expression string
    expiration: Any = None  # Optional: Can be date or expression string
    time: FlowTimeSpec = None  # Optional: Absolute or relative time specification


@dataclass
class FlowAction:
    """Wrapper for flow actions"""
    action_type: FlowActionType
    action_config: Any  # SendNotificationAction or ProcessTemplateAction


@dataclass
class Flow:
    """Configuration for a complete flow"""
    id: str
    name: Optional[str] = None
    enabled: bool = True
    event: Optional[FlowEventConfig] = None
    actions: List[FlowAction] = field(default_factory=list)
    
    def get_display_name(self) -> str:
        """Returns the flow name or ID if name is not set"""
        return self.name if self.name else self.id
