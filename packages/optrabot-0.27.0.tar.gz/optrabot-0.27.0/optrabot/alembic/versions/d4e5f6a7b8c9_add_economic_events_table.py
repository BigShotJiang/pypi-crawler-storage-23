"""Add economic_events table for OTB-387

Revision ID: d4e5f6a7b8c9
Revises: 235bd68ca48c
Create Date: 2026-02-24 10:00:00.000000

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = 'd4e5f6a7b8c9'
down_revision: Union[str, None] = '235bd68ca48c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create economic_events table for caching Investing.com calendar data"""
    op.create_table(
        'economic_events',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('event_date', sa.Date(), nullable=False),
        sa.Column('time', sa.String(), nullable=True),
        sa.Column('currency', sa.String(), nullable=True),
        sa.Column('country', sa.String(), nullable=True),
        sa.Column('importance', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('event_name', sa.String(), nullable=False),
        sa.Column('actual', sa.String(), nullable=True),
        sa.Column('forecast', sa.String(), nullable=True),
        sa.Column('previous', sa.String(), nullable=True),
        sa.Column('fetched_at', sa.TIMESTAMP(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_economic_events_event_date', 'economic_events', ['event_date'])
    op.create_index('ix_economic_events_country', 'economic_events', ['country'])


def downgrade() -> None:
    """Drop economic_events table"""
    op.drop_index('ix_economic_events_country', table_name='economic_events')
    op.drop_index('ix_economic_events_event_date', table_name='economic_events')
    op.drop_table('economic_events')
