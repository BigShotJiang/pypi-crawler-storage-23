import click

from snippy_ng.__about__ import __version__, EXE, GITHUB_URL
from snippy_ng.cli.short_cli import short
from snippy_ng.cli.asm_cli import asm
from snippy_ng.cli.long_cli import long
from snippy_ng.cli.ref_cli import ref
from snippy_ng.cli.core_cli import core
from snippy_ng.cli.tree_cli import tree
from snippy_ng.cli.multi_cli import multi
from snippy_ng.cli.gather_cli import gather
from snippy_ng.cli.samclip_cli import samclip
from snippy_ng.cli.report_cli import report
from snippy_ng.cli.yolo_cli import yolo
from snippy_ng.cli.utils.bug_catcher import BugCatchingGroup


def show_citation(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    click.echo(f"Please cite '{EXE}' in your research: …")
    ctx.exit()


def bug_report(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    import webbrowser
    url = f"{GITHUB_URL}/issues/new?template=bug_report.md&labels=bug&type=bug"
    click.echo(f"Please report bugs at: {url}")
    webbrowser.open(url, new=2)
    ctx.exit()


def version(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    click.echo(__version__)
    ctx.exit()


@click.group(
    cls=BugCatchingGroup,
    context_settings={"help_option_names": ["-h", "--help"], "max_content_width": 120},
)
@click.option("--version", "-v", is_flag=True, callback=version, expose_value=False, help="Show version and exit.")
@click.option("--citation", "-c", is_flag=True, callback=show_citation, expose_value=False,
              help="Print citation for referencing Snippy-NG.")
@click.option("--bug", "-b", is_flag=True, callback=bug_report, expose_value=False,
              help="Report a bug or issue with Snippy-NG.")
def snippy_ng():
    """
    Snippy-NG: The Next Generation of Variant Calling.
    """
    pass

########################
# Register Subcommands #
########################
snippy_ng.add_command(asm)
snippy_ng.add_command(short)
snippy_ng.add_command(long)
snippy_ng.add_command(multi)
snippy_ng.add_command(core)
snippy_ng.add_command(tree)
snippy_ng.add_command(yolo)


# Add utility sub group
@snippy_ng.group(cls=BugCatchingGroup, context_settings={"help_option_names": ["-h", "--help"], "max_content_width": 120})
def utils():
    """
    Utility commands for Snippy-NG.
    """
    pass

utils.add_command(ref)
utils.add_command(gather)
utils.add_command(samclip)
utils.add_command(report)