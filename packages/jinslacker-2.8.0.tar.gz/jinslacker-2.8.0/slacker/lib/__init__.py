"""Generic library stuff."""

__author__ = 'Murray Andrews'
