"""Allows us to treat resources as a package, which is occassionally handy."""
