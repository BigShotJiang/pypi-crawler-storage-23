#!/usr/bin/env python3

"""Set version."""

__version__ = '2.8.0'

if __name__ == '__main__':  # pragma: no cover
    print(__version__)
