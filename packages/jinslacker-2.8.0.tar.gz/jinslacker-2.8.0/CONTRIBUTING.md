Positive contributions are welcome, so let's not over-complicate this.

These are the rules, for now:

1.  Be courteous and respectful, and think before you type.

2.  All proposed changes should be discussed with us first by raising an issue.

3.  We have the final say on everything, but we'll always try to be reasonable.
