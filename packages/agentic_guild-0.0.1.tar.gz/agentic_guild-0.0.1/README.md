# agentic:guild
This package name is reserved for the agentic:guild engineering framework.
