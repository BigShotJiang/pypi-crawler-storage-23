# fastapi-auth-utils
A minimal authentication/authorization utility for FastAPI.

## How tom install
using pip:
```bash
pip install fastapi-auth-utils
```

using poetry:
```bash
poetry add fastapi-auth-utils
```

## How to use
See [examples](https://github.com/alirezaja1384/fastapi-auth-utils/tree/main/examples)

## License
MIT
