# Git Spellcheck

Spelling mistakes in commit messages can easily occur, especially when using the CLI with `git commit -m`.  

This tool aims to be quick and easy to set up, while also being lightweight. It automatically checks for spelling errors
in commit message and provides an option to interactively fix them without rewriting the entire message.
## How To Use

1. Install from PyPi: 
    ```bash
    pip install git-spellcheck
    ```
2. Either setup:

    **Global installation** for all repositories:
    
    ```bash
    git-spellcheck --install-global
    ```
    
    OR **local installation** only for current repository
    ```bash
    git-spellcheck --install-local
    ```

3. Commit as usual 
    ```bash
   git commit -m "Fix autentcation bug in login modul"
   ```
   If spelling mistakes are found, you'll see:
    ```
    Git Spellcheck Warning:
    - "autentcation" (suggestions: authentication)
    - "modul" (suggestions: module, moduli, model, mosul, mogul, modal)
   Run `git-spellcheck --fix` to amend.```
   
4. Fix last commit interactively
    ```bash
    git-spellcheck --fix
   ```
   Interactive mode lets you:
   - See spelling suggestions 
   - Enter replacements 
   - Automatically amend your last commit
   
   ```
       - "autentcation"
       suggestions: authentication
       Enter replacement (or press ENTER to skip):
    ```
5. The commit is now ready to be pushed.
   

## Behavior

When a commit is made, the subject line is scanned for misspelled words using `pyspellchecker`. If issues are found, suggestions are displayed.

The interactive mode allows reviewing each misspelled word and optionally replacing it, automatically amending the last commit with the corrected message.

Adding `[skip-spell]` to a commit message bypasses the spellcheck. The flag is automatically removed before finalising 
the commit.

## Requirements

- Python 3.7 or higher  
- Git
