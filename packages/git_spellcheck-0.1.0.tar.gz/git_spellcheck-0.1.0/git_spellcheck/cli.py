#!/usr/bin/env python3
import sys
import re
import platform
import subprocess
import os
from pathlib import Path
from spellchecker import SpellChecker

BYPASS_FLAG = "[skip-spell]"


def run_commit_msg_hook(commit_msg_file: str):
    spell = SpellChecker()
    commit_msg_path = Path(commit_msg_file)

    message = commit_msg_path.read_text(encoding="utf-8")

    if BYPASS_FLAG in message:
        cleaned = message.replace(BYPASS_FLAG, "").strip()
        commit_msg_path.write_text(cleaned, encoding="utf-8")
        return 0

    subject = message.split("\n")[0]
    words = re.findall(r"\b[a-zA-Z']+\b", subject)
    misspelled = list(spell.unknown(words))

    if not misspelled:
        return 0

    print("\nGit Spellcheck Warning:")
    for word in misspelled:
        candidates = spell.candidates(word)
        suggestions = list(candidates)[:6] if candidates else []
        if suggestions:
            print(f'  - "{word}" (suggestions: {", ".join(suggestions)})')
        else:
            print(f'  - "{word}" has no suggestions')

    print("Run `git-spellcheck --fix` to amend.\n")

    return 0


def fix_last_commit():
    spell = SpellChecker()

    result = subprocess.run(
        ["git", "log", "-1", "--pretty=%B"],
        capture_output=True,
        text=True
    )

    print("""---------------------------------
Git Spellcheck - Interactive Mode
---------------------------------""")
    print()

    if result.returncode != 0:
        print("Failed to retrieve last commit message. Exiting Git Spellcheck.")
        return 1

    message = result.stdout
    lines = message.split("\n")
    subject = lines[0]

    words = re.findall(r"\b[a-zA-Z']+\b", subject)
    misspelled = list(spell.unknown(words))

    if not misspelled:
        print("No spelling issues found. Exiting Git Spellcheck.")
        return 0

    updated_subject = subject

    for word in misspelled:
        print("-" * 20)
        print(f'  - "{word}"')
        candidates = spell.candidates(word)
        suggestions = list(candidates)[:6] if candidates else []

        if suggestions:
            print(f"    suggestions: {', '.join(suggestions)}")
        else:
            print("    no suggestions")

        replacement = input("Enter replacement (or press ENTER to skip): ").strip()
        print("-" * 20)
        print()

        if replacement:
            def replace_match(match):
                original = match.group(0)

                if original.isupper():
                    return replacement.upper()
                elif original[0].isupper():
                    return replacement.capitalize()
                else:
                    return replacement

            updated_subject = re.sub(
                rf"\b{re.escape(word)}\b",
                replace_match,
                updated_subject,
                flags=re.IGNORECASE
            )

    if updated_subject == subject:
        print("No changes made.")
        return 0

    lines[0] = updated_subject
    new_message = "\n".join(lines)

    subprocess.run(["git", "commit", "--amend", "-m", new_message])
    return 0


def install_hook(global_install=False):
    if platform.system() == "Windows":
        hooks_path = Path(os.environ["USERPROFILE"]) / ".git-hooks"
    else:
        hooks_path = Path.home() / ".git-hooks"

    if global_install:
        hooks_path.mkdir(exist_ok=True)
        hook_file = hooks_path / "commit-msg"
        hook_file.write_text("""#!/bin/sh
git-spellcheck "$1"
""")
        hook_file.chmod(0o755)
        subprocess.run(["git", "config", "--global", "core.hooksPath", str(hooks_path)])
        print(f"Global commit-msg hook installed in {hooks_path}")
    else:
        repo_hooks = Path(".git/hooks")
        if not repo_hooks.exists():
            print("Not a git repository.")
            return
        repo_hooks.mkdir(exist_ok=True)
        hook_file = repo_hooks / "commit-msg"
        hook_file.write_text("""#!/bin/sh
git-spellcheck "$1"
""")
        hook_file.chmod(0o755)
        print(f"commit-msg hook installed in {repo_hooks}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Interactive Git commit message spellchecker")
    parser.add_argument("commit_msg_file", nargs="?", help=argparse.SUPPRESS)
    parser.add_argument("--install-global", action="store_true", help="Install commit-msg hook globally")
    parser.add_argument("--install-local", action="store_true", help="Install commit-msg hook locally in current repo")
    parser.add_argument("--fix", action="store_true", help="Interactively fix last commit")
    args = parser.parse_args()

    if args.install_global:
        install_hook(global_install=True)
    elif args.install_local:
        install_hook(global_install=False)
    elif args.commit_msg_file:
        sys.exit(run_commit_msg_hook(args.commit_msg_file))
    elif args.fix:
        sys.exit(fix_last_commit())
    else:
        parser.print_help()
        sys.exit(1)
