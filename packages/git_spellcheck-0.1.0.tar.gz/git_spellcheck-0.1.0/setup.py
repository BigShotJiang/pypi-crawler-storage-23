from setuptools import setup, find_packages

setup(
    name="git-spellcheck",
    version="0.1.0",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "pyspellchecker>=0.7.0"
    ],
    entry_points={
        "console_scripts": [
            "git-spellcheck=git_spellcheck.cli:main"
        ]
    },
    python_requires=">=3.7",
    description="Interactive Git commit message spellchecker",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Asad Khalid",
    url="https://github.com/Asad-K2025/git-spellcheck",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
