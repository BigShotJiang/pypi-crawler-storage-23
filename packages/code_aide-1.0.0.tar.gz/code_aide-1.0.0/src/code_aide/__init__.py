"""code-aide - Manage AI coding CLI tools."""

__version__ = "1.0.0"
