"""Benchmark package for Palfrey performance comparisons."""
