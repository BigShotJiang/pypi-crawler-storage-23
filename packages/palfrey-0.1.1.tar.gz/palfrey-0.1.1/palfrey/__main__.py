"""Command-line module entrypoint for Palfrey."""

from palfrey.cli import main

if __name__ == "__main__":
    main()
