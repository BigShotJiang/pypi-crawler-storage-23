# Watch the current directory for Python changes.
# palfrey myapp.main:app --reload

# Watch selected paths and patterns.
# palfrey myapp.main:app --reload --reload-dir src --reload-include '*.py' --reload-exclude 'tests/*'
