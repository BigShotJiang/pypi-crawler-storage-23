# Serve HTTPS traffic directly from Palfrey.
# palfrey myapp.main:app --ssl-keyfile ./key.pem --ssl-certfile ./cert.pem

# Client certificate verification.
# palfrey myapp.main:app --ssl-keyfile ./key.pem --ssl-certfile ./cert.pem --ssl-ca-certs ./ca.pem --ssl-cert-reqs 2
