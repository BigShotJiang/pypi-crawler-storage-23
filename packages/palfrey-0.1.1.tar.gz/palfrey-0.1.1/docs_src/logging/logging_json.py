# Run with a JSON logging config file.
# palfrey myapp.main:app --log-config ./logging.json --log-level info
