from does_not_exist import foo  # noqa: F401

myattr = object()
