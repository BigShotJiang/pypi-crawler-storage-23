from tests.importer.circular_import_a import bar  # noqa: F401
