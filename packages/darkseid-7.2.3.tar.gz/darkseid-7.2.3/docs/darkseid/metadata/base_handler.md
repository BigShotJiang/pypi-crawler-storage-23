:::darkseid.metadata.base_handler.XmlError
:::darkseid.metadata.base_handler.BaseMetadataHandler
