:::darkseid.issue_string.IssueString
