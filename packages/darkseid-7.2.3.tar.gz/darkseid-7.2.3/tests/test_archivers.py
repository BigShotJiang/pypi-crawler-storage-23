# test_archivers.py
# ruff: noqa: ARG001, ARG002, PLR0913
"""Comprehensive tests for archiver modules using pytest parametrization."""

import io
import tarfile
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import Mock, patch

import pytest
import rarfile
from py7zr import py7zr

from darkseid.archivers import (
    ArchiverFactory,
    RarArchiver,
    SevenZipArchiver,
    TarArchiver,
    UnknownArchiver,
    ZipArchiver,
)
from darkseid.archivers.archiver import Archiver, ArchiverReadError
from darkseid.archivers.pdf import PYMUPDF_AVAILABLE

if PYMUPDF_AVAILABLE:
    import pymupdf

    from darkseid.archivers import PdfArchiver


# Test data and fixtures
@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        yield Path(tmp_dir)


@pytest.fixture
def sample_seven_zip_path(temp_dir):
    seven_zip_path = temp_dir / "test.cb7"
    with py7zr.SevenZipFile(seven_zip_path, "w") as zf:
        zf.writestr("content1", "file1.txt")
        zf.writestr(b"fake_image_data", "file2.jpg")
        zf.writestr("content3", "dir/file3.txt")
    return seven_zip_path


@pytest.fixture
def sample_tar_path(temp_dir):
    """Create a sample TAR file for testing."""
    tar_path = temp_dir / "test.cbt"
    with tarfile.open(tar_path, "w") as tf:
        # File 1
        tarinfo_1 = tarfile.TarInfo(name="file1.txt")
        content = b"content1"
        tarinfo_1.size = len(content)
        tf.addfile(tarinfo_1, io.BytesIO(content))
        # File 2
        tarinfo_2 = tarfile.TarInfo(name="file2.jpg")
        content2 = b"fake_image_data"
        tarinfo_2.size = len(content2)
        tf.addfile(tarinfo_2, io.BytesIO(content2))
        # File 3
        tarinfo_3 = tarfile.TarInfo(name="dir/file3.txt")
        content3 = b"content3"
        tarinfo_3.size = len(content3)
        tf.addfile(tarinfo_3, io.BytesIO(content3))
    return tar_path


@pytest.fixture
def sample_zip_path(temp_dir):
    """Create a sample ZIP file for testing."""
    zip_path = temp_dir / "test.cbz"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("file1.txt", "content1")
        zf.writestr("file2.jpg", b"fake_image_data")
        zf.writestr("dir/file3.txt", "content3")
    return zip_path


@pytest.fixture
def empty_zip_path(temp_dir):
    """Create an empty ZIP file for testing."""
    zip_path = temp_dir / "empty.cbz"
    with zipfile.ZipFile(zip_path, "w") as _:
        pass
    return zip_path


@pytest.fixture
def sample_rar_path(temp_dir):
    """Create a mock RAR file path."""
    return temp_dir / "test.rar"


@pytest.fixture
def sample_pdf_path(temp_dir):
    """Create a sample PDF file for testing."""
    if not PYMUPDF_AVAILABLE:
        pytest.skip("pymupdf not available")

    pdf_path = temp_dir / "test.pdf"
    doc = pymupdf.open()  # Create new PDF

    # Add 3 pages with some content
    for i in range(3):
        page = doc.new_page(width=595, height=842)  # A4 size
        # Add some text to make the pages different
        page.insert_text((100, 100), f"Page {i + 1}", fontsize=20)

    doc.save(pdf_path)
    doc.close()
    return pdf_path


@pytest.fixture
def nonexistent_path(temp_dir):
    """Return path to a nonexistent file."""
    return temp_dir / "nonexistent.cbz"


# Test data for parametrized tests
ARCHIVE_TEST_DATA = [
    ("zip", ZipArchiver, "test.cbz"),
    ("tar", TarArchiver, "test.cbt"),
    ("seven_zip", SevenZipArchiver, "test.cb7"),
]

FACTORY_EXTENSION_DATA = [
    (".cbz", ZipArchiver),
    (".cbr", RarArchiver),
    (".cbt", TarArchiver),
    (".xyz", UnknownArchiver),
    (".cb7", SevenZipArchiver),
]

READ_WRITE_ARCHIVE_DATA = [
    ("zip", ZipArchiver, "test.cbz"),
    ("tar", TarArchiver, "test.cbt"),
    ("seven_zip", SevenZipArchiver, "test.cb7"),
]

FILE_TEST_DATA = [
    ("file1.txt", b"content1"),
    ("file2.jpg", b"fake_image_data"),
    ("dir/file3.txt", b"content3"),
]


# Base Archiver Tests
def test_archiver_is_abstract():
    """Test that Archiver cannot be instantiated directly."""
    with pytest.raises(TypeError):
        Archiver(Path("test.cbz"))


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_archiver_path_property(temp_dir, archive_type, archiver_class, filename):
    """Test that archiver path property works correctly."""
    path = temp_dir / filename
    archiver = archiver_class(path)
    assert archiver.path == path


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_archiver_context_manager(temp_dir, archive_type, archiver_class, filename):
    """Test that archiver works as context manager."""
    path = temp_dir / filename
    with archiver_class(path) as archiver:
        assert isinstance(archiver, archiver_class)
        assert archiver.path == path


# Parametrized tests for common archive operations
@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_archiver_init(temp_dir, archive_type, archiver_class, filename):
    """Test archiver initialization."""
    path = temp_dir / filename
    archiver = archiver_class(path)
    assert archiver.path == path


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_archiver_init_nonexistent_file(temp_dir, archive_type, archiver_class, filename):
    """Test archiver initialization with nonexistent file."""
    path = temp_dir / f"nonexistent_{filename}"
    archiver = archiver_class(path)
    assert archiver.path == path


@pytest.mark.parametrize(("test_file", "expected_content"), FILE_TEST_DATA)
def test_zip_read_file_success(sample_zip_path, test_file, expected_content):
    """Test reading existing files from ZIP archive."""
    archiver = ZipArchiver(sample_zip_path)
    content = archiver.read_file(test_file)
    assert content == expected_content


@pytest.mark.parametrize(("test_file", "expected_content"), FILE_TEST_DATA)
def test_tar_read_file_success(sample_tar_path, test_file, expected_content):
    """Test reading existing files from TAR archive."""
    archiver = TarArchiver(sample_tar_path)
    content = archiver.read_file(test_file)
    assert content == expected_content


@pytest.mark.parametrize(("test_file", "expected_content"), FILE_TEST_DATA)
def test_seven_zip_read_file_success(sample_seven_zip_path, test_file, expected_content):
    """Test reading existing files from SEVENZIP archive."""
    archiver = SevenZipArchiver(sample_seven_zip_path)
    content = archiver.read_file(test_file)
    assert content == expected_content


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_read_nonexistent_file(temp_dir, archive_type, archiver_class, filename, request):
    """Test reading nonexistent file raises ArchiverReadError."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)
    with pytest.raises(ArchiverReadError, match="File not found in archive"):
        archiver.read_file("nonexistent.txt")


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
@pytest.mark.parametrize(
    ("test_data", "expected_content"),
    [
        ("hello world", b"hello world"),
        (b"binary data", b"binary data"),
    ],
)
def test_write_file(temp_dir, archive_type, archiver_class, filename, test_data, expected_content):
    """Test writing data to archives."""
    path = temp_dir / f"write_test_{filename}"
    archiver = archiver_class(path)

    result = archiver.write_file("test.txt", test_data)
    assert result is True

    # Verify file was written
    content = archiver.read_file("test.txt")
    assert content == expected_content

    # Verify 7zip is valid
    if archive_type == "seven_zip":
        assert archiver.test() is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
def test_write_file_overwrite_existing(temp_dir, archive_type, archiver_class, filename, request):
    """Test overwriting existing file in archives."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)

    # Overwrite existing file
    result = archiver.write_file("file1.txt", "new content")
    assert result is True

    # Verify content was updated
    content = archiver.read_file("file1.txt")
    assert content == b"new content"

    # Verify existing data is *still* present
    existing = archiver.read_file("dir/file3.txt")
    assert existing == b"content3"

    # Verify 7zip is valid
    if archive_type == "seven_zip":
        assert archiver.test() is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
def test_remove_file_success(temp_dir, archive_type, archiver_class, filename, request):
    """Test removing existing file from archives."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)

    # Verify file exists first
    assert "file1.txt" in archiver.get_filename_list()

    # Remove file
    result = archiver.remove_files(["file1.txt"])
    assert result is True

    # Verify file is gone
    assert "file1.txt" not in archiver.get_filename_list()

    # Verify 7zip is valid
    if archive_type == "seven_zip":
        assert archiver.test() is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
def test_remove_nonexistent_file(temp_dir, archive_type, archiver_class, filename, request):
    """Test removing nonexistent file returns False."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        # Fake this test for now
        return
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)
    result = archiver.remove_files(["nonexistent.txt"])
    assert result is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
def test_remove_multiple_files(temp_dir, archive_type, archiver_class, filename, request):
    """Test removing multiple files from archives."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)

    files_to_remove = ["file1.txt", "file2.jpg"]
    result = archiver.remove_files(files_to_remove)
    assert result is True

    # Verify files are gone
    remaining_files = archiver.get_filename_list()
    assert "file1.txt" not in remaining_files
    assert "file2.jpg" not in remaining_files
    assert "dir/file3.txt" in remaining_files  # Should still exist

    # Verify 7zip is valid
    if archive_type == "seven_zip":
        assert archiver.test() is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
@pytest.mark.parametrize(
    "files_to_remove",
    [
        [],
        ["nonexistent1.txt", "nonexistent2.txt"],
    ],
)
def test_remove_files_edge_cases(
    temp_dir, archive_type, archiver_class, filename, files_to_remove, request
):
    """Test removing files edge cases."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)
    result = archiver.remove_files(files_to_remove)
    assert result is True


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_get_filename_list(temp_dir, archive_type, archiver_class, filename, request):
    """Test getting list of files in archives."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)
    files = archiver.get_filename_list()

    expected_files = ["file1.txt", "file2.jpg", "dir/file3.txt"]
    assert set(files) == set(expected_files)


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
@pytest.mark.parametrize(
    ("test_file", "expected_exists"),
    [
        ("file1.txt", True),
        ("nonexistent.txt", False),
    ],
)
def test_exists_file(
    temp_dir, archive_type, archiver_class, filename, test_file, expected_exists, request
):
    """Test checking if file exists in archives."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    archiver = archiver_class(archive_path)
    assert archiver.exists(test_file) is expected_exists


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), READ_WRITE_ARCHIVE_DATA)
def test_copy_from_archive(temp_dir, archive_type, archiver_class, filename, request):
    """Test copying from one archive to another."""
    if archive_type == "zip":
        source_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        source_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        source_path = request.getfixturevalue("sample_tar_path")

    dest_path = temp_dir / f"destination_{filename}"
    source_archiver = archiver_class(source_path)
    dest_archiver = archiver_class(dest_path)

    result = dest_archiver.copy_from_archive(source_archiver)
    if archive_type == "seven_zip":
        assert result is False
    else:
        assert result is True

    # Verify all files were copied
    if archive_type != "seven_zip":
        dest_files = dest_archiver.get_filename_list()
        source_files = source_archiver.get_filename_list()
        assert set(dest_files) == set(source_files)

        # Verify content is the same
        for file in source_files:
            source_content = source_archiver.read_file(file)
            dest_content = dest_archiver.read_file(file)
            assert source_content == dest_content


# Specific ZIP tests
def test_zip_read_corrupted_archive(temp_dir):
    """Test reading from corrupted ZIP file raises ArchiverReadError."""
    corrupted_path = temp_dir / "corrupted.cbz"
    corrupted_path.write_text("not a zip file")

    archiver = ZipArchiver(corrupted_path)
    with pytest.raises(ArchiverReadError, match="Corrupt ZIP file"):
        archiver.read_file("any_file.txt")


def test_zip_write_file_image_compression(temp_dir):
    """Test that image files use stored compression."""
    zip_path = temp_dir / "compression_test.cbz"
    archiver = ZipArchiver(zip_path)

    # Write image file (should use ZIP_STORED)
    result = archiver.write_file("image.jpg", b"fake_image_data")
    assert result is True

    # Write text file (should use ZIP_DEFLATED)
    result = archiver.write_file("text.txt", "text content")
    assert result is True


def test_zip_get_filename_list_empty(empty_zip_path):
    """Test getting filename list from empty ZIP archive."""
    archiver = ZipArchiver(empty_zip_path)
    files = archiver.get_filename_list()
    assert files == []


def test_zip_get_filename_list_corrupted(temp_dir):
    """Test getting filename list from corrupted ZIP returns empty list."""
    corrupted_path = temp_dir / "corrupted.cbz"
    corrupted_path.write_text("not a zip file")

    archiver = ZipArchiver(corrupted_path)
    files = archiver.get_filename_list()
    assert files == []


# Specific 7ZIP tests
def test_seven_zip_test(sample_seven_zip_path):
    """Test SevenZipArchiver .test() method."""
    archive = SevenZipArchiver(sample_seven_zip_path)
    assert archive.test() is True


# Specific TAR tests
def test_tar_get_filename_list_corrupted(temp_dir):
    """Test getting filename list from corrupted TAR returns empty list."""
    corrupted_path = temp_dir / "corrupted.cbt"
    corrupted_path.write_text("not a cbt file")

    archiver = TarArchiver(corrupted_path)
    files = archiver.get_filename_list()
    assert files == []


def test_tar_test(sample_tar_path):
    """Test TarArchive .test() method."""
    archive = TarArchiver(sample_tar_path)
    assert archive.test() is True


# RAR Archiver Tests (with mocking)
@pytest.mark.parametrize(
    ("test_file", "expected_content"),
    [
        ("test.txt", b"rar content"),
        ("file1.txt", b"rar file1"),
    ],
)
@patch("rarfile.RarFile")
def test_rar_read_file_success(mock_rar_file, sample_rar_path, test_file, expected_content):
    """Test reading files from RAR archive."""
    mock_rf = Mock()
    mock_rf.read.return_value = expected_content
    mock_rar_file.return_value.__enter__.return_value = mock_rf

    archiver = RarArchiver(sample_rar_path)
    content = archiver.read_file(test_file)

    assert content == expected_content
    mock_rf.read.assert_called_once_with(test_file)


@pytest.mark.parametrize(
    ("exception_class", "exception_msg", "expected_error"),
    [
        (rarfile.RarCannotExec, "Cannot execute", "Cannot execute RAR command"),
        (rarfile.BadRarFile, "Bad RAR file", "Corrupt RAR file"),
    ],
)
@patch("rarfile.RarFile")
def test_rar_read_file_errors(
    mock_rar_file, sample_rar_path, exception_class, exception_msg, expected_error
):
    """Test RAR read errors."""
    mock_rar_file.side_effect = exception_class(exception_msg)

    archiver = RarArchiver(sample_rar_path)
    with pytest.raises(ArchiverReadError, match=expected_error):
        archiver.read_file("test.txt")


@patch("rarfile.RarFile")
def test_rar_read_file_not_found(mock_rar_file, sample_rar_path):
    """Test RAR read error when file not found."""
    mock_rf = Mock()
    mock_rf.read.side_effect = KeyError("File not found")
    mock_rar_file.return_value.__enter__.return_value = mock_rf

    archiver = RarArchiver(sample_rar_path)
    with pytest.raises(ArchiverReadError, match="File not found in archive"):
        archiver.read_file("nonexistent.txt")


@patch("rarfile.RarFile")
def test_rar_read_file_unsupported_operation(mock_rar_file, sample_rar_path):
    """Test RAR read handles UnsupportedOperation (empty directories)."""
    mock_rf = Mock()
    mock_rf.read.side_effect = io.UnsupportedOperation("Unsupported")
    mock_rar_file.return_value.__enter__.return_value = mock_rf

    archiver = RarArchiver(sample_rar_path)
    content = archiver.read_file("empty_dir/")

    assert content == b""


@pytest.mark.parametrize(
    "operation",
    [
        "write_file",
        "remove_file",
        "remove_files",
        "copy_from_archive",
    ],
)
def test_rar_readonly_operations(sample_rar_path, operation):
    """Test that RAR operations return False (read-only)."""
    archiver = RarArchiver(sample_rar_path)

    # init value
    result = True

    if operation == "write_file":
        result = archiver.write_file("test.txt", "data")
    elif operation == "remove_file":
        result = archiver.remove_files(["test.txt"])
    elif operation == "remove_files":
        result = archiver.remove_files(["file1.txt", "file2.txt"])
    elif operation == "copy_from_archive":
        result = archiver.copy_from_archive(Mock())

    assert result is False


@patch("rarfile.RarFile")
def test_rar_get_filename_list(mock_rar_file, sample_rar_path):
    """Test getting filename list from RAR archive."""
    mock_rf = Mock()
    mock_rf.namelist.return_value = ["file2.txt", "file1.txt", "dir/file3.txt"]
    mock_rar_file.return_value.__enter__.return_value = mock_rf

    archiver = RarArchiver(sample_rar_path)
    files = archiver.get_filename_list()

    # Should be sorted
    expected = ["dir/file3.txt", "file1.txt", "file2.txt"]
    assert files == expected


@patch("rarfile.RarFile")
def test_rar_get_filename_list_error(mock_rar_file, sample_rar_path):
    """Test RAR filename list error handling."""
    mock_rar_file.side_effect = rarfile.BadRarFile("Bad RAR")

    archiver = RarArchiver(sample_rar_path)
    with pytest.raises(ArchiverReadError, match="Cannot read RAR archive"):
        archiver.get_filename_list()


# UnknownArchiver Tests
@pytest.mark.parametrize(
    ("operation", "args", "expected_result"),
    [
        ("name", [], "Unknown"),
        ("write_file", ["test.txt", "data"], False),
        ("remove_files", [["file1.txt", "file2.txt"]], False),
        ("get_filename_list", [], []),
        ("copy_from_archive", [Mock()], False),
    ],
)
def test_unknown_archiver_operations(temp_dir, operation, args, expected_result):
    """Test UnknownArchiver operations."""
    path = temp_dir / "unknown.xyz"
    archiver = UnknownArchiver(path)

    result = archiver.name() if operation == "name" else getattr(archiver, operation)(*args)

    assert result == expected_result


def test_unknown_archiver_read_file_not_implemented(temp_dir):
    """Test UnknownArchiver read_file raises NotImplementedError."""
    path = temp_dir / "unknown.xyz"
    archiver = UnknownArchiver(path)
    with pytest.raises(NotImplementedError):
        archiver.read_file("test.txt")


# ArchiverFactory Tests
@pytest.mark.parametrize(("extension", "expected_class"), FACTORY_EXTENSION_DATA)
def test_factory_create_archiver(temp_dir, extension, expected_class):
    """Test factory creates correct archiver for extensions."""
    path = temp_dir / f"test{extension}"
    if extension == ".cb7":
        ArchiverFactory.register_archiver(".cb7", SevenZipArchiver)
    archiver = ArchiverFactory.create_archiver(path)
    assert isinstance(archiver, expected_class)
    assert archiver.path == path


@pytest.mark.parametrize("extension", [".CBZ", ".CBR"])
def test_factory_case_insensitive(temp_dir, extension):
    """Test factory is case-insensitive for extensions."""
    path = temp_dir / f"test{extension}"
    archiver = ArchiverFactory.create_archiver(path)
    assert not isinstance(archiver, UnknownArchiver)


def test_factory_register_new_archiver(temp_dir):
    """Test registering new archiver type with factory."""

    class MockArchiver(Archiver):
        def read_file(self, archive_file: str) -> bytes:
            return b"mock"

        def write_file(self, archive_file: str, data) -> bool:
            return True

        def remove_files(self, filename_list: list[str]) -> bool:
            return True

        def get_filename_list(self) -> list[str]:
            return []

        def test(self) -> bool:
            return True

        def copy_from_archive(self, other_archive: Archiver) -> bool:
            return True

    # Register new archiver
    ArchiverFactory.register_archiver(".mock", MockArchiver)

    # Test it works
    mock_path = temp_dir / "test.mock"
    archiver = ArchiverFactory.create_archiver(mock_path)
    assert isinstance(archiver, MockArchiver)


def test_factory_get_supported_extensions():
    """Test getting list of supported extensions."""
    extensions = ArchiverFactory.get_supported_extensions()
    expected_extensions = [".cbz", ".cbr"]

    for ext in expected_extensions:
        assert ext in extensions


# Integration Tests
def test_zip_to_zip_copy_integration(temp_dir):
    """Integration test: copy from one ZIP to another."""
    # Create source ZIP
    source_path = temp_dir / "source.cbz"
    with zipfile.ZipFile(source_path, "w") as zf:
        zf.writestr("file1.txt", "content1")
        zf.writestr("file2.txt", "content2")

    # Create destination archiver
    dest_path = temp_dir / "dest.cbz"
    source_archiver = ZipArchiver(source_path)
    dest_archiver = ZipArchiver(dest_path)

    # Copy files
    result = dest_archiver.copy_from_archive(source_archiver)
    assert result is True

    # Verify copy
    assert dest_archiver.exists("file1.txt")
    assert dest_archiver.exists("file2.txt")
    assert dest_archiver.read_file("file1.txt") == b"content1"
    assert dest_archiver.read_file("file2.txt") == b"content2"


def test_factory_integration(temp_dir):
    """Integration test: use factory to create and operate on archives."""
    # Create test ZIP
    zip_path = temp_dir / "test.cbz"
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("test.txt", "factory test")

    # Use factory to create archiver
    archiver = ArchiverFactory.create_archiver(zip_path)

    # Perform operations
    assert archiver.exists("test.txt")
    content = archiver.read_file("test.txt")
    assert content == b"factory test"

    # Add new file
    result = archiver.write_file("new.txt", "new content")
    assert result is True
    assert archiver.exists("new.txt")


@pytest.mark.parametrize(("archive_type", "archiver_class", "filename"), ARCHIVE_TEST_DATA)
def test_context_manager_integration(temp_dir, archive_type, archiver_class, filename, request):
    """Integration test: use archiver as context manager."""
    if archive_type == "zip":
        archive_path = request.getfixturevalue("sample_zip_path")
    elif archive_type == "seven_zip":
        archive_path = request.getfixturevalue("sample_seven_zip_path")
    else:
        archive_path = request.getfixturevalue("sample_tar_path")

    with archiver_class(archive_path) as archiver:
        files = archiver.get_filename_list()
        assert len(files) > 0

        content = archiver.read_file(files[0])
        assert isinstance(content, bytes)
        assert len(content) > 0


# Edge Cases and Error Conditions
def test_zip_write_to_readonly_file(temp_dir):
    """Test writing to read-only ZIP file."""
    zip_path = temp_dir / "readonly.cbz"
    zip_path.touch()
    zip_path.chmod(0o444)  # Read-only

    archiver = ZipArchiver(zip_path)
    result = archiver.write_file("test.txt", "data")
    # Should handle permission error gracefully
    assert result is False


def test_zip_large_file_handling(temp_dir):
    """Test handling large files in ZIP archives."""
    zip_path = temp_dir / "large.cbz"
    archiver = ZipArchiver(zip_path)

    # Create large content (1MB)
    large_content = "x" * (1024 * 1024)
    result = archiver.write_file("large.txt", large_content)
    assert result is True

    # Read it back
    content = archiver.read_file("large.txt")
    assert content == large_content.encode("utf-8")


@pytest.mark.parametrize(
    ("filename", "content"),
    [
        ("тест_файл.txt", "unicode content"),  # Russian text
        ("файл_тест.txt", "more unicode"),  # More Russian text
    ],
)
def test_archiver_with_unicode_filenames(temp_dir, filename, content):
    """Test handling Unicode filenames in archives."""
    zip_path = temp_dir / "unicode.cbz"
    archiver = ZipArchiver(zip_path)

    result = archiver.write_file(filename, content)
    assert result is True

    assert archiver.exists(filename)
    read_content = archiver.read_file(filename)
    assert read_content == content.encode("utf-8")


@pytest.mark.parametrize(
    ("data_type", "data", "expected"),
    [
        ("empty_string", "", b""),
        ("empty_bytes", b"", b""),
    ],
)
def test_archiver_empty_data_handling(temp_dir, data_type, data, expected):
    """Test handling empty data in archives."""
    zip_path = temp_dir / "empty_data.cbz"
    archiver = ZipArchiver(zip_path)

    filename = f"empty_{data_type}.txt"
    result = archiver.write_file(filename, data)
    assert result is True

    content = archiver.read_file(filename)
    assert content == expected


# PDF Archiver Tests
@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_get_filename_list(sample_pdf_path):
    """Test getting filename list from PDF returns page filenames."""
    archiver = PdfArchiver(sample_pdf_path)
    files = archiver.get_filename_list()

    # Should return 3 pages with zero-padded names
    expected = ["page_001.png", "page_002.png", "page_003.png"]
    assert files == expected


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
@pytest.mark.parametrize(
    ("page_file", "page_index"),
    [
        ("page_001.png", 0),
        ("page_002.png", 1),
        ("page_003.png", 2),
    ],
)
def test_pdf_read_page_success(sample_pdf_path, page_file, page_index):
    """Test reading pages from PDF as PNG images."""
    archiver = PdfArchiver(sample_pdf_path)
    content = archiver.read_file(page_file)

    # Verify we got PNG data
    assert content.startswith(b"\x89PNG")  # PNG magic bytes
    assert len(content) > 0


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_read_invalid_page_format(sample_pdf_path):
    """Test reading with invalid filenames raises appropriate errors."""
    archiver = PdfArchiver(sample_pdf_path)

    # Files not matching page pattern are treated as embedded files
    with pytest.raises(ArchiverReadError, match="Embedded file not found"):
        archiver.read_file("invalid.png")

    with pytest.raises(ArchiverReadError, match="Embedded file not found"):
        archiver.read_file("page_001.jpg")

    # Invalid page number in page pattern raises format error
    with pytest.raises(ArchiverReadError, match="Invalid page filename format"):
        archiver.read_file("page_abc.png")


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_read_page_out_of_range(sample_pdf_path):
    """Test reading non-existent page raises error."""
    archiver = PdfArchiver(sample_pdf_path)

    with pytest.raises(ArchiverReadError, match="Page 999 not found"):
        archiver.read_file("page_999.png")


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_read_invalid_page_number(sample_pdf_path):
    """Test reading with invalid page numbers raises error."""
    archiver = PdfArchiver(sample_pdf_path)

    with pytest.raises(ArchiverReadError, match="Invalid page number"):
        archiver.read_file("page_000.png")


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
@pytest.mark.parametrize(
    "operation",
    [
        "write_file",
        "remove_files",
        "copy_from_archive",
    ],
)
def test_pdf_readonly_operations(sample_pdf_path, operation):
    """Test that PDF page operations are blocked but metadata operations work."""
    archiver = PdfArchiver(sample_pdf_path)

    result = None

    if operation == "write_file":
        # Page files should fail
        result = archiver.write_file("page_001.png", b"data")
        assert result is False, "Writing to page files should fail"
        # But metadata files should succeed
        result = archiver.write_file("ComicInfo.xml", b"<ComicInfo/>")
        assert result is True, "Writing metadata files should succeed"
    elif operation == "remove_files":
        # Page files should be protected (returns True but doesn't remove)
        result = archiver.remove_files(["page_001.png"])
        assert result is True, "Remove returns True even for page files"
        assert "page_001.png" in archiver.get_filename_list(), "Page should still exist"
    elif operation == "copy_from_archive":
        # copy_from_archive is not supported for PDFs
        result = archiver.copy_from_archive(Mock())
        assert result is False, "copy_from_archive should fail"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_is_write_operation_expected(sample_pdf_path):
    """Test that PDF archiver supports write operations for metadata."""
    archiver = PdfArchiver(sample_pdf_path)
    assert archiver.is_write_operation_expected() is True


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_test_valid(sample_pdf_path):
    """Test that valid PDF returns True for test()."""
    archiver = PdfArchiver(sample_pdf_path)
    assert archiver.test() is True


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_test_invalid(temp_dir):
    """Test that invalid PDF returns False for test()."""
    invalid_pdf = temp_dir / "invalid.pdf"
    invalid_pdf.write_text("not a pdf")

    archiver = PdfArchiver(invalid_pdf)
    assert archiver.test() is False


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_write_metadata(sample_pdf_path):
    """Test writing metadata files to PDF."""
    archiver = PdfArchiver(sample_pdf_path)

    # Write ComicInfo.xml
    xml_data = b"<ComicInfo><Title>Test</Title></ComicInfo>"
    result = archiver.write_file("ComicInfo.xml", xml_data)
    assert result is True, "Writing ComicInfo.xml should succeed"

    # Verify it appears in file list
    files = archiver.get_filename_list()
    assert "ComicInfo.xml" in files, "ComicInfo.xml should be in file list"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_read_metadata(sample_pdf_path):
    """Test reading metadata files from PDF."""
    archiver = PdfArchiver(sample_pdf_path)

    # Write metadata
    xml_data = b"<ComicInfo><Title>Test Comic</Title></ComicInfo>"
    archiver.write_file("ComicInfo.xml", xml_data)

    # Read it back
    read_data = archiver.read_file("ComicInfo.xml")
    assert read_data == xml_data, "Read data should match written data"
    assert b"Test Comic" in read_data, "Should contain expected content"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_update_metadata(sample_pdf_path):
    """Test updating existing metadata in PDF."""
    archiver = PdfArchiver(sample_pdf_path)

    # Write initial metadata
    initial_data = b"<ComicInfo><Title>Original</Title></ComicInfo>"
    archiver.write_file("MetronInfo.xml", initial_data)

    # Update with new data
    updated_data = b"<ComicInfo><Title>Updated</Title></ComicInfo>"
    result = archiver.write_file("MetronInfo.xml", updated_data)
    assert result is True, "Update should succeed"

    # Verify updated content
    read_data = archiver.read_file("MetronInfo.xml")
    assert read_data == updated_data, "Should have updated data"
    assert b"Updated" in read_data, "Should contain new content"
    assert b"Original" not in read_data, "Should not contain old content"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_remove_metadata(sample_pdf_path):
    """Test removing metadata files from PDF."""
    archiver = PdfArchiver(sample_pdf_path)

    # Write metadata files
    archiver.write_file("ComicInfo.xml", b"<ComicInfo/>")
    archiver.write_file("MetronInfo.xml", b"<MetronInfo/>")

    # Verify both exist
    files = archiver.get_filename_list()
    assert "ComicInfo.xml" in files
    assert "MetronInfo.xml" in files

    # Remove one
    result = archiver.remove_files(["MetronInfo.xml"])
    assert result is True, "Remove should succeed"

    # Verify it's gone
    files = archiver.get_filename_list()
    assert "MetronInfo.xml" not in files, "MetronInfo.xml should be removed"
    assert "ComicInfo.xml" in files, "ComicInfo.xml should still exist"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_metadata_persistence(sample_pdf_path):
    """Test that metadata persists across archiver instances."""
    # Write metadata with first instance
    archiver1 = PdfArchiver(sample_pdf_path)
    xml_data = b"<ComicInfo><Title>Persistent</Title></ComicInfo>"
    archiver1.write_file("ComicInfo.xml", xml_data)

    # Create new instance and verify data persists
    archiver2 = PdfArchiver(sample_pdf_path)
    files = archiver2.get_filename_list()
    assert "ComicInfo.xml" in files, "Metadata should persist"

    read_data = archiver2.read_file("ComicInfo.xml")
    assert read_data == xml_data, "Data should be identical"


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_mixed_file_list(sample_pdf_path):
    """Test that file list includes both pages and metadata."""
    archiver = PdfArchiver(sample_pdf_path)

    # Get initial page count
    initial_files = archiver.get_filename_list()
    page_count = len(initial_files)

    # Add metadata
    archiver.write_file("ComicInfo.xml", b"<ComicInfo/>")
    archiver.write_file("MetronInfo.xml", b"<MetronInfo/>")

    # Verify file list includes both pages and metadata
    files = archiver.get_filename_list()
    assert len(files) == page_count + 2, "Should have pages + 2 metadata files"

    # Pages should come first
    for i in range(page_count):
        assert files[i].startswith("page_"), f"First {page_count} should be pages"

    # Metadata should be sorted alphabetically after pages
    metadata_files = files[page_count:]
    assert "ComicInfo.xml" in metadata_files
    assert "MetronInfo.xml" in metadata_files


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_context_manager(sample_pdf_path):
    """Test PDF archiver works as context manager."""
    with PdfArchiver(sample_pdf_path) as archiver:
        files = archiver.get_filename_list()
        assert len(files) == 3


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_factory_registration(temp_dir):
    """Test that factory creates PdfArchiver for .pdf extension."""
    pdf_path = temp_dir / "test.pdf"
    archiver = ArchiverFactory.create_archiver(pdf_path)
    assert isinstance(archiver, PdfArchiver)


@pytest.mark.skipif(not PYMUPDF_AVAILABLE, reason="pymupdf not installed")
def test_pdf_exists(sample_pdf_path):
    """Test checking if page exists in PDF."""
    archiver = PdfArchiver(sample_pdf_path)

    # Pages that exist
    assert archiver.exists("page_001.png") is True
    assert archiver.exists("page_002.png") is True
    assert archiver.exists("page_003.png") is True

    # Page that doesn't exist
    assert archiver.exists("page_999.png") is False
    assert archiver.exists("nonexistent.png") is False
