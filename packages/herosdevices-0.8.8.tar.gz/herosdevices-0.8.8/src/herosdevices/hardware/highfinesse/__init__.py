"""Device specific classes for device from Highfinesse."""

from .wsx import WSx

__all__ = ["WSx"]

__vendor_name__ = "HighFinesse GmbH"
