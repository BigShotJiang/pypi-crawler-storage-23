"""PowerPoint COM automation modules for ppt-com-mcp."""
