from .canvas2d.elements.dot import DotElement
from .canvas2d.surface import WorkSurface

__all__ = [
    "WorkSurface",
    "DotElement",
]
