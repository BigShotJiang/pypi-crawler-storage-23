"""Constants for Rayforge application."""

APP_NAME = "Rayforge"
MIME_TYPE_PROJECT = "application/x-rayforge-project"
MIME_TYPE_SKETCH = "application/x-rayforge-sketch"
