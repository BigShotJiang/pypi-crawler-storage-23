# Python SDK examples

Merged from `api/custom/python/examples/`. Set `FLEXPRICE_API_KEY` (and optionally `FLEXPRICE_API_HOST`). Install from parent: `pip install -e ..` (from api/python).

**Note:** These examples target an older OpenAPI-generated SDK. If the current SDK is Speakeasy-generated, update imports and API calls (e.g. to the new client and method names).
