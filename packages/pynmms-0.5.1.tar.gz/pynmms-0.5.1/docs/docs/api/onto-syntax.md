# Ontology Syntax

::: pynmms.onto.syntax
    options:
      members:
        - OntoSentence
        - parse_onto_sentence
        - is_onto_atomic
        - all_onto_atomic
        - make_concept_assertion
        - make_role_assertion
