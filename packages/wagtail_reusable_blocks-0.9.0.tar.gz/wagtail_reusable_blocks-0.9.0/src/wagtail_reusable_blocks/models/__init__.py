"""Models for wagtail-reusable-blocks."""

from .reusable_block import ReusableBlock

__all__ = ["ReusableBlock"]
