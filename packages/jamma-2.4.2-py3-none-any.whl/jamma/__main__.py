"""Enable ``python -m jamma`` execution."""

from jamma.cli import main

if __name__ == "__main__":
    main()
