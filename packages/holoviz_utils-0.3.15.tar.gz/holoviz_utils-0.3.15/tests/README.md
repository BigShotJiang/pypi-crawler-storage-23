# Tests

## Running Tests

### Standard Approach
```bash
pytest tests/
```

Tests are fully isolated at the instance level - each `DataPresentation` instance maintains its own parameter mapping independently.

### Alternative: Forked Execution
For maximum isolation, you can run tests in separate processes using pytest-xdist:

```bash
# Install pytest-xdist
pip install pytest-xdist

# Run tests with process isolation
pytest tests/ --forked
```

### Running Individual Tests
Each test can also be run independently:

```bash
pytest tests/test_dataviz.py::test_datapresentation_with_sine_wave
pytest tests/test_dataviz.py::test_datapresentation_parameter_defaults
pytest tests/test_dataviz.py::test_datapresentation_parameter_bounds
pytest tests/test_dataviz.py::test_datapresentation_empty
```

## Test Isolation

The `DataPresentation` class dynamically adds parameters and methods at the class level during initialization. This means modifications made in one test can affect subsequent tests running in the same Python process.

To handle this:

1. **Automatic cleanup fixture**: The `isolate_datapresentation` fixture in `test_dataviz.py` automatically cleans up class-level modifications after each test
2. **Process isolation**: Using `pytest --forked` runs each test in a separate process, providing complete isolation
3. **Individual execution**: Running tests one at a time naturally provides isolation

## Test Structure

- `test_dataviz.py`: Tests for the `DataPresentation` class
  - Test initialization with callback functions
  - Test parameter defaults
  - Test parameter bounds from type annotations
  - Test empty initialization
