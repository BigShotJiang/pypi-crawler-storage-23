# ISP Tools (`isptools`)

A fast, modern command-line utility for ISP Network Engineers.

## Installation

You can install this tool globally on your system using `pip`:

```bash
pip install isptools-cli
```

## Commands

Once installed, you can simply type `isptools` from anywhere in your terminal.

```bash
# Calculate subnet details
isptools subnet 192.168.1.0/24

# Look up a MAC address vendor
isptools mac D4:CA:6D:12:34:56

# Check your public IP and ISP info
isptools myip

# See all available commands
isptools --help
```
