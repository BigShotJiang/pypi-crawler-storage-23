# Change Log

## [1.12.1] - 25/02/2026

### Added
- Auto indentation.
- Token values ​​for types `NUMBER` and `STRING` in Lexer with `parser_flags=LEXER_HIGHLIGHT` produce a `tuple` object
  with the value or representation and a conversion function.
- The `NO_COLOR_PROMPT` and `NOTEBOOK` flags.
- The `sys.get_int_max_str_digits` function.
- _etc_.

### Fixed
- **Fixed some bugs**.
- Fixed some spelling errors.
- _etc._