"""Overwatch default policy template data files."""
