from .extension_importer import import_extension

__all__ = ["import_extension"]
