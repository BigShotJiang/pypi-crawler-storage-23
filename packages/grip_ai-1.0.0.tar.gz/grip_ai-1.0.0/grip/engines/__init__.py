"""Dual-engine system: Claude Agent SDK (primary) + LiteLLM (fallback)."""
