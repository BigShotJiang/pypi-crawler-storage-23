import backer.cli as cli

if __name__ == "__main__":
    raise SystemExit( cli.main() )