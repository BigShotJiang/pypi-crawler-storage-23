# Playlist2Podcast

[![Repo](https://img.shields.io/badge/repo-Codeberg.org-blue)](https://codeberg.org/pyyttools/playlist2podcasts "Repo at Codeberg")
[![CI - Woodpecker](https://ci.codeberg.org/api/badges/pyyttools/playlist2podcasts/status.svg)](https://ci.codeberg.org/pyyttools/playlist2podcasts "CI / Woodpecker")
[![Downloads](https://pepy.tech/badge/playlist2podcasts)](https://pepy.tech/project/playlist2podcasts "Download count")
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/playlist2podcasts)](https://pypi.org/project/playlist2podcasts "PyPI – Python Version")
[![PyPI - Wheel](https://img.shields.io/pypi/wheel/playlist2podcasts)](https://pypi.org/project/playlist2podcasts "PyPI – Wheel")
[![AGPL](https://www.gnu.org/graphics/agplv3-with-text-162x68.png)](https://codeberg.org/pyyttools/playlist2podcasts/src/branch/main/license.md "AGPL 3 or later")


Playlist2Podcast is a command line tool that takes a Youtube playlist, downloads the audio portion of the videos on that
list, and creates a podcast feed from this.

Playlist2Podcast:

1) downloads and converts the videos in one or more playlists to opus audio only files,
2) downloads thumbnails and converts them to JPEG format, and
3) creates a podcast feed with the downloaded videos and thumbnails.

## Install and run natively

Easiest way to use Playlist2Podcast is to use `pipx` to install it from PyPi. Then you can simply use
`playlist2podcast` on the command line run it.
To configure playlist2podacast you can rename the [config.toml.example][1] file to `config.toml` and adjust values as
needed.

Below is an annotated version of the config.toml file explaining the various settings:

```toml
   # version of playlist2podcasts this configuration file is built for.
   version = "2.0.0"
   # URL where the feed.rss file will be published. This value is used for references within the generated `feed.rss`
   # file. This value needs to be provided.
   podcast_host = "http://<...>"
   # directory on local file system to place all files for podcast in
   publish_dir = "publish"
   # directory on local file system where all media files are saved to, this is a sub directory inside the publish_dir
   media_dir = "media"
   # how many of the most recent episodes to download and save for each playlist
   number_of_episodes = 5
   # optional, file (with path if needed) on local filesystem where youtube cookie is stored for yt-dlp to use
   youtube_cookie_file = "youtube-dl-cookies.txt"

   # Each youtube playlist to be processed into your podcast is contained under a `[[play_lists]]` header. You can have
   # multiple `[[play_lists]]` sections

   [[play_lists]]
   # URL to list of media to look at and download audio files from to build your personalised podcast
   url = "https://www.youtube.com/@PythonBytes/streams"
   # Include filters allowing to only process some videos. Will allow all if empty.
   include = []
   # Exclude filters for videos NOT to download. If some video has been selected with an include filer but is also selected
   # with an exclude filter, that video will be excluded. In other words, exclude filters trump include filters.
   exclude = []

   [[play_lists]]
   # Second playlist to show an example of include and exclude filters. In this example, we exclude all videos that
   # contain "shorts" anywhere in the title or url. Additionally we only include videos where the title starts with
   # "The Level1 Show"
   url = "https://www.youtube.com/c/Level1Techs/videos"
   include = [
       "^The Level1 Show.*",
   ]
   exclude = [
       "shorts",
   ]
```

## Docker

There is a container image published for playlist2podcast that can be used with docker of Podman.

Following is an example run command using podman (replace podman with docker to run with docker):

```bash
   podman run \
      --rm \
      --replace \
      --detach \
      --env TZ=UTC \
      --env UPDATE_INTERVAL=4h \
      --env LOGGING_CONFIG=/config/logging-config.toml \
      --name playlist2podcasts \
      --volume ./playlist2podcasts/config:/config \
      --volume ./playlist2podcasts/publish:/publish \
      --volume ./playlist2podcasts/logging:/logging \
      codeberg.org/pyyttools/playlist2podcasts:latest
```

## Changelog

See the [Changelog][2] for any changes introduced with each version.

## License

Playlist2Podcast is licences under the [GNU Affero General Public License v3.0](https://codeberg.org/pyyttools/playlist2podcasts/src/branch/main/LICENSE.md)
