"""Internal adapters for built-in storage formats."""

from jabs.io.internal import (
    dataclass,
    inference,
    keypoints,
    prediction,
)
