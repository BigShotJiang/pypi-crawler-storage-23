"""Inference result adapters."""

from .run_metadata import InferenceRunMetadataAdapter

__all__ = [
    "InferenceRunMetadataAdapter",
]
