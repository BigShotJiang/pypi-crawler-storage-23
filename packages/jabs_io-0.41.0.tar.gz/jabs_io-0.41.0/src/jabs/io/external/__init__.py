"""Adapters for interoperability with non-JABS files and datatypes."""
