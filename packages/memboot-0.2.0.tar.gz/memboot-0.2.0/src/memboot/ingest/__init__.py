"""File ingestion subpackage."""

from __future__ import annotations
