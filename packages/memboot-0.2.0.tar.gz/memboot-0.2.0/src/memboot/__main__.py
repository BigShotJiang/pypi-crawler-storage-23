"""Allow running as ``python -m memboot``."""

from __future__ import annotations

from memboot.cli import app

if __name__ == "__main__":
    app()
