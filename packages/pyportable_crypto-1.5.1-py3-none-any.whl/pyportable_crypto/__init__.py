"""
references:
    https://stackoverflow.com/questions/12524994/encrypt-decrypt-using-
        pycrypto-aes-256
    https://blog.csdn.net/Flower941220/article/details/101166912

warnings:
    docs/cythonize-known-issues.zh.md
"""
if True:
    import lk_logger
    lk_logger.setup(quiet=True, show_varnames=True)

from . import cipher_gen
from .compilation import PyCompiler
# TODO: rename to "compile_package"/"encrypt_package"?
from .compilation import compile_dir
# TODO: rename to "compile_module"/"encrypt_module"?
from .compilation import compile_file
from .encryption import decrypt_data
from .encryption import decrypt_file
from .encryption import encrypt_data
from .encryption import encrypt_file
from .encryption import keygen

__version__ = '1.5.1'
