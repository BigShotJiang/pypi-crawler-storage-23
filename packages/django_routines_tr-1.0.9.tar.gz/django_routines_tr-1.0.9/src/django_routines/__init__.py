from .i18n.slug_redirect import redirect_to_correct_i18n_slug
from .i18n.slugify_tr import turkce_slugify
from .images.compress import resim_sikistir

__all__ = [
    "redirect_to_correct_i18n_slug",
    "turkce_slugify",
    "resim_sikistir",
    "coklu_dil_slug_uygula",
]