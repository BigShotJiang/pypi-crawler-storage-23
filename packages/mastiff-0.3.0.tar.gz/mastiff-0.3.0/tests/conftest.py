"""Mastiff test configuration."""
