from typing import List

from pyPhases.util.Logger import classLogger
from pyPhasesRecordloader import AnnotationInvalid, AnnotationNotFound, Event
from pyPhasesRecordloader.recordLoaders.XMLAnnotationLoader import XMLAnnotationLoader


@classLogger
class ProfusionAnnotationLoader(XMLAnnotationLoader):

    mapSleep = {
        '9': 'undefined',
        '0': 'W',
        '1': 'N1',
        '2': 'N2',
        '3': 'N3',
        '5': 'R',
    }

    mapEvents = {
        'Central Apnea': 'resp_centralapnea', 
        'Obstructive Apnea': 'resp_obstructiveapnea', 
        'Mixed Apnea': 'resp_mixedapnea',
        'Hypopnea': 'resp_hypopnea',

        'Obstructive Hypopnea': 'resp_hypopnea_obstructive',
        'Central Hypopnea': 'resp_hypopnea_central',
        'Mixed Hypopnea': 'hypopnea',

        'Arousal ()': 'arousal',
        'Arousal (ARO RES)': 'arousal_respiratory',
        'Arousal (ARO Limb)': 'arousal_limb',
        'Arousal (ARO SPONT)': 'arousal_spontaneous',

        'RERA': 'arousal_rera',

        'Limb Movement (Left)': 'LegMovement-Left',
        'Limb Movement (Right)': 'egMovement-Right',
        'PLM (Left)': 'PLM-Left',
        'PLM (Right)': 'PLM-Right',

        'Cheyne Stokes Breathing': 'resp_cheynestokesbreath',

        'SpO2 desaturation': 'spo2_desaturation',

        # 'Unsure': '',
        # 'Bradycardia': '',
        # 'Tachycardia': '',
        # 'TcCO2 artifact': '',
        # 'EtCO2 artifact': '',
        # 'Distal pH artifact': '',
        # 'Distal pH': '',
        # 'Proximal pH artifact': '',
        # 'Blood pressure artifact': '',
        # 'Body temperature artifact': '',
        # 'Respiratory Paradox': '',
        # 'Periodic Breathing': '',
        # 'Respiratory artifact': '',
        # 'SpO2 artifact': '',
    }
    

    def getPath(self, xml, path):
        path = "./" + path
        return xml.findall(path)
    

    def loadEvents(
        self,
        path,
        eventMap,
        durationChild="Duration",
        startChild="Start",
        nameChild="Name",
        minDuration=0,
        replaceName=None,
    ):
        tags = self.getPath(self.metaXML, path)
        if tags is None:
            raise AnnotationNotFound(path)

        events = []

        lastDefaultEvent = None
        startDuration = 0
        defaultDuration = 30

        for tag in tags:
            name = tag.find(nameChild).text

            if startChild is None:
                startValue = startDuration
                duration = defaultDuration
                startDuration += defaultDuration
            else:
                startValue = float(tag.find(startChild).text)
                duration = 0
            
            if startValue is None:
                raise AnnotationInvalid(path + [startChild])

            startInSeconds = float(startValue)
            # if the name is in the eventMap it will be added to the annotations
            if name in eventMap:
                event = Event()
                event.start = startInSeconds
                event.manual = True
                eventName = replaceName(tag) if replaceName else eventMap[name]

                event.name = eventName
                event.duration = duration

                if durationChild is not None:
                    # if there is a duration the event will be saved as as 2 events:
                    # startTime, "(eventName"
                    # endTime, "eventName)"
                    durationValue = float(tag.find(durationChild).text)
                    if durationValue is None:
                        raise AnnotationInvalid(path + [durationChild])

                    durationInSeconds = float(durationValue)
                    if durationInSeconds > minDuration:
                        event.duration = durationInSeconds
                        events.append(event)
                else:
                    # if its without a duration, it is considered a permanent state change
                    # that will persist until it is changed again
                    if lastDefaultEvent is not None:
                        lastDefaultEvent.duration = event.start - lastDefaultEvent.start
                    events.append(event)
                    lastDefaultEvent = event
            # else:
            #     self.logWarning("Event " + name + " not in EventMap.")

        if lastDefaultEvent is not None and self.lightOn is not None:
            lastDefaultEvent.duration = self.lightOn - lastDefaultEvent.start

        return events

    def loadAnnotation(self, xmlFile) -> List[Event]:
        self.loadXmlFile(xmlFile)

        allEvents = []
        allEvents += self.loadEvents(
            "SleepStages/SleepStage",
            self.mapSleep,
            nameChild=".",
            durationChild=None,
            startChild=None
        )
        allEvents += self.loadEvents(
            "ScoredEvents/ScoredEvent",
            self.mapEvents,
        )

        # no light annotations ?
        self.lightOff = 0
        self.lightOn = None

        return allEvents

    def fillRecord(self, record, xmlFile):
        pass
