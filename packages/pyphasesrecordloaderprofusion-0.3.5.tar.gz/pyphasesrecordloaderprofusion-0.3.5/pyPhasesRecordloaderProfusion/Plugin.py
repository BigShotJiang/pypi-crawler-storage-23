from pyPhases import PluginAdapter
from pyPhasesRecordloader import RecordLoader


class Plugin(PluginAdapter):
    defaultConfig = "config.yaml"
    def initPlugin(self):
        # self.project.loadConfig(self.project.loadConfig(pathlib.Path(__file__).parent.absolute().joinpath("config.yaml")))
        module = "pyPhasesRecordloaderProfusion"
        rlPath = f"{module}.recordLoaders"
        RecordLoader.registerRecordLoader("RecordLoaderProfusion", rlPath)
        RecordLoader.registerRecordLoader("ProfusionAnnotationLoader", rlPath)
        profusionPath = self.getConfig("profusion-path")
        self.project.setConfig("loader.profusion.filePath", profusionPath)
