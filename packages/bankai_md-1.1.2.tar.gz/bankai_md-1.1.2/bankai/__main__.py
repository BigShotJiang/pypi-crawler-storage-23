"""Allow running BANKAI as: python -m bankai [command] [options]"""

from bankai.cli import main

main()
