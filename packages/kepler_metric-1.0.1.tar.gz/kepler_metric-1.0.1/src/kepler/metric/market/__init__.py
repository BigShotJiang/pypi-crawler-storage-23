"""Market relationship metrics for financial analysis.

This module provides functions for calculating metrics that describe
the relationship between a strategy and a market benchmark:
- Alpha and Beta
- Capture ratios
- Beta fragility heuristic
"""

from .alpha_beta import (
    alpha,
    alpha_aligned,
    beta,
    beta_aligned,
    alpha_beta,
    alpha_beta_aligned,
    up_alpha_beta,
    down_alpha_beta,
)
from .capture import capture, up_capture, down_capture, up_down_capture
from .fragility import beta_fragility_heuristic, beta_fragility_heuristic_aligned

__all__ = [
    # Alpha/Beta
    "alpha",
    "alpha_aligned",
    "beta",
    "beta_aligned",
    "alpha_beta",
    "alpha_beta_aligned",
    "up_alpha_beta",
    "down_alpha_beta",
    # Capture
    "capture",
    "up_capture",
    "down_capture",
    "up_down_capture",
    # Fragility
    "beta_fragility_heuristic",
    "beta_fragility_heuristic_aligned",
]
