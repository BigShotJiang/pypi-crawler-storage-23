"""Alpha and Beta calculations for market relationship analysis."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import PeriodType, Returns1D, Numeric, OutType
from kepler.metric._utils import nanmean, adjust_returns, aligned_series
from kepler.metric.periods import DAILY
from kepler.metric.returns import annualization_factor

__all__ = [
    "alpha",
    "alpha_aligned",
    "beta",
    "beta_aligned",
    "alpha_beta",
    "alpha_beta_aligned",
    "up_alpha_beta",
    "down_alpha_beta",
]


def _aligned_series(*many_series: Returns1D) -> tuple[Returns1D, ...]:
    """Align multiple series by their indices."""
    head = many_series[0]
    tail = many_series[1:]
    n = len(head)

    if isinstance(head, np.ndarray) and all(
        len(s) == n and isinstance(s, np.ndarray) for s in tail
    ):
        return many_series

    return tuple(
        v for _, v in pd.concat(map(_to_pandas, many_series), axis=1).items()
    )


def _to_pandas(ob):
    """Convert array-like to pandas object."""
    if isinstance(ob, pd.Series | pd.DataFrame):
        return ob
    if ob.ndim == 1:
        return pd.Series(ob)
    elif ob.ndim == 2:
        return pd.DataFrame(ob)
    else:
        raise ValueError("Cannot convert array of dim > 2 to a pandas structure")


def beta(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    *,
    out: OutType = None,
) -> float:
    """
    Calculate beta.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor to which beta is computed.
        Usually a benchmark such as the market.
    risk_free : int, float, optional
        Constant risk-free return throughout the period.
    out : array-like, optional
        Array to use as output buffer.

    Returns
    -------
    float
        Beta.
    """
    if not (isinstance(returns, np.ndarray) and isinstance(factor_returns, np.ndarray)):
        returns, factor_returns = _aligned_series(returns, factor_returns)

    return beta_aligned(returns, factor_returns, risk_free=risk_free, out=out)


def beta_aligned(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    *,
    out: OutType = None,
) -> float:
    """
    Calculate beta with pre-aligned inputs.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative. Already aligned.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor. Already aligned.
    risk_free : int, float, optional
        Constant risk-free return throughout the period.
    out : array-like, optional
        Array to use as output buffer.

    Returns
    -------
    float
        Beta.
    """
    if len(returns) < 2:
        return np.nan

    # Compute covariance and variance
    adj_returns = adjust_returns(np.asanyarray(returns), risk_free)
    adj_factor = adjust_returns(np.asanyarray(factor_returns), risk_free)

    cov_matrix = np.cov(adj_returns, adj_factor, ddof=1)
    beta_value = cov_matrix[0, 1] / cov_matrix[1, 1]

    return float(beta_value)


def alpha(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
    _beta: float | None = None,
) -> float:
    """
    Calculate annualized alpha.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor.
    risk_free : int, float, optional
        Constant risk-free return throughout the period.
    period : str, optional
        Defines the periodicity of the returns for annualizing.
    annualization : int, optional
        Used to suppress default values in period.
    _beta : float, optional
        Pre-computed beta. Will be calculated if not provided.
    out : array-like, optional
        Array to use as output buffer.

    Returns
    -------
    float
        Alpha.
    """
    if not (isinstance(returns, np.ndarray) and isinstance(factor_returns, np.ndarray)):
        returns, factor_returns = _aligned_series(returns, factor_returns)

    return alpha_aligned(
        returns,
        factor_returns,
        risk_free=risk_free,
        period=period,
        annualization=annualization,
        out=out,
        _beta=_beta,
    )


def alpha_aligned(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
    _beta: float | None = None,
) -> float:
    """
    Calculate annualized alpha with pre-aligned inputs.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative. Already aligned.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor. Already aligned.
    risk_free : int, float, optional
        Constant risk-free return throughout the period.
    period : str, optional
        Defines the periodicity of the returns for annualizing.
    annualization : int, optional
        Used to suppress default values in period.
    _beta : float, optional
        Pre-computed beta. Will be calculated if not provided.
    out : array-like, optional
        Array to use as output buffer.

    Returns
    -------
    float
        Alpha.
    """
    if len(returns) < 2:
        return np.nan

    ann_factor = annualization_factor(period, annualization)

    if _beta is None:
        _beta = beta_aligned(returns, factor_returns, risk_free)

    adj_returns = adjust_returns(np.asanyarray(returns), risk_free)
    adj_factor_returns = adjust_returns(np.asanyarray(factor_returns), risk_free)
    alpha_series = adj_returns - (_beta * adj_factor_returns)

    alpha_value = (1 + nanmean(alpha_series, axis=0)) ** ann_factor - 1

    return float(alpha_value)


def alpha_beta(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
) -> tuple[float, float]:
    """
    Calculate both annualized alpha and beta.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor.
    risk_free : int, float, optional
        Constant risk-free return throughout the period.
    period : str, optional
        Defines the periodicity of the returns for annualizing.
    annualization : int, optional
        Used to suppress default values in period.
    out : array-like, optional
        Array to use as output buffer.

    Returns
    -------
    tuple[float, float]
        (alpha, beta)
    """
    if not (isinstance(returns, np.ndarray) and isinstance(factor_returns, np.ndarray)):
        returns, factor_returns = _aligned_series(returns, factor_returns)

    return alpha_beta_aligned(
        returns,
        factor_returns,
        risk_free=risk_free,
        period=period,
        annualization=annualization,
        out=out,
    )


def alpha_beta_aligned(
    returns: Returns1D,
    factor_returns: Returns1D,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
) -> tuple[float, float]:
    """
    Calculate both annualized alpha and beta with pre-aligned inputs.

    Returns
    -------
    tuple[float, float]
        (alpha, beta)
    """
    b = beta_aligned(returns, factor_returns, risk_free)
    a = alpha_aligned(
        returns,
        factor_returns,
        risk_free,
        period,
        annualization=annualization,
        _beta=b,
        out=out,
    )
    return (a, b)


def up_alpha_beta(
    returns: Returns1D,
    factor_returns: Returns1D,
    *,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    annualization: int | None = None,
) -> tuple[float, float]:
    """
    Calculate alpha and beta for up periods (positive factor returns).

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy.
    factor_returns : pd.Series or np.ndarray
        Daily returns of the benchmark.
    risk_free : int, float, optional
        Constant risk-free return.
    period : str, optional
        Periodicity of returns.
    annualization : int, optional
        Annualization factor.

    Returns
    -------
    tuple[float, float]
        (alpha, beta) for up periods.
    """
    returns = returns[factor_returns > 0]
    factor_returns = factor_returns[factor_returns > 0]
    return alpha_beta(returns, factor_returns, risk_free, period, annualization=annualization)


def down_alpha_beta(
    returns: Returns1D,
    factor_returns: Returns1D,
    *,
    risk_free: Numeric = 0.0,
    period: PeriodType = DAILY,
    annualization: int | None = None,
) -> tuple[float, float]:
    """
    Calculate alpha and beta for down periods (negative factor returns).

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy.
    factor_returns : pd.Series or np.ndarray
        Daily returns of the benchmark.
    risk_free : int, float, optional
        Constant risk-free return.
    period : str, optional
        Periodicity of returns.
    annualization : int, optional
        Annualization factor.

    Returns
    -------
    tuple[float, float]
        (alpha, beta) for down periods.
    """
    returns = returns[factor_returns < 0]
    factor_returns = factor_returns[factor_returns < 0]
    return alpha_beta(returns, factor_returns, risk_free, period, annualization=annualization)
