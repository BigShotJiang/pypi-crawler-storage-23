"""Beta fragility heuristic calculations."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import Returns1D
from kepler.metric._utils import aligned_series

__all__ = ["beta_fragility_heuristic", "beta_fragility_heuristic_aligned"]


def beta_fragility_heuristic(
    returns: Returns1D,
    factor_returns: Returns1D,
) -> float:
    """
    Estimate fragility to drop in beta.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor to which beta is computed.
        Usually a benchmark such as the market.

    Returns
    -------
    float or np.nan
        The beta fragility of the strategy.

    Note
    ----
    A negative return value indicates potential losses could follow volatility
    in beta. The magnitude of the negative value indicates the size of the
    potential loss.

    See Also
    --------
    beta : Measures systematic risk.

    Reference
    ---------
    `A New Heuristic Measure of Fragility and Tail Risks: Application to
    Stress Testing <https://www.imf.org/external/pubs/ft/wp/2012/wp12216.pdf>`_
    An IMF Working Paper describing the heuristic.
    """
    if len(returns) < 3 or len(factor_returns) < 3:
        return np.nan

    return beta_fragility_heuristic_aligned(*aligned_series(returns, factor_returns))


def beta_fragility_heuristic_aligned(
    returns: Returns1D,
    factor_returns: Returns1D,
) -> float:
    """
    Estimate fragility to drop in beta with pre-aligned inputs.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative. Already aligned.
    factor_returns : pd.Series or np.ndarray
        Daily noncumulative returns of the factor. Already aligned.

    Returns
    -------
    float or np.nan
        The beta fragility of the strategy.

    Note
    ----
    If they are pd.Series, expects returns and factor_returns have already
    been aligned on their labels. If np.ndarray, these arguments should have
    the same shape.
    """
    if len(returns) < 3 or len(factor_returns) < 3:
        return np.nan

    # Combine returns and factor returns into pairs
    returns_series = pd.Series(returns)
    factor_returns_series = pd.Series(factor_returns)
    pairs = pd.concat([returns_series, factor_returns_series], axis=1)
    pairs.columns = ["returns", "factor_returns"]

    # Exclude any rows where returns are nan
    pairs = pairs.dropna()

    if len(pairs) < 3:
        return np.nan

    # Sort by factor returns using mergesort for consistency across platforms
    pairs = pairs.sort_values(by=["factor_returns"], kind="mergesort")

    # Find the three vectors using median of 3
    start_index = 0
    mid_index = int(np.around(len(pairs) / 2, 0))
    end_index = len(pairs) - 1

    (start_returns, start_factor_returns) = pairs.iloc[start_index]
    (mid_returns, mid_factor_returns) = pairs.iloc[mid_index]
    (end_returns, end_factor_returns) = pairs.iloc[end_index]

    factor_returns_range = end_factor_returns - start_factor_returns
    start_returns_weight = 0.5
    end_returns_weight = 0.5

    # Find weights for the start and end returns using a convex combination
    if factor_returns_range != 0:
        start_returns_weight = (mid_factor_returns - start_factor_returns) / factor_returns_range
        end_returns_weight = (end_factor_returns - mid_factor_returns) / factor_returns_range

    # Calculate fragility heuristic
    heuristic = (
        start_returns_weight * start_returns + end_returns_weight * end_returns - mid_returns
    )

    return float(heuristic)
