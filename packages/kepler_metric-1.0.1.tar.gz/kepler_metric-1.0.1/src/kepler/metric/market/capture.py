"""Capture ratio calculations for market relationship analysis."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import PeriodType, Returns1D
from kepler.metric.periods import DAILY
from kepler.metric.returns import annual_return

__all__ = ["capture", "up_capture", "down_capture", "up_down_capture"]


def capture(
    returns: Returns1D,
    factor_returns: Returns1D,
    period: PeriodType = DAILY,
) -> float:
    """
    Compute capture ratio.

    The capture ratio measures the relationship between the annualized
    return of a strategy and the annualized return of a benchmark.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Noncumulative returns of the factor to which beta is computed.
        Usually a benchmark such as the market.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252

    Returns
    -------
    float
        Capture ratio.

    Note
    ----
    See https://www.investopedia.com/terms/u/up-market-capture-ratio.asp for
    more information.
    """
    return annual_return(returns, period=period) / annual_return(factor_returns, period=period)


def up_capture(
    returns: Returns1D,
    factor_returns: Returns1D,
    *,
    period: PeriodType = DAILY,
) -> float:
    """
    Compute the capture ratio for periods when the benchmark return is positive.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Noncumulative returns of the benchmark.
    period : str, optional
        Defines the periodicity of the 'returns' data for annualizing.

    Returns
    -------
    float
        Up capture ratio.

    Note
    ----
    See https://www.investopedia.com/terms/u/up-market-capture-ratio.asp for
    more information.
    """
    # Filter for up periods
    if isinstance(returns, pd.Series):
        up_returns = returns[factor_returns > 0]
        up_factor = factor_returns[factor_returns > 0]
    else:
        mask = factor_returns > 0
        up_returns = returns[mask]
        up_factor = factor_returns[mask]

    return capture(up_returns, up_factor, period=period)


def down_capture(
    returns: Returns1D,
    factor_returns: Returns1D,
    *,
    period: PeriodType = DAILY,
) -> float:
    """
    Compute the capture ratio for periods when the benchmark return is negative.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Noncumulative returns of the benchmark.
    period : str, optional
        Defines the periodicity of the 'returns' data for annualizing.

    Returns
    -------
    float
        Down capture ratio.

    Note
    ----
    See https://www.investopedia.com/terms/d/down-market-capture-ratio.asp for
    more information.
    """
    # Filter for down periods
    if isinstance(returns, pd.Series):
        down_returns = returns[factor_returns < 0]
        down_factor = factor_returns[factor_returns < 0]
    else:
        mask = factor_returns < 0
        down_returns = returns[mask]
        down_factor = factor_returns[mask]

    return capture(down_returns, down_factor, period=period)


def up_down_capture(
    returns: Returns1D,
    factor_returns: Returns1D,
    *,
    period: PeriodType = DAILY,
) -> float:
    """
    Compute the ratio of up_capture to down_capture.

    This ratio compares the strategy's performance in up markets
    versus down markets. A ratio > 1 indicates the strategy performs
    better in up markets.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Noncumulative returns of the benchmark.
    period : str, optional
        Defines the periodicity of the 'returns' data for annualizing.

    Returns
    -------
    float
        Up/down capture ratio.
    """
    up = up_capture(returns, factor_returns, period=period)
    down = down_capture(returns, factor_returns, period=period)

    if down == 0:
        return np.nan

    return up / down
