"""Risk metrics for financial analysis.

This module provides functions for calculating various risk metrics:
- Maximum drawdown
- Volatility (annual)
- Downside risk
- Value at Risk (VaR)
- Conditional Value at Risk (CVaR)
- Tail ratio
"""

from .drawdown import max_drawdown, get_max_drawdown_period
from .volatility import volatility, annual_volatility
from .downside import downside_risk
from .var import var, cvar
from .tail import tail_ratio, gpd_risk_estimates, gpd_risk_estimates_aligned

__all__ = [
    # Drawdown
    "max_drawdown",
    "get_max_drawdown_period",
    # Volatility
    "volatility",
    "annual_volatility",
    # Downside
    "downside_risk",
    # VaR
    "var",
    "cvar",
    # Tail
    "tail_ratio",
    "gpd_risk_estimates",
    "gpd_risk_estimates_aligned",
]
