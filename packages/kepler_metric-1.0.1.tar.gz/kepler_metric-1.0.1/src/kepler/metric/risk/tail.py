"""Tail risk calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd
from scipy import optimize
from sys import float_info

from kepler.metric._types import Returns1D, Numeric
from kepler.metric._utils import aligned_series

__all__ = [
    "tail_ratio",
    "gpd_risk_estimates",
    "gpd_risk_estimates_aligned",
]


def tail_ratio(returns: Returns1D) -> float | pd.Series:
    """
    Determine the ratio between the right (95%) and left tail (5%).

    For example, a ratio of 0.25 means that losses are four times
    as bad as profits.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.

    Returns
    -------
    float or pd.Series
        Tail ratio. Returns a Series for DataFrame input with column names
        preserved.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, -0.05, 0.02, -0.08, 0.03])
    >>> tail_ratio(returns)
    0.375
    """
    if len(returns) < 1:
        if isinstance(returns, pd.DataFrame):
            return pd.Series([np.nan] * len(returns.columns), index=returns.columns)
        return np.nan

    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns[col].dropna()
            if len(col_returns) < 1:
                result[col] = np.nan
            else:
                result[col] = np.abs(np.percentile(col_returns, 95)) / np.abs(
                    np.percentile(col_returns, 5)
                )
        return result
    else:
        # Handle Series/array input
        returns = np.asanyarray(returns)
        # Be tolerant of nan's
        returns = returns[~np.isnan(returns)]
        if len(returns) < 1:
            return np.nan

        return np.abs(np.percentile(returns, 95)) / np.abs(np.percentile(returns, 5))


def gpd_risk_estimates(
    returns: Returns1D,
    var_p: Numeric = 0.01,
) -> NDArray[np.floating] | pd.Series:
    """
    Estimate VaR and ES using the Generalized Pareto Distribution (GPD).

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    var_p : float
        The percentile to use for estimating the VaR and ES.

    Returns
    -------
    np.ndarray or pd.Series
        [threshold, scale_param, shape_param, var_estimate, es_estimate]:
        - threshold: the threshold used to cut off exception tail losses
        - scale_param: parameter capturing the scale (related to variance)
        - shape_param: parameter capturing the shape or type of distribution
        - var_estimate: an estimate for the VaR for the given percentile
        - es_estimate: an estimate for the ES for the given percentile

    Note
    ----
    See also: `An Application of Extreme Value Theory for Measuring Risk
    <https://link.springer.com/article/10.1007/s10614-006-9025-7>`_
    """
    if len(returns) < 3:
        result = np.zeros(5)
        if isinstance(returns, pd.Series):
            result = pd.Series(result)
        return result
    return gpd_risk_estimates_aligned(*aligned_series(returns, var_p))


def gpd_risk_estimates_aligned(
    returns: Returns1D,
    var_p: Numeric = 0.01,
) -> NDArray[np.floating] | pd.Series:
    """
    Estimate VaR and ES using the Generalized Pareto Distribution (GPD).

    This is the aligned version that expects pre-aligned inputs.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    var_p : float
        The percentile to use for estimating the VaR and ES.

    Returns
    -------
    np.ndarray or pd.Series
        [threshold, scale_param, shape_param, var_estimate, es_estimate]
    """
    result = np.zeros(5)
    if not len(returns) < 3:
        default_threshold = 0.2
        minimum_threshold = 0.000000001

        returns_array = pd.Series(returns).to_numpy()

        flipped_returns = -1 * returns_array
        losses = flipped_returns[flipped_returns > 0]
        threshold = default_threshold
        finished = False
        scale_param = 0
        shape_param = 0
        var_estimate = 0

        while not finished and threshold > minimum_threshold:
            losses_beyond_threshold = losses[losses >= threshold]
            param_result = _gpd_loglikelihood_minimizer_aligned(losses_beyond_threshold)
            if param_result[0] is not False and param_result[1] is not False:
                scale_param = param_result[0]
                shape_param = param_result[1]
                var_estimate = _gpd_var_calculator(
                    threshold,
                    scale_param,
                    shape_param,
                    var_p,
                    len(losses),
                    len(losses_beyond_threshold),
                )
                # non-negative shape parameter is required for fat tails
                # non-negative VaR estimate is required for loss of some kind
                if shape_param > 0 and var_estimate > 0:
                    finished = True
            if not finished:
                threshold = threshold / 2

        if finished:
            es_estimate = _gpd_es_calculator(var_estimate, threshold, scale_param, shape_param)
            result = np.array([threshold, scale_param, shape_param, var_estimate, es_estimate])

    if isinstance(returns, pd.Series):
        result = pd.Series(result)
    return result


# Internal GPD helper functions


def _gpd_es_calculator(
    var_estimate: float,
    threshold: float,
    scale_param: float,
    shape_param: float,
) -> float:
    """Calculate Expected Shortfall using GPD parameters."""
    result = 0
    if (1 - shape_param) != 0:
        # Formula from Gilli and Kellezi pg. 8
        var_ratio = var_estimate / (1 - shape_param)
        param_ratio = (scale_param - (shape_param * threshold)) / (1 - shape_param)
        result = var_ratio + param_ratio
    return result


def _gpd_var_calculator(
    threshold: float,
    scale_param: float,
    shape_param: float,
    probability: float,
    total_n: int,
    exceedance_n: int,
) -> float:
    """Calculate VaR using GPD parameters."""
    result = 0
    if exceedance_n > 0 and shape_param > 0:
        # Formula from Gilli and Kellezi pg. 12
        param_ratio = scale_param / shape_param
        prob_ratio = (total_n / exceedance_n) * probability
        result = threshold + (param_ratio * (pow(prob_ratio, -shape_param) - 1))
    return result


def _gpd_loglikelihood_minimizer_aligned(price_data: np.ndarray) -> list:
    """Minimize GPD log-likelihood to find optimal parameters."""
    result = [False, False]
    default_scale_param = 1
    default_shape_param = 1

    if len(price_data) > 0:
        gpd_loglikelihood_lambda = _gpd_loglikelihood_factory(price_data)
        optimization_results = optimize.minimize(
            gpd_loglikelihood_lambda,
            [default_scale_param, default_shape_param],
            method="Nelder-Mead",
        )
        if optimization_results.success:
            resulting_params = optimization_results.x
            if len(resulting_params) == 2:
                result[0] = resulting_params[0]
                result[1] = resulting_params[1]
    return result


def _gpd_loglikelihood_factory(price_data: np.ndarray):
    """Create log-likelihood function for optimization."""
    return lambda params: _gpd_loglikelihood(params, price_data)


def _gpd_loglikelihood(params: list, price_data: np.ndarray) -> float:
    """Calculate GPD log-likelihood."""
    if params[1] != 0:
        return -_gpd_loglikelihood_scale_and_shape(params[0], params[1], price_data)
    else:
        return -_gpd_loglikelihood_scale_only(params[0], price_data)


def _gpd_loglikelihood_scale_and_shape(
    scale: float,
    shape: float,
    price_data: np.ndarray,
) -> float:
    """Calculate GPD log-likelihood with scale and shape parameters."""
    n = len(price_data)
    result = -1 * float_info.max
    if scale != 0:
        param_factor = shape / scale
        if shape != 0 and param_factor >= 0 and scale >= 0:
            result = (
                (-n * np.log(scale))
                - ((1 / shape) + 1) * np.sum(np.log(1 + param_factor * price_data))
            )
    return result


def _gpd_loglikelihood_scale_only(scale: float, price_data: np.ndarray) -> float:
    """Calculate GPD log-likelihood with scale parameter only (shape=0)."""
    n = len(price_data)
    result = -1 * float_info.max
    if scale != 0 and scale >= 0:
        result = (-n * np.log(scale)) - (np.sum(price_data) / scale)
    return result
