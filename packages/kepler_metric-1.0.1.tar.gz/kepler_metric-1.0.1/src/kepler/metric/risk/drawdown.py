"""Maximum drawdown calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import ReturnsInput, OutType
from kepler.metric._utils import nanmin
from kepler.metric.returns import cum_returns

__all__ = ["max_drawdown", "get_max_drawdown_period"]


def max_drawdown(
    returns: ReturnsInput,
    *,
    out: OutType = None,
) -> float | pd.Series:
    """
    Determine the maximum drawdown of a strategy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    float or pd.Series
        Maximum drawdown. If input is DataFrame, returns a Series indexed by
        column names.

    See Also
    --------
    get_max_drawdown_period : Get the start and end dates of max drawdown.

    Note
    ----
    See https://en.wikipedia.org/wiki/Drawdown_(economics) for more details.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, -0.05, 0.02, -0.03, 0.04])
    >>> max_drawdown(returns)
    -0.0796...
    """
    allocated_output = out is None
    if allocated_output:
        out = np.empty(returns.shape[1:])

    returns_1d = returns.ndim == 1

    if len(returns) < 1:
        out[()] = np.nan
        if returns_1d:
            out = out.item()
        return out

    returns_array = np.asanyarray(returns)

    cumulative = np.empty(
        (returns.shape[0] + 1,) + returns.shape[1:],
        dtype="float64",
    )
    cumulative[0] = start = 100
    cum_returns(returns_array, starting_value=start, out=cumulative[1:])

    max_return = np.fmax.accumulate(cumulative, axis=0)

    nanmin((cumulative - max_return) / max_return, axis=0, out=out)
    if returns_1d:
        out = out.item()
    elif allocated_output and isinstance(returns, pd.DataFrame):
        out = pd.Series(out, index=returns.columns)

    return out


def get_max_drawdown_period(returns: pd.Series) -> str:
    """
    Calculate the start and end dates of the maximum drawdown period.

    Parameters
    ----------
    returns : pd.Series
        Daily returns series with datetime index.

    Returns
    -------
    str
        A string in the format "start_date,end_date" representing the period
        of maximum drawdown.

    Examples
    --------
    >>> import pandas as pd
    >>> idx = pd.date_range('2020-01-01', periods=10, freq='D')
    >>> returns = pd.Series([0.01, -0.05, 0.02, -0.08, 0.01, -0.02, 0.03, 0.01, -0.01, 0.02], index=idx)
    >>> get_max_drawdown_period(returns)
    '2020-01-02,2020-01-05'
    """
    # Calculate cumulative returns
    cumulative = (1 + returns).cumprod()

    # Calculate rolling maximum
    rolling_max = cumulative.cummax()

    # Calculate drawdown
    drawdown = cumulative / rolling_max - 1

    # Find the end date of maximum drawdown
    end_date = drawdown.idxmin()

    # Find the start date of maximum drawdown (previous peak)
    start_date = cumulative.loc[:end_date].idxmax()

    return f"{start_date.date()},{end_date.date()}"
