"""Value at Risk (VaR) calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import ReturnsInput, Numeric

__all__ = ["var", "cvar"]


def var(
    returns: ReturnsInput,
    cutoff: Numeric = 0.05,
) -> float | pd.Series:
    """
    Value at risk (VaR) of a returns stream.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Non-cumulative daily returns.
    cutoff : float, optional
        Decimal representing the percentage cutoff for the bottom percentile of
        returns. Default is 0.05.

    Returns
    -------
    float or pd.Series
        The VaR value. Returns a Series for DataFrame input with column names
        preserved.

    See Also
    --------
    cvar : Expected shortfall (CVaR).

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, -0.05, 0.02, -0.08, 0.03])
    >>> var(returns, cutoff=0.05)
    -0.08
    """
    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns[col].dropna()
            if len(col_returns) == 0:
                result[col] = np.nan
            else:
                result[col] = np.percentile(col_returns, 100 * cutoff)
        return result
    else:
        # Handle Series/array input
        return np.percentile(returns, 100 * cutoff)


def cvar(
    returns: ReturnsInput,
    cutoff: Numeric = 0.05,
) -> float | pd.Series:
    """
    Conditional value at risk (CVaR) of a returns stream.

    CVaR measures the expected single-day returns of an asset on that asset's
    worst performing days, where "worst-performing" is defined as falling below
    `cutoff` as a percentile of all daily returns.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Non-cumulative daily returns.
    cutoff : float, optional
        Decimal representing the percentage cutoff for the bottom percentile of
        returns. Default is 0.05.

    Returns
    -------
    float or pd.Series
        The CVaR value. Returns a Series for DataFrame input with column names
        preserved.

    See Also
    --------
    var : Value at Risk (VaR).

    Note
    ----
    Also known as Expected Shortfall (ES) or Expected Tail Loss (ETL).

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, -0.05, 0.02, -0.08, 0.03])
    >>> cvar(returns, cutoff=0.2)
    -0.065
    """
    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns[col].dropna()
            if len(col_returns) == 0:
                result[col] = np.nan
            else:
                # PERF: Instead of using the 'var' function to find the cutoff
                # value, which requires a call to numpy.percentile, determine the cutoff
                # index manually and partition out the lowest returns values.
                cutoff_index = int((len(col_returns) - 1) * cutoff)
                result[col] = np.mean(np.partition(col_returns, cutoff_index)[: cutoff_index + 1])
        return result
    else:
        # Handle Series/array input
        cutoff_index = int((len(returns) - 1) * cutoff)
        return np.mean(np.partition(returns, cutoff_index)[: cutoff_index + 1])
