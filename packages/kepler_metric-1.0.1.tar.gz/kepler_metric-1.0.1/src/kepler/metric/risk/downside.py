"""Downside risk calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import PeriodType, ReturnsInput, RequiredReturnType, OutType
from kepler.metric._utils import nanmean, adjust_returns
from kepler.metric.periods import DAILY
from kepler.metric.returns import annualization_factor

__all__ = ["downside_risk"]


def downside_risk(
    returns: ReturnsInput,
    required_return: RequiredReturnType = 0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
) -> float | pd.Series:
    """
    Determine the downside deviation below a threshold.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    required_return : float or pd.Series, optional
        Minimum acceptable return. Default is 0.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    float or pd.Series
        Downside deviation. If input is DataFrame, returns a Series indexed by
        column names.

    Note
    ----
    See `<https://www.sunrisecapital.com/wp-content/uploads/2014/06/Futures_
    Mag_Sortino_0213.pdf>`__ for more details, specifically why using the
    standard deviation of the negative returns is not correct.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, -0.02, 0.03, -0.01, 0.02])
    >>> downside_risk(returns)
    0.1009...
    """
    allocated_output = out is None
    if allocated_output:
        out = np.empty(returns.shape[1:])

    returns_1d = returns.ndim == 1

    if len(returns) < 1:
        out[()] = np.nan
        if returns_1d:
            out = out.item()
        return out

    ann_factor = annualization_factor(period, annualization)

    downside_diff = np.clip(
        adjust_returns(
            np.asanyarray(returns),
            np.asanyarray(required_return),
        ),
        -np.inf,
        0,
    )

    np.square(downside_diff, out=downside_diff)
    nanmean(downside_diff, axis=0, out=out)
    np.sqrt(out, out=out)
    np.multiply(out, np.sqrt(ann_factor), out=out)

    if returns_1d:
        out = out.item()
    elif isinstance(returns, pd.DataFrame):
        out = pd.Series(out, index=returns.columns)

    return out
