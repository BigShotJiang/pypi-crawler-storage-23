"""Type definitions for kepler.metric."""

from ._core import (
    Numeric,
    Returns1D,
    ReturnsInput,
    PricesInput,
    ScalarResult,
    FlexibleResult,
    PeriodLiteral,
    PeriodType,
    RiskFreeType,
    RequiredReturnType,
    OutType,
    ArrayLike,
    T,
    SeriesT,
)

__all__ = [
    "Numeric",
    "Returns1D",
    "ReturnsInput",
    "PricesInput",
    "ScalarResult",
    "FlexibleResult",
    "PeriodLiteral",
    "PeriodType",
    "RiskFreeType",
    "RequiredReturnType",
    "OutType",
    "ArrayLike",
    "T",
    "SeriesT",
]
