"""Core type definitions for kepler.metric.

This module provides type aliases and protocols for consistent
type annotations across the library.
"""

from __future__ import annotations

from typing import Literal, Protocol, TypeVar, Union, runtime_checkable

import numpy as np
from numpy.typing import NDArray
import pandas as pd

# ============== Basic Type Aliases ==============

#: Numeric type (int or float)
Numeric = Union[int, float]

#: 1D returns input (Series or numpy array)
Returns1D = Union[pd.Series, NDArray[np.floating]]

#: Returns input (1D or 2D, Series, DataFrame, or numpy array)
ReturnsInput = Union[pd.Series, pd.DataFrame, NDArray[np.floating]]

#: Prices input (1D or 2D)
PricesInput = Union[pd.Series, pd.DataFrame, NDArray[np.floating]]

#: Scalar result (single float value)
ScalarResult = float

#: Flexible result (scalar or Series depending on input)
FlexibleResult = Union[float, pd.Series]

#: Period literal values
PeriodLiteral = Literal["daily", "weekly", "monthly", "quarterly", "yearly"]

#: Period type (literal or string)
PeriodType = Union[PeriodLiteral, str]

#: Risk-free rate type (scalar or series)
RiskFreeType = Union[Numeric, pd.Series, NDArray[np.floating]]

#: Required return type (scalar or series)
RequiredReturnType = Union[Numeric, pd.Series, NDArray[np.floating]]

#: Output buffer type for in-place operations
OutType = Union[NDArray[np.floating], None]

# ============== Type Variables ==============

#: Generic type for returns data
T = TypeVar("T", pd.Series, pd.DataFrame, NDArray[np.floating])

#: Type variable bounded by pandas Series
SeriesT = TypeVar("SeriesT", bound=pd.Series)

# ============== Protocols ==============


@runtime_checkable
class ArrayLike(Protocol):
    """Protocol for array-like objects supporting basic operations."""

    def __len__(self) -> int: ...
    def __getitem__(self, key, /): ...
    @property
    def ndim(self) -> int: ...
    @property
    def shape(self) -> tuple[int, ...]: ...


# ============== Exports ==============

__all__ = [
    "Numeric",
    "Returns1D",
    "ReturnsInput",
    "PricesInput",
    "ScalarResult",
    "FlexibleResult",
    "PeriodLiteral",
    "PeriodType",
    "RiskFreeType",
    "RequiredReturnType",
    "OutType",
    "ArrayLike",
    "T",
    "SeriesT",
]
