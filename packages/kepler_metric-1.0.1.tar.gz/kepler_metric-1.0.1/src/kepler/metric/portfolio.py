"""Portfolio analysis class for convenient metric calculation.

This module provides a high-level interface for calculating multiple
metrics on a portfolio of returns.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np
import pandas as pd

from kepler.metric._types import PeriodType, Returns1D
from kepler.metric.periods import DAILY
from kepler.metric.returns import cum_returns, total_return, annualized_return, cagr
from kepler.metric.risk import (
    max_drawdown,
    volatility,
    downside_risk,
    var,
    cvar,
    tail_ratio,
)
from kepler.metric.risk_adjusted import (
    sharpe,
    sortino,
    calmar,
    omega,
    information_ratio,
    stability,
)
from kepler.metric.market import alpha, beta, capture


@dataclass
class Portfolio:
    """
    A portfolio analysis class for convenient metric calculation.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the portfolio, noncumulative.
    benchmark : pd.Series or np.ndarray, optional
        Benchmark returns for relative metrics.
    risk_free : float, optional
        Risk-free rate. Default is 0.
    period : str, optional
        Periodicity of returns. Default is 'daily'.

    Examples
    --------
    >>> import pandas as pd
    >>> import numpy as np
    >>> returns = pd.Series(np.random.normal(0.001, 0.02, 252))
    >>> pf = Portfolio(returns)
    >>> pf.sharpe()
    0.85
    >>> pf.summary()
    {'total_return': 0.12, 'sharpe': 0.85, 'max_drawdown': -0.15, ...}
    """

    returns: Returns1D
    benchmark: Returns1D | None = None
    risk_free: float = 0.0
    period: PeriodType = DAILY

    # Cached results
    _metrics_cache: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        """Initialize and validate inputs."""
        if isinstance(self.returns, np.ndarray):
            self.returns = pd.Series(self.returns)

    # ===== Returns Metrics =====
    def total_return(self) -> float:
        """Calculate total return."""
        return total_return(self.returns)

    def annualized_return(self) -> float:
        """Calculate annualized return."""
        return annualized_return(self.returns, period=self.period)

    def cagr(self) -> float:
        """Calculate compound annual growth rate."""
        return cagr(self.returns, period=self.period)

    def cum_returns(self) -> pd.Series:
        """Calculate cumulative returns."""
        return cum_returns(self.returns)

    # ===== Risk Metrics =====
    def max_drawdown(self) -> float:
        """Calculate maximum drawdown."""
        return max_drawdown(self.returns)

    def volatility(self) -> float:
        """Calculate annualized volatility."""
        return volatility(self.returns, period=self.period)

    def downside_risk(self, required_return: float = 0.0) -> float:
        """Calculate downside risk."""
        return downside_risk(self.returns, required_return=required_return, period=self.period)

    def var(self, cutoff: float = 0.05) -> float:
        """Calculate Value at Risk."""
        return var(self.returns, cutoff=cutoff)

    def cvar(self, cutoff: float = 0.05) -> float:
        """Calculate Conditional Value at Risk."""
        return cvar(self.returns, cutoff=cutoff)

    def tail_ratio(self) -> float:
        """Calculate tail ratio."""
        return tail_ratio(self.returns)

    # ===== Risk-Adjusted Metrics =====
    def sharpe(self) -> float:
        """Calculate Sharpe ratio."""
        return sharpe(self.returns, risk_free=self.risk_free, period=self.period)

    def sortino(self, required_return: float = 0.0) -> float:
        """Calculate Sortino ratio."""
        return sortino(
            self.returns, required_return=required_return, period=self.period
        )

    def calmar(self) -> float:
        """Calculate Calmar ratio."""
        return calmar(self.returns, period=self.period)

    def omega(self, required_return: float = 0.0) -> float:
        """Calculate Omega ratio."""
        return omega(
            self.returns,
            risk_free=self.risk_free,
            required_return=required_return,
        )

    def stability(self) -> float:
        """Calculate stability of time series (R²)."""
        return stability(self.returns)

    def information_ratio(self) -> float | None:
        """Calculate information ratio (requires benchmark)."""
        if self.benchmark is None:
            return None
        excess = self.returns - self.benchmark
        return information_ratio(excess, period=self.period)

    # ===== Market Metrics =====
    def alpha(self) -> float | None:
        """Calculate alpha (requires benchmark)."""
        if self.benchmark is None:
            return None
        return alpha(self.returns, self.benchmark, risk_free=self.risk_free, period=self.period)

    def beta(self) -> float | None:
        """Calculate beta (requires benchmark)."""
        if self.benchmark is None:
            return None
        return beta(self.returns, self.benchmark, risk_free=self.risk_free)

    def capture(self) -> float | None:
        """Calculate capture ratio (requires benchmark)."""
        if self.benchmark is None:
            return None
        return capture(self.returns, self.benchmark, period=self.period)

    # ===== Summary =====
    def summary(self) -> dict[str, float]:
        """
        Calculate all available metrics and return as a dictionary.

        Returns
        -------
        dict
            Dictionary of all calculated metrics.
        """
        return {
            # Returns
            "total_return": self.total_return(),
            "annualized_return": self.annualized_return(),
            "cagr": self.cagr(),
            # Risk
            "max_drawdown": self.max_drawdown(),
            "volatility": self.volatility(),
            "downside_risk": self.downside_risk(),
            "var_5": self.var(),
            "cvar_5": self.cvar(),
            "tail_ratio": self.tail_ratio(),
            # Risk-adjusted
            "sharpe": self.sharpe(),
            "sortino": self.sortino(),
            "calmar": self.calmar(),
            "omega": self.omega(),
            "stability": self.stability(),
            # Market (if benchmark provided)
            "alpha": self.alpha(),
            "beta": self.beta(),
            "capture": self.capture(),
            "information_ratio": self.information_ratio(),
        }

    def to_frame(self) -> pd.DataFrame:
        """
        Return summary metrics as a single-row DataFrame.

        Returns
        -------
        pd.DataFrame
            DataFrame with one row and metrics as columns.
        """
        return pd.DataFrame([self.summary()])


def analyze(
    returns: Returns1D,
    benchmark: Returns1D | None = None,
    *,
    risk_free: float = 0.0,
    period: PeriodType = DAILY,
    metrics: list[str] | None = None,
) -> dict[str, float]:
    """
    One-shot analysis of returns.

    This is a convenience function that creates a Portfolio and
    returns the requested metrics.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns, noncumulative.
    benchmark : pd.Series or np.ndarray, optional
        Benchmark returns for relative metrics.
    risk_free : float, optional
        Risk-free rate. Default is 0.
    period : str, optional
        Periodicity of returns. Default is 'daily'.
    metrics : list of str, optional
        List of metrics to calculate. If None, calculates all available.

    Returns
    -------
    dict
        Dictionary of metric names to values.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.random.normal(0.001, 0.02, 252)
    >>> analyze(returns, metrics=['sharpe', 'max_drawdown', 'total_return'])
    {'sharpe': 0.85, 'max_drawdown': -0.15, 'total_return': 0.12}
    """
    pf = Portfolio(returns, benchmark=benchmark, risk_free=risk_free, period=period)

    if metrics is None:
        return pf.summary()

    result = {}
    summary = pf.summary()
    for m in metrics:
        if m in summary:
            result[m] = summary[m]
        elif hasattr(pf, m):
            result[m] = getattr(pf, m)()
        else:
            raise ValueError(f"Unknown metric: {m}")

    return result


__all__ = ["Portfolio", "analyze"]
