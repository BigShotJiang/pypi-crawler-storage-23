"""Internal utility functions for kepler.metric.

This module provides:
- NaN-aware statistical functions
- Rolling window utilities
- Series alignment utilities
"""

from .nanfuncs import (
    nanmean,
    nanstd,
    nansum,
    nanmax,
    nanmin,
    nanargmax,
    nanargmin,
)

from .rolling import (
    roll,
    up,
    down,
    rolling_window,
)

from .alignment import (
    flatten,
    to_pandas,
    adjust_returns,
    aligned_series,
)

__all__ = [
    # NaN functions
    "nanmean",
    "nanstd",
    "nansum",
    "nanmax",
    "nanmin",
    "nanargmax",
    "nanargmin",
    # Rolling utilities
    "roll",
    "up",
    "down",
    "rolling_window",
    # Alignment utilities
    "flatten",
    "to_pandas",
    "adjust_returns",
    "aligned_series",
]
