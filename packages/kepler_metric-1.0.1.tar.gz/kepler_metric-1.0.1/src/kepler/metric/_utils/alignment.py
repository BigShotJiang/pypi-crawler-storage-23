"""Alignment and conversion utilities for financial data.

This module provides functions for aligning series and converting
between different data structures.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import Numeric, ReturnsInput, Returns1D

__all__ = [
    "flatten",
    "to_pandas",
    "adjust_returns",
    "aligned_series",
]


def flatten(arr: Returns1D) -> NDArray[np.floating]:
    """
    Convert a pandas Series to a numpy array, or pass through arrays.

    Parameters
    ----------
    arr : pd.Series or np.ndarray
        Input data.

    Returns
    -------
    np.ndarray
        Numpy array view of the input.
    """
    return arr if not isinstance(arr, pd.Series) else arr.values


def to_pandas(ob: ReturnsInput) -> pd.Series | pd.DataFrame:
    """
    Convert an array-like to a pandas object.

    Parameters
    ----------
    ob : array-like
        The object to convert.

    Returns
    -------
    pd.Series or pd.DataFrame
        The correct structure based on the dimensionality of the data.

    Raises
    ------
    ValueError
        If array has more than 2 dimensions.
    """
    if isinstance(ob, pd.Series | pd.DataFrame):
        return ob

    if ob.ndim == 1:
        return pd.Series(ob)
    elif ob.ndim == 2:
        return pd.DataFrame(ob)
    else:
        raise ValueError("Cannot convert array of dim > 2 to a pandas structure")


def adjust_returns(
    returns: ReturnsInput,
    adjustment_factor: Numeric | pd.Series | NDArray[np.floating],
) -> ReturnsInput:
    """
    Adjust returns by subtracting an adjustment factor.

    Optimizes for the case of adjustment_factor being 0 by returning
    `returns` itself, not a copy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Returns to adjust.
    adjustment_factor : float, int, pd.Series, or np.ndarray
        Factor to subtract from returns (e.g., risk-free rate).

    Returns
    -------
    pd.Series, pd.DataFrame, or np.ndarray
        Adjusted returns (same type as input).
    """
    if isinstance(adjustment_factor, float | int) and adjustment_factor == 0:
        return returns
    return returns - adjustment_factor


def aligned_series(
    *many_series: Returns1D,
) -> tuple[Returns1D, ...]:
    """
    Align multiple series by their indices.

    Return a new tuple of series containing the data in the input series,
    but with their indices aligned. NaNs will be filled in for missing values.

    Parameters
    ----------
    *many_series
        The series to align.

    Returns
    -------
    tuple of array-like
        Aligned series. If all inputs are ndarrays of the same length,
        they are returned unchanged.
    """
    head = many_series[0]
    tail = many_series[1:]
    n = len(head)

    if isinstance(head, np.ndarray) and all(
        len(s) == n and isinstance(s, np.ndarray) for s in tail
    ):
        # Optimization: ndarrays of the same length are already aligned
        return many_series

    # DataFrame has no ``itervalues``
    return tuple(
        v for _, v in pd.concat(map(to_pandas, many_series), axis=1).items()
    )
