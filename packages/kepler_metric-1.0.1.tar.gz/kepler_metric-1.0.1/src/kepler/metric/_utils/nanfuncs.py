"""NaN-aware statistical functions.

This module provides NaN-aware statistical functions that use bottleneck
when available for better performance, falling back to numpy otherwise.
"""

from __future__ import annotations

from functools import wraps
from typing import overload

import numpy as np
from numpy.typing import NDArray

__all__ = [
    "nanmean",
    "nanstd",
    "nansum",
    "nanmax",
    "nanmin",
    "nanargmax",
    "nanargmin",
]

try:
    import bottleneck as bn

    HAS_BOTTLENECK = True

    def _wrap_function(f):
        """Wrap bottleneck function to support 'out' parameter."""

        @wraps(f)
        def wrapped(*args, **kwargs):
            out = kwargs.pop("out", None)
            data = f(*args, **kwargs)
            if out is None:
                out = data
            else:
                out[()] = data
            return out

        return wrapped

    nanmean = _wrap_function(bn.nanmean)
    nanstd = _wrap_function(bn.nanstd)
    nansum = _wrap_function(bn.nansum)
    nanmax = _wrap_function(bn.nanmax)
    nanmin = _wrap_function(bn.nanmin)
    nanargmax = _wrap_function(bn.nanargmax)
    nanargmin = _wrap_function(bn.nanargmin)

except ImportError:
    HAS_BOTTLENECK = False
    # Fallback to numpy
    nanmean = np.nanmean
    nanstd = np.nanstd
    nansum = np.nansum
    nanmax = np.nanmax
    nanmin = np.nanmin
    nanargmax = np.nanargmax
    nanargmin = np.nanargmin
