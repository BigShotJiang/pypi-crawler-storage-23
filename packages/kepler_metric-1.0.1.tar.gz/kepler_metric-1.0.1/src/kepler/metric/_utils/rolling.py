"""Rolling window utilities for financial metrics.

This module provides functions for calculating statistics over
rolling time windows.
"""

from __future__ import annotations

from typing import Callable

import numpy as np
from numpy.lib.stride_tricks import as_strided
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import Returns1D

__all__ = [
    "roll",
    "up",
    "down",
    "rolling_window",
    "_roll_ndarray",
    "_roll_pandas",
]


def roll(
    *args: Returns1D,
    function: Callable,
    window: int,
    **kwargs,
) -> pd.Series | NDArray[np.floating]:
    """
    Calculate a given statistic across a rolling time period.

    Parameters
    ----------
    *args : pd.Series or np.ndarray
        Returns data to pass to the function.
        Maximum 2 return sets supported.
    function : Callable
        The function to run for each rolling window.
    window : int
        The number of periods included in each calculation.
    **kwargs
        Additional keyword arguments passed to the function.

    Returns
    -------
    pd.Series or np.ndarray
        Rolling statistics. Type depends on input:
        - ndarray input -> ndarray output
        - Series input -> Series output

    Raises
    ------
    ValueError
        If more than 2 return sets are passed, or if the two
        return sets are not the same type.
    """
    if len(args) > 2:
        raise ValueError("Cannot pass more than 2 return sets")

    if len(args) == 2:
        if not isinstance(args[0], type(args[1])):
            raise ValueError("The two returns arguments are not the same.")

    if isinstance(args[0], np.ndarray):
        return _roll_ndarray(function, window, *args, **kwargs)
    return _roll_pandas(function, window, *args, **kwargs)


def up(
    returns: pd.Series,
    factor_returns: pd.Series,
    *,
    function: Callable,
    **kwargs,
):
    """
    Calculate a statistic filtering only positive factor return periods.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Benchmark return to compare returns against.
    function : Callable
        The function to run on filtered data.
    **kwargs
        Additional keyword arguments passed to the function.

    Returns
    -------
    Same as the return of the function
    """
    returns = returns[factor_returns > 0]
    factor_returns = factor_returns[factor_returns > 0]
    return function(returns, factor_returns, **kwargs)


def down(
    returns: pd.Series,
    factor_returns: pd.Series,
    *,
    function: Callable,
    **kwargs,
):
    """
    Calculate a statistic filtering only negative factor return periods.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
    factor_returns : pd.Series or np.ndarray
        Benchmark return to compare returns against.
    function : Callable
        The function to run on filtered data.
    **kwargs
        Additional keyword arguments passed to the function.

    Returns
    -------
    Same as the return of the function
    """
    returns = returns[factor_returns < 0]
    factor_returns = factor_returns[factor_returns < 0]
    return function(returns, factor_returns, **kwargs)


def _roll_ndarray(
    func: Callable,
    window: int,
    *args: NDArray[np.floating],
    **kwargs,
) -> NDArray[np.floating]:
    """Rolling calculation for numpy arrays."""
    data = []
    for i in range(window, len(args[0]) + 1):
        rets = [s[i - window : i] for s in args]
        data.append(func(*rets, **kwargs))
    return np.array(data)


def _roll_pandas(
    func: Callable,
    window: int,
    *args: pd.Series,
    **kwargs,
) -> pd.Series:
    """Rolling calculation for pandas Series."""
    data = {}
    index_values = []
    for i in range(window, len(args[0]) + 1):
        rets = [s.iloc[i - window : i] for s in args]
        index_value = args[0].index[i - 1]
        index_values.append(index_value)
        data[index_value] = func(*rets, **kwargs)
    return pd.Series(data, index=type(args[0].index)(index_values), dtype=np.float64)


def rolling_window(
    array: NDArray[np.floating],
    length: int,
    *,
    mutable: bool = False,
) -> NDArray[np.floating]:
    """
    Restride an array into rolling windows.

    Converts an array of shape (X_0, ... X_N) into an array of shape
    (length, X_0 - length + 1, ... X_N), where each slice at index i
    along the first axis is equivalent to array[length * i:length * (i + 1)].

    Parameters
    ----------
    array : np.ndarray
        The base array.
    length : int
        Length of the synthetic first axis to generate.
    mutable : bool, optional
        Return a mutable array? The returned array shares the same memory as
        the input array. Default is False.

    Returns
    -------
    np.ndarray
        View of the array with rolling windows.

    Raises
    ------
    ValueError
        If length is 0.
    IndexError
        If array is scalar or shorter than the window length.

    Examples
    --------
    >>> import numpy as np
    >>> a = np.arange(25).reshape(5, 5)
    >>> rolling_window(a, 2).shape
    (4, 2, 5)
    """
    if not length:
        raise ValueError("Can't have 0-length window")

    orig_shape = array.shape
    if not orig_shape:
        raise IndexError("Can't restride a scalar.")
    elif orig_shape[0] < length:
        raise IndexError(
            f"Can't restride array of shape {orig_shape} with "
            f"a window length of {length}"
        )

    num_windows = orig_shape[0] - length + 1
    new_shape = (num_windows, length) + orig_shape[1:]
    new_strides = (array.strides[0],) + array.strides

    out = as_strided(array, new_shape, new_strides)
    out.setflags(write=mutable)
    return out
