"""Return aggregation utilities."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd

from kepler.metric._types import PricesInput, PeriodType
from kepler.metric.periods import WEEKLY, MONTHLY, QUARTERLY, YEARLY
from .cumulative import cum_returns

__all__ = ["simple_returns", "aggregate_returns"]


def simple_returns(prices: PricesInput) -> PricesInput:
    """
    Compute simple returns from a timeseries of prices.

    Parameters
    ----------
    prices : pd.Series, pd.DataFrame or np.ndarray
        Prices of assets in wide-format, with assets as columns,
        and indexed by datetimes.

    Returns
    -------
    pd.Series, pd.DataFrame, or np.ndarray
        Returns of assets in wide-format, with assets as columns,
        and index coerced to be tz-aware.

    Examples
    --------
    >>> import pandas as pd
    >>> prices = pd.Series([100, 101, 99, 102])
    >>> simple_returns(prices)
    1    0.010000
    2   -0.019802
    3    0.030303
    dtype: float64
    """
    if isinstance(prices, pd.DataFrame | pd.Series):
        out = prices.pct_change().iloc[1:]
    else:
        # Assume np.ndarray
        out = np.diff(prices, axis=0)
        # Avoid division by zero warning
        with np.errstate(divide="ignore", invalid="ignore"):
            np.divide(out, prices[:-1], out=out)

    return out


def aggregate_returns(
    returns: pd.Series,
    convert_to: PeriodType,
) -> pd.Series:
    """
    Aggregate returns by week, month, quarter, or year.

    Parameters
    ----------
    returns : pd.Series
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    convert_to : str
        Can be 'weekly', 'monthly', 'quarterly', or 'yearly'.

    Returns
    -------
    pd.Series
        Aggregated returns.

    Raises
    ------
    ValueError
        If convert_to is not one of the allowed values.

    Examples
    --------
    >>> import pandas as pd
    >>> idx = pd.date_range('2020-01-01', periods=60, freq='D')
    >>> returns = pd.Series(0.001, index=idx)
    >>> monthly = aggregate_returns(returns, 'monthly')
    """
    def cumulate_returns(x: pd.Series) -> float:
        return cum_returns(x).iloc[-1]

    if convert_to == WEEKLY:
        grouping = [lambda x: x.year, lambda x: x.isocalendar()[1]]
    elif convert_to == MONTHLY:
        grouping = [lambda x: x.year, lambda x: x.month]
    elif convert_to == QUARTERLY:
        grouping = [lambda x: x.year, lambda x: int(math.ceil(x.month / 3.0))]
    elif convert_to == YEARLY:
        grouping = [lambda x: x.year]
    else:
        raise ValueError(
            f"convert_to must be {WEEKLY}, {MONTHLY}, {QUARTERLY} or {YEARLY}"
        )

    return returns.groupby(grouping).apply(cumulate_returns)
