"""Cumulative return calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import Numeric, ReturnsInput, OutType

__all__ = ["cum_returns", "cum_returns_final", "total_return"]


def cum_returns(
    returns: ReturnsInput,
    starting_value: Numeric = 0,
    *,
    out: OutType = None,
) -> ReturnsInput:
    """
    Compute cumulative returns from simple returns.

    Parameters
    ----------
    returns : pd.Series, np.ndarray, or pd.DataFrame
        Returns of the strategy as a percentage, noncumulative.
        - Time series with decimal returns.
        - Example::

            2015-07-16   -0.012143
            2015-07-17    0.045350
            2015-07-20    0.030957
            2015-07-21    0.004902

        - Also accepts two-dimensional data. In this case, each column is
          cumulated.
    starting_value : float, optional
        The starting returns. Default is 0.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    pd.Series, pd.DataFrame, or np.ndarray
        Series of cumulative returns. Same type as input.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01])
    >>> cum_returns(returns)
    array([ 0.01  ,  0.0302,  0.019898])
    """
    if len(returns) < 1:
        return returns.copy()

    nanmask = np.isnan(returns)
    if np.any(nanmask):
        returns = returns.copy()
        returns[nanmask] = 0

    allocated_output = out is None
    if allocated_output:
        out = np.empty_like(returns)

    np.add(returns, 1, out=out)
    out.cumprod(axis=0, out=out)

    if starting_value == 0:
        np.subtract(out, 1, out=out)
    else:
        np.multiply(out, starting_value, out=out)

    if allocated_output:
        if returns.ndim == 1 and isinstance(returns, pd.Series):
            out = pd.Series(out, index=returns.index)
        elif isinstance(returns, pd.DataFrame):
            out = pd.DataFrame(out, index=returns.index, columns=returns.columns)

    return out


def cum_returns_final(
    returns: ReturnsInput,
    starting_value: Numeric = 0,
) -> float | pd.Series | NDArray[np.floating]:
    """
    Compute total returns from simple returns.

    Parameters
    ----------
    returns : pd.DataFrame, pd.Series, or np.ndarray
        Noncumulative simple returns of one or more timeseries.
    starting_value : float, optional
        The starting returns. Default is 0.

    Returns
    -------
    float, pd.Series, or np.ndarray
        If input is 1-dimensional (a Series or 1D numpy array), the result is a
        scalar. If input is 2-dimensional (a DataFrame or 2D numpy array), the
        result is a 1D array containing cumulative returns for each column.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01])
    >>> cum_returns_final(returns)
    0.019898...
    """
    if len(returns) == 0:
        return np.nan

    if isinstance(returns, pd.DataFrame):
        result = (returns + 1).prod()
    else:
        result = np.nanprod(returns + 1, axis=0)

    if starting_value == 0:
        result -= 1
    else:
        result *= starting_value

    return result


# Alias for better naming
total_return = cum_returns_final
