"""Return metrics for financial analysis.

This module provides functions for calculating various return metrics:
- Cumulative returns
- Annual returns / CAGR
- Aggregated returns (weekly, monthly, yearly)
- Simple returns from prices
"""

from .cumulative import cum_returns, cum_returns_final, total_return
from .annual import annualized_return, annual_return, cagr, annualization_factor
from .aggregation import simple_returns, aggregate_returns

__all__ = [
    # Cumulative
    "cum_returns",
    "total_return",
    "cum_returns_final",
    # Annual
    "annualized_return",
    "annual_return",
    "cagr",
    "annualization_factor",
    # Aggregation
    "simple_returns",
    "aggregate_returns",
]
