"""Annual return calculations and annualization utilities."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import PeriodType, Returns1D
from kepler.metric.periods import (
    DAILY,
    ANNUALIZATION_FACTORS,
)
from .cumulative import cum_returns_final

__all__ = ["annualized_return", "annual_return", "cagr", "annualization_factor"]


def annualization_factor(
    period: PeriodType,
    annualization: int | None,
) -> int:
    """
    Return annualization factor from the period entered or a custom value.

    Parameters
    ----------
    period : str
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Allowed values are:
        - 'daily': 252
        - 'weekly': 52
        - 'monthly': 12
        - 'quarterly': 4
        - 'yearly': 1
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.

    Returns
    -------
    int
        The annualization factor.

    Raises
    ------
    ValueError
        If period is not recognized and annualization is not provided.

    Examples
    --------
    >>> annualization_factor('daily', None)
    252
    >>> annualization_factor('monthly', None)
    12
    >>> annualization_factor('daily', 365)
    365
    """
    if annualization is None:
        try:
            factor = ANNUALIZATION_FACTORS[period]
        except KeyError:
            raise ValueError(
                f"Period cannot be '{period}'. "
                f"Can be '{', '.join(ANNUALIZATION_FACTORS.keys())}'."
            )
    else:
        factor = annualization
    return factor


def annual_return(
    returns: Returns1D,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
) -> float:
    """
    Determine the mean annual growth rate of returns.

    This is equivalent to the compound annual growth rate (CAGR).

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Periodic returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.

    Returns
    -------
    float
        Annual return rate.

    See Also
    --------
    cagr : Alias for this function.

    Examples
    --------
    >>> import pandas as pd
    >>> returns = pd.Series([0.01, 0.02, -0.01])
    >>> annual_return(returns, period='daily')  # doctest: +SKIP
    """
    if len(returns) < 1:
        return np.nan

    ann_factor = annualization_factor(period, annualization)
    num_years = len(returns) / ann_factor

    # Pass array to ensure index -1 looks up successfully.
    ending_value = cum_returns_final(returns, starting_value=1)

    return ending_value ** (1 / num_years) - 1


def cagr(
    returns: Returns1D,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
) -> float:
    """
    Compute compound annual growth rate.

    This is an alias for :func:`~kepler.metric.returns.annual_return`.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.

    Returns
    -------
    float
        Compound annual growth rate.

    See Also
    --------
    annual_return : The underlying function.
    """
    return annual_return(returns, period=period, annualization=annualization)


# Alias for backward compatibility
annualized_return = annual_return
