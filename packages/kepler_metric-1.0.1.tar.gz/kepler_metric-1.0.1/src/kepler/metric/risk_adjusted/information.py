"""Information ratio calculation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import PeriodType, Returns1D
from kepler.metric.periods import DAILY
from kepler.metric.returns import annualization_factor

__all__ = ["information_ratio"]


def information_ratio(
    returns: Returns1D,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
) -> float | pd.Series:
    """
    Calculate the Information Ratio of a strategy.

    The Information Ratio measures the risk-adjusted excess return
    of a strategy relative to its tracking error.

    Parameters
    ----------
    returns : pd.Series or np.ndarray
        Excess returns (strategy returns - benchmark returns).
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    period : str, optional
        Periodicity of returns. Default is 'daily'.
        Options: 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.

    Returns
    -------
    float or pd.Series
        The Information Ratio value.

    Note
    ----
    IR = (Mean Excess Return * Annualization Factor) /
         (Std Excess Return * sqrt(Annualization Factor))
       = Mean Excess Return / Std Excess Return * sqrt(Annualization Factor)

    See Also
    --------
    sharpe_ratio : Risk-adjusted return relative to risk-free rate.
    excess_sharpe : Ratio of excess returns to tracking error.

    Examples
    --------
    >>> import numpy as np
    >>> excess_returns = np.array([0.005, 0.01, -0.005, 0.015, -0.01])
    >>> information_ratio(excess_returns)
    0.4216...
    """
    if len(returns) < 2:
        if isinstance(returns, pd.DataFrame):
            return pd.Series([np.nan] * len(returns.columns), index=returns.columns)
        return np.nan

    ann_factor = annualization_factor(period, annualization)

    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns[col].dropna()
            if len(col_returns) < 2:
                result[col] = np.nan
            else:
                mean_excess = col_returns.mean()
                std_excess = col_returns.std(ddof=1)
                # Avoid division by zero
                if std_excess == 0:
                    result[col] = np.nan
                else:
                    # BUG FIX: Use ann_factor (local variable) instead of annualization_factor (function)
                    result[col] = (mean_excess * ann_factor) / (std_excess * np.sqrt(ann_factor))
        return result
    else:
        # Handle Series/array input
        if isinstance(returns, pd.Series):
            returns = returns.dropna()

        mean_excess_return = np.nanmean(returns, axis=0)
        std_excess_return = np.nanstd(returns, ddof=1, axis=0)

        # Avoid division by zero
        if std_excess_return == 0:
            return np.nan

        # BUG FIX: Use ann_factor (local variable) instead of annualization_factor (function)
        # Original buggy code was:
        # ir = (mean_excess_return * annualization_factor) / (std_excess_return * np.sqrt(ann_factor))
        ir = (mean_excess_return * ann_factor) / (std_excess_return * np.sqrt(ann_factor))

        return float(ir) if np.ndim(returns) == 1 else pd.Series(ir)
