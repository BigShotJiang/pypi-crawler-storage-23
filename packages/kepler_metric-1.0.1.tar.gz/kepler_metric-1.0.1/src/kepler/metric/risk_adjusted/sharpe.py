"""Sharpe ratio calculations."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import PeriodType, ReturnsInput, RiskFreeType, OutType
from kepler.metric._utils import nanmean, nanstd, adjust_returns
from kepler.metric.periods import DAILY
from kepler.metric.returns import annualization_factor

__all__ = ["sharpe", "excess_sharpe"]


def sharpe(
    returns: ReturnsInput,
    risk_free: RiskFreeType = 0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    out: OutType = None,
) -> float | pd.Series:
    """
    Determine the Sharpe ratio of a strategy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    risk_free : int, float, pd.Series, or np.ndarray
        Constant daily risk-free return throughout the period.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    float or pd.Series
        Sharpe ratio. Returns a Series for DataFrame input.
        Returns nan if insufficient length of returns or if adjusted returns are 0.

    See Also
    --------
    sortino_ratio : Uses downside deviation instead of standard deviation.
    excess_sharpe : Ratio of excess returns to tracking error.

    Note
    ----
    See https://en.wikipedia.org/wiki/Sharpe_ratio for more details.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> sharpe(returns)
    0.5299...
    """
    allocated_output = out is None
    if allocated_output:
        out = np.empty(returns.shape[1:])

    return_1d = returns.ndim == 1

    if len(returns) < 2:
        out[()] = np.nan
        if return_1d:
            out = out.item()
        return out

    returns_risk_adj = np.asanyarray(adjust_returns(returns, risk_free))
    ann_factor = annualization_factor(period, annualization)

    # Handle division by zero
    std_returns = nanstd(returns_risk_adj, ddof=1, axis=0)
    mean_returns = nanmean(returns_risk_adj, axis=0)

    # Avoid division by zero warning
    with np.errstate(divide="ignore", invalid="ignore"):
        np.multiply(
            np.divide(
                mean_returns,
                std_returns,
                out=out,
            ),
            np.sqrt(ann_factor),
            out=out,
        )

    if return_1d:
        out = out.item()
    elif allocated_output and isinstance(returns, pd.DataFrame):
        out = pd.Series(out, index=returns.columns)

    return out


def excess_sharpe(
    returns: ReturnsInput,
    factor_returns: ReturnsInput,
    *,
    out: OutType = None,
) -> float | pd.Series:
    """
    Determine the Excess Sharpe of a strategy.

    The Excess Sharpe ratio is the ratio of excess returns over the
    benchmark to the tracking error.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    factor_returns : pd.Series, pd.DataFrame, or np.ndarray
        Benchmark return to compare returns against.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    float or pd.Series
        Excess Sharpe ratio. Returns a Series for DataFrame input.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> factor = np.array([0.005, 0.015, -0.005, 0.02, -0.01])
    >>> excess_sharpe(returns, factor)
    0.3162...
    """
    allocated_output = out is None
    if allocated_output:
        out = np.empty(returns.shape[1:])

    returns_1d = returns.ndim == 1

    if len(returns) < 2:
        out[()] = np.nan
        if returns_1d:
            out = out.item()
        return out

    excess_returns = adjust_returns(returns, factor_returns)

    # Avoid division by zero warning
    with np.errstate(divide="ignore", invalid="ignore"):
        np.divide(
            nanmean(excess_returns, axis=0),
            nanstd(excess_returns, ddof=1, axis=0),
            out=out,
        )

    if returns_1d:
        out = out.item()
    elif allocated_output and isinstance(returns, pd.DataFrame):
        out = pd.Series(out, index=returns.columns)

    return out
