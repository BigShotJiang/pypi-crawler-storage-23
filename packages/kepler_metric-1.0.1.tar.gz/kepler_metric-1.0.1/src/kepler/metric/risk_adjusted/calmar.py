"""Calmar ratio calculation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import PeriodType, ReturnsInput
from kepler.metric.periods import DAILY
from kepler.metric.returns import annual_return
from kepler.metric.risk import max_drawdown

__all__ = ["calmar"]


def calmar(
    returns: ReturnsInput,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
) -> float | pd.Series:
    """
    Determine the Calmar ratio, or drawdown ratio, of a strategy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.

    Returns
    -------
    float or pd.Series
        Calmar ratio (drawdown ratio). Returns np.nan if there is no
        calmar ratio (e.g., max drawdown is 0). Returns a Series for
        DataFrame input.

    See Also
    --------
    max_drawdown : Maximum drawdown of a strategy.
    annual_return : Annual return rate.

    Note
    ----
    See https://en.wikipedia.org/wiki/Calmar_ratio for more details.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> calmar(returns)
    nan
    """
    max_dd = max_drawdown(returns=returns)

    # Handle both scalar and Series cases
    if isinstance(max_dd, pd.Series):
        # Return a Series for DataFrame input
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            if max_dd[col] < 0:
                annual_ret = annual_return(
                    returns=returns[col],
                    period=period,
                    annualization=annualization,
                )
                result[col] = annual_ret / abs(max_dd[col])
            else:
                result[col] = np.nan

        # Check for infinity
        result = result.replace([np.inf, -np.inf], np.nan)
        return result
    else:
        # Scalar case for Series input
        if max_dd < 0:
            temp = annual_return(
                returns=returns,
                period=period,
                annualization=annualization,
            ) / abs(max_dd)
        else:
            return np.nan

        if np.isinf(temp):
            return np.nan

        return temp
