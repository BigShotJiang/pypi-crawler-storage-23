"""Sortino ratio calculation."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
import pandas as pd

from kepler.metric._types import PeriodType, ReturnsInput, RequiredReturnType, OutType
from kepler.metric._utils import nanmean, adjust_returns
from kepler.metric.periods import DAILY
from kepler.metric.returns import annualization_factor
from kepler.metric.risk import downside_risk

__all__ = ["sortino"]


def sortino(
    returns: ReturnsInput,
    required_return: RequiredReturnType = 0,
    period: PeriodType = DAILY,
    *,
    annualization: int | None = None,
    _downside_risk: float | None = None,
    out: OutType = None,
) -> float | pd.Series:
    """
    Determine the Sortino ratio of a strategy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    required_return : float or pd.Series, optional
        Minimum acceptable return. Default is 0.
    period : str, optional
        Defines the periodicity of the 'returns' data for purposes of
        annualizing. Value ignored if `annualization` parameter is specified.
        Defaults are:
        - 'monthly': 12
        - 'weekly': 52
        - 'daily': 252
    annualization : int, optional
        Used to suppress default values available in `period` to convert
        returns into annual returns. Value should be the annual frequency of
        `returns`.
    _downside_risk : float, optional
        The downside risk of the given inputs, if known. It will be calculated
        if not provided.
    out : array-like, optional
        Array to use as output buffer. If not passed, a new array will be created.

    Returns
    -------
    float or pd.Series
        Sortino ratio. Returns a Series for DataFrame input.

    See Also
    --------
    sharpe_ratio : Uses standard deviation instead of downside deviation.
    downside_risk : The underlying downside risk calculation.

    Note
    ----
    See `<https://www.sunrisecapital.com/wp-content/uploads/2014/06/Futures_
    Mag_Sortino_0213.pdf>`__ for more details.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> sortino(returns)
    1.3650...
    """
    allocated_output = out is None
    if allocated_output:
        out = np.empty(returns.shape[1:])

    return_1d = returns.ndim == 1

    if len(returns) < 2:
        out[()] = np.nan
        if return_1d:
            out = out.item()
        return out

    adj_returns = np.asanyarray(adjust_returns(returns, required_return))

    ann_factor = annualization_factor(period, annualization)

    average_annual_return = nanmean(adj_returns, axis=0) * ann_factor
    annualized_downside_risk = (
        _downside_risk
        if _downside_risk is not None
        else downside_risk(returns, required_return, period, annualization=annualization)
    )

    # Avoid division by zero warning
    with np.errstate(divide="ignore", invalid="ignore"):
        np.divide(average_annual_return, annualized_downside_risk, out=out)

    if return_1d:
        out = out.item()
    elif isinstance(returns, pd.DataFrame):
        out = pd.Series(out, index=returns.columns)

    return out
