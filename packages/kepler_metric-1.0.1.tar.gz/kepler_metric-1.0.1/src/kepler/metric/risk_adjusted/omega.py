"""Omega ratio calculation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kepler.metric._types import ReturnsInput, Numeric
from kepler.metric.periods import APPROX_BDAYS_PER_YEAR

__all__ = ["omega"]


def omega(
    returns: ReturnsInput,
    risk_free: Numeric = 0.0,
    required_return: Numeric = 0.0,
    *,
    annualization: int = APPROX_BDAYS_PER_YEAR,
) -> float | pd.Series:
    """
    Determine the Omega ratio of a strategy.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.
    risk_free : int or float
        Constant risk-free return throughout the period.
    required_return : float, optional
        Minimum acceptance return of the investor. Threshold over which to
        consider positive vs. negative returns. It will be converted to a
        value appropriate for the period of the returns. E.g., an annual
        minimum acceptable return of 100 will translate to a minimum
        acceptable return of 0.018.
    annualization : int, optional
        Factor used to convert the required_return into a daily
        value. Enter 1 if no time period conversion is necessary.
        Default is 252 (daily).

    Returns
    -------
    float or pd.Series
        Omega ratio. Returns a Series for DataFrame input.

    See Also
    --------
    sortino_ratio : Uses downside deviation instead of positive/negative split.
    sharpe_ratio : Uses mean excess return over standard deviation.

    Note
    ----
    See https://en.wikipedia.org/wiki/Omega_ratio for more details.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> omega(returns, required_return=0.0)
    1.2
    """
    if len(returns) < 2:
        if isinstance(returns, pd.DataFrame):
            return pd.Series([np.nan] * len(returns.columns), index=returns.columns)
        return np.nan

    if annualization == 1:
        return_threshold = required_return
    elif required_return <= -1:
        if isinstance(returns, pd.DataFrame):
            return pd.Series([np.nan] * len(returns.columns), index=returns.columns)
        return np.nan
    else:
        return_threshold = (1 + required_return) ** (1.0 / annualization) - 1

    returns_less_thresh = returns - risk_free - return_threshold

    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns_less_thresh[col]
            numer = sum(col_returns[col_returns > 0.0])
            denom = -1.0 * sum(col_returns[col_returns < 0.0])
            result[col] = numer / denom if denom > 0.0 else np.nan
        return result
    else:
        # Handle Series/array input
        if isinstance(returns_less_thresh, pd.Series):
            numer = sum(returns_less_thresh[returns_less_thresh > 0.0])
            denom = -1.0 * sum(returns_less_thresh[returns_less_thresh < 0.0])
        else:
            numer = np.sum(returns_less_thresh[returns_less_thresh > 0.0])
            denom = -1.0 * np.sum(returns_less_thresh[returns_less_thresh < 0.0])

        if denom > 0.0:
            return numer / denom
        else:
            return np.nan
