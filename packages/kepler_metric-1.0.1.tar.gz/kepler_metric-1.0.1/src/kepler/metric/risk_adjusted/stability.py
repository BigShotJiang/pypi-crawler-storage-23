"""Stability of time series calculation."""

from __future__ import annotations

import numpy as np
from scipy import stats
import pandas as pd

from kepler.metric._types import ReturnsInput

__all__ = ["stability"]


def stability(returns: ReturnsInput) -> float | pd.Series:
    """
    Determine R-squared of a linear fit to the cumulative log returns.

    Computes an ordinary least squares linear fit, and returns R-squared.

    Parameters
    ----------
    returns : pd.Series, pd.DataFrame, or np.ndarray
        Daily returns of the strategy, noncumulative.
        - See full explanation in :func:`~kepler.metric.returns.cum_returns`.

    Returns
    -------
    float or pd.Series
        R-squared value. Returns a Series for DataFrame input with column
        names preserved.

    Examples
    --------
    >>> import numpy as np
    >>> returns = np.array([0.01, 0.02, -0.01, 0.03, -0.02])
    >>> stability(returns)
    0.1245...
    """
    if len(returns) < 2:
        if isinstance(returns, pd.DataFrame):
            return pd.Series([np.nan] * len(returns.columns), index=returns.columns)
        return np.nan

    # Handle DataFrame input
    if isinstance(returns, pd.DataFrame):
        result = pd.Series(index=returns.columns, dtype=float)
        for col in returns.columns:
            col_returns = returns[col].dropna()
            if len(col_returns) < 2:
                result[col] = np.nan
            else:
                cum_log_returns = np.log1p(col_returns).cumsum()
                rhat = stats.linregress(np.arange(len(cum_log_returns)), cum_log_returns)[2]
                result[col] = rhat**2
        return result
    else:
        # Handle Series/array input
        returns = np.asanyarray(returns)
        returns = returns[~np.isnan(returns)]

        if len(returns) < 2:
            return np.nan

        cum_log_returns = np.log1p(returns).cumsum()
        rhat = stats.linregress(np.arange(len(cum_log_returns)), cum_log_returns)[2]

        return rhat**2
