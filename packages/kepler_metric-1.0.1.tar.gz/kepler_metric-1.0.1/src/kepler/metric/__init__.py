"""
kepler.metric - Financial risk and performance metrics library.

Usage:
    from kepler.metric import sharpe, max_drawdown, total_return
    from kepler.metric import Portfolio, analyze
"""

from __future__ import annotations

__version__ = "1.0.0"

# Period constants
from kepler.metric.periods import (
    DAILY,
    WEEKLY,
    MONTHLY,
    QUARTERLY,
    YEARLY,
)

# ===== Returns =====
from kepler.metric.returns import (
    cum_returns,
    cum_returns_final,
    total_return,
    annual_return,
    cagr,
    simple_returns,
    aggregate_returns,
)

# ===== Risk =====
from kepler.metric.risk import (
    max_drawdown,
    volatility,
    downside_risk,
    var,
    cvar,
    tail_ratio,
    gpd_risk_estimates,
    gpd_risk_estimates_aligned,
)

# ===== Risk-adjusted =====
from kepler.metric.risk_adjusted import (
    sharpe,
    excess_sharpe,
    sortino,
    calmar,
    omega,
    information_ratio,
    stability,
)

# ===== Market =====
from kepler.metric.market import (
    alpha,
    alpha_aligned,
    beta,
    beta_aligned,
    alpha_beta,
    alpha_beta_aligned,
    up_alpha_beta,
    down_alpha_beta,
    capture,
    up_capture,
    down_capture,
    up_down_capture,
    beta_fragility_heuristic,
    beta_fragility_heuristic_aligned,
)

# ===== Portfolio =====
from kepler.metric.portfolio import Portfolio, analyze

# ===== Rolling functions (from legacy stats.py) =====
from kepler.metric.stats import (
    roll_alpha_beta,
    roll_up_capture,
    roll_down_capture,
    roll_up_down_capture,
    roll_max_drawdown,
    roll_sharpe_ratio,
)

# ===== Aliases for test compatibility =====
# These are kept for internal test compatibility
cum_returns_final = total_return
annual_volatility = volatility
value_at_risk = var
conditional_value_at_risk = cvar
sharpe_ratio = sharpe
sortino_ratio = sortino
calmar_ratio = calmar
omega_ratio = omega
stability_of_timeseries = stability

__all__ = [
    # Version
    "__version__",
    # Periods
    "DAILY",
    "WEEKLY",
    "MONTHLY",
    "QUARTERLY",
    "YEARLY",
    # Returns
    "cum_returns",
    "total_return",
    "annual_return",
    "cagr",
    "simple_returns",
    "aggregate_returns",
    # Risk
    "max_drawdown",
    "volatility",
    "downside_risk",
    "var",
    "cvar",
    "tail_ratio",
    # Risk-adjusted
    "sharpe",
    "sortino",
    "calmar",
    "omega",
    "information_ratio",
    "stability",
    # Market
    "alpha",
    "beta",
    "alpha_beta",
    "capture",
    "up_capture",
    "down_capture",
    # Portfolio
    "Portfolio",
    "analyze",
]
