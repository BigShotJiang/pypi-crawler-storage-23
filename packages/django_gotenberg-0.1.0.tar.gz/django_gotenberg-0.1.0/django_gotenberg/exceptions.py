class RenderException(Exception):
    pass


class GotenbergException(RenderException):
    pass


class FileGatheringException(RenderException):
    pass
