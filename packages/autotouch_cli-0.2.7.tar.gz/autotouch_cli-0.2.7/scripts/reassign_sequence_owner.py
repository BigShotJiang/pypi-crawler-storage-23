#!/usr/bin/env python3
"""
Reassign a sequence to a new user and reassign all linked enrollments/tasks.

Usage:
  MONGODB_URI="mongodb+srv://..." MONGODB_DB_NAME="autotouch" \
    python scripts/reassign_sequence_owner.py \
      --sequence-id 69306412024a06cd51c47c95 \
      --new-user-id 690a6af437ce4ce7f1a3af23

Add --dry-run to see counts without modifying data.
"""

import argparse
import os
import sys
from datetime import datetime
from typing import Any, Dict, List

from bson import ObjectId
from pymongo import MongoClient


def coerce_object_id(value: str):
    try:
        return ObjectId(value)
    except Exception:
        return None


def match_type(new_id: str, sample_value: Any):
    """
    Keep the existing type where possible (ObjectId vs str) to avoid
    surprising downstream filters.
    """
    if isinstance(sample_value, ObjectId):
        oid = coerce_object_id(new_id)
        return oid if oid else new_id
    return new_id


def build_in_clause(value: str) -> Dict[str, List[Any]]:
    values: List[Any] = [value]
    oid = coerce_object_id(value)
    if oid:
        values.append(oid)
    return {"$in": values}


def main():
    parser = argparse.ArgumentParser(description="Reassign sequence owner and tasks")
    parser.add_argument("--sequence-id", required=True, help="Sequence _id (24-hex or string)")
    parser.add_argument("--new-user-id", required=True, help="Target user id for ownership/assignee")
    parser.add_argument("--dry-run", action="store_true", help="Report counts without writing")
    args = parser.parse_args()

    mongo_uri = os.getenv("MONGODB_URI")
    if not mongo_uri:
        sys.exit("MONGODB_URI is required")
    db_name = os.getenv("MONGODB_DB_NAME", "autotouch")

    client = MongoClient(mongo_uri)
    db = client[db_name]

    sequence_id = args.sequence_id
    new_user_id = args.new_user_id
    now = datetime.utcnow()

    # Fetch the sequence to capture org + current user type
    seq_query = {"$or": [{"_id": sequence_id}]}
    seq_oid = coerce_object_id(sequence_id)
    if seq_oid:
        seq_query["$or"].append({"_id": seq_oid})
    sequence = db.sequences.find_one(seq_query)
    if not sequence:
        sys.exit("Sequence not found")

    org_id = sequence.get("organization_id")
    new_user_for_sequence = match_type(new_user_id, sequence.get("user_id"))

    updates_applied = {}

    # Update sequence document
    seq_update = {
        "$set": {"user_id": new_user_for_sequence, "updated_at": now},
    }
    seq_filter = {"$or": [{"_id": sequence_id}], "organization_id": org_id}
    if seq_oid:
        seq_filter["$or"].append({"_id": seq_oid})
    if args.dry_run:
        updates_applied["sequences"] = db.sequences.count_documents(seq_filter)
    else:
        res = db.sequences.update_one(seq_filter, seq_update)
        updates_applied["sequences"] = res.modified_count

    # Update enrollments
    enrollment_filter: Dict[str, Any] = {
        "organization_id": org_id,
        "sequence_id": build_in_clause(sequence_id),
    }
    enrollment_sample = db.sequence_enrollments.find_one(enrollment_filter, {"user_id": 1})
    new_user_for_enrollments = match_type(new_user_id, enrollment_sample.get("user_id") if enrollment_sample else new_user_id)
    enrollment_update = {
        "$set": {"user_id": new_user_for_enrollments, "updated_at": now},
    }
    if args.dry_run:
        updates_applied["sequence_enrollments"] = db.sequence_enrollments.count_documents(enrollment_filter)
    else:
        res = db.sequence_enrollments.update_many(enrollment_filter, enrollment_update)
        updates_applied["sequence_enrollments"] = res.modified_count

    # Update tasks linked to the sequence
    task_filter: Dict[str, Any] = {
        "organization_id": org_id,
        "sequence_id": build_in_clause(sequence_id),
    }
    task_sample = db.task_queue.find_one(task_filter, {"assigned_to": 1})
    new_assignee = match_type(new_user_id, task_sample.get("assigned_to") if task_sample else new_user_id)
    task_update = {
        "$set": {"assigned_to": new_assignee, "updated_at": now},
    }
    if args.dry_run:
        updates_applied["task_queue"] = db.task_queue.count_documents(task_filter)
    else:
        res = db.task_queue.update_many(task_filter, task_update)
        updates_applied["task_queue"] = res.modified_count

    client.close()

    print("Done. Updates:")
    for k, v in updates_applied.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
