import pymongo
from bson import ObjectId

URI = "mongodb+srv://mongo_autotouch:autotouch@cluster1.dlvbh5h.mongodb.net/autotouch"

client = pymongo.MongoClient(URI, serverSelectionTimeoutMS=5000)
leads = client.autotouch.leads

sample_id = ObjectId("69162950907d606661aa36df")
doc = leads.find_one({"_id": sample_id})

print(doc)
