#!/usr/bin/env python3
"""Check if mode field exists in column config for debugging agent mode."""

import os
import sys
from pymongo import MongoClient
from bson import ObjectId
import json

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

def check_column_mode():
    # Connect to MongoDB
    client = MongoClient(os.getenv('MONGODB_URI', 'mongodb://localhost:27017'))
    db = client[os.getenv('MONGODB_DB_NAME', 'smart_table')]
    
    # Table and column to check
    table_id = "68409292003d77815e99ad5e"
    column_key = "pricing_6"
    
    print(f"Checking table {table_id} for column {column_key}...")
    
    try:
        # Find the table
        table = db.tables.find_one({'_id': ObjectId(table_id)})
        
        if not table:
            print(f"Table {table_id} not found!")
            return
        
        print(f"Found table: {table.get('name', 'Unnamed')}")
        
        # Find the column
        columns = table.get('columns', [])
        pricing_column = None
        
        for col in columns:
            if col.get('key') == column_key:
                pricing_column = col
                break
        
        if not pricing_column:
            print(f"Column {column_key} not found in table!")
            return
        
        print(f"\nColumn found: {pricing_column.get('label', 'Unnamed')}")
        print(f"Column ID: {pricing_column.get('id')}")
        print(f"Column kind: {pricing_column.get('kind')}")
        
        # Check config
        config = pricing_column.get('config', {})
        print(f"\nFull config:")
        print(json.dumps(config, indent=2))
        
        # Check mode specifically
        print(f"\nMode field analysis:")
        print(f"  - 'mode' in config: {'mode' in config}")
        print(f"  - Mode value: {config.get('mode', 'NOT FOUND')}")
        print(f"  - Mode type: {type(config.get('mode'))}")
        
        # Check if it's an enrichment column with gemini provider
        if config.get('provider') == 'gemini':
            print(f"\nThis is a Gemini enrichment column")
            print(f"Expected to use {'agent' if config.get('mode') == 'agent' else 'basic'} mode")
        
        # Also check in the columns collection directly
        print(f"\n--- Checking columns collection directly ---")
        column_doc = db.columns.find_one({'key': column_key, 'table_id': table_id})
        if column_doc:
            print("Column found in columns collection")
            col_config = column_doc.get('config', {})
            print(f"Config from columns collection:")
            print(json.dumps(col_config, indent=2))
            print(f"Mode in columns collection: {col_config.get('mode', 'NOT FOUND')}")
        else:
            print("Column NOT found in columns collection")
            
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        client.close()

if __name__ == "__main__":
    check_column_mode()