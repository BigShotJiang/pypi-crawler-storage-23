#!/usr/bin/env python3
"""
Fix lead.title after a bad CSV mapping (e.g., mapped location into title).

Reads a CSV export and updates MongoDB `leads` documents:
- lead `title` <- CSV `Person Title`
- lead `search_fields.lead_title` <- CSV `Person Title`

Matching strategy:
1) Prefer `_id` from the CSV `CRM Lead` JSON field (keys: existing_lead_id/lead_id/id/_id).
2) Fallback to matching by `linkedin_url` (CSV `Person Linkedin`) with an optional `organization_id` guard.

This script defaults to dry-run. Use --apply to write changes.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import re
import sys
from dataclasses import dataclass
from typing import Any, Iterable, Optional

from bson import ObjectId
import certifi
from pymongo import MongoClient, UpdateMany, UpdateOne


HEX24_RE = re.compile(r"^[0-9a-f]{24}$")


def _is_object_id_hex(value: Any) -> bool:
    return isinstance(value, str) and bool(HEX24_RE.match(value))


def _clean_str(value: Any) -> str:
    return ("" if value is None else str(value)).strip()


def _try_parse_json(value: str) -> Optional[dict]:
    value = value.strip()
    if not value:
        return None
    try:
        data = json.loads(value)
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def _extract_lead_id_from_crm_lead(crm_lead_raw: str) -> Optional[str]:
    data = _try_parse_json(crm_lead_raw)
    if not data:
        return None
    for key in ("existing_lead_id", "lead_id", "id", "_id"):
        val = data.get(key)
        if _is_object_id_hex(val):
            return val
    return None


@dataclass(frozen=True)
class TitleUpdate:
    lead_id: Optional[str]
    linkedin_url: Optional[str]
    new_title: str


def _iter_title_updates(csv_path: str) -> Iterable[TitleUpdate]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise RuntimeError("CSV appears to have no headers.")

        required = {"Person Title", "Person Linkedin", "CRM Lead"}
        missing = required.difference(set(reader.fieldnames))
        if missing:
            raise RuntimeError(f"CSV is missing required columns: {sorted(missing)}")

        for row in reader:
            new_title = _clean_str(row.get("Person Title"))
            if not new_title:
                # Unexpected given the export shape; skip rather than writing blanks.
                continue
            linkedin = _clean_str(row.get("Person Linkedin")) or None
            lead_id = _extract_lead_id_from_crm_lead(_clean_str(row.get("CRM Lead"))) or None
            yield TitleUpdate(lead_id=lead_id, linkedin_url=linkedin, new_title=new_title)


def _connect(uri: str, db_name: str):
    # Use certifi CA bundle because the runtime environment may not have
    # Atlas CA roots available via the system trust store.
    client = MongoClient(uri, serverSelectionTimeoutMS=10_000, tlsCAFile=certifi.where())
    return client[db_name]


def main() -> int:
    p = argparse.ArgumentParser(description="Fix lead.title using a CSV export column mapping.")
    p.add_argument("--csv", required=True, help="Path to the CSV export file.")
    p.add_argument("--uri", default=os.getenv("MONGODB_URI", ""), help="MongoDB connection string (or set MONGODB_URI).")
    p.add_argument("--db", default=os.getenv("MONGODB_DB_NAME", "autotouch"), help="MongoDB database name.")
    p.add_argument(
        "--org",
        default=os.getenv("ORGANIZATION_ID", ""),
        help="Optional organization_id guard for linkedin_url fallback updates (recommended).",
    )
    p.add_argument("--apply", action="store_true", help="Apply updates (default is dry-run).")
    p.add_argument("--limit", type=int, default=0, help="Optional limit for number of CSV rows to process.")
    args = p.parse_args()

    csv_path = args.csv
    if not os.path.exists(csv_path):
        print(f"CSV not found: {csv_path}", file=sys.stderr)
        return 2

    updates = []
    by_id = 0
    by_linkedin = 0
    skipped = 0
    seen_id = set()
    seen_linkedin = set()

    for i, upd in enumerate(_iter_title_updates(csv_path), start=1):
        if args.limit and i > args.limit:
            break
        if upd.lead_id:
            # De-dupe by lead id to avoid double-writes.
            if upd.lead_id in seen_id:
                skipped += 1
                continue
            seen_id.add(upd.lead_id)
            by_id += 1
        elif upd.linkedin_url:
            # For safety, only allow linkedin_url fallback when org scoping is provided.
            if not args.org:
                skipped += 1
                continue
            if upd.linkedin_url in seen_linkedin:
                skipped += 1
                continue
            seen_linkedin.add(upd.linkedin_url)
            by_linkedin += 1
        else:
            skipped += 1
            continue
        updates.append(upd)

    print("Parsed CSV title updates:")
    print(f"- total_rows_considered: {i if updates or skipped else 0}")
    print(f"- updates_total: {len(updates)}")
    print(f"- match_by_lead_id: {by_id}")
    print(f"- match_by_linkedin_url: {by_linkedin}")
    print(f"- skipped_dedup_or_missing_keys: {skipped}")
    if not args.org:
        print("- NOTE: linkedin_url fallback updates require --org (they were skipped for safety).")

    # Show a tiny sample of new titles (avoid dumping PII).
    sample = [u.new_title for u in updates[:5]]
    print(f"- sample_new_titles: {sample}")

    if not args.apply:
        print("Dry-run only (no writes). Re-run with --apply to update MongoDB.")
        return 0

    if not args.uri:
        print("Missing MongoDB URI (pass --uri or set MONGODB_URI).", file=sys.stderr)
        return 2

    db = _connect(args.uri, args.db)
    col = db.leads

    now = dt.datetime.now(dt.UTC)
    ops = []
    for u in updates:
        update_doc = {
            "$set": {
                "title": u.new_title,
                "search_fields.lead_title": u.new_title,
                "updated_at": now,
            }
        }

        if u.lead_id:
            ops.append(UpdateOne({"_id": ObjectId(u.lead_id)}, update_doc))
        else:
            # Fallback: linkedin_url match (optionally scoped to org).
            flt = {"linkedin_url": u.linkedin_url}
            if args.org:
                flt["organization_id"] = args.org
            ops.append(UpdateMany(flt, update_doc))

    if not ops:
        print("No updates to apply.")
        return 0

    # Bulk write in manageable chunks.
    total_modified = 0
    total_matched = 0
    chunk = 500
    for start in range(0, len(ops), chunk):
        batch = ops[start : start + chunk]
        res = col.bulk_write(batch, ordered=False)
        total_modified += int(res.modified_count or 0)
        total_matched += int(res.matched_count or 0)

    print("MongoDB update complete:")
    print(f"- matched: {total_matched}")
    print(f"- modified: {total_modified}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
