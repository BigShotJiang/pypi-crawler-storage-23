#!/usr/bin/env python3
"""
Create unique email constraint for leads deduplication.

This migration adds a compound unique index on (organization_id, email)
to prevent duplicate leads within organizations.

Usage:
    python scripts/migrations/20250119_create_leads_unique_email_index.py
"""

import asyncio
import os
import sys
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import DuplicateKeyError, OperationFailure
from datetime import datetime

# Add project root to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../'))

from apps.api.models import LEADS_COLLECTION


async def check_existing_duplicates(db):
    """Check for existing duplicate emails that would prevent index creation"""
    print("🔍 Checking for existing duplicate emails...")

    pipeline = [
        {"$group": {
            "_id": {"organization_id": "$organization_id", "email": "$email"},
            "count": {"$sum": 1},
            "docs": {"$push": {"id": "$_id", "created_at": "$created_at"}}
        }},
        {"$match": {"count": {"$gt": 1}}},
        {"$sort": {"count": -1}}
    ]

    duplicates = []
    async for doc in db[LEADS_COLLECTION].aggregate(pipeline):
        duplicates.append(doc)

    if duplicates:
        print(f"❌ Found {len(duplicates)} sets of duplicate emails:")
        for dup in duplicates[:5]:  # Show first 5
            email = dup["_id"]["email"]
            org_id = dup["_id"]["organization_id"]
            count = dup["count"]
            print(f"   - {email} (org: {org_id[:8]}...): {count} duplicates")

        if len(duplicates) > 5:
            print(f"   ... and {len(duplicates) - 5} more")

        return duplicates
    else:
        print("✅ No duplicate emails found - safe to create unique index")
        return []


async def cleanup_duplicates(db, duplicates):
    """Clean up duplicate leads by keeping the oldest one"""
    print(f"\n🧹 Cleaning up {len(duplicates)} sets of duplicates...")

    removed_count = 0
    for dup_set in duplicates:
        # Sort by created_at and keep the oldest (first) one
        docs = sorted(dup_set["docs"], key=lambda x: x.get("created_at", datetime.min))
        docs_to_remove = docs[1:]  # Remove all except the first (oldest)

        for doc in docs_to_remove:
            try:
                result = await db[LEADS_COLLECTION].delete_one({"_id": doc["id"]})
                if result.deleted_count > 0:
                    removed_count += 1
            except Exception as e:
                print(f"   ⚠️ Failed to remove duplicate {doc['id']}: {e}")

    print(f"✅ Removed {removed_count} duplicate leads")
    return removed_count


async def create_unique_index(db):
    """Create the unique email constraint"""
    print("\n📝 Creating unique index on (organization_id, email)...")

    try:
        # Create compound unique index
        index_name = await db[LEADS_COLLECTION].create_index([
            ("organization_id", 1),
            ("email", 1)
        ], unique=True, name="unique_org_email")

        print(f"✅ Successfully created unique index: {index_name}")
        return True

    except DuplicateKeyError as e:
        print(f"❌ Cannot create unique index due to remaining duplicates:")
        print(f"   Error: {e}")
        return False

    except OperationFailure as e:
        print(f"❌ Database operation failed:")
        print(f"   Error: {e}")
        return False


async def verify_index(db):
    """Verify the index was created successfully"""
    print("\n🔍 Verifying index creation...")

    indexes = await db[LEADS_COLLECTION].list_indexes().to_list(None)

    unique_email_index = None
    for index in indexes:
        if index.get("name") == "unique_org_email":
            unique_email_index = index
            break

    if unique_email_index:
        print("✅ Unique email index verified:")
        print(f"   Name: {unique_email_index['name']}")
        print(f"   Keys: {unique_email_index['key']}")
        print(f"   Unique: {unique_email_index.get('unique', False)}")
        return True
    else:
        print("❌ Unique email index not found")
        return False


async def test_constraint(db):
    """Test the constraint by attempting to insert a duplicate"""
    print("\n🧪 Testing duplicate prevention...")

    test_lead = {
        "first_name": "Test",
        "last_name": "User",
        "email": "test.constraint@example.com",
        "company_website": "https://example.com",
        "organization_id": "test_org_123",
        "created_by": "test_user",
        "created_at": datetime.utcnow(),
        "lead_source": "test"
    }

    try:
        # Insert first lead
        result1 = await db[LEADS_COLLECTION].insert_one(test_lead.copy())
        print(f"✅ First test lead inserted: {result1.inserted_id}")

        # Try to insert duplicate
        result2 = await db[LEADS_COLLECTION].insert_one(test_lead.copy())
        print(f"❌ Duplicate test lead was incorrectly allowed: {result2.inserted_id}")

        # Clean up
        await db[LEADS_COLLECTION].delete_many({"email": "test.constraint@example.com"})
        return False

    except DuplicateKeyError:
        print("✅ Duplicate insertion correctly prevented by constraint")

        # Clean up the first test lead
        await db[LEADS_COLLECTION].delete_many({"email": "test.constraint@example.com"})
        return True

    except Exception as e:
        print(f"❌ Unexpected error during constraint test: {e}")
        # Clean up
        await db[LEADS_COLLECTION].delete_many({"email": "test.constraint@example.com"})
        return False


async def run_migration():
    """Run the complete migration process"""
    print("🚀 Starting Leads Email Deduplication Migration")
    print("=" * 60)

    # Connect to database
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    mongodb_db = os.getenv('MONGODB_DB_NAME', 'smart_table')

    client = AsyncIOMotorClient(mongodb_uri)
    db = client[mongodb_db]

    try:
        # Step 1: Check for existing duplicates
        duplicates = await check_existing_duplicates(db)

        # Step 2: Clean up duplicates if found
        if duplicates:
            print(f"\n⚠️ Found {len(duplicates)} sets of duplicate emails")
            response = input("Do you want to automatically clean up duplicates? (y/N): ")

            if response.lower() == 'y':
                await cleanup_duplicates(db, duplicates)

                # Re-check for remaining duplicates
                remaining_duplicates = await check_existing_duplicates(db)
                if remaining_duplicates:
                    print("❌ Some duplicates remain - manual cleanup required")
                    return False
            else:
                print("❌ Cannot proceed with duplicates present")
                print("Please manually resolve duplicates and run migration again")
                return False

        # Step 3: Create unique index
        success = await create_unique_index(db)
        if not success:
            return False

        # Step 4: Verify index creation
        verified = await verify_index(db)
        if not verified:
            return False

        # Step 5: Test constraint
        tested = await test_constraint(db)
        if not tested:
            return False

        print("\n" + "=" * 60)
        print("✅ Migration completed successfully!")
        print("📧 Email deduplication is now enforced at the database level")
        print("🔒 Duplicate leads within organizations will be prevented")

        return True

    except Exception as e:
        print(f"\n❌ Migration failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

    finally:
        client.close()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Create unique email constraint for leads")
    parser.add_argument("--dry-run", action="store_true", help="Check for duplicates without making changes")
    args = parser.parse_args()

    if args.dry_run:
        print("🔍 DRY RUN MODE - No changes will be made")

        async def dry_run():
            mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
            mongodb_db = os.getenv('MONGODB_DB_NAME', 'smart_table')

            client = AsyncIOMotorClient(mongodb_uri)
            db = client[mongodb_db]

            try:
                await check_existing_duplicates(db)
            finally:
                client.close()

        asyncio.run(dry_run())
    else:
        success = asyncio.run(run_migration())
        sys.exit(0 if success else 1)