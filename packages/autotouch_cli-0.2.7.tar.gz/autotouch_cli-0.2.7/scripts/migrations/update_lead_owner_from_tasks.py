#!/usr/bin/env python3
import argparse
import os
from pathlib import Path
from typing import Any, Dict, Optional

from pymongo import MongoClient, UpdateOne
from bson import ObjectId
from datetime import datetime


def _load_env(env_path: Path) -> None:
  if not env_path.exists():
    return
  for line in env_path.read_text().splitlines():
    raw = line.strip()
    if not raw or raw.startswith('#') or '=' not in raw:
      continue
    key, value = raw.split('=', 1)
    key = key.strip()
    value = value.strip().strip('"').strip("'")
    os.environ.setdefault(key, value)


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
  if not value:
    return None
  try:
    return datetime.fromisoformat(value)
  except Exception:
    return None


def _coerce_oid(value: Any) -> Optional[ObjectId]:
  try:
    return ObjectId(str(value))
  except Exception:
    return None


def main() -> None:
  parser = argparse.ArgumentParser(description="Set lead.user_id based on assigned task owners.")
  parser.add_argument("--env", default=".env", help="Path to .env with Mongo connection.")
  parser.add_argument("--db", default=None, help="Override DB name (defaults to MONGODB_DB_NAME).")
  parser.add_argument("--org-id", default=None, help="Limit updates to a single organization_id.")
  parser.add_argument("--since", default=None, help="Only consider tasks created after ISO datetime.")
  parser.add_argument("--overwrite", action="store_true", help="Overwrite existing lead owners.")
  parser.add_argument("--dry-run", action="store_true", help="Print counts only, no writes.")
  parser.add_argument("--batch-size", type=int, default=500, help="Bulk update batch size.")
  parser.add_argument("--limit", type=int, default=0, help="Limit number of leads to update (0 = no limit).")
  args = parser.parse_args()

  _load_env(Path(args.env))
  conn = os.environ.get("MONGODB_PROD_CONNECTION_STRING")
  if not conn:
    raise SystemExit("Missing MONGODB_PROD_CONNECTION_STRING in env.")
  db_name = args.db or os.environ.get("MONGODB_DB_NAME")
  if not db_name:
    raise SystemExit("Missing MONGODB_DB_NAME (pass --db to override).")

  tls_ca_file = None
  try:
    import certifi
    tls_ca_file = certifi.where()
  except Exception:
    tls_ca_file = None

  client = MongoClient(conn, tlsCAFile=tls_ca_file) if tls_ca_file else MongoClient(conn)
  db = client[db_name]
  tasks = db["task_queue"]
  leads = db["leads"]

  task_match: Dict[str, Any] = {
    "assigned_to": {"$exists": True, "$ne": None},
    "lead_id": {"$exists": True, "$ne": None},
  }
  if args.org_id:
    task_match["organization_id"] = args.org_id

  since_dt = _parse_iso(args.since)
  if since_dt:
    task_match["created_at"] = {"$gte": since_dt}

  pipeline = [
    {"$match": task_match},
    {"$sort": {"updated_at": -1, "created_at": -1, "due_date": -1}},
    {"$group": {"_id": "$lead_id", "assigned_to": {"$first": "$assigned_to"}}},
  ]

  updates = []
  matched = 0
  modified = 0
  processed = 0

  cursor = tasks.aggregate(pipeline, allowDiskUse=True)
  now = datetime.utcnow()

  for doc in cursor:
    lead_id = doc.get("_id")
    assignee = doc.get("assigned_to")
    if not lead_id or assignee is None:
      continue
    processed += 1
    if args.limit and processed > args.limit:
      break

    assignee_value = str(assignee)
    lead_oid = _coerce_oid(lead_id)
    lead_filter: Dict[str, Any] = {"organization_id": args.org_id} if args.org_id else {}
    lead_filter.update({"_id": lead_oid or lead_id})

    if not args.overwrite:
      lead_filter.update({
        "$or": [
          {"user_id": {"$exists": False}},
          {"user_id": None},
          {"user_id": ""},
        ]
      })

    updates.append(
      UpdateOne(
        lead_filter,
        {"$set": {"user_id": assignee_value, "updated_at": now}},
      )
    )

    if len(updates) >= args.batch_size:
      if not args.dry_run:
        result = leads.bulk_write(updates, ordered=False)
        matched += result.matched_count
        modified += result.modified_count
      updates = []

  if updates and not args.dry_run:
    result = leads.bulk_write(updates, ordered=False)
    matched += result.matched_count
    modified += result.modified_count

  print({
    "db": db_name,
    "org_id": args.org_id,
    "processed_leads": processed,
    "dry_run": args.dry_run,
    "overwrite": args.overwrite,
    "matched": matched if not args.dry_run else "dry_run",
    "modified": modified if not args.dry_run else "dry_run",
  })


if __name__ == "__main__":
  main()
