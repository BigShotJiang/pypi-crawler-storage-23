#!/usr/bin/env python3
"""
Migration: Convert user_id fields from email strings to MongoDB ObjectIds
Date: 2025-01-28
Reason: Improve security, performance, and follow proper database design patterns

This migration updates the following collections:
- tables: user_id field
- rows: user_id field (if present)
- cells: user_id field (if present)
- Any other collections with user_id references

IMPORTANT: Run this after updating the JWT generation to use ObjectIds
"""

import asyncio
import os
import sys
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId

# Add the apps directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '../../apps'))

# MongoDB connection
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "autotouch")

async def get_user_email_to_id_mapping(db):
    """Create a mapping from email to ObjectId for all users."""
    print("📋 Building user email → ObjectId mapping...")

    users = await db.users.find({}, {"email": 1, "_id": 1}).to_list(None)
    mapping = {}

    for user in users:
        email = user.get('email')
        user_id = str(user['_id'])
        if email:
            mapping[email] = user_id

    print(f"✅ Found {len(mapping)} users to migrate")
    return mapping

async def migrate_collection(db, collection_name, email_to_id_mapping, user_id_field="user_id"):
    """Migrate user_id fields in a collection from email to ObjectId."""
    collection = db[collection_name]

    # Count documents that need migration
    email_users = list(email_to_id_mapping.keys())
    count = await collection.count_documents({user_id_field: {"$in": email_users}})

    if count == 0:
        print(f"⏭️  {collection_name}: No documents to migrate")
        return 0

    print(f"🔄 Migrating {collection_name}: {count} documents...")

    migrated = 0
    for email, object_id in email_to_id_mapping.items():
        result = await collection.update_many(
            {user_id_field: email},
            {"$set": {user_id_field: object_id}}
        )
        migrated += result.modified_count

    print(f"✅ {collection_name}: Migrated {migrated} documents")
    return migrated

async def verify_migration(db, collection_name, email_to_id_mapping, user_id_field="user_id"):
    """Verify that no email-based user_ids remain in the collection."""
    collection = db[collection_name]

    email_users = list(email_to_id_mapping.keys())
    remaining = await collection.count_documents({user_id_field: {"$in": email_users}})

    if remaining > 0:
        print(f"⚠️  {collection_name}: {remaining} documents still have email user_ids!")
        return False
    else:
        print(f"✅ {collection_name}: Migration verified - no email user_ids remaining")
        return True

async def main():
    """Run the user ID migration."""
    print("🚀 Starting User ID Migration: Email → ObjectId")
    print("=" * 60)

    # Connect to MongoDB
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        # Step 1: Build email → ObjectId mapping
        email_to_id_mapping = await get_user_email_to_id_mapping(db)

        if not email_to_id_mapping:
            print("❌ No users found! Cannot proceed with migration.")
            return

        print(f"\n📦 Sample mapping:")
        for i, (email, obj_id) in enumerate(list(email_to_id_mapping.items())[:3]):
            print(f"   {email} → {obj_id}")
        if len(email_to_id_mapping) > 3:
            print(f"   ... and {len(email_to_id_mapping) - 3} more")

        # Step 2: Migrate each collection
        print("\n🔄 Starting migration...")
        collections_to_migrate = [
            ("tables", "user_id"),
            ("tables", "created_by"),  # Also migrate created_by field
            ("rows", "user_id"),
            ("cells", "user_id"),
            ("companies", "user_id"),  # Company extraction system
            ("tasks", "user_id"),      # If tasks have user ownership
        ]

        total_migrated = 0
        for collection_name, field_name in collections_to_migrate:
            try:
                migrated = await migrate_collection(db, collection_name, email_to_id_mapping, field_name)
                total_migrated += migrated
            except Exception as e:
                print(f"⚠️  Error migrating {collection_name}.{field_name}: {e}")

        # Step 3: Verification
        print(f"\n🔍 Verifying migration...")
        all_verified = True
        for collection_name, field_name in collections_to_migrate:
            try:
                verified = await verify_migration(db, collection_name, email_to_id_mapping, field_name)
                if not verified:
                    all_verified = False
            except Exception as e:
                print(f"⚠️  Error verifying {collection_name}.{field_name}: {e}")
                all_verified = False

        # Step 4: Summary
        print("\n" + "=" * 60)
        if all_verified:
            print(f"🎉 Migration completed successfully!")
            print(f"📊 Total documents migrated: {total_migrated}")
            print(f"👥 Users processed: {len(email_to_id_mapping)}")
        else:
            print("❌ Migration completed with errors. Please review the warnings above.")

        print(f"\n📝 Migration completed at: {datetime.now()}")

    except Exception as e:
        print(f"❌ Migration failed: {e}")
        raise
    finally:
        client.close()

if __name__ == "__main__":
    print("User ID Migration Script")
    print("This will convert user_id fields from emails to MongoDB ObjectIds")
    print("Make sure you've updated the JWT generation first!")

    confirmation = input("\n⚠️  Continue with migration? (yes/no): ").strip().lower()
    if confirmation not in ['yes', 'y']:
        print("Migration cancelled.")
        sys.exit(0)

    asyncio.run(main())