#!/usr/bin/env python3
"""
Bundle relevant backend source files into a single labeled text file for LLM sharing.

Usage:
  python scripts/bundle_sequences_backend.py \
    --output docs/shares/sequences_backend_bundle.txt

Options:
  --output PATH                Output file (default: docs/shares/sequences_backend_bundle.txt)
  --stdout                     Print to stdout instead of writing a file
  --extra PATH ...             Additional file paths to include (repeatable)
  --auto                       Auto-discover relevant backend files (keywords scan)
  --core                       Force core-only (DEFAULT_FILES) and ignore --auto
  --max-lines-per-file N       Truncate each file to the first N lines (annotation added)
  --strip-comments             Remove full-line comments and leading module docstrings; collapse blank lines
  --root PATH                  Project root (default: cwd)

By default, it includes the core Sequences pipeline files:
  - apps/api/routers/sequences.py
  - apps/api/services/sequence_service.py
  - apps/api/services/sequence_enrollment_service.py
  - apps/api/services/research_snapshot_service.py
  - apps/api/models/sequence.py
  - apps/api/models/sequence_enrollment.py
  - apps/api/models/collections.py
  - apps/api/main.py
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from datetime import datetime
from typing import Iterable, List, Set, Optional, Tuple

DEFAULT_FILES: List[str] = [
    "apps/api/routers/sequences.py",
    "apps/api/services/sequence_service.py",
    "apps/api/services/sequence_enrollment_service.py",
    "apps/api/services/research_snapshot_service.py",
    "apps/api/models/sequence.py",
    "apps/api/models/sequence_enrollment.py",
    "apps/api/models/collections.py",
    "apps/api/main.py",
]

SEPARATOR_LINE = "=" * 60
SUBSEP_LINE = "-" * 60


def _strip_leading_docstring(text: str) -> Tuple[str, bool]:
    """Remove a top-level triple-quoted module docstring if present."""
    import re
    # Match at very start, optional encoding/comments/blank lines ignored is complicated;
    # keep it simple: only strip if the very first non-whitespace chars are a triple quote.
    s = text.lstrip()
    leading_ws_len = len(text) - len(s)
    if s.startswith('"""') or s.startswith("'''"):
        quote = s[:3]
        end = s.find(quote, 3)
        if end != -1:
            stripped = s[end + 3 :]
            return ("\n" * (1 if leading_ws_len > 0 else 0)) + stripped.lstrip("\n"), True
    return text, False


def _strip_comments_and_collapse(text: str) -> str:
    lines = text.splitlines()
    out: List[str] = []
    for ln in lines:
        # Remove full-line comments; keep inline code comments
        if ln.strip().startswith("#"):
            continue
        out.append(ln)
    # collapse consecutive blank lines
    collapsed: List[str] = []
    blank = 0
    for ln in out:
        if ln.strip() == "":
            blank += 1
            if blank > 1:
                continue
        else:
            blank = 0
        collapsed.append(ln)
    return "\n".join(collapsed)


def read_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        return f"<ERROR reading {path}: {e}>\n"


def format_section(path: Path, content: str) -> str:
    rel = str(path)
    return (
        f"{SEPARATOR_LINE}\n"
        f"{rel}\n"
        f"{SUBSEP_LINE}\n"
        f"{content.rstrip()}\n\n"
    )


def bundle(paths: Iterable[Path], *, max_lines_per_file: Optional[int] = None, strip_comments: bool = False) -> str:
    ts = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    header = (
        "SEQUENCES BACKEND BUNDLE — Source Snapshot\n"
        f"Generated: {ts}\n"
        "Repo root relative paths.\n\n"
    )
    sections: List[str] = [header]
    for p in paths:
        raw = read_file(p)
        if strip_comments:
            stripped, did_strip = _strip_leading_docstring(raw)
            raw = _strip_comments_and_collapse(stripped)
        if max_lines_per_file is not None and max_lines_per_file > 0:
            lines = raw.splitlines()
            if len(lines) > max_lines_per_file:
                clipped = "\n".join(lines[:max_lines_per_file]) + f"\n\n# [truncated to first {max_lines_per_file} lines]\n"
                sections.append(format_section(p, clipped))
                continue
        sections.append(format_section(p, raw))
    return "".join(sections)


KEYWORDS: List[str] = [
    # Sequences + enrollment + schedule
    "SEQUENCES_COLLECTION",
    "SEQUENCE_ENROLLMENTS_COLLECTION",
    "sequence_enrollment",
    "sequence_enrollments",
    "sequence_service",
    "sequence_enrollment_service",
    "emailDelivery",
    "delivery-status",
    "next_run_at",
    "timeline",
    # Research context
    "research_snapshot_service",
    "projection_resolver",
    "research_context",
    # Task queue hooks
    "task_queue",
    # Readiness dependencies
    "mail_users",
    "api_keys",
]


def scan_auto(root: Path, base_dir: str = "apps/api") -> List[Path]:
    import re
    matches: Set[Path] = set()
    search_dir = root / base_dir
    if not search_dir.exists():
        return []
    pattern = re.compile("|".join(re.escape(k) for k in KEYWORDS))
    for p in search_dir.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if pattern.search(text):
            matches.add(p)
    # Always ensure main router + models included
    for rel in DEFAULT_FILES:
        q = root / rel
        if q.exists():
            matches.add(q)
    # Sort and relativize
    rels = []
    for p in matches:
        try:
            rels.append(p.relative_to(root))
        except Exception:
            rels.append(p)
    return sorted(rels, key=lambda x: str(x))


def main() -> None:
    parser = argparse.ArgumentParser(description="Bundle backend files into a single text file")
    parser.add_argument("--output", default="docs/shares/sequences_backend_bundle.txt", help="Output path")
    parser.add_argument("--stdout", action="store_true", help="Print to stdout instead of writing a file")
    parser.add_argument("--extra", action="append", default=[], help="Additional file path to include (repeatable)")
    parser.add_argument("--auto", action="store_true", help="Auto-discover relevant backend files (keyword scan under apps/api)")
    parser.add_argument("--core", action="store_true", help="Include only core DEFAULT_FILES and ignore --auto")
    parser.add_argument("--max-lines-per-file", type=int, default=None, help="Truncate each file to the first N lines")
    parser.add_argument("--strip-comments", action="store_true", help="Remove full-line comments and top module docstrings; collapse blank lines")
    parser.add_argument("--root", default=None, help="Project root (default: cwd)")
    args = parser.parse_args()

    root = Path(args.root) if args.root else Path.cwd()
    candidates = []

    if args.core:
        # Force core-only
        for rel in DEFAULT_FILES:
            p = root / rel
            if p.exists():
                candidates.append(p)
            else:
                print(f"[warn] missing core file: {rel}")
    elif args.auto:
        auto_paths = scan_auto(root)
        candidates.extend(auto_paths)
    else:
        # Collect default files
        for rel in DEFAULT_FILES:
            p = root / rel
            if p.exists():
                candidates.append(p)
            else:
                print(f"[warn] missing default file: {rel}")

    # Add extras
    for rel in args.extra:
        p = (root / rel).resolve()
        if p.exists():
            candidates.append(p.relative_to(root))
        else:
            print(f"[warn] extra file not found: {rel}")

    # De-duplicate and sort
    uniq_sorted = sorted({str(p) for p in candidates})
    paths = [Path(s) for s in uniq_sorted]

    output_text = bundle(
        paths,
        max_lines_per_file=args.max_lines_per_file,
        strip_comments=args.strip_comments,
    )

    if args.stdout:
        print(output_text)
        return

    out_path = root / args.output
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(output_text, encoding="utf-8")
    print(f"[ok] Wrote {out_path} ({len(paths)} files)")


if __name__ == "__main__":
    main()
