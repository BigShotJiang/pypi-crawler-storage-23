"""Collmex CLI - LLM-friendly wrapper for Collmex accounting API."""

__version__ = "2026.03.8"
