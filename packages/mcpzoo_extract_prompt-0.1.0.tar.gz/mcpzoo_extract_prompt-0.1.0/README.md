# mcpzoo-extract-prompt

> 提取提示词 — 生成信息提取的提示词模板

## Installation

```bash
uvx mcpzoo-extract-prompt
```

## uvx JSON

```json
{
  "mcpServers": {
    "extract-prompt": {
      "args": ["mcpzoo-extract-prompt"],
      "command": "uvx"
    }
  }
}
```
