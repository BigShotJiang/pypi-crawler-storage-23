from mcp.server.fastmcp import FastMCP

mcp = FastMCP("extract-prompt")

@mcp.tool()
def gen_extract(text: str, fields: str) -> str:
    """生成结构化信息提取的提示词模板。"""
    field_list = fields.split(";")
    prompt = "请从以下文本中提取关键信息，并以结构化的格式返回。\n\n"
    
    prompt += "需要提取的字段列表：\n"
    for f in field_list:
        prompt += f"- {f}\n"
        
    prompt += "\n提取规则：\n"
    prompt += "1. 如果某字段在文本中不存在，请填充 '未提及'。\n"
    prompt += "2. 严格遵循上述字段名称，不要自定义字段。\n"
    prompt += "3. 请以清晰的键值对形式（如 JSON 格式）输出提取结果，不附带多余文本。\n\n"
    prompt += f"原文：\n{text}"
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
