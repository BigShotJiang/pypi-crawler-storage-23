"""
aura.carbon — Composant de mesure d'émissions CO2.

Wrapper autour de CodeCarbon avec sortie vers le serveur Aura/Django.

Usage :
    from aura.carbon import AuraCarbon

    # Context manager
    with AuraCarbon() as tracker:
        train_model()

    # Decorator
    from aura.carbon import track_emissions

    @track_emissions()
    def train_model():
        pass

    # Start/Stop explicite
    tracker = AuraCarbon()
    tracker.start()
    train_model()
    emissions = tracker.stop()
"""

from aura.carbon.tracker import AuraCarbon
from aura.carbon.decorators import track_emissions

__all__ = [
    "AuraCarbon",
    "track_emissions",
]
