"""
AuraCarbon — Wrapper autour de CodeCarbon EmissionsTracker.

Ajoute automatiquement AuraOutput et charge la configuration
depuis ~/.aura.config.
"""

from typing import Optional, List
from codecarbon import EmissionsTracker
from codecarbon.output_methods.base_output import BaseOutput

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraConfigError
from aura.carbon.output import AuraOutput


class AuraCarbon:
    """
        Tracker d'émissions CO2 pré-configuré pour le serveur Aura.

        Encapsule CodeCarbon EmissionsTracker avec :
            - AuraOutput branché automatiquement
            - Configuration chargée depuis ~/.aura.config
            - Interface identique à EmissionsTracker

        Usage :
            # Context manager
            with AuraCarbon() as tracker:
                train_model()

            # Start/Stop
            tracker = AuraCarbon(project_name="Mon projet")
            tracker.start()
            train_model()
            emissions = tracker.stop()

            # Avec options CodeCarbon supplémentaires
            tracker = AuraCarbon(
                project_name="Training GPT",
                measure_power_secs=5,
                save_to_file=True,          # garde aussi le CSV local
            )
    """

    def __init__(
        self,
        project_name: Optional[str] = None,
        experiment_id: Optional[str] = None,
        measure_power_secs: float = 15,
        save_to_file: bool = False,
        output_dir: str = ".",
        output_file: str = "emissions.csv",
        extra_output_handlers: Optional[List[BaseOutput]] = None,
        config: Optional[AuraConfig] = None,
        project_id: Optional[str] = None,
        execution_id: Optional[str] = None,
        **codecarbon_kwargs,
    ):
        """
        Args:
            project_name: Nom du projet. Si None, utilise default_project
                          depuis ~/.aura.config.
            experiment_id: ID de l'expérience CodeCarbon.
            measure_power_secs: Fréquence de mesure en secondes (défaut: 15).
            save_to_file: Sauvegarder aussi dans un CSV local (défaut: False).
            output_dir: Répertoire pour le CSV local.
            output_file: Nom du fichier CSV local.
            extra_output_handlers: Outputs supplémentaires (Prometheus, etc.).
            config: AuraConfig personnalisé. Si None, chargé depuis ~/.aura.config.
            project_id: UUID du projet d'audit parent (optionnel).
                       Si None, utilise default_project_id de ~/.aura.config.
            execution_id: UUID de l'exécution pour lier les résultats (optionnel).
                         Si None, utilise default_execution_id de ~/.aura.config.
            **codecarbon_kwargs: Tous les autres paramètres de EmissionsTracker
                                 sont transmis directement.
        """
        # Chargement de la configuration Aura
        if config is None:
            try:
                config = AuraConfig().load()
            except AuraConfigError as e:
                raise AuraConfigError(
                    f"{e}\n"
                    "Fournissez un objet AuraConfig ou créez ~/.aura.config"
                ) from e

        self._config = config

        # Utiliser les valeurs par défaut si non fournies
        self._project_id = project_id or config.default_project_id
        self._execution_id = execution_id or config.default_execution_id

        # Résolution du nom de projet
        resolved_project = project_name or config.default_project or "aura-default"

        # Construction de la liste des output handlers
        aura_output = AuraOutput(
            config=config,
            project_id=self._project_id,
            execution_id=self._execution_id
        )
        handlers = [aura_output]
        if extra_output_handlers:
            handlers.extend(extra_output_handlers)

        # Initialisation de CodeCarbon avec AuraOutput
        self._tracker = EmissionsTracker(
            project_name=resolved_project,
            experiment_id=experiment_id,
            measure_power_secs=measure_power_secs,
            save_to_file=save_to_file,
            output_dir=output_dir,
            output_file=output_file,
            save_to_api=False,      # On gère l'envoi via AuraOutput
            output_handlers=handlers,
            tracking_mode="machine",  # Force mode machine (pas de sudo)
            **codecarbon_kwargs,
        )

    # ─── Interface publique ───────────────────────────────────────────────────

    def start(self) -> None:
        """Démarre le tracking d'émissions."""
        self._tracker.start()

    def stop(self) -> Optional[float]:
        """
        Arrête le tracking et envoie les données au serveur Aura.

        Returns:
            Émissions totales en kg CO2eq, ou None.
        """
        return self._tracker.stop()

    def flush(self) -> Optional[float]:
        """Envoie les données courantes sans arrêter le tracking."""
        return self._tracker.flush()

    def start_task(self, task_name: str = None) -> None:
        """Démarre le tracking d'une tâche spécifique."""
        self._tracker.start_task(task_name)

    def stop_task(self, task_name: str = None):
        """Arrête le tracking de la tâche et retourne ses émissions."""
        return self._tracker.stop_task(task_name)

    # ─── Context manager ─────────────────────────────────────────────────────

    def __enter__(self) -> "AuraCarbon":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.stop()

    # ─── Accès au tracker CodeCarbon sous-jacent ──────────────────────────────

    @property
    def tracker(self) -> EmissionsTracker:
        """Accès direct au EmissionsTracker CodeCarbon sous-jacent."""
        return self._tracker

    def __repr__(self) -> str:
        return (
            f"AuraCarbon("
            f"project={self._tracker._project_name!r}, "
            f"server={self._config.api_endpoint!r}"
            f")"
        )
