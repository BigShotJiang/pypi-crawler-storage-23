"""
    Décorateurs Aura pour le tracking d'émissions.

    Usage :
        from aura.carbon import track_emissions

        @track_emissions()
        def train_model():
            pass

        @track_emissions(project_name="GPT Training", measure_power_secs=5)
        def fine_tune(model, dataset):
            pass
"""

import functools
from typing import Optional, Callable, Any

from aura.carbon.tracker import AuraCarbon


def track_emissions(
    project_name: Optional[str] = None,
    measure_power_secs: float = 15,
    save_to_file: bool = False,
    **kwargs,
) -> Callable:
    """
    Décorateur pour tracker les émissions d'une fonction.

    Args:
        project_name: Nom du projet (défaut : depuis ~/.aura.config).
        measure_power_secs: Fréquence de mesure en secondes.
        save_to_file: Sauvegarder aussi dans un CSV local.
        **kwargs: Autres paramètres transmis à AuraCarbon / EmissionsTracker.

    Example :
        @track_emissions(project_name="Training", measure_power_secs=5)
        def train():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **func_kwargs) -> Any:
            tracker = AuraCarbon(
                project_name=project_name or func.__name__,
                measure_power_secs=measure_power_secs,
                save_to_file=save_to_file,
                **kwargs,
            )
            with tracker:
                return func(*args, **func_kwargs)
        return wrapper
    return decorator
