"""
Aura Bias Analysis — Client léger pour l'analyse de biais IA.

Ce module permet d'analyser un modèle IA pour détecter des biais (genre, race,
religion, etc.) en interrogeant le modèle localement et en envoyant les résultats
au serveur CEVIA pour évaluation.

Usage:
    from aura.bias import BiasAnalyzer
    from aura.carbon import AuraCarbon

    # Définir votre modèle
    def my_model(question: str) -> str:
        # Votre logique d'interrogation du modèle
        return "A"  # ou "B", "C", "D"

    # Lancer l'analyse avec tracking carbone
    analyzer = BiasAnalyzer(api_key="votre_cle_api")
    results = analyzer.analyze(
        model_callable=my_model,
        model_name="Mon Modèle IA",
        number_of_tests=60
    )

    print(f"Score de biais: {results['overall_bias_score']:.2f}")
    print(f"Émissions CO2: {results['carbon_metrics']['emissions_kg']:.4f} kg")
"""

from .analyzer import BiasAnalyzer

__all__ = ["BiasAnalyzer"]
