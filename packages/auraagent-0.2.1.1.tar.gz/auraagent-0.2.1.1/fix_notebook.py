#!/usr/bin/env python3
"""
Script pour corriger automatiquement le notebook test_execution_notebook.ipynb
en remplaçant les cellules problématiques.
"""
import json
import shutil
from pathlib import Path


def fix_notebook():
    """Corrige le notebook en remplaçant la cellule 6 (BiasAnalyzer)."""
    notebook_path = Path("test_execution_notebook.ipynb")
    backup_path = Path("test_execution_notebook.ipynb.backup")

    # Créer une sauvegarde
    shutil.copy(notebook_path, backup_path)
    print(f"✅ Sauvegarde créée : {backup_path}")

    # Charger le notebook
    with open(notebook_path, 'r', encoding='utf-8') as f:
        notebook = json.load(f)

    # Identifier et corriger la cellule 6 (index 5, car 0-indexed)
    # Cellule 6 est celle avec BiasAnalyzer
    cell_6_new_source = [
        "# Lancer l'analyse de biais\n",
        "print(\"🔧 Initialisation de BiasAnalyzer...\")\n",
        "print()\n",
        "\n",
        "# BiasAnalyzer charge automatiquement la config depuis ~/.aura.config\n",
        "analyzer = BiasAnalyzer()  # ✅ Pas de paramètres !\n",
        "\n",
        "print(\"🚀 Lancement de l'analyse de biais...\")\n",
        "print(\"   (Cela prendra environ 10-30 secondes pour 2 tests/catégorie)\")\n",
        "print()\n",
        "\n",
        "bias_results = analyzer.analyze(\n",
        "    model_callable=simple_model,\n",
        "    model_name=\"Test Notebook Model\",\n",
        "    number_of_tests=2,  # 2 × 6 catégories = 12 tests (rapide)\n",
        "    track_carbon=False,  # On teste le carbone séparément\n",
        "    verbose=True,\n",
        "    execution_id=EXECUTION_ID  # ✅ execution_id va dans analyze() !\n",
        ")\n",
        "\n",
        "print(f\"\\n✅ Analyse terminée ! {bias_results['total_tests_run']} tests exécutés\")"
    ]

    # Trouver la cellule avec BiasAnalyzer
    for i, cell in enumerate(notebook['cells']):
        if cell['cell_type'] == 'code':
            source = ''.join(cell.get('source', []))
            if 'BiasAnalyzer(' in source and 'backend_url' in source:
                print(f"📝 Cellule {i+1} trouvée et corrigée (BiasAnalyzer)")
                cell['source'] = cell_6_new_source
                # Réinitialiser les outputs
                cell['outputs'] = []
                cell['execution_count'] = None

    # Optionnel : Simplifier aussi AuraCarbon (cellule 9)
    cell_9_new_source = [
        "# Configuration du tracker carbone\n",
        "print(\"🔥 Test Carbon Tracking...\")\n",
        "print(\"-\" * 60)\n",
        "\n",
        "# AuraCarbon charge aussi la config depuis ~/.aura.config\n",
        "carbon_tracker = AuraCarbon(\n",
        "    project_name=\"test-notebook-carbon\",\n",
        "    execution_id=EXECUTION_ID  # ✅ Utilise automatiquement ~/.aura.config\n",
        ")\n",
        "\n",
        "print(\"✅ Tracker carbone configuré\")"
    ]

    for i, cell in enumerate(notebook['cells']):
        if cell['cell_type'] == 'code':
            source = ''.join(cell.get('source', []))
            if 'AuraCarbon(' in source and 'backend_url' in source:
                print(f"📝 Cellule {i+1} trouvée et corrigée (AuraCarbon)")
                cell['source'] = cell_9_new_source
                # Réinitialiser les outputs
                cell['outputs'] = []
                cell['execution_count'] = None

    # Sauvegarder le notebook corrigé
    with open(notebook_path, 'w', encoding='utf-8') as f:
        json.dump(notebook, f, indent=1, ensure_ascii=False)

    print(f"✅ Notebook corrigé : {notebook_path}")
    print()
    print("📋 Résumé des changements :")
    print("   • BiasAnalyzer() : Suppression de backend_url et execution_id de __init__()")
    print("   • BiasAnalyzer.analyze() : Ajout de execution_id en paramètre")
    print("   • AuraCarbon() : Suppression de backend_url (utilise ~/.aura.config)")
    print()
    print("🎯 Prochaine étape : Ouvrir le notebook et exécuter les cellules")
    print("   jupyter notebook test_execution_notebook.ipynb")


if __name__ == "__main__":
    fix_notebook()
