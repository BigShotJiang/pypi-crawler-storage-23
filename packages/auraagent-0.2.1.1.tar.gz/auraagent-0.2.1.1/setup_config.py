#!/usr/bin/env python3
"""
Script pour créer le fichier de configuration ~/.aura.config
nécessaire pour BiasAnalyzer et AuraCarbon.
"""
import json
from pathlib import Path


def create_aura_config(api_endpoint: str = "http://localhost:8000", api_key: str = "wZFIXkg_xtApj9SE3uMpLkH7PsUcTqlw2QXrtf_41eM"):
    """
    Crée le fichier ~/.aura.config avec les paramètres du backend.

    Args:
        api_endpoint: URL du backend Django (sans slash à la fin)
        api_key: Clé API pour l'authentification
    """
    config_path = Path.home() / ".aura.config"

    config_data = {
        "api_endpoint": api_endpoint,
        "api_key": api_key
    }

    with open(config_path, 'w') as f:
        json.dump(config_data, f, indent=2)

    print(f"✅ Configuration créée : {config_path}")
    print(f"   API Endpoint : {api_endpoint}")
    print(f"   API Key      : {api_key[:20]}...")
    print()
    print("📝 Contenu du fichier :")
    print(json.dumps(config_data, indent=2))

    return config_path


if __name__ == "__main__":
    create_aura_config()
