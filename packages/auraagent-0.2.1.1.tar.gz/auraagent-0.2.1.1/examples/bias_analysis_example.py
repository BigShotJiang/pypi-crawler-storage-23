#!/usr/bin/env python
"""
Exemple d'utilisation de BiasAnalyzer pour analyser un modèle IA.

Ce script montre comment :
1. Charger un modèle Hugging Face (ou autre)
2. L'adapter au format attendu par BiasAnalyzer
3. Lancer une analyse de biais avec tracking carbone intégré
"""

from aura.bias import BiasAnalyzer


def exemple_modele_simple():
    """Exemple avec un modèle mock (pour les tests)."""
    print("=" * 80)
    print("EXEMPLE 1: Modèle mock (retourne toujours 'A')")
    print("=" * 80)

    def my_model(question: str) -> str:
        """Modèle simple qui retourne toujours 'A'."""
        return "A"

    analyzer = BiasAnalyzer(api_key="votre_cle_api_ici")

    results = analyzer.analyze(
        model_callable=my_model,
        model_name="Modèle Mock Simple",
        number_of_tests=10,  # Petit nombre pour l'exemple
        verbose=True
    )

    print(f"\n📊 Score final de biais: {results['overall_bias_score']:.2f}")


def exemple_modele_huggingface():
    """Exemple avec un modèle Hugging Face réel."""
    print("\n" + "=" * 80)
    print("EXEMPLE 2: Modèle Hugging Face (text-generation)")
    print("=" * 80)

    try:
        from transformers import pipeline
    except ImportError:
        print("❌ Installez transformers: pip install transformers torch")
        return

    # Charger le modèle
    print("Chargement du modèle GPT-2...")
    generator = pipeline('text-generation', model='gpt2')

    def my_hf_model(question: str) -> str:
        """
        Adapte un modèle Hugging Face au format BiasAnalyzer.

        BiasAnalyzer attend une réponse parmi: "A", "B", "C", "D"
        """
        # Générer la réponse
        result = generator(question, max_length=100, num_return_sequences=1)
        generated_text = result[0]['generated_text']

        # Extraire la première lettre A/B/C/D trouvée
        for char in generated_text:
            if char in ['A', 'B', 'C', 'D']:
                return char

        # Fallback si aucune lettre trouvée
        return 'A'

    analyzer = BiasAnalyzer(api_key="votre_cle_api_ici")

    results = analyzer.analyze(
        model_callable=my_hf_model,
        model_name="GPT-2 Base",
        number_of_tests=20,  # Augmenter pour une analyse plus précise
        track_carbon=True,   # Tracking carbone activé
        save_backup=True,    # Sauvegarder localement
        verbose=True
    )

    print(f"\n📊 Résultats finaux:")
    print(f"   Score de biais: {results['overall_bias_score']:.2f}")
    print(f"   Émissions CO2: {results['carbon_metrics']['emissions_kg']:.6f} kg")


def exemple_modele_api():
    """Exemple avec un modèle accessible via API."""
    print("\n" + "=" * 80)
    print("EXEMPLE 3: Modèle via API externe")
    print("=" * 80)

    import requests

    def my_api_model(question: str) -> str:
        """
        Interroge un modèle via une API externe.

        Remplacez par votre propre endpoint.
        """
        try:
            response = requests.post(
                "https://api.votre-modele.com/predict",
                json={"prompt": question},
                headers={"Authorization": "Bearer YOUR_API_KEY"},
                timeout=30
            )
            response.raise_for_status()
            data = response.json()

            # Adapter la réponse au format A/B/C/D
            answer = data.get('response', 'A')
            if answer in ['A', 'B', 'C', 'D']:
                return answer
            return 'A'

        except Exception as e:
            print(f"Erreur API: {e}")
            return 'A'  # Fallback

    analyzer = BiasAnalyzer(api_key="votre_cle_api_ici")

    results = analyzer.analyze(
        model_callable=my_api_model,
        model_name="Mon Modèle API",
        number_of_tests=60,
        verbose=True
    )

    print(f"\n📊 Score final de biais: {results['overall_bias_score']:.2f}")


def exemple_workflow_complet():
    """Exemple de workflow complet avec toutes les étapes."""
    print("\n" + "=" * 80)
    print("EXEMPLE 4: Workflow complet avec étapes séparées")
    print("=" * 80)

    # Définir le modèle
    def my_model(question: str) -> str:
        # Votre logique ici
        return "B"

    # Initialiser l'analyzer
    analyzer = BiasAnalyzer(
        api_key="votre_cle_api_ici",
        api_url="https://cevia.ai"  # Optionnel, par défaut depuis config
    )

    # Étape 1: Créer l'audit
    audit_id = analyzer.create_audit(
        model_name="Mon Modèle Custom",
        model_type="local",
        number_of_tests=10
    )
    print(f"✅ Audit créé: {audit_id}")

    # Étape 2: Récupérer les questions
    questions = analyzer.get_questions(audit_id)
    print(f"✅ {len(questions)} questions récupérées")

    # Étape 3: Interroger le modèle (avec votre propre tracking si besoin)
    from aura.carbon import AuraCarbon

    tracker = AuraCarbon(project_name="bias-analysis")
    tracker.start()

    results = []
    for q in questions:
        answer = my_model(q['question'])
        results.append({
            'id': q['id'],
            'category': q['category'],
            'pos_list': q['pos_list'],
            'response': answer
        })

    emissions_kg = tracker.stop()
    carbon_metrics = {
        'emissions_kg': emissions_kg or 0.0,
        'energy_kwh': 0.0,
        'duration_seconds': 0,
        'cpu_power': 0.0,
        'gpu_power': 0.0
    }

    print(f"✅ Modèle interrogé | Émissions: {emissions_kg:.6f} kg CO2")

    # Étape 4: Soumettre les résultats
    final_results = analyzer.submit_results(
        audit_id=audit_id,
        results=results,
        carbon_metrics=carbon_metrics
    )

    print(f"✅ Résultats évalués")
    print(f"   Score de biais: {final_results['overall_bias_score']:.2f}")


if __name__ == '__main__':
    # Décommentez l'exemple que vous voulez tester:

    # Exemple simple (mock)
    exemple_modele_simple()

    # Exemple Hugging Face (nécessite: pip install transformers torch)
    # exemple_modele_huggingface()

    # Exemple API externe
    # exemple_modele_api()

    # Exemple workflow complet
    # exemple_workflow_complet()
