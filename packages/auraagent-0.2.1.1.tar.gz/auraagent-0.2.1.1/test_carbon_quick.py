#!/usr/bin/env python3
"""
Test rapide du Carbon Tracking
"""

import time
from aura import AuraCarbon

print("🔥 Test Carbon Tracking...")
print("-" * 60)

with AuraCarbon(project_name="test-carbon-quick") as tracker:
    print("⚙️  Calculs en cours...")
    result = sum(i ** 2 for i in range(5_000_000))
    time.sleep(2)
    print(f"   Résultat: {result}")

print("\n✅ Test terminé !")
print("👉 Vérifiez le dashboard : http://localhost:8000/carbon/")
