# Corrections pour test_execution_notebook.ipynb

## ✅ Problème résolu

Le fichier `~/.aura.config` a été créé avec succès. Il contient :
```json
{
  "api_endpoint": "http://localhost:8000",
  "api_key": "wZFIXkg_xtApj9SE3uMpLkH7PsUcTqlw2QXrtf_41eM"
}
```

## 🔧 Corrections à apporter dans le notebook

### Cellule 6 : Lancer l'analyse de biais

**❌ Code incorrect (actuel) :**
```python
analyzer = BiasAnalyzer(
    backend_url=BACKEND_URL,  # ❌ Paramètre inexistant !
    execution_id=EXECUTION_ID  # ❌ Ne va pas dans __init__ !
)

bias_results = analyzer.analyze(
    model_callable=simple_model,
    model_name="Test Notebook Model",
    number_of_tests=2,
    track_carbon=False,
    verbose=True
)
```

**✅ Code corrigé :**
```python
# BiasAnalyzer charge automatiquement la config depuis ~/.aura.config
print("🔧 Initialisation de BiasAnalyzer...")
analyzer = BiasAnalyzer()  # ✅ Pas de paramètres, utilise ~/.aura.config

print("🚀 Lancement de l'analyse de biais...")
print("   (Cela prendra environ 10-30 secondes pour 2 tests/catégorie)")
print()

bias_results = analyzer.analyze(
    model_callable=simple_model,
    model_name="Test Notebook Model",
    number_of_tests=2,
    track_carbon=False,
    verbose=True,
    execution_id=EXECUTION_ID  # ✅ execution_id va dans analyze() !
)

print(f"\n✅ Analyse terminée ! {bias_results['total_tests_run']} tests exécutés")
```

### Cellule 9 : Configuration du tracker carbone

**✅ Code actuel (déjà correct) :**
```python
print("🔥 Test Carbon Tracking...")
print("-" * 60)

carbon_tracker = AuraCarbon(
    project_name="test-notebook-carbon",
    backend_url=BACKEND_URL,  # AuraCarbon accepte ce paramètre
    execution_id=EXECUTION_ID  # ✅ Correct pour AuraCarbon
)

print("✅ Tracker carbone configuré")
```

**Note** : Le code pour AuraCarbon est déjà correct, mais peut être simplifié :

**✅ Code simplifié (optionnel) :**
```python
print("🔥 Test Carbon Tracking...")
print("-" * 60)

# AuraCarbon charge aussi la config depuis ~/.aura.config
carbon_tracker = AuraCarbon(
    project_name="test-notebook-carbon",
    execution_id=EXECUTION_ID  # Utilise automatiquement ~/.aura.config
)

print("✅ Tracker carbone configuré")
```

## 📋 Résumé des différences entre BiasAnalyzer et AuraCarbon

### BiasAnalyzer
```python
class BiasAnalyzer:
    def __init__(
        self,
        api_key: Optional[str] = None,      # Optionnel, chargé depuis config
        api_url: Optional[str] = None,      # Optionnel, chargé depuis config
        config: Optional[AuraConfig] = None # Chargé automatiquement
    ):
        # Si aucun paramètre, charge ~/.aura.config automatiquement

    def analyze(
        self,
        model_callable: Callable[[str], str],
        model_name: str,
        number_of_tests: int = 60,
        track_carbon: bool = True,
        verbose: bool = True,
        project_id: Optional[str] = None,
        execution_id: Optional[str] = None  # ← execution_id ICI !
    ) -> Dict[str, Any]:
        # ...
```

### AuraCarbon
```python
class AuraCarbon:
    def __init__(
        self,
        project_name: Optional[str] = None,
        execution_id: Optional[str] = None,   # ← execution_id ICI !
        config: Optional[AuraConfig] = None,  # Chargé automatiquement
        # ... autres paramètres
    ):
        # Si config=None, charge ~/.aura.config automatiquement
```

## 🎯 Instructions pour corriger le notebook

### Option 1 : Modification manuelle dans Jupyter

1. Ouvrir le notebook :
   ```bash
   jupyter notebook test_execution_notebook.ipynb
   ```

2. Localiser la **cellule 6** (celle avec `BiasAnalyzer(backend_url=...)`)

3. Remplacer tout le code de la cellule par le **code corrigé** ci-dessus

4. Exécuter les cellules dans l'ordre

### Option 2 : Utiliser le notebook corrigé

Un nouveau notebook corrigé sera créé : `test_execution_notebook_fixed.ipynb`

Pour l'utiliser :
```bash
jupyter notebook test_execution_notebook_fixed.ipynb
```

## ✅ Vérification

Après correction, vous devriez voir :

**Cellule 6 (Bias) :**
```
🔧 Initialisation de BiasAnalyzer...
🚀 Lancement de l'analyse de biais...
   (Cela prendra environ 10-30 secondes pour 2 tests/catégorie)

[Progression de l'analyse...]

✅ Analyse terminée ! 12 tests exécutés

================================================================================
📊 RÉSULTATS ANALYSE DE BIAIS
================================================================================

🎯 Score global de biais : XX.XX
📈 Tests exécutés        : 12
❌ Tests échoués         : X

📊 Scores par catégorie :
   ✅ gender               : XX.XX%
   ...
```

**Cellule 10 (Carbon) :**
```
🔥 Test Carbon Tracking...
------------------------------------------------------------
✅ Tracker carbone configuré
⚙️  Calculs en cours...
   Résultat: XXXXXXX
   ✅ Calculs terminés

✅ Tracking carbone terminé !
```

## 🐛 Si vous rencontrez encore des erreurs

### Erreur : "Config file not found"
**Solution** : Relancer `python3 setup_config.py`

### Erreur : "Connection refused"
**Solution** : Vérifier que le backend Django tourne :
```bash
curl http://localhost:8000/api/health
```

### Erreur : "Invalid API key"
**Solution** : Vérifier la clé API dans `~/.aura.config` correspond à celle du backend

## 📚 Fichiers de référence

| Fichier | Description |
|---------|-------------|
| `setup_config.py` | Script pour créer `~/.aura.config` |
| `~/.aura.config` | Fichier de configuration généré |
| `aura/bias/analyzer.py:13-52` | Signature de `BiasAnalyzer.__init__()` |
| `aura/bias/analyzer.py:199-229` | Signature de `BiasAnalyzer.analyze()` |
| `aura/carbon/tracker.py:17-60` | Signature de `AuraCarbon.__init__()` |

---

**Dernière mise à jour** : 2026-02-23
**Status** : ✅ Config créée, corrections identifiées
