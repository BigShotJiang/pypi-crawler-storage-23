#!/usr/bin/env python3
"""
Test du workflow complet après les modifications.
"""
from aura.core.config import AuraConfig

# 1. Vérifier que la config existe et est en INI
print("=" * 80)
print("1️⃣  VÉRIFICATION DE LA CONFIGURATION")
print("=" * 80)

cfg = AuraConfig()
if cfg.exists():
    cfg.load()
    print("✅ Fichier ~/.aura.config trouvé")
    print(f"   Format     : INI")
    print(f"   Endpoint   : {cfg.api_endpoint}")
    print(f"   API Key    : {cfg.api_key[:10]}...")

    # Vérifier les nouveaux champs
    if cfg.default_project_id:
        print(f"   Projet ID  : {cfg.default_project_id[:8]}...")
    else:
        print("   Projet ID  : ⚠️  Non défini")

    if cfg.default_execution_id:
        print(f"   Exec ID    : {cfg.default_execution_id[:8]}...")
    else:
        print("   Exec ID    : ⚠️  Non défini")
else:
    print("❌ Fichier ~/.aura.config introuvable")
    print("   Lancez: aura init")

print()
print("=" * 80)
print("2️⃣  TEST BIASANALYZER")
print("=" * 80)

try:
    from aura import BiasAnalyzer

    # Créer l'analyzer sans paramètres (utilise config)
    analyzer = BiasAnalyzer()
    print("✅ BiasAnalyzer initialisé avec succès")
    print(f"   API URL : {analyzer._api_url}")
    print(f"   Config chargée : {analyzer._config.exists()}")

    # Vérifier les valeurs par défaut
    if analyzer._config.default_execution_id:
        print(f"   ✅ Exécution par défaut disponible : {analyzer._config.default_execution_id[:8]}...")
    else:
        print("   ⚠️  Pas d'exécution par défaut")

except Exception as e:
    print(f"❌ Erreur : {e}")

print()
print("=" * 80)
print("3️⃣  TEST AURACARBON")
print("=" * 80)

try:
    from aura import AuraCarbon

    # Créer le tracker sans paramètres (utilise config)
    tracker = AuraCarbon()
    print("✅ AuraCarbon initialisé avec succès")
    print(f"   Config chargée : {tracker._config.exists()}")

    # Vérifier les valeurs par défaut
    if tracker._execution_id:
        print(f"   ✅ Exécution par défaut : {tracker._execution_id[:8]}...")
    else:
        print("   ⚠️  Pas d'exécution par défaut")

    if tracker._project_id:
        print(f"   ✅ Projet par défaut : {tracker._project_id[:8]}...")
    else:
        print("   ⚠️  Pas de projet par défaut")

except Exception as e:
    print(f"❌ Erreur : {e}")

print()
print("=" * 80)
print("✅ TESTS TERMINÉS")
print("=" * 80)
