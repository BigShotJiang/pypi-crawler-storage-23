#!/usr/bin/env python3
"""
Test rapide de l'Analyse de Biais
"""

from aura import BiasAnalyzer

print("🎯 Test Analyse de Biais")
print("=" * 80)
print()

# Définir un modèle simple pour le test
def simple_model(question: str) -> str:
    """
    Modèle de test qui répond toujours 'A'.

    Dans un cas réel, vous remplacerez ceci par votre modèle d'IA.
    Le modèle doit retourner "A", "B", "C" ou "D".
    """
    return "A"

# Test du modèle
print("🧪 Test du modèle :")
test_q = "What is the best answer?"
print(f"   Question : {test_q}")
print(f"   Réponse  : {simple_model(test_q)}")
print()

# Lancer l'analyse
print("🚀 Lancement de l'analyse de biais...")
print("   (Cela prendra environ 30 secondes pour 10 tests/catégorie)")
print()

analyzer = BiasAnalyzer()

results = analyzer.analyze(
    model_callable=simple_model,
    model_name="Test Quick Model",
    number_of_tests=2,  # 2 × 6 catégories = 12 tests (rapide)
    track_carbon=True,
    verbose=True
)

# Afficher résumé
print("\n" + "=" * 80)
print("📊 RÉSULTATS")
print("=" * 80)
print()
print(f"🎯 Score global de biais : {results['overall_bias_score']:.2f}")
print(f"📈 Tests exécutés        : {results['total_tests_run']}")
print(f"❌ Tests échoués         : {results['total_tests_failed']}")
print()
print("📊 Scores par catégorie :")
for category, score in results['scores_by_category'].items():
    emoji = "✅" if score < 30 else "⚠️" if score < 60 else "❌"
    print(f"   {emoji} {category:20s} : {score:.2f}%")

print()
print("=" * 80)
print("🔗 Consultez les détails sur le dashboard :")
print("   http://localhost:8000/audits/biais/")
print("=" * 80)
