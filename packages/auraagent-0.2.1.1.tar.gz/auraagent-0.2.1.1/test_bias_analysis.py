#!/usr/bin/env python3
"""
Test rapide de l'analyse de biais avec la configuration corrigée.
Ce script valide que BiasAnalyzer fonctionne correctement avec ~/.aura.config
"""
from aura import BiasAnalyzer


def simple_model(question: str) -> str:
    """Modèle de test qui répond toujours 'A'."""
    return "A"


def main():
    print("🎯 Test Analyse de Biais")
    print("=" * 80)
    print()

    # Configuration
    EXECUTION_ID = "b3f0936a-75b0-415c-ad8c-74e23365c329"

    print("🧪 Test du modèle :")
    test_q = "What is the best answer?"
    print(f"   Question : {test_q}")
    print(f"   Réponse  : {simple_model(test_q)}")
    print()

    print("🔧 Initialisation de BiasAnalyzer...")
    print("   (Charge automatiquement ~/.aura.config)")
    analyzer = BiasAnalyzer()
    print("   ✅ BiasAnalyzer initialisé")
    print()

    print("🚀 Lancement de l'analyse de biais...")
    print("   (Cela prendra environ 10-30 secondes pour 2 tests/catégorie)")
    print()

    bias_results = analyzer.analyze(
        model_callable=simple_model,
        model_name="Test Script Model",
        number_of_tests=2,  # 2 × 6 catégories = 12 tests (rapide)
        track_carbon=False,
        verbose=True,
        execution_id=EXECUTION_ID
    )

    print()
    print("=" * 80)
    print("📊 RÉSULTATS")
    print("=" * 80)
    print()
    print(f"🎯 Score global de biais : {bias_results['overall_bias_score']:.2f}")
    print(f"📈 Tests exécutés        : {bias_results['total_tests_run']}")
    print(f"❌ Tests échoués         : {bias_results['total_tests_failed']}")
    print()
    print("📊 Scores par catégorie :")
    for category, score in bias_results['scores_by_category'].items():
        emoji = "✅" if score < 30 else "⚠️" if score < 60 else "❌"
        print(f"   {emoji} {category:20s} : {score:.2f}%")

    print()
    print("✅ Test terminé avec succès !")
    print(f"🔗 Dashboard : http://localhost:8000/audits/executions/{EXECUTION_ID}/")


if __name__ == "__main__":
    main()
