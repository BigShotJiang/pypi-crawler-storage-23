#!/usr/bin/env python3
"""
Test de l'API /api/init-workspace/ directement.
"""
import requests

API_KEY = "wZFIXkg_xtApj9SE3uMpLkH7PsUcTqlw2QXrtf_41eM"
API_URL = "http://localhost:8000"

print("=" * 80)
print("TEST API /api/init-workspace/")
print("=" * 80)
print()

try:
    print("📡 Appel de l'API...")
    response = requests.post(
        f"{API_URL}/api/init-workspace/",
        headers={"Authorization": f"Token {API_KEY}"},
        json={},
        timeout=10
    )

    print(f"   Status: {response.status_code}")
    print()

    if response.ok:
        data = response.json()
        print("✅ Réponse reçue :")
        print(f"   Projet ID    : {data.get('project_id')}")
        print(f"   Projet nom   : {data.get('project_name')}")
        print(f"   Exec ID      : {data.get('execution_id')}")
        print(f"   Exec nom     : {data.get('execution_name')}")
        print(f"   Message      : {data.get('message')}")
        print()

        # Maintenant mettre à jour ~/.aura.config
        print("📝 Mise à jour de ~/.aura.config...")
        from aura.core.config import AuraConfig

        cfg = AuraConfig()
        if not cfg.exists():
            cfg._parser.add_section('aura')
            cfg._parser.set('aura', 'api_endpoint', API_URL)
            cfg._parser.set('aura', 'api_key', API_KEY)
        else:
            cfg.load()

        cfg._parser.set('aura', 'default_project_id', data.get('project_id'))
        cfg._parser.set('aura', 'default_execution_id', data.get('execution_id'))
        cfg.save()

        print("   ✅ Configuration sauvegardée")
        print()

        # Vérifier
        cfg2 = AuraConfig().load()
        print("🔍 Vérification :")
        print(f"   Projet ID : {cfg2.default_project_id}")
        print(f"   Exec ID   : {cfg2.default_execution_id}")

    else:
        print(f"❌ Erreur {response.status_code}")
        print(f"   {response.text}")

except Exception as e:
    print(f"❌ Erreur : {e}")
    import traceback
    traceback.print_exc()

print()
print("=" * 80)
