#!/usr/bin/env python3
"""
Test complet du système d'exécutions - Aura

Ce script teste l'intégration complète :
1. Création d'un audit de biais lié à un projet avec execution_id
2. Tracking carbone lié au même projet et execution_id
3. Vérification que les données sont bien groupées

Prérequis :
- auraagent installé et configuré (aura init)
- Serveur Django en cours d'exécution
"""

import datetime
from aura import BiasAnalyzer, AuraCarbon

# ============================================================================
# CONFIGURATION
# ============================================================================

# IDs de projets existants (récupérés de la base)
PROJECT_IDS = {
    'bert_sentiment': 'e88ddad4-f719-44c3-ab20-8d82859b72c7',
    'audit_test': 'e4c6d8a8-6728-4fca-a663-d9cfeacb48de'
}

# Choisir le projet à utiliser
PROJECT_ID = PROJECT_IDS['bert_sentiment']

# Générer un execution_id unique basé sur le timestamp
EXECUTION_ID = f"test-run-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"

print("=" * 80)
print("TEST SYSTÈME D'EXÉCUTIONS - AURA")
print("=" * 80)
print()
print(f"📋 Projet ID: {PROJECT_ID}")
print(f"🔄 Execution ID: {EXECUTION_ID}")
print()

# ============================================================================
# PARTIE 1 : ANALYSE DE BIAIS
# ============================================================================

print("=" * 80)
print("🎯 PARTIE 1 : ANALYSE DE BIAIS AVEC PROJECT_ID + EXECUTION_ID")
print("=" * 80)
print()

# Définir un modèle simple pour le test
def test_model(question: str) -> str:
    """
    Modèle de test qui répond de manière pseudo-aléatoire.

    Dans un cas réel, vous remplacerez ceci par votre modèle d'IA.
    """
    # Simple heuristique basée sur la longueur de la question
    length = len(question)
    if length < 50:
        return "A"
    elif length < 100:
        return "B"
    elif length < 150:
        return "C"
    else:
        return "D"


# Lancer l'analyse avec project_id et execution_id
analyzer = BiasAnalyzer()

try:
    print("🚀 Lancement de l'analyse de biais...")
    print(f"   → Nombre de tests: 2 questions/catégorie (rapide)")
    print(f"   → Project ID: {PROJECT_ID}")
    print(f"   → Execution ID: {EXECUTION_ID}")
    print(f"   → Tracking carbone: Activé")
    print()

    results = analyzer.analyze(
        model_callable=test_model,
        model_name=f"Test Model - {EXECUTION_ID}",
        number_of_tests=2,  # Rapide : 2 × 6 = 12 tests
        track_carbon=True,
        verbose=True,
        project_id=PROJECT_ID,
        execution_id=EXECUTION_ID
    )

    print()
    print("✅ Analyse de biais terminée avec succès!")
    print(f"   → Audit ID: {results.get('audit_id', 'N/A')}")
    print(f"   → Score global: {results['overall_bias_score']:.2f}")
    print(f"   → Tests exécutés: {results['total_tests_run']}")
    print()

except Exception as e:
    print(f"❌ Erreur lors de l'analyse de biais: {e}")
    print()


# ============================================================================
# PARTIE 2 : TRACKING CARBONE
# ============================================================================

print("=" * 80)
print("🌱 PARTIE 2 : TRACKING CARBONE AVEC PROJECT_ID + EXECUTION_ID")
print("=" * 80)
print()

try:
    print("🚀 Démarrage du tracking carbone...")
    print(f"   → Project ID: {PROJECT_ID}")
    print(f"   → Execution ID: {EXECUTION_ID}")
    print()

    # Utiliser le même execution_id pour lier au même "run"
    with AuraCarbon(
        project_name=f"Test Carbon - {EXECUTION_ID}",
        project_id=PROJECT_ID,
        execution_id=EXECUTION_ID,
        measure_power_secs=5
    ) as tracker:
        print("⚙️  Simulation d'un calcul intensif...")

        # Simulation d'un calcul
        import time
        result = 0
        for i in range(1000000):
            result += i ** 2

        time.sleep(2)  # Quelques secondes pour avoir une mesure

        print(f"   ✓ Calcul terminé: {result}")

    print()
    print("✅ Tracking carbone terminé!")
    print()

except Exception as e:
    print(f"❌ Erreur lors du tracking carbone: {e}")
    print()


# ============================================================================
# PARTIE 3 : SECONDE EXÉCUTION (pour tester le groupement)
# ============================================================================

print("=" * 80)
print("🔁 PARTIE 3 : SECONDE EXÉCUTION (POUR TESTER LE GROUPEMENT)")
print("=" * 80)
print()

EXECUTION_ID_2 = f"test-run-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}-bis"

print(f"🔄 Nouvelle Execution ID: {EXECUTION_ID_2}")
print()

try:
    # Petite analyse rapide
    print("🚀 Lancement d'une petite analyse...")

    results_2 = analyzer.analyze(
        model_callable=test_model,
        model_name=f"Test Model 2 - {EXECUTION_ID_2}",
        number_of_tests=2,
        track_carbon=True,
        verbose=False,  # Mode silencieux
        project_id=PROJECT_ID,
        execution_id=EXECUTION_ID_2
    )

    print(f"✅ Seconde analyse terminée!")
    print(f"   → Score: {results_2['overall_bias_score']:.2f}")
    print()

except Exception as e:
    print(f"❌ Erreur: {e}")
    print()


# ============================================================================
# RÉSUMÉ
# ============================================================================

print("=" * 80)
print("📊 RÉSUMÉ")
print("=" * 80)
print()
print("✅ Tests terminés avec succès!")
print()
print("🔗 Vérifiez maintenant sur le dashboard:")
print()
print(f"   1. Liste des projets:")
print(f"      http://localhost:8000/audits/projects/")
print()
print(f"   2. Détail du projet (avec liste des exécutions):")
print(f"      http://localhost:8000/audits/projects/{PROJECT_ID}/")
print()
print(f"   3. Détail de la première exécution:")
print(f"      http://localhost:8000/audits/projects/{PROJECT_ID}/executions/{EXECUTION_ID}/")
print()
print(f"   4. Détail de la seconde exécution:")
print(f"      http://localhost:8000/audits/projects/{PROJECT_ID}/executions/{EXECUTION_ID_2}/")
print()
print("=" * 80)
print()
print("📝 Vérifications à faire sur le dashboard:")
print()
print("   ✓ Sur la page du projet, vous devriez voir 2 exécutions")
print("   ✓ Chaque exécution devrait montrer:")
print("       - 1 audit de biais")
print("       - Des événements carbone")
print("   ✓ Les exécutions sont triées par date (plus récentes en premier)")
print("   ✓ En cliquant sur 'Voir détails', vous voyez les résultats complets")
print()
print("=" * 80)
