#!/bin/bash
# Script de nettoyage des anciens fichiers backup JSON

echo "🧹 Nettoyage des fichiers backup..."
echo ""

# Chercher les fichiers backup dans le répertoire courant
count=$(find . -maxdepth 1 -name "bias_*.json" -type f 2>/dev/null | wc -l | tr -d ' ')

if [ "$count" -eq 0 ]; then
    echo "✅ Aucun fichier backup trouvé."
else
    echo "📁 $count fichier(s) backup trouvé(s):"
    find . -maxdepth 1 -name "bias_*.json" -type f -exec ls -lh {} \;
    echo ""

    read -p "Voulez-vous supprimer ces fichiers ? (y/N) " -n 1 -r
    echo

    if [[ $REPLY =~ ^[Yy]$ ]]; then
        find . -maxdepth 1 -name "bias_*.json" -type f -delete
        echo "✅ Fichiers supprimés."
    else
        echo "❌ Opération annulée."
    fi
fi

echo ""
echo "✨ Terminé !"
