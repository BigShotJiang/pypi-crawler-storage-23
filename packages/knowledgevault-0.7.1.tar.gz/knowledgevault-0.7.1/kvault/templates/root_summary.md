---
created: '{{DATE}}'
updated: '{{DATE}}'
source: kvault-init
aliases: []
---

# Personal Knowledge Base

**Owner:** {{OWNER_NAME}}

Executive view of everything tracked in this knowledge base.

## People

Organized by relationship type.

- **Family:** (add family members)
- **Friends:** (add friends)
- **Contacts:** (add professional contacts, acquaintances)

## Projects

Active work and research initiatives.

(none yet)

## Accomplishments

Professional wins and quantifiable impacts.

(none yet)

## Journal

Temporal log of interactions and events. See [journal/](journal/) for full history.

---

*Last updated: {{DATE}}*
