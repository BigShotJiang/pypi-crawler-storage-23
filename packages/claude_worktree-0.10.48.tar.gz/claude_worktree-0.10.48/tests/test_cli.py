"""Tests for CLI interface - classicist style."""

import subprocess
from pathlib import Path

from typer.testing import CliRunner

from claude_worktree.cli import app

runner = CliRunner()


def test_cli_help() -> None:
    """Test that help command works."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Claude Code × git worktree helper CLI" in result.stdout


def test_cli_version() -> None:
    """Test version flag."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "claude-worktree version" in result.stdout


def test_new_command_help() -> None:
    """Test new command help."""
    result = runner.invoke(app, ["new", "--help"])
    assert result.exit_code == 0
    assert "Create a new worktree" in result.stdout


def test_new_command_execution(temp_git_repo: Path, disable_claude) -> None:
    """Test new command with real execution."""
    result = runner.invoke(app, ["new", "test-feature"])

    # Command should succeed
    assert result.exit_code == 0

    # Verify worktree was actually created
    expected_path = temp_git_repo.parent / f"{temp_git_repo.name}-test-feature"
    assert expected_path.exists()

    # Verify branch exists
    git_result = subprocess.run(
        ["git", "branch", "--list", "test-feature"],
        cwd=temp_git_repo,
        capture_output=True,
        text=True,
    )
    assert "test-feature" in git_result.stdout


def test_new_command_with_base(temp_git_repo: Path, disable_claude) -> None:
    """Test new command with base branch specification."""
    # Create develop branch
    subprocess.run(
        ["git", "branch", "develop"],
        cwd=temp_git_repo,
        check=True,
        capture_output=True,
    )

    result = runner.invoke(app, ["new", "from-develop", "--base", "develop"])

    assert result.exit_code == 0
    expected_path = temp_git_repo.parent / f"{temp_git_repo.name}-from-develop"
    assert expected_path.exists()


def test_new_command_custom_path(temp_git_repo: Path, disable_claude) -> None:
    """Test new command with custom path."""
    custom_path = temp_git_repo.parent / "my-custom-worktree"

    result = runner.invoke(app, ["new", "custom", "--path", str(custom_path)])

    assert result.exit_code == 0
    assert custom_path.exists()


def test_new_command_invalid_base(temp_git_repo: Path) -> None:
    """Test new command with invalid base branch."""
    result = runner.invoke(app, ["new", "feature", "--base", "nonexistent"])

    # Should fail
    assert result.exit_code != 0
    assert "Error" in result.stdout


def test_list_command_help() -> None:
    """Test list command help."""
    result = runner.invoke(app, ["list", "--help"])
    assert result.exit_code == 0
    assert "List all worktrees" in result.stdout


def test_list_command_execution(temp_git_repo: Path, disable_claude) -> None:
    """Test list command with real worktrees."""
    # Create some worktrees
    runner.invoke(app, ["new", "wt1"])
    runner.invoke(app, ["new", "wt2"])

    # List worktrees
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "wt1" in result.stdout
    assert "wt2" in result.stdout


def test_status_command_help() -> None:
    """Test status command help."""
    result = runner.invoke(app, ["status", "--help"])
    assert result.exit_code == 0
    assert "Show status" in result.stdout


def test_status_command_execution(temp_git_repo: Path, disable_claude, monkeypatch) -> None:
    """Test status command from within worktree."""
    # Create worktree
    runner.invoke(app, ["new", "status-test"])
    worktree_path = temp_git_repo.parent / f"{temp_git_repo.name}-status-test"

    # Change to worktree
    monkeypatch.chdir(worktree_path)

    # Show status
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "status-test" in result.stdout


def test_delete_command_help() -> None:
    """Test delete command help."""
    result = runner.invoke(app, ["delete", "--help"])
    assert result.exit_code == 0
    assert "Delete a worktree" in result.stdout


def test_delete_command_by_branch(temp_git_repo: Path, disable_claude) -> None:
    """Test delete command by branch name."""
    # Create worktree
    runner.invoke(app, ["new", "delete-me"])
    worktree_path = temp_git_repo.parent / f"{temp_git_repo.name}-delete-me"
    assert worktree_path.exists()

    # Delete by branch name
    result = runner.invoke(app, ["delete", "delete-me"])
    assert result.exit_code == 0

    # Verify removal
    assert not worktree_path.exists()


def test_delete_command_by_path(temp_git_repo: Path, disable_claude) -> None:
    """Test delete command by path."""
    # Create worktree
    runner.invoke(app, ["new", "delete-path"])
    worktree_path = temp_git_repo.parent / f"{temp_git_repo.name}-delete-path"

    # Delete by path
    result = runner.invoke(app, ["delete", str(worktree_path)])
    assert result.exit_code == 0
    assert not worktree_path.exists()


def test_delete_command_keep_branch(temp_git_repo: Path, disable_claude) -> None:
    """Test delete command with keep-branch flag."""
    # Create worktree
    runner.invoke(app, ["new", "keep-br"])
    worktree_path = temp_git_repo.parent / f"{temp_git_repo.name}-keep-br"

    # Delete with keep-branch
    result = runner.invoke(app, ["delete", "keep-br", "--keep-branch"])
    assert result.exit_code == 0

    # Worktree removed
    assert not worktree_path.exists()

    # Branch still exists
    git_result = subprocess.run(
        ["git", "branch", "--list", "keep-br"],
        cwd=temp_git_repo,
        capture_output=True,
        text=True,
    )
    assert "keep-br" in git_result.stdout


def test_new_command_with_iterm_tab_flag(temp_git_repo: Path, disable_claude) -> None:
    """Test that new command accepts --iterm-tab flag."""
    result = runner.invoke(app, ["new", "iterm-tab-test"])
    assert result.exit_code == 0

    # Verify worktree was created
    expected_path = temp_git_repo.parent / f"{temp_git_repo.name}-iterm-tab-test"
    assert expected_path.exists()

    # Clean up
    runner.invoke(app, ["delete", "iterm-tab-test"])


def test_resume_command_with_iterm_tab_flag(temp_git_repo: Path, disable_claude) -> None:
    """Test that resume command accepts --iterm-tab flag."""
    # Create a worktree first
    runner.invoke(app, ["new", "resume-tab-test"])

    # Resume with --iterm-tab flag (won't actually launch on non-macOS, but should accept the flag)
    result = runner.invoke(app, ["resume", "resume-tab-test"])
    assert result.exit_code == 0

    # Clean up
    runner.invoke(app, ["delete", "resume-tab-test"])


def test_shell_command_help() -> None:
    """Test shell command help."""
    result = runner.invoke(app, ["shell", "--help"])
    assert result.exit_code == 0
    assert "shell" in result.stdout.lower()
    assert "command" in result.stdout.lower()


def test_shell_command_with_branch_and_command(temp_git_repo: Path, disable_claude) -> None:
    """Test shell command executes command in worktree."""
    # Create worktree
    runner.invoke(app, ["new", "shell-test"])
    worktree_path = temp_git_repo.parent / f"{temp_git_repo.name}-shell-test"

    # Execute command in worktree (no -- separator needed)
    result = runner.invoke(app, ["shell", "shell-test", "echo", "test"])
    # Command execution exits with the command's exit code
    assert result.exit_code == 0
    # Check that command was executed (shows in message)
    assert "Executing in" in result.stdout
    # Check for worktree path (may be split across lines in CI, so check without whitespace)
    stdout_no_ws = result.stdout.replace("\n", "").replace(" ", "")
    path_no_ws = str(worktree_path).replace(" ", "")
    assert path_no_ws in stdout_no_ws

    # Clean up
    runner.invoke(app, ["delete", "shell-test"])


def test_shell_command_nonexistent_branch(temp_git_repo: Path) -> None:
    """Test shell command with nonexistent branch."""
    result = runner.invoke(app, ["shell", "nonexistent", "ls"])
    assert result.exit_code != 0
    assert "Error" in result.stdout


def test_sync_command_help(temp_git_repo: Path) -> None:
    """Test sync command help."""
    result = runner.invoke(app, ["sync", "--help"])
    assert result.exit_code == 0
    assert "Synchronize worktree" in result.stdout


def test_sync_command_accepts_flags(temp_git_repo: Path, disable_claude) -> None:
    """Test sync command accepts all flags."""
    result = runner.invoke(app, ["sync", "--help"])
    assert result.exit_code == 0
    # Check for flag names (ANSI codes may be present in colored output)
    assert "all" in result.stdout and "Sync all worktrees" in result.stdout
    assert (
        "fetch" in result.stdout and "only" in result.stdout and "without rebasing" in result.stdout
    )


def test_clean_command_help(temp_git_repo: Path) -> None:
    """Test clean command help."""
    result = runner.invoke(app, ["clean", "--help"])
    assert result.exit_code == 0
    assert "Batch cleanup of worktrees" in result.stdout


def test_clean_command_accepts_flags(temp_git_repo: Path, disable_claude) -> None:
    """Test clean command accepts all flags."""
    result = runner.invoke(app, ["clean", "--help"])
    assert result.exit_code == 0
    # Check for flag names (ANSI codes may be present in colored output)
    assert "merged" in result.stdout and "branches already merged" in result.stdout
    assert "older" in result.stdout and "than" in result.stdout and "days" in result.stdout
    assert "interactive" in result.stdout.lower() or "-i" in result.stdout
    assert "dry" in result.stdout and "run" in result.stdout
    # Check that auto-prune is mentioned in help
    assert "prune" in result.stdout.lower()


def test_pr_command_help(temp_git_repo: Path) -> None:
    """Test pr command help."""
    result = runner.invoke(app, ["pr", "--help"])
    assert result.exit_code == 0
    assert "pull request" in result.stdout.lower() or "pull-request" in result.stdout.lower()
    assert "GitHub" in result.stdout


def test_pr_command_flags(temp_git_repo: Path) -> None:
    """Test pr command accepts all flags."""
    result = runner.invoke(app, ["pr", "--help"])
    assert result.exit_code == 0
    # Check for flag names (handle ANSI color codes by checking components)
    assert "no" in result.stdout and "push" in result.stdout
    assert "title" in result.stdout and "-t" in result.stdout
    assert "body" in result.stdout and "-b" in result.stdout
    assert "draft" in result.stdout


def test_merge_command_help(temp_git_repo: Path) -> None:
    """Test merge command help."""
    result = runner.invoke(app, ["merge", "--help"])
    assert result.exit_code == 0
    assert "merge" in result.stdout.lower()
    assert "base branch" in result.stdout.lower()


def test_merge_command_flags(temp_git_repo: Path) -> None:
    """Test merge command accepts all flags."""
    result = runner.invoke(app, ["merge", "--help"])
    assert result.exit_code == 0
    # Check for flag names (handle ANSI color codes by checking components)
    assert "push" in result.stdout
    assert "interactive" in result.stdout and "-i" in result.stdout
    assert "dry" in result.stdout and "run" in result.stdout


# Shell function tests


def test_shell_function_help() -> None:
    """Test _shell-function command help."""
    result = runner.invoke(app, ["_shell-function", "--help"])
    assert result.exit_code == 0
    assert "shell function" in result.stdout.lower()


def test_shell_function_bash() -> None:
    """Test _shell-function outputs bash script."""
    result = runner.invoke(app, ["_shell-function", "bash"])
    assert result.exit_code == 0
    assert "cw-cd()" in result.stdout
    assert "bash" in result.stdout.lower() or "zsh" in result.stdout.lower()
    assert "_cw_cd_completion" in result.stdout


def test_shell_function_zsh() -> None:
    """Test _shell-function outputs zsh script."""
    result = runner.invoke(app, ["_shell-function", "zsh"])
    assert result.exit_code == 0
    assert "cw-cd()" in result.stdout
    assert "_cw_cd_zsh" in result.stdout


def test_shell_function_fish() -> None:
    """Test _shell-function outputs fish script."""
    result = runner.invoke(app, ["_shell-function", "fish"])
    assert result.exit_code == 0
    assert "function cw-cd" in result.stdout
    assert "complete -c cw-cd" in result.stdout


def test_shell_function_powershell() -> None:
    """Test _shell-function outputs PowerShell script."""
    result = runner.invoke(app, ["_shell-function", "powershell"])
    assert result.exit_code == 0
    assert "function cw-cd" in result.stdout
    assert "Register-ArgumentCompleter" in result.stdout
    assert "Set-Location" in result.stdout


def test_shell_function_pwsh_alias() -> None:
    """Test _shell-function accepts 'pwsh' as PowerShell alias."""
    result = runner.invoke(app, ["_shell-function", "pwsh"])
    assert result.exit_code == 0
    assert "function cw-cd" in result.stdout
    assert "Register-ArgumentCompleter" in result.stdout


def test_shell_function_invalid_shell() -> None:
    """Test _shell-function rejects invalid shell."""
    result = runner.invoke(app, ["_shell-function", "invalid"])
    assert result.exit_code != 0
    assert "Error" in result.stderr or "Invalid" in result.stderr


def test_shell_setup_help() -> None:
    """Test shell-setup command help."""
    result = runner.invoke(app, ["shell-setup", "--help"])
    assert result.exit_code == 0
    assert "shell" in result.stdout.lower()
    assert "setup" in result.stdout.lower() or "install" in result.stdout.lower()


# Branch completion tests


def test_complete_all_branches(temp_git_repo: Path) -> None:
    """Test complete_all_branches returns local branches."""
    from claude_worktree.cli import complete_all_branches

    branches = complete_all_branches()
    assert "main" in branches


def test_complete_all_branches_includes_remote(temp_git_repo: Path, tmp_path: Path) -> None:
    """Test complete_all_branches includes remote branches with origin/ stripped."""
    from claude_worktree.cli import complete_all_branches

    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )

    # Add the bare repo as a remote and push a remote-only branch
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "branch", "remote-feature"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "push", "origin", "remote-feature"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "branch", "-D", "remote-feature"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    branches = complete_all_branches()
    # Should contain both local "main" and remote "remote-feature" (without origin/ prefix)
    assert "main" in branches
    assert "remote-feature" in branches
    # Should NOT contain "origin/remote-feature"
    assert "origin/remote-feature" not in branches


def test_complete_new_branch_names_excludes_worktrees(
    temp_git_repo: Path, disable_claude
) -> None:
    """Test complete_new_branch_names excludes branches that have worktrees."""
    from claude_worktree.cli import complete_new_branch_names

    # Create a branch and worktree
    subprocess.run(
        ["git", "branch", "available-branch"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    # Create worktree for another branch
    runner.invoke(app, ["new", "worktree-branch"])

    names = complete_new_branch_names()

    # "available-branch" should be in the list (no worktree)
    assert "available-branch" in names

    # "worktree-branch" should NOT be in the list (has a worktree)
    assert "worktree-branch" not in names

    # "main" should NOT be in the list (current branch + has worktree)
    assert "main" not in names


def test_complete_all_branches_not_in_repo(tmp_path: Path, monkeypatch) -> None:
    """Test complete_all_branches returns empty list when not in a git repo."""
    from claude_worktree.cli import complete_all_branches

    non_repo = tmp_path / "not_a_repo"
    non_repo.mkdir()
    monkeypatch.chdir(non_repo)

    branches = complete_all_branches()
    assert branches == []


def test_complete_new_branch_names_not_in_repo(tmp_path: Path, monkeypatch) -> None:
    """Test complete_new_branch_names returns empty list when not in a git repo."""
    from claude_worktree.cli import complete_new_branch_names

    non_repo = tmp_path / "not_a_repo"
    non_repo.mkdir()
    monkeypatch.chdir(non_repo)

    names = complete_new_branch_names()
    assert names == []


def test_get_all_branch_names_filters_head(temp_git_repo: Path, tmp_path: Path) -> None:
    """Test _get_all_branch_names filters HEAD entries from remote."""
    from claude_worktree.cli import _get_all_branch_names

    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    branches = _get_all_branch_names()

    # HEAD should be filtered out (origin/HEAD -> HEAD)
    assert "HEAD" not in branches
    # origin/HEAD should not appear as-is
    assert "origin/HEAD" not in branches
    # But main should be present
    assert "main" in branches


def test_get_all_branch_names_with_slashes(temp_git_repo: Path, tmp_path: Path) -> None:
    """Test _get_all_branch_names strips origin/ from branches with slashes."""
    from claude_worktree.cli import _get_all_branch_names

    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    # Create and push branch with slashes
    subprocess.run(
        ["git", "branch", "feature/auth/login"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "push", "origin", "feature/auth/login"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "branch", "-D", "feature/auth/login"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    branches = _get_all_branch_names()

    # Should contain "feature/auth/login" not "origin/feature/auth/login"
    assert "feature/auth/login" in branches
    assert "origin/feature/auth/login" not in branches


def test_get_all_branch_names_deduplicates(temp_git_repo: Path, tmp_path: Path) -> None:
    """Test _get_all_branch_names deduplicates branches that exist locally and remotely."""
    from claude_worktree.cli import _get_all_branch_names

    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    branches = _get_all_branch_names()

    # "main" exists both locally and as origin/main - should appear only once
    assert branches.count("main") == 1


def test_complete_new_branch_names_includes_remote(
    temp_git_repo: Path, disable_claude, tmp_path: Path
) -> None:
    """Test complete_new_branch_names includes remote-only branches."""
    from claude_worktree.cli import complete_new_branch_names

    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    # Push a branch to remote only
    subprocess.run(
        ["git", "branch", "remote-only"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "push", "origin", "remote-only"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "branch", "-D", "remote-only"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    names = complete_new_branch_names()

    # Remote-only branch should be available for completion
    assert "remote-only" in names

    # Current branch (main) should still be excluded
    assert "main" not in names


def test_new_command_with_remote_branch(
    temp_git_repo: Path, disable_claude, tmp_path: Path
) -> None:
    """Test cw new end-to-end with a remote-only branch via CLI."""
    # Create a bare "remote" repository
    remote_path = tmp_path / "remote_repo.git"
    subprocess.run(
        ["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    # Create a remote-only branch
    subprocess.run(
        ["git", "branch", "remote-cli-test"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "push", "origin", "remote-cli-test"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "branch", "-D", "remote-cli-test"],
        cwd=temp_git_repo, check=True, capture_output=True,
    )

    result = runner.invoke(app, ["new", "remote-cli-test"])

    assert result.exit_code == 0
    assert "Remote branch found" in result.stdout or "tracking remote branch" in result.stdout

    # Verify worktree was created
    expected_path = temp_git_repo.parent / f"{temp_git_repo.name}-remote-cli-test"
    assert expected_path.exists()

    # Clean up
    runner.invoke(app, ["delete", "remote-cli-test"])
