import os
import pandas as pd
from typing import List, Optional, Callable, Union
from rich.pretty import pprint
import plotly.express as px
from ..common.common import pprint_local_path


class PlotlyUtils:
    @staticmethod
    # Extract experiment IDs from complex naming convention
    def exp_id_extractor(df: pd.DataFrame) -> pd.Series:
        # MainPC__ds_UFireIndoor2__mt_temp_method_motion_block__9896ed2e67e7__20260202.133758
        exp_names = df["Name"].to_list()
        exp_ids = []
        for name in exp_names:
            parts = name.split("__")
            exp_id = parts[-2] if len(parts) >= 2 else name
            exp_ids.append(exp_id)
        # ! make sure series index matches df index
        # ! if not, it will cause misalignment issues later
        assert len(exp_ids) == len(df), "exp_id_extractor: Length mismatch"
        return pd.Series(exp_ids, index=df.index)

    @staticmethod
    def exp_id_formatter(exp_id: str) -> str:
        if len(exp_id) <= 6:
            return exp_id
        return f"{exp_id[:6]}"

    @staticmethod
    def parallel_plot(
        df_or_csv_file: Union[pd.DataFrame, str],
        dimensions: List[str] = [],
        exclude_dims: List[str] = [],
        exp_col_or_func: Union[
            str, Callable[[pd.DataFrame], pd.Series]
        ] = exp_id_extractor,
        exp_id_formatter: Optional[Callable[[str], str]] = exp_id_formatter,
        color: Optional[str] = None,
        csv_separator: str = ";",
        plot_bar_height: int = 1200,
        plot_width: int = 1500,
        title: str = "Parallel Coordinates Plot",
        template: str = "plotly_white",
        outdir: str = ".",
        outfile: str = "zresults_with_table.html",
    ):
        # 1. Unified Data Loading
        if isinstance(df_or_csv_file, str):
            df = pd.read_csv(df_or_csv_file, sep=csv_separator, encoding="utf-8")
        else:
            df = df_or_csv_file.copy()

        # 2. Extract Experiment IDs
        if callable(exp_col_or_func):
            df["exp_id"] = exp_col_or_func(df)
        elif isinstance(exp_col_or_func, str):
            if exp_col_or_func not in df.columns:
                raise ValueError(f"Column '{exp_col_or_func}' not found.")
            df["exp_id"] = df[exp_col_or_func].copy()
            exclude_dims.append(exp_col_or_func)
        else:
            raise ValueError("exp_col_or_func must be a column name or a callable.")

        # 3. Setup Plot Dimensions
        # Priority: explicit dimensions -> all columns minus exclusions
        if not dimensions:
            dimensions = [
                c for c in df.columns if c not in exclude_dims and c != "exp_id"
            ]

        df["numeric_id"] = range(len(df))
        # Ensure numeric_id is the first axis for the labels to work
        final_plot_dims = ["numeric_id"] + [
            d for d in dimensions if d != "numeric_id" and d in df.columns
        ]

        pprint(f"Generating plot: {title}")

        # 4. Create and Configure Plotly Figure
        fig = px.parallel_coordinates(
            df,
            dimensions=final_plot_dims,
            color=color,
            title=title,
            template=template,
        )

        # Map string IDs to the numeric axis
        fig.data[0].dimensions[0].tickvals = list(df["numeric_id"])
        fig.data[0].dimensions[0].ticktext = (
            [exp_id_formatter(i) for i in df["exp_id"]]
            if exp_id_formatter
            else df["exp_id"]
        )
        fig.data[0].dimensions[0].label = "Exp IDs"

        fig.update_layout(
            title={
                "text": title,
                "y": 0.98,
                "x": 0.5,
                "xanchor": "center",
                "yanchor": "top",
            },
            width=plot_width,
            height=plot_bar_height,
            margin=dict(l=150, r=50, t=150, b=50),
        )

        # 5. Prepare Table Display
        # Clean up columns: Move exp_id to front, drop internal numeric_id
        cols = ["exp_id"] + [c for c in df.columns if c not in ["exp_id", "numeric_id"]]
        cols = [col for col in cols if col not in exclude_dims]

        df_display = df[cols].copy()
        df_display.insert(0, "Selection", '<button class="select-btn">Select</button>')

        chart_html = fig.to_html(full_html=False, include_plotlyjs="cdn")

        table_html = df_display.to_html(
            classes="display nowrap", table_id="exp_table", index=False, escape=False
        )

        final_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Experiment Dashboard</title>
            <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
            <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>
            <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
            <style>
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    margin: 20px;
                    background-color: #f0f2f5;
                }}
                .container {{
                    background: white;
                    padding: 30px;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
                }}

                /* --- TABLE FONT SIZE FIX --- */
                table.dataTable {{
                    font-size: 11px; /* Smaller overall text */
                }}
                table.dataTable thead th {{
                    background-color: #333;
                    color: white;
                    padding: 8px 12px !important;
                    padding-right: 20px !important; /* THIS LINE FIXES THE OVERLAP */
                    font-size: 12px;
                    position: relative; /* Ensures sort icons align correctly */
                }}
                table.dataTable tbody td {{
                    padding: 4px 8px !important; /* Compact rows */
                }}

                #exp_table tbody tr:nth-child(even), #selected_table tbody tr:nth-child(even) {{ background-color: #f2f2f2; }}
                #exp_table tbody tr:nth-child(odd), #selected_table tbody tr:nth-child(odd) {{ background-color: #ffffff; }}
                #exp_table tbody tr:hover, #selected_table tbody tr:hover {{ background-color: #adadad; }}

                h2 {{ color: #2c3e50; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 40px; }}

                /* Smaller buttons */
                .select-btn {{ background-color: #28a745; color: white; border: none; padding: 3px 7px; cursor: pointer; border-radius: 4px; font-size: 10px; }}
                .remove-btn {{ background-color: #dc3545; color: white; border: none; padding: 3px 7px; cursor: pointer; border-radius: 4px; font-size: 10px; }}
                .clear-btn {{ background-color: #6c757d; color: white; border: none; padding: 8px 12px; cursor: pointer; border-radius: 4px; margin-bottom: 10px; font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="container">
                {chart_html}

                <h2>Selected Experiments</h2>
                <button id="clear_all" class="clear-btn">Clear All</button>
                <div style="overflow-x:auto; margin-bottom: 40px;">
                    <table id="selected_table" class="display nowrap">
                        <thead>{df_display.iloc[:0].to_html(index=False, escape=False).split("<thead>")[1].split("</thead>")[0]}</thead>
                        <tbody></tbody>
                    </table>
                </div>

                <hr>

                <h2>Full Experiment Raw Data</h2>
                <div style="overflow-x:auto;">
                    {table_html}
                </div>
            </div>

            <script>
                $(document).ready( function () {{
                    var mainTable = $('#exp_table').DataTable({{
                        "pageLength": 25,
                        "order": [[ 5, "desc" ]],
                        "stripeClasses": []
                    }});

                    var selectedTable = $('#selected_table').DataTable({{
                        "paging": false,
                        "searching": false,
                        "info": false,
                        "stripeClasses": []
                    }});

                    // Handle Select button
                    $('#exp_table tbody').on('click', '.select-btn', function () {{
                        var data = mainTable.row($(this).parents('tr')).data();
                        var rowNode = $(this).parents('tr');

                        // Change button to remove in the new table
                        var newData = [...data];
                        newData[0] = '<button class="remove-btn">Remove</button>';

                        // Check if already in selectedTable (optional but good)
                        var alreadyExists = false;
                        selectedTable.rows().every(function() {{
                            if(this.data()[1] === data[1]) {{ alreadyExists = true; }}
                        }});

                        if(!alreadyExists) {{
                            selectedTable.row.add(newData).draw();
                        }}
                    }});

                    // Handle Remove button
                    $('#selected_table tbody').on('click', '.remove-btn', function () {{
                        selectedTable.row($(this).parents('tr')).remove().draw();
                    }});

                    // Handle Clear All
                    $('#clear_all').on('click', function() {{
                        selectedTable.clear().draw();
                    }});
                }});
            </script>
        </body>
        </html>
        """

        final_html_path = os.path.join(outdir, outfile)
        with open(final_html_path, "w") as f:
            f.write(final_html)

        pprint_local_path(
            final_html_path, get_wins_path=True, tag="PlotlyUtils.parallel_plot"
        )
        return fig
