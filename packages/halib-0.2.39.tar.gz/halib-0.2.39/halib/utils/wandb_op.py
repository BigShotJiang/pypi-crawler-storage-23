import glob
import wandb
import subprocess
from pathlib import Path
from typing import Optional, Literal

from tap import Tap
from tqdm import tqdm

from rich.console import Console
import yaml

wandb_console = Console()


# --- Argument Parser ---
class WandbArgs(Tap):
    # --- Auth ---
    api_key_yaml: Path = Path(
        "E:/Dev/__halib/.env.yaml"
    )  # Path to YAML file containing W&B API key

    # --- Operations ---
    op: Literal["sync", "delete"] = "delete"  # Operation to perform

    # --- Project & Filtering ---
    project: str = "paper2_main"  # W&B project name
    pattern: Optional[str] = None  # Run name pattern to match for deletion

    # --- Paths ---
    outdir: Path = Path("./zout/zruns")  # Directory containing runs to sync

    def configure(self):
        self.add_argument("-prj", "--project")
        self.add_argument("-pt", "--pattern")
        self.add_argument("-o", "--outdir")
        self.add_argument("-k", "--api_key_yaml")

    def validate(self):
        if self.op == "sync" and not self.outdir.exists():
            raise ValueError(f"Output directory {self.outdir} does not exist.")
        if self.op == "delete" and not self.project.strip():
            raise ValueError("Project name must be a non-empty string.")


def login_wandb(api_key: Optional[str]):
    """Handles authentication with Weights & Biases."""
    try:
        if api_key:
            # Explicit login with key
            wandb.login(key=api_key)
            wandb_console.print(
                "[green]Successfully logged into W&B using provided API key.[/green]"
            )
        else:
            # Attempts to find key in environment variables or netrc file
            if wandb.login():
                wandb_console.print(
                    "[blue]Logged into W&B using existing credentials.[/blue]"
                )
            else:
                wandb_console.print(
                    "[red]Authentication failed. Please provide an API key with -k.[/red]"
                )
                exit(1)
    except Exception as e:
        wandb_console.print(f"[bold red]Login Error:[/bold red] {e}")
        exit(1)


# --- Logic Functions ---


def sync_runs(outdir: Path):
    outdir_path = outdir.absolute()
    sub_dirs = [d for d in outdir_path.iterdir() if d.is_dir()]

    if not sub_dirs:
        wandb_console.print(f"[red]No subdirectories found in {outdir_path}.[/red]")
        return

    wandb_console.rule(f"Syncing from {outdir_path}")

    wandb_dirs = []
    for exp_dir in sub_dirs:
        wandb_dirs.extend(glob.glob(str(exp_dir / "wandb" / "*run-*")))

    if not wandb_dirs:
        wandb_console.print("No wandb runs found.")
        return

    for i, wandb_dir in enumerate(wandb_dirs):
        wandb_console.print(f"[{i+1}/{len(wandb_dirs)}] Syncing: {wandb_dir}")

        # Note: 'wandb sync' command uses the credentials from wandb.login()
        process = subprocess.Popen(
            ["wandb", "sync", wandb_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        for line in process.stdout:  # ty:ignore[not-iterable]
            if "ERROR" in line:
                wandb_console.print(f"[red]{line.strip()}[/red]")
        process.wait()


def delete_runs(project: str, pattern: Optional[str]):
    api = wandb.Api()
    runs = api.runs(project)

    deleted = 0
    for run in tqdm(runs, desc="Processing runs"):
        if pattern is None or pattern in run.name:
            run.delete()
            deleted += 1
    wandb_console.print(f"[green]Total runs deleted: {deleted}[/green]")


def main():
    args = WandbArgs().parse_args()
    cfg_dict = {}
    with open(args.api_key_yaml, "r") as f:
        cfg_dict = yaml.safe_load(f)
    wandb_api_key = cfg_dict.get("WANDB_API_KEY")
    assert (
        wandb_api_key is not None
    ), "W&B API key not found in the specified YAML file."
    # 1. Login first
    login_wandb(wandb_api_key)

    # 2. Execute operation
    if args.op == "sync":
        sync_runs(args.outdir)
    elif args.op == "delete":
        delete_runs(args.project, args.pattern)


if __name__ == "__main__":
    main()
