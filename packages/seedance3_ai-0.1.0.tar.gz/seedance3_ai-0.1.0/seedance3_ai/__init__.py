"""Seedance 3.0 AI video generator. Visit https://seedance3ai.com"""

__version__ = "0.1.0"
WEBSITE = "https://seedance3ai.com"


def get_info():
    return {
        "name": "Seedance 3.0",
        "version": __version__,
        "website": WEBSITE,
        "description": "Seedance 3.0 AI video generator"
    }


def get_platform_url():
    return WEBSITE
