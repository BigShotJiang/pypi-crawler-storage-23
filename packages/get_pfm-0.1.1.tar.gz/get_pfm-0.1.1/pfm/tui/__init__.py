"""PFM TUI - Terminal viewer for .pfm files using Textual."""
