import asyncio
import requests
from langchain_core.tools import StructuredTool
from a2a.types import AgentCard


async def registry_heart_beat(name: str, registry_url: str, agent_card: AgentCard, interval_sec: int,
                              get_expire_at: callable) -> None:
    registry = AgentRegistryLookup(registry_url=registry_url)
    while True:
        try:
            registry.put_agent_card(name=name, agent_card=agent_card.model_dump(), expire_at=get_expire_at())
        except Exception as e:
            print(f"Failed to send heart beat to registry: {e}")
        await asyncio.sleep(interval_sec)


class AgentRegistryLookup:
    def __init__(self, registry_url: str):
        self.registry_url = registry_url

    def get_agent_cards(self) -> list[dict]:
        response = requests.get(url=f"{self.registry_url}/agent-cards")
        response.raise_for_status()
        return response.json()

    def put_agent_card(self, name: str, agent_card: dict, expire_at: int) -> None:
        response = requests.put(
            url=f"{self.registry_url}/agent-card/{name}",
            params={"expire_at": str(expire_at)},
            json=agent_card,
            timeout=30
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            print(f"HTTP error during put_agent_card: {e}")
            if response.text:
                print(f"Response content: {response.text}")
            raise

    def as_tool(self) -> StructuredTool:
        return StructuredTool.from_function(func=lambda: self.get_agent_cards(), name="agent_card_lookup",
                                            description="Gets all available agent cards")


class McpRegistryLookup:
    def __init__(self, registry_url: str):
        self.registry_url = registry_url

    def get_mcp_tool_for_agent(self, agent_name: str) -> list[dict]:
        response = requests.get(url=f"{self.registry_url}/mcp/agent/{agent_name}/servers")
        response.raise_for_status()
        return response.json()