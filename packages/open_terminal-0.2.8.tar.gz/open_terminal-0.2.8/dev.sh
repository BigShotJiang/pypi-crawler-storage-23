#!/usr/bin/env bash
uv run uvicorn open_terminal.main:app --reload
