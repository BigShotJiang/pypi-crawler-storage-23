"""open-terminal — a barebones terminal interaction API."""
