##save as InterDate.java

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterDate extends Remote {

    // Remote method must throw RemoteException
    String display() throws RemoteException;
}


##

 ##save as ClientDate.java
import java.rmi.Naming;

public class ClientDate {

    public static void main(String[] args) {
        try {
            // Lookup remote object
            InterDate stub = (InterDate) Naming.lookup("rmi://localhost:1099/DS");

            // Call remote method
            String date = stub.display();

            // Display result
            System.out.println("Current Date and Time from Server:");
            System.out.println(date);
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
## save as ServerDate
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;

public class ServerDate extends UnicastRemoteObject implements InterDate {

    // Constructor
    protected ServerDate() throws RemoteException {
        super();
    }

    // Implementation of remote method
    public String display() throws RemoteException {
        return new Date().toString();
    }

    // Main method
    public static void main(String[] args) {
        try {
            // Start RMI registry at port 1099
            LocateRegistry.createRegistry(1099);

            // Create remote object
            ServerDate server = new ServerDate();

            // Bind object to registry
            Naming.rebind("rmi://localhost:1099/DS", server);

            System.out.println("Server is running and object registered...");
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

run javac *.java
java ServerDate
java ClientDate
