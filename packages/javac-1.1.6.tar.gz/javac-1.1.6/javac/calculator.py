
#calculator

import java.net.*;

class RPCServer {
    DatagramSocket ds;

    RPCServer() {
        try {
            ds = new DatagramSocket(1200);
            System.out.println("RPC Server is running on port 1200...\n");

            while (true) {

                byte b[] = new byte[1024];   // Fresh buffer each time
                DatagramPacket dp = new DatagramPacket(b, b.length);

                ds.receive(dp);

                String request = new String(dp.getData(), 0, dp.getLength()).trim();

                if (request.equalsIgnoreCase("q")) {
                    System.out.println("Server Stopped.");
                    break;
                }

                String result;

                try {
                    String arr[] = request.split(" ");

                    if (arr.length != 3) {
                        result = "Invalid Input Format. Use: add 3 4";
                    } else {
                        String methodName = arr[0];
                        int val1 = Integer.parseInt(arr[1]);
                        int val2 = Integer.parseInt(arr[2]);

                        switch (methodName.toLowerCase()) {
                            case "add":
                                result = String.valueOf(add(val1, val2));
                                break;
                            case "sub":
                                result = String.valueOf(sub(val1, val2));
                                break;
                            case "mul":
                                result = String.valueOf(mul(val1, val2));
                                break;
                            case "div":
                                if (val2 == 0)
                                    result = "Error: Division by zero";
                                else
                                    result = String.valueOf(div(val1, val2));
                                break;
                            default:
                                result = "Invalid Method";
                        }
                    }

                } catch (NumberFormatException e) {
                    result = "Error: Parameters must be integers";
                }

                byte b1[] = result.getBytes();

                DatagramPacket dp1 = new DatagramPacket(
                        b1,
                        b1.length,
                        dp.getAddress(),
                        dp.getPort()
                );

                ds.send(dp1);

                System.out.println("Client Request: " + request);
                System.out.println("Result Sent: " + result + "\n");
            }

            ds.close();

        } catch (Exception e) {
            System.out.println("Server Error: " + e.getMessage());
        }
    }

    public int add(int a, int b) {
        return a + b;
    }

    public int sub(int a, int b) {
        return a - b;
    }

    public int mul(int a, int b) {
        return a * b;
    }

    public int div(int a, int b) {
        return a / b;
    }

    public static void main(String args[]) {
        new RPCServer();
    }
}


##
import java.net.*;
import java.io.*;

class RPCClient {
    RPCClient() {
        try {
            DatagramSocket ds = new DatagramSocket();
            InetAddress ia = InetAddress.getLocalHost();

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in)
            );

            System.out.println("Enter method name and parameters like: add 3 4");
            System.out.println("Type 'q' to quit.");

            while (true) {
                System.out.print(">> ");
                String s = br.readLine();

                if (s == null || s.trim().equalsIgnoreCase("q")) {
                    byte[] quitMsg = "q".getBytes();
                    DatagramPacket quitPacket = new DatagramPacket(
                            quitMsg, quitMsg.length, ia, 1200
                    );
                    ds.send(quitPacket);
                    break;
                }

                byte b[] = s.trim().getBytes();

                DatagramPacket dp = new DatagramPacket(
                        b, b.length, ia, 1200
                );

                ds.send(dp);

                byte b1[] = new byte[1024];
                DatagramPacket dp1 = new DatagramPacket(b1, b1.length);

                ds.receive(dp1);

                String result = new String(dp1.getData(), 0, dp1.getLength());

                System.out.println("Result = " + result);
            }

            ds.close();

        } catch (Exception e) {
            System.out.println("Client Error: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        new RPCClient();
    }
}