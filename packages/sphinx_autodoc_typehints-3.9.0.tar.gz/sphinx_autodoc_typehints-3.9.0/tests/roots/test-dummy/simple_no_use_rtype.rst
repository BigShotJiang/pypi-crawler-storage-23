:orphan:

Simple Module
=============

.. autofunction:: dummy_module_simple_no_use_rtype.function_no_returns
.. autofunction:: dummy_module_simple_no_use_rtype.function_returns_with_type
.. autofunction:: dummy_module_simple_no_use_rtype.function_returns_with_compound_type
.. autofunction:: dummy_module_simple_no_use_rtype.function_returns_without_type
