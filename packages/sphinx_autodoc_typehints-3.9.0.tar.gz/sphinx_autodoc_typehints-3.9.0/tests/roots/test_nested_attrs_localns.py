from __future__ import annotations


class Outer:
    class Inner:
        def __init__(self) -> None: ...
