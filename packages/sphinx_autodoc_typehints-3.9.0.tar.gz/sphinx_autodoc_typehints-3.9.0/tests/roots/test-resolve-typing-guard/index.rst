.. automodule:: demo_typing_guard
   :members:
