from __future__ import annotations

from sphinx_autodoc_typehints import __version__


def test_version() -> None:
    assert __version__
