"""PFM Web - Browser viewer for .pfm files. Zero dependencies."""
