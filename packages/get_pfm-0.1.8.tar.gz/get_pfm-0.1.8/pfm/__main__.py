"""Allow running PFM as a module: python -m pfm"""
from pfm.cli import main

main()
