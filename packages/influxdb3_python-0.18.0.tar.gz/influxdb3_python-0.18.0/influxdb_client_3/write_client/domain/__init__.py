# coding: utf-8

# flake8: noqa

from __future__ import absolute_import

# import models into model package
from influxdb_client_3.write_client.domain.write_precision import WritePrecision


