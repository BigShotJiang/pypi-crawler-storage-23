"""Version of the Client that is used in User-Agent header."""

VERSION = '0.18.0'
USER_AGENT = f'influxdb3-python/{VERSION}'
