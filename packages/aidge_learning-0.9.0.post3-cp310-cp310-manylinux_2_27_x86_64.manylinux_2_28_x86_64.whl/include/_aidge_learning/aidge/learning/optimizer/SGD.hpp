/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CORE_OPTIMIZER_SGD_H_
#define AIDGE_CORE_OPTIMIZER_SGD_H_

#include <functional>
#include <memory>
#include <vector>

#include "aidge/backend/cpu/data/TensorImpl.hpp"
#include "aidge/data/Tensor.hpp"
#include "aidge/learning/optimizer/Optimizer.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/TensorUtils.hpp"
#include "aidge/utils/Types.h"

#define LIST_SGD_ATTR(X)  \
    X(Momentum, "momentum", float),  \
    X(Dampening, "dampening", float), \
    X(WeightDecay, "weight_decay", float)

namespace Aidge {
/**
 * @enum SGDAttr
 * @brief Enum class defining the attributes for the SGD optimizer.
 */
enum class SGDAttr { GENERATE_LIST_ATTR_ENUM(LIST_SGD_ATTR) };
} // namespace Aidge

namespace {
template <> struct EnumStrings<Aidge::SGDAttr>
{
    static const char *const data[];
};
constexpr const char *const EnumStrings<Aidge::SGDAttr>::data[] = {
    GENERATE_LIST_ATTR_STR(LIST_SGD_ATTR)};
} // namespace

namespace Aidge {
/**
 * @brief Description of the SGD optimizer.
 */
class SGD : public Optimizer {
  private:
    std::vector<Tensor> mGradientInertia;
    Tensor mLR{std::vector<std::size_t>({1})};
    Tensor mMomentum{std::vector<std::size_t>({1})};
    Tensor mReversedDampening{std::vector<std::size_t>({1})};
    Tensor mWeightDecay{std::vector<std::size_t>({1})};

  public:
    using Attributes_ =
        StaticAttributes<SGDAttr, GENERATE_LIST_ATTR_TYPE(LIST_SGD_ATTR)>;

    template <SGDAttr e> using attr = typename Attributes_::template attr<e>;

    const std::shared_ptr<Attributes_> mAttributes;

    SGD(const float momentum = 0.0f,
        const float dampening = 0.0f,
        const float weightDecay = 0.0f)
        : Optimizer(),
          mAttributes(std::make_shared<Attributes_>(
              attr<SGDAttr::Momentum>(momentum),
              attr<SGDAttr::Dampening>(dampening),
              attr<SGDAttr::WeightDecay>(weightDecay)))
    {
        mMomentum = Tensor(momentum);
        mReversedDampening = Tensor(1.0f - dampening);
        mWeightDecay = Tensor(weightDecay);
    }

    inline std::shared_ptr<Attributes> attributes() const override
    {
        return mAttributes;
    }

    void update() override final
    {

        auto backend = mParameters[0]->backend();
        auto device = mParameters[0]->device();
        auto dataType = mParameters[0]->dtype();

        mLR = Tensor(learningRate());

        // Set backends / devices

        mLR.toDtype(dataType);
        mLR.toBackend(backend, device);

        mWeightDecay.toDtype(dataType);
        mWeightDecay.toBackend(backend, device);

        mReversedDampening.toDtype(dataType);
        mReversedDampening.toBackend(backend, device);

        mMomentum.toDtype(dataType);
        mMomentum.toBackend(backend, device);

        // update loop

        if (mLRScheduler.step() == 0) {
            for (std::size_t i = 0; i < mParameters.size(); ++i) {
                mGradientInertia[i] = mParameters[i]->grad()->clone();
                *mParameters[i] -= mLR * mGradientInertia[i];
            }
        } else {
            for (std::size_t i = 0; i < mParameters.size(); ++i) {
                (*mParameters[i]->grad()) += mWeightDecay * (*mParameters[i]);
                mGradientInertia[i] =
                    mMomentum * mGradientInertia[i] +
                    mReversedDampening * (*mParameters[i]->grad());
                *mParameters[i] -= mLR * mGradientInertia[i];
            }
        }
        mLRScheduler.update();
    }

    void setParameters(
        const std::vector<std::shared_ptr<Tensor>> &parameters) override final
    {
        Optimizer::setParameters(parameters);
        mGradientInertia = std::vector<Tensor>(parameters.size());
        for (std::size_t i = 0; i < parameters.size(); ++i) {
            mGradientInertia[i] = Tensor(parameters[i]->dims());
            mGradientInertia[i].toBackend(parameters[i]->backend(),
                                          parameters[i]->device());
            mGradientInertia[i].toDtype(parameters[i]->dtype());
        }
        if (parameters.size() > 0) {
            mReversedDampening.toBackend(mParameters[0]->backend(),
                                         mParameters[0]->device());
            mReversedDampening.toDtype(parameters[0]->dtype());
            mMomentum.toBackend(mParameters[0]->backend(),
                                mParameters[0]->device());
            mMomentum.toDtype(parameters[0]->dtype());
        }
    }
};

} // namespace Aidge

#endif // AIDGE_CORE_OPTIMIZER_SGD_H_
