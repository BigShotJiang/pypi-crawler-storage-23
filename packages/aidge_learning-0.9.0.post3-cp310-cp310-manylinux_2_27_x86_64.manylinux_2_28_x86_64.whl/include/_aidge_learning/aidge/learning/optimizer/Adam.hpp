/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CORE_OPTIMIZER_ADAM_H_
#define AIDGE_CORE_OPTIMIZER_ADAM_H_

#include <cmath> // std::sqrt, std::pow
#include <functional>
#include <memory>
#include <vector>

#include "aidge/backend/cpu/data/TensorImpl.hpp"
#include "aidge/data/Tensor.hpp"
#include "aidge/learning/optimizer/Optimizer.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/TensorUtils.hpp"
#include "aidge/utils/Types.h"

#define LIST_ADAM_ATTR(X)  \
    X(Beta1, "beta1", float),  \
    X(Beta2, "beta2", float), \
    X(Epsilon, "epsilon", float)

namespace Aidge {
/**
 * @enum AdamAttr
 * @brief Enum class defining the attributes for the Adam optimizer.
 */
enum class AdamAttr { GENERATE_LIST_ATTR_ENUM(LIST_ADAM_ATTR) };
} // namespace Aidge

namespace {
template <> struct EnumStrings<Aidge::AdamAttr>
{
    static const char *const data[];
};
constexpr const char *const EnumStrings<Aidge::AdamAttr>::data[] = {
    GENERATE_LIST_ATTR_STR(LIST_ADAM_ATTR)};
} // namespace

namespace Aidge {
/**
 * @brief Description of the Adam optimizer.
 */
class Adam : public Optimizer {
  private:
    std::vector<Tensor> mMomentum1;
    std::vector<Tensor> mMomentum2;
    Tensor mBeta1;
    Tensor mReversedBeta1;
    Tensor mBeta2;
    Tensor mReversedBeta2;

  public:
    using Attributes_ =
        StaticAttributes<AdamAttr, GENERATE_LIST_ATTR_TYPE(LIST_ADAM_ATTR)>;

    template <AdamAttr e> using attr = typename Attributes_::template attr<e>;

    const std::shared_ptr<Attributes_> mAttributes;

    Adam(const float beta1 = 0.9f,
         const float beta2 = 0.999f,
         const float epsilon = 1.0e-8f)
        : Optimizer(),
          mAttributes(
              std::make_shared<Attributes_>(attr<AdamAttr::Beta1>(beta1),
                                            attr<AdamAttr::Beta2>(beta2),
                                            attr<AdamAttr::Epsilon>(epsilon)))
    {
        mBeta1 = Tensor(beta1);
        mReversedBeta1 = Tensor(1.0f - beta1);
        mBeta2 = Tensor(beta2);
        mReversedBeta2 = Tensor(1.0f - beta2);
    }

    inline std::shared_ptr<Attributes> attributes() const override
    {
        return mAttributes;
    }

    void update() override final
    {

        auto backend = mParameters[0]->backend();
        auto device = mParameters[0]->device();
        auto dataType = mParameters[0]->dtype();

        float mBeta1Power =
            std::pow(mAttributes->getAttr<AdamAttr::Beta1>(),
                     static_cast<float>(mLRScheduler.step() + 1));
        float mBeta2Power =
            std::pow(mAttributes->getAttr<AdamAttr::Beta2>(),
                     static_cast<float>(mLRScheduler.step() + 1));

        float mReversedBeta1Power = 1.0f - mBeta1Power;
        float mSqrtReversedBeta2Power = std::sqrt(1.0f - mBeta2Power);

        Tensor alpha = Tensor(learningRate() * mSqrtReversedBeta2Power /
                              mReversedBeta1Power);
        alpha.toBackend(backend, device);
        alpha.toDtype(dataType);

        Tensor epsilon_hat = Tensor(mAttributes->getAttr<AdamAttr::Epsilon>() *
                                    mSqrtReversedBeta2Power);
        epsilon_hat.toBackend(backend, device);
        epsilon_hat.toDtype(dataType);

        mBeta1.toBackend(backend, device);
        mBeta1.toDtype(dataType);
        mReversedBeta1.toBackend(backend, device);
        mReversedBeta1.toDtype(dataType);

        mBeta2.toBackend(backend, device);
        mBeta2.toDtype(dataType);
        mReversedBeta2.toBackend(backend, device);
        mReversedBeta2.toDtype(dataType);

        if (mLRScheduler.step() == 0) {
            for (std::size_t i = 0; i < mParameters.size(); ++i) {
                mMomentum1[i].zeros();
                mMomentum1[i].toBackend(backend, device);
                mMomentum1[i].toDtype(dataType);
                mMomentum2[i].zeros();
                mMomentum2[i].toBackend(backend, device);
                mMomentum2[i].toDtype(dataType);
            }
        }

        for (std::size_t i = 0; i < mParameters.size(); ++i) {
            mMomentum1[i] = mBeta1 * mMomentum1[i] +
                            mReversedBeta1 * (*mParameters[i]->grad());
            mMomentum2[i] = mBeta2 * mMomentum2[i] +
                            mReversedBeta2 * (*mParameters[i]->grad()) *
                                (*mParameters[i]->grad());
            *mParameters[i] -=
                alpha * mMomentum1[i] / (mMomentum2[i].sqrt() + epsilon_hat);
        }

        mLRScheduler.update();
    }

    void setParameters(
        const std::vector<std::shared_ptr<Tensor>> &parameters) override final
    {

        Optimizer::setParameters(parameters);
        mMomentum1 = std::vector<Tensor>(parameters.size());
        mMomentum2 = std::vector<Tensor>(parameters.size());

        for (std::size_t i = 0; i < parameters.size(); ++i) {

            mMomentum1[i] = Tensor(parameters[i]->dims());
            mMomentum1[i].toBackend(parameters[i]->backend(),
                                    parameters[i]->device());
            mMomentum1[i].toDtype(parameters[i]->dtype());

            mMomentum2[i] = Tensor(parameters[i]->dims());
            mMomentum2[i].toBackend(parameters[i]->backend(),
                                    parameters[i]->device());
            mMomentum2[i].toDtype(parameters[i]->dtype());
        }
        if (parameters.size() > 0) {

            mBeta1.toBackend(mParameters[0]->backend(),
                             mParameters[0]->device());
            mBeta1.toDtype(parameters[0]->dtype());

            mReversedBeta1.toBackend(mParameters[0]->backend(),
                                     mParameters[0]->device());
            mReversedBeta1.toDtype(parameters[0]->dtype());

            mBeta2.toBackend(mParameters[0]->backend(),
                             mParameters[0]->device());
            mBeta2.toDtype(parameters[0]->dtype());

            mReversedBeta2.toBackend(mParameters[0]->backend(),
                                     mParameters[0]->device());
            mReversedBeta2.toDtype(parameters[0]->dtype());
        }
    }
};

} // namespace Aidge

#endif // AIDGE_CORE_OPTIMIZER_ADAM_H_
