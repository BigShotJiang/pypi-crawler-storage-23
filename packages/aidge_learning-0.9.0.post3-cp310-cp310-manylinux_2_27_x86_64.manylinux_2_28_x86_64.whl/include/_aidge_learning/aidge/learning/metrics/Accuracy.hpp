/********************************************************************************
 * Copyright (c) 2024 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_LEARNING_METRICS_ACCURACY_H_
#define AIDGE_LEARNING_METRICS_ACCURACY_H_

#include <cstddef> // std::size_t
#include <memory>

#include "aidge/data/Tensor.hpp"

namespace Aidge {
namespace metrics {

/**
 * @brief Compute the Accuracy.
 * This function returns the loss and set the ``grad()`` of the prediction
 * input.
 * @param prediction Tensor returned by the Aidge Graph, it is important that
 * this tensor is not a copy as otherwise the backward function will not have a
 * gradient to start.
 * @param target Tensor representing the ground truth, it must be one hot
 * encoded.
 * @param axis The classes axis.
 */
Tensor Accuracy(std::shared_ptr<Tensor> &prediction,
                const std::shared_ptr<Tensor> &target,
                std::int32_t axis);
} // namespace metrics
} // namespace Aidge

#endif /* AIDGE_LEARNING_METRICS_ACCURACY_H_ */
