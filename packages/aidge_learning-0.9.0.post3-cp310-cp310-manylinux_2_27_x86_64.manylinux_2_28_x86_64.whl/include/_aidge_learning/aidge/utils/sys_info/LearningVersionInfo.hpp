#ifndef AIDGE_UTILS_SYS_INFO_LEARNING_VERSION_INFO_H
#define AIDGE_UTILS_SYS_INFO_LEARNING_VERSION_INFO_H

#include "aidge/learning/version.hpp"
#include "aidge/utils/Log.hpp"

namespace Aidge {

constexpr inline const char *getLearningProjectVersion()
{
    return Aidge::learning::Version::full;
}

constexpr inline const char *getLearningGitHash()
{
    return Aidge::learning::Version::git_hash;
}

inline void showLearningVersion()
{
    Log::println("Aidge Learning: {} ({}), {} {}",
                 getLearningProjectVersion(),
                 getLearningGitHash(),
                 __DATE__,
                 __TIME__);
    // Compiler version
#if defined(__clang__)
    /* Clang/LLVM. ---------------------------------------------- */
    Log::println("Clang/LLVM compiler version: {}.{}.{}",
                 __clang_major__,
                 __clang_minor__,
                 __clang_patchlevel__);
#elif defined(__ICC) || defined(__INTEL_COMPILER)
    /* Intel ICC/ICPC. ------------------------------------------ */
    Log::println("Intel ICC/ICPC compiler version: {}", __INTEL_COMPILER);
#elif defined(__GNUC__) || defined(__GNUG__)
    /* GNU GCC/G++. --------------------------------------------- */
    Log::println("GNU GCC/G++ compiler version: {}.{}.{}",
                 __GNUC__,
                 __GNUC_MINOR__,
                 __GNUC_PATCHLEVEL__);
#elif defined(_MSC_VER)
    /* Microsoft Visual Studio. --------------------------------- */
    Log::println("Microsoft Visual Studio compiler version: {}", _MSC_VER);
#else
    Log::println("Unknown compiler");
#endif
}
} // namespace Aidge
#endif // AIDGE_UTILS_SYS_INFO_LEARNING_VERSION_INFO_H
