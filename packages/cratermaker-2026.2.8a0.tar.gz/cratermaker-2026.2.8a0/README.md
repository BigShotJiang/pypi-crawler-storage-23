# Cratermaker
## Simulate the evolution of a landscape dominated by impact bombardment.

Cratermaker is a modernized re-write of the older Cratered Terrain Evolution Model (CTEM).

See [documentation](https://cratermaker.readthedocs.io/en/latest/)


