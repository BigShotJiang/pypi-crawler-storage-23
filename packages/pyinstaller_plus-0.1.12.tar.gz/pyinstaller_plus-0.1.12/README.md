# pyinstaller-plus

`pyinstaller-plus` is a PyInstaller-compatible wrapper that keeps your existing
PyInstaller workflow and then runs DistroMate packaging or publishing.
This README focuses on end-user packaging usage.

## Features

- Compatible with standard PyInstaller arguments
- Runs `distromate package` after a successful PyInstaller build
- Supports publish mode (`distromate publish`)
- Works on Windows, macOS, and Linux
- Auto-detects DistroMate CLI and falls back to installer scripts when needed
- Auto-creates `distromate.yaml` when missing and auto-syncs package fields

## Install

```bash
pip install pyinstaller-plus
```

## Quick Start

1. Log in to DistroMate:

```bash
distromate login
```

2. Optional: create a `distromate.yaml` (or `distromate.yml`) in your project root.
   If missing, `pyinstaller-plus` will create one with defaults.

3. Build and package:

```bash
pyinstaller-plus --dm-version 1.2.3 your.spec
```

4. Build and publish:

```bash
pyinstaller-plus --publish --dm-version 1.2.3 your.spec
```

## CLI Behavior

`pyinstaller-plus` executes this flow:

1. Run `python -m PyInstaller ...`
2. Resolve DistroMate CLI from:
   - `PATH`
   - bundled binary in this package
   - OS-specific installer fallback
3. Resolve release version from:
   - `--dm-version`
   - `pyproject.toml` -> `project.version`
4. Ensure and auto-update `distromate.yaml`/`distromate.yml` from PyInstaller args/spec:
   - top-level `name` (only auto-fill when missing)
   - `package.name`
   - `package.executable`
   - `package.target`
   - `package.icon` (from `--icon` or `EXE(icon=...)`)
   - `package.description` (from `--version-file` or `EXE(version=...)` -> `FileDescription`)
   - `package.publisher` (from `--version-file` or `EXE(version=...)` -> `CompanyName`)
5. Run one of:
   - `distromate package -v <version>`
   - `distromate publish -v <version>`

### Extra Arguments

- `--publish` / `--dm-publish`: publish mode
- `-p`: publish shorthand when used as a standalone flag
- `--dm-version <version>`: release version passed to DistroMate

Note: `-p <path>` is still treated as the original PyInstaller `-p` option.
Use `--publish` if you want unambiguous publish mode.

## Example `distromate.yml`

```yaml
appid: your_appid
name: MyApp
description: My desktop app

package:
  name: myapp
  executable: dist/myapp.exe
  target: dist
  publisher: MyApp Publisher
  language: english

preservePaths:
  - config
  - data

ignores:
  - "*.log"
  - temp/
  - "__pycache__/"
  - "*.pyc"
```

