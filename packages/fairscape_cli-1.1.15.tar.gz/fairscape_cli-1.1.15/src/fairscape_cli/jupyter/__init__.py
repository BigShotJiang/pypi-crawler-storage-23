from .magic import fairscape

__all__ = ['fairscape']
