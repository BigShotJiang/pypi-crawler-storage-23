from .ooverpunch import *

__doc__ = ooverpunch.__doc__
if hasattr(ooverpunch, "__all__"):
    __all__ = ooverpunch.__all__