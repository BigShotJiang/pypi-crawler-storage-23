"""Allow running autoguess as ``python -m autoguess``."""

from autoguess.cli import main

if __name__ == "__main__":
    main()
