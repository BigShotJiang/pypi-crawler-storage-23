"""
Utility sub-package for autoguess helpers (MiniZinc installer, etc.).
"""
