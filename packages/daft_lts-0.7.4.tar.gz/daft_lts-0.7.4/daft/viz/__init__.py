from __future__ import annotations

from .html_viz_hooks import register_viz_hook

__all__ = ["register_viz_hook"]
