from daft.datasets.common_crawl import common_crawl

__all__ = ["common_crawl"]
