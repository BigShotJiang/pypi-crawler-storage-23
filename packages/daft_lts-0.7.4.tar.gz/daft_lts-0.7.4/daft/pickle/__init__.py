from __future__ import annotations

from .pickle import dumps, loads

__all__ = ["dumps", "loads"]
