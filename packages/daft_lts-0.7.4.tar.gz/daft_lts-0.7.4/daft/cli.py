from __future__ import annotations

import sys

from daft.daft import cli


def main() -> None:
    cli(sys.argv)


if __name__ == "__main__":
    main()
