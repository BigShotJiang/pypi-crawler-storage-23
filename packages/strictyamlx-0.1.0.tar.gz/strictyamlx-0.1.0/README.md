# strictyamlx
An extension of StrictYAML that adds more expressive schema tools for validation.
