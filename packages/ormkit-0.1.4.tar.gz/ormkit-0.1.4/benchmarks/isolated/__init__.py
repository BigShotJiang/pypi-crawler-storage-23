# Isolated benchmark modules
