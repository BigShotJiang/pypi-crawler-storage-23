"""Allow running as `python -m gnosis_mcp`."""

from gnosis_mcp.cli import main

main()
