from agent_cli.main import main

main()
