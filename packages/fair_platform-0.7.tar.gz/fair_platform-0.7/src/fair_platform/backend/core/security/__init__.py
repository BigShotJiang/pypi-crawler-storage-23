"""Security helpers and permission checks."""

