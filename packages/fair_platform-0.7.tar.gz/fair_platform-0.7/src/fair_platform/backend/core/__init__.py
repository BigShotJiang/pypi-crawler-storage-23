"""Core backend utilities."""

