************************
ansiblelint-package-sort
************************

Ansible-lint rule for package list sorting.

This package provides a custom Ansible Lint rule that ensures package lists
in package manager modules are sorted alphabetically. The rule checks tasks
that use various package management modules and verifies that their package
lists are properly sorted. This rule does support automatic fixing.

The rule supports the following package manager modules:

* ansible.builtin.apt
* ansible.builtin.dnf
* ansible.builtin.dnf5
* ansible.builtin.package
* ansible.builtin.yum

License
#######
* Copyright 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics (MPP)

All rights reserved.

This software may be modified and distributed under the terms of the GNU Lesser General Public License (LGPL). See the ``LICENSE`` file for details.
