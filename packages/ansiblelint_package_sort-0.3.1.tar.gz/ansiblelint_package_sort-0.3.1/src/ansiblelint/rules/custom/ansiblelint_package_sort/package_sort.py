# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

"""Ansible-lint rule for package list sorting.

This module provides a custom Ansible Lint rule that ensures package lists
in package manager modules are sorted alphabetically. The rule checks tasks
that use various package management modules and verifies that their package
lists are properly sorted.

The rule supports the following package manager modules:
- ansible.builtin.apt
- ansible.builtin.dnf
- ansible.builtin.dnf5
- ansible.builtin.package
- ansible.builtin.yum

"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, override

from ansiblelint.text import has_jinja
from ruamel.yaml.comments import CommentedSeq

from ansiblelint.rules import AnsibleLintRule, TransformMixin

if TYPE_CHECKING:
    from ansiblelint.errors import MatchError
    from ansiblelint.file_utils import Lintable
    from ansiblelint.utils import Task
    from ruamel.yaml.comments import CommentedMap

logger = logging.getLogger(__name__)


class PackageSortRule(AnsibleLintRule, TransformMixin):
    """Ensure package lists in package manager modules are sorted."""

    id = "package-sort"
    shortdesc = "Package lists should be sorted."
    description = (
        "Package lists in ansible.builtin.apt, ansible.builtin.dnf "
        "ansible.builtin.dnf5, ansible.builtin.package and ansible.builtin.yum"
        "should be sorted alphabetically."
    )
    severity = "MEDIUM"
    tags = ["formatting"]  # noqa: RUF012
    version_changed = "0.0.0"

    _modules: tuple[str, ...] = (
        "apt",
        "dnf",
        "dnf5",
        "package",
        "yum",
    )
    _parameters: tuple[str, ...] = (
        "name",
        "package",
        "pkg",
        "deb",
        "exclude",
    )

    @override
    def matchtask(
        self,
        task: Task,
        file: Lintable | None = None,
    ) -> bool | str | MatchError | list[MatchError]:
        """Check if the task uses package manager module with unsorted packages."""
        action = task.get("action", {})
        module = action.get("__ansible_module__", action.get("module"))

        if module not in self._modules:
            logger.debug(
                "%s: module name (%s) does not match this rule's targets: %s",
                self.id,
                module,
                self._modules,
            )
            return False
        logger.debug(
            "%s: module name (%s) matches this rule's targets.", self.id, module
        )

        for module_parameter in self._parameters:
            raw_packages = action.get(module_parameter)

            if not raw_packages:
                continue

            logger.debug(
                "%s: package definition found: {%s: %s}",
                self.id,
                module_parameter,
                raw_packages,
            )

            if has_jinja(str(raw_packages)):
                logger.debug(
                    "%s: packages list contain variables or templates. SKIP!", self.id
                )
                continue

            if isinstance(raw_packages, str):
                packages_list = raw_packages.split(",")
            elif isinstance(raw_packages, list):
                packages_list = raw_packages
            else:
                continue
            logger.debug("%s: packages list: %s", self.id, packages_list)

            clean_packages = [pkg.strip() for pkg in packages_list if pkg.strip()]

            sorted_clean_packages = sorted(clean_packages, key=str.casefold)
            if clean_packages != sorted_clean_packages:
                logger.info("%s: packages list is not sorted!", self.id)
                logger.info("%s: expected order: %s", self.id, sorted_clean_packages)
                return True
            logger.debug("%s: packages list is already sorted.", self.id)
        return False

    @override
    def transform(  # noqa: C901
        self,
        match: MatchError,
        lintable: Lintable,
        data: CommentedMap | CommentedSeq | str,
    ) -> None:
        """Fix package lists order in package manager modules."""
        logger.debug("%s: Fixing the package order...", self.id)
        if match.tag != self.id:
            return

        target_task = self.seek(match.yaml_path, data)
        logger.debug("%s: target_task: %s", self.id, str(target_task))

        for module_name in self._modules:
            if target_task.get(module_name):
                action = target_task.get(module_name)
                break
            fqn = f"ansible.builtin.{module_name}"
            if target_task.get(fqn):
                action = target_task.get(fqn)
                break

        if not action:
            logger.error("%s: Could not find a compatible module!", self.id)
            return

        logger.debug("%s: Found module: %s", self.id, module_name)

        for module_parameter in self._parameters:
            raw_packages = action.get(module_parameter)
            if not raw_packages or has_jinja(str(raw_packages)):
                continue
            logger.debug(
                "%s: Parsing %s: %s", self.id, module_parameter, str(raw_packages)
            )

            if isinstance(raw_packages, str):
                packages = [
                    pkg.strip() for pkg in raw_packages.split(",") if pkg.strip()
                ]
                action[module_parameter] = ", ".join(sorted(packages, key=str.casefold))
                match.fixed = True

            elif isinstance(raw_packages, CommentedSeq):
                logger.debug("%s: Sorting packages while preserving comments", self.id)

                comments_dict = raw_packages.ca.items if raw_packages.ca else {}
                indexed_items = [
                    (pkg.strip(), pkg, comments_dict.get(i))
                    for i, pkg in enumerate(raw_packages)
                    if pkg.strip()
                ]

                indexed_items.sort(key=lambda x: x[0])

                raw_packages.clear()
                comments_dict.clear()

                for new_idx, (_, pkg, comment_data) in enumerate(indexed_items):
                    raw_packages.append(pkg)
                    comments_dict[new_idx] = comment_data

                match.fixed = True
