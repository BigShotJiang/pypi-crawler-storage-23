"""Ollama wizard runner for `nacho init` with provider=ollama."""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
from importlib import resources as importlib_resources
from pathlib import Path

import httpx

DEFAULT_OLLAMA_URL = "http://localhost:11434"
DEFAULT_MODEL = "qwen2.5-coder:14b"

# (name, size_str, description)
# Models below 14B parameters struggle with the multi-step tool-calling required
# by the wizard and are not listed here.
CURATED_MODELS: list[tuple[str, str, str]] = [
    ("qwen2.5-coder:14b", "9.0 GB",  "Recommended — reliable tool use, 16 GB RAM"),
    ("qwen2.5-coder:32b", "20 GB",   "Better quality, 32 GB RAM"),
    ("llama3.3:70b",      "40 GB",   "Highest quality, 64 GB RAM"),
]

_DEFAULT_API_URL = "https://nacho.bot/api"
_CREDENTIALS_FILE = Path.home() / ".nacho" / "credentials"

_BLOCKED_SUBSTRINGS = [
    "rm -rf /",
    "rm -rf ~",
    "rm -rf ~/",
    "mkfs",
    "dd if=/dev/zero",
    ":(){ :|:& };:",  # fork bomb
    "shutdown",
    "reboot",
    "poweroff",
    "halt",
]

_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "nacho_search",
            "description": "Search the Nacho context library for matching contexts.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "tags": {"type": "string", "description": "Comma-separated tags to filter by"},
                    "sort": {
                        "type": "string",
                        "description": "Sort order: relevance, newest, downloads, upvotes",
                    },
                    "page": {"type": "integer", "description": "Page number (default 1)"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "nacho_info",
            "description": (
                "Get full details about a Nacho context including description, "
                "tags, version history, and stats."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "ref": {
                        "type": "string",
                        "description": "Context reference in username/context-name format",
                    },
                },
                "required": ["ref"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "nacho_pull",
            "description": "Download the raw markdown content of a Nacho context.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ref": {
                        "type": "string",
                        "description": "Context reference in username/context-name format",
                    },
                    "version": {
                        "type": "integer",
                        "description": "Specific version number (latest if omitted)",
                    },
                },
                "required": ["ref"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "nacho_install",
            "description": (
                "Download a Nacho context and append it to AGENTS.md in the project directory. "
                "Use this instead of nacho_pull + write_file when installing community contexts."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "ref": {
                        "type": "string",
                        "description": "Context reference in username/context-name format",
                    },
                    "version": {
                        "type": "integer",
                        "description": "Specific version number (latest if omitted)",
                    },
                },
                "required": ["ref"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_bash",
            "description": (
                "Run a shell command in the project directory. "
                "Returns stdout and stderr combined. "
                "Use for git, npm, pip, uv, cargo, go, etc."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to run"},
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": (
                "Write content to a file inside the project directory. "
                "Creates parent directories as needed. "
                "Use for creating source files, configs, README, etc."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Relative path within the project directory",
                    },
                    "content": {"type": "string", "description": "File content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
]


# ── Nacho API helpers ─────────────────────────────────────────────────


def _get_api_url() -> str:
    return os.environ.get("NACHO_API_URL", _DEFAULT_API_URL)


def _get_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    if _CREDENTIALS_FILE.exists():
        token = _CREDENTIALS_FILE.read_text().strip()
        if token:
            headers["Authorization"] = f"Bearer {token}"
    return headers


def _api_get(path: str, params: dict | None = None) -> dict | list:
    url = f"{_get_api_url()}{path}"
    resp = httpx.get(url, params=params, headers=_get_headers(), timeout=30.0)
    resp.raise_for_status()
    return resp.json()


def _pull_content(ref: str, version: int | None = None) -> str:
    parts = ref.strip().split("/", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ValueError(f"Invalid ref '{ref}'. Use username/context-name.")
    username, name = parts
    data = _api_get(f"/contexts/{username}/{name}")
    context_id = data.get("id")
    if not context_id:
        raise ValueError("Could not resolve context ID.")
    params: dict = {}
    if version is not None:
        params["version"] = version
    url = f"{_get_api_url()}/contexts/{context_id}/download"
    resp = httpx.get(
        url, params=params, headers=_get_headers(), timeout=30.0, follow_redirects=True
    )
    resp.raise_for_status()
    return resp.text


# ── Tool implementations ──────────────────────────────────────────────


def _nacho_search(
    query: str = "",
    tags: str = "",
    sort: str = "relevance",
    page: int = 1,
) -> str:
    try:
        params: dict = {"page": page, "per_page": 10, "sort": sort}
        if query:
            params["q"] = query
        if tags:
            params["tags"] = tags
        data = _api_get("/contexts/search", params)
        items = data.get("items", [])
        if not items:
            return "No contexts found matching your query."
        total = data.get("total", 0)
        lines = [f"Found {total} context(s) (page {data.get('page', 1)} of {data.get('pages', 1)}):\n"]
        for i, item in enumerate(items, 1):
            owner = item.get("owner_username", "unknown")
            name = item.get("name", "unknown")
            ref = f"{owner}/{name}"
            title = item.get("title", name)
            desc = item.get("short_description") or ""
            tags_list = item.get("tags", [])
            downloads = item.get("download_count", 0)
            upvotes = item.get("upvote_count", 0)
            lines.append(f"{i}. **{title}** (`{ref}`)")
            if desc:
                lines.append(f"   {desc}")
            if tags_list:
                lines.append(f"   Tags: {', '.join(tags_list)}")
            lines.append(f"   ↓{downloads} ▲{upvotes}")
            lines.append("")
        return "\n".join(lines)
    except Exception as e:
        return f"Error searching Nacho: {e}"


def _nacho_info(ref: str) -> str:
    try:
        parts = ref.strip().split("/", 1)
        if len(parts) != 2:
            return "Error: Invalid ref format. Use username/context-name."
        username, name = parts
        data = _api_get(f"/contexts/{username}/{name}")
        context_id = data.get("id")
        title = data.get("title", name)
        desc = data.get("short_description") or data.get("long_description") or "No description."
        long_desc = data.get("long_description") or ""
        tags_list = data.get("tags", [])
        downloads = data.get("download_count", 0)
        upvotes = data.get("upvote_count", 0)
        latest_version = data.get("latest_version", 1)
        license_val = data.get("license") or "Not specified"
        lines = [
            f"# {title}",
            f"**Ref:** `{ref}`",
            f"**Description:** {desc}",
        ]
        if long_desc and long_desc != desc:
            lines.append(f"\n{long_desc}")
        lines.append(f"**Tags:** {', '.join(tags_list) if tags_list else 'None'}")
        lines.append(f"**License:** {license_val}")
        lines.append(f"**Downloads:** {downloads} | **Upvotes:** {upvotes}")
        lines.append(f"**Latest version:** {latest_version}")
        if context_id:
            try:
                versions_data = _api_get(f"/contexts/{context_id}/versions")
                if isinstance(versions_data, list) and versions_data:
                    lines.append("\n**Versions:**")
                    for v in versions_data[:5]:
                        ver_num = v.get("version", "?")
                        changelog = v.get("changelog") or "No changelog"
                        created = v.get("created_at", "")[:10]
                        lines.append(f"  - v{ver_num} ({created}): {changelog}")
            except Exception:
                pass
        return "\n".join(lines)
    except Exception as e:
        return f"Error getting info: {e}"


def _nacho_pull(ref: str, version: int | None = None) -> str:
    try:
        return _pull_content(ref, version)
    except Exception as e:
        return f"Error pulling context: {e}"


def _nacho_install(ref: str, version: int | None, project_dir: Path) -> str:
    try:
        content = _pull_content(ref, version)
    except Exception as e:
        return f"Error: {e}"
    agents_md = project_dir / "AGENTS.md"
    header = f"\n\n<!-- nacho: {ref} -->\n"
    if agents_md.exists():
        agents_md.write_text(agents_md.read_text() + header + content)
        return f"Appended context `{ref}` to AGENTS.md."
    else:
        agents_md.write_text(header.lstrip() + content)
        return f"Created AGENTS.md with context `{ref}`."


_DEV_SERVER_PATTERNS = [
    r"\bnpm\s+run\s+dev\b",
    r"\bnpx?\s+next\s+dev\b",
    r"\bnpm\s+start\b",
    r"\bpnpm\s+(run\s+)?dev\b",
    r"\bpnpm\s+start\b",
    r"\byarn\s+(run\s+)?dev\b",
    r"\byarn\s+start\b",
    r"\buvicorn\b",
    r"\bflask\s+run\b",
    r"\bfastapi\s+dev\b",
    r"\bpython\s+.*manage\.py\s+runserver\b",
    r"\bgo\s+run\b",
    r"\bcargo\s+run\b",
]


def _is_dev_server(command: str) -> bool:
    return any(re.search(p, command.strip(), re.IGNORECASE) for p in _DEV_SERVER_PATTERNS)


def _run_bash(command: str, project_dir: Path) -> str:
    cmd_lower = command.lower().strip()
    for blocked in _BLOCKED_SUBSTRINGS:
        if blocked in cmd_lower:
            return f"Error: Command blocked for safety reasons (matched: {blocked!r})."

    # Dev server commands are long-running — start detached and return quickly.
    if _is_dev_server(command):
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                cwd=project_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            time.sleep(3)
            if proc.poll() is not None:
                return f"Error: Dev server exited immediately (code {proc.returncode}). Check your configuration."
            return (
                f"Dev server started (pid={proc.pid}). "
                f"Open http://localhost:3000 in your browser. "
                f"(The server keeps running after this wizard exits.)"
            )
        except Exception as e:
            return f"Error starting dev server: {e}"

    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=project_dir,
            capture_output=True,
            text=True,
            timeout=120,
        )
        output = (result.stdout or "") + (result.stderr or "")
        if not output:
            output = f"(exit code {result.returncode})"
        if len(output) > 4000:
            output = output[:3900] + "\n...[output truncated]..."
        return output
    except subprocess.TimeoutExpired:
        return "Error: Command timed out after 120 seconds."
    except Exception as e:
        return f"Error running command: {e}"


def _write_file(path: str, content: str, project_dir: Path) -> str:
    try:
        resolved = (project_dir / path).resolve()
        if not resolved.is_relative_to(project_dir.resolve()):
            return "Error: path outside project directory."
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(content, encoding="utf-8")
        return f"Wrote {path} ({len(content)} bytes)"
    except Exception as e:
        return f"Error writing file: {e}"


def _call_tool(name: str, args: dict, project_dir: Path) -> str:
    if name == "nacho_search":
        return _nacho_search(
            query=args.get("query", ""),
            tags=args.get("tags", ""),
            sort=args.get("sort", "relevance"),
            page=args.get("page", 1),
        )
    elif name == "nacho_info":
        return _nacho_info(args.get("ref", ""))
    elif name == "nacho_pull":
        return _nacho_pull(args.get("ref", ""), args.get("version"))
    elif name == "nacho_install":
        return _nacho_install(args.get("ref", ""), args.get("version"), project_dir)
    elif name == "run_bash":
        return _run_bash(args.get("command", ""), project_dir)
    elif name == "write_file":
        return _write_file(args.get("path", ""), args.get("content", ""), project_dir)
    else:
        return f"Error: Unknown tool '{name}'."


# ── Ollama API helpers ────────────────────────────────────────────────


def check_ollama(base_url: str = DEFAULT_OLLAMA_URL) -> bool:
    """Return True if Ollama is reachable at base_url."""
    try:
        resp = httpx.get(f"{base_url}/api/tags", timeout=5.0)
        return resp.status_code == 200
    except Exception:
        return False


def list_models(base_url: str = DEFAULT_OLLAMA_URL) -> list[str]:
    """Return list of model names currently available in Ollama."""
    try:
        resp = httpx.get(f"{base_url}/api/tags", timeout=5.0)
        resp.raise_for_status()
        return [m["name"] for m in resp.json().get("models", [])]
    except Exception:
        return []


def pull_model(model: str, base_url: str = DEFAULT_OLLAMA_URL) -> None:
    """Stream-download a model via Ollama, printing progress."""
    print(f"  Pulling {model}...")
    try:
        with httpx.stream(
            "POST",
            f"{base_url}/api/pull",
            json={"name": model, "stream": True},
            timeout=None,
        ) as resp:
            for line in resp.iter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue
                status = chunk.get("status", "")
                total = chunk.get("total", 0)
                completed = chunk.get("completed", 0)
                if total and completed:
                    pct = int(completed / total * 100)
                    print(f"\r  {status}: {pct}%    ", end="", flush=True)
                elif status:
                    print(f"\r  {status}...         ", end="", flush=True)
        print("\r  Download complete.         ")
    except Exception as e:
        print(f"\n  Warning: Could not pull model: {e}")
        print(f"  Try manually: ollama pull {model}")


# ── Text tool-call fallback ───────────────────────────────────────────


def _extract_text_tool_calls(content: str) -> list[dict]:
    """
    Fallback for models that describe tool calls in text instead of using the
    structured tool API.  Handles two formats:

    1. JSON code blocks: ```json {"name": "tool", "arguments": {...}} ```
    2. [invoke tool_name ...] key: value  — written by some models as literal text
    """
    tool_names = {t["function"]["name"] for t in _TOOLS}
    tool_calls = []

    # Format 1: JSON code blocks
    for match in re.finditer(r"```(?:json)?\s*(\{.*?\})\s*```", content, re.DOTALL):
        raw = match.group(1).strip()
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError:
            continue
        name = obj.get("name")
        arguments = obj.get("arguments", {})
        if name in tool_names:
            tool_calls.append({"function": {"name": name, "arguments": arguments}})

    if tool_calls:
        return tool_calls

    # Format 2: [invoke tool_name optional qualifier] key: value ...
    for match in re.finditer(r"\[invoke\s+(\w+)[^\]]*\]\s*([^\[]*)", content, re.DOTALL):
        name = match.group(1).strip()
        if name not in tool_names:
            continue
        arg_text = match.group(2).strip().splitlines()[0] if match.group(2).strip() else ""
        args = _parse_inline_args(name, arg_text)
        tool_calls.append({"function": {"name": name, "arguments": args}})

    return tool_calls


def _parse_inline_args(tool_name: str, text: str) -> dict:
    """Parse 'key: value' text into tool arguments for simple tools."""
    args: dict = {}
    if tool_name == "nacho_search":
        m = re.search(r"query:\s*(.+?)(?:\s+tags:|$)", text)
        if m:
            args["query"] = m.group(1).strip()
        m = re.search(r"tags:\s*(.+?)(?:\s+\w+:|$)", text)
        if m:
            args["tags"] = m.group(1).strip()
    elif tool_name in ("nacho_info", "nacho_install", "nacho_pull"):
        m = re.search(r"ref:\s*(\S+)", text) or re.search(r"(\w[\w-]*/[\w][\w-]*)", text)
        if m:
            args["ref"] = m.group(1).rstrip(")")
    elif tool_name == "run_bash":
        m = re.search(r'command:\s*["\']?(.+?)["\']?\s*$', text)
        if m:
            args["command"] = m.group(1).strip()
    return args


# ── System prompt ─────────────────────────────────────────────────────

_TIER_PROMPTS = {
    "medium": "NACHO_MEDIUM.md",
    "large":  "NACHO_LARGE.md",
}


def get_model_tier(model: str) -> str:
    """Return 'medium' or 'large' based on parameter count in the model name."""
    match = re.search(r"(\d+)b", model.lower())
    if match:
        params = int(match.group(1))
        if params <= 49:
            return "medium"
    return "large"


def _load_system_prompt(model: str = "") -> str:
    tier = get_model_tier(model)
    filename = _TIER_PROMPTS[tier]
    source = importlib_resources.files("nacho").joinpath("data", filename)
    text = source.read_text()

    # Strip leading "[//]: # (...)" comment if present
    lines = text.splitlines()
    if lines and lines[0].startswith("[//]: #"):
        lines = lines[1:]
    text = "\n".join(lines).lstrip()

    # Replace $ARGUMENTS placeholder (large prompt only)
    text = text.replace("$ARGUMENTS", "")

    # Patch MCP-specific language so models aren't confused
    text = text.replace("Nacho MCP tools", "Nacho tools")
    text = text.replace("MCP tools", "tools")

    return text


# ── Streaming chat loop ───────────────────────────────────────────────


def _stream_chat(
    messages: list[dict],
    model: str,
    base_url: str,
) -> tuple[str, list[dict]]:
    """POST to Ollama /api/chat with streaming. Returns (content, tool_calls)."""
    payload = {
        "model": model,
        "messages": messages,
        "tools": _TOOLS,
        "stream": True,
    }

    content_parts: list[str] = []
    tool_calls: list[dict] = []

    try:
        with httpx.stream(
            "POST",
            f"{base_url}/api/chat",
            json=payload,
            timeout=httpx.Timeout(connect=10.0, read=300.0, write=10.0, pool=10.0),
        ) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue

                msg = chunk.get("message", {})

                if msg.get("content"):
                    content_parts.append(msg["content"])
                    print(msg["content"], end="", flush=True)

                if msg.get("tool_calls"):
                    tool_calls.extend(msg["tool_calls"])

                if chunk.get("done"):
                    break

    except httpx.HTTPStatusError as e:
        print(f"\nError: Ollama returned HTTP {e.response.status_code}")
    except httpx.ConnectError:
        print(f"\nError: Lost connection to Ollama at {base_url}")
    except Exception as e:
        print(f"\nError communicating with Ollama: {e}")

    return "".join(content_parts), tool_calls


# ── Public entry point ────────────────────────────────────────────────


def run_ollama_wizard(
    model: str = DEFAULT_MODEL,
    project_dir: Path | None = None,
    base_url: str = DEFAULT_OLLAMA_URL,
) -> None:
    """Run the /nachoinit wizard locally using a local Ollama model."""
    if project_dir is None:
        project_dir = Path.cwd()
    project_dir = project_dir.resolve()

    tier = get_model_tier(model)
    system_prompt = _load_system_prompt(model)
    print(f"Prompt tier: {tier}")

    # Pre-fill the opening question instead of sending a "Begin." trigger.
    # Smaller models misread "Begin." as "start building" and immediately call tools.
    opening = "What do you want to build? Just describe it in your own words — like you're telling a friend about an app idea."
    messages: list[dict] = [
        {"role": "system", "content": system_prompt},
        {"role": "assistant", "content": opening},
    ]

    print(f"Model: {model}  |  Project: {project_dir}")
    print("Type 'exit' or press Ctrl+C to quit.\n")
    print("-" * 60)
    print(f"\nNacho: {opening}")

    # Get first user input before entering the model loop
    try:
        user_input = input("\nYou: ").strip()
    except (EOFError, KeyboardInterrupt):
        print(f"\n\nWizard interrupted. Your project is at: {project_dir}")
        return
    if not user_input or user_input.lower() in ("exit", "quit", "bye", "q"):
        print(f"\nGoodbye! Your project is at: {project_dir}")
        return
    messages.append({"role": "user", "content": user_input})

    while True:
        print("\nNacho: ", end="", flush=True)
        content, tool_calls = _stream_chat(messages, model, base_url)
        print()  # newline after streamed content

        if tool_calls:
            # Structured tool calls from Ollama API
            messages.append({
                "role": "assistant",
                "content": content,
                "tool_calls": tool_calls,
            })
            for tc in tool_calls:
                fn = tc.get("function", {})
                name = fn.get("name", "")
                raw_args = fn.get("arguments", {})
                if isinstance(raw_args, str):
                    try:
                        raw_args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        raw_args = {}
                print(f"  [calling {name}...]")
                result = _call_tool(name, raw_args, project_dir)
                messages.append({"role": "tool", "content": result})
            # Loop back — model needs to respond to tool results
            continue

        # Fallback: model printed tool calls as JSON text instead of using the API
        text_tool_calls = _extract_text_tool_calls(content)
        if text_tool_calls:
            messages.append({"role": "assistant", "content": content})
            results: list[str] = []
            for tc in text_tool_calls:
                fn = tc.get("function", {})
                name = fn.get("name", "")
                raw_args = fn.get("arguments", {})
                print(f"  [calling {name}...]")
                result = _call_tool(name, raw_args, project_dir)
                results.append(f"Result of `{name}`:\n{result}")
            # Inject results as a user message — works with any model regardless of tool-message support
            messages.append({
                "role": "user",
                "content": "Tool results:\n\n" + "\n\n---\n\n".join(results) + "\n\nPlease continue.",
            })
            continue

        # Detect if model described tool calls as text instead of using the API.
        # Catches both tool_name(...) and [invoke tool_name ...] patterns.
        _TOOL_NAMES = {t["function"]["name"] for t in _TOOLS}
        _tool_pattern = re.compile(
            r'(?:\[invoke\s+(?:' + '|'.join(_TOOL_NAMES) + r')'
            r'|\b(?:' + '|'.join(_TOOL_NAMES) + r')\s*\()'
        )
        if _tool_pattern.search(content):
            messages.append({"role": "assistant", "content": content})
            messages.append({
                "role": "user",
                "content": (
                    "You described a tool call in your message instead of invoking it. "
                    "Use the tool API directly — select the tool and call it now."
                ),
            })
            continue

        # Regular response — get user input
        messages.append({"role": "assistant", "content": content})

        try:
            user_input = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n\nWizard interrupted. Your project is at: {project_dir}")
            break

        if not user_input or user_input.lower() in ("exit", "quit", "bye", "q"):
            print(f"\nGoodbye! Your project is at: {project_dir}")
            break

        messages.append({"role": "user", "content": user_input})
