import httpx

from nacho.config import get_api_url, load_token


class APIClient:
    def __init__(self):
        self.base_url = get_api_url()
        self.token = load_token()

    @property
    def headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def login(self, email: str, password: str) -> dict:
        resp = httpx.post(
            f"{self.base_url}/auth/login",
            json={"email": email, "password": password},
        )
        resp.raise_for_status()
        return resp.json()

    def push(self, file_path: str, name: str, title: str, **kwargs) -> dict:
        with open(file_path, "rb") as f:
            files = {"file": (file_path, f, "text/markdown")}
            data = {"name": name, "title": title}
            data.update({k: v for k, v in kwargs.items() if v is not None})
            headers = {}
            if self.token:
                headers["Authorization"] = f"Bearer {self.token}"
            resp = httpx.post(
                f"{self.base_url}/contexts",
                files=files,
                data=data,
                headers=headers,
            )
        resp.raise_for_status()
        return resp.json()

    def push_version(self, context_id: str, file_path: str, changelog: str | None = None) -> dict:
        with open(file_path, "rb") as f:
            files = {"file": (file_path, f, "text/markdown")}
            data = {}
            if changelog:
                data["changelog"] = changelog
            headers = {}
            if self.token:
                headers["Authorization"] = f"Bearer {self.token}"
            resp = httpx.post(
                f"{self.base_url}/contexts/{context_id}/versions",
                files=files,
                data=data,
                headers=headers,
            )
        resp.raise_for_status()
        return resp.json()

    def get_my_context(self, name: str) -> dict | None:
        resp = httpx.get(f"{self.base_url}/auth/me", headers=self.headers)
        resp.raise_for_status()
        username = resp.json()["username"]
        resp = httpx.get(f"{self.base_url}/contexts/{username}/{name}", headers=self.headers)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    def pull(self, username: str, context_name: str, version: int | None = None) -> bytes:
        # First get context info
        resp = httpx.get(
            f"{self.base_url}/contexts/{username}/{context_name}",
            headers=self.headers,
        )
        resp.raise_for_status()
        context = resp.json()

        params = {}
        if version:
            params["version"] = version
        resp = httpx.get(
            f"{self.base_url}/contexts/{context['id']}/download",
            params=params,
            headers=self.headers,
            follow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content

    def upvote(self, username: str, context_name: str) -> dict:
        resp = httpx.get(
            f"{self.base_url}/contexts/{username}/{context_name}",
            headers=self.headers,
        )
        resp.raise_for_status()
        context = resp.json()

        resp = httpx.post(
            f"{self.base_url}/contexts/{context['id']}/upvote",
            headers=self.headers,
        )
        resp.raise_for_status()
        return resp.json()

    def search(self, query: str, page: int = 1) -> dict:
        resp = httpx.get(
            f"{self.base_url}/contexts/search",
            params={"q": query, "page": page},
            headers=self.headers,
        )
        resp.raise_for_status()
        return resp.json()
