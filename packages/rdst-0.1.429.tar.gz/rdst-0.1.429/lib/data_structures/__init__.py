"""
Data structures for rdst.

Ask3-specific structures are defined in lib/engines/ask3/ (Ask3Context, etc.)
"""

__all__ = []
