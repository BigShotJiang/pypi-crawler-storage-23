"""
定义时间, 方便与datetimeIndex配合

最后修改时间: 2026-02-22
"""

class Time:
    """
    定义时间, 方便与datetimeIndex配合
    """
    def __init__(
        self,
        years: int = None,
        months: int = None,
        weeks: int = None,
        days: int = None,
        hours: int = None,
        minutes: int = None,
        seconds: int = None,
    ): 
        self._dict = dict(
            years =  years,
            months = months,
            weeks =  weeks,
            days =  days,
            hours =  hours,
            minutes = minutes,
            seconds = seconds
        )
    
    @property
    def values(self):
        return {k: v for k, v in self._dict.items() if v}