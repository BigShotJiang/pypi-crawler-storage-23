"""
单一因子测试引擎

最后修改时间: 2026-02-12
"""

import pandas as pd
from typing import Callable
import inspect

from ._util import _check_DatetimeIndex
from .Factor import Factor
from .FactorValues import FactorValues


class SingleFactorTesting():
    """
    单一因子测试引擎
        注意: 因子可以是相同的, 但是在不同交易品种(大豆、菜籽)下同一因子会有不同的因子值
    """
    def __init__(self, func: Callable[[Factor],None], name: str = None):
        """
        单一因子测试引擎
            注意: 因子可以是相同的, 但是在不同交易品种(大豆、菜籽)下同一因子会有不同的因子值
        Args:
            func(Callable): 单一因子
            name(str): 因子名称
        """
        # 因子名称
        # 以name中命名策略
        if name is not None: 
            self._func_name = name
        # 从func的docstring中获取策略名称
        elif name is None and inspect.getdoc(func) is not None: 
            self._func_name = inspect.getdoc(func)
        # 从func.__name__命名策略
        else: 
            self._func_name = func.__name__
        self._func = func # 单一因子构造
        self._market = pd.DataFrame() # 当前市场数据
        self._func_data = pd.DataFrame() # 当前因子绑定的数据
        self._all_values = pd.DataFrame()  # 单一因子生成的所有具体值
        self._all_markets = pd.DataFrame() # 全部市场价格数据

    def set_market_data(self, df:pd.DataFrame, name:str=None):
        """
        绑定单一交易品种的市场数据: 需要在市场数据中进行
        Args:
            df: 单一交易品种的市场数据
            name: 交易品种名称
        """
        _check_DatetimeIndex(df)
        if name is not None and name in df.columns.values:
            raise ValueError('交易品种名称重复')
        self._market = df
        self._market_name = name
        return self

    def _rename_by_market(self, df: pd.DataFrame):
        df.rename(columns={df.columns[-1]: self._market_name},inplace=True)

    def set_factor_data(self, df: pd.DataFrame|Factor):
        """
        绑定交易品种基础数据: 因子构造需要通过基础数据才能生成具体因子值
        Args:
            df: 基础数据
        """
        _check_DatetimeIndex(df)
        self._func_data = df
        return self

    def run(self):
        """
        开始按照因子构造生成具体因子值
        """
        if self._market.empty:
            raise ValueError('未绑定市场数据, 请先调用.set_market_data()绑定市场数据')
        if self._func_data.empty:
            raise ValueError('因子构造未绑定基础数据，无法转变为具体因子值, 请先调用.set_factor_data()绑定基础数据值')
        # 用self._market.index初始化Index, 保证全局索引对齐
        self._all_values = self._all_values.reindex(self._market.index.copy())
        self._all_markets = self._all_markets.reindex(self._market.index.copy()) 
        # 记录将当前因子具体值
        values = FactorValues(self._func, self._func_data).values
        self._all_values = self._all_values.join(values, rsuffix='_')
        self._rename_by_market(self._all_values)
        # 记录市场数据
        self._all_markets = self._all_markets.join(self._market, rsuffix='_')
        self._rename_by_market(self._all_markets)
        
        # 清空市场数据和基础数据值, 防止重复生成同一具体因子值
        self._market = pd.DataFrame()
        self._func_data = pd.DataFrame()
        return self
    
    @property
    def factors(self):
        return self._all_values
    
    @property
    def markets(self):
        return self._all_markets

