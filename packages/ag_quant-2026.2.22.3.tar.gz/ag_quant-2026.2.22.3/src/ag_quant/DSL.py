"""
Domain Specific Language (DSL) 

最后修改时间: 2026-02-12
"""

import pandas as pd

from ._util import _to_list


class DSL():
    """
    基于时间序列Pandas Dataframe的“领域特定语言 (domain specific langauge, DSL)”
    """
    def __init__(self, df:pd.DataFrame|pd.Series = None):
        if df is None:
            self._df = pd.DataFrame()
        self._df = pd.DataFrame(df.copy())
    
    # ---------------------------- Python 技术功能 ----------------------------
    def _to_df(self,x=None) -> pd.DataFrame:
        if x is None:
            out = self._df.squeeze("columns") if self._df.shape[1]==1 else self._df
        elif x is not None and isinstance(x, self.__class__):
            out = x._df.squeeze("columns") if self._df.shape[1]==1 else x._df 
        else:
            out = x
        return out
    
    def __getitem__(self, labels):
        """
        根据列label选择数据
        Args:
            labels: 要选择的列名
        """
        labels = _to_list(labels)
        temp = list(set(labels)-set(self._df.columns.to_list()))
        if len(temp)>0:
            raise KeyError(f"所选列labels不存在: {temp}")
        return self.__class__(self._df[labels])
    
    def __setitem__(self, labels, values):
        """
        根据列label赋值数据
        Args:
            labels: 要选择的列名
            values: 赋值
        """
        v = values._df if isinstance(values,DSL) else values
        self._df[_to_list(labels)] = v
        return self.__class__(self._df)
    
    @property
    def values(self):
        return self._df.copy()
    
    def describe(self):
        return self._df.describe()
    
    @property
    def dtypes(self):
        return self._df.dtypes

    # ---------------------------- 代数运算 ----------------------------
    def __add__(self, x):
        return self.__class__(self._to_df() + self._to_df(x))
    
    def __radd__(self, x):
        return self.__class__(self._to_df() + self._to_df(x))

    def __sub__(self, x):
        return self.__class__(self._to_df() - self._to_df(x))
    
    def __rsub__(self, x):
        return self.__class__(self._to_df() - self._to_df(x))

    def __mul__(self, x):
        return self.__class__(self._to_df() * self._to_df(x))
    
    def __rmul__(self, x):
        return self.__class__(self._to_df() * self._to_df(x))
        
    def __truediv__(self, x):
        return self.__class__(self._to_df() / self._to_df(x))
    
    def __rtruediv__(self, x):
        return self.__class__(self._to_df() / self._to_df(x))

    # ---------------------------- 比较 ----------------------------
    def __gt__(self, x): 
        return self.__class__(self._to_df() > self._to_df(x))
    
    def __ge__(self, x): 
        return self.__class__(self._to_df() >= self._to_df(x))
    
    def __lt__(self, x): 
        return self.__class__(self._to_df() < self._to_df(x))
        
    def __le__(self, x): 
        return self.__class__(self._to_df() <= self._to_df(x))
    
    def __eq__(self, x): 
        return self.__class__(self._to_df() == self._to_df(x))
    
    # ---------------------------- 逻辑运算 ----------------------------
    def __and__(self, x): 
        return self.__class__(self._to_df() & self._to_df(x))
    
    def __or__(self, x):  
        return self.__class__(self._to_df() | self._to_df(x))
    
    def __invert__(self):  
        return self.__class__(~self._to_df())

