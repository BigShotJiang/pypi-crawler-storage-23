"""
数据预处理

最后修改时间: 2026-02-12
"""

import pandas as pd


def clean(df:pd.DataFrame, datetime_colume_label: str = 'date', freq: str = None):
    """
    清理源数据, 将行index改为DatetimeIndex
    Args:
        df(pd.DataFrame): 源数据dataframe
        datetime_colume_label(str): 源数据中包含时间信息的列label
        freq(str): 源数据时间频率
    """
    df[datetime_colume_label] = pd.to_datetime(df[datetime_colume_label], errors='coerce')
    df = df.set_index(datetime_colume_label).sort_index() 
    freq = df.index.to_series().diff().mean().floor("D") if freq is None else freq   # get the data frequency
    df = df.asfreq(freq)
    df = df.astype('float')
    return df