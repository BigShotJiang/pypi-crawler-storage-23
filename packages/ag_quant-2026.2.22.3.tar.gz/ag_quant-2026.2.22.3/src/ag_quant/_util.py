"""
一些技术/检查工具

最后修改时间: 2026-02-22
"""

import pandas as pd
from typing import get_type_hints
import inspect
import types



def _to_list(args: tuple|object):
    if isinstance(args, tuple):
        return list(args) 
    elif isinstance(args, list):
        return args
    else:
        return [args]
    

def _check_DatetimeIndex(df: pd.DataFrame|pd.Series):
    """
    确保DataFrame的行index的数据类型为pd.DatetimeIndex, 且已设定频率
    """
    if not isinstance(df, pd.DataFrame|pd.Series): 
        raise TypeError('信号数据类型不是DataFrame或Series')
    if not isinstance(df.index, pd.DatetimeIndex):
        raise TypeError('输入DateFrame行index的数据类型不是pd.DatetimeIndex')  
    if df.index.freq is None:
        raise TypeError('输入DateFrame行DatetimeIndex没有设定freq')        
    df.sort_index(inplace=True)


def read_py(file: str, type: object):
    """
    解析.py文件, 得到构造函数
    Args:
        file(str): .py文件
        type(object): 构造函数的类型, 例如Factor, Stratagy
    """
    with open(file, "r", encoding="utf-8") as f:
        code = f.read()
    namespace = {}
    compiled = compile(code, 'temp', "exec")
    exec(compiled, namespace)   # 执行后，函数会出现在 namespace 里
    func_dict = dict()
    for _, obj in namespace.items():
        # 只要“普通 def 定义的函数”
        if isinstance(obj, types.FunctionType):
            # 确保要是合法定义
            sig = inspect.signature(obj)
            params = list(sig.parameters.values())
            hints = get_type_hints(obj, globalns=globals(), localns=locals()) # get_type_hints 会解析 "Factor" 这类前向引用
            p0 = params[0].name
            if (
                len(params) != 1 or 
                p0 not in hints or 
                hints[p0] is not type or
                obj.__name__.startswith("_") 
            ): 
                continue
            func_dict[obj.__name__] = obj
    return func_dict