"""
单一策略交易

注意：回测的对象是策略，而不是因子。策略可以认为是由因子组成的。回测的好坏直接说明策略的表现，而策略的表现会收到因子有效性的影响。因子有自己的评价指标（例如IC、IR）

最后修改时间: 2026-02-12
"""

import pandas as pd
from typing import Callable
import inspect

from ._util import _check_DatetimeIndex
from .Factor import Factor
from .Strategy import Strategy
from .StrategyValues import StrategyValues

class SingleStrategyBackTesting():
    """
    单一策略交易
        注意: 策略不等于交易品种(大豆、菜籽), 单一策略可以应用到多种交易品种生成不同交易信号
    """
    def __init__(self, func: Callable[[Strategy],None], name: str = None):
        """
        单一策略交易
            注意: 策略不等于交易品种(大豆、菜籽), 单一策略可以应用到多种交易品种生成不同交易信号
        Args:
            func(Callable): 单一策略
            name(str): 策略名称
        """
        # 策略名称
        # 以name中命名策略
        if name is not None: 
            self._func_name = name
        # 从func的docstring中获取策略名称
        elif name is None and inspect.getdoc(func) is not None: 
            self._func_name = inspect.getdoc(func)
        # 从func.__name__命名策略
        else: 
            self._func_name = func.__name__ 
        self._func = func # 单一策略
        self._market = pd.DataFrame() # 当前市场数据
        self._func_data = pd.DataFrame() # 当前策略绑定数据
        self._all_signals = pd.DataFrame()  # 单一策略生成的所有信号
        self._all_holding_positions = pd.DataFrame() # 持仓记录
        self._all_cash_flows = pd.DataFrame() # 所有现金流变动记录

    def set_market_data(self, df:pd.DataFrame, name:str=None):
        """
        绑定单一交易品种的市场数据: 交易需要在市场数据中进行
        Args:
            df: 单一交易品种的市场数据
            name: 交易品种名称
        """
        _check_DatetimeIndex(df)
        if name is not None and name in df.columns.values:
            raise ValueError('交易品种名称重复')
        self._market = df
        self._market_name = name
        return self

    def _rename_by_market(self, df: pd.DataFrame):
        df.rename(columns={df.columns[-1]: self._market_name},inplace=True)

    def set_strategy_data(self, df: pd.DataFrame|Factor):
        """
        绑定因子值: 策略需要通过因子值才能生成交易信号
        Args:
            df: 因子值
        """
        _check_DatetimeIndex(df)
        self._func_data = df
        return self

    def _signals_to_positions(self, signals:pd.DataFrame) -> pd.DataFrame:
        """
        由信号合成持仓量
        """
        return signals.cumsum()

    def run(self):
        """
        开始按照该策略进行交易
        """
        if self._market.empty:
            raise ValueError('未绑定市场数据，无法交易, 请先调用.set_market_data()绑定市场数据')
        if self._func_data.empty:
            raise ValueError('未绑定因子值，策略无法转变为信号, 请先调用.set_strategy_data()绑定因子值')
        # 用self._market.index初始化Index, 保证全局索引对齐
        self._all_signals = self._all_signals.reindex(self._market.index.copy())
        self._all_holding_positions = self._all_holding_positions.reindex(self._market.index.copy()) 
        self._all_cash_flows = self._all_cash_flows.reindex(self._market.index.copy()) 
        # 记录将当前信号
        signals = StrategyValues(self._func, self._func_data).values
        self._all_signals = self._all_signals.join(signals, rsuffix='_')
        self._rename_by_market(self._all_signals)
        # 将信号合成持仓量
        positions = self._signals_to_positions(signals)
        self._all_holding_positions = self._all_holding_positions.join(positions, rsuffix='_')
        self._rename_by_market(self._all_holding_positions)
        # 通过逐日盯市计算盈亏
        price_diff = self._market['price'].diff() # 逐日盯市的价差
        self._all_cash_flows = self._all_cash_flows.join(positions.shift(periods=1).mul(price_diff, axis=0), rsuffix='_')
        self._rename_by_market(self._all_cash_flows)
        # 清空市场数据和信号, 防止重复交易同一交易品种
        self._market = pd.DataFrame()
        self._func_data = pd.DataFrame()
        return self
    
    @property
    def cumulative_profit_and_loss(self) -> pd.DataFrame:
        """
        计算累计盈亏
        """
        return self._all_cash_flows.resample(pd.Timedelta(days=1)).sum().cumsum()

    def plot(self):
        """
        画图
        """
        ax = self.cumulative_profit_and_loss.plot(legend=True)
        ax.legend(loc='best')      
        ax.set_title(f'策略名称:{self._func_name}\n 累计盈亏随时间变化记录')
        ax.set_xlabel('时间')
        ax.set_ylabel('货币单位')
        
        ax = self._all_holding_positions.plot(legend=True)
        ax.legend(loc='best')      
        ax.set_title(f'策略名称:{self._func_name}\n 持仓量随时间变化记录')
        ax.set_xlabel('时间')
        ax.set_ylabel('仓位')
