"""Core installer functionality for mcp-guide."""
