"""Middleware package for command processing."""
