"""Feature flags module for mcp-guide."""
