"""MemoTrail — Persistent memory layer for AI coding assistants."""

__version__ = "0.3.1"
