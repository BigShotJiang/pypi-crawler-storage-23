<div align="center">

# MemoTrail

> 🌐 یہ ایک خودکار ترجمہ ہے۔ کمیونٹی کی اصلاحات کا خیرمقدم ہے! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**آپ کا AI کوڈنگ اسسٹنٹ سب کچھ بھول جاتا ہے۔ MemoTrail اسے حل کرتا ہے۔**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

AI کوڈنگ اسسٹنٹس کے لیے مستقل میموری لیئر۔
ہر سیشن ریکارڈ، ہر فیصلہ تلاش کے قابل، ہر سیاق و سباق یاد رکھا گیا۔

</div>

---

## v0.3.0 میں نیا کیا ہے

- **خودکار سیشن خلاصہ** — ہر سیشن کو AI سے تیار کردہ خلاصہ ملتا ہے (کوئی API کلید ضروری نہیں)
- **خودکار فیصلے کا استخراج** — پیٹرن میچنگ کا استعمال کرتے ہوئے بات چیت سے آرکیٹیکچر فیصلے خودکار طور پر شناخت کیے جاتے ہیں
- **BM25 کیورڈ تلاش** — عین مطابق الفاظ، غلطی کے پیغامات، فنکشن ناموں کے لیے نیا `search_keyword` ٹول
- **ہائبرڈ تلاش** — reciprocal rank fusion کا استعمال کرتے ہوئے سیمینٹک + کیورڈ نتائج کو ملاتا ہے
- **Cursor IDE سپورٹ** — `state.vscdb` فائلوں سے Cursor چیٹ تاریخ انڈیکس کرتا ہے
- **ریئل ٹائم فائل مانیٹرنگ** — watchdog کے ذریعے نئے سیشنز فوری طور پر انڈیکس ہوتے ہیں (ری سٹارٹ کی ضرورت نہیں)
- **چنکنگ حکمت عملی** — ٹوکن پر مبنی، ٹرن پر مبنی، یا ریکرسو تقسیم میں سے منتخب کریں
- **VS Code ایکسٹینشن** — VS Code سے براہ راست تلاش، انڈیکس اور اعداد و شمار دیکھیں
- **69 ٹیسٹ** — تمام ماڈیولز میں جامع ٹیسٹ کوریج

## مسئلہ

Claude Code کا ہر نیا سیشن صفر سے شروع ہوتا ہے۔ آپ کا AI کل کے 3 گھنٹے کے ڈیبگنگ سیشن، پچھلے ہفتے کے آرکیٹیکچر فیصلوں، یا پہلے سے ناکام ہو چکے طریقوں کو یاد نہیں رکھتا۔

**MemoTrail کے بغیر:**
```
آپ: "کیشنگ کے لیے Redis استعمال کرتے ہیں"
AI:   "ضرور، Redis سیٹ اپ کرتے ہیں"
         ... 2 ہفتے بعد، نیا سیشن ...
آپ: "ہم Redis کیوں استعمال کر رہے ہیں؟"
AI:   "مجھے اس فیصلے کے بارے میں کوئی سیاق نہیں ہے"
```

**MemoTrail کے ساتھ:**
```
آپ: "ہم Redis کیوں استعمال کر رہے ہیں؟"
AI:   "15 جنوری کے سیشن کی بنیاد پر — آپ نے Redis بمقابلہ Memcached کا جائزہ لیا۔
       ڈیٹا سٹرکچر سپورٹ اور استقامت کے لیے Redis منتخب کیا گیا۔
       بحث سیشن #42 میں ہے۔"
```

## فوری آغاز

```bash
# 1. انسٹال کریں
pip install memotrail

# 2. Claude Code سے جوڑیں
claude mcp add memotrail -- memotrail serve
```

بس۔ MemoTrail پہلی بار لانچ پر آپ کی تاریخ کو خودکار طور پر انڈیکس کرتا ہے۔

## یہ کیسے کام کرتا ہے

| مرحلہ | کیا ہوتا ہے |
|:----:|:-------------|
| **1. ریکارڈ** | MemoTrail سٹارٹ اپ پر نئے سیشنز کو خودکار انڈیکس کرتا ہے + ریئل ٹائم میں نئی فائلوں کی نگرانی کرتا ہے |
| **2. تقسیم** | بات چیت کو ٹوکن، ٹرن پر مبنی، یا ریکرسو حکمت عملیوں کا استعمال کرتے ہوئے تقسیم کیا جاتا ہے |
| **3. ایمبیڈنگ** | ہر حصہ `all-MiniLM-L6-v2` سے ایمبیڈ ہوتا ہے (~80MB، CPU پر چلتا ہے) |
| **4. استخراج** | خلاصے اور آرکیٹیکچر فیصلے خودکار طور پر نکالے جاتے ہیں |
| **5. ذخیرہ** | ویکٹرز ChromaDB میں، میٹا ڈیٹا SQLite میں — سب `~/.memotrail/` میں |
| **6. تلاش** | سیمینٹک + BM25 کیورڈ تلاش آپ کی پوری تاریخ میں |
| **7. دکھائیں** | سب سے متعلقہ ماضی کا سیاق بالکل تب ظاہر ہوتا ہے جب آپ کو ضرورت ہو |

> **100% مقامی** — کوئی کلاؤڈ نہیں، کوئی API کلید نہیں، کوئی ڈیٹا آپ کی مشین نہیں چھوڑتا۔
>
> **ملٹی پلیٹ فارم** — Claude Code اور Cursor IDE کو سپورٹ کرتا ہے، مزید جلد آ رہے ہیں۔

## دستیاب ٹولز

| ٹول | تفصیل |
|------|-------------|
| `search_chats` | تمام ماضی کی بات چیت میں سیمینٹک تلاش |
| `search_keyword` | BM25 کیورڈ تلاش — عین مطابق الفاظ، فنکشن نام، غلطی کے پیغامات کے لیے بہترین |
| `get_decisions` | ریکارڈ شدہ آرکیٹیکچر فیصلے حاصل کریں (خودکار استخراج + دستی) |
| `get_recent_sessions` | AI سے تیار کردہ خلاصوں کے ساتھ حالیہ کوڈنگ سیشنز کی فہرست |
| `get_session_detail` | کسی مخصوص سیشن کے مواد کا تفصیلی جائزہ |
| `save_memory` | اہم حقائق یا فیصلے دستی طور پر محفوظ کریں |
| `memory_stats` | انڈیکسنگ کے اعداد و شمار اور اسٹوریج کا استعمال دیکھیں |

## CLI کمانڈز

```bash
memotrail serve                          # MCP سرور شروع کریں
memotrail search "redis caching decision"  # ٹرمینل سے تلاش کریں
memotrail stats                          # انڈیکسنگ کے اعداد و شمار دیکھیں
memotrail index                          # دستی طور پر دوبارہ انڈیکس کریں (اختیاری)
```

## آرکیٹیکچر

```
~/.memotrail/
├── chroma/          # ویکٹر ایمبیڈنگز (ChromaDB)
└── memotrail.db     # سیشن میٹا ڈیٹا (SQLite)
```

| جزو | ٹیکنالوجی | تفصیلات |
|-----------|-----------|---------|
| ایمبیڈنگز | `all-MiniLM-L6-v2` | ~80MB، CPU پر چلتا ہے |
| ویکٹر DB | ChromaDB | مستقل مقامی اسٹوریج |
| کیورڈ تلاش | BM25 | خالص Python، کوئی اضافی انحصار نہیں |
| میٹا ڈیٹا | SQLite | سنگل فائل ڈیٹا بیس |
| فائل مانیٹرنگ | watchdog | ریئل ٹائم سیشن شناخت |
| پروٹوکول | MCP | Model Context Protocol |

### معاون پلیٹ فارمز

| پلیٹ فارم | حیثیت | فارمیٹ |
|----------|--------|--------|
| Claude Code | معاون | JSONL سیشن فائلز |
| Cursor IDE | معاون | state.vscdb (SQLite) |
| GitHub Copilot | منصوبہ بند | — |

### چنکنگ حکمت عملی

| حکمت عملی | بہترین استعمال |
|----------|----------|
| `token` (ڈیفالٹ) | عام استعمال — ٹوکن حد تک پیغامات کو گروپ کرتا ہے |
| `turn` | بات چیت پر مبنی — صارف+معاون جوڑوں کو گروپ کرتا ہے |
| `recursive` | طویل مواد — پیراگراف، جملوں، الفاظ پر تقسیم کرتا ہے |

## MemoTrail کیوں؟

| | MemoTrail | CLAUDE.md / قواعد فائلز | دستی نوٹس |
|---|---|---|---|
| خودکار | ہاں — ہر سیشن شروع پر انڈیکس | نہیں — آپ لکھتے ہیں | نہیں |
| تلاش کے قابل | سیمینٹک تلاش | AI پڑھتا ہے، لیکن صرف جو آپ نے لکھا | صرف Ctrl+F |
| اسکیل ایبل | ہزاروں سیشنز | ایک فائل | بکھری ہوئی فائلیں |
| سیاق سے آگاہ | متعلقہ سیاق واپس کرتا ہے | جامد قواعد | دستی تلاش |
| سیٹ اپ | 5 منٹ | مسلسل دیکھ بھال | مسلسل دیکھ بھال |

MemoTrail `CLAUDE.md` کی جگہ نہیں لیتا — یہ اس کا تکمیلی ہے۔ قواعد فائلز ہدایات کے لیے۔ MemoTrail میموری کے لیے۔

## روڈ میپ

- [x] Claude Code سیشن انڈیکسنگ
- [x] بات چیت میں سیمینٹک تلاش
- [x] 7 ٹولز کے ساتھ MCP سرور
- [x] انڈیکسنگ اور تلاش کے لیے CLI
- [x] سرور سٹارٹ اپ پر آٹو انڈیکسنگ
- [x] خودکار فیصلے کا استخراج
- [x] سیشن خلاصہ
- [x] Cursor IDE کلیکٹر
- [x] BM25 کیورڈ تلاش + ہائبرڈ تلاش
- [x] ریئل ٹائم فائل مانیٹرنگ (watchdog)
- [x] متعدد چنکنگ حکمت عملی (token، turn، recursive)
- [x] VS Code ایکسٹینشن
- [ ] Copilot کلیکٹر
- [ ] کلاؤڈ سنک (Pro)
- [ ] ٹیم میموری (Team)

## VS Code ایکسٹینشن

MemoTrail براہ راست IDE انٹیگریشن کے لیے VS Code ایکسٹینشن شامل کرتا ہے۔

**دستیاب کمانڈز:**
- `MemoTrail: Search Conversations` — سیمینٹک تلاش
- `MemoTrail: Keyword Search` — BM25 کیورڈ تلاش
- `MemoTrail: Recent Sessions` — سیشن اعداد و شمار دیکھیں
- `MemoTrail: Index Sessions Now` — دستی انڈیکسنگ شروع کریں
- `MemoTrail: Show Stats` — انڈیکسنگ اعداد و شمار دکھائیں

**سیٹ اپ:**
```bash
cd vscode-extension
npm install
npm run compile
# پھر VS Code میں F5 دبائیں ایکسٹینشن ڈیولپمنٹ ہوسٹ شروع کرنے کے لیے
```

## ڈیولپمنٹ

```bash
git clone https://github.com/HalilHopa-Datatent/memotrail.git
cd memotrail
pip install -e ".[dev]"
pytest
ruff check src/
```

## شراکت

شراکت کا خیرمقدم ہے! رہنما اصولوں کے لیے [CONTRIBUTING.md](../../docs/CONTRIBUTING.md) دیکھیں۔

## لائسنس

MIT — [LICENSE](../../LICENSE) دیکھیں

---

<div align="center">

**[Halil Hopa](https://halilhopa.com) نے بنایا** · [memotrail.ai](https://memotrail.ai)

اگر MemoTrail آپ کی مدد کرتا ہے تو GitHub پر اسٹار دینے پر غور کریں۔

</div>
