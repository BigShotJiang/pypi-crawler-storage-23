<div align="center">

# MemoTrail

> 🌐 นี่คือการแปลอัตโนมัติ ยินดีรับการแก้ไขจากชุมชน! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**ผู้ช่วยเขียนโค้ด AI ของคุณลืมทุกอย่าง MemoTrail แก้ปัญหานี้**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

ชั้นหน่วยความจำถาวรสำหรับผู้ช่วยเขียนโค้ด AI
ทุกเซสชันถูกบันทึก ทุกการตัดสินใจค้นหาได้ ทุกบริบทถูกจดจำ

</div>

---

## มีอะไรใหม่ใน v0.3.0

- **สรุปเซสชันอัตโนมัติ** — ทุกเซสชันจะได้รับสรุปที่สร้างโดย AI (ไม่ต้องใช้ API key)
- **การสกัดการตัดสินใจอัตโนมัติ** — การตัดสินใจด้านสถาปัตยกรรมถูกตรวจจับจากบทสนทนาโดยใช้การจับคู่รูปแบบ
- **การค้นหาคำหลัก BM25** — เครื่องมือ `search_keyword` ใหม่สำหรับคำที่ต้องการ, ข้อความผิดพลาด, ชื่อฟังก์ชัน
- **การค้นหาแบบผสม** — รวมผลลัพธ์เชิงความหมาย + คำหลักโดยใช้ reciprocal rank fusion
- **รองรับ Cursor IDE** — จัดทำดัชนีประวัติแชท Cursor จากไฟล์ `state.vscdb`
- **การติดตามไฟล์แบบเรียลไทม์** — เซสชันใหม่ถูกจัดทำดัชนีทันทีผ่าน watchdog (ไม่ต้องรีสตาร์ท)
- **กลยุทธ์การแบ่ง** — เลือกระหว่าง token-based, turn-based หรือการแบ่งแบบ recursive
- **ส่วนขยาย VS Code** — ค้นหา จัดทำดัชนี และดูสถิติจาก VS Code โดยตรง
- **69 การทดสอบ** — ครอบคลุมการทดสอบอย่างครอบคลุมในทุกโมดูล

## ปัญหา

ทุกเซสชันใหม่ของ Claude Code เริ่มต้นจากศูนย์ AI ของคุณไม่จำเซสชันดีบัก 3 ชั่วโมงเมื่อวาน การตัดสินใจด้านสถาปัตยกรรมเมื่อสัปดาห์ที่แล้ว หรือแนวทางที่ล้มเหลวไปแล้ว

**ไม่มี MemoTrail:**
```
คุณ: "ใช้ Redis สำหรับ caching กัน"
AI:   "ได้เลย มาตั้งค่า Redis กัน"
         ... 2 สัปดาห์ต่อมา เซสชันใหม่ ...
คุณ: "ทำไมเราถึงใช้ Redis?"
AI:   "ผมไม่มีบริบทเกี่ยวกับการตัดสินใจนั้น"
```

**มี MemoTrail:**
```
คุณ: "ทำไมเราถึงใช้ Redis?"
AI:   "จากเซสชันวันที่ 15 มกราคม — คุณประเมิน Redis กับ Memcached
       Redis ถูกเลือกเพราะรองรับโครงสร้างข้อมูลและความคงทน
       การสนทนาอยู่ในเซสชัน #42"
```

## เริ่มต้นอย่างรวดเร็ว

```bash
# 1. ติดตั้ง
pip install memotrail

# 2. เชื่อมต่อกับ Claude Code
claude mcp add memotrail -- memotrail serve
```

แค่นั้น MemoTrail จะจัดทำดัชนีประวัติของคุณโดยอัตโนมัติเมื่อเปิดใช้ครั้งแรก

## วิธีการทำงาน

| ขั้นตอน | สิ่งที่เกิดขึ้น |
|:----:|:-------------|
| **1. บันทึก** | MemoTrail จัดทำดัชนีเซสชันใหม่โดยอัตโนมัติเมื่อเริ่มต้น + ติดตามไฟล์ใหม่แบบเรียลไทม์ |
| **2. แบ่ง** | บทสนทนาถูกแบ่งโดยใช้กลยุทธ์ token, turn-based หรือ recursive |
| **3. ฝัง** | แต่ละส่วนถูกฝังด้วย `all-MiniLM-L6-v2` (~80MB, ทำงานบน CPU) |
| **4. สกัด** | สรุปและการตัดสินใจด้านสถาปัตยกรรมถูกสกัดโดยอัตโนมัติ |
| **5. เก็บ** | เวกเตอร์ไปที่ ChromaDB, เมตาดาต้าไปที่ SQLite — ทั้งหมดใน `~/.memotrail/` |
| **6. ค้นหา** | การค้นหาเชิงความหมาย + BM25 คำหลักทั่วประวัติทั้งหมดของคุณ |
| **7. แสดง** | บริบทในอดีตที่เกี่ยวข้องที่สุดปรากฏขึ้นเมื่อคุณต้องการ |

> **100% ในเครื่อง** — ไม่มีคลาวด์ ไม่มี API key ไม่มีข้อมูลออกจากเครื่องของคุณ
>
> **หลายแพลตฟอร์ม** — รองรับ Claude Code และ Cursor IDE พร้อมแพลตฟอร์มอื่นเร็ว ๆ นี้

## เครื่องมือที่มี

| เครื่องมือ | คำอธิบาย |
|------|-------------|
| `search_chats` | ค้นหาเชิงความหมายในบทสนทนาทั้งหมด |
| `search_keyword` | ค้นหาคำหลัก BM25 — เหมาะสำหรับคำที่ต้องการ ชื่อฟังก์ชัน ข้อความผิดพลาด |
| `get_decisions` | ดึงการตัดสินใจด้านสถาปัตยกรรมที่บันทึกไว้ (สกัดอัตโนมัติ + ด้วยตนเอง) |
| `get_recent_sessions` | แสดงรายการเซสชันล่าสุดพร้อมสรุปที่สร้างโดย AI |
| `get_session_detail` | ดูรายละเอียดเนื้อหาของเซสชันที่ระบุ |
| `save_memory` | บันทึกข้อเท็จจริงหรือการตัดสินใจสำคัญด้วยตนเอง |
| `memory_stats` | ดูสถิติการจัดทำดัชนีและการใช้พื้นที่จัดเก็บ |

## คำสั่ง CLI

```bash
memotrail serve                          # เริ่มเซิร์ฟเวอร์ MCP (จัดทำดัชนีเซสชันใหม่โดยอัตโนมัติ)
memotrail search "redis caching decision"  # ค้นหาจากเทอร์มินัล
memotrail stats                          # ดูสถิติการจัดทำดัชนี
memotrail index                          # จัดทำดัชนีใหม่ด้วยตนเอง (ไม่จำเป็น)
```

## สถาปัตยกรรม

```
~/.memotrail/
├── chroma/          # เวกเตอร์เอ็มเบดดิ้ง (ChromaDB)
└── memotrail.db     # เมตาดาต้าเซสชัน (SQLite)
```

| ส่วนประกอบ | เทคโนโลยี | รายละเอียด |
|-----------|-----------|---------|
| เอ็มเบดดิ้ง | `all-MiniLM-L6-v2` | ~80MB, ทำงานบน CPU |
| Vector DB | ChromaDB | ที่จัดเก็บถาวรในเครื่อง |
| ค้นหาคำหลัก | BM25 | Python ล้วน ไม่ต้องมี dependency เพิ่มเติม |
| เมตาดาต้า | SQLite | ฐานข้อมูลไฟล์เดียว |
| ติดตามไฟล์ | watchdog | ตรวจจับเซสชันแบบเรียลไทม์ |
| โปรโตคอล | MCP | Model Context Protocol |

### แพลตฟอร์มที่รองรับ

| แพลตฟอร์ม | สถานะ | รูปแบบ |
|----------|--------|--------|
| Claude Code | รองรับ | ไฟล์เซสชัน JSONL |
| Cursor IDE | รองรับ | state.vscdb (SQLite) |
| GitHub Copilot | วางแผนไว้ | — |

### กลยุทธ์การแบ่ง

| กลยุทธ์ | เหมาะสำหรับ |
|----------|----------|
| `token` (ค่าเริ่มต้น) | ใช้งานทั่วไป — จัดกลุ่มข้อความจนถึงขีดจำกัด token |
| `turn` | เน้นบทสนทนา — จัดกลุ่มคู่ผู้ใช้+ผู้ช่วย |
| `recursive` | เนื้อหายาว — แบ่งตามย่อหน้า ประโยค คำ |

## ทำไมต้อง MemoTrail?

| | MemoTrail | CLAUDE.md / ไฟล์กฎ | บันทึกด้วยตนเอง |
|---|---|---|---|
| อัตโนมัติ | ใช่ — จัดทำดัชนีทุกครั้งที่เริ่มเซสชัน | ไม่ — คุณเขียนเอง | ไม่ |
| ค้นหาได้ | ค้นหาเชิงความหมาย | AI อ่าน แต่เฉพาะสิ่งที่คุณเขียน | Ctrl+F เท่านั้น |
| ขยายได้ | เซสชันนับพัน | ไฟล์เดียว | ไฟล์กระจัดกระจาย |
| รู้บริบท | คืนบริบทที่เกี่ยวข้อง | กฎคงที่ | ค้นหาด้วยตนเอง |
| ตั้งค่า | 5 นาที | ต้องดูแลตลอด | ต้องดูแลตลอด |

MemoTrail ไม่ได้แทนที่ `CLAUDE.md` — แต่เสริมมัน ไฟล์กฎสำหรับคำสั่ง MemoTrail สำหรับความทรงจำ

## แผนงาน

- [x] จัดทำดัชนีเซสชัน Claude Code
- [x] ค้นหาเชิงความหมายระหว่างบทสนทนา
- [x] MCP server พร้อม 7 เครื่องมือ
- [x] CLI สำหรับจัดทำดัชนีและค้นหา
- [x] จัดทำดัชนีอัตโนมัติเมื่อ server เริ่มต้น
- [x] การสกัดการตัดสินใจอัตโนมัติ
- [x] การสรุปเซสชัน
- [x] ตัวรวบรวม Cursor IDE
- [x] ค้นหาคำหลัก BM25 + ค้นหาแบบผสม
- [x] ติดตามไฟล์แบบเรียลไทม์ (watchdog)
- [x] กลยุทธ์การแบ่งหลากหลาย (token, turn, recursive)
- [x] ส่วนขยาย VS Code
- [ ] ตัวรวบรวม Copilot
- [ ] ซิงค์คลาวด์ (Pro)
- [ ] หน่วยความจำทีม (Team)

## ส่วนขยาย VS Code

MemoTrail มีส่วนขยาย VS Code สำหรับการรวมเข้ากับ IDE โดยตรง

**คำสั่งที่มี:**
- `MemoTrail: Search Conversations` — ค้นหาเชิงความหมาย
- `MemoTrail: Keyword Search` — ค้นหาคำหลัก BM25
- `MemoTrail: Recent Sessions` — ดูสถิติเซสชัน
- `MemoTrail: Index Sessions Now` — เริ่มจัดทำดัชนีด้วยตนเอง
- `MemoTrail: Show Stats` — แสดงสถิติการจัดทำดัชนี

**ตั้งค่า:**
```bash
cd vscode-extension
npm install
npm run compile
# จากนั้นกด F5 ใน VS Code เพื่อเปิด Extension Development Host
```

## การพัฒนา

```bash
git clone https://github.com/HalilHopa-Datatent/memotrail.git
cd memotrail
pip install -e ".[dev]"
pytest
ruff check src/
```

## การมีส่วนร่วม

ยินดีรับการมีส่วนร่วม! ดู [CONTRIBUTING.md](../../docs/CONTRIBUTING.md) สำหรับแนวทาง

## สัญญาอนุญาต

MIT — ดู [LICENSE](../../LICENSE)

---

<div align="center">

**สร้างโดย [Halil Hopa](https://halilhopa.com)** · [memotrail.ai](https://memotrail.ai)

หาก MemoTrail ช่วยคุณได้ โปรดพิจารณาให้ดาวบน GitHub

</div>
