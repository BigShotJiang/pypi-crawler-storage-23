Icon Credits
############


* target.png: "Target Flat Icon.svg de Wikimedia Commons par Videoplasty.com, CC-BY-SA 4.0"
  https://fr.wikipedia.org/wiki/Fichier:Target_Flat_Icon.svg
* algo.png: <a href="https://www.flaticon.com/fr/icones-gratuites/algorithme" title="algorithme icônes">Algorithme icônes créées par phatplus - Flaticon</a>
