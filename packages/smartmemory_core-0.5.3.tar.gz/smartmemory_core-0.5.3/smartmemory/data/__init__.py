# Package data directory for bundled resources (snapshots, etc.)
