"""smartmemory.tools — standalone utilities (CLI helpers, markdown writer, lite factory)."""
