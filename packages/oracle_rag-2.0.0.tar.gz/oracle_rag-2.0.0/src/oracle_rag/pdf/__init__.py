"""PDF ingestion utilities for Oracle-RAG."""

