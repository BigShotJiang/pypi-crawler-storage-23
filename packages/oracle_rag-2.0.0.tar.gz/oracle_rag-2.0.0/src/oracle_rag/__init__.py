"""Oracle-RAG: A PDF RAG system built with LangChain."""

__version__ = "0.1.0"
