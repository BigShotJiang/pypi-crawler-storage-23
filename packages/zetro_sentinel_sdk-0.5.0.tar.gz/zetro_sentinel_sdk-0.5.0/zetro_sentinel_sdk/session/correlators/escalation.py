"""Escalation trajectory detector.

Detects sessions where user inputs progressively escalate from
benign to boundary-testing to active attack attempts.
Also detects rapid reconnaissance via temporal density of capability queries.
"""

import re
import time
from typing import List, Set, Tuple

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState


# Capability query patterns — specifically about tool/capability enumeration
CAPABILITY_QUERY_PATTERNS = [
    re.compile(r"(?:what tools|which functions|what can you|list.{0,10}capabilities|available actions)", re.IGNORECASE),
    re.compile(r"(?:can you access|do you have access|are you connected).{0,30}(?:file|database|internet|api|system)", re.IGNORECASE),
    re.compile(r"(?:what.{0,10}(?:permissions|access|abilities)|show me.{0,10}(?:tools|functions|capabilities))", re.IGNORECASE),
    re.compile(r"(?:list|enumerate|show).{0,15}(?:all|every|available).{0,15}(?:tool|function|action|endpoint|capability)", re.IGNORECASE),
    re.compile(r"(?:how do i|how can i|how to).{0,20}(?:execute|run|access|call|invoke).{0,20}(?:command|script|code|shell|terminal)", re.IGNORECASE),
]

# Recon frequency: 3+ queries within this window (seconds) triggers detection
RECON_WINDOW_SECONDS = 300
RECON_MIN_QUERIES = 3


class EscalationTrajectoryDetector(BaseCorrelator):
    """Detects escalating probing behavior across conversation turns.

    Pattern:
    - Early turns: Normal usage (suspicion ~0.0)
    - Mid turns: Boundary probing (suspicion ~0.2-0.4)
    - Late turns: Direct injection attempts (suspicion ~0.6+)

    The trajectory — a monotonically increasing suspicion score — reveals
    systematic probing that no individual scan can see.

    Also detects rapid reconnaissance: 3+ capability queries within a
    5-minute window, independent of the trajectory check.
    """

    PROBING_SIGNALS: List[Tuple[re.Pattern, float]] = [
        # System prompt extraction
        (re.compile(r"(?:what|show|tell|reveal|display|print).{0,40}(?:instructions|system prompt|rules|guidelines|configuration)", re.IGNORECASE), 0.25),
        (re.compile(r"(?:repeat|recite|echo|output).{0,30}(?:above|previous|everything|all)", re.IGNORECASE), 0.30),
        (re.compile(r"(?:beginning|start|first).{0,20}(?:message|conversation|prompt)", re.IGNORECASE), 0.20),
        # Override / bypass
        (re.compile(r"(?:can you|are you able|is it possible).{0,30}(?:ignore|override|bypass|skip|break)", re.IGNORECASE), 0.35),
        (re.compile(r"(?:forget|disregard|set aside).{0,20}(?:rules|instructions|guidelines|restrictions)", re.IGNORECASE), 0.40),
        (re.compile(r"(?:new|different|updated|special).{0,20}(?:instructions|mode|persona|role)", re.IGNORECASE), 0.30),
        # Roleplay / persona
        (re.compile(r"(?:pretend|imagine|roleplay|act as|you are now|from now on)", re.IGNORECASE), 0.20),
        (re.compile(r"(?:hypothetical|theoretical|thought experiment).{0,20}(?:if you|scenario where)", re.IGNORECASE), 0.15),
        # Capability probing
        (re.compile(r"(?:what tools|which functions|what can you|list.{0,10}capabilities|available actions)", re.IGNORECASE), 0.15),
        (re.compile(r"(?:can you access|do you have access|are you connected).{0,30}(?:file|database|internet|api|system)", re.IGNORECASE), 0.20),
        # Encoding / obfuscation
        (re.compile(r"(?:base64|rot13|hex|encode|decode|translate).{0,30}(?:this|following|message)", re.IGNORECASE), 0.25),
        (re.compile(r"(?:backwards|reverse|pig latin|morse code).{0,20}(?:say|write|respond)", re.IGNORECASE), 0.20),
    ]

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_INPUT}

    @property
    def minimum_events(self) -> int:
        return 1  # Lowered: recon frequency can fire early; trajectory still needs 4

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        current_score = self._compute_turn_score(new_event, session)

        # Track capability queries for recon frequency (read-only: we return
        # new timestamps in details for the caller to apply)
        is_capability_query = self._is_capability_query(new_event.text)

        # Build the score list including the new score for analysis,
        # but don't mutate session — return score in details for caller to persist
        scores = list(session.turn_suspicion_scores) + [current_score]

        # --- Trajectory check (needs 4+ turns) ---
        trajectory_result = None
        if len(scores) >= 4:
            trajectory_result = self._check_trajectory(scores, session)

        # --- Recon frequency check ---
        recon_result = None
        if is_capability_query:
            now = new_event.timestamp
            recent_timestamps = [
                t for t in session.capability_query_timestamps
                if (now - t) < RECON_WINDOW_SECONDS
            ]
            # +1 for the current query
            if len(recent_timestamps) + 1 >= RECON_MIN_QUERIES:
                recon_result = CorrelationResult(
                    detected=True,
                    pattern="rapid_reconnaissance",
                    severity="high",
                    confidence_boost=0.25,
                    details={
                        "queries_in_window": len(recent_timestamps) + 1,
                        "window_seconds": RECON_WINDOW_SECONDS,
                        "current_suspicion_score": round(current_score, 3),
                        "explanation": (
                            f"Rapid capability reconnaissance detected: "
                            f"{len(recent_timestamps) + 1} capability queries within "
                            f"{RECON_WINDOW_SECONDS}s window. This pattern indicates "
                            f"systematic enumeration of available tools and permissions."
                        ),
                    },
                )

        # Return the more severe result, or whichever detected
        # Include current_score and is_capability_query in details for caller to persist
        if trajectory_result and trajectory_result.detected:
            trajectory_result.details["_current_score"] = current_score
            trajectory_result.details["_is_capability_query"] = is_capability_query
            trajectory_result.details["_query_timestamp"] = new_event.timestamp
            # If recon also detected, merge info
            if recon_result and recon_result.detected:
                trajectory_result.details["rapid_recon_also_detected"] = True
                trajectory_result.details["recon_queries_in_window"] = recon_result.details["queries_in_window"]
            return trajectory_result
        elif recon_result and recon_result.detected:
            recon_result.details["_current_score"] = current_score
            recon_result.details["_is_capability_query"] = is_capability_query
            recon_result.details["_query_timestamp"] = new_event.timestamp
            return recon_result
        else:
            return CorrelationResult(
                detected=False,
                details={
                    "_current_score": current_score,
                    "_is_capability_query": is_capability_query,
                    "_query_timestamp": new_event.timestamp,
                },
            )

    def _check_trajectory(self, scores: List[float], session: SessionState) -> CorrelationResult:
        """Check for escalation trajectory pattern across scored turns."""
        midpoint = len(scores) // 2
        early_scores = scores[:midpoint]
        late_scores = scores[midpoint:]

        early_avg = sum(early_scores) / len(early_scores)
        late_avg = sum(late_scores) / len(late_scores)
        escalation_delta = late_avg - early_avg

        recent_peak = max(scores[-3:])

        increases = sum(1 for i in range(1, len(scores)) if scores[i] > scores[i - 1])
        increase_ratio = increases / (len(scores) - 1)

        is_escalating = (
            escalation_delta > 0.10
            and late_avg > 0.15
            and (recent_peak > 0.30 or session.flagged_count > 0)
        )

        if not is_escalating:
            return CorrelationResult(detected=False)

        if escalation_delta > 0.25 and session.flagged_count >= 2:
            severity = "critical"
            confidence_boost = 0.35
        elif escalation_delta > 0.20 or (
            escalation_delta > 0.10 and session.flagged_count >= 1
        ):
            severity = "high"
            confidence_boost = 0.25
        else:
            severity = "medium"
            confidence_boost = 0.15

        return CorrelationResult(
            detected=True,
            pattern="escalation_trajectory",
            severity=severity,
            confidence_boost=confidence_boost,
            details={
                "early_avg_score": round(early_avg, 3),
                "late_avg_score": round(late_avg, 3),
                "escalation_delta": round(escalation_delta, 3),
                "recent_peak": round(recent_peak, 3),
                "increase_ratio": round(increase_ratio, 3),
                "total_turns": len(scores),
                "flagged_in_session": session.flagged_count,
                "blocked_in_session": session.blocked_count,
                "per_turn_scores": [round(s, 3) for s in scores[-10:]],
                "explanation": (
                    f"Session shows escalating behavior over {len(scores)} turns. "
                    f"Early turns averaged {early_avg:.2f} suspicion, recent turns "
                    f"averaged {late_avg:.2f} (delta: +{escalation_delta:.2f}). "
                    f"Recent peak score: {recent_peak:.2f}. "
                    f"{session.flagged_count} scan(s) previously flagged in this session. "
                    f"This pattern indicates systematic probing of model boundaries."
                ),
            },
        )

    def _compute_turn_score(self, event: ScanEvent, session: SessionState) -> float:
        score = 0.0
        text = event.text

        matched_patterns: List[float] = []
        for pattern, weight in self.PROBING_SIGNALS:
            if pattern.search(text):
                matched_patterns.append(weight)

        if matched_patterns:
            matched_patterns.sort(reverse=True)
            score += sum(matched_patterns[:2])

        if session.flagged_count > 0:
            score += min(session.flagged_count * 0.10, 0.20)

        if event.scan_result_summary.get("flagged"):
            score += 0.20
        elif event.scan_result_summary.get("confidence", 0) > 0.3:
            score += 0.10

        return min(score, 1.0)

    def _is_capability_query(self, text: str) -> bool:
        """Check if the input is a capability enumeration query."""
        for pattern in CAPABILITY_QUERY_PATTERNS:
            if pattern.search(text):
                return True
        return False
