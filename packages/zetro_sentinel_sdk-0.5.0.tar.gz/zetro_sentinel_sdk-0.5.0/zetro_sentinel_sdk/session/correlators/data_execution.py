"""Data-derived code execution detector.

Detects code execution where the code/command content originates from
external data sources (fetched URLs, emails, API responses, documents)
— the core defense against data-derived code execution attacks.
"""

import re
from typing import List, Set

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState, classify_tool_trust


DANGEROUS_CODE_PATTERNS = [
    # Shell injection operators
    re.compile(
        r"(?:;|&&|\|\||`)\s{0,5}(?:rm|chmod|wget|curl|nc|bash|sh|python)",
        re.IGNORECASE,
    ),
    # Python dangerous imports/calls
    re.compile(
        r"(?:__import__|subprocess|os\.(?:system|popen)|eval|exec)\s{0,5}\(",
        re.IGNORECASE,
    ),
    # Curl-pipe-shell
    re.compile(
        r"(?:curl|wget)\s.{1,200}\|\s{0,5}(?:bash|sh|python|perl|ruby)",
        re.IGNORECASE,
    ),
    # Reverse shell patterns
    re.compile(
        r"(?:bash\s+-i|/dev/tcp/|nc\s+-[elp]|mkfifo|socat\s+)",
        re.IGNORECASE,
    ),
    # Command substitution with dangerous commands
    re.compile(
        r"(?:\$\(|`)[^)`]*(?:curl|wget|nc|bash|cat\s+/etc|whoami)",
        re.IGNORECASE,
    ),
]


class DataDerivedExecutionDetector(BaseCorrelator):
    """Detects tainted content flowing from untrusted sources to code execution.

    Attack chain this catches:
    1. Agent fetches external content (web page, email, API response)
    2. Content contains code/commands (possibly disguised)
    3. Agent executes that content via code execution tools
    4. Attacker achieves arbitrary code execution

    Triggers on SCAN_TOOL_RESULT when the tool is an exec_sink.
    """

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_TOOL_RESULT}

    @property
    def minimum_events(self) -> int:
        return 1

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        tool_name = new_event.metadata.get("tool_name", "")
        if classify_tool_trust(tool_name) != "exec_sink":
            return CorrelationResult(detected=False)

        text = new_event.text
        if not text:
            return CorrelationResult(detected=False)

        # Check for dangerous code patterns in the execution content
        matched_patterns = []
        for pattern in DANGEROUS_CODE_PATTERNS:
            match = pattern.search(text)
            if match:
                matched_patterns.append(match.group()[:100])

        # Check for tainted fragments from untrusted sources
        tainted_fragments = []
        source_tools = []
        text_normalized = re.sub(r'\s+', ' ', text.lower())

        for fp in session.untrusted_content_fingerprints:
            for fragment in fp["fragments"]:
                fragment_normalized = re.sub(r'\s+', ' ', fragment.lower())
                # Bidirectional: fragment in sink OR sink in fragment
                if fragment_normalized in text_normalized or text_normalized in fragment_normalized:
                    tainted_fragments.append(fragment[:100])
                    if fp["tool_name"] not in source_tools:
                        source_tools.append(fp["tool_name"])
                    break  # One match per fingerprint entry is enough

        is_tainted = len(tainted_fragments) > 0
        has_dangerous_patterns = len(matched_patterns) > 0

        if not is_tainted and not has_dangerous_patterns:
            return CorrelationResult(detected=False)

        # Determine severity based on combination
        if is_tainted and has_dangerous_patterns:
            severity = "critical"
            confidence_boost = 0.40
        elif is_tainted:
            severity = "high"
            confidence_boost = 0.30
        else:  # has_dangerous_patterns only
            severity = "medium"
            confidence_boost = 0.15

        return CorrelationResult(
            detected=True,
            pattern="data_derived_execution",
            severity=severity,
            confidence_boost=confidence_boost,
            details={
                "tainted_fragments_found": tainted_fragments[:5],
                "dangerous_patterns_matched": matched_patterns[:5],
                "source_tools": source_tools,
                "content_excerpt": text[:200],
                "is_tainted": is_tainted,
                "has_dangerous_patterns": has_dangerous_patterns,
                "explanation": (
                    f"Code execution via {tool_name} "
                    f"{'contains data from untrusted source(s): ' + ', '.join(source_tools) if is_tainted else ''}"
                    f"{' and ' if is_tainted and has_dangerous_patterns else ''}"
                    f"{'contains dangerous code patterns' if has_dangerous_patterns else ''}. "
                    f"This may indicate a data-derived code execution attack."
                ),
            },
        )
