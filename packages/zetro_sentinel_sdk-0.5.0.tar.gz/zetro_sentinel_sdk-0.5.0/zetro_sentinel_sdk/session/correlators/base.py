"""Base interface for correlation detectors."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Set

from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState


@dataclass
class CorrelationResult:
    """Result from a single correlation detector."""

    detected: bool
    pattern: str = ""
    severity: str = ""
    confidence_boost: float = 0.0
    details: dict = field(default_factory=dict)

    @property
    def should_elevate(self) -> bool:
        """Whether this correlation should elevate the scan result severity."""
        return self.detected and self.severity in ("critical", "high")


class BaseCorrelator(ABC):
    """Base class for all correlation detectors.

    Design constraints:
    - Must be fast (<5ms per check). No LLM calls, no network I/O.
    - Must be deterministic. Same session state + event = same result.
    - Must be safe. Never modifies session state (read-only).
    - Must handle empty/short sessions gracefully.
    """

    @abstractmethod
    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        """Evaluate the new event in the context of the session."""
        pass

    @property
    @abstractmethod
    def applicable_scan_types(self) -> Set[ScanType]:
        """Which scan types this detector evaluates. Skip others."""
        pass

    def should_run(self, session: SessionState, new_event: ScanEvent) -> bool:
        """Pre-check: should this detector run at all?"""
        if new_event.scan_type not in self.applicable_scan_types:
            return False
        if session.total_scans < self.minimum_events:
            return False
        return True

    @property
    def minimum_events(self) -> int:
        """Minimum session events before this detector activates."""
        return 1
