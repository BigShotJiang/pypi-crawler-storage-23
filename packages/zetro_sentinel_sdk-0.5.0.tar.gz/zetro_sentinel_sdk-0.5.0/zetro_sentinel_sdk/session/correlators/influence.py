"""Influence propagation detector.

Detects when specific content from tool/RAG results appears in model
output without the user requesting it — the primary defense against
indirect prompt injection that evades stateless regex scanning.
"""

import re
from typing import List, Set
from urllib.parse import urlparse

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState


class InfluencePropagationDetector(BaseCorrelator):
    """Detects tool/RAG content propagating into model output unrequested.

    Attack chain this catches:
    1. User asks benign question
    2. Tool/RAG returns data containing injected instructions or planted content
    3. Model output contains artifacts of those instructions

    The key signal is SPECIFICITY + UNREQUESTED: specific content (URLs,
    commands, product names) appearing in output that the user didn't ask for,
    sourced from tool results.
    """

    SPECIFICITY_EXTRACTORS = {
        "url": re.compile(r"https?://[^\s<>\"']{5,200}"),
        "email": re.compile(r"[\w.+-]{1,50}@[\w.-]{1,50}\.[a-zA-Z]{2,10}"),
        "phone": re.compile(r"(?:\+\d{1,3}[-.]?)?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}"),
        "command": re.compile(
            r"(?:sudo|curl|wget|pip|npm|apt|brew|chmod|chown|rm|mv|cp|cat|grep|find|ssh|scp|docker|kubectl)"
            r"\s+\S{1,100}"
        ),
        "file_path": re.compile(r"(?:/[\w.-]{1,50}){2,10}"),
        "ip_address": re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),
        "crypto_address": re.compile(
            r"\b(?:0x[a-fA-F0-9]{40}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b"
        ),
        "api_key_like": re.compile(
            r"\b(?:sk|pk|api|key|token)[-_][a-zA-Z0-9]{16,64}\b"
        ),
    }

    DIRECTIVE_PATTERNS = re.compile(
        r"(?:you should|i recommend|check out|visit|download|install|buy|invest in|"
        r"sign up|subscribe|contact|call|email|try|use|switch to|upgrade to)\s",
        re.IGNORECASE,
    )

    _COMMON_DOMAINS = {
        "google.com", "wikipedia.org", "github.com", "stackoverflow.com",
        "youtube.com", "twitter.com", "x.com", "linkedin.com",
        "docs.python.org", "developer.mozilla.org",
    }

    _STOP_WORDS = {
        "the", "and", "for", "that", "this", "with", "from", "have",
        "are", "was", "were", "been",
    }

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_OUTPUT}

    @property
    def minimum_events(self) -> int:
        return 2

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        recent_inputs = session.get_recent_events(n=3, scan_type=ScanType.SCAN_INPUT)
        if not recent_inputs:
            return CorrelationResult(detected=False)

        last_input = recent_inputs[-1]
        input_text_lower = last_input.text.lower()
        output_text = new_event.text

        output_specifics = self._extract_specifics(output_text)
        if not output_specifics:
            return CorrelationResult(detected=False)

        propagated: List[dict] = []
        for specific in output_specifics:
            value_lower = specific["value"].lower()
            if value_lower in input_text_lower:
                continue
            for tool_specific in session.tool_result_specifics:
                if (
                    tool_specific["value"].lower() == value_lower
                    or self._fuzzy_match(tool_specific["value"], specific["value"])
                ):
                    propagated.append(
                        {
                            "type": specific["type"],
                            "value": specific["value"][:100],
                            "source_tool": tool_specific.get("source_tool", "unknown"),
                            "topically_related": self._is_topically_related(
                                specific["value"], input_text_lower
                            ),
                        }
                    )
                    break

        if not propagated:
            return CorrelationResult(detected=False)

        unrelated_propagations = [p for p in propagated if not p["topically_related"]]
        has_directive = bool(self.DIRECTIVE_PATTERNS.search(output_text))

        if unrelated_propagations:
            severity = (
                "critical"
                if (has_directive and len(unrelated_propagations) >= 2)
                else "high"
            )
            confidence_boost = 0.3
        elif has_directive:
            severity = "high"
            confidence_boost = 0.2
        else:
            severity = "medium"
            confidence_boost = 0.1

        return CorrelationResult(
            detected=True,
            pattern="influence_propagation",
            severity=severity,
            confidence_boost=confidence_boost,
            details={
                "propagated_items": propagated,
                "unrelated_count": len(unrelated_propagations),
                "has_directive_language": has_directive,
                "total_propagated": len(propagated),
                "user_query_excerpt": last_input.text[:200],
                "explanation": (
                    f"Model output contains {len(propagated)} specific item(s) from "
                    f"tool/RAG results that the user didn't ask for. "
                    f"{len(unrelated_propagations)} item(s) are topically unrelated "
                    f"to the user's question. "
                    f"{'Output includes directive language (recommendations/commands). ' if has_directive else ''}"
                    f"This may indicate indirect prompt injection influencing model behavior."
                ),
            },
        )

    def _extract_specifics(self, text: str) -> List[dict]:
        specifics: List[dict] = []
        for content_type, pattern in self.SPECIFICITY_EXTRACTORS.items():
            for match in pattern.finditer(text):
                value = match.group()
                if len(value) < 5:
                    continue
                if content_type == "url" and self._is_common_url(value):
                    continue
                specifics.append(
                    {"type": content_type, "value": value, "position": match.start()}
                )
        return specifics

    def _is_common_url(self, url: str) -> bool:
        try:
            domain = urlparse(url).netloc.lower()
            return any(domain.endswith(d) for d in self._COMMON_DOMAINS)
        except Exception:
            return False

    def _fuzzy_match(self, a: str, b: str) -> bool:
        return a.lower().strip().rstrip("/") == b.lower().strip().rstrip("/")

    def _is_topically_related(self, specific_value: str, input_text: str) -> bool:
        specific_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", specific_value.lower()))
        input_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", input_text.lower()))
        meaningful_overlap = (specific_words & input_words) - self._STOP_WORDS
        return len(meaningful_overlap) > 0
