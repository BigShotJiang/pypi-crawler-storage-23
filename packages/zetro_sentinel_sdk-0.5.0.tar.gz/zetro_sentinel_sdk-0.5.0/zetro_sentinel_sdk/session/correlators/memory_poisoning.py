"""Memory poisoning detector.

Detects content from untrusted sources (web pages, emails, API responses)
flowing into persistent storage (memory, notes, preferences) containing
instruction-like payloads — the core defense against memory persistence
poisoning attacks.
"""

import re
from typing import List, Set

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState, classify_tool_trust


MEMORY_INJECTION_PATTERNS = [
    # Override directives
    re.compile(
        r"(?:ignore|disregard|override)\s{1,10}(?:all\s)?(?:previous|safety|security)"
        r"\s{1,10}(?:instructions?|rules?|guidelines?)",
        re.IGNORECASE,
    ),
    # Standing behavioral instructions
    re.compile(
        r"(?:always|never|every\s{1,5}time|whenever)\s.{0,40}"
        r"(?:ignore|bypass|send|forward|reveal|disclose|include)",
        re.IGNORECASE,
    ),
    # Conditional triggers
    re.compile(
        r"(?:when(?:ever)?\s{1,5}(?:asked|prompted)|if\s{1,5}(?:the\s)?(?:user|anyone)"
        r"\s{1,5}(?:asks?|mentions?)).{0,50}(?:respond|always|include|append)",
        re.IGNORECASE,
    ),
    # Persistence commands targeting AI
    re.compile(
        r"(?:remember|save|store|persist)\s{1,5}(?:that|this|to)\s.{0,30}"
        r"(?:always|never|must|should)\s.{0,30}(?:ignore|override|bypass|send|forward)",
        re.IGNORECASE,
    ),
]


class MemoryPoisoningDetector(BaseCorrelator):
    """Detects tainted content flowing from untrusted sources to persistent storage.

    Attack chain this catches:
    1. Agent fetches external content (web page, email, API response)
    2. Content contains instruction-like payloads
    3. Agent writes that content to memory/notes/preferences
    4. Poisoned memory persists across future sessions

    Triggers on SCAN_TOOL_RESULT when the tool is a persist_sink.
    """

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_TOOL_RESULT}

    @property
    def minimum_events(self) -> int:
        return 1

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        tool_name = new_event.metadata.get("tool_name", "")
        if classify_tool_trust(tool_name) != "persist_sink":
            return CorrelationResult(detected=False)

        text = new_event.text
        if not text:
            return CorrelationResult(detected=False)

        # Check for instruction-like patterns in memory write content
        matched_instructions = []
        for pattern in MEMORY_INJECTION_PATTERNS:
            match = pattern.search(text)
            if match:
                matched_instructions.append(match.group()[:100])

        # Check for tainted fragments from untrusted sources
        tainted_fragments = []
        source_tools = []
        text_normalized = re.sub(r'\s+', ' ', text.lower())

        for fp in session.untrusted_content_fingerprints:
            for fragment in fp["fragments"]:
                fragment_normalized = re.sub(r'\s+', ' ', fragment.lower())
                # Bidirectional: fragment in sink OR sink in fragment
                if fragment_normalized in text_normalized or text_normalized in fragment_normalized:
                    tainted_fragments.append(fragment[:100])
                    if fp["tool_name"] not in source_tools:
                        source_tools.append(fp["tool_name"])
                    break  # One match per fingerprint entry is enough

        is_tainted = len(tainted_fragments) > 0
        has_instructions = len(matched_instructions) > 0

        if not is_tainted and not has_instructions:
            return CorrelationResult(detected=False)

        # Determine severity based on combination
        if is_tainted and has_instructions:
            severity = "critical"
            confidence_boost = 0.40
        elif is_tainted:
            severity = "high"
            confidence_boost = 0.25
        else:  # has_instructions only
            severity = "medium"
            confidence_boost = 0.15

        return CorrelationResult(
            detected=True,
            pattern="memory_poisoning",
            severity=severity,
            confidence_boost=confidence_boost,
            details={
                "tainted_fragments_found": tainted_fragments[:5],
                "instruction_patterns_matched": matched_instructions[:5],
                "source_tools": source_tools,
                "content_excerpt": text[:200],
                "is_tainted": is_tainted,
                "has_instruction_patterns": has_instructions,
                "explanation": (
                    f"Content being written to persistent storage ({tool_name}) "
                    f"{'contains data from untrusted source(s): ' + ', '.join(source_tools) if is_tainted else ''}"
                    f"{' and ' if is_tainted and has_instructions else ''}"
                    f"{'contains instruction-like patterns that could poison agent memory' if has_instructions else ''}. "
                    f"This may indicate a memory persistence poisoning attack."
                ),
            },
        )
