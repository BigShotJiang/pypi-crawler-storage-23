"""Correlation detectors for session-aware threat detection."""

from zetro_sentinel_sdk.session.correlators.base import CorrelationResult, BaseCorrelator
from zetro_sentinel_sdk.session.correlators.influence import InfluencePropagationDetector
from zetro_sentinel_sdk.session.correlators.escalation import EscalationTrajectoryDetector
from zetro_sentinel_sdk.session.correlators.tool_chain import ToolChainAbuseDetector
from zetro_sentinel_sdk.session.correlators.grounding import OutputGroundingDetector
from zetro_sentinel_sdk.session.correlators.memory_poisoning import MemoryPoisoningDetector
from zetro_sentinel_sdk.session.correlators.data_execution import DataDerivedExecutionDetector

__all__ = [
    "CorrelationResult",
    "BaseCorrelator",
    "InfluencePropagationDetector",
    "EscalationTrajectoryDetector",
    "ToolChainAbuseDetector",
    "OutputGroundingDetector",
    "MemoryPoisoningDetector",
    "DataDerivedExecutionDetector",
]
