"""Tool chain abuse detector.

Detects dangerous sequences of tool invocations within a session,
analogous to process chain detection in EDR systems.
"""

from typing import Dict, List, Optional, Set

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState, categorize_tool


# Dangerous category sequences
DANGEROUS_CHAINS: List[Dict] = [
    {
        "name": "data_exfiltration",
        "description": "Data read followed by network transmission",
        "sequence": [{"read"}, {"network"}],
        "severity": "critical",
        "confidence_boost": 0.35,
        "requires_flag": False,
    },
    {
        "name": "recon_to_exploit",
        "description": "Reconnaissance followed by data access and modification",
        "sequence": [{"read"}, {"read"}, {"write", "exec"}],
        "severity": "critical",
        "confidence_boost": 0.30,
        "requires_flag": False,
    },
    {
        "name": "read_then_execute",
        "description": "File/data read followed by code execution",
        "sequence": [{"read"}, {"exec"}],
        "severity": "critical",
        "confidence_boost": 0.35,
        "requires_flag": False,
    },
    {
        "name": "wide_reconnaissance",
        "description": "Three or more consecutive read operations across different scopes",
        "sequence": [{"read"}, {"read"}, {"read"}],
        "severity": "high",
        "confidence_boost": 0.20,
        "requires_flag": True,
    },
    {
        "name": "write_then_network",
        "description": "File write followed by network call (staging + exfil)",
        "sequence": [{"write"}, {"network"}],
        "severity": "high",
        "confidence_boost": 0.25,
        "requires_flag": False,
    },
]


class ToolChainAbuseDetector(BaseCorrelator):
    """Detects dangerous sequences of tool invocations.

    Individual tool calls are almost always legitimate. But certain
    sequences reveal attack intent:

    - read → network = data exfiltration
    - recon → read → write/exec = privilege escalation
    - read → read → read (with broadening scope) = reconnaissance sweep
    """

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_TOOL_RESULT}

    @property
    def minimum_events(self) -> int:
        return 2

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        category_sequence: List[str] = []
        tool_detail_sequence: List[str] = []

        for tool_name in session.tools_invoked:
            cat = categorize_tool(tool_name)
            category_sequence.append(cat)
            tool_detail_sequence.append(tool_name)

        if len(category_sequence) < 2:
            return CorrelationResult(detected=False)

        for chain_def in DANGEROUS_CHAINS:
            if chain_def["requires_flag"] and session.flagged_count == 0:
                continue

            match_indices = self._match_subsequence(
                category_sequence, chain_def["sequence"]
            )

            if match_indices is not None:
                matched_tools = [tool_detail_sequence[i] for i in match_indices]

                return CorrelationResult(
                    detected=True,
                    pattern="tool_chain_abuse",
                    severity=chain_def["severity"],
                    confidence_boost=chain_def["confidence_boost"],
                    details={
                        "chain_name": chain_def["name"],
                        "chain_description": chain_def["description"],
                        "matched_tools": matched_tools,
                        "matched_categories": [
                            category_sequence[i] for i in match_indices
                        ],
                        "full_tool_sequence": tool_detail_sequence,
                        "full_category_sequence": category_sequence,
                        "session_flagged_count": session.flagged_count,
                        "explanation": (
                            f"Detected '{chain_def['name']}' tool chain. "
                            f"Tools invoked in sequence: {' → '.join(matched_tools)}. "
                            f"Category pattern: {' → '.join(category_sequence[i] for i in match_indices)}. "
                            f"{chain_def['description']}."
                        ),
                    },
                )

        return CorrelationResult(detected=False)

    @staticmethod
    def _match_subsequence(
        sequence: List[str], pattern: List[Set[str]]
    ) -> Optional[List[int]]:
        """Find the pattern as a subsequence in the sequence.

        Pattern elements are sets — any category in the set satisfies that step.
        Returns the indices of matched elements, or None if no match.
        """
        if not pattern:
            return []

        matched_indices: List[int] = []
        pattern_idx = 0

        for seq_idx, category in enumerate(sequence):
            if category in pattern[pattern_idx]:
                matched_indices.append(seq_idx)
                pattern_idx += 1
                if pattern_idx >= len(pattern):
                    return matched_indices

        return None
