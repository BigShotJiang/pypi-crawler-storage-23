"""Output grounding verification detector.

Detects model outputs containing specific, actionable content that
isn't grounded in any visible text source (user input or tool results).
This is the text-layer defense against adversarial image attacks
and any injection where the vector is invisible to text scanning
but the effect on output is detectable.
"""

import re
from typing import Dict, List, Set
from urllib.parse import urlparse

from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState


class OutputGroundingDetector(BaseCorrelator):
    """Detects ungrounded specific content in model output.

    We're NOT looking for hallucinations in general. We're looking for
    SPECIFIC, ACTIONABLE content (URLs, stock tickers, commands, product
    recommendations) that appears ungrounded. The specificity +
    actionability combination is the security signal.
    """

    GROUNDING_CHECKS: List[Dict] = [
        {
            "type": "url",
            "pattern": re.compile(r"https?://[^\s<>\"']{5,200}"),
            "min_length": 10,
            "severity_weight": 0.8,
            "skip_common": True,
        },
        {
            "type": "stock_ticker",
            "pattern": re.compile(
                r"(?:buy|sell|invest\s+in|shares?\s+of|stock\s+in|ticker:?)\s+"
                r"(?:\$)?([A-Z]{1,5})\b"
            ),
            "min_length": 1,
            "severity_weight": 0.9,
            "skip_common": False,
        },
        {
            "type": "product_recommendation",
            "pattern": re.compile(
                r"(?:recommend|suggest|try|check out|you should (?:use|get|buy)|"
                r"i'd go with|best (?:option|choice) is)\s+"
                r"([A-Z][a-zA-Z0-9]+(?:\s+[A-Z][a-zA-Z0-9]+){0,3})",
                re.IGNORECASE,
            ),
            "min_length": 3,
            "severity_weight": 0.6,
            "skip_common": False,
        },
        {
            "type": "command",
            "pattern": re.compile(
                r"(?:run|execute|type|enter|use the command)\s+"
                r"[`\"]?(\S{3,100}(?:\s+\S{1,50}){0,5})[`\"]?"
            ),
            "min_length": 5,
            "severity_weight": 0.7,
            "skip_common": False,
        },
        {
            "type": "contact_info",
            "pattern": re.compile(
                r"(?:contact|reach|call|email|text)\s+(?:us\s+)?(?:at\s+)?"
                r"([\w.+-]+@[\w.-]+\.\w{2,10}|\+?\d[\d\s.-]{8,20})"
            ),
            "min_length": 5,
            "severity_weight": 0.7,
            "skip_common": False,
        },
    ]

    COMMON_SAFE_DOMAINS: Set[str] = {
        "google.com", "wikipedia.org", "github.com", "stackoverflow.com",
        "youtube.com", "python.org", "mozilla.org", "microsoft.com",
        "apple.com", "amazon.com", "docs.google.com", "en.wikipedia.org",
    }

    @property
    def applicable_scan_types(self) -> Set[ScanType]:
        return {ScanType.SCAN_OUTPUT}

    @property
    def minimum_events(self) -> int:
        return 2

    def check(self, session: SessionState, new_event: ScanEvent) -> CorrelationResult:
        if not self.should_run(session, new_event):
            return CorrelationResult(detected=False)

        output_text = new_event.text
        grounding_text = session.get_grounding_text()
        grounding_lower = grounding_text.lower()

        grounding_specifics: Set[str] = {
            s["value"].lower() for s in session.tool_result_specifics
        }

        ungrounded_items: List[Dict] = []

        for check in self.GROUNDING_CHECKS:
            for match in check["pattern"].finditer(output_text):
                value = match.group(1) if match.lastindex else match.group()

                if len(value) < check["min_length"]:
                    continue

                if check["skip_common"] and check["type"] == "url":
                    try:
                        domain = urlparse(value).netloc.lower()
                        if any(domain.endswith(d) for d in self.COMMON_SAFE_DOMAINS):
                            continue
                    except Exception:
                        pass

                value_lower = value.lower()
                is_grounded = (
                    value_lower in grounding_lower
                    or value_lower in grounding_specifics
                    or self._partial_grounding(value_lower, grounding_lower)
                )

                if not is_grounded:
                    ungrounded_items.append(
                        {
                            "type": check["type"],
                            "value": value[:100],
                            "severity_weight": check["severity_weight"],
                            "position_in_output": match.start(),
                        }
                    )

        if not ungrounded_items:
            return CorrelationResult(detected=False)

        max_weight = max(item["severity_weight"] for item in ungrounded_items)
        total_weight = sum(item["severity_weight"] for item in ungrounded_items)

        if max_weight >= 0.8 or total_weight >= 1.5:
            severity = "critical"
            confidence_boost = 0.30
        elif max_weight >= 0.6 or total_weight >= 1.0:
            severity = "high"
            confidence_boost = 0.20
        else:
            severity = "medium"
            confidence_boost = 0.10

        return CorrelationResult(
            detected=True,
            pattern="ungrounded_output",
            severity=severity,
            confidence_boost=confidence_boost,
            details={
                "ungrounded_items": ungrounded_items,
                "total_severity_weight": round(total_weight, 2),
                "grounding_corpus_length": len(grounding_text),
                "session_tool_results": session.tool_result_count,
                "explanation": (
                    f"Model output contains {len(ungrounded_items)} specific item(s) "
                    f"not found in user input or tool results: "
                    + ", ".join(
                        f"{i['type']}: {i['value'][:40]}"
                        for i in ungrounded_items[:3]
                    )
                    + ". "
                    f"Grounding corpus contained {len(grounding_text)} characters from "
                    f"{session.tool_result_count} tool result(s) and {session.input_count} input(s). "
                    f"Ungrounded specific content may indicate adversarial influence "
                    f"on model behavior via invisible injection vectors."
                ),
            },
        )

    @staticmethod
    def _partial_grounding(value: str, corpus: str) -> bool:
        """Check partial grounding via domain or word overlap."""
        if value.startswith("http"):
            try:
                domain = urlparse(value).netloc.lower()
                return domain in corpus
            except Exception:
                return False

        words = re.findall(r"\b\w{3,}\b", value)
        if not words:
            return False
        found = sum(1 for w in words if w in corpus)
        return (found / len(words)) >= 0.6
