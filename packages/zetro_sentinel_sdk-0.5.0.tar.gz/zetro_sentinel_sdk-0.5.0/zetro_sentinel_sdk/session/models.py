"""Session state models for cross-scan correlation.

These structures live in the SDK process. They're lightweight, ephemeral,
and never persisted to disk unless the customer explicitly opts into
session export.
"""

import hashlib
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Set


class ScanType(str, Enum):
    """Type of scan operation within a session."""

    SCAN_INPUT = "scan_input"
    SCAN_TOOL_RESULT = "scan_tool_result"
    SCAN_OUTPUT = "scan_output"


@dataclass
class ScanEvent:
    """A single scan within a session. Immutable after creation.

    This is the fundamental unit of session state.
    """

    scan_type: ScanType
    text: str
    timestamp: float
    scan_result_summary: dict
    metadata: dict = field(default_factory=dict)

    # Derived at creation time for fast lookup
    text_hash: str = ""
    text_length: int = 0
    extracted_specifics: list = field(default_factory=list)

    def __post_init__(self) -> None:
        self.text_hash = hashlib.sha256(self.text.encode()).hexdigest()[:16]
        self.text_length = len(self.text)


# Tool categorization sets
_READ_TOOLS = {
    "read_file", "query_db", "search", "list_files", "get_user",
    "get_document", "fetch_url", "read_config", "describe_schema",
    "get_permissions", "list_users", "get_user_details", "get_secrets",
    "get_context", "get_system_info", "lookup", "retrieve", "find",
}
_WRITE_TOOLS = {
    "write_file", "update_user", "delete_record", "create_document",
    "update_config", "set_permission", "insert_record", "modify",
    "create", "update", "delete", "put",
}
_NETWORK_TOOLS = {
    "send_email", "http_request", "webhook", "post_message",
    "send_slack", "send_notification", "api_call", "fetch",
    "upload", "publish",
}
_EXEC_TOOLS = {
    "execute_command", "run_script", "shell", "eval", "exec",
    "run_code", "subprocess", "terminal",
}


def categorize_tool(tool_name: str) -> str:
    """Categorize a tool name into a broad category for chain detection."""
    name_lower = tool_name.lower()
    for keyword in _EXEC_TOOLS:
        if keyword in name_lower:
            return "exec"
    for keyword in _NETWORK_TOOLS:
        if keyword in name_lower:
            return "network"
    for keyword in _WRITE_TOOLS:
        if keyword in name_lower:
            return "write"
    for keyword in _READ_TOOLS:
        if keyword in name_lower:
            return "read"
    return "unknown"


# Trust-aware tool classification for taint tracking
_UNTRUSTED_SOURCE_TOOLS = {
    "web_fetch", "fetch_url", "http_request", "browse", "read_email",
    "get_email", "api_call", "mcp_", "slack_read", "teams_read",
    "get_message", "receive", "download", "scrape", "crawl",
    "calendar_read", "get_calendar",
}
_PERSIST_SINK_TOOLS = {
    "memory_write", "memory_save", "save_note", "save_memory",
    "add_memory", "update_preference", "create_note", "update_note",
    "knowledge_base", "remember", "persist", "store_",
}
_EXEC_SINK_TOOLS = {
    "execute", "exec", "eval", "run_code", "run_script", "shell",
    "subprocess", "terminal", "command", "code_interpreter", "sandbox",
}


def classify_tool_trust(tool_name: str) -> str:
    """Returns 'untrusted_source', 'persist_sink', 'exec_sink', or 'neutral'.

    Priority: exec_sink > persist_sink > untrusted_source > neutral.
    Uses substring matching (same approach as categorize_tool).
    """
    name_lower = tool_name.lower()
    for keyword in _EXEC_SINK_TOOLS:
        if keyword in name_lower:
            return "exec_sink"
    for keyword in _PERSIST_SINK_TOOLS:
        if keyword in name_lower:
            return "persist_sink"
    for keyword in _UNTRUSTED_SOURCE_TOOLS:
        if keyword in name_lower:
            return "untrusted_source"
    return "neutral"


# Sentence boundary: period/excl/question followed by space+uppercase, or newline.
# Avoids splitting on dots inside URLs, emails, filenames.
_SENTENCE_BOUNDARY_RE = re.compile(r'(?<=[.!?])\s+(?=[A-Z])|[\n]+')


def _extract_content_fragments(text: str) -> List[str]:
    """Extract meaningful text fragments from untrusted tool result text.

    These fragments are stored and later checked against content flowing
    to dangerous sinks (persist/exec) for taint tracking.

    Uses sentence-boundary splitting that preserves dots inside URLs/emails.
    Also generates overlapping n-gram windows for better substring matching.
    """
    fragments: List[str] = []
    # Split into sentences at real boundaries
    parts = _SENTENCE_BOUNDARY_RE.split(text)
    for part in parts:
        part = part.strip()
        if len(part) < 15 or len(part) > 500:
            continue
        fragments.append(part)
        if len(fragments) >= 30:
            break

    # Additionally, generate word-level sliding windows for matching shorter
    # excerpts. This catches cases where the sink text is a partial quote.
    words = text.split()
    for window_size in (5, 8):
        for i in range(0, max(1, len(words) - window_size + 1), 3):
            window = " ".join(words[i:i + window_size])
            if len(window) >= 15:
                fragments.append(window)
                if len(fragments) >= 50:
                    return fragments

    return fragments


@dataclass
class SessionState:
    """Tracks all scans within a single conversation or request chain.

    Memory budget: ~1KB per scan event (text stored as hash + extracted
    specifics, not full text, for sessions longer than 50 turns). Full text
    retained for the most recent 20 events for grounding checks.

    Lifecycle:
    - Created on first scan with a given session_id
    - Updated on each subsequent scan
    - Expired after TTL (default 1 hour of inactivity)
    - Evicted under memory pressure (LRU)
    """

    session_id: str
    created_at: float = field(default_factory=time.time)
    last_activity_at: float = field(default_factory=time.time)
    ttl_seconds: int = 3600

    # Event log
    events: List[ScanEvent] = field(default_factory=list)

    # Running counters
    total_scans: int = 0
    input_count: int = 0
    tool_result_count: int = 0
    output_count: int = 0
    flagged_count: int = 0
    blocked_count: int = 0

    # Tool tracking
    tools_invoked: List[str] = field(default_factory=list)
    tool_categories_seen: Set[str] = field(default_factory=set)

    # Escalation state
    turn_suspicion_scores: List[float] = field(default_factory=list)

    # Influence tracking
    tool_result_specifics: List[dict] = field(default_factory=list)

    # Grounding corpus
    grounding_text_hashes: Set[str] = field(default_factory=set)

    # Taint tracking — content fingerprints from untrusted tool results
    untrusted_content_fingerprints: List[dict] = field(default_factory=list)
    # Each entry: {"tool_name": str, "fragments": List[str], "timestamp": float}

    # Reconnaissance frequency tracking
    capability_query_timestamps: List[float] = field(default_factory=list)

    def add_event(self, event: ScanEvent) -> None:
        """Add a scan event to the session."""
        self.events.append(event)
        self.last_activity_at = time.time()
        self.total_scans += 1

        if event.scan_type == ScanType.SCAN_INPUT:
            self.input_count += 1
        elif event.scan_type == ScanType.SCAN_TOOL_RESULT:
            self.tool_result_count += 1
            tool_name = event.metadata.get("tool_name")
            if tool_name:
                self.tools_invoked.append(tool_name)
                self.tool_categories_seen.add(categorize_tool(tool_name))
                # Populate taint tracking for untrusted sources
                if classify_tool_trust(tool_name) == "untrusted_source" and event.text:
                    fragments = _extract_content_fragments(event.text)
                    if fragments:
                        self.untrusted_content_fingerprints.append({
                            "tool_name": tool_name,
                            "fragments": fragments,
                            "timestamp": event.timestamp,
                        })
            if event.extracted_specifics:
                self.tool_result_specifics.extend(event.extracted_specifics)
        elif event.scan_type == ScanType.SCAN_OUTPUT:
            self.output_count += 1

        # Track flagged/blocked
        if event.scan_result_summary.get("flagged"):
            self.flagged_count += 1
        if event.scan_result_summary.get("blocked"):
            self.blocked_count += 1

        # Update grounding corpus
        if event.scan_type in (ScanType.SCAN_INPUT, ScanType.SCAN_TOOL_RESULT):
            self.grounding_text_hashes.add(event.text_hash)

        self._compact_if_needed()

    def get_recent_events(
        self, n: int = 20, scan_type: Optional[ScanType] = None
    ) -> List[ScanEvent]:
        """Get the N most recent events, optionally filtered by type."""
        if scan_type:
            filtered = [e for e in self.events if e.scan_type == scan_type]
            return filtered[-n:]
        return self.events[-n:]

    def get_grounding_text(self) -> str:
        """Get concatenated text from recent input and tool_result events."""
        recent = [
            e
            for e in self.events[-20:]
            if e.scan_type in (ScanType.SCAN_INPUT, ScanType.SCAN_TOOL_RESULT)
        ]
        return " ".join(e.text for e in recent)

    def _compact_if_needed(self) -> None:
        """Compact older events to save memory when session exceeds 50 events."""
        if len(self.events) > 50:
            cutoff = len(self.events) - 20
            for i in range(cutoff):
                event = self.events[i]
                object.__setattr__(event, "text", "")

    @property
    def is_expired(self) -> bool:
        """Session expires after TTL of inactivity."""
        return (time.time() - self.last_activity_at) > self.ttl_seconds

    @property
    def duration_seconds(self) -> float:
        """Duration from creation to last activity."""
        return self.last_activity_at - self.created_at
