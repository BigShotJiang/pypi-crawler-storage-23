"""Session manager with LRU eviction and TTL expiry.

Thread-safe in-memory session store for the SDK. For multi-process
deployments, swap for a Redis backend (out of scope for initial release).
"""

import threading
from collections import OrderedDict
from typing import Dict

from zetro_sentinel_sdk.session.models import SessionState


class SessionManager:
    """Manages active sessions with LRU eviction and TTL expiry.

    Thread-safe. Designed for in-process use within the SDK.

    Memory budget: with ~1KB per event and 50 events max per session,
    each session costs ~50KB. 10,000 concurrent sessions ≈ 500MB.
    Adjust max_sessions based on available memory.
    """

    DEFAULT_MAX_SESSIONS = 10_000
    DEFAULT_TTL_SECONDS = 3600
    CLEANUP_INTERVAL = 300

    def __init__(
        self,
        max_sessions: int = DEFAULT_MAX_SESSIONS,
        ttl_seconds: int = DEFAULT_TTL_SECONDS,
    ) -> None:
        self.max_sessions = max_sessions
        self.ttl_seconds = ttl_seconds
        self._sessions: OrderedDict[str, SessionState] = OrderedDict()
        self._lock = threading.Lock()
        self._cleanup_timer: threading.Timer = None
        self._start_cleanup_timer()

    def get_or_create(self, session_id: str) -> SessionState:
        """Get existing session or create new one. Thread-safe."""
        with self._lock:
            if session_id in self._sessions:
                session = self._sessions[session_id]
                self._sessions.move_to_end(session_id)
                if session.is_expired:
                    session = SessionState(
                        session_id=session_id, ttl_seconds=self.ttl_seconds
                    )
                    self._sessions[session_id] = session
                return session
            else:
                if len(self._sessions) >= self.max_sessions:
                    self._sessions.popitem(last=False)
                session = SessionState(
                    session_id=session_id, ttl_seconds=self.ttl_seconds
                )
                self._sessions[session_id] = session
                return session

    def save(self, session: SessionState) -> None:
        """Persist session state after modification.

        No-op for memory backend (mutations are in-place).
        """
        pass

    def get_stats(self) -> Dict:
        """Return session manager stats for monitoring."""
        with self._lock:
            return {
                "active_sessions": len(self._sessions),
                "max_sessions": self.max_sessions,
                "memory_estimate_mb": round(len(self._sessions) * 50 / 1024, 2),
            }

    def _cleanup_expired(self) -> None:
        """Remove expired sessions. Runs periodically."""
        with self._lock:
            expired = [
                sid for sid, s in self._sessions.items() if s.is_expired
            ]
            for sid in expired:
                del self._sessions[sid]

    def _start_cleanup_timer(self) -> None:
        self._cleanup_timer = threading.Timer(
            self.CLEANUP_INTERVAL, self._cleanup_and_restart
        )
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    def _cleanup_and_restart(self) -> None:
        self._cleanup_expired()
        self._start_cleanup_timer()

    def close(self) -> None:
        """Cancel the cleanup timer and release resources."""
        if self._cleanup_timer is not None:
            self._cleanup_timer.cancel()
            self._cleanup_timer = None

    def __del__(self) -> None:
        self.close()
