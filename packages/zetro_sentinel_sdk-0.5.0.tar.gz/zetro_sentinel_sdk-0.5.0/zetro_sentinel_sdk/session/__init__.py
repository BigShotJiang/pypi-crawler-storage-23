"""Session correlation layer for cross-scan attack detection.

This module provides session-aware correlation that detects multi-turn
attack patterns invisible to stateless per-request scanning.

Usage:
    from zetro_sentinel_sdk import Sentinel

    sentinel = Sentinel(api_key="your-api-key")

    # Pass session_id to enable correlation
    result = sentinel.scan_input("hello", agent_id="my-agent", session_id="conv-123")
    result = sentinel.scan_tool_result(
        "tool output", tool_name="search", agent_id="my-agent", session_id="conv-123"
    )
    result = sentinel.scan_output("response", agent_id="my-agent", session_id="conv-123")
"""

from zetro_sentinel_sdk.session.models import (
    ScanType,
    ScanEvent,
    SessionState,
    classify_tool_trust,
)
from zetro_sentinel_sdk.session.manager import SessionManager
from zetro_sentinel_sdk.session.correlators.base import CorrelationResult, BaseCorrelator
from zetro_sentinel_sdk.session.correlators.influence import InfluencePropagationDetector
from zetro_sentinel_sdk.session.correlators.escalation import EscalationTrajectoryDetector
from zetro_sentinel_sdk.session.correlators.tool_chain import ToolChainAbuseDetector
from zetro_sentinel_sdk.session.correlators.grounding import OutputGroundingDetector
from zetro_sentinel_sdk.session.correlators.memory_poisoning import MemoryPoisoningDetector
from zetro_sentinel_sdk.session.correlators.data_execution import DataDerivedExecutionDetector

__all__ = [
    "ScanType",
    "ScanEvent",
    "SessionState",
    "SessionManager",
    "CorrelationResult",
    "BaseCorrelator",
    "classify_tool_trust",
    "InfluencePropagationDetector",
    "EscalationTrajectoryDetector",
    "ToolChainAbuseDetector",
    "OutputGroundingDetector",
    "MemoryPoisoningDetector",
    "DataDerivedExecutionDetector",
]
