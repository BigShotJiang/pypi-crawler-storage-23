"""Behavioral Detection Module for AI Sentinel SDK.

This module provides runtime behavioral detection capabilities:
- API key registry for tracking known legitimate keys
- Behavioral detector for identifying potential exfiltration
- Exfiltration endpoint detection
"""

import hashlib
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger("zetro_sentinel_sdk.behavioral")


class AlertSeverity(str, Enum):
    """Severity levels for behavioral alerts."""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class AlertType(str, Enum):
    """Types of behavioral alerts."""

    UNKNOWN_API_KEY = "unknown_api_key"
    EXFIL_ENDPOINT = "exfil_endpoint"
    SUSPICIOUS_HEADER = "suspicious_header"
    RATE_ANOMALY = "rate_anomaly"
    CUSTOM_HOOK = "custom_hook"


@dataclass
class Alert:
    """A behavioral detection alert."""

    severity: AlertSeverity
    alert_type: AlertType
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        """Convert alert to dictionary."""
        return {
            "severity": self.severity.value,
            "type": self.alert_type.value,
            "message": self.message,
            "details": self.details,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class BehavioralResult:
    """Result from behavioral detection check."""

    allow: bool
    alerts: List[Alert] = field(default_factory=list)
    blocked_by: Optional[str] = None
    check_duration_ms: Optional[float] = None

    @property
    def has_critical_alerts(self) -> bool:
        """Check if result has critical alerts."""
        return any(a.severity == AlertSeverity.CRITICAL for a in self.alerts)

    @property
    def has_high_alerts(self) -> bool:
        """Check if result has high severity alerts."""
        return any(a.severity in (AlertSeverity.CRITICAL, AlertSeverity.HIGH) for a in self.alerts)

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            "allow": self.allow,
            "alerts": [a.to_dict() for a in self.alerts],
            "blocked_by": self.blocked_by,
            "check_duration_ms": self.check_duration_ms,
        }


class APIKeyRegistry:
    """Track known legitimate API keys vs unknown (potential exfiltration).

    This registry stores hashed API keys that are known to be legitimate.
    When a request uses an unregistered key, it may indicate an exfiltration
    attempt where the attacker injects their own API key.

    Example attack scenario:
    1. Attacker embeds malicious instructions in external data
    2. Instructions tell the LLM to use attacker's API key
    3. LLM makes request with attacker's key to exfiltrate data
    4. SDK detects unknown key and blocks the request

    Usage:
        registry = APIKeyRegistry()
        registry.register_key("sk-ant-...")  # Register legitimate keys
        registry.register_key("sk-openai-...")

        # Later, during request
        if not registry.is_known_key(request_api_key):
            # Alert: potential exfiltration!
    """

    def __init__(self):
        self._known_key_hashes: Set[str] = set()
        self._key_labels: Dict[str, str] = {}  # hash -> label

    def register_key(self, api_key: str, label: Optional[str] = None) -> None:
        """Register a legitimate API key (stores hash only).

        Args:
            api_key: The API key to register
            label: Optional human-readable label (e.g., "production", "dev")
        """
        key_hash = self._hash_key(api_key)
        self._known_key_hashes.add(key_hash)
        if label:
            self._key_labels[key_hash] = label
        logger.debug(f"Registered API key with label: {label or 'unlabeled'}")

    def unregister_key(self, api_key: str) -> bool:
        """Remove an API key from the registry.

        Args:
            api_key: The API key to remove

        Returns:
            True if key was found and removed, False otherwise
        """
        key_hash = self._hash_key(api_key)
        if key_hash in self._known_key_hashes:
            self._known_key_hashes.discard(key_hash)
            self._key_labels.pop(key_hash, None)
            return True
        return False

    def is_known_key(self, api_key: str) -> bool:
        """Check if an API key is registered as legitimate.

        Args:
            api_key: The API key to check

        Returns:
            True if key is registered, False if unknown
        """
        return self._hash_key(api_key) in self._known_key_hashes

    def get_key_label(self, api_key: str) -> Optional[str]:
        """Get the label for a registered key.

        Args:
            api_key: The API key to look up

        Returns:
            The label if registered and labeled, None otherwise
        """
        key_hash = self._hash_key(api_key)
        return self._key_labels.get(key_hash)

    @property
    def registered_count(self) -> int:
        """Number of registered keys."""
        return len(self._known_key_hashes)

    def clear(self) -> None:
        """Clear all registered keys."""
        self._known_key_hashes.clear()
        self._key_labels.clear()

    @staticmethod
    def _hash_key(key: str) -> str:
        """Hash an API key for secure storage.

        Uses SHA256 with a prefix to prevent rainbow table attacks.
        """
        # Add prefix to prevent simple rainbow table attacks
        prefixed = f"sentinel:apikey:{key}"
        return hashlib.sha256(prefixed.encode()).hexdigest()


class BehavioralDetector:
    """Runtime behavioral detection for identifying potential attacks.

    This detector runs checks on outgoing requests to identify:
    - Unknown API keys (potential key injection/exfiltration)
    - Known exfiltration endpoints (webhook.site, pipedream, etc.)
    - Suspicious request patterns

    Usage:
        registry = APIKeyRegistry()
        registry.register_key(os.environ["ANTHROPIC_API_KEY"])

        detector = BehavioralDetector(registry)

        # Check a request
        result = detector.check_request(httpx_request)
        if not result.allow:
            raise SecurityAlert(result.alerts)
    """

    # Common exfiltration endpoints - regex patterns
    DEFAULT_EXFIL_PATTERNS = [
        r"api\.anthropic\.com/v\d+/files",  # Anthropic Files API
        r"api\.openai\.com/v\d+/files",  # OpenAI Files API
        r"webhook\.site",  # Common testing/exfil endpoint
        r"pipedream\.net",  # Webhook relay service
        r"requestbin\.com",  # Request capture service
        r"hookbin\.com",  # Webhook testing
        r"beeceptor\.com",  # API mocking/capture
        r"ngrok\.io",  # Tunnel service
        r"burpcollaborator\.net",  # Burp Suite collaborator
        r"oastify\.com",  # Out-of-band testing
        r"interact\.sh",  # Interactsh OOB server
        r"canarytokens\.com",  # Canary tokens
    ]

    # Headers that might contain API keys
    API_KEY_HEADERS = [
        "x-api-key",
        "authorization",
        "api-key",
        "x-auth-token",
        "x-access-token",
    ]

    def __init__(
        self,
        key_registry: Optional[APIKeyRegistry] = None,
        block_unknown_keys: bool = True,
        block_exfil_endpoints: bool = True,
        custom_exfil_patterns: Optional[List[str]] = None,
        endpoint_allowlist: Optional[List[str]] = None,
    ):
        """Initialize behavioral detector.

        Args:
            key_registry: Registry of known legitimate API keys
            block_unknown_keys: Whether to block requests with unknown keys
            block_exfil_endpoints: Whether to block known exfil endpoints
            custom_exfil_patterns: Additional patterns to flag
            endpoint_allowlist: Endpoints to always allow (regex patterns)
        """
        self._key_registry = key_registry or APIKeyRegistry()
        self._block_unknown_keys = block_unknown_keys
        self._block_exfil_endpoints = block_exfil_endpoints

        # Compile exfiltration patterns
        all_patterns = self.DEFAULT_EXFIL_PATTERNS + (custom_exfil_patterns or [])
        self._exfil_patterns = [re.compile(p, re.IGNORECASE) for p in all_patterns]

        # Compile allowlist patterns
        self._allowlist_patterns = []
        if endpoint_allowlist:
            self._allowlist_patterns = [re.compile(p, re.IGNORECASE) for p in endpoint_allowlist]

    @property
    def key_registry(self) -> APIKeyRegistry:
        """Get the API key registry."""
        return self._key_registry

    def add_exfil_pattern(self, pattern: str) -> None:
        """Add a custom exfiltration pattern.

        Args:
            pattern: Regex pattern to match against URLs
        """
        self._exfil_patterns.append(re.compile(pattern, re.IGNORECASE))

    def add_allowlist_pattern(self, pattern: str) -> None:
        """Add an endpoint to the allowlist.

        Args:
            pattern: Regex pattern for allowed endpoints
        """
        self._allowlist_patterns.append(re.compile(pattern, re.IGNORECASE))

    def check_request(self, request: Any) -> BehavioralResult:
        """Check a request for behavioral anomalies.

        Args:
            request: An httpx.Request or similar request object

        Returns:
            BehavioralResult with allow status and any alerts
        """
        import time

        start_time = time.time()
        alerts: List[Alert] = []

        try:
            url = str(request.url) if hasattr(request, "url") else str(request)
            headers = dict(request.headers) if hasattr(request, "headers") else {}

            # Check if endpoint is allowlisted
            if self._is_allowlisted(url):
                return BehavioralResult(
                    allow=True,
                    alerts=[],
                    check_duration_ms=(time.time() - start_time) * 1000,
                )

            # Check for unknown API key
            api_key = self._extract_api_key(headers)
            if api_key:
                key_alert = self._check_api_key(api_key)
                if key_alert:
                    alerts.append(key_alert)

            # Check for exfiltration endpoints
            exfil_alert = self._check_exfil_endpoint(url)
            if exfil_alert:
                alerts.append(exfil_alert)

            # Determine if we should block
            blocked_by = None
            allow = True

            if self._block_unknown_keys:
                critical_key_alerts = [
                    a for a in alerts
                    if a.alert_type == AlertType.UNKNOWN_API_KEY and a.severity == AlertSeverity.CRITICAL
                ]
                if critical_key_alerts:
                    allow = False
                    blocked_by = "unknown_api_key"

            if self._block_exfil_endpoints and allow:
                exfil_alerts = [a for a in alerts if a.alert_type == AlertType.EXFIL_ENDPOINT]
                if exfil_alerts:
                    allow = False
                    blocked_by = "exfil_endpoint"

            return BehavioralResult(
                allow=allow,
                alerts=alerts,
                blocked_by=blocked_by,
                check_duration_ms=(time.time() - start_time) * 1000,
            )

        except Exception as e:
            logger.error(f"Error in behavioral check: {e}")
            # Fail open on error - don't block due to internal issues
            return BehavioralResult(
                allow=True,
                alerts=[Alert(
                    severity=AlertSeverity.INFO,
                    alert_type=AlertType.CUSTOM_HOOK,
                    message=f"Behavioral check error: {e}",
                )],
                check_duration_ms=(time.time() - start_time) * 1000,
            )

    def _is_allowlisted(self, url: str) -> bool:
        """Check if URL matches allowlist."""
        for pattern in self._allowlist_patterns:
            if pattern.search(url):
                return True
        return False

    def _extract_api_key(self, headers: Dict[str, str]) -> Optional[str]:
        """Extract API key from request headers."""
        headers_lower = {k.lower(): v for k, v in headers.items()}

        for header_name in self.API_KEY_HEADERS:
            value = headers_lower.get(header_name)
            if value:
                # Handle "Bearer <token>" format
                if value.lower().startswith("bearer "):
                    return value[7:].strip()
                return value.strip()

        return None

    def _check_api_key(self, api_key: str) -> Optional[Alert]:
        """Check if API key is registered."""
        if not api_key:
            return None

        if not self._key_registry.is_known_key(api_key):
            # Mask the key for logging
            masked_key = f"{api_key[:8]}...{api_key[-4:]}" if len(api_key) > 16 else "***"
            return Alert(
                severity=AlertSeverity.CRITICAL,
                alert_type=AlertType.UNKNOWN_API_KEY,
                message="Request using unregistered API key - possible exfiltration",
                details={
                    "masked_key": masked_key,
                    "key_length": len(api_key),
                },
            )

        return None

    def _check_exfil_endpoint(self, url: str) -> Optional[Alert]:
        """Check if URL matches known exfiltration endpoints."""
        for pattern in self._exfil_patterns:
            if pattern.search(url):
                return Alert(
                    severity=AlertSeverity.HIGH,
                    alert_type=AlertType.EXFIL_ENDPOINT,
                    message=f"Request to potential exfiltration endpoint",
                    details={
                        "url": url,
                        "matched_pattern": pattern.pattern,
                    },
                )

        return None


class SecurityAlert(Exception):
    """Exception raised when behavioral detection blocks a request."""

    def __init__(self, alerts: List[Alert], message: Optional[str] = None):
        self.alerts = alerts
        self.message = message or self._build_message()
        super().__init__(self.message)

    def _build_message(self) -> str:
        """Build error message from alerts."""
        if not self.alerts:
            return "Security check failed"

        critical = [a for a in self.alerts if a.severity == AlertSeverity.CRITICAL]
        if critical:
            return f"BLOCKED: {critical[0].message}"

        return f"Security alert: {self.alerts[0].message}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "message": self.message,
            "alerts": [a.to_dict() for a in self.alerts],
        }


@dataclass
class OutputInvariantViolation:
    """A violation of an output invariant pattern."""

    invariant_id: str
    pattern: str
    action: str = "redact"
    description: Optional[str] = None
    matched_text: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "invariant_id": self.invariant_id,
            "pattern": self.pattern,
            "action": self.action,
            "description": self.description,
        }


@dataclass
class OutputInvariantResult:
    """Result from output invariant checking."""

    has_violations: bool
    violations: List[OutputInvariantViolation] = field(default_factory=list)
    redacted_text: Optional[str] = None
    original_text: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "has_violations": self.has_violations,
            "violations": [v.to_dict() for v in self.violations],
            "redacted_text": self.redacted_text,
        }


class OutputInvariantChecker:
    """Check output text against invariant patterns that must never appear.

    This provides defense-in-depth by detecting credential patterns and other
    sensitive data in LLM outputs, regardless of whether the API detected them.

    Output invariants are patterns that should NEVER appear in output:
    - API keys for various services
    - Private keys and certificates
    - Other sensitive credential patterns

    Usage:
        checker = OutputInvariantChecker()

        # Check output before sending to user
        result = checker.check("Here is the key: sk-ant-api03-...")
        if result.has_violations:
            # Option 1: Use redacted text
            safe_output = result.redacted_text

            # Option 2: Block entirely
            raise SecurityError("Output contains credentials")

        # Register additional patterns from rules
        checker.register_patterns([
            {"id": "custom_secret", "pattern": r"SECRET_[A-Z0-9]+", "action": "redact"}
        ])
    """

    # Default patterns for common credential types
    DEFAULT_PATTERNS: List[Dict[str, Any]] = [
        {
            "id": "anthropic_api_key",
            "pattern": r"sk-ant-[a-zA-Z0-9\-_]{20,}",
            "action": "redact",
            "description": "Anthropic API key",
        },
        {
            "id": "openai_api_key",
            "pattern": r"sk-[a-zA-Z0-9]{20,}",
            "action": "redact",
            "description": "OpenAI API key",
        },
        {
            "id": "github_pat",
            "pattern": r"ghp_[a-zA-Z0-9]{30,}",
            "action": "redact",
            "description": "GitHub personal access token",
        },
        {
            "id": "github_oauth",
            "pattern": r"gho_[a-zA-Z0-9]{30,}",
            "action": "redact",
            "description": "GitHub OAuth token",
        },
        {
            "id": "github_app",
            "pattern": r"ghs_[a-zA-Z0-9]{30,}",
            "action": "redact",
            "description": "GitHub App token",
        },
        {
            "id": "github_refresh",
            "pattern": r"ghr_[a-zA-Z0-9]{30,}",
            "action": "redact",
            "description": "GitHub refresh token",
        },
        {
            "id": "aws_access_key",
            "pattern": r"AKIA[A-Z0-9]{16}",
            "action": "redact",
            "description": "AWS access key ID",
        },
        {
            "id": "aws_secret_key",
            "pattern": r"(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])",
            "action": "alert",  # Too many false positives for auto-redact
            "description": "Possible AWS secret access key",
        },
        {
            "id": "private_key_header",
            "pattern": r"-----BEGIN [A-Z ]+ PRIVATE KEY-----",
            "action": "redact",
            "description": "Private key header",
        },
        {
            "id": "stripe_secret_key",
            "pattern": r"sk_live_[a-zA-Z0-9]{20,}",
            "action": "redact",
            "description": "Stripe secret key",
        },
        {
            "id": "stripe_test_key",
            "pattern": r"sk_test_[a-zA-Z0-9]{20,}",
            "action": "redact",
            "description": "Stripe test secret key",
        },
        {
            "id": "slack_token",
            "pattern": r"xox[baprs]-[a-zA-Z0-9-]+",
            "action": "redact",
            "description": "Slack token",
        },
        {
            "id": "google_api_key",
            "pattern": r"AIza[a-zA-Z0-9_-]{35}",
            "action": "redact",
            "description": "Google API key",
        },
        {
            "id": "twilio_api_key",
            "pattern": r"SK[a-f0-9]{32}",
            "action": "redact",
            "description": "Twilio API key",
        },
        {
            "id": "sendgrid_api_key",
            "pattern": r"SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}",
            "action": "redact",
            "description": "SendGrid API key",
        },
    ]

    def __init__(
        self,
        custom_patterns: Optional[List[Dict[str, Any]]] = None,
        include_defaults: bool = True,
        redaction_placeholder: str = "[REDACTED]",
    ):
        """Initialize the output invariant checker.

        Args:
            custom_patterns: Additional patterns to check
            include_defaults: Whether to include default credential patterns
            redaction_placeholder: Text to replace matched patterns with
        """
        self._patterns: List[Dict[str, Any]] = []
        self._compiled_patterns: List[tuple] = []  # (pattern_dict, compiled_regex)
        self._redaction_placeholder = redaction_placeholder

        if include_defaults:
            self._patterns.extend(self.DEFAULT_PATTERNS)

        if custom_patterns:
            self._patterns.extend(custom_patterns)

        self._compile_patterns()

    def _compile_patterns(self) -> None:
        """Compile all regex patterns for performance."""
        self._compiled_patterns = []
        for p in self._patterns:
            try:
                compiled = re.compile(p["pattern"], re.IGNORECASE)
                self._compiled_patterns.append((p, compiled))
            except re.error as e:
                logger.warning(f"Invalid pattern {p.get('id', 'unknown')}: {e}")

    def register_patterns(self, patterns: List[Dict[str, Any]]) -> None:
        """Register additional patterns to check.

        Args:
            patterns: List of pattern dicts with id, pattern, action, description
        """
        self._patterns.extend(patterns)
        self._compile_patterns()

    def clear_patterns(self, keep_defaults: bool = True) -> None:
        """Clear registered patterns.

        Args:
            keep_defaults: Whether to keep the default credential patterns
        """
        if keep_defaults:
            self._patterns = list(self.DEFAULT_PATTERNS)
        else:
            self._patterns = []
        self._compile_patterns()

    def check(self, text: str, redact: bool = True) -> OutputInvariantResult:
        """Check text against all invariant patterns.

        Args:
            text: The text to check
            redact: Whether to produce redacted text

        Returns:
            OutputInvariantResult with violations and optionally redacted text
        """
        violations: List[OutputInvariantViolation] = []
        redacted_text = text if redact else None

        for pattern_dict, compiled in self._compiled_patterns:
            matches = list(compiled.finditer(text))
            if matches:
                for match in matches:
                    violations.append(OutputInvariantViolation(
                        invariant_id=pattern_dict.get("id", "unknown"),
                        pattern=pattern_dict.get("pattern", ""),
                        action=pattern_dict.get("action", "redact"),
                        description=pattern_dict.get("description"),
                        matched_text=match.group(0)[:20] + "..." if len(match.group(0)) > 20 else match.group(0),
                    ))

                # Apply redaction if action is "redact"
                if redact and pattern_dict.get("action") == "redact":
                    redacted_text = compiled.sub(self._redaction_placeholder, redacted_text)

        return OutputInvariantResult(
            has_violations=len(violations) > 0,
            violations=violations,
            redacted_text=redacted_text if redact else None,
            original_text=text,
        )

    def redact(self, text: str) -> str:
        """Convenience method to just get redacted text.

        Args:
            text: The text to redact

        Returns:
            Text with all matching patterns replaced
        """
        result = self.check(text, redact=True)
        return result.redacted_text or text

    @property
    def pattern_count(self) -> int:
        """Get the number of registered patterns."""
        return len(self._patterns)
