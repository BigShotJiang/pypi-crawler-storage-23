"""Threat Intelligence client for AI Sentinel SDK.

This module provides local threat detection using signatures
fetched from the Sentinel API.
"""

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)


@dataclass
class ThreatSignature:
    """A threat signature for local detection."""

    id: str
    name: str
    description: str
    category: str
    severity: str
    status: str
    extracted_prompt: str
    regex_patterns: list[str]
    keywords: list[str]
    affected_models: list[str]
    mitre_atlas_id: Optional[str] = None
    owasp_llm_id: Optional[str] = None
    source: str = ""
    source_url: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ThreatSignature":
        """Create from API response dict."""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            category=data["category"],
            severity=data["severity"],
            status=data.get("status", "active"),
            extracted_prompt=data.get("extracted_prompt", ""),
            regex_patterns=data.get("regex_patterns", []),
            keywords=data.get("keywords", []),
            affected_models=data.get("affected_models", []),
            mitre_atlas_id=data.get("mitre_atlas_id"),
            owasp_llm_id=data.get("owasp_llm_id"),
            source=data.get("source", ""),
            source_url=data.get("source_url"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
        )


@dataclass
class ThreatMatch:
    """Result of matching a prompt against threat signatures."""

    signature: ThreatSignature
    match_type: str  # "regex", "keyword", "semantic"
    confidence: float
    matched_pattern: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "threat_id": self.signature.id,
            "threat_name": self.signature.name,
            "category": self.signature.category,
            "severity": self.signature.severity,
            "match_type": self.match_type,
            "confidence": self.confidence,
            "matched_pattern": self.matched_pattern,
            "mitre_atlas_id": self.signature.mitre_atlas_id,
            "owasp_llm_id": self.signature.owasp_llm_id,
        }


@dataclass
class ThreatCheckResult:
    """Result of checking a prompt for threats."""

    has_threats: bool
    matches: list[ThreatMatch] = field(default_factory=list)
    highest_severity: Optional[str] = None
    check_time_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "has_threats": self.has_threats,
            "match_count": len(self.matches),
            "highest_severity": self.highest_severity,
            "matches": [m.to_dict() for m in self.matches],
            "check_time_ms": self.check_time_ms,
        }


class ThreatIntelClient:
    """
    Client for threat intelligence features.

    Fetches threat signatures from the Sentinel API and provides
    local detection capabilities for fast, offline threat checking.

    Usage:
        from zetro_sentinel_sdk import Sentinel
        from zetro_sentinel_sdk.threat_intel import ThreatIntelClient

        sentinel = Sentinel(api_key="your-api-key")
        threat_intel = ThreatIntelClient(sentinel)

        # Sync signatures (do this periodically)
        await threat_intel.sync()

        # Check a prompt locally (fast, no API call)
        result = threat_intel.check("Ignore all previous instructions...")
        if result.has_threats:
            print(f"Threat detected: {result.matches[0].signature.name}")
    """

    SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"]

    def __init__(
        self,
        sentinel_client=None,
        api_key: str = None,
        base_url: str = None,
        auto_sync_interval_minutes: int = 5,
    ):
        """
        Initialize the threat intel client.

        Args:
            sentinel_client: Existing Sentinel client instance
            api_key: API key (if not using existing client)
            base_url: API base URL (if not using existing client)
            auto_sync_interval_minutes: How often to auto-sync (0 to disable)
        """
        self._sentinel = sentinel_client
        self._api_key = api_key or (sentinel_client.api_key if sentinel_client else None)
        self._base_url = base_url or (sentinel_client.base_url if sentinel_client else "https://api.zetro.ai")
        self._sync_interval = timedelta(minutes=auto_sync_interval_minutes)

        # Local signature cache
        self._signatures: dict[str, ThreatSignature] = {}
        self._last_sync: Optional[datetime] = None
        self._compiled_patterns: dict[str, list[re.Pattern]] = {}

        # HTTP client for direct API calls
        self._http_client: Optional[httpx.AsyncClient] = None

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "X-API-Key": self._api_key,
                    "Content-Type": "application/json",
                    "User-Agent": "zetro-sentinel-sdk/threat-intel",
                },
                timeout=30.0,
            )
        return self._http_client

    async def sync(self, full: bool = False) -> int:
        """
        Sync threat signatures from the API.

        Args:
            full: If True, fetch all signatures. If False, only fetch updates.

        Returns:
            Number of new/updated signatures
        """
        client = await self._get_http_client()

        params = {"status": "active", "page_size": 1000}

        # Incremental sync if we have a last sync time
        if not full and self._last_sync:
            params["since"] = self._last_sync.isoformat()

        try:
            response = await client.get("/v1/threat-intel", params=params)

            if response.status_code != 200:
                logger.error(f"Failed to sync threat intel: {response.status_code}")
                return 0

            data = response.json()
            threats = data.get("threats", [])

            count = 0
            for threat_data in threats:
                sig = ThreatSignature.from_dict(threat_data)
                self._upsert_signature(sig)
                count += 1

            self._last_sync = datetime.utcnow()
            logger.info(f"Synced {count} threat signatures")

            return count

        except Exception as e:
            logger.error(f"Error syncing threat intel: {e}")
            return 0

    def _upsert_signature(self, sig: ThreatSignature):
        """Add or update a signature in the local cache."""
        self._signatures[sig.id] = sig

        # Pre-compile regex patterns for performance
        compiled = []
        for pattern in sig.regex_patterns:
            try:
                compiled.append(re.compile(pattern, re.IGNORECASE))
            except re.error as e:
                logger.warning(f"Invalid regex pattern in {sig.id}: {e}")
        self._compiled_patterns[sig.id] = compiled

    def check(self, prompt: str) -> ThreatCheckResult:
        """
        Check a prompt against all local threat signatures.

        This runs entirely locally - no API call required.
        Fast enough to use on every user input.

        Args:
            prompt: The text to check for threats

        Returns:
            ThreatCheckResult with any matches found
        """
        import time

        start = time.perf_counter()
        matches = []

        for sig_id, sig in self._signatures.items():
            match = self._check_signature(prompt, sig)
            if match:
                matches.append(match)

        # Sort by severity
        matches.sort(
            key=lambda m: self.SEVERITY_ORDER.index(m.signature.severity)
            if m.signature.severity in self.SEVERITY_ORDER
            else 999
        )

        elapsed_ms = (time.perf_counter() - start) * 1000

        return ThreatCheckResult(
            has_threats=len(matches) > 0,
            matches=matches,
            highest_severity=matches[0].signature.severity if matches else None,
            check_time_ms=round(elapsed_ms, 2),
        )

    def _check_signature(self, prompt: str, sig: ThreatSignature) -> Optional[ThreatMatch]:
        """Check a prompt against a single signature."""
        prompt_lower = prompt.lower()

        # Check compiled regex patterns first (most specific)
        compiled_patterns = self._compiled_patterns.get(sig.id, [])
        for i, pattern in enumerate(compiled_patterns):
            match = pattern.search(prompt)
            if match:
                return ThreatMatch(
                    signature=sig,
                    match_type="regex",
                    confidence=0.95,
                    matched_pattern=sig.regex_patterns[i] if i < len(sig.regex_patterns) else None,
                )

        # Check keywords (faster but less precise)
        keyword_hits = 0
        for keyword in sig.keywords:
            if keyword.lower() in prompt_lower:
                keyword_hits += 1

        # Require at least 2 keyword matches for a hit
        if keyword_hits >= 2:
            confidence = min(0.5 + (keyword_hits * 0.1), 0.85)
            return ThreatMatch(
                signature=sig,
                match_type="keyword",
                confidence=confidence,
                matched_pattern=None,
            )

        return None

    def check_with_semantic(
        self,
        prompt: str,
        embedding: list[float],
        threshold: float = 0.85,
    ) -> ThreatCheckResult:
        """
        Check a prompt using both pattern matching and semantic similarity.

        Requires embeddings to be present in signatures.

        Args:
            prompt: The text to check
            embedding: Pre-computed embedding of the prompt
            threshold: Similarity threshold for semantic matching

        Returns:
            ThreatCheckResult with matches from both methods
        """
        # First do pattern matching
        result = self.check(prompt)
        matches = list(result.matches)

        # Then check semantic similarity
        for sig in self._signatures.values():
            if sig.embedding:
                similarity = self._cosine_similarity(embedding, sig.embedding)
                if similarity >= threshold:
                    # Don't duplicate if already matched by pattern
                    if not any(m.signature.id == sig.id for m in matches):
                        matches.append(
                            ThreatMatch(
                                signature=sig,
                                match_type="semantic",
                                confidence=similarity,
                                matched_pattern=None,
                            )
                        )

        # Re-sort
        matches.sort(
            key=lambda m: self.SEVERITY_ORDER.index(m.signature.severity)
            if m.signature.severity in self.SEVERITY_ORDER
            else 999
        )

        return ThreatCheckResult(
            has_threats=len(matches) > 0,
            matches=matches,
            highest_severity=matches[0].signature.severity if matches else None,
            check_time_ms=result.check_time_ms,
        )

    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if len(a) != len(b):
            return 0.0

        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot_product / (norm_a * norm_b)

    async def report_incident(
        self,
        input_text: str,
        category: str = None,
        severity: str = None,
        agent_id: str = None,
        session_id: str = None,
        metadata: dict = None,
    ) -> dict:
        """
        Report a detected threat back to Sentinel.

        This contributes to the collective threat intelligence.

        Args:
            input_text: The malicious input that was detected
            category: Category of the threat
            severity: Severity level
            agent_id: Agent that detected it
            session_id: Session identifier
            metadata: Additional context

        Returns:
            Response from API with incident ID
        """
        client = await self._get_http_client()

        payload = {
            "input_text": input_text,
            "category": category,
            "severity": severity,
            "agent_id": agent_id,
            "session_id": session_id,
            "metadata": metadata or {},
        }

        try:
            response = await client.post("/v1/threat-intel/report", json=payload)

            if response.status_code != 200:
                logger.error(f"Failed to report incident: {response.status_code}")
                return {"status": "error", "message": "Failed to report"}

            return response.json()

        except Exception as e:
            logger.error(f"Error reporting incident: {e}")
            return {"status": "error", "message": str(e)}

    def get_stats(self) -> dict:
        """Get statistics about loaded signatures."""
        by_category = {}
        by_severity = {}

        for sig in self._signatures.values():
            by_category[sig.category] = by_category.get(sig.category, 0) + 1
            by_severity[sig.severity] = by_severity.get(sig.severity, 0) + 1

        return {
            "total_signatures": len(self._signatures),
            "by_category": by_category,
            "by_severity": by_severity,
            "last_sync": self._last_sync.isoformat() if self._last_sync else None,
        }

    def needs_sync(self) -> bool:
        """Check if signatures need to be synced."""
        if not self._last_sync:
            return True
        return datetime.utcnow() - self._last_sync > self._sync_interval

    async def close(self):
        """Clean up resources."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
