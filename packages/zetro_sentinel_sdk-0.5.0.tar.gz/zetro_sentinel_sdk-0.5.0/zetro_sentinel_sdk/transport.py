"""Custom Transport for AI Sentinel SDK.

This module provides transport-level interception for behavioral detection:
- Intercepts all outgoing HTTP requests
- Runs pre-request behavioral checks (API key verification, endpoint allowlist)
- Runs post-response behavioral checks
- Supports custom hooks for extensibility

Usage:
    from zetro_sentinel_sdk.transport import SentinelTransport
    from zetro_sentinel_sdk.behavioral import BehavioralDetector, APIKeyRegistry

    # Set up behavioral detection
    registry = APIKeyRegistry()
    registry.register_key(os.environ["ANTHROPIC_API_KEY"])
    detector = BehavioralDetector(registry)

    # Create transport with behavioral detection
    transport = SentinelTransport(
        base_transport=httpx.HTTPTransport(),
        behavioral_detector=detector,
    )

    # Use with httpx client
    client = httpx.Client(transport=transport)
"""

import logging
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional, Union

import httpx

from zetro_sentinel_sdk.behavioral import (
    BehavioralDetector,
    BehavioralResult,
    SecurityAlert,
    Alert,
    AlertSeverity,
    AlertType,
)

logger = logging.getLogger("zetro_sentinel_sdk.transport")


# Type for hook callbacks
PreRequestHook = Callable[[httpx.Request], Optional[httpx.Request]]
PostResponseHook = Callable[[httpx.Request, httpx.Response], Optional[httpx.Response]]


class SentinelTransport(httpx.BaseTransport):
    """Custom HTTP transport that intercepts all outgoing requests for behavioral detection.

    This transport wraps an existing httpx transport and adds:
    - Pre-request behavioral checks (API key, exfil endpoint detection)
    - Post-response inspection
    - Custom hook support for extensibility

    The transport is used when you want to monitor/control HTTP requests made by
    LLM-powered agents to detect and prevent data exfiltration attacks.

    Example:
        # Basic usage with behavioral detection
        registry = APIKeyRegistry()
        registry.register_key("sk-ant-...")

        detector = BehavioralDetector(registry, block_unknown_keys=True)
        transport = SentinelTransport(httpx.HTTPTransport(), detector)

        with httpx.Client(transport=transport) as client:
            # All requests now pass through behavioral detection
            response = client.get("https://api.example.com/data")
    """

    def __init__(
        self,
        base_transport: httpx.BaseTransport,
        behavioral_detector: Optional[BehavioralDetector] = None,
        on_alert: Optional[Callable[[Alert], None]] = None,
        on_block: Optional[Callable[[BehavioralResult], None]] = None,
        fail_open: bool = False,
    ):
        """Initialize the Sentinel transport.

        Args:
            base_transport: The underlying transport to wrap
            behavioral_detector: Optional behavioral detector for security checks
            on_alert: Callback when any alert is raised (even non-blocking)
            on_block: Callback when a request is blocked
            fail_open: If True, allow requests on internal errors (default: False)
        """
        self._transport = base_transport
        self._detector = behavioral_detector
        self._on_alert = on_alert
        self._on_block = on_block
        self._fail_open = fail_open

        # Hook registrations
        self._pre_request_hooks: List[PreRequestHook] = []
        self._post_response_hooks: List[PostResponseHook] = []

        # Statistics
        self._stats: Dict[str, int] = defaultdict(int)

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        """Handle an outgoing HTTP request.

        Args:
            request: The HTTP request to process

        Returns:
            The HTTP response

        Raises:
            SecurityAlert: If behavioral detection blocks the request
        """
        self._stats["total_requests"] += 1

        try:
            # Run pre-request behavioral checks
            modified_request = self._run_pre_request_checks(request)

            # Run custom pre-request hooks
            for hook in self._pre_request_hooks:
                result = hook(modified_request)
                if result is not None:
                    modified_request = result

            # Make the actual request
            response = self._transport.handle_request(modified_request)

            # Run post-response checks
            self._run_post_response_checks(modified_request, response)

            # Run custom post-response hooks
            for hook in self._post_response_hooks:
                result = hook(modified_request, response)
                if result is not None:
                    response = result

            self._stats["successful_requests"] += 1
            return response

        except SecurityAlert:
            self._stats["blocked_requests"] += 1
            raise
        except Exception as e:
            self._stats["error_requests"] += 1
            logger.error(f"Error in SentinelTransport: {e}")
            if self._fail_open:
                # On error, attempt the request without checks
                return self._transport.handle_request(request)
            raise

    def _run_pre_request_checks(self, request: httpx.Request) -> httpx.Request:
        """Run pre-request behavioral checks.

        Args:
            request: The request to check

        Returns:
            The request (possibly modified)

        Raises:
            SecurityAlert: If the request should be blocked
        """
        if not self._detector:
            return request

        result = self._detector.check_request(request)

        # Call alert callback for all alerts
        if self._on_alert:
            for alert in result.alerts:
                try:
                    self._on_alert(alert)
                except Exception as e:
                    logger.error(f"Error in alert callback: {e}")

        # If blocked, raise SecurityAlert
        if not result.allow:
            self._stats["blocked_by_behavioral"] += 1

            if self._on_block:
                try:
                    self._on_block(result)
                except Exception as e:
                    logger.error(f"Error in block callback: {e}")

            raise SecurityAlert(result.alerts)

        return request

    def _run_post_response_checks(
        self,
        request: httpx.Request,
        response: httpx.Response,
    ) -> None:
        """Run post-response behavioral checks.

        Currently logs response metadata for monitoring.
        Future: Could implement response content scanning.

        Args:
            request: The original request
            response: The response received
        """
        # Log response status for monitoring
        if response.status_code >= 400:
            logger.debug(
                f"Response {response.status_code} for {request.method} {request.url}"
            )

    def register_pre_request_hook(self, hook: PreRequestHook) -> None:
        """Register a custom pre-request hook.

        Hooks are called in order of registration. Each hook receives the request
        and can optionally return a modified request.

        Args:
            hook: Function that takes request, optionally returns modified request
        """
        self._pre_request_hooks.append(hook)

    def register_post_response_hook(self, hook: PostResponseHook) -> None:
        """Register a custom post-response hook.

        Hooks are called in order of registration. Each hook receives the request
        and response, and can optionally return a modified response.

        Args:
            hook: Function that takes (request, response), optionally returns modified response
        """
        self._post_response_hooks.append(hook)

    def clear_hooks(self) -> None:
        """Clear all registered hooks."""
        self._pre_request_hooks.clear()
        self._post_response_hooks.clear()

    @property
    def stats(self) -> Dict[str, int]:
        """Get transport statistics."""
        return dict(self._stats)

    def reset_stats(self) -> None:
        """Reset statistics counters."""
        self._stats.clear()

    def close(self) -> None:
        """Close the transport."""
        self._transport.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncSentinelTransport(httpx.AsyncBaseTransport):
    """Async version of SentinelTransport for use with httpx.AsyncClient.

    Usage:
        transport = AsyncSentinelTransport(
            httpx.AsyncHTTPTransport(),
            behavioral_detector,
        )

        async with httpx.AsyncClient(transport=transport) as client:
            response = await client.get("https://api.example.com/data")
    """

    def __init__(
        self,
        base_transport: httpx.AsyncBaseTransport,
        behavioral_detector: Optional[BehavioralDetector] = None,
        on_alert: Optional[Callable[[Alert], None]] = None,
        on_block: Optional[Callable[[BehavioralResult], None]] = None,
        fail_open: bool = False,
    ):
        """Initialize the async Sentinel transport.

        Args:
            base_transport: The underlying async transport to wrap
            behavioral_detector: Optional behavioral detector for security checks
            on_alert: Callback when any alert is raised
            on_block: Callback when a request is blocked
            fail_open: If True, allow requests on internal errors
        """
        self._transport = base_transport
        self._detector = behavioral_detector
        self._on_alert = on_alert
        self._on_block = on_block
        self._fail_open = fail_open

        # Hook registrations (sync callbacks for simplicity)
        self._pre_request_hooks: List[PreRequestHook] = []
        self._post_response_hooks: List[PostResponseHook] = []

        # Statistics
        self._stats: Dict[str, int] = defaultdict(int)

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        """Handle an async HTTP request.

        Args:
            request: The HTTP request to process

        Returns:
            The HTTP response

        Raises:
            SecurityAlert: If behavioral detection blocks the request
        """
        self._stats["total_requests"] += 1

        try:
            # Run pre-request behavioral checks (sync - detector is fast)
            modified_request = self._run_pre_request_checks(request)

            # Run custom pre-request hooks
            for hook in self._pre_request_hooks:
                result = hook(modified_request)
                if result is not None:
                    modified_request = result

            # Make the actual request
            response = await self._transport.handle_async_request(modified_request)

            # Run post-response checks
            self._run_post_response_checks(modified_request, response)

            # Run custom post-response hooks
            for hook in self._post_response_hooks:
                result = hook(modified_request, response)
                if result is not None:
                    response = result

            self._stats["successful_requests"] += 1
            return response

        except SecurityAlert:
            self._stats["blocked_requests"] += 1
            raise
        except Exception as e:
            self._stats["error_requests"] += 1
            logger.error(f"Error in AsyncSentinelTransport: {e}")
            if self._fail_open:
                return await self._transport.handle_async_request(request)
            raise

    def _run_pre_request_checks(self, request: httpx.Request) -> httpx.Request:
        """Run pre-request behavioral checks."""
        if not self._detector:
            return request

        result = self._detector.check_request(request)

        if self._on_alert:
            for alert in result.alerts:
                try:
                    self._on_alert(alert)
                except Exception as e:
                    logger.error(f"Error in alert callback: {e}")

        if not result.allow:
            self._stats["blocked_by_behavioral"] += 1

            if self._on_block:
                try:
                    self._on_block(result)
                except Exception as e:
                    logger.error(f"Error in block callback: {e}")

            raise SecurityAlert(result.alerts)

        return request

    def _run_post_response_checks(
        self,
        request: httpx.Request,
        response: httpx.Response,
    ) -> None:
        """Run post-response behavioral checks."""
        if response.status_code >= 400:
            logger.debug(
                f"Response {response.status_code} for {request.method} {request.url}"
            )

    def register_pre_request_hook(self, hook: PreRequestHook) -> None:
        """Register a custom pre-request hook."""
        self._pre_request_hooks.append(hook)

    def register_post_response_hook(self, hook: PostResponseHook) -> None:
        """Register a custom post-response hook."""
        self._post_response_hooks.append(hook)

    @property
    def stats(self) -> Dict[str, int]:
        """Get transport statistics."""
        return dict(self._stats)

    async def aclose(self) -> None:
        """Close the transport."""
        await self._transport.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
