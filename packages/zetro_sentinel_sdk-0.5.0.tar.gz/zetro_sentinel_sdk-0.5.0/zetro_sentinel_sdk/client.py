"""AI Sentinel SDK Client.

This module provides the main client interfaces for AI Sentinel:
- Sentinel: Synchronous client for scanning and authorization
- AsyncSentinel: Asynchronous client for the same operations

New in 0.4.0: Behavioral detection with runtime hooks
- API key registry for tracking legitimate keys
- Behavioral detector for exfiltration prevention
- Custom transport with pre/post request hooks
"""

import logging
import re
import time
from collections import defaultdict
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

import httpx

from zetro_sentinel_sdk.exceptions import (
    AuthenticationError,
    NetworkError,
    RateLimitError,
    SentinelError,
    ValidationError,
)
from zetro_sentinel_sdk.models import (
    ActionSourceResult,
    AuthorizeResult,
    CorrelationDetail,
    HierarchyResult,
    Incident,
    IncidentList,
    Policy,
    RateLimitResult,
    ScanResult,
    ToolExecution,
    ToolExecutionList,
    ToolResultScanResult,
)
from zetro_sentinel_sdk.session.manager import SessionManager
from zetro_sentinel_sdk.session.models import ScanEvent, ScanType, SessionState
from zetro_sentinel_sdk.session.correlators.base import BaseCorrelator, CorrelationResult
from zetro_sentinel_sdk.session.correlators.influence import InfluencePropagationDetector
from zetro_sentinel_sdk.session.correlators.escalation import EscalationTrajectoryDetector
from zetro_sentinel_sdk.session.correlators.tool_chain import ToolChainAbuseDetector
from zetro_sentinel_sdk.session.correlators.grounding import OutputGroundingDetector
from zetro_sentinel_sdk.session.correlators.memory_poisoning import MemoryPoisoningDetector
from zetro_sentinel_sdk.session.correlators.data_execution import DataDerivedExecutionDetector
from zetro_sentinel_sdk.behavioral import (
    APIKeyRegistry,
    BehavioralDetector,
    BehavioralResult,
    Alert,
    SecurityAlert,
    OutputInvariantChecker,
    OutputInvariantResult,
)
from zetro_sentinel_sdk.transport import (
    SentinelTransport,
    AsyncSentinelTransport,
)

logger = logging.getLogger("zetro_sentinel_sdk")


# Hook event types
HOOK_PRE_REQUEST = "pre_request"
HOOK_POST_RESPONSE = "post_response"
HOOK_CODE_EXECUTION = "code_execution"


_SPECIFICS_PATTERNS = {
    "url": re.compile(r"https?://[^\s<>\"']{5,200}"),
    "email": re.compile(r"[\w.+-]{1,50}@[\w.-]{1,50}\.[a-zA-Z]{2,10}"),
    "command": re.compile(r"(?:sudo|curl|wget|pip|npm)\s+\S{1,100}"),
    "file_path": re.compile(r"(?:/[\w.-]{1,50}){2,10}"),
    "ip_address": re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),
}


def _extract_specifics_from_text(
    text: str, scan_type: ScanType, tool_name: Optional[str] = None
) -> List[dict]:
    """Extract high-specificity content from text for session tracking."""
    if scan_type not in (ScanType.SCAN_TOOL_RESULT, ScanType.SCAN_OUTPUT):
        return []

    specifics: List[dict] = []
    for content_type, pattern in _SPECIFICS_PATTERNS.items():
        for match in pattern.finditer(text):
            specifics.append(
                {
                    "type": content_type,
                    "value": match.group(),
                    "source_tool": tool_name
                    if scan_type == ScanType.SCAN_TOOL_RESULT
                    else None,
                }
            )

    return specifics


_SEVERITY_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def _persist_escalation_state(session: SessionState, correlation: CorrelationResult) -> None:
    """Persist escalation detector state from correlation details to session.

    The escalation detector no longer mutates session state directly (preserving
    the read-only contract). Instead it returns computed values in details for
    the caller to persist.
    """
    details = correlation.details
    if "_current_score" in details:
        session.turn_suspicion_scores.append(details["_current_score"])
    if details.get("_is_capability_query") and "_query_timestamp" in details:
        session.capability_query_timestamps.append(details["_query_timestamp"])


def _apply_session_correlation(
    session_manager: SessionManager,
    correlators: List[BaseCorrelator],
    result: ScanResult,
    scan_type: ScanType,
    text: str,
    session_id: str,
    tool_name: Optional[str] = None,
) -> ScanResult:
    """Run client-side session correlation and merge into ScanResult."""
    session = session_manager.get_or_create(session_id)

    scan_summary = {
        "flagged": not result.allowed,
        "blocked": result.action == "DENY",
        "confidence": result.confidence or 0.0,
    }

    metadata: Dict[str, Any] = {}
    if tool_name:
        metadata["tool_name"] = tool_name

    event = ScanEvent(
        scan_type=scan_type,
        text=text,
        timestamp=time.time(),
        scan_result_summary=scan_summary,
        metadata=metadata,
        extracted_specifics=_extract_specifics_from_text(text, scan_type, tool_name),
    )

    session.add_event(event)

    for correlator in correlators:
        if correlator.should_run(session, event):
            correlation = correlator.check(session, event)

            # Persist escalation detector state from details
            _persist_escalation_state(session, correlation)

            if correlation.detected:
                detail = CorrelationDetail(
                    detected=True,
                    pattern=correlation.pattern,
                    severity=correlation.severity,
                    confidence_boost=correlation.confidence_boost,
                    details=correlation.details,
                )
                result.correlations.append(detail)

                if correlation.should_elevate:
                    new_level = _SEVERITY_ORDER.get(correlation.severity, 0)
                    if new_level >= _SEVERITY_ORDER["medium"]:
                        if not result.severity_elevated:
                            result.original_severity = (
                                "low" if result.allowed else "medium"
                            )
                        result.severity_elevated = True
                        result.elevation_reason = (
                            f"Session correlation: {correlation.pattern}"
                        )
                        if result.allowed and new_level >= _SEVERITY_ORDER["high"]:
                            result.allowed = False
                            result.action = "DENY"
                            result.reason = (
                                f"Blocked by session correlation ({correlation.pattern}): "
                                f"{correlation.details.get('explanation', '')[:200]}"
                            )
                    if result.confidence is not None:
                        result.confidence = min(
                            1.0, result.confidence + correlation.confidence_boost
                        )

    result.session_id = session_id
    session_manager.save(session)
    return result


def _apply_tool_result_session_correlation(
    session_manager: SessionManager,
    correlators: List[BaseCorrelator],
    result: ToolResultScanResult,
    text: str,
    session_id: str,
    tool_name: str,
) -> ToolResultScanResult:
    """Run client-side session correlation and merge into ToolResultScanResult."""
    session = session_manager.get_or_create(session_id)

    scan_summary = {
        "flagged": result.contains_instructions,
        "blocked": result.action == "DENY",
        "confidence": result.confidence or 0.0,
    }

    event = ScanEvent(
        scan_type=ScanType.SCAN_TOOL_RESULT,
        text=text,
        timestamp=time.time(),
        scan_result_summary=scan_summary,
        metadata={"tool_name": tool_name},
        extracted_specifics=_extract_specifics_from_text(
            text, ScanType.SCAN_TOOL_RESULT, tool_name
        ),
    )

    session.add_event(event)

    for correlator in correlators:
        if correlator.should_run(session, event):
            correlation = correlator.check(session, event)

            # Persist escalation detector state from details
            _persist_escalation_state(session, correlation)

            if correlation.detected:
                detail = CorrelationDetail(
                    detected=True,
                    pattern=correlation.pattern,
                    severity=correlation.severity,
                    confidence_boost=correlation.confidence_boost,
                    details=correlation.details,
                )
                result.correlations.append(detail)

                if correlation.should_elevate:
                    if not result.severity_elevated:
                        result.original_severity = (
                            "low" if result.action != "DENY" else "medium"
                        )
                    result.severity_elevated = True
                    result.elevation_reason = (
                        f"Session correlation: {correlation.pattern}"
                    )
                    if result.confidence is not None:
                        result.confidence = min(
                            1.0, result.confidence + correlation.confidence_boost
                        )

    result.session_id = session_id
    session_manager.save(session)
    return result


class FailureMode(str, Enum):
    """How to handle API failures."""

    RAISE = "raise"  # Raise exception (default)
    FAIL_OPEN = "fail_open"  # Allow on error (returns allowed=True)
    FAIL_CLOSED = "fail_closed"  # Deny on error (returns allowed=False)


class Sentinel:
    """
    Synchronous client for AI Sentinel API.

    Usage:
        sentinel = Sentinel(api_key="your-api-key")

        # Scan user input
        result = sentinel.scan_input("Hello world", agent_id="my-agent")
        if not result.allowed:
            print(f"Blocked: {result.reason}")

        # Authorize tool call
        auth = sentinel.authorize_tool(
            agent_id="my-agent",
            tool_name="send_email",
            user_role="USER",
            user_id="user-123"
        )

    Failure Modes:
        sentinel = Sentinel(
            api_key="your-api-key",
            failure_mode="fail_open"  # Allow requests if API is down
        )

    Retry Configuration:
        sentinel = Sentinel(
            api_key="your-api-key",
            max_retries=3,  # Retry on transient failures
            retry_delay=0.5  # Wait 0.5s between retries
        )

    Behavioral Detection (new in 0.4.0):
        sentinel = Sentinel(api_key="your-api-key")

        # Register known legitimate API keys
        sentinel.register_api_key(os.environ["ANTHROPIC_API_KEY"])
        sentinel.register_api_key(os.environ["OPENAI_API_KEY"])

        # Register custom hooks
        sentinel.register_hook("pre_request", my_pre_request_handler)

        # Get behavioral detection transport for wrapping other clients
        transport = sentinel.get_behavioral_transport()
    """

    DEFAULT_BASE_URL = "https://api.zetro.ai"
    DEFAULT_TIMEOUT = 30.0
    SDK_VERSION = "0.5.0"

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: float = None,
        failure_mode: str = "raise",
        max_retries: int = 0,
        retry_delay: float = 0.5,
        enable_behavioral_detection: bool = False,
        block_unknown_keys: bool = True,
        block_exfil_endpoints: bool = True,
    ) -> None:
        """
        Initialize the Sentinel client.

        Args:
            api_key: Your AI Sentinel API key
            base_url: API base URL (defaults to production)
            timeout: Request timeout in seconds
            failure_mode: How to handle API failures:
                - "raise" (default): Raise exceptions on errors
                - "fail_open": Return allowed=True on errors (use with caution)
                - "fail_closed": Return allowed=False on errors (secure default)
            max_retries: Number of retries on transient failures (0 = no retries)
            retry_delay: Seconds to wait between retries
            enable_behavioral_detection: Enable behavioral detection (API key tracking, etc.)
            block_unknown_keys: Block requests with unregistered API keys
            block_exfil_endpoints: Block requests to known exfiltration endpoints
        """
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.failure_mode = FailureMode(failure_mode)
        self.max_retries = max_retries
        self.retry_delay = retry_delay

        # Behavioral detection setup
        self._hooks: Dict[str, List[Callable]] = defaultdict(list)
        self._key_registry = APIKeyRegistry()
        self._behavioral_detector = BehavioralDetector(
            key_registry=self._key_registry,
            block_unknown_keys=block_unknown_keys,
            block_exfil_endpoints=block_exfil_endpoints,
        )
        self._enable_behavioral = enable_behavioral_detection

        # Output invariant checker for defense-in-depth credential detection
        self._output_checker = OutputInvariantChecker()
        self._check_output_invariants = True  # Enable by default

        # Register the SDK's own API key as legitimate
        self._key_registry.register_key(api_key, label="sentinel_sdk")

        # Session correlation layer (client-side, opt-in via session_id)
        self._session_manager = SessionManager()
        self._correlators: List[BaseCorrelator] = [
            InfluencePropagationDetector(),
            EscalationTrajectoryDetector(),
            ToolChainAbuseDetector(),
            OutputGroundingDetector(),
            MemoryPoisoningDetector(),
            DataDerivedExecutionDetector(),
        ]

        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "User-Agent": f"zetro-sentinel-sdk/{self.SDK_VERSION}",
            },
            timeout=self.timeout,
        )

    # =========================================================================
    # BEHAVIORAL DETECTION API
    # =========================================================================

    def register_api_key(self, api_key: str, label: Optional[str] = None) -> None:
        """Register a known legitimate API key for behavioral detection.

        When behavioral detection is enabled, requests using unregistered
        API keys will be flagged or blocked as potential exfiltration.

        Args:
            api_key: The API key to register
            label: Optional human-readable label (e.g., "production", "dev")

        Example:
            sentinel.register_api_key(os.environ["ANTHROPIC_API_KEY"], "anthropic")
            sentinel.register_api_key(os.environ["OPENAI_API_KEY"], "openai")
        """
        self._key_registry.register_key(api_key, label)
        logger.debug(f"Registered API key: {label or 'unlabeled'}")

    def unregister_api_key(self, api_key: str) -> bool:
        """Remove an API key from the registry.

        Args:
            api_key: The API key to remove

        Returns:
            True if key was found and removed
        """
        return self._key_registry.unregister_key(api_key)

    def register_hook(self, event: str, callback: Callable) -> None:
        """Register a custom behavioral detection hook.

        Hooks are called during request processing to allow custom
        detection logic or modifications.

        Args:
            event: Hook event type:
                - "pre_request": Called before each request
                - "post_response": Called after each response
                - "code_execution": Called before code execution (if applicable)
            callback: Function to call for this event

        Example:
            def my_pre_request_hook(request):
                # Log all outgoing requests
                logger.info(f"Request to: {request.url}")
                return request  # Return modified request or None

            sentinel.register_hook("pre_request", my_pre_request_hook)
        """
        valid_events = {HOOK_PRE_REQUEST, HOOK_POST_RESPONSE, HOOK_CODE_EXECUTION}
        if event not in valid_events:
            raise ValueError(f"Invalid event: {event}. Must be one of: {valid_events}")
        self._hooks[event].append(callback)

    def unregister_hook(self, event: str, callback: Callable) -> bool:
        """Remove a registered hook.

        Args:
            event: The hook event type
            callback: The callback to remove

        Returns:
            True if hook was found and removed
        """
        if event in self._hooks and callback in self._hooks[event]:
            self._hooks[event].remove(callback)
            return True
        return False

    def get_behavioral_transport(
        self,
        base_transport: Optional[httpx.BaseTransport] = None,
        on_alert: Optional[Callable[[Alert], None]] = None,
        on_block: Optional[Callable[[BehavioralResult], None]] = None,
    ) -> SentinelTransport:
        """Get a behavioral detection transport for wrapping httpx clients.

        Use this to add behavioral detection to any httpx-based client.

        Args:
            base_transport: Transport to wrap (default: new HTTPTransport)
            on_alert: Callback for alerts (even non-blocking)
            on_block: Callback when a request is blocked

        Returns:
            SentinelTransport with behavioral detection enabled

        Example:
            # Wrap Anthropic client with behavioral detection
            transport = sentinel.get_behavioral_transport()
            anthropic_client = Anthropic(
                http_client=httpx.Client(transport=transport)
            )
        """
        if base_transport is None:
            base_transport = httpx.HTTPTransport()

        transport = SentinelTransport(
            base_transport=base_transport,
            behavioral_detector=self._behavioral_detector,
            on_alert=on_alert,
            on_block=on_block,
        )

        # Register any custom hooks
        for hook in self._hooks.get(HOOK_PRE_REQUEST, []):
            transport.register_pre_request_hook(hook)
        for hook in self._hooks.get(HOOK_POST_RESPONSE, []):
            transport.register_post_response_hook(hook)

        return transport

    def check_request_behavioral(self, request: Any) -> BehavioralResult:
        """Manually check a request against behavioral detection.

        Use this for manual integration when you can't use the transport.

        Args:
            request: An httpx.Request or similar request object

        Returns:
            BehavioralResult with allow status and alerts
        """
        return self._behavioral_detector.check_request(request)

    def add_exfil_pattern(self, pattern: str) -> None:
        """Add a custom exfiltration endpoint pattern.

        Args:
            pattern: Regex pattern to match against URLs
        """
        self._behavioral_detector.add_exfil_pattern(pattern)

    def add_endpoint_allowlist(self, pattern: str) -> None:
        """Add an endpoint to the allowlist (bypass behavioral checks).

        Args:
            pattern: Regex pattern for allowed endpoints
        """
        self._behavioral_detector.add_allowlist_pattern(pattern)

    @property
    def key_registry(self) -> APIKeyRegistry:
        """Get the API key registry for direct manipulation."""
        return self._key_registry

    @property
    def behavioral_detector(self) -> BehavioralDetector:
        """Get the behavioral detector for direct manipulation."""
        return self._behavioral_detector

    @property
    def output_checker(self) -> OutputInvariantChecker:
        """Get the output invariant checker for direct manipulation."""
        return self._output_checker

    def register_output_invariants(self, patterns: List[Dict[str, Any]]) -> None:
        """Register additional output invariant patterns from rules.

        Use this to add patterns from behavioral_controls returned by the API.
        These patterns will be checked locally for defense-in-depth.

        Args:
            patterns: List of pattern dicts with id, pattern, action, description

        Example:
            # After receiving behavioral controls from API
            if response.behavioral and response.behavioral.output_invariants:
                sentinel.register_output_invariants(response.behavioral.output_invariants)
        """
        self._output_checker.register_patterns(patterns)

    def set_output_invariant_checking(self, enabled: bool) -> None:
        """Enable or disable local output invariant checking.

        Args:
            enabled: Whether to check outputs against invariant patterns
        """
        self._check_output_invariants = enabled

    def check_output_invariants(self, text: str) -> OutputInvariantResult:
        """Manually check text against output invariant patterns.

        Use this for manual integration when you want to check output
        without going through scan_output.

        Args:
            text: The text to check

        Returns:
            OutputInvariantResult with violations and redacted text
        """
        return self._output_checker.check(text)

    def redact_output(self, text: str) -> str:
        """Convenience method to redact sensitive patterns from text.

        Args:
            text: The text to redact

        Returns:
            Text with sensitive patterns replaced with [REDACTED]
        """
        return self._output_checker.redact(text)

    @property
    def session_manager(self) -> SessionManager:
        """Get the session manager for monitoring/debugging."""
        return self._session_manager

    def _run_pre_request_hooks(self, request: httpx.Request) -> httpx.Request:
        """Run pre-request hooks internally.

        Args:
            request: The request to process

        Returns:
            Possibly modified request

        Raises:
            SecurityAlert: If behavioral detection blocks the request
        """
        # Run behavioral detection if enabled
        if self._enable_behavioral:
            result = self._behavioral_detector.check_request(request)
            if not result.allow:
                raise SecurityAlert(result.alerts)

        # Run custom hooks
        for hook in self._hooks.get(HOOK_PRE_REQUEST, []):
            result = hook(request)
            if result is not None:
                request = result

        return request

    def _run_post_response_hooks(
        self,
        request: httpx.Request,
        response: httpx.Response,
    ) -> httpx.Response:
        """Run post-response hooks internally."""
        for hook in self._hooks.get(HOOK_POST_RESPONSE, []):
            result = hook(request, response)
            if result is not None:
                response = result
        return response

    def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code == 401:
            raise AuthenticationError(
                "Invalid API key. Get your key at https://app.zetro.ai/settings/api-keys",
                status_code=401,
                response=response.json() if response.content else None,
            )
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                "Rate limit exceeded. Upgrade your plan or wait before retrying.",
                retry_after=int(retry_after) if retry_after else None,
                response=response.json() if response.content else None,
            )
        elif response.status_code == 422:
            data = response.json() if response.content else {}
            raise ValidationError(
                "Invalid request parameters. Check your input data.",
                errors=data.get("detail", []),
                response=data,
            )
        elif response.status_code >= 500:
            # Try to parse error, but handle HTML/empty responses
            try:
                error_data = response.json() if response.content else None
            except Exception:
                error_data = None
            raise SentinelError(
                f"Server error ({response.status_code}). The API may be temporarily unavailable.",
                status_code=response.status_code,
                response=error_data,
            )
        elif response.status_code >= 400:
            try:
                error_data = response.json() if response.content else None
            except Exception:
                error_data = None
            raise SentinelError(
                f"API error: {response.status_code}",
                status_code=response.status_code,
                response=error_data,
            )

        return response.json()

    def _is_retryable(self, exception: Exception) -> bool:
        """Check if an exception is retryable."""
        if isinstance(exception, NetworkError):
            return True
        if isinstance(exception, SentinelError) and exception.status_code:
            # Retry on 5xx errors and 429 (rate limit)
            return exception.status_code >= 500 or exception.status_code == 429
        return False

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make an API request with retry support."""
        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(method, f"/v1{path}", **kwargs)
                return self._handle_response(response)
            except httpx.RequestError as e:
                last_exception = NetworkError(
                    f"Network error: {str(e)}. Check your internet connection."
                )
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
            except (SentinelError, RateLimitError) as e:
                last_exception = e
                if not self._is_retryable(e):
                    raise
                logger.warning(f"Request failed (attempt {attempt + 1}): {e}")

            # Wait before retry (except on last attempt)
            if attempt < self.max_retries:
                time.sleep(self.retry_delay * (attempt + 1))  # Exponential backoff

        raise last_exception

    def _handle_failure(self, operation: str, error: Exception) -> Optional[Dict[str, Any]]:
        """Handle failure based on failure_mode setting."""
        if self.failure_mode == FailureMode.RAISE:
            raise error

        logger.error(f"AI Sentinel {operation} failed: {error}")

        if self.failure_mode == FailureMode.FAIL_OPEN:
            logger.warning(f"FAIL_OPEN: Allowing request despite error")
            return {
                "allowed": True,
                "action": "ALLOW",
                "reason": f"AI Sentinel unavailable (fail_open mode): {str(error)}",
                "confidence": 0.0,
                "matched_patterns": [],
                "_sentinel_error": True,
            }
        else:  # FAIL_CLOSED
            logger.warning(f"FAIL_CLOSED: Denying request due to error")
            return {
                "allowed": False,
                "action": "DENY",
                "reason": f"AI Sentinel unavailable (fail_closed mode): {str(error)}",
                "confidence": 0.0,
                "matched_patterns": [],
                "_sentinel_error": True,
            }

    # =========================================================================
    # CONNECTIVITY
    # =========================================================================

    def ping(self) -> Dict[str, Any]:
        """
        Check SDK connectivity and API key validity.

        This lightweight endpoint verifies:
        - Network connectivity to AI Sentinel
        - API key is valid and active
        - Returns tenant information for verification

        The request also updates the last_used_at timestamp, keeping
        the SDK connection marked as "healthy" in the admin dashboard.

        Returns:
            Dict with status, tenant_id, tenant_name, api_key_name, timestamp

        Raises:
            AuthenticationError: If API key is invalid
            NetworkError: If unable to connect to API

        Example:
            >>> result = sentinel.ping()
            >>> print(f"Connected to {result['tenant_name']}")
        """
        # Use the health router's ping endpoint (with /v1 prefix stripped)
        response = self._client.get("/v1/ping")
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key")
        elif response.status_code != 200:
            raise NetworkError(f"Ping failed with status {response.status_code}")
        return response.json()

    # =========================================================================
    # SCANNING
    # =========================================================================

    def scan_input(
        self,
        text: str,
        agent_id: str = "default",
        session_id: str = None,
    ) -> ScanResult:
        """
        Scan user input for prompt injection and policy violations.

        Args:
            text: User input text to scan
            agent_id: Agent identifier (for agent-specific policies)
            session_id: Optional session ID for logging

        Returns:
            ScanResult with allowed status and detection details

        Note:
            Behavior on API errors depends on failure_mode:
            - "raise": Raises exception (default)
            - "fail_open": Returns allowed=True
            - "fail_closed": Returns allowed=False
        """
        try:
            data = self._request(
                "POST",
                "/scan/input",
                json={
                    "text": text,
                    "agent_id": agent_id,
                    "session_id": session_id,
                },
            )
            result = ScanResult(**data)

            # Run client-side session correlation if session_id provided
            if session_id:
                result = _apply_session_correlation(
                    self._session_manager, self._correlators,
                    result, ScanType.SCAN_INPUT, text, session_id,
                )

            return result
        except (SentinelError, NetworkError) as e:
            fallback = self._handle_failure("scan_input", e)
            if fallback:
                return ScanResult(**fallback)
            raise

    def scan_output(
        self,
        text: str,
        agent_id: str = "default",
        session_id: str = None,
        check_invariants_locally: bool = True,
    ) -> ScanResult:
        """
        Scan agent output for sensitive data leaks.

        This method provides defense-in-depth by:
        1. Checking output against local invariant patterns BEFORE sending to API
        2. Sending to API for comprehensive scanning
        3. Merging local and API violations

        Args:
            text: Output text to scan
            agent_id: Agent identifier
            session_id: Optional session ID for logging
            check_invariants_locally: Whether to check local invariants (default: True)

        Returns:
            ScanResult with allowed status and any detected patterns

        Note:
            Behavior on API errors depends on failure_mode:
            - "raise": Raises exception (default)
            - "fail_open": Returns allowed=True
            - "fail_closed": Returns allowed=False
        """
        # Defense-in-depth: check output invariants locally BEFORE sending to API
        local_violations = []
        if check_invariants_locally and self._check_output_invariants:
            local_result = self._output_checker.check(text)
            if local_result.has_violations:
                for v in local_result.violations:
                    local_violations.append(f"local:{v.invariant_id}")
                logger.warning(
                    f"Local output invariant check found {len(local_result.violations)} violations"
                )

        try:
            data = self._request(
                "POST",
                "/scan/output",
                json={
                    "text": text,
                    "agent_id": agent_id,
                    "session_id": session_id,
                },
            )
            result = ScanResult(**data)

            # Merge local violations into result
            if local_violations:
                result.matched_patterns = list(set(result.matched_patterns + local_violations))
                # If API allowed but we found local violations, block
                if result.allowed:
                    blocking_local = [v for v in local_violations if "redact" in v or "block" in v]
                    if blocking_local or local_violations:
                        result.allowed = False
                        result.action = "DENY"
                        if not result.reason or result.reason == "No policy violations detected":
                            result.reason = f"Output contains blocked content detected locally: {local_violations[0]}"

            # Run client-side session correlation if session_id provided
            if session_id:
                result = _apply_session_correlation(
                    self._session_manager, self._correlators,
                    result, ScanType.SCAN_OUTPUT, text, session_id,
                )

            return result
        except (SentinelError, NetworkError) as e:
            fallback = self._handle_failure("scan_output", e)
            if fallback:
                result = ScanResult(**fallback)
                # Even in fail-open, apply local invariant checks
                if local_violations:
                    result.matched_patterns = local_violations
                    result.allowed = False
                    result.action = "DENY"
                    result.reason = f"Output contains blocked content (local check): {local_violations[0]}"
                return result
            raise

    # =========================================================================
    # TARGET HELPERS (for allowlist validation)
    # =========================================================================

    @staticmethod
    def email_target(email: str) -> Dict[str, str]:
        """Create an email target for allowlist validation.

        Args:
            email: The email address being accessed

        Returns:
            Target dict with type='email' and the value
        """
        return {"type": "email", "value": email}

    @staticmethod
    def url_target(url: str) -> Dict[str, str]:
        """Create a URL target for allowlist validation.

        Args:
            url: The URL being accessed

        Returns:
            Target dict with type='url' and the value
        """
        return {"type": "url", "value": url}

    @staticmethod
    def domain_target(domain: str) -> Dict[str, str]:
        """Create a domain target for allowlist validation.

        Args:
            domain: The domain being accessed

        Returns:
            Target dict with type='domain' and the value
        """
        return {"type": "domain", "value": domain}

    @staticmethod
    def file_path_target(path: str) -> Dict[str, str]:
        """Create a file path target for allowlist validation.

        Args:
            path: The file path being accessed

        Returns:
            Target dict with type='file_path' and the value
        """
        return {"type": "file_path", "value": path}

    @staticmethod
    def channel_target(channel: str) -> Dict[str, str]:
        """Create a channel target for allowlist validation.

        Args:
            channel: The Slack/Teams channel being accessed

        Returns:
            Target dict with type='channel' and the value
        """
        return {"type": "channel", "value": channel}

    @staticmethod
    def database_target(database: str) -> Dict[str, str]:
        """Create a database target for allowlist validation.

        Args:
            database: The database name being accessed

        Returns:
            Target dict with type='database' and the value
        """
        return {"type": "database", "value": database}

    def scan_tool_result(
        self,
        text: str,
        tool_name: str,
        agent_id: str = "default",
        session_id: str = None,
        targets: Optional[List[Dict[str, str]]] = None,
    ) -> ToolResultScanResult:
        """
        Scan tool result for indirect injection patterns.

        Use this after executing external tool calls to detect
        instruction patterns embedded in the response.

        Args:
            text: Tool result text to scan
            tool_name: Name of the tool that produced the result
            agent_id: Agent identifier
            session_id: Optional session ID for logging
            targets: List of targets being accessed. Required for capabilities
                with allowlists. Each target is a dict with:
                - type: "email", "url", "domain", "file_path", "channel", "database"
                - value: The actual target value

        Returns:
            ToolResultScanResult with detection details

        Example using helpers:
            sentinel.scan_tool_result(
                agent_id="email-assistant",
                tool_name="send_email",
                text="Email sent successfully",
                targets=[
                    sentinel.email_target("john@company.com"),
                    sentinel.email_target("external@partner.com"),
                    sentinel.url_target("https://attachment.s3.amazonaws.com/file.pdf"),
                ]
            )
        """
        payload = {
            "text": text,
            "tool_name": tool_name,
            "agent_id": agent_id,
        }
        if session_id:
            payload["session_id"] = session_id
        if targets:
            payload["targets"] = targets

        data = self._request("POST", "/scan/tool-result", json=payload)
        result = ToolResultScanResult(**data)

        # Run client-side session correlation if session_id provided
        if session_id:
            result = _apply_tool_result_session_correlation(
                self._session_manager, self._correlators,
                result, text, session_id, tool_name,
            )

        return result

    # =========================================================================
    # AUTHORIZATION
    # =========================================================================

    def authorize_tool(
        self,
        agent_id: str,
        tool_name: str,
        user_role: str,
        user_id: str,
        is_resource_owner: bool = True,
        arguments: Dict[str, Any] = None,
        session_id: str = None,
    ) -> AuthorizeResult:
        """
        Authorize a tool call based on policy.

        Args:
            agent_id: Agent identifier
            tool_name: Tool to authorize
            user_role: User's role (e.g., "USER", "ADMIN")
            user_id: User identifier
            is_resource_owner: Whether user owns the resource
            arguments: Tool arguments (for HITL hash verification)
            session_id: Optional session ID

        Returns:
            AuthorizeResult with allowed status and approval details
        """
        data = self._request(
            "POST",
            "/authorize/tool",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "user_role": user_role,
                "user_id": user_id,
                "is_resource_owner": is_resource_owner,
                "arguments": arguments,
                "session_id": session_id,
            },
        )
        return AuthorizeResult(**data)

    def check_rate_limit(
        self,
        agent_id: str,
        tool_name: str,
        user_id: str,
    ) -> RateLimitResult:
        """
        Check if a tool call is within rate limits.

        Args:
            agent_id: Agent identifier
            tool_name: Tool being called
            user_id: User identifier

        Returns:
            RateLimitResult with current counts and limits
        """
        data = self._request(
            "POST",
            "/authorize/rate-limit",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "user_id": user_id,
            },
        )
        return RateLimitResult(**data)

    def evaluate_action_source(
        self,
        agent_id: str,
        user_message: str,
        tool_name: str,
        tool_arguments: Dict[str, Any],
        tool_results: List[Dict] = None,
    ) -> ActionSourceResult:
        """
        Evaluate whether an action was directly requested or data-derived.

        Use this for indirect injection defense to determine if
        a proposed action came from the user or external data.

        Args:
            agent_id: Agent identifier
            user_message: Original user request
            tool_name: Tool being called
            tool_arguments: Arguments to the tool
            tool_results: Previous tool results with provenance

        Returns:
            ActionSourceResult with source classification
        """
        data = self._request(
            "POST",
            "/authorize/action-source",
            json={
                "agent_id": agent_id,
                "user_message": user_message,
                "tool_name": tool_name,
                "tool_arguments": tool_arguments,
                "tool_results": tool_results or [],
            },
        )
        return ActionSourceResult(**data)

    def check_hierarchy(
        self,
        agent_id: str,
        user_message: str,
        proposed_action: Dict[str, Any],
        tool_results_with_instructions: List[Dict],
    ) -> HierarchyResult:
        """
        Check if proposed action respects instruction hierarchy.

        Verifies that external data is not overriding user instructions.

        Args:
            agent_id: Agent identifier
            user_message: Original user request
            proposed_action: Action LLM wants to take
            tool_results_with_instructions: Tool results flagged with instructions

        Returns:
            HierarchyResult with violation details if any
        """
        data = self._request(
            "POST",
            "/authorize/hierarchy",
            json={
                "agent_id": agent_id,
                "user_message": user_message,
                "proposed_action": proposed_action,
                "tool_results_with_instructions": tool_results_with_instructions,
            },
        )
        return HierarchyResult(**data)

    # =========================================================================
    # INCIDENTS
    # =========================================================================

    def list_incidents(
        self,
        page: int = 1,
        page_size: int = 20,
        severity: str = None,
        category: str = None,
        agent_id: str = None,
        resolved: bool = None,
    ) -> IncidentList:
        """
        List security incidents with filtering.

        Args:
            page: Page number (1-indexed)
            page_size: Items per page (max 100)
            severity: Filter by severity
            category: Filter by category
            agent_id: Filter by agent
            resolved: Filter by resolution status

        Returns:
            IncidentList with paginated incidents
        """
        params = {"page": page, "page_size": page_size}
        if severity:
            params["severity"] = severity
        if category:
            params["category"] = category
        if agent_id:
            params["agent_id"] = agent_id
        if resolved is not None:
            params["resolved"] = resolved

        data = self._request("GET", "/incidents", params=params)
        return IncidentList(**data)

    def get_incident(self, incident_id: str) -> Incident:
        """
        Get a specific incident by ID.

        Args:
            incident_id: Incident ID

        Returns:
            Incident details
        """
        data = self._request("GET", f"/incidents/{incident_id}")
        return Incident(**data)

    # =========================================================================
    # POLICIES
    # =========================================================================

    def get_policy(self) -> Policy:
        """
        Get the current security policy.

        Returns:
            Policy configuration
        """
        data = self._request("GET", "/policies")
        return Policy(**data)

    def toggle_agent(self, agent_id: str, enabled: bool, reason: str = None) -> Dict:
        """
        Toggle the kill switch for an agent.

        Args:
            agent_id: Agent identifier
            enabled: Whether to enable or disable
            reason: Reason for the change

        Returns:
            Confirmation dict
        """
        return self._request(
            "POST",
            f"/policies/kill-switch/agent/{agent_id}",
            json={"enabled": enabled, "reason": reason},
        )

    def toggle_tool(
        self, agent_id: str, tool_name: str, enabled: bool, reason: str = None
    ) -> Dict:
        """
        Toggle the kill switch for a specific tool.

        Args:
            agent_id: Agent identifier
            tool_name: Tool name
            enabled: Whether to enable or disable
            reason: Reason for the change

        Returns:
            Confirmation dict
        """
        return self._request(
            "POST",
            f"/policies/kill-switch/tool/{agent_id}/{tool_name}",
            json={"enabled": enabled, "reason": reason},
        )

    # =========================================================================
    # TOOL EXECUTIONS
    # =========================================================================

    def create_execution(
        self,
        agent_id: str,
        tool_name: str,
        user_id: str = None,
        session_id: str = None,
        tool_arguments: Dict[str, Any] = None,
        argument_hash: str = None,
        action_source: str = None,
    ) -> ToolExecution:
        """
        Create a tool execution record to track a tool call.

        Call this when starting a tool execution to begin tracking.
        Use complete_execution() when the tool call finishes.

        Args:
            agent_id: Agent making the tool call
            tool_name: Name of the tool being called
            user_id: Optional user identifier
            session_id: Optional session identifier
            tool_arguments: Arguments passed to the tool
            argument_hash: Hash of arguments (for verification)
            action_source: DIRECT_REQUEST, DATA_DERIVED, or HYBRID

        Returns:
            ToolExecution with ID to use for completion

        Example:
            execution = sentinel.create_execution(
                agent_id="my-agent",
                tool_name="send_email",
                user_id="user-123",
                tool_arguments={"to": "user@example.com"}
            )
            try:
                result = execute_tool(...)
                sentinel.complete_execution(execution.id, "SUCCESS", result=result)
            except Exception as e:
                sentinel.complete_execution(execution.id, "FAILED", error=str(e))
        """
        data = self._request(
            "POST",
            "/tool-executions",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "user_id": user_id,
                "session_id": session_id,
                "tool_arguments": tool_arguments,
                "argument_hash": argument_hash,
                "action_source": action_source,
            },
        )
        return ToolExecution(**data)

    def complete_execution(
        self,
        execution_id: str,
        status: str,
        result: Dict[str, Any] = None,
        error: str = None,
        error_type: str = None,
    ) -> ToolExecution:
        """
        Complete a tool execution record.

        Call this when a tool call finishes to record the outcome.

        Args:
            execution_id: Execution ID from create_execution()
            status: Final status - one of:
                - SUCCESS: Tool completed successfully
                - FAILED: Tool encountered an error
                - DENIED: Tool was denied by policy
                - TIMEOUT: Tool execution timed out
                - CANCELLED: Tool execution was cancelled
            result: Optional result data (for SUCCESS)
            error: Error message (for FAILED/TIMEOUT)
            error_type: Type of error (e.g., "ValidationError")

        Returns:
            Updated ToolExecution with completion details
        """
        data = self._request(
            "POST",
            f"/tool-executions/{execution_id}/complete",
            json={
                "status": status,
                "result": result,
                "error": error,
                "error_type": error_type,
            },
        )
        return ToolExecution(**data)

    def list_executions(
        self,
        page: int = 1,
        page_size: int = 20,
        tool_name: str = None,
        status: str = None,
        agent_id: str = None,
        user_id: str = None,
        session_id: str = None,
    ) -> ToolExecutionList:
        """
        List tool executions with filtering.

        Args:
            page: Page number (1-indexed)
            page_size: Items per page (max 100)
            tool_name: Filter by tool name
            status: Filter by status
            agent_id: Filter by agent
            user_id: Filter by user
            session_id: Filter by session

        Returns:
            ToolExecutionList with paginated executions
        """
        params = {"page": page, "page_size": page_size}
        if tool_name:
            params["tool_name"] = tool_name
        if status:
            params["status"] = status
        if agent_id:
            params["agent_id"] = agent_id
        if user_id:
            params["user_id"] = user_id
        if session_id:
            params["session_id"] = session_id

        data = self._request("GET", "/tool-executions", params=params)
        return ToolExecutionList(**data)

    def get_execution(self, execution_id: str) -> ToolExecution:
        """
        Get a specific tool execution by ID.

        Args:
            execution_id: Execution ID

        Returns:
            ToolExecution details
        """
        data = self._request("GET", f"/tool-executions/{execution_id}")
        return ToolExecution(**data)

    def close(self) -> None:
        """Close the HTTP client and session manager."""
        self._session_manager.close()
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncSentinel:
    """
    Asynchronous client for AI Sentinel API.

    Usage:
        async with AsyncSentinel(api_key="your-api-key") as sentinel:
            result = await sentinel.scan_input("Hello world")

    With behavioral detection:
        async with AsyncSentinel(
            api_key="your-api-key",
            enable_behavioral_detection=True,
        ) as sentinel:
            # Register legitimate API keys
            sentinel.register_api_key(os.environ["ANTHROPIC_API_KEY"])

            # Get transport for wrapping other clients
            transport = sentinel.get_behavioral_transport()
    """

    DEFAULT_BASE_URL = "https://api.zetro.ai"
    DEFAULT_TIMEOUT = 30.0
    SDK_VERSION = "0.5.0"

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: float = None,
        enable_behavioral_detection: bool = False,
        block_unknown_keys: bool = True,
        block_exfil_endpoints: bool = True,
    ) -> None:
        """Initialize the async Sentinel client.

        Args:
            api_key: Your AI Sentinel API key
            base_url: API base URL (defaults to production)
            timeout: Request timeout in seconds
            enable_behavioral_detection: Enable behavioral detection
            block_unknown_keys: Block requests with unregistered API keys
            block_exfil_endpoints: Block requests to known exfiltration endpoints
        """
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout or self.DEFAULT_TIMEOUT

        # Behavioral detection setup
        self._hooks: Dict[str, List[Callable]] = defaultdict(list)
        self._key_registry = APIKeyRegistry()
        self._behavioral_detector = BehavioralDetector(
            key_registry=self._key_registry,
            block_unknown_keys=block_unknown_keys,
            block_exfil_endpoints=block_exfil_endpoints,
        )
        self._enable_behavioral = enable_behavioral_detection

        # Output invariant checker for defense-in-depth credential detection
        self._output_checker = OutputInvariantChecker()
        self._check_output_invariants = True  # Enable by default

        # Session correlation layer (client-side, opt-in via session_id)
        self._session_manager = SessionManager()
        self._correlators: List[BaseCorrelator] = [
            InfluencePropagationDetector(),
            EscalationTrajectoryDetector(),
            ToolChainAbuseDetector(),
            OutputGroundingDetector(),
            MemoryPoisoningDetector(),
            DataDerivedExecutionDetector(),
        ]

        # Register the SDK's own API key as legitimate
        self._key_registry.register_key(api_key, label="sentinel_sdk")

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "User-Agent": f"zetro-sentinel-sdk/{self.SDK_VERSION}",
            },
            timeout=self.timeout,
        )

    # =========================================================================
    # BEHAVIORAL DETECTION API (same as sync client)
    # =========================================================================

    @property
    def session_manager(self) -> SessionManager:
        """Get the session manager for monitoring/debugging."""
        return self._session_manager

    def register_api_key(self, api_key: str, label: Optional[str] = None) -> None:
        """Register a known legitimate API key for behavioral detection."""
        self._key_registry.register_key(api_key, label)

    def unregister_api_key(self, api_key: str) -> bool:
        """Remove an API key from the registry."""
        return self._key_registry.unregister_key(api_key)

    def register_hook(self, event: str, callback: Callable) -> None:
        """Register a custom behavioral detection hook."""
        valid_events = {HOOK_PRE_REQUEST, HOOK_POST_RESPONSE, HOOK_CODE_EXECUTION}
        if event not in valid_events:
            raise ValueError(f"Invalid event: {event}. Must be one of: {valid_events}")
        self._hooks[event].append(callback)

    def get_behavioral_transport(
        self,
        base_transport: Optional[httpx.AsyncBaseTransport] = None,
        on_alert: Optional[Callable[[Alert], None]] = None,
        on_block: Optional[Callable[[BehavioralResult], None]] = None,
    ) -> AsyncSentinelTransport:
        """Get an async behavioral detection transport."""
        if base_transport is None:
            base_transport = httpx.AsyncHTTPTransport()

        transport = AsyncSentinelTransport(
            base_transport=base_transport,
            behavioral_detector=self._behavioral_detector,
            on_alert=on_alert,
            on_block=on_block,
        )

        for hook in self._hooks.get(HOOK_PRE_REQUEST, []):
            transport.register_pre_request_hook(hook)
        for hook in self._hooks.get(HOOK_POST_RESPONSE, []):
            transport.register_post_response_hook(hook)

        return transport

    def check_request_behavioral(self, request: Any) -> BehavioralResult:
        """Manually check a request against behavioral detection."""
        return self._behavioral_detector.check_request(request)

    def add_exfil_pattern(self, pattern: str) -> None:
        """Add a custom exfiltration endpoint pattern."""
        self._behavioral_detector.add_exfil_pattern(pattern)

    def add_endpoint_allowlist(self, pattern: str) -> None:
        """Add an endpoint to the allowlist."""
        self._behavioral_detector.add_allowlist_pattern(pattern)

    @property
    def key_registry(self) -> APIKeyRegistry:
        """Get the API key registry."""
        return self._key_registry

    @property
    def behavioral_detector(self) -> BehavioralDetector:
        """Get the behavioral detector."""
        return self._behavioral_detector

    @property
    def output_checker(self) -> OutputInvariantChecker:
        """Get the output invariant checker for direct manipulation."""
        return self._output_checker

    def register_output_invariants(self, patterns: List[Dict[str, Any]]) -> None:
        """Register additional output invariant patterns from rules."""
        self._output_checker.register_patterns(patterns)

    def set_output_invariant_checking(self, enabled: bool) -> None:
        """Enable or disable local output invariant checking."""
        self._check_output_invariants = enabled

    def check_output_invariants(self, text: str) -> OutputInvariantResult:
        """Manually check text against output invariant patterns."""
        return self._output_checker.check(text)

    def redact_output(self, text: str) -> str:
        """Convenience method to redact sensitive patterns from text."""
        return self._output_checker.redact(text)

    async def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code == 401:
            raise AuthenticationError("Invalid API key", status_code=401)
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                "Rate limit exceeded",
                retry_after=int(retry_after) if retry_after else None,
            )
        elif response.status_code == 422:
            data = response.json() if response.content else {}
            raise ValidationError("Validation error", errors=data.get("detail", []))
        elif response.status_code >= 400:
            raise SentinelError(f"API error: {response.status_code}", status_code=response.status_code)

        return response.json()

    async def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make an async API request."""
        try:
            response = await self._client.request(method, f"/v1{path}", **kwargs)
            return await self._handle_response(response)
        except httpx.RequestError as e:
            raise NetworkError(f"Network error: {str(e)}")

    async def ping(self) -> Dict[str, Any]:
        """
        Check SDK connectivity and API key validity (async version).

        This lightweight endpoint verifies:
        - Network connectivity to AI Sentinel
        - API key is valid and active
        - Returns tenant information for verification

        Returns:
            Dict with status, tenant_id, tenant_name, api_key_name, timestamp

        Raises:
            AuthenticationError: If API key is invalid
            NetworkError: If unable to connect to API
        """
        try:
            response = await self._client.get("/v1/ping")
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif response.status_code != 200:
                raise NetworkError(f"Ping failed with status {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise NetworkError(f"Network error: {str(e)}")

    async def scan_input(
        self,
        text: str,
        agent_id: str = "default",
        session_id: str = None,
    ) -> ScanResult:
        """Async version of scan_input."""
        data = await self._request(
            "POST",
            "/scan/input",
            json={"text": text, "agent_id": agent_id, "session_id": session_id},
        )
        result = ScanResult(**data)

        if session_id:
            result = _apply_session_correlation(
                self._session_manager, self._correlators,
                result, ScanType.SCAN_INPUT, text, session_id,
            )

        return result

    async def scan_output(
        self,
        text: str,
        agent_id: str = "default",
        session_id: str = None,
        check_invariants_locally: bool = True,
    ) -> ScanResult:
        """Async version of scan_output with local invariant checking.

        This method provides defense-in-depth by:
        1. Checking output against local invariant patterns BEFORE sending to API
        2. Sending to API for comprehensive scanning
        3. Merging local and API violations
        """
        # Defense-in-depth: check output invariants locally BEFORE sending to API
        local_violations = []
        if check_invariants_locally and self._check_output_invariants:
            local_result = self._output_checker.check(text)
            if local_result.has_violations:
                for v in local_result.violations:
                    local_violations.append(f"local:{v.invariant_id}")
                logger.warning(
                    f"Local output invariant check found {len(local_result.violations)} violations"
                )

        data = await self._request(
            "POST",
            "/scan/output",
            json={"text": text, "agent_id": agent_id, "session_id": session_id},
        )
        result = ScanResult(**data)

        # Merge local violations into result
        if local_violations:
            result.matched_patterns = list(set(result.matched_patterns + local_violations))
            # If API allowed but we found local violations, block
            if result.allowed:
                result.allowed = False
                result.action = "DENY"
                if not result.reason or result.reason == "No policy violations detected":
                    result.reason = f"Output contains blocked content detected locally: {local_violations[0]}"

        # Run client-side session correlation if session_id provided
        if session_id:
            result = _apply_session_correlation(
                self._session_manager, self._correlators,
                result, ScanType.SCAN_OUTPUT, text, session_id,
            )

        return result

    # =========================================================================
    # TARGET HELPERS (same as sync client)
    # =========================================================================

    @staticmethod
    def email_target(email: str) -> Dict[str, str]:
        """Create an email target for allowlist validation."""
        return {"type": "email", "value": email}

    @staticmethod
    def url_target(url: str) -> Dict[str, str]:
        """Create a URL target for allowlist validation."""
        return {"type": "url", "value": url}

    @staticmethod
    def domain_target(domain: str) -> Dict[str, str]:
        """Create a domain target for allowlist validation."""
        return {"type": "domain", "value": domain}

    @staticmethod
    def file_path_target(path: str) -> Dict[str, str]:
        """Create a file path target for allowlist validation."""
        return {"type": "file_path", "value": path}

    @staticmethod
    def channel_target(channel: str) -> Dict[str, str]:
        """Create a channel target for allowlist validation."""
        return {"type": "channel", "value": channel}

    @staticmethod
    def database_target(database: str) -> Dict[str, str]:
        """Create a database target for allowlist validation."""
        return {"type": "database", "value": database}

    async def scan_tool_result(
        self,
        text: str,
        tool_name: str,
        agent_id: str = "default",
        session_id: str = None,
        targets: Optional[List[Dict[str, str]]] = None,
    ) -> ToolResultScanResult:
        """Async version of scan_tool_result.

        Args:
            text: Tool result text to scan
            tool_name: Name of the tool that produced the result
            agent_id: Agent identifier
            session_id: Optional session ID for logging
            targets: List of targets being accessed (for allowlist validation)

        Returns:
            ToolResultScanResult with detection details
        """
        payload = {
            "text": text,
            "tool_name": tool_name,
            "agent_id": agent_id,
        }
        if session_id:
            payload["session_id"] = session_id
        if targets:
            payload["targets"] = targets

        data = await self._request("POST", "/scan/tool-result", json=payload)
        result = ToolResultScanResult(**data)

        # Run client-side session correlation if session_id provided
        if session_id:
            result = _apply_tool_result_session_correlation(
                self._session_manager, self._correlators,
                result, text, session_id, tool_name,
            )

        return result

    async def authorize_tool(
        self,
        agent_id: str,
        tool_name: str,
        user_role: str,
        user_id: str,
        is_resource_owner: bool = True,
        arguments: Dict[str, Any] = None,
        session_id: str = None,
    ) -> AuthorizeResult:
        """Async version of authorize_tool."""
        data = await self._request(
            "POST",
            "/authorize/tool",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "user_role": user_role,
                "user_id": user_id,
                "is_resource_owner": is_resource_owner,
                "arguments": arguments,
                "session_id": session_id,
            },
        )
        return AuthorizeResult(**data)

    async def evaluate_action_source(
        self,
        agent_id: str,
        user_message: str,
        tool_name: str,
        tool_arguments: Dict[str, Any],
        tool_results: List[Dict] = None,
    ) -> ActionSourceResult:
        """Async version of evaluate_action_source."""
        data = await self._request(
            "POST",
            "/authorize/action-source",
            json={
                "agent_id": agent_id,
                "user_message": user_message,
                "tool_name": tool_name,
                "tool_arguments": tool_arguments,
                "tool_results": tool_results or [],
            },
        )
        return ActionSourceResult(**data)

    async def check_hierarchy(
        self,
        agent_id: str,
        user_message: str,
        proposed_action: Dict[str, Any],
        tool_results_with_instructions: List[Dict],
    ) -> HierarchyResult:
        """Async version of check_hierarchy."""
        data = await self._request(
            "POST",
            "/authorize/hierarchy",
            json={
                "agent_id": agent_id,
                "user_message": user_message,
                "proposed_action": proposed_action,
                "tool_results_with_instructions": tool_results_with_instructions,
            },
        )
        return HierarchyResult(**data)

    # =========================================================================
    # TOOL EXECUTIONS
    # =========================================================================

    async def create_execution(
        self,
        agent_id: str,
        tool_name: str,
        user_id: str = None,
        session_id: str = None,
        tool_arguments: Dict[str, Any] = None,
        argument_hash: str = None,
        action_source: str = None,
    ) -> ToolExecution:
        """Async version of create_execution."""
        data = await self._request(
            "POST",
            "/tool-executions",
            json={
                "agent_id": agent_id,
                "tool_name": tool_name,
                "user_id": user_id,
                "session_id": session_id,
                "tool_arguments": tool_arguments,
                "argument_hash": argument_hash,
                "action_source": action_source,
            },
        )
        return ToolExecution(**data)

    async def complete_execution(
        self,
        execution_id: str,
        status: str,
        result: Dict[str, Any] = None,
        error: str = None,
        error_type: str = None,
    ) -> ToolExecution:
        """Async version of complete_execution."""
        data = await self._request(
            "POST",
            f"/tool-executions/{execution_id}/complete",
            json={
                "status": status,
                "result": result,
                "error": error,
                "error_type": error_type,
            },
        )
        return ToolExecution(**data)

    async def list_executions(
        self,
        page: int = 1,
        page_size: int = 20,
        tool_name: str = None,
        status: str = None,
        agent_id: str = None,
        user_id: str = None,
        session_id: str = None,
    ) -> ToolExecutionList:
        """Async version of list_executions."""
        params = {"page": page, "page_size": page_size}
        if tool_name:
            params["tool_name"] = tool_name
        if status:
            params["status"] = status
        if agent_id:
            params["agent_id"] = agent_id
        if user_id:
            params["user_id"] = user_id
        if session_id:
            params["session_id"] = session_id

        data = await self._request("GET", "/tool-executions", params=params)
        return ToolExecutionList(**data)

    async def get_execution(self, execution_id: str) -> ToolExecution:
        """Async version of get_execution."""
        data = await self._request("GET", f"/tool-executions/{execution_id}")
        return ToolExecution(**data)

    async def close(self) -> None:
        """Close the HTTP client and session manager."""
        self._session_manager.close()
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
