"""
AI Sentinel Python SDK

Simple, type-safe SDK for integrating AI Sentinel security into your AI agents.

Basic usage:
    from zetro_sentinel_sdk import Sentinel

    sentinel = Sentinel(api_key="your-api-key")

    # Scan input
    result = sentinel.scan_input("Hello, how are you?", agent_id="my-agent")
    if not result.allowed:
        print(f"Blocked: {result.reason}")

    # Authorize tool call
    auth = sentinel.authorize_tool(
        agent_id="my-agent",
        tool_name="send_email",
        user_role="USER",
        user_id="user-123"
    )
    if not auth.allowed:
        print(f"Denied: {auth.reason}")

Graceful Degradation (recommended for production):
    # Don't block your app if Sentinel is down
    sentinel = Sentinel(
        api_key="your-api-key",
        failure_mode="fail_open",  # Allow requests if API unavailable
        max_retries=2              # Retry on transient failures
    )

Behavioral Detection (new in 0.4.0):
    import os
    from zetro_sentinel_sdk import Sentinel

    sentinel = Sentinel(api_key="your-api-key")

    # Register known legitimate API keys
    sentinel.register_api_key(os.environ["ANTHROPIC_API_KEY"], "anthropic")
    sentinel.register_api_key(os.environ["OPENAI_API_KEY"], "openai")

    # Get transport for wrapping LLM clients
    transport = sentinel.get_behavioral_transport()

    # Now any requests through this transport will be monitored
    # Unknown API keys or exfiltration endpoints will be blocked

Upgrade:
    pip install --upgrade zetro-sentinel-sdk
"""

__version__ = "0.5.0"
MIN_RECOMMENDED_VERSION = "0.4.0"


def _check_version():
    """Warn if using an outdated version."""
    import warnings
    try:
        from packaging import version
        current = version.parse(__version__)
        recommended = version.parse(MIN_RECOMMENDED_VERSION)
        if current < recommended:
            warnings.warn(
                f"zetro-sentinel-sdk {__version__} is outdated. "
                f"Please upgrade: pip install --upgrade zetro-sentinel-sdk",
                DeprecationWarning,
                stacklevel=3
            )
    except ImportError:
        pass  # packaging not available, skip check

from zetro_sentinel_sdk.client import Sentinel, AsyncSentinel, FailureMode
from zetro_sentinel_sdk.models import (
    ScanResult,
    AuthorizeResult,
    ActionSourceResult,
    CorrelationDetail,
    HierarchyResult,
    Incident,
    ToolExecution,
    ToolExecutionList,
    ToolResultScanResult,
    # Behavioral detection models (re-exported from behavioral.py)
    Alert,
    AlertSeverity,
    AlertType,
    BehavioralResult,
    SecurityAlert,
    # Behavioral enforcement models (new)
    BehavioralEnforcement,
    OutputViolationDetail,
    OutputInvariantChecker,
    OutputInvariantResult,
    OutputInvariantViolation,
)
from zetro_sentinel_sdk.session import (
    ScanType,
    ScanEvent,
    SessionState,
    SessionManager,
    CorrelationResult,
    classify_tool_trust,
    InfluencePropagationDetector,
    EscalationTrajectoryDetector,
    ToolChainAbuseDetector,
    OutputGroundingDetector,
    MemoryPoisoningDetector,
    DataDerivedExecutionDetector,
)
from zetro_sentinel_sdk.exceptions import (
    SentinelError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NetworkError,
)
from zetro_sentinel_sdk.threat_intel import (
    ThreatIntelClient,
    ThreatSignature,
    ThreatMatch,
    ThreatCheckResult,
)
from zetro_sentinel_sdk.behavioral import (
    APIKeyRegistry,
    BehavioralDetector,
)
from zetro_sentinel_sdk.transport import (
    SentinelTransport,
    AsyncSentinelTransport,
)

__all__ = [
    # Client
    "Sentinel",
    "AsyncSentinel",
    "FailureMode",
    # Models
    "ScanResult",
    "AuthorizeResult",
    "ActionSourceResult",
    "HierarchyResult",
    "Incident",
    "ToolExecution",
    "ToolExecutionList",
    "ToolResultScanResult",
    "CorrelationDetail",
    # Session Correlation
    "ScanType",
    "ScanEvent",
    "SessionState",
    "SessionManager",
    "CorrelationResult",
    "classify_tool_trust",
    "InfluencePropagationDetector",
    "EscalationTrajectoryDetector",
    "ToolChainAbuseDetector",
    "OutputGroundingDetector",
    "MemoryPoisoningDetector",
    "DataDerivedExecutionDetector",
    # Behavioral Detection
    "APIKeyRegistry",
    "BehavioralDetector",
    "BehavioralResult",
    "Alert",
    "AlertSeverity",
    "AlertType",
    "SecurityAlert",
    # Behavioral Enforcement (new)
    "BehavioralEnforcement",
    "OutputViolationDetail",
    "OutputInvariantChecker",
    "OutputInvariantResult",
    "OutputInvariantViolation",
    # Transport
    "SentinelTransport",
    "AsyncSentinelTransport",
    # Exceptions
    "SentinelError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NetworkError",
    # Threat Intel
    "ThreatIntelClient",
    "ThreatSignature",
    "ThreatMatch",
    "ThreatCheckResult",
]
