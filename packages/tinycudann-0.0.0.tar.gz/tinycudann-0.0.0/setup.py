"""
Empty setup.py for tinycudann
"""
from setuptools import setup

setup(
    name="tinycudann",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
