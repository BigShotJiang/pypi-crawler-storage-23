---
title: Jinja Test
---

# Hello {{ page.title }}

DEBUG is {{ DEBUG }}.
