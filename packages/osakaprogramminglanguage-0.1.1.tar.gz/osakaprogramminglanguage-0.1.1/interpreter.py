# interpreter.py

from ast_nodes import *
import io
import sys


class ReturnSignal(Exception):
    def __init__(self, value, kind):
        self.value = value
        self.kind = kind


class Runtime:
    def __init__(self):
        self.vars = {}
        self.var_kinds = {}
        self.functions = {}
        self.acknowledged = set()
        self.completed = set()
        self.assumed = set()
        self.legacy = set()
        self.warnings = []  # list of warning messages
        self.errors = []    # list of error messages
        self.stdout = io.StringIO()
        self.stderr = io.StringIO()
        self.has_unresolved_grain = False
        self.context_level = 0
        self.execution_traces = []  # store execution traces
        self.initialised = set()    # track initialized variables

    def push_scope(self):
        # Create a new scope by saving current state
        self.vars = self.vars.copy()
        self.var_kinds = self.var_kinds.copy()

    def pop_scope(self):
        # Revert to previous scope (simplified for example)
        pass

    def set_var(self, name, value):
        self.vars[name] = value

    def get_var(self, name):
        return self.vars.get(name, 0)  # default to 0

    def warn(self, message):
        self.warnings.append(message)
        print(f"Warning: {message}", file=sys.stderr)

    def info(self, message):
        print(f"Info: {message}", file=sys.stdout)

    def capture_trace(self, line):
        """Capture current execution state as a trace"""
        trace = {
            "line": line,
            "variables": {k: (v, self.var_kinds.get(k, "grain")) 
                         for k, v in self.vars.items()},
            "warnings": self.warnings.copy(),
            "errors": self.errors.copy(),
            "stdout": self.stdout.getvalue(),
            "stderr": self.stderr.getvalue()
        }
        self.execution_traces.append(trace)


class Interpreter:
    def __init__(self, runtime):
        self.rt = runtime

    def run(self, program):
        # Clear any previous traces
        self.rt.execution_traces = []
        
        for stmt in program:
            # Capture trace before executing statement
            if hasattr(stmt, 'line'):
                current_function = None
                for scope in reversed(self.rt.scopes):
                    if 'function_name' in scope:
                        current_function = scope['function_name']
                        break
                    
                self.rt.capture_trace(
                    line_num=stmt.line,
                    function_name=current_function,
                    expression=stmt.__class__.__name__
                )
            
            self.execute(stmt)
            
            # Capture trace after executing statement
            if hasattr(stmt, 'line'):
                current_function = None
                for scope in reversed(self.rt.scopes):
                    if 'function_name' in scope:
                        current_function = scope['function_name']
                        break
                    
                self.rt.capture_trace(
                    line_num=stmt.line,
                    function_name=current_function,
                    expression=stmt.__class__.__name__
                )

        print(f"\nDiagnostics: {len(self.rt.warnings)} warning(s)")

    # ---------- Top-level dispatcher ----------

    def execute(self, node):
        # Capture trace before executing node
        if hasattr(node, 'line'):
            self.rt.capture_trace(node.line)
        
        # Function definition: just register it
        if isinstance(node, FunctionDef):
            self.rt.functions[node.name] = node
            return

        # Return inside a function
        if isinstance(node, Return):
            value, kind = self.eval(node.expr)
            raise ReturnSignal(value, kind)

        if isinstance(node, Block):
            self.exec_block(node)
        elif isinstance(node, If):
            self.execute_if(node)
        elif isinstance(node, While):
            self.execute_while(node)
        elif isinstance(node, TryCatch):
            self.execute_try_catch(node)
        elif isinstance(node, Assign):
            self.exec_assign(node)
        elif isinstance(node, Call):
            self.call(node)
        elif isinstance(node, Declaration):
            self.exec_declaration(node)
        elif isinstance(node, IndexAssign):
            self.exec_index_assign(node)
        else:
            raise RuntimeError(f"Unknown node type: {type(node)}")

    # ---------- Declarations for Escalator/Elevator (yours) ----------

    def exec_declaration(self, node):
        # Handle Escalator/Elevator declarations
        if node.decl_type == "Escalator":
            self.rt.context_level += 1
            self.rt.info(
                f"Escalator declaration: {node.name} (level {self.rt.context_level})"
            )
        elif node.decl_type == "Elevator":
            self.rt.context_level = max(self.rt.context_level, 5)
            self.rt.info(
                f"Elevator declaration: {node.name} (level {self.rt.context_level})"
            )

    # ---------- Assignment & blocks ----------

    def exec_assign(self, node: Assign):
        name = node.name

        # Legacy protection
        if name in self.rt.legacy:
            self.rt.warn(f"{name} is Ivebeengot (legacy) and cannot be reassigned")
            return

        # Hecho freeze: once completed, cannot change
        if name in self.rt.completed:
            self.rt.warn(f"{name} is Hecho and cannot be reassigned")
            return

        # Ah() is now just a soft requirement
        is_first_assignment = name not in self.rt.initialised

        if not is_first_assignment:
            if name not in self.rt.acknowledged and name not in self.rt.assumed:
                warned = getattr(self.rt, "mutation_warned", set())
                if name not in warned:
                    self.rt.warn(f"{name} mutated without Ah()")
                    warned.add(name)
                    self.rt.mutation_warned = warned

        value, expr_kind = self.eval(node.expr)

        # Handle declaration kind / truth model
        if node.decl_type == "grain":
            kind = "grain"
            self.rt.has_unresolved_grain = True
        elif node.decl_type == "truth":
            kind = "truth"
            self.rt.acknowledged.add(name)  # Auto-acknowledge truth declarations
        else:
            # Plain assignment: keep existing kind if present, else from expression
            existing_kind = self.rt.var_kinds.get(name)
            kind = existing_kind if existing_kind is not None else expr_kind

        self.rt.var_kinds[name] = kind
        self.rt.set_var(name, value)
        self.rt.initialised.add(name)

    def exec_block(self, block: Block):
        self.rt.push_scope()
        try:
            for stmt in block.statements:
                self.execute(stmt)
        finally:
            self.rt.pop_scope()

    # ---------- Control flow: if / while ----------

    def execute_if(self, node: If):
        value, kind = self.eval(node.condition)
        if kind != "truth":
            raise RuntimeError("if-condition must be truthaboutgrain")
        if value:
            self.exec_block(node.body)
        elif getattr(node, "else_body", None) is not None:
            self.exec_block(node.else_body)

    def execute_while(self, node: While):
        while True:
            value, kind = self.eval(node.condition)
            if kind != "truth":
                raise RuntimeError("while-condition must be truthaboutgrain")
            if not value:
                break
            self.exec_block(node.body)

    def execute_try_catch(self, node: TryCatch):
        try:
            self.exec_block(node.try_body)
        except Exception:
            self.exec_block(node.catch_body)

    def exec_index_assign(self, node: IndexAssign):
        # Evaluate container
        container_node = node.container

        if not isinstance(container_node, Variable):
            raise RuntimeError("Can only assign into named collections")

        name = container_node.name

        # Hecho protection
        if name in self.rt.completed:
            self.rt.warn(f"{name} is Hecho and cannot be modified")
            return

        # Ah warning
        if name in self.rt.initialised:
            if name not in self.rt.acknowledged and name not in self.rt.assumed:
                warned = getattr(self.rt, "mutation_warned", set())
                if name not in warned:
                    self.rt.warn(f"{name} mutated without Ah()")
                    warned.add(name)
                    self.rt.mutation_warned = warned

        container_val, container_kind = self.eval(container_node)
        index_val, _ = self.eval(node.index)
        value_val, value_kind = self.eval(node.value)

        try:
            container_val[index_val] = value_val
        except Exception:
            raise RuntimeError("Invalid index assignment")

        # Grain propagation
        if value_kind == "grain":
            self.rt.var_kinds[name] = "grain"

    # ---------- Evaluation (always returns (value, kind)) ----------
    def eval_compare(self, node: Compare):
        left_val, left_kind = self.eval(node.left)
        right_val, right_kind = self.eval(node.right)

        result = {
            "==": left_val == right_val,
            "<": left_val < right_val,
            ">": left_val > right_val,
        }[node.op]

        # truth only if both sides are truth
        kind = "truth" if left_kind == "truth" and right_kind == "truth" else "grain"
        return result, kind

    def eval(self, node):
        if isinstance(node, CallExpr):
            return self.call_function(node)
        
        if isinstance(node, ListLiteral):
            vals = []
            kinds = []

            for elem in node.elements:
                v, k = self.eval(elem)
                vals.append(v)
                kinds.append(k)

            # A list is truth only if ALL elements are truth  
            kind = "truth" if all(k == "truth" for k in kinds) else "grain"
            return vals, kind
        
        if isinstance(node, MapLiteral):
            result = {}
            kinds = []

            for key_node, val_node in node.pairs:
                key, _ = self.eval(key_node)
                val, kind = self.eval(val_node)
                result[key] = val
                kinds.append(kind)

            map_kind = "truth" if all(k == "truth" for k in kinds) else "grain"
            return result, map_kind
        
        if isinstance(node, IndexAccess):
            container_val, container_kind = self.eval(node.container)
            index_val, _ = self.eval(node.index)

            try:
                result = container_val[index_val]
            except Exception:
                raise RuntimeError("Invalid map/list access")

            # element inherits container truth
            return result, container_kind

        if isinstance(node, String):
            return node.value, "truth"

        if isinstance(node, Number):
            # literals are authoritative by default
            if isinstance(node.value, float):
                return node.value, "grain"
            return node.value, "truth"

        if isinstance(node, Variable):
            try:
                value = self.rt.get_var(node.name)
            except RuntimeError:
                self.rt.warn(
                    f"{node.name} used before assignment (defaulting to 0)"
                )
                value = 0
            kind = self.rt.var_kinds.get(node.name, "grain")
            return value, kind

        if isinstance(node, Compare):
            return self.eval_compare(node)

        if isinstance(node, BinaryOp):
            left_val, left_kind = self.eval(node.left)
            right_val, right_kind = self.eval(node.right)
            if node.op == "+":
                if isinstance(left_val, str) or isinstance(right_val, str):
                    result = str(left_val) + str(right_val)
                    # Truth propagation: concatenation is truth only if BOTH sides are truth
                    kind = "truth" if left_kind == "truth" and right_kind == "truth" else "grain"
                    return result, kind
                result = left_val + right_val
                kind = "truth" if left_kind == "truth" and right_kind == "truth" else "grain"
                return result, kind
            if node.op == "/":
                if right_val == 0:
                    raise RuntimeError("division by zero")
                result = left_val / right_val
                kind = "truth" if left_kind == "truth" and right_kind == "truth" else "grain"
                return result, kind
                    
            else:
                raise RuntimeError(f"Unsupported operator {node.op}")

        raise RuntimeError(f"Cannot eval node type: {type(node)}")

    # ---------- Built-in ceremonial calls (Ah, Hecho, etc.) ----------

    def call(self, node: Call):
        name = node.name
        # Ensure args is always treated as a list
        arg_list = node.args if isinstance(node.args, list) else [node.args]

        if name == "SataAndagi":
            self.rt.booted = True
            info = {
                "name": "SATA",
                "version": getattr(self.rt, "version", "1.0"),
                "context": getattr(self.rt, "context_level", 0),
                "warnings": getattr(self.rt, "shame", 0),
            }
            self.rt.last_value = (info, "truth")
            self.rt.info("SataAndagi: runtime booted")
            return

        if name == "Americaya":
            if not arg_list:
                self.rt.warn("Americaya() called without argument")
                return
            val, kind = self.eval(arg_list[0])
            if kind == "grain":
                self.rt.info("Americaya: promoted grainsoftruth to truthaboutgrain")
            self.rt.last_value = (val, "truth")
            return

        if name == "slice":
            x, kx = self.eval(node.args[0])
            a, ka = self.eval(node.args[1])
            b, kb = self.eval(node.args[2])

            if not isinstance(x, (list, str)):
                raise RuntimeError("slice() requires list or string")

            result = x[a:b]
            kind = "truth" if kx == ka == kb == "truth" else "grain"
            return result, kind

        if name == "pop":
            lst_node = node.args[0]

            if not isinstance(lst_node, Variable):
                raise RuntimeError(f"Line {node.line}: pop() requires named list")

            name_var = lst_node.name

            if name_var in self.rt.completed:
                self.rt.warn(f"Line {node.line}: {name_var} is Hecho and cannot be modified")
                return None, self.rt.var_kinds.get(name_var)

            if name_var not in self.rt.acknowledged and name_var not in self.rt.assumed:
                self.rt.warn(f"Line {node.line}: {name_var} mutated without Ah()")
            
            if name_var in self.rt.legacy:
                self.rt.warn(f"{name_var} is Ivebeengot (legacy) and cannot be modified")
                return

            lst, lk = self.eval(lst_node)
            if not isinstance(lst, list):
                raise RuntimeError(f"Line {node.line}: pop() requires list")

            if not lst:
                raise RuntimeError(f"Line {node.line}: pop() on empty list")

            return lst.pop(), lk

        if name == "push":
            lst_node = node.args[0]
            val_node = node.args[1]

            if not isinstance(lst_node, Variable):
                raise RuntimeError(f"Line {node.line}: push() requires named list")

            name_var = lst_node.name

            if name_var in self.rt.completed:
                self.rt.warn(f"Line {node.line}: {name_var} is Hecho and cannot be modified")
                return

            # Standard library mutations do not warn on first change
            if name_var in self.rt.initialised:
                if name_var not in self.rt.acknowledged and name_var not in self.rt.assumed:
                    self.rt.warn(f"Line {node.line}: {name_var} mutated without Ah()")
            
            if name_var in self.rt.legacy:
                self.rt.warn(f"{name_var} is Ivebeengot (legacy) and cannot be modified")
                return None, self.rt.var_kinds.get(name_var, "grain")

            lst, lk = self.eval(lst_node)
            val, vk = self.eval(val_node)

            if not isinstance(lst, list):
                raise RuntimeError(f"Line {node.line}: push() requires list")

            lst.append(val)

            if vk == "grain":
                self.rt.var_kinds[name_var] = "grain"

            return

        if name == "contains":
            m, mk = self.eval(node.args[0])
            k, kk = self.eval(node.args[1])
            if not isinstance(m, dict):
                raise RuntimeError("contains() requires map")
            result = k in m
            kind = "truth" if mk == "truth" and kk == "truth" else "grain"
            return result, kind

        if name == "values":
            if not arg_list:
                self.rt.warn("values() called without argument")
                return
            value, kind = self.eval(arg_list[0])
            if not isinstance(value, dict):
                raise RuntimeError("values() requires map")
            return list(value.values()), kind

        if name == "keys":
            if not arg_list:
                self.rt.warn("keys() called without argument")
                return
            value, kind = self.eval(arg_list[0])
            if not isinstance(value, dict):
                raise RuntimeError("keys() requires map")
            return list(value.keys()), kind

        if name == "len":
            if not arg_list:
                self.rt.warn("len() called without argument")
                return
            value, kind = self.eval(arg_list[0])
            if not isinstance(value, (list, dict, str)):
                raise RuntimeError("len() unsupported type")
            return len(value), kind

        if name == "Say":
            if not arg_list:
                self.rt.warn(f"Line {node.line}: Say() called without argument")
                return

            value, kind = self.eval(arg_list[0])

            if kind == "grain":
                self.rt.warn(f"Line {node.line}: Say() used on grainsoftruth (output may be unreliable)")

            if isinstance(value, list):
                print("[" + ", ".join(str(v) for v in value) + "]", file=self.rt.stdout)
                return
            
            if isinstance(value, dict):
                items = ", ".join(f"{k}: {v}" for k, v in value.items())
                print("{" + items + "}", file=self.rt.stdout)
                return

            print(value, file=self.rt.stdout)
            return

        # --- Ah ---
        if name == "Ah":
            if not arg_list:
                self.rt.warn(f"Line {node.line}: Ah() called without argument")
                return
            if not isinstance(arg_list[0], Variable):
                self.rt.warn(f"Line {node.line}: Ah() requires a variable name")
                return
            var_name = arg_list[0].name
            self.rt.acknowledged.add(var_name)
            self.rt.info(f"Line {node.line}: {var_name} acknowledged")
            return

        # --- Hecho (freeze variable) ---
        if name == "Hecho":
            if not arg_list:
                self.rt.warn(f"Line {node.line}: Hecho called without variable")
                return
            if not isinstance(arg_list[0], Variable):
                self.rt.warn(f"Line {node.line}: Hecho requires a variable name")
                return
            var_name = arg_list[0].name
            try:
                self.rt.get_var(var_name)
            except RuntimeError:
                self.rt.warn(f"Line {node.line}: Hecho on unknown variable {var_name}")
                return

            kind = self.rt.var_kinds.get(var_name)
            if kind == "grain":
                self.rt.info(
                    f"[Advisory] Line {node.line}: Cannot Hecho grainsoftruth variable {var_name}; "
                    f"promote to truthaboutgrain first"
                )
                return

            if var_name in self.rt.completed:
                self.rt.warn(f"Line {node.line}: {var_name} is already Hecho")
                return

            self.rt.completed.add(var_name)
            self.rt.info(f"Line {node.line}: {var_name} marked as Hecho (frozen)")
            return

        # --- Ohmygah (soft error hook, currently just a log) ---
        if name == "Ohmygah":
            if not arg_list:
                self.rt.warn("Ohmygah called without argument")
                return
            if not isinstance(arg_list[0], Variable):
                self.rt.warn("Ohmygah requires a variable name")
                return
            self.rt.warn(f"Ohmygah triggered on {arg_list[0].name} (non-fatal)")
            return

        # --- Getittogether (stabilise system) ---
        if name == "Getittogether":
            # For now, we only mark unresolved grain as "handled".
            # Types remain grain/truth; this just says "we're okay to proceed".
            if self.rt.has_unresolved_grain:
                self.rt.info(
                    "Getittogether: unresolved grainsoftruth acknowledged and stabilised"
                )
                self.rt.has_unresolved_grain = False
            else:
                self.rt.info("Getittogether: nothing pending, system already stable")
            return

        # --- Escalator (stepwise context progression) ---
        if name == "Escalator":
            if self.rt.has_unresolved_grain:
                self.rt.warn(
                    "Cannot Escalator with unresolved grain data; "
                    "call Getittogether first"
                )
                return
            level_label = arg_list[0].name if arg_list else f"level{self.rt.context_level}"
            self.rt.context_level += 1
            self.rt.info(
                f"Escalator: moved to context level {self.rt.context_level} "
                f"({level_label})"
            )
            return

        # --- Elevator (bigger abstraction jump) ---
        if name == "Elevator":
            if self.rt.has_unresolved_grain:
                self.rt.warn(
                    "Cannot Elevator with unresolved grain data; "
                    "call Getittogether first"
                )
                return
            target_label = arg_list[0].name if arg_list else "HIGH"
            self.rt.context_level = max(self.rt.context_level, 5)
            self.rt.info(
                f"Elevator: jumped to high context level {self.rt.context_level} "
                f"({target_label})"
            )
            return
        
        if name == "youknowsealsright":
            if not arg_list:
                self.rt.warn(f"Line {node.line}: youknowsealsright() called without argument")
                return
            if not isinstance(arg_list[0], Variable):
                self.rt.warn(f"Line {node.line}: youknowsealsright() requires a variable name")
                return
            var_name = arg_list[0].name
            self.rt.assumed.add(var_name)
            self.rt.info(f"Line {node.line}: {var_name} marked as assumed (youknowsealsright)")
            return
        
        if name == "Ivebeengot":
            if not arg_list:
                self.rt.warn(f"Line {node.line}: Ivebeengot() called without argument")
                return
            if not isinstance(arg_list[0], Variable):
                self.rt.warn(f"Line {node.line}: Ivebeengot() requires a variable name")
                return
            var_name = arg_list[0].name
            self.rt.legacy.add(var_name)
            self.rt.info(f"Line {node.line}: {var_name} marked as Ivebeengot (legacy)")
            return

        # --- Unknown call ---
        if name in self.rt.functions:
            # Allow user-defined function calls as statements
            self.call_function(CallExpr(name, arg_list, getattr(node, "line", -1)))
            return

        self.rt.warn(f"Unknown function {name}")

    # ---------- User-defined function calls ----------

    def _validate_arg_count(self, call, expected):
        if len(call.args) != expected:
            raise RuntimeError(f"{call.name}() expects {expected} arguments, got {len(call.args)}")

    def call_function(self, call: CallExpr):
        # Handle built-in Say first
        if call.name == "Say":
            if not call.args:
                self.rt.warn("Say() called without argument")
                return None, None
            
            value, kind = self.eval(call.args[0])
            
            if kind == "grain":
                self.rt.warn("Say() used on grainsoftruth (output may be unreliable)")

            if isinstance(value, list):
                print("[" + ", ".join(str(v) for v in value) + "]", file=self.rt.stdout)
            else:
                print(value, file=self.rt.stdout)
            return None, None

        if call.name == "SataAndagi":
            self._validate_arg_count(call, 0)
            self.rt.booted = True
            info = {
                "name": "SATA",
                "version": getattr(self.rt, "version", "1.0"),
                "context": getattr(self.rt, "context_level", 0),
                "warnings": getattr(self.rt, "shame", 0),
            }
            self.rt.info("SataAndagi: runtime booted")
            return info, "truth"

        if call.name == "Americaya":
            self._validate_arg_count(call, 1)
            val, kind = self.eval(call.args[0])
            if kind == "grain":
                self.rt.info("Americaya: promoted grainsoftruth to truthaboutgrain")
            return val, "truth"

        # Handle other built-ins
        builtins = {
            "len": lambda: (self._validate_arg_count(call, 1), (len(self.eval(call.args[0])[0]), "truth"))[1],
            "push": lambda: self._handle_push(call),
            "pop": lambda: self._handle_pop(call),
            "contains": lambda: self._handle_contains(call),
            "keys": lambda: (list(self.eval(call.args[0])[0].keys()), "truth"),
            "values": lambda: (list(self.eval(call.args[0])[0].values()), "truth"),
            "slice": lambda: self._handle_slice(call)
        }
        
        if call.name in builtins:
            return builtins[call.name]()
            
        if call.name not in self.rt.functions:
            raise RuntimeError(f"Undefined function {call.name}")

        fn = self.rt.functions[call.name]

        if len(call.args) != len(fn.params):
            raise RuntimeError(f"Argument count mismatch in {call.name}")

        # Evaluate arguments FIRST and discard their kind.
        # Inside the function, params always start as grainsoftruth.
        arg_values = [self.eval(arg)[0] for arg in call.args]

        # New function scope
        self.rt.push_scope()

        # Bind parameters as grainsoftruth by rule
        for name, value in zip(fn.params, arg_values):
            self.rt.set_var(name, value)
            self.rt.var_kinds[name] = "grain"

        try:
            # Execute function body; we expect a ReturnSignal
            self.execute(fn.body)
            raise RuntimeError(f"Function {call.name} missing return")
        except ReturnSignal as ret:
            self.rt.pop_scope()
            return ret.value, ret.kind

    def _handle_push(self, call):
        self._validate_arg_count(call, 2)
        lst = self.eval(call.args[0])[0]
        value = self.eval(call.args[1])[0]
        lst.append(value)
        return None, None

    def _handle_pop(self, call):
        self._validate_arg_count(call, 1)
        lst = self.eval(call.args[0])[0]
        return lst.pop(), "truth"

    def _handle_contains(self, call):
        self._validate_arg_count(call, 2)
        m = self.eval(call.args[0])[0]
        k = self.eval(call.args[1])[0]
        return k in m, "truth"

    def _handle_slice(self, call):
        self._validate_arg_count(call, 3)
        x = self.eval(call.args[0])[0]
        a = self.eval(call.args[1])[0]
        b = self.eval(call.args[2])[0]
        return x[a:b], "truth"