# pyright: reportShadowedImports=false
# equiv_test.py
#Harness
import io 
import sys
from contextlib import redirect_stdout, redirect_stderr
from dataclasses import dataclass
from typing import Optional

from lexer import lex
from parser import Parser
from runtime import Runtime

# Your existing interpreter (AST)
from interpreter import Interpreter

# Your VM pipeline
from compiler import Compiler
from vm import VM


@dataclass
class RunResult:
    stdout: str
    stderr: str
    diagnostics: list
    traces: list
    error: Optional[str]
    warnings: int


def parse_ast(source: str, show_tokens: bool = False, debug: bool = False):
    tokens = lex(source, show_tokens=show_tokens)
    ast = Parser(tokens, debug=debug).parse()
    return ast


def make_runtime() -> Runtime:
    rt = Runtime()

    # Ensure Stage 6D fields exist (harmless if already present)
    rt.initialised = getattr(rt, "initialised", set())
    rt.acknowledged = getattr(rt, "acknowledged", set())
    rt.assumed = getattr(rt, "assumed", set())
    rt.legacy = getattr(rt, "legacy", set())
    rt.completed = getattr(rt, "completed", set())
    rt.var_kinds = getattr(rt, "var_kinds", {})

    return rt


def run_interpreter(ast, debug=False) -> RunResult:
    rt = make_runtime()
    rt.debug = debug  # Set debug mode
    buf = io.StringIO()
    stderr_buf = io.StringIO()

    err = None
    with redirect_stdout(buf), redirect_stderr(stderr_buf):
        try:
            Interpreter(rt).run(ast)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"

    # Program output comes from Say(...), which writes to rt.stdout.
    # Keep redirected stdout available for parser/debug noise if needed,
    # but return language-program output to callers.
    out = rt.stdout.getvalue()
    stderr_out = stderr_buf.getvalue()
    diagnostics = []
    if hasattr(rt, 'warnings'):
        diagnostics.extend(rt.warnings)
    if hasattr(rt, 'errors'):
        diagnostics.extend(rt.errors)
        
    return RunResult(
        stdout=out,
        stderr=stderr_out,
        diagnostics=diagnostics,
        traces=rt.execution_traces,
        error=err,
        warnings=getattr(rt, "shame", 0)
    )


def run_vm(ast, debug=False) -> RunResult:
    rt = make_runtime()
    rt.debug = debug  # Set debug mode
    buf = io.StringIO()
    stderr_buf = io.StringIO()

    err = None
    with redirect_stdout(buf), redirect_stderr(stderr_buf):
        try:
            bc = Compiler().compile_program(ast)
            vm = VM(rt)
            vm.run(bc)
            # Ensure we get the traces from the VM's runtime
            rt.execution_traces = vm.rt.execution_traces
            # Print diagnostics only if not in debug mode
            if not debug:
                print(f"\nDiagnostics: {rt.shame} warning(s)")
        except Exception as e:
            err = f"{type(e).__name__}: {e}"

    # VM program output is also captured in rt.stdout.
    out = rt.stdout.getvalue()
    stderr_out = stderr_buf.getvalue()
    diagnostics = []
    if hasattr(rt, 'warnings'):
        diagnostics.extend(rt.warnings)
    if hasattr(rt, 'errors'):
        diagnostics.extend(rt.errors)
        
    return RunResult(
        stdout=out,
        stderr=stderr_out,
        diagnostics=diagnostics,
        traces=rt.execution_traces,
        error=err,
        warnings=getattr(rt, "shame", 0)
    )


def show_diff(label_a: str, a: RunResult, label_b: str, b: RunResult):
    print("==== EQUIVALENCE RESULT ====")

    if a.error or b.error:
        print(f"{label_a} error: {a.error}")
        print(f"{label_b} error: {b.error}")
        if a.error == b.error:
            print(" Both errored the same way.")
        else:
            print(" Different errors.")
        return

    ok_out = a.stdout == b.stdout
    ok_warn = a.warnings == b.warnings

    print(f"stdout match: {'✅' if ok_out else '❌'}")
    print(f"warnings match: {'✅' if ok_warn else '❌'}  ({label_a}={a.warnings}, {label_b}={b.warnings})")

    if ok_out and ok_warn:
        print(" VM matches interpreter.")
        return

    # Print small helpful diff
    if not ok_out:
        print("\n---- stdout (interpreter) ----")
        print(a.stdout.rstrip())
        print("\n---- stdout (vm) ----")
        print(b.stdout.rstrip())

        # simple line diff
        a_lines = a.stdout.splitlines()
        b_lines = b.stdout.splitlines()
        maxn = max(len(a_lines), len(b_lines))
        print("\n---- first differing line ----")
        for i in range(maxn):
            aa = a_lines[i] if i < len(a_lines) else "<EOF>"
            bb = b_lines[i] if i < len(b_lines) else "<EOF>"
            if aa != bb:
                print(f"line {i+1}:")
                print(f"  interp: {aa}")
                print(f"  vm    : {bb}")
                break

    if not ok_warn:
        print("\n⚠ Warning counts differ — likely a policy hook mismatch (Ah/assumed/legacy/Hecho or 6D.4).")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 equiv_test.py <file.sata>")
        sys.exit(2)

    path = sys.argv[1]
    src = open(path, "r", encoding="utf-8").read()

    ast = parse_ast(src)

    interp = run_interpreter(ast)
    vm = run_vm(ast)

    show_diff("INTERP", interp, "VM", vm)


if __name__ == "__main__":
    main()
