# parser.py
# pyright: reportShadowedImports=false, reportUnusedVariable=false


from ast_nodes import *

class Parser:
    def __init__(self, tokens, debug=False):
        self.tokens = tokens
        self.pos = 0
        self.debug = debug

    def peek(self):
        if self.pos >= len(self.tokens):
            return ('EOF', '', -1)
        tok = self.tokens[self.pos]
        # Return token as (kind, value, line)
        return (tok[0], tok[1], tok[2] if len(tok) > 2 else -1)

    def consume(self, expected_kind=None):
        if self.pos >= len(self.tokens):
            # Show last 5 tokens when we run out
            last_tokens = self.tokens[max(0, self.pos-5):self.pos] if self.tokens else []
            raise SyntaxError(f"Unexpected end of input at position {self.pos}. Last tokens: {last_tokens}")
        tok = self.tokens[self.pos]
        if expected_kind and tok[0] != expected_kind:
            raise SyntaxError(f"Expected {expected_kind}, got {tok[0]} at position {self.pos}")
        self.pos += 1
        # Return token as (kind, value, line)
        return (tok[0], tok[1], tok[2] if len(tok) > 2 else -1)

    def parse(self):
        statements = []
        while self.pos < len(self.tokens):
            try:
                stmt = self.statement()
                statements.append(stmt)
            except SyntaxError as e:
                # If we're at the end of tokens, break gracefully
                if "Unexpected end of input" in str(e) and self.pos >= len(self.tokens):
                    break
                else:
                    raise
        if self.debug:
            print(f"Parsed {len(statements)} statements")
            for i, stmt in enumerate(statements):
                print(f"Statement {i}: {type(stmt).__name__}")
        return statements
    
    def statement(self):
        token = self.peek()
        kind = token[0]
        value = token[1]

        # Handle function definitions first
        if kind in ("FUNCTION", "FUNC"):
            return self.function_def()
        if kind == "RETURN":
            return self.return_stmt()
        if kind == "TRY":
            return self.try_catch_stmt()

        # Handle index assignment: container[index] = expr;
        if kind == "IDENT":
            save_pos = self.pos
            token = self.consume()
            name = token[1]

            if self.peek()[0] == "LBRACKET":
                self.consume("LBRACKET")
                index_expr = self.expression()
                self.consume("RBRACKET")

                if self.peek()[0] == "EQUAL":
                    self.consume("EQUAL")
                    value_expr = self.expression()
                    if self.peek()[0] == "SEMICOL":
                        self.consume("SEMICOL")
                    return IndexAssign(Variable(name), index_expr, value_expr)

            # rollback if not index assignment
            self.pos = save_pos

        if kind == "IF":
            return self.if_stmt()
        if kind == "WHILE":
            return self.while_stmt()
        if kind == "LBRACE":
            return self.block()
            
        # Function-style keywords (require parentheses)
        if kind in ("AH", "HECHO", "OHMYGAH","YOUKNOWSEALSRIGHT", "IVEBEENGOT"):
            token = self.consume()
            kw_name = token[1]
            line = token[2]  # Capture line number

            # Handle function call syntax: Keyword(Argument)
            token = self.consume()
            lparen_kind = token[0]
            if lparen_kind != "LPAREN":
                raise SyntaxError(f"Expected '(' after {kw_name}")
            
            # Parse argument expression
            arg = self.expression()
            
            token = self.consume()
            rparen_kind = token[0]
            if rparen_kind != "RPAREN":
                raise SyntaxError(f"Expected ')' after argument in {kw_name}")
            
            if self.peek()[0] == "SEMICOL":
                self.consume("SEMICOL")
            return Call(kw_name, [arg], line)  # Pass line number

        # Declaration-style keywords (Escalator/Elevator)
        if kind in ("ESCALATOR", "ELEVATOR"):
            token = self.consume()
            kw_name = token[1]
            
            # Parse identifier name
            token = self.consume()
            ident_kind = token[0]
            ident_value = token[1]
            if ident_kind != "IDENT":
                raise SyntaxError(f"Expected identifier after {kw_name}")
            
            if self.peek()[0] == "SEMICOL":
                self.consume("SEMICOL")
            return Declaration(kw_name, ident_value)

        # Handle Getittogether()
        if kind == "GETITTOGETHER":
            token = self.consume()
            kw_name = token[1]
            line = token[2]  # Capture line number
            self.consume("LPAREN")
            self.consume("RPAREN")
            if self.peek()[0] == "SEMICOL":
                self.consume("SEMICOL")
            return Call(kw_name, [], line)  # Pass line number

        # Declarations with grainsoftruth / truthaboutgrain
        if kind in ("GRAINSOFTRUTH", "TRUTHABOUTGRAIN"):
            decl_kind = kind
            self.consume()  # keyword

            token = self.consume()
            name = token[1]
            line = token[2] if len(token) > 2 else -1
            self.consume("EQUAL")
            expr = self.expression()
            if self.peek()[0] == "SEMICOL":
                self.consume("SEMICOL")

            decl_type = "grain" if decl_kind == "GRAINSOFTRUTH" else "truth"
            return Assign(name, expr, decl_type, line=line)

        # Handle regular function calls (e.g., Say(h);)
        if kind == "IDENT":
            next_pos = self.pos + 1
            if next_pos < len(self.tokens) and self.tokens[next_pos][0] == "LPAREN":
                token = self.consume()
                func_name = token[1]
                line = token[2]  # Capture line number
                self.consume("LPAREN")
                args = []
                # Parse arguments
                while self.peek()[0] != "RPAREN":
                    args.append(self.expression())
                    if self.peek()[0] == "COMMA":
                        self.consume("COMMA")
                self.consume("RPAREN")
                if self.peek()[0] == "SEMICOL":
                    self.consume("SEMICOL")
                return Call(func_name, args, line)

        # Plain assignment: x = expr;
        token = self.consume()
        name = token[1]
        line = token[2] if len(token) > 2 else -1
        self.consume("EQUAL")
        expr = self.expression()
        if self.peek()[0] == "SEMICOL":
            self.consume("SEMICOL")
        return Assign(name, expr, line=line)
    
    def expression(self):
        if self.peek()[0] == 'EOF':
            return None
        
        left = self.addition()
        if self.pos < len(self.tokens) and self.peek()[0] in ("EQEQ", "LT", "GT"):
            op_tok = self.consume()
            op = op_tok[1]
            right = self.addition()
            line = op_tok[2] if len(op_tok) > 2 else -1
            return Compare(left, op, right, line=line)
        return left
    
    def function_def(self):
        # Consume FUNCTION/FUNC token
        if self.peek()[0] in ("FUNCTION", "FUNC"):
            self.consume()
        
        token = self.consume()        # function name (IDENT)
        name = token[1]
        self.consume("LPAREN")

        params = []
        # Parse parameters
        if self.peek()[0] == "IDENT":
            token = self.consume()   # IDENT
            param = token[1]
            params.append(param)

        # Parse additional comma-separated parameters
        while self.peek()[0] == "COMMA":
            self.consume("COMMA")
            if self.peek()[0] == "IDENT":
                token = self.consume()   # IDENT
                param = token[1]
                params.append(param)

        self.consume("RPAREN")
        body = self.block()
        return FunctionDef(name, params, body)
    
    def return_stmt(self):
        self.consume("RETURN")
        expr = self.expression()
        
        # Only consume semicolon if it's present
        if self.peek()[0] == "SEMICOL":
            self.consume("SEMICOL")
            
        return Return(expr)

    def term(self):
        if self.peek()[0] == 'EOF':
            return None
            
        token = self.consume()
        kind, value, line = token[0], token[1], token[2] if len(token) > 2 else -1

        if kind == "STRING":
            return String(value.strip('"'), line)
        
        if kind == "LBRACKET":
            elements = []
            # Empty list
            if self.peek()[0] == "RBRACKET":
                self.consume()
                return ListLiteral(elements, line)

            # Parse elements
            while True:
                elements.append(self.expression())
                if self.peek()[0] == "COMMA":
                    self.consume()
                    continue
                break

            self.consume("RBRACKET")
            return ListLiteral(elements, line)
        
        elif kind == "LBRACE":
            pairs = []

            # Empty map
            if self.peek()[0] == "RBRACE":
                self.consume("RBRACE")
                return MapLiteral(pairs, line)
            else:
                while True:
                    # Key must be STRING
                    key_token = self.consume()
                    key_kind, key_val, key_line = key_token[0], key_token[1], key_token[2] if len(key_token) > 2 else -1
                    if key_kind != "STRING":
                        raise SyntaxError("Map keys must be string literals")

                    self.consume("COLON")
                    value_expr = self.expression()
                    pairs.append((String(key_val.strip('"'), key_line), value_expr))

                    if self.peek()[0] == "COMMA":
                        self.consume("COMMA")
                        continue
                    break

                self.consume("RBRACE")
                return MapLiteral(pairs, line)

        if kind == "FLOAT":
            return Number(float(value), line)

        if kind == "NUMBER":
            return Number(int(value), line)

        if kind == "IDENT":
            # Function call: foo(...)
            if self.pos < len(self.tokens) and self.peek()[0] == "LPAREN":
                self.consume("LPAREN")
                args = []
                while self.peek()[0] != "RPAREN":
                    args.append(self.expression())
                    if self.peek()[0] == "COMMA":
                        self.consume("COMMA")
                self.consume("RPAREN")
                node = CallExpr(value, args, line)
            else:
                node = Variable(value, line)
        else:
            node = self.simple_term()
        
        # Handle index accesses as postfix operations
        while self.pos < len(self.tokens) and self.peek()[0] == "LBRACKET":
            self.consume("LBRACKET")
            index_expr = self.expression()
            self.consume("RBRACKET")
            node = IndexAccess(node, index_expr, line)
            
        return node
    
    def simple_term(self):
        token = self.consume()
        kind, value, line = token[0], token[1], token[2] if len(token) > 2 else -1
        if kind == "STRING":
            return String(value.strip('"'), line)
        if kind == "FLOAT":
            return Number(float(value), line)
        if kind == "NUMBER":
            return Number(int(value), line)
        if kind == "IDENT":
            # Check for function calls
            if self.pos < len(self.tokens) and self.peek()[0] == "LPAREN":
                self.consume("LPAREN")
                args = []
                while self.peek()[0] != "RPAREN":
                    args.append(self.expression())
                    if self.peek()[0] == "COMMA":
                        self.consume("COMMA")
                self.consume("RPAREN")
                return CallExpr(value, args, line)
            return Variable(value, line)
        raise SyntaxError(f"Unexpected token: {kind}")

    def addition(self):
        left = self.term()
        while self.pos < len(self.tokens) and self.peek()[0] in ("PLUS", "SLASH"):
            op_tok = self.consume()
            op = "+" if op_tok[0] == "PLUS" else "/"
            right = self.term()
            left = BinaryOp(left, op, right)
        return left
    
    def block(self):
        self.consume("LBRACE")
        statements = []
        while self.pos < len(self.tokens) and self.peek()[0] != "RBRACE":
            statements.append(self.statement())
        self.consume("RBRACE")
        return Block(statements)

    def if_stmt(self):
        tok = self.consume("IF")
        line = tok[2] if len(tok) > 2 else -1
        # Allow both parenthesized and non-parenthesized conditions
        if self.peek()[0] == "LPAREN":
            self.consume("LPAREN")
            condition = self.expression()
            self.consume("RPAREN")
        else:
            condition = self.expression()
        body = self.block()
        else_body = None
        if self.pos < len(self.tokens) and self.peek()[0] == "ELSE":
            self.consume("ELSE")
            else_body = self.block()
        return If(condition, body, else_body, line=line)

    def while_stmt(self):
        tok = self.consume("WHILE")
        line = tok[2] if len(tok) > 2 else -1
        # Allow both parenthesized and non-parenthesized conditions
        if self.peek()[0] == "LPAREN":
            self.consume("LPAREN")
            condition = self.expression()
            self.consume("RPAREN")
        else:
            condition = self.expression()
        body = self.block()
        return While(condition, body, line=line)

    def try_catch_stmt(self):
        tok = self.consume("TRY")
        line = tok[2] if len(tok) > 2 else -1
        try_body = self.block()
        self.consume("CATCH")
        catch_body = self.block()
        return TryCatch(try_body, catch_body, line=line)