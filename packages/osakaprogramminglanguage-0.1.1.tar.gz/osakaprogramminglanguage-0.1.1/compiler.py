# compiler.py
from typing import List, Tuple, Any
from bytecode import (
    BytecodeProgram, Value, 
    PUSH_CONST, LOAD_VAR, STORE_VAR, ADD, DIV,
    MAKE_LIST, MAKE_MAP, INDEX_GET, INDEX_SET,
    CALL_BUILTIN, HALT,
    JMP, JMP_IF_FALSE,
    CMP_EQ, CMP_LT, CMP_GT,
    CALL_FUNC, RET, TRACE_POINT, TRY_PUSH, TRY_POP,
    FunctionBytecode,
)

# Import your AST node classes
from ast_nodes import (
    Number, String, Variable, BinaryOp,
    ListLiteral, MapLiteral, IndexAccess,
    Assign, Call, IndexAssign, CallExpr,
    If, While, Block, Compare, FunctionDef, Return, TryCatch,
)

class Compiler:
    def __init__(self, debug=False):
        self.debug = debug
        self.consts: List[Value] = []
        self.code: List[Tuple[str, Any]] = []
        self.functions = {}   # name -> FunctionBytecode
        self.function_table = {}  # Add function table for verification



    def add_const(self, data, kind="truth") -> int:
        self.consts.append(Value(data, kind))
        return len(self.consts) - 1

    def emit(self, op, arg=None, line=-1):
        self.code.append((op, arg, line))

    def compile(self, program) -> BytecodeProgram:
        return self.compile_program(program)
        
    def compile_program(self, program) -> BytecodeProgram:
        # First pass: compile all function definitions
        self.code = []
        for stmt in program:
            if isinstance(stmt, FunctionDef):
                self.compile_function_def(stmt)
                
        # Second pass: compile other statements into one contiguous main stream
        for stmt in program:
            if not isinstance(stmt, FunctionDef):
                line = getattr(stmt, "line", -1)
                if line != -1:
                    self.emit(TRACE_POINT, None, line)
                self.compile_stmt(stmt)
                if line != -1:
                    self.emit(TRACE_POINT, None, line)
        main_code = self.code.copy()
                
        # Create BytecodeProgram with main code as executable code
        return BytecodeProgram(
            consts=self.consts,
            code=main_code,
            functions=self.functions,
            main=main_code
        )
        
    def compile_function_def(self, node):
        if self.debug:
            print(f"Compiling function: {node.name}")
        # Create sub-compiler for function body
        sub_compiler = Compiler()
        
        # Declare parameters as local variables
        for param in node.params:
            sub_compiler.emit(STORE_VAR, param)
            
        # Compile function body
        sub_compiler.compile_stmt(node.body)
        
        # Add return if missing
        if not sub_compiler.code or sub_compiler.code[-1][0] != RET:
            sub_compiler.emit(RET, None)
            
        # Create function bytecode
        func_program = BytecodeProgram(
            sub_compiler.consts, 
            sub_compiler.code, 
            {}
        )
        
        # Add to functions dictionary
        self.functions[node.name] = FunctionBytecode(
            params=node.params,
            program=func_program
        )
        
        # Add to function table for verification
        self.function_table[node.name] = {
            "params": node.params,
            "return_type": None  # Placeholder for actual type system
        }
        
        print(f"Added function: {node.name} with {len(node.params)} parameters")
    
    def emit_placeholder(self, op):
            """Emit jump with placeholder operand, return index to patch later."""
            self.code.append((op, None, -1))
            return len(self.code) - 1

    def patch(self, instr_index, target_ip):
            op, _, line = self.code[instr_index]
            self.code[instr_index] = (op, target_ip, line)


    # ---------- statements ----------
    def compile_stmt(self, node):
        # Trace point for interpreter's execute() pre-node capture
        line = getattr(node, "line", -1)
        if line != -1:
            self.emit(TRACE_POINT, None, line)
        if isinstance(node, Assign):
            # Compile the expression
            self.compile_expr(node.expr)
            # Assignment kind: if decl_type indicates grain/truth, force kind here
            if node.decl_type == "grain":
                # force top-of-stack kind to grain
                self.emit(CALL_BUILTIN, ("__force_kind_grain__", 1))
            elif node.decl_type == "truth":
                self.emit(CALL_BUILTIN, ("__force_kind_truth__", 1))
            self.emit(STORE_VAR, node.name)
            return
        
        if isinstance(node, Assign):
            # Compile function body in its own compiler instance
            sub = Compiler()
            sub.compile_stmt(node.body)
            sub.emit(RET, None)  # implicit ret if missing; can make error later

            fn_prog = BytecodeProgram(sub.consts, sub.code, sub.functions)
            self.functions[node.name] = FunctionBytecode(node.params, fn_prog)
            return
        
        if isinstance(node, Return):
            self.compile_expr(node.expr)
            self.emit(RET, None)
            return


        if isinstance(node, IndexAssign):
            # container must be Variable by your parser rule
            base = node.container.name
            self.emit(LOAD_VAR, base)
            self.compile_expr(node.index)
            self.compile_expr(node.value)
            self.emit(INDEX_SET, base)
            return
        
        if isinstance(node, Block):
            self.emit(CALL_BUILTIN, ("__push_scope__", 0), getattr(node, "line", -1))
            for s in node.statements:
                self.compile_stmt(s)
            self.emit(CALL_BUILTIN, ("__pop_scope__", 0), getattr(node, "line", -1))
            return
        
        if isinstance(node, If):
            # condition -> stack
            self.compile_expr(node.condition)
            # Convert truth to truthaboutgrain
            self.emit(CALL_BUILTIN, ("__to_truthaboutgrain__", 1))

            # if false, jump to end of body
            jmp_false_ix = self.emit_placeholder(JMP_IF_FALSE)

            # body
            self.compile_stmt(node.body)

            # Optional else body
            if getattr(node, "else_body", None) is not None:
                jmp_end_ix = self.emit_placeholder(JMP)
                self.patch(jmp_false_ix, len(self.code))
                self.compile_stmt(node.else_body)
                self.patch(jmp_end_ix, len(self.code))
            else:
                # patch jump target to here
                self.patch(jmp_false_ix, len(self.code))
            return
        
        if isinstance(node, While):
            loop_start = len(self.code)

            self.compile_expr(node.condition)
            # Convert truth to truthaboutgrain
            self.emit(CALL_BUILTIN, ("__to_truthaboutgrain__", 1))
            jmp_false_ix = self.emit_placeholder(JMP_IF_FALSE)

            self.compile_stmt(node.body)

            # jump back to start
            self.emit(JMP, loop_start)

            # patch exit
            self.patch(jmp_false_ix, len(self.code))
            return

        if isinstance(node, TryCatch):
            # TRY_PUSH points to catch block start
            try_push_ix = self.emit_placeholder(TRY_PUSH)
            self.compile_stmt(node.try_body)
            self.emit(TRY_POP, None)
            jmp_end_ix = self.emit_placeholder(JMP)

            catch_start = len(self.code)
            self.patch(try_push_ix, catch_start)
            self.compile_stmt(node.catch_body)
            self.patch(jmp_end_ix, len(self.code))
            return

        # Handle expression statements
        try:
            self.compile_expr(node)
            return
        except RuntimeError:
            pass  # Not an expression, continue to error below



        if isinstance(node, FunctionDef):
            # Compile function body
            saved_code = self.code
            self.code = []
            
            # Declare parameters as local variables
            for param in node.params:
                self.emit(STORE_VAR, param)
                
            # Compile function body
            self.compile_stmt(node.body)
            
            # Create function bytecode
            func_code = self.code.copy()
            self.code = saved_code  # Restore original code
            
            # Add to functions dictionary
            self.functions[node.name] = FunctionBytecode(
                params=node.params,
                program=BytecodeProgram(consts=self.consts.copy(), code=func_code)
            )
            return

        if isinstance(node, Call):
            # Strictly allow only these built-in functions as statements
            BUILTIN_STATEMENT_FUNCS = {
                "Say", "Ah", "Hecho", "youknowsealsright", 
                "Ivebeengot", "Getittogether", "push", "pop",
                "SataAndagi", "Americaya"
            }

            POLICY_NAME_FUNCS = {"Ah", "Hecho", "youknowsealsright", "Ivebeengot"}
            
            if node.name not in BUILTIN_STATEMENT_FUNCS:
                # Allow user-defined function calls in statement position.
                # Return value (if any) is ignored by the source program.
                for a in reversed(node.args):
                    self.compile_expr(a)
                self.emit(CALL_FUNC, (node.name, len(node.args)), node.line)
                return
            
            # Compile arguments
            for arg in node.args:
                if node.name in POLICY_NAME_FUNCS and isinstance(arg, Variable):
                    const_index = self.add_const(arg.name, "truth")
                    self.emit(PUSH_CONST, const_index, node.line)
                else:
                    self.compile_expr(arg)
            
            # Emit CALL_BUILTIN for built-in statement functions
            self.emit(CALL_BUILTIN, (node.name, len(node.args)), node.line)
            return

        raise RuntimeError(f"Compiler: unsupported stmt {type(node)}")

    # ---------- expressions ----------
    def compile_expr(self, node):
        if isinstance(node, CallExpr):
            # Define built-in names first
            BUILTIN_NAMES = {
                "Say", "len", "keys", "values", "contains", "slice",
                "push", "pop",
                "Ah", "Hecho", "youknowsealsright", "Ivebeengot",
                "SataAndagi", "Americaya",
                "__force_kind_grain__", "__force_kind_truth__",
            }

            # Validate argument count for user-defined functions
            if node.name not in BUILTIN_NAMES and node.name in self.functions:
                expected_args = len(self.functions[node.name].params)
                if len(node.args) != expected_args:
                    raise RuntimeError(f"Function '{node.name}' expects {expected_args} arguments, got {len(node.args)}")

            # Compile args in reverse order (right-to-left)
            # to ensure leftmost argument is at top of stack
            for a in reversed(node.args):
                self.compile_expr(a)

            # Debug: print function call
            print(f"Emitting call to {node.name} with {len(node.args)} arguments")
            
            if node.name in BUILTIN_NAMES:
                self.emit(CALL_BUILTIN, (node.name, len(node.args)), node.line)
            else:
                self.emit(CALL_FUNC, (node.name, len(node.args)), node.line)
            return


        if isinstance(node, Number):
            kind = "grain" if isinstance(node.value, float) else "truth"
            ci = self.add_const(node.value, kind)
            self.emit(PUSH_CONST, ci, node.line)
            return

        if isinstance(node, String):
            ci = self.add_const(node.value, "truth")
            self.emit(PUSH_CONST, ci, node.line)
            return

        if isinstance(node, Variable):
            self.emit(LOAD_VAR, node.name, node.line)
            return

        if isinstance(node, BinaryOp):
            self.compile_expr(node.left)
            self.compile_expr(node.right)
            if node.op == "+":
                self.emit(ADD, None, node.line)
                return
            if node.op == "/":
                self.emit(DIV, None, node.line)
                return
            raise RuntimeError(f"Compiler: unsupported op {node.op}")

        if isinstance(node, Compare):
            self.compile_expr(node.left)
            self.compile_expr(node.right)
            if node.op == "==":
                self.emit(CMP_EQ, None, node.line)
            elif node.op == "<":
                self.emit(CMP_LT, None, node.line)
            elif node.op == ">":
                self.emit(CMP_GT, None, node.line)
            else:
                raise RuntimeError(f"Compiler: unsupported compare {node.op}")
            return

        if isinstance(node, ListLiteral):
            for e in node.elements:
                self.compile_expr(e)
            self.emit(MAKE_LIST, len(node.elements), node.line)
            return

        if isinstance(node, MapLiteral):
            # Push key then value for each pair
            for key_node, val_node in node.pairs:
                # keys are String nodes already in your parser
                self.compile_expr(key_node)
                self.compile_expr(val_node)
            self.emit(MAKE_MAP, len(node.pairs), node.line)
            return

        if isinstance(node, IndexAccess):
            self.compile_expr(node.container)
            self.compile_expr(node.index)
            self.emit(INDEX_GET, None, node.line)
            return

        raise RuntimeError(f"Compiler: unsupported expr {type(node)}")
