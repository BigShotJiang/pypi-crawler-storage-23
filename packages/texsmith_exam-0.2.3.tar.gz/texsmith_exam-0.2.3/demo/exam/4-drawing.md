# Drawing { points=5 }

Draw a sheep in the box:

!!! solution { box=50 }

    ![Sheep](assets/sheep.svg){ width=50% }

---
