

# AdvancedAnalysisFileParser

![PyPI version](https://img.shields.io/pypi/v/AdvancedAnalysisFileParser.svg?label=PyPI%20version)

A Python package to parse Illumina-DRAGEN "special caller" outputs (TSV/JSON) into a unified JSON format, with automatic warnings based on user-defined or default conditions. Supports oncology, GBA, SMN, HBA, and more.

---

## Features

- Unified JSON output for multiple DRAGEN caller types (TSV/JSON)
- Automatic warnings for each file type, based on config or defaults
- Pluggable parser architecture for new file types
- CLI and Python API usage
- Example configs and test data included

---

## Installation

Install from PyPI (recommended):

```bash
pip install AdvancedAnalysisFileParser
```

Or from source:

```bash
git clone https://github.com/geneyx/geneyx.analysis.api.git
cd geneyx.analysis.api/scripts/AdvancedAnalysisFileParser
pip install -e .
```

---

## Quickstart

### Python API Usage

```python
from AdvancedAnalysisFileParser.AdvancedAnalysisParser import AdvancedAnalysisParser

request = {
		"input_dir": "./Test",
		"output_dir": "./Test",
		"output_json": "adv_output.json",
		# Optionally, you can specify input_files or map_files for custom configs
}
parser = AdvancedAnalysisParser(request)
parser.run()  # writes output to adv_output.json

# Or get result as dict:
result = parser.run(return_dict=True)
print(result)
```

### Command-Line Usage

Create a config file (e.g. `config.json`):

```json
{
	"input_dir": "./Test",
	"output_dir": "./Test",
	"output_json": "adv_output.json"
}
```

Then run:

```bash
python -m AdvancedAnalysisFileParser.AdvancedAnalysisParser -c config.json
```

---

## Configuration

The parser uses config files (JSON) to define how to parse and warn for each file type. Default configs are provided for:

- GBA: `gba_tsv_config.json`
- SMN: `smn_tsv_config.json`
- Oncology: `dragen_500_tsv_config.json`
- JSON: `advConfig.json`

You can override or extend these by providing your own config in the `map_files` key of the request.

### Example request/config structure

| Key           | Type   | Description                                                           |
| ------------- | ------ | --------------------------------------------------------------------- |
| `output_json` | string | Filename for the generated JSON (default: `adv_analysis_output.json`) |
| `input_dir`   | string | Directory containing all input files                                  |
| `input_files` | list   | (Optional) List of files to parse                                     |
| `map_files`   | object | (Optional) Mapping of filenames → caller definitions                  |

---

## Warnings

Warnings are generated automatically for each caller/file type, based on the config. Each config defines conditions for warnings (see `*_config.json` files for examples). You can customize these for your use case.

---

## Testing

Run the test suite to validate all parsing and warning logic:

```bash
pytest AdvancedAnalysisFileParser/Test_AdvancedAnalysisParser.py
```

Or run the test script:

```bash
python AdvancedAnalysisFileParser/run_test_parser.py
```

---

## Example Data

See the `Test/` folder for example input files (TSV/JSON) and expected outputs.

---

## License

MIT
