import json
from .IAdvancedAnalysisFileParser import IAdvancedAnalysisFileParser
from ..Models import JsonDict
class JsonSectionParser(IAdvancedAnalysisFileParser):
    """
    Parse JSON files with a specific section into a unified format.
    The section is specified by the 'json_key' or 'caller_key' in the config.
    """
    def parse(self) -> JsonDict:
        data = JsonSectionParser._load_json(self.file_path)
        result = {}
        import logging
        # Build a mapping of lowercased data keys to actual keys
        data_key_map = {k.lower(): k for k in data.keys()}
        for key in self.section_config.keys():
            caller_data = {}
            key_lc = key.lower()
            if key_lc in data_key_map:
                actual_key = data_key_map[key_lc]
                section = data.get(actual_key, {})
                if section == {}:
                    logging.warning(f"Section '{key}' is empty in the input data.")
                for k, value in section.items():
                    if k == 'variants':
                        variant_list = []
                        for index, var in enumerate(value):
                            variant_list.append(IAdvancedAnalysisFileParser._format_value(var))
                        caller_data[k] = variant_list
                    else:
                        caller_data[k] = IAdvancedAnalysisFileParser._format_value(value)
            else:
                logging.warning(f"Key '{key}' from config not found in input data. Skipping.")
            result[key] = caller_data
        return result

    @staticmethod
    def _load_json(path: str) -> JsonDict:
        with open(path, 'r') as f:
            return json.load(f)