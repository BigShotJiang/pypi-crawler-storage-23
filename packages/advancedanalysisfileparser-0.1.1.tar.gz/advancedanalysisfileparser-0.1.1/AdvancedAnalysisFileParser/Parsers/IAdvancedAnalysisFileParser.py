from abc import ABC, abstractmethod
import os
from pathlib import Path
from typing import Any

from ..Warnings import IWarning

from AdvancedAnalysisFileParser.AdvancedAnalysisConstants import AdvancedAnalysisConstants
from AdvancedAnalysisFileParser.Warnings.WarningFactory import WarningFactory
from ..Models import JsonDict
class IAdvancedAnalysisFileParser(ABC):
    section_config : JsonDict
    file_config : JsonDict
    def __init__(self,section_config: JsonDict, file_path: str) -> None:
        """
        Initialize a file parser for advanced analysis.

        Args:
            section_config (JsonDict): Section configuration for parsing.
            file_path (str): Path to the file to parse (must be .json or .tsv).

        Raises:
            ValueError: If file_path is empty or not a string.
            FileNotFoundError: If the file does not exist.
        """
        self.section_config = section_config    
        if not file_path:
            raise ValueError("Filename cannot be empty")
        if not isinstance(file_path, str):
            raise TypeError(f"Filename must be a string, got {type(filename).__name__}")
        if not file_path.lower().endswith(('.json', '.tsv')):
            raise ValueError("Filename must be in lowercase")
        #check if the file exists on path
        if not os.path.exists(file_path):
            base = Path(__file__).resolve().parent.parent
            file_path = os.path.join(base, file_path)
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
        self.file_path: str = file_path
        
    @abstractmethod
    def parse(self) -> JsonDict:
        """
        Parse the file and return its data as a JsonDict.

        Returns:
            JsonDict: Parsed data from the file.
        """
        pass
    
    def build_result(self,data: JsonDict) -> JsonDict:
        """
        Build a result dictionary from parsed data and section config.

        Args:
            data (JsonDict): Parsed data from the file.

        Returns:
            JsonDict: Result dictionary with formatted values and warnings.
        """
        result: JsonDict = {}
        for caller_name, caller_config in self.section_config.items():
            caller_title = caller_config.get("caller_name", None)
            fields = caller_config.get("fields", None)
            fields = {k: v for k, v in fields.items()} if isinstance(fields, dict) else fields
            caller_data = data.get(caller_name, {})
            if fields is None:
                caller_warning = caller_config.get(AdvancedAnalysisConstants.WARNING_KEY, None)
                if caller_warning:
                    warning_formatter: IWarning = WarningFactory.get_formatter(caller_warning)
                    warning_text = warning_formatter.format(caller_warning, caller_data)
                    if result.get(caller_name.upper()) is None:
                        result[caller_name.upper()] = {"data": {}, "warning": {}}
                    result[caller_name.upper()]["caller_name"] = caller_title
                    result[caller_name.upper()]["data"] = caller_data
                    result[caller_name.upper()]["warning"] = warning_text
                else:
                    if result.get(caller_name.upper()) is None:
                        result[caller_name.upper()] = {"data": {}}
                    result[caller_name.upper()]["caller_name"] = caller_title
                    result[caller_name.upper()]["data"] = caller_data
        return result


    @staticmethod
    def _format_value(v: Any) -> Any:
        if isinstance(v, dict):
            return {k: IAdvancedAnalysisFileParser._format_value(v) for k, v in v.items()}
        if isinstance(v, list):
            clean = [IAdvancedAnalysisFileParser._format_value(x) for x in v if x not in ("", None)]
            return clean or None
        if isinstance(v, str):
            low = v.lower()
            if low == "true":
                return True
            if low == "false":
                return False
            if low in ("none", "null", ""):
                return None
            try:
                return int(v)
            except ValueError:
                pass
            try:
                return round(float(v), 2)
            except ValueError:
                return v
        if isinstance(v, float):
            return round(v, 2)
        #if isinstance(v, bool):
        #if isinstance(v, int):
        return v