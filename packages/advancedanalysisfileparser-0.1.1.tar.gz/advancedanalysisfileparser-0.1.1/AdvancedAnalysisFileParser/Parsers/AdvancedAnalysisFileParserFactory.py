from .IAdvancedAnalysisFileParser import IAdvancedAnalysisFileParser
from .DragenTruSightOncology500TSVParser import DragenTruSightOncology500TSVParser
from .OneLineTsvParser import OneLineTsvParser
from .JsonSectionParser import JsonSectionParser
from ..Models import JsonDict
class AdvancedAnalysisFileParserFactory:
    """
    Returns the correct IParser implementation based on file path.
    """
    @staticmethod
    def get_parser( file_path: str) -> IAdvancedAnalysisFileParser:
        import importlib.resources
        import json
        lower = file_path.lower()
        section_config = {}
        try:
            if lower.endswith(".tsv"):
                if lower.endswith("combinedvariantoutput.tsv"):
                    with importlib.resources.files('AdvancedAnalysisFileParser').joinpath('dragen_500_tsv_config.json').open('r', encoding='utf-8') as f:
                        section_config = json.load(f)
                    return DragenTruSightOncology500TSVParser(section_config, file_path)
                if lower.endswith("smn.tsv"):
                    with importlib.resources.files('AdvancedAnalysisFileParser').joinpath('smn_tsv_config.json').open('r', encoding='utf-8') as f:
                        section_config = json.load(f)
                    return OneLineTsvParser(section_config, file_path)
                if lower.endswith("gba.tsv"):
                    with importlib.resources.files('AdvancedAnalysisFileParser').joinpath('gba_tsv_config.json').open('r', encoding='utf-8') as f:
                        section_config = json.load(f)
                    return OneLineTsvParser(section_config, file_path)       
            if lower.endswith(".json"):
                with importlib.resources.files('AdvancedAnalysisFileParser').joinpath('advConfig.json').open('r', encoding='utf-8') as f:
                    section_config = json.load(f)
                return JsonSectionParser(section_config, file_path)
        except Exception as e:
            raise RuntimeError(f"Failed to load config for {file_path}: {e}")
        raise ValueError(f"Unsupported file type: {file_path}")
