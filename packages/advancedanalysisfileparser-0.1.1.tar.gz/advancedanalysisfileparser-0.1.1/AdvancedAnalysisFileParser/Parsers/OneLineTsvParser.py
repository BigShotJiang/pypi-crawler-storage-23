from typing import Any
from .IAdvancedAnalysisFileParser import IAdvancedAnalysisFileParser
from ..Models import JsonDict
# --- Parser Implementations ---
class OneLineTsvParser(IAdvancedAnalysisFileParser):
    is_tsv_parser = True

    def parse(self) -> JsonDict:
        with open(self.file_path, 'r') as f:
            headers = f.readline().strip().split('\t')
            values = f.readline().strip().split('\t')
        parsed = {h: IAdvancedAnalysisFileParser._format_value(v) for h, v in zip(headers, values)}

        # Find the caller name from config (should match the file type, e.g., 'GBA' or 'SMN1')
        import os
        caller_name = None
        filename_base = os.path.splitext(os.path.basename(self.file_path))[0].lower()
        for key in self.section_config.keys():
            if filename_base == key.lower():
                caller_name = key
                break
        if not caller_name:
            caller_name = next(iter(self.section_config.keys()))

        # Only return parsed data under caller name
        return {caller_name: parsed}
