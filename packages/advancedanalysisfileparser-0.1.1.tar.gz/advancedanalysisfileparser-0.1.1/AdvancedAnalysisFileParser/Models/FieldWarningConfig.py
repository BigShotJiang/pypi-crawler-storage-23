from typing import Optional
from .FieldCondition import FieldCondition
class FieldWarningConfig:
    warning: Optional[FieldCondition] = None