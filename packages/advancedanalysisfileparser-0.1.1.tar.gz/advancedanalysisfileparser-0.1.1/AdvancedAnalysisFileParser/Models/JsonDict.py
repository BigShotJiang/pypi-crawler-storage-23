from typing import Any, Dict
JsonDict = Dict[str, Any]