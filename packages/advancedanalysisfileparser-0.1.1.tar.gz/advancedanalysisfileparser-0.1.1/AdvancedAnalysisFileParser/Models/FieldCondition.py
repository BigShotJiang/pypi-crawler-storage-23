from typing import Any, Callable,Dict,Optional
from .ConditionOperator import ConditionOperator

class FieldCondition:
    def __init__(self, operator: ConditionOperator, value: Any, message: str, field: Optional[str] = None):
        """
        Create a condition to check a field value against a target value using an operator.

        Args:
            operator (ConditionOperator): The comparison operator (e.g., EQ, GT, CONTAINS).
            value (Any): The value to compare against.
            message (str): Message to return if the condition is met.
            field (Optional[str]): Name of the field to check (optional, for context).
        """
        self.operator = operator
        self.value = value
        self.message = message

    def check(self, value: Any) -> bool:
        """
        Check if the provided value satisfies the condition.

        Args:
            value (Any): The value to check.

        Returns:
            bool: True if the condition is met, False otherwise.
        """
        func = OPERATOR_FUNCS[self.operator]
        return func(value, self.value)

    def __str__(self) -> str:
        """
        Return the message associated with this condition.

        Returns:
            str: The message string.
        """
        return self.message

# map each operator to a function that compares (field_value, target_value) → bool
OPERATOR_FUNCS: Dict[ConditionOperator, Callable[[Any, Any], bool]] = {
    ConditionOperator.EQ:       lambda a, b: a == b,
    ConditionOperator.NE:       lambda a, b: a != b,
    ConditionOperator.GT:       lambda a, b: isinstance(a, (int, float)) and a > b,
    ConditionOperator.LT:       lambda a, b: isinstance(a, (int, float)) and a < b,
    ConditionOperator.GE:       lambda a, b: isinstance(a, (int, float)) and a >= b,
    ConditionOperator.LE:       lambda a, b: isinstance(a, (int, float)) and a <= b,
    ConditionOperator.CONTAINS: lambda a, b: (isinstance(a, str) and b in a)
                                or (isinstance(a, (list, set)) and b in a),
}


