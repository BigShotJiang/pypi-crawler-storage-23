﻿
# Advanced Analysis Parser

A Python package to parse Illumina-DRAGEN "special caller" outputs (TSV/JSON) into a unified JSON format, with automatic warnings based on user-defined or default conditions. Supports oncology, GBA, SMN, HBA, and more.

---

## Features

- Unified JSON output for multiple DRAGEN caller types (TSV/JSON)
- Automatic warnings for each file type, based on config or defaults
- Pluggable parser architecture for new file types
- CLI and Python API usage
- Example configs and test data included

---

## Installation

Install from PyPI (recommended):

```bash
pip install AdvancedAnalysisFileParser
```

Or from source:

```bash
git clone https://github.com/geneyx/geneyx.analysis.api.git
cd geneyx.analysis.api/scripts/AdvancedAnalysisFileParser
pip install -e .
```

---

## Quickstart

### Python API Usage

```python
from AdvancedAnalysisFileParser.AdvancedAnalysisParser import AdvancedAnalysisParser

request = {
    "input_dir": "./Test",
    "output_dir": "./Test",
    "output_json": "adv_output.json",
    # Optionally, you can specify input_files or map_files for custom configs
}
parser = AdvancedAnalysisParser(request)
parser.run()  # writes output to adv_output.json

# Or get result as dict:
result = parser.run(return_dict=True)
print(result)
```

### Command-Line Usage

Create a config file (e.g. `config.json`):

```json
{
  "input_dir": "./Test",
  "output_dir": "./Test",
  "output_json": "adv_output.json"
}
```

Then run:

```bash
python -m AdvancedAnalysisFileParser.AdvancedAnalysisParser -c config.json
```

---

## Configuration

The parser uses config files (JSON) to define how to parse and warn for each file type. Default configs are provided for:

- GBA: `gba_tsv_config.json`
- SMN: `smn_tsv_config.json`
- Oncology: `dragen_500_tsv_config.json`
- JSON: `advConfig.json`

You can override or extend these by providing your own config in the `map_files` key of the request.

### Example request/config structure

| Key           | Type   | Description                                                           |
| ------------- | ------ | --------------------------------------------------------------------- |
| `output_json` | string | Filename for the generated JSON (default: `adv_analysis_output.json`) |
| `input_dir`   | string | Directory containing all input files                                  |
| `input_files` | list   | (Optional) List of files to parse                                     |
| `map_files`   | object | (Optional) Mapping of filenames → caller definitions                  |

---

## Warnings

Warnings are generated automatically for each caller/file type, based on the config. Each config defines conditions for warnings (see `*_config.json` files for examples). You can customize these for your use case.

---

## Testing

Run the test suite to validate all parsing and warning logic:

```bash
pytest AdvancedAnalysisFileParser/Test_AdvancedAnalysisParser.py
```

Or run the test script:

```bash
python AdvancedAnalysisFileParser/run_test_parser.py
```

---

## Example Data

See the `Test/` folder for example input files (TSV/JSON) and expected outputs.

---

## License

MIT

# Build your JSON request (see next section for details)
request: JsonDict = {
    "output_json": "out.json",
    "input_dir": "path/to/input",
    "map_files": {
        "MyCallerOutput.tsv": {
            "MY_CALLER": {
                "caller_name": "My Caller",
                "fields": { ... },
            }
        }
    }
}

parser = AdvancedAnalysisParser(request)
result = parser.run(return_dict=True)
print(result)
```

### Command-Line Usage

1. Create a config file, e.g. `config.json` (see below).
2. Run:

  ```bash
  python -m AdvancedAnalysisFileParser.AdvancedAnalysisParser --input-dir <input_dir> --output-dir <output_dir> --input-files <file1> <file2> --output-json <output_json>
  ```

  Or with a config file:

  ```bash
  python -m AdvancedAnalysisFileParser.AdvancedAnalysisParser -c config.json
  ```

You can override config values with CLI arguments for flexible context modification.

This will write the unified JSON to `output_json` under `output_dir`.

---

## Configuration JSON

Top‐level JSON must include:

| Key           | Type   | Description                                                           |
| ------------- | ------ | --------------------------------------------------------------------- |
| `output_json` | string | Filename for the generated JSON (default: `adv_analysis_output.json`) |
| `input_dir`   | string | Directory containing all input files                                  |
| `map_files`   | object | Mapping of filenames → caller definitions                             |

### `map_files` Structure

```jsonc
"map_files": {
  "<filename.tsv|.json>": {
    "<CALLER_KEY>": {
      "caller_name": "<Human-readable name>",

      // Option A: per-field warnings
      "fields": {
        "<FieldName>": {
          "Warning": {
            "type": "condition",
            "conditions": [
              {
                "operator": "GT",
                "value": 10,
                "message": "Value > 10"
              }
            ]
          }
        }
      }

      // Option B: whole-caller warning (no "fields" key)
      "Warning": {
        "type": "condition",
        "conditions": [ ... ]
      }
    },
    /* repeat for other callers in the same file */
  }
}
```

#### TSV Caller Example (MSI/TMB/GIS)

```json
{
  "TruSightOncology500\\sample__CombinedVariantOutput.tsv": {
    "MSI": {
      "caller_name": "Percent Unstable MSI Sites",
      "fields": {
        "Usable MSI Sites": {
          "Warning": {
            "type": "condition",
            "conditions": [
              { "operator": "GT", "value": 10, "message": "MSI>10 detected" }
            ]
          }
        }
      }
    },
    "TMB": {
      "caller_name": "Total TMB",
      "fields": {
        "Total TMB": {
          "Warning": {
            "type": "condition",
            "conditions": [
              { "operator": "GT", "value": 10, "message": "TMB>10 detected" }
            ]
          }
        }
      }
    },
    "GIS": {
      "caller_name": "Genomic Instability Score",
      "fields": {
        "Genomic Instability Score": {
          "Warning": {
            "type": "condition",
            "conditions": [
              { "operator": "GT", "value": 42, "message": "GIS>42 detected" }
            ]
          }
        }
      }
    }
  }
}
```

#### Boolean-Flag Caller Example (GBA/SMN)

```json
{
  "SRR1289…gba.tsv": {
    "GBA": {
      "caller_name": "GBA Special Caller",
      "Warning": {
        "type": "condition",
        "disease_name": "Gaucher disease",
        "conditions": [
          {
            "field": "is_carrier",
            "operator": "EQ",
            "value": true,
            "message": "Based on the GBA Caller, this sample is positive for Gaucher disease"
          },
          {
            "field": "is_biallelic",
            "operator": "EQ",
            "value": true,
            "message": "Based on the GBA Caller, this sample is positive for Gaucher disease"
          }
        ]
      }
    }
  }
}
```

#### Genotype-Mapping Example (HBA)

```json
{
  "…targeted.json": {
    "hba": {
      "caller_name": "HBA Special Caller",
      "Warning": {
        "type": "genotype",
        "phenotypeGenotypeMapping": {
          "silent carrier": [
            "-a3.7/aa", "-a4.2/aa"
          ],
          "carrier": [
            "--/aaa3.7", "--/aaa4.2"
          ],
          "positive for hemoglobin H disease": [
            "--/-a3.7","--/-a4.2"
          ]
        }
      }
    }
  }
}
```

---

## Warning Types

### `condition`

* Evaluates one or more **FieldCondition** entries
* Each condition must specify:

  * `field` (optional for per-field; required for whole-caller)
  * `operator`: one of `EQ`, `NE`, `GT`, `LT`, etc.
    * `EQ`: Equals (`a == b`)
    * `NE`: Not Equals (`a != b`)
    * `GT`: Greater then (`a > b`)
    * `LT`: Less then (`a < b`)
    * `GE`: Greater then or equal (`a >= b`)
    * `LE`: Less then or equal (`a <= b`)
    * `CONTAINS`: Equals (`b in a`)
  * `value`: comparison target
  * `message`: text to emit if triggered

### `genotype`

* Maps raw genotypes → phenotype labels
* First matching genotype string in `phenotypeGenotypeMapping` is used

---

## Running Tests

We use `pytest` and parametrize via in-memory JSON contexts.


Sample snippet from `tests/test_parser.py`:

```python
import pytest
from AdvancedAnalysisFileParser import JsonDict, AdvancedAnalysisParser

TEST_CONTEXTS = [ { "request": { … }, "expected": { … } } ]

@pytest.mark.parametrize("context", TEST_CONTEXTS)
def test_parser_in_memory(context: JsonDict):
    parser = AdvancedAnalysisParser(context["request"])
    result = parser.run(return_dict=True)
    assert result["MSI"]["warning"] == "MSI>10 detected"
    # … more assertions …
```

---

## AdvancedAnalysisFile Properties

| JSON Name | Type                               | Required? |
|-----------|------------------------------------|-----------|
| LPA       | AdvancedAnalysis<LpaData>          | No        |
| SMN1      | AdvancedAnalysis<Smn1Data>         | No        |
| SMN       | AdvancedAnalysis<SmnData>          | No        |
| HBA       | AdvancedAnalysis<HbaData>          | No        |
| RH        | AdvancedAnalysis<RhData>           | No        |
| CYP2D6    | AdvancedAnalysis<Cyp2bData>        | No        |
| CYP2B6    | AdvancedAnalysis<Cyp2bData>        | No        |
| CYP21A2   | AdvancedAnalysis<Cyp21a2Data>      | No        |
| GBA       | AdvancedAnalysis<GbaData>          | No        |
| TMB       | AdvancedAnalysis<TmbData>          | No        |
| GIS       | AdvancedAnalysis<GisData>          | No        |
| MSI       | AdvancedAnalysis<MsiData>          | No        |
| HRD       | AdvancedAnalysis<HrdData>          | No        |

---

## Common Wrapper

### AdvancedAnalysis<T>

| JSON Name | Type     | Required? |
|-----------|----------|-----------|
| data      | T        | No        |
| Warning   | string   | No        |

---

## Data Models

### LpaData

| JSON Name                   | Type               | Required? |
|-----------------------------|--------------------|-----------|
| kiv2CopyNumber              | double             | Yes       |
| refMarkerAlleleCopyNumber   | double?            | No        |
| altMarkerAlleleCopyNumber   | double?            | No        |
| type                        | LpaType            | Yes       |
| variants                    | List<Variant>      | Yes       |

---

### Smn1Data

| JSON Name            | Type    | Required? |
|----------------------|---------|-----------|
| #Sample              | string  | Yes       |
| isSMA                | bool    | Yes       |
| isCarrier            | bool    | Yes       |
| SMN1_CN              | double  | No        |
| SMN2_CN              | double  | No        |
| SMN2delta7-8_CN      | int     | Yes       |
| Total_CN_raw         | double  | Yes       |
| Full_length_CN_raw   | double  | Yes       |
| SMN1_CN_raw          | string  | Yes       |

---

### SmnData

| JSON Name            | Type            | Required? |
|----------------------|-----------------|-----------|
| smn1CopyNumber       | double?         | Yes       |
| smn2CopyNumber       | double?         | Yes       |
| smn2Delta78CopyNumber| int             | Yes       |
| totalCopyNumber      | double          | Yes       |
| fullLengthCopyNumber | double          | No        |
| variants             | List<Variant>   | Yes       |

---

### HbaData

| JSON Name         | Type              | Required? |
|-------------------|-------------------|-----------|
| genotype          | string            | Yes       |
| genotypeFilter    | GenotypeFilter    | Yes       |
| genotypeQual      | double            | Yes       |
| minPValue         | double            | Yes       |
| variants          | List<Variant>     | Yes       |

---

### RhData

| JSON Name        | Type            | Required? |
|------------------|-----------------|-----------|
| totalCopyNumber  | int             | Yes       |
| rhdCopyNumber    | int             | Yes       |
| rhceCopyNumber   | int             | Yes       |
| variants         | List<Variant>   | Yes       |

---

### Cyp2bData

| JSON Name               | Type             | Required? |
|-------------------------|------------------|-----------|
| genotype                | string           | Yes       |
| genotypeFilter          | GenotypeFilter   | Yes       |
| pharmcatDescription     | string           | No        |
| pharmcatMetabolismStatus| string           | No        |

---

### Cyp21a2Data

| JSON Name                | Type            | Required? |
|--------------------------|-----------------|-----------|
| totalCopyNumber          | int             | Yes       |
| deletionBreakpointInGene | bool?           | No        |
| recombinantHaplotypes    | List<string>    | No        |
| variants                 | List<Variant>   | Yes       |

---

### GbaData

| JSON Name                      | Type    | Required? |
|--------------------------------|---------|-----------|
| #Sample                        | string  | Yes       |
| is_biallelic                   | bool    | Yes       |
| is_carrier                     | bool    | Yes       |
| total_CN                       | int     | Yes       |
| deletion_breakpoint_in_GBA_gene| string  | No        |
| recombinant_variants           | string  | No        |
| other_variants                 | string  | No        |

---

### TmbData

| JSON Name   | Type   | Required? |
|-------------|--------|-----------|
| Total TMB   | double | Yes       |

---

### GisData

| JSON Name                | Type    | Required? |
|--------------------------|---------|-----------|
| Genomic Instability Score| int     | No        |
| Tumor Fraction           | double  | No        |
| Ploidy                   | double  | No        |

---

### MsiData

| JSON Name                  | Type    | Required? |
|----------------------------|---------|-----------|
| Percent Unstable MSI Sites | double  | Yes       |

---

### HrdData

| JSON Name   | Type   | Required? |
|-------------|--------|-----------|
| HRD Score   | int    | Yes       |

---

### Variant

| JSON Name            | Type    | Required? |
|----------------------|---------|-----------|
| hgvs                 | string  | No        |
| qual                 | double  | No        |
| altCopyNumber        | int     | No        |
| altCopyNumberQuality | double  | No        |

---

## Contributing

1. Fork
2. Create feature branch
3. Submit PR

Please follow existing style and add tests for new parser logic.
Bar Cohen

### **Additional Help & Support**:
For any troubleshooting or questions, feel free to contact [support@geneyx.com](mailto:support@geneyx.com).

## License

Copyright (c) 2025 GeneyX Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```


