#!/usr/bin/env python3
import argparse
import json
import logging
import os
from typing import Optional
from .Models import *
from .Warnings import *
from .Parsers import *
from .AdvancedAnalysisConstants import AdvancedAnalysisConstants

class AdvancedAnalysisParser:
    """
    AdvancedAnalysisParser

    Parses special callers outputs (TSV/JSON) into a unified JSON format.
    
    Usage:
        - Instantiate with a config dict (JsonDict) specifying input/output files and directories.
        - Call run() to parse and write output JSON.
        - Use from_cli() for command-line usage.

    Parameters for constructor (json_request: JsonDict):
        - input_files: List[str] (optional) - List of input file paths to parse.
        - input_dir: str (optional) - Directory containing input files.
        - output_dir: str (optional) - Directory to write output JSON.
        - output_json: str (optional) - Output JSON filename.
        - MAP_FILES: dict (optional) - Mapping for file-specific configs.

    Returns:
        - run(return_dict=True): Returns parsed result as JsonDict.
        - run(return_dict=False): Writes output JSON file, returns None.

    Example:
        config = {
            "input_files": ["file1.json", "file2.tsv"],
            "input_dir": "./inputs",
            "output_dir": "./outputs",
            "output_json": "result.json"
        }
        parser = AdvancedAnalysisParser(config)
        parser.run()
    """
    def __init__(self, json_request: JsonDict) -> None:
        """
        Initialize parser with configuration.

        Args:
            json_request (JsonDict): Configuration dict. See class docstring for keys.
        """
        self.output_dir: str = json_request.get(AdvancedAnalysisConstants.OUTPUT_DIR, '.')
        self.output_json: str = json_request.get(AdvancedAnalysisConstants.OUTPUT_JSON, 'adv_analysis_output.json')
        self.input_dir: str = json_request.get(AdvancedAnalysisConstants.INPUT_DIR, '.')
        self.input_files: list[str] = json_request.get('input_files', [])

    def run(self, return_dict: bool = False) -> Optional[JsonDict]:
        """
        Parse files and output unified JSON.

        Args:
            return_dict (bool): If True, returns parsed result as dict. If False, writes output file.

        Returns:
            JsonDict if return_dict is True, else None.
        """
        result = self.parse_files()
        if return_dict:
            return result
        out_path = os.path.join(self.output_dir, self.output_json)
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=4)
        logging.info(f"Wrote unified JSON to {out_path}")
        return None

    def parse_files(self) -> JsonDict:
        """
        Parse all input files specified in config.

        Returns:
            JsonDict: Unified parsed result from all files.
        Raises:
            ValueError: If no input files found.
        """
        logging.info("Started parsing Advanced Analysis files")
        if not self.input_files or self.input_files == [] and self.input_dir and os.path.exists(self.input_dir):
            folder_files = [
                os.path.join(self.input_dir, f) 
                for f in os.listdir(self.input_dir) if os.path.isfile(os.path.join(self.input_dir, f))
                and f.lower().endswith(('.json', '.tsv'))
            ]
            self.input_files.extend(folder_files)
        if not self.input_files or self.input_files == []:
            raise ValueError("No input files found in configuration or input directory.")
        result : JsonDict = {}
        for fname in self.input_files:
            if not os.path.exists(fname):
                fname_path = os.path.join(self.input_dir, fname)
                if os.path.exists(fname_path):
                    fname = fname_path
                else:
                    logging.warning(f"File {fname} not found. Skipping.")
                    continue
            parser: IAdvancedAnalysisFileParser = AdvancedAnalysisFileParserFactory.get_parser(fname)
            file_parsed_data = self.parse_by_config(parser)
            result.update(file_parsed_data)
        return result

    def parse_by_config(self,parser : IAdvancedAnalysisFileParser) -> JsonDict:
        """
        Parse a single file using its parser and build result.

        Args:
            parser (IAdvancedAnalysisFileParser): Parser instance for the file.

        Returns:
            JsonDict: Parsed and formatted result for the file.
        """
        caller_data: JsonDict = parser.parse()
        return parser.build_result(caller_data)

    @staticmethod
    def _threshold_warning(w: JsonDict, parsed: JsonDict, value_key: str, threshold_key: str, label: str) -> str:
        """
        Helper to generate threshold warning string if value exceeds threshold.

        Args:
            w (JsonDict): Warning config dict.
            parsed (JsonDict): Parsed data dict.
            value_key (str): Key for value to check.
            threshold_key (str): Key for threshold value.
            label (str): Label for warning.

        Returns:
            str: Warning message or empty string.
        """
        name = w.get("caller_name")
        key = w.get(value_key)
        threshold = w.get(threshold_key)
        val = parsed.get(key or "")
        if isinstance(val, (int, float)) and threshold is not None and val >= threshold:
            return f"Based on {name}, sample {label} {val} ≥ {threshold}"
        return ""

    @staticmethod
    def parse_args() -> argparse.Namespace:
        """
        Parse command-line arguments for CLI usage.

        Returns:
            argparse.Namespace: Parsed CLI arguments.
        """
        parser = argparse.ArgumentParser(
            description="Parse special callers outputs into unified JSON"
        )
        parser.add_argument("-c", "--config", required=False, help="Path to config JSON file")
        parser.add_argument("--input-dir", help="Input directory")
        parser.add_argument("--output-dir", help="Output directory")
        parser.add_argument("--input-files", nargs='+', help="Input file(s)")
        parser.add_argument("--output-json", help="Output JSON filename")
        return parser.parse_args()

    @classmethod
    def from_cli(cls) -> None:
        """
        Entry point for command-line usage.
        Loads config from file and/or CLI args, runs parser.
        """
        args = cls.parse_args()
        config = {}
        # Load config file if provided
        if args.config:
            with open(args.config, 'r') as f:
                config = json.load(f)
        # Override config with CLI args if provided
        if args.input_dir:
            config[AdvancedAnalysisConstants.INPUT_DIR] = args.input_dir
        if args.output_dir:
            config[AdvancedAnalysisConstants.OUTPUT_DIR] = args.output_dir
        if args.input_files:
            # If input files are provided, build map_files structure and set input_files
            map_files = {}
            for fname in args.input_files:
                map_files[fname] = config.get('map_files', {}).get(fname, {})
            config[AdvancedAnalysisConstants.MAP_FILES] = map_files
            config['input_files'] = args.input_files
        if args.output_json:
            config[AdvancedAnalysisConstants.OUTPUT_JSON] = args.output_json
        parser = cls(config)
        parser.run()

if __name__ == "__main__":
    import sys
    from argparse import ArgumentParser
    # Parse output-dir early to set up file logging
    parser = ArgumentParser(add_help=False)
    parser.add_argument("--output-dir", default=".")
    args, _ = parser.parse_known_args()
    log_path = os.path.join(args.output_dir, "advanced_analysis.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path, mode="a", encoding="utf-8")
        ]
    )
    logging.info(f"Logging to {log_path}")
    AdvancedAnalysisParser.from_cli()
