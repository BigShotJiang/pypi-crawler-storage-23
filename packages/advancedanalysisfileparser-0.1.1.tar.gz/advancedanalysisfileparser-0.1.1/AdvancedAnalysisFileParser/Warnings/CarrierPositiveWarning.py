from .IWarning import IWarning
from ..Models import *
class CarrierPositiveWarning(IWarning):
    def format(self, config: JsonDict, data: JsonDict) -> str:
        """
        Generate a warning message for carrier/positive status based on conditions.

        Args:
            config (JsonDict): Configuration dict with 'conditions' (list of dicts).
            data (JsonDict): Data dict to check conditions against.

        Returns:
            str: Warning message if a condition is met, else empty string.
        """
        name = config.get("caller_name") or config.get("name")
        disease = config.get("disease_name") or config.get("disease")
        conditions = config.get("conditions",{})
        for condition in conditions:
            condition["operator"] = ConditionOperator[condition["operator"]]
            field_condition = FieldCondition(
                field= condition.get("field",None),
                operator=condition.get("operator"),
                value=condition.get("value"),
                message=f"Based on the {name}, this sample is <b>Positive</b> for {disease}"
            )
            if field_condition.check(data):
                return field_condition.__str__()
        return ""