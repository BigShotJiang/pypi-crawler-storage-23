from .IWarning import IWarning
from ..Models import JsonDict, FieldCondition, ConditionOperator

class ConditionWarning(IWarning):
    def format(self, config: JsonDict, data: JsonDict) -> str:
        """
        Generate warning messages based on a list of conditions.

        Args:
            config (JsonDict): Configuration dictionary. Must contain a "conditions" key with a list of dicts,
                each representing a FieldCondition (keys: operator, value, message, field [optional]).
            data (JsonDict): Data dictionary to check conditions against. If a condition specifies a field, that field's value is used.

        Returns:
            str: Concatenated warning messages for all triggered conditions, separated by ". ". Returns an empty string if no conditions are met.

        Example config:
            config = {
                "conditions": [
                    {"operator": "GT", "value": 10, "message": "Value is too high", "field": "score"},
                    {"operator": "EQ", "value": 0, "message": "Value is zero"}
                ]
            }
        """
        msgs = []
        for cond_dict in config.get("conditions", []):
            cond_dict["operator"] = ConditionOperator[cond_dict["operator"]]
            cond = FieldCondition(**cond_dict)
            if isinstance(data, dict):
                if cond_dict.get("field") in data:
                    data = data[cond_dict["field"]]
            warning = cond.__str__()
            if warning in msgs:
                continue
            if cond.check(data):
                msgs.append(warning)
                print(f"Warning triggered by condition: {warning}")
        return ". ".join(msgs)