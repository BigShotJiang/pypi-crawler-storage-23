from .IWarning import IWarning
from ..Models import JsonDict
class GenotypeWarning(IWarning):
    def format(self, config: JsonDict, data: JsonDict) -> str:
        """
        Generate a warning message based on genotype-to-phenotype mapping.

        Args:
            config (JsonDict): Configuration dict with mapping info.
            data (JsonDict): Data dict with genotype info.

        Returns:
            str: Warning message if mapping found, else empty string.
        """
        name = config.get("caller_name") or config.get("name")
        genotype_key = config.get("genotype_data_key", "genotype")
        sample = data.get(genotype_key)
        mapping = config.get("phenotypeGenotypeMapping") or config.get("phenotype_genotype_mapping") or {}
        warning = ""
        # Support both old and new mapping formats
        if mapping:
            if all(isinstance(v, str) for v in mapping.values()):
                # Old format: genotype→phenotype
                if sample in mapping:
                    warning = f"Based on {name}, this sample is defined as <b>{mapping[sample]}</b>"
            elif all(isinstance(v, list) for v in mapping.values()):
                # New format: phenotype→[genotypes]
                for phenotype, genotypes in mapping.items():
                    if sample in genotypes:
                        warning = f"Based on {name}, this sample is defined as <b>{phenotype}</b>"
                        break
        return warning