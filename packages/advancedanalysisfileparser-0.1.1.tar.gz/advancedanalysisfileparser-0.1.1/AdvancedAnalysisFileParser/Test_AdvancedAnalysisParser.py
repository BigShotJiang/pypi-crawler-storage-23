import json
import logging
import os
import pytest
from AdvancedAnalysisFileParser import JsonDict
from AdvancedAnalysisFileParser import AdvancedAnalysisParser

# Always resolve the test data directory relative to this file
TEST_DATA_DIR = os.path.join(os.path.dirname(__file__), "Test")

# Define test contexts for parametrization
TEST_CONTEXTS = [
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["dummy_warnset_1.targeted.json"]
            },
            "expected": {
                "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>positive for hemoglobin H disease</b>"},
                "SMN": {"warning": "Based on the SMN Caller, this sample is positive for Spinal Muscular Atrophy"},
                "GBA": {"warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"}
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["dummy_warnset_2.targeted.json"]
            },
            "expected": {
                "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>carrier</b>"},
                "SMN": {"warning": "Based on the SMN Caller, this sample is carrier for Spinal Muscular Atrophy"},
                "GBA": {"warning": "Multiple GBA variants detected; phase is unknown (could be in cis or in trans). Interpret cautiously."}
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["dummy_warnset_3.targeted.json"]
            },
            "expected": {
                "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>silent carrier</b>"},
                "SMN": {"warning": "Based on the SMN Caller, this sample has increased risk of being a silent carrier (2+0) for Spinal Muscular Atrophy"},
                "GBA": {"warning": "Based on the GBA Caller, this sample is carrier for Gaucher disease"}
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["dummy_gba_phase_unknown_one_recomb_plus_variant.targeted.json"]
            },
            "expected": {
                "GBA": {"warning": "Multiple GBA variants detected; phase is unknown (could be in cis or in trans). Interpret cautiously."}
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["dummy_gba_carrier_one_recomb_only.targeted.json"]
            },
            "expected": {
                "GBA": {"warning": "Based on the GBA Caller, this sample is carrier for Gaucher disease"}
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["gba_carrier_1.json"]
            },
            "expected": {
                "GBA": {
                    "warning": "Based on the GBA Caller, this sample is carrier for Gaucher disease"
                }
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["gba_positive_1.json"]
            },
            "expected": {
                "GBA": {
                    "warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"
                }
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["smn_carrier.json"]
            },
            "expected": {
                "SMN": {
                    "warning": "Based on the SMN Caller, this sample is carrier for Spinal Muscular Atrophy"
                }
            }
        },
        {
            "request": {
                "output_json": "out.json",
                "input_dir": TEST_DATA_DIR,
                "output_dir": TEST_DATA_DIR,
                "input_files": ["smn_positive.json"]
            },
            "expected": {
                "SMN": {
                    "warning": "Based on the SMN Caller, this sample is positive for Spinal Muscular Atrophy"
                }
            }
        },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba_positive_1.json"]
        },
        "expected": {
            "GBA": {
                "warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"
            }
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_carrier_1.json"]
        },
        "expected": {
            "HBA": {
                "warning": "Based on HBA Special Caller, this sample is defined as <b>carrier</b>"
            }
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_hemoglobin_h_disease.json"]
        },
        "expected": {
            "HBA": {
                "warning": "Based on HBA Special Caller, this sample is defined as <b>positive for hemoglobin H disease</b>"
            }
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_silent_carrier.json"]
        },
        "expected": {
            "HBA": {
                "warning": "Based on HBA Special Caller, this sample is defined as <b>silent carrier</b>"
            }
        }
    },
      {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba_carrier_2.json"]
        },
        "expected": {
            "GBA": {"warning": "Based on the GBA Caller, this sample is carrier for Gaucher disease"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba_multiple_phase_unknown_1.json"]
        },
        "expected": {
            "GBA": {"warning": "Multiple GBA variants detected; phase is unknown (could be in cis or in trans). Interpret cautiously."}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba_multiple_phase_unknown_2.json"]
        },
        "expected": {
            "GBA": {"warning": "Multiple GBA variants detected; phase is unknown (could be in cis or in trans). Interpret cautiously."}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba_positive_2.json"]
        },
        "expected": {
            "GBA": {"warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_carrier_2.json"]
        },
        "expected": {
            "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>carrier</b>"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_carrier_3.json"]
        },
        "expected": {
            "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>carrier</b>"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["hba_carrier_4.json"]
        },
        "expected": {
            "HBA": {"warning": "Based on HBA Special Caller, this sample is defined as <b>carrier</b>"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["smn_silent_carrier_risk.json"]
        },
        "expected": {
            "SMN": {"warning": "Based on the SMN Caller, this sample has increased risk of being a silent carrier (2+0) for Spinal Muscular Atrophy"},
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["dragen424.targeted.json"]
        },
        "expected": {
            "CYP2D6": {},
            "CYP2B6": {},
            "CYP21A2": {},
            "LPA": {}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files" : ["dummy_gba_affected_nonrecomb_acn2.targeted.json"]
        },
        "expected": {
            "GBA": {"warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["gba.tsv"]
        },
        "expected": {
            "GBA": {"warning": "Based on the GBA Caller, this sample is positive for Gaucher disease"}
        }
    },
    {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["smn.tsv"]
        },
        "expected": {
            "SMN1": {"warning": "Based on the SMN Caller, this sample is positive for Spinal Muscular Atrophy"}
        }
    },
        {
        "request": {
            "output_json": "out.json",
            "input_dir": TEST_DATA_DIR,
            "output_dir": TEST_DATA_DIR,
            "input_files": ["TruSightOncology500.CombinedVariantOutput.tsv"]
        },
        "expected": {
            # TODO: Fill in expected output for this file
        }
    },
]

@pytest.mark.parametrize("context", TEST_CONTEXTS)
def test_parser_in_memory(context: JsonDict) -> None:
    parser = AdvancedAnalysisParser(context["request"])
    result = parser.run(return_dict=True)
    print(json.dumps(result, indent=2, default=str))
    if result is not None:
        print(f"[DEBUG] Result keys: {list(result.keys())}")
        for gene in result:
            print(f"[DEBUG] {gene} warning: {result[gene].get('warning')}")
    assert result is not None
    # Validate all expected fields (not just warning)
    for gene, expected in context["expected"].items():
        assert gene in result, f"Missing result for {gene}"
        for key, value in expected.items():
            result_value = result[gene].get(key, None)
            assert result_value == value, f"Mismatch for {gene}.{key}: got {result_value}, expected {value}"
    
