import json
import os
import sys

# Ensure package import works when running this file directly
CURRENT_DIR = os.path.dirname(__file__)
PARENT_DIR = os.path.dirname(CURRENT_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

from AdvancedAnalysisFileParser import AdvancedAnalysisParser

def main():
    base = os.path.join(os.path.dirname(__file__), "Test")
    filename = "gba_positive_1.json"
    request = {
        "input_dir": base,
        "output_dir": base,
        "output_json": "adv_output.json",
        "map_files": {
            filename: {}
        }
    }
    parser = AdvancedAnalysisParser(request)
    result = parser.run(return_dict=True)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
