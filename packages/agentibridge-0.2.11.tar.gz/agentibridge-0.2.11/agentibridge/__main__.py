"""Enable ``python -m agentibridge`` execution."""

from agentibridge.server import main

main()
