from .client import MongoDBSingleton
