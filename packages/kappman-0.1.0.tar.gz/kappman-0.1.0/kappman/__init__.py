"""KAppMan - KDE AppImage Manager package."""

__version__ = "0.1.0"
__app_name__ = "KAppMan"
