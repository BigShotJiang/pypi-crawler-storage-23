"""
git-p4son - Utility for keeping a Perforce workspace and local git repo in sync.

This package provides commands for syncing a local git repository with a Perforce workspace,
creating and updating changelists, and managing Swarm reviews.
"""

__version__ = "0.2.0"
__author__ = "Andreas Andersson"
__email__ = "andreas@neoboid.com"
