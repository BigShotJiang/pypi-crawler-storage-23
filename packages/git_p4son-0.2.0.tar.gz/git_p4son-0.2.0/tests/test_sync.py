"""Tests for git_p4son.sync module."""

import sys
import unittest
from unittest import mock

from git_p4son.common import CommandError, RunError
from git_p4son.sync import (
    P4SyncOutputProcessor,
    get_file_count_to_sync,
    get_latest_changelist_affecting_workspace,
    get_writable_files,
    git_add_all_files,
    git_changelist_of_last_sync,
    git_commit,
    git_get_dirty_files,
    p4_get_opened_files,
    p4_sync,
    parse_p4_sync_line,
    sync_command,
)
from tests.helpers import make_run_result


class TestParseP4SyncLine(unittest.TestCase):
    def test_added_file(self):
        mode, filename = parse_p4_sync_line(
            '//depot/foo.txt#1 - added as /ws/foo.txt')
        self.assertEqual(mode, 'add')
        self.assertEqual(filename, '/ws/foo.txt')

    def test_deleted_file(self):
        mode, filename = parse_p4_sync_line(
            '//depot/foo.txt#2 - deleted as /ws/foo.txt')
        self.assertEqual(mode, 'del')
        self.assertEqual(filename, '/ws/foo.txt')

    def test_updated_file(self):
        mode, filename = parse_p4_sync_line(
            '//depot/foo.txt#3 - updating /ws/foo.txt')
        self.assertEqual(mode, 'upd')
        self.assertEqual(filename, '/ws/foo.txt')

    def test_clobber_file(self):
        mode, filename = parse_p4_sync_line(
            "Can't clobber writable file /ws/foo.txt")
        self.assertEqual(mode, 'clb')
        self.assertEqual(filename, '/ws/foo.txt')

    def test_unparsable_line(self):
        mode, filename = parse_p4_sync_line('some random output')
        self.assertIsNone(mode)
        self.assertIsNone(filename)


class TestGetWritableFiles(unittest.TestCase):
    def test_extracts_writable_files(self):
        stderr = [
            "Can't clobber writable file /ws/a.txt",
            "Can't clobber writable file /ws/b.txt",
            "some other error",
        ]
        result = get_writable_files(stderr)
        self.assertEqual(result, ['/ws/a.txt', '/ws/b.txt'])

    def test_empty_stderr(self):
        self.assertEqual(get_writable_files([]), [])


class TestGitGetDirtyFiles(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    def test_clean_workspace(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[])
        self.assertEqual(git_get_dirty_files('/ws'), [])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_modified_file(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[' M file.txt'])
        result = git_get_dirty_files('/ws')
        self.assertEqual(result, [('file.txt', 'modify')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_added_file(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=['A  new.txt'])
        result = git_get_dirty_files('/ws')
        self.assertEqual(result, [('new.txt', 'add')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_deleted_file(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[' D gone.txt'])
        result = git_get_dirty_files('/ws')
        self.assertEqual(result, [('gone.txt', 'delete')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_untracked_file(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=['?? unknown.txt'])
        result = git_get_dirty_files('/ws')
        self.assertEqual(result, [('unknown.txt', 'untracked')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_multiple_files(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            ' M mod.txt',
            'A  add.txt',
            '?? new.txt',
        ])
        result = git_get_dirty_files('/ws')
        self.assertEqual(result, [
            ('mod.txt', 'modify'),
            ('add.txt', 'add'),
            ('new.txt', 'untracked'),
        ])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_command_failure(self, mock_rwo):
        mock_rwo.side_effect = RunError('git status failed')
        with self.assertRaises(RunError):
            git_get_dirty_files('/ws')


class TestP4GetOpenedFiles(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    def test_clean(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[])
        self.assertEqual(p4_get_opened_files('/ws'), [])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_edit(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '//depot/foo.txt#1 - edit default change (text)'
        ])
        result = p4_get_opened_files('/ws')
        self.assertEqual(result, [('//depot/foo.txt', 'modify')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_add(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '//depot/new.txt#1 - add change 12345 (text)'
        ])
        result = p4_get_opened_files('/ws')
        self.assertEqual(result, [('//depot/new.txt', 'add')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_delete(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '//depot/old.txt#3 - delete change 12345 (text)'
        ])
        result = p4_get_opened_files('/ws')
        self.assertEqual(result, [('//depot/old.txt', 'delete')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_move_add(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '//depot/new.txt#1 - move/add change 12345 (text)'
        ])
        result = p4_get_opened_files('/ws')
        self.assertEqual(result, [('//depot/new.txt', 'add')])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_command_failure(self, mock_rwo):
        mock_rwo.side_effect = RunError('p4 opened failed')
        with self.assertRaises(RunError):
            p4_get_opened_files('/ws')


class TestGitAddAllFiles(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    def test_success(self, mock_rwo):
        mock_rwo.return_value = make_run_result()
        git_add_all_files('/ws')

    @mock.patch('git_p4son.sync.run_with_output')
    def test_failure(self, mock_rwo):
        mock_rwo.side_effect = RunError('git add failed')
        with self.assertRaises(RunError):
            git_add_all_files('/ws')


class TestGitCommit(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    def test_success(self, mock_rwo):
        mock_rwo.return_value = make_run_result()
        git_commit('msg', '/ws')
        cmd = mock_rwo.call_args[0][0]
        self.assertEqual(cmd, ['git', 'commit', '-m', 'msg'])

    @mock.patch('git_p4son.sync.run_with_output')
    def test_allow_empty(self, mock_rwo):
        mock_rwo.return_value = make_run_result()
        git_commit('msg', '/ws', allow_empty=True)
        cmd = mock_rwo.call_args[0][0]
        self.assertIn('--allow-empty', cmd)


class TestGitChangelistOfLastSync(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    def test_extracts_changelist_nr(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '12345: p4 sync //...@12345'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertEqual(result, 12345)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_extracts_changelist_pergit(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            'pergit: p4 sync //...@12345'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertEqual(result, 12345)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_extracts_changelist_git_p4son(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            'git-p4son: p4 sync //...@12345'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertEqual(result, 12345)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_extracts_changelist_fail(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            'pergot: p4 sync //...@12345'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertEqual(result, None)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_no_match(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[
            '"some other commit message"'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertIsNone(result)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_empty_output(self, mock_rwo):
        mock_rwo.return_value = make_run_result(stdout=[])
        result = git_changelist_of_last_sync('/ws')
        self.assertIsNone(result)

    @mock.patch('git_p4son.sync.run_with_output')
    def test_command_failure(self, mock_rwo):
        mock_rwo.side_effect = RunError('git log failed')
        with self.assertRaises(RunError):
            git_changelist_of_last_sync('/ws')

    @mock.patch('git_p4son.sync.run_with_output')
    def test_uses_git_grep_to_search_history(self, mock_rwo):
        """Verifies git log --grep is used so sync commits are found
        even when HEAD is not a sync commit."""
        mock_rwo.return_value = make_run_result(stdout=[
            'git-p4son: p4 sync //...@99999'
        ])
        result = git_changelist_of_last_sync('/ws')
        self.assertEqual(result, 99999)
        cmd = mock_rwo.call_args[0][0]
        self.assertIn('--grep=: p4 sync //\\.\\.\\.@', cmd)


class TestGetLatestChangelistAffectingWorkspace(unittest.TestCase):
    @mock.patch('git_p4son.sync.run')
    @mock.patch('git_p4son.sync.get_p4_client_name', return_value='myclient')
    def test_success(self, _mock_client, mock_run):
        mock_run.return_value = make_run_result(stdout=[
            "Change 54321 on 2024/01/01 by user@ws 'description'"
        ])
        cl = get_latest_changelist_affecting_workspace('/ws')
        self.assertEqual(cl, 54321)

    @mock.patch('git_p4son.sync.get_p4_client_name', return_value=None)
    def test_no_client_name(self, _mock_client):
        with self.assertRaises(CommandError):
            get_latest_changelist_affecting_workspace('/ws')

    @mock.patch('git_p4son.sync.run')
    @mock.patch('git_p4son.sync.get_p4_client_name', return_value='myclient')
    def test_no_changes_found(self, _mock_client, mock_run):
        mock_run.return_value = make_run_result(stdout=[])
        with self.assertRaises(CommandError):
            get_latest_changelist_affecting_workspace('/ws')


class TestGetFileCountToSync(unittest.TestCase):
    @mock.patch('git_p4son.sync.run')
    def test_returns_count(self, mock_run):
        mock_run.return_value = make_run_result(stdout=[
            '//depot/a.txt - added',
            '//depot/b.txt - updating',
        ])
        count = get_file_count_to_sync(12345, '/ws')
        self.assertEqual(count, 2)

    @mock.patch('git_p4son.sync.run')
    def test_failure(self, mock_run):
        mock_run.side_effect = RunError('p4 sync -n failed')
        with self.assertRaises(RunError):
            get_file_count_to_sync(12345, '/ws')


class TestP4SyncOutputProcessor(unittest.TestCase):
    def test_tracks_added_file(self):
        processor = P4SyncOutputProcessor(10)
        processor('//depot/foo.txt#1 - added as /ws/foo.txt', sys.stdout)
        self.assertEqual(processor.stats['add'], 1)
        self.assertEqual(processor.synced_file_count, 1)

    def test_tracks_deleted_file(self):
        processor = P4SyncOutputProcessor(10)
        processor('//depot/foo.txt#2 - deleted as /ws/foo.txt', sys.stdout)
        self.assertEqual(processor.stats['del'], 1)

    def test_up_to_date_message(self):
        processor = P4SyncOutputProcessor(10)
        processor('//...@12345 - file(s) up-to-date.', sys.stdout)
        self.assertEqual(processor.synced_file_count, 0)


class TestP4Sync(unittest.TestCase):
    @mock.patch('git_p4son.sync.run_with_output')
    @mock.patch('git_p4son.sync.run')
    def test_success(self, mock_run, mock_rwo):
        mock_run.return_value = make_run_result(stdout=['file1', 'file2'])
        mock_rwo.return_value = make_run_result()
        result = p4_sync(12345, 'test', False, '/ws')
        self.assertTrue(result)

    @mock.patch('git_p4son.sync.run')
    def test_up_to_date(self, mock_run):
        mock_run.return_value = make_run_result(stdout=[])
        result = p4_sync(12345, 'test', False, '/ws')
        self.assertTrue(result)

    @mock.patch('git_p4son.sync.run')
    def test_count_failure(self, mock_run):
        mock_run.side_effect = RunError('p4 sync -n failed')
        with self.assertRaises(RunError):
            p4_sync(12345, 'test', False, '/ws')


class TestSyncCommand(unittest.TestCase):
    @mock.patch('git_p4son.sync.git_commit')
    @mock.patch('git_p4son.sync.git_add_all_files')
    @mock.patch('git_p4son.sync.git_get_dirty_files')
    @mock.patch('git_p4son.sync.p4_sync', return_value=True)
    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=10000)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    def test_sync_specific_cl(self, _p4clean, _last_cl, _p4sync,
                              mock_git_clean, _git_add, _git_commit):
        # First call: initial check (clean), second call: after sync (dirty -> add files)
        mock_git_clean.side_effect = [[], [('file.txt', 'modify')]]
        args = mock.Mock(changelist='12345', force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 0)

    @mock.patch('git_p4son.sync.git_get_dirty_files',
                return_value=[('file.txt', 'modify')])
    def test_dirty_git_workspace_aborts(self, _git_clean):
        args = mock.Mock(changelist='100', force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 1)

    @mock.patch('git_p4son.sync.git_get_dirty_files', return_value=[])
    @mock.patch('git_p4son.sync.p4_get_opened_files',
                return_value=[('//depot/foo.txt', 'modify')])
    def test_dirty_p4_workspace_aborts(self, _p4clean, _git_clean):
        args = mock.Mock(changelist='100', force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 1)

    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=200)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    @mock.patch('git_p4son.sync.git_get_dirty_files', return_value=[])
    def test_older_cl_without_force_aborts(self, _git_clean, _p4clean, _last_cl):
        args = mock.Mock(changelist='100', force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 1)

    @mock.patch('git_p4son.sync.git_commit')
    @mock.patch('git_p4son.sync.git_add_all_files')
    @mock.patch('git_p4son.sync.git_get_dirty_files')
    @mock.patch('git_p4son.sync.p4_sync', return_value=True)
    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=200)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    def test_older_cl_with_force_proceeds(self, _p4clean, _last_cl,
                                          _p4sync, mock_git_clean, _add, _commit):
        mock_git_clean.side_effect = [[], [('file.txt', 'modify')]]
        args = mock.Mock(changelist='100', force=True, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 0)

    @mock.patch('git_p4son.sync.p4_sync', return_value=True)
    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=100)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    @mock.patch('git_p4son.sync.git_get_dirty_files', return_value=[])
    def test_same_cl_is_noop(self, _git_clean, _p4clean, _last_cl, _p4sync):
        args = mock.Mock(changelist='100', force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 0)

    @mock.patch('git_p4son.sync.p4_sync', return_value=True)
    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=100)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    @mock.patch('git_p4son.sync.git_get_dirty_files', return_value=[])
    def test_last_synced(self, _git_clean, _p4clean, _last_cl, mock_p4sync):
        args = mock.Mock(changelist='last-synced',
                         force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 0)
        mock_p4sync.assert_called_once_with(100, 'last synced', False, '/ws')

    @mock.patch('git_p4son.sync.get_latest_changelist_affecting_workspace')
    @mock.patch('git_p4son.sync.git_commit')
    @mock.patch('git_p4son.sync.git_get_dirty_files')
    @mock.patch('git_p4son.sync.p4_sync', return_value=True)
    @mock.patch('git_p4son.sync.git_changelist_of_last_sync', return_value=100)
    @mock.patch('git_p4son.sync.p4_get_opened_files', return_value=[])
    def test_latest_keyword(self, _p4clean, _last_cl, _p4sync,
                            mock_git_clean, _commit, mock_get_latest):
        mock_get_latest.return_value = 200
        mock_git_clean.side_effect = [[], []]  # clean before and after
        args = mock.Mock(changelist=None, force=False, workspace_dir='/ws')
        rc = sync_command(args)
        self.assertEqual(rc, 0)


if __name__ == '__main__':
    unittest.main()
