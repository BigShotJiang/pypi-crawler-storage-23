class BasePlugin:
    name = "base"

    def register(self) -> None:
        return None
