from .core import BayaError


class PluginError(BayaError):
    pass
