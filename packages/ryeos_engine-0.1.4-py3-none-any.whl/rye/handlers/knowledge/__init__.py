"""Knowledge handler module."""

from rye.handlers.knowledge.handler import KnowledgeHandler

__all__ = ["KnowledgeHandler"]
