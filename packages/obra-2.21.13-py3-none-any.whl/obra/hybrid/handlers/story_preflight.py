"""Story pre-flight handler for per-story SenseCheck + CodeVerify refinement."""

from __future__ import annotations

import copy
import json
import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.agents.code_verify_runner import VerificationSessionRunner
from obra.api.protocol import StoryPreflightResult, ValidatorRequest
from obra.config.loaders import get_code_verify_preflight_config
from obra.display.observability import ProgressEmitter, VerbosityLevel
from obra.hybrid.handlers.validator_executor import ValidatorExecutionError, ValidatorExecutor
from obra.messages.validator import get_validator
from obra.prompts.agents import load_prompt

logger = logging.getLogger(__name__)

_TASK_ID_PATTERN = re.compile(r"S\d+\.T\d+(?:\.\d+)?")

# V0-arch is the only blocking severity. V0-spec is advisory (implementer catches it).
# Legacy "V0" (without sub-type) is treated as blocking for backward compat.
_BLOCKING_SEVERITIES = {"V0", "V0-ARCH"}


def apply_preflight_modifications(
    plan_items: list[dict[str, Any]],
    modifications: list[dict[str, Any]],
    state_manager: Any = None,
) -> int:
    """Apply Story Pre-flight task modifications in pass order.

    Args:
        plan_items: Mutable list of plan item dictionaries.
        modifications: Modification dictionaries from StoryPreflightResult.
        state_manager: Optional state manager exposing update_plan_items().

    Returns:
        Number of applied modifications.
    """
    if not plan_items or not modifications:
        return 0

    ordered = sorted(
        [mod for mod in modifications if isinstance(mod, dict)],
        key=lambda mod: int(mod.get("pass_number", 0) or 0),
    )
    item_map: dict[str, dict[str, Any]] = {}
    for item in plan_items:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("id", "")).strip()
        if item_id:
            item_map[item_id] = item

    applied = 0
    for mod in ordered:
        task_id = str(mod.get("task_id", "")).strip()
        field = str(mod.get("field", "")).strip().lower()
        reason = str(mod.get("reason", "")).strip()
        modified_value = mod.get("modified_value")
        if not task_id:
            continue

        item = item_map.get(task_id)
        if item is None:
            continue

        changed = False
        if field in {"desc", "description"}:
            text = str(modified_value or "")
            if "desc" in item:
                item["desc"] = text
            else:
                item["description"] = text
            changed = True
        elif field in {"verify", "acceptance_criteria", "criteria"}:
            item["verify"] = str(modified_value or "")
            changed = True
        elif field in {"depends_on", "dependency", "dependencies"}:
            parsed: list[str] = []
            if isinstance(modified_value, list):
                parsed = [str(dep).strip() for dep in modified_value if str(dep).strip()]
            else:
                raw = str(modified_value or "").strip()
                if raw:
                    try:
                        loaded = json.loads(raw)
                    except json.JSONDecodeError:
                        loaded = None
                    if isinstance(loaded, list):
                        parsed = [str(dep).strip() for dep in loaded if str(dep).strip()]
                    else:
                        parsed = [part.strip() for part in raw.split(",") if part.strip()]
            if "depends_on" in item:
                item["depends_on"] = parsed
            else:
                item["dependencies"] = parsed
            changed = True
        elif field == "status" and str(modified_value).strip().lower() == "removed":
            item["status"] = "skipped"
            notes = item.get("notes")
            if isinstance(notes, str) and notes.strip():
                item["notes"] = f"{notes}\nSkipped by pre-flight: {reason}"
            else:
                item["notes"] = f"Skipped by pre-flight: {reason}"
            changed = True
        elif field == "remove":
            item["status"] = "skipped"
            notes = item.get("notes")
            if isinstance(notes, str) and notes.strip():
                item["notes"] = f"{notes}\nSkipped by pre-flight: {reason}"
            else:
                item["notes"] = f"Skipped by pre-flight: {reason}"
            changed = True

        if not changed:
            continue

        applied += 1
        logger.info(
            "Pre-flight modified %s.%s: %s",
            task_id,
            field or "unknown",
            reason or "updated",
        )

    updater = getattr(state_manager, "update_plan_items", None)
    if callable(updater):
        try:
            updater(plan_items)
        except Exception:
            logger.debug("state_manager.update_plan_items failed", exc_info=True)

    return applied


class StoryPreflightHandler:
    """Run story-level pre-flight verification before execution."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        llm_config: dict[str, Any],
        log_event: Callable[..., None] | None = None,
        session_id: str = "",
        trace_id: str | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = dict(config or {})
        self._llm_config = dict(llm_config or {})
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._progress_emitter = progress_emitter
        self._runner = VerificationSessionRunner(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )
        self._finding_tracker: dict[
            tuple[str, str, str, int],
            dict[str, Any],
        ] = {}

    def handle(
        self,
        story_item: dict[str, Any],
        plan_items: list[dict[str, Any]],
        exploration_context: dict[str, Any] | None = None,
    ) -> StoryPreflightResult:
        """Run two-phase pre-flight checks and return story-level verification result."""
        preflight_config = get_code_verify_preflight_config()
        if not bool(preflight_config.get("enabled", True)):
            return StoryPreflightResult(
                findings=[],
                task_modifications=[],
                sense_check=None,
                resolved_findings=[],
                loop_metadata={
                    "sense_check_pass": 0,
                    "code_verify_passes": 0,
                    "total_modifications": 0,
                    "exit_reason": "preflight_disabled",
                },
                disposition="PROCEED",
            )

        story_id = str(story_item.get("id", "")).strip() or "unknown"
        working_tasks = self._extract_story_tasks(story_id, plan_items)
        if not working_tasks:
            return StoryPreflightResult(
                findings=[],
                task_modifications=[],
                sense_check={"sound": True, "issues": []},
                resolved_findings=[],
                loop_metadata={
                    "sense_check_pass": 0,
                    "code_verify_passes": 0,
                    "total_modifications": 0,
                    "exit_reason": "no_story_tasks",
                },
                disposition="PROCEED",
            )

        task_modifications: list[dict[str, Any]] = []
        resolved_findings: list[dict[str, Any]] = []
        final_findings: list[dict[str, Any]] = []
        sense_check_payload: dict[str, Any] | None = None
        self._finding_tracker = {}

        self._emit_preflight("start", story_id=story_id)

        sense_check_pass = 0
        if bool(preflight_config.get("sense_check", True)):
            sense_check_pass = 1
            working_tasks, sense_modifications, sense_check_payload = self._run_sense_check_phase(
                story_item=story_item,
                story_tasks=working_tasks,
                timeout_s=int(preflight_config.get("timeout_s", 600)),
            )
            task_modifications.extend(sense_modifications)
            self._emit_preflight(
                "sense_check",
                task_count=len(working_tasks),
                changes=len(sense_modifications),
            )

        max_passes = max(1, int(preflight_config.get("max_verification_passes", 5)))
        max_task_mods = max(0, int(preflight_config.get("max_task_modifications", 10)))
        timeout_s = max(30, int(preflight_config.get("timeout_s", 600)))
        scope_to_modified = bool(preflight_config.get("scope_to_modified", True))
        track_resolved = bool(preflight_config.get("track_resolved", True))
        checks = preflight_config.get("checks", ["C1", "C2", "C3", "C4", "C7", "C8", "C9"])
        checks_to_run = [str(check).strip() for check in checks if str(check).strip()]
        v0_action = str(preflight_config.get("v0_action", "escalate")).strip().lower()

        previous_keys: set[tuple[str, str, str, int]] = set()
        previous_lookup: dict[tuple[str, str, str, int], dict[str, Any]] = {}
        previous_v0_keys: set[tuple[str, str, str, int]] = set()
        persistent_keys: set[tuple[str, str, str, int]] = set()
        modified_last_pass = False
        modified_ids_previous_pass: set[str] = set()

        exit_reason = "max_passes_reached"
        code_verify_passes = 0

        for pass_num in range(1, max_passes + 1):
            scoped_tasks = self._determine_scope(
                tasks=working_tasks,
                modified_ids=modified_ids_previous_pass,
                pass_num=pass_num,
                scope_to_modified=scope_to_modified,
            )
            self._emit_preflight(
                "pass_start",
                pass_num=pass_num,
                task_count=len(scoped_tasks),
            )
            code_verify_passes = pass_num
            pass_result = self._run_code_verify_pass(
                scoped_tasks=scoped_tasks,
                exploration_context=exploration_context,
                timeout_s=timeout_s,
                checks=checks_to_run,
                pass_num=pass_num,
            )

            raw_findings = pass_result.get("findings", [])
            findings = [finding for finding in raw_findings if isinstance(finding, dict)]
            final_findings = findings

            current_lookup = {
                self._finding_key(finding): finding
                for finding in findings
                if self._finding_key(finding) is not None
            }
            current_keys = set(current_lookup.keys())
            current_v0_keys = {
                key
                for key, finding in current_lookup.items()
                if str(finding.get("severity", "")).upper() in {"V0", "V0-ARCH"}
            }

            if track_resolved:
                for key, finding in current_lookup.items():
                    self._finding_tracker[key] = {
                        **finding,
                        "pass_number": pass_num,
                    }

            for finding in findings:
                severity = str(finding.get("severity", "V1")).upper()
                self._emit_preflight(
                    "finding",
                    severity=severity,
                    description=str(finding.get("description", "Issue detected")),
                )

            if track_resolved and previous_lookup:
                resolved_keys = previous_keys - current_keys
                for key in sorted(resolved_keys):
                    resolved = dict(previous_lookup[key])
                    resolved["resolved_in_pass"] = pass_num
                    resolved_findings.append(resolved)

            if track_resolved and modified_last_pass:
                persistent_keys.update(previous_v0_keys & current_v0_keys)

            previous_keys = current_keys
            previous_lookup = current_lookup
            previous_v0_keys = current_v0_keys

            v0_findings = [
                finding
                for finding in findings
                if str(finding.get("severity", "")).upper() in _BLOCKING_SEVERITIES
            ]

            if not findings:
                exit_reason = "clean"
                break

            if not v0_findings:
                exit_reason = "non_blocking_findings"
                break

            pass_modifications, modified_ids = self._apply_v0_modifications(
                findings=v0_findings,
                working_tasks=working_tasks,
                pass_num=pass_num,
                max_task_modifications=max_task_mods,
            )
            task_modifications.extend(pass_modifications)

            for modification in pass_modifications:
                self._emit_preflight(
                    "adjusted",
                    task_id=modification["task_id"],
                    reason=modification["reason"],
                )

            if pass_modifications:
                modified_ids_previous_pass = modified_ids
                modified_last_pass = True
                continue

            modified_ids_previous_pass = set()
            modified_last_pass = False
            exit_reason = "v0_no_modifications"
            break

        blockers = [
            finding
            for finding in final_findings
            if str(finding.get("severity", "")).upper() in _BLOCKING_SEVERITIES
        ]

        disposition = "PROCEED"
        loop_metadata: dict[str, Any] = {
            "sense_check_pass": sense_check_pass,
            "code_verify_passes": code_verify_passes,
            "total_modifications": len(task_modifications),
            "exit_reason": exit_reason,
        }

        if blockers and exit_reason in {"max_passes_reached", "v0_no_modifications"}:
            if v0_action == "revise":
                disposition = "REVISE"
                loop_metadata["exit_reason"] = "v0_persistent_revise"
                revision_constraints: list[str] = []
                for finding in blockers:
                    check = str(finding.get("check", "")).strip().upper() or "C?"
                    description = str(finding.get("description", "")).strip() or "Blocking issue"
                    recommendation = (
                        str(finding.get("recommendation", "")).strip() or "Apply required fix"
                    )
                    revision_constraints.append(
                        f"[{check}] {description} -- Fix: {recommendation}"
                    )
                loop_metadata["revision_constraints"] = revision_constraints
            elif v0_action == "annotate":
                demoted_count = 0
                for finding in final_findings:
                    key = self._finding_key(finding)
                    if (
                        str(finding.get("severity", "")).upper() in _BLOCKING_SEVERITIES
                        and key is not None
                        and (not persistent_keys or key in persistent_keys)
                    ):
                        finding["severity"] = "V1"
                        finding["was_v0"] = True
                        finding["preflight_unresolved"] = True
                        finding["passes_attempted"] = code_verify_passes
                        demoted_count += 1
                disposition = "PROCEED"
                loop_metadata["exit_reason"] = "persistent_v0_demoted"
                logger.warning(
                    "!! Pre-flight: %d V0 findings annotated (unresolved after %d passes)",
                    demoted_count,
                    code_verify_passes,
                )
            else:
                disposition = "ESCALATE"
                loop_metadata["exit_reason"] = "v0_persistent_escalate"

        if disposition == "ESCALATE" and blockers:
            self._emit_preflight(
                "escalate",
                story_id=story_id,
                passes=code_verify_passes,
                description=str(blockers[0].get("description", "blocking issue persists")),
            )
        else:
            self._emit_preflight(
                "complete",
                story_id=story_id,
                passes=code_verify_passes,
                adjustments=len(task_modifications),
                blockers=len(
                    [
                        finding
                        for finding in final_findings
                        if str(finding.get("severity", "")).upper() in _BLOCKING_SEVERITIES
                    ]
                ),
            )

        return StoryPreflightResult(
            findings=final_findings,
            task_modifications=task_modifications,
            sense_check=sense_check_payload,
            resolved_findings=resolved_findings if track_resolved else [],
            loop_metadata=loop_metadata,
            disposition=disposition,
        )

    def _run_sense_check_phase(
        self,
        *,
        story_item: dict[str, Any],
        story_tasks: list[dict[str, Any]],
        timeout_s: int,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any] | None]:
        if not story_tasks:
            return story_tasks, [], {"sound": True, "issues": []}

        validator = ValidatorExecutor(
            self._working_dir,
            llm_config=self._llm_config,
            log_event=self._log_event,
            trace_id=self._trace_id,
            progress_emitter=self._progress_emitter,
        )
        prompt = self._build_sense_check_prompt(story_item=story_item, story_tasks=story_tasks)

        request = ValidatorRequest(
            stage="plan",
            subject_type="plan_items",
            subject_payload={"story_id": story_item.get("id"), "plan_items": story_tasks},
            prompt_id="sensecheck.plan",
            prompt_version="v1",
            compiled_prompt=prompt,
            timeout_s=timeout_s,
            config={"source": "preflight", "schema_validation": True, "prompt_provenance": True},
        )

        try:
            result = validator.handle(request)
        except (ValidatorExecutionError, Exception) as exc:  # defensive: pre-flight must continue
            logger.warning("Story preflight SenseCheck failed: %s", exc)
            return story_tasks, [], {"sound": True, "issues": [], "error": str(exc)}

        modifications = self._extract_sense_check_modifications(
            issues=result.issues,
            pass_num=0,
            task_ids={str(task.get("id", "")).strip() for task in story_tasks},
        )
        updated_tasks = copy.deepcopy(story_tasks)
        applied_modifications: list[dict[str, Any]] = []
        for modification in modifications:
            if self._apply_task_modification(updated_tasks, modification):
                applied_modifications.append(modification)

        return updated_tasks, applied_modifications, result.to_dict()

    def _run_code_verify_pass(
        self,
        *,
        scoped_tasks: list[dict[str, Any]],
        exploration_context: dict[str, Any] | None,
        timeout_s: int,
        checks: list[str],
        pass_num: int,
    ) -> dict[str, Any]:
        prompt = self._build_preflight_prompt(
            scoped_tasks=scoped_tasks,
            exploration_context=exploration_context,
            checks=checks,
            pass_num=pass_num,
        )
        try:
            result = self._runner.run_session(
                prompt=prompt,
                timeout_s=timeout_s,
                allowed_tools=["Read", "Grep", "Glob"],
            )
        except Exception as exc:
            logger.warning("Story preflight CodeVerify pass failed: %s", exc)
            return {"disposition": "HAS_GAPS", "findings": [], "verification_summary": {}, "error": str(exc)}

        if not isinstance(result, dict):
            return {
                "disposition": "HAS_GAPS",
                "findings": [],
                "verification_summary": {},
                "error": "CodeVerify pass returned invalid payload",
            }
        return result

    def _extract_story_tasks(
        self,
        story_id: str,
        plan_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        prefix = f"{story_id}.T"
        tasks: list[dict[str, Any]] = []
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            parent_id = str(item.get("parent_id", "")).strip()
            if item_id.startswith(prefix) or parent_id == story_id:
                tasks.append(copy.deepcopy(item))
        tasks.sort(key=lambda task: str(task.get("id", "")))
        return tasks

    def _determine_scope(
        self,
        *,
        tasks: list[dict[str, Any]],
        modified_ids: set[str],
        pass_num: int,
        scope_to_modified: bool,
    ) -> list[dict[str, Any]]:
        if pass_num == 1 or not scope_to_modified or not modified_ids:
            return copy.deepcopy(tasks)

        scoped_ids = set(modified_ids)
        for task in tasks:
            task_id = str(task.get("id", "")).strip()
            if not task_id:
                continue
            depends_on = self._normalize_depends_on(task.get("depends_on"))
            if depends_on & modified_ids:
                scoped_ids.add(task_id)

        scoped_tasks = [
            copy.deepcopy(task)
            for task in tasks
            if str(task.get("id", "")).strip() in scoped_ids
        ]
        if scoped_tasks:
            return scoped_tasks
        return copy.deepcopy(tasks)

    def _apply_v0_modifications(
        self,
        *,
        findings: list[dict[str, Any]],
        working_tasks: list[dict[str, Any]],
        pass_num: int,
        max_task_modifications: int,
    ) -> tuple[list[dict[str, Any]], set[str]]:
        modifications: list[dict[str, Any]] = []
        modified_ids: set[str] = set()

        if max_task_modifications <= 0:
            return modifications, modified_ids

        for finding in findings:
            if len(modifications) >= max_task_modifications:
                break
            modification = self._build_modification_from_finding(finding=finding, pass_num=pass_num)
            if modification is None:
                continue
            if self._apply_task_modification(working_tasks, modification):
                modifications.append(modification)
                modified_ids.add(str(modification.get("task_id", "")))

        return modifications, modified_ids

    def _extract_sense_check_modifications(
        self,
        *,
        issues: list[dict[str, Any]],
        pass_num: int,
        task_ids: set[str],
    ) -> list[dict[str, Any]]:
        modifications: list[dict[str, Any]] = []

        for issue in issues:
            if not isinstance(issue, dict):
                continue

            action = str(issue.get("action", "")).strip().lower()
            issue_type = str(issue.get("issue_type", "")).strip().lower()
            task_id = str(issue.get("task_id", "")).strip()
            affected = self._coerce_ids(issue.get("affected_items"))
            reason = (
                str(issue.get("reason", "")).strip()
                or str(issue.get("description", "")).strip()
                or issue_type
                or "SenseCheck structural adjustment"
            )

            is_remove = action in {"remove", "delete", "drop"} or "redund" in issue_type
            if is_remove:
                targets = [task_id] if task_id else affected
                for target in targets:
                    if target in task_ids:
                        modifications.append(
                            {
                                "task_id": target,
                                "field": "remove",
                                "reason": reason,
                                "modified_value": "",
                                "pass_number": pass_num,
                            }
                        )
                continue

            is_update = action in {"update", "modify", "adjust", "rewrite"}
            if not is_update and task_id == "" and not affected:
                continue

            target = task_id or (affected[0] if affected else "")
            if not target or target not in task_ids:
                continue

            field = str(issue.get("field", "")).strip() or "desc"
            modified_value = (
                issue.get("modified_value")
                or issue.get("new_value")
                or issue.get("suggested_simplification")
                or issue.get("description")
                or ""
            )
            modifications.append(
                {
                    "task_id": target,
                    "field": field,
                    "reason": reason,
                    "modified_value": str(modified_value),
                    "pass_number": pass_num,
                }
            )

        return modifications

    def _build_modification_from_finding(
        self,
        *,
        finding: dict[str, Any],
        pass_num: int,
    ) -> dict[str, Any] | None:
        task_id = str(finding.get("plan_ref", "")).strip()
        if not _TASK_ID_PATTERN.match(task_id):
            description = str(finding.get("description", ""))
            match = _TASK_ID_PATTERN.search(description)
            task_id = match.group(0) if match else ""

        recommendation = str(finding.get("recommendation", "")).strip()
        if not task_id or not recommendation:
            return None

        lower = recommendation.lower()
        if "depends_on" in lower or "dependenc" in lower:
            field = "depends_on"
        elif "acceptance" in lower or "verify" in lower or "criterion" in lower:
            field = "verify"
        else:
            field = "desc"

        reason = str(finding.get("description", "CodeVerify finding"))
        return {
            "task_id": task_id,
            "field": field,
            "reason": reason,
            "modified_value": recommendation,
            "pass_number": pass_num,
        }

    def _apply_task_modification(
        self,
        tasks: list[dict[str, Any]],
        modification: dict[str, Any],
    ) -> bool:
        task_id = str(modification.get("task_id", "")).strip()
        field = str(modification.get("field", "")).strip().lower()
        modified_value = str(modification.get("modified_value", ""))

        if not task_id:
            return False

        if field == "remove":
            before = len(tasks)
            tasks[:] = [task for task in tasks if str(task.get("id", "")).strip() != task_id]
            return len(tasks) != before

        target: dict[str, Any] | None = None
        for task in tasks:
            if str(task.get("id", "")).strip() == task_id:
                target = task
                break

        if target is None:
            return False

        if field in {"desc", "description", "title"}:
            if "desc" in target or "description" not in target:
                target["desc"] = modified_value
            else:
                target["description"] = modified_value
            return True

        if field in {"verify", "acceptance_criteria", "criteria"}:
            target["verify"] = modified_value
            return True

        if field in {"depends_on", "dependency", "dependencies"}:
            target["depends_on"] = self._parse_depends_on(modified_value)
            return True

        target[field] = modified_value
        return True

    def _build_sense_check_prompt(
        self,
        *,
        story_item: dict[str, Any],
        story_tasks: list[dict[str, Any]],
    ) -> str:
        template = load_prompt("story_preflight_sense_check_plan")
        objective = str(
            story_item.get("desc")
            or story_item.get("description")
            or story_item.get("title")
            or ""
        )
        formatted_plan_items = self._format_plan_items_for_prompt(story_tasks)
        return (
            template.replace("{formatted_plan_items}", formatted_plan_items).replace(
                "{objective}", objective
            )
        )

    def _build_preflight_prompt(
        self,
        *,
        scoped_tasks: list[dict[str, Any]],
        exploration_context: dict[str, Any] | None,
        checks: list[str],
        pass_num: int,
    ) -> str:
        template = load_prompt("code_verify_preflight")
        checks_text = ", ".join(checks) if checks else "C1, C2, C3, C4, C7, C8, C9"
        plan_payload = json.dumps(scoped_tasks, indent=2, sort_keys=True)
        exploration_markdown = self._render_exploration_context(exploration_context)

        return (
            template.replace("{checks}", checks_text)
            .replace("{pass_num}", str(pass_num))
            .replace("{working_dir}", str(self._working_dir))
            .replace("{plan_payload}", plan_payload)
            .replace("{exploration_context}", exploration_markdown)
        )

    def _render_exploration_context(self, exploration_context: Any) -> str:
        if exploration_context is None:
            return "None provided."

        to_markdown = getattr(exploration_context, "to_markdown", None)
        if callable(to_markdown):
            try:
                return str(to_markdown())
            except Exception:
                logger.debug("Failed to render exploration context", exc_info=True)

        if isinstance(exploration_context, (dict, list)):
            return json.dumps(exploration_context, indent=2, sort_keys=True)
        return str(exploration_context)

    def _finding_key(self, finding: dict[str, Any]) -> tuple[str, str, str, int] | None:
        task_id = str(finding.get("plan_ref", "")).strip()
        if not task_id:
            description = str(finding.get("description", ""))
            match = _TASK_ID_PATTERN.search(description)
            task_id = match.group(0) if match else ""

        check = str(finding.get("check", "")).strip().upper()
        file_path = str(finding.get("file", "")).strip()
        line_raw = finding.get("line", 0)
        try:
            line = int(line_raw)
        except (TypeError, ValueError):
            line = 0

        if not task_id or not check:
            return None
        return (task_id, check, file_path, line)

    def _parse_depends_on(self, value: str) -> list[str]:
        stripped = value.strip()
        if not stripped:
            return []
        if stripped.startswith("["):
            try:
                parsed = json.loads(stripped)
                if isinstance(parsed, list):
                    return [str(item).strip() for item in parsed if str(item).strip()]
            except json.JSONDecodeError:
                pass

        parts = [chunk.strip() for chunk in re.split(r"[,\n]", stripped)]
        return [part for part in parts if part]

    def _coerce_ids(self, value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        if isinstance(value, str) and value.strip():
            return [value.strip()]
        return []

    @staticmethod
    def _format_plan_items_for_prompt(items: list[dict[str, Any]]) -> str:
        if not items:
            return "(no plan items)"

        lines = []
        for item in items:
            item_id = item.get("id", "unknown")
            item_type = item.get("item_type") or item.get("type") or "task"
            title = item.get("title") or item.get("desc") or item.get("description") or "Untitled"
            lines.append(f"- [{item_id}] ({item_type}) {title}")
        return "\n".join(lines)

    def _normalize_depends_on(self, value: Any) -> set[str]:
        if isinstance(value, list):
            return {str(item).strip() for item in value if str(item).strip()}
        if isinstance(value, str) and value.strip():
            return {value.strip()}
        return set()

    def _emit_preflight(self, event: str, **kwargs: Any) -> None:
        emitter = self._progress_emitter
        if emitter is None:
            return

        verbosity = int(getattr(getattr(emitter, "config", None), "verbosity", 0))
        if verbosity < int(VerbosityLevel.PROGRESS):
            return

        message = get_validator(f"code_verify.preflight.{event}", **kwargs)

        timestamp_fn = getattr(emitter, "_timestamp", None)
        timestamp = timestamp_fn() if callable(timestamp_fn) else ""

        style = "cyan"
        if event == "complete":
            style = "green"
        elif event == "escalate":
            style = "red"
        elif event == "finding":
            severity = str(kwargs.get("severity", "")).upper()
            style = "red" if severity in {"V0", "V0-ARCH"} else "yellow"

        line = f"{timestamp}{message}"
        printer = getattr(emitter, "_print", None)
        if callable(printer):
            printer(line, style=style)
            return

        console = getattr(emitter, "console", None)
        if console is not None and hasattr(console, "print"):
            console.print(line, style=style)
