"""LLM Registry facade for Config Explorer.

Provides a simplified interface to obra.model_registry for use in the
config explorer widgets. This is the single source of truth for LLM
provider and model data in the explorer.

All model data is dynamically loaded from MODEL_REGISTRY - no hardcoded model names.
"""

from __future__ import annotations

from typing import Any

# Lazy-loaded caches
_PROVIDERS_CACHE: list[tuple[str, str, str]] | None = None
_MODELS_CACHE: dict[str, list[tuple[str, str, str]]] | None = None
_SPARK_REASONING_DEFAULTS: dict[tuple[str, str], str] = {
    ("openai", "gpt-5.3-codex-spark"): "high"
}

# Re-export from canonical location (obra.config.llm)
from obra.config.llm import ROLE_TIER_DEFAULTS


def get_role_tier_defaults(provider: str, role: str) -> dict[str, str]:
    """Get tier defaults for a specific provider and role.

    When "Let Obra choose" (value="default") is selected, these are the
    actual models that will be used at runtime.

    Args:
        provider: Provider ID (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)

    Returns:
        Dict mapping tier names (fast, medium, high) to model IDs.

    Example:
        >>> get_role_tier_defaults('anthropic', 'orchestrator')
        {'fast': 'sonnet', 'medium': 'opus', 'high': 'opus'}
    """
    provider_defaults = ROLE_TIER_DEFAULTS.get(provider, {})
    role_defaults = provider_defaults.get(role, {})
    if role_defaults:
        return role_defaults
    # Fall back to generic provider tier defaults
    return get_provider_tier_defaults(provider)


def resolve_tier_model_display(provider: str, role: str, tier: str, model_id: str) -> str:
    """Resolve a tier's model to display name, using role defaults for 'default'.

    When model_id is 'default', uses ROLE_TIER_DEFAULTS to show what Obra
    will actually use for this provider/role/tier combination.

    Args:
        provider: Provider ID (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)
        tier: Tier name (fast, medium, high)
        model_id: Model ID (may be 'default')

    Returns:
        Human-readable model display name
    """
    from obra.model_registry import MODEL_REGISTRY

    provider_config = MODEL_REGISTRY.get(provider)
    if not provider_config:
        return model_id

    # If not "default", just resolve the model directly
    if model_id != "default":
        model_info = provider_config.models.get(model_id)
        return model_info.display_name if model_info else model_id

    # For "default", use the Obra-recommended role/tier defaults
    role_defaults = get_role_tier_defaults(provider, role)
    actual_id = role_defaults.get(tier, provider_config.default_model or "auto")
    model_info = provider_config.models.get(actual_id)
    return model_info.display_name if model_info else actual_id


def build_tier_preview(
    orch_provider: str,
    orch_model: str,
    impl_provider: str,
    impl_model: str,
    *,
    orch_tiers: dict[str, str] | None = None,
    impl_tiers: dict[str, str] | None = None,
) -> str:
    """Build side-by-side preview text showing tier assignments.

    Shows Orchestrator on left, Implementation on right. Used by both
    SimpleLLMView and ModerateLLMView for consistent preview display.

    Args:
        orch_provider: Orchestrator provider ID
        orch_model: Orchestrator model ID (used if orch_tiers not provided)
        impl_provider: Implementation provider ID
        impl_model: Implementation model ID (used if impl_tiers not provided)
        orch_tiers: Optional dict of tier->model for orchestrator
        impl_tiers: Optional dict of tier->model for implementation

    Returns:
        Formatted string with side-by-side tier assignments.
    """

    # Resolve each tier - use per-tier values if provided, otherwise use role model
    def get_orch_tier(tier: str) -> str:
        model = (orch_tiers or {}).get(tier, orch_model)
        return resolve_tier_model_display(orch_provider, "orchestrator", tier, model)

    def get_impl_tier(tier: str) -> str:
        model = (impl_tiers or {}).get(tier, impl_model)
        return resolve_tier_model_display(impl_provider, "implementation", tier, model)

    # Build side-by-side layout with fixed column widths
    # Left column: 24 chars, Right column: rest
    def row(left: str, right: str) -> str:
        return f"{left:<24} {right}"

    lines = [
        row("Orchestrator:", "Implementation:"),
        row(f"  Fast:   {get_orch_tier('fast')}", f"  Fast:   {get_impl_tier('fast')}"),
        row(
            f"  Medium: {get_orch_tier('medium')}",
            f"  Medium: {get_impl_tier('medium')}",
        ),
        row(f"  High:   {get_orch_tier('high')}", f"  High:   {get_impl_tier('high')}"),
    ]
    return "\n".join(lines)


def _extract_tier_model(tier_value: Any, fallback_model: str = "default") -> str:
    """Extract model id from a tier entry (string or mapping)."""
    if isinstance(tier_value, dict):
        model = tier_value.get("model", fallback_model)
        return str(model)
    if tier_value is None:
        return fallback_model
    return str(tier_value)


def _normalize_reasoning_tiers(
    reasoning_tiers: dict[str, str] | None,
    fallback_reasoning: str,
) -> dict[str, str]:
    """Normalize reasoning tiers with fallbacks for missing values."""
    return {
        "fast": (reasoning_tiers or {}).get("fast", fallback_reasoning),
        "medium": (reasoning_tiers or {}).get("medium", fallback_reasoning),
        "high": (reasoning_tiers or {}).get("high", fallback_reasoning),
    }


def build_authoritative_llm_preview(
    *,
    orch_provider: str,
    impl_provider: str,
    orch_tiers: dict[str, Any],
    impl_tiers: dict[str, Any],
    orch_reasoning_tiers: dict[str, str] | None,
    impl_reasoning_tiers: dict[str, str] | None,
    orch_fallback_reasoning: str = "medium",
    impl_fallback_reasoning: str = "medium",
    role_configs: dict[str, dict[str, Any]] | None = None,
) -> str:
    """Build preview from effective parent tiers + explicit child overrides.

    This is intended for menu previews where the displayed state should reflect
    final effective config, including explicit per-action overrides.
    """

    normalized_orch_reasoning = _normalize_reasoning_tiers(
        orch_reasoning_tiers, orch_fallback_reasoning
    )
    normalized_impl_reasoning = _normalize_reasoning_tiers(
        impl_reasoning_tiers, impl_fallback_reasoning
    )

    preview = build_tier_preview(
        orch_provider=orch_provider,
        orch_model="default",
        impl_provider=impl_provider,
        impl_model="default",
        orch_tiers={
            "fast": _extract_tier_model(orch_tiers.get("fast"), "default"),
            "medium": _extract_tier_model(orch_tiers.get("medium"), "default"),
            "high": _extract_tier_model(orch_tiers.get("high"), "default"),
        },
        impl_tiers={
            "fast": _extract_tier_model(impl_tiers.get("fast"), "default"),
            "medium": _extract_tier_model(impl_tiers.get("medium"), "default"),
            "high": _extract_tier_model(impl_tiers.get("high"), "default"),
        },
    )

    lines = [
        preview,
        "",
        "Reasoning by tier:",
        (
            "  Orchestrator: "
            f"fast={normalized_orch_reasoning['fast']}, "
            f"medium={normalized_orch_reasoning['medium']}, "
            f"high={normalized_orch_reasoning['high']}"
        ),
        (
            "  Implementation: "
            f"fast={normalized_impl_reasoning['fast']}, "
            f"medium={normalized_impl_reasoning['medium']}, "
            f"high={normalized_impl_reasoning['high']}"
        ),
    ]

    override_lines: list[str] = []
    for action, role_cfg in sorted((role_configs or {}).items()):
        if not isinstance(role_cfg, dict):
            continue
        parts: list[str] = []
        if role_cfg.get("provider"):
            parts.append(f"provider={role_cfg['provider']}")
        if role_cfg.get("model"):
            parts.append(f"model={role_cfg['model']}")
        if role_cfg.get("reasoning_level"):
            parts.append(f"reasoning={role_cfg['reasoning_level']}")
        if parts:
            override_lines.append(f"  {action}: {', '.join(parts)}")

    lines.append("")
    if override_lines:
        lines.append("Explicit child overrides (Menu 3):")
        lines.extend(override_lines)
    else:
        lines.append("Explicit child overrides (Menu 3): none")

    return "\n".join(lines)


def _load_providers() -> list[tuple[str, str, str]]:
    """Load provider definitions from MODEL_REGISTRY.

    Uses authoritative data from MODEL_REGISTRY:
    - name: Provider company (Anthropic, Google, OpenAI, Ollama)
    - cli: Product/CLI name (Claude, Gemini, Codex, Ollama)
    - description: Short description for UI

    Returns:
        List of (provider_id, display_name, description) tuples.
        display_name format: "{name} {cli}" (e.g., "Anthropic Claude")
        If name == cli (e.g., Ollama), just use the name once.

        Ordered: Claude, Codex, Gemini, Ollama, then any future providers.
    """
    from obra.model_registry import MODEL_REGISTRY

    # Preferred ordering for UI (new providers go at end)
    provider_order = ["anthropic", "openai", "google", "ollama"]

    providers = []
    for provider_id, config in MODEL_REGISTRY.items():
        # Format: "Anthropic Claude", "Google Gemini", "OpenAI Codex"
        # But if name == cli (Ollama), just use the name once
        if config.name.lower() == config.cli.lower():
            display_name = config.name
        else:
            display_name = f"{config.name} {config.cli}"
        description = config.description
        providers.append((provider_id, display_name, description))

    # Sort by preferred order, unknown providers go at end
    def sort_key(p: tuple[str, str, str]) -> int:
        try:
            return provider_order.index(p[0])
        except ValueError:
            return len(provider_order)  # Unknown providers at end

    providers.sort(key=sort_key)
    return providers


def _load_models() -> dict[str, list[tuple[str, str, str]]]:
    """Load model definitions per provider from MODEL_REGISTRY.

    Smart alias filtering:
    - If alias target exists in registry: Hide alias (avoid duplicates)
    - If alias target doesn't exist: Show FIRST alias only (prefer shorter names)

    Models are sorted by tier: recommended → high → medium → fast.

    Returns:
        Dict mapping provider_id to list of (model_id, display_string, tier) tuples.
        Tier is one of: 'recommended', 'high', 'medium', 'fast'.
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus, resolve_quality_tier

    # Tier sort order: recommended first, then high → medium → fast
    tier_order = {"recommended": 0, "high": 1, "medium": 2, "fast": 3}

    models = {}
    for provider_name, provider_config in MODEL_REGISTRY.items():
        # Start with recommended option
        provider_models: list[tuple[str, str, str]] = [
            ("default", "Let Obra choose", "recommended")
        ]

        # Track which alias targets we've already included
        seen_targets = set()

        # Add non-deprecated models with smart alias filtering
        for model_id, model_info in provider_config.models.items():
            # Skip deprecated models
            if model_info.status == ModelStatus.DEPRECATED:
                continue

            # Smart alias handling
            if hasattr(model_info, "resolves_to") and model_info.resolves_to is not None:
                target = model_info.resolves_to

                # If target exists in registry, skip this alias (avoid duplicates)
                if target in provider_config.models:
                    continue

                # If we've already shown an alias for this target, skip this one
                if target in seen_targets:
                    continue

                # Mark this target as seen
                seen_targets.add(target)

            # Get the quality tier for this model
            tier = resolve_quality_tier(provider_name, model_id)

            display = model_info.display_name
            if model_info.description:
                display += f" - {model_info.description}"
            provider_models.append((model_id, display, tier))

        # Sort by tier order (recommended first, then high → medium → fast)
        provider_models.sort(key=lambda x: tier_order.get(x[2], 99))

        models[provider_name] = provider_models

    return models


def get_providers() -> list[tuple[str, str, str]]:
    """Get list of available LLM providers.

    Returns:
        List of (provider_id, display_name, description) tuples.

    Example:
        >>> providers = get_providers()
        >>> providers[0]
        ('anthropic', 'Claude', 'AI thinking partner for developers')
    """
    global _PROVIDERS_CACHE
    if _PROVIDERS_CACHE is None:
        _PROVIDERS_CACHE = _load_providers()
    return _PROVIDERS_CACHE


def get_models() -> dict[str, list[tuple[str, str, str]]]:
    """Get available models per provider, sorted by tier.

    Models are sorted: recommended → high → medium → fast.

    Returns:
        Dict mapping provider_id to list of (model_id, display_string, tier) tuples.
        Tier is one of: 'recommended', 'high', 'medium', 'fast'.

    Example:
        >>> models = get_models()
        >>> models['anthropic'][0]
        ('default', 'Let Obra choose', 'recommended')
        >>> models['anthropic'][1]
        ('opus', 'Claude Opus 4.6 - ...', 'high')
    """
    global _MODELS_CACHE
    if _MODELS_CACHE is None:
        _MODELS_CACHE = _load_models()
    return _MODELS_CACHE


def get_model_cost(provider: str, model_id: str) -> str:
    """Get cost indicator for a model based on quality tier.

    Derives cost dynamically from the model's quality tier:
    - high tier: '$$$'
    - medium tier: '$$'
    - fast tier: '$'
    - Local providers (api_key_env is None): 'Free'

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier

    Returns:
        Cost indicator string: '$', '$$', '$$$', or 'Free'

    Example:
        >>> get_model_cost('anthropic', 'opus')
        '$$$'
        >>> get_model_cost('anthropic', 'haiku')
        '$'
        >>> get_model_cost('ollama', 'qwen2.5-coder:32b')
        'Free'
    """
    from obra.model_registry import MODEL_REGISTRY, resolve_quality_tier

    # Check if provider is local (no API key required)
    config = MODEL_REGISTRY.get(provider)
    if config and config.api_key_env is None:
        return "Free"

    # Handle 'default' model by using provider's default
    if model_id == "default":
        if config and config.default_model:
            model_id = config.default_model
        else:
            return "$$"  # Safe default for unknown

    # Derive cost from quality tier
    tier = resolve_quality_tier(provider, model_id)
    tier_to_cost = {
        "high": "$$$",
        "medium": "$$",
        "fast": "$",
    }
    return tier_to_cost.get(tier, "$$")


def supports_thinking(provider: str, model_id: str) -> bool:
    """Check whether a model supports extended thinking.

    Delegates to obra.model_registry.supports_extended_thinking().

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier

    Returns:
        True if extended thinking is supported, False otherwise.

    Example:
        >>> supports_thinking('anthropic', 'opus')
        True
        >>> supports_thinking('anthropic', 'haiku')
        False
    """
    from obra.model_registry import supports_extended_thinking

    # Handle 'default' model by using provider's default
    if model_id == "default":
        from obra.model_registry import MODEL_REGISTRY

        config = MODEL_REGISTRY.get(provider)
        if config and config.default_model:
            model_id = config.default_model
        else:
            return True  # Safe default

    return supports_extended_thinking(provider, model_id)


def get_model_default_reasoning(
    provider: str,
    model_id: str,
    fallback_reasoning: str = "medium",
) -> str:
    """Get model-specific default reasoning level for explorer selections.

    Returns:
        Model-specific default when defined, otherwise the provided fallback.
    """
    return _SPARK_REASONING_DEFAULTS.get((provider, model_id), fallback_reasoning)


def get_provider_tier_defaults(provider: str) -> dict[str, str]:
    """Get mapping of quality tiers to default model IDs for a provider.

    Used by personas to resolve tier references to actual models.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)

    Returns:
        Dict mapping tier ('fast', 'medium', 'high') to model_id.

    Example:
        >>> get_provider_tier_defaults('anthropic')
        {'fast': 'haiku', 'medium': 'sonnet', 'high': 'opus'}
    """
    from obra.config.loaders import (
        get_provider_tier_defaults as get_runtime_provider_tier_defaults,
    )
    from obra.model_registry import (
        MODEL_REGISTRY,
        resolve_quality_tier,
    )

    runtime_defaults = get_runtime_provider_tier_defaults()
    provider_defaults = runtime_defaults.get(provider)
    if isinstance(provider_defaults, dict) and provider_defaults:
        return {
            tier: model
            for tier, model in provider_defaults.items()
            if tier in {"fast", "medium", "high"}
        }

    config = MODEL_REGISTRY.get(provider)
    if not config:
        return {}

    tier_defaults: dict[str, str] = {}
    for model_id, model_info in config.models.items():
        # Skip deprecated models and aliases
        from obra.model_registry import ModelStatus

        if model_info.status == ModelStatus.DEPRECATED:
            continue
        if model_info.resolves_to is not None:
            continue

        tier = resolve_quality_tier(provider, model_id)
        # Use first model found for each tier (prefer shorter aliases)
        if tier not in tier_defaults:
            tier_defaults[tier] = model_id

    return tier_defaults


def clear_cache() -> None:
    """Clear cached provider and model data.

    Useful for testing or when MODEL_REGISTRY is updated.
    """
    global _PROVIDERS_CACHE, _MODELS_CACHE
    _PROVIDERS_CACHE = None
    _MODELS_CACHE = None
