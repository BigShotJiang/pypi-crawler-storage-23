"""Display utilities for Obra using Rich console.

This module provides a configured Rich Console and error handling utilities.

Encoding Strategy (following Python best practices):
---------------------------------------------------
UTF-8 mode is enforced at CLI startup. This is the standard
approach used by major Python CLI tools (pip, poetry, black, etc.).

If encoding issues still occur despite UTF-8 enforcement, the
handle_encoding_errors decorator provides helpful guidance to users,
following Rich's own recommendation (GitHub Issue #212).

References:
- https://dev.to/methane/python-use-utf-8-mode-on-windows-212i
- https://peps.python.org/pep-0529/
- https://github.com/willmcgugan/rich/issues/212
"""

import functools
import sys
from collections.abc import Callable
from typing import Any, TypeVar

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from obra.display.charset import (
    get_unicode_support,
    glyphs,
    reset_detection,
)
from obra.display.closeout import (
    CloseoutContext,
    TerminationState,
    build_closeout_message,
)
from obra.display.escalation import EscalationRenderer
from obra.display.errors import (
    ERROR_CODE_MAP,
    ErrorDisplay,
    display_error,
    display_obra_error,
    get_error_display,
)
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
    VerbosityLevel,
    set_runtime_verbosity,
)
from obra.display.pipeline import (
    PIPELINE_STAGES,
    PipelineRenderer,
    PipelineStage,
    StageState,
)

# Type variable for decorator
F = TypeVar("F", bound=Callable[..., Any])


def handle_encoding_errors[F: Callable[..., Any]](func: F) -> F:
    """Decorator to catch encoding errors with user-friendly messages.

    This follows Rich's recommended approach: when encoding fails,
    provide clear guidance on how to fix the environment rather than
    silently degrading functionality.

    Example:
        @app.command()
        @handle_encoding_errors
        def my_command():
            console.print("Starting...")
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except UnicodeEncodeError as e:
            # Use raw print to avoid any Rich formatting issues
            print("\n[ERROR] Terminal encoding issue detected.")
            print(f"        Character: {e.object[e.start : e.end]!r}")
            print("\nThis usually means your terminal is not configured for UTF-8.")
            print("\nSolutions:")
            print("  1. Use Windows Terminal (recommended) instead of cmd.exe")
            print("  2. Set environment variable: PYTHONUTF8=1")
            print("  3. Set environment variable: PYTHONIOENCODING=utf-8")
            print("  4. In cmd.exe, run: chcp 65001")
            print("\nFor more info: https://obra.dev/docs/troubleshooting/windows-unicode")

            # Import typer here to avoid circular imports
            import typer

            raise typer.Exit(1) from None

    return wrapper  # type: ignore[return-value]


# Module-level console instances
# Standard Rich Console - UTF-8 is enforced at CLI startup
console = Console()
# Console for stderr (warnings, deprecation notices) - keeps stdout clean for JSON/piping
err_console = Console(stderr=True)


def refresh_console_streams() -> None:
    """Refresh console file handles to use current sys.stdout/sys.stderr.

    This must be called after any code that redirects sys.stdout/sys.stderr
    (e.g., session logging TeeWriter) to ensure Rich Console output is captured.

    Rich Console caches the file handle at construction time, so if sys.stdout
    is replaced after the Console is created, output bypasses the new stream.
    """
    # Update the file handles to point to current sys.stdout/sys.stderr
    # Rich Console stores the file in _file attribute
    console._file = sys.stdout
    err_console._file = sys.stderr


def print_error(message: str, detail: str = "") -> None:
    """Print an error message with consistent styling.

    Args:
        message: Main error message
        detail: Optional additional detail
    """
    text = Text()
    text.append("Error: ", style="bold red")
    text.append(message)
    if detail:
        text.append(f"\n{detail}", style="dim")
    console.print(text)


def print_success(message: str) -> None:
    """Print a success message with consistent styling.

    Args:
        message: Success message to display
    """
    text = Text()
    text.append("Success: ", style="bold green")
    text.append(message)
    console.print(text)


def print_warning(message: str) -> None:
    """Print a warning message with consistent styling.

    Args:
        message: Warning message to display
    """
    text = Text()
    text.append("Warning: ", style="bold yellow")
    text.append(message)
    console.print(text)


def print_info(message: str) -> None:
    """Print an info message with consistent styling.

    Args:
        message: Info message to display
    """
    text = Text()
    text.append("Info: ", style="bold blue")
    text.append(message)
    console.print(text)


def print_banner() -> None:
    """Print the Obra startup banner.

    Displays a minimal, confident banner at session start.
    Design: Clean typography with the core workflow as tagline.
    """
    banner = """


                     OBRA

               plan  execute  done


"""
    console.print(banner, style="bold")


def print_panel(content: str, title: str = "", style: str = "blue") -> None:
    """Print content in a bordered panel.

    Args:
        content: Content to display inside panel
        title: Optional panel title
        style: Border style/color
    """
    panel = Panel(content, title=title, border_style=style)
    console.print(panel)


def create_table(title: str = "", show_header: bool = True) -> Table:
    """Create a styled table for consistent output.

    Args:
        title: Optional table title
        show_header: Whether to show column headers

    Returns:
        Configured Rich Table instance
    """
    return Table(
        title=title,
        show_header=show_header,
        header_style="bold cyan",
        border_style="blue",
    )


__all__ = [
    "ERROR_CODE_MAP",
    "CloseoutContext",
    "EscalationRenderer",
    "ErrorDisplay",
    "ObservabilityConfig",
    "PIPELINE_STAGES",
    "PipelineRenderer",
    "PipelineStage",
    "ProgressEmitter",
    "StageState",
    "TerminationState",
    "VerbosityLevel",
    "build_closeout_message",
    "console",
    "create_table",
    "display_error",
    "display_obra_error",
    "err_console",
    "get_error_display",
    "get_unicode_support",
    "glyphs",
    "handle_encoding_errors",
    "print_banner",
    "print_error",
    "print_info",
    "print_panel",
    "print_success",
    "print_warning",
    "refresh_console_streams",
    "reset_detection",
    "set_runtime_verbosity",
]
