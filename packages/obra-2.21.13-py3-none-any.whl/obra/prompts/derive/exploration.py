"""Prompts for derivation/planning operations.

Contains prompts extracted from obra/hybrid/handlers/derive.py as part of
the prompt library refactoring (REFACTOR-PROMPT-LIBRARY-001).

Prompts:
    EXPLORATION_PROMPT_TEMPLATE: Template for codebase exploration
    build_exploration_prompt: Builder for exploration prompts
    build_task_classification_prompt: Builder for task-to-step classification
"""

from __future__ import annotations

__all__ = [
    "EXPLORATION_PROMPT_TEMPLATE",
    "build_exploration_prompt",
    "build_task_classification_prompt",
]

# Exploration prompt template for discovering codebase patterns (ADR-055)
# Designed to work with any LLM provider, outputs structured JSON
EXPLORATION_PROMPT_TEMPLATE = """## Exploration Task

You are exploring a codebase to help an agent understand patterns before implementation.

**Objective**: {objective}
**Work Type**: {work_type}
**Working Directory**: {working_dir}

### Instructions

1. Search for existing patterns relevant to this task
2. Identify utilities the agent should use (not reinvent)
3. Note architectural constraints and conventions
4. List relevant files (max {max_relevant_files})

### Search Strategy

Focus on finding:
1. **Similar implementations**: How are similar features/fixes implemented?
2. **Related utilities**: What helper functions exist that could be reused?
3. **Conventions**: What naming patterns, parameter conventions, and interfaces are used?
4. **Constraints**: What architectural rules must be followed?

### Output Format

Return structured JSON (and ONLY JSON, no markdown code blocks):

```json
{{
  "patterns": [
    {{
      "file": "path/to/file.py",
      "line": 123,
      "pattern": "Description of pattern found",
      "relevance": "Why this matters for the task"
    }}
  ],
  "relevant_files": [
    {{
      "path": "path/to/file.py",
      "reason": "Why agent should read this"
    }}
  ],
  "utilities": [
    {{
      "name": "function_name()",
      "location": "path/to/file.py:line",
      "purpose": "What it does and when to use it"
    }}
  ],
  "constraints": ["Constraint description that must be followed"],
  "queries_executed": ["search query 1", "search query 2"]
}}
```

### Quality Guidelines

- Be **concise**: Focus on actionable information for implementation
- Be **specific**: Include exact file paths, line numbers, function names
- Be **relevant**: Only include patterns/utilities directly related to the task
- Use short phrases: 1 line per item, avoid long sentences (<=120 chars per item)
- **Limit scope**: Max {max_relevant_files} relevant files, max 5 patterns, max 5 utilities

Return ONLY the JSON content, no additional text or explanation.
"""


def build_exploration_prompt(
    objective: str,
    work_type: str,
    working_dir: str,
    max_relevant_files: int,
) -> str:
    """Build the exploration prompt for codebase discovery.

    Args:
        objective: The task objective to explore for
        work_type: Type of work (feature, bug, refactoring, etc.)
        working_dir: Working directory path
        max_relevant_files: Maximum number of relevant files to list

    Returns:
        Formatted exploration prompt string
    """
    return EXPLORATION_PROMPT_TEMPLATE.format(
        objective=objective,
        work_type=work_type,
        working_dir=working_dir,
        max_relevant_files=max_relevant_files,
    )


def build_task_classification_prompt(
    userplan_steps: list[dict],
    items: list[dict],
) -> str:
    """Build the task classification prompt for mapping tasks to UserPlan steps.

    Args:
        userplan_steps: List of UserPlan step dicts with 'id', 'title', and optional 'description'
        items: List of task dicts with 'id', 'title', and optional 'description'

    Returns:
        Formatted classification prompt string
    """
    prompt_parts = [
        "Classify each task to the UserPlan step it implements.",
        'Output JSON only: {"mappings": [{"task_id": "T1", "step_id": "UP-...:S1"}, ...]}',
        "",
        "UserPlan Steps:",
    ]
    for step in userplan_steps:
        prompt_parts.append(f"- {step['id']}: {step['title']}")
        if step.get("description"):
            desc = step["description"][:200]  # Truncate if long
            prompt_parts.append(f"  {desc}")

    prompt_parts.extend(["", "Tasks to classify:"])
    for item in items:
        prompt_parts.append(f"- {item['id']}: {item['title']}")
        desc = item.get("description", "")[:200]  # Truncate if long
        if desc:
            prompt_parts.append(f"  {desc}")

    prompt_parts.extend(
        [
            "",
            "Rules:",
            "- Each task maps to exactly one step",
            "- Choose the step whose goal this task primarily implements",
            "- Output valid JSON with mappings array",
        ]
    )

    return "\n".join(prompt_parts)
