"""Prompt builder for plan integrity auto-repair."""

from __future__ import annotations

import json
from typing import Any


def build_plan_repair_prompt(
    plan_items: list[dict[str, Any]],
    violations: list[Any],
    allowed_ops: list[str] | None = None,
    constraints: list[str] | None = None,
) -> str:
    """Build a deterministic prompt for repairing plan integrity violations."""
    if allowed_ops is None:
        allowed_ops = ["add_tasks", "correct_depth", "move_items"]
    if constraints is None:
        constraints = [
            "Preserve existing valid IDs and hierarchy wherever possible.",
            "Apply the minimal delta needed to fix listed violations.",
            "Do not add new epics.",
        ]

    normalized_violations: list[dict[str, Any]] = []
    for violation in violations:
        code = getattr(violation, "code", "")
        code_value = getattr(code, "value", code)
        item_ids = getattr(violation, "item_ids", [])
        message = getattr(violation, "message", "")
        normalized_violations.append(
            {
                "code": str(code_value),
                "item_ids": [str(item_id) for item_id in item_ids if str(item_id).strip()],
                "message": str(message),
            }
        )

    return (
        "Repair the plan graph to satisfy all integrity violations.\n\n"
        "Allowed operations:\n"
        f"{json.dumps(allowed_ops, indent=2)}\n\n"
        "Preservation constraints:\n"
        f"{json.dumps(constraints, indent=2)}\n\n"
        "Violations to fix (exact):\n"
        f"{json.dumps(normalized_violations, indent=2)}\n\n"
        "Current plan graph JSON:\n"
        f"{json.dumps(plan_items, indent=2)}\n\n"
        "Output requirements:\n"
        "- Return ONLY the repaired plan_items as a JSON array.\n"
        "- Do not include explanations, markdown, or extra keys.\n"
        "- Keep unaffected items unchanged unless required by a listed violation."
    )
