"""Template prompts for project initialization.

This package contains template content for Obra-managed projects:
- claude_md: Default CLAUDE.md template
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # claude_md.py exports
    "DEFAULT_OBRA_CLAUDE_MD": ".claude_md",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
