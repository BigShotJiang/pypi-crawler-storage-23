"""Cleanup epic generation from skip records."""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.config import load_config
from obra.config.loaders import get_cleanup_investigation_config
from obra.execution.skip_record import (
    SkipReason,
    SkipRecord,
    SkipStatus,
    list_skip_records,
)

# DEPRECATED: Use get_cleanup_investigation_config() from obra.config.loaders
MAX_HINTS = 5
TIER_GAP = 1
TIER_CONTEXT = 2


@dataclass
class CleanupStory:
    """Grouped cleanup story for a skip reason."""

    skip_records: list[SkipRecord]
    title: str
    reason_group: SkipReason


@dataclass
class CleanupEpic:
    """Cleanup epic grouping skips into stories."""

    stories: list[CleanupStory]
    total_skips: int
    created_at: str


def generate_cleanup_epic(
    skip_records: list[SkipRecord] | None = None,
    base_dir: str | Path | None = None,
) -> CleanupEpic:
    """Generate a cleanup epic from pending skip records."""
    if skip_records is None:
        skip_records = list_skip_records(base_dir=base_dir, status=SkipStatus.PENDING)

    grouped: dict[SkipReason, list[SkipRecord]] = defaultdict(list)
    for record in skip_records:
        grouped[record.reason].append(record)

    stories: list[CleanupStory] = []
    for reason, records in grouped.items():
        title = f"Resolve {reason.value} skips ({len(records)})"
        stories.append(CleanupStory(skip_records=records, title=title, reason_group=reason))

    stories.sort(key=lambda s: s.title)
    return CleanupEpic(
        stories=stories,
        total_skips=len(skip_records),
        created_at=datetime.now(UTC).isoformat(),
    )


def generate_investigation_summary(skip: SkipRecord) -> str:
    """Generate a markdown investigation summary for a skip record."""
    # Load investigation config from config file
    config = get_cleanup_investigation_config()
    max_hints = config["max_hints"]
    tier_gap = config["tier_gap"]
    tier_context = config["tier_context"]

    hints: list[str] = []
    logs = skip.error_logs or ""
    if logs:
        for line_text in logs.splitlines():
            stripped = line_text.strip()
            if any(token in stripped.lower() for token in ("error", "exception", "failed")):
                hints.append(stripped[:200])
            if len(hints) >= max_hints:
                break
    if not hints:
        hints.append("No direct error hints found in logs.")

    if skip.tier == tier_gap:
        recommendation = "Action required to resolve the gap."
    elif skip.tier == tier_context:
        recommendation = "Informational; review if unexpected."
    else:
        recommendation = "Intentional skip; verify if still desired."

    summary = [
        f"### Skip: {skip.task_id}",
        "",
        f"**Source**: {skip.source.value}",
        f"**Reason**: {skip.reason.value}",
        f"**Description**: {skip.description}",
        "",
        "**Root Cause Hints**:",
    ]
    summary.extend([f"- {hint}" for hint in hints])
    summary.extend(
        [
            "",
            "**Recommended Resolution**:",
            f"- {recommendation}",
        ]
    )
    return "\n".join(summary)


def _build_machine_plan(epic: CleanupEpic) -> dict[str, Any]:
    stories_payload: list[dict[str, Any]] = []
    story_index = 1
    for story in epic.stories:
        tasks_payload = []
        task_index = 1
        for record in story.skip_records:
            task_id = f"S{story_index}.T{task_index}"
            tasks_payload.append(
                {
                    "id": task_id,
                    "desc": record.description or f"Resolve skip {record.id}",
                    "status": "pending",
                    "verify": "Skip resolved or deferred with notes",
                    "notes": generate_investigation_summary(record),
                }
            )
            task_index += 1

        stories_payload.append(
            {
                "id": f"S{story_index}",
                "title": story.title,
                "status": "pending",
                "tasks": tasks_payload,
            }
        )
        story_index += 1

    return {
        "work_id": "SKIP-CLEANUP-001",
        "version": 1,
        "created": epic.created_at,
        "last_updated": epic.created_at,
        "epics": [
            {
                "id": "E1",
                "title": "Skip Cleanup Epic",
                "status": "pending",
                "stories": stories_payload,
            }
        ],
        "completion_checklist": [
            "All cleanup tasks completed or deferred",
            "Skip registry reviewed",
        ],
    }


def export_cleanup_as_machine_plan(
    epic: CleanupEpic,
    output_dir: str | Path | None = None,
) -> Path:
    """Export cleanup epic to MACHINE_PLAN.json."""
    config = load_config()
    cleanup_config = config.get("orchestration", {}).get("cleanup", {})
    target_dir = (
        Path(output_dir)
        if output_dir is not None
        else Path(cleanup_config.get("output_dir", ".obra/skip-tracking/cleanup"))
    )
    target_dir.mkdir(parents=True, exist_ok=True)

    plan_payload = _build_machine_plan(epic)
    output_path = target_dir / "CLEANUP_MACHINE_PLAN.json"
    output_path.write_text(json.dumps(plan_payload, indent=2))
    return output_path


__all__ = [
    "CleanupEpic",
    "CleanupStory",
    "export_cleanup_as_machine_plan",
    "generate_cleanup_epic",
    "generate_investigation_summary",
]
