"""
Progress domain message templates.

Templates for item execution, story/epic completion, fix summaries, and file changes.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    ProgressCategory,
)

__all__ = [
    "TEMPLATES",
    "build_completion_summary",
    "build_file_summary",
    "build_item_progress",
    "get_progress",
]

# =============================================================================
# Progress Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Item Category
    # -------------------------------------------------------------------------
    "progress.item.executing": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.ITEM,
        template="Executing {item_id}...",
        verbose_template="Executing {item_id}: {title}",
        placeholders=("item_id",),
    ),
    "progress.item.complete": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.ITEM,
        template="Completed {item_id}",
        placeholders=("item_id",),
    ),
    # -------------------------------------------------------------------------
    # Story Category
    # -------------------------------------------------------------------------
    "progress.story.complete": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.STORY,
        template="Story {story_id} complete",
        placeholders=("story_id",),
    ),
    # -------------------------------------------------------------------------
    # Epic Category
    # -------------------------------------------------------------------------
    "progress.epic.complete": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.EPIC,
        template="Epic {epic_id} complete",
        placeholders=("epic_id",),
    ),
    # -------------------------------------------------------------------------
    # Fix Category
    # -------------------------------------------------------------------------
    "progress.fix.summary": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.FIX,
        template="Fix completed: {fixed} fixed, {failed} failed",
        placeholders=("fixed", "failed"),
    ),
    # -------------------------------------------------------------------------
    # Files Category
    # -------------------------------------------------------------------------
    "progress.files.summary": MessageTemplate(
        domain=MessageDomain.PROGRESS,
        category=ProgressCategory.FILES,
        template="Files: +{created} created, ~{modified} modified",
        placeholders=("created", "modified"),
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_progress(key: str, **kwargs: Any) -> str:
    """
    Get a progress message with automatic domain prefix.

    Args:
        key: Key without 'progress.' prefix (e.g., 'item.executing')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"progress.{key}", **kwargs)


def build_item_progress(item_id: str, title: str | None = None, state: str = "executing") -> str:
    """
    Build item progress message.

    Args:
        item_id: ID of the item being processed
        title: Optional title for verbose output
        state: 'executing' or 'complete'

    Returns:
        Progress message for the item
    """
    from obra.messages.registry import get_message

    state_lower = state.lower()
    if state_lower == "complete":
        return get_message("progress.item.complete", item_id=item_id)

    # For executing state, include title if available
    if title:
        return get_message("progress.item.executing", item_id=item_id, title=title, verbose=True)
    return get_message("progress.item.executing", item_id=item_id)


def build_completion_summary(stats: dict[str, int]) -> str:
    """
    Build multi-line completion summary from stats.

    Args:
        stats: Dictionary with keys like 'epics', 'stories', 'tasks', 'fixed', 'failed',
               'files_created', 'files_modified'

    Returns:
        Multi-line completion summary
    """
    from obra.messages.registry import get_message

    lines: list[str] = []

    # Epic completion
    if stats.get("epics", 0) > 0:
        lines.append(get_message("progress.epic.complete", epic_id=f"{stats['epics']}"))

    # Story completion
    if stats.get("stories", 0) > 0:
        lines.append(get_message("progress.story.complete", story_id=f"{stats['stories']}"))

    # Fix summary
    if stats.get("fixed", 0) > 0 or stats.get("failed", 0) > 0:
        lines.append(
            get_message(
                "progress.fix.summary",
                fixed=stats.get("fixed", 0),
                failed=stats.get("failed", 0),
            )
        )

    # File summary
    created = stats.get("files_created", stats.get("created", 0))
    modified = stats.get("files_modified", stats.get("modified", 0))
    if created > 0 or modified > 0:
        lines.append(get_message("progress.files.summary", created=created, modified=modified))

    return "\n".join(lines)


def build_file_summary(created: int, modified: int) -> str:
    """
    Build file summary message.

    Args:
        created: Number of files created
        modified: Number of files modified

    Returns:
        Formatted file summary
    """
    from obra.messages.registry import get_message

    return get_message("progress.files.summary", created=created, modified=modified)
