"""Tests for Layer 5: Sliding Window Context Indexing (antaris-memory v4.5.0)."""

import unittest
from antaris_memory.entry import MemoryEntry
from antaris_memory.windowing import WindowIndexer, WindowEntry
from antaris_memory.search import SearchEngine


def make_entry(content: str, category: str = "general", tags=None,
               session_id: str = "", created: str = "2024-01-01T00:00:00") -> MemoryEntry:
    """Helper to create a MemoryEntry with predictable defaults."""
    e = MemoryEntry(content, source="test", line=0, category=category,
                    created=created, session_id=session_id)
    e.tags = tags or []
    return e


# ---------------------------------------------------------------------------
# WindowEntry structural tests
# ---------------------------------------------------------------------------

class TestWindowEntry(unittest.TestCase):
    """WindowEntry must duck-type as a MemoryEntry for search purposes."""

    def setUp(self):
        self.entries = [
            make_entry("gym costs $49.99", "finance", ["gym", "cost"],
                       created="2024-01-01T08:00:00"),
            make_entry("monthly subscription service", "finance", ["subscription"],
                       created="2024-01-01T09:00:00"),
            make_entry("fitness plan details", "health", ["fitness", "gym"],
                       created="2024-01-01T10:00:00"),
        ]
        self.indexer = WindowIndexer(window_size=3, stride=1)
        windows = self.indexer.build_windows(self.entries)
        self.win = windows[0]  # single window covering all 3 entries

    def test_window_content_concatenated(self):
        """Content must be a newline-joined concatenation of constituent texts."""
        expected = "gym costs $49.99\nmonthly subscription service\nfitness plan details"
        self.assertEqual(self.win.content, expected)

    def test_window_source_is_window(self):
        self.assertEqual(self.win.source, "window")

    def test_window_hash_format(self):
        self.assertEqual(self.win.hash, "window_0")

    def test_window_source_ids(self):
        hashes = [e.hash for e in self.entries]
        self.assertEqual(self.win.source_ids, hashes)

    def test_window_tags_union(self):
        """Tags must be the union of all constituent entry tags (no duplicates)."""
        expected = {"gym", "cost", "subscription", "fitness"}
        self.assertEqual(set(self.win.tags), expected)

    def test_window_category_most_common(self):
        """Category should be 'finance' (appears twice vs health once)."""
        self.assertEqual(self.win.category, "finance")

    def test_window_created_earliest(self):
        """Created must be the earliest timestamp among constituents."""
        self.assertEqual(self.win.created, "2024-01-01T08:00:00")

    def test_window_duck_typing_attributes(self):
        """WindowEntry must expose all MemoryEntry-like attributes."""
        for attr in ("content", "source", "tags", "category", "session_id", "hash"):
            self.assertTrue(hasattr(self.win, attr), f"Missing attribute: {attr}")

    def test_window_session_id_from_first_entry(self):
        entries = [make_entry("a", session_id="sess1"),
                   make_entry("b", session_id="sess2"),
                   make_entry("c", session_id="sess2")]
        wins = WindowIndexer(window_size=3).build_windows(entries)
        self.assertEqual(wins[0].session_id, "sess1")


# ---------------------------------------------------------------------------
# WindowIndexer build_windows tests
# ---------------------------------------------------------------------------

class TestWindowIndexer(unittest.TestCase):

    def _make_entries(self, n: int) -> list:
        return [make_entry(f"entry number {i}") for i in range(n)]

    def test_basic_window_count_size3_stride1(self):
        """5 entries, window_size=3, stride=1 → 3 windows."""
        entries = self._make_entries(5)
        wins = WindowIndexer(window_size=3, stride=1).build_windows(entries)
        self.assertEqual(len(wins), 3)

    def test_window_count_size2_stride1(self):
        """4 entries, window_size=2, stride=1 → 3 windows."""
        entries = self._make_entries(4)
        wins = WindowIndexer(window_size=2, stride=1).build_windows(entries)
        self.assertEqual(len(wins), 3)

    def test_window_count_stride2(self):
        """6 entries, window_size=3, stride=2 → 2 windows (start at 0, 2)."""
        entries = self._make_entries(6)
        wins = WindowIndexer(window_size=3, stride=2).build_windows(entries)
        self.assertEqual(len(wins), 2)

    def test_fewer_entries_than_window_size_returns_empty(self):
        """If len(entries) < window_size, return []."""
        entries = self._make_entries(2)
        wins = WindowIndexer(window_size=3).build_windows(entries)
        self.assertEqual(wins, [])

    def test_exactly_window_size_returns_one(self):
        """Exactly window_size entries → exactly 1 window."""
        entries = self._make_entries(3)
        wins = WindowIndexer(window_size=3).build_windows(entries)
        self.assertEqual(len(wins), 1)

    def test_window_indices_sequential(self):
        """window_index must be 0-based sequential integers."""
        entries = self._make_entries(5)
        wins = WindowIndexer(window_size=2, stride=1).build_windows(entries)
        for i, w in enumerate(wins):
            self.assertEqual(w.window_index, i)

    def test_overlap_between_windows(self):
        """Consecutive windows (stride=1) should share entries at the boundary."""
        entries = self._make_entries(4)
        wins = WindowIndexer(window_size=3, stride=1).build_windows(entries)
        # win[0] covers entries 0,1,2; win[1] covers 1,2,3
        # They share entries[1] and entries[2]
        shared = set(wins[0].source_ids) & set(wins[1].source_ids)
        self.assertEqual(len(shared), 2)

    def test_invalid_window_size_raises(self):
        with self.assertRaises(ValueError):
            WindowIndexer(window_size=0)

    def test_invalid_stride_raises(self):
        with self.assertRaises(ValueError):
            WindowIndexer(stride=0)

    def test_category_tie_broken_alphabetically(self):
        """When categories are tied, pick the alphabetically first one."""
        entries = [
            make_entry("a", category="zebra"),
            make_entry("b", category="apple"),
        ]
        wins = WindowIndexer(window_size=2).build_windows(entries)
        self.assertEqual(wins[0].category, "apple")


# ---------------------------------------------------------------------------
# SearchEngine integration with use_windows
# ---------------------------------------------------------------------------

class TestWindowedSearch(unittest.TestCase):

    def setUp(self):
        self.engine = SearchEngine()
        # Two related facts that individually wouldn't match a combined query well,
        # but together should.
        self.memories = [
            make_entry("gym costs $49.99"),
            make_entry("monthly subscription renewed"),
            make_entry("fitness center membership active"),
            make_entry("completely unrelated entry about cooking recipes"),
            make_entry("another unrelated note about weather forecasts"),
        ]

    def test_windowed_search_returns_results(self):
        """search() with use_windows=True should return results."""
        results = self.engine.search(
            "gym subscription cost", self.memories, use_windows=True
        )
        self.assertTrue(len(results) > 0)

    def test_windowed_search_disabled(self):
        """use_windows=False should also return results (baseline behaviour)."""
        results = self.engine.search(
            "gym subscription", self.memories, use_windows=False
        )
        self.assertTrue(len(results) >= 0)  # may or may not match — just shouldn't crash

    def test_window_entry_in_results_has_concatenated_content(self):
        """If a WindowEntry makes it into results, its content is multi-line."""
        results = self.engine.search(
            "gym subscription", self.memories, use_windows=True
        )
        for r in results:
            if r.entry.source == "window":
                self.assertIn("\n", r.entry.content)
                break  # found at least one window result, test passes

    def test_use_windows_default_true(self):
        """Default call (no use_windows arg) should behave the same as True."""
        r1 = self.engine.search("gym subscription", self.memories)
        r2 = self.engine.search("gym subscription", self.memories, use_windows=True)
        # Both calls should produce the same number of results
        self.assertEqual(len(r1), len(r2))

    def test_window_deduplication_no_duplicate_entries(self):
        """If a window supersedes its constituents, the same content shouldn't appear twice."""
        results = self.engine.search(
            "gym subscription cost", self.memories, use_windows=True
        )
        # Collect all entry hashes
        seen_hashes = [r.entry.hash for r in results]
        # No duplicates
        self.assertEqual(len(seen_hashes), len(set(seen_hashes)))

    def test_existing_search_tests_unaffected(self):
        """A standard search (no windowing involved) should still work normally."""
        memories = [
            MemoryEntry("PostgreSQL database migration", "docs", 1, "tactical"),
            MemoryEntry("Frontend React TypeScript setup", "docs", 2, "operational"),
            MemoryEntry("JWT authentication tokens", "docs", 3, "operational"),
        ]
        results = self.engine.search("PostgreSQL database", memories, use_windows=True)
        self.assertTrue(len(results) > 0)
        self.assertIn("postgresql", results[0].content.lower())

    def test_configurable_window_size(self):
        """Larger window_size means fewer windows; search should still work."""
        results = self.engine.search(
            "gym subscription", self.memories, use_windows=True, window_size=4
        )
        # Just verify no crash and returns a list
        self.assertIsInstance(results, list)

    def test_window_stride_configurable(self):
        """window_stride param should be accepted and forwarded without crash."""
        results = self.engine.search(
            "gym", self.memories, use_windows=True, window_stride=2
        )
        self.assertIsInstance(results, list)


if __name__ == "__main__":
    unittest.main()
