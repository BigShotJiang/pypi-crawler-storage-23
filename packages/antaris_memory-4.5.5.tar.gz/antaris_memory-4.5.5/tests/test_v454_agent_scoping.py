"""
v4.5.4 — Agent Scoping Tests

Verifies:
- MemorySystem(agent_name=None) emits UserWarning
- MemorySystem(agent_name=None) does not stamp agent_id on ingested memories
- search(agent_id=) pre-filters correctly — no cross-agent contamination
- Shared pool memories (no agent_id) visible to all agents
- MemorySystem.recent() returns entries newest-first for the correct agent
- multi-agent isolation on the same memory store

Note: search() with explain=False returns MemoryEntry objects directly.
      search() with explain=True returns SearchResult objects (access via .entry).
"""

import os
import tempfile
import unittest
import warnings

from antaris_memory import MemorySystem


class TestAgentNameDefault(unittest.TestCase):
    """MemorySystem with no agent_name must warn, not silently corrupt data."""

    def test_no_agent_name_warns(self):
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                mem = MemorySystem(d, half_life=7.0)
                self.assertTrue(
                    any("agent_name not set" in str(warning.message) for warning in w),
                    "Expected UserWarning about missing agent_name",
                )

    def test_no_agent_name_does_not_stamp(self):
        """Memories ingested without agent_name should have agent_id = None."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                mem = MemorySystem(d, half_life=7.0)
            mem.ingest("unique test content for shared pool check", source="test")
            # Find the ingested entry
            matches = [m for m in mem.memories if "shared pool check" in m.content]
            self.assertTrue(matches, "Ingested entry not found in memories")
            entry = matches[0]
            self.assertFalse(
                getattr(entry, "agent_id", None),
                "Entry should have no agent_id when agent_name is None",
            )

    def test_with_agent_name_no_warning(self):
        """MemorySystem with agent_name set should not emit the warning."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                mem = MemorySystem(d, half_life=7.0, agent_name="alice")
                agent_name_warnings = [
                    x for x in w if "agent_name not set" in str(x.message)
                ]
                self.assertEqual(len(agent_name_warnings), 0)

    def test_with_agent_name_stamps_correctly(self):
        """Memories ingested with agent_name should be stamped with that agent."""
        with tempfile.TemporaryDirectory() as d:
            mem = MemorySystem(d, half_life=7.0, agent_name="alice")
            mem.ingest("alice unique content check stamp test", source="test")
            matches = [m for m in mem.memories if "stamp test" in m.content]
            self.assertTrue(matches, "Ingested entry not found")
            entry = matches[0]
            self.assertEqual(getattr(entry, "agent_id", None), "alice")


class TestAgentScopedSearch(unittest.TestCase):
    """search(agent_id=) pre-filter must prevent cross-agent contamination."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # Use a shared memory store for both agents
        self.mem_alice = MemorySystem(self.tmpdir, half_life=7.0, agent_name="alice")
        self.mem_bob = MemorySystem(self.tmpdir, half_life=7.0, agent_name="bob")

        # Ingest distinct memories per agent
        self.mem_alice.ingest("alice loves raspberry pie unique word alicefood", source="alice_test")
        self.mem_alice.ingest("alice works on quantum computing unique alicework", source="alice_test")
        self.mem_bob.ingest("bob enjoys mountain climbing unique bobsport", source="bob_test")
        self.mem_bob.ingest("bob is a professional chef unique bobchef", source="bob_test")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _get_shared_mem(self):
        """Load both agents' memories into one MemorySystem for cross-agent search."""
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            return MemorySystem(self.tmpdir, half_life=7.0)

    def test_alice_search_excludes_bob(self):
        """Searching with agent_id='alice' must never return bob's memories."""
        mem = self._get_shared_mem()
        # search() with explain=False returns MemoryEntry directly
        results = mem.search("alicefood bobchef bobsport", agent_id="alice", session_id="*")
        for entry in results:
            aid = getattr(entry, "agent_id", None)
            self.assertNotEqual(aid, "bob", "Bob's memory leaked into alice's search")

    def test_bob_search_excludes_alice(self):
        """Searching with agent_id='bob' must never return alice's memories."""
        mem = self._get_shared_mem()
        results = mem.search("alicework alicefood bobsport", agent_id="bob", session_id="*")
        for entry in results:
            aid = getattr(entry, "agent_id", None)
            self.assertNotEqual(aid, "alice", "Alice's memory leaked into bob's search")

    def test_alice_search_returns_alice_memories(self):
        """Alice's MemorySystem search (auto-scoped via agent_name) finds her memories."""
        # self.mem_alice has agent_name="alice" → search defaults to agent_id="alice"
        results = self.mem_alice.search("raspberry quantum", session_id="*")
        self.assertGreater(len(results), 0, "Alice should find her own memories")
        for entry in results:
            aid = getattr(entry, "agent_id", None)
            self.assertIn(
                aid, [None, "alice"],
                f"Unexpected agent_id in alice's results: {aid}",
            )

    def test_shared_pool_visible_to_all(self):
        """Memories with no agent_id (shared pool) must be visible to any agent."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                shared = MemorySystem(d, half_life=7.0)
            shared.ingest("globalknowledge for everyone sharedvisible", source="global")

            alice = MemorySystem(d, half_life=7.0, agent_name="alice")
            results = alice.search("globalknowledge sharedvisible", agent_id="alice", session_id="*")
            contents = [e.content for e in results]
            self.assertTrue(
                any("globalknowledge" in c for c in contents),
                "Shared pool memory should be visible to alice",
            )

    def test_no_agent_id_returns_all(self):
        """search() via MemorySystem with no agent_name should return all agents' memories."""
        mem = self._get_shared_mem()  # agent_name=None → no filter
        results = mem.search("alicefood bobchef", session_id="*")
        agent_ids = {getattr(e, "agent_id", None) for e in results}
        self.assertIn("alice", agent_ids, "Alice's memory should appear without agent_id filter")
        self.assertIn("bob", agent_ids, "Bob's memory should appear without agent_id filter")

    def test_explicit_agent_id_overrides_system_default(self):
        """Passing agent_id= explicitly should override MemorySystem.agent_name."""
        # alice's MemorySystem, but we explicitly search for bob's memories
        results = self.mem_alice.search("bobchef bobsport", agent_id="bob", session_id="*")
        for entry in results:
            aid = getattr(entry, "agent_id", None)
            self.assertIn(
                aid, [None, "bob"],
                "Explicit agent_id='bob' override should return bob's memories",
            )


class TestRecent(unittest.TestCase):
    """MemorySystem.recent() must return newest entries first, agent-scoped."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.mem = MemorySystem(self.tmpdir, half_life=7.0, agent_name="tester")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_recent_returns_list(self):
        self.mem.ingest("first memory", source="test")
        self.mem.ingest("second memory", source="test")
        result = self.mem.recent(limit=5)
        self.assertIsInstance(result, list)

    def test_recent_respects_limit(self):
        for i in range(20):
            self.mem.ingest(f"memory number unique{i} batch", source="test")
        result = self.mem.recent(limit=5)
        self.assertLessEqual(len(result), 5)

    def test_recent_returns_empty_when_no_memories(self):
        result = self.mem.recent(limit=10)
        self.assertEqual(result, [])

    def test_recent_agent_filter_excludes_others(self):
        """recent(agent_id='alice') must not return bob's memories."""
        with tempfile.TemporaryDirectory() as d:
            alice = MemorySystem(d, half_life=7.0, agent_name="alice")
            bob = MemorySystem(d, half_life=7.0, agent_name="bob")
            alice.ingest("alice unique recent thing alicerecent", source="test")
            bob.ingest("bob unique recent thing bobrecent", source="test")

            result = alice.recent(limit=10)
            agent_ids = [getattr(e, "agent_id", None) for e in result]
            self.assertNotIn("bob", agent_ids, "Bob's entries leaked into alice's recent()")

    def test_recent_include_shared(self):
        """recent() should include shared pool entries by default."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                shared = MemorySystem(d, half_life=7.0)
            shared.ingest("globalentry sharedrecent unique", source="shared")

            alice = MemorySystem(d, half_life=7.0, agent_name="alice")
            result = alice.recent(limit=10, include_shared=True)
            contents = [e.content for e in result]
            self.assertTrue(
                any("globalentry" in c for c in contents),
                "Shared pool entry should appear in recent() with include_shared=True",
            )

    def test_recent_exclude_shared(self):
        """recent(include_shared=False) should exclude unscoped entries."""
        with tempfile.TemporaryDirectory() as d:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                shared = MemorySystem(d, half_life=7.0)
            shared.ingest("globalonly entry unique exclude test", source="shared")

            alice = MemorySystem(d, half_life=7.0, agent_name="alice")
            result = alice.recent(limit=10, include_shared=False)
            self.assertEqual(
                len(result), 0,
                "include_shared=False should exclude unscoped shared pool entries",
            )


class TestMultiAgentIsolation(unittest.TestCase):
    """End-to-end: 3 agents on the same store must have zero cross-contamination."""

    def test_three_agent_isolation(self):
        with tempfile.TemporaryDirectory() as d:
            agents = {}
            topics = {
                "alpha": "alpha agent works on robotics unique alpharobotics sensors",
                "beta": "beta agent specialises in natural unique betalanguage processing",
                "gamma": "gamma agent focuses on unique gammafinancial data pipelines",
            }
            for name, content in topics.items():
                agents[name] = MemorySystem(d, half_life=7.0, agent_name=name)
                agents[name].ingest(content, source=f"{name}_test")

            # Each agent's default search must only surface its own memories
            checks = [
                ("alpha", "alpharobotics"),
                ("beta", "betalanguage"),
                ("gamma", "gammafinancial"),
            ]
            for name, keyword in checks:
                results = agents[name].search(keyword, session_id="*")
                for entry in results:
                    aid = getattr(entry, "agent_id", None)
                    self.assertIn(
                        aid, [None, name],
                        f"Agent '{name}' search for '{keyword}' returned entry "
                        f"belonging to '{aid}'",
                    )


if __name__ == "__main__":
    unittest.main()
