"""
Distributed metric abstractions and implementations.
"""

from .abc import Metric

__all__ = [
    "Metric",
]
