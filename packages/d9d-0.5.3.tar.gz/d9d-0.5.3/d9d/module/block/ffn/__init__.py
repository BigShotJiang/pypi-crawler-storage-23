from .swiglu import SwiGLU

__all__ = [
    "SwiGLU",
]
