"""Exposes the internal distributed profiler."""

from .profile import Profiler

__all__ = [
    "Profiler",
]
