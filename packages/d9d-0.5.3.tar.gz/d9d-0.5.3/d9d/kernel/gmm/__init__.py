from .function import gmm

__all__ = [
    "gmm",
]
