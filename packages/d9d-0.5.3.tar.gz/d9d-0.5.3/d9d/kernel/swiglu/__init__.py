from .function import silu_mul

__all__ = [
    "silu_mul",
]
