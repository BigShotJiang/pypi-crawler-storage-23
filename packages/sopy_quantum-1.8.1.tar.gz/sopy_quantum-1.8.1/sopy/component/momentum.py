####################  ##########################
################  SoPy        ##################
####################  ########################## 

################################################
###          by Quantum Galaxies Corp        ###
##           (2023,2024,2025)                 ##
################################################

import tensorflow as tf
from . import component
from bandlimit.gaussian import ops


class Momentum(component.Component):
    def __init__(self, lattice , contents = [], transform = [] ):
        super().__init__(lattice, contents, transform)
        zero = tf.constant(0., tf.float64)
        one  = tf.constant(1., tf.float64)
        self.complexity = tf.constant(tf.complex(one,zero), dtype = tf.complex128)
        self.spacing = abs(lattice[1] - lattice[0])
        self.p = tf.convert_to_tensor( [ [ -( -1 )**(i-j)/(i-j) if i != j else 0 for j in range(len(lattice)) ] for i in range(len(lattice))] , dtype = tf.float64)
        pass


    @classmethod
    def from_Component(cls, component_instance):
        # Create a new Momentum instance using the Component's data
        return cls(component_instance.lattice, component_instance.contents, component_instance.transform)

    def __getitem__(self, r):
        if r < len(self):
            return Momentum(lattice = self.lattice, contents = [self.contents[r]], transform = self.transform )


    def copy(self, norm_ = True, threshold = 0):
        return Momentum( lattice = self.lattice, contents = self.contents, transform = self.transform)
        

    def resample(self, lattice2):
        """
        useful for adding lattice elements while maintaining content
        """
        contents2 = [tf.reduce_sum(
         tf.transpose([ value*Momentum(lattice2).delta( 
         			spacing=self.spacing, 
         			position=position).contents[0] 
         			for position,value in zip(lattice2,self.contents[0]) 
         ])
         , axis=1
        )]    
        return Momentum( lattice2, contents2 )


    ##document changes
    ##(A)reduce band-pass to pi/spacing
    ##
    
    def P(self, compl = True):
        zero = tf.constant(0., tf.float64)
        one  = tf.constant(1., tf.float64)
        new = self.copy()
        new.contents = tf.matmul(self.contents ,self.p)/self.spacing
        if compl :
            new.complexity *= tf.constant(tf.complex(zero,-one))
        return new
    
    def h(self, k, poly = False):
        """
        momentum boost 
        diagonal piece
        """
        zero = tf.constant(0., tf.float64)
        one  = tf.constant(1., tf.float64)
        k_re = tf.constant(k, dtype = tf.float64)
        coef = ( (one if k_re >= 0 else one) if not poly else -tf.math.abs(k_re)*self.spacing/component.pi2 )

        if ( abs(k_re) > component.pi2 / self.spacing /2 ):##A
            mul = tf.convert_to_tensor([ tf.complex(zero,zero) for position in tf.constant(self.lattice, dtype = tf.float64) ])
        else:
            mul = tf.convert_to_tensor([ 
                tf.complex(coef*tf.math.cos( k_re * position ), -coef*tf.math.sin(k_re * position ) ) for position in tf.constant(self.lattice, dtype = tf.float64) ] )

        re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)
        im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform) 
        return re,im
        
    def g(self, k, P = False):
        """
        momentum boost
        off diagonal piece"""
        zero = tf.constant(0., tf.float64)
        one  = tf.constant(1., tf.float64)
        k_re = tf.constant(k, dtype = tf.float64)

        i_m  = tf.complex(zero,-one)
        coef = ( (-one if k_re >= 0 else one)  )*(self.spacing/component.pi2)
        
        if ( abs(k_re) > component.pi2 / self.spacing /2):##A
            mul = tf.convert_to_tensor([ tf.complex(zero,zero) for position in tf.constant(self.lattice, dtype = tf.float64) ])
        else:
            mul = tf.convert_to_tensor([ 
                tf.complex(coef*tf.math.cos( k_re * position ), 
                           -coef*tf.math.sin(k_re * position ) ) for position in tf.constant(self.lattice, dtype = tf.float64) ] )

        if P:
            re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity*i_m) * value for value in self.contents ], dtype = tf.float64),self.transform).P(False)
            im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity*i_m) * value for value in self.contents ], dtype = tf.float64),self.transform).P(False)
        else:
            re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)
            im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)             
        return re,im
    
    def h2(self, alpha, position):
        """
        gaussian ops 
        diagonal piece
        """
        zero = tf.constant(0., tf.float64)
        alpha_re = tf.constant(alpha, dtype = tf.float64)
        position_re = tf.constant(position, dtype = tf.float64)
        mul = tf.convert_to_tensor([ 
                tf.complex(tf.constant(ops(self.spacing, alpha_re, position_p-position_re, 1), dtype=tf.float64),zero) for position_p in tf.constant(self.lattice, dtype = tf.float64) ] )

        re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)
        im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)             
        return re,im

    def g2(self, alpha, position, P = False):
        """
        gaussian ops
        off diagonal piece
        """
        zero = tf.constant(0., tf.float64)
        one  = tf.constant(1., tf.float64)
        alpha_re = tf.constant(alpha, dtype = tf.float64)
        position_re = tf.constant(position, dtype = tf.float64)
        i_m  = tf.complex(zero,-one)

        mul = tf.convert_to_tensor([ 
                tf.complex(tf.constant(ops(self.spacing, alpha_re, position_p-position_re, 0),dtype=tf.float64),zero) for position_p in tf.constant(self.lattice, dtype = tf.float64) ] )
        if P:
            re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity*i_m) * value for value in self.contents ], dtype = tf.float64),self.transform).P(False)
            im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity*i_m) * value for value in self.contents ], dtype = tf.float64),self.transform).P(False)
        else:
            re = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.real(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)
            im = Momentum( self.lattice, tf.convert_to_tensor([ tf.math.imag(mul * self.complexity) * value for value in self.contents ], dtype = tf.float64),self.transform)             
        return re,im