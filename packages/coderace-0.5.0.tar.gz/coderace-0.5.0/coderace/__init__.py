"""coderace - Race coding agents against each other on real tasks."""

__version__ = "0.5.0"
