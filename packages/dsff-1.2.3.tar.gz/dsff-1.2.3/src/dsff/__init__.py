# -*- coding: UTF-8 -*-
"""DSFF package.

"""
from .__info__ import __author__, __copyright__, __license__, __version__
from .formats import *
from .formats import __all__

