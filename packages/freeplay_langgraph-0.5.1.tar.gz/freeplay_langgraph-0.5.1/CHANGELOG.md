# Changelog

Notable additions, fixes, or breaking changes to the Freeplay LangGraph integration.

## [0.5.1] - 2026-02-19

**Dependencies:**

- Updated `freeplay` dependency to `>=0.5.8`.

## [0.5.0] - 2026-02-13

**New Features:**

- Added optional `tracer_provider` parameter to `FreeplayLangGraph()` constructor, allowing users to bring their own fully configured `TracerProvider` (e.g., with `BatchSpanProcessor` for resilience against transient export failures). When provided, the SDK skips internal provider/exporter setup and uses the given provider as-is. User-provided providers are not shut down by the SDK — the caller manages their lifecycle.

## [0.4.0] - 2025-11-12

**Breaking Changes:**

- Variables are now passed in the input dict instead of as a parameter
  - Before: `agent.invoke({"messages": [...]}, variables={...})`
  - After: `agent.invoke({"messages": [...], "variables": {...}})`

- Removed `variables` parameter from `create_agent()` - all variables are now dynamic (passed per invocation)
  - Before: `create_agent(prompt_name="...", variables={"company": "Acme"})`
  - After: `create_agent(prompt_name="...")` (variables in invoke input)

- Template-only invocations use variables-only dict
  - Before: `agent.invoke(variables={...})`
  - After: `agent.invoke({"variables": {...}})`

**New Features:**

- Tool validation - warns when provided tools don't match Freeplay prompt's tool schema (can be disabled with `validate_tools=False`)

- System prompts are now re-rendered on every model call (not just at agent creation)

## [0.3.1] - 2025-11-12

- Add dynamic variables support for agent invocation - pass `variables` parameter to `invoke()`, `ainvoke()`, `stream()`, `astream()`, `batch()`, and `abatch()` to render template messages per call


