Documentación del Gestor de Inventario
======================================

Bienvenido/a a la documentación oficial del Gestor de Inventario. Una aplicación de escritorio desarrollada en Python utilizando GTK3 para la interfaz gráfica y SQLite para la persistencia de datos.

.. toctree::
   :maxdepth: 2
   :caption: Contenidos Principales:

   api_reference
   guias/01_instalacion_y_uso
   guias/02_arquitectura