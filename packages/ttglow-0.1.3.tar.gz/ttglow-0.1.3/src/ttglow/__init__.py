"""TTGlow: Tensor Train linear algebra package for PyTorch."""

from .tensortrain import TensorTrain, add, dot, hadamard, scale
from .ttmatrix import TTMatrix
from . import linalg

# TTVector is an alias for TensorTrain.
# A tensor and a vector are the same object (a tensor IS a vector in a vector space).
# The only difference is interpretation, not structure.
TTVector = TensorTrain

__version__ = "0.1.0"
__all__ = [
    "TensorTrain",
    "TTVector",
    "TTMatrix",
    "add",
    "dot",
    "hadamard",
    "scale",
    "linalg",
]
