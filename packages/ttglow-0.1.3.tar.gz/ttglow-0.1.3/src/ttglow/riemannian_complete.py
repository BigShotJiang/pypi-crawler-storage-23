"""Tensor completion via alternating least squares on the TT manifold.

Completes a tensor from a sparse set of observed entries by performing
alternating least squares (ALS) sweeps in tensor-train format.  Unlike
SiLRTC-TT, this algorithm works directly in TT format and scales
polynomially: O(n * d * r^2) per iteration, where n = number of
observations, d = number of modes, r = TT rank.

The implementation uses a sweep-based approach: for each site in a
left-to-right sweep, the TT is in mixed canonical form (left-orthogonal
to the left, right-orthogonal to the right) so the metric at the active
core is the identity.  The core is then updated by solving a local
least-squares problem (ALS) or by a gradient step with exact line search.

Reference:
    Cai, Li & Xia, "Provable Tensor-Train Format Tensor Completion by
    Riemannian Optimization", 2022.
"""

from __future__ import annotations

import torch

from . import linalg
from .tensortrain import TensorTrain, scale


def _batch_evaluate(tt: TensorTrain, indices: torch.Tensor) -> torch.Tensor:
    """Evaluate a TT at multiple multi-indices simultaneously.

    Args:
        tt: Tensor train with d modes.
        indices: Multi-indices of shape (num_obs, d), dtype long.

    Returns:
        Values at the given indices, shape (num_obs,).
    """
    # Start with shape (num_obs, 1) — the left boundary rank is 1
    result = torch.ones(indices.shape[0], 1, dtype=tt.dtype, device=tt.device)

    for k in range(tt.d):
        # cores[k] shape: (r_left, n_k, r_right)
        # Select slices for each observation: (r_left, num_obs, r_right)
        slices = tt.cores[k][:, indices[:, k], :]
        # Transpose to (num_obs, r_left, r_right) for batched matmul
        slices = slices.permute(1, 0, 2)
        # result: (num_obs, 1, r_left) @ (num_obs, r_left, r_right)
        # -> (num_obs, 1, r_right) -> squeeze to (num_obs, r_right)
        result = torch.bmm(result.unsqueeze(1), slices).squeeze(1)

    # result shape: (num_obs, 1) — squeeze final rank dimension
    return result.squeeze(1)


def _compute_partial_products(
    tt: TensorTrain, indices: torch.Tensor
) -> tuple[list[torch.Tensor], list[torch.Tensor]]:
    """Compute left and right partial products at observed indices.

    Args:
        tt: Tensor train (d modes).
        indices: Multi-indices, shape (num_obs, d).

    Returns:
        (left_parts, right_parts) where:
        - left_parts[k] has shape (num_obs, r_k) for k=0..d
          left_parts[0] = ones(num_obs, 1)  (boundary)
          left_parts[k] = product of cores 0..k-1 evaluated at indices
        - right_parts[k] has shape (num_obs, r_k) for k=0..d
          right_parts[d] = ones(num_obs, 1)  (boundary)
          right_parts[k] = product of cores k..d-1 evaluated at indices
    """
    num_obs = indices.shape[0]
    d = tt.d

    # Left partial products: left[k] = T_0(x_0) @ T_1(x_1) @ ... @ T_{k-1}(x_{k-1})
    left_parts = [None] * (d + 1)
    left_parts[0] = torch.ones(num_obs, 1, dtype=tt.dtype, device=tt.device)
    for k in range(d):
        slices = tt.cores[k][:, indices[:, k], :]  # (r_left, num_obs, r_right)
        slices = slices.permute(1, 0, 2)  # (num_obs, r_left, r_right)
        left_parts[k + 1] = torch.bmm(
            left_parts[k].unsqueeze(1), slices
        ).squeeze(1)

    # Right partial products: right[k] = T_k(x_k) @ ... @ T_{d-1}(x_{d-1})
    right_parts = [None] * (d + 1)
    right_parts[d] = torch.ones(num_obs, 1, dtype=tt.dtype, device=tt.device)
    for k in range(d - 1, -1, -1):
        slices = tt.cores[k][:, indices[:, k], :]  # (r_left, num_obs, r_right)
        slices = slices.permute(1, 0, 2)  # (num_obs, r_left, r_right)
        right_parts[k] = torch.bmm(
            slices, right_parts[k + 1].unsqueeze(2)
        ).squeeze(2)

    return left_parts, right_parts


def _local_gradient(
    indices: torch.Tensor,
    residuals: torch.Tensor,
    left_parts: torch.Tensor,
    right_parts: torch.Tensor,
    n_k: int,
) -> torch.Tensor:
    """Compute the gradient of the loss w.r.t. one TT core.

    For site k with mixed-canonical gauge, the gradient is:
        grad[:, j, :] = sum_{omega: x_k=j} g_omega * left(omega)^T outer right(omega)^T

    Args:
        indices: Physical indices at site k, shape (num_obs,).
        residuals: Residual values, shape (num_obs,).
        left_parts: Left partial products, shape (num_obs, r_left).
        right_parts: Right partial products, shape (num_obs, r_right).
        n_k: Physical dimension at site k.

    Returns:
        Gradient core, shape (r_left, n_k, r_right).
    """
    r_left = left_parts.shape[1]
    r_right = right_parts.shape[1]

    # weighted outer product: g_omega * left outer right
    outer = left_parts.unsqueeze(2) * right_parts.unsqueeze(1)
    weighted = residuals.unsqueeze(1).unsqueeze(2) * outer

    # Scatter into grad[:, j, :]
    grad_flat = torch.zeros(
        n_k, r_left * r_right, dtype=left_parts.dtype, device=left_parts.device
    )
    grad_flat.index_add_(0, indices, weighted.reshape(-1, r_left * r_right))
    return grad_flat.reshape(n_k, r_left, r_right).permute(1, 0, 2)


def _local_als_solve(
    indices: torch.Tensor,
    values: torch.Tensor,
    left_parts: torch.Tensor,
    right_parts: torch.Tensor,
    n_k: int,
    regularization: float = 1e-12,
) -> torch.Tensor:
    """Solve the local least-squares problem for one TT core.

    In mixed canonical form at site k, the observation equation is linear
    in the core entries:
        value[ω] = left[ω]^T @ core[:, x_k(ω), :] @ right[ω]
                 = (left[ω] ⊗ right[ω])^T @ vec(core[:, x_k(ω), :])

    We solve: min_core  sum_ω (value[ω] - left[ω]^T core[:, x_k, :] right[ω])^2

    This is done per physical index j: for all ω with x_k(ω) = j, we
    solve a small least-squares problem.

    Args:
        indices: Physical indices at site k, shape (num_obs,).
        values: Observed values, shape (num_obs,).
        left_parts: Left partial products, shape (num_obs, r_left).
        right_parts: Right partial products, shape (num_obs, r_right).
        n_k: Physical dimension at site k.
        regularization: Tikhonov regularization parameter.

    Returns:
        New core, shape (r_left, n_k, r_right).
    """
    r_left = left_parts.shape[1]
    r_right = right_parts.shape[1]
    m = r_left * r_right  # number of unknowns per physical index

    new_core = torch.zeros(
        r_left, n_k, r_right, dtype=left_parts.dtype, device=left_parts.device
    )

    for j in range(n_k):
        mask = indices == j
        if not mask.any():
            continue

        left_j = left_parts[mask]   # (n_j, r_left)
        right_j = right_parts[mask]  # (n_j, r_right)
        vals_j = values[mask]        # (n_j,)

        # Design matrix: each row is kron(left[ω], right[ω])
        # = left[ω].unsqueeze(2) * right[ω].unsqueeze(1) -> (n_j, r_left, r_right)
        # reshaped to (n_j, r_left * r_right)
        design = (left_j.unsqueeze(2) * right_j.unsqueeze(1)).reshape(-1, m)

        # Solve: design @ x = vals_j  via normal equations with regularization
        # A^T A x = A^T b, with Tikhonov: (A^T A + λI) x = A^T b
        ata = design.T @ design
        ata.diagonal().add_(regularization)
        atb = design.T @ vals_j
        x = torch.linalg.solve(ata, atb)

        new_core[:, j, :] = x.reshape(r_left, r_right)

    return new_core


def _apply_core_at_obs(
    grad_core: torch.Tensor,
    indices_k: torch.Tensor,
    left_parts: torch.Tensor,
    right_parts: torch.Tensor,
) -> torch.Tensor:
    """Evaluate a core perturbation at observed entries.

    Computes: out[omega] = left(omega)^T @ grad_core[:, x_k(omega), :] @ right(omega)

    Args:
        grad_core: Core tensor, shape (r_left, n_k, r_right).
        indices_k: Physical indices at site k, shape (num_obs,).
        left_parts: Left partial products, shape (num_obs, r_left).
        right_parts: Right partial products, shape (num_obs, r_right).

    Returns:
        Values at observations, shape (num_obs,).
    """
    # grad_core[:, indices_k, :] -> (r_left, num_obs, r_right)
    slices = grad_core[:, indices_k, :].permute(1, 0, 2)  # (num_obs, r_left, r_right)
    # left^T @ slice @ right for each obs
    # (num_obs, 1, r_left) @ (num_obs, r_left, r_right) -> (num_obs, 1, r_right)
    tmp = torch.bmm(left_parts.unsqueeze(1), slices)
    # (num_obs, 1, r_right) @ (num_obs, r_right, 1) -> (num_obs, 1, 1)
    return torch.bmm(tmp, right_parts.unsqueeze(2)).reshape(-1)


def _optimal_step_size(
    grad_core: torch.Tensor,
    indices_k: torch.Tensor,
    left_parts: torch.Tensor,
    right_parts: torch.Tensor,
) -> float:
    """Compute optimal step size for steepest descent at one core.

    For f(T_k) = (1/2)||r||^2 with gradient g, the exact line search gives:
        alpha = ||g||_F^2 / ||A_k g||^2

    where A_k g is the change in observations from moving core k by g.

    Args:
        grad_core: Gradient core, shape (r_left, n_k, r_right).
        indices_k: Physical indices at site k, shape (num_obs,).
        left_parts: Left partial products, shape (num_obs, r_left).
        right_parts: Right partial products, shape (num_obs, r_right).

    Returns:
        Optimal step size (scalar).
    """
    grad_norm_sq = torch.sum(grad_core**2).item()
    if grad_norm_sq < 1e-30:
        return 0.0

    # A_k g: evaluate the gradient core at observations
    ag = _apply_core_at_obs(grad_core, indices_k, left_parts, right_parts)
    ag_norm_sq = torch.sum(ag**2).item()

    if ag_norm_sq < 1e-30:
        return 1.0

    return grad_norm_sq / ag_norm_sq


def _left_orthogonalize_core(tt: TensorTrain, k: int) -> None:
    """QR-decompose core k and absorb R into core k+1 (in-place).

    After this, core k is left-orthogonal.
    """
    core = tt.cores[k]
    r_left, n_k, r_right = core.shape
    mat = core.reshape(r_left * n_k, r_right)
    q_mat, r_mat = torch.linalg.qr(mat)
    r_new = q_mat.shape[1]
    tt.cores[k] = q_mat.reshape(r_left, n_k, r_new)
    tt.cores[k + 1] = torch.einsum("ij,jkl->ikl", r_mat, tt.cores[k + 1])
    tt.ranks[k + 1] = r_new


def _right_orthogonalize_core(tt: TensorTrain, k: int) -> None:
    """LQ-decompose core k and absorb L into core k-1 (in-place).

    After this, core k is right-orthogonal.
    """
    core = tt.cores[k]
    r_left, n_k, r_right = core.shape
    mat = core.reshape(r_left, n_k * r_right)
    # LQ = mat, L lower triangular, Q with orthonormal rows
    # Use QR on transpose: mat^T = Q^T R^T => mat = R^T^T Q^T^T = L Q
    qt, rt = torch.linalg.qr(mat.T)
    r_new = qt.shape[1]
    tt.cores[k] = qt.T.reshape(r_new, n_k, r_right)
    tt.cores[k - 1] = torch.einsum("ijk,kl->ijl", tt.cores[k - 1], rt.T)
    tt.ranks[k] = r_new


def rgrad_tt(
    indices: torch.Tensor,
    values: torch.Tensor,
    dims: list[int] | tuple[int, ...],
    ranks: list[int],
    init: TensorTrain | None = None,
    method: str = "gradient",
    step_size: float | None = None,
    max_iters: int = 200,
    tol: float = 1e-6,
    regularization: float = 1e-12,
    dtype: torch.dtype = torch.float64,
    device: torch.device | None = None,
    verbose: bool = False,
) -> TensorTrain:
    """Complete a tensor from observed entries via TT manifold optimization.

    Uses alternating least squares (ALS) or Riemannian gradient descent
    with sweep-based updates in mixed canonical form.

    Unlike SiLRTC-TT, this works directly in TT format and scales
    polynomially in the tensor dimensions.

    Args:
        indices: Multi-indices of observed entries, shape (num_obs, d).
        values: Observed values, shape (num_obs,).
        dims: Tensor dimensions (n_1, n_2, ..., n_d).
        ranks: Target TT-ranks [r_1, ..., r_{d-1}].
        init: Initial TT guess. Random if None.
        method: Local solver — ``"als"`` (default) solves the local
            least-squares problem exactly at each core, ``"gradient"``
            uses a gradient step with exact line search (or fixed step).
        step_size: Gradient step size (only used when method="gradient").
            If None, an exact line search computes the optimal step per core.
        max_iters: Maximum number of iterations (full sweeps).
        tol: Convergence tolerance on relative change of loss.
        regularization: Tikhonov regularization for ALS (default 1e-12).
        dtype: Torch dtype for computation.
        device: Torch device.
        verbose: Print convergence info.

    Returns:
        TensorTrain of the completed tensor with the specified ranks.

    Raises:
        ValueError: If inputs have incompatible shapes or out-of-bounds indices.
    """
    dims = list(dims)
    d = len(dims)
    num_obs = indices.shape[0]

    # --- Validation ---
    indices = indices.to(dtype=torch.long, device=device)
    values = values.to(dtype=dtype, device=device)

    if indices.ndim != 2:
        raise ValueError(f"indices must be 2D, got {indices.ndim}D")
    if values.ndim != 1:
        raise ValueError(f"values must be 1D, got {values.ndim}D")
    if indices.shape[0] != values.shape[0]:
        raise ValueError(
            f"indices ({indices.shape[0]}) and values ({values.shape[0]}) "
            f"must have the same number of entries"
        )
    if indices.shape[1] != d:
        raise ValueError(
            f"indices has {indices.shape[1]} columns but dims has {d} entries"
        )
    if len(ranks) != d - 1:
        raise ValueError(
            f"ranks has {len(ranks)} entries but expected {d - 1}"
        )
    for k in range(d):
        if indices[:, k].min() < 0 or indices[:, k].max() >= dims[k]:
            raise ValueError(
                f"Index out of bounds for dimension {k} (size {dims[k]})"
            )

    # --- Method validation ---
    if method not in ("als", "gradient"):
        raise ValueError(f"method must be 'als' or 'gradient', got '{method}'")
    use_als = method == "als"
    use_line_search = step_size is None

    # --- Initialization ---
    if init is not None:
        tt = init.copy()
    else:
        tt = TensorTrain.random(dims, ranks, dtype=dtype, device=device)
        # Scale so initial norm is comparable to signal
        tt_norm = linalg.norm(tt)
        val_scale = torch.linalg.norm(values).item()
        if tt_norm > 0 and val_scale > 0:
            target_norm = val_scale / (num_obs**0.5)
            tt = scale(tt, target_norm / tt_norm)

    # --- Right-orthogonalize: put in right-canonical form initially ---
    # Cores 1..d-1 become right-orthogonal, core 0 is the gauge core
    for k in range(d - 1, 0, -1):
        _right_orthogonalize_core(tt, k)

    prev_loss = float("inf")

    for iteration in range(max_iters):
        # === Left-to-right half-sweep ===
        for k in range(d):
            # TT is in mixed canonical form at site k:
            # - cores 0..k-1 are left-orthogonal
            # - cores k+1..d-1 are right-orthogonal
            left_parts, right_parts = _compute_partial_products(tt, indices)

            if use_als:
                tt.cores[k] = _local_als_solve(
                    indices[:, k], values,
                    left_parts[k], right_parts[k + 1],
                    dims[k], regularization=regularization,
                )
            else:
                tt_values = left_parts[d].squeeze(1)
                residuals = tt_values - values
                grad_k = _local_gradient(
                    indices[:, k], residuals,
                    left_parts[k], right_parts[k + 1],
                    dims[k],
                )
                if use_line_search:
                    alpha = _optimal_step_size(
                        grad_k, indices[:, k],
                        left_parts[k], right_parts[k + 1],
                    )
                else:
                    alpha = step_size
                tt.cores[k] = tt.cores[k] - alpha * grad_k

            # Move gauge to the right (left-orthogonalize core k)
            if k < d - 1:
                _left_orthogonalize_core(tt, k)

        # === Right-to-left half-sweep ===
        for k in range(d - 1, -1, -1):
            left_parts, right_parts = _compute_partial_products(tt, indices)

            if use_als:
                tt.cores[k] = _local_als_solve(
                    indices[:, k], values,
                    left_parts[k], right_parts[k + 1],
                    dims[k], regularization=regularization,
                )
            else:
                tt_values = left_parts[d].squeeze(1)
                residuals = tt_values - values
                grad_k = _local_gradient(
                    indices[:, k], residuals,
                    left_parts[k], right_parts[k + 1],
                    dims[k],
                )
                if use_line_search:
                    alpha = _optimal_step_size(
                        grad_k, indices[:, k],
                        left_parts[k], right_parts[k + 1],
                    )
                else:
                    alpha = step_size
                tt.cores[k] = tt.cores[k] - alpha * grad_k

            # Move gauge to the left (right-orthogonalize core k)
            if k > 0:
                _right_orthogonalize_core(tt, k)

        # === Compute loss for convergence check ===
        left_parts, right_parts = _compute_partial_products(tt, indices)
        tt_values = left_parts[d].squeeze(1)
        residuals = tt_values - values
        loss = 0.5 * torch.sum(residuals**2).item()

        if verbose:
            print(f"Iter {iteration}: loss = {loss:.6e}")

        if prev_loss > 0:
            rel_change = abs(prev_loss - loss) / max(prev_loss, 1e-30)
        else:
            rel_change = abs(loss)
        if rel_change <= tol and iteration > 0:
            if verbose:
                print(f"Converged at iteration {iteration}")
            break
        prev_loss = loss

    return tt
