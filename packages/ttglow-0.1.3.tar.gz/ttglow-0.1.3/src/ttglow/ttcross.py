"""TT-Cross interpolation for constructing tensor train approximations.

Builds a tensor train from a function or tensor using only O(d * n * r^2)
evaluations instead of n^d, via alternating maxvol-based sweeps.
"""

from __future__ import annotations

from collections.abc import Callable

import numpy as np
import torch

from . import linalg
from .tensortrain import TensorTrain


def maxvol(
    mat: np.ndarray, tol: float = 1.01, max_iters: int = 100
) -> tuple[np.ndarray, np.ndarray]:
    """Find the maximal-volume submatrix of a tall matrix.

    Given a matrix of shape (n, r) with n >= r, finds r row indices such that
    the corresponding r x r submatrix has approximately maximal determinant.
    Returns coefficient matrix coeff such that mat ≈ coeff @ mat[indices].

    Uses lstsq for robustness when the matrix is rank-deficient, which occurs
    during early TT-Cross sweeps when random index sets produce linearly
    dependent fiber columns.

    Args:
        mat: Tall matrix of shape (n, r) with n >= r.
        tol: Convergence tolerance. Iterations stop when all entries
             of coeff satisfy |coeff[i,j]| <= tol. Default 1.01.
        max_iters: Maximum number of refinement iterations.

    Returns:
        Tuple of (indices, coeff) where:
            - indices: Array of r row indices (the pivot rows)
            - coeff: Coefficient matrix of shape (n, r) where mat ≈ coeff @ mat[indices]
    """
    n, r = mat.shape
    if n < r:
        raise ValueError(f"Matrix must be tall: got shape ({n}, {r})")

    indices = _greedy_maxvol_init(mat, r)

    # Compute initial coeff = mat @ inv(mat[indices])
    # Use lstsq for robustness with rank-deficient matrices
    sub = mat[indices]  # (r, r)
    coeff, _, _, _ = np.linalg.lstsq(sub.T, mat.T, rcond=None)
    coeff = coeff.T  # (n, r)

    # Iterative refinement
    for _ in range(max_iters):
        # Find the element with largest absolute value in coeff
        i, j = np.unravel_index(np.abs(coeff).argmax(), coeff.shape)

        if np.abs(coeff[i, j]) <= tol:
            break

        # Swap: replace pivot row j with row i
        indices[j] = i

        # Recompute coeff from scratch (stable for moderate r)
        sub = mat[indices]
        coeff, _, _, _ = np.linalg.lstsq(sub.T, mat.T, rcond=None)
        coeff = coeff.T

    return indices, coeff


def _greedy_maxvol_init(mat: np.ndarray, r: int) -> np.ndarray:
    """Greedy initialization for maxvol pivot rows.

    Selects r rows greedily to maximize volume (determinant) of the submatrix.

    Args:
        mat: Matrix of shape (n, r).
        r: Number of rows to select.

    Returns:
        Array of r row indices.
    """
    n = mat.shape[0]
    indices = np.zeros(r, dtype=np.int64)
    used = np.zeros(n, dtype=bool)

    # Pick first row as the one with largest norm
    norms = np.linalg.norm(mat, axis=1)
    indices[0] = np.argmax(norms)
    used[indices[0]] = True

    if r == 1:
        return indices

    # Greedily pick remaining rows to maximize volume
    # Use QR-like pivoting: project out selected rows and pick largest residual
    basis = mat[indices[0] : indices[0] + 1, :].copy()  # (1, r)
    basis = basis / np.linalg.norm(basis)

    for k in range(1, r):
        # Project mat onto orthogonal complement of selected rows
        projections = mat @ basis.T  # (n, k)
        residuals = mat - projections @ basis  # (n, r)
        res_norms = np.linalg.norm(residuals, axis=1)
        res_norms[used] = -1.0  # exclude already selected rows

        idx = np.argmax(res_norms)
        indices[k] = idx
        used[idx] = True

        # Update basis with new row (Gram-Schmidt)
        new_row = residuals[idx : idx + 1, :]
        new_row_norm = np.linalg.norm(new_row)
        if new_row_norm > 1e-14:
            basis = np.vstack([basis, new_row / new_row_norm])
        else:
            basis = np.vstack([basis, mat[idx : idx + 1, :] / (np.linalg.norm(mat[idx]) + 1e-30)])

    return indices


def _build_eval_points(
    left_idx: np.ndarray,
    right_idx: np.ndarray,
    k: int,
    n_k: int,
    d: int,
) -> np.ndarray:
    """Build multi-index evaluation points for a fiber.

    Constructs all combinations: left[alpha] + [i_k] + right[beta]
    for alpha in range(r_left), i_k in range(n_k), beta in range(r_right).

    Args:
        left_idx: Left index set of shape (r_left, k) for modes 0..k-1.
        right_idx: Right index set of shape (r_right, d-k-1) for modes k+1..d-1.
        k: Current mode index.
        n_k: Dimension of mode k.
        d: Total number of modes.

    Returns:
        Array of shape (r_left * n_k * r_right, d) containing all evaluation points.
    """
    r_left = left_idx.shape[0] if left_idx.size > 0 else 1
    r_right = right_idx.shape[0] if right_idx.size > 0 else 1

    # Total number of points
    total = r_left * n_k * r_right
    points = np.zeros((total, d), dtype=np.int64)

    for alpha in range(r_left):
        for i_k in range(n_k):
            for beta in range(r_right):
                flat = alpha * (n_k * r_right) + i_k * r_right + beta
                if left_idx.size > 0:
                    points[flat, :k] = left_idx[alpha]
                points[flat, k] = i_k
                if right_idx.size > 0:
                    points[flat, k + 1 :] = right_idx[beta]

    return points


def _evaluate_fiber(
    func: Callable,
    left_idx: np.ndarray,
    right_idx: np.ndarray,
    k: int,
    n_k: int,
    d: int,
    dtype: torch.dtype,
    device: torch.device | None,
) -> torch.Tensor:
    """Evaluate the function on a fiber and reshape to core format.

    Args:
        func: Callable that takes an array of shape (N, d) of int indices
              and returns an array/tensor of shape (N,) of values.
        left_idx: Left index set of shape (r_left, k).
        right_idx: Right index set of shape (r_right, d-k-1).
        k: Current mode index.
        n_k: Dimension of mode k.
        d: Total number of modes.
        dtype: Torch dtype for output.
        device: Torch device for output.

    Returns:
        Tensor of shape (r_left, n_k, r_right).
    """
    r_left = left_idx.shape[0] if left_idx.size > 0 else 1
    r_right = right_idx.shape[0] if right_idx.size > 0 else 1

    points = _build_eval_points(left_idx, right_idx, k, n_k, d)
    values = func(points)

    if isinstance(values, torch.Tensor):
        values = values.to(dtype=dtype, device=device)
    else:
        values = torch.tensor(values, dtype=dtype, device=device)

    return values.reshape(r_left, n_k, r_right)


def tt_cross(
    func: Callable | torch.Tensor,
    dims: list[int],
    max_rank: int = 10,
    max_sweeps: int = 10,
    tol: float = 1e-6,
    dtype: torch.dtype = torch.float64,
    device: torch.device | None = None,
    seed: int | None = None,
    verbose: bool = False,
) -> TensorTrain:
    """Construct a tensor train approximation via TT-Cross interpolation.

    Given a function f(i_1, ..., i_d) or a dense tensor, constructs a TT
    approximation using only O(d * n * r^2) evaluations. The algorithm
    alternates left-to-right and right-to-left sweeps, using maxvol to
    select interpolation indices at each step.

    Args:
        func: Either a callable f(points) where points is an int array of
              shape (N, d) returning values of shape (N,), or a dense
              torch.Tensor of shape dims.
        dims: List of dimensions [n_1, n_2, ..., n_d].
        max_rank: Maximum TT rank at each bond. Actual ranks are clamped
                  to min(max_rank, product_of_left_dims, product_of_right_dims).
        max_sweeps: Maximum number of alternating sweeps. Default 10.
        tol: Relative convergence tolerance on the norm. Default 1e-6.
        dtype: Torch dtype. Default torch.float64.
        device: Torch device. Default None.
        seed: Random seed for index initialization. Default None.
        verbose: Print convergence info per sweep. Default False.

    Returns:
        TensorTrain approximation of the function/tensor.

    Example:
        # From a dense tensor
        dense = torch.randn(4, 5, 6, dtype=torch.float64)
        tt = tt_cross(dense, [4, 5, 6], max_rank=3)

        # From a function
        def f(points):
            # points: (N, d) array of integer indices
            return np.sum(points, axis=1).astype(float)
        tt = tt_cross(f, [10, 10, 10], max_rank=2)
    """
    d = len(dims)
    if d < 2:
        raise ValueError("TT-Cross requires at least 2 dimensions")

    rng = np.random.RandomState(seed)

    # If func is a dense tensor, wrap it
    if isinstance(func, torch.Tensor):
        dense_tensor = func

        if list(dense_tensor.shape) != dims:
            raise ValueError(f"Tensor shape {list(dense_tensor.shape)} doesn't match dims {dims}")

        def _dense_eval(points):
            idx = tuple(points[:, k] for k in range(d))
            return dense_tensor[idx].cpu().numpy()

        eval_func = _dense_eval
    else:
        eval_func = func

    # Clamp ranks: r_k <= min(max_rank, prod(n_0..n_k), prod(n_{k+1}..n_{d-1}))
    ranks = []
    for k in range(d - 1):
        left_prod = 1
        for j in range(k + 1):
            left_prod *= dims[j]
        right_prod = 1
        for j in range(k + 1, d):
            right_prod *= dims[j]
        r = min(max_rank, left_prod, right_prod)
        ranks.append(r)

    # Initialize right index sets randomly
    # right_idx_sets[k] has shape (ranks[k], d-k-1) for bond between k and k+1
    right_idx_sets: list[np.ndarray | None] = [None] * d
    for k in range(d - 2, -1, -1):
        r = ranks[k]
        n_right = d - k - 1
        right_idx = np.zeros((r, n_right), dtype=np.int64)
        for j in range(n_right):
            right_idx[:, j] = rng.randint(0, dims[k + 1 + j], size=r)
        right_idx_sets[k] = right_idx

    # Left index sets
    left_idx_sets: list[np.ndarray | None] = [None] * d
    left_idx_sets[0] = np.zeros((1, 0), dtype=np.int64)

    # Storage for cores
    cores: list[torch.Tensor | None] = [None] * d

    prev_norm_sq = None

    for sweep in range(max_sweeps):
        # === Left-to-right sweep ===
        _sweep_left_to_right(
            eval_func,
            dims,
            d,
            ranks,
            left_idx_sets,
            right_idx_sets,
            cores,
            dtype,
            device,
        )

        # === Right-to-left sweep ===
        _sweep_right_to_left(
            eval_func,
            dims,
            d,
            ranks,
            left_idx_sets,
            right_idx_sets,
            cores,
            dtype,
            device,
        )

        # Check convergence via norm
        internal_ranks = [cores[k].shape[2] for k in range(d - 1)]
        tt = TensorTrain(dims, internal_ranks, dtype, device)
        for k in range(d):
            tt.cores[k] = cores[k]

        norm_sq = linalg.norm_squared(tt)

        if verbose:
            print(f"Sweep {sweep}: norm^2 = {norm_sq:.6e}")

        if prev_norm_sq is not None and prev_norm_sq > 0:
            rel_change = abs(norm_sq - prev_norm_sq) / abs(prev_norm_sq)
            if rel_change < tol:
                if verbose:
                    print(f"Converged at sweep {sweep} (rel_change={rel_change:.2e})")
                break

        prev_norm_sq = norm_sq

    # Build final TT
    internal_ranks = [cores[k].shape[2] for k in range(d - 1)]
    tt = TensorTrain(dims, internal_ranks, dtype, device)
    for k in range(d):
        tt.cores[k] = cores[k]

    return tt


def _sweep_left_to_right(
    eval_func, dims, d, ranks, left_idx_sets, right_idx_sets, cores, dtype, device
):
    """Perform one left-to-right sweep, updating cores and left index sets.

    At each site k (except the last), evaluates the fiber, applies maxvol
    (with automatic rank detection) to find pivot rows, stores the coefficient
    matrix as the core, and updates the left index set from the pivot rows.
    """
    for k in range(d):
        left_idx = left_idx_sets[k]
        right_idx = right_idx_sets[k] if k < d - 1 else np.zeros((1, 0), dtype=np.int64)

        fiber = _evaluate_fiber(eval_func, left_idx, right_idx, k, dims[k], d, dtype, device)
        r_left, n_k, r_right = fiber.shape

        if k < d - 1:
            # Reshape to (r_left * n_k, r_right)
            # maxvol selects pivot rows and gives coefficient matrix as the core
            fiber_np = fiber.cpu().numpy().reshape(r_left * n_k, r_right)

            if r_left * n_k >= r_right:
                pivot_rows, coeff = maxvol(fiber_np)
                new_r = r_right
            else:
                # Fewer rows than columns: use all rows as pivots
                pivot_rows = np.arange(r_left * n_k)
                coeff = np.eye(r_left * n_k)
                new_r = r_left * n_k

            cores[k] = torch.tensor(
                coeff.reshape(r_left, n_k, new_r),
                dtype=dtype,
                device=device,
            )

            # Update left index set for k+1 from pivot rows
            # pivot_rows indexes into (r_left * n_k): unravel to (alpha, i_k)
            alphas = pivot_rows // n_k
            i_ks = pivot_rows % n_k

            new_left = np.zeros((new_r, k + 1), dtype=np.int64)
            for p in range(new_r):
                if k > 0:
                    new_left[p, :k] = left_idx[alphas[p]]
                new_left[p, k] = i_ks[p]
            left_idx_sets[k + 1] = new_left

            ranks[k] = new_r
        else:
            # Last core: store fiber directly
            cores[k] = fiber


def _sweep_right_to_left(
    eval_func, dims, d, ranks, left_idx_sets, right_idx_sets, cores, dtype, device
):
    """Perform one right-to-left sweep, updating cores and right index sets.

    At each site k (except the first), evaluates the fiber, applies maxvol
    (with automatic rank detection) to the transposed fiber to find pivot rows,
    stores the transposed coefficient matrix as the core, and updates the
    right index set.
    """
    for k in range(d - 1, -1, -1):
        left_idx = left_idx_sets[k]
        right_idx = right_idx_sets[k] if k < d - 1 else np.zeros((1, 0), dtype=np.int64)

        fiber = _evaluate_fiber(eval_func, left_idx, right_idx, k, dims[k], d, dtype, device)
        r_left, n_k, r_right = fiber.shape

        if k > 0:
            # Reshape to (r_left, n_k * r_right), transpose to
            # (n_k * r_right, r_left). maxvol selects pivot rows and
            # gives coefficient matrix; transposing gives the core.
            fiber_np = fiber.cpu().numpy().reshape(r_left, n_k * r_right)
            mat_t = fiber_np.T  # (n_k * r_right, r_left)

            if n_k * r_right >= r_left:
                pivot_rows, coeff = maxvol(mat_t)
                new_r = r_left
            else:
                # Fewer rows than columns: use all rows as pivots
                pivot_rows = np.arange(n_k * r_right)
                coeff = np.eye(n_k * r_right)
                new_r = n_k * r_right

            # coeff: (n_k*r_right, new_r), transpose -> (new_r, n_k*r_right)
            cores[k] = torch.tensor(
                coeff.T.reshape(new_r, n_k, r_right),
                dtype=dtype,
                device=device,
            )

            # Update right index set for k-1 from pivot rows
            # pivot_rows indexes into (n_k * r_right): unravel to (i_k, beta)
            i_ks = pivot_rows // r_right
            betas = pivot_rows % r_right

            new_right = np.zeros((new_r, d - k), dtype=np.int64)
            for p in range(new_r):
                new_right[p, 0] = i_ks[p]
                if k < d - 1 and right_idx.size > 0:
                    new_right[p, 1:] = right_idx[betas[p]]
            right_idx_sets[k - 1] = new_right

            ranks[k - 1] = new_r
        else:
            # First core: store fiber directly
            cores[k] = fiber
