"""Diagonalization algorithms for Tensor Train matrices.

This module implements the weighted approximate joint diagonalization (AJD)
algorithm for TTMatrix diagonalization, as described in:

    "Tensor Train Diagonalization via Weighted Off-Diagonal Minimization"

The key idea is to find a unitary U that maximizes the weighted diagonal norm:
    f(U) = Σ_α ||U τ^α U^T||_D^2

where D = P_k + P_{k+1} is the weight matrix assigning:
    - Weight 2 to elements diagonal in both modes
    - Weight 1 to elements diagonal in exactly one mode
    - Weight 0 to elements off-diagonal in both modes
"""

from typing import List, Tuple, Optional, Dict, Any
import torch


def build_weight_matrix(
    n_k: int, n_kp1: int, dtype: torch.dtype = torch.float64, device: torch.device = None,
    w_k: float = 1.0, w_kp1: float = 1.0,
) -> torch.Tensor:
    """Build the weight matrix D = w_k * P_k + w_{k+1} * P_{k+1} for the fused mode space.

    The weight matrix assigns:
        D[(i_k, i_{k+1}), (j_k, j_{k+1})] = w_k * δ_{i_k, j_k} + w_{k+1} * δ_{i_{k+1}, j_{k+1}}

    Args:
        n_k: Dimension of mode k
        n_kp1: Dimension of mode k+1
        dtype: Data type for the tensor
        device: Device for the tensor
        w_k: Weight for mode k (default: 1.0)
        w_kp1: Weight for mode k+1 (default: 1.0)

    Returns:
        Weight matrix D of shape (n_k * n_kp1, n_k * n_kp1)
    """
    n = n_k * n_kp1
    D = torch.zeros(n, n, dtype=dtype, device=device)

    for i_k in range(n_k):
        for i_kp1 in range(n_kp1):
            i = i_k * n_kp1 + i_kp1  # Fused index
            for j_k in range(n_k):
                for j_kp1 in range(n_kp1):
                    j = j_k * n_kp1 + j_kp1  # Fused index
                    # Weight = w_k * δ_{i_k, j_k} + w_{k+1} * δ_{i_{k+1}, j_{k+1}}
                    weight = (w_k if i_k == j_k else 0) + (w_kp1 if i_kp1 == j_kp1 else 0)
                    D[i, j] = weight

    return D


def build_weight_matrix_fast(
    n_k: int, n_kp1: int, dtype: torch.dtype = None, device: torch.device = None,
    w_k: float = 1.0, w_kp1: float = 1.0,
) -> torch.Tensor:
    """Build the weight matrix D = w_k * P_k + w_{k+1} * P_{k+1} using vectorized operations.

    This is a faster implementation using Kronecker products:
        P_k = I_{n_k} ⊗ ones_{n_{k+1}}
        P_{k+1} = ones_{n_k} ⊗ I_{n_{k+1}}
        D = w_k * P_k + w_{k+1} * P_{k+1}

    Args:
        n_k: Dimension of mode k
        n_kp1: Dimension of mode k+1
        dtype: Data type for the tensor
        device: Device for the tensor
        w_k: Weight for mode k (default: 1.0)
        w_kp1: Weight for mode k+1 (default: 1.0)

    Returns:
        Weight matrix D of shape (n_k * n_kp1, n_k * n_kp1)
    """
    # Use default dtype if not specified
    if dtype is None:
        dtype = torch.get_default_dtype()

    # P_k: identity on mode k, all-ones on mode k+1
    # In fused space: P_k[i, j] = δ_{i_k, j_k}
    I_k = torch.eye(n_k, dtype=dtype, device=device)
    ones_kp1 = torch.ones(n_kp1, n_kp1, dtype=dtype, device=device)
    P_k = torch.kron(I_k, ones_kp1)

    # P_{k+1}: all-ones on mode k, identity on mode k+1
    # In fused space: P_{k+1}[i, j] = δ_{i_{k+1}, j_{k+1}}
    ones_k = torch.ones(n_k, n_k, dtype=dtype, device=device)
    I_kp1 = torch.eye(n_kp1, dtype=dtype, device=device)
    P_kp1 = torch.kron(ones_k, I_kp1)

    return w_k * P_k + w_kp1 * P_kp1


# Use the fast implementation by default
build_weight_matrix = build_weight_matrix_fast


def build_diagonal_weight_matrix(
    n: int, dtype: torch.dtype = None, device: torch.device = None
) -> torch.Tensor:
    """Build the standard diagonal weight matrix D = I.

    For standard matrix diagonalization, we want to maximize the squared
    norm of the diagonal elements only. This corresponds to D = I.

    Args:
        n: Matrix dimension
        dtype: Data type for the tensor
        device: Device for the tensor

    Returns:
        Identity matrix of shape (n, n)
    """
    if dtype is None:
        dtype = torch.get_default_dtype()
    return torch.eye(n, dtype=dtype, device=device)


def perturb_weight_matrix(
    D: torch.Tensor,
    noise_scale: float,
    offdiag_only: bool = True,
) -> torch.Tensor:
    """Add random noise to the weight matrix to escape local minima.

    Args:
        D: Weight matrix of shape (n, n)
        noise_scale: Scale of the random noise (multiplied by D's scale)
        offdiag_only: If True, only perturb off-diagonal elements

    Returns:
        Perturbed weight matrix
    """
    n = D.shape[0]
    noise = torch.randn_like(D) * noise_scale

    if offdiag_only:
        # Zero out diagonal noise
        noise = noise - torch.diag(torch.diag(noise))

    # Add noise and ensure non-negative weights
    D_perturbed = D + noise
    D_perturbed = torch.clamp(D_perturbed, min=0.0)

    # Keep symmetry
    D_perturbed = 0.5 * (D_perturbed + D_perturbed.T)

    return D_perturbed


def weighted_norm_squared(tau: torch.Tensor, D: torch.Tensor) -> torch.Tensor:
    """Compute the D-weighted norm squared: ||τ||_D^2 = <D, τ ⊙ τ>.

    Args:
        tau: Matrix of shape (n, n)
        D: Weight matrix of shape (n, n)

    Returns:
        Scalar tensor with the weighted norm squared
    """
    return torch.sum(D * tau * tau)


def euclidean_gradient_at_identity(
    taus: List[torch.Tensor], D: torch.Tensor
) -> torch.Tensor:
    """Compute the Euclidean gradient of the objective at U = I.

    The gradient is:
        G = 2 Σ_α [(D ⊙ τ^α)(τ^α)^T + (D ⊙ (τ^α)^T)τ^α]

    Args:
        taus: List of matrices τ^α, each of shape (n, n)
        D: Weight matrix of shape (n, n)

    Returns:
        Gradient matrix G of shape (n, n)
    """
    n = taus[0].shape[0]
    G = torch.zeros(n, n, dtype=taus[0].dtype, device=taus[0].device)

    for tau in taus:
        G += (D * tau) @ tau.T + (D * tau.T) @ tau

    return 2 * G


def skew(M: torch.Tensor) -> torch.Tensor:
    """Extract the skew-symmetric part of a matrix.

    Args:
        M: Square matrix

    Returns:
        Skew-symmetric matrix (M - M^T) / 2
    """
    return 0.5 * (M - M.T)


def weighted_ajd(
    taus: List[torch.Tensor],
    n_k: int,
    n_kp1: int,
    max_iters: int = 100,
    tol: float = 1e-8,
    step_size: float = 0.5,
    return_info: bool = False,
    w_k: float = 1.0,
    w_kp1: float = 1.0,
) -> Tuple[torch.Tensor, List[torch.Tensor], Optional[Dict[str, Any]]]:
    """Weighted Approximate Joint Diagonalization.

    Finds a unitary U that maximizes:
        f(U) = Σ_α ||U τ^α U^T||_D^2

    where D = w_k * P_k + w_{k+1} * P_{k+1} is the mode-weighted weight matrix.

    Args:
        taus: List of matrices τ^α, each of shape (n_k * n_kp1, n_k * n_kp1)
        n_k: Dimension of mode k
        n_kp1: Dimension of mode k+1
        max_iters: Maximum number of iterations
        tol: Convergence tolerance on gradient norm
        step_size: Step size η for gradient ascent
        return_info: If True, return additional info dict
        w_k: Weight for mode k (default: 1.0). Use increasing weights (e.g., k+1)
             to break degeneracies and avoid local minima.
        w_kp1: Weight for mode k+1 (default: 1.0)

    Returns:
        U: Optimal unitary matrix such that taus_transformed[i] = U @ taus[i] @ U.T
        taus_transformed: List of transformed matrices U τ^α U^T
        info: (optional) Dict with convergence info
    """
    n = n_k * n_kp1
    dtype = taus[0].dtype
    device = taus[0].device

    # Build weight matrix with mode-dependent weights
    D = build_weight_matrix(n_k, n_kp1, dtype=dtype, device=device, w_k=w_k, w_kp1=w_kp1)

    # Initialize accumulated unitary
    U = torch.eye(n, dtype=dtype, device=device)

    # Make copies of taus that we'll transform in-place
    taus_current = [tau.clone() for tau in taus]

    info = {"iterations": 0, "grad_norms": [], "objectives": []}

    for iteration in range(max_iters):
        # Compute objective
        obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
        info["objectives"].append(obj.item())

        # Compute Euclidean gradient at identity (for current taus)
        G = euclidean_gradient_at_identity(taus_current, D)

        # Extract Riemannian gradient (skew-symmetric part)
        Omega = skew(G)

        # Check convergence
        grad_norm = torch.norm(Omega, p="fro")
        info["grad_norms"].append(grad_norm.item())

        if grad_norm < tol:
            info["iterations"] = iteration
            info["converged"] = True
            break

        # Backtracking line search to ensure objective increases
        current_step = step_size
        obj_current = obj

        for _ in range(10):  # Max line search iterations
            # Gradient ascent step via matrix exponential
            # ΔU = exp(η * Ω)
            delta_U = torch.linalg.matrix_exp(current_step * Omega)

            # Trial transform
            taus_trial = [delta_U @ tau @ delta_U.T for tau in taus_current]
            obj_trial = sum(weighted_norm_squared(tau, D) for tau in taus_trial)

            if obj_trial >= obj_current:
                break
            current_step *= 0.5
        else:
            # Line search failed, use very small step
            current_step = 0.01
            delta_U = torch.linalg.matrix_exp(current_step * Omega)

        # Accumulate: U ← ΔU · U (left multiply so that U @ tau_orig @ U.T = tau_current)
        U = delta_U @ U

        # Transform τ^α matrices: τ^α ← ΔU τ^α ΔU^T
        for i in range(len(taus_current)):
            taus_current[i] = delta_U @ taus_current[i] @ delta_U.T

        info["iterations"] = iteration + 1
    else:
        info["converged"] = False

    # Final objective
    obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
    info["final_objective"] = obj.item()

    if return_info:
        return U, taus_current, info
    else:
        return U, taus_current


def weighted_ajd_with_linesearch(
    taus: List[torch.Tensor],
    n_k: int,
    n_kp1: int,
    max_iters: int = 100,
    tol: float = 1e-8,
    return_info: bool = False,
) -> Tuple[torch.Tensor, List[torch.Tensor], Optional[Dict[str, Any]]]:
    """Weighted AJD with adaptive step size via line search.

    Uses backtracking line search to find an appropriate step size.

    Args:
        taus: List of matrices τ^α
        n_k: Dimension of mode k
        n_kp1: Dimension of mode k+1
        max_iters: Maximum number of iterations
        tol: Convergence tolerance on gradient norm
        return_info: If True, return additional info dict

    Returns:
        U: Optimal unitary matrix
        taus_transformed: List of transformed matrices
        info: (optional) Dict with convergence info
    """
    n = n_k * n_kp1
    dtype = taus[0].dtype
    device = taus[0].device

    D = build_weight_matrix(n_k, n_kp1, dtype=dtype, device=device)
    U = torch.eye(n, dtype=dtype, device=device)
    taus_current = [tau.clone() for tau in taus]

    info = {"iterations": 0, "grad_norms": [], "objectives": [], "step_sizes": []}

    for iteration in range(max_iters):
        obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
        info["objectives"].append(obj.item())

        G = euclidean_gradient_at_identity(taus_current, D)
        Omega = skew(G)

        grad_norm = torch.norm(Omega, p="fro")
        info["grad_norms"].append(grad_norm.item())

        if grad_norm < tol:
            info["iterations"] = iteration
            info["converged"] = True
            break

        # Backtracking line search
        step_size = 2.0
        c = 0.5  # Sufficient decrease parameter
        rho = 0.5  # Step size reduction factor

        for _ in range(20):  # Max line search iterations
            delta_U = torch.linalg.matrix_exp(step_size * Omega)

            # Compute new objective
            taus_trial = [delta_U @ tau @ delta_U.T for tau in taus_current]
            obj_new = sum(weighted_norm_squared(tau, D) for tau in taus_trial)

            # Check sufficient increase (we're maximizing)
            # Expected increase from gradient: <G, Ω> ≈ ||Ω||^2 (since G is related to Ω)
            expected_increase = step_size * grad_norm**2

            if obj_new >= obj + c * expected_increase:
                break

            step_size *= rho
        else:
            # Line search failed, use small step
            step_size = 0.1

        info["step_sizes"].append(step_size)

        # Apply the update
        delta_U = torch.linalg.matrix_exp(step_size * Omega)
        U = U @ delta_U

        for i in range(len(taus_current)):
            taus_current[i] = delta_U @ taus_current[i] @ delta_U.T

        info["iterations"] = iteration + 1
    else:
        info["converged"] = False

    obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
    info["final_objective"] = obj.item()

    if return_info:
        return U, taus_current, info
    else:
        return U, taus_current


def _skew_inner(A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
    """Frobenius inner product for skew-symmetric matrices.

    <A, B> = tr(A^T B) = Σ_{ij} A_{ij} B_{ij}

    Args:
        A: Skew-symmetric matrix
        B: Skew-symmetric matrix

    Returns:
        Scalar tensor with the inner product
    """
    return torch.sum(A * B)


def weighted_ajd_lbfgs(
    taus: List[torch.Tensor],
    n_k: int,
    n_kp1: int,
    max_iters: int = 100,
    tol: float = 1e-8,
    memory_size: int = 10,
    c1: float = 1e-4,
    c2: float = 0.9,
    return_info: bool = False,
    D: Optional[torch.Tensor] = None,
    w_k: float = 1.0,
    w_kp1: float = 1.0,
) -> Tuple[torch.Tensor, List[torch.Tensor], Optional[Dict[str, Any]]]:
    """Weighted AJD using Riemannian L-BFGS on the orthogonal group.

    Uses L-BFGS with limited memory to approximate the inverse Hessian
    on the tangent space (skew-symmetric matrices). Since the algorithm
    works at identity by transforming τ matrices, the tangent space
    is fixed and no explicit vector transport is needed.

    The search direction is computed via the standard L-BFGS two-loop
    recursion, and steps are taken along geodesics via matrix exponential.

    Args:
        taus: List of matrices τ^α, each of shape (n_k * n_kp1, n_k * n_kp1)
        n_k: Dimension of mode k
        n_kp1: Dimension of mode k+1
        max_iters: Maximum number of iterations
        tol: Convergence tolerance on gradient norm
        memory_size: Number of (s, y) pairs to store for L-BFGS
        c1: Armijo condition parameter for line search
        c2: Wolfe curvature condition parameter (not strictly enforced)
        return_info: If True, return additional info dict
        D: Optional custom weight matrix. If None, builds D = w_k * P_k + w_{k+1} * P_{k+1}.
        w_k: Weight for mode k (default: 1.0). Use increasing weights (e.g., k+1)
             to break degeneracies and avoid local minima. Ignored if D is provided.
        w_kp1: Weight for mode k+1 (default: 1.0). Ignored if D is provided.

    Returns:
        U: Optimal unitary matrix such that taus_transformed[i] = U @ taus[i] @ U.T
        taus_transformed: List of transformed matrices U τ^α U^T
        info: (optional) Dict with convergence info
    """
    n = n_k * n_kp1
    dtype = taus[0].dtype
    device = taus[0].device

    # Build weight matrix if not provided
    if D is None:
        D = build_weight_matrix(n_k, n_kp1, dtype=dtype, device=device, w_k=w_k, w_kp1=w_kp1)

    # Initialize accumulated unitary
    U = torch.eye(n, dtype=dtype, device=device)

    # Make copies of taus that we'll transform in-place
    taus_current = [tau.clone() for tau in taus]

    # L-BFGS memory: store s and y as skew-symmetric matrices
    s_history: List[torch.Tensor] = []  # step directions
    y_history: List[torch.Tensor] = []  # gradient differences
    rho_history: List[torch.Tensor] = []  # 1 / <y, s>

    info = {
        "iterations": 0,
        "grad_norms": [],
        "objectives": [],
        "step_sizes": [],
    }

    # Compute initial gradient
    G = euclidean_gradient_at_identity(taus_current, D)
    grad = skew(G)

    for iteration in range(max_iters):
        # Compute objective
        obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
        info["objectives"].append(obj.item())

        # Check convergence
        grad_norm = torch.norm(grad, p="fro")
        info["grad_norms"].append(grad_norm.item())

        if grad_norm < tol:
            info["iterations"] = iteration
            info["converged"] = True
            break

        # L-BFGS two-loop recursion to compute search direction
        q = grad.clone()
        alphas = []

        # First loop (backward through history)
        for s, y, rho in zip(
            reversed(s_history), reversed(y_history), reversed(rho_history)
        ):
            alpha = rho * _skew_inner(s, q)
            alphas.append(alpha)
            q = q - alpha * y

        alphas = alphas[::-1]  # Reverse to match forward loop order

        # Initial Hessian approximation: H_0 = γ * I
        # where γ = <s_{k-1}, y_{k-1}> / <y_{k-1}, y_{k-1}>
        if len(s_history) > 0:
            sy = _skew_inner(s_history[-1], y_history[-1])
            yy = _skew_inner(y_history[-1], y_history[-1])
            if yy > 1e-12:
                gamma = sy / yy
                gamma = torch.clamp(gamma, min=1e-6, max=1e6)
            else:
                gamma = torch.tensor(1.0, dtype=dtype, device=device)
        else:
            gamma = torch.tensor(1.0, dtype=dtype, device=device)

        r = gamma * q

        # Second loop (forward through history)
        for i, (s, y, rho) in enumerate(zip(s_history, y_history, rho_history)):
            beta = rho * _skew_inner(y, r)
            r = r + (alphas[i] - beta) * s

        # Search direction (we're maximizing, so this is ascent direction)
        direction = r

        # Wolfe line search
        step_size = torch.tensor(1.0, dtype=dtype, device=device)
        obj_current = obj
        grad_dot_dir = _skew_inner(grad, direction)

        # Ensure we have an ascent direction
        if grad_dot_dir <= 0:
            # Fall back to gradient direction
            direction = grad
            grad_dot_dir = _skew_inner(grad, direction)

        # Backtracking line search with Armijo condition
        for ls_iter in range(25):
            delta_U = torch.linalg.matrix_exp(step_size * direction)
            taus_trial = [delta_U @ tau @ delta_U.T for tau in taus_current]
            obj_trial = sum(weighted_norm_squared(tau, D) for tau in taus_trial)

            # Armijo condition for maximization: f(x + αp) ≥ f(x) + c1 * α * ∇f·p
            if obj_trial >= obj_current + c1 * step_size * grad_dot_dir:
                break
            step_size = step_size * 0.5
        else:
            # Line search failed, use very small step
            step_size = torch.tensor(0.01, dtype=dtype, device=device)
            delta_U = torch.linalg.matrix_exp(step_size * direction)

        info["step_sizes"].append(step_size.item())

        # Take the step
        # Accumulate: U ← ΔU · U (left multiply so that U @ tau_orig @ U.T = tau_current)
        U = delta_U @ U

        # Transform τ^α matrices: τ^α ← ΔU τ^α ΔU^T
        for i in range(len(taus_current)):
            taus_current[i] = delta_U @ taus_current[i] @ delta_U.T

        # Compute new gradient
        G_new = euclidean_gradient_at_identity(taus_current, D)
        grad_new = skew(G_new)

        # Update L-BFGS history
        # s_k = actual step in tangent space
        s_k = step_size * direction
        # y_k = gradient difference
        # For MAXIMIZATION: we negate y_k because we're effectively minimizing -f
        # This ensures the curvature condition sy > 0 is satisfied
        y_k = grad - grad_new  # Note: negated for maximization

        sy = _skew_inner(s_k, y_k)
        # Only update if curvature condition is satisfied
        if sy > 1e-10:
            if len(s_history) >= memory_size:
                s_history.pop(0)
                y_history.pop(0)
                rho_history.pop(0)
            s_history.append(s_k.clone())
            y_history.append(y_k.clone())
            rho_history.append(1.0 / sy)

        grad = grad_new
        info["iterations"] = iteration + 1
    else:
        info["converged"] = False

    # Final objective
    obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
    info["final_objective"] = obj.item()

    if return_info:
        return U, taus_current, info
    else:
        return U, taus_current


def joint_diagonalize_lbfgs(
    taus: List[torch.Tensor],
    max_iters: int = 100,
    tol: float = 1e-8,
    memory_size: int = 10,
    c1: float = 1e-4,
    return_info: bool = False,
) -> Tuple[torch.Tensor, List[torch.Tensor], Optional[Dict[str, Any]]]:
    """Standard joint diagonalization using Riemannian L-BFGS.

    Finds a unitary U that maximizes:
        f(U) = Σ_α ||diag(U τ^α U^T)||^2

    This is STANDARD joint diagonalization (Jacobi-style), using D = I
    as the weight matrix, which only rewards true diagonal elements.

    Use this for matrix diagonalization. Use weighted_ajd_lbfgs for
    TT-specific diagonalization with the P_k + P_{k+1} weighting.

    Args:
        taus: List of matrices τ^α, each of shape (n, n)
        max_iters: Maximum number of iterations
        tol: Convergence tolerance on gradient norm
        memory_size: Number of (s, y) pairs to store for L-BFGS
        c1: Armijo condition parameter for line search
        return_info: If True, return additional info dict

    Returns:
        U: Optimal unitary matrix such that taus_transformed[i] = U @ taus[i] @ U.T
        taus_transformed: List of transformed matrices U τ^α U^T
        info: (optional) Dict with convergence info
    """
    n = taus[0].shape[0]
    dtype = taus[0].dtype
    device = taus[0].device

    # Use standard diagonal weight matrix D = I
    D = build_diagonal_weight_matrix(n, dtype=dtype, device=device)

    # Initialize accumulated unitary
    U = torch.eye(n, dtype=dtype, device=device)

    # Make copies of taus that we'll transform in-place
    taus_current = [tau.clone() for tau in taus]

    # L-BFGS memory
    s_history: List[torch.Tensor] = []
    y_history: List[torch.Tensor] = []
    rho_history: List[torch.Tensor] = []

    info = {
        "iterations": 0,
        "grad_norms": [],
        "objectives": [],
        "step_sizes": [],
    }

    # Compute initial gradient
    G = euclidean_gradient_at_identity(taus_current, D)
    grad = skew(G)

    for iteration in range(max_iters):
        # Compute objective
        obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
        info["objectives"].append(obj.item())

        # Check convergence
        grad_norm = torch.norm(grad, p="fro")
        info["grad_norms"].append(grad_norm.item())

        if grad_norm < tol:
            info["iterations"] = iteration
            info["converged"] = True
            break

        # L-BFGS two-loop recursion
        q = grad.clone()
        alphas = []

        for s, y, rho in zip(
            reversed(s_history), reversed(y_history), reversed(rho_history)
        ):
            alpha = rho * _skew_inner(s, q)
            alphas.append(alpha)
            q = q - alpha * y

        alphas = alphas[::-1]

        if len(s_history) > 0:
            sy = _skew_inner(s_history[-1], y_history[-1])
            yy = _skew_inner(y_history[-1], y_history[-1])
            if yy > 1e-12:
                gamma = sy / yy
                gamma = torch.clamp(gamma, min=1e-6, max=1e6)
            else:
                gamma = torch.tensor(1.0, dtype=dtype, device=device)
        else:
            gamma = torch.tensor(1.0, dtype=dtype, device=device)

        r = gamma * q

        for i, (s, y, rho) in enumerate(zip(s_history, y_history, rho_history)):
            beta = rho * _skew_inner(y, r)
            r = r + (alphas[i] - beta) * s

        direction = r
        step_size = torch.tensor(1.0, dtype=dtype, device=device)
        obj_current = obj
        grad_dot_dir = _skew_inner(grad, direction)

        if grad_dot_dir <= 0:
            direction = grad
            grad_dot_dir = _skew_inner(grad, direction)

        # Backtracking line search
        for ls_iter in range(25):
            delta_U = torch.linalg.matrix_exp(step_size * direction)
            taus_trial = [delta_U @ tau @ delta_U.T for tau in taus_current]
            obj_trial = sum(weighted_norm_squared(tau, D) for tau in taus_trial)

            if obj_trial >= obj_current + c1 * step_size * grad_dot_dir:
                break
            step_size = step_size * 0.5
        else:
            step_size = torch.tensor(0.01, dtype=dtype, device=device)
            delta_U = torch.linalg.matrix_exp(step_size * direction)

        info["step_sizes"].append(step_size.item())

        U = delta_U @ U

        for i in range(len(taus_current)):
            taus_current[i] = delta_U @ taus_current[i] @ delta_U.T

        G_new = euclidean_gradient_at_identity(taus_current, D)
        grad_new = skew(G_new)

        s_k = step_size * direction
        y_k = grad - grad_new  # Negated for maximization

        sy = _skew_inner(s_k, y_k)
        if sy > 1e-10:
            if len(s_history) >= memory_size:
                s_history.pop(0)
                y_history.pop(0)
                rho_history.pop(0)
            s_history.append(s_k.clone())
            y_history.append(y_k.clone())
            rho_history.append(1.0 / sy)

        grad = grad_new
        info["iterations"] = iteration + 1
    else:
        info["converged"] = False

    obj = sum(weighted_norm_squared(tau, D) for tau in taus_current)
    info["final_objective"] = obj.item()

    if return_info:
        return U, taus_current, info
    else:
        return U, taus_current