"""Tensor completion via SiLRTC-TT (Simple Low-Rank Tensor Completion - Tensor Train).

Completes a tensor from a sparse set of observed entries by minimizing the
sum of TT-style nuclear norms of balanced matricizations.  The algorithm
works with the full dense tensor and applies soft-thresholded SVD to each
matricization at every iteration.

Reference:
    Bengua et al., "Efficient Tensor Completion for Color Image and Video
    Recovery: Low-Rank Tensor Train", 2016.  Algorithm I (SiLRTC-TT).
"""

from __future__ import annotations

import math

import torch

from .tensortrain import TensorTrain


def _soft_threshold_svd(matrix: torch.Tensor, gamma: float) -> torch.Tensor:
    """Soft-thresholded SVD: D_gamma(A) = U diag(max(sigma - gamma, 0)) V^T."""
    u, s, vt = torch.linalg.svd(matrix, full_matrices=False)
    s_thresh = torch.clamp(s - gamma, min=0.0)
    return u * s_thresh.unsqueeze(0) @ vt


def _compute_weights(dims: list[int] | tuple[int, ...]) -> list[float]:
    """Compute alpha_k weights per eq (44).

    alpha_k = delta_k / sum(delta_k) where
    delta_k = min(prod(dims[:k+1]), prod(dims[k+1:])).
    """
    n = len(dims)
    total = math.prod(dims)
    deltas = []
    left_prod = 1
    for k in range(n - 1):
        left_prod *= dims[k]
        right_prod = total // left_prod
        deltas.append(min(left_prod, right_prod))
    delta_sum = sum(deltas)
    return [d / delta_sum for d in deltas]


def silrtc_tt(
    indices: torch.Tensor,
    values: torch.Tensor,
    dims: list[int] | tuple[int, ...],
    alpha: list[float] | None = None,
    beta: list[float] | None = None,
    max_iters: int = 500,
    tol: float = 1e-4,
    dtype: torch.dtype = torch.float64,
    device: torch.device | None = None,
    verbose: bool = False,
) -> TensorTrain:
    """Complete a tensor from observed entries using SiLRTC-TT.

    Minimizes the sum of TT nuclear norms via alternating soft-thresholded
    SVD on balanced matricizations (Algorithm I of Bengua et al., 2016).

    When ``beta`` is not provided, a continuation schedule is used: beta
    starts small (large gamma → aggressive nuclear-norm shrinkage for fast
    rank reduction) and is geometrically increased each iteration until a
    target value is reached (small gamma → preserves detail).  This is a
    standard enhancement to SiLRTC that greatly improves convergence.

    Args:
        indices: Multi-indices of observed entries, shape (num_obs, N).
        values: Observed values, shape (num_obs,).
        dims: Tensor dimensions (I_1, I_2, ..., I_N).
        alpha: Per-unfolding weights (length N-1). Auto-computed if None.
        beta: Per-unfolding penalty parameters (length N-1). Auto-computed
              if None; when None a continuation schedule is used internally.
        max_iters: Maximum number of iterations.
        tol: Convergence tolerance on relative change ||X^{l+1} - X^l|| / ||X^l||.
        dtype: Torch dtype for computation.
        device: Torch device.
        verbose: Print convergence info.

    Returns:
        TensorTrain of the completed tensor.

    Raises:
        ValueError: If inputs have incompatible shapes or out-of-bounds indices.
    """
    dims = list(dims)
    n = len(dims)

    # --- Validation ---
    indices = indices.to(dtype=torch.long, device=device)
    values = values.to(dtype=dtype, device=device)

    if indices.ndim != 2:
        raise ValueError(f"indices must be 2D, got {indices.ndim}D")
    if values.ndim != 1:
        raise ValueError(f"values must be 1D, got {values.ndim}D")
    if indices.shape[0] != values.shape[0]:
        raise ValueError(
            f"indices ({indices.shape[0]}) and values ({values.shape[0]}) "
            f"must have the same number of entries"
        )
    if indices.shape[1] != n:
        raise ValueError(
            f"indices has {indices.shape[1]} columns but dims has {n} entries"
        )
    for k in range(n):
        if indices[:, k].min() < 0 or indices[:, k].max() >= dims[k]:
            raise ValueError(
                f"Index out of bounds for dimension {k} (size {dims[k]})"
            )

    # --- Weight setup ---
    num_unfolds = n - 1
    if alpha is None:
        alpha = _compute_weights(dims)

    use_continuation = beta is None
    if use_continuation:
        # Estimate scale from the initial zero-filled tensor.
        # gamma_k = alpha_k/beta_k;  with beta_k = f*alpha_k  →  gamma = 1/f.
        # Start with gamma ~ median noise singular value (aggressive shrinkage)
        # and decrease to gamma ~ 0 (preserve signal) over iterations.
        x_init = torch.zeros(dims, dtype=dtype, device=device)
        idx_init = tuple(indices[:, k] for k in range(n))
        x_init[idx_init] = values
        total_prod = math.prod(dims)
        left_prod = 1
        max_sv = 0.0
        for k in range(num_unfolds):
            left_prod *= dims[k]
            right_prod = total_prod // left_prod
            sv = torch.linalg.svdvals(x_init.reshape(left_prod, right_prod))
            max_sv = max(max_sv, sv[0].item())
        del x_init

        # gamma_start = fraction of the largest singular value: aggressive
        # enough to threshold noise but preserves dominant signal.
        # gamma_end is small (nearly no thresholding, refinement phase).
        gamma_start = max(0.5 * max_sv, 1e-8)
        gamma_end = gamma_start * 1e-3
        # f = 1/gamma, so beta_k = alpha_k / gamma
        beta_start = [a / gamma_start for a in alpha]
        beta_end = [a / gamma_end for a in alpha]
        # Spread transition over all iterations for smooth convergence
        rho = (gamma_start / gamma_end) ** (1.0 / max(max_iters - 1, 1))
        beta = list(beta_start)

    # Build index tuple for fancy indexing
    idx_tuple = tuple(indices[:, k] for k in range(n))

    # --- Initialize X: zeros with observed entries pinned ---
    x = torch.zeros(dims, dtype=dtype, device=device)
    x[idx_tuple] = values

    for iteration in range(max_iters):
        x_prev = x.clone()

        # --- Compute M_k for each unfolding ---
        beta_sum = sum(beta)
        m_sum = torch.zeros_like(x)
        total_prod = math.prod(dims)
        left_prod = 1
        for k in range(num_unfolds):
            left_prod *= dims[k]
            right_prod = total_prod // left_prod
            # Matricize
            x_mat = x.reshape(left_prod, right_prod)
            # Soft-thresholded SVD
            gamma = alpha[k] / beta[k]
            m_k = _soft_threshold_svd(x_mat, gamma)
            # Fold back and accumulate
            m_sum += beta[k] * m_k.reshape(dims)

        # --- Update X ---
        x = m_sum / beta_sum
        # Pin observed entries
        x[idx_tuple] = values

        # --- Update beta (continuation) ---
        if use_continuation:
            beta = [min(b * rho, b_end) for b, b_end in zip(beta, beta_end)]

        # --- Convergence check ---
        x_prev_norm = torch.linalg.norm(x_prev).item()
        if x_prev_norm > 0:
            rel_change = torch.linalg.norm(x - x_prev).item() / x_prev_norm
        else:
            rel_change = torch.linalg.norm(x - x_prev).item()

        if verbose:
            print(f"Iter {iteration}: rel_change = {rel_change:.6e}")

        if rel_change <= tol:
            if verbose:
                print(f"Converged at iteration {iteration}")
            break

    return TensorTrain.from_dense(x)
