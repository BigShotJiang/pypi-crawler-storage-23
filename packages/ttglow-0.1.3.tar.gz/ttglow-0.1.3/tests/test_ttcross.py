import numpy as np
import pytest
import torch

from ttglow.ttcross import maxvol, tt_cross


class TestMaxvol:
    def test_basic_identity(self):
        """Maxvol of identity-like matrix should recover identity rows."""
        mat = np.eye(5, 3)
        indices, coeff = maxvol(mat)
        assert len(indices) == 3
        # coeff @ mat[indices] should approximate mat
        approx = coeff @ mat[indices]
        np.testing.assert_allclose(approx, mat, atol=1e-10)

    def test_random_matrix(self):
        """Maxvol on random tall matrix should give good approximation."""
        rng = np.random.RandomState(42)
        mat = rng.randn(20, 5)
        indices, coeff = maxvol(mat)

        assert len(indices) == 5
        assert coeff.shape == (20, 5)
        # Check reconstruction: mat ≈ coeff @ mat[indices]
        approx = coeff @ mat[indices]
        np.testing.assert_allclose(approx, mat, atol=1e-10)

    def test_pivot_rows_are_identity(self):
        """coeff[indices] should be close to identity matrix."""
        rng = np.random.RandomState(123)
        mat = rng.randn(15, 4)
        indices, coeff = maxvol(mat)
        np.testing.assert_allclose(coeff[indices], np.eye(4), atol=1e-10)

    def test_square_matrix(self):
        """Maxvol on square matrix should return all rows."""
        rng = np.random.RandomState(0)
        mat = rng.randn(4, 4)
        indices, coeff = maxvol(mat)
        assert len(indices) == 4
        np.testing.assert_allclose(coeff, np.eye(4), atol=1e-10)

    def test_raises_on_wide_matrix(self):
        """Should raise ValueError for wide matrices."""
        mat = np.zeros((3, 5))
        with pytest.raises(ValueError, match="must be tall"):
            maxvol(mat)


class TestTTCrossDense:
    def test_exact_rank1(self):
        """TT-Cross should exactly recover a rank-1 tensor."""
        torch.manual_seed(42)
        # Rank-1 tensor: outer product of vectors
        a = torch.randn(4, dtype=torch.float64)
        b = torch.randn(5, dtype=torch.float64)
        c = torch.randn(6, dtype=torch.float64)
        dense = torch.einsum("i,j,k->ijk", a, b, c)

        tt = tt_cross(dense, [4, 5, 6], max_rank=2, max_sweeps=10, seed=42)
        reconstructed = tt.to_tensor()
        assert torch.allclose(dense, reconstructed, atol=1e-8)

    def test_low_rank_tensor(self):
        """TT-Cross should approximate a low-rank tensor well."""
        torch.manual_seed(42)
        from ttglow import TensorTrain

        tt_ref = TensorTrain.random([6, 7, 8], ranks=[3, 3])
        dense = tt_ref.to_tensor()

        tt = tt_cross(dense, [6, 7, 8], max_rank=5, max_sweeps=20, seed=42)
        reconstructed = tt.to_tensor()

        rel_err = torch.norm(dense - reconstructed) / torch.norm(dense)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"

    def test_convergence_with_rank(self):
        """Higher max_rank should give better approximation."""
        torch.manual_seed(42)
        dense = torch.randn(5, 5, 5, dtype=torch.float64)

        errors = []
        for max_rank in [1, 2, 5]:
            tt = tt_cross(dense, [5, 5, 5], max_rank=max_rank, max_sweeps=15, seed=42)
            err = torch.norm(dense - tt.to_tensor()) / torch.norm(dense)
            errors.append(err.item())

        # Errors should be non-increasing (with some tolerance for stochastic effects)
        assert errors[-1] <= errors[0] + 0.05, (
            f"Higher rank should give better approximation: {errors}"
        )

    def test_shape_mismatch_raises(self):
        """Should raise when tensor shape doesn't match dims."""
        dense = torch.randn(4, 5, dtype=torch.float64)
        with pytest.raises(ValueError, match="doesn't match"):
            tt_cross(dense, [4, 6], max_rank=2)

    def test_too_few_dims_raises(self):
        """Should raise for d < 2."""
        with pytest.raises(ValueError, match="at least 2"):

            def f(points):
                return np.zeros(len(points))

            tt_cross(f, [5], max_rank=2)


class TestTTCrossCallable:
    def test_sum_function(self):
        """TT-Cross on f(i,j,k) = i + j + k should be exact at low rank."""
        dims = [6, 7, 8]

        def f(points):
            return points.sum(axis=1).astype(np.float64)

        tt = tt_cross(f, dims, max_rank=3, max_sweeps=15, seed=42)

        # Build reference dense tensor
        dense = torch.zeros(dims, dtype=torch.float64)
        for i in range(dims[0]):
            for j in range(dims[1]):
                for k in range(dims[2]):
                    dense[i, j, k] = i + j + k

        reconstructed = tt.to_tensor()
        rel_err = torch.norm(dense - reconstructed) / torch.norm(dense)
        assert rel_err < 0.05, f"Relative error too large: {rel_err:.4e}"

    def test_product_function(self):
        """TT-Cross on f(i,j,k) = (i+1)*(j+1)*(k+1) should be rank 1."""
        dims = [4, 5, 6]

        def f(points):
            return np.prod(points + 1, axis=1).astype(np.float64)

        tt = tt_cross(f, dims, max_rank=3, max_sweeps=10, seed=42)

        # Build reference
        dense = torch.zeros(dims, dtype=torch.float64)
        for i in range(dims[0]):
            for j in range(dims[1]):
                for k in range(dims[2]):
                    dense[i, j, k] = (i + 1) * (j + 1) * (k + 1)

        reconstructed = tt.to_tensor()
        rel_err = torch.norm(dense - reconstructed) / torch.norm(dense)
        assert rel_err < 0.05, f"Relative error too large: {rel_err:.4e}"


class TestTTCrossEdgeCases:
    def test_d_equals_2(self):
        """TT-Cross should work with d=2."""
        torch.manual_seed(42)
        dense = torch.randn(5, 6, dtype=torch.float64)

        tt = tt_cross(dense, [5, 6], max_rank=5, max_sweeps=10, seed=42)
        reconstructed = tt.to_tensor()

        rel_err = torch.norm(dense - reconstructed) / torch.norm(dense)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"

    def test_small_dims(self):
        """TT-Cross with very small dimensions."""
        torch.manual_seed(42)
        dense = torch.randn(2, 2, 2, dtype=torch.float64)

        tt = tt_cross(dense, [2, 2, 2], max_rank=4, max_sweeps=10, seed=42)
        reconstructed = tt.to_tensor()

        rel_err = torch.norm(dense - reconstructed) / torch.norm(dense)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"

    def test_rank_clamping(self):
        """Ranks should be clamped to min(max_rank, left_prod, right_prod)."""
        torch.manual_seed(42)
        dense = torch.randn(2, 3, 2, dtype=torch.float64)

        # max_rank=100 but actual ranks should be clamped by dimensions
        tt = tt_cross(dense, [2, 3, 2], max_rank=100, max_sweeps=10, seed=42)

        # Ranks should be clamped: r1 <= min(100, 2, 6)=2, r2 <= min(100, 6, 2)=2
        assert tt.ranks[1] <= 2
        assert tt.ranks[2] <= 2

    def test_output_is_tensor_train(self):
        """Result should be a proper TensorTrain."""
        from ttglow import TensorTrain

        torch.manual_seed(42)
        dense = torch.randn(4, 5, 6, dtype=torch.float64)
        tt = tt_cross(dense, [4, 5, 6], max_rank=3, seed=42)

        assert isinstance(tt, TensorTrain)
        assert tt.d == 3
        assert tt.dims == [4, 5, 6]
        assert tt.ranks[0] == 1
        assert tt.ranks[-1] == 1
