import pytest
import torch

from ttglow import TensorTrain
from ttglow.riemannian_complete import _batch_evaluate, rgrad_tt


def _all_indices(dims):
    """Return (prod(dims), N) tensor of all multi-indices."""
    grids = torch.meshgrid(*[torch.arange(d) for d in dims], indexing="ij")
    return torch.stack([g.reshape(-1) for g in grids], dim=1)


def _make_low_rank_tensor(dims, tt_ranks, seed=42):
    """Create a low-rank tensor via TensorTrain.random and return dense."""
    torch.manual_seed(seed)
    tt = TensorTrain.random(dims, tt_ranks, dtype=torch.float64)
    return tt.to_tensor()


def _sample_indices(dims, fraction, seed):
    """Sample a fraction of all multi-indices."""
    all_idx = _all_indices(dims)
    num_total = all_idx.shape[0]
    num_obs = int(fraction * num_total)
    rng = torch.Generator().manual_seed(seed)
    perm = torch.randperm(num_total, generator=rng)[:num_obs]
    return all_idx[perm]


class TestInputValidation:
    def test_non_2d_indices_raises(self):
        with pytest.raises(ValueError, match="indices must be 2D"):
            rgrad_tt(
                torch.tensor([0, 1, 2]),
                torch.tensor([1.0, 2.0, 3.0]),
                dims=[4, 5],
                ranks=[2],
            )

    def test_non_1d_values_raises(self):
        with pytest.raises(ValueError, match="values must be 1D"):
            rgrad_tt(
                torch.tensor([[0, 0], [1, 1]]),
                torch.tensor([[1.0], [2.0]]),
                dims=[4, 5],
                ranks=[2],
            )

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="must have the same number"):
            rgrad_tt(
                torch.tensor([[0, 0], [1, 1], [2, 2]]),
                torch.tensor([1.0, 2.0]),
                dims=[4, 5],
                ranks=[2],
            )

    def test_wrong_num_columns_raises(self):
        with pytest.raises(ValueError, match="columns but dims has"):
            rgrad_tt(
                torch.tensor([[0, 0, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
                ranks=[2],
            )

    def test_wrong_num_ranks_raises(self):
        with pytest.raises(ValueError, match="ranks has"):
            rgrad_tt(
                torch.tensor([[0, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
                ranks=[2, 3],
            )

    def test_index_out_of_bounds_raises(self):
        with pytest.raises(ValueError, match="out of bounds"):
            rgrad_tt(
                torch.tensor([[5, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
                ranks=[2],
            )


class TestBatchEvaluate:
    def test_matches_element_access(self):
        """Batch evaluate should match per-element access."""
        torch.manual_seed(42)
        dims = [4, 5, 6]
        tt = TensorTrain.random(dims, [3, 3], dtype=torch.float64)

        indices = torch.tensor([
            [0, 0, 0],
            [1, 2, 3],
            [3, 4, 5],
            [2, 1, 0],
        ])

        batch_vals = _batch_evaluate(tt, indices)

        for i in range(indices.shape[0]):
            idx = tuple(indices[i].tolist())
            expected = tt[idx]
            assert abs(batch_vals[i].item() - expected) < 1e-12, (
                f"Mismatch at index {idx}"
            )

    def test_all_entries(self):
        """Batch evaluate on all entries should match to_tensor."""
        torch.manual_seed(42)
        dims = [3, 4, 5]
        tt = TensorTrain.random(dims, [2, 2], dtype=torch.float64)

        indices = _all_indices(dims)
        batch_vals = _batch_evaluate(tt, indices)
        dense = tt.to_tensor()
        dense_vals = dense[tuple(indices[:, k] for k in range(len(dims)))]

        assert torch.allclose(batch_vals, dense_vals, atol=1e-12)


class TestFullObservation:
    def test_rank2_3d_full_observation(self):
        """All entries observed on a rank-2 TT tensor -> good recovery."""
        dims = [6, 7, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            max_iters=500, tol=1e-8, verbose=False,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.05, f"Relative error too large: {rel_err:.4e}"


class TestPartialObservation:
    def test_3d_50pct(self):
        """3D shape (8,10,12), TT-ranks [2,2], 50% observed."""
        dims = [8, 10, 12]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _sample_indices(dims, 0.5, seed=99)
        idx_tuple = tuple(indices[:, k] for k in range(len(dims)))
        values = tensor[idx_tuple]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            max_iters=500, tol=1e-8, verbose=False,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.2, f"Relative error too large: {rel_err:.4e}"

    def test_4d_50pct(self):
        """4D shape (5,6,4,8), TT-ranks [2,2,2], 50% observed."""
        dims = [5, 6, 4, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2, 2], seed=42)

        indices = _sample_indices(dims, 0.5, seed=99)
        idx_tuple = tuple(indices[:, k] for k in range(len(dims)))
        values = tensor[idx_tuple]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2, 2],
            max_iters=500, tol=1e-8, verbose=False,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.2, f"Relative error too large: {rel_err:.4e}"


class TestConvergence:
    def test_loss_decreases(self):
        """Loss should generally decrease over iterations."""
        dims = [6, 7, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        # Run a few iterations and check that loss decreases overall
        # (not necessarily monotonically due to step size)
        result_short = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            max_iters=20, tol=1e-12,
        )
        result_long = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            max_iters=200, tol=1e-12,
        )

        err_short = torch.norm(tensor - result_short.to_tensor()) / torch.norm(tensor)
        err_long = torch.norm(tensor - result_long.to_tensor()) / torch.norm(tensor)

        assert err_long < err_short + 0.01, (
            f"More iterations should help: err_short={err_short:.4e}, "
            f"err_long={err_long:.4e}"
        )


class TestCustomInit:
    def test_warm_start(self):
        """Providing a good initial guess should help convergence."""
        dims = [6, 7, 8]

        torch.manual_seed(42)
        tt_true = TensorTrain.random(dims, [2, 2], dtype=torch.float64)
        tensor = tt_true.to_tensor()

        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            init=tt_true, max_iters=50, tol=1e-10,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        # Starting from the true solution should keep error very small
        assert rel_err < 0.05, f"Warm start error too large: {rel_err:.4e}"


class TestALSMethod:
    def test_als_full_observation(self):
        """ALS should recover the tensor from full observations."""
        dims = [6, 7, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            method="als", max_iters=500, tol=1e-8,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.05, f"ALS rel error too large: {rel_err:.4e}"

    def test_als_partial_observation(self):
        """ALS on 4D with 50% observations."""
        dims = [5, 6, 4, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2, 2], seed=42)

        indices = _sample_indices(dims, 0.5, seed=99)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2, 2],
            method="als", max_iters=500, tol=1e-8,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.2, f"ALS rel error too large: {rel_err:.4e}"

    def test_invalid_method_raises(self):
        """Unknown method name should raise ValueError."""
        with pytest.raises(ValueError, match="method must be"):
            rgrad_tt(
                torch.tensor([[0, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
                ranks=[2],
                method="bogus",
            )


class TestOutputProperties:
    def test_output_is_tensor_train(self):
        """Output should be a TensorTrain with correct dims."""
        dims = [4, 5, 6]
        indices = torch.tensor([[0, 0, 0], [1, 1, 1], [2, 2, 2]])
        values = torch.tensor([1.0, 2.0, 3.0])

        result = rgrad_tt(indices, values, dims, ranks=[2, 2], max_iters=10)
        assert isinstance(result, TensorTrain)
        assert result.dims == dims

    def test_output_dtype(self):
        """Output cores should have the requested dtype."""
        dims = [4, 5, 6]
        indices = torch.tensor([[0, 0, 0], [1, 1, 1]])
        values = torch.tensor([1.0, 2.0])

        result = rgrad_tt(
            indices, values, dims, ranks=[2, 2],
            max_iters=10, dtype=torch.float64,
        )
        for core in result.cores:
            assert core.dtype == torch.float64

    def test_output_ranks_bounded(self):
        """Output ranks should not exceed the requested max rank."""
        dims = [4, 5, 6]
        target_ranks = [3, 3]
        indices = _all_indices(dims)
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = rgrad_tt(
            indices, values, dims, ranks=target_ranks, max_iters=50,
        )
        # Internal ranks (excluding boundaries) should be <= max(target_ranks)
        for k in range(1, result.d):
            assert result.ranks[k] <= max(target_ranks) + 1, (
                f"Rank at bond {k} is {result.ranks[k]}, "
                f"expected <= {max(target_ranks)}"
            )
