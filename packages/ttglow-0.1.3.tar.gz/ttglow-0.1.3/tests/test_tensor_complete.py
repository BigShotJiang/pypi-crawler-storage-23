import pytest
import torch

from ttglow.tensor_complete import silrtc_tt


def _all_indices(dims):
    """Return (prod(dims), N) tensor of all multi-indices."""
    grids = torch.meshgrid(*[torch.arange(d) for d in dims], indexing="ij")
    return torch.stack([g.reshape(-1) for g in grids], dim=1)


def _make_low_rank_tensor(dims, tt_ranks, seed=42):
    """Create a low-rank tensor via TensorTrain.random and return dense."""
    from ttglow import TensorTrain

    torch.manual_seed(seed)
    tt = TensorTrain.random(dims, tt_ranks, dtype=torch.float64)
    return tt.to_tensor()


def _sample_indices(dims, fraction, seed):
    """Sample a fraction of all multi-indices."""
    all_idx = _all_indices(dims)
    num_total = all_idx.shape[0]
    num_obs = int(fraction * num_total)
    rng = torch.Generator().manual_seed(seed)
    perm = torch.randperm(num_total, generator=rng)[:num_obs]
    return all_idx[perm]


class TestInputValidation:
    def test_non_2d_indices_raises(self):
        with pytest.raises(ValueError, match="indices must be 2D"):
            silrtc_tt(
                torch.tensor([0, 1, 2]),
                torch.tensor([1.0, 2.0, 3.0]),
                dims=[4, 5],
            )

    def test_non_1d_values_raises(self):
        with pytest.raises(ValueError, match="values must be 1D"):
            silrtc_tt(
                torch.tensor([[0, 0], [1, 1]]),
                torch.tensor([[1.0], [2.0]]),
                dims=[4, 5],
            )

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="must have the same number"):
            silrtc_tt(
                torch.tensor([[0, 0], [1, 1], [2, 2]]),
                torch.tensor([1.0, 2.0]),
                dims=[4, 5],
            )

    def test_wrong_num_columns_raises(self):
        with pytest.raises(ValueError, match="columns but dims has"):
            silrtc_tt(
                torch.tensor([[0, 0, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
            )

    def test_index_out_of_bounds_raises(self):
        with pytest.raises(ValueError, match="out of bounds"):
            silrtc_tt(
                torch.tensor([[5, 0]]),
                torch.tensor([1.0]),
                dims=[4, 5],
            )


class TestFullObservation:
    def test_rank2_3d_full_observation(self):
        """All entries observed on a rank-2 TT tensor -> near-exact recovery."""
        dims = [6, 7, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        result = silrtc_tt(indices, values, dims, max_iters=200, tol=1e-8)
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 1e-4, f"Relative error too large: {rel_err:.4e}"


class TestPartialObservation:
    def test_matrix_80pct(self):
        """2D rank-2 matrix, 80% observed.

        Note: with N=2 there is only one unfolding, so SiLRTC-TT reduces to
        standard SVT (iterative soft-thresholding) which has a nuclear-norm
        bias.  Higher observation rates or larger matrices are needed for
        good 2D recovery.
        """
        dims = [20, 15]
        tensor = _make_low_rank_tensor(dims, [2], seed=42)

        rng = torch.Generator().manual_seed(123)
        num_total = 20 * 15
        num_obs = int(0.8 * num_total)
        flat_idx = torch.randperm(num_total, generator=rng)[:num_obs]
        row = flat_idx // 15
        col = flat_idx % 15
        indices = torch.stack([row, col], dim=1)
        values = tensor[row, col]

        result = silrtc_tt(indices, values, dims, max_iters=500, tol=1e-6)
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"

    def test_3d_50pct(self):
        """3D shape (8,10,12), TT-ranks [2,2], 50% observed -> rel_err < 0.1."""
        dims = [8, 10, 12]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)

        indices = _sample_indices(dims, 0.5, seed=99)
        idx_tuple = tuple(indices[:, k] for k in range(len(dims)))
        values = tensor[idx_tuple]

        result = silrtc_tt(indices, values, dims, max_iters=500, tol=1e-6)
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"

    def test_rank1_50pct(self):
        """Rank-1 tensor from 50% observations."""
        dims = [8, 10, 12]
        tensor = _make_low_rank_tensor(dims, [1, 1], seed=42)

        indices = _sample_indices(dims, 0.5, seed=77)
        idx_tuple = tuple(indices[:, k] for k in range(len(dims)))
        values = tensor[idx_tuple]

        result = silrtc_tt(indices, values, dims, max_iters=1000, tol=1e-6)
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"


class TestConvergence:
    def test_more_observations_gives_lower_error(self):
        """More observations should give better reconstruction."""
        dims = [8, 10, 12]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)
        all_idx = _all_indices(dims)
        num_total = all_idx.shape[0]

        fractions = [0.3, 0.6, 1.0]
        errors = []
        for frac in fractions:
            rng = torch.Generator().manual_seed(55)
            num_obs = int(frac * num_total)
            perm = torch.randperm(num_total, generator=rng)[:num_obs]
            indices = all_idx[perm]
            idx_tuple = tuple(indices[:, k] for k in range(len(dims)))
            values = tensor[idx_tuple]

            result = silrtc_tt(indices, values, dims, max_iters=300, tol=1e-6)
            completed = result.to_tensor()
            err = (torch.norm(tensor - completed) / torch.norm(tensor)).item()
            errors.append(err)

        assert errors[2] < errors[0] + 0.01, (
            f"Expected improvement: errors={errors}"
        )


class TestCustomWeights:
    def test_user_provided_alpha_beta(self):
        """Custom alpha/beta should work without error."""
        dims = [6, 7, 8]
        tensor = _make_low_rank_tensor(dims, [2, 2], seed=42)
        indices = _all_indices(dims)
        values = tensor[tuple(indices[:, k] for k in range(len(dims)))]

        alpha = [0.5, 0.5]
        beta = [0.01, 0.01]
        result = silrtc_tt(
            indices, values, dims,
            alpha=alpha, beta=beta, max_iters=100, tol=1e-6,
        )
        completed = result.to_tensor()

        rel_err = torch.norm(tensor - completed) / torch.norm(tensor)
        assert rel_err < 0.1, f"Relative error too large: {rel_err:.4e}"


class TestOutputProperties:
    def test_output_is_tensor_train(self):
        """Output should be a TensorTrain with correct dims."""
        from ttglow import TensorTrain

        dims = [4, 5, 6]
        indices = torch.tensor([[0, 0, 0], [1, 1, 1], [2, 2, 2]])
        values = torch.tensor([1.0, 2.0, 3.0])

        result = silrtc_tt(indices, values, dims, max_iters=10)
        assert isinstance(result, TensorTrain)
        assert result.dims == dims

    def test_output_dtype(self):
        """Output cores should have the requested dtype."""
        dims = [4, 5, 6]
        indices = torch.tensor([[0, 0, 0], [1, 1, 1]])
        values = torch.tensor([1.0, 2.0])

        result = silrtc_tt(indices, values, dims, max_iters=10, dtype=torch.float64)
        for core in result.cores:
            assert core.dtype == torch.float64
