"""Tests for weighted approximate joint diagonalization (AJD) algorithm.

The weighted AJD problem is: given matrices {τ^α}, find unitary U maximizing
    f(U) = Σ_α ||U τ^α U^T||_D^2
where D = P_k + P_{k+1} is the weight matrix.
"""

import torch
import pytest
from ttglow.diag import (
    build_weight_matrix,
    weighted_norm_squared,
    weighted_ajd,
    weighted_ajd_lbfgs,
    euclidean_gradient_at_identity,
)

# Use float64 for numerical stability in tests
DTYPE = torch.float64


class TestWeightMatrix:
    """Tests for weight matrix D = P_k + P_{k+1}."""

    def test_weight_matrix_2x2(self):
        """Test weight matrix for n_k = n_{k+1} = 2 (4x4 fused space)."""
        torch.manual_seed(42)
        D = build_weight_matrix(n_k=2, n_kp1=2, dtype=DTYPE)

        # D should be 4x4
        assert D.shape == (4, 4)

        # Diagonal elements (i_k = j_k AND i_{k+1} = j_{k+1}) have weight 2
        # Off-diagonal in one mode has weight 1
        # Off-diagonal in both modes has weight 0

        # Index mapping for (i_k, i_{k+1}): (0,0)->0, (0,1)->1, (1,0)->2, (1,1)->3
        # Element (0,0) vs (0,0): both match -> weight 2
        assert D[0, 0] == 2
        # Element (0,0) vs (0,1): k matches, k+1 differs -> weight 1
        assert D[0, 1] == 1
        # Element (0,0) vs (1,0): k differs, k+1 matches -> weight 1
        assert D[0, 2] == 1
        # Element (0,0) vs (1,1): both differ -> weight 0
        assert D[0, 3] == 0

    def test_weight_matrix_symmetry(self):
        """Weight matrix should be symmetric."""
        D = build_weight_matrix(n_k=3, n_kp1=2, dtype=DTYPE)
        assert torch.allclose(D, D.T)

    def test_weight_matrix_values(self):
        """Weight matrix should only contain 0, 1, 2."""
        D = build_weight_matrix(n_k=4, n_kp1=3, dtype=DTYPE)
        unique_values = torch.unique(D)
        assert set(unique_values.tolist()) == {0.0, 1.0, 2.0}


class TestWeightedNorm:
    """Tests for the D-weighted norm."""

    def test_weighted_norm_diagonal_matrix(self):
        """Diagonal matrix should have maximum weighted norm."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        # Diagonal matrix
        tau_diag = torch.diag(torch.randn(n, dtype=DTYPE))
        norm_diag = weighted_norm_squared(tau_diag, D)

        # Compare to off-diagonal matrix with same Frobenius norm
        tau_offdiag = torch.zeros(n, n, dtype=DTYPE)
        tau_offdiag[0, 3] = torch.norm(tau_diag)  # Put all mass in (0,3) which has D=0
        norm_offdiag = weighted_norm_squared(tau_offdiag, D)

        # Diagonal should have higher weighted norm
        assert norm_diag > norm_offdiag
        # Off-diagonal in both modes should have zero weighted norm
        assert torch.isclose(norm_offdiag, torch.tensor(0.0, dtype=DTYPE))

    def test_weighted_norm_formula(self):
        """Test weighted norm formula: ||τ||_D^2 = <D, τ ⊙ τ>."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 3
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)
        tau = torch.randn(n_k * n_kp1, n_k * n_kp1, dtype=DTYPE)

        computed = weighted_norm_squared(tau, D)
        expected = torch.sum(D * tau * tau)

        assert torch.allclose(computed, expected)


class TestEuclideanGradient:
    """Tests for the Euclidean gradient at identity."""

    def test_gradient_formula(self):
        """Test gradient: G = 2[(D ⊙ τ)τ^T + (D ⊙ τ^T)τ]."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)
        tau = torch.randn(n_k * n_kp1, n_k * n_kp1, dtype=DTYPE)

        G = euclidean_gradient_at_identity([tau], D)

        # Manual computation
        expected = 2 * ((D * tau) @ tau.T + (D * tau.T) @ tau)

        assert torch.allclose(G, expected)

    def test_gradient_sum_over_alpha(self):
        """Test gradient sums over all τ^α matrices."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)
        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        G = euclidean_gradient_at_identity(taus, D)

        # Manual computation
        expected = torch.zeros(4, 4, dtype=DTYPE)
        for tau in taus:
            expected += 2 * ((D * tau) @ tau.T + (D * tau.T) @ tau)

        assert torch.allclose(G, expected)

    def test_gradient_symmetric_tau(self):
        """For symmetric τ, gradient simplifies to 4(D ⊙ τ)τ."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)
        tau = torch.randn(4, 4, dtype=DTYPE)
        tau = tau + tau.T  # Make symmetric

        G = euclidean_gradient_at_identity([tau], D)

        # For symmetric τ: G = 4(D ⊙ τ)τ
        expected = 4 * (D * tau) @ tau

        assert torch.allclose(G, expected)


class TestWeightedAJD:
    """Tests for the full weighted AJD algorithm."""

    def test_identity_is_fixed_point_for_diagonal(self):
        """If all τ^α are already D-diagonal, U=I should be optimal."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        # Create diagonal matrices
        taus = [torch.diag(torch.randn(4, dtype=DTYPE)) for _ in range(3)]

        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=10)

        # U should be close to identity (or any rotation that preserves diagonality)
        # Check that objective didn't change
        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        assert torch.isclose(obj_before, obj_after, rtol=1e-5)

    def test_ajd_improves_objective(self):
        """AJD should not decrease the weighted norm objective."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        # Random matrices
        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)

        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=100)

        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        # Objective should increase (we're maximizing)
        assert obj_after >= obj_before - 1e-10

    def test_ajd_unitary_output(self):
        """Output U should be unitary."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]
        U, _ = weighted_ajd(taus, n_k, n_kp1, max_iters=50)

        # Check U @ U^T = I
        assert torch.allclose(U @ U.T, torch.eye(4, dtype=DTYPE), atol=1e-6)
        # Check U^T @ U = I
        assert torch.allclose(U.T @ U, torch.eye(4, dtype=DTYPE), atol=1e-6)

    def test_ajd_transforms_correctly(self):
        """Check τ^α_transformed = U τ^α U^T."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]
        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=50)

        for tau_orig, tau_trans in zip(taus, taus_transformed):
            expected = U @ tau_orig @ U.T
            assert torch.allclose(tau_trans, expected, atol=1e-6)

    def test_ajd_jointly_diagonalizable(self):
        """If matrices are exactly jointly diagonalizable, find the solution."""
        torch.manual_seed(42)
        n = 4

        # Create jointly diagonalizable matrices: τ^α = V D^α V^T
        V = torch.linalg.qr(torch.randn(n, n, dtype=DTYPE))[0]  # Random orthogonal matrix
        diags = [torch.randn(n, dtype=DTYPE) for _ in range(3)]
        taus = [V @ torch.diag(d) @ V.T for d in diags]

        # Weight matrix for 2x2 fused space
        D = build_weight_matrix(2, 2, dtype=DTYPE)

        U, taus_transformed = weighted_ajd(taus, 2, 2, max_iters=200, tol=1e-8)

        # After transformation, matrices should be (nearly) diagonal
        for tau_t in taus_transformed:
            # Off-diagonal elements should be small (machine precision for float64)
            offdiag_norm = torch.norm(tau_t - torch.diag(torch.diag(tau_t)))
            assert offdiag_norm < 1e-6, f"Off-diagonal norm: {offdiag_norm}"


class TestWeightedAJDLarger:
    """Tests on larger systems."""

    def test_ajd_3x3_system(self):
        """Test AJD on 3x3 fused space (9x9 matrices)."""
        torch.manual_seed(42)
        n_k, n_kp1 = 3, 3
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(n, n, dtype=DTYPE) for _ in range(5)]

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=100)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        # Objective should improve
        assert obj_after >= obj_before - 1e-10
        # U should be unitary
        assert torch.allclose(U @ U.T, torch.eye(n, dtype=DTYPE), atol=1e-5)

    def test_ajd_asymmetric_modes(self):
        """Test AJD with different mode dimensions n_k ≠ n_{k+1}."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 3
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(n, n, dtype=DTYPE) for _ in range(4)]

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=100)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        assert obj_after >= obj_before - 1e-10
        assert torch.allclose(U @ U.T, torch.eye(n, dtype=DTYPE), atol=1e-5)


class TestWeightedAJDSymmetric:
    """Tests specifically for symmetric matrices (common in physics)."""

    def test_ajd_symmetric_matrices(self):
        """Test AJD when all τ^α are symmetric."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        # Create symmetric matrices
        taus = []
        for _ in range(3):
            A = torch.randn(n, n, dtype=DTYPE)
            taus.append(A + A.T)

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        U, taus_transformed = weighted_ajd(taus, n_k, n_kp1, max_iters=100)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        assert obj_after >= obj_before - 1e-10

        # Transformed matrices should still be symmetric
        for tau_t in taus_transformed:
            assert torch.allclose(tau_t, tau_t.T, atol=1e-6)


class TestConvergence:
    """Tests for convergence behavior."""

    def test_convergence_tolerance(self):
        """Algorithm should stop when gradient norm is below tolerance."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        # Run with tight tolerance
        U1, _, info1 = weighted_ajd(
            taus, n_k, n_kp1, max_iters=1000, tol=1e-10, return_info=True
        )

        # Run with loose tolerance
        U2, _, info2 = weighted_ajd(
            taus, n_k, n_kp1, max_iters=1000, tol=1e-3, return_info=True
        )

        # Loose tolerance should converge in fewer iterations
        assert info2["iterations"] <= info1["iterations"]

    def test_max_iterations_respected(self):
        """Algorithm should stop at max_iters."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        _, _, info = weighted_ajd(
            taus, n_k, n_kp1, max_iters=5, tol=1e-15, return_info=True
        )

        assert info["iterations"] <= 5


class TestWeightedAJDLBFGS:
    """Tests for the Riemannian L-BFGS version of weighted AJD."""

    def test_lbfgs_improves_objective(self):
        """L-BFGS should not decrease the weighted norm objective."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)

        U, taus_transformed = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=100)

        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        # Objective should increase (we're maximizing)
        assert obj_after >= obj_before - 1e-10

    def test_lbfgs_unitary_output(self):
        """Output U should be unitary."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]
        U, _ = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=50)

        # Check U @ U^T = I
        assert torch.allclose(U @ U.T, torch.eye(4, dtype=DTYPE), atol=1e-6)
        # Check U^T @ U = I
        assert torch.allclose(U.T @ U, torch.eye(4, dtype=DTYPE), atol=1e-6)

    def test_lbfgs_transforms_correctly(self):
        """Check τ^α_transformed = U τ^α U^T."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]
        U, taus_transformed = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=50)

        for tau_orig, tau_trans in zip(taus, taus_transformed):
            expected = U @ tau_orig @ U.T
            assert torch.allclose(tau_trans, expected, atol=1e-6)

    def test_lbfgs_jointly_diagonalizable(self):
        """If matrices are exactly jointly diagonalizable, find the solution."""
        torch.manual_seed(42)
        n = 4

        # Create jointly diagonalizable matrices: τ^α = V D^α V^T
        V = torch.linalg.qr(torch.randn(n, n, dtype=DTYPE))[0]
        diags = [torch.randn(n, dtype=DTYPE) for _ in range(3)]
        taus = [V @ torch.diag(d) @ V.T for d in diags]

        U, taus_transformed = weighted_ajd_lbfgs(taus, 2, 2, max_iters=200, tol=1e-8)

        # After transformation, matrices should be (nearly) diagonal
        for tau_t in taus_transformed:
            offdiag_norm = torch.norm(tau_t - torch.diag(torch.diag(tau_t)))
            assert offdiag_norm < 1e-6, f"Off-diagonal norm: {offdiag_norm}"

    def test_lbfgs_3x3_system(self):
        """Test L-BFGS on 3x3 fused space (9x9 matrices)."""
        torch.manual_seed(42)
        n_k, n_kp1 = 3, 3
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(n, n, dtype=DTYPE) for _ in range(5)]

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        U, taus_transformed = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=100)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        # Objective should improve
        assert obj_after >= obj_before - 1e-10
        # U should be unitary
        assert torch.allclose(U @ U.T, torch.eye(n, dtype=DTYPE), atol=1e-5)

    def test_lbfgs_symmetric_matrices(self):
        """Test L-BFGS when all τ^α are symmetric."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        n = n_k * n_kp1
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        # Create symmetric matrices
        taus = []
        for _ in range(3):
            A = torch.randn(n, n, dtype=DTYPE)
            taus.append(A + A.T)

        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        U, taus_transformed = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=100)
        obj_after = sum(weighted_norm_squared(tau_t, D) for tau_t in taus_transformed)

        assert obj_after >= obj_before - 1e-10

        # Transformed matrices should still be symmetric
        for tau_t in taus_transformed:
            assert torch.allclose(tau_t, tau_t.T, atol=1e-6)

    def test_lbfgs_convergence_info(self):
        """Test that L-BFGS returns proper convergence info."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        U, _, info = weighted_ajd_lbfgs(
            taus, n_k, n_kp1, max_iters=50, return_info=True
        )

        # Check info dict has expected fields
        assert "iterations" in info
        assert "grad_norms" in info
        assert "objectives" in info
        assert "step_sizes" in info
        assert "final_objective" in info

        # Gradient norms should generally decrease
        assert len(info["grad_norms"]) > 0
        # Objectives should generally increase (maximization)
        assert len(info["objectives"]) > 0

    def test_lbfgs_memory_size(self):
        """Test L-BFGS with different memory sizes."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        # Small memory
        _, taus_small, _ = weighted_ajd_lbfgs(
            taus, n_k, n_kp1, max_iters=50, memory_size=2, return_info=True
        )
        obj_small = sum(weighted_norm_squared(tau, D) for tau in taus_small)

        # Large memory
        _, taus_large, _ = weighted_ajd_lbfgs(
            taus, n_k, n_kp1, max_iters=50, memory_size=20, return_info=True
        )
        obj_large = sum(weighted_norm_squared(tau, D) for tau in taus_large)

        # Both should improve the objective
        obj_before = sum(weighted_norm_squared(tau, D) for tau in taus)
        assert obj_small >= obj_before - 1e-10
        assert obj_large >= obj_before - 1e-10


class TestLBFGSvsGradientDescent:
    """Compare L-BFGS to gradient descent."""

    def test_lbfgs_converges_faster(self):
        """L-BFGS should typically converge in fewer iterations."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        # Run both methods with same tolerance
        _, _, info_gd = weighted_ajd(
            taus, n_k, n_kp1, max_iters=200, tol=1e-6, return_info=True
        )
        _, _, info_lbfgs = weighted_ajd_lbfgs(
            taus, n_k, n_kp1, max_iters=200, tol=1e-6, return_info=True
        )

        # L-BFGS should converge in fewer or equal iterations
        # (not strictly guaranteed, but typical)
        assert info_lbfgs["iterations"] <= info_gd["iterations"] + 10

    def test_both_reach_similar_objective(self):
        """Both methods should reach similar final objectives."""
        torch.manual_seed(42)
        n_k, n_kp1 = 2, 2
        D = build_weight_matrix(n_k, n_kp1, dtype=DTYPE)

        taus = [torch.randn(4, 4, dtype=DTYPE) for _ in range(3)]

        _, taus_gd = weighted_ajd(taus, n_k, n_kp1, max_iters=200, tol=1e-8)
        _, taus_lbfgs = weighted_ajd_lbfgs(taus, n_k, n_kp1, max_iters=200, tol=1e-8)

        obj_gd = sum(weighted_norm_squared(tau, D) for tau in taus_gd)
        obj_lbfgs = sum(weighted_norm_squared(tau, D) for tau in taus_lbfgs)

        # Both should reach similar objectives (within 1%)
        assert abs(obj_gd - obj_lbfgs) / max(obj_gd, obj_lbfgs) < 0.01
