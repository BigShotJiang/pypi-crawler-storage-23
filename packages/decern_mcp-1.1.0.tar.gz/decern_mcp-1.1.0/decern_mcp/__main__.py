"""Allow running as `python -m decern_mcp`."""
from decern_mcp import main

main()
