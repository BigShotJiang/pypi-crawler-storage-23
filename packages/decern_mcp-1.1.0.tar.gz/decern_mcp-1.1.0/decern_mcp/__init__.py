"""
Decern MCP Server
=================
A Model Context Protocol server that connects AI agents to DecernHQ CRM.

Supports contacts, accounts, deals, pipelines, tasks, activity logging,
data triage, and human-in-the-loop approval workflows for high-value operations.
"""

import os
import json
import httpx
from mcp.server.fastmcp import FastMCP

__version__ = "1.1.0"

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DECERN_API_URL = os.environ.get("DECERN_API_URL", "https://decernhq.com/api")
DECERN_API_KEY = os.environ.get("DECERN_API_KEY", "")

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _headers():
    return {
        "Authorization": f"Api-Key {DECERN_API_KEY}",
        "Content-Type": "application/json",
    }


def _get(path: str, params: dict | None = None) -> dict | list:
    with httpx.Client(timeout=30) as client:
        r = client.get(f"{DECERN_API_URL}{path}", headers=_headers(), params=params)
        r.raise_for_status()
        return r.json()


def _post(path: str, data: dict | None = None) -> dict:
    with httpx.Client(timeout=30) as client:
        r = client.post(f"{DECERN_API_URL}{path}", headers=_headers(), json=data or {})
        r.raise_for_status()
        return r.json()


def _patch(path: str, data: dict | None = None) -> dict:
    with httpx.Client(timeout=30) as client:
        r = client.patch(f"{DECERN_API_URL}{path}", headers=_headers(), json=data or {})
        r.raise_for_status()
        return r.json()


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "Decern",
    instructions="""You are connected to the Decern CRM — a unified platform
covering Sales, Marketing, Service, Content, and Operations. Use these tools
to read CRM data, manage contacts, accounts, deals, and tasks, and log activities.

IMPORTANT SAFEGUARDS:
- High-value deals (>=$10,000) require human approval before stage changes.
- All state mutations are recorded in the audit trail.
- Use search_contacts before creating duplicates.
- Use search_accounts before creating duplicate accounts.
""",
)


# ===================================================================
# TOOLS — Read
# ===================================================================


@mcp.tool()
def search_contacts(query: str) -> str:
    """Search contacts by name, email, or role. Returns up to 20 matches.

    Args:
        query: Search term to match against name, email, or role
    """
    results = _get("/contacts/", params={"search": query})
    if isinstance(results, list):
        return json.dumps(results[:20], indent=2)
    return json.dumps(results, indent=2)


@mcp.tool()
def get_contact(contact_id: int) -> str:
    """Get full details for a specific contact by ID, including health score and intent signals.

    Args:
        contact_id: The contact's integer ID
    """
    try:
        result = _get(f"/contacts/{contact_id}/")
        return json.dumps(result, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"error": f"Contact {contact_id} not found. Use search_contacts to find valid IDs."})
        raise


@mcp.tool()
def get_deal(deal_id: int) -> str:
    """Get full details for a specific deal by ID, including stage, value, and tasks.

    Args:
        deal_id: The deal's integer ID
    """
    try:
        result = _get(f"/deals/{deal_id}/")
        return json.dumps(result, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"error": f"Deal {deal_id} not found. Use get_pipeline to list all deals."})
        raise


@mcp.tool()
def get_pipeline() -> str:
    """Get all deals in the sales pipeline with stage, value, and approval status."""
    results = _get("/deals/")
    return json.dumps(results, indent=2)


@mcp.tool()
def search_accounts(query: str) -> str:
    """Search accounts (companies) by name. Returns matching accounts.

    Args:
        query: Search term to match against account name
    """
    results = _get("/accounts/", params={"search": query})
    if isinstance(results, list):
        return json.dumps(results[:20], indent=2)
    return json.dumps(results, indent=2)


@mcp.tool()
def get_account(account_id: int) -> str:
    """Get full details for a specific account, including contacts, deals, and AI insights.

    Args:
        account_id: The account's integer ID
    """
    try:
        result = _get(f"/accounts/{account_id}/")
        return json.dumps(result, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"error": f"Account {account_id} not found. Use search_accounts to find valid IDs."})
        raise


@mcp.tool()
def get_approval_status(approval_id: int) -> str:
    """Check whether a pending approval has been granted or rejected.

    Args:
        approval_id: The approval request ID to check
    """
    try:
        result = _get(f"/approval-requests/{approval_id}/")
        return json.dumps(result, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"error": f"Approval {approval_id} not found."})
        raise


@mcp.tool()
def get_data_health() -> str:
    """Get current data integrity metrics and triage pipeline statistics from the AI Data Janitor."""
    results = _get("/operations/triage/stats/")
    return json.dumps(results, indent=2)


# ===================================================================
# TOOLS — Write
# ===================================================================


@mcp.tool()
def create_contact(name: str, email: str = "", role: str = "", account_id: int = 0) -> str:
    """Create a new contact in the CRM. Use search_contacts first to avoid duplicates.

    Args:
        name: Full name of the contact (required)
        email: Email address
        role: Job title or role (e.g. 'VP of Sales')
        account_id: Associated account/company ID (0 for none)
    """
    data = {"name": name}
    if email:
        data["email"] = email
    if role:
        data["role"] = role
    if account_id:
        data["account_id"] = account_id
    result = _post("/contacts/", data)
    return json.dumps({"status": "created", "contact": result}, indent=2)


@mcp.tool()
def create_deal(description: str, total_value: float = 0, contact_id: int = 0, account_id: int = 0) -> str:
    """Create a new deal in the sales pipeline.

    Args:
        description: Deal title / description (required)
        total_value: Deal value in dollars
        contact_id: Associated contact ID (0 for none)
        account_id: Associated account/company ID (0 for none)
    """
    data = {"description": description, "total_value": total_value or 0}
    if contact_id:
        data["contact_id"] = contact_id
    if account_id:
        data["account_id"] = account_id
    result = _post("/deals/", data)
    return json.dumps({"status": "created", "deal": result}, indent=2)


@mcp.tool()
def update_deal_stage(deal_id: int, stage_name: str) -> str:
    """Move a deal to a different pipeline stage.

    SAFEGUARD: Deals worth >= $10,000 will require human approval.
    When approval is required, this tool returns a PENDING_APPROVAL status
    with an approval_id. Use get_approval_status to poll for the decision.

    Args:
        deal_id: The deal ID to update
        stage_name: Name of the target stage (e.g. 'Qualified', 'Proposal', 'Closed Won')
    """
    # Get available stages (correct route: /sales/stages/)
    stages = _get("/sales/stages/")
    target = next((s for s in stages if s["name"].lower() == stage_name.lower()), None)
    if not target:
        available = [s["name"] for s in stages]
        return json.dumps({"error": f"Stage '{stage_name}' not found. Available: {available}"})

    # Get current deal to check value for safeguard
    try:
        deal = _get(f"/deals/{deal_id}/")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"error": f"Deal {deal_id} not found."})
        raise

    # SAFEGUARD: High-value deals require approval
    deal_value = deal.get("total_value", 0) or 0
    if deal_value >= 10000:
        # Create an approval request instead of directly updating
        try:
            approval = _post("/approval-requests/", {
                "subject_type": "deal",
                "subject_id": deal_id,
                "approver_ids": [1],  # Default to first approver
            })
            return json.dumps({
                "status": "PENDING_APPROVAL",
                "approval_id": approval.get("id"),
                "message": f"Deal #{deal_id} is worth ${deal_value:,.0f}. "
                           f"Stage change to '{stage_name}' requires human approval. "
                           f"Use get_approval_status(approval_id={approval.get('id')}) to check.",
            }, indent=2)
        except httpx.HTTPStatusError:
            return json.dumps({
                "status": "PENDING_APPROVAL",
                "message": f"Deal #{deal_id} is worth ${deal_value:,.0f}. "
                           f"Stage change to '{stage_name}' requires human approval in the Decern UI.",
            }, indent=2)

    # Direct update for lower-value deals
    result = _patch(f"/deals/{deal_id}/", {"stage_id": target["id"]})
    return json.dumps({"status": "updated", "deal": result}, indent=2)


@mcp.tool()
def create_task(title: str, top_level: str = "sales") -> str:
    """Create a task in the Operations module.

    Args:
        title: Task description (required)
        top_level: Module context — one of: executive, sales, marketing, service, content, operations
    """
    valid = ["executive", "sales", "marketing", "service", "content", "operations"]
    if top_level not in valid:
        return json.dumps({"error": f"Invalid top_level '{top_level}'. Must be one of: {valid}"})
    data = {"description": title, "top_level": top_level}
    result = _post("/tasks/", data)
    return json.dumps({"status": "created", "task": result}, indent=2)


@mcp.tool()
def log_activity(
    object_type: str,
    object_id: int,
    activity_type: str,
    notes: str = "",
) -> str:
    """Log an interaction or activity on any CRM object.

    Args:
        object_type: The object type (contact, deal, account, task)
        object_id: The object's ID
        activity_type: Type of activity — one of: call, email, meeting, note
        notes: Free-text notes about the activity
    """
    data = {
        "object_type": object_type,
        "object_id": object_id,
        "actor": "mcp:agent",
        "activity_type": activity_type,
        "body": notes,
    }
    # Correct route: /sales/activities/
    result = _post("/sales/activities/", data)
    return json.dumps({"status": "logged", "activity": result}, indent=2)


@mcp.tool()
def submit_data_with_triage(raw_data: str) -> str:
    """Ingest raw lead data into the CRM through the AI Data Janitor triage layer.
    The Data Janitor will standardize UTMs, deduplicate, and clean the record.

    Args:
        raw_data: JSON string of the record data (e.g. '{"name":"Jane Doe","email":"jane@co.io","utm_source":"linkedin"}')
    """
    try:
        data_dict = json.loads(raw_data)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON in raw_data. Must be a valid JSON string."})

    result = _post("/operations/triage/ingest/", {"data": data_dict, "target_model": "Contact"})
    return json.dumps({
        "status": "QUEUED_FOR_TRIAGE",
        "triage_id": result.get("id"),
        "message": "Data ingested. The AI Data Janitor is now processing this record.",
    }, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    """CLI entry point for the Decern MCP server."""
    if not DECERN_API_KEY:
        import sys
        print("Error: DECERN_API_KEY environment variable is required.", file=sys.stderr)
        print("Generate one from your Decern Workspace Settings → API Keys.", file=sys.stderr)
        sys.exit(1)
    mcp.run()


if __name__ == "__main__":
    main()
