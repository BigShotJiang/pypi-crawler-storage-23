# bitbucket - list_files

**Toolkit**: `bitbucket`
**Method**: `list_files`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def list_files(self, path: str = None, recursive: bool = True, branch: str = None) -> List[str]:
        """List files in the repository with optional path, recursive search, and branch."""
        branch = branch if branch else self._active_branch
        try:
            files_str = self._get_files(path, branch, recursive)
            # Parse the string response to extract file paths
            # This is a simplified implementation - might need adjustment based on actual response format
            import ast
            try:
                files_list = ast.literal_eval(files_str)
                if isinstance(files_list, list):
                    return files_list
                else:
                    return [str(files_list)]
            except:
                return [files_str] if files_str else []
        except Exception as e:
            return f"Failed to list files: {str(e)}"
```
