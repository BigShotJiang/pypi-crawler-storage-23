# azure_ai - get_available_tools

**Toolkit**: `azure_ai`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        """
        Get the available tools for the Azure Search API.

        :return: A list of available tools.
        """
        return [
            {
                "name": "text_search",
                "ref": self.text_search,
                "description": self.text_search.__doc__,
                "args_schema": TextSearchInput,
            },
            # {
            #     "name": "vector_search",
            #     "ref": self.vector_search,
            #     "description": self.vector_search.__doc__,
            #     "args_schema": VectorSearchInput,
            # },
            # {
            #     "name": "hybrid_search",
            #     "ref": self.hybrid_search,
            #     "description": self.hybrid_search.__doc__,
            #     "args_schema": HybridSearchInput,
            # },
            {
                "name": "get_document",
                "ref": self.get_document,
                "description": self.get_document.__doc__,
                "args_schema": AzureDocumentInput,
            },
        ]
```
