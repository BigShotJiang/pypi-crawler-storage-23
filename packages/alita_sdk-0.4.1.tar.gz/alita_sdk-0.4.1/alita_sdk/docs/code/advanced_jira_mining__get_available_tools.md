# advanced_jira_mining - get_available_tools

**Toolkit**: `advanced_jira_mining`
**Method**: `get_available_tools`
**Source File**: `data_mining_wrapper.py`
**Class**: `AdvancedJiraMiningWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "prepare_data",
                "description": self.prepare_data.__doc__,
                "args_schema": PrepareDataSchema,
                "ref": self.prepare_data,
            },
            {
                "name": "search_data",
                "description": self.search_data.__doc__,
                "args_schema": SearchDataSchema,
                "ref": self.search_data,
            },
            {
                "name": "gaps_analysis",
                "description": self.gaps_analysis.__doc__,
                "args_schema": SearchDataSchema,
                "ref": self.gaps_analysis,
            }

        ]
```
