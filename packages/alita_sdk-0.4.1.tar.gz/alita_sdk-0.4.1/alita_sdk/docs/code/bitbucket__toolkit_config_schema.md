# bitbucket - toolkit_config_schema

**Toolkit**: `bitbucket`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AlitaBitbucketToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in
                          BitbucketAPIWrapper.model_construct().get_available_tools()}
        m = create_model(
            name,
            project=(str, Field(description="Project/Workspace")),
            repository=(str, Field(description="Repository")),
            branch=(str, Field(description="Main branch", default="main")),
            cloud=(Optional[bool], Field(description="Hosting Option", default=None)),
            bitbucket_configuration=(BitbucketConfiguration, Field(description="Bitbucket Configuration", json_schema_extra={'configuration_types': ['bitbucket']})),
            pgvector_configuration=(Optional[PgVectorConfiguration], Field(default=None, description="PgVector Configuration", json_schema_extra={'configuration_types': ['pgvector']})),
            # embedder settings
            embedding_model=(Optional[str], Field(default=None, description="Embedding configuration.", json_schema_extra={'configuration_model': 'embedding'})),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__=ConfigDict(json_schema_extra=
            {
                'metadata':
                    {
                        "label": "Bitbucket", "icon_url": "bitbucket-icon.svg",
                        "categories": ["code repositories"],
                        "extra_categories": ["bitbucket", "git", "repository", "code", "version control"],
                    }
            })
        )

        @check_connection_response
        def check_connection(self):
            bitbucket_config = self.bitbucket_configuration or {}
            url = bitbucket_config.get('url', '')
            username = bitbucket_config.get('username', '')
            password = bitbucket_config.get('password', '')

            if self.cloud:
                request_url = f"{url}/2.0/repositories/{self.project}/{self.repository}"
            else:
                request_url = f"{url}/rest/api/1.0/projects/{self.project}/repos/{self.repository}"
            response = requests.get(request_url, auth=HTTPBasicAuth(username, password))
            return response

        m.check_connection = check_connection
        return m
```
