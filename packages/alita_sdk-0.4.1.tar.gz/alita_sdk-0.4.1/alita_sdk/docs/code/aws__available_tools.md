# aws - available_tools

**Toolkit**: `aws`
**Method**: `available_tools`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkit`

---

## Method Implementation

```python
    def available_tools(self) -> List[dict]:
        return self.api_wrapper.get_available_tools()
```
