# bitbucket - get_available_tools

**Toolkit**: `bitbucket`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "create_branch",
                "ref": self.create_branch,
                "description": self.create_branch.__doc__ or "Create a new branch in the repository.",
                "args_schema": CreateBranchModel,
            },
            {
                "name": "delete_branch",
                "ref": self.delete_branch,
                "description": self.delete_branch.__doc__ or "Delete a branch from the repository. Cannot delete main or master branches.",
                "args_schema": DeleteBranchModel,
            },
            {
                "name": "list_branches_in_repo",
                "ref": self.list_branches_in_repo,
                "description": self.list_branches_in_repo.__doc__ or "List branches in the repository with optional limit and wildcard filtering.",
                "args_schema": ListBranchesInRepoModel,
            },
            {
                "name": "list_files",
                "ref": self.list_files,
                "description": self.list_files.__doc__ or "List files in the repository with optional path, recursive search, and branch.",
                "args_schema": ListFilesModel,
            },
            {
                "name": "create_pull_request",
                "ref": self.create_pull_request,
                "description": self.create_pull_request.__doc__ or "Create a pull request in the repository.",
                "args_schema": CreatePullRequestModel,
            },
            {
                "name": "create_file",
                "ref": self.create_file,
                "description": self.create_file.__doc__ or "Create a new file in the repository.",
                "args_schema": CreateFileModel,
            },
            {
                "name": "read_file",
                "ref": self.read_file,
                "description": self.read_file.__doc__ or "Read the contents of a file in the repository.",
                "args_schema": ReadFileModel,
            },
            {
                "name": "update_file",
                "ref": self.update_file,
                "description": EDIT_FILE_DESCRIPTION,
                "args_schema": UpdateFileModel,
            },
            {
                "name": "set_active_branch",
                "ref": self.set_active_branch,
                "description": self.set_active_branch.__doc__ or "Set the active branch in the repository.",
                "args_schema": SetActiveBranchModel,
            },
            {
                "name": "get_pull_requests_commits",
                "ref": self.get_pull_requests_commits,
                "description": self.get_pull_requests_commits.__doc__ or "Get commits from a pull request in the repository.",
                "args_schema": GetPullRequestsCommitsModel,
            },
            {
                "name": "get_pull_request",
                "ref": self.get_pull_request,
                "description": self.get_pull_request.__doc__ or "Get details of a pull request in the repository.",
                "args_schema": GetPullRequestModel,
            },
            {
                "name": "get_pull_requests_changes",
                "ref": self.get_pull_requests_changes,
                "description": self.get_pull_requests_changes.__doc__ or "Get changes from a pull request in the repository.",
                "args_schema": GetPullRequestsChangesModel,
            },
            {
                "name": "add_pull_request_comment",
                "ref": self.add_pull_request_comment,
                "description": self.add_pull_request_comment.__doc__ or "Add a comment to a pull request in the repository.",
                "args_schema": AddPullRequestCommentModel,
            },
            {
                "name": "close_pull_request",
                "ref": self.close_pull_request,
                "description": self.close_pull_request.__doc__ or "Close (decline) a pull request without merging it.",
                "args_schema": ClosePullRequestModel,
            }
        ]
```
