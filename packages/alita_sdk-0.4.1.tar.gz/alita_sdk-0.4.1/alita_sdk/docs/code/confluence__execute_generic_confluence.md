# confluence - execute_generic_confluence

**Toolkit**: `confluence`
**Method**: `execute_generic_confluence`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def execute_generic_confluence(self, method: str, relative_url: str, params: Optional[str] = "") -> str:
        """Generic Confluence Tool for Official Atlassian Confluence REST API to call, searching, creating, updating pages, etc."""
        payload_params = parse_payload_params(params)
        if method == "GET":
            response = self.client.request(
                method=method,
                path=relative_url,
                params=payload_params,
                advanced_mode=True
            )
            response_text = self.process_search_response(relative_url, response)
        else:
            response = self.client.request(
                method=method,
                path=relative_url,
                data=payload_params,
                advanced_mode=True
            )
            response_text = response.text
        response_string = f"HTTP: {method}{relative_url} -> {response.status_code}{response.reason}{response_text}"
        logger.debug(response_string)
        return response_string
```

## Helper Methods

```python
Helper: parse_payload_params
def parse_payload_params(params: Optional[str]) -> Dict[str, Any]:
    if params:
        try:
            return json.loads(params)
        except JSONDecodeError:
            stacktrace = traceback.format_exc()
            return ToolException(f"Confluence tool exception. Passed params are not valid JSON. {stacktrace}")
    return {}
```

```python
Helper: process_search_response
    def process_search_response(self, relative_url: str, response) -> str:
        page_search_pattern = r'/rest/api/content/\d+'
        if re.match(page_search_pattern, relative_url):
            body = markdownify(response.text, heading_style="ATX")
            return body
        return response.text
```
