# figma - categorize_components

**Toolkit**: `figma`
**Method**: `categorize_components`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def categorize_components(components: List[str]) -> Dict[str, List[str]]:
    """
    Group components into semantic categories.

    Returns:
        {
            'buttons': ['Button/Primary', 'Button/Secondary'],
            'inputs': ['Input/Text', 'Input/Email'],
            'other': ['CustomComponent'],
            ...
        }
    """
    categorized = {cat: [] for cat in COMPONENT_CATEGORIES}
    categorized['other'] = []

    for component in components:
        comp_lower = component.lower()
        found_category = False

        for category, keywords in COMPONENT_CATEGORIES.items():
            if any(kw in comp_lower for kw in keywords):
                categorized[category].append(component)
                found_category = True
                break

        if not found_category:
            categorized['other'].append(component)

    # Remove empty categories
    return {k: v for k, v in categorized.items() if v}
```
