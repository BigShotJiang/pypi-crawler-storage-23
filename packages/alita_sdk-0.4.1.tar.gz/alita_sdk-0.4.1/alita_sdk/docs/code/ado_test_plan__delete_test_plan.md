# ado_test_plan - delete_test_plan

**Toolkit**: `ado_test_plan`
**Method**: `delete_test_plan`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def delete_test_plan(self, plan_id: int):
        """Delete a test plan in Azure DevOps."""
        try:
            self._client.delete_test_plan(self.project, plan_id)
            return f"Test plan {plan_id} deleted successfully."
        except Exception as e:
            logger.error(f"Error deleting test plan: {e}")
            return ToolException(f"Error deleting test plan: {e}")
```
