# ado - list_open_pull_requests

**Toolkit**: `ado`
**Method**: `list_open_pull_requests`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def list_open_pull_requests(self) -> str:
        """
        Fetches all open pull requests from the Azure DevOps repository.

        Returns:
            str: A plaintext report containing the number of PRs
            and each PR's title and ID.
        """
        try:
            pull_requests = self._client.get_pull_requests(
                repository_id=self.repository_id,
                search_criteria=GitPullRequestSearchCriteria(
                    repository_id=self.repository_id, status="active"
                ),
                project=self.project,
            )
        except Exception as e:
            msg = f"Error during attempt to get active pull request: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        if pull_requests:
            parsed_prs = self.parse_pull_requests(pull_requests)
            parsed_prs_str = (
                    "Found "
                    + str(len(parsed_prs))
                    + " open pull requests:\n"
                    + str(parsed_prs)
            )
            return parsed_prs_str
        else:
            return "No open pull requests available"
```
