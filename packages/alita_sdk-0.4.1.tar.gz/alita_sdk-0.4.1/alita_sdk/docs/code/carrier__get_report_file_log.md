# carrier - get_report_file_log

**Toolkit**: `carrier`
**Method**: `get_report_file_log`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def get_report_file_log(self, bucket: str, file_name: str):
        bucket_endpoint = f"api/v1/artifacts/artifact/default/{self.credentials.project_id}/{bucket}/{file_name}"
        full_url = f"{self.credentials.url.rstrip('/')}/{bucket_endpoint.lstrip('/')}"
        headers = {'Authorization': f'bearer {self.credentials.token}'}
        s3_config = {'integration_id': 1, 'is_local': False}
        response = requests.get(full_url, params=s3_config, headers=headers)
        file_path = f"/tmp/{file_name}"
        with open(file_path, 'wb') as f:
            f.write(response.content)
        return file_path
```
