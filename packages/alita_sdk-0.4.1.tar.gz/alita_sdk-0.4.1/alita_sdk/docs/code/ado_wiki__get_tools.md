# ado_wiki - get_tools

**Toolkit**: `ado_wiki`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsWikiToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
