# figma - analyze_frame_with_llm

**Toolkit**: `figma`
**Method**: `analyze_frame_with_llm`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def analyze_frame_with_llm(
    frame_data: Dict,
    llm: Any,
    toon_serializer: Optional['TOONSerializer'] = None,
    image_url: Optional[str] = None,
) -> Optional[ScreenExplanation]:
    """
    Analyze a single frame using LLM with structured output.

    Supports vision-based analysis when image_url is provided (for multimodal LLMs).
    Falls back to text-based analysis using TOON data otherwise.

    Args:
        frame_data: Processed frame data dict
        llm: LangChain LLM instance with structured output support
        toon_serializer: Optional serializer for formatting
        image_url: Optional URL to frame image for vision-based analysis

    Returns:
        ScreenExplanation model or None if analysis fails
    """
    if not llm:
        return None

    frame_name = frame_data.get('name', 'Unknown')
    frame_id = frame_data.get('id', '')

    # Try vision-based analysis first if image available
    if image_url:
        try:
            from langchain_core.messages import HumanMessage

            structured_llm = llm.with_structured_output(ScreenExplanation)
            prompt_text = SCREEN_VISION_PROMPT.format(
                frame_name=frame_name,
                frame_id=frame_id,
            )

            # Create message with image content
            message = HumanMessage(
                content=[
                    {"type": "text", "text": prompt_text},
                    {"type": "image_url", "image_url": {"url": image_url}},
                ]
            )
            result = structured_llm.invoke([message])
            if result:
                return result
        except Exception as e:
            # Vision analysis failed - fall back to text-based
            logging.warning(f"Vision analysis failed for {frame_name}, falling back to text: {type(e).__name__}: {e}")

    # Text-based analysis (fallback or primary if no image)
    try:
        if toon_serializer is None:
            toon_serializer = TOONSerializer()

        toon_lines = toon_serializer.serialize_frame(frame_data, level=0)
        toon_data = '\n'.join(toon_lines)

        prompt = SCREEN_TEXT_PROMPT.format(
            frame_name=frame_name,
            frame_id=frame_id,
            toon_data=toon_data,
        )

        structured_llm = llm.with_structured_output(ScreenExplanation)
        result = structured_llm.invoke(prompt)
        return result

    except Exception as e:
        logging.warning(f"LLM frame analysis failed for {frame_name}: {type(e).__name__}: {e}")
        return None
```
