# ado - process_attachment

**Toolkit**: `ado`
**Method**: `process_attachment`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def process_attachment(self, attachment_url, attachment_name, repos_wrapper, image_description_prompt):
        file_path = unquote(attachment_url.lstrip('/'))
        attachment_content = repos_wrapper.download_file(path=file_path)
        return parse_file_content(
            file_content=attachment_content,
            file_name=attachment_name,
            llm=self.llm,
            prompt=image_description_prompt
        )
```
