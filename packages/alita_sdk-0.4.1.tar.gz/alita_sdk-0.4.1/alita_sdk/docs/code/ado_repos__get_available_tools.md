# ado_repos - get_available_tools

**Toolkit**: `ado_repos`
**Method**: `get_available_tools`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        """Return a list of available tools."""
        return [
            {
                "ref": self.list_branches_in_repo,
                "name": "list_branches_in_repo",
                "description": self.list_branches_in_repo.__doc__,
                "args_schema": ArgsSchema.NoInput.value,
            },
            {
                "ref": self.set_active_branch,
                "name": "set_active_branch",
                "description": self.set_active_branch.__doc__,
                "args_schema": ArgsSchema.BranchName.value,
            },
            {
                "ref": self.list_files,
                "name": "list_files",
                "description": self.list_files.__doc__,
                "args_schema": ArgsSchema.ListFilesModel.value,
            },
            {
                "ref": self.list_open_pull_requests,
                "name": "list_open_pull_requests",
                "description": self.list_open_pull_requests.__doc__,
                "args_schema": ArgsSchema.NoInput.value,
            },
            {
                "ref": self.get_pull_request,
                "name": "get_pull_request",
                "description": self.get_pull_request.__doc__,
                "args_schema": ArgsSchema.GetPR.value,
            },
            {
                "ref": self.list_pull_request_diffs,
                "name": "list_pull_request_files",
                "description": self.list_pull_request_diffs.__doc__,
                "args_schema": ArgsSchema.GetPR.value,
            },
            {
                "ref": self.create_branch,
                "name": "create_branch",
                "description": self.create_branch.__doc__,
                "args_schema": ArgsSchema.BranchName.value,
            },
            {
                "ref": self._read_file,
                "name": "read_file",
                "description": self._read_file.__doc__,
                "args_schema": ArgsSchema.ReadFile.value,
            },
            {
                "ref": self.create_file,
                "name": "create_file",
                "description": self.create_file.__doc__,
                "args_schema": ArgsSchema.CreateFile.value,
            },
            {
                "ref": self.update_file,
                "name": "update_file",
                "description": EDIT_FILE_DESCRIPTION,
                "args_schema": ArgsSchema.UpdateFile.value,
            },
            {
                "ref": self.delete_file,
                "name": "delete_file",
                "description": self.delete_file.__doc__,
                "args_schema": ArgsSchema.DeleteFile.value,
            },
            {
                "ref": self.get_work_items,
                "name": "get_work_items",
                "description": self.get_work_items.__doc__,
                "args_schema": ArgsSchema.GetWorkItems.value,
            },
            {
                "ref": self.comment_on_pull_request,
                "name": "comment_on_pull_request",
                "description": self.comment_on_pull_request.__doc__,
                "args_schema": ArgsSchema.CommentOnPullRequest.value,
            },
            {
                "ref": self.create_pr,
                "name": "create_pull_request",
                "description": self.create_pr.__doc__,
                "args_schema": ArgsSchema.CreatePullRequest.value,
            },
            {
                "ref": self.get_commits,
                "name": "get_commits",
                "description": self.get_commits.__doc__,
                "args_schema": ArgsSchema.GetCommits.value,
            },
        ]
```
