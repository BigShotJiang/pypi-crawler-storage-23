# aws - delta_table

**Toolkit**: `aws`
**Method**: `delta_table`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def delta_table(self) -> DeltaTable:
        if not self._delta_table:
            path = self.table_path or self.s3_path
            if not path:
                raise ToolException("Delta Lake table path (table_path or s3_path) must be specified.")
            try:
                storage_options = {
                    "AWS_ACCESS_KEY_ID": self.aws_access_key_id.get_secret_value() if self.aws_access_key_id else None,
                    "AWS_SECRET_ACCESS_KEY": self.aws_secret_access_key.get_secret_value() if self.aws_secret_access_key else None,
                    "AWS_REGION": self.aws_region,
                }
                if self.aws_session_token:
                    storage_options["AWS_SESSION_TOKEN"] = self.aws_session_token.get_secret_value()
                storage_options = {k: v for k, v in storage_options.items() if v is not None}
                self._delta_table = DeltaTable(path, storage_options=storage_options)
            except Exception as e:
                raise ToolException(f"Error initializing DeltaTable: {e}")
        return self._delta_table
```
