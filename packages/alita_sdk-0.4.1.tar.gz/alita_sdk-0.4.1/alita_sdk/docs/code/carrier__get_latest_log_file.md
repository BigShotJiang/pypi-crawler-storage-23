# carrier - get_latest_log_file

**Toolkit**: `carrier`
**Method**: `get_latest_log_file`
**Source File**: `utils.py`

---

## Method Implementation

```python
def get_latest_log_file(root_dir: str, log_file_name: str) -> str:
    if not os.path.isdir(root_dir):
        raise FileNotFoundError(f"Directory not found: {root_dir}")
    folders = next(os.walk(root_dir))[1]
    folders.sort(key=lambda folder: os.path.getmtime(os.path.join(root_dir, folder)))
    latest_folder = folders[-1]
    simulation_log_file = os.path.join(root_dir, latest_folder, log_file_name)

    if not os.path.isfile(simulation_log_file):
        raise FileNotFoundError(f"File not found: {simulation_log_file}")
    return simulation_log_file
```
