# figma - enrich_toon_with_llm_analysis

**Toolkit**: `figma`
**Method**: `enrich_toon_with_llm_analysis`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def enrich_toon_with_llm_analysis(
    toon_output: str,
    file_data: Dict,
    llm: Any,
    analysis_level: str = 'summary',
    frame_images: Optional[Dict[str, str]] = None,
    status_callback: Optional[Callable[[str], None]] = None,
    include_design_insights: bool = True,
    parallel_workers: int = 5,
    max_frames_to_analyze: int = 50,
) -> str:
    """
    Enrich TOON output with LLM-generated explanations.

    For 'detailed' mode, explanations are merged inline with each FRAME.
    Supports vision-based analysis when frame_images are provided.
    For 'summary' mode, only file-level analysis is appended.

    Args:
        toon_output: Base TOON formatted string
        file_data: Processed file data
        llm: LangChain LLM instance
        analysis_level: 'summary' (file-level only) or 'detailed' (per-screen inline)
        frame_images: Optional dict mapping frame_id -> image_url for vision analysis
        status_callback: Optional callback for progress updates
        include_design_insights: Whether to include DESIGN INSIGHTS section (default True)
        parallel_workers: Number of parallel LLM workers (default 5)
        max_frames_to_analyze: Maximum frames to analyze with LLM (default 50)

    Returns:
        Enriched TOON output with LLM analysis
    """
    if not llm:
        return toon_output

    if analysis_level == 'detailed':
        # Re-serialize with inline LLM explanations (with optional vision)
        return serialize_file_with_llm_explanations(
            file_data, llm, frame_images=frame_images, status_callback=status_callback,
            include_design_insights=include_design_insights,
            parallel_workers=parallel_workers,
            max_frames_to_analyze=max_frames_to_analyze,
        )

    # For summary mode, just append file-level analysis
    lines = [toon_output]
    analysis = analyze_file_with_llm(file_data, llm)
    if analysis:
        lines.append("")
        lines.append("=" * 60)
        lines.append("DESIGN ANALYSIS")
        lines.append("=" * 60)
        lines.append(serialize_design_analysis(analysis))

    return '\n'.join(lines)
```

## Helper Methods

```python
Helper: analyze_file_with_llm
def analyze_file_with_llm(
    file_data: Dict,
    llm: Any,
    max_screens: int = 10,
) -> Optional[DesignAnalysis]:
    """
    Analyze entire Figma file using LLM with structured output.

    Args:
        file_data: Processed file data dict with pages and frames
        llm: LangChain LLM instance with structured output support
        max_screens: Maximum screens to include in analysis (for token limits)

    Returns:
        DesignAnalysis model or None if analysis fails
    """
    if not llm:
        return None

    try:
        # Serialize file to TOON format
        serializer = TOONSerializer()
        toon_output = serializer.serialize_file(file_data)

        # Truncate if too long (rough token estimate: 4 chars per token)
        max_chars = 8000  # ~2000 tokens for input
        if len(toon_output) > max_chars:
            toon_output = toon_output[:max_chars] + "\n... (truncated)"

        # Build prompt
        prompt = FILE_ANALYSIS_PROMPT.format(toon_data=toon_output)

        # Call LLM with structured output
        structured_llm = llm.with_structured_output(DesignAnalysis)
        result = structured_llm.invoke(prompt)

        return result

    except Exception as e:
        logging.warning(f"LLM file analysis failed: {e}")
        return None
```

```python
Helper: serialize_file_with_llm_explanations
def serialize_file_with_llm_explanations(
    file_data: Dict,
    llm: Any,
    frame_images: Optional[Dict[str, str]] = None,
    max_frames_to_analyze: int = 50,
    status_callback: Optional[Callable[[str], None]] = None,
    parallel_workers: int = 5,
    include_design_insights: bool = True,
) -> str:
    """
    Serialize file with LLM explanations merged inline with each FRAME.

    Supports vision-based analysis when frame_images dict is provided.
    Uses parallel LLM processing for faster analysis.
    Output uses visual insights instead of element mappings.

    Args:
        file_data: Processed file data dict
        llm: LangChain LLM instance
        frame_images: Optional dict mapping frame_id -> image_url for vision analysis
        max_frames_to_analyze: Maximum frames to analyze with LLM (default 50)
        status_callback: Optional callback function for progress updates
        parallel_workers: Number of parallel LLM workers (default 5)
        include_design_insights: Whether to include DESIGN INSIGHTS section (default True)

    Output format:
    FILE: Name [key:xxx]
      PAGE: Page Name #id
        FRAME: Frame Name [pos] type/state #id
          Purpose: Authentication screen for returning users
          Goal: Sign into account | Action: "Sign In"
          Visual: [focus] title and form | [layout] form-stack | [state] default
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _log_status(msg: str):
        """Log status via callback if provided."""
        logging.info(msg)
        if status_callback:
            try:
                status_callback(msg)
            except Exception:
                pass  # Don't let callback failures break processing

    lines = []
    serializer = TOONSerializer()
    frame_images = frame_images or {}

    # File header
    name = file_data.get('name', 'Untitled')
    key = file_data.get('key', '')
    lines.append(f"FILE: {name} [key:{key}]")

    # Collect all frames first for parallel processing
    all_frames = []
    frame_to_page = {}  # Map frame_id to page info for later

    for page in file_data.get('pages', []):
        for frame in page.get('frames', []):
            all_frames.append(frame)
            frame_to_page[frame.get('id', '')] = {
                'page_name': page.get('name', 'Untitled Page'),
                'page_id': page.get('id', ''),
            }

    total_frames = len(all_frames)
    frames_to_analyze = all_frames[:max_frames_to_analyze]
    _log_status(f"Starting LLM analysis for {len(frames_to_analyze)} of {total_frames} frames...")

    # Parallel LLM analysis
    frame_explanations = {}  # frame_id -> explanation

    def _analyze_single_frame(frame: Dict) -> Tuple[str, Optional[Any]]:
        """Worker function to analyze a single frame."""
        frame_id = frame.get('id', '')
        image_url = frame_images.get(frame_id)
        try:
            explanation = analyze_frame_with_llm(
                frame, llm, serializer, image_url=image_url
            )
            return frame_id, explanation
        except Exception as e:
            logging.warning(f"LLM analysis failed for frame {frame.get('name')}: {e}")
            return frame_id, None

    # Use parallel processing for LLM calls
    if frames_to_analyze:
        workers = min(parallel_workers, len(frames_to_analyze))
        _log_status(f"Analyzing frames with {workers} parallel LLM workers...")
        completed = 0

        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_frame = {
                executor.submit(_analyze_single_frame, frame): frame
                for frame in frames_to_analyze
            }

            for future in as_completed(future_to_frame):
                frame = future_to_frame[future]
                frame_name = frame.get('name', 'Untitled')
                try:
                    frame_id, explanation = future.result()
                    if explanation:
                        frame_explanations[frame_id] = explanation
                        _log_status(f"Analyzed {completed + 1}/{len(frames_to_analyze)}: {frame_name} ✓")
                    else:
                        _log_status(f"Analyzed {completed + 1}/{len(frames_to_analyze)}: {frame_name} (no result)")
                    completed += 1
                except Exception as e:
                    completed += 1
                    logging.warning(f"Frame analysis failed for {frame_name}: {e}")
                    _log_status(f"Analyzed {completed}/{len(frames_to_analyze)}: {frame_name} (error: {type(e).__name__})")

    # Summary of LLM analysis results
    success_count = len(frame_explanations)
    _log_status(f"Frame analysis complete: {success_count}/{len(frames_to_analyze)} frames analyzed successfully")

    # Now generate output with pre-computed explanations
    for page in file_data.get('pages', []):
        page_name = page.get('name', 'Untitled Page')
        page_id = page.get('id', '')
        lines.append(f"  PAGE: {page_name} #{page_id}")

        for frame in page.get('frames', []):
            frame_name = frame.get('name', 'Untitled')
            frame_id = frame.get('id', '')
            frame_type = frame.get('type', 'screen')
            frame_state = frame.get('state', 'default')

            # Compact frame header
            pos = frame.get('position', {})
            size = frame.get('size', {})
            pos_str = f"[{int(pos.get('x', 0))},{int(pos.get('y', 0))} {int(size.get('w', 0))}x{int(size.get('h', 0))}]"
            lines.append(f"    FRAME: {frame_name} {pos_str} {frame_type}/{frame_state} #{frame_id}")

            # Get frame content
            headings = frame.get('headings', [])
            buttons = frame.get('buttons', []).copy()  # Copy to allow modification
            inputs = frame.get('inputs', [])
            primary_action = None  # Track LLM-identified action

            # LLM analysis from pre-computed results
            explanation = frame_explanations.get(frame_id)
            if explanation:
                lines.append(f"      Purpose: {explanation.purpose}")
                goal_action = f"Goal: {explanation.user_goal}"
                if explanation.primary_action:
                    primary_action = explanation.primary_action
                    goal_action += f" | Action: \"{primary_action}\""
                lines.append(f"      {goal_action}")

                # Visual insights
                visual_parts = []
                if explanation.visual_focus:
                    visual_parts.append(f"[focus] {explanation.visual_focus}")
                if explanation.layout_pattern:
                    visual_parts.append(f"[layout] {explanation.layout_pattern}")
                if explanation.visual_state and explanation.visual_state != 'default':
                    visual_parts.append(f"[state] {explanation.visual_state}")
                if visual_parts:
                    lines.append(f"      Visual: {' | '.join(visual_parts)}")

            # Ensure primary_action from LLM appears in buttons (button completeness)
            if primary_action:
                # Check if action is already in buttons (case-insensitive)
                buttons_lower = [b.lower() for b in buttons]
                action_lower = primary_action.lower()
                if not any(action_lower in b or b in action_lower for b in buttons_lower):
                    # Add the LLM-identified action to buttons list
                    buttons.insert(0, f"[LLM] {primary_action}")

            # Use LLM-extracted inputs if available (preferred), else fall back to heuristic
            llm_inputs = []
            if explanation and hasattr(explanation, 'inputs') and explanation.inputs:
                llm_inputs = explanation.inputs

            # Extracted content (Headings, Buttons, Inputs)
            if headings:
                lines.append(f"      Headings: {' | '.join(headings[:3])}")
            if buttons:
                # Show buttons with inferred actions
                btn_strs = []
                for btn in buttons[:6]:  # Increased limit to accommodate added LLM action
                    dest = infer_cta_destination(btn, frame_context=frame_name)
                    btn_strs.append(f"{btn} > {dest}" if dest else btn)
                lines.append(f"      Buttons: {' | '.join(btn_strs)}")

            # Prefer LLM-extracted inputs over heuristic extraction (standardized format)
            if llm_inputs:
                # Convert LLM ExtractedInput objects to dicts for standardized formatting
                llm_inputs_dicts = [
                    {
                        'name': inp.label,
                        'type': inp.input_type,
                        'required': inp.required,
                        'value': inp.current_value,
                        'options': inp.options,
                    }
                    for inp in llm_inputs
                ]
                inputs_str = format_inputs_list(llm_inputs_dicts)
                if inputs_str:
                    lines.append(f"      Inputs: {inputs_str}")
            elif inputs:
                # Fallback to heuristic-extracted inputs (standardized format)
                inputs_str = format_inputs_list(inputs)
                if inputs_str:
                    lines.append(f"      Inputs: {inputs_str}")

        lines.append("")  # Blank line after page

    _log_status("Analyzing flows and variants (parallel)...")

    # Run LLM flow analysis and design insights in parallel
    flow_analysis_result = None
    design_analysis_result = None
    flow_error = None
    design_error = None

    def _analyze_flows():
        """Worker for flow analysis."""
        nonlocal flow_analysis_result, flow_error
        try:
            flow_analysis_result = analyze_flows_with_llm(all_frames, llm)
        except Exception as e:
            flow_error = e

    def _analyze_design():
        """Worker for design insights."""
        nonlocal design_analysis_result, design_error
        try:
            design_analysis_result = analyze_file_with_llm(file_data, llm)
        except Exception as e:
            design_error = e

    # Run flow analysis and optionally design insights in parallel
    if all_frames:
        parallel_tasks = [_analyze_flows]
        if include_design_insights:
            parallel_tasks.append(_analyze_design)

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(task) for task in parallel_tasks]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    logging.warning(f"Parallel analysis task failed: {e}")

    # Add FLOWS section
    if all_frames:
        lines.append("FLOWS:")
        if flow_analysis_result:
            flow_lines = serialize_flow_analysis(flow_analysis_result, level=0)
            lines.extend(flow_lines)
        elif flow_error:
            logging.warning(f"LLM flow analysis failed, using heuristics: {flow_error}")
            flow_lines = serializer.serialize_flows(all_frames, level=0)
            lines.extend(flow_lines)
        else:
            # Fallback to heuristic flows if LLM returned nothing
            flow_lines = serializer.serialize_flows(all_frames, level=0)
            lines.extend(flow_lines)

    # Explicit VARIANTS section with frame differences (fast heuristic, no parallelization needed)
    if all_frames:
        variants = group_variants(all_frames)
        if variants:
            lines.append("")
            lines.append("VARIANTS:")
            for base, variant_list in variants.items():
                if len(variant_list) > 1:
                    # Group by states
                    states_by_id = {}
                    for v in variant_list:
                        state = v.get('state', 'default')
                        frame_id = v.get('id', '')[:6]  # Short ID
                        states_by_id[f"#{frame_id}"] = state

                    # Detect potential duplicates (same state, similar content)
                    state_groups = {}
                    for v in variant_list:
                        state = v.get('state', 'default')
                        if state not in state_groups:
                            state_groups[state] = []
                        state_groups[state].append(v)

                    # Build variant line
                    lines.append(f"  {base} ({len(variant_list)} frames):")

                    # List variants by state
                    for state, variants_in_state in state_groups.items():
                        ids = [f"#{v.get('id', '')[:6]}" for v in variants_in_state]
                        if len(variants_in_state) > 1:
                            # Potential duplicates or responsive variants
                            lines.append(f"    {state}: {', '.join(ids)} - potential duplicates or responsive")
                        else:
                            # Unique state
                            frame = variants_in_state[0].get('frame', {})
                            # Try to identify distinguishing feature
                            distinguisher = ""
                            if frame.get('headings'):
                                distinguisher = f" - \"{frame['headings'][0][:30]}...\""
                            elif frame.get('inputs'):
                                inp = frame['inputs'][0]
                                distinguisher = f" - {inp.get('type', 'text')} labeled \"{inp.get('name', '')[:20]}\""
                            lines.append(f"    {state}: {ids[0]}{distinguisher}")

    # Add DESIGN INSIGHTS section (if enabled and analysis succeeded)
    if include_design_insights:
        if design_analysis_result:
            _log_status("Adding design insights...")
            lines.append("")
            lines.append("DESIGN INSIGHTS:")
            lines.append(f"  Type: {design_analysis_result.design_type} | Target: {design_analysis_result.target_user}")
            lines.append(f"  Purpose: {design_analysis_result.overall_purpose}")
            if design_analysis_result.design_patterns:
                lines.append(f"  Patterns: {', '.join(design_analysis_result.design_patterns[:5])}")
            if design_analysis_result.gaps_or_concerns:
                lines.append(f"  Gaps: {'; '.join(design_analysis_result.gaps_or_concerns[:3])}")
        elif design_error:
            logging.warning(f"File-level LLM analysis failed: {design_error}")

    return '\n'.join(lines)
```

```python
Helper: serialize_design_analysis
def serialize_design_analysis(
    analysis: DesignAnalysis,
    indent: str = TOON_INDENT,
) -> str:
    """
    Serialize a complete DesignAnalysis to readable format.

    Returns formatted string.
    """
    lines = []

    lines.append(f"DESIGN ANALYSIS: {analysis.file_name}")
    lines.append(f"{indent}Type: {analysis.design_type}")
    lines.append(f"{indent}Target User: {analysis.target_user}")
    lines.append(f"{indent}Purpose: {analysis.overall_purpose}")

    if analysis.design_patterns:
        lines.append(f"{indent}Patterns: {', '.join(analysis.design_patterns)}")

    # Flows
    if analysis.flows:
        lines.append(f"{indent}USER FLOWS:")
        for flow in analysis.flows:
            lines.append(f"{indent}{indent}{flow.flow_name}: {flow.entry_point} > ... > {flow.exit_point}")
            lines.append(f"{indent}{indent}{indent}{flow.description}")
            if flow.error_states:
                lines.append(f"{indent}{indent}{indent}Error states: {', '.join(flow.error_states)}")

    # Screens
    if analysis.screens:
        lines.append(f"{indent}SCREENS ({len(analysis.screens)}):")
        for screen in analysis.screens:
            lines.append(f"{indent}{indent}{screen.frame_name}: {screen.purpose}")
            if screen.primary_action:
                lines.append(f"{indent}{indent}{indent}Primary: {screen.primary_action}")

    # Concerns
    if analysis.gaps_or_concerns:
        lines.append(f"{indent}GAPS/CONCERNS:")
        for concern in analysis.gaps_or_concerns:
            lines.append(f"{indent}{indent}- {concern}")

    # Accessibility
    if analysis.accessibility_notes:
        lines.append(f"{indent}ACCESSIBILITY:")
        for note in analysis.accessibility_notes:
            lines.append(f"{indent}{indent}- {note}")

    return '\n'.join(lines)
```
