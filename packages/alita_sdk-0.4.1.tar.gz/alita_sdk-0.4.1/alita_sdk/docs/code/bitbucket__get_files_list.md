# bitbucket - get_files_list

**Toolkit**: `bitbucket`
**Method**: `get_files_list`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_files_list(self, file_path: str, branch: str, recursive: bool = True) -> list:
        """Get list of files from a specific path and branch.

        Branch names with slashes are URL-encoded to ensure proper API requests.

        Parameters:
            file_path (str): The path to list files from
            branch (str): The branch name
            recursive (bool): Whether to list files recursively. If False, only direct children are returned.

        Returns:
            list: List of file paths
        """
        files_list = []
        # URL-encode branch name to handle special characters like forward slashes
        branch_hash = self._get_branch(branch).hash
        page = None

        while True:
            # Build the path with pagination
            path = f'src/{branch_hash}/{file_path}?max_depth=100&pagelen=100&fields=values.path,next&q=type="commit_file"'
            if page:
                path = page

            response = self.repository.get(path=path)

            for item in response.get('values', []):
                files_list.append(item['path'])

            # Check for next page
            page = response.get('next')
            if not page:
                break

        # Apply client-side filtering when recursive=False
        if not recursive:
            files_list = self._filter_non_recursive(files_list, file_path)

        return files_list
```
