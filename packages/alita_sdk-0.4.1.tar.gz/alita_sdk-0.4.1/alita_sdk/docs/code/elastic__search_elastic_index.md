# elastic - search_elastic_index

**Toolkit**: `elastic`
**Method**: `search_elastic_index`
**Source File**: `api_wrapper.py`
**Class**: `ELITEAElasticApiWrapper`

---

## Method Implementation

```python
    def search_elastic_index(self, index: str, query: str):
        """Search a specific data in the specific index in Elastic."""
        mapping = json.loads(query)
        response = self._client.search(index=index, body=mapping)
        return response
```
