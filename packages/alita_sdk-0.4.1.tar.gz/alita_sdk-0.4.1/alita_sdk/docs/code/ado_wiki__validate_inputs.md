# ado_wiki - validate_inputs

**Toolkit**: `ado_wiki`
**Method**: `validate_inputs`
**Source File**: `ado_wrapper.py`
**Class**: `GetPageInput`

---

## Method Implementation

```python
    def validate_inputs(cls, values):
        """Validator to ensure at least one of page_path or page_id is provided."""
        page_path = values.get('page_path')
        page_id = values.get('page_id')
        if not page_path and not page_id:
            raise ValueError("At least one of 'page_path' or 'page_id' must be provided")
        return values
```
