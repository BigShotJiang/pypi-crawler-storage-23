# figma - infer_entry_exit_points

**Toolkit**: `figma`
**Method**: `infer_entry_exit_points`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def infer_entry_exit_points(frames: List[Dict]) -> Dict[str, List[str]]:
    """
    Identify entry and exit points in the design.

    Entry points: Frames that are likely starting screens (home, landing, welcome)
    Exit points: Frames with completion/success states or external actions
    """
    entry_keywords = ['home', 'landing', 'welcome', 'splash', 'start', 'main', 'dashboard']
    exit_keywords = ['success', 'complete', 'done', 'confirmed', 'thank', 'finish']

    entry_points = []
    exit_points = []

    for frame in frames:
        name = frame.get('name', '').lower()
        state = frame.get('state', '')

        # Check for entry points
        if any(kw in name for kw in entry_keywords):
            entry_points.append(frame.get('name', ''))

        # Check for exit points
        if any(kw in name for kw in exit_keywords) or state == 'success':
            exit_points.append(frame.get('name', ''))

    return {
        'entry': entry_points[:3],  # Limit to 3
        'exit': exit_points[:3],
    }
```
