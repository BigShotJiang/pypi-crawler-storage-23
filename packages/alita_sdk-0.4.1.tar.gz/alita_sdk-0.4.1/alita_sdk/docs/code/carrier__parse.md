# carrier - parse

**Toolkit**: `carrier`
**Method**: `parse`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse(self) -> Dict[str, Any]:
        latest_log_file = self.log_file
        print(f"Path: {latest_log_file}")
        groups, requests, users, date_start, date_end, ramp_up_period = self.parse_log_file(latest_log_file)

        # Combine requests and groups for reporting purposes
        requests = defaultdict(list, {**requests})
        duration = self.calculate_duration(date_start, date_end)

        transactions_data = {
            "requests": {
                transaction: self.calculate_single_metric(transaction, entries)
                for transaction, entries in requests.items()
            },
            "groups": {
                group: self.calculate_single_metric(group, entries)
                for group, entries in groups.items()
            }
        }
        # Calculate total requests only from the original requests dictionary
        total_requests = self.calculate_all_requests(requests)
        transactions_data["requests"]["Total Requests"] = total_requests

        throughput = total_requests['Total'] / (duration * 60)  # Initializing a variable with the default value

        if duration > 1:
            duration = round(duration)
        if ramp_up_period > 1:
            ramp_up_period = round(ramp_up_period, 1)
            throughput = total_requests['Total'] / (duration * 60)
        if throughput > 1:
            throughput = round(throughput, 1)

        # Add any additional required summary metrics
        # Convert to Eastern Time (EST/EDT)
        from pytz import timezone
        eastern = timezone('US/Eastern')
        date_start = date_start.astimezone(eastern) if date_start else None
        date_end = date_end.astimezone(eastern) if date_end else None

        transactions_data.update({
            'max_user_count': users,
            'ramp_up_period': ramp_up_period,
            'error_rate': total_requests['Error%'],
            'date_start': date_start.strftime('%Y-%m-%d %H:%M:%S') if date_start else None,
            'date_end': date_end.strftime('%Y-%m-%d %H:%M:%S') if date_end else None,
            'throughput': throughput,
            'duration': duration,
            'think_time': self.calculated_think_time
        })
        return transactions_data
```

## Helper Methods

```python
Helper: parse_log_file
    def parse_log_file(self, file_path: str):
        groups = defaultdict(list)
        requests = defaultdict(list)
        users = 0
        date_start = None
        date_end = None
        ramp_start = None
        ramp_end = None
        try:
            with open(file_path, 'r', encoding="utf8") as file:
                for line_number, line in enumerate(file):
                    if not date_start:
                        if 'ASSERTION' in line:
                            continue
                        date_start = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                    try:
                        date_end = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                    except:
                        # TODO: Fix logic
                        pass
                    if line.startswith('REQUEST'):
                        self.parse_request_line(requests, line)
                    elif line.startswith('USER') and 'START' in line:
                        users += 1
                        if "START" in line:
                            if not ramp_start:
                                ramp_start = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                            else:
                                ramp_end = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))

                    elif line.startswith('GROUP'):
                        self.parse_group_line(groups, line, self.include_group_pauses)
        except FileNotFoundError as e:
            print(f"File not found: {e}")
            raise
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            raise
        return groups, requests, users, date_start, date_end, self.calculate_duration(ramp_start, ramp_end)
```
