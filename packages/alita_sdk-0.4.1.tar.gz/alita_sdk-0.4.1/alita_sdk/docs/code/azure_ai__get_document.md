# azure_ai - get_document

**Toolkit**: `azure_ai`
**Method**: `get_document`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def get_document(self, document_id: str, selected_fields: Optional[list] = None) -> Dict[str, Any]:
        """
        Get a specific document from the Azure Search index.

        :param document_id: The ID of the document to retrieve.
        :param selected_fields: The fields to retrieve from the document.
        :return: The document.
        """
        if selected_fields and len(selected_fields) == 0:
            selected_fields = None
        return self._client.get_document(key=document_id, selected_fields=selected_fields)
```
