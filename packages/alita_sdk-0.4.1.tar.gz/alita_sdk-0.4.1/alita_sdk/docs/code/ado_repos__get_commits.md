# ado_repos - get_commits

**Toolkit**: `ado_repos`
**Method**: `get_commits`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def get_commits(
            self,
            sha: Optional[str] = None,
            path: Optional[str] = None,
            since: Optional[str] = None,
            until: Optional[str] = None,
            author: Optional[str] = None,
    ) -> str:
        """
        Retrieves a list of commits from the repository.

        Parameters:
            sha (Optional[str]): The commit SHA to start listing commits from.
            path (Optional[str]): The file path to filter commits by.
            since (Optional[datetime]): Only commits after this date will be returned.
            until (Optional[datetime]): Only commits before this date will be returned.
            author (Optional[str]): The author of the commits.

        Returns:
            str: A list of commit data or an error message.
        """
        try:
            search_criteria = GitQueryCommitsCriteria(
                # get from the active branch if not specified
                item_version=GitVersionDescriptor(version=sha, version_type='commit') if sha else None,
                item_path=path,
                from_date=str(datetime.fromisoformat(since)) if since else None,
                to_date=str(datetime.fromisoformat(until)) if until else None,
                author=author if isinstance(author, str) else None
            )

            commits = self._client.get_commits(
                repository_id=self.repository_id,
                project=self.project,
                search_criteria=search_criteria)

            commit_list = [
                {
                    "sha": commit.commit_id,
                    "author": commit.author.name,
                    "createdAt": str(commits[0].author.date),
                    "message": commit.comment,
                    "url": commit.remote_url,
                }
                for commit in commits
            ]

            return commit_list
        except Exception as e:
            return ToolException(f"Unable to retrieve commits due to error:\n{str(e)}")
```
