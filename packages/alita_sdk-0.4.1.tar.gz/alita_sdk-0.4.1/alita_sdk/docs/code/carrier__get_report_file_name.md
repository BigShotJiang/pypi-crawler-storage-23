# carrier - get_report_file_name

**Toolkit**: `carrier`
**Method**: `get_report_file_name`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def get_report_file_name(self, report_id: str, extract_to: str = "/tmp"):
        endpoint = f"api/v1/backend_performance/reports/{self.credentials.project_id}?report_id={report_id}"
        report_info = self.request('get', endpoint)
        bucket_name = report_info["name"].replace("_", "").replace(" ", "").lower()
        report_archive_prefix = f"reports_test_results_{report_info['build_id']}"
        lg_type = report_info.get("lg_type")
        bucket_endpoint = f"api/v1/artifacts/artifacts/default/{self.credentials.project_id}/{bucket_name}"
        files_info = self.request('get', bucket_endpoint)
        file_list = [file_data["name"] for file_data in files_info["rows"]]
        report_files_list = []
        for file_name in file_list:
            if file_name.startswith(report_archive_prefix) and "excel_report" not in file_name:
                report_files_list.append(file_name)
        test_log_file_path, errors_log_file_path = self.download_and_merge_reports(report_files_list, lg_type,
                                                                                   bucket_name, extract_to)

        return report_info, test_log_file_path, errors_log_file_path
```

## Helper Methods

```python
Helper: request
    def request(self, method: str, endpoint: str, **kwargs) -> Any:
        full_url = f"{self.credentials.url.rstrip('/')}/{endpoint.lstrip('/')}"
        response = self.session.request(method, full_url, **kwargs)
        try:
            response.raise_for_status()  # This will raise for 4xx/5xx
        except requests.HTTPError as http_err:
            # Log or parse potential HTML in response.text
            logger.error(f"HTTP {response.status_code} error: {response.text[:500]}")  # short snippet
            raise CarrierAPIError(f"Request to {full_url} failed with status {response.status_code}")

        # If the response is JSON, parse it. If it’s HTML or something else, handle gracefully
        try:
            return response.json()
        except json.JSONDecodeError:
            # Possibly HTML error or unexpected format
            logger.error(f"Response was not valid JSON. Body:\n{response.text[:500]}")
            raise CarrierAPIError("Server returned non-JSON response")
```

```python
Helper: download_and_merge_reports
    def download_and_merge_reports(self, report_files_list: list, lg_type: str, bucket: str, extract_to: str = "/tmp"):
        if lg_type == "jmeter":
            summary_log_file_path = f"summary_{bucket}_jmeter.jtl"
            error_log_file_path = f"error_{bucket}_jmeter.log"
        else:
            summary_log_file_path = f"summary_{bucket}_simulation.log"
            error_log_file_path = f"error_{bucket}_simulation.log"
        extracted_reports = []
        for each in report_files_list:
            endpoint = f"api/v1/artifacts/artifact/{self.credentials.project_id}/{bucket}/{each}"
            response = self.session.get(f"{self.credentials.url}/{endpoint}")
            local_file_path = f"{extract_to}/{each}"
            with open(local_file_path, 'wb') as f:
                f.write(response.content)

            extract_dir = f"{local_file_path.replace('.zip', '')}"
            try:
                shutil.rmtree(extract_dir)
            except Exception as e:
                logger.error(e)
            import zipfile
            with zipfile.ZipFile(local_file_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            import os
            if os.path.exists(local_file_path):
                os.remove(local_file_path)
            extracted_reports.append(extract_dir)

        # get files from extract_dirs and merge to summary_log_file_path and error_log_file_path
        self.merge_log_files(summary_log_file_path, extracted_reports, lg_type)
        try:
            self.merge_error_files(error_log_file_path, extracted_reports)
        except Exception as e:
            logger.error(f"Failed to merge errors log: {e}")

        # Clean up
        for each in extracted_reports:
            try:
                shutil.rmtree(each)
            except Exception as e:
                logger.error(e)

        return summary_log_file_path, error_log_file_path
```
