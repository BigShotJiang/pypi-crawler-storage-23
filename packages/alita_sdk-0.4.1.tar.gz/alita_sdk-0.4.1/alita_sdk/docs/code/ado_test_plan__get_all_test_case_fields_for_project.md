# ado_test_plan - get_all_test_case_fields_for_project

**Toolkit**: `ado_test_plan`
**Method**: `get_all_test_case_fields_for_project`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_all_test_case_fields_for_project(self, force_refresh: bool = False) -> str:
        """
        Get formatted information about available Test Case fields and their metadata.
        This method helps discover which fields are required for Test Case creation.
        Delegates to the work_item wrapper's get_work_item_type_fields method.

        Args:
            force_refresh: If True, reload field definitions from Azure DevOps instead of using cache.
                          Use this if project configuration has changed (new fields added, etc.).

        Returns:
            Formatted string with field names, types, and requirements
        """
        # Use the class-level work_item wrapper instance
        return self._work_item_wrapper.get_work_item_type_fields(work_item_type="Test Case", force_refresh=force_refresh)
```
