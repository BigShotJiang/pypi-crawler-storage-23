# carrier - clean_file_name

**Toolkit**: `carrier`
**Method**: `clean_file_name`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
            def clean_file_name(file_name):
                # Extract JSON files only and clean the names
                if file_name.endswith('.json'):
                    return file_name
                return None
```
