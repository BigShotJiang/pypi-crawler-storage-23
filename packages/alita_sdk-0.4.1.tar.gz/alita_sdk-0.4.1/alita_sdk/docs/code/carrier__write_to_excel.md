# carrier - write_to_excel

**Toolkit**: `carrier`
**Method**: `write_to_excel`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def write_to_excel(self, results, carrier_report, thresholds, report_percentile):
        results["carrier_report"] = carrier_report
        try:
            results["build_status"], results["justification"] = self.get_build_status_and_justification(thresholds,
                                                                                                    report_percentile)
        except Exception as e:
            print(e)
            results["build_status"], results["justification"] = "SUCCESS", ""
        wb = Workbook()
        ws = wb.active
        ws.title = "Test results"

        requests_filtered = results["requests"]

        self.write_title_above_headers(self.title, results, self.header, ws)

        content_start, content_end = None, None
        for i, (header_field_name, header_key) in enumerate(self.header.items()):
            header_cell = ws.cell(row=len(self.title) + 1, column=i + 1,
                                  value=header_field_name)  # i + 1 because excel index starts from 1
            header_cell.alignment = Alignment(horizontal="center")
            border_style = Side(border_style="thin", color="040404")
            header_cell.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
            header_cell.fill = PatternFill("solid", fgColor='007FD5D8')

            if not content_start:
                content_start = get_column_letter(header_cell.column) + str(header_cell.row)

            need_cond_format = header_key in ['min', 'average', '95Pct', 'max', '90Pct']
            start_cell_for_formatting, end_cell_for_formatting = None, None
            for j, req_info in enumerate(requests_filtered.values()):
                if need_cond_format:
                    cur_cell = ws.cell(row=j + len(self.title) + 2, column=i + 1,
                                       value=round(req_info[header_key] / 1000, 3))
                    if start_cell_for_formatting is None:
                        start_cell_for_formatting = cur_cell
                    end_cell_for_formatting = cur_cell
                else:
                    cur_cell = ws.cell(row=j + len(self.title) + 2, column=i + 1, value=req_info[header_key])
                border_style = Side(border_style="thin", color="040404")
                cur_cell.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
                if header_key == 'Error%':
                    cur_cell.number_format = '0.00%'
                content_end = get_column_letter(cur_cell.column) + str(cur_cell.row)

            if need_cond_format:
                start_col = get_column_letter(start_cell_for_formatting.column)
                start_row = start_cell_for_formatting.row
                end_col = get_column_letter(end_cell_for_formatting.column)
                end_row = end_cell_for_formatting.row
                coords = start_col + str(start_row) + ':' + end_col + str(end_row)
                try:
                    rt_threshold = float(self.get_response_threshold(thresholds))
                except Exception as e:
                    print(e)
                    rt_threshold = 0
                if rt_threshold > 1:
                    threshold = rt_threshold/1000
                else:
                    threshold = rt_threshold

                ws.conditional_formatting.add(coords,
                                              CellIsRule(operator='lessThan', formula=[threshold], fill=GREEN_FILL))
                ws.conditional_formatting.add(coords, CellIsRule(operator='greaterThan', formula=[threshold * 1.5],
                                                                 fill=RED_FILL))
                ws.conditional_formatting.add(coords,
                                              CellIsRule(operator='between', formula=[threshold, threshold * 1.5],
                                                         fill=YELLOW_FILL))

                # column width adjusted
        for i, key in enumerate(self.header):
            length = len(str(key))
            ws.column_dimensions[get_column_letter(i + 1)].width = length + 5

        first_column_length = max(len(str(cell.value)) for cell in ws["A"])
        ws.column_dimensions[get_column_letter(1)].width = first_column_length + 5

        ws.auto_filter.ref = content_start + ":" + content_end

        # horizontal and vertical freeze
        freezen_area = ws['B' + str(len(self.title) + 2)]
        ws.freeze_panes = freezen_area
        print(f"Excel path: {self.report_path}")
        wb.save(self.report_path)
```
