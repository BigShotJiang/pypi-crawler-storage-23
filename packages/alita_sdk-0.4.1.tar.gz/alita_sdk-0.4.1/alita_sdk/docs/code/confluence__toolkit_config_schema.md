# confluence - toolkit_config_schema

**Toolkit**: `confluence`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `ConfluenceToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in
                          ConfluenceAPIWrapper.model_construct().get_available_tools()}

        @check_connection_response
        def check_connection(self):
            # Normalize base URL and construct API endpoint
            normalized_url = self.base_url.rstrip('/')
            cloud = getattr(self, 'cloud', True)

            # For cloud instances, ensure /wiki is present in the API path
            # Self-hosted instances may use different paths (e.g., /confluence)
            if cloud:
                # Check if base_url already includes /wiki
                if normalized_url.endswith('/wiki'):
                    url = normalized_url + '/rest/api/space'
                else:
                    url = normalized_url + '/wiki/rest/api/space'
            else:
                # For self-hosted, append /rest/api/space directly
                url = normalized_url + '/rest/api/space'

            headers = {'Accept': 'application/json'}
            auth = None
            confluence_config = self.confluence_configuration or {}
            token = confluence_config.get('token')
            username = confluence_config.get('username')
            api_key = confluence_config.get('api_key')

            if token:
                headers['Authorization'] = f'Bearer {token}'
            elif username and api_key:
                auth = (username, api_key)
            else:
                raise ValueError('Confluence connection requires either token or username+api_key')
            response = requests.get(url, headers=headers, auth=auth, timeout=5, verify=getattr(self, 'verify_ssl', True))
            return response

        model = create_model(
            name,
            space=(str, Field(description="Space")),
            cloud=(bool, Field(description="Hosting Option", json_schema_extra={'configuration': True})),
            limit=(int, Field(description="Pages limit per request", default=5, gt=0)),
            labels=(Optional[str], Field(
                description="List of comma separated labels used for labeling of agent's created or updated entities",
                default=None,
                examples="alita,elitea;another-label"
            )),
            max_pages=(int, Field(description="Max total pages", default=10, gt=0)),
            number_of_retries=(int, Field(description="Number of retries", default=2, ge=0)),
            min_retry_seconds=(int, Field(description="Min retry, sec", default=10, ge=0)),
            max_retry_seconds=(int, Field(description="Max retry, sec", default=60, ge=0)),
            # optional field for custom headers as dictionary
            custom_headers=(Optional[dict], Field(description="Custom headers for API requests", default={})),
            confluence_configuration=(ConfluenceConfiguration, Field(description="Confluence Configuration", json_schema_extra={'configuration_types': ['confluence']})),
            pgvector_configuration=(Optional[PgVectorConfiguration], Field(default = None,
                                                                           description="PgVector Configuration",
                                                                           json_schema_extra={'configuration_types': ['pgvector']})),
            # embedder settings
            embedding_model=(Optional[str], Field(default=None, description="Embedding configuration.", json_schema_extra={'configuration_model': 'embedding'})),

            selected_tools=(List[Literal[tuple(selected_tools)]],
                            Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__=ConfigDict(json_schema_extra={
                'metadata': {
                    "label": "Confluence",
                    "icon_url": None,
                    "categories": ["documentation"],
                    "extra_categories": ["confluence", "wiki", "knowledge base", "documentation", "atlassian"]
                }
            })
        )
        model.check_connection = check_connection
        return model
```
