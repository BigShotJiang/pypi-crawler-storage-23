# custom_open_api - get_tools

**Toolkit**: `custom_open_api`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `OpenApiToolkit`

---

## Method Implementation

```python
    def get_tools(self) -> list[BaseTool]:
        return self.tools
```
