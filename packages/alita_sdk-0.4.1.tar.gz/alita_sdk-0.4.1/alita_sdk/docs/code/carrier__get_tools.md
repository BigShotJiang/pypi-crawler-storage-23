# carrier - get_tools

**Toolkit**: `carrier`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AlitaCarrierToolkit`

---

## Method Implementation

```python
    def get_tools(self) -> List[BaseTool]:
        logger.info(f"[AlitaCarrierToolkit] Retrieving {len(self.tools)} initialized tools")
        return self.tools
```
