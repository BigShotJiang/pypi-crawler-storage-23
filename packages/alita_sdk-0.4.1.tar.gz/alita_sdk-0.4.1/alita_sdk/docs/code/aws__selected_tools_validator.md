# aws - selected_tools_validator

**Toolkit**: `aws`
**Method**: `selected_tools_validator`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkitConfig`

---

## Method Implementation

```python
    def selected_tools_validator(cls, value: List[str]) -> list[str]:
        return [i for i in value if i in get_available_tools()]
```

## Helper Methods

```python
Helper: get_available_tools
def get_available_tools() -> dict[str, dict]:
    api_wrapper = DeltaLakeApiWrapper.model_construct()
    available_tools: dict = {
        x["name"]: x["args_schema"].model_json_schema()
        for x in api_wrapper.get_available_tools()
    }
    return available_tools
```
