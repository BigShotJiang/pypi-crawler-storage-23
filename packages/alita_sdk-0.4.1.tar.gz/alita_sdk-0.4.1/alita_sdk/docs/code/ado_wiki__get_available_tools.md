# ado_wiki - get_available_tools

**Toolkit**: `ado_wiki`
**Method**: `get_available_tools`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        """Return a list of available tools."""
        # Add default wiki identifier info to descriptions if configured
        default_wiki_info = f"\nDefault wiki: {self.default_wiki_identifier}" if self.default_wiki_identifier else ""

        return [
            {
                "name": "get_wiki",
                "description": (self.get_wiki.__doc__ or "") + default_wiki_info,
                "args_schema": GetWikiInput,
                "ref": self.get_wiki,
            },
            {
                "name": "get_wiki_page",
                "description": (self.get_wiki_page.__doc__ or "") + default_wiki_info,
                "args_schema": GetPageInput,
                "ref": self.get_wiki_page,
            },
            {
                "name": "get_wiki_page_by_path",
                "description": (self.get_wiki_page_by_path.__doc__ or "") + default_wiki_info,
                "args_schema": GetPageByPathInput,
                "ref": self.get_wiki_page_by_path,
            },
            {
                "name": "get_wiki_page_by_id",
                "description": (self.get_wiki_page_by_id.__doc__ or "") + default_wiki_info,
                "args_schema": GetPageByIdInput,
                "ref": self.get_wiki_page_by_id,
            },
            {
                "name": "delete_page_by_path",
                "description": (self.delete_page_by_path.__doc__ or "") + default_wiki_info,
                "args_schema": GetPageByPathInput,
                "ref": self.delete_page_by_path,
            },
            {
                "name": "delete_page_by_id",
                "description": (self.delete_page_by_id.__doc__ or "") + default_wiki_info,
                "args_schema": GetPageByIdInput,
                "ref": self.delete_page_by_id,
            },
            {
                "name": "modify_wiki_page",
                "description": (self.modify_wiki_page.__doc__ or "") + default_wiki_info,
                "args_schema": ModifyPageInput,
                "ref": self.modify_wiki_page,
            },
            {
                "name": "rename_wiki_page",
                "description": (self.rename_wiki_page.__doc__ or "") + default_wiki_info,
                "args_schema": RenamePageInput,
                "ref": self.rename_wiki_page,
            }
        ]
```
