# figma - get_file_nodes

**Toolkit**: `figma`
**Method**: `get_file_nodes`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_file_nodes(self, file_key: str, ids: str, **kwargs):
        """Reads a specified file nodes by field key from Figma."""
        return self._client.api_request(
            f"files/{file_key}/nodes?ids={str(ids)}", method="get"
        )
```
