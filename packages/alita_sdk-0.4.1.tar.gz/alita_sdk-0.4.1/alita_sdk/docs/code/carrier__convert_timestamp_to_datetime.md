# carrier - convert_timestamp_to_datetime

**Toolkit**: `carrier`
**Method**: `convert_timestamp_to_datetime`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def convert_timestamp_to_datetime(timestamp: int) -> datetime:
        """Converts a timestamp to a human-readable datetime object."""
        return datetime.fromtimestamp(timestamp / 1000.0)
```
