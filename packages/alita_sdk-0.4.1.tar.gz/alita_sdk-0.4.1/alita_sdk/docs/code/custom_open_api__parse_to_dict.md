# custom_open_api - parse_to_dict

**Toolkit**: `custom_open_api`
**Method**: `parse_to_dict`
**Source File**: `api_wrapper.py`

---

## Method Implementation

```python
def parse_to_dict(input_string):
    try:
        # Try parsing it directly first, in case the string is already in correct JSON format
        parsed_dict = json.loads(input_string)
    except json.JSONDecodeError:
        # If that fails, replace single quotes with double quotes
        # and escape existing double quotes
        try:
            # This will convert single quotes to double quotes and escape existing double quotes
            adjusted_string = input_string.replace('\'', '\"').replace('\"', '\\\"')
            # If the above line replaces already correct double quotes, we correct them back
            adjusted_string = adjusted_string.replace('\\\"{', '\"{').replace('}\\\"', '}\"')
            # Now try to parse the adjusted string
            parsed_dict = json.loads(adjusted_string)
        except json.JSONDecodeError as e:
            # Handle any JSON errors
            print("JSON decode error:", e)
            return None
    return parsed_dict
```
