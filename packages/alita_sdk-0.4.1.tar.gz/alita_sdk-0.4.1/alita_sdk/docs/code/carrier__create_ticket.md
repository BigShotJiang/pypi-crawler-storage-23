# carrier - create_ticket

**Toolkit**: `carrier`
**Method**: `create_ticket`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def create_ticket(self, ticket_data: Dict[str, Any]) -> Dict[str, Any]:
        endpoint = f"api/v1/issues/issues/{self.credentials.project_id}"
        logger.info(f"ENDPOINT: {endpoint}")
        response = self.request('post', endpoint, json=ticket_data)

        # Optionally check for successful creation:
        # Some APIs return status=201, or an `item` field in JSON
        if not response or "item" not in response:
            # We expected "item" in the response
            logger.warning(f"Unexpected response: {response}")
            raise CarrierAPIError("Carrier did not return a valid ticket response")

        # Return the entire JSON so the tool can parse "id", "hash_id", or others
        return response
```

## Helper Methods

```python
Helper: request
    def request(self, method: str, endpoint: str, **kwargs) -> Any:
        full_url = f"{self.credentials.url.rstrip('/')}/{endpoint.lstrip('/')}"
        response = self.session.request(method, full_url, **kwargs)
        try:
            response.raise_for_status()  # This will raise for 4xx/5xx
        except requests.HTTPError as http_err:
            # Log or parse potential HTML in response.text
            logger.error(f"HTTP {response.status_code} error: {response.text[:500]}")  # short snippet
            raise CarrierAPIError(f"Request to {full_url} failed with status {response.status_code}")

        # If the response is JSON, parse it. If it’s HTML or something else, handle gracefully
        try:
            return response.json()
        except json.JSONDecodeError:
            # Possibly HTML error or unexpected format
            logger.error(f"Response was not valid JSON. Body:\n{response.text[:500]}")
            raise CarrierAPIError("Server returned non-JSON response")
```
