# ado - parse_pull_request_comments

**Toolkit**: `ado`
**Method**: `parse_pull_request_comments`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def parse_pull_request_comments(
            self, comment_threads: List[GitPullRequestCommentThread]
    ) -> List[dict]:
        """
        Extracts comments from each comment thread and puts them in a dictionary.

        Parameters:
            comment_threads (List[GitPullRequestCommentThread]): A list of comment threads associated with a pull request.

        Returns:
            List[dict]: A list of dictionaries with comment details.
        """
        parsed_comments = []
        for thread in comment_threads:
            for comment in thread.comments:
                parsed_comments.append(
                    {
                        "id": comment.id,
                        "author": comment.author.display_name,
                        "content": comment.content,
                        "published_date": comment.published_date.strftime(
                            "%Y-%m-%d %H:%M:%S %Z"
                        )
                        if comment.published_date
                        else None,
                        "status": thread.status if thread.status else None,
                    }
                )
        return parsed_comments
```
