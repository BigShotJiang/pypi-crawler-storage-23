# ado_repos - check_connection

**Toolkit**: `ado_repos`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsReposToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            ado_config = self.ado_configuration
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/git/repositories/{self.repository_id}?api-version=7.0',
                headers = {'Authorization': f'Bearer {ado_config.token.get_secret_value() if ado_config.token else ""}'},
                timeout=5
            )
            return response
```
