"""hdx server — create and develop MCP servers."""

import click

from hatchdx.cli.init_cmd import init_cmd
from hatchdx.cli.test_cmd import test_cmd
from hatchdx.cli.dev_cmd import dev_cmd
from hatchdx.cli.sandbox_cmd import sandbox_cmd
from hatchdx.cli.validate_cmd import validate_cmd
from hatchdx.cli.eval_cmd import eval_cmd


@click.group("server")
def server_cmd():
    """Create and develop MCP servers."""


server_cmd.add_command(init_cmd, "create")
server_cmd.add_command(test_cmd)
server_cmd.add_command(dev_cmd)
server_cmd.add_command(sandbox_cmd)
server_cmd.add_command(validate_cmd)
server_cmd.add_command(eval_cmd)
