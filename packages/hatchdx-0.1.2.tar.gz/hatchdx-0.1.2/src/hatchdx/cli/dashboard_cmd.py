"""hdx dashboard — start the web dashboard."""

import asyncio

import click


@click.command("dashboard")
@click.option("--port", default=4320, help="Port to run the dashboard on.")
@click.option("--no-open", is_flag=True, help="Don't open the browser automatically.")
def dashboard_cmd(port: int, no_open: bool) -> None:
    """Start the HatchDX web dashboard."""
    from hatchdx.utils.console import console

    console.print("\n  [bold]hdx dashboard[/bold]")
    console.print(f"  Starting on port {port}...\n")

    from hatchdx.dashboard.server import run_server

    try:
        asyncio.run(run_server(port=port, open_browser=not no_open))
    except KeyboardInterrupt:
        console.print("\n  Dashboard stopped.")
