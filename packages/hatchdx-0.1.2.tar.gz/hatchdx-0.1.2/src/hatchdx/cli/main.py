import click
from hatchdx import __version__
from hatchdx.cli.server_cmd import server_cmd
from hatchdx.cli.dashboard_cmd import dashboard_cmd
from hatchdx.cli.agent_cmd import agent_cmd
from hatchdx.cli.workspace_cmd import workspace_init_cmd


@click.group()
@click.version_option(version=__version__, prog_name="hdx")
def cli():
    """HatchDX — the DX-first platform for agentic engineering."""


cli.add_command(workspace_init_cmd)
cli.add_command(server_cmd)
cli.add_command(dashboard_cmd)
cli.add_command(agent_cmd)
