"""Data models for the MCP test harness."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class TestExpectation:
    """What we expect from a tool call result."""

    status: str | None = None  # "success" or "error"
    is_error: bool | None = None
    schema: dict[str, Any] | None = None  # JSON Schema to validate against
    content_contains: str | None = None
    content_not_contains: str | None = None
    max_latency_ms: int | None = None


@dataclass
class TestCase:
    """A single test case loaded from a YAML fixture."""

    name: str
    tool: str
    input: dict[str, Any]
    expect: TestExpectation


@dataclass
class TestResult:
    """The outcome of running a single test case."""

    test_case: TestCase
    passed: bool
    actual_response: dict[str, Any]
    latency_ms: float
    failure_reason: str | None = None