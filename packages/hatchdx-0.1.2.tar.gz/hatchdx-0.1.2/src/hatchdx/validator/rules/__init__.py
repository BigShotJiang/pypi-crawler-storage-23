"""Import all rule modules to trigger registration via decorators."""

from hatchdx.validator.rules import (
    annotations,
    errors,
    naming,
    pagination,
    response,
    schema,
)

__all__ = [
    "annotations",
    "errors",
    "naming",
    "pagination",
    "response",
    "schema",
]
