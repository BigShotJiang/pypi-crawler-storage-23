"""HatchDX agent engine — scaffold, wire, and run AI agents with MCP servers."""

from hatchdx.agent.config import (
    AgentConfig,
    AgentSettings,
    ModelConfig,
    ServerConfig,
    ToolFilterConfig,
    load_agent_config,
)
from hatchdx.agent.engine import AgentEngine, AgentError, create_provider, estimate_cost_for_provider
from hatchdx.agent.runtime.loop import (
    LoopResult,
    LoopTurn,
    ToolCallEvent,
    ToolCallLoopError,
)
from hatchdx.agent.runtime.servers import (
    ManagedServer,
    ServerConnectionError,
    ServerManager,
)
from hatchdx.agent.runtime.tools import (
    CollectedTools,
    ToolCollisionError,
    ToolDefinition,
    ToolFilterError,
    ToolRoute,
    collect_and_filter_tools,
)

__all__ = [
    "AgentConfig",
    "AgentEngine",
    "AgentError",
    "AgentSettings",
    "CollectedTools",
    "LoopResult",
    "LoopTurn",
    "ManagedServer",
    "ModelConfig",
    "ServerConfig",
    "ServerConnectionError",
    "ServerManager",
    "ToolCallEvent",
    "ToolCallLoopError",
    "ToolCollisionError",
    "ToolDefinition",
    "ToolFilterConfig",
    "ToolFilterError",
    "ToolRoute",
    "collect_and_filter_tools",
    "create_provider",
    "estimate_cost_for_provider",
    "load_agent_config",
]
