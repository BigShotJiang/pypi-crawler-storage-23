"""Model provider protocol — defines the interface all providers must implement."""

from dataclasses import dataclass, field
from typing import Protocol

from hatchdx import HdxError


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ProviderError(HdxError):
    """Model provider returned an error."""


class ProviderAuthError(ProviderError):
    """Missing or invalid API key for a model provider."""


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class ToolCall:
    """A model's request to call a tool."""

    id: str
    name: str
    arguments: dict


@dataclass
class ToolResult:
    """Result of executing a tool call."""

    tool_call_id: str
    content: str
    is_error: bool = False


@dataclass
class AgentResponse:
    """A single response from the model."""

    text: str | None
    tool_calls: list[ToolCall] = field(default_factory=list)
    stop_reason: str = "end_turn"
    usage: dict = field(default_factory=lambda: {"input": 0, "output": 0})


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


class ModelProvider(Protocol):
    """Interface all model providers must implement."""

    async def chat(
        self,
        messages: list[dict],
        tools: list[dict],
        system: str,
        max_tokens: int,
        temperature: float,
    ) -> AgentResponse: ...
