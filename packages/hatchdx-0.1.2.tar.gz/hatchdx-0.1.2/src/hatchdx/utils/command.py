"""Shared command resolution utilities for CLI commands."""

from __future__ import annotations

import platform
import shlex
from pathlib import Path


def resolve_command(raw_command: str) -> list[str]:
    """Parse *raw_command* and resolve ``python`` to the project's venv if one exists."""
    parts = shlex.split(raw_command)
    if not parts:
        return parts

    # If the command starts with "python", check for a local venv
    if parts[0] in ("python", "python3"):
        if platform.system() == "Windows":
            venv_python = Path(".venv/Scripts/python.exe")
        else:
            venv_python = Path(".venv/bin/python")

        if venv_python.is_file():
            parts[0] = str(venv_python.absolute())

    return parts
