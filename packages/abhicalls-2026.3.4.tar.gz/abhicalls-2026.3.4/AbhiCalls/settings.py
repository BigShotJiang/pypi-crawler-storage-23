class Settings:
    def __init__(self):
        # ==========================
        # YOUTUBE
        # ==========================
        self.cookies: str | None = None
        self.require_cookies: bool = True

        # ==========================
        # DEBUG
        # ==========================
        self.debug: bool = False

        # ==========================
        # MESSAGE BEHAVIOUR
        # ==========================
        self.auto_delete_queue: bool = True
        self.auto_delete_nowplaying: bool = True

        # ==========================
        # ENGINE
        # ==========================
        self.default_volume: int = 200

        # ==========================
        # FUTURE SAFETY SWITCH
        # ==========================
        self.experimental: bool = False

    # ==========================
    # DEBUG PRINT
    # ==========================
    def __repr__(self):
        return (
            f"<Settings debug={self.debug} "
            f"cookies={'Yes' if self.cookies else 'No'} "
            f"require_cookies={self.require_cookies}>"
        )


settings = Settings()
