import requests
from colorama import init, Fore
from AbhiCalls import __version__, __author__

init(autoreset=True)


def check_latest_version(pkg_name="AbhiCalls"):
    try:
        r = requests.get(f"https://pypi.org/pypi/{pkg_name}/json", timeout=3)
        if r.status_code == 200:
            return r.json()["info"]["version"]
        print(f"[Startup] PyPI bad status → {r.status_code}")
    except Exception as e:
        print(f"[Startup] version check failed → {e}")

    return None


def print_startup_message():
    print(Fore.GREEN + "✅ AbhiCalls started\n")

    print(Fore.CYAN + f"Version  : {__version__}")
    print(Fore.CYAN + f"Author   : {__author__}")
    print(Fore.CYAN + "License  : Abhishek Special")
    print(Fore.CYAN + "GitHub   : https://github.com/YouTubeMusicAPI/AbhiCalls")
    print(Fore.CYAN + "Telegram : https://t.me/WhyAbhishek")

    print(Fore.CYAN + "\nChecking updates...")

    latest = check_latest_version("AbhiCalls")

    if not latest:
        print(Fore.YELLOW + "Could not check latest version (offline or PyPI issue)")
        return

    if latest != __version__:
        print(Fore.YELLOW + f"Update Available → v{latest}")
    else:
        print(Fore.GREEN + "You are using the latest version!")
