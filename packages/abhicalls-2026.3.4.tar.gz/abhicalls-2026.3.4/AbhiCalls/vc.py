from AbhiCalls._engine.native import _NativeEngine
from AbhiCalls.controller import VoiceController


class VoiceEngine:
    def __init__(self, app, cookies: str | None = None):
        print("[VoiceEngine] init")

        try:
            self._engine = _NativeEngine(app)
            self.vc = VoiceController(self._engine, cookies=cookies)

            print("[VoiceEngine] controller attached")

        except Exception as e:
            raise Exception(f"[VoiceEngine:Init] {e}")

    async def start(self):
        try:
            await self._engine.start()
            print("[VoiceEngine] started")
        except Exception as e:
            raise Exception(f"[VoiceEngine:Start] {e}")
