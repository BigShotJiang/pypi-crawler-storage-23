# AbhiCalls

AbhiCalls is a Telegram Voice Chat Music Engine built on top of PyTgCalls.

## Features
- Play audio in Telegram voice chats
- Queue management
- Skip, pause, resume
- Loop and ETA support

## Installation
```bash
pip install abhicalls

