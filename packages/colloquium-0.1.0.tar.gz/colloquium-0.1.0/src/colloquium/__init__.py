"""Colloquium — agent-native slide creation tool for research talks."""

__version__ = "0.1.0"

from colloquium.slide import Slide
from colloquium.deck import Deck

__all__ = ["Slide", "Deck", "__version__"]
