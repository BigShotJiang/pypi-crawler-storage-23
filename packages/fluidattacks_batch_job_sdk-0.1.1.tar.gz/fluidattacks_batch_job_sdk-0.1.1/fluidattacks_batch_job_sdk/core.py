"""Domain types and API client interface for AWS Batch job executions."""

from collections.abc import (
    Callable,
)
from dataclasses import (
    dataclass,
)
from enum import (
    Enum,
)

from fa_purity import (
    Cmd,
    FrozenList,
    Maybe,
    ResultE,
)
from fa_purity.date_time import (
    DatetimeUTC,
)


@dataclass(frozen=True)
class QueueName:
    """Opaque wrapper for an AWS Batch queue name string."""

    value: str


class TerminalJobStatus(Enum):
    """Possible terminal statuses for an AWS Batch job."""

    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


@dataclass(frozen=True)
class JobItem:
    """Internal representation of a single AWS Batch job."""

    name: str
    created_at: DatetimeUTC
    status: TerminalJobStatus
    status_reason: Maybe[str]
    started_at: Maybe[DatetimeUTC]
    stopped_at: DatetimeUTC


@dataclass(frozen=True)
class ApiClient:
    """Functional interface for the AWS Batch API."""

    list_queues: Cmd[FrozenList[QueueName]]
    list_jobs: Callable[[QueueName, DatetimeUTC], Cmd[ResultE[FrozenList[JobItem]]]]
