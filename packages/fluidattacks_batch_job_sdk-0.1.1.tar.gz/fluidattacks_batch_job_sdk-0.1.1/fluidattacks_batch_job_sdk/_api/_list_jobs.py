"""Fetch AWS Batch jobs for a queue filtered by date range."""

from __future__ import annotations

from typing import TYPE_CHECKING

from fa_purity import (
    Cmd,
    FrozenList,
    Maybe,
    PureIterFactory,
    Result,
    ResultE,
    StreamTransform,
    cast_exception,
)
from fluidattacks_etl_utils.paginate import cursor_pagination

if TYPE_CHECKING:
    from logging import Logger

    from fa_purity.date_time import DatetimeUTC
    from mypy_boto3_batch import BatchClient
    from mypy_boto3_batch.type_defs import KeyValuesPairTypeDef, ListJobsResponseTypeDef

    from fluidattacks_batch_job_sdk.core import JobItem, QueueName

from fluidattacks_batch_job_sdk._api._decode import decode_job


def _get_jobs_page(
    client: BatchClient,
    queue: QueueName,
    before: DatetimeUTC,
    next_token: Maybe[str],
) -> Cmd[ListJobsResponseTypeDef]:
    def _run() -> ListJobsResponseTypeDef:
        to_ts = str(int(before.date_time.timestamp() * 1000))
        filters: list[KeyValuesPairTypeDef] = [{"name": "BEFORE_CREATED_AT", "values": [to_ts]}]
        token = next_token.value_or(None)
        if token:
            return client.list_jobs(
                jobQueue=queue.value,
                maxResults=100,
                filters=filters,
                nextToken=token,
            )
        return client.list_jobs(
            jobQueue=queue.value,
            maxResults=100,
            filters=filters,
        )

    return Cmd.wrap_impure(_run)


def _decode_page(
    resp: ListJobsResponseTypeDef,
    log: Logger,
    queue: QueueName,
) -> tuple[FrozenList[JobItem], Maybe[str]]:
    raw_jobs = resp.get("jobSummaryList", [])
    jobs = tuple(
        item for j in raw_jobs for item in (decode_job(j).value_or(None),) if item is not None
    )
    log.info(
        "Decoded %d terminal jobs queue=%s",
        len(jobs),
        queue.value,
    )
    return jobs, Maybe.from_optional(resp.get("nextToken"))


def _fetch_jobs(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    before: DatetimeUTC,
) -> Cmd[FrozenList[JobItem]]:
    return (
        cursor_pagination(
            lambda next_token: (
                Cmd.wrap_impure(lambda: log.info("Fetching page queue=%s", queue.value))
                + _get_jobs_page(client, queue, before, next_token).map(
                    lambda resp: _decode_page(resp, log, queue)
                )
            )
        )
        .transform(lambda s: StreamTransform.chain(s.map(PureIterFactory.from_list)))
        .to_list()
        .map(tuple)
    )


def list_jobs(
    client: BatchClient,
    log: Logger,
    queue: QueueName,
    before: DatetimeUTC,
) -> Cmd[ResultE[FrozenList[JobItem]]]:
    """Fetch all terminal jobs for a queue created before the given date."""
    log_start = Cmd.wrap_impure(
        lambda: log.info("Fetching jobs queue=%s before=%s", queue.value, before)
    )
    return log_start + _fetch_jobs(client, log, queue, before).bind(
        lambda jobs: (
            Cmd.wrap_impure(
                lambda: log.info("Fetched %d total jobs queue=%s", len(jobs), queue.value)
            )
            + Cmd.wrap_impure(lambda: Result.success(jobs).alt(cast_exception))
        )
    )
