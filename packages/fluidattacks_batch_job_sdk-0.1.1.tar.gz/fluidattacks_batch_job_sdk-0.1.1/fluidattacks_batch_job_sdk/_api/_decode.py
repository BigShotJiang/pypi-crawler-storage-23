"""Decode AWS Batch API responses into domain types."""

from __future__ import annotations

import inspect
from datetime import UTC, datetime
from typing import TYPE_CHECKING, TypeVar

from fa_purity import Maybe, Result, ResultE, cast_exception
from fa_purity.date_time import DatetimeUTC
from fluidattacks_etl_utils.bug import Bug

if TYPE_CHECKING:
    from mypy_boto3_batch.type_defs import JobSummaryTypeDef

from fluidattacks_batch_job_sdk.core import JobItem, TerminalJobStatus

_T = TypeVar("_T")


def _require(value: _T | None) -> ResultE[_T]:
    if value is None:
        return Result.failure(ValueError("Expected non-None value")).alt(cast_exception)
    return Result.success(value)


def _epoch_ms_to_utc(ms: int) -> DatetimeUTC:
    raw = datetime.fromtimestamp(ms / 1000, tz=UTC)
    return Bug.assume_success(
        "_epoch_ms_to_utc",
        inspect.currentframe(),
        (),
        DatetimeUTC.assert_utc(raw),
    )


def _decode_status(raw: str) -> ResultE[TerminalJobStatus]:
    try:
        return Result.success(TerminalJobStatus(raw))
    except ValueError as e:
        return Result.failure(e).alt(cast_exception)


def decode_job(raw: JobSummaryTypeDef) -> ResultE[JobItem]:
    """Decode a JobSummaryTypeDef into a JobItem."""
    status_reason: Maybe[str] = Maybe.from_optional(raw.get("statusReason"))
    started_at: Maybe[DatetimeUTC] = Maybe.from_optional(raw.get("startedAt")).map(_epoch_ms_to_utc)
    return _require(raw.get("createdAt")).bind(
        lambda created: _require(raw.get("stoppedAt")).bind(
            lambda stopped: _require(raw.get("status")).bind(
                lambda status: _decode_status(status).map(
                    lambda s: JobItem(
                        name=raw["jobName"],
                        created_at=_epoch_ms_to_utc(created),
                        status=s,
                        status_reason=status_reason,
                        started_at=started_at,
                        stopped_at=_epoch_ms_to_utc(stopped),
                    )
                )
            )
        )
    )
