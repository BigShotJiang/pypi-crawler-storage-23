import logging
from datetime import UTC, datetime

import pytest
from fa_purity import Unsafe
from fa_purity.date_time import DatetimeUTC

from fluidattacks_batch_job_sdk._api import new_api_client
from fluidattacks_batch_job_sdk.core import QueueName

LOG = logging.getLogger(__name__)

_FLAGS_QUEUE = QueueName("flags")
_BEFORE = DatetimeUTC.assert_utc(datetime.now(tz=UTC)).alt(Unsafe.raise_exception).to_union()


def test_list_queues() -> None:
    cmd = new_api_client().bind(lambda c: c.list_queues)
    with pytest.raises(SystemExit):
        cmd.compute()


def test_list_jobs() -> None:
    cmd = new_api_client().bind(
        lambda c: c.list_jobs(_FLAGS_QUEUE, _BEFORE).map(
            lambda r: r.alt(Unsafe.raise_exception).to_union()
        )
    )
    with pytest.raises(SystemExit):
        cmd.compute()
