from datetime import UTC, datetime

from fa_purity import Maybe, Unsafe
from fa_purity.date_time import DatetimeUTC
from mypy_boto3_batch.type_defs import JobSummaryTypeDef

from fluidattacks_batch_job_sdk._api._decode import decode_job
from fluidattacks_batch_job_sdk.core import JobItem, TerminalJobStatus


def _ms_to_utc(ms: int) -> DatetimeUTC:
    raw = datetime.fromtimestamp(ms / 1000, tz=UTC)
    return DatetimeUTC.assert_utc(raw).alt(Unsafe.raise_exception).to_union()


def test_decode_succeeded_job() -> None:
    raw = JobSummaryTypeDef(
        jobId="abc-123",
        jobName="directs-static-scanner-poc_mygroup",
        createdAt=1740000000000,
        status="SUCCEEDED",
        statusReason="Essential container in task exited",
        startedAt=1740000010000,
        stoppedAt=1740000060000,
    )
    expected = JobItem(
        name="directs-static-scanner-poc_mygroup",
        created_at=_ms_to_utc(1740000000000),
        status=TerminalJobStatus.SUCCEEDED,
        status_reason=Maybe.some("Essential container in task exited"),
        started_at=Maybe.some(_ms_to_utc(1740000010000)),
        stopped_at=_ms_to_utc(1740000060000),
    )
    result = decode_job(raw).alt(Unsafe.raise_exception).to_union()
    assert result == expected


def test_decode_failed_job_no_start() -> None:
    """A job failed from RUNNABLE never reached RUNNING so startedAt is absent."""
    raw = JobSummaryTypeDef(
        jobId="def-456",
        jobName="directs-probes-poc_somegroup",
        createdAt=1740001000000,
        status="FAILED",
        statusReason="Host EC2 was terminated",
        stoppedAt=1740001500000,
    )
    expected = JobItem(
        name="directs-probes-poc_somegroup",
        created_at=_ms_to_utc(1740001000000),
        status=TerminalJobStatus.FAILED,
        status_reason=Maybe.some("Host EC2 was terminated"),
        started_at=Maybe.empty(),
        stopped_at=_ms_to_utc(1740001500000),
    )
    result = decode_job(raw).alt(Unsafe.raise_exception).to_union()
    assert result == expected


def test_decode_missing_stopped_at_fails() -> None:
    raw = JobSummaryTypeDef(
        jobId="xyz-789",
        jobName="directs-flags-poc_group",
        createdAt=1740002000000,
        status="SUCCEEDED",
        # stoppedAt intentionally omitted — NotRequired in TypedDict
    )
    assert decode_job(raw).value_or(None) is None


def test_decode_non_terminal_status_fails() -> None:
    raw = JobSummaryTypeDef(
        jobId="xyz-789",
        jobName="directs-flags-poc_group",
        createdAt=1740002000000,
        status="RUNNING",
        stoppedAt=1740002500000,
    )
    assert decode_job(raw).value_or(None) is None
