# Serializer

Module for JSON serialization/deserialization of IR.

::: torch_ir.serializer
