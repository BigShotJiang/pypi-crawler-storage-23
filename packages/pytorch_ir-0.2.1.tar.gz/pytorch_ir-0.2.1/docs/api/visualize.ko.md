# Visualize

IR 시각화 유틸리티 모듈입니다: `ir_to_mermaid`, `generate_op_distribution_pie`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/visualize.md)를 참조하세요.
