# Weight Loader

Module for loading weights from `.pt` and `.safetensors` files.

::: torch_ir.weight_loader
