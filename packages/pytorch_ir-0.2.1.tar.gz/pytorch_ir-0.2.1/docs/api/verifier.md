# Verifier

Module that verifies IR execution results against the original model output.

::: torch_ir.verifier
