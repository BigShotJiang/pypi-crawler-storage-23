# Executor

Module that executes IR graphs with actual weights.

::: torch_ir.executor
