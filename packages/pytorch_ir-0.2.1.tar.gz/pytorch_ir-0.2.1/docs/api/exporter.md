# Exporter

Module that wraps `torch.export` to export models.

::: torch_ir.exporter
