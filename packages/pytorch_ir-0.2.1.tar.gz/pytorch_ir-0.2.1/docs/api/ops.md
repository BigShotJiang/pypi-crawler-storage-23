# Ops

Operator registry and utility module.

::: torch_ir.ops
