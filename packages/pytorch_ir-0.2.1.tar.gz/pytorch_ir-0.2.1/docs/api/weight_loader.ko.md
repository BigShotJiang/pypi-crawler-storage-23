# Weight Loader

`.pt` 및 `.safetensors` 파일에서 weight를 로드하는 모듈입니다: `load_weights`, `WeightLoader`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/weight_loader.md)를 참조하세요.
