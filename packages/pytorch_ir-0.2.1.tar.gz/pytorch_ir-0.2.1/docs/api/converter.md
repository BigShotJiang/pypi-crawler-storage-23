# Converter

Module that converts `ExportedProgram` to `IR`.

::: torch_ir.converter
