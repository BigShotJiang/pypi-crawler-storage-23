# IR Data Structures

Core data structures that compose the IR graph.

::: torch_ir.ir
