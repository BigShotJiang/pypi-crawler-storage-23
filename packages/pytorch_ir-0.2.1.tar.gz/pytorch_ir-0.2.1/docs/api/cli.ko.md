# CLI

::: torch_ir.cli
    options:
      members:
        - create_parser
        - main
        - cmd_visualize
        - cmd_info
