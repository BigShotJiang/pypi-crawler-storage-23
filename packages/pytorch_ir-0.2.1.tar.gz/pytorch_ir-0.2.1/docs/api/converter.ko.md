# Converter

`ExportedProgram`을 `IR`로 변환하는 모듈입니다: `IRConverter`, `ConversionError`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/converter.md)를 참조하세요.
