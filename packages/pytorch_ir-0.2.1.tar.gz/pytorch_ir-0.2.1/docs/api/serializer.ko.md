# Serializer

IR의 JSON 직렬화/역직렬화를 담당하는 모듈입니다: `serialize_ir`, `save_ir`, `load_ir`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/serializer.md)를 참조하세요.
