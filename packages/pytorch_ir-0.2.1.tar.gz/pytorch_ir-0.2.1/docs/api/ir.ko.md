# IR 데이터 구조

IR 그래프를 구성하는 핵심 데이터 구조입니다: `TensorMeta`, `OpNode`, `IR`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/ir.md)를 참조하세요.
