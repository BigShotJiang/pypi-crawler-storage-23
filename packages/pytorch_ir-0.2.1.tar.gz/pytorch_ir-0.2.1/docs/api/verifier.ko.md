# Verifier

원본 모델 출력과 IR 실행 결과를 비교하여 검증하는 모듈입니다: `verify_ir`, `IRVerifier`.

!!! info
    API 문서는 소스 코드 docstring에서 자동 생성됩니다. 전체 API 레퍼런스는 [영문 페이지](../api/verifier.md)를 참조하세요.
