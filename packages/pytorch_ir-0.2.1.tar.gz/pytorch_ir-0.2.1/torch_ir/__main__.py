"""Support running torch_ir as a module: python -m torch_ir."""

from torch_ir.cli import main

main()
