from enum import Enum


class GeminiModel(Enum):
    """
    Available Google Gemini models.

    Attributes:
        FLASH: Gemini 2.5 Flash — fast and efficient, great for most use cases.
        FLASH_LITE: Gemini 2.5 Flash Lite — lightweight and fastest model.
        PRO: Gemini 2.5 Pro — most powerful model, best for complex tasks.
        FLASH_2: Gemini 2.0 Flash — previous generation Flash model.
        FLASH_2_LITE: Gemini 2.0 Flash Lite — previous generation lite model.
        FLASH_3: Gemini 3 Flash — latest experimental Flash model.
        PRO_3: Gemini 3 Pro — latest experimental Pro model.
        FLASH_LATEST: Always points to the latest Flash model.
        PRO_LATEST: Always points to the latest Pro model.

    Example:
        >>> from dracula import Dracula, GeminiModel
        >>> ai = Dracula(api_key="your-api-key", model=GeminiModel.FLASH)
    """

    # Gemini 2.5
    FLASH = "gemini-2.5-flash"
    FLASH_LITE = "gemini-2.5-flash-lite"
    PRO = "gemini-2.5-pro"

    # Gemini 2.0
    FLASH_2 = "gemini-2.0-flash"
    FLASH_2_LITE = "gemini-2.0-flash-lite"

    # Gemini 3 (not yet available — included for forward compatibility)
    FLASH_3 = "gemini-3-flash-preview"
    PRO_3 = "gemini-3-pro-preview"

    # Always latest
    FLASH_LATEST = "gemini-flash-latest"
    FLASH_LITE_LATEST = "gemini-flash-lite-latest"
    PRO_LATEST = "gemini-pro-latest"
