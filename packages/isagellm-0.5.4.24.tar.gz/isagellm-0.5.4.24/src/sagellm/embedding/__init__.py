"""sagellm embedding module.

Canonical embedding interfaces and service facade.
"""

from __future__ import annotations

from .client import EmbeddingClient
from .compat import (
    EmbeddingFactory,
    EmbeddingRegistry,
    check_model_availability,
    get_embedding_model,
    list_embedding_models,
)
from .protocols import EmbeddingClientAdapter, EmbeddingProtocol, adapt_embedding_client
from .service import EmbeddingService

__all__ = [
    "EmbeddingProtocol",
    "EmbeddingClientAdapter",
    "adapt_embedding_client",
    "EmbeddingClient",
    "EmbeddingService",
    "EmbeddingFactory",
    "EmbeddingRegistry",
    "get_embedding_model",
    "list_embedding_models",
    "check_model_availability",
]
