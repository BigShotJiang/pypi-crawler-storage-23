"""Tests for sagellm.embedding migration module."""

from __future__ import annotations

from sagellm.embedding import (
    EmbeddingClient,
    EmbeddingFactory,
    EmbeddingRegistry,
    EmbeddingService,
    check_model_availability,
    get_embedding_model,
    list_embedding_models,
)


def test_embedding_client_empty_input_returns_empty() -> None:
    client = EmbeddingClient(base_url="http://127.0.0.1:8890")
    assert client.embed([]) == []


def test_embedding_service_normalizes_vectors() -> None:
    class _FakeClient:
        def embed(self, texts: list[str], model: str | None = None) -> list[list[float]]:
            return [[3.0, 4.0]]

    service = EmbeddingService(client=_FakeClient(), normalize=True)
    vectors = service.embed(["hello"])

    assert len(vectors) == 1
    assert abs(vectors[0][0] - 0.6) < 1e-6
    assert abs(vectors[0][1] - 0.8) < 1e-6


def test_embedding_service_can_disable_normalize() -> None:
    class _FakeClient:
        def embed(self, texts: list[str], model: str | None = None) -> list[list[float]]:
            return [[3.0, 4.0]]

    service = EmbeddingService(client=_FakeClient(), normalize=False)
    vectors = service.embed(["hello"])

    assert vectors == [[3.0, 4.0]]


def test_compat_hash_embedder_dim_and_batch() -> None:
    embedder = get_embedding_model("hash", dim=256)
    vector = embedder.embed("hello")
    vectors = embedder.embed_batch(["hello", "world"])

    assert len(vector) == 256
    assert len(vectors) == 2
    assert embedder.get_dim() == 256


def test_compat_registry_and_factory() -> None:
    methods = EmbeddingRegistry.list_methods()
    assert "hash" in methods
    assert "openai" in methods

    model_info = list_embedding_models()
    assert "mockembedder" in model_info

    embedder = EmbeddingFactory.create("mockembedder", fixed_dim=64)
    assert len(embedder.embed("x")) == 64


def test_compat_check_model_availability() -> None:
    ok = check_model_availability("hash")
    bad = check_model_availability("not_exists")

    assert ok["status"] == "available"
    assert bad["status"] == "unavailable"
