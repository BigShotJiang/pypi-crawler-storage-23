"""
Storage utilities for Cloud Storage operations.

This module provides a class for interacting with Google Cloud Storage.
"""

from __future__ import annotations

import json
import mimetypes
import tempfile
import uuid
from pathlib import Path

import pandas as pd
import requests
from google.cloud import storage
from google.cloud.exceptions import GoogleCloudError, NotFound

from brownllama.logger import get_logger

logger = get_logger(__name__)


class StorageController:
    """
    Google Cloud Storage manager for staging data.

    Attributes:
        project_id (str): Google Cloud project ID
        bucket_name (str): Cloud Storage bucket name

    """

    def __init__(self, project_id: str, bucket_name: str) -> None:
        """
        Initialize the Cloud Storage client and get or create the bucket.

        Args:
            project_id: Google Cloud project ID
            bucket_name: Cloud Storage bucket name

        """
        self.project_id = project_id
        self.bucket_name = bucket_name

        self.storage_client = storage.Client(project=self.project_id)

        try:
            self.bucket = self.storage_client.get_bucket(bucket_name)
        except NotFound:
            self.bucket = self.storage_client.create_bucket(bucket_name)
            logger.debug(f"{'=' * 10} Created new bucket: {bucket_name} {'=' * 10}")

    def upload_blob(self, data: dict | list[dict], prefix: str = "data") -> str:
        r"""
        Serialize and upload a dict or list of dicts to GCS as NDJSON.

        WHY NDJSON:
            BigQuery's NEWLINE_DELIMITED_JSON loader expects exactly one valid
            JSON object per line. Each record must be self-contained on a single
            line — no pretty-printing, no multi-line values.

        WHY NOT pandas.to_json():
            pandas uses ujson internally. With force_ascii=False, ujson can
            mishandle multi-byte Unicode characters (e.g. Polish 'Śląska',
            German 'Müller', French 'Île-de-France'), occasionally emitting
            a malformed byte sequence that BigQuery's parser interprets as a
            line break. This caused a single record to appear as 2 rows in BQ.

        WHY json.dumps() + manual encode:
            - json.dumps() escapes any literal \n or \r inside string values
              as \\n / \\r, so a newline can never appear inside a JSON value
              and corrupt the line boundary.
            - ensure_ascii=False preserves Unicode characters as-is (UTF-8),
              avoiding any lossy escaping like \\u015alqska.
            - Writing in binary mode (mode='wb') with explicit .encode('utf-8')
              bypasses OS-level newline translation (e.g. \n -> \r\n on Windows)
              and guarantees the file on disk is pure UTF-8 bytes.

        Args:
            data: Payload to upload. Accepts a single record (dict) or a batch
                  of records (list[dict]). No CSV or Excel — those are handled
                  on the download side via pandas.
            prefix: Blob name prefix in GCS. Used to group related files and
                    make them identifiable (e.g. 'my_table_data_chunk_0').

        Returns:
            str: GCS URI of the uploaded file, e.g. 'gs://my-bucket/prefix_<uuid>.json'.

        Raises:
            Exception: Propagates any GCS or I/O error after logging.

        """
        logger.debug(f"{'=' * 10} Exporting data to GCS {'=' * 10}")
        temp_file_path: Path | None = None
        filename = f"{prefix}_{uuid.uuid4().hex}.json"

        # Normalize to a list so the write loop is always uniform.
        # A single dict is wrapped in a list — no branching logic below.
        records: list[dict] = data if isinstance(data, list) else [data]

        try:
            # Open in binary mode so Python does not apply any text-mode
            # transformations (newline translation, encoding assumptions).
            # We own every byte written to this file.
            with tempfile.NamedTemporaryFile(
                mode="wb",
                delete=False,
                suffix=".json",
            ) as temp_file:
                temp_file_path = Path(temp_file.name)

                for record in records:
                    # json.dumps guarantees:
                    #   1. The output is a single line (no internal newlines).
                    #   2. Special Unicode chars are preserved, not escaped.
                    #   3. Any \n or \r inside a value is safely escaped as \\n.
                    # The trailing '\n' is the NDJSON record separator.
                    line = json.dumps(record, ensure_ascii=False) + "\n"

                    # Explicit UTF-8 encoding — consistent across all platforms.
                    temp_file.write(line.encode("utf-8"))

            blob = self.bucket.blob(filename)

            # Declare UTF-8 in the content-type header so GCS metadata,
            # downstream consumers, and BigQuery all agree on the encoding.
            blob.upload_from_filename(
                temp_file_path,
                content_type="application/json; charset=utf-8",
            )

            logger.debug(
                f"{'=' * 10} Successfully uploaded data to gs://{self.bucket_name}/{filename} {'=' * 10}"
            )

        except Exception:
            logger.exception("Error uploading to GCS.")
            raise

        else:
            return f"gs://{self.bucket_name}/{filename}"

        finally:
            # Always clean up the temp file, even if the upload failed.
            if temp_file_path and temp_file_path.exists():
                temp_file_path.unlink()

    def download_blob(self, blob_path: str, blob_name: str) -> dict:
        """
        Download a single CSV file from GCS and return it as a dict.

        The file is read as UTF-16 encoded CSV via pandas, then converted
        to a JSON-serializable dict. UTF-16 is expected here because the
        source files are produced with that encoding.

        Args:
            blob_path (str): Folder-like path prefix within the bucket.
            blob_name (str): Filename of the blob to download.

        Returns:
            dict: Parsed records from the CSV file.

        Raises:
            FileNotFoundError: If the blob does not exist in GCS.
            GoogleCloudError: If a GCS API error occurs.
            Exception: For any other unexpected failure.

        """
        logger.debug(f"{'=' * 10} Downloading data from GCS {'=' * 10}")
        temp_file_path: Path | None = None

        try:
            blob_name = (
                f"{blob_path.rstrip('/')}/{blob_name}" if blob_path else blob_name
            )

            blob = self.bucket.blob(blob_name)

            if not blob.exists():
                error_message = f"File not found in GCS: {blob_name}"
                raise FileNotFoundError(error_message)

            with tempfile.NamedTemporaryFile(
                mode="wb", delete=False, encoding=None
            ) as temp_file:
                blob.download_to_file(temp_file)
                temp_file_path = Path(temp_file.name)

            # Source CSVs are UTF-16 encoded — pandas handles the BOM and
            # decoding. If the source encoding changes, update this argument.
            dataframe_data = pd.read_csv(temp_file_path, encoding="utf-16")
            json_data = dataframe_data.to_json(orient="records")
            return json.loads(json_data)

        except NotFound as e:
            error_message = f"File not found in GCS: {blob_name}"
            raise FileNotFoundError(error_message) from e
        except GoogleCloudError:
            logger.exception(f"Google Cloud error downloading file {blob_name}.")
            raise
        except Exception:
            logger.exception(
                f"An unexpected error occurred while downloading or parsing file {blob_name}."
            )
            raise

        finally:
            if temp_file_path and temp_file_path.exists():
                temp_file_path.unlink()

    def download_from_blob_path(self, blob_path: str) -> list[dict]:
        """
        Download all CSV files under a GCS path prefix and return as a list of dicts.

        Iterates over every blob under blob_path, downloads each one to a temp
        file, parses it as a UTF-16 CSV via pandas, and accumulates the records.
        Files that fail to download or parse are skipped with a warning so a
        single bad file does not abort the entire batch.

        Args:
            blob_path (str): The GCS path prefix (acts like a folder) to list
                             and download from.

        Returns:
            list[dict]: Aggregated records from all successfully parsed files.

        Raises:
            GoogleCloudError: If the GCS listing or a download call fails.
            Exception: For any other unexpected failure.

        """
        logger.debug(
            f"{'=' * 10} Downloading all data from GCS blob_path: {blob_path} {'=' * 10}"
        )
        all_downloaded_data: list[dict] = []
        temp_files_paths: list[Path] = []

        try:
            # Normalise the prefix so list_blobs scopes correctly to the folder.
            prefix = blob_path.rstrip("/") + "/" if blob_path else ""
            blobs = self.bucket.list_blobs(prefix=blob_path)

            for blob in blobs:
                # Skip the virtual directory entry itself (GCS lists it as a blob
                # whose name equals the prefix when created via the console).
                if blob.name == prefix:
                    continue

                logger.debug(f"{'=' * 10} Downloading file: {blob.name} {'=' * 10}")
                temp_file_path = None
                try:
                    with tempfile.NamedTemporaryFile(
                        mode="wb", delete=False, encoding=None
                    ) as temp_file:
                        blob.download_to_file(temp_file)
                        temp_file_path = Path(temp_file.name)
                        temp_files_paths.append(temp_file_path)

                    # Same UTF-16 assumption as download_blob — see note there.
                    dataframe_data = pd.read_csv(temp_file_path, encoding="utf-16")
                    json_data = dataframe_data.to_json(orient="records")
                    all_downloaded_data.extend(json.loads(json_data))

                except Exception as e:
                    # Log and continue — one bad file should not block the rest.
                    logger.warning(
                        f"Error downloading or processing file {blob.name}: {e}"
                    )
                    continue

            return all_downloaded_data

        except GoogleCloudError:
            logger.exception(
                f"Google Cloud error listing or downloading files from blob_path {blob_path}."
            )
            raise
        except Exception:
            logger.exception(
                f"An unexpected error occurred while downloading all files from blob_path {blob_path}."
            )
            raise

        finally:
            # Clean up all temp files regardless of success or failure.
            for temp_path in temp_files_paths:
                if temp_path.exists():
                    temp_path.unlink()

    def delete_blob(self, gcs_uri: str) -> None:
        """
        Delete a blob from GCS by its URI.

        NotFound is treated as a no-op because the file may have already been
        cleaned up by a previous attempt or a concurrent process. All other
        errors are logged but not re-raised to avoid blocking cleanup flows.

        Args:
            gcs_uri: Full GCS URI of the file to delete, e.g. 'gs://bucket/file.json'.

        """
        logger.debug(f"{'=' * 10} Deleting data from GCS {'=' * 10}")
        try:
            # Strip the bucket prefix to get the blob name relative to the bucket.
            blob_name = gcs_uri.replace(f"gs://{self.bucket_name}/", "")
            self.bucket.blob(blob_name).delete()
            logger.debug(f"{'=' * 10} Deleted file: {gcs_uri} {'=' * 10}")
        except NotFound:
            # Acceptable during cleanup — treat as success.
            logger.warning(
                f"File not found during deletion: {gcs_uri}. It may have already been deleted."
            )
        except GoogleCloudError:
            logger.exception(f"Google Cloud error deleting file {gcs_uri}.")
        except Exception:
            logger.exception(
                f"An unexpected error occurred while deleting file {gcs_uri}."
            )

    def upload_from_url(
        self,
        download_url: str,
        blob_name: str,
        content_type: str | None = None,
        timeout: int = 120,
        chunk_size: int = 8 * 1024 * 1024,
    ) -> str:
        """
        Stream a file from a URL directly into GCS without buffering it fully in memory.

        Uses requests' streaming mode and GCS resumable uploads (via blob.open)
        so large files are transferred in chunks rather than loaded all at once.
        Content-type is resolved in priority order:
            1. Caller-supplied content_type argument
            2. Content-Type response header from the download URL
            3. MIME type guessed from blob_name
            4. Fallback: application/octet-stream

        Args:
            download_url: The source URL to stream from.
            blob_name: Destination blob path within the bucket.
            content_type: Optional MIME type override.
            timeout: HTTP request timeout in seconds.
            chunk_size: Chunk size for both streaming download and resumable
                        GCS upload (default 8 MB).

        Returns:
            str: GCS URI of the uploaded file.

        Raises:
            requests.RequestException: If the HTTP download fails.
            GoogleCloudError: If the GCS upload fails.

        """
        logger.info(
            "Uploading file from URL to gs://%s/%s", self.bucket_name, blob_name
        )

        try:
            response = requests.get(download_url, timeout=timeout, stream=True)
            response.raise_for_status()

            # Resolve content-type following the priority chain described above.
            if content_type is None:
                content_type = response.headers.get("Content-Type")

            if content_type is None or content_type == "application/octet-stream":
                guessed, _ = mimetypes.guess_type(blob_name)
                content_type = guessed or "application/octet-stream"

            # chunk_size on the blob enables GCS resumable uploads, which are
            # required for reliable transfer of files larger than ~5 MB.
            blob = self.bucket.blob(blob_name, chunk_size=chunk_size)

            with blob.open("wb", content_type=content_type) as blob_writer:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        blob_writer.write(chunk)

            gcs_uri = f"gs://{self.bucket_name}/{blob_name}"
            logger.info(
                "Successfully uploaded to %s (content_type=%s)", gcs_uri, content_type
            )
            return gcs_uri

        except requests.RequestException:
            logger.exception("Failed to download file from URL: %s", download_url)
            raise
        except GoogleCloudError:
            logger.exception("Failed to upload file to GCS: %s", blob_name)
            raise
