"""Built-in skills that ship with the Deep Agents CLI.

These skills are always available at the lowest precedence level. User and
project skills with the same name will override them.
"""
