"""Allow running the CLI as: python -m deepagents_cli.main."""

from deepagents_cli.main import cli_main

if __name__ == "__main__":
    cli_main()
