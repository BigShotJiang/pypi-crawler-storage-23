"""
qc plots 
    -

"""