from dataclasses import dataclass


