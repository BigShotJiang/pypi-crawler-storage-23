from dataclasses import dataclass


__all__ = [
    "SQLTable"
]


@dataclass
class SQLTable:
    pass