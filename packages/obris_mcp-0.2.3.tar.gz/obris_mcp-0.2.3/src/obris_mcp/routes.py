API_PREFIX = "/v1"


def _path(*segments: str) -> str:
    return f"{API_PREFIX}/{'/'.join(segments)}"


# Topics
def topics() -> str:
    return _path("topics")


def topic(topic_id: str) -> str:
    return _path("topics", topic_id)


def topic_knowledge(topic_id: str) -> str:
    return _path("topics", topic_id, "knowledge")


# Knowledge
def knowledge(source_type: str | None = None) -> str:
    if source_type:
        return _path("knowledge", source_type)
    return _path("knowledge")


# Auth
def api_keys() -> str:
    return _path("auth", "api-keys")


def api_key(key_id: str) -> str:
    return _path("auth", "api-keys", key_id)
