"""
PowerPath Exceptions

Re-exports common errors and adds PowerPath-specific exceptions.
"""

from timeback_common import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)

PowerPathError = TimebackError


__all__ = [
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "InputValidationError",
    "NotFoundError",
    "PowerPathError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "create_input_validation_error",
]
