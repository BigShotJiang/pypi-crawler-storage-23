"""
Screening Resource

PowerPath screening session operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from timeback_common import serialize_input, validate_non_empty_string, validate_with_schema

from ..types.inputs import ScreeningAssignTestInput, ScreeningResetSessionInput
from ..types.responses import (
    ScreeningAssignTestResponse,
    ScreeningResetSessionResponse,
    ScreeningResultsResponse,
    ScreeningSessionResponse,
)

if TYPE_CHECKING:
    from ..lib.transport import Transport


class ScreeningResource:
    """Screening resource for PowerPath screening APIs."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return self._transport.paths.base

    async def get_results(self, user_id: str) -> ScreeningResultsResponse:
        """Get screening results for a user."""
        validate_non_empty_string(user_id, "user_id")
        body = await self._transport.get(
            f"{self._base_path}/screening/results/{quote(user_id, safe='')}"
        )
        return ScreeningResultsResponse.model_validate(body)

    async def get_session(self, user_id: str) -> ScreeningSessionResponse:
        """Get screening session for a user."""
        validate_non_empty_string(user_id, "user_id")
        body = await self._transport.get(
            f"{self._base_path}/screening/session/{quote(user_id, safe='')}"
        )
        return ScreeningSessionResponse.model_validate(body)

    async def reset_session(
        self, input: ScreeningResetSessionInput | dict[str, Any]
    ) -> ScreeningResetSessionResponse:
        """Reset a screening session."""
        validate_with_schema(ScreeningResetSessionInput, input, "screening reset session")
        body = await self._transport.post(
            f"{self._base_path}/screening/session/reset",
            serialize_input(input, ScreeningResetSessionInput),
        )
        return ScreeningResetSessionResponse.model_validate(body)

    async def assign_test(
        self, input: ScreeningAssignTestInput | dict[str, Any]
    ) -> ScreeningAssignTestResponse:
        """Assign a screening test."""
        validate_with_schema(ScreeningAssignTestInput, input, "screening assign test")
        body = await self._transport.post(
            f"{self._base_path}/screening/tests/assign",
            serialize_input(input, ScreeningAssignTestInput),
        )
        return ScreeningAssignTestResponse.model_validate(body)
