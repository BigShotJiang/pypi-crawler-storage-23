"""
PowerPath Constants

Configuration constants for the PowerPath client.
"""

SERVICE_NAME = "powerpath"
