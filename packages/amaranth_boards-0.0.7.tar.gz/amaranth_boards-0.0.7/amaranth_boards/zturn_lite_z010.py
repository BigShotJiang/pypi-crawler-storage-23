from .zturn_lite_z007s import ZTurnLiteZ007SPlatform


__all__ = ["ZTurnLiteZ010Platform"]


class ZTurnLiteZ010Platform(ZTurnLiteZ007SPlatform):
    device = "xc7z010"
