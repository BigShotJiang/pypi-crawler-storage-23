"""IPC transport implementations (Unix socket + TCP loopback fallback)."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import platform
import secrets
import sys
from dataclasses import dataclass
from typing import TYPE_CHECKING

from kagan.core.ipc.constants import STREAM_LIMIT_BYTES
from kagan.core.paths import get_core_runtime_dir

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine
    from typing import Any

    ClientHandler = Callable[
        [asyncio.StreamReader, asyncio.StreamWriter],
        Coroutine[Any, Any, None],
    ]

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ServerHandle:
    """Handle returned after starting a transport server."""

    transport_type: str
    address: str
    port: int | None = None
    close: Callable[[], Coroutine[Any, Any, None]] | None = None


_SOCKET_NAME = "core.sock"


def _default_socket_path() -> str:
    return str(get_core_runtime_dir() / _SOCKET_NAME)


class UnixSocketTransport:
    """IPC transport over Unix domain sockets (macOS/Linux only)."""

    def __init__(self, path: str | None = None) -> None:
        if platform.system() == "Windows":
            msg = "Unix sockets are not supported on Windows"
            raise NotImplementedError(msg)
        self._path = path or _default_socket_path()

    async def start_server(self, handler: ClientHandler) -> ServerHandle:
        """Bind a Unix socket server, removing any stale socket file."""
        with contextlib.suppress(FileNotFoundError):
            os.unlink(self._path)

        parent = os.path.dirname(self._path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        server = await asyncio.start_unix_server(
            handler,
            path=self._path,
            limit=STREAM_LIMIT_BYTES,
        )

        if sys.platform != "win32":
            os.chmod(self._path, 0o600)

        logger.info("Unix socket server listening on %s", self._path)

        async def _close() -> None:
            server.close()
            await server.wait_closed()
            with contextlib.suppress(FileNotFoundError):
                os.unlink(self._path)
            logger.info("Unix socket server stopped")

        return ServerHandle(
            transport_type="socket",
            address=self._path,
            port=None,
            close=_close,
        )

    async def connect(
        self, address: str, port: int | None = None
    ) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        """Open a connection to the Unix socket at *address*."""
        reader, writer = await asyncio.open_unix_connection(
            address,
            limit=STREAM_LIMIT_BYTES,
        )
        logger.debug("Connected to Unix socket at %s", address)
        return reader, writer


_LOCALHOST = "127.0.0.1"
_TOKEN_BYTES = 32


class TCPLoopbackTransport:
    """IPC transport over a TCP loopback socket with handshake token validation."""

    def __init__(self, host: str | None = None) -> None:
        self._host = host or _LOCALHOST
        self._handshake_token: str | None = None

    def set_handshake_token(self, token: str) -> None:
        """Configure a deterministic handshake token before server start."""
        self._handshake_token = token

    @property
    def handshake_token(self) -> str | None:
        """The secret handshake token generated when the server starts."""
        return self._handshake_token

    async def start_server(self, handler: ClientHandler) -> ServerHandle:
        """Bind a TCP server on localhost with a random OS-assigned port."""
        if self._handshake_token is None:
            self._handshake_token = secrets.token_hex(_TOKEN_BYTES)

        async def _handshake_wrapper(
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
        ) -> None:
            """Validate the handshake token before delegating to *handler*."""
            try:
                raw = await asyncio.wait_for(reader.readline(), timeout=5.0)
                line = raw.decode("utf-8").strip()
                if line != self._handshake_token:
                    logger.warning("TCP handshake failed: invalid token")
                    writer.close()
                    await writer.wait_closed()
                    return
                writer.write(b"OK\n")
                await writer.drain()
            except (TimeoutError, ConnectionError, OSError):
                logger.warning("TCP handshake error", exc_info=True)
                writer.close()
                await writer.wait_closed()
                return

            await handler(reader, writer)

        server = await asyncio.start_server(
            _handshake_wrapper,
            host=self._host,
            port=0,  # OS picks a free port
            limit=STREAM_LIMIT_BYTES,
        )

        addrs = server.sockets[0].getsockname() if server.sockets else (self._host, 0)
        bound_port: int = addrs[1]

        logger.info("TCP loopback server listening on %s:%d", self._host, bound_port)

        async def _close() -> None:
            server.close()
            await server.wait_closed()
            logger.info("TCP loopback server stopped")

        return ServerHandle(
            transport_type="tcp",
            address=self._host,
            port=bound_port,
            close=_close,
        )

    async def connect(
        self,
        address: str,
        port: int | None = None,
        *,
        handshake_token: str | None = None,
    ) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        """Open a TCP connection and complete the handshake."""
        if port is None:
            msg = "TCP transport requires a port"
            raise ValueError(msg)
        if not handshake_token:
            msg = "TCP transport requires a handshake token"
            raise ValueError(msg)

        reader, writer = await asyncio.open_connection(
            address,
            port,
            limit=STREAM_LIMIT_BYTES,
        )
        writer.write((handshake_token + "\n").encode("utf-8"))
        await writer.drain()

        raw = await asyncio.wait_for(reader.readline(), timeout=5.0)
        ack = raw.decode("utf-8").strip()
        if ack != "OK":
            writer.close()
            await writer.wait_closed()
            msg = "TCP handshake rejected by server"
            raise ConnectionError(msg)

        logger.debug("Connected to TCP server at %s:%d", address, port)
        return reader, writer


if sys.platform == "win32":
    DefaultTransport = TCPLoopbackTransport
else:
    DefaultTransport = UnixSocketTransport

__all__ = [
    "ClientHandler",
    "DefaultTransport",
    "ServerHandle",
    "TCPLoopbackTransport",
    "UnixSocketTransport",
]
