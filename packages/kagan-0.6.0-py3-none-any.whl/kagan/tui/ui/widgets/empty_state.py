"""Empty state widget for planner screen."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Center, Vertical
from textual.widget import Widget
from textual.widgets import Static

from kagan.core.constants import BOX_DRAWING, KAGAN_LOGO

if TYPE_CHECKING:
    from textual.app import ComposeResult


class EmptyState(Widget):
    """Empty state widget showing tutorial content for planner screen."""

    DEFAULT_CLASSES = "empty-state"

    def compose(self) -> ComposeResult:
        with Center():
            with Vertical(classes="empty-state-card"):
                with Center():
                    yield Static(KAGAN_LOGO, id="empty-state-logo")

                yield Static("Getting Started", classes="empty-card-title")

                yield Static("How it works:", classes="empty-card-section")
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Describe the feature below",
                    classes="card-item-compact",
                )
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} AI analyzes and asks clarifying questions",
                    classes="card-item-compact",
                )
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Tasks are generated for your review",
                    classes="card-item-compact",
                )

                yield Static("Tips:", classes="empty-card-section")
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Be specific about requirements",
                    classes="card-item-compact",
                )
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Mention stack and constraints",
                    classes="card-item-compact",
                )
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Esc returns to board",
                    classes="card-item-compact",
                )
                yield Static(
                    f"  {BOX_DRAWING['BULLET']} Ctrl+E enhances your prompt with AI",
                    classes="card-item-compact",
                )
