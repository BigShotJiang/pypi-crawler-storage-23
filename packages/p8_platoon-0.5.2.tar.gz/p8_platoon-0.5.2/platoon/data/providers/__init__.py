"""Data providers — vendor-specific integrations.

Each provider maps an external API to the standard commerce schema
defined in platoon.data.schema.
"""
