"""Markdown/clearance discount optimization.

TODO: Implement discount cadence optimization for clearance items:
    - Optimal discount schedule to maximize revenue while clearing inventory
    - Time-based markdown curves (aggressive vs. gradual)
    - Category-specific strategies (fashion vs. electronics vs. perishable)

Planned backends:
    - builtin: Rule-based markdown schedule (heuristic)
    - scipy: Optimization-based discount cadence using scipy.optimize

Usage (planned):
    from platoon.learning.providers import get_provider
    md = get_provider("markdown")
    result = md.plan(product, current_stock=200, target_days=30, min_margin=0.1)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List

from platoon.learning.providers import ModelProvider, register_provider


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class MarkdownResult:
    """Output of markdown/clearance optimization."""

    discount_schedule: List[Dict[str, Any]]  # [{week, discount_pct, projected_units, revenue}]
    projected_clearance_pct: float  # fraction of stock cleared
    total_projected_revenue: float


# ---------------------------------------------------------------------------
# Provider stubs
# ---------------------------------------------------------------------------


@register_provider
class BuiltinMarkdownProvider(ModelProvider):
    """Rule-based markdown schedule — heuristic discount cadence.

    TODO: Implement plan() with time-decay discount curves.
    """

    name = "builtin_markdown"
    domain = "markdown"
    backend = "builtin"

    def plan(self, product: Dict, current_stock: int, target_days: int = 30, **kwargs) -> MarkdownResult:
        """Generate a markdown schedule to clear inventory."""
        raise NotImplementedError("builtin markdown provider not yet implemented")


@register_provider
class ScipyMarkdownProvider(ModelProvider):
    """Optimization-based markdown schedule via scipy.optimize.

    TODO: Implement plan() using constrained optimization for revenue-maximizing discount curves.
    Requires: scipy
    """

    name = "scipy_markdown"
    domain = "markdown"
    backend = "scipy"

    @classmethod
    def is_available(cls) -> bool:
        try:
            import scipy  # noqa: F401
            return True
        except ImportError:
            return False

    def plan(self, product: Dict, current_stock: int, target_days: int = 30, **kwargs) -> MarkdownResult:
        """Generate an optimized markdown schedule."""
        raise NotImplementedError("scipy markdown provider not yet implemented")
