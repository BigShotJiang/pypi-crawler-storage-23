"""p8-platoon: News feed digest with percolate integration."""

from typing import Optional
from uuid import UUID

from platoon.models import Item, P8Moment, P8Resource, UserProfile
from platoon.providers import BaseProvider, FeedProvider, ProviderResult


def run(
    user_metadata,
    user_id: UUID,
    config: Optional[dict] = None,
) -> ProviderResult:
    """Run the feed pipeline for a user.

    This is the primary library entry point. Pass a p8k8 UserMetadata
    object (or any dict/pydantic model with ``interests`` and ``categories``)
    and get back percolate-compatible Resources and Moments.

    Sources and fetcher settings come from ``config`` (global);
    user interests and categories come from ``user_metadata``.
    API keys are resolved from env vars (P8_TAVILY_KEY or P8_PLATOON_KEYS).

    Args:
        user_metadata: p8k8 UserMetadata, UserProfile, or plain dict.
        user_id: User UUID for entity ownership and deterministic IDs.
        config: Global config dict with ``sources``, ``fetcher``, ``output``.
            If None, built-in defaults are used.

    Returns:
        ProviderResult with resources, moments, and raw items.
    """
    from platoon.config import resolve_for_user, resolve_keys

    pipeline_config = resolve_for_user(user_metadata, config)
    keys = resolve_keys()
    tavily_key = keys.get("tavily")

    provider = FeedProvider(tavily_key=tavily_key or None)
    return provider.run(pipeline_config, user_id=user_id)


__all__ = [
    "run",
    "Item",
    "P8Resource",
    "P8Moment",
    "UserProfile",
    "BaseProvider",
    "FeedProvider",
    "ProviderResult",
]
