from setuptools import setup, find_packages
import os

# Read the contents of your README file for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="qeltrix_v6", # The name people will 'pip install'
    version="0.1.0",
    author="hejhdiss",
    author_email="hejhdiss@gmail.com",
    description="A useful paacakge for  ultra high file encryption and  routing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Qeltrix/Qeltrix-v6", 
    
    # This automatically finds the 'qeltrix_v6' folder
    packages=find_packages(),
    package_data={
        # "": means "in any package found"
        # Then list the patterns you want to include
        "": ["*.dll", "*.so"],
    },
    # If you have non-python files (json, txt, etc.) inside the package
    include_package_data=True,
    
    # Important: DLLs/shared libs often mean your package is not "zip safe"
    zip_safe=False,

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
    ],
    python_requires='>=3.10',
    install_requires=[
        "cryptography",
    ],
)