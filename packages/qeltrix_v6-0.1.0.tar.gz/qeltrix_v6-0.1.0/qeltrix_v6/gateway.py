"""
qeltrix_v6/gateway.py - Qeltrix V6 Network Gateway / Router

Implements the "Encryption Router" concept:
  - GatewayServer: Listens for connections; encrypts incoming streams on-the-fly
    and routes the resulting V6 container to a destination or client.
  - GatewayClient: Connect to a V6 gateway server to receive encrypted streams.
  - HttpStreamGateway: Fetches a URL and serves it as a live V6 stream.
  - SeekServer: HTTP server wrapping a .qltx file with Range Request support.

C library handles all socket I/O for maximum performance.
Python/cryptography library handles all crypto.

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0
"""

import os
import io
import time
import zlib
import struct
import logging
import hashlib
import threading
import socket
import ctypes
import urllib.request
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Callable

from qeltrix_v6 import _clib
from qeltrix_v6 import crypto
from qeltrix_v6.container import (
    _pack_one_block, _serialize_footer, BlockIndexEntry,
    DEFAULT_BLOCK_SIZE, MAX_WORKERS
)

logger = logging.getLogger("qeltrix_v6.gateway")

FLAG_NO_VERIFY   = 0x01
FLAG_STREAMING   = 0x02


# ─── Live streaming packer ───────────────────────────────────────────

class StreamPacker:
    """
    Reads data from a source stream, encrypts it block-by-block,
    and writes a valid V6 stream to an output (socket or file).
    
    This is the core of the Gateway: live, on-the-fly V6 creation.
    """
    
    def __init__(
        self,
        master_key: bytes,
        block_size: int = DEFAULT_BLOCK_SIZE,
        cipher_id: int = crypto.CIPHER_AES256_GCM,
        workers: int = MAX_WORKERS,
        no_verify: bool = False,
    ):
        self.master_key = master_key
        self.block_size = block_size
        self.cipher_id  = cipher_id
        self.workers    = workers
        self.no_verify  = no_verify
        self._index: list[BlockIndexEntry] = []
        self._block_index = 0
        self._container_offset = 0
    
    def pack_stream(
        self,
        source: io.RawIOBase | io.BufferedIOBase,
        dest_write: Callable[[bytes], None],
        total_size: Optional[int] = None,
        progress_cb: Optional[Callable[[int, int], None]] = None
    ) -> list[BlockIndexEntry]:
        """
        Stream source → V6 encrypted blocks → dest_write callback.
        
        Emits header first, then blocks as they're processed, footer last.
        This enables streaming: dest can be a network socket.
        """
        self._index.clear()
        self._block_index = 0
        
        flags = FLAG_STREAMING | (FLAG_NO_VERIFY if self.no_verify else 0)
        
        # Write placeholder header (footer info unknown until end)
        hdr = _clib.make_header(
            self.block_size, 0, total_size or 0,
            0, 0,
            flags, self.cipher_id
        )
        dest_write(hdr)
        self._container_offset = len(hdr)
        
        # Buffer to accumulate incomplete block data
        buf = bytearray()
        orig_size = 0
        
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            pending = {}
            pending_order = []
            
            def _flush_pending():
                """Emit completed blocks in order."""
                while pending_order and pending_order[0] in pending:
                    bidx = pending_order.pop(0)
                    result = pending.pop(bidx).result()
                    self._emit_block(result, dest_write)
                    if progress_cb and total_size:
                        progress_cb(self._block_index, max(1, total_size // self.block_size))
            
            while True:
                chunk = source.read(self.block_size)
                if not chunk:
                    break
                buf.extend(chunk)
                orig_size += len(chunk)
                
                while len(buf) >= self.block_size:
                    block_data = bytes(buf[:self.block_size])
                    del buf[:self.block_size]
                    
                    future = pool.submit(_pack_one_block,
                                        self._block_index, block_data,
                                        self.master_key, self.cipher_id)
                    pending[self._block_index] = future
                    pending_order.append(self._block_index)
                    self._block_index += 1
                    
                    _flush_pending()
            
            # Process remaining partial block
            if buf:
                block_data = bytes(buf)
                future = pool.submit(_pack_one_block,
                                     self._block_index, block_data,
                                     self.master_key, self.cipher_id)
                pending[self._block_index] = future
                pending_order.append(self._block_index)
                self._block_index += 1
            
            # Wait for all remaining
            for future in pending.values():
                future.result()  # ensure done
            _flush_pending()
        
        # Emit footer
        footer_data         = _serialize_footer(self._index)
        self._footer_offset = self._container_offset
        self._footer_size   = len(footer_data)
        dest_write(footer_data)
        
        logger.info(f"StreamPacker: {self._block_index} blocks, "
                    f"{orig_size:,} bytes original, footer@{self._footer_offset}")
        return self._index
    
    def patch_header(self, buf, total_size: int = 0):
        """Rewrite header with correct footer info (for seekable buffers)."""
        hdr_size = _clib.header_size()
        flags    = FLAG_STREAMING | (FLAG_NO_VERIFY if self.no_verify else 0)
        real_hdr = _clib.make_header(
            self.block_size, self._block_index, total_size,
            self._footer_offset, self._footer_size,
            flags, self.cipher_id
        )
        pos = buf.tell()
        buf.seek(0)
        buf.write(real_hdr)
        buf.seek(pos)
    
    def _emit_block(self, result, dest_write):
        """Serialize one processed block and write to dest."""
        bidx       = result["block_index"]
        v6c_iv     = result["v6c_iv"]
        enc_v6c    = result["enc_v6c"]
        payload    = result["payload"]
        block_hash = result["block_hash"]
        iv         = result["iv"]
        salt       = result["salt"]
        cid        = result["cipher_id"]
        orig_sz    = result["orig_sz"]
        
        v6c_size_field = len(v6c_iv) + len(enc_v6c)
        prefix = _clib.make_block_prefix(bidx, v6c_size_field, len(payload))
        
        block_start = self._container_offset
        data = prefix + v6c_iv + enc_v6c + payload
        dest_write(data)
        
        block_total = len(data)
        self._container_offset += block_total
        
        orig_offset = bidx * self.block_size
        self._index.append(BlockIndexEntry(
            block_index=bidx,
            original_offset=orig_offset,
            original_size=orig_sz,
            container_offset=block_start,
            container_size=block_total,
            block_hash=block_hash,
            iv=(iv + b'\x00'*16)[:16],
            salt=(salt + b'\x00'*32)[:32],
            cipher_id=cid,
        ))


# ─── Gateway Server ──────────────────────────────────────────────────

class GatewayServer:
    """
    TCP server that receives raw data on one port and serves it as
    a live Qeltrix V6 encrypted stream to connecting clients.
    
    Architecture:
      [Source] → [GatewayServer: port A] → [Encrypt on-the-fly] → [Client: port B]
    
    Optionally can route to a downstream host:port instead of back to client.
    """
    
    def __init__(
        self,
        master_key: bytes,
        listen_host: str = "0.0.0.0",
        listen_port: int = 7620,
        block_size: int = DEFAULT_BLOCK_SIZE,
        cipher_id: int = crypto.CIPHER_AES256_GCM,
        workers: int = MAX_WORKERS,
        dest_host: Optional[str] = None,
        dest_port: Optional[int] = None,
    ):
        self.master_key  = master_key
        self.listen_host = listen_host
        self.listen_port = listen_port
        self.block_size  = block_size
        self.cipher_id   = cipher_id
        self.workers     = workers
        self.dest_host   = dest_host
        self.dest_port   = dest_port
        self._running    = False
        self._thread     = None
        self.stats = {"connections": 0, "bytes_in": 0, "bytes_out": 0, "blocks": 0}
    
    def start(self, blocking: bool = False):
        """Start the gateway server."""
        self._running = True
        if blocking:
            self._serve()
        else:
            self._thread = threading.Thread(target=self._serve, daemon=True)
            self._thread.start()
            logger.info(f"GatewayServer listening on {self.listen_host}:{self.listen_port}")
    
    def stop(self):
        """Stop the gateway server."""
        self._running = False
        # The accept loop has a 1 s timeout, so it will exit on its own.
        # A brief connect-to-self speeds up shutdown if needed.
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            s.connect((self.listen_host or "127.0.0.1", self.listen_port))
            s.close()
        except Exception:
            pass
    
    def _serve(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.listen_host, self.listen_port))
        srv.listen(16)
        srv.settimeout(1.0)
        logger.info(f"Gateway listening on {self.listen_host}:{self.listen_port}")

        while self._running:
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except Exception as e:
                if self._running:
                    logger.error(f"Gateway accept error: {e}")
                break

            client_ip, client_port = addr
            logger.info(f"Gateway: connection from {client_ip}:{client_port}")
            self.stats["connections"] += 1
            t = threading.Thread(
                target=self._handle_client,
                args=(conn, client_ip, client_port),
                daemon=True
            )
            t.start()

        srv.close()
    
    def _handle_client(self, client_sock: socket.socket, ip: str, port: int):
        """Handle one client: receive raw data, encrypt, send back as V6 stream."""
        try:
            # ── Read all incoming raw data ──────────────────────────────
            chunks = []
            client_sock.settimeout(30)
            while True:
                chunk = client_sock.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
                self.stats["bytes_in"] += len(chunk)

            raw_data = b"".join(chunks)
            if not raw_data:
                return

            # ── Encrypt into a V6 container (in memory) ─────────────────
            import io as _io
            buf = _io.BytesIO()

            packer = StreamPacker(
                self.master_key, self.block_size, self.cipher_id, self.workers
            )
            packer.pack_stream(_io.BytesIO(raw_data), buf.write,
                               total_size=len(raw_data))
            # Patch header now that footer_offset / total_blocks are known
            packer.patch_header(buf, total_size=len(raw_data))
            container = buf.getvalue()

            # ── Send to destination ──────────────────────────────────────
            if self.dest_host and self.dest_port:
                dest_sock = socket.create_connection(
                    (self.dest_host, self.dest_port), timeout=10
                )
                try:
                    dest_sock.sendall(container)
                    self.stats["bytes_out"] += len(container)
                finally:
                    dest_sock.close()
            else:
                # Reflect: send V6 container back to sender
                client_sock.sendall(container)
                self.stats["bytes_out"] += len(container)

            self.stats["blocks"] += packer._block_index

        except Exception as e:
            logger.error(f"Gateway client error ({ip}:{port}): {e}")
        finally:
            try:
                client_sock.close()
            except Exception:
                pass
            logger.info(f"Gateway: closed {ip}:{port}")


class _SocketStream(io.RawIOBase):
    """
    Adapter to read from a socket as a Python stream.

    Default backend: Python ``socket`` object — reliable EOF detection,
    correct partial-read behaviour, cross-platform (including Windows).

    Optional C backend (use_c=True): wraps the raw fd via the C library's
    ``qltx_recv_exact``.  Only use when you have a known-length stream and
    want maximum throughput; it blocks until exactly N bytes arrive and
    does NOT handle partial reads or clean EOF.

    Args:
        fd_or_sock: An integer fd (for C backend) or a ``socket.socket``
                    (for Python backend).
        lib:        The loaded C library (used only when use_c=True).
        use_c:      If True, use C recv; if False (default), use Python socket.
    """

    def __init__(self, fd_or_sock, lib=None, use_c: bool = False):
        self._use_c = use_c
        self._lib   = lib

        if use_c:
            # C backend — fd must be an integer
            if not isinstance(fd_or_sock, int):
                raise TypeError("C backend requires an integer fd")
            self._fd   = fd_or_sock
            self._sock = None
        else:
            # Python backend (default)
            if isinstance(fd_or_sock, int):
                # Wrap raw fd into a Python socket WITHOUT taking ownership
                # so the caller can still close it independently.
                import socket as _socket
                self._sock = _socket.fromfd(
                    fd_or_sock, _socket.AF_INET, _socket.SOCK_STREAM
                )
            else:
                self._sock = fd_or_sock
            self._sock.settimeout(30)
            self._fd = self._sock.fileno()

    def read(self, n: int = -1) -> bytes:
        if n <= 0:
            n = 65536

        if self._use_c:
            # C path: recv exactly n bytes (blocks; no partial read / EOF)
            buf = (ctypes.c_uint8 * n)()
            r = self._lib.qltx_recv_exact(self._fd, buf, n)
            if r != 0:          # qltx_recv_exact returns 0 on success
                return b""
            return bytes(buf)
        else:
            # Python path (default): up-to-n bytes, b"" on EOF
            try:
                return self._sock.recv(n)
            except OSError:
                return b""

    def readable(self) -> bool:
        return True

    def close(self):
        if self._use_c:
            pass  # caller owns the fd
        else:
            # fromfd() duplicates the fd, so closing our copy is safe
            try:
                if self._sock:
                    self._sock.close()
            except Exception:
                pass
        super().close()


# ─── HTTP Stream Gateway ─────────────────────────────────────────────

class HttpStreamGateway:
    """
    Fetches content from a URL and serves it as a live V6 encrypted stream.
    
    Usage:
        gw = HttpStreamGateway(master_key, "https://example.com/data.bin")
        gw.stream_to_file("output.qltx")
        # or
        gw.stream_to_socket(dest_socket_fd)
    """
    
    def __init__(
        self,
        master_key: bytes,
        url: str,
        block_size: int = DEFAULT_BLOCK_SIZE,
        cipher_id: int = crypto.CIPHER_AES256_GCM,
        workers: int = MAX_WORKERS,
    ):
        self.master_key = master_key
        self.url        = url
        self.block_size = block_size
        self.cipher_id  = cipher_id
        self.workers    = workers
    
    def stream_to_file(
        self,
        output_path: str,
        progress_cb: Optional[Callable] = None
    ) -> int:
        """
        Download URL and save as V6 container.
        Returns bytes written.
        """
        start = time.monotonic()
        logger.info(f"HttpStreamGateway: fetching {self.url}")
        
        buf = io.BytesIO()
        written = [0]
        
        def dest_write(data: bytes):
            buf.write(data)
            written[0] += len(data)
        
        with urllib.request.urlopen(self.url) as response:
            total = int(response.headers.get("Content-Length", 0) or 0)
            source = response  # file-like
            
            packer = StreamPacker(
                self.master_key, self.block_size, self.cipher_id, self.workers
            )
            packer.pack_stream(source, dest_write, total_size=total, 
                               progress_cb=progress_cb)
        
        buf.seek(0)
        with open(output_path, "wb") as f:
            import shutil
            shutil.copyfileobj(buf, f)
        
        elapsed = time.monotonic() - start
        logger.info(f"Saved {written[0]:,} bytes to {output_path} in {elapsed:.3f}s")
        return written[0]


# ─── Seek / HTTP Range Request Server ────────────────────────────────

class SeekServer:
    """
    HTTP server that serves a .qltx container with full Range Request support.
    
    Clients can do:
      GET /  → full V6 stream
      GET /  Range: bytes=0-1048576  → specific blocks only
    
    The server translates byte ranges in the original file to the correct
    encrypted blocks in the V6 container, enabling seek without full download.
    """
    
    def __init__(
        self,
        container_path: str,
        master_key: bytes,
        host: str = "0.0.0.0",
        port: int = 7621,
        workers: int = MAX_WORKERS,
    ):
        self.container_path = container_path
        self.master_key     = master_key
        self.host           = host
        self.port           = port
        self.workers        = workers
        self._running       = False
        self._thread        = None
        
        # Load index once
        from qeltrix_v6.container import _read_container_index
        self._header, self._index = _read_container_index(container_path)
        self._entry_map = {e.block_index: e for e in self._index}
        logger.info(f"SeekServer: loaded {len(self._index)} blocks from {container_path}")
    
    def start(self, blocking: bool = False):
        self._running = True
        if blocking:
            self._serve()
        else:
            self._thread = threading.Thread(target=self._serve, daemon=True)
            self._thread.start()
            logger.info(f"SeekServer listening on {self.host}:{self.port}")
    
    def stop(self):
        self._running = False
    
    def _serve(self):
        # Use Python's built-in socket for the HTTP server for simplicity
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.host, self.port))
        srv.listen(32)
        srv.settimeout(1.0)
        
        while self._running:
            try:
                conn, addr = srv.accept()
                t = threading.Thread(
                    target=self._handle_http,
                    args=(conn, addr),
                    daemon=True
                )
                t.start()
            except socket.timeout:
                continue
            except Exception as e:
                if self._running:
                    logger.error(f"SeekServer: {e}")
                break
        
        srv.close()
    
    def _handle_http(self, conn: socket.socket, addr):
        try:
            conn.settimeout(30)
            
            # Read request line + headers
            headers = {}
            first_line = None
            
            buf = b""
            while b"\r\n\r\n" not in buf:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buf += chunk
            
            head, _, body = buf.partition(b"\r\n\r\n")
            lines = head.decode(errors="replace").split("\r\n")
            first_line = lines[0]
            
            for line in lines[1:]:
                if ":" in line:
                    k, _, v = line.partition(":")
                    headers[k.strip().lower()] = v.strip()
            
            # Parse Range header
            range_val = headers.get("range", "")
            original_size = self._header["original_size"]
            
            if range_val:
                lib = _clib.get_lib()
                rstart = ctypes.c_int64(-1)
                rend   = ctypes.c_int64(-1)
                lib.qltx_parse_range_header(
                    range_val.encode(), ctypes.byref(rstart), ctypes.byref(rend)
                )
                seek_start = int(rstart.value)
                seek_end   = int(rend.value) if rend.value >= 0 else original_size - 1
                
                if seek_start < 0:
                    # Suffix range: last N bytes
                    n = seek_end  
                    seek_start = max(0, original_size - n)
                    seek_end   = original_size - 1
                
                seek_len = seek_end - seek_start + 1
                
                from qeltrix_v6.container import seek_extract
                data = seek_extract(
                    self.container_path, seek_start, seek_len,
                    self.master_key, workers=self.workers
                )
                
                resp_hdr = (
                    f"HTTP/1.1 206 Partial Content\r\n"
                    f"Content-Type: application/octet-stream\r\n"
                    f"Content-Length: {len(data)}\r\n"
                    f"Content-Range: bytes {seek_start}-{seek_end}/{original_size}\r\n"
                    f"Accept-Ranges: bytes\r\n"
                    f"Connection: close\r\n"
                    f"\r\n"
                ).encode()
                conn.sendall(resp_hdr + data)
                
            else:
                # Serve the full decrypted original file
                from qeltrix_v6.container import unpack
                import tempfile
                
                with tempfile.NamedTemporaryFile(delete=False) as tmp:
                    tmp_path = tmp.name
                
                try:
                    unpack(self.container_path, tmp_path, self.master_key,
                           workers=self.workers)
                    
                    with open(tmp_path, "rb") as f:
                        content = f.read()
                    
                    resp_hdr = (
                        f"HTTP/1.1 200 OK\r\n"
                        f"Content-Type: application/octet-stream\r\n"
                        f"Content-Length: {len(content)}\r\n"
                        f"Accept-Ranges: bytes\r\n"
                        f"Connection: close\r\n"
                        f"\r\n"
                    ).encode()
                    conn.sendall(resp_hdr + content)
                finally:
                    os.unlink(tmp_path)
        
        except Exception as e:
            logger.error(f"SeekServer HTTP error from {addr}: {e}")
        finally:
            conn.close()
