"""
qeltrix_v6/_clib.py - ctypes bindings for the Qeltrix V6 C core library.

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0
"""

import ctypes
import ctypes.util
import os
import sys
import platform

# ─── Locate the shared library ──────────────────────────────────────

def _find_lib() -> str:
    """Find libqeltrix_v6.so/.dll/.dylib next to this file or on system path."""
    here = os.path.dirname(os.path.abspath(__file__))
    
    if sys.platform == "win32":
        candidates = [
            os.path.join(here, "qeltrix_v6.dll"),
            os.path.join(here, "..", "c_lib", "qeltrix_v6.dll"),
        ]
    elif sys.platform == "darwin":
        candidates = [
            os.path.join(here, "libqeltrix_v6.dylib"),
            os.path.join(here, "..", "c_lib", "libqeltrix_v6.dylib"),
        ]
    else:
        candidates = [
            os.path.join(here, "libqeltrix_v6.so"),
            os.path.join(here, "..", "c_lib", "libqeltrix_v6.so"),
        ]
    
    for path in candidates:
        if os.path.exists(path):
            return path
    
    raise FileNotFoundError(
        "Could not find Qeltrix V6 C library. "
        f"Expected one of: {candidates}\n"
        "Run: cd c_lib && make"
    )


# ─── Load library ───────────────────────────────────────────────────

_lib = None

def get_lib() -> ctypes.CDLL:
    global _lib
    if _lib is None:
        path = _find_lib()
        _lib = ctypes.CDLL(path)
        _setup_signatures(_lib)
    return _lib


def _setup_signatures(lib: ctypes.CDLL):
    """Configure argument/return types for all exported C functions."""
    u8p  = ctypes.POINTER(ctypes.c_uint8)
    u64p = ctypes.POINTER(ctypes.c_uint64)
    i64p = ctypes.POINTER(ctypes.c_int64)
    cp   = ctypes.c_char_p
    u16p = ctypes.POINTER(ctypes.c_uint16)

    # Permutation
    lib.qltx_permute_table_gen.restype  = ctypes.POINTER(ctypes.c_uint64)
    lib.qltx_permute_table_gen.argtypes = [u8p, ctypes.c_uint64]

    lib.qltx_permute_block.restype  = ctypes.c_int
    lib.qltx_permute_block.argtypes = [u8p, ctypes.c_uint64, u8p, u8p]

    lib.qltx_unpermute_block.restype  = ctypes.c_int
    lib.qltx_unpermute_block.argtypes = [u8p, ctypes.c_uint64, u8p, u8p]

    # Block math
    lib.qltx_block_count.restype  = ctypes.c_uint64
    lib.qltx_block_count.argtypes = [ctypes.c_uint64, ctypes.c_uint64]

    lib.qltx_block_range.restype  = ctypes.c_int
    lib.qltx_block_range.argtypes = [ctypes.c_uint64, ctypes.c_uint64,
                                     ctypes.c_uint64, u64p, u64p]

    lib.qltx_seek_blocks.restype  = ctypes.c_int
    lib.qltx_seek_blocks.argtypes = [ctypes.c_uint64, ctypes.c_uint64,
                                     ctypes.c_uint64, ctypes.c_uint64,
                                     u64p, ctypes.c_int]

    # Header / Footer
    lib.qltx_write_header.restype  = ctypes.c_int
    lib.qltx_write_header.argtypes = [u8p,
                                      ctypes.c_uint64, ctypes.c_uint64,
                                      ctypes.c_uint64, ctypes.c_uint64,
                                      ctypes.c_uint64, ctypes.c_uint8,
                                      ctypes.c_uint16, u8p, u8p, u8p]

    lib.qltx_read_header.restype  = ctypes.c_int
    lib.qltx_read_header.argtypes = [u8p, u8p]   # raw struct out

    lib.qltx_write_block_prefix.restype  = ctypes.c_int
    lib.qltx_write_block_prefix.argtypes = [u8p, ctypes.c_uint64,
                                            ctypes.c_uint64, ctypes.c_uint64,
                                            ctypes.c_uint64]

    lib.qltx_read_block_prefix.restype  = ctypes.c_int
    lib.qltx_read_block_prefix.argtypes = [u8p, u64p, u64p, u64p]

    lib.qltx_write_v6c.restype  = ctypes.c_int
    lib.qltx_write_v6c.argtypes = [u8p, ctypes.c_uint64, ctypes.c_uint64,
                                   ctypes.c_uint64, u8p, u8p, u8p, u8p,
                                   ctypes.c_uint8]

    lib.qltx_read_v6c.restype  = ctypes.c_int
    lib.qltx_read_v6c.argtypes = [u8p, u64p, u64p, u64p, u8p, u8p, u8p, u8p,
                                  ctypes.POINTER(ctypes.c_uint8)]

    lib.qltx_write_index_entry.restype  = ctypes.c_int
    lib.qltx_write_index_entry.argtypes = [u8p,
                                           ctypes.c_uint64, ctypes.c_uint64,
                                           ctypes.c_uint64, ctypes.c_uint64,
                                           ctypes.c_uint64,
                                           u8p, u8p, u8p, ctypes.c_uint8]

    # Sizes
    lib.qltx_header_size.restype      = ctypes.c_uint64
    lib.qltx_v6c_size.restype         = ctypes.c_uint64
    lib.qltx_index_entry_size.restype = ctypes.c_uint64
    lib.qltx_footer_base_size.restype = ctypes.c_uint64
    lib.qltx_block_prefix_size.restype= ctypes.c_int

    # HTTP helpers
    lib.qltx_parse_range_header.restype  = ctypes.c_int
    lib.qltx_parse_range_header.argtypes = [cp, i64p, i64p]

    lib.qltx_format_206_header.restype  = ctypes.c_int
    lib.qltx_format_206_header.argtypes = [ctypes.c_char_p, ctypes.c_int,
                                           ctypes.c_int64, ctypes.c_int64,
                                           ctypes.c_uint64, ctypes.c_uint64,
                                           ctypes.c_char_p]

    # Networking
    lib.qltx_listen_tcp.restype   = ctypes.c_int
    lib.qltx_listen_tcp.argtypes  = [cp, ctypes.c_uint16, ctypes.c_int]

    lib.qltx_accept_tcp.restype   = ctypes.c_int
    lib.qltx_accept_tcp.argtypes  = [ctypes.c_int, ctypes.c_char_p, u16p]

    lib.qltx_connect_tcp.restype  = ctypes.c_int
    lib.qltx_connect_tcp.argtypes = [cp, ctypes.c_uint16]

    lib.qltx_send_all.restype     = ctypes.c_int
    lib.qltx_send_all.argtypes    = [ctypes.c_int, u8p, ctypes.c_uint64]

    lib.qltx_recv_exact.restype   = ctypes.c_int
    lib.qltx_recv_exact.argtypes  = [ctypes.c_int, u8p, ctypes.c_uint64]

    lib.qltx_recv_line.restype    = ctypes.c_int
    lib.qltx_recv_line.argtypes   = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int]

    lib.qltx_close_socket.restype  = None
    lib.qltx_close_socket.argtypes = [ctypes.c_int]

    lib.qltx_send_http_get.restype  = ctypes.c_int
    lib.qltx_send_http_get.argtypes = [ctypes.c_int, cp, cp,
                                       ctypes.c_int64, ctypes.c_int64]

    # Utility
    lib.qltx_time_us.restype  = ctypes.c_uint64
    lib.qltx_version.restype  = ctypes.c_char_p


# ─── Python-friendly wrapper helpers ────────────────────────────────

def _bytes_ptr(data: bytes):
    """Return a ctypes uint8 pointer to a bytes object."""
    return ctypes.cast(data, ctypes.POINTER(ctypes.c_uint8))


def permute_block(data: bytes, seed: bytes) -> bytes:
    """Apply V4/V2-style deterministic permutation. Fast C implementation."""
    lib = get_lib()
    out = (ctypes.c_uint8 * len(data))()
    rc = lib.qltx_permute_block(
        _bytes_ptr(data), len(data),
        out, _bytes_ptr(seed)
    )
    if rc != 0:
        raise RuntimeError(f"qltx_permute_block failed: {rc}")
    return bytes(out)


def unpermute_block(data: bytes, seed: bytes) -> bytes:
    """Reverse V4/V2-style permutation. Fast C implementation."""
    lib = get_lib()
    out = (ctypes.c_uint8 * len(data))()
    rc = lib.qltx_unpermute_block(
        _bytes_ptr(data), len(data),
        out, _bytes_ptr(seed)
    )
    if rc != 0:
        raise RuntimeError(f"qltx_unpermute_block failed: {rc}")
    return bytes(out)


def block_count(file_size: int, block_size: int) -> int:
    return int(get_lib().qltx_block_count(file_size, block_size))


def block_range(block_index: int, file_size: int, block_size: int):
    """Returns (offset, size) of block N in the original file."""
    lib = get_lib()
    off = ctypes.c_uint64(0)
    sz  = ctypes.c_uint64(0)
    rc = lib.qltx_block_range(block_index, file_size, block_size,
                              ctypes.byref(off), ctypes.byref(sz))
    if rc != 0:
        raise ValueError(f"block_range failed: {rc}")
    return int(off.value), int(sz.value)


def seek_blocks(seek_offset: int, seek_len: int,
                file_size: int, block_size: int) -> list[int]:
    """Return list of block indices needed to satisfy a seek request."""
    lib = get_lib()
    arr = (ctypes.c_uint64 * 65536)()
    count = lib.qltx_seek_blocks(seek_offset, seek_len, file_size, block_size,
                                  arr, 65536)
    if count < 0:
        raise ValueError(f"seek_blocks failed: {count}")
    return [int(arr[i]) for i in range(count)]


def make_header(block_size: int, total_blocks: int, original_file_size: int,
                footer_offset: int, footer_size: int,
                flags: int = 0, cipher_default: int = 0,
                encrypted_mk: bytes = None, mk_iv: bytes = None,
                mk_salt: bytes = None) -> bytes:
    lib = get_lib()
    hdr_size = int(lib.qltx_header_size())
    buf = (ctypes.c_uint8 * hdr_size)()
    mk_  = _bytes_ptr(encrypted_mk or b'\x00' * 256)
    iv_  = _bytes_ptr(mk_iv   or b'\x00' * 16)
    salt_= _bytes_ptr(mk_salt or b'\x00' * 32)
    rc = lib.qltx_write_header(buf, block_size, total_blocks, original_file_size,
                               footer_offset, footer_size, flags, cipher_default,
                               mk_, iv_, salt_)
    if rc != 0:
        raise RuntimeError(f"write_header failed: {rc}")
    return bytes(buf)


def make_block_prefix(block_index: int, v6c_size: int, payload_size: int) -> bytes:
    lib = get_lib()
    buf = (ctypes.c_uint8 * 28)()
    rc = lib.qltx_write_block_prefix(buf, 28, block_index, v6c_size, payload_size)
    if rc < 0:
        raise RuntimeError(f"write_block_prefix failed: {rc}")
    return bytes(buf)


def parse_block_prefix(data: bytes):
    """Returns (block_index, v6c_size, payload_size)."""
    lib = get_lib()
    bi  = ctypes.c_uint64(0)
    vs  = ctypes.c_uint64(0)
    ps  = ctypes.c_uint64(0)
    rc = lib.qltx_read_block_prefix(_bytes_ptr(data),
                                    ctypes.byref(bi), ctypes.byref(vs), ctypes.byref(ps))
    if rc != 0:
        raise ValueError(f"read_block_prefix failed (bad magic?): {rc}")
    return int(bi.value), int(vs.value), int(ps.value)


def make_v6c(block_index: int, original_size: int, compressed_size: int,
             data_hash: bytes, iv: bytes, salt: bytes,
             encrypted_cdk: bytes, cipher_id: int) -> bytes:
    lib = get_lib()
    sz = int(lib.qltx_v6c_size())
    buf = (ctypes.c_uint8 * sz)()
    # Keep all byte buffers in local variables so they stay alive
    # until after the C call returns (avoids dangling pointer on Windows).
    _hash = data_hash[:32].ljust(32, b'\x00')
    _iv   = iv[:16].ljust(16, b'\x00')
    _salt = salt[:32].ljust(32, b'\x00')
    _cdk  = (encrypted_cdk + b'\x00' * 64)[:64]
    rc = lib.qltx_write_v6c(
        buf, block_index, original_size, compressed_size,
        _bytes_ptr(_hash),
        _bytes_ptr(_iv),
        _bytes_ptr(_salt),
        _bytes_ptr(_cdk),
        cipher_id
    )
    if rc != 0:
        raise RuntimeError(f"write_v6c failed: {rc}")
    return bytes(buf)


def header_size() -> int:
    return int(get_lib().qltx_header_size())

def v6c_size() -> int:
    return int(get_lib().qltx_v6c_size())

def index_entry_size() -> int:
    return int(get_lib().qltx_index_entry_size())

def block_prefix_size() -> int:
    return int(get_lib().qltx_block_prefix_size())

def c_version() -> str:
    return get_lib().qltx_version().decode()
