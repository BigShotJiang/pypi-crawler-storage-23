"""
Qeltrix V6 - Network-Native Encrypted Streaming Container
==========================================================

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0 (Creative Commons Attribution-ShareAlike 4.0)

WARNING: Proof-of-Concept only. NOT for production security-critical use
without independent cryptographic audit.

Architecture:
  - C shared library (libqeltrix_v6.so / qeltrix_v6.dll):
      Fast block processing, permutation, framing, networking
  - Python (cryptography library):
      AES-256-GCM, ChaCha20-Poly1305, HKDF, SHA-256

Quick start:
    from qeltrix_v6 import pack, unpack, seek_extract, GatewayServer
    from qeltrix_v6.crypto import random_master_key, CIPHER_AES256_GCM

    # Generate a master key
    mk = random_master_key()

    # Pack a file
    result = pack("input.bin", "output.qltx", mk)

    # Unpack
    result = unpack("output.qltx", "recovered.bin", mk)

    # Seek (partial extraction without full unpack)
    data = seek_extract("output.qltx", offset=1000, length=500, master_key=mk)

    # Run a gateway server (encrypts incoming connections on-the-fly)
    gw = GatewayServer(mk, listen_port=7620)
    gw.start()

    # Run an HTTP seek server (serve .qltx with Range Request support)
    srv = SeekServer("output.qltx", mk, port=7621)
    srv.start()
"""

from .crypto import (
    random_master_key,
    random_key,
    random_iv,
    random_salt,
    random_bytes,
    sha256,
    derive_cdk,
    encrypt_block,
    decrypt_block,
    wrap_master_key,
    unwrap_master_key,
    CIPHER_AES256_GCM,
    CIPHER_CHACHA20_POLY1305,
    CIPHER_NAMES,
)

from .container import (
    pack,
    unpack,
    seek_extract,
    V6PackResult,
    V6UnpackResult,
    BlockIndexEntry,
    DEFAULT_BLOCK_SIZE,
)

from .gateway import (
    GatewayServer,
    SeekServer,
    HttpStreamGateway,
    StreamPacker,
    FLAG_NO_VERIFY,
    FLAG_STREAMING,
)

from ._clib import (
    c_version,
    permute_block,
    unpermute_block,
    block_count,
    block_range,
    seek_blocks,
    make_header,
    make_block_prefix,
    parse_block_prefix,
)

__version__ = "6.0.0"
__author__  = "Muhammed Shafin P (@hejhdiss)"
__license__ = "CC BY-SA 4.0"

__all__ = [
    # Crypto
    "random_master_key", "random_key", "random_iv", "random_salt", "random_bytes",
    "sha256", "derive_cdk", "encrypt_block", "decrypt_block",
    "wrap_master_key", "unwrap_master_key",
    "CIPHER_AES256_GCM", "CIPHER_CHACHA20_POLY1305", "CIPHER_NAMES",
    # Container
    "pack", "unpack", "seek_extract",
    "V6PackResult", "V6UnpackResult", "BlockIndexEntry",
    "DEFAULT_BLOCK_SIZE",
    # Gateway
    "GatewayServer", "SeekServer", "HttpStreamGateway", "StreamPacker",
    "FLAG_NO_VERIFY", "FLAG_STREAMING",
    # C lib helpers
    "c_version", "permute_block", "unpermute_block",
    "block_count", "block_range", "seek_blocks",
    "make_header", "make_block_prefix", "parse_block_prefix",
]
