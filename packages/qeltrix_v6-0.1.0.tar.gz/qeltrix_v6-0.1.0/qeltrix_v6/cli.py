#!/usr/bin/env python3
"""
qeltrix_v6/cli.py - Command-line interface for Qeltrix V6

Usage:
    python -m qeltrix_v6 pack   input.bin output.qltx --passphrase mypassword
    python -m qeltrix_v6 unpack output.qltx recovered.bin --passphrase mypassword
    python -m qeltrix_v6 seek   output.qltx --offset 1000 --length 500 --passphrase mypassword
    python -m qeltrix_v6 gateway --port 7620 --passphrase mypassword [--dest-host H --dest-port P]
    python -m qeltrix_v6 serve  output.qltx --port 7621 --passphrase mypassword
    python -m qeltrix_v6 info   output.qltx

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0
"""

import argparse
import hashlib
import logging
import os
import sys
import time

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
    datefmt="%H:%M:%S"
)


def _mk_from_passphrase(passphrase: str) -> bytes:
    """Derive a 32-byte master key from a passphrase (PBKDF2)."""
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", passphrase.encode(), b"QeltrixV6Salt", 200_000)


def _progress(done, total):
    pct = done * 100 // max(total, 1)
    bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
    print(f"\r  [{bar}] {pct}% ({done}/{total} blocks)", end="", flush=True)
    if done >= total:
        print()


def cmd_pack(args):
    from qeltrix_v6 import pack, CIPHER_AES256_GCM, CIPHER_CHACHA20_POLY1305
    
    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)
    
    mk = _mk_from_passphrase(args.passphrase)
    cipher = CIPHER_CHACHA20_POLY1305 if args.cipher == "chacha" else CIPHER_AES256_GCM
    block_size = args.block_size * 1024  # KB → bytes
    
    print(f"Qeltrix V6 Pack")
    print(f"  Input:      {args.input} ({os.path.getsize(args.input):,} bytes)")
    print(f"  Output:     {args.output}")
    print(f"  Cipher:     {'ChaCha20-Poly1305' if cipher else 'AES-256-GCM'}")
    print(f"  Block size: {block_size:,} bytes")
    print(f"  Workers:    {args.workers}")
    print()
    
    result = pack(
        args.input, args.output, mk,
        block_size=block_size,
        cipher_id=cipher,
        workers=args.workers,
        progress_cb=_progress
    )
    
    in_size  = os.path.getsize(args.input)
    out_size = os.path.getsize(args.output)
    ratio    = out_size / in_size if in_size else 0
    
    print(f"\n✓ Done in {result.elapsed_s:.3f}s")
    print(f"  Blocks:       {result.total_blocks}")
    print(f"  Original:     {in_size:,} bytes")
    print(f"  Container:    {out_size:,} bytes ({ratio:.2f}x overhead)")
    speed = in_size / result.elapsed_s / 1e6 if result.elapsed_s > 0 else 0
    print(f"  Speed:        {speed:.1f} MB/s")


def cmd_unpack(args):
    from qeltrix_v6 import unpack
    
    if not os.path.exists(args.input):
        print(f"Error: Container not found: {args.input}")
        sys.exit(1)
    
    mk = _mk_from_passphrase(args.passphrase)
    
    print(f"Qeltrix V6 Unpack")
    print(f"  Container: {args.input} ({os.path.getsize(args.input):,} bytes)")
    print(f"  Output:    {args.output}")
    print(f"  Verify:    {'No' if args.no_verify else 'Yes'}")
    print(f"  Workers:   {args.workers}")
    print()
    
    result = unpack(
        args.input, args.output, mk,
        no_verify=args.no_verify,
        workers=args.workers,
        progress_cb=_progress
    )
    
    print(f"\n✓ Done in {result.elapsed_s:.3f}s")
    print(f"  Blocks:       {result.total_blocks}")
    print(f"  Original:     {result.original_size:,} bytes")
    speed = result.original_size / result.elapsed_s / 1e6 if result.elapsed_s > 0 else 0
    print(f"  Speed:        {speed:.1f} MB/s")
    print(f"  Integrity:    {'✓ OK' if result.integrity_ok else '✗ FAILED'}")


def cmd_seek(args):
    from qeltrix_v6 import seek_extract
    
    if not os.path.exists(args.input):
        print(f"Error: Container not found: {args.input}")
        sys.exit(1)
    
    mk = _mk_from_passphrase(args.passphrase)
    
    print(f"Qeltrix V6 Seek Extract")
    print(f"  Container: {args.input}")
    print(f"  Range:     bytes {args.offset}–{args.offset + args.length - 1}")
    print()
    
    start = time.monotonic()
    data = seek_extract(args.input, args.offset, args.length, mk,
                        no_verify=args.no_verify, workers=args.workers)
    elapsed = time.monotonic() - start
    
    print(f"✓ Extracted {len(data):,} bytes in {elapsed:.3f}s")
    
    if args.output:
        with open(args.output, "wb") as f:
            f.write(data)
        print(f"  Saved to: {args.output}")
    else:
        print(f"  First 64 bytes (hex): {data[:64].hex()}")


def cmd_gateway(args):
    from qeltrix_v6 import GatewayServer, CIPHER_AES256_GCM, CIPHER_CHACHA20_POLY1305
    
    mk = _mk_from_passphrase(args.passphrase)
    cipher = CIPHER_CHACHA20_POLY1305 if args.cipher == "chacha" else CIPHER_AES256_GCM
    
    print(f"Qeltrix V6 Gateway Server")
    print(f"  Listen:  {args.host}:{args.port}")
    if args.dest_host:
        print(f"  Route → {args.dest_host}:{args.dest_port}")
    else:
        print(f"  Mode:    Reflect (send V6 stream back to sender)")
    print(f"  Cipher:  {'ChaCha20-Poly1305' if cipher else 'AES-256-GCM'}")
    print(f"  Press Ctrl+C to stop")
    print()
    
    gw = GatewayServer(
        mk,
        listen_host=args.host,
        listen_port=args.port,
        cipher_id=cipher,
        workers=args.workers,
        dest_host=args.dest_host,
        dest_port=args.dest_port,
    )
    gw.start(blocking=False)
    
    try:
        while True:
            time.sleep(5)
            s = gw.stats
            print(f"  Stats: {s['connections']} connections, "
                  f"{s['bytes_in']:,} bytes in, {s['bytes_out']:,} bytes out")
    except KeyboardInterrupt:
        print("\nStopping gateway...")
        gw.stop()


def cmd_serve(args):
    from qeltrix_v6 import SeekServer
    
    if not os.path.exists(args.input):
        print(f"Error: Container not found: {args.input}")
        sys.exit(1)
    
    mk = _mk_from_passphrase(args.passphrase)
    
    print(f"Qeltrix V6 Seek Server")
    print(f"  Container: {args.input}")
    print(f"  Serving:   http://{args.host}:{args.port}/")
    print(f"  Supports:  HTTP Range Requests (seek without full download)")
    print(f"  Press Ctrl+C to stop")
    print()
    
    srv = SeekServer(args.input, mk, host=args.host, port=args.port,
                     workers=args.workers)
    srv.start(blocking=False)
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping server...")
        srv.stop()


def cmd_info(args):
    import struct
    from qeltrix_v6._clib import header_size
    from qeltrix_v6.container import _read_container_index
    from qeltrix_v6.crypto import CIPHER_NAMES
    
    if not os.path.exists(args.input):
        print(f"Error: File not found: {args.input}")
        sys.exit(1)
    
    file_size = os.path.getsize(args.input)
    
    with open(args.input, "rb") as f:
        hdr = f.read(header_size())
    
    if hdr[:4] != b"QLTX" or hdr[4] != 6:
        print("Error: Not a valid Qeltrix V6 container")
        sys.exit(1)
    
    (version, flags, cipher_default,
     block_size, total_blocks, orig_size,
     footer_offset, footer_size) = struct.unpack_from("<BBHQQQQ Q", hdr, 4)
    
    print(f"Qeltrix V6 Container Info")
    print(f"  File:           {args.input}")
    print(f"  File size:      {file_size:,} bytes")
    print(f"  Version:        {version}")
    print(f"  Flags:          0x{flags:02X}")
    print(f"  Cipher:         {CIPHER_NAMES.get(cipher_default, 'Unknown')}")
    print(f"  Block size:     {block_size:,} bytes ({block_size // 1024} KB)")
    print(f"  Total blocks:   {total_blocks}")
    print(f"  Original size:  {orig_size:,} bytes")
    print(f"  Footer offset:  {footer_offset:,}")
    print(f"  Footer size:    {footer_size:,} bytes")
    overhead = (file_size - orig_size) / max(orig_size, 1) * 100
    print(f"  Overhead:       {overhead:.1f}%")


def main():
    parser = argparse.ArgumentParser(
        description="Qeltrix V6 - Network-Native Encrypted Streaming Container",
        epilog="Author: Muhammed Shafin P (@hejhdiss) | License: CC BY-SA 4.0"
    )
    
    sub = parser.add_subparsers(dest="command", required=True)
    
    # pack
    p = sub.add_parser("pack", help="Pack a file into a V6 container")
    p.add_argument("input",  help="Input file path")
    p.add_argument("output", help="Output .qltx path")
    p.add_argument("--passphrase", required=True, help="Encryption passphrase")
    p.add_argument("--cipher", choices=["aes", "chacha"], default="aes")
    p.add_argument("--block-size", type=int, default=1024, help="Block size in KB (default: 1024)")
    p.add_argument("--workers", type=int, default=4, help="Parallel workers")
    
    # unpack
    p = sub.add_parser("unpack", help="Unpack a V6 container")
    p.add_argument("input",  help="Input .qltx path")
    p.add_argument("output", help="Output file path")
    p.add_argument("--passphrase", required=True)
    p.add_argument("--no-verify", action="store_true", help="Skip integrity checks")
    p.add_argument("--workers", type=int, default=4)
    
    # seek
    p = sub.add_parser("seek", help="Extract a byte range from a V6 container")
    p.add_argument("input", help="Input .qltx path")
    p.add_argument("--offset", type=int, required=True, help="Start byte offset")
    p.add_argument("--length", type=int, required=True, help="Number of bytes")
    p.add_argument("--passphrase", required=True)
    p.add_argument("--output", help="Save extracted bytes to file")
    p.add_argument("--no-verify", action="store_true")
    p.add_argument("--workers", type=int, default=4)
    
    # gateway
    p = sub.add_parser("gateway", help="Run V6 encryption gateway/router")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=7620)
    p.add_argument("--passphrase", required=True)
    p.add_argument("--cipher", choices=["aes", "chacha"], default="aes")
    p.add_argument("--dest-host", help="Route encrypted stream to this host")
    p.add_argument("--dest-port", type=int)
    p.add_argument("--workers", type=int, default=4)
    
    # serve
    p = sub.add_parser("serve", help="HTTP server with Range Request support")
    p.add_argument("input", help="Input .qltx path")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=7621)
    p.add_argument("--passphrase", required=True)
    p.add_argument("--workers", type=int, default=4)
    
    # info
    p = sub.add_parser("info", help="Show container metadata")
    p.add_argument("input", help="Input .qltx path")
    
    args = parser.parse_args()
    
    cmds = {
        "pack":    cmd_pack,
        "unpack":  cmd_unpack,
        "seek":    cmd_seek,
        "gateway": cmd_gateway,
        "serve":   cmd_serve,
        "info":    cmd_info,
    }
    cmds[args.command](args)


if __name__ == "__main__":
    main()
