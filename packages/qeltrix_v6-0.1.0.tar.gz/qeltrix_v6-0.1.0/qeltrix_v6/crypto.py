"""
qeltrix_v6/crypto.py - All cryptographic operations for Qeltrix V6.

Uses Python's `cryptography` library exclusively for:
  - AES-256-GCM AEAD
  - ChaCha20-Poly1305 AEAD
  - HKDF-SHA256 (Content Derived Key generation)
  - SHA-256 hashing
  - Random IV/salt/key generation

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0
"""

import os
import hashlib
import struct
from typing import Tuple, Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend

# ─── Cipher IDs ─────────────────────────────────────────────────────
CIPHER_AES256_GCM       = 0
CIPHER_CHACHA20_POLY1305 = 1

CIPHER_NAMES = {
    CIPHER_AES256_GCM:        "AES256-GCM",
    CIPHER_CHACHA20_POLY1305: "ChaCha20-Poly1305",
}

# ─── Key / IV sizes ─────────────────────────────────────────────────
AES_KEY_SIZE   = 32   # 256-bit
AES_IV_SIZE    = 12   # 96-bit for GCM
CHACHA_KEY_SIZE= 32   # 256-bit
CHACHA_IV_SIZE = 12   # 96-bit
SALT_SIZE      = 32   # 256-bit HKDF salt
MASTER_KEY_SIZE= 32   # 256-bit master key

# ─── Random generation ──────────────────────────────────────────────

def random_bytes(n: int) -> bytes:
    """Cryptographically secure random bytes."""
    return os.urandom(n)

def random_key(cipher_id: int = CIPHER_AES256_GCM) -> bytes:
    if cipher_id == CIPHER_CHACHA20_POLY1305:
        return random_bytes(CHACHA_KEY_SIZE)
    return random_bytes(AES_KEY_SIZE)

def random_iv(cipher_id: int = CIPHER_AES256_GCM) -> bytes:
    if cipher_id == CIPHER_CHACHA20_POLY1305:
        return random_bytes(CHACHA_IV_SIZE)
    return random_bytes(AES_IV_SIZE)

def random_salt() -> bytes:
    return random_bytes(SALT_SIZE)

def random_master_key() -> bytes:
    return random_bytes(MASTER_KEY_SIZE)

# ─── Hashing ────────────────────────────────────────────────────────

def sha256(data: bytes) -> bytes:
    """SHA-256 of data. Returns 32 bytes."""
    return hashlib.sha256(data).digest()

def sha256_file(path: str, chunk_size: int = 1 << 20) -> bytes:
    """Streaming SHA-256 of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.digest()

# ─── HKDF - Content Derived Key (CDK) ───────────────────────────────

def derive_cdk(
    master_key: bytes,
    block_index: int,
    block_data_hash: bytes,
    salt: bytes,
    cipher_id: int = CIPHER_AES256_GCM,
    key_size: int = AES_KEY_SIZE
) -> bytes:
    """
    Derive a per-block Content Derived Key (CDK) using HKDF-SHA256.

    Inputs:
      - master_key: The root MK
      - block_index: Block sequence number (binds key to position)
      - block_data_hash: SHA-256 of uncompressed block data (binds key to content)
      - salt: Random per-block salt
      - cipher_id: Which cipher (determines output key length)
      - key_size: Override key length

    The CDK is mathematically tied to both the content AND its position,
    providing dual-layer binding as per V6cs design.
    """
    info = (
        b"QeltrixV6-CDK"
        + struct.pack(">Q", block_index)
        + block_data_hash
        + bytes([cipher_id])
    )
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=key_size,
        salt=salt,
        info=info,
        backend=default_backend()
    )
    return hkdf.derive(master_key)

# ─── AEAD Encryption ─────────────────────────────────────────────────

def encrypt_block(
    plaintext: bytes,
    key: bytes,
    iv: bytes,
    cipher_id: int = CIPHER_AES256_GCM,
    aad: bytes = b""
) -> bytes:
    """
    AEAD encrypt a block. Returns ciphertext + tag (auth tag appended).
    
    AES-256-GCM: 16-byte tag appended by cryptography library.
    ChaCha20-Poly1305: 16-byte tag appended by cryptography library.
    """
    if cipher_id == CIPHER_CHACHA20_POLY1305:
        chacha = ChaCha20Poly1305(key)
        return chacha.encrypt(iv, plaintext, aad or None)
    else:
        aesgcm = AESGCM(key)
        return aesgcm.encrypt(iv, plaintext, aad or None)


def decrypt_block(
    ciphertext: bytes,
    key: bytes,
    iv: bytes,
    cipher_id: int = CIPHER_AES256_GCM,
    aad: bytes = b""
) -> bytes:
    """
    AEAD decrypt a block. Raises InvalidTag if authentication fails.
    Caller should catch cryptography.exceptions.InvalidTag.
    """
    if cipher_id == CIPHER_CHACHA20_POLY1305:
        chacha = ChaCha20Poly1305(key)
        return chacha.decrypt(iv, ciphertext, aad or None)
    else:
        aesgcm = AESGCM(key)
        return aesgcm.decrypt(iv, ciphertext, aad or None)


# ─── V6-C Metadata encryption ────────────────────────────────────────

def encrypt_v6c_metadata(metadata_bytes: bytes, master_key: bytes) -> Tuple[bytes, bytes]:
    """
    Encrypt the V6-C metadata block with the master key.
    Returns (encrypted_metadata, iv).
    """
    iv = random_iv(CIPHER_AES256_GCM)
    encrypted = encrypt_block(metadata_bytes, master_key, iv, CIPHER_AES256_GCM,
                              aad=b"V6C-METADATA")
    return encrypted, iv


def decrypt_v6c_metadata(encrypted: bytes, master_key: bytes, iv: bytes) -> bytes:
    """Decrypt V6-C metadata block."""
    return decrypt_block(encrypted, master_key, iv, CIPHER_AES256_GCM,
                         aad=b"V6C-METADATA")


# ─── CDK wrapping (Dual-layer security) ──────────────────────────────

def wrap_cdk(cdk: bytes, master_key: bytes) -> Tuple[bytes, bytes]:
    """
    Encrypt the CDK with the master key (Layer 1 of dual-layer security).
    Returns (wrapped_cdk, iv).  wrapped_cdk is 48 bytes (32 + 16 tag).
    """
    iv = random_iv(CIPHER_AES256_GCM)
    wrapped = encrypt_block(cdk, master_key, iv, CIPHER_AES256_GCM,
                            aad=b"V6C-CDK-WRAP")
    return wrapped, iv


def unwrap_cdk(wrapped_cdk: bytes, master_key: bytes, iv: bytes) -> bytes:
    """Decrypt a wrapped CDK."""
    return decrypt_block(wrapped_cdk, master_key, iv, CIPHER_AES256_GCM,
                         aad=b"V6C-CDK-WRAP")


# ─── Master key storage (simple symmetric wrap for demos) ────────────

def wrap_master_key(master_key: bytes, passphrase: bytes) -> Tuple[bytes, bytes, bytes]:
    """
    Protect the master key with a passphrase using HKDF + AES-GCM.
    Returns (wrapped_mk, iv, salt).
    
    In production: use RSA-OAEP or other asymmetric scheme.
    """
    salt = random_salt()
    wrap_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=b"QeltrixV6-MasterKeyWrap",
        backend=default_backend()
    ).derive(passphrase)
    
    iv = random_iv(CIPHER_AES256_GCM)
    wrapped = encrypt_block(master_key, wrap_key, iv, CIPHER_AES256_GCM,
                            aad=b"V6-MK-WRAP")
    return wrapped, iv, salt


def unwrap_master_key(wrapped_mk: bytes, passphrase: bytes,
                      iv: bytes, salt: bytes) -> bytes:
    """Recover the master key from a wrapped version."""
    wrap_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=b"QeltrixV6-MasterKeyWrap",
        backend=default_backend()
    ).derive(passphrase)
    return decrypt_block(wrapped_mk, wrap_key, iv, CIPHER_AES256_GCM,
                         aad=b"V6-MK-WRAP")


# ─── Footer integrity ────────────────────────────────────────────────

def hash_footer_entries(index_entries: list[bytes]) -> bytes:
    """SHA-256 of all serialized index entries concatenated."""
    h = hashlib.sha256()
    for entry in index_entries:
        h.update(entry)
    return h.digest()
