"""
qeltrix_v6/container.py - V6 container Pack/Unpack with parallel processing.

  pack()   : file/stream -> .qltx V6 container
  unpack() : .qltx V6 container -> original file/stream
  seek()   : random-access extraction from a V6 container

Uses ThreadPoolExecutor (cross-platform, works on Windows without __main__ guard).

Author: Muhammed Shafin P (@hejhdiss)
License: CC BY-SA 4.0
"""

import os
import io
import struct
import zlib
import hashlib
import logging
import ctypes
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Optional, Callable

# ── All imports at module level (never use relative imports in worker fns) ──
from qeltrix_v6 import _clib
from qeltrix_v6 import crypto

logger = logging.getLogger("qeltrix_v6")

DEFAULT_BLOCK_SIZE = 1 << 20   # 1 MB
MAX_WORKERS        = min(os.cpu_count() or 4, 16)


# ─── Data classes ──────────────────────────────────────────────────────────

@dataclass
class BlockIndexEntry:
    block_index:      int
    original_offset:  int
    original_size:    int
    container_offset: int
    container_size:   int
    block_hash:       bytes
    iv:               bytes
    salt:             bytes
    cipher_id:        int


@dataclass
class V6PackResult:
    container_path: str
    total_blocks:   int
    original_size:  int
    block_size:     int
    cipher_id:      int
    elapsed_s:      float


@dataclass
class V6UnpackResult:
    output_path:  str
    total_blocks: int
    original_size: int
    elapsed_s:    float
    integrity_ok: bool


# ─── Block processing (runs in ThreadPoolExecutor workers) ─────────────────

def _pack_one_block(block_index, raw_data, master_key, cipher_id):
    """
    Compress + permute + encrypt one block.
    Returns a dict with all result fields.
    All imports are module-level to be Windows thread-safe.
    """
    # 1. Hash original data
    block_hash = hashlib.sha256(raw_data).digest()

    # 2. Compress
    compressed = zlib.compress(raw_data, level=6)

    # 3. Per-block crypto params
    salt = crypto.random_salt()
    iv   = crypto.random_iv(cipher_id)

    # 4. Derive CDK (V6cs mode)
    cdk = crypto.derive_cdk(master_key, block_index, block_hash, salt, cipher_id)

    # 5. Permute compressed data using block_hash as seed
    permuted = _clib.permute_block(compressed, block_hash)

    # 6. AEAD encrypt with CDK
    aad     = struct.pack(">Q", block_index)
    payload = crypto.encrypt_block(permuted, cdk, iv, cipher_id, aad=aad)

    # 7. Wrap CDK with master key (Layer 1 dual-layer security)
    wrapped_cdk, cdk_iv = crypto.wrap_cdk(cdk, master_key)

    # 8. Build cdk_blob: [cdk_iv 12] [wrapped_cdk 48] [padding 4] = 64 bytes
    cdk_blob = cdk_iv + wrapped_cdk + b'\x00' * (64 - len(cdk_iv) - len(wrapped_cdk))

    # 9. Build V6-C metadata struct
    v6c_raw = _clib.make_v6c(
        block_index, len(raw_data), len(compressed),
        block_hash, iv, salt, cdk_blob[:64], cipher_id
    )

    # 10. Encrypt V6-C metadata (Layer 2 dual-layer security)
    enc_v6c, v6c_iv = crypto.encrypt_v6c_metadata(v6c_raw, master_key)

    return {
        "block_index":  block_index,
        "v6c_iv":       v6c_iv,
        "enc_v6c":      enc_v6c,
        "payload":      payload,
        "block_hash":   block_hash,
        "iv":           iv,
        "salt":         salt,
        "cipher_id":    cipher_id,
        "orig_sz":      len(raw_data),
        "comp_sz":      len(compressed),
    }


def _unpack_one_block(block_index, enc_v6c, v6c_iv, payload, master_key, no_verify):
    """
    Decrypt + unpermute + decompress one block.
    Returns (block_index, original_data).
    All imports are module-level to be Windows thread-safe.
    """
    # 1. Decrypt V6-C metadata
    v6c_raw = crypto.decrypt_v6c_metadata(enc_v6c, master_key, v6c_iv)

    # 2. Parse V6-C struct via ctypes
    lib = _clib.get_lib()

    bi_   = ctypes.c_uint64(0)
    osiz_ = ctypes.c_uint64(0)
    csiz_ = ctypes.c_uint64(0)
    dhash = (ctypes.c_uint8 * 32)()
    iv_   = (ctypes.c_uint8 * 16)()
    salt_ = (ctypes.c_uint8 * 32)()
    cdk_b = (ctypes.c_uint8 * 64)()
    cid_  = ctypes.c_uint8(0)

    rc = lib.qltx_read_v6c(
        _clib._bytes_ptr(v6c_raw),
        ctypes.byref(bi_), ctypes.byref(osiz_), ctypes.byref(csiz_),
        dhash, iv_, salt_, cdk_b, ctypes.byref(cid_)
    )
    if rc != 0:
        raise ValueError(f"Block {block_index}: bad V6-C magic (rc={rc})")

    block_hash = bytes(dhash)
    cipher_id  = int(cid_.value)
    iv         = bytes(iv_)[:12]   # stored in 16-byte field, only 12 used
    salt       = bytes(salt_)
    cdk_blob   = bytes(cdk_b)

    # 3. Unwrap CDK
    cdk_iv      = cdk_blob[:12]
    wrapped_cdk = cdk_blob[12:60]   # 32-byte key + 16-byte GCM tag = 48 bytes
    cdk = crypto.unwrap_cdk(wrapped_cdk, master_key, cdk_iv)

    # 4. Decrypt payload
    aad      = struct.pack(">Q", block_index)
    permuted = crypto.decrypt_block(payload, cdk, iv, cipher_id, aad=aad)

    # 5. Unpermute
    compressed = _clib.unpermute_block(permuted, block_hash)

    # 6. Decompress
    raw_data = zlib.decompress(compressed)

    # 7. Integrity check
    if not no_verify:
        actual = hashlib.sha256(raw_data).digest()
        if actual != block_hash:
            raise ValueError(f"Block {block_index}: integrity FAILED "
                             f"(expected {block_hash.hex()[:16]}... "
                             f"got {actual.hex()[:16]}...)")

    return block_index, raw_data


# ─── Footer serialization ──────────────────────────────────────────────────

def _serialize_footer(entries: list) -> bytes:
    """Serialize footer: 48-byte base header + all index entries."""
    entry_size   = _clib.index_entry_size()
    entries_data = bytearray()
    lib          = _clib.get_lib()

    for e in entries:
        buf = (ctypes.c_uint8 * entry_size)()
        # Keep byte buffers alive until after the C call (avoids dangling ptr on Windows)
        _hash = (e.block_hash + b'\x00'*32)[:32]
        _iv   = (e.iv   + b'\x00'*16)[:16]
        _salt = (e.salt + b'\x00'*32)[:32]
        lib.qltx_write_index_entry(
            buf,
            e.block_index, e.original_offset, e.original_size,
            e.container_offset, e.container_size,
            _clib._bytes_ptr(_hash),
            _clib._bytes_ptr(_iv),
            _clib._bytes_ptr(_salt),
            e.cipher_id
        )
        entries_data.extend(bytes(buf))

    footer_hash = crypto.hash_footer_entries([bytes(entries_data)])
    footer_base = b"QLTXFOOT" + struct.pack("<Q", len(entries)) + footer_hash
    return footer_base + bytes(entries_data)


def _parse_footer(data: bytes) -> list:
    """Deserialize footer into list of BlockIndexEntry."""
    if len(data) < 8 or data[:8] != b"QLTXFOOT":
        raise ValueError(f"Invalid footer magic: {data[:8]!r}")

    block_count = struct.unpack_from("<Q", data, 8)[0]
    entry_size  = _clib.index_entry_size()
    entries_start = 48   # 8 magic + 8 count + 32 hash

    entries = []
    for i in range(block_count):
        off = entries_start + i * entry_size
        e   = data[off : off + entry_size]
        if len(e) < entry_size:
            raise ValueError(f"Footer truncated at entry {i}")
        # C struct layout (packed, little-endian):
        # block_idx(8) orig_off(8) orig_sz(8) cont_off(8) cont_sz(8)
        # block_hash(32) iv(16) salt(32) cipher(1) reserved(7)
        (bidx, oo, os_, co, cs) = struct.unpack_from("<QQQQQ", e, 0)
        bh   = e[40:72]
        iv_  = e[72:88]
        sl_  = e[88:120]
        cid  = e[120]
        entries.append(BlockIndexEntry(
            block_index=bidx, original_offset=oo, original_size=os_,
            container_offset=co, container_size=cs,
            block_hash=bh, iv=iv_, salt=sl_, cipher_id=cid,
        ))
    return entries


def _read_container_index(container_path: str):
    """Read header + footer. Returns (header_info dict, [BlockIndexEntry])."""
    hdr_size = _clib.header_size()
    with open(container_path, "rb") as f:
        hdr = f.read(hdr_size)

    if len(hdr) < 8 or hdr[:4] != b"QLTX" or hdr[4] != 6:
        raise ValueError(f"Not a valid Qeltrix V6 container: {container_path!r}")

    # Header layout after magic(4): version(1) flags(1) cipher(2) then 8-byte fields
    (version, flags, cipher_default,
     block_size, total_blocks, orig_size,
     footer_offset, footer_size) = struct.unpack_from("<BBHQQQQQ", hdr, 4)

    hdr_info = {
        "version":        version,
        "flags":          flags,
        "cipher_default": cipher_default,
        "block_size":     block_size,
        "total_blocks":   total_blocks,
        "original_size":  orig_size,
        "footer_offset":  footer_offset,
        "footer_size":    footer_size,
    }

    with open(container_path, "rb") as f:
        f.seek(footer_offset)
        footer_data = f.read(footer_size)

    entries = _parse_footer(footer_data)
    return hdr_info, entries


# ─── Pack ──────────────────────────────────────────────────────────────────

def pack(
    source,
    output_path: str,
    master_key: bytes,
    block_size: int = DEFAULT_BLOCK_SIZE,
    cipher_id: int = crypto.CIPHER_AES256_GCM,
    flags: int = 0,
    workers: int = MAX_WORKERS,
    progress_cb: Optional[Callable] = None
) -> V6PackResult:
    """
    Pack a file path / bytes / file-like into a Qeltrix V6 container.

    Args:
        source:      File path (str), bytes, or readable file-like object
        output_path: Destination .qltx file path
        master_key:  32-byte master key (V6cs mode)
        block_size:  Block size in bytes (default 1 MB)
        cipher_id:   CIPHER_AES256_GCM or CIPHER_CHACHA20_POLY1305
        flags:       V6 header flags
        workers:     ThreadPoolExecutor worker count
        progress_cb: Optional callback(blocks_done, total_blocks)

    Returns:
        V6PackResult
    """
    import time
    start = time.monotonic()

    # Read source
    if isinstance(source, (str, os.PathLike)):
        with open(source, "rb") as f:
            raw = f.read()
    elif isinstance(source, (bytes, bytearray)):
        raw = bytes(source)
    else:
        raw = source.read()

    original_size = len(raw)
    total_blocks  = _clib.block_count(original_size, block_size)

    logger.info(f"Packing {original_size:,} bytes -> {total_blocks} blocks "
                f"(block_size={block_size}, cipher={crypto.CIPHER_NAMES[cipher_id]})")

    # Submit all blocks to thread pool
    results_map = {}   # block_index -> result dict
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {}
        for i in range(total_blocks):
            off, sz = _clib.block_range(i, original_size, block_size)
            f = pool.submit(_pack_one_block, i, raw[off:off+sz], master_key, cipher_id)
            futures[f] = i

        done = 0
        for future in as_completed(futures):
            result = future.result()   # raises if worker threw
            results_map[result["block_index"]] = result
            done += 1
            if progress_cb:
                progress_cb(done, total_blocks)

    # Write container file
    index_entries = []
    hdr_placeholder = _clib.make_header(
        block_size, total_blocks, original_size, 0, 0, flags, cipher_id
    )

    with open(output_path, "wb") as f:
        f.write(hdr_placeholder)
        current_offset = len(hdr_placeholder)

        for i in range(total_blocks):
            r = results_map[i]
            v6c_iv   = r["v6c_iv"]
            enc_v6c  = r["enc_v6c"]
            payload  = r["payload"]

            v6c_field_size = len(v6c_iv) + len(enc_v6c)   # 12 + N
            prefix = _clib.make_block_prefix(i, v6c_field_size, len(payload))

            block_start = current_offset
            data_out    = prefix + v6c_iv + enc_v6c + payload
            f.write(data_out)
            block_total = len(data_out)
            current_offset += block_total

            index_entries.append(BlockIndexEntry(
                block_index=i,
                original_offset=i * block_size,
                original_size=r["orig_sz"],
                container_offset=block_start,
                container_size=block_total,
                block_hash=(r["block_hash"] + b'\x00'*32)[:32],
                iv=(r["iv"]   + b'\x00'*16)[:16],
                salt=(r["salt"] + b'\x00'*32)[:32],
                cipher_id=r["cipher_id"],
            ))

        # Write footer
        footer_offset = current_offset
        footer_data   = _serialize_footer(index_entries)
        footer_size   = len(footer_data)
        f.write(footer_data)

        # Patch header with correct footer_offset / footer_size
        real_hdr = _clib.make_header(
            block_size, total_blocks, original_size,
            footer_offset, footer_size, flags, cipher_id
        )
        f.seek(0)
        f.write(real_hdr)

    elapsed = time.monotonic() - start
    logger.info(f"Pack done: {output_path} in {elapsed:.3f}s")
    return V6PackResult(
        container_path=output_path,
        total_blocks=total_blocks,
        original_size=original_size,
        block_size=block_size,
        cipher_id=cipher_id,
        elapsed_s=elapsed,
    )


# ─── Unpack ────────────────────────────────────────────────────────────────

def unpack(
    container_path: str,
    output_path: str,
    master_key: bytes,
    no_verify: bool = False,
    workers: int = MAX_WORKERS,
    progress_cb: Optional[Callable] = None
) -> V6UnpackResult:
    """
    Unpack a Qeltrix V6 container to the original file.

    Args:
        container_path: Path to the .qltx file
        output_path:    Destination file path
        master_key:     32-byte master key
        no_verify:      Skip per-block hash checks (faster, lower security)
        workers:        ThreadPoolExecutor worker count
        progress_cb:    Optional callback(blocks_done, total_blocks)

    Returns:
        V6UnpackResult
    """
    import time
    start = time.monotonic()

    hdr_info, index_entries = _read_container_index(container_path)
    total_blocks  = hdr_info["total_blocks"]
    original_size = hdr_info["original_size"]

    logger.info(f"Unpacking {total_blocks} blocks -> {original_size:,} bytes")

    prefix_size = _clib.block_prefix_size()

    # Read all encrypted block data from file (sequential I/O first)
    block_jobs = []
    with open(container_path, "rb") as f:
        for entry in sorted(index_entries, key=lambda e: e.block_index):
            f.seek(entry.container_offset)
            prefix_bytes = f.read(prefix_size)
            bidx, v6c_field_size, payload_size = _clib.parse_block_prefix(prefix_bytes)
            v6c_iv  = f.read(12)
            enc_v6c = f.read(v6c_field_size - 12)
            payload = f.read(payload_size)
            block_jobs.append((int(bidx), enc_v6c, v6c_iv, payload))

    # Decrypt in parallel
    results_map = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(_unpack_one_block,
                        bidx, enc_v6c, v6c_iv, payload, master_key, no_verify): bidx
            for (bidx, enc_v6c, v6c_iv, payload) in block_jobs
        }
        done = 0
        for future in as_completed(futures):
            block_idx, data = future.result()   # raises on crypto error
            results_map[block_idx] = data
            done += 1
            if progress_cb:
                progress_cb(done, total_blocks)

    # Write output in order
    with open(output_path, "wb") as f:
        for i in range(total_blocks):
            if i not in results_map:
                raise RuntimeError(f"Block {i} missing from results")
            f.write(results_map[i])

    elapsed = time.monotonic() - start
    logger.info(f"Unpack done: {output_path} in {elapsed:.3f}s")
    return V6UnpackResult(
        output_path=output_path,
        total_blocks=total_blocks,
        original_size=original_size,
        elapsed_s=elapsed,
        integrity_ok=True,
    )


# ─── Seek ──────────────────────────────────────────────────────────────────

def seek_extract(
    container_path: str,
    seek_offset: int,
    seek_len: int,
    master_key: bytes,
    no_verify: bool = False,
    workers: int = MAX_WORKERS,
) -> bytes:
    """
    Extract a byte range from a V6 container without full unpack.
    Only the blocks that contain the requested bytes are decrypted.

    Args:
        container_path: Path to the .qltx file
        seek_offset:    Start byte in the original (unencrypted) file
        seek_len:       Number of bytes to extract
        master_key:     32-byte master key
        no_verify:      Skip hash verification for speed

    Returns:
        Extracted bytes (exactly seek_len bytes when available)
    """
    hdr_info, index_entries = _read_container_index(container_path)
    block_size    = hdr_info["block_size"]
    original_size = hdr_info["original_size"]

    needed    = _clib.seek_blocks(seek_offset, seek_len, original_size, block_size)
    entry_map = {e.block_index: e for e in index_entries}
    prefix_size = _clib.block_prefix_size()

    block_jobs = []
    with open(container_path, "rb") as f:
        for bidx in needed:
            entry = entry_map[bidx]
            f.seek(entry.container_offset)
            prefix_bytes    = f.read(prefix_size)
            b2, v6c_fsz, ps = _clib.parse_block_prefix(prefix_bytes)
            v6c_iv  = f.read(12)
            enc_v6c = f.read(v6c_fsz - 12)
            payload = f.read(ps)
            block_jobs.append((int(bidx), enc_v6c, v6c_iv, payload))

    results_map = {}
    with ThreadPoolExecutor(max_workers=min(workers, len(block_jobs) or 1)) as pool:
        futures = {
            pool.submit(_unpack_one_block,
                        bidx, enc_v6c, v6c_iv, payload, master_key, no_verify): bidx
            for (bidx, enc_v6c, v6c_iv, payload) in block_jobs
        }
        for future in as_completed(futures):
            block_idx, data = future.result()
            results_map[block_idx] = data

    # Assemble just the requested byte range
    out = bytearray()
    for bidx in sorted(needed):
        block_data  = results_map[bidx]
        block_start = bidx * block_size
        s = max(0, seek_offset - block_start)
        e = min(len(block_data), seek_offset + seek_len - block_start)
        if s < e:
            out.extend(block_data[s:e])

    return bytes(out)
