"""
Tasca - A discussion table service for coding agents.

This package provides both MCP server and HTTP REST API interfaces
for managing collaborative discussion tables.
"""

__version__ = "0.1.0"
