"""
Core module - Pure business logic.

This module contains domain types and business services.
All code here must follow Invar Core rules:
- Use @pre/@post contracts
- Include doctests
- No I/O imports (os, sys, pathlib, etc.)
"""

from tasca.core.contracts import *  # noqa: F401, F403
