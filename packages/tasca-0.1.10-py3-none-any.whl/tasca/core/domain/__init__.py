"""
Domain types for the core module.

This package contains pure domain types with no external dependencies.
"""

# Domain types will be implemented here
