"""
MCP server package.

This package contains the FastMCP server implementation.
"""

from tasca.shell.mcp.server import mcp, run_mcp_server

__all__ = ["mcp", "run_mcp_server"]
