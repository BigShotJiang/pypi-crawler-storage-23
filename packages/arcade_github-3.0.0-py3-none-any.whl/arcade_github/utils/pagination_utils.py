from typing import Any

from arcade_github.models.tool_outputs.common import PaginationInfo


def build_pagination_info(
    page: int,
    per_page: int,
    items: list[Any],
    total_count: int | None = None,
) -> PaginationInfo:
    """
    Build pagination information for list responses.

    Args:
        page: Current page number
        per_page: Items per page
        items: List of items returned
        total_count: Total number of items (optional, from search API)

    Returns:
        Pagination information
    """
    result: PaginationInfo = {
        "page": page,
        "per_page": per_page,
        "has_next_page": len(items) == per_page,
    }
    if total_count is not None:
        result["total_count"] = total_count
    return result
