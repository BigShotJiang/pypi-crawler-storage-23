from typing import cast

from arcade_github.models.mappers import map_repository
from arcade_github.models.tool_outputs.repositories import (
    RecentBranchData,
    RepoSearchOutput,
    RepositoryOutput,
)
from arcade_github.utils import repo_utils
from arcade_github.utils.github_api_client import GitHubAPIClient


async def build_repo_search_result(
    *,
    client: GitHubAPIClient,
    scope_value: str,
    repo_sources: list[repo_utils.RepoSource],
    best_match: repo_utils.RepoMatch | None,
    suggestions: list[repo_utils.RepoMatch],
    branch_limit: int,
    sources_list: list[str],
) -> RepoSearchOutput:
    branch_cache: dict[str, list[RecentBranchData]] = {}

    async def _attach_recent_branches(repo_payload: RepositoryOutput) -> None:
        if branch_limit <= 0:
            return
        full_name = repo_payload.get("full_name")
        if not full_name or "/" not in full_name:
            return
        cache_key = full_name.lower()
        if cache_key not in branch_cache:
            owner, repo_name = full_name.split("/", 1)
            branch_data = await repo_utils.fetch_recent_branches(
                client=client,
                owner=owner,
                repo=repo_name,
                limit=branch_limit,
            )
            branch_cache[cache_key] = cast(list[RecentBranchData], branch_data)
        repo_payload["recent_branches"] = branch_cache[cache_key]

    suggestion_payloads: list[RepositoryOutput] = []
    for match in suggestions:
        repo_payload = map_repository(match.repo)
        await _attach_recent_branches(repo_payload)
        suggestion_payloads.append(repo_payload)

    result: RepoSearchOutput = {
        "suggestions": suggestion_payloads,
        "sources_searched": sources_list,
        "total_repos_searched": len(repo_sources),
        "search_scope": scope_value,
    }

    if best_match:
        matched_repo = map_repository(best_match.repo)
        await _attach_recent_branches(matched_repo)
        result["matched_repository"] = matched_repo
        result["confidence"] = best_match.score

    return result
