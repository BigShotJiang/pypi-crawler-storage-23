import asyncio
import base64
import re
from typing import Any, ClassVar, cast

import httpx
from arcade_tdk import ToolContext

from arcade_github.constants import ENDPOINTS
from arcade_github.models.api_responses import (
    ActivityResponse,
    CommentResponse,
    CommitResponse,
    IssueResponse,
    LabelResponse,
    ProjectV2FieldResponse,
    ProjectV2ItemResponse,
    ProjectV2Response,
    PullRequestFileResponse,
    PullRequestResponse,
    RepositoryResponse,
    StargazerResponse,
)
from arcade_github.utils.error_utils import wrap_github_422_error


class GitHubAPIClient:
    """
    GitHub API client with HTTP/2 support, connection pooling, and retry logic.
    """

    _clients: ClassVar[dict[str, httpx.AsyncClient]] = {}
    _client_locks: ClassVar[dict[str, asyncio.Lock]] = {}
    _global_lock: ClassVar[asyncio.Lock] = asyncio.Lock()

    def __init__(self, base_url: str, token: str):
        self.base_url = base_url
        self.token = token
        self._client: httpx.AsyncClient | None = None
        self._base_url_for_client = base_url

    @staticmethod
    def get_base_url(context: ToolContext) -> str:
        """Get GitHub server URL from context secret (required)."""
        return context.get_secret("GITHUB_SERVER_URL")

    @staticmethod
    def get_token(context: ToolContext) -> str:
        """Extract the authorization token from the tool context."""
        if context.authorization and context.authorization.token:
            return context.authorization.token
        return ""

    async def star_repository(self, owner: str, repo: str) -> None:
        """Star a repository."""
        url = self._build_url("user_starred", owner=owner, repo=repo)
        headers = self._get_json_headers()
        await self._request_with_retry("PUT", url, headers=headers)

    async def unstar_repository(self, owner: str, repo: str) -> None:
        """Unstar a repository."""
        url = self._build_url("user_starred", owner=owner, repo=repo)
        headers = self._get_json_headers()
        await self._request_with_retry("DELETE", url, headers=headers)

    async def list_repository_stargazers(
        self, owner: str, repo: str, per_page: int = 100, page: int = 1
    ) -> list[StargazerResponse]:
        """List stargazers for a repository."""
        url = self._build_url("repo_stargazers", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[StargazerResponse], response.json())

    async def create_repository_issue(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str | None = None,
        assignees: list[str] | None = None,
        milestone: int | None = None,
        labels: list[str] | None = None,
    ) -> IssueResponse:
        """Create an issue in a repository."""
        url = self._build_url("repo_issues", owner=owner, repo=repo)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "title": title,
            "body": body,
            "assignees": assignees,
            "milestone": milestone,
            "labels": labels,
        })
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(IssueResponse, response.json())

    async def update_repository_issue(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        title: str | None = None,
        body: str | None = None,
        state: str | None = None,
        labels: list[str] | None = None,
        assignees: list[str] | None = None,
        milestone: int | None = None,
    ) -> IssueResponse:
        """Update an issue in a repository."""
        url = self._build_url("repo_issue", owner=owner, repo=repo, issue_number=issue_number)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "title": title,
            "body": body,
            "state": state,
            "labels": labels,
            "assignees": assignees,
            "milestone": milestone,
        })
        response = await self._request_with_retry("PATCH", url, headers=headers, json=data)
        return cast(IssueResponse, response.json())

    async def create_issue_comment(
        self, owner: str, repo: str, issue_number: int, body: str
    ) -> CommentResponse:
        """Create a comment on an issue."""
        url = self._build_url(
            "repo_issue_comments", owner=owner, repo=repo, issue_number=issue_number
        )
        headers = self._get_json_headers()
        data = {"body": body}
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(CommentResponse, response.json())

    async def list_repository_labels(
        self, owner: str, repo: str, per_page: int = 100, page: int = 1
    ) -> list[LabelResponse]:
        """List all labels in a repository."""
        url = self._build_url("repo_labels", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[LabelResponse], response.json())

    async def add_issue_labels(
        self, owner: str, repo: str, issue_number: int, labels: list[str]
    ) -> list[LabelResponse]:
        """Add labels to an issue or pull request."""
        url = self._build_url(
            "repo_issue_labels", owner=owner, repo=repo, issue_number=issue_number
        )
        headers = self._get_json_headers()
        data = {"labels": labels}
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(list[LabelResponse], response.json())

    async def remove_issue_label(
        self, owner: str, repo: str, issue_number: int, label_name: str
    ) -> list[LabelResponse]:
        """Remove a label from an issue or pull request."""
        url = self._build_url(
            "repo_issue_label", owner=owner, repo=repo, issue_number=issue_number, name=label_name
        )
        headers = self._get_json_headers()
        response = await self._request_with_retry("DELETE", url, headers=headers)
        return cast(list[LabelResponse], response.json())

    async def list_repository_issues(
        self,
        owner: str,
        repo: str,
        state: str | None = None,
        labels: str | None = None,
        sort: str | None = None,
        direction: str | None = None,
        since: str | None = None,
        per_page: int = 30,
        page: int = 1,
        milestone: str | None = None,
        assignee: str | None = None,
        creator: str | None = None,
        mentioned: str | None = None,
    ) -> list[IssueResponse]:
        """List issues in a repository."""
        url = self._build_url("repo_issues", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "state": state,
            "labels": labels,
            "sort": sort,
            "direction": direction,
            "since": since,
            "per_page": per_page,
            "page": page,
            "milestone": milestone,
            "assignee": assignee,
            "creator": creator,
            "mentioned": mentioned,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[IssueResponse], response.json())

    async def get_repository_issue(self, owner: str, repo: str, issue_number: int) -> IssueResponse:
        """Get a specific issue from a repository."""
        url = self._build_url("repo_issue", owner=owner, repo=repo, issue_number=issue_number)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(IssueResponse, response.json())

    async def get_repository(self, owner: str, repo: str) -> RepositoryResponse:
        """Get repository information."""
        url = self._build_url("repo", owner=owner, repo=repo)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(RepositoryResponse, response.json())

    async def list_organization_repositories(
        self,
        org: str,
        repo_type: str = "all",
        sort: str = "created",
        direction: str = "asc",
        per_page: int = 30,
        page: int = 1,
    ) -> list[RepositoryResponse]:
        """List repositories for an organization."""
        url = self._build_url("org_repos", org=org)
        headers = self._get_json_headers()
        params = {
            "type": repo_type,
            "sort": sort,
            "direction": direction,
            "per_page": per_page,
            "page": page,
        }
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[RepositoryResponse], response.json())

    async def list_repository_activities(
        self,
        owner: str,
        repo: str,
        direction: str | None = None,
        per_page: int = 30,
        before: str | None = None,
        after: str | None = None,
        ref: str | None = None,
        actor: str | None = None,
        time_period: str | None = None,
        activity_type: str | None = None,
    ) -> list[ActivityResponse]:
        """List activities for a repository."""
        url = self._build_url("repo_activity", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "direction": direction,
            "per_page": per_page,
            "before": before,
            "after": after,
            "ref": ref,
            "actor": actor,
            "time_period": time_period,
            "activity_type": activity_type,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[ActivityResponse], response.json())

    async def list_repository_review_comments(
        self,
        owner: str,
        repo: str,
        sort: str | None = None,
        direction: str | None = None,
        since: str | None = None,
        per_page: int = 30,
        page: int = 1,
    ) -> list[CommentResponse]:
        """List review comments in a repository."""
        url = self._build_url("repo_pulls_comments", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "sort": sort,
            "direction": direction,
            "since": since,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[CommentResponse], response.json())

    async def list_repository_pull_requests(
        self,
        owner: str,
        repo: str,
        state: str | None = None,
        head: str | None = None,
        base: str | None = None,
        sort: str | None = None,
        direction: str | None = None,
        per_page: int = 30,
        page: int = 1,
    ) -> list[PullRequestResponse]:
        """List pull requests for a repository."""
        url = self._build_url("repo_pulls", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "state": state,
            "head": head,
            "base": base,
            "sort": sort,
            "direction": direction,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[PullRequestResponse], response.json())

    async def get_pull_request(
        self, owner: str, repo: str, pull_number: int
    ) -> PullRequestResponse:
        """Get a specific pull request."""
        url = self._build_url("repo_pull", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(PullRequestResponse, response.json())

    async def get_pull_request_diff(self, owner: str, repo: str, pull_number: int) -> str:
        """Get the diff for a pull request."""
        url = self._build_url("repo_pull", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_diff_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return response.text

    async def update_pull_request(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        title: str | None = None,
        body: str | None = None,
        state: str | None = None,
        base: str | None = None,
    ) -> PullRequestResponse:
        """Update a pull request."""
        url = self._build_url("repo_pull", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "title": title,
            "body": body,
            "state": state,
            "base": base,
        })
        response = await self._request_with_retry("PATCH", url, headers=headers, json=data)
        return cast(PullRequestResponse, response.json())

    async def list_pull_request_commits(
        self, owner: str, repo: str, pull_number: int, per_page: int = 30, page: int = 1
    ) -> list[CommitResponse]:
        """List commits for a pull request."""
        url = self._build_url("repo_pull_commits", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[CommitResponse], response.json())

    async def list_pull_request_files(
        self, owner: str, repo: str, pull_number: int, per_page: int = 30, page: int = 1
    ) -> list[PullRequestFileResponse]:
        """List files changed in a pull request."""
        url = self._build_url("repo_pull_files", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[PullRequestFileResponse], response.json())

    async def create_pull_request_review_comment_reply(
        self, owner: str, repo: str, pull_number: int, comment_id: int, body: str
    ) -> CommentResponse:
        """Create a reply to a pull request review comment."""
        url = self._build_url(
            "repo_pull_comment_replies",
            owner=owner,
            repo=repo,
            pull_number=pull_number,
            comment_id=comment_id,
        )
        headers = self._get_json_headers()
        data = {"body": body}
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(CommentResponse, response.json())

    async def list_pull_request_review_comments(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        sort: str | None = None,
        direction: str | None = None,
        since: str | None = None,
        per_page: int = 30,
        page: int = 1,
    ) -> list[CommentResponse]:
        """List review comments for a pull request."""
        url = self._build_url("repo_pull_comments", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "sort": sort,
            "direction": direction,
            "since": since,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[CommentResponse], response.json())

    async def create_pull_request_review_comment(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        body: str,
        commit_id: str,
        path: str,
        line: int | None = None,
        side: str | None = None,
        start_line: int | None = None,
        start_side: str | None = None,
        subject_type: str | None = None,
    ) -> CommentResponse:
        """Create a review comment on a pull request."""
        url = self._build_url("repo_pull_comments", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "body": body,
            "commit_id": commit_id,
            "path": path,
            "line": line,
            "side": side,
            "start_line": start_line,
            "start_side": start_side,
        })
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(CommentResponse, response.json())

    async def get_authenticated_user(self) -> dict[str, Any]:
        """Get authenticated user information."""
        url = self._build_url("user")
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(dict[str, Any], response.json())

    async def list_user_organizations(
        self, per_page: int = 100, page: int = 1
    ) -> list[dict[str, Any]]:
        """List organizations for the authenticated user."""
        url = self._build_url("user_orgs")
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def list_user_repositories(
        self,
        sort: str = "updated",
        direction: str | None = None,
        per_page: int = 30,
        page: int = 1,
        affiliation: str | None = None,
    ) -> list[RepositoryResponse]:
        """List repositories for the authenticated user."""
        url = self._build_url("user_repos")
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "sort": sort,
            "direction": direction,
            "per_page": per_page,
            "page": page,
            "affiliation": affiliation,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[RepositoryResponse], response.json())

    async def list_user_teams(self, per_page: int = 100, page: int = 1) -> list[dict[str, Any]]:
        """List teams for the authenticated user."""
        url = self._build_url("user_teams")
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def list_repository_branches(
        self,
        owner: str,
        repo: str,
        per_page: int = 100,
        page: int = 1,
        protected: bool | None = None,
    ) -> list[dict[str, Any]]:
        """List branches for a repository."""
        url = self._build_url("repo_branches", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "per_page": per_page,
            "page": page,
            "protected": str(protected).lower() if protected is not None else None,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def get_repository_commit(self, owner: str, repo: str, commit_sha: str) -> dict[str, Any]:
        """Get commit information for a repository."""
        url = self._build_url("repo_commit", owner=owner, repo=repo, commit_sha=commit_sha)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(dict[str, Any], response.json())

    async def search_issues(
        self,
        query: str,
        sort: str | None = None,
        order: str | None = None,
        per_page: int = 30,
        page: int = 1,
    ) -> dict[str, Any]:
        """Search issues and pull requests."""
        url = self._build_url("search_issues")
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "q": query,
            "sort": sort,
            "order": order,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(dict[str, Any], response.json())

    async def search_commits(
        self,
        query: str,
        sort: str | None = None,
        order: str | None = None,
        per_page: int = 30,
        page: int = 1,
    ) -> dict[str, Any]:
        """Search commits."""
        url = self._build_url("search_commits")
        headers = self._get_commit_search_headers()
        params = self._remove_none_values({
            "q": query,
            "sort": sort,
            "order": order,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(dict[str, Any], response.json())

    async def list_organization_projects_v2(
        self,
        org: str,
        q: str | None = None,
        before: str | None = None,
        after: str | None = None,
        per_page: int = 30,
    ) -> tuple[list[ProjectV2Response], str | None, str | None]:
        """List Projects V2 for organization. Returns (projects, next_cursor, prev_cursor)."""
        url = self._build_url("org_projects_v2", org=org)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "q": q,
            "before": before,
            "after": after,
            "per_page": per_page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        next_cursor, prev_cursor = self._extract_cursors(response)
        return cast(list[ProjectV2Response], response.json()), next_cursor, prev_cursor

    async def list_user_projects_v2(
        self,
        username: str,
        q: str | None = None,
        before: str | None = None,
        after: str | None = None,
        per_page: int = 30,
    ) -> tuple[list[ProjectV2Response], str | None, str | None]:
        """List Projects V2 for user."""
        url = self._build_url("user_projects_v2", username=username)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "q": q,
            "before": before,
            "after": after,
            "per_page": per_page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        next_cursor, prev_cursor = self._extract_cursors(response)
        return cast(list[ProjectV2Response], response.json()), next_cursor, prev_cursor

    async def get_project_v2(
        self,
        scope_target: str,
        identifier: str,
        project_number: int,
    ) -> ProjectV2Response:
        """Get a specific V2 project."""
        if scope_target == "organization":
            url = self._build_url("org_project_v2", org=identifier, project_number=project_number)
        else:
            url = self._build_url(
                "user_project_v2", username=identifier, project_number=project_number
            )
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(ProjectV2Response, response.json())

    async def list_project_v2_items(
        self,
        scope_target: str,
        identifier: str,
        project_number: int,
        q: str | None = None,
        fields: list[str] | None = None,
        before: str | None = None,
        after: str | None = None,
        per_page: int = 30,
    ) -> tuple[list[ProjectV2ItemResponse], str | None, str | None]:
        """List items for a V2 project."""
        if scope_target == "organization":
            url = self._build_url(
                "org_project_v2_items", org=identifier, project_number=project_number
            )
        else:
            url = self._build_url(
                "user_project_v2_items", username=identifier, project_number=project_number
            )
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "q": q,
            "fields": ",".join(fields) if fields else None,
            "before": before,
            "after": after,
            "per_page": per_page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        next_cursor, prev_cursor = self._extract_cursors(response)
        return cast(list[ProjectV2ItemResponse], response.json()), next_cursor, prev_cursor

    async def list_project_v2_fields(
        self,
        scope_target: str,
        identifier: str,
        project_number: int,
    ) -> list[ProjectV2FieldResponse]:
        """List fields for a V2 project."""
        if scope_target == "organization":
            url = self._build_url(
                "org_project_v2_fields", org=identifier, project_number=project_number
            )
        else:
            url = self._build_url(
                "user_project_v2_fields", username=identifier, project_number=project_number
            )
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(list[ProjectV2FieldResponse], response.json())

    async def add_item_to_project(
        self,
        scope_target: str,
        identifier: str,
        project_number: int,
        item_number: int,
        item_type: str,
    ) -> ProjectV2ItemResponse:
        """Add an existing issue or PR to a V2 project."""
        if scope_target == "organization":
            url = self._build_url(
                "org_project_v2_items", org=identifier, project_number=project_number
            )
        else:
            url = self._build_url(
                "user_project_v2_items", username=identifier, project_number=project_number
            )
        headers = self._get_json_headers()
        data = {"type": item_type, "id": item_number}
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(ProjectV2ItemResponse, response.json())

    async def update_project_v2_item(
        self,
        scope_target: str,
        identifier: str,
        project_number: int,
        item_id: int,
        field_updates: list[dict[str, Any]],
    ) -> ProjectV2ItemResponse:
        """Update field values for a V2 project item."""
        if scope_target == "organization":
            url = self._build_url(
                "org_project_v2_item",
                org=identifier,
                project_number=project_number,
                item_id=item_id,
            )
        else:
            url = self._build_url(
                "user_project_v2_item",
                username=identifier,
                project_number=project_number,
                item_id=item_id,
            )
        headers = self._get_json_headers()
        data = {"fields": field_updates}
        response = await self._request_with_retry("PATCH", url, headers=headers, json=data)
        return cast(ProjectV2ItemResponse, response.json())

    async def create_pull_request(
        self,
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str,
        body: str | None = None,
        draft: bool | None = None,
        maintainer_can_modify: bool | None = None,
        issue: int | None = None,
    ) -> PullRequestResponse:
        """Create a pull request."""
        url = self._build_url("repo_pulls", owner=owner, repo=repo)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "title": title,
            "head": head,
            "base": base,
            "body": body,
            "draft": draft,
            "maintainer_can_modify": maintainer_can_modify,
            "issue": issue,
        })
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(PullRequestResponse, response.json())

    async def merge_pull_request(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        commit_title: str | None = None,
        commit_message: str | None = None,
        sha: str | None = None,
        merge_method: str | None = None,
    ) -> dict[str, Any]:
        """Merge a pull request."""
        url = self._build_url("repo_pull_merge", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        data = self._remove_none_values({
            "commit_title": commit_title,
            "commit_message": commit_message,
            "sha": sha,
            "merge_method": merge_method,
        })
        response = await self._request_with_retry("PUT", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def update_pull_request_branch(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        expected_head_sha: str | None = None,
    ) -> dict[str, Any]:
        """Update a pull request branch with the latest upstream changes."""
        url = self._build_url(
            "repo_pull_update_branch", owner=owner, repo=repo, pull_number=pull_number
        )
        headers = self._get_json_headers()
        data = self._remove_none_values({"expected_head_sha": expected_head_sha})
        response = await self._request_with_retry("PUT", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def request_pull_request_reviewers(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        reviewers: list[str] | None = None,
        team_reviewers: list[str] | None = None,
    ) -> dict[str, Any]:
        """Request reviewers for a pull request."""
        url = self._build_url(
            "repo_pull_requested_reviewers", owner=owner, repo=repo, pull_number=pull_number
        )
        headers = self._get_json_headers()
        data = self._remove_none_values({"reviewers": reviewers, "team_reviewers": team_reviewers})
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def remove_pull_request_reviewers(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        reviewers: list[str] | None = None,
        team_reviewers: list[str] | None = None,
    ) -> dict[str, Any]:
        """Remove requested reviewers from a pull request."""
        url = self._build_url(
            "repo_pull_requested_reviewers", owner=owner, repo=repo, pull_number=pull_number
        )
        headers = self._get_json_headers()
        data = self._remove_none_values({"reviewers": reviewers, "team_reviewers": team_reviewers})
        response = await self._request_with_retry("DELETE", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def list_pull_request_reviews(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        per_page: int = 100,
        page: int = 1,
    ) -> list[dict[str, Any]]:
        """
        List reviews for a pull request.

        See: https://docs.github.com/en/rest/pulls/reviews#list-reviews-for-a-pull-request
        """
        url = self._build_url("repo_pull_reviews", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def create_pull_request_review(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        event: str,
        body: str | None = None,
        commit_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a review for a pull request."""
        url = self._build_url("repo_pull_reviews", owner=owner, repo=repo, pull_number=pull_number)
        headers = self._get_json_headers()
        data = self._remove_none_values({"event": event, "body": body, "commit_id": commit_id})
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def add_issue_assignees(
        self, owner: str, repo: str, issue_number: int, assignees: list[str]
    ) -> IssueResponse:
        """Add assignees to an issue or pull request."""
        url = self._build_url(
            "repo_issue_assignees", owner=owner, repo=repo, issue_number=issue_number
        )
        headers = self._get_json_headers()
        data = {"assignees": assignees}
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(IssueResponse, response.json())

    async def check_assignee(self, owner: str, repo: str, assignee: str) -> bool:
        """Check if a user can be assigned to issues in a repository."""
        url = self._build_url("repo_assignee", owner=owner, repo=repo, assignee=assignee)
        headers = self._get_json_headers()
        try:
            response = await self._request_with_retry("GET", url, headers=headers)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return False
            raise
        else:
            return response.status_code == 204

    async def search_users(self, query: str, per_page: int = 30, page: int = 1) -> dict[str, Any]:
        """Search for users."""
        url = self._build_url("search_users")
        headers = self._get_json_headers()
        params = {"q": query, "per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(dict[str, Any], response.json())

    async def list_repository_collaborators(
        self,
        owner: str,
        repo: str,
        affiliation: str | None = None,
        permission: str | None = None,
        per_page: int = 100,
        page: int = 1,
    ) -> list[dict[str, Any]]:
        """List collaborators for a repository with optional filters."""
        url = self._build_url("repo_collaborators", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = self._remove_none_values({
            "affiliation": affiliation,
            "permission": permission,
            "per_page": per_page,
            "page": page,
        })
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def list_repository_teams(
        self, owner: str, repo: str, per_page: int = 100, page: int = 1
    ) -> list[dict[str, Any]]:
        """List teams for a repository."""
        url = self._build_url("repo_teams", owner=owner, repo=repo)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def list_organization_members(
        self, org: str, per_page: int = 100, page: int = 1
    ) -> list[dict[str, Any]]:
        """List members of an organization."""
        url = self._build_url("org_members", org=org)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(list[dict[str, Any]], response.json())

    async def compare_commits(self, owner: str, repo: str, base: str, head: str) -> dict[str, Any]:
        """Compare two commits or branches."""
        url = self._build_url("repo_compare", owner=owner, repo=repo, base=base, head=head)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(dict[str, Any], response.json())

    async def get_branch(self, owner: str, repo: str, branch: str) -> dict[str, Any]:
        """Get a branch."""
        url = self._build_url("repo_branch", owner=owner, repo=repo, branch=branch)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(dict[str, Any], response.json())

    async def delete_git_ref(self, owner: str, repo: str, ref: str) -> None:
        """Delete a git reference (branch)."""
        url = self._build_url("repo_git_ref", owner=owner, repo=repo, ref=ref)
        headers = self._get_json_headers()
        await self._request_with_retry("DELETE", url, headers=headers)

    async def get_combined_status(self, owner: str, repo: str, ref: str) -> dict[str, Any]:
        """Get combined commit status for a reference."""
        url = self._build_url("repo_commit_status", owner=owner, repo=repo, ref=ref)
        headers = self._get_json_headers()
        response = await self._request_with_retry("GET", url, headers=headers)
        return cast(dict[str, Any], response.json())

    async def list_check_runs_for_ref(
        self, owner: str, repo: str, ref: str, per_page: int = 100, page: int = 1
    ) -> dict[str, Any]:
        """List check runs for a git reference."""
        url = self._build_url("repo_commit_check_runs", owner=owner, repo=repo, ref=ref)
        headers = self._get_json_headers()
        params = {"per_page": per_page, "page": page}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(dict[str, Any], response.json())

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create a pooled HTTP client for the base URL (async-safe)."""
        if self._client is not None:
            return self._client

        base_url = self._base_url_for_client

        async with self._global_lock:
            if base_url not in self._client_locks:
                self._client_locks[base_url] = asyncio.Lock()
            lock = self._client_locks[base_url]

        async with lock:
            if base_url not in self._clients:
                self._clients[base_url] = httpx.AsyncClient(
                    http2=True,
                    limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
                    timeout=30.0,
                )
            self._client = self._clients[base_url]
            return self._client

    def _build_url(self, endpoint: str, **kwargs: Any) -> str:
        """Build the full URL for a given endpoint."""
        return f"{self.base_url}{ENDPOINTS[endpoint].format(**kwargs)}"

    def _get_json_headers(self) -> dict[str, str]:
        """Generate headers for JSON API requests."""
        return {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _get_commit_search_headers(self) -> dict[str, str]:
        """Generate headers for commit search preview API."""
        headers = self._get_json_headers()
        headers["Accept"] = "application/vnd.github.cloak-preview+json"
        return headers

    def _get_diff_headers(self) -> dict[str, str]:
        """Generate headers for diff content requests."""
        return {
            "Accept": "application/vnd.github.diff",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _remove_none_values(self, params: dict[str, Any]) -> dict[str, Any]:
        """Remove None values from a dictionary."""
        return {k: v for k, v in params.items() if v is not None}

    def _extract_cursors(self, response: httpx.Response) -> tuple[str | None, str | None]:
        """Extract next/prev cursors from Link header."""
        link_header = response.headers.get("Link", "")
        next_cursor = None
        prev_cursor = None

        for link in link_header.split(","):
            if 'rel="next"' in link:
                match = re.search(r"[?&]after=([^&>]+)", link)
                if match:
                    next_cursor = match.group(1)
            elif 'rel="prev"' in link:
                match = re.search(r"[?&]before=([^&>]+)", link)
                if match:
                    prev_cursor = match.group(1)

        return next_cursor, prev_cursor

    async def _request_with_retry(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """
        Make an HTTP request with retry logic for 5xx errors.
        Retries up to 2 times (3 total attempts) with exponential backoff.
        """
        client = await self._get_client()
        backoff_delays = [0.3, 0.6, 1.2]

        for attempt, delay in enumerate(backoff_delays):
            try:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                    json=json,
                )

                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                is_last_attempt = attempt == len(backoff_delays) - 1
                if e.response.status_code >= 500 and not is_last_attempt:
                    await asyncio.sleep(delay)
                    continue
                if e.response.status_code == 422:
                    operation = f"{method} {url}"
                    raise wrap_github_422_error(e, operation) from e
                raise
            except Exception:
                raise
            else:
                return response
        raise RuntimeError("Retry logic exited unexpectedly without returning or raising.")

    async def get_file_contents(
        self, owner: str, repo: str, path: str, ref: str | None = None
    ) -> dict[str, Any]:
        """Get file contents from repository."""
        url = self._build_url("repo_contents", owner=owner, repo=repo, path=path)
        headers = self._get_json_headers()
        params = {"ref": ref} if ref else {}
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        return cast(dict[str, Any], response.json())

    async def update_file(
        self,
        owner: str,
        repo: str,
        path: str,
        content: str,
        message: str,
        branch: str,
        sha: str | None = None,
    ) -> dict[str, Any]:
        """Create or update a file in repository."""
        url = self._build_url("repo_contents", owner=owner, repo=repo, path=path)
        headers = self._get_json_headers()
        content_encoded = base64.b64encode(content.encode()).decode()
        data = {
            "message": message,
            "content": content_encoded,
            "branch": branch,
        }
        if sha:
            data["sha"] = sha

        response = await self._request_with_retry("PUT", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def create_branch(
        self, owner: str, repo: str, branch: str, from_sha: str
    ) -> dict[str, Any]:
        """Create a new branch."""
        url = self._build_url("repo_git_refs", owner=owner, repo=repo)
        headers = self._get_json_headers()
        data = {
            "ref": f"refs/heads/{branch}",
            "sha": from_sha,
        }
        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        return cast(dict[str, Any], response.json())

    async def execute_graphql(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute a GraphQL query or mutation."""
        url = f"{self.base_url}/graphql"
        headers = self._get_json_headers()
        data: dict[str, Any] = {"query": query}
        if variables:
            data["variables"] = variables

        response = await self._request_with_retry("POST", url, headers=headers, json=data)
        result = response.json()

        if "errors" in result:
            error_msgs = [e.get("message", str(e)) for e in result["errors"]]
            raise ValueError(f"GraphQL errors: {'; '.join(error_msgs)}")

        return cast(dict[str, Any], result.get("data", {}))

    async def get_pull_request_review_threads(
        self, owner: str, repo: str, pull_number: int
    ) -> list[dict[str, Any]]:
        """Get review threads for a pull request via GraphQL."""
        query = """
        query($owner: String!, $repo: String!, $number: Int!) {
          repository(owner: $owner, name: $repo) {
            pullRequest(number: $number) {
              reviewThreads(first: 100) {
                nodes {
                  id
                  isResolved
                  comments(first: 100) {
                    nodes {
                      databaseId
                      body
                      createdAt
                      updatedAt
                      diffHunk
                      path
                      position
                      commit { oid }
                      author { login }
                      url
                    }
                  }
                }
              }
            }
          }
        }
        """
        result = await self.execute_graphql(
            query, {"owner": owner, "repo": repo, "number": pull_number}
        )
        threads = (
            result.get("repository", {})
            .get("pullRequest", {})
            .get("reviewThreads", {})
            .get("nodes", [])
        )
        return cast(list[dict[str, Any]], threads)

    async def get_file_metadata(
        self, owner: str, repo: str, path: str, ref: str | None = None
    ) -> dict[str, Any]:
        """Get file metadata (SHA, size) without downloading content."""
        url = self._build_url("repo_contents", owner=owner, repo=repo, path=path)
        headers = self._get_json_headers()
        params = {}
        if ref:
            params["ref"] = ref

        # GET returns metadata without needing to decode base64 content
        response = await self._request_with_retry("GET", url, headers=headers, params=params)
        data = response.json()

        # Return only metadata, don't decode content
        return {
            "sha": data.get("sha"),
            "size": data.get("size"),
            "name": data.get("name"),
            "path": data.get("path"),
        }
