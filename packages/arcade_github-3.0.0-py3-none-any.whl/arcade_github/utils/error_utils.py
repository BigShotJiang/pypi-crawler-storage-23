from typing import Any

import httpx
from arcade_tdk.errors import RetryableToolError


def parse_github_error_response(response: httpx.Response) -> str:
    """
    Parse GitHub API error response for detailed error message.

    Args:
        response: HTTP response object from GitHub API

    Returns:
        Formatted error message with details from GitHub
    """
    try:
        data: dict[str, Any] = response.json()
        main_message: str = str(data.get("message", "Unknown error"))
        errors: list[Any] = data.get("errors", [])

        if not errors:
            return main_message

        error_details: list[str] = []
        for err in errors:
            field: str = str(err.get("field", ""))
            message: str = str(err.get("message", ""))

            if field and message:
                error_details.append(f"• {field}: {message}")
            elif message:
                error_details.append(f"• {message}")

        if error_details:
            return f"{main_message}\n" + "\n".join(error_details)
        else:
            return main_message
    except Exception:
        text: str = response.text if hasattr(response, "text") else "Unable to parse error details"
        return text


def wrap_github_422_error(
    error: httpx.HTTPStatusError,
    operation: str,
) -> RetryableToolError:
    """
    Wrap GitHub 422 validation errors with detailed messages and helpful suggestions.

    Args:
        error: The original HTTPStatusError with 422 status
        operation: Description of what operation failed

    Returns:
        RetryableToolError with parsed GitHub error details and suggestions
    """
    error_message = parse_github_error_response(error.response)

    prompt_suggestions = []
    try:
        error_data = error.response.json()
        errors = error_data.get("errors", [])

        for err in errors:
            code = err.get("code", "")
            field = err.get("field", "")
            message = err.get("message", "").lower()

            if "no commits" in message or "nothing to merge" in message:
                prompt_suggestions.append(
                    "Ensure the head branch has commits that the base branch doesn't have. "
                    "The branches might be identical."
                )
            elif "already exists" in message or code == "already_exists":
                prompt_suggestions.append(
                    "A pull request may already exist between these branches. "
                    "Check for existing PRs first."
                )
            elif field in ["line", "position"] or "line" in message:
                prompt_suggestions.append(
                    "The line number might not exist in the diff at this commit. "
                    "Line numbers must be part of the changed lines. "
                    "Consider using subject_type='file' to comment on the entire file."
                )
            elif "diff" in message or "position" in message:
                prompt_suggestions.append(
                    "GitHub requires line numbers that exist in the pull request diff. "
                    "File line numbers may not match diff positions."
                )
    except Exception:
        error_data = {}

    additional_prompt = (
        " ".join(prompt_suggestions)
        if prompt_suggestions
        else "Review the validation errors and adjust the parameters accordingly."
    )

    user_message = f"GitHub validation error while {operation}:\n\n{error_message}"

    return RetryableToolError(
        message=user_message,
        developer_message=f"GitHub API 422: {error.response.text}",
        additional_prompt_content=additional_prompt,
    )


def wrap_github_403_error(
    error: httpx.HTTPStatusError,
    resource: str,
    required_permission: str | None = None,
) -> RetryableToolError:
    """
    Wrap GitHub 403 forbidden errors with permission guidance.

    Args:
        error: The original HTTPStatusError with 403 status
        resource: What resource was being accessed
        required_permission: Description of required permission

    Returns:
        RetryableToolError with permission guidance
    """
    base_message = f"Access forbidden when accessing {resource}."

    if required_permission:
        user_message = f"{base_message}\n\nRequired permission: {required_permission}"
        additional_prompt = (
            f"Ensure your GitHub App or token has the {required_permission} permission."
        )
    else:
        user_message = base_message
        additional_prompt = "Check that you have the necessary permissions for this resource."

    return RetryableToolError(
        message=user_message,
        developer_message=f"GitHub API 403: {error.response.text}",
        additional_prompt_content=additional_prompt,
    )
