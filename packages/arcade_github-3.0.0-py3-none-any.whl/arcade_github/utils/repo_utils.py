import asyncio
from typing import Any, NamedTuple

from arcade_tdk.errors import RetryableToolError
from rapidfuzz import fuzz

from arcade_github.constants import FUZZY_MATCH_THRESHOLD
from arcade_github.models.api_responses import RepositoryResponse
from arcade_github.models.models import RepoSearchScope
from arcade_github.utils.github_api_client import GitHubAPIClient

_DEFAULT_PER_PAGE = 100
_MAX_BRANCH_COMMITS = 60


class RepoSource(NamedTuple):
    """Repository paired with the source it was fetched from."""

    repo: RepositoryResponse
    source: str


class RepoMatch(NamedTuple):
    """Repository match scored by fuzzy logic."""

    repo: RepositoryResponse
    source: str
    score: float


async def get_user_org_logins(client: GitHubAPIClient) -> list[str]:
    """
    Retrieve all organization logins for the authenticated user.
    """

    orgs: list[str] = []
    page = 1

    while True:
        page_data = await client.list_user_organizations(per_page=_DEFAULT_PER_PAGE, page=page)
        if not page_data:
            break
        orgs.extend(org["login"] for org in page_data if org.get("login"))
        if len(page_data) < _DEFAULT_PER_PAGE:
            break
        page += 1

    return orgs


async def collect_repo_sources(
    client: GitHubAPIClient,
    scope: RepoSearchScope,
    username: str,
    org_logins: list[str] | None = None,
) -> list[RepoSource]:
    """
    Collect repositories for the specified scope, tagging each with its source.
    """

    sources: list[RepoSource] = []

    if scope in (RepoSearchScope.ALL, RepoSearchScope.PERSONAL):
        personal_repos = await _fetch_all_user_repositories(client, affiliation="owner")
        sources.extend(RepoSource(repo=repo, source=f"user:{username}") for repo in personal_repos)

    if scope in (RepoSearchScope.ALL, RepoSearchScope.ORGANIZATION):
        org_targets = org_logins or []

        if scope == RepoSearchScope.ALL and org_logins is None:
            org_targets = await get_user_org_logins(client)

        if org_targets:
            org_results = await asyncio.gather(*[
                _fetch_all_org_repositories(client, org) for org in org_targets
            ])
            for org, repos in zip(org_targets, org_results, strict=False):
                sources.extend(
                    RepoSource(repo=repo, source=f"organization:{org}") for repo in repos
                )

    return _deduplicate_sources(sources)


def score_repository_sources(
    sources: list[RepoSource],
    search_term: str,
) -> list[RepoMatch]:
    """
    Compute fuzzy scores for repository sources using name and full_name.
    """

    term = search_term.lower()
    matches: list[RepoMatch] = []

    for source in sources:
        repo_name = (source.repo.get("name") or "").lower()
        full_name = (source.repo.get("full_name") or "").lower()
        if not repo_name and not full_name:
            continue
        score = max(
            fuzz.ratio(term, repo_name) / 100 if repo_name else 0.0,
            fuzz.ratio(term, full_name) / 100 if full_name else 0.0,
        )
        matches.append(RepoMatch(repo=source.repo, source=source.source, score=score))

    matches.sort(key=lambda candidate: candidate.score, reverse=True)
    return matches


def select_best_match(
    matches: list[RepoMatch],
    auto_accept_threshold: float,
) -> tuple[RepoMatch | None, list[RepoMatch]]:
    """
    Select the best match and suggestion list given a confidence threshold.
    """

    if not matches:
        return None, []

    best = matches[0]

    if best.score >= auto_accept_threshold:
        suggestions = matches[:10]
        return best, suggestions

    suggestions = [match for match in matches if match.score >= FUZZY_MATCH_THRESHOLD][:10]
    if not suggestions:
        suggestions = matches[:10]

    return None, suggestions


def resolve_org_targets(
    scope: RepoSearchScope,
    organization: str | None,
    user_org_logins: list[str],
) -> list[str]:
    """
    Determine which organizations to search based on scope and user input.
    """

    if scope == RepoSearchScope.PERSONAL:
        if organization:
            raise RetryableToolError(
                message="The organization parameter can only be used when scope is 'organization'.",
                additional_prompt_content=(
                    "Set scope to 'organization' or remove the organization input."
                ),
            )
        return []

    if scope == RepoSearchScope.ORGANIZATION:
        if organization:
            normalized = organization.lower()
            matched = next((org for org in user_org_logins if org.lower() == normalized), None)
            if not matched:
                additional = (
                    "You are not a member of any organizations."
                    if not user_org_logins
                    else f"Available organizations: {', '.join(user_org_logins)}"
                )
                raise RetryableToolError(
                    message=f"Organization '{organization}' not found for this user.",
                    additional_prompt_content=additional,
                )
            return [matched]

        if not user_org_logins:
            raise RetryableToolError(
                message="You are not a member of any organizations.",
                additional_prompt_content=(
                    "Join an organization or specify a repository from your personal account."
                ),
            )
        return user_org_logins

    return user_org_logins if user_org_logins else []


async def fetch_recent_branches(
    client: GitHubAPIClient,
    owner: str,
    repo: str,
    limit: int,
) -> list[dict[str, str]]:
    """
    Fetch recent branches ordered by latest commit timestamp (best effort).
    """

    if limit <= 0:
        return []

    branches = await client.list_repository_branches(
        owner=owner,
        repo=repo,
        per_page=_DEFAULT_PER_PAGE,
        page=1,
    )
    if not branches:
        return []

    limited_branches = [
        branch for branch in branches if branch.get("name") and branch.get("commit", {}).get("sha")
    ][:_MAX_BRANCH_COMMITS]

    async def _fetch_branch(branch: dict[str, Any]) -> dict[str, str | None] | None:
        name = branch.get("name")
        sha = branch.get("commit", {}).get("sha")
        if not name or not sha:
            return None
        try:
            commit = await client.get_repository_commit(owner=owner, repo=repo, commit_sha=sha)
        except Exception:
            return None
        commit_block = commit.get("commit", {})
        committer_data = commit_block.get("committer") or {}
        committed_at = committer_data.get("date")
        if not committed_at:
            return None
        return {
            "name": name,
            "commit_sha": sha or "",
            "committed_at": committed_at or "",
            "committer": committer_data.get("name"),
        }

    results = await asyncio.gather(*[_fetch_branch(branch) for branch in limited_branches])
    cleaned = [res for res in results if res]
    cleaned.sort(key=lambda item: item["committed_at"], reverse=True)
    return cleaned[:limit]


async def _fetch_all_user_repositories(
    client: GitHubAPIClient,
    affiliation: str,
) -> list[RepositoryResponse]:
    repos: list[RepositoryResponse] = []
    page = 1

    while True:
        page_data = await client.list_user_repositories(
            sort="updated", per_page=_DEFAULT_PER_PAGE, page=page, affiliation=affiliation
        )
        if not page_data:
            break
        repos.extend(page_data)
        if len(page_data) < _DEFAULT_PER_PAGE:
            break
        page += 1

    return repos


async def _fetch_all_org_repositories(
    client: GitHubAPIClient,
    org: str,
) -> list[RepositoryResponse]:
    repos: list[RepositoryResponse] = []
    page = 1

    while True:
        page_data = await client.list_organization_repositories(
            org=org,
            repo_type="all",
            sort="updated",
            direction="desc",
            per_page=_DEFAULT_PER_PAGE,
            page=page,
        )
        if not page_data:
            break
        repos.extend(page_data)
        if len(page_data) < _DEFAULT_PER_PAGE:
            break
        page += 1

    return repos


def _deduplicate_sources(sources: list[RepoSource]) -> list[RepoSource]:
    unique: dict[str, RepoSource] = {}

    for source in sources:
        key = source.repo.get("full_name") or source.repo.get("id")
        if key is None:
            continue
        normalized_key = key.lower() if isinstance(key, str) else str(key)
        if normalized_key in unique:
            continue
        unique[normalized_key] = source

    return list(unique.values())
