import asyncio
import logging
from typing import Any

import httpx

from arcade_github.utils.github_api_client import GitHubAPIClient

logger = logging.getLogger(__name__)


async def enrich_user_with_profile_data(
    client: GitHubAPIClient, user: dict[str, Any]
) -> dict[str, Any]:
    """
    Enrich a user dict with full profile data (name, email).

    Args:
        client: GitHub API client
        user: User dict with at least 'login' field

    Returns:
        Enriched user dict with name and email if available
    """
    login = user.get("login")
    if not login:
        return user

    enriched = user.copy()

    try:
        url = f"{client.base_url}/users/{login}"
        headers = client._get_json_headers()
        response = await client._request_with_retry("GET", url, headers=headers)
        profile_data = response.json()

        if profile_data.get("name"):
            enriched["name"] = profile_data.get("name")
        if profile_data.get("email"):
            enriched["email"] = profile_data.get("email")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            logger.debug(f"User {login} not found (404), skipping enrichment")
        elif e.response.status_code == 403:
            logger.warning(f"Permission denied enriching {login}: {e}")
        elif e.response.status_code == 429:
            logger.warning(f"Rate limit exceeded enriching {login}")
        else:
            logger.warning(f"HTTP {e.response.status_code} enriching {login}: {e}")
    except httpx.TimeoutException:
        logger.warning(f"Timeout enriching profile for {login}")
    except Exception:
        logger.exception(f"Unexpected error enriching profile for {login}")

    return enriched


async def enrich_users_batch(
    client: GitHubAPIClient, users: list[dict[str, Any]], max_concurrent: int = 5
) -> list[dict[str, Any]]:
    """
    Enrich multiple users with profile data in parallel.

    Args:
        client: GitHub API client
        users: List of user dicts
        max_concurrent: Maximum concurrent API calls

    Returns:
        List of enriched user dicts
    """
    if not users:
        return users

    semaphore = asyncio.Semaphore(max_concurrent)

    async def enrich_with_limit(user: dict[str, Any]) -> dict[str, Any]:
        async with semaphore:
            return await enrich_user_with_profile_data(client, user)

    enriched = await asyncio.gather(*[enrich_with_limit(user) for user in users])
    return list(enriched)
