"""Utilities for repository name normalization."""


def normalize_repo_name(repo: str) -> str:
    """
    Normalize repository name by removing .git suffix.

    Args:
        repo: Repository name (may include .git suffix)

    Returns:
        Clean repository name without .git
    """
    if repo.lower().endswith(".git"):
        return repo[:-4]
    return repo
