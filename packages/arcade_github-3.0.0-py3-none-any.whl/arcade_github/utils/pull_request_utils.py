from arcade_tdk.errors import RetryableToolError

from arcade_github.models.models import ReviewCommentSubjectType


def normalize_review_comment_range(
    subject_type: ReviewCommentSubjectType | None,
    start_line: int | None,
    end_line: int | None,
) -> tuple[int | None, int | None]:
    if subject_type == ReviewCommentSubjectType.FILE or subject_type is None:
        return None, None

    if start_line is None or end_line is None:
        message = (
            "'start_line' and 'end_line' parameters are required when 'subject_type' "
            "parameter is not 'file'. Either provide both a start_line and end_line or set "
            "subject_type to 'file' to comment on the entire file."
        )
        raise RetryableToolError(
            message=message,
            developer_message=message,
            additional_prompt_content=(
                "Please provide both start_line and end_line parameters when subject_type is not "
                "'file', or set subject_type to 'file' to comment on the entire file."
            ),
        )

    return (min(start_line, end_line), max(start_line, end_line))
