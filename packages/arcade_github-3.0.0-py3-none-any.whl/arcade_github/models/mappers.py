import base64
from typing import Any, cast

from arcade_github.models.api_responses import (
    ActivityResponse,
    CommentResponse,
    CommitResponse,
    IssueResponse,
    LabelResponse,
    ProjectV2ItemResponse,
    ProjectV2Response,
    PullRequestResponse,
    RepositoryResponse,
    StargazerResponse,
)
from arcade_github.models.api_responses.user import (
    OrganizationResponse,
    TeamResponse,
    UserResponse,
)
from arcade_github.models.tool_outputs.activity import StargazerData
from arcade_github.models.tool_outputs.files import (
    BranchOutput,
    FileContentOutput,
    FileUpdateOutput,
)
from arcade_github.models.tool_outputs.issues import CommentOutput, IssueOutput, LabelData
from arcade_github.models.tool_outputs.notifications import ReviewWorkloadPR
from arcade_github.models.tool_outputs.projects_v2 import ProjectData, ProjectItemData
from arcade_github.models.tool_outputs.pull_requests import (
    CommitData,
    CommitDetails,
    PullRequestOutput,
    ReviewCommentOutput,
)
from arcade_github.models.tool_outputs.repositories import (
    ActivityData,
    CollaboratorOutput,
    RepositoryOutput,
    ReviewCommentData,
    TeamOutput,
)
from arcade_github.models.tool_outputs.user_context import (
    CommitSummary,
    IssueSummary,
    OrganizationMembership,
    PullRequestSummary,
    RepositorySummary,
    TeamMembership,
    UserProfileData,
)


def map_commit_summary(api_data: dict[str, Any]) -> CommitSummary:
    """Map API commit response to summary."""
    commit = api_data.get("commit", {})
    return cast(
        CommitSummary,
        {
            "sha": api_data.get("sha"),
            "message": _truncate_text(commit.get("message", ""), 100),
            "repository": api_data.get("repository", {}).get("full_name", "unknown"),
            "date": commit.get("author", {}).get("date"),
            "html_url": api_data.get("html_url"),
        },
    )


def map_stargazer(api_data: StargazerResponse) -> StargazerData:
    """Map API stargazer response to tool output."""
    return cast(
        StargazerData,
        {
            "login": api_data.get("login"),
            "id": api_data.get("id"),
            "node_id": api_data.get("node_id"),
            "html_url": api_data.get("html_url"),
        },
    )


def map_issue(api_data: IssueResponse) -> IssueOutput:
    """Map API issue response to tool output."""
    return cast(
        IssueOutput,
        {
            "id": api_data.get("id"),
            "number": api_data.get("number"),
            "url": api_data.get("url"),
            "title": api_data.get("title"),
            "body": api_data.get("body"),
            "state": api_data.get("state"),
            "html_url": api_data.get("html_url"),
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "user": api_data.get("user", {}).get("login"),
            "assignees": [assignee.get("login") for assignee in api_data.get("assignees", [])],
            "labels": [label.get("name") for label in api_data.get("labels", [])],
        },
    )


def map_comment(api_data: CommentResponse) -> CommentOutput:
    """Map API comment response to tool output."""
    return cast(
        CommentOutput,
        {
            "id": api_data.get("id"),
            "url": api_data.get("url"),
            "body": api_data.get("body"),
            "user": api_data.get("user", {}).get("login"),
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
        },
    )


def map_repository(api_data: RepositoryResponse) -> RepositoryOutput:
    """Map API repository response to tool output."""
    return cast(
        RepositoryOutput,
        {
            "name": api_data.get("name", ""),
            "full_name": api_data.get("full_name", ""),
            "html_url": api_data.get("html_url", ""),
            "description": api_data.get("description"),
            "clone_url": api_data.get("clone_url", ""),
            "private": api_data.get("private", False),
            "created_at": api_data.get("created_at", ""),
            "updated_at": api_data.get("updated_at", ""),
            "pushed_at": api_data.get("pushed_at", ""),
            "stargazers_count": api_data.get("stargazers_count", 0),
            "watchers_count": api_data.get("watchers_count", 0),
            "forks_count": api_data.get("forks_count", 0),
        },
    )


def map_project_v2(
    api_data: ProjectV2Response,
    scope_type: str,
    owner: str | None,
    confidence: float | None = None,
) -> ProjectData:
    """Map V2 project response to tool output."""
    return cast(
        ProjectData,
        {
            "id": api_data.get("id"),
            "number": api_data.get("number"),
            "title": api_data.get("title"),
            "description": api_data.get("description"),
            "state": api_data.get("state"),
            "public": api_data.get("public"),
            "html_url": f"https://github.com/{scope_type}s/{owner}/projects/{api_data.get('number')}",
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "scope_type": scope_type,
            "owner": owner,
            "confidence": confidence,
        },
    )


def map_project_v2_item(
    api_data: ProjectV2ItemResponse,
    project_number: int,
    project_title: str | None,
    confidence: float | None = None,
) -> ProjectItemData:
    """Map V2 item response to tool output."""
    content = api_data.get("content") or {}
    return cast(
        ProjectItemData,
        {
            "id": api_data.get("id"),
            "title": content.get("title", ""),
            "content_type": api_data.get("content_type"),
            "content_url": content.get("html_url"),
            "field_values": api_data.get("field_values", {}),
            "project_number": project_number,
            "project_title": project_title,
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "confidence": confidence,
        },
    )


def map_pull_request(
    api_data: PullRequestResponse, diff_content: str | None = None
) -> PullRequestOutput:
    """Map API pull request response to tool output."""
    result: PullRequestOutput = cast(
        PullRequestOutput,
        {
            "number": api_data.get("number"),
            "title": api_data.get("title"),
            "body": api_data.get("body"),
            "state": api_data.get("state"),
            "html_url": api_data.get("html_url"),
            "diff_url": api_data.get("diff_url"),
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "user": (api_data.get("user") or {}).get("login"),
            "base": (api_data.get("base") or {}).get("ref"),
            "head": (api_data.get("head") or {}).get("ref"),
            "url": api_data.get("url"),
            "id": api_data.get("id"),
        },
    )
    if diff_content:
        result["diff_content"] = diff_content
    return result


def map_pull_request_for_update(api_data: PullRequestResponse) -> PullRequestOutput:
    """Map API pull request response to tool output for update operations."""
    return map_pull_request(api_data)


def map_commit(api_data: CommitResponse) -> CommitData:
    """Map API commit response to tool output."""
    html_url = api_data.get("html_url")
    return cast(
        CommitData,
        {
            "sha": api_data.get("sha"),
            "html_url": html_url,
            "diff_url": (html_url or "") + ".diff" if html_url else None,
            "metadata": cast(
                CommitDetails,
                {
                    "message": (api_data.get("commit") or {}).get("message"),
                    "author_name": (api_data.get("commit") or {}).get("author", {}).get("name"),
                    "committer_name": (api_data.get("commit") or {})
                    .get("committer", {})
                    .get("name"),
                    "committed_date": (api_data.get("commit") or {})
                    .get("committer", {})
                    .get("date"),
                },
            ),
            "author": (api_data.get("author") or {}).get("login"),
            "committer": (api_data.get("committer") or {}).get("login"),
        },
    )


def map_activity(api_data: ActivityResponse) -> ActivityData:
    """Map API activity response to tool output."""
    return cast(
        ActivityData,
        {
            "id": api_data.get("id", 0),
            "node_id": api_data.get("node_id"),
            "before": api_data.get("before"),
            "after": api_data.get("after"),
            "ref": api_data.get("ref"),
            "timestamp": api_data.get("timestamp"),
            "activity_type": api_data.get("activity_type"),
            "actor": (api_data.get("actor") or {}).get("login") if api_data.get("actor") else None,
        },
    )


def map_review_comment(api_data: CommentResponse) -> ReviewCommentOutput:
    """Map API review comment response to tool output."""
    return cast(
        ReviewCommentOutput,
        {
            "id": api_data.get("id", 0),
            "url": api_data.get("url", ""),
            "diff_hunk": api_data.get("diff_hunk", ""),
            "path": api_data.get("path", ""),
            "position": api_data.get("position", 0),
            "original_position": api_data.get("original_position", 0),
            "commit_id": api_data.get("commit_id", ""),
            "original_commit_id": api_data.get("original_commit_id", ""),
            "in_reply_to_id": api_data.get("in_reply_to_id"),
            "user": (api_data.get("user") or {}).get("login"),
            "body": api_data.get("body", ""),
            "created_at": api_data.get("created_at", ""),
            "updated_at": api_data.get("updated_at", ""),
            "html_url": api_data.get("html_url", ""),
            "line": api_data.get("line", 0),
            "side": api_data.get("side", ""),
            "pull_request_url": api_data.get("pull_request_url", ""),
        },
    )


def map_review_comment_for_repos(api_data: CommentResponse) -> ReviewCommentData:
    """Map API review comment response to repository tool output."""
    return cast(
        ReviewCommentData,
        {
            "id": api_data.get("id", 0),
            "url": api_data.get("url", ""),
            "diff_hunk": api_data.get("diff_hunk", ""),
            "path": api_data.get("path", ""),
            "position": api_data.get("position", 0),
            "original_position": api_data.get("original_position", 0),
            "commit_id": api_data.get("commit_id", ""),
            "original_commit_id": api_data.get("original_commit_id", ""),
            "in_reply_to_id": api_data.get("in_reply_to_id"),
            "user": (api_data.get("user") or {}).get("login"),
            "body": api_data.get("body", ""),
            "created_at": api_data.get("created_at", ""),
            "updated_at": api_data.get("updated_at", ""),
            "html_url": api_data.get("html_url", ""),
            "line": api_data.get("line", 0),
            "side": api_data.get("side", ""),
            "pull_request_url": api_data.get("pull_request_url", ""),
        },
    )


def map_user_profile(api_data: UserResponse) -> UserProfileData:
    """Map API user response to profile data."""
    return cast(
        UserProfileData,
        {
            "login": api_data.get("login"),
            "name": api_data.get("name"),
            "email": api_data.get("email"),
            "id": api_data.get("id"),
            "html_url": api_data.get("html_url"),
            "avatar_url": api_data.get("avatar_url"),
            "bio": api_data.get("bio"),
            "company": api_data.get("company"),
            "location": api_data.get("location"),
            "blog": api_data.get("blog"),
            "twitter_username": api_data.get("twitter_username"),
            "created_at": api_data.get("created_at"),
            "type": api_data.get("type"),
        },
    )


def map_repository_summary(api_data: RepositoryResponse) -> RepositorySummary:
    """Map API repository response to summary."""
    return cast(
        RepositorySummary,
        {
            "name": api_data.get("name"),
            "full_name": api_data.get("full_name"),
            "html_url": api_data.get("html_url"),
            "description": _truncate_text(api_data.get("description"), 150),
            "updated_at": api_data.get("updated_at"),
            "stargazers_count": api_data.get("stargazers_count"),
            "language": api_data.get("language"),
            "private": api_data.get("private"),
        },
    )


def map_organization_membership(api_data: OrganizationResponse) -> OrganizationMembership:
    """Map API organization response to membership."""
    return cast(
        OrganizationMembership,
        {
            "login": api_data.get("login"),
            "html_url": api_data.get("html_url"),
            "description": _truncate_text(api_data.get("description"), 100),
        },
    )


def map_team_membership(api_data: TeamResponse) -> TeamMembership:
    """Map API team response to membership."""
    org_data = api_data.get("organization", {})
    return cast(
        TeamMembership,
        {
            "name": api_data.get("name"),
            "slug": api_data.get("slug"),
            "organization": org_data.get("login") if org_data else None,
            "description": _truncate_text(api_data.get("description"), 100),
            "privacy": api_data.get("privacy"),
            "permission": api_data.get("permission"),
            "html_url": api_data.get("html_url"),
        },
    )


def map_pull_request_summary(api_data: dict[str, Any]) -> PullRequestSummary:
    """Map search result PR to summary."""
    repo_url = api_data.get("repository_url", "")
    return cast(
        PullRequestSummary,
        {
            "number": api_data.get("number"),
            "title": api_data.get("title"),
            "repository": _extract_repository_name(repo_url),
            "state": api_data.get("state"),
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "html_url": api_data.get("html_url"),
            "draft": api_data.get("draft"),
        },
    )


def map_issue_summary(api_data: dict[str, Any]) -> IssueSummary:
    """Map search result issue to summary."""
    repo_url = api_data.get("repository_url", "")
    return cast(
        IssueSummary,
        {
            "number": api_data.get("number"),
            "title": api_data.get("title"),
            "repository": _extract_repository_name(repo_url),
            "state": api_data.get("state"),
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "html_url": api_data.get("html_url"),
        },
    )


def map_review_workload_pr(api_data: dict[str, Any]) -> ReviewWorkloadPR:
    """Map search result PR to review workload PR."""
    user = api_data.get("user", {})
    repo_url = api_data.get("repository_url", "")
    return cast(
        ReviewWorkloadPR,
        {
            "number": api_data.get("number"),
            "title": api_data.get("title"),
            "repository": _extract_repository_name(repo_url),
            "author": user.get("login") if user else None,
            "created_at": api_data.get("created_at"),
            "updated_at": api_data.get("updated_at"),
            "html_url": api_data.get("html_url"),
            "draft": api_data.get("draft"),
            "labels": [label.get("name") for label in api_data.get("labels", [])],
        },
    )


def _truncate_text(text: str | None, max_length: int = 100) -> str | None:
    """Truncate text to max_length characters, adding ellipsis if truncated."""
    if not text or len(text) <= max_length:
        return text
    return text[: max_length - 3] + "..."


def _extract_repository_name(repo_url: str | None) -> str | None:
    """Extract the <owner>/<repo> identifier from a GitHub API repository URL."""
    if not repo_url:
        return None
    marker = "/repos/"
    if marker not in repo_url:
        return None
    extracted = repo_url.split(marker, 1)[-1]
    return extracted or None


def map_collaborator(api_data: dict[str, Any]) -> CollaboratorOutput:
    """Map GitHub API collaborator response to CollaboratorOutput."""
    return cast(
        CollaboratorOutput,
        {
            "login": api_data.get("login"),
            "id": api_data.get("id"),
            "name": api_data.get("name"),
            "email": api_data.get("email"),
            "type": api_data.get("type"),
            "site_admin": api_data.get("site_admin"),
            "permissions": api_data.get("permissions", {}),
            "role_name": api_data.get("role_name"),
        },
    )


def map_team(api_data: dict[str, Any]) -> TeamOutput:
    """Map GitHub API team response to TeamOutput."""
    return cast(
        TeamOutput,
        {
            "id": api_data.get("id"),
            "slug": api_data.get("slug"),
            "name": api_data.get("name"),
            "description": api_data.get("description"),
            "privacy": api_data.get("privacy"),
            "permission": api_data.get("permission"),
            "members_count": api_data.get("members_count", 0),
            "html_url": api_data.get("html_url"),
        },
    )


def map_label(api_data: LabelResponse) -> LabelData:
    """Map API label response to tool output."""
    return cast(
        LabelData,
        {
            "name": api_data.get("name", ""),
            "color": api_data.get("color", ""),
            "description": api_data.get("description", ""),
        },
    )


def _decode_file_content(content: str, encoding: str) -> tuple[str, int | None]:
    """Decode file content and calculate line count."""
    decoded_content = content
    line_count: int | None = None

    if encoding == "base64" and content:
        try:
            decoded_bytes = base64.b64decode(content)
            decoded_content = decoded_bytes.decode("utf-8")
            line_count = len(decoded_content.splitlines()) if decoded_content else 0
        except (UnicodeDecodeError, ValueError):
            decoded_content = content
    elif isinstance(content, str):
        line_count = len(content.splitlines()) if content else 0

    return decoded_content, line_count


def _build_file_content_result(
    api_data: dict[str, Any], decoded_content: str, encoding: str, line_count: int | None
) -> FileContentOutput:
    """Build FileContentOutput dictionary with optional fields."""
    result: FileContentOutput = {
        "encoding": encoding,
        "content": decoded_content,
    }
    if (name := api_data.get("name")) is not None:
        result["name"] = name
    if (path := api_data.get("path")) is not None:
        result["path"] = path
    if (sha := api_data.get("sha")) is not None:
        result["sha"] = sha
    if (size := api_data.get("size")) is not None:
        result["size"] = size
    if (html_url := api_data.get("html_url")) is not None:
        result["html_url"] = html_url
    if (download_url := api_data.get("download_url")) is not None:
        result["download_url"] = download_url
    if line_count is not None:
        result["line_count"] = line_count
    return result


def map_file_content(api_data: dict[str, Any]) -> FileContentOutput:
    """Map API file content response to tool output."""
    content = api_data.get("content", "")
    encoding = api_data.get("encoding", "")

    decoded_content, line_count = _decode_file_content(content, encoding)
    return _build_file_content_result(api_data, decoded_content, encoding, line_count)


def map_file_update(api_data: dict[str, Any]) -> FileUpdateOutput:
    """Map API file update response to tool output."""
    return cast(
        FileUpdateOutput,
        {
            "content": map_file_content(api_data.get("content", {})),
            "commit": api_data.get("commit", {}),
        },
    )


def map_branch(api_data: dict[str, Any]) -> BranchOutput:
    """Map API branch response to tool output."""
    return cast(
        BranchOutput,
        {
            "ref": api_data.get("ref"),
            "node_id": api_data.get("node_id"),
            "url": api_data.get("url"),
            "object": api_data.get("object"),
        },
    )


def map_review_thread_comments(
    threads: list[dict[str, Any]],
    sort_key: str,
    reverse: bool,
    since_filter: str | None,
    show_resolved: bool | None,
) -> list[ReviewCommentOutput]:
    """Map GraphQL review threads to flat list of comments with thread info."""
    all_comments = []
    for thread in threads:
        thread_id = thread.get("id")
        is_resolved = thread.get("isResolved", False)

        for comment_node in thread.get("comments", {}).get("nodes", []):
            comment_data: ReviewCommentOutput = {
                "id": comment_node.get("databaseId", 0),
                "body": comment_node.get("body", ""),
                "created_at": comment_node.get("createdAt", ""),
                "updated_at": comment_node.get("updatedAt", ""),
                "diff_hunk": comment_node.get("diffHunk", ""),
                "path": comment_node.get("path", ""),
                "position": comment_node.get("position"),
                "commit_id": comment_node.get("commit", {}).get("oid", ""),
                "user": comment_node.get("author", {}).get("login", ""),
                "url": comment_node.get("url", ""),
                "html_url": comment_node.get("url", "")
                .replace("api.github.com/repos", "github.com")
                .replace("/pulls/comments/", "/pull/"),
                "thread_node_id": thread_id or "",
                "thread_resolved": is_resolved,
            }
            all_comments.append(comment_data)

    # Apply filters
    if since_filter:
        all_comments = [c for c in all_comments if c.get("updated_at", "") > since_filter]

    if show_resolved is not None:
        all_comments = [c for c in all_comments if c.get("thread_resolved", False) == show_resolved]

    # Sort
    all_comments.sort(key=lambda x: cast(str, x.get(sort_key, "") or ""), reverse=reverse)

    return all_comments
