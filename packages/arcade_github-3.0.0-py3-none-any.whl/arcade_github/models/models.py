from enum import Enum

from typing_extensions import TypedDict


# Pull Request specific
class PRSortProperty(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    POPULARITY = "popularity"
    LONG_RUNNING = "long-running"


class PRState(str, Enum):
    OPEN = "open"
    CLOSED = "closed"
    ALL = "all"


class ReviewCommentSortProperty(str, Enum):
    CREATED = "created"
    UPDATED = "updated"


class ReviewCommentSubjectType(str, Enum):
    FILE = "file"
    LINE = "line"


class DiffSide(str, Enum):
    """
    The side of the diff that the pull request's changes appear on.
    Use LEFT for deletions that appear in red.
    Use RIGHT for additions that appear in green or unchanged
        lines that appear in white and are shown for context
    """

    LEFT = "LEFT"
    RIGHT = "RIGHT"


# Repo specific
class RepoType(str, Enum):
    """
    The types of repositories you want returned when listing organization repositories.
    Default is all repositories.
    """

    ALL = "all"
    PUBLIC = "public"
    PRIVATE = "private"
    FORKS = "forks"
    SOURCES = "sources"
    MEMBER = "member"


class RepoSearchScope(str, Enum):
    """
    Scope to use when searching repositories available to the user.
    """

    ALL = "all"
    PERSONAL = "personal"
    ORGANIZATION = "organization"


class RepoSortProperty(str, Enum):
    """
    The property to sort the results by when listing organization repositories.
    Default is created.
    """

    CREATED = "created"
    UPDATED = "updated"
    PUSHED = "pushed"
    FULL_NAME = "full_name"


class RepoTimePeriod(str, Enum):
    """
    The time period to filter by when listing repository activities.
    """

    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    QUARTER = "quarter"
    YEAR = "year"


class ActivityType(str, Enum):
    """
    The activity type to filter by when listing repository activities.
    """

    PUSH = "push"
    FORCE_PUSH = "force_push"
    BRANCH_CREATION = "branch_creation"
    BRANCH_DELETION = "branch_deletion"
    PR_MERGE = "pr_merge"
    MERGE_QUEUE_MERGE = "merge_queue_merge"


class CollaboratorAffiliation(str, Enum):
    """
    The affiliation to filter collaborators by.
    """

    OUTSIDE = "outside"
    DIRECT = "direct"
    ALL = "all"


class CollaboratorPermission(str, Enum):
    """
    The permission level to filter collaborators by.
    """

    PULL = "pull"
    TRIAGE = "triage"
    PUSH = "push"
    MAINTAIN = "maintain"
    ADMIN = "admin"


class CollaboratorDetailLevel(str, Enum):
    """
    The level of detail to include when listing collaborators.
    """

    BASIC = "basic"
    INCLUDE_ORG_MEMBERS = "include_org_members"
    FULL_PROFILES = "full_profiles"


class SortDirection(str, Enum):
    """
    The order to sort by when listing organization repositories.
    Default is asc.
    """

    ASC = "asc"
    DESC = "desc"


# Issue specific
class IssueState(str, Enum):
    """
    The state of issues to return when listing issues.
    """

    OPEN = "open"
    CLOSED = "closed"
    ALL = "all"


class IssueSortProperty(str, Enum):
    """
    The property to sort issues by when listing issues.
    Default is created.
    """

    CREATED = "created"
    UPDATED = "updated"
    COMMENTS = "comments"


# Date utilities
class RelativeDate(str, Enum):
    """
    Relative date strings supported by parse_flexible_date.
    """

    TODAY = "today"
    YESTERDAY = "yesterday"
    LAST_WEEK = "last_week"
    LAST_7_DAYS = "last_7_days"
    LAST_30_DAYS = "last_30_days"
    LAST_MONTH = "last_month"


class ProjectScopeTarget(str, Enum):
    """
    The location of a GitHub project (V2).
    """

    ALL = "all"
    ORGANIZATION = "organization"
    USER = "user"


class ProjectLookupMode(str, Enum):
    """
    How to locate a project (V2).
    """

    NUMBER = "number"
    NAME = "name"


class ProjectItemLookupMode(str, Enum):
    """
    How to locate a project item (V2).
    """

    ID = "id"
    TITLE = "title"


class ProjectState(str, Enum):
    """
    The state of a GitHub project (V2).
    """

    OPEN = "open"
    CLOSED = "closed"
    ALL = "all"


# Pull Request Lifecycle
class MergeMethod(str, Enum):
    """
    The merge method to use when merging a pull request.
    """

    MERGE = "merge"
    SQUASH = "squash"
    REBASE = "rebase"


class ReviewEvent(str, Enum):
    """
    The review action to perform on a pull request.
    """

    APPROVE = "APPROVE"
    REQUEST_CHANGES = "REQUEST_CHANGES"
    COMMENT = "COMMENT"


class UserSearchMode(str, Enum):
    """
    How to search for and resolve a GitHub user.
    """

    USERNAME = "username"
    EMAIL = "email"
    NAME = "name"
    ID = "id"


class LabelEntityType(str, Enum):
    """
    The type of entity to manage labels for.
    """

    ISSUE = "issue"
    PULL_REQUEST = "pull_request"


class ProjectFieldUpdate(TypedDict, total=False):
    """Field update for project items - OpenAI compatible structure."""

    field_name: str
    field_value: str | int | bool | None


class FileMode(str, Enum):
    """
    The mode to use when creating or overwriting a file.
    """

    CREATE = "create"
    OVERWRITE = "overwrite"


class FileUpdateMode(str, Enum):
    """
    How update_file_lines should apply changes to a file.
    """

    REPLACE = "replace"
    APPEND = "append"
