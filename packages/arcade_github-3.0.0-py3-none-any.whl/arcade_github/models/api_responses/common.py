from typing import Any

from typing_extensions import TypedDict


class StargazerResponse(TypedDict, total=False):
    login: str
    id: int
    node_id: str
    html_url: str


class IssueResponse(TypedDict, total=False):
    id: int
    node_id: str
    number: int
    title: str
    body: str
    state: str
    user: dict[str, Any]
    labels: list[dict[str, Any]]
    assignees: list[dict[str, Any]]
    milestone: dict[str, Any] | None
    comments: int
    created_at: str
    updated_at: str
    closed_at: str | None
    html_url: str
    url: str


class CommentResponse(TypedDict, total=False):
    id: int
    body: str
    user: dict[str, Any]
    created_at: str
    updated_at: str
    html_url: str
    url: str
    diff_hunk: str
    path: str
    position: int
    original_position: int
    commit_id: str
    original_commit_id: str
    line: int
    side: str
    pull_request_url: str
    in_reply_to_id: int


class RepositoryResponse(TypedDict, total=False):
    id: int
    name: str
    full_name: str
    owner: dict[str, Any]
    private: bool
    description: str | None
    fork: bool
    created_at: str
    updated_at: str
    pushed_at: str
    size: int
    stargazers_count: int
    watchers_count: int
    language: str | None
    forks_count: int
    open_issues_count: int
    default_branch: str
    html_url: str
    url: str
    clone_url: str


class PullRequestResponse(TypedDict, total=False):
    id: int
    number: int
    title: str
    body: str
    state: str
    user: dict[str, Any]
    created_at: str
    updated_at: str
    closed_at: str | None
    merged_at: str | None
    merge_commit_sha: str | None
    head: dict[str, Any]
    base: dict[str, Any]
    html_url: str
    url: str
    diff_url: str
    patch_url: str
    diff_content: str
    mergeable: bool | None
    mergeable_state: str
    requested_reviewers: list[dict[str, Any]]
    requested_teams: list[dict[str, Any]]


class CommitResponse(TypedDict, total=False):
    sha: str
    commit: dict[str, Any]
    author: dict[str, Any] | None
    committer: dict[str, Any] | None
    parents: list[dict[str, Any]]
    html_url: str
    url: str


class PullRequestFileResponse(TypedDict, total=False):
    filename: str
    status: str
    additions: int
    deletions: int
    changes: int
    blob_url: str
    raw_url: str
    contents_url: str
    patch: str | None


class ActivityResponse(TypedDict, total=False):
    id: int
    node_id: str
    timestamp: str
    activity_type: str
    actor: dict[str, Any] | None
    ref: str | None
    ref_type: str | None
    before: str
    after: str


class LabelResponse(TypedDict, total=False):
    id: int
    node_id: str
    name: str
    color: str
    description: str | None
    default: bool
