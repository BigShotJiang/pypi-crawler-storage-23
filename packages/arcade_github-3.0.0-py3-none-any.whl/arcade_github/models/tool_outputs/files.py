from typing_extensions import TypedDict


class FileContentOutput(TypedDict, total=False):
    """Output for file content tools."""

    name: str
    """Name of the file."""

    path: str
    """Path to the file."""

    sha: str
    """SHA of the file."""

    size: int
    """Size of the file in bytes."""

    encoding: str
    """Encoding of the content (usually base64)."""

    content: str
    """Decoded content of the file."""

    line_count: int
    """Total number of lines in the decoded content."""

    html_url: str
    """URL to view the file on GitHub."""

    download_url: str
    """URL to download the raw file."""

    line_range: dict
    """Line range retrieved (start and end line numbers) if partial content requested."""

    line_range_warnings: list[str]
    """Warnings generated while adjusting the requested line range."""


class LinesChangedInfo(TypedDict, total=False):
    """Line change metadata for partial file updates."""

    start_line: int
    """First line number replaced."""

    end_line: int
    """Last line number replaced."""

    old_line_count: int
    """Number of lines removed."""

    new_line_count: int
    """Number of lines added."""


class FileUpdateOutput(TypedDict, total=False):
    """Output for file mutation tools."""

    content: FileContentOutput
    """Details of the created/updated file."""

    commit: dict
    """Details of the commit."""

    lines_changed: LinesChangedInfo
    """Metadata describing the line changes that occurred."""


class BranchOutput(TypedDict, total=False):
    """Output for create_branch tool."""

    ref: str
    """The reference name (e.g., refs/heads/feature)."""

    node_id: str
    """Global node ID."""

    url: str
    """API URL for the reference."""

    object: dict
    """Object the reference points to (SHA and type)."""
