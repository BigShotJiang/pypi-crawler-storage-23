from typing import Any

from typing_extensions import TypedDict

from arcade_github.models.tool_outputs.common import PaginationInfo


class IssueOutput(TypedDict, total=False):
    """Cleaned issue data for tool responses."""

    id: int
    """Unique identifier for the issue."""

    number: int
    """Issue number within the repository."""

    url: str
    """API URL for the issue."""

    title: str
    """Title of the issue."""

    body: str
    """Body content of the issue."""

    state: str
    """Current state (open, closed)."""

    html_url: str
    """GitHub web URL for the issue."""

    created_at: str
    """ISO 8601 timestamp when issue was created."""

    updated_at: str
    """ISO 8601 timestamp when issue was last updated."""

    user: str
    """Login of the user who created the issue."""

    assignees: list[str]
    """List of assignee logins."""

    labels: list[str]
    """List of label names."""

    added_to_project: bool
    """Whether issue was successfully added to project (when project specified)."""

    project_number: int
    """Project number if issue was added to project."""

    project_error: str
    """Error message if adding to project failed."""


class IssuesListOutput(TypedDict, total=False):
    """Output for list_issues tool."""

    issues: list[IssueOutput]
    """List of issues."""

    pagination: PaginationInfo
    """Pagination information."""


class CommentOutput(TypedDict, total=False):
    """Cleaned comment data for tool responses."""

    id: int
    """Unique identifier for the comment."""

    url: str
    """API URL for the comment."""

    body: str
    """Content of the comment."""

    user: str
    """Login of the user who created the comment."""

    created_at: str
    """ISO 8601 timestamp when comment was created."""

    updated_at: str
    """ISO 8601 timestamp when comment was last updated."""


class LabelData(TypedDict, total=False):
    """Label data for tool responses."""

    name: str
    """Name of the label."""

    color: str
    """Hex color code without the leading #."""

    description: str
    """Description of the label's purpose."""


class RepositoryLabelsOutput(TypedDict, total=False):
    """Output for list_repository_labels tool."""

    labels: list[LabelData]
    """List of labels defined in the repository."""

    total_count: int
    """Total number of labels."""

    pagination: PaginationInfo
    """Pagination information."""


class LabelsManagementOutput(TypedDict, total=False):
    """Output for manage_labels tool."""

    current_labels: list[str]
    """Current labels after the operation."""

    labels_added: list[str]
    """Labels that were added."""

    labels_removed: list[str]
    """Labels that were removed."""

    fuzzy_matches_used: dict[str, dict[str, Any]]
    """Details of fuzzy matches applied for typo correction."""
