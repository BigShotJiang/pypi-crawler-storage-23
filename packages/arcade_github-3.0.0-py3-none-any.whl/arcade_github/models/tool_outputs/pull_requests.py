from typing_extensions import TypedDict

from arcade_github.models.tool_outputs.common import PaginationInfo


class PullRequestOutput(TypedDict, total=False):
    """Normalized pull request details returned by tools."""

    number: int
    """Pull request number within the repository."""

    title: str
    """Title of the pull request."""

    body: str
    """Body content of the pull request."""

    state: str
    """Current state (open, closed, merged)."""

    html_url: str
    """GitHub web URL for the pull request."""

    diff_url: str
    """URL to view the diff representation."""

    created_at: str
    """ISO 8601 timestamp when the pull request was created."""

    updated_at: str
    """ISO 8601 timestamp when the pull request was last updated."""

    user: str
    """Login of the user who created the pull request."""

    base: str
    """Base branch reference the pull request targets."""

    head: str
    """Head branch reference containing the proposed changes."""

    diff_content: str
    """Raw diff content when requested."""

    url: str
    """GitHub REST API URL for the pull request."""

    id: int
    """Unique identifier of the pull request resource."""

    reviewer_request_errors: list[str]
    """Human-readable errors when reviewer requests fail."""


class PullRequestsListOutput(TypedDict, total=False):
    """Output for list_pull_requests tool."""

    pull_requests: list[PullRequestOutput]
    """List of pull requests."""

    pagination: PaginationInfo
    """Pagination information."""


class CommitDetails(TypedDict, total=False):
    """Metadata describing a commit."""

    message: str
    """Commit message headline."""

    author_name: str
    """Display name of the commit author."""

    committer_name: str
    """Display name of the committer."""

    committed_date: str
    """ISO 8601 timestamp of the commit."""


class CommitData(TypedDict, total=False):
    """Individual commit entry returned by list_pull_request_commits."""

    sha: str
    """SHA hash of the commit."""

    html_url: str
    """GitHub web URL for the commit."""

    diff_url: str
    """URL to view the commit diff."""

    metadata: CommitDetails
    """Commit metadata suitable for rendering."""

    author: str
    """Login of the commit author."""

    committer: str
    """Login of the committer."""


class CommitsListOutput(TypedDict, total=False):
    """Output for list_pull_request_commits tool."""

    commits: list[CommitData]
    """List of commits on the pull request."""


class ReviewCommentOutput(TypedDict, total=False):
    """Cleaned review comment data for tool responses."""

    id: int
    """Unique identifier for the comment."""

    url: str
    """API URL for the comment."""

    diff_hunk: str
    """Diff hunk the comment is about."""

    path: str
    """File path the comment is on."""

    position: int
    """Position in the diff."""

    original_position: int
    """Original position in the diff."""

    commit_id: str
    """SHA of the commit the comment is on."""

    original_commit_id: str
    """SHA of the original commit."""

    in_reply_to_id: int
    """ID of the comment this is replying to."""

    user: str
    """Login of the user who created the comment."""

    body: str
    """Content of the comment."""

    created_at: str
    """ISO 8601 timestamp when comment was created."""

    updated_at: str
    """ISO 8601 timestamp when comment was last updated."""

    html_url: str
    """GitHub web URL for the comment."""

    line: int
    """Line number the comment is on."""

    side: str
    """Side of the diff (LEFT or RIGHT)."""

    pull_request_url: str
    """API URL of the associated pull request."""

    pull_request_review_id: int
    """Review ID this comment belongs to."""

    thread_node_id: str
    """GraphQL Node ID for the review thread (for resolving conversations)."""

    thread_resolved: bool
    """Whether the conversation thread is resolved."""


class ReviewCommentsListOutput(TypedDict, total=False):
    """Output for list_review_comments_on_pull_request tool."""

    review_comments: list[ReviewCommentOutput]
    """List of review comments."""

    pagination: PaginationInfo
    """Pagination information."""

    total_threads: int
    """Total number of unique conversation threads."""


class ReviewOutput(TypedDict, total=False):
    """Output for submit_pull_request_review tool."""

    id: int
    """Review ID."""

    state: str
    """Review state."""

    body: str
    """Review comment body."""

    user: str
    """Reviewer username."""

    submitted_at: str
    """ISO 8601 timestamp when review was submitted."""

    html_url: str
    """GitHub web URL for the review."""


class MergeStatusOutput(TypedDict, total=False):
    """Output for merge_pull_request tool."""

    success: bool
    """Whether the merge operation succeeded."""

    merged: bool
    """Whether the PR was actually merged."""

    merge_commit_sha: str
    """SHA of the merge commit if successful."""

    status: str
    """Merge status: merged, blocked, conflict, checks_failed, behind."""

    blocking_reasons: list[str]
    """Human-readable reasons why merge is blocked."""

    failed_checks: list[str]
    """Names of failing status checks."""

    branch_deleted: bool
    """Whether the head branch was deleted after merge."""


class UserData(TypedDict, total=False):
    """GitHub user information."""

    login: str
    """GitHub username."""

    name: str
    """Display name."""

    email: str
    """Email address."""

    id: int
    """User ID."""

    html_url: str
    """GitHub profile URL."""

    match_method: str
    """How the user was matched (login, name, email, email_prefix)."""


class UserSuggestion(TypedDict, total=False):
    """User suggestion with confidence score."""

    login: str
    """GitHub username."""

    name: str
    """Display name."""

    email: str
    """Email address."""

    confidence_score: float
    """Match confidence (0.0-1.0)."""

    match_method: str
    """How the user was matched (login, name, email, email_prefix)."""

    html_url: str
    """GitHub profile URL."""


class AssigneeOutput(TypedDict, total=False):
    """Output for assign_pull_request_user tool."""

    success: bool
    """Whether assignment succeeded."""

    assigned_user: UserData
    """Details of the assigned user."""

    suggestions: list[UserSuggestion]
    """User suggestions if no confident match found."""

    search_scope: str
    """Search scope used: collaborators, org_members, api_search."""

    validation_performed: bool
    """Whether pre-validation was performed."""


class CheckDetail(TypedDict, total=False):
    """Individual check run or status check details."""

    name: str
    """Name of the check."""

    status: str
    """Status: queued, in_progress, completed."""

    conclusion: str
    """Conclusion: success, failure, neutral, cancelled, skipped."""

    html_url: str
    """URL to check details."""


class ChecksSummary(TypedDict, total=False):
    """Summary of all status checks."""

    total: int
    """Total number of checks."""

    passed: int
    """Number of passed checks."""

    failed: int
    """Number of failed checks."""

    pending: int
    """Number of pending checks."""

    conclusion: str
    """Overall conclusion: success, failure, pending."""


class ReviewsSummary(TypedDict, total=False):
    """Summary of PR reviews."""

    approved_count: int
    """Number of approving reviews."""

    changes_requested_count: int
    """Number of reviews requesting changes."""

    required_approvals: int
    """Number of required approving reviews."""

    requirements_met: bool
    """Whether review requirements are met."""


class MergeCheckOutput(TypedDict, total=False):
    """Output for check_pull_request_merge_status tool."""

    ready_to_merge: bool
    """Overall readiness to merge."""

    mergeable: bool
    """Whether PR can be merged."""

    mergeable_state: str
    """GitHub mergeable state."""

    checks_summary: ChecksSummary
    """Summary of all checks."""

    checks_details: list[CheckDetail]
    """Individual check details if requested."""

    reviews_summary: ReviewsSummary
    """Summary of review status."""

    conflicts: bool
    """Whether PR has merge conflicts."""

    behind_by: int
    """Number of commits behind base branch."""

    blocking_reasons: list[str]
    """Prioritized blocking reasons."""

    suggested_actions: list[str]
    """Suggested next steps."""


class ReviewersOutput(TypedDict, total=False):
    """Output for manage_pull_request_reviewers tool."""

    requested_reviewers: list[str]
    """List of user reviewer logins."""

    requested_team_reviewers: list[str]
    """List of team reviewer slugs."""

    reviewers_added: list[str]
    """Users successfully added as reviewers."""

    teams_added: list[str]
    """Teams successfully added as reviewers."""

    reviewers_removed: list[str]
    """Users successfully removed as reviewers."""

    teams_removed: list[str]
    """Teams successfully removed as reviewers."""


class ResolveThreadOutput(TypedDict, total=False):
    """Output for resolve_review_thread tool."""

    thread_id: str
    """GraphQL Node ID of the thread."""

    resolved: bool
    """Whether thread is now resolved."""

    success: bool
    """Whether operation succeeded."""
