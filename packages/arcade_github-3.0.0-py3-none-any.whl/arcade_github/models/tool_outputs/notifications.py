from typing_extensions import TypedDict


class ReviewWorkloadPR(TypedDict, total=False):
    """Pull request in review workload."""

    number: int
    """Pull request number."""

    title: str
    """PR title."""

    repository: str
    """Repository full name."""

    author: str
    """PR author login."""

    created_at: str
    """ISO 8601 creation timestamp."""

    updated_at: str
    """ISO 8601 last update timestamp."""

    html_url: str
    """GitHub web URL."""

    draft: bool
    """Whether PR is draft."""

    labels: list[str]
    """PR labels."""


class ReviewWorkloadOutput(TypedDict, total=False):
    """PR review workload information."""

    pending_reviews: list[ReviewWorkloadPR]
    """PRs awaiting your review."""

    pending_count: int
    """Number of PRs awaiting review."""

    reviewed_recently: list[ReviewWorkloadPR]
    """PRs you recently reviewed (still open)."""

    reviewed_count: int
    """Number of recently reviewed PRs."""
