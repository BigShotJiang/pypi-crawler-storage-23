# Base URL for GitHub API
GITHUB_API_BASE_URL = "https://api.github.com"

# Authentication mode: False = GitHub App, True = OAuth App
USE_OAUTH_APP_AUTH = False

# Summary collection limits for first-page metrics
MAX_SUMMARY_PROJECTS = 50
MAX_SUMMARY_ITEMS = 500

# Fuzzy matching thresholds
FUZZY_MATCH_THRESHOLD = 0.70
FUZZY_AUTO_ACCEPT_CONFIDENCE = 0.90
DISABLE_AUTO_ACCEPT_THRESHOLD = 1.01

# User resolution confidence controls
PERFECT_MATCH_CONFIDENCE = 1.0
USER_RESOLUTION_SCOPED_PRIMARY_CONFIDENCE = 0.95
USER_RESOLUTION_API_PRIMARY_CONFIDENCE = 0.80
USER_RESOLUTION_API_SUGGESTION_CONFIDENCE = 0.70
USER_RESOLUTION_SCOPED_NAME_CONFIDENCE = 0.90
USER_RESOLUTION_SCOPED_NAME_REMAINDER_CONFIDENCE = 0.85
USER_RESOLUTION_API_NAME_BASE_CONFIDENCE = 0.75
USER_RESOLUTION_CONFIDENCE_DECREMENT = 0.05
USER_RESOLUTION_MIN_CONFIDENCE = 0.50
USER_RESOLUTION_MAX_SUGGESTIONS = 10

# Project resolution configuration
PROJECT_SUGGESTION_THRESHOLD_MULTIPLIER = 0.5
PROJECT_MAX_SUGGESTIONS = 10

# HTTP client configuration
HTTP_CLIENT_TIMEOUT = 30.0
HTTP_CLIENT_MAX_KEEPALIVE_CONNECTIONS = 20
HTTP_CLIENT_MAX_CONNECTIONS = 100

# Retry configuration (exponential backoff in seconds)
HTTP_RETRY_BACKOFF_DELAYS = [0.3, 0.6, 1.2]
HTTP_RETRY_SERVER_ERROR_THRESHOLD = 500

# Endpoint patterns
ENDPOINTS = {
    "repo": "/repos/{owner}/{repo}",
    "org_repos": "/orgs/{org}/repos",
    "repo_activity": "/repos/{owner}/{repo}/events",
    "repo_pulls_comments": "/repos/{owner}/{repo}/pulls/comments",
    "repo_issues": "/repos/{owner}/{repo}/issues",
    "repo_issue": "/repos/{owner}/{repo}/issues/{issue_number}",
    "repo_issue_comments": "/repos/{owner}/{repo}/issues/{issue_number}/comments",
    "repo_labels": "/repos/{owner}/{repo}/labels",
    "repo_issue_labels": "/repos/{owner}/{repo}/issues/{issue_number}/labels",
    "repo_issue_label": "/repos/{owner}/{repo}/issues/{issue_number}/labels/{name}",
    "repo_pulls": "/repos/{owner}/{repo}/pulls",
    "repo_pull": "/repos/{owner}/{repo}/pulls/{pull_number}",
    "repo_pull_commits": "/repos/{owner}/{repo}/pulls/{pull_number}/commits",
    "repo_pull_files": "/repos/{owner}/{repo}/pulls/{pull_number}/files",
    "repo_pull_comments": "/repos/{owner}/{repo}/pulls/{pull_number}/comments",
    "repo_pull_comment_replies": "/repos/{owner}/{repo}/pulls/{pull_number}/comments/{comment_id}/replies",  # noqa: E501
    "repo_branches": "/repos/{owner}/{repo}/branches",
    "repo_commit": "/repos/{owner}/{repo}/commits/{commit_sha}",
    "repo_contents": "/repos/{owner}/{repo}/contents/{path}",
    "user_starred": "/user/starred/{owner}/{repo}",
    "repo_stargazers": "/repos/{owner}/{repo}/stargazers",
    "user": "/user",
    "user_orgs": "/user/orgs",
    "user_repos": "/user/repos",
    "user_teams": "/user/teams",
    "search_issues": "/search/issues",
    "search_commits": "/search/commits",
    "org_projects_v2": "/orgs/{org}/projectsV2",
    "user_projects_v2": "/users/{username}/projectsV2",
    "org_project_v2": "/orgs/{org}/projectsV2/{project_number}",
    "user_project_v2": "/users/{username}/projectsV2/{project_number}",
    "org_project_v2_items": "/orgs/{org}/projectsV2/{project_number}/items",
    "user_project_v2_items": "/users/{username}/projectsV2/{project_number}/items",
    "org_project_v2_fields": "/orgs/{org}/projectsV2/{project_number}/fields",
    "user_project_v2_fields": "/users/{username}/projectsV2/{project_number}/fields",
    "org_project_v2_item": "/orgs/{org}/projectsV2/{project_number}/items/{item_id}",
    "user_project_v2_item": "/users/{username}/projectsV2/{project_number}/items/{item_id}",
    "repo_pull_merge": "/repos/{owner}/{repo}/pulls/{pull_number}/merge",
    "repo_pull_update_branch": "/repos/{owner}/{repo}/pulls/{pull_number}/update-branch",
    "repo_pull_requested_reviewers": "/repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers",  # noqa: E501
    "repo_pull_reviews": "/repos/{owner}/{repo}/pulls/{pull_number}/reviews",
    "repo_issue_assignees": "/repos/{owner}/{repo}/issues/{issue_number}/assignees",
    "repo_assignee": "/repos/{owner}/{repo}/assignees/{assignee}",
    "search_users": "/search/users",
    "repo_collaborators": "/repos/{owner}/{repo}/collaborators",
    "repo_teams": "/repos/{owner}/{repo}/teams",
    "org_members": "/orgs/{org}/members",
    "repo_branch": "/repos/{owner}/{repo}/branches/{branch}",
    "repo_git_ref": "/repos/{owner}/{repo}/git/refs/{ref}",
    "repo_git_refs": "/repos/{owner}/{repo}/git/refs",
    "repo_commit_status": "/repos/{owner}/{repo}/commits/{ref}/status",
    "repo_commit_check_runs": "/repos/{owner}/{repo}/commits/{ref}/check-runs",
    "repo_compare": "/repos/{owner}/{repo}/compare/{base}...{head}",
}
