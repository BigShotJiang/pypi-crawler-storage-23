from typing import Annotated

from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import ToolExecutionError

from arcade_github.models.mappers import map_comment, map_issue
from arcade_github.models.models import (
    IssueSortProperty,
    IssueState,
    ProjectScopeTarget,
    SortDirection,
)
from arcade_github.models.tool_outputs.issues import CommentOutput, IssueOutput, IssuesListOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.pagination_utils import build_pagination_info
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(scopes=["repo", "project"]),
    requires_secrets=["GITHUB_SERVER_URL"],
)
async def create_issue(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    title: Annotated[str, "The title of the issue."],
    body: Annotated[str | None, "The contents of the issue."] = None,
    assignees: Annotated[list[str] | None, "Logins for Users to assign to this issue."] = None,
    milestone: Annotated[
        int | None, "The number of the milestone to associate this issue with."
    ] = None,
    labels: Annotated[list[str] | None, "Labels to associate with this issue."] = None,
    add_to_project_number: Annotated[int | None, "Project number to add this issue to"] = None,
    add_to_project_scope: Annotated[ProjectScopeTarget | None, "Project scope"] = None,
    add_to_project_owner: Annotated[
        str | None, "Project owner (defaults to issue owner if not specified)"
    ] = None,
) -> Annotated[IssueOutput, "Created issue details with optional project link status"]:
    """
    Create an issue in a GitHub repository.

    Optionally add the created issue to a project by specifying add_to_project_number
    and add_to_project_scope.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    issue_data = await client.create_repository_issue(
        owner=owner,
        repo=repo,
        title=title,
        body=body,
        assignees=assignees,
        milestone=milestone,
        labels=labels,
    )

    result = map_issue(issue_data)

    if add_to_project_number is not None:
        if not add_to_project_scope:
            raise ToolExecutionError(
                "add_to_project_scope required when add_to_project_number specified"
            )

        project_owner = add_to_project_owner or owner

        try:
            scope_str = (
                "organization"
                if add_to_project_scope == ProjectScopeTarget.ORGANIZATION
                else "user"
            )
            await client.add_item_to_project(
                scope_target=scope_str,
                identifier=project_owner,
                project_number=add_to_project_number,
                item_number=issue_data["number"],
                item_type="Issue",
            )
            result["added_to_project"] = True
            result["project_number"] = add_to_project_number
        except Exception as e:
            result["added_to_project"] = False
            result["project_error"] = f"Failed to add to project: {e}"

    return remove_none_values_recursive(result)


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def update_issue(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository"],
    repo: Annotated[str, "The name of the repository"],
    issue_number: Annotated[int, "The number that identifies the issue"],
    title: Annotated[str | None, "The new title. Not provided = unchanged."] = None,
    body: Annotated[str | None, "The new contents. Not provided = unchanged."] = None,
    state: Annotated[IssueState | None, "State of the issue. Not provided = unchanged."] = None,
    labels: Annotated[
        list[str] | None, "Labels to set (replaces existing). Not provided = unchanged."
    ] = None,
    assignees: Annotated[
        list[str] | None, "Assignees to set (replaces existing). Not provided = unchanged."
    ] = None,
    milestone: Annotated[int | None, "Milestone number. Not provided = unchanged."] = None,
) -> Annotated[IssueOutput, "Updated issue details"]:
    """
    Update an issue in a GitHub repository.

    Parameters that are not provided (None) will not be updated or cleared.
    Updates apply to the issue in the repository. If the issue is in a project,
    the project item will automatically reflect these changes.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    issue_data = await client.update_repository_issue(
        owner=owner,
        repo=repo,
        issue_number=issue_number,
        title=title,
        body=body,
        state=state.value if state else None,
        labels=labels,
        assignees=assignees,
        milestone=milestone,
    )
    return remove_none_values_recursive(map_issue(issue_data))


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def create_issue_comment(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    issue_number: Annotated[int, "The number that identifies the issue."],
    body: Annotated[str, "The contents of the comment."],
) -> Annotated[CommentOutput, "Created comment details"]:
    """
    Create a comment on an issue in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    comment_data = await client.create_issue_comment(
        owner=owner, repo=repo, issue_number=issue_number, body=body
    )
    return remove_none_values_recursive(map_comment(comment_data))


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def list_issues(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    state: Annotated[
        IssueState | None,
        "Indicates the state of the issues to return. Default: open",
    ] = IssueState.OPEN,
    labels: Annotated[
        str | None,
        "A list of comma separated label names. Example: bug,ui,@high",
    ] = None,
    sort: Annotated[
        IssueSortProperty | None,
        "What to sort results by. Default: created",
    ] = IssueSortProperty.CREATED,
    direction: Annotated[
        SortDirection | None,
        "The direction to sort the results by. Default: desc",
    ] = SortDirection.DESC,
    since: Annotated[
        str | None,
        "Only show notifications updated after the given time. "
        "This is a timestamp in ISO 8601 format: YYYY-MM-DDTHH:MM:SSZ.",
    ] = None,
    per_page: Annotated[
        int | None,
        "The number of results per page (max 100). Default: 30",
    ] = 30,
    page: Annotated[
        int | None,
        "Page number of the results to fetch. Default: 1",
    ] = 1,
    search_org_wide: Annotated[
        bool,
        "Search across all organization repositories instead of just one repository. "
        "Default is False.",
    ] = False,
) -> Annotated[IssuesListOutput, "List of issues in the repository"]:
    """
    List issues in a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page if per_page is not None else 30), 100)
    page = max(1, page if page is not None else 1)

    total_count = None
    if search_org_wide:
        # Build search query for organization-wide search
        query_parts = [f"org:{owner}", "type:issue"]

        if state and state != IssueState.ALL:
            query_parts.append(f"state:{state.value}")

        if labels:
            # Split comma-separated labels and add each as a label filter
            label_list = [label.strip() for label in labels.split(",")]
            for label in label_list:
                query_parts.append(f"label:{label}")

        query = " ".join(query_parts)
        search_result = await client.search_issues(query=query, per_page=per_page, page=page)
        issues_data = search_result.get("items", [])
        total_count = search_result.get("total_count")  # Search API provides total count!
    else:
        issues_data = await client.list_repository_issues(
            owner=owner,
            repo=repo,
            state=state.value if state else None,
            labels=labels,
            sort=sort.value if sort else None,
            direction=direction.value if direction else None,
            since=since,
            per_page=per_page,
            page=page,
        )

    result: IssuesListOutput = {
        "issues": [map_issue(issue) for issue in issues_data],
        "pagination": build_pagination_info(page, per_page, issues_data, total_count),
    }
    return remove_none_values_recursive(result)


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def get_issue(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    issue_number: Annotated[int, "The number that identifies the issue."],
) -> Annotated[IssueOutput, "Issue details"]:
    """
    Get a specific issue from a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    issue_data = await client.get_repository_issue(
        owner=owner, repo=repo, issue_number=issue_number
    )
    return remove_none_values_recursive(map_issue(issue_data))
