from typing import Annotated

from arcade_tdk import ToolContext, tool

from arcade_github.models.mappers import map_review_workload_pr
from arcade_github.models.tool_outputs.notifications import ReviewWorkloadOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive
from arcade_github.utils.review_workload_utils import fetch_review_workload_issues


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "read:user",
            "repo",
        ],
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
)
async def get_review_workload(
    context: ToolContext,
) -> Annotated[ReviewWorkloadOutput, "PR review workload information"]:
    """
    Get pull requests awaiting review by the authenticated user.

    Returns PRs where user is requested as reviewer and PRs user has recently reviewed.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    user_data = await client.get_authenticated_user()
    username = user_data.get("login", "")

    pending_prs, reviewed_prs = await fetch_review_workload_issues(client, username)

    result: ReviewWorkloadOutput = {
        "pending_reviews": [map_review_workload_pr(pr) for pr in pending_prs],
        "pending_count": len(pending_prs),
        "reviewed_recently": [map_review_workload_pr(pr) for pr in reviewed_prs],
        "reviewed_count": len(reviewed_prs),
    }

    return remove_none_values_recursive(result)
