from typing import Annotated

from arcade_tdk import ToolContext, tool

from arcade_github.models.tool_outputs.pull_requests import ResolveThreadOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(
        scopes=[
            "repo",  # GraphQL API - resolveReviewThread mutation
        ]
    ),
    requires_secrets=["GITHUB_SERVER_URL"],
)
async def resolve_review_thread(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository."],
    thread_id: Annotated[str, "The GraphQL Node ID of the review thread."],
    resolved: Annotated[
        bool, "Whether to resolve or unresolve the thread. Default is True."
    ] = True,
) -> Annotated[ResolveThreadOutput, "Thread resolution result"]:
    """
    Resolve or unresolve a pull request review conversation thread.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    mutation = (
        """
    mutation($threadId: ID!) {
      resolveReviewThread(input: {threadId: $threadId}) {
        thread {
          id
          isResolved
        }
      }
    }
    """
        if resolved
        else """
    mutation($threadId: ID!) {
      unresolveReviewThread(input: {threadId: $threadId}) {
        thread {
          id
          isResolved
        }
      }
    }
    """
    )

    variables = {"threadId": thread_id}
    result = await client.execute_graphql(mutation, variables)

    mutation_key = "resolveReviewThread" if resolved else "unresolveReviewThread"
    thread_data = result.get(mutation_key, {}).get("thread", {})

    output: ResolveThreadOutput = {
        "thread_id": thread_id,
        "resolved": thread_data.get("isResolved", resolved),
        "success": True,
    }
    return remove_none_values_recursive(output)
