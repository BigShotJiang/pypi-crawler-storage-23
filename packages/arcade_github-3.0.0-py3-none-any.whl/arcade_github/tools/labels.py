from typing import Annotated, Any

from arcade_tdk import ToolContext, tool
from arcade_tdk.errors import RetryableToolError

from arcade_github.constants import DISABLE_AUTO_ACCEPT_THRESHOLD, FUZZY_AUTO_ACCEPT_CONFIDENCE
from arcade_github.models.mappers import map_label
from arcade_github.models.models import LabelEntityType
from arcade_github.models.tool_outputs.issues import LabelsManagementOutput, RepositoryLabelsOutput
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.label_utils import (
    resolve_labels_with_fuzzy,
    validate_and_raise_label_errors,
)
from arcade_github.utils.pagination_utils import build_pagination_info
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def list_repository_labels(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository. The name is not case sensitive."],
    repo: Annotated[
        str,
        "The name of the repository without the .git extension. The name is not case sensitive.",
    ],
    per_page: Annotated[int, "The number of results per page (max 100). Default is 100."] = 100,
    page: Annotated[int, "The page number of the results to fetch. Default is 1."] = 1,
) -> Annotated[RepositoryLabelsOutput, "List of repository labels"]:
    """
    List all labels defined in a repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    page = max(1, page)

    labels_data = await client.list_repository_labels(owner, repo, per_page, page)

    total_count = len(labels_data)
    result: RepositoryLabelsOutput = {
        "labels": [map_label(label) for label in labels_data],
        "total_count": total_count,
        "pagination": build_pagination_info(page, per_page, labels_data),
    }

    return remove_none_values_recursive(result)


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def manage_labels(
    context: ToolContext,
    owner: Annotated[str, "The account owner of the repository."],
    repo: Annotated[str, "The name of the repository without the .git extension."],
    number: Annotated[int, "The number that identifies the issue or pull request."],
    entity_type: Annotated[LabelEntityType, "The type of entity (issue or pull_request)."],
    add_labels: Annotated[
        list[str] | None, "List of label names to add. Supports fuzzy matching for typo tolerance."
    ] = None,
    remove_labels: Annotated[
        list[str] | None,
        "List of label names to remove. Supports fuzzy matching for typo tolerance.",
    ] = None,
    auto_accept_matches: Annotated[
        bool,
        f"Auto-accept fuzzy matches above {FUZZY_AUTO_ACCEPT_CONFIDENCE} confidence. "
        "Default is False.",
    ] = False,
) -> Annotated[LabelsManagementOutput, "Label management operation result"]:
    """
    Add or remove labels from an issue or pull request.

    Supports fuzzy matching for typo tolerance. Both issues and pull requests
    support labels through the same API. You can add and remove labels in a
    single operation.
    """
    if not add_labels and not remove_labels:
        raise RetryableToolError(
            message="At least one of add_labels or remove_labels must be provided.",
            additional_prompt_content="Please provide labels to add or remove.",
        )

    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    auto_accept_confidence = (
        FUZZY_AUTO_ACCEPT_CONFIDENCE if auto_accept_matches else DISABLE_AUTO_ACCEPT_THRESHOLD
    )

    added_labels: list[str] = []
    removed_labels: list[str] = []
    all_fuzzy_matches: dict[str, dict[str, Any]] = {}

    # Add labels
    if add_labels:
        resolved_add, fuzzy_add, suggestions_add = await resolve_labels_with_fuzzy(
            client, owner, repo, add_labels, auto_accept_confidence, 0.70
        )
        validate_and_raise_label_errors(suggestions_add)

        if resolved_add:
            await client.add_issue_labels(owner, repo, number, resolved_add)
            added_labels = resolved_add
            all_fuzzy_matches.update(fuzzy_add)

    # Remove labels
    if remove_labels:
        resolved_remove, fuzzy_remove, suggestions_remove = await resolve_labels_with_fuzzy(
            client, owner, repo, remove_labels, auto_accept_confidence, 0.70
        )
        validate_and_raise_label_errors(suggestions_remove)

        for label_name in resolved_remove:
            await client.remove_issue_label(owner, repo, number, label_name)
        removed_labels = resolved_remove
        all_fuzzy_matches.update(fuzzy_remove)

    # Fetch current labels
    issue_data = await client.get_repository_issue(owner, repo, number)
    current_label_names = [label.get("name", "") for label in issue_data.get("labels", [])]

    result: LabelsManagementOutput = {
        "current_labels": current_label_names,
        "labels_added": added_labels,
        "labels_removed": removed_labels,
        "fuzzy_matches_used": all_fuzzy_matches,
    }

    return remove_none_values_recursive(result)
