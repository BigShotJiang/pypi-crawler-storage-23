from typing import Annotated

from arcade_tdk import ToolContext, tool

from arcade_github.models.mappers import map_stargazer
from arcade_github.models.tool_outputs.activity import SetStarredOutput, StargazersListOutput
from arcade_github.models.tool_outputs.common import PaginationInfo
from arcade_github.utils.auth_utils import get_github_auth
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def set_starred(
    context: ToolContext,
    owner: Annotated[str, "The owner of the repository"],
    name: Annotated[str, "The name of the repository"],
    starred: Annotated[bool, "Whether to star the repository or not. Default is True."] = True,
) -> Annotated[SetStarredOutput, "Result of starring/unstarring operation"]:
    """
    Star or un-star a GitHub repository.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    if starred:
        await client.star_repository(owner, name)
    else:
        await client.unstar_repository(owner, name)

    result: SetStarredOutput = {
        "starred": starred,
        "repository": f"{owner}/{name}",
        "message": f"Successfully {'starred' if starred else 'unstarred'} the repository",
    }
    return remove_none_values_recursive(result)


@tool(requires_auth=get_github_auth(), requires_secrets=["GITHUB_SERVER_URL"])
async def list_stargazers(
    context: ToolContext,
    owner: Annotated[str, "The owner of the repository"],
    repo: Annotated[str, "The name of the repository"],
    page: Annotated[int, "The page number of the stargazers to fetch. Default is 1."] = 1,
    per_page: Annotated[int, "The number of stargazers per page (max 100). Default is 30."] = 30,
) -> Annotated[StargazersListOutput, "List of stargazers for the repository"]:
    """
    List the stargazers for a GitHub repository.

    Returns stargazers in chronological order (oldest first).
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    page = max(1, page)

    data = await client.list_repository_stargazers(owner, repo, per_page=per_page, page=page)
    stargazers = [map_stargazer(stargazer) for stargazer in data]

    pagination: PaginationInfo = {
        "page": page,
        "per_page": per_page,
        "has_next_page": len(data) == per_page,
    }

    result: StargazersListOutput = {"stargazers": stargazers, "pagination": pagination}
    return remove_none_values_recursive(result)
