"""
GitHub toolkit for Arcade AI.

This toolkit provides tools for interacting with GitHub repositories, issues, and pull requests.
"""

from arcade_github.models.models import (
    FileMode,
    FileUpdateMode,
    IssueSortProperty,
    IssueState,
    SortDirection,
)
from arcade_github.tools.activity import (
    list_stargazers,
    set_starred,
)
from arcade_github.tools.branches import create_branch
from arcade_github.tools.files import (
    create_file,
    get_file_contents,
    update_file_lines,
)
from arcade_github.tools.issues import (
    create_issue,
    create_issue_comment,
    get_issue,
    list_issues,
    update_issue,
)
from arcade_github.tools.labels import list_repository_labels, manage_labels
from arcade_github.tools.pr_lifecycle import (
    assign_pull_request_user,
    check_pull_request_merge_status,
    create_pull_request,
    manage_pull_request_reviewers,
    merge_pull_request,
    submit_pull_request_review,
)
from arcade_github.tools.projects import (
    list_project_fields,
    list_project_items,
    list_projects,
    search_project_item,
)
from arcade_github.tools.pull_requests import (
    create_reply_for_review_comment,
    create_review_comment,
    get_pull_request,
    list_pull_request_commits,
    list_pull_requests,
    list_review_comments_on_pull_request,
    update_pull_request,
)
from arcade_github.tools.repositories import (
    count_stargazers,
    get_repository,
    list_org_repositories,
    list_repository_activities,
    list_repository_collaborators,
    list_review_comments_in_a_repository,
    search_my_repos,
)
from arcade_github.tools.review_threads import resolve_review_thread
from arcade_github.tools.review_workload import get_review_workload
from arcade_github.tools.user_context import (
    get_user_open_items,
    get_user_recent_activity,
    who_am_i,
)

__all__ = [
    "IssueSortProperty",
    "IssueState",
    "SortDirection",
    "FileMode",
    "FileUpdateMode",
    "assign_pull_request_user",
    "check_pull_request_merge_status",
    "count_stargazers",
    "create_branch",
    "create_issue",
    "create_issue_comment",
    "create_file",
    "create_pull_request",
    "create_reply_for_review_comment",
    "create_review_comment",
    "get_file_contents",
    "get_issue",
    "get_pull_request",
    "get_repository",
    "get_review_workload",
    "get_user_open_items",
    "get_user_recent_activity",
    "list_issues",
    "list_org_repositories",
    "list_project_fields",
    "list_project_items",
    "list_projects",
    "list_review_comments_on_pull_request",
    "list_pull_request_commits",
    "list_pull_requests",
    "list_repository_activities",
    "list_repository_collaborators",
    "list_repository_labels",
    "list_review_comments_in_a_repository",
    "list_stargazers",
    "manage_labels",
    "manage_pull_request_reviewers",
    "merge_pull_request",
    "resolve_review_thread",
    "search_my_repos",
    "search_project_item",
    "set_starred",
    "submit_pull_request_review",
    "update_file_lines",
    "update_issue",
    "update_pull_request",
    "who_am_i",
]
