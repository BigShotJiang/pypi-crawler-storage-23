"""Shared networking utilities for Flux daemon and TUI."""
