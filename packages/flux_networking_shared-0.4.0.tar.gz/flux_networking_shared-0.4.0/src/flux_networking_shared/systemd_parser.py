from ast import literal_eval
from configparser import ConfigParser


class ConfigParserDict(dict):
    def items(self):
        for k, v in super().items():
            if v.startswith("[") and v.endswith("]"):
                # change this to json parse
                for i in literal_eval(v):
                    yield k, i
            else:
                yield k, v


class SystemdConfigParser(ConfigParser):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

        self._dict = ConfigParserDict

    def optionxform(self, optionstr: str) -> str:
        # this stops the keys being lowercased
        return optionstr
