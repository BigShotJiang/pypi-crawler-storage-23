"""Main SDK Client for Agent Payment Network"""

import requests
from typing import Optional, Dict, Any, List
from decimal import Decimal


class AgentPaymentClient:
    """
    Client for interacting with Agent Payment Network API
    
    Example:
        >>> client = AgentPaymentClient(
        ...     api_key="your_api_key",
        ...     base_url="http://localhost:8002"
        ... )
        >>> payment = client.create_payment(
        ...     to_agent_id="agent_123",
        ...     amount=50.00,
        ...     currency="USD",
        ...     payment_method="stripe_card"
        ... )
        >>> print(payment["payment_id"])
    """
    
    def __init__(
        self, 
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:8002",
        timeout: int = 30
    ):
        """
        Initialize the Agent Payment Network client
        
        Args:
            api_key: Your API key (optional for testing)
            base_url: Base URL of the API (default: localhost)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        
        if api_key:
            self.session.headers.update({
                "Authorization": f"Bearer {api_key}"
            })
    
    def _request(
        self, 
        method: str, 
        endpoint: str, 
        **kwargs
    ) -> Dict[str, Any]:
        """Make HTTP request to API"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                timeout=self.timeout,
                **kwargs
            )
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.HTTPError as e:
            error_detail = "Unknown error"
            try:
                error_data = e.response.json()
                error_detail = error_data.get("detail", str(e))
            except:
                error_detail = str(e)
            
            raise PaymentError(f"API Error: {error_detail}")
        
        except requests.exceptions.Timeout:
            raise NetworkError("Request timed out")
        
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error: {str(e)}")
    
    # Payment Operations
    
    def create_payment(
        self,
        to_agent_id: str,
        amount: float,
        currency: str = "USD",
        payment_method: str = "auto",
        memo: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new payment
        
        Args:
            to_agent_id: Recipient agent ID
            amount: Payment amount
            currency: Currency code (USD, ETH, etc.)
            payment_method: Payment method (auto, crypto, stripe_card)
            memo: Optional payment memo
            
        Returns:
            Payment response with payment_id, status, and client_secret
            
        Example:
            >>> payment = client.create_payment(
            ...     to_agent_id="agent_456",
            ...     amount=100.00,
            ...     currency="USD",
            ...     payment_method="stripe_card",
            ...     memo="Monthly API usage"
            ... )
            >>> print(f"Payment ID: {payment['payment_id']}")
        """
        data = {
            "to_agent_id": to_agent_id,
            "amount": amount,
            "currency": currency,
            "payment_method": payment_method,
            "memo": memo
        }
        
        return self._request(
            "POST",
            "/api/v1/payments/create",
            json=data
        )
    
    def get_payment(self, payment_id: str) -> Dict[str, Any]:
        """
        Get payment status by ID
        
        Args:
            payment_id: Payment ID
            
        Returns:
            Payment details including status
        """
        return self._request(
            "GET",
            f"/api/v1/payments/{payment_id}"
        )
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check API health and available payment methods
        
        Returns:
            Health status and configuration
        """
        return self._request(
            "GET",
            "/api/v1/payments/health"
        )
    
    # Payment Method Management
    
    def add_payment_method(
        self,
        agent_id: str,
        method_type: str,
        wallet_address: Optional[str] = None,
        stripe_payment_method_id: Optional[str] = None,
        is_default: bool = False
    ) -> Dict[str, Any]:
        """
        Add a new payment method
        
        Args:
            agent_id: Your agent ID
            method_type: Type (crypto_wallet, stripe_card, stripe_bank)
            wallet_address: Wallet address (for crypto)
            stripe_payment_method_id: Stripe payment method ID (for cards)
            is_default: Set as default payment method
            
        Returns:
            Payment method details
        """
        data = {
            "agent_id": agent_id,
            "method_type": method_type,
            "is_default": is_default
        }
        
        if wallet_address:
            data["wallet_address"] = wallet_address
        
        if stripe_payment_method_id:
            data["stripe_payment_method_id"] = stripe_payment_method_id
        
        return self._request(
            "POST",
            "/api/v1/payment-methods/add",
            json=data
        )
    
    def list_payment_methods(self, agent_id: str) -> List[Dict[str, Any]]:
        """
        List all payment methods for an agent
        
        Args:
            agent_id: Agent ID
            
        Returns:
            List of payment methods
        """
        return self._request(
            "GET",
            f"/api/v1/payment-methods/list/{agent_id}"
        )
    
    def delete_payment_method(self, method_id: str) -> Dict[str, Any]:
        """
        Delete a payment method
        
        Args:
            method_id: Payment method ID
            
        Returns:
            Success confirmation
        """
        return self._request(
            "DELETE",
            f"/api/v1/payment-methods/{method_id}"
        )


# Exceptions

class PaymentError(Exception):
    """Base exception for payment errors"""
    pass


class AuthenticationError(PaymentError):
    """Authentication failed"""
    pass


class InvalidRequestError(PaymentError):
    """Invalid request parameters"""
    pass


class NetworkError(PaymentError):
    """Network communication error"""
    pass
