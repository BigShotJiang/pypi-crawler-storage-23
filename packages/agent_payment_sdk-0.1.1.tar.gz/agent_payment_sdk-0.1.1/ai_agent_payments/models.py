from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from datetime import datetime

@dataclass
class Payment:
    """Payment object"""
    txn_id: str
    status: str
    amount_usd: float
    fee_usd: float
    processing_time_ms: Optional[float] = None
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Payment':
        return cls(
            txn_id=data.get('txn_id'),
            status=data.get('status'),
            amount_usd=data.get('amount_usd'),
            fee_usd=data.get('fee_usd'),
            processing_time_ms=data.get('processing_time_ms')
        )

@dataclass
class Agent:
    """Agent object"""
    agent_id: str
    balance_usd: float
    available_usd: float

@dataclass
class Webhook:
    """Webhook endpoint object"""
    id: int
    agent_address: str
    url: str
    events: List[str]
    is_active: bool
    secret_key: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Optional[Dict] = None
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Webhook':
        return cls(
            id=data.get('id'),
            agent_address=data.get('agent_address'),
            url=data.get('url'),
            events=data.get('events', []),
            is_active=data.get('is_active', True),
            secret_key=data.get('secret_key'),
            created_at=data.get('created_at'),
            updated_at=data.get('updated_at'),
            metadata=data.get('metadata', {})
        )

@dataclass
class WebhookDelivery:
    """Webhook delivery attempt"""
    id: int
    webhook_endpoint_id: int
    event_type: str
    status: str
    attempt_count: int
    response_status_code: Optional[int] = None
    error_message: Optional[str] = None
