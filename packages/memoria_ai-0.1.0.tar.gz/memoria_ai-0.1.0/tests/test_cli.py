"""Tests for Click CLI commands using CliRunner."""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import frontmatter
import pytest
from click.testing import CliRunner

from aspirational_self.cli import main


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def cli_env(tmp_path):
    """Set up temporary directories and patch CLI path functions."""
    entries_dir = tmp_path / "data" / "entries"
    entries_dir.mkdir(parents=True)
    index_dir = tmp_path / "data" / "index"
    index_dir.mkdir(parents=True)
    return {
        "entries_dir": entries_dir,
        "index_dir": index_dir,
        "tmp_path": tmp_path,
    }


def _patch_dirs(cli_env):
    """Return patches for CLI directory functions."""
    return (
        patch("aspirational_self.cli.get_entries_dir", return_value=cli_env["entries_dir"]),
        patch("aspirational_self.cli.get_index_dir", return_value=cli_env["index_dir"]),
    )


class TestAddCommand:
    def test_add_with_content(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["add", "My test entry"])
        assert result.exit_code == 0
        assert "Entry saved" in result.output

        # Verify file was created
        entries = list(cli_env["entries_dir"].glob("*.md"))
        assert len(entries) == 1

    def test_add_with_mood(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["add", "--mood", "happy", "Great day"])
        assert result.exit_code == 0

        entries = list(cli_env["entries_dir"].glob("*.md"))
        with open(entries[0]) as f:
            post = frontmatter.load(f)
        assert post.metadata["mood"] == "happy"

    def test_add_with_themes(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(
                main, ["add", "--theme", "career", "--theme", "growth", "Promotion!"]
            )
        assert result.exit_code == 0

        entries = list(cli_env["entries_dir"].glob("*.md"))
        with open(entries[0]) as f:
            post = frontmatter.load(f)
        assert post.metadata["themes"] == ["career", "growth"]

    def test_add_shows_preview(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["add", "Short entry"])
        assert "Preview" in result.output


class TestRecentCommand:
    def test_recent_empty(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["recent"])
        assert result.exit_code == 0
        assert "No entries yet" in result.output

    def test_recent_with_entries(self, runner, cli_env):
        # Create an entry first
        post = frontmatter.Post(
            "Test entry content",
            type="text",
            timestamp="2025-01-15T10:30:00",
            processed=False,
        )
        entry_path = cli_env["entries_dir"] / "2025-01-15-1030-text.md"
        entry_path.write_text(frontmatter.dumps(post))

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["recent"])
        assert result.exit_code == 0
        assert "2025-01-15" in result.output

    def test_recent_with_count(self, runner, cli_env):
        for i in range(5):
            post = frontmatter.Post(
                f"Entry {i}",
                type="text",
                timestamp=f"2025-01-{10+i}T09:00:00",
            )
            path = cli_env["entries_dir"] / f"2025-01-{10+i}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["recent", "-n", "2"])
        assert result.exit_code == 0


class TestReadCommand:
    def test_read_existing_entry(self, runner, cli_env):
        post = frontmatter.Post(
            "My important thoughts",
            type="text",
            timestamp="2025-01-15T10:30:00",
        )
        entry_path = cli_env["entries_dir"] / "2025-01-15-1030-text.md"
        entry_path.write_text(frontmatter.dumps(post))

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["read", "2025-01-15-1030-text.md"])
        assert result.exit_code == 0
        assert "important thoughts" in result.output

    def test_read_nonexistent_entry(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["read", "nonexistent.md"])
        assert "not found" in result.output

    def test_read_partial_match(self, runner, cli_env):
        post = frontmatter.Post("Content", type="text", timestamp="2025-01-15T10:30:00")
        (cli_env["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["read", "2025-01-15"])
        assert result.exit_code == 0


class TestSearchCommand:
    def test_search_with_results(self, runner, cli_env):
        post = frontmatter.Post(
            "Feeling anxious about the deadline",
            type="text",
            timestamp="2025-01-15T10:30:00",
        )
        (cli_env["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["search", "anxious"])
        assert result.exit_code == 0
        assert "Found 1" in result.output

    def test_search_no_results(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["search", "nonexistent"])
        assert "No entries matching" in result.output

    def test_search_with_theme_filter(self, runner, cli_env):
        post = frontmatter.Post(
            "Career thoughts",
            type="text",
            timestamp="2025-01-15T10:30:00",
            themes_extracted=["career"],
        )
        (cli_env["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["search", "--theme", "career", "Career"])
        assert result.exit_code == 0

    def test_search_with_since_filter(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["search", "--since", "7d", "test"])
        assert result.exit_code == 0


class TestPatternsCommand:
    def test_patterns_no_file(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["patterns"])
        assert result.exit_code == 0
        assert "No patterns" in result.output

    def test_patterns_with_file(self, runner, cli_env):
        (cli_env["index_dir"] / "patterns.md").write_text(
            "# Patterns\n\nRecurring: career"
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["patterns"])
        assert result.exit_code == 0


class TestContradictionsCommand:
    def test_contradictions_empty(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["contradictions"])
        assert result.exit_code == 0
        assert "No contradictions" in result.output


class TestThemesCommand:
    def test_themes_no_file(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["themes"])
        assert result.exit_code == 0
        assert "No themes" in result.output

    def test_themes_with_file(self, runner, cli_env):
        (cli_env["index_dir"] / "themes.md").write_text(
            "# Themes\n\n## Career\n- First mentioned: 2025-01-10"
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2:
            result = runner.invoke(main, ["themes"])
        assert result.exit_code == 0


class TestStatusCommand:
    def test_status_empty(self, runner, cli_env):
        p1, p2 = _patch_dirs(cli_env)
        with p1, p2, patch("aspirational_self.cli.ollama", create=True) as mock_ollama:
            mock_ollama.list.side_effect = Exception("not available")
            result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "Total entries" in result.output

    def test_status_with_entries(self, runner, cli_env):
        post = frontmatter.Post(
            "Test", type="text", timestamp=datetime(2025, 1, 15, 10, 30)
        )
        (cli_env["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        p1, p2 = _patch_dirs(cli_env)
        with p1, p2, patch("aspirational_self.cli.ollama", create=True) as mock_ollama:
            mock_ollama.list.side_effect = Exception("not available")
            result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "1" in result.output
