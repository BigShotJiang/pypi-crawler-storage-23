"""Tests for entry creation, search, listing, and frontmatter parsing."""

from datetime import datetime, timedelta
from pathlib import Path

import frontmatter
import pytest

from aspirational_self.entries import (
    create_entry,
    generate_entry_filename,
    get_recent_context,
    list_entries,
    read_entry,
    search_entries,
)


class TestGenerateEntryFilename:
    def test_default_type(self):
        filename = generate_entry_filename()
        assert filename.endswith("-text.md")

    def test_voice_type(self):
        filename = generate_entry_filename("voice")
        assert filename.endswith("-voice.md")

    def test_contains_timestamp(self):
        filename = generate_entry_filename()
        # Should start with YYYY-MM-DD-HHMM
        parts = filename.split("-")
        assert len(parts[0]) == 4  # year
        assert len(parts[1]) == 2  # month
        assert len(parts[2]) == 2  # day


class TestCreateEntry:
    def test_basic_entry(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Test journal entry",
        )
        assert path.exists()
        assert path.suffix == ".md"

        with open(path) as f:
            post = frontmatter.load(f)
        assert post.content == "Test journal entry"
        assert post.metadata["type"] == "text"
        assert post.metadata["processed"] is False

    def test_entry_with_mood(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Feeling great today",
            mood="happy",
        )
        with open(path) as f:
            post = frontmatter.load(f)
        assert post.metadata["mood"] == "happy"

    def test_entry_with_themes(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Career growth thoughts",
            themes=["career", "growth"],
        )
        with open(path) as f:
            post = frontmatter.load(f)
        assert post.metadata["themes"] == ["career", "growth"]

    def test_entry_with_duration(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Voice entry content",
            entry_type="voice",
            duration="5:30",
        )
        with open(path) as f:
            post = frontmatter.load(f)
        assert post.metadata["duration"] == "5:30"
        assert post.metadata["type"] == "voice"

    def test_entry_has_timestamp(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Timestamped entry",
        )
        with open(path) as f:
            post = frontmatter.load(f)
        assert "timestamp" in post.metadata
        # Should be a valid ISO format timestamp
        datetime.fromisoformat(post.metadata["timestamp"])

    def test_entry_without_optional_fields(self, tmp_entries_dir):
        path = create_entry(
            entries_dir=tmp_entries_dir,
            content="Minimal entry",
        )
        with open(path) as f:
            post = frontmatter.load(f)
        assert "mood" not in post.metadata
        assert "themes" not in post.metadata
        assert "duration" not in post.metadata


class TestListEntries:
    def test_list_empty_dir(self, tmp_entries_dir):
        entries = list_entries(tmp_entries_dir)
        assert entries == []

    def test_list_with_entries(self, tmp_entries_dir, multiple_entries):
        entries = list_entries(tmp_entries_dir)
        assert len(entries) == 4

    def test_list_newest_first(self, tmp_entries_dir, multiple_entries):
        entries = list_entries(tmp_entries_dir)
        names = [e.name for e in entries]
        assert names == sorted(names, reverse=True)

    def test_list_with_limit(self, tmp_entries_dir, multiple_entries):
        entries = list_entries(tmp_entries_dir, limit=2)
        assert len(entries) == 2

    def test_ignores_non_md_files(self, tmp_entries_dir):
        (tmp_entries_dir / "notes.txt").write_text("not an entry")
        (tmp_entries_dir / ".gitkeep").write_text("")
        create_entry(tmp_entries_dir, "Real entry")
        entries = list_entries(tmp_entries_dir)
        assert len(entries) == 1


class TestReadEntry:
    def test_read_basic_entry(self, tmp_entries_dir):
        path = create_entry(tmp_entries_dir, "My test content")
        content = read_entry(path)
        assert "My test content" in content

    def test_read_entry_with_metadata(self, sample_entry_with_metadata):
        content = read_entry(sample_entry_with_metadata)
        assert "Mood:" in content
        assert "anxious" in content
        assert "Themes:" in content
        assert "career" in content

    def test_read_entry_with_key_quotes(self, sample_entry_with_metadata):
        content = read_entry(sample_entry_with_metadata)
        assert "Key Quotes:" in content
        assert "Not sure I can make it" in content

    def test_read_entry_with_challenge_points(self, sample_entry_with_metadata):
        content = read_entry(sample_entry_with_metadata)
        assert "Challenge Points:" in content


class TestSearchEntries:
    def test_search_finds_matching_content(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "exercise")
        assert len(results) == 1
        assert "exercise" in results[0][2].lower()

    def test_search_no_results(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "nonexistent_xyz")
        assert len(results) == 0

    def test_search_case_insensitive(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "EXERCISE")
        assert len(results) == 1

    def test_search_filter_by_theme(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "feeling", theme="health")
        # Only entries with theme "health" should match
        for path, score, snippet in results:
            with open(path) as f:
                post = frontmatter.load(f)
            themes = post.metadata.get("themes_extracted", [])
            assert any("health" in t.lower() for t in themes)

    def test_search_filter_by_mood(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "feeling", mood="anxious")
        assert len(results) >= 1

    def test_search_filter_by_since(self, tmp_entries_dir, multiple_entries):
        since = datetime(2025, 1, 14)
        results = search_entries(
            tmp_entries_dir,
            "feeling",
            since=since,
        )
        # Only entries after Jan 14 should appear
        for path, score, snippet in results:
            assert path.name >= "2025-01-14"

    def test_search_returns_snippets(self, tmp_entries_dir, multiple_entries):
        results = search_entries(tmp_entries_dir, "deadline")
        assert len(results) == 1
        path, score, snippet = results[0]
        assert isinstance(snippet, str)
        assert len(snippet) > 0

    def test_search_empty_query_matches_all(self, tmp_entries_dir, multiple_entries):
        # Empty string is in every content
        results = search_entries(tmp_entries_dir, "")
        assert len(results) == 4


class TestGetRecentContext:
    def test_no_entries(self, tmp_entries_dir):
        context = get_recent_context(tmp_entries_dir)
        assert "No previous entries" in context

    def test_with_entries(self, tmp_entries_dir, multiple_entries):
        context = get_recent_context(tmp_entries_dir, count=2)
        assert "Recent Entries" in context

    def test_respects_count(self, tmp_entries_dir, multiple_entries):
        context = get_recent_context(tmp_entries_dir, count=1)
        # Should only include 1 entry's content
        assert "Recent Entries" in context

    def test_includes_mood_info(self, tmp_entries_dir, multiple_entries):
        context = get_recent_context(tmp_entries_dir, count=5)
        assert "mood:" in context

    def test_truncates_long_content(self, tmp_entries_dir):
        long_content = "x" * 1000
        create_entry(tmp_entries_dir, long_content)
        context = get_recent_context(tmp_entries_dir, count=1)
        assert "..." in context
