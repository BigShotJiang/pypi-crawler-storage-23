"""Tests for Flask web routes using test client."""

import json
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import frontmatter
import pytest


@pytest.fixture
def web_dirs(tmp_path):
    """Create temp directories for the web app."""
    entries_dir = tmp_path / "data" / "entries"
    entries_dir.mkdir(parents=True)
    index_dir = tmp_path / "data" / "index"
    index_dir.mkdir(parents=True)
    self_dir = tmp_path / "self"
    self_dir.mkdir(parents=True)
    (self_dir / "personality.md").write_text("You are a mirror.")
    return {
        "entries_dir": entries_dir,
        "index_dir": index_dir,
        "self_dir": self_dir,
    }


@pytest.fixture
def client(web_dirs):
    """Create a Flask test client with mocked directories."""
    with patch("web.app.ENTRIES_DIR", web_dirs["entries_dir"]), \
         patch("web.app.INDEX_DIR", web_dirs["index_dir"]), \
         patch("web.app.SELF_DIR", web_dirs["self_dir"]), \
         patch("web.app.ollama") as mock_ollama:

        mock_ollama.list.return_value = {"models": [{"name": "llama3.1:8b"}]}
        mock_ollama.chat.return_value = {
            "message": {"content": "What brings you here today?"}
        }

        from web.app import app
        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client, web_dirs


class TestHealthEndpoint:
    def test_health_check(self, client):
        client, dirs = client
        with patch("web.app.ollama") as mock_ollama:
            mock_ollama.list.return_value = {"models": []}
            response = client.get("/api/health")
        assert response.status_code == 200
        data = response.get_json()
        assert data["status"] == "ok"


class TestStatsEndpoint:
    def test_stats_empty(self, client):
        client, dirs = client
        response = client.get("/api/stats")
        assert response.status_code == 200
        data = response.get_json()
        assert data["total_entries"] == 0
        assert data["themes"] == []

    def test_stats_with_entries(self, client):
        client, dirs = client
        post = frontmatter.Post(
            "Test content",
            type="text",
            timestamp="2025-01-15T10:30:00",
            mood_detected=["happy"],
            themes_extracted=["career"],
        )
        (dirs["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        response = client.get("/api/stats")
        assert response.status_code == 200
        data = response.get_json()
        assert data["total_entries"] == 1
        assert len(data["themes"]) == 1
        assert data["themes"][0]["name"] == "career"


class TestEntriesEndpoint:
    def test_list_entries_empty(self, client):
        client, dirs = client
        response = client.get("/api/entries")
        assert response.status_code == 200
        assert response.get_json() == []

    def test_list_entries(self, client):
        client, dirs = client
        post = frontmatter.Post(
            "Entry content",
            type="text",
            timestamp="2025-01-15T10:30:00",
            processed=True,
            mood_detected=["reflective"],
            themes_extracted=["growth"],
        )
        (dirs["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        response = client.get("/api/entries")
        assert response.status_code == 200
        data = response.get_json()
        assert len(data) == 1
        assert data[0]["filename"] == "2025-01-15-1030-text.md"

    def test_list_entries_with_limit(self, client):
        client, dirs = client
        for i in range(5):
            post = frontmatter.Post(
                f"Entry {i}",
                type="text",
                timestamp=f"2025-01-{10+i}T09:00:00",
            )
            (dirs["entries_dir"] / f"2025-01-{10+i}-0900-text.md").write_text(
                frontmatter.dumps(post)
            )

        response = client.get("/api/entries?limit=2")
        assert response.status_code == 200
        assert len(response.get_json()) == 2

    def test_list_entries_filter_by_theme(self, client):
        client, dirs = client
        post1 = frontmatter.Post("Career", themes_extracted=["career"])
        (dirs["entries_dir"] / "entry1.md").write_text(frontmatter.dumps(post1))
        post2 = frontmatter.Post("Health", themes_extracted=["health"])
        (dirs["entries_dir"] / "entry2.md").write_text(frontmatter.dumps(post2))

        response = client.get("/api/entries?theme=career")
        data = response.get_json()
        assert len(data) == 1

    def test_list_entries_filter_by_search(self, client):
        client, dirs = client
        post = frontmatter.Post("Unique searchable content xyz123")
        (dirs["entries_dir"] / "entry.md").write_text(frontmatter.dumps(post))

        response = client.get("/api/entries?search=xyz123")
        data = response.get_json()
        assert len(data) == 1

    def test_get_single_entry(self, client):
        client, dirs = client
        post = frontmatter.Post(
            "Detailed content here",
            type="text",
            timestamp="2025-01-15T10:30:00",
        )
        (dirs["entries_dir"] / "2025-01-15-1030-text.md").write_text(
            frontmatter.dumps(post)
        )

        response = client.get("/api/entries/2025-01-15-1030-text.md")
        assert response.status_code == 200
        data = response.get_json()
        assert data["content"] == "Detailed content here"
        assert "content_html" in data

    def test_get_nonexistent_entry(self, client):
        client, dirs = client
        response = client.get("/api/entries/nonexistent.md")
        assert response.status_code == 404


class TestCreateEntryEndpoint:
    def test_create_entry(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"content": "New journal entry"},
            content_type="application/json",
        )
        assert response.status_code == 200
        data = response.get_json()
        assert "filename" in data
        assert data["message"] == "Entry created successfully"

        # Verify file exists
        entries = list(dirs["entries_dir"].glob("*.md"))
        assert len(entries) == 1

    def test_create_entry_empty_content(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"content": ""},
            content_type="application/json",
        )
        assert response.status_code == 400

    def test_create_entry_with_mood(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"content": "Happy day", "mood": "happy"},
            content_type="application/json",
        )
        assert response.status_code == 200

        entries = list(dirs["entries_dir"].glob("*.md"))
        with open(entries[0]) as f:
            post = frontmatter.load(f)
        assert post.metadata["mood"] == "happy"

    def test_create_entry_with_themes(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"content": "Career note", "themes": ["career"]},
            content_type="application/json",
        )
        assert response.status_code == 200

    def test_create_entry_missing_content_field(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"mood": "happy"},
            content_type="application/json",
        )
        assert response.status_code == 400

    def test_create_entry_whitespace_only_content(self, client):
        client, dirs = client
        response = client.post(
            "/api/entries",
            json={"content": "   \n  \t  "},
            content_type="application/json",
        )
        assert response.status_code == 400


class TestPatternsEndpoint:
    def test_patterns_no_file(self, client):
        client, dirs = client
        response = client.get("/api/patterns")
        assert response.status_code == 200
        data = response.get_json()
        assert "No patterns" in data["content"]

    def test_patterns_with_file(self, client):
        client, dirs = client
        (dirs["index_dir"] / "patterns.md").write_text("# Patterns\n\nRecurring: career")

        response = client.get("/api/patterns")
        assert response.status_code == 200
        data = response.get_json()
        assert "career" in data["content"]


class TestThemesEndpoint:
    def test_themes_no_file(self, client):
        client, dirs = client
        response = client.get("/api/themes")
        assert response.status_code == 200
        data = response.get_json()
        assert "No themes" in data["content"]

    def test_themes_with_file(self, client):
        client, dirs = client
        (dirs["index_dir"] / "themes.md").write_text("# Themes\n\n## Career")

        response = client.get("/api/themes")
        assert response.status_code == 200
        data = response.get_json()
        assert "Career" in data["content"]


class TestReflectEndpoint:
    def test_reflect_no_message(self, client):
        client, dirs = client
        response = client.post(
            "/api/reflect",
            json={"message": ""},
            content_type="application/json",
        )
        assert response.status_code == 400

    def test_reflect_with_message(self, client):
        client, dirs = client
        with patch("web.app.ollama") as mock_ollama:
            mock_ollama.chat.return_value = {
                "message": {"content": "Tell me more about that."}
            }
            response = client.post(
                "/api/reflect",
                json={"message": "I feel stuck"},
                content_type="application/json",
            )
        assert response.status_code == 200
        data = response.get_json()
        assert "reply" in data
        assert "history" in data

    def test_reflect_with_history(self, client):
        client, dirs = client
        history = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there"},
        ]
        with patch("web.app.ollama") as mock_ollama:
            mock_ollama.chat.return_value = {
                "message": {"content": "Interesting."}
            }
            response = client.post(
                "/api/reflect",
                json={"message": "I feel better", "history": history},
                content_type="application/json",
            )
        assert response.status_code == 200

    def test_reflect_ollama_error(self, client):
        client, dirs = client
        with patch("web.app.ollama") as mock_ollama:
            mock_ollama.chat.side_effect = Exception("Model not found")
            response = client.post(
                "/api/reflect",
                json={"message": "Hello"},
                content_type="application/json",
            )
        assert response.status_code == 500
