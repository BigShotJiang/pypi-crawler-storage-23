"""Tests for context building from entries."""

from datetime import datetime
from pathlib import Path

import frontmatter
import pytest

from aspirational_self.context import (
    build_session_context,
    find_contradictions,
    format_context_for_prompt,
    get_theme_history,
)


class TestBuildSessionContext:
    def test_empty_dirs(self, tmp_entries_dir, tmp_index_dir):
        context = build_session_context(tmp_entries_dir, tmp_index_dir)
        assert context["personality"] == ""
        assert context["recent_entries"] == []
        assert context["challenge_points"] == []

    def test_loads_personality(self, tmp_entries_dir, tmp_index_dir, tmp_self_dir):
        context = build_session_context(
            tmp_entries_dir, tmp_index_dir, self_dir=tmp_self_dir
        )
        assert "reflective mirror" in context["personality"]

    def test_loads_life_context(self, tmp_entries_dir, tmp_index_dir, tmp_self_dir):
        context = build_session_context(
            tmp_entries_dir, tmp_index_dir, self_dir=tmp_self_dir
        )
        assert "tech" in context["life_context"]

    def test_skips_template_context(self, tmp_entries_dir, tmp_index_dir, tmp_self_dir):
        """Should skip context.md that's still a template."""
        (tmp_self_dir / "context.md").write_text("(Add your context here)")
        context = build_session_context(
            tmp_entries_dir, tmp_index_dir, self_dir=tmp_self_dir
        )
        assert context["life_context"] == ""

    def test_loads_patterns(self, tmp_entries_dir, tmp_index_dir):
        patterns_file = tmp_index_dir / "patterns.md"
        patterns_file.write_text("# Patterns\n\nRecurring theme: career")

        context = build_session_context(tmp_entries_dir, tmp_index_dir)
        assert "career" in context["patterns"]

    def test_skips_empty_patterns(self, tmp_entries_dir, tmp_index_dir):
        patterns_file = tmp_index_dir / "patterns.md"
        patterns_file.write_text("No patterns detected yet.")

        context = build_session_context(tmp_entries_dir, tmp_index_dir)
        assert context["patterns"] == ""

    def test_loads_recent_entries(self, tmp_entries_dir, tmp_index_dir, multiple_entries):
        context = build_session_context(
            tmp_entries_dir, tmp_index_dir, max_entries=2
        )
        assert len(context["recent_entries"]) == 2

    def test_collects_challenge_points(
        self, tmp_entries_dir, tmp_index_dir, sample_entry_with_metadata
    ):
        context = build_session_context(tmp_entries_dir, tmp_index_dir)
        assert len(context["challenge_points"]) >= 1
        assert "thrive under pressure" in context["challenge_points"][0]["point"]


class TestFormatContextForPrompt:
    def test_empty_context(self):
        context = {
            "personality": "",
            "life_context": "",
            "patterns": "",
            "recent_entries": [],
            "challenge_points": [],
        }
        result = format_context_for_prompt(context)
        assert result == ""

    def test_includes_personality(self):
        context = {
            "personality": "You are a mirror.",
            "life_context": "",
            "patterns": "",
            "recent_entries": [],
            "challenge_points": [],
        }
        result = format_context_for_prompt(context)
        assert "You are a mirror." in result

    def test_includes_recent_entries(self):
        context = {
            "personality": "",
            "life_context": "",
            "patterns": "",
            "recent_entries": [
                {
                    "timestamp": "2025-01-15T10:30:00",
                    "mood": ["anxious"],
                    "content": "Stressed about deadline",
                    "key_quotes": ["Not sure I can make it"],
                }
            ],
            "challenge_points": [],
        }
        result = format_context_for_prompt(context)
        assert "Recent Entries" in result
        assert "Stressed about deadline" in result
        assert "anxious" in result

    def test_includes_challenge_points(self):
        context = {
            "personality": "",
            "life_context": "",
            "patterns": "",
            "recent_entries": [],
            "challenge_points": [
                {"source": "entry.md", "point": "You said you thrive under pressure"}
            ],
        }
        result = format_context_for_prompt(context)
        assert "Challenge Points" in result
        assert "thrive under pressure" in result

    def test_handles_datetime_timestamps(self):
        context = {
            "personality": "",
            "life_context": "",
            "patterns": "",
            "recent_entries": [
                {
                    "timestamp": datetime(2025, 1, 15, 10, 30),
                    "mood": [],
                    "content": "Test",
                    "key_quotes": [],
                }
            ],
            "challenge_points": [],
        }
        result = format_context_for_prompt(context)
        assert "2025-01-15 10:30" in result

    def test_handles_list_mood(self):
        context = {
            "personality": "",
            "life_context": "",
            "patterns": "",
            "recent_entries": [
                {
                    "timestamp": "2025-01-15",
                    "mood": ["happy", "excited"],
                    "content": "Good day",
                    "key_quotes": [],
                }
            ],
            "challenge_points": [],
        }
        result = format_context_for_prompt(context)
        assert "happy, excited" in result


class TestFindContradictions:
    def test_no_themes_returns_empty(self, tmp_entries_dir):
        result = find_contradictions(tmp_entries_dir, "some content", [])
        assert result == []

    def test_no_matching_themes(self, tmp_entries_dir, multiple_entries):
        result = find_contradictions(
            tmp_entries_dir, "content about cooking", ["cooking"]
        )
        assert result == []

    def test_finds_past_quotes_on_matching_theme(
        self, tmp_entries_dir, multiple_entries
    ):
        result = find_contradictions(
            tmp_entries_dir,
            "I hate my career now",
            ["career"],
        )
        # Should find past quotes about career
        assert len(result) >= 1

    def test_limits_results(self, tmp_entries_dir):
        """Should limit to 5 contradictions."""
        for i in range(10):
            post = frontmatter.Post(
                f"Entry {i}",
                timestamp=f"2025-01-{10+i:02d}T09:00:00",
                themes_extracted=["career"],
                key_quotes=[f"Quote {j}" for j in range(3)],
            )
            path = tmp_entries_dir / f"2025-01-{10+i:02d}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        result = find_contradictions(
            tmp_entries_dir, "Career changes", ["career"]
        )
        assert len(result) <= 5


class TestGetThemeHistory:
    def test_no_entries(self, tmp_entries_dir):
        history = get_theme_history(tmp_entries_dir, "career")
        assert history == []

    def test_finds_matching_theme(self, tmp_entries_dir, multiple_entries):
        history = get_theme_history(tmp_entries_dir, "career")
        assert len(history) >= 1
        for entry in history:
            assert "filename" in entry
            assert "date" in entry

    def test_case_insensitive_theme_match(self, tmp_entries_dir, multiple_entries):
        history = get_theme_history(tmp_entries_dir, "CAREER")
        assert len(history) >= 1

    def test_no_matching_theme(self, tmp_entries_dir, multiple_entries):
        history = get_theme_history(tmp_entries_dir, "cooking")
        assert history == []

    def test_sorted_chronologically(self, tmp_entries_dir, multiple_entries):
        history = get_theme_history(tmp_entries_dir, "career")
        if len(history) > 1:
            dates = [h["date"] for h in history]
            assert dates == sorted(dates)

    def test_includes_key_quotes(self, tmp_entries_dir, multiple_entries):
        history = get_theme_history(tmp_entries_dir, "career")
        assert any("key_quotes" in h for h in history)
