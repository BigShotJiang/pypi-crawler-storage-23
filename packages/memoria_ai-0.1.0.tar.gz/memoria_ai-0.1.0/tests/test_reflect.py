"""Tests for reflection flow with mocked Ollama responses."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aspirational_self.reflect import (
    build_system_prompt,
    load_patterns,
    load_personality,
)


class TestLoadPersonality:
    def test_default_personality(self, tmp_path):
        """Should return default if no personality file exists."""
        personality = load_personality(tmp_path)
        assert "Aspirational Self" in personality
        assert "reflective mirror" in personality

    def test_custom_personality(self, tmp_self_dir):
        personality = load_personality(tmp_self_dir)
        assert "reflective mirror" in personality

    def test_none_self_dir_uses_defaults(self):
        """When self_dir is None, should try project-local then home."""
        personality = load_personality(None)
        assert isinstance(personality, str)
        assert len(personality) > 0


class TestLoadPatterns:
    def test_no_patterns_file(self, tmp_index_dir):
        patterns = load_patterns(tmp_index_dir)
        assert patterns == ""

    def test_template_patterns(self, tmp_index_dir):
        """Should return empty for template/placeholder content."""
        (tmp_index_dir / "patterns.md").write_text("No patterns detected yet.")
        patterns = load_patterns(tmp_index_dir)
        assert patterns == ""

    def test_real_patterns(self, tmp_index_dir):
        (tmp_index_dir / "patterns.md").write_text(
            "# Patterns\n\n## Career\nRecurring theme about career"
        )
        patterns = load_patterns(tmp_index_dir)
        assert "Career" in patterns
        assert "Current Patterns" in patterns


class TestBuildSystemPrompt:
    def test_includes_personality(self, tmp_entries_dir, tmp_index_dir):
        prompt = build_system_prompt(tmp_entries_dir, tmp_index_dir)
        assert "Aspirational Self" in prompt

    def test_includes_recent_context(self, tmp_entries_dir, tmp_index_dir, multiple_entries):
        prompt = build_system_prompt(tmp_entries_dir, tmp_index_dir)
        assert "Recent Entries" in prompt

    def test_includes_patterns_when_available(self, tmp_entries_dir, tmp_index_dir):
        (tmp_index_dir / "patterns.md").write_text(
            "# Patterns\n\n## Career theme detected"
        )
        prompt = build_system_prompt(tmp_entries_dir, tmp_index_dir)
        assert "Career" in prompt


class TestStartReflection:
    def test_missing_ollama_package(self, tmp_entries_dir, tmp_index_dir):
        """Should gracefully handle missing ollama import."""
        from io import StringIO
        from rich.console import Console

        console = Console(file=StringIO())

        with patch.dict("sys.modules", {"ollama": None}):
            # This should handle the ImportError gracefully
            from aspirational_self.reflect import start_reflection
            # Can't easily test this without modifying the import structure,
            # but the function handles ImportError internally

    def test_ollama_connection_failure(
        self, tmp_entries_dir, tmp_index_dir
    ):
        """Should handle Ollama connection failure."""
        from io import StringIO
        from rich.console import Console

        console = Console(file=StringIO())

        with patch("ollama.list", side_effect=ConnectionError("Connection refused")):
            from aspirational_self.reflect import start_reflection
            start_reflection(tmp_entries_dir, tmp_index_dir, console)
            output = console.file.getvalue()
            assert "Cannot connect" in output

    def test_model_not_found_triggers_pull(
        self, tmp_entries_dir, tmp_index_dir
    ):
        """Should attempt to pull model if not available."""
        from io import StringIO
        from rich.console import Console

        console = Console(file=StringIO())

        with patch("ollama.list") as mock_list, \
             patch("ollama.pull") as mock_pull, \
             patch("ollama.chat") as mock_chat, \
             patch("rich.prompt.Prompt.ask", side_effect=KeyboardInterrupt):

            mock_list.return_value = {"models": [{"name": "other-model:7b"}]}
            mock_pull.return_value = None

            from aspirational_self.reflect import start_reflection
            start_reflection(tmp_entries_dir, tmp_index_dir, console)

            mock_pull.assert_called_once()
