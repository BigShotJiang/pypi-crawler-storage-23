"""Tests for file watcher event handling with mocked filesystem events."""

import json
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import frontmatter
import pytest


class TestExtractMetadata:
    def test_extracts_metadata(self, mock_ollama):
        from watcher.watcher import extract_metadata

        result = extract_metadata("Had a great day at work today.")
        assert "mood_detected" in result
        assert "themes_extracted" in result
        assert "key_quotes" in result
        assert isinstance(result["mood_detected"], list)

    def test_handles_ollama_error(self):
        with patch("ollama.chat", side_effect=Exception("Connection refused")):
            from watcher.watcher import extract_metadata
            result = extract_metadata("Some content")
            assert result == {}

    def test_handles_invalid_json_response(self):
        with patch("ollama.chat") as mock_chat:
            mock_chat.return_value = {
                "message": {"content": "not valid json"}
            }
            from watcher.watcher import extract_metadata
            result = extract_metadata("Some content")
            assert result == {}


class TestFindRelatedEntries:
    def test_no_themes_returns_empty(self, tmp_entries_dir):
        from watcher.watcher import find_related_entries

        entry = tmp_entries_dir / "current.md"
        entry.write_text("---\n---\nContent")
        result = find_related_entries(tmp_entries_dir, entry, [])
        assert result == []

    def test_finds_related_by_theme(self, tmp_entries_dir, multiple_entries):
        from watcher.watcher import find_related_entries

        # Create a new entry about career
        new_entry = tmp_entries_dir / "new-entry.md"
        post = frontmatter.Post("New career thoughts", themes_extracted=["career"])
        new_entry.write_text(frontmatter.dumps(post))

        result = find_related_entries(tmp_entries_dir, new_entry, ["career"])
        assert len(result) >= 1
        # Should not include the current entry
        assert "new-entry.md" not in result

    def test_limits_to_five_results(self, tmp_entries_dir):
        from watcher.watcher import find_related_entries

        for i in range(10):
            post = frontmatter.Post(f"Entry {i}", themes_extracted=["career"])
            (tmp_entries_dir / f"entry-{i:03d}.md").write_text(frontmatter.dumps(post))

        current = tmp_entries_dir / "current.md"
        post = frontmatter.Post("Current", themes_extracted=["career"])
        current.write_text(frontmatter.dumps(post))

        result = find_related_entries(tmp_entries_dir, current, ["career"])
        assert len(result) <= 5

    def test_case_insensitive_theme_matching(self, tmp_entries_dir):
        from watcher.watcher import find_related_entries

        post = frontmatter.Post("Past entry", themes_extracted=["Career"])
        (tmp_entries_dir / "past.md").write_text(frontmatter.dumps(post))

        current = tmp_entries_dir / "current.md"
        current.write_text("---\n---\nContent")

        result = find_related_entries(tmp_entries_dir, current, ["career"])
        assert len(result) == 1


class TestFindContradictions:
    def test_no_themes_returns_empty(self, tmp_entries_dir, mock_ollama):
        from watcher.watcher import find_contradictions
        result = find_contradictions(tmp_entries_dir, "content", [])
        assert result == []

    def test_no_past_quotes_returns_empty(self, tmp_entries_dir, mock_ollama):
        from watcher.watcher import find_contradictions
        result = find_contradictions(tmp_entries_dir, "content", ["cooking"])
        assert result == []

    def test_finds_contradictions(self, tmp_entries_dir, multiple_entries):
        mock_response = {
            "message": {
                "content": json.dumps({
                    "challenge_points": ["You previously said X but now say Y"]
                })
            }
        }
        with patch("ollama.chat", return_value=mock_response):
            from watcher.watcher import find_contradictions
            result = find_contradictions(
                tmp_entries_dir, "I hate my career", ["career"]
            )
            assert len(result) >= 1


class TestProcessEntry:
    def test_processes_unprocessed_entry(self, tmp_entries_dir, mock_ollama):
        post = frontmatter.Post(
            "Today I reflected on my career path",
            type="text",
            timestamp="2025-01-15T10:30:00",
            processed=False,
        )
        entry_path = tmp_entries_dir / "2025-01-15-1030-text.md"
        entry_path.write_text(frontmatter.dumps(post))

        with patch("watcher.watcher.ENTRIES_DIR", tmp_entries_dir), \
             patch("watcher.watcher.INDEX_DIR", tmp_entries_dir.parent / "index"), \
             patch("watcher.watcher.update_indexes"):
            from watcher.watcher import process_entry
            process_entry(entry_path)

        # Verify entry was updated
        with open(entry_path) as f:
            updated = frontmatter.load(f)
        assert updated.metadata["processed"] is True
        assert "mood_detected" in updated.metadata

    def test_skips_already_processed(self, tmp_entries_dir):
        post = frontmatter.Post(
            "Already processed",
            type="text",
            timestamp="2025-01-15T10:30:00",
            processed=True,
        )
        entry_path = tmp_entries_dir / "2025-01-15-1030-text.md"
        entry_path.write_text(frontmatter.dumps(post))

        with patch("ollama.chat") as mock_chat:
            with patch("watcher.watcher.ENTRIES_DIR", tmp_entries_dir):
                from watcher.watcher import process_entry
                process_entry(entry_path)
            # Ollama should not have been called
            mock_chat.assert_not_called()

    def test_handles_processing_error(self, tmp_entries_dir):
        """Should not crash on processing errors."""
        post = frontmatter.Post("Content", processed=False)
        entry_path = tmp_entries_dir / "entry.md"
        entry_path.write_text(frontmatter.dumps(post))

        with patch("ollama.chat", side_effect=Exception("Network error")), \
             patch("watcher.watcher.ENTRIES_DIR", tmp_entries_dir):
            from watcher.watcher import process_entry
            # Should not raise
            process_entry(entry_path)


class TestEntryHandler:
    def test_ignores_directories(self):
        from watcher.watcher import EntryHandler

        handler = EntryHandler()
        event = MagicMock()
        event.is_directory = True

        with patch("watcher.watcher.process_entry") as mock_process:
            handler.on_created(event)
            mock_process.assert_not_called()

    def test_ignores_non_md_files(self):
        from watcher.watcher import EntryHandler

        handler = EntryHandler()
        event = MagicMock()
        event.is_directory = False
        event.src_path = "/tmp/entries/notes.txt"

        with patch("watcher.watcher.process_entry") as mock_process:
            handler.on_created(event)
            mock_process.assert_not_called()

    def test_processes_new_md_files(self, tmp_entries_dir):
        from watcher.watcher import EntryHandler

        post = frontmatter.Post("New entry", processed=False)
        entry_path = tmp_entries_dir / "new-entry.md"
        entry_path.write_text(frontmatter.dumps(post))

        handler = EntryHandler()
        event = MagicMock()
        event.is_directory = False
        event.src_path = str(entry_path)

        with patch("watcher.watcher.process_entry") as mock_process, \
             patch("time.sleep"):
            handler.on_created(event)
            mock_process.assert_called_once_with(entry_path)

    def test_debounces_duplicate_events(self, tmp_entries_dir):
        from watcher.watcher import EntryHandler

        post = frontmatter.Post("Entry", processed=False)
        entry_path = tmp_entries_dir / "entry.md"
        entry_path.write_text(frontmatter.dumps(post))

        handler = EntryHandler()
        # Simulate file already being processed
        handler.processing.add("entry.md")

        event = MagicMock()
        event.is_directory = False
        event.src_path = str(entry_path)

        with patch("watcher.watcher.process_entry") as mock_process:
            handler.on_created(event)
            mock_process.assert_not_called()

    def test_on_modified_skips_processed(self, tmp_entries_dir):
        from watcher.watcher import EntryHandler

        post = frontmatter.Post("Already done", processed=True)
        entry_path = tmp_entries_dir / "entry.md"
        entry_path.write_text(frontmatter.dumps(post))

        handler = EntryHandler()
        event = MagicMock()
        event.is_directory = False
        event.src_path = str(entry_path)

        with patch("watcher.watcher.process_entry") as mock_process:
            handler.on_modified(event)
            mock_process.assert_not_called()


class TestUpdateIndexes:
    def test_creates_themes_index(self, tmp_path):
        index_dir = tmp_path / "index"
        index_dir.mkdir()

        post = frontmatter.Post(
            "Content",
            timestamp="2025-01-15T10:30:00",
        )
        entry_path = tmp_path / "entry.md"

        metadata = {
            "themes_extracted": ["career", "growth"],
            "mood_detected": ["hopeful"],
            "summary": "Career reflections",
        }

        with patch("watcher.watcher.INDEX_DIR", index_dir):
            from watcher.watcher import update_indexes
            update_indexes(entry_path, post, metadata)

        themes_file = index_dir / "themes.md"
        assert themes_file.exists()
        content = themes_file.read_text()
        assert "career" in content

    def test_creates_timeline(self, tmp_path):
        index_dir = tmp_path / "index"
        index_dir.mkdir()

        post = frontmatter.Post(
            "Content",
            timestamp="2025-01-15T10:30:00",
        )
        entry_path = tmp_path / "entry.md"

        metadata = {
            "themes_extracted": [],
            "mood_detected": ["hopeful"],
            "summary": "Good day",
        }

        with patch("watcher.watcher.INDEX_DIR", index_dir):
            from watcher.watcher import update_indexes
            update_indexes(entry_path, post, metadata)

        timeline_file = index_dir / "timeline.md"
        assert timeline_file.exists()
        content = timeline_file.read_text()
        assert "Good day" in content


class TestWaitForOllama:
    def test_succeeds_on_first_try(self):
        with patch("ollama.list", return_value={"models": []}):
            from watcher.watcher import wait_for_ollama
            assert wait_for_ollama() is True

    def test_fails_after_retries(self):
        with patch("ollama.list", side_effect=Exception("Connection refused")), \
             patch("time.sleep"), \
             patch("watcher.watcher.max_retries", 2, create=True):
            from watcher.watcher import wait_for_ollama
            # Will fail after max_retries (30 by default, but we mock sleep)
            # We need to limit retries for testing
            result = wait_for_ollama()
            assert result is False


class TestEnsureModel:
    def test_model_already_available(self, mock_ollama):
        from watcher.watcher import ensure_model
        ensure_model()
        mock_ollama["pull"].assert_not_called()

    def test_pulls_missing_model(self):
        with patch("ollama.list") as mock_list, \
             patch("ollama.pull") as mock_pull:
            mock_list.return_value = {"models": [{"name": "other:7b"}]}
            from watcher.watcher import ensure_model
            ensure_model()
            mock_pull.assert_called_once()
