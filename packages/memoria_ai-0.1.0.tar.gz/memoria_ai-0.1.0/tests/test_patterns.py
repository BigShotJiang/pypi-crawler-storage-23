"""Tests for pattern detection, mood analysis, and theme extraction."""

from datetime import datetime
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock

import frontmatter
import pytest
from rich.console import Console

from aspirational_self.patterns import (
    detect_patterns_in_entries,
    show_contradictions,
    show_patterns,
)


class TestDetectPatterns:
    def test_empty_dir(self, tmp_entries_dir):
        patterns = detect_patterns_in_entries(tmp_entries_dir)
        assert patterns == []

    def test_few_entries_no_patterns(self, tmp_entries_dir):
        """With only a few entries, no recurring patterns should be detected."""
        for i in range(2):
            post = frontmatter.Post(
                f"Entry {i}",
                timestamp=f"2025-01-{10+i}T09:00:00",
                mood_detected=["happy"],
                themes_extracted=["work"],
            )
            path = tmp_entries_dir / f"2025-01-{10+i}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        patterns = detect_patterns_in_entries(tmp_entries_dir)
        # Not enough entries for recurring theme (need 5+)
        assert len([p for p in patterns if p["type"] == "recurring_theme"]) == 0

    def test_recurring_theme_detected(self, tmp_entries_dir):
        """Theme appearing 5+ times should be detected."""
        for i in range(6):
            post = frontmatter.Post(
                f"Entry about work {i}",
                timestamp=f"2025-01-{10+i}T09:00:00",
                themes_extracted=["career"],
            )
            path = tmp_entries_dir / f"2025-01-{10+i}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        patterns = detect_patterns_in_entries(tmp_entries_dir)
        theme_patterns = [p for p in patterns if p["type"] == "recurring_theme"]
        assert len(theme_patterns) == 1
        assert theme_patterns[0]["name"] == "career"
        assert theme_patterns[0]["occurrences"] >= 5

    def test_weekday_mood_pattern(self, tmp_entries_dir):
        """Consistent mood on same weekday should be detected (need 3+)."""
        # Create entries all on Mondays with same mood
        # 2025-01-06 is Monday, 2025-01-13 is Monday, 2025-01-20 is Monday
        mondays = ["2025-01-06", "2025-01-13", "2025-01-20"]
        for date in mondays:
            post = frontmatter.Post(
                "Monday blues again",
                timestamp=f"{date}T09:00:00",
                mood_detected=["stressed"],
            )
            path = tmp_entries_dir / f"{date}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        patterns = detect_patterns_in_entries(tmp_entries_dir)
        weekday_patterns = [p for p in patterns if p["type"] == "weekday_mood"]
        assert len(weekday_patterns) >= 1
        assert "Monday" in weekday_patterns[0]["name"]

    def test_handles_string_themes(self, tmp_entries_dir):
        """Should handle themes as a single string (not list)."""
        for i in range(6):
            post = frontmatter.Post(
                f"Entry {i}",
                timestamp=f"2025-01-{10+i}T09:00:00",
                themes_extracted="health",  # string, not list
            )
            path = tmp_entries_dir / f"2025-01-{10+i}-0900-text.md"
            path.write_text(frontmatter.dumps(post))

        patterns = detect_patterns_in_entries(tmp_entries_dir)
        theme_patterns = [p for p in patterns if p["type"] == "recurring_theme"]
        assert len(theme_patterns) == 1

    def test_handles_missing_timestamp(self, tmp_entries_dir):
        """Should not crash on entries without timestamps."""
        post = frontmatter.Post("No timestamp entry")
        path = tmp_entries_dir / "2025-01-10-0900-text.md"
        path.write_text(frontmatter.dumps(post))

        # Should not raise
        patterns = detect_patterns_in_entries(tmp_entries_dir)
        assert isinstance(patterns, list)

    def test_handles_malformed_entries(self, tmp_entries_dir):
        """Should skip malformed entry files gracefully."""
        # Write invalid frontmatter
        path = tmp_entries_dir / "bad-entry.md"
        path.write_text("not valid frontmatter content")

        patterns = detect_patterns_in_entries(tmp_entries_dir)
        assert isinstance(patterns, list)


class TestShowPatterns:
    def test_no_patterns_message(self, tmp_index_dir):
        patterns_file = tmp_index_dir / "patterns.md"
        patterns_file.write_text("No patterns detected yet.")

        console = Console(file=StringIO())
        show_patterns(patterns_file, console)
        output = console.file.getvalue()
        assert "No patterns" in output

    def test_with_patterns(self, tmp_index_dir):
        patterns_file = tmp_index_dir / "patterns.md"
        patterns_file.write_text("# Patterns\n\n## Recurring: career\nAppears 5 times")

        console = Console(file=StringIO())
        show_patterns(patterns_file, console)
        output = console.file.getvalue()
        assert "career" in output


class TestShowContradictions:
    def test_no_contradictions(self, tmp_entries_dir):
        console = Console(file=StringIO())
        show_contradictions(tmp_entries_dir, console)
        output = console.file.getvalue()
        assert "No contradictions" in output

    def test_with_challenge_points(self, tmp_entries_dir, sample_entry_with_metadata):
        console = Console(file=StringIO())
        show_contradictions(tmp_entries_dir, console)
        output = console.file.getvalue()
        assert "thrive under pressure" in output

    def test_limits_display_to_10(self, tmp_entries_dir):
        """Should only show last 10 contradictions."""
        for i in range(15):
            post = frontmatter.Post(
                f"Entry {i}",
                timestamp=f"2025-01-{10+i:02d}T09:00:00" if i < 22 else f"2025-02-{i-21:02d}T09:00:00",
                challenge_points=[f"Contradiction point {i}"],
            )
            path = tmp_entries_dir / f"entry-{i:03d}.md"
            path.write_text(frontmatter.dumps(post))

        console = Console(file=StringIO())
        show_contradictions(tmp_entries_dir, console)
        output = console.file.getvalue()
        # Should show at most 10 contradiction points
        shown_count = output.count("Contradiction point")
        assert shown_count <= 10
        assert shown_count > 0
