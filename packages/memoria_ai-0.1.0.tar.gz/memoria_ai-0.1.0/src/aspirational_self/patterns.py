"""Pattern and contradiction detection for Aspirational Self."""

from datetime import datetime
from pathlib import Path
from typing import Optional

import frontmatter
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table


# Simple entry cache: maps file path -> (mtime, parsed post)
_entry_cache: dict[Path, tuple[float, frontmatter.Post]] = {}


def _load_entry_cached(entry_path: Path) -> Optional[frontmatter.Post]:
    """Load and cache a parsed entry, reusing cache if file hasn't changed."""
    try:
        mtime = entry_path.stat().st_mtime
        cached = _entry_cache.get(entry_path)
        if cached and cached[0] == mtime:
            return cached[1]

        with open(entry_path) as f:
            post = frontmatter.load(f)

        _entry_cache[entry_path] = (mtime, post)
        return post
    except (OSError, ValueError):
        return None


def show_patterns(patterns_file: Path, console: Console):
    """Display detected patterns.

    Args:
        patterns_file: Path to patterns.md
        console: Rich console for output
    """
    content = patterns_file.read_text()

    if "No patterns detected yet" in content:
        console.print("[yellow]No patterns detected yet. Keep adding entries![/yellow]")
        return

    console.print(Markdown(content))


def show_contradictions(entries_dir: Path, console: Console):
    """Find and display contradictions between entries.

    Args:
        entries_dir: Directory containing entries
        console: Rich console for output
    """
    # Collect entries with challenge points
    contradictions = []

    entries = list(entries_dir.glob("*.md"))

    for entry_path in entries:
        post = _load_entry_cached(entry_path)
        if post is None:
            continue

        challenge_points = post.metadata.get("challenge_points", [])
        if challenge_points:
            timestamp = post.metadata.get("timestamp", entry_path.stem)
            if isinstance(timestamp, datetime):
                timestamp = timestamp.strftime("%Y-%m-%d")

            for point in challenge_points:
                contradictions.append({
                    "date": timestamp,
                    "file": entry_path.name,
                    "point": point,
                })

    if not contradictions:
        console.print("[yellow]No contradictions detected yet.[/yellow]")
        console.print("[dim]As you add more entries, the AI will identify when your current thoughts contradict past statements.[/dim]")
        return

    console.print(Panel(
        "[bold]These are moments where your past and present thinking diverge.[/bold]\n"
        "Not necessarily wrong - but worth examining.",
        title="Contradictions",
        border_style="yellow"
    ))

    for item in contradictions[-10:]:  # Show last 10
        console.print(f"\n[cyan]{item['date']}[/cyan] - [dim]{item['file']}[/dim]")
        console.print(f"  {item['point']}")


def detect_patterns_in_entries(entries_dir: Path) -> list[dict]:
    """Analyze entries to detect patterns.

    This is called by the watcher service, not directly by CLI.

    Args:
        entries_dir: Directory containing entries

    Returns:
        List of detected pattern dictionaries
    """
    patterns = []

    entries = list(entries_dir.glob("*.md"))
    entries.sort(key=lambda p: p.name)

    # Collect themes and moods by day/time
    by_weekday = {i: {"moods": [], "themes": []} for i in range(7)}
    theme_frequency = {}
    mood_frequency = {}

    for entry_path in entries:
        post = _load_entry_cached(entry_path)
        if post is None:
            continue

        timestamp = post.metadata.get("timestamp")
        if isinstance(timestamp, str):
            try:
                timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
            except ValueError:
                continue

        if timestamp:
            weekday = timestamp.weekday()

            # Track moods by day
            mood = post.metadata.get("mood_detected", post.metadata.get("mood", ""))
            if mood:
                if isinstance(mood, list):
                    by_weekday[weekday]["moods"].extend(mood)
                    for m in mood:
                        mood_frequency[m] = mood_frequency.get(m, 0) + 1
                else:
                    by_weekday[weekday]["moods"].append(mood)
                    mood_frequency[mood] = mood_frequency.get(mood, 0) + 1

            # Track themes
            themes = post.metadata.get("themes_extracted", post.metadata.get("themes", []))
            if themes:
                if isinstance(themes, str):
                    themes = [themes]
                by_weekday[weekday]["themes"].extend(themes)
                for t in themes:
                    theme_frequency[t] = theme_frequency.get(t, 0) + 1

    # Detect weekday patterns
    weekday_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for day_num, data in by_weekday.items():
        if len(data["moods"]) >= 3:
            # Check for consistent mood on this day
            mood_counts = {}
            for m in data["moods"]:
                mood_counts[m] = mood_counts.get(m, 0) + 1

            for mood, count in mood_counts.items():
                if count >= 3:
                    patterns.append({
                        "type": "weekday_mood",
                        "name": f"{weekday_names[day_num]} {mood}",
                        "description": f"You tend to feel {mood} on {weekday_names[day_num]}s",
                        "occurrences": count,
                    })

    # Detect recurring themes
    for theme, count in theme_frequency.items():
        if count >= 5:
            patterns.append({
                "type": "recurring_theme",
                "name": theme,
                "description": f"'{theme}' appears frequently in your entries",
                "occurrences": count,
            })

    return patterns
