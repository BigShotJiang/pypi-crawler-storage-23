"""Aspirational Self - A private AI mirror for personal reflection."""

__version__ = "0.1.0"
