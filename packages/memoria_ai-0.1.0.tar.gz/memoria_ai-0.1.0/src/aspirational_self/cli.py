"""CLI for Aspirational Self - personal reflection journal."""

import os
import subprocess
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import click
import frontmatter
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

from .entries import create_entry, list_entries, read_entry, search_entries
from .reflect import start_reflection
from .patterns import show_patterns, show_contradictions

console = Console()

# Default paths
DEFAULT_DATA_DIR = Path.home() / "aspirational-self" / "data"
DEFAULT_ENTRIES_DIR = DEFAULT_DATA_DIR / "entries"
DEFAULT_INDEX_DIR = DEFAULT_DATA_DIR / "index"
DEFAULT_SELF_DIR = Path.home() / "aspirational-self" / "self"


def get_data_dir() -> Path:
    """Get the data directory, checking for project-local first."""
    # Check if we're in the project directory
    local_data = Path.cwd() / "data"
    if local_data.exists():
        return local_data

    # Fall back to home directory
    DEFAULT_DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DEFAULT_DATA_DIR


def get_entries_dir() -> Path:
    """Get the entries directory."""
    entries_dir = get_data_dir() / "entries"
    entries_dir.mkdir(parents=True, exist_ok=True)
    return entries_dir


def get_index_dir() -> Path:
    """Get the index directory."""
    index_dir = get_data_dir() / "index"
    index_dir.mkdir(parents=True, exist_ok=True)
    return index_dir


@click.group()
@click.version_option()
def main():
    """Aspirational Self - Your private AI reflection mirror."""
    pass


@main.command()
@click.argument("content", required=False)
@click.option("--mood", "-m", help="Tag with a mood (e.g., hopeful, anxious, reflective)")
@click.option("--theme", "-t", multiple=True, help="Tag with themes (can use multiple)")
@click.option("--type", "entry_type", default="text", help="Entry type: text, voice")
@click.option("--edit", "-e", is_flag=True, help="Open in $EDITOR for longer entries")
def add(content: Optional[str], mood: Optional[str], theme: tuple, entry_type: str, edit: bool):
    """Add a new journal entry.

    Examples:
        aspire add "Had a breakthrough today..."
        aspire add --mood hopeful "Feeling good about the direction"
        aspire add --theme career --theme growth "Got the promotion"
        aspire add -e  # Opens your editor
    """
    entries_dir = get_entries_dir()

    if edit or content is None:
        # Open editor for content
        editor = os.environ.get("EDITOR", "nano")
        with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False) as f:
            f.write("# Entry\n\nWrite your thoughts here...\n")
            temp_path = f.name

        subprocess.call([editor, temp_path])

        with open(temp_path, "r") as f:
            content = f.read()

        os.unlink(temp_path)

        if content.strip() == "# Entry\n\nWrite your thoughts here...":
            console.print("[yellow]Entry cancelled (no changes made)[/yellow]")
            return

    # Create the entry
    entry_path = create_entry(
        entries_dir=entries_dir,
        content=content,
        entry_type=entry_type,
        mood=mood,
        themes=list(theme) if theme else None,
    )

    console.print(f"[green]Entry saved:[/green] {entry_path.name}")

    # Show a preview
    with open(entry_path) as f:
        post = frontmatter.load(f)

    preview = post.content[:200] + "..." if len(post.content) > 200 else post.content
    console.print(Panel(preview, title="Preview", border_style="dim"))


@main.command()
@click.option("-n", "--count", default=10, help="Number of entries to show")
def recent(count: int):
    """Show recent journal entries."""
    entries_dir = get_entries_dir()
    entries = list_entries(entries_dir, limit=count)

    if not entries:
        console.print("[yellow]No entries yet. Use 'aspire add' to create your first entry.[/yellow]")
        return

    table = Table(title=f"Recent Entries (last {count})")
    table.add_column("Date", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Mood", style="yellow")
    table.add_column("Preview", style="white")
    table.add_column("File", style="dim")

    for entry in entries:
        with open(entry) as f:
            post = frontmatter.load(f)

        timestamp = post.metadata.get("timestamp", "")
        if isinstance(timestamp, datetime):
            date_str = timestamp.strftime("%Y-%m-%d %H:%M")
        else:
            date_str = str(timestamp)[:16] if timestamp else entry.stem[:10]

        entry_type = post.metadata.get("type", "text")
        mood = post.metadata.get("mood_detected", post.metadata.get("mood", ""))
        if isinstance(mood, list):
            mood = ", ".join(mood[:2])

        preview = post.content[:50].replace("\n", " ")
        if len(post.content) > 50:
            preview += "..."

        table.add_row(date_str, entry_type, str(mood), preview, entry.name)

    console.print(table)


@main.command()
@click.argument("filename")
def read(filename: str):
    """Read a specific entry."""
    entries_dir = get_entries_dir()

    # Handle relative or absolute paths
    if "/" in filename or filename.endswith(".md"):
        entry_path = entries_dir / filename
    else:
        # Try to find a matching file
        matches = list(entries_dir.glob(f"*{filename}*"))
        if not matches:
            console.print(f"[red]Entry not found: {filename}[/red]")
            return
        entry_path = matches[0]

    if not entry_path.exists():
        console.print(f"[red]Entry not found: {filename}[/red]")
        return

    content = read_entry(entry_path)
    console.print(Markdown(content))


@main.command()
@click.argument("query")
@click.option("--theme", "-t", help="Filter by theme")
@click.option("--mood", "-m", help="Filter by mood")
@click.option("--since", "-s", help="Filter by time (e.g., 7d, 2w, 1m)")
@click.option("--semantic/--no-semantic", default=True, help="Use semantic search")
def search(query: str, theme: Optional[str], mood: Optional[str], since: Optional[str], semantic: bool):
    """Search your journal entries.

    Examples:
        aspire search "times I felt stuck"
        aspire search --theme career "promotion"
        aspire search --since 7d "anxiety"
    """
    entries_dir = get_entries_dir()

    # Parse time filter
    since_date = None
    if since:
        unit = since[-1]
        amount = int(since[:-1])
        if unit == "d":
            since_date = datetime.now() - timedelta(days=amount)
        elif unit == "w":
            since_date = datetime.now() - timedelta(weeks=amount)
        elif unit == "m":
            since_date = datetime.now() - timedelta(days=amount * 30)

    results = search_entries(
        entries_dir=entries_dir,
        query=query,
        theme=theme,
        mood=mood,
        since=since_date,
        semantic=semantic,
    )

    if not results:
        console.print(f"[yellow]No entries matching '{query}'[/yellow]")
        return

    console.print(f"[green]Found {len(results)} matching entries:[/green]\n")

    for entry_path, score, snippet in results:
        with open(entry_path) as f:
            post = frontmatter.load(f)

        timestamp = post.metadata.get("timestamp", "")
        if isinstance(timestamp, datetime):
            date_str = timestamp.strftime("%Y-%m-%d")
        else:
            date_str = str(timestamp)[:10] if timestamp else ""

        console.print(f"[cyan]{date_str}[/cyan] - [dim]{entry_path.name}[/dim]")
        console.print(Panel(snippet, border_style="dim"))
        console.print()


@main.command()
def reflect():
    """Start an interactive reflection session.

    The AI will read your recent entries and engage in a Socratic dialogue.
    """
    entries_dir = get_entries_dir()
    index_dir = get_index_dir()

    console.print(Panel(
        "[bold]Starting reflection session...[/bold]\n\n"
        "The Aspirational Self will engage with you based on your recent entries.\n"
        "Type 'quit' or 'exit' to end the session.",
        title="Reflect",
        border_style="blue"
    ))

    start_reflection(entries_dir, index_dir, console)


@main.command()
def patterns():
    """Show detected patterns in your entries."""
    index_dir = get_index_dir()
    patterns_file = index_dir / "patterns.md"

    if not patterns_file.exists():
        console.print("[yellow]No patterns detected yet. Keep adding entries![/yellow]")
        return

    show_patterns(patterns_file, console)


@main.command()
def contradictions():
    """Show contradictions between past and recent entries."""
    entries_dir = get_entries_dir()

    show_contradictions(entries_dir, console)


@main.command()
def themes():
    """Show extracted themes from your entries."""
    index_dir = get_index_dir()
    themes_file = index_dir / "themes.md"

    if not themes_file.exists():
        console.print("[yellow]No themes extracted yet. Keep adding entries![/yellow]")
        return

    with open(themes_file) as f:
        content = f.read()

    console.print(Markdown(content))


@main.command()
def status():
    """Show system status and statistics."""
    entries_dir = get_entries_dir()

    entries = list(entries_dir.glob("*.md"))

    table = Table(title="Aspirational Self Status")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Total entries", str(len(entries)))
    table.add_row("Entries directory", str(entries_dir))

    if entries:
        # Get date range
        dates = []
        for entry in entries:
            try:
                with open(entry) as f:
                    post = frontmatter.load(f)
                ts = post.metadata.get("timestamp")
                if isinstance(ts, datetime):
                    dates.append(ts)
            except (OSError, ValueError, KeyError):
                pass

        if dates:
            table.add_row("First entry", min(dates).strftime("%Y-%m-%d"))
            table.add_row("Latest entry", max(dates).strftime("%Y-%m-%d"))

    # Check Ollama
    try:
        import ollama
        ollama.list()
        table.add_row("Ollama", "[green]Connected[/green]")
    except (ImportError, Exception):
        table.add_row("Ollama", "[red]Not available[/red]")

    console.print(table)


if __name__ == "__main__":
    main()
