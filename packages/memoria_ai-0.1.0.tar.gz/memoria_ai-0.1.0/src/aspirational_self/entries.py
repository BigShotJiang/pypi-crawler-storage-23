"""Entry management for Aspirational Self."""

from datetime import datetime
from pathlib import Path
from typing import Optional

import frontmatter


def generate_entry_filename(entry_type: str = "text") -> str:
    """Generate a filename for a new entry."""
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d-%H%M")
    return f"{timestamp}-{entry_type}.md"


def create_entry(
    entries_dir: Path,
    content: str,
    entry_type: str = "text",
    mood: Optional[str] = None,
    themes: Optional[list] = None,
    duration: Optional[str] = None,
) -> Path:
    """Create a new journal entry.

    Args:
        entries_dir: Directory to save entries
        content: The entry content
        entry_type: Type of entry (text, voice)
        mood: Optional mood tag
        themes: Optional list of themes
        duration: Optional duration for voice entries

    Returns:
        Path to the created entry file
    """
    filename = generate_entry_filename(entry_type)
    entry_path = entries_dir / filename

    # Build metadata
    metadata = {
        "type": entry_type,
        "timestamp": datetime.now().isoformat(),
        "processed": False,  # Will be set to True by watcher
    }

    if mood:
        metadata["mood"] = mood

    if themes:
        metadata["themes"] = themes

    if duration:
        metadata["duration"] = duration

    # Create the entry
    post = frontmatter.Post(content, **metadata)

    with open(entry_path, "w") as f:
        f.write(frontmatter.dumps(post))

    return entry_path


def list_entries(entries_dir: Path, limit: int = 10) -> list[Path]:
    """List recent entries, newest first.

    Args:
        entries_dir: Directory containing entries
        limit: Maximum number of entries to return

    Returns:
        List of entry paths, newest first
    """
    entries = list(entries_dir.glob("*.md"))

    # Sort by filename (which starts with timestamp) descending
    entries.sort(key=lambda p: p.name, reverse=True)

    return entries[:limit]


def read_entry(entry_path: Path) -> str:
    """Read an entry and return formatted content.

    Args:
        entry_path: Path to the entry file

    Returns:
        Formatted markdown content with metadata
    """
    with open(entry_path) as f:
        post = frontmatter.load(f)

    # Build header from metadata
    lines = [f"# {entry_path.stem}\n"]

    timestamp = post.metadata.get("timestamp", "")
    if timestamp:
        if isinstance(timestamp, datetime):
            lines.append(f"**Date:** {timestamp.strftime('%Y-%m-%d %H:%M')}\n")
        else:
            lines.append(f"**Date:** {timestamp}\n")

    if post.metadata.get("mood_detected"):
        mood = post.metadata["mood_detected"]
        if isinstance(mood, list):
            mood = ", ".join(mood)
        lines.append(f"**Mood:** {mood}\n")

    if post.metadata.get("themes_extracted"):
        themes = post.metadata["themes_extracted"]
        if isinstance(themes, list):
            themes = ", ".join(themes)
        lines.append(f"**Themes:** {themes}\n")

    if post.metadata.get("key_quotes"):
        lines.append("\n**Key Quotes:**\n")
        for quote in post.metadata["key_quotes"]:
            lines.append(f'- "{quote}"\n')

    if post.metadata.get("challenge_points"):
        lines.append("\n**Challenge Points:**\n")
        for point in post.metadata["challenge_points"]:
            lines.append(f"- {point}\n")

    lines.append("\n---\n\n")
    lines.append(post.content)

    return "".join(lines)


def search_entries(
    entries_dir: Path,
    query: str,
    theme: Optional[str] = None,
    mood: Optional[str] = None,
    since: Optional[datetime] = None,
    semantic: bool = True,
) -> list[tuple[Path, float, str]]:
    """Search entries by query and filters.

    Args:
        entries_dir: Directory containing entries
        query: Search query
        theme: Filter by theme
        mood: Filter by mood
        since: Filter by date (entries after this date)
        semantic: Use semantic search if available

    Returns:
        List of (path, score, snippet) tuples
    """
    results = []

    entries = list(entries_dir.glob("*.md"))

    for entry_path in entries:
        try:
            with open(entry_path) as f:
                post = frontmatter.load(f)

            # Apply filters
            if theme:
                entry_themes = post.metadata.get("themes_extracted", [])
                if isinstance(entry_themes, str):
                    entry_themes = [entry_themes]
                if not any(theme.lower() in t.lower() for t in entry_themes):
                    continue

            if mood:
                entry_mood = post.metadata.get("mood_detected", post.metadata.get("mood", ""))
                if isinstance(entry_mood, list):
                    entry_mood = " ".join(entry_mood)
                if mood.lower() not in str(entry_mood).lower():
                    continue

            if since:
                timestamp = post.metadata.get("timestamp")
                if timestamp:
                    if isinstance(timestamp, str):
                        timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                    if timestamp < since:
                        continue

            # Simple text search (semantic search handled separately)
            content_lower = post.content.lower()
            query_lower = query.lower()

            if query_lower in content_lower:
                # Find snippet around match
                idx = content_lower.find(query_lower)
                start = max(0, idx - 50)
                end = min(len(post.content), idx + len(query) + 100)
                snippet = post.content[start:end]
                if start > 0:
                    snippet = "..." + snippet
                if end < len(post.content):
                    snippet = snippet + "..."

                results.append((entry_path, 1.0, snippet))

        except (OSError, ValueError, KeyError):
            # Skip problematic files (corrupt frontmatter, unreadable, etc.)
            continue

    # Sort by score (for now just 1.0 for matches)
    results.sort(key=lambda x: x[1], reverse=True)

    return results


def get_recent_context(entries_dir: Path, count: int = 3) -> str:
    """Get recent entries as context for the AI.

    Args:
        entries_dir: Directory containing entries
        count: Number of entries to include

    Returns:
        Formatted context string
    """
    entries = list_entries(entries_dir, limit=count)

    if not entries:
        return "No previous entries yet."

    context_parts = ["## Recent Entries\n"]

    for entry_path in entries:
        try:
            with open(entry_path) as f:
                post = frontmatter.load(f)

            timestamp = post.metadata.get("timestamp", entry_path.stem)
            if isinstance(timestamp, datetime):
                timestamp = timestamp.strftime("%Y-%m-%d %H:%M")

            mood = post.metadata.get("mood_detected", post.metadata.get("mood", ""))
            if isinstance(mood, list):
                mood = ", ".join(mood)

            context_parts.append(f"\n### {timestamp}")
            if mood:
                context_parts.append(f" (mood: {mood})")
            context_parts.append(f"\n{post.content[:500]}")
            if len(post.content) > 500:
                context_parts.append("...\n")
            else:
                context_parts.append("\n")

            # Include key quotes if available
            if post.metadata.get("key_quotes"):
                context_parts.append("\nKey quotes from this entry:\n")
                for quote in post.metadata["key_quotes"][:3]:
                    context_parts.append(f'- "{quote}"\n')

        except Exception:
            continue

    return "".join(context_parts)
