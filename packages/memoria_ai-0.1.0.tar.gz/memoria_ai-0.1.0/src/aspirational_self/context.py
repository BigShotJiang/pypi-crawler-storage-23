"""Context building and challenge detection for Aspirational Self."""

from datetime import datetime
from pathlib import Path
from typing import Optional

import frontmatter


def build_session_context(
    entries_dir: Path,
    index_dir: Path,
    self_dir: Optional[Path] = None,
    max_entries: int = 3,
) -> dict:
    """Build context for a conversation session.

    Args:
        entries_dir: Directory containing entries
        index_dir: Directory containing index files
        self_dir: Directory containing personality files
        max_entries: Maximum number of recent entries to include

    Returns:
        Dictionary with context components
    """
    context = {
        "personality": "",
        "life_context": "",
        "patterns": "",
        "recent_entries": [],
        "challenge_points": [],
        "themes_summary": "",
    }

    # Load personality
    if self_dir:
        personality_file = self_dir / "personality.md"
        if personality_file.exists():
            context["personality"] = personality_file.read_text()

        context_file = self_dir / "context.md"
        if context_file.exists():
            content = context_file.read_text()
            if "(Add " not in content:  # Not template
                context["life_context"] = content

    # Load patterns
    patterns_file = index_dir / "patterns.md"
    if patterns_file.exists():
        content = patterns_file.read_text()
        if "No patterns detected" not in content:
            context["patterns"] = content

    # Load recent entries
    entries = list(entries_dir.glob("*.md"))
    entries.sort(key=lambda p: p.name, reverse=True)

    for entry_path in entries[:max_entries]:
        try:
            with open(entry_path) as f:
                post = frontmatter.load(f)

            entry_data = {
                "filename": entry_path.name,
                "timestamp": post.metadata.get("timestamp", ""),
                "mood": post.metadata.get("mood_detected", []),
                "themes": post.metadata.get("themes_extracted", []),
                "content": post.content[:500],
                "key_quotes": post.metadata.get("key_quotes", []),
            }

            context["recent_entries"].append(entry_data)

            # Collect challenge points
            for point in post.metadata.get("challenge_points", []):
                context["challenge_points"].append({
                    "source": entry_path.name,
                    "point": point,
                })

        except Exception:
            continue

    return context


def format_context_for_prompt(context: dict) -> str:
    """Format context dictionary into a prompt string.

    Args:
        context: Context dictionary from build_session_context

    Returns:
        Formatted string for LLM prompt
    """
    parts = []

    if context.get("personality"):
        parts.append(context["personality"])

    if context.get("life_context"):
        parts.append(f"\n# Current Life Context\n{context['life_context']}")

    if context.get("patterns"):
        parts.append(f"\n# Patterns Noticed\n{context['patterns'][:1000]}")

    if context.get("recent_entries"):
        parts.append("\n# Recent Entries\n")

        for entry in context["recent_entries"]:
            timestamp = entry["timestamp"]
            if isinstance(timestamp, datetime):
                timestamp = timestamp.strftime("%Y-%m-%d %H:%M")
            elif timestamp and len(str(timestamp)) > 16:
                timestamp = str(timestamp)[:16]

            mood = entry.get("mood", [])
            if isinstance(mood, list):
                mood = ", ".join(mood)

            parts.append(f"\n## {timestamp}")
            if mood:
                parts.append(f" (mood: {mood})")
            parts.append(f"\n{entry['content']}\n")

            if entry.get("key_quotes"):
                parts.append("Key quotes:\n")
                for quote in entry["key_quotes"][:2]:
                    parts.append(f'- "{quote}"\n')

    if context.get("challenge_points"):
        parts.append("\n# Challenge Points Ready\n")
        parts.append("Use these to gently challenge the user when relevant:\n")
        for cp in context["challenge_points"][:5]:
            parts.append(f"- {cp['point']}\n")

    return "".join(parts)


def find_contradictions(
    entries_dir: Path,
    current_content: str,
    current_themes: list,
) -> list[str]:
    """Find contradictions between current content and past entries.

    Args:
        entries_dir: Directory containing entries
        current_content: Current entry or message content
        current_themes: Themes in current content

    Returns:
        List of contradiction/challenge point strings
    """
    if not current_themes:
        return []

    # Collect past key quotes on similar themes
    past_quotes = []

    entries = list(entries_dir.glob("*.md"))
    entries.sort(key=lambda p: p.name, reverse=True)

    for entry_path in entries[:20]:  # Look at recent 20 entries
        try:
            with open(entry_path) as f:
                post = frontmatter.load(f)

            entry_themes = post.metadata.get("themes_extracted", [])
            if isinstance(entry_themes, str):
                entry_themes = [entry_themes]

            # Check for theme overlap
            theme_overlap = any(
                t.lower() in [et.lower() for et in entry_themes]
                for t in current_themes
            )

            if not theme_overlap:
                continue

            timestamp = post.metadata.get("timestamp", "")
            if isinstance(timestamp, datetime):
                timestamp = timestamp.strftime("%b %d")
            elif timestamp:
                timestamp = str(timestamp)[:10]

            for quote in post.metadata.get("key_quotes", [])[:2]:
                past_quotes.append({
                    "date": timestamp,
                    "quote": quote,
                    "file": entry_path.name,
                })

        except Exception:
            continue

    # For now, return the past quotes as potential challenge material
    # A more sophisticated version would use an LLM to detect actual contradictions
    contradictions = []
    for pq in past_quotes[:5]:
        contradictions.append(
            f"On {pq['date']} you said: \"{pq['quote']}\""
        )

    return contradictions


def get_theme_history(entries_dir: Path, theme: str) -> list[dict]:
    """Get history of entries related to a specific theme.

    Args:
        entries_dir: Directory containing entries
        theme: Theme to search for

    Returns:
        List of entry summaries related to the theme
    """
    history = []
    theme_lower = theme.lower()

    entries = list(entries_dir.glob("*.md"))
    entries.sort(key=lambda p: p.name)

    for entry_path in entries:
        try:
            with open(entry_path) as f:
                post = frontmatter.load(f)

            entry_themes = post.metadata.get("themes_extracted", [])
            if isinstance(entry_themes, str):
                entry_themes = [entry_themes]

            if not any(theme_lower in t.lower() for t in entry_themes):
                continue

            timestamp = post.metadata.get("timestamp", "")
            if isinstance(timestamp, datetime):
                timestamp = timestamp.strftime("%Y-%m-%d")
            elif timestamp:
                timestamp = str(timestamp)[:10]

            history.append({
                "date": timestamp,
                "filename": entry_path.name,
                "mood": post.metadata.get("mood_detected", []),
                "summary": post.content[:200],
                "key_quotes": post.metadata.get("key_quotes", []),
            })

        except Exception:
            continue

    return history
