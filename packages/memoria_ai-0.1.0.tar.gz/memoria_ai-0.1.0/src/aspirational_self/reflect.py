"""Interactive reflection sessions with Ollama."""

from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from .entries import get_recent_context


def load_personality(self_dir: Optional[Path] = None) -> str:
    """Load the personality definition.

    Args:
        self_dir: Directory containing personality.md

    Returns:
        Personality definition string
    """
    if self_dir is None:
        # Try project-local first
        local_self = Path.cwd() / "self"
        if local_self.exists():
            self_dir = local_self
        else:
            self_dir = Path.home() / "aspirational-self" / "self"

    personality_file = self_dir / "personality.md"

    if personality_file.exists():
        return personality_file.read_text()

    # Default personality if file doesn't exist
    return """You are the user's Aspirational Self - a reflective mirror, not an assistant.

You listen for subtext, not just words. You ask questions more than you give answers.
When they vent, ask "What's underneath that?"
When they contradict past statements, gently surface it.
Keep responses short. One thought at a time."""


def load_patterns(index_dir: Path) -> str:
    """Load current patterns from index.

    Args:
        index_dir: Directory containing index files

    Returns:
        Patterns content or empty string
    """
    patterns_file = index_dir / "patterns.md"

    if patterns_file.exists():
        content = patterns_file.read_text()
        # Skip if it's just the template
        if "No patterns detected yet" in content:
            return ""
        return f"\n## Current Patterns Noticed\n{content}\n"

    return ""


def build_system_prompt(entries_dir: Path, index_dir: Path) -> str:
    """Build the full system prompt with context.

    Args:
        entries_dir: Directory containing entries
        index_dir: Directory containing index files

    Returns:
        Full system prompt
    """
    parts = []

    # Personality
    parts.append(load_personality())

    # Patterns
    patterns = load_patterns(index_dir)
    if patterns:
        parts.append(patterns)

    # Recent context
    recent = get_recent_context(entries_dir, count=3)
    parts.append(f"\n{recent}")

    return "\n".join(parts)


def start_reflection(entries_dir: Path, index_dir: Path, console: Console):
    """Start an interactive reflection session.

    Args:
        entries_dir: Directory containing entries
        index_dir: Directory containing index files
        console: Rich console for output
    """
    try:
        import ollama
    except ImportError:
        console.print("[red]Ollama package not installed. Run: pip install ollama[/red]")
        return

    # Check Ollama connection
    try:
        models = ollama.list()
    except Exception as e:
        console.print(f"[red]Cannot connect to Ollama: {e}[/red]")
        console.print("Make sure Ollama is running: docker compose up -d ollama")
        return

    # Check for required model with fallback options
    preferred_models = ["llama3.1:8b", "llama3.2", "llama3:8b", "mistral"]
    available_models = [m.get("name", "") for m in models.get("models", [])]

    model_name = None
    for candidate in preferred_models:
        if any(candidate in m for m in available_models):
            model_name = candidate
            break

    if model_name is None:
        # Try to pull the first preferred model
        for candidate in preferred_models:
            console.print(f"[yellow]Trying to pull model {candidate}...[/yellow]")
            try:
                ollama.pull(candidate)
                model_name = candidate
                break
            except Exception as e:
                console.print(f"[dim]Could not pull {candidate}: {e}[/dim]")
                continue

    if model_name is None:
        console.print("[red]No suitable model available. Install one with: ollama pull llama3.1:8b[/red]")
        return

    # Build context
    system_prompt = build_system_prompt(entries_dir, index_dir)

    console.print("\n[dim]Aspirational Self is ready. Type your thoughts.[/dim]\n")

    messages = [{"role": "system", "content": system_prompt}]

    # Opening prompt from the AI
    opening = "What's on your mind?"

    # Check if there are recent entries to reference
    recent = get_recent_context(entries_dir, count=1)
    if recent and "No previous entries" not in recent:
        opening = "I've been reading your recent entries. What brings you here today?"

    console.print(Panel(opening, title="Aspirational Self", border_style="blue"))
    messages.append({"role": "assistant", "content": opening})

    while True:
        try:
            user_input = Prompt.ask("\n[bold cyan]You[/bold cyan]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Session ended.[/dim]")
            break

        if user_input.lower() in ("quit", "exit", "q"):
            console.print("\n[dim]Session ended.[/dim]")
            break

        if not user_input.strip():
            continue

        messages.append({"role": "user", "content": user_input})

        # Get response from Ollama
        try:
            console.print()
            response_text = ""

            # Stream the response
            with console.status("[dim]Thinking...[/dim]", spinner="dots"):
                response = ollama.chat(
                    model=model_name,
                    messages=messages,
                    stream=True,
                )

            console.print("[bold blue]Aspirational Self:[/bold blue] ", end="")

            for chunk in response:
                content = chunk.get("message", {}).get("content", "")
                console.print(content, end="")
                response_text += content

            console.print()

            messages.append({"role": "assistant", "content": response_text})

        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            messages.pop()  # Remove the user message that failed
