"""Conversation compaction utilities."""

from pydantic_ai.messages import ModelMessage
from pydantic_ai.usage import RequestUsage

from shotgun.agents.models import AgentDeps
from shotgun.logging_config import get_logger
from shotgun.posthog_telemetry import track_event

from .token_estimation import estimate_tokens_from_messages, get_last_api_token_count

logger = get_logger(__name__)


async def apply_persistent_compaction(
    messages: list[ModelMessage], deps: AgentDeps, force: bool = False
) -> list[ModelMessage]:
    """Apply compaction to message history for persistent storage.

    This ensures that compacted history is actually used as the conversation baseline,
    preventing cascading compaction issues across both CLI and TUI usage patterns.

    Compaction happens in two phases:
    1. Deterministic pre-compaction: Remove file content (no LLM needed)
    2. LLM-based compaction: Summarize conversation if still over threshold

    Args:
        messages: Full message history from agent run
        deps: Agent dependencies containing model config
        force: If True, force compaction even if below token threshold

    Returns:
        Compacted message history that should be stored as conversation state
    """
    from .history_processors import token_limit_compactor

    try:
        # Count tokens to decide if LLM-based compaction is needed
        # Prefer API usage data (accurate) over text-based estimation (undercounts)
        api_tokens = get_last_api_token_count(messages)
        if api_tokens > 0:
            estimated_tokens = api_tokens
            logger.debug(
                f"Using API usage data for compaction check: {estimated_tokens} tokens"
            )
        else:
            estimated_tokens = await estimate_tokens_from_messages(
                messages, deps.llm_model
            )
            logger.debug(
                f"Using text estimation for compaction check: {estimated_tokens} tokens (no API usage data)"
            )

        # Create minimal usage info for compaction check
        usage = RequestUsage(
            input_tokens=estimated_tokens,
            output_tokens=0,
        )

        # Create a minimal context object for compaction
        class MockContext:
            def __init__(self, deps: AgentDeps, usage: RequestUsage | None):
                self.deps = deps
                self.usage = usage

        ctx = MockContext(deps, usage)
        compacted_messages = await token_limit_compactor(ctx, messages, force=force)

        # Log the result for monitoring
        original_size = len(messages)
        compacted_size = len(compacted_messages)

        if compacted_size < original_size:
            reduction_pct = ((original_size - compacted_size) / original_size) * 100
            logger.debug(
                f"Persistent compaction applied: {original_size} → {compacted_size} messages "
                f"({reduction_pct:.1f}% reduction)"
            )

            # Track persistent compaction event with simple metrics (fast, no token counting)
            track_event(
                "persistent_compaction_applied",
                {
                    # Basic compaction metrics
                    "messages_before": original_size,
                    "messages_after": compacted_size,
                    "reduction_percentage": round(reduction_pct, 2),
                    "agent_mode": deps.agent_mode.value
                    if hasattr(deps, "agent_mode") and deps.agent_mode
                    else "unknown",
                    # Model and provider info (no computation needed)
                    "model_name": deps.llm_model.name_str,
                    "provider": deps.llm_model.provider.value,
                    "key_provider": deps.llm_model.key_provider.value,
                },
            )
        else:
            logger.debug(
                f"No persistent compaction needed: {original_size} messages unchanged"
            )

        return compacted_messages

    except Exception as e:
        if force:
            # When force=True (manual compaction), propagate the error so the user
            # gets a clear error message instead of silent "0% reduction"
            raise
        # For auto-compaction, return original messages to keep the system functional
        logger.warning(f"Persistent compaction failed, using original history: {e}")
        return messages


def should_apply_persistent_compaction(deps: AgentDeps) -> bool:
    """Check if persistent compaction should be applied.

    Args:
        deps: Agent dependencies

    Returns:
        True if persistent compaction should be applied
    """
    # For now, always apply persistent compaction
    # Future: Add configuration option in deps or environment variable
    return True
