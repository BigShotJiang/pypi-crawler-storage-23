"""History processing prompt templates."""
