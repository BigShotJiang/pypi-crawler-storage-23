import pandas as pd
import sys
from dataclasses import dataclass
from .api_config import API
from concurrent.futures import ThreadPoolExecutor, as_completed

@dataclass
class Risk(API):
    # === BENCHMARKS ===
    def get_benchmarks(self,bmk:str, year:str, debug:bool=False) -> pd.DataFrame:
        """
        Retorna el método GET FM_Detalle de la API-INVESTMENT-RISK.
        """
        api_url = f'{self.API_URL}/Benchmarks/{bmk}_{year}'
        if debug:
            print(f"API URL: {api_url}")
        data = self.engine(url=api_url)
        if data is None or data.empty:
            return pd.DataFrame()

        return data