document.addEventListener('DOMContentLoaded', function () {
    let addReportBtn = document.getElementById('addBattleReportBtn');
    if (addReportBtn)
        addReportBtn.addEventListener('click', ()=>addReport());
});


async function addReport() {
    if (!(await showConfirm('Вы уверены, что введенные данные верны?')))
        return;
    let filters = document.querySelector('#filters-list')

    if(filters && document.querySelector('#filters-list').childElementCount == 0 &&
        !(await showConfirm('У вас не задан ни один фильтр. Будут загружены все киллмэйлы.\r\nЧтобы загрузить киллмэйлы только своей корпорации или альянса, сначала добавьте фильтры.\r\nДобавить ссылку на отчет?')))
        return;
    let link = document.getElementById('brLink')?.value;
    let comment = document.getElementById('brComment')?.value;
    if (link) {
        let result = await addReportRequest(link,comment);
        if(result){
            showAlert('Ссылка успешно добавлена. Данные находятся на обработке.');
            return;
        }
        showAlert('При добавлении ссылки произошла ошибка!');
    }
}

async function addReportRequest(link, comment) {
    result = fetch(`/br_compensations/api/battle-reports/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({
            "link": link,
            "comment": comment,
            "report_type": 'br',
            "process": true
        })
    })
        .then(async response => {
            if (!response.ok){
                if(response.body)
                    showAlert(`Ошибка добавления ссылки. Код ${response.status}\r\n${await readableStreamToString(response.body)}`)
                showAlert(`Response status code indicates error. Status code ${response.status} ${response.body}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}

