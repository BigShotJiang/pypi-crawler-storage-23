document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.delete-btn').forEach(el=>{
        el.addEventListener('click', evnt=>deleteReportCallback(evnt));
    });
    document.querySelectorAll('.recreate-btn').forEach(el=>{
        el.addEventListener('click', evnt=>recreateReportCallback(evnt));
    })
});

async function deleteReportCallback(evnt){
    if(!(await showConfirm('Вы уверены, что хотите удалить выбранный отчет?')))
        return;
    let id = evnt.srcElement.parentElement.dataset.id;
    let parent = evnt.srcElement.closest('tr');
    let result = await deleteReportRequest(id);
    if(result)
        parent.remove();
}

async function recreateReportCallback(evnt){
    if(!(await showConfirm('Вы уверены, что хотите заново загрузить выбранный отчет?')))
        return;
    let btn = evnt.srcElement;
    let icon = btn.querySelector('i');
    icon.classList.add('spinner');
    let id = btn.dataset.id;
    let parent = btn.closest('tr');
    let result = await recreateReportRequest(id);
    if(result){
        showAlert('Отчет обработан')
        window.location.reload()
    }
    icon.classList.remove('spinner')
}

async function deleteReportRequest(id) {
    result = fetch(`/br_compensations/api/battle-reports/${id}/`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        }
        })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return true;
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}


async function recreateReportRequest(id) {
    result = fetch(`/br_compensations/api/battle-reports/${id}/`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body:JSON.stringify(
                {
                    status: 'R'
                })
        })
        .then(response => {
            if (!response.ok)
                throw new Error(`Response status code indicates error. Status code ${response.status}`);
            return true;
        })
        .then(data => {
            console.log(data);
            return data;
        })
        .catch(error => {
            console.error('Error: ', error);
        })

    return result;
}