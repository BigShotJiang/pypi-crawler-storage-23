from celery import shared_task
from br_compensations.mails_service import EveMailService
from allianceauth.services.hooks import get_extension_logger

from br_compensations.models import CharMailParse
from allianceauth.services.tasks import QueueOnce


logger = get_extension_logger(__name__)


