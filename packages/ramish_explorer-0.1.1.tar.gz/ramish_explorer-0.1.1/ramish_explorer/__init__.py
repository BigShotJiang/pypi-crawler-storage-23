"""
Ramish Explorer — Read, query, and explore .ramish knowledge graph files.

Install: pip install ramish-explorer
Usage:   ramish-explorer explore engine.ramish
"""

__version__ = "0.1.1"
