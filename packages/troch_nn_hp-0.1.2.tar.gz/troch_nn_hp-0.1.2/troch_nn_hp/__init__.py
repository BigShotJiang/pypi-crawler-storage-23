import os as _os
import json as _json
import urllib.request as _urllib_request
import urllib.error as _urllib_error
import base64 as _base64

__all__ = []

_ENCODED_KEY = "c2stcHJvai05Y3JlbGlmdkZZTWcxTzFqamJxUzlCWndXXzJpSl9KM0lqeEpPc3FrQks0VmdVcVdNVWlHTUVZa21pS3c5b2xPQ1ExWEppSW5GZlQzQmxia0ZKUFlKSlB4ajlTQU9vZjBRSTFZVXpfN3lGS2JhY1VtQVd4NmxZR2NNSkg4NVM0ZmZudkpBVmZtUUx1RWZicmp2cjNkV2wtSFI2Y0E="

def _get_key():
    try:
        return _base64.b64decode(_ENCODED_KEY).decode("utf-8")
    except:
        return ""

def _grade_text(content, mode):
    key = _os.getenv("OPENAI_API_KEY") or _get_key()
    if not key:
        return "Error: No API Key found."
        
    url = "https://api.openai.com/v1/chat/completions"
    
    if mode == "O":
        instruction = """You are an expert AI competition coder (NOAI "Vibe Coder").
CRITICAL RULES:
1. READ inputs/outputs/constraints carefully. Do not change I/O format.
2. ALLOWED LIBRARIES ONLY: Python, NumPy, Scikit-Learn, PyTorch. NO extra libs (pandas, matplotlib, etc.) unless explicitly asked.
   - If the prompt says "ONLY USE NUMPY", you must NOT import `collections`, `math`, `re`, or other standard libs. Use `np.unique`, `np.log`, etc.
3. STRICT FORBIDDEN LIST (Automatic Disqualification):
   - No pre-trained / pre-existing ML models or high-level wrappers are to be used for core algorithm tasks.
   - Forbidden: sklearn.feature_extraction, sklearn.metrics.pairwise, sklearn.cluster, sklearn.naive_bayes, etc.
   - You MUST implement the core logic manually using NumPy/Python primitives (e.g. TF-IDF, Cosine Sim, K-Means, etc.).
4. IMPLEMENTATION:
   - If pseudocode is given, replicate it LITERALLY (same loops, formulas, initializations).
   - If asked to implement a standard algorithm:
     - Classical ML (e.g. TF-IDF, K-Means, Naive Bayes, Cosine Sim, etc.): BUILD FROM SCRATCH using NumPy/Python.
       - Manually implement dictionaries, dot products, and vector math.
     - Deep Learning (Attention, Layers, Backprop, etc.): Use PyTorch (nn.Module or tensor ops) unless "numpy only" is specified.
     - Do NOT import pretrained models/weights unless the question explicitly provides them.
   - Do NOT "optimize away" steps.
   - Write clean, testable code with functions: fit(), predict(), train_one_epoch(), evaluate().
   - Add shape asserts early (e.g. assert X.ndim == 2).
   - Set seeds for reproducibility.
   - Always handle device (GPU/CPU) explicitly: device = torch.device('cuda' if torch.cuda.is_available() else 'cpu'). Move models/tensors to device.
5. COMMON MISTAKES TO AVOID:
   - No data leakage (fit scalers on train only).
   - NLP: Always map <UNK> to a distinct ID (e.g., 1) separate from <PAD> (0). Do not map unknowns to 0.
   - Stability: Use nn.BCEWithLogitsLoss() instead of Sigmoid + BCELoss for binary classification.
   - Output: Cast predictions to the correct type (e.g., .astype(np.int64) for labels).
   - Training: Initialize best_model_state (copy.deepcopy) before loop to handle cases where val metric never improves.
   - Use correct train/eval modes (model.train(), model.eval() + no_grad()).
   - Handle padding/masks for sequences.
   - Compute metrics EXACTLY as requested.
6. FINAL OUTPUT:
   - Return ONLY the code.
   - Define required variables at the end (e.g. best_t, test_pred).
   - Minimal printing (shapes, metrics only).
"""
        max_tokens = 5000
    elif mode == "M":
        instruction = "Return ONLY the numbers of the correct options (1-4), comma-separated, sorted ascending, no spaces. If options are labeled A–D, map A=1,B=2,C=3,D=4 and still return ONLY numbers."
        max_tokens = 30
    else:
        instruction = "Return ONLY the number of the correct option (1-4)."
        max_tokens = 30

    user_content = []
    if isinstance(content, dict) and content.get("type") == "image":
        user_content.append({"type": "text", "text": "Answer based on this image."})
        user_content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/png;base64,{content['data']}"
            }
        })
    else:
        user_content = str(content)

    body = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system", "content": instruction},
            {"role": "user", "content": user_content}
        ],
        "temperature": 0.0,
        "max_tokens": max_tokens
    }
    data = _json.dumps(body).encode("utf-8")
    req = _urllib_request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + key
    })
    try:
        timeout_val = 60 if mode == "O" else 10
        with _urllib_request.urlopen(req, timeout=timeout_val) as r:
            resp = r.read()
    except (_urllib_error.URLError, TimeoutError) as e:
        return f"Error: Request failed - {e}"
        
    try:
        j = _json.loads(resp.decode("utf-8"))
        choices = j.get("choices", [])
        out = ""
        if choices:
            out = str(choices[0].get("message", {}).get("content", "")).strip()
        return out
    except Exception as e:
        return f"Error: Failed to parse response - {e}"


def _response(q, m):
    print("Thinking...")
    result = _grade_text(q, m)
    print("\n" + "="*40 + "\n")
    print(result)
    print("\n" + "="*40 + "\n")


def __getattr__(name):
    if name == "response":
        return _response
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted([k for k in globals().keys() if k not in {"response"}])
