import os
import re
import json
import urllib.request
import urllib.error
import tkinter as tk
import sys
import threading
import ctypes
import io
import base64
from PIL import ImageGrab
from ctypes import wintypes

def show_overlay(root, n, state=None):
    # Close previous overlay if exists
    if state and state.get("last_overlay"):
        try:
            state["last_overlay"].destroy()
        except Exception:
            pass
            
    w = tk.Toplevel(root)
    w.overrideredirect(True)
    w.attributes("-topmost", True)
    
    font_size = 24
    if state and "font_size" in state:
        font_size = state["font_size"]
        
    lbl = tk.Label(w, text=str(n), font=("Segoe UI", font_size), bg="#111", fg="#fff")
    lbl.pack(ipadx=10, ipady=5)
    
    sw = w.winfo_screenwidth()
    sh = w.winfo_screenheight()
    ww = lbl.winfo_reqwidth() + 20
    wh = lbl.winfo_reqheight() + 10
    
    x = (sw - ww) // 2
    y = sh - wh - 60
    
    if state and state.get("pos_x") is not None and state.get("pos_y") is not None:
        x = state["pos_x"]
        y = state["pos_y"]
    elif state:
        # Save default calculated position if not set
        state["pos_x"] = x
        state["pos_y"] = y
        
    w.geometry(f"{ww}x{wh}+{x}+{y}")
    
    if state:
        state["last_overlay"] = w
        
    w.after(1000, w.destroy)

def grade_text(content, mode):
    key = os.getenv("OPENAI_API_KEY") or "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"
    if not key:
        return 0 if mode == "S" else "?"
    url = "https://api.openai.com/v1/chat/completions"
    
    if mode == "O":
        instruction = """You are an expert AI competition coder (NOAI "Vibe Coder").
CRITICAL RULES:
1. READ inputs/outputs/constraints carefully. Do not change I/O format.
2. ALLOWED LIBRARIES ONLY: Python, NumPy, Scikit-Learn, PyTorch. NO extra libs (pandas, matplotlib, etc.) unless explicitly asked.
3. IMPLEMENTATION:
   - If pseudocode is given, replicate it LITERALLY (same loops, formulas, initializations).
   - **IMPLEMENT FROM SCRATCH**: For core algorithms (TF-IDF, Cosine Similarity, K-Means, etc.), DO NOT use library functions (like TfidfVectorizer) unless the prompt explicitly says "use sklearn/library". Build them using NumPy/Python primitives.
   - Do NOT "optimize away" steps.
   - Write clean, testable code with functions: fit(), predict(), train_one_epoch(), evaluate().
   - Add shape asserts early (e.g. assert X.ndim == 2).
   - Set seeds for reproducibility.
   - Always handle device (GPU/CPU) explicitly: device = torch.device('cuda' if torch.cuda.is_available() else 'cpu'). Move models/tensors to device.
4. COMMON MISTAKES TO AVOID:
   - No data leakage (fit scalers on train only).
   - NLP: Always map <UNK> to a distinct ID (e.g., 1) separate from <PAD> (0). Do not map unknowns to 0.
   - Stability: Use nn.BCEWithLogitsLoss() instead of Sigmoid + BCELoss for binary classification.
   - Output: Cast predictions to the correct type (e.g., .astype(np.int64) for labels).
   - Training: Initialize best_model_state (copy.deepcopy) before loop to handle cases where val metric never improves.
   - Use correct train/eval modes (model.train(), model.eval() + no_grad()).
   - Handle padding/masks for sequences.
   - Compute metrics EXACTLY as requested.
5. FINAL OUTPUT:
   - Return ONLY the code.
   - Define required variables at the end (e.g. best_t, test_pred).
   - Minimal printing (shapes, metrics only).
"""
        max_tokens = 4000
    elif mode == "M":
        instruction = "Return ONLY the numbers of the correct options (1-4), comma-separated, sorted ascending, no spaces. If options are labeled A–D, map A=1,B=2,C=3,D=4 and still return ONLY numbers."
        max_tokens = 30
    else:
        instruction = "Return ONLY the number of the correct option (1-4)."
        max_tokens = 30

    # Determine if content is text or image
    user_content = []
    if isinstance(content, dict) and content.get("type") == "image":
        user_content.append({"type": "text", "text": "Answer based on this image."})
        user_content.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/png;base64,{content['data']}"
            }
        })
    else:
        user_content = str(content)

    body = {
        "model": "gpt-4o",
        "messages": [
            {"role": "system", "content": instruction},
            {"role": "user", "content": user_content}
        ],
        "temperature": 0.0,
        "max_tokens": max_tokens
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + key
    })
    try:
        # Increase timeout for open-ended mode as it generates long text
        timeout_val = 60 if mode == "O" else 10
        with urllib.request.urlopen(req, timeout=timeout_val) as r:
            resp = r.read()
    except (urllib.error.URLError, TimeoutError):
        return 0 if mode == "S" else "?"
    try:
        j = json.loads(resp.decode("utf-8"))
        choices = j.get("choices", [])
        out = ""
        if choices:
            out = str(choices[0].get("message", {}).get("content", "")).strip()
    except Exception:
        return 0 if mode == "S" else "?"
    if "--print" in sys.argv:
        try:
            print("OUT:", out)
        except Exception:
            pass
    
    if mode == "O":
        return out

    if mode == "S":
        m = re.match(r"^\s*([1-9])\s*$", out)
        if m:
            return int(m.group(1))
        m = re.search(r"\bindex\b\s*[:=]\s*([1-9])", out, flags=re.I)
        if m:
            return int(m.group(1))
        m = re.search(r"([1-9])", out)
        if m:
            return int(m.group(1))
        return 0
    else:
        nums = re.findall(r"\b([1-9])\b", out)
        letters = re.findall(r"\b([A-D])\b", out, flags=re.I)
        vals = []
        if nums:
            vals.extend(int(x) for x in nums)
        if letters:
            for ch in letters:
                idx = ord(ch.upper()) - ord('A') + 1
                if 1 <= idx <= 4:
                    vals.append(idx)
        if vals:
            vals = sorted(set(vals))
            return ",".join(str(x) for x in vals)
        return "?"

def poll_clipboard(root):
    state = {"last": None, "mode": "S", "paused": True, "font_size": 12, "pos_x": None, "pos_y": None, "last_overlay": None}
    def start_hotkey_listener():
        user32 = ctypes.windll.user32
        MOD_ALT = 0x0001
        MOD_CONTROL = 0x0002
        VK_S = ord('S')
        VK_F1 = 0x70
        
        # Arrow keys
        VK_LEFT = 0x25
        VK_UP = 0x26
        VK_RIGHT = 0x27
        VK_DOWN = 0x28
        
        # Resize keys (Main and Numpad)
        VK_PLUS = 0xBB
        VK_MINUS = 0xBD
        VK_ADD = 0x6B
        VK_SUBTRACT = 0x6D

        # Register hotkeys
        user32.RegisterHotKey(None, 1, MOD_CONTROL | MOD_ALT, VK_S)
        user32.RegisterHotKey(None, 2, 0, VK_F1)
        
        # Move
        user32.RegisterHotKey(None, 3, MOD_CONTROL | MOD_ALT, VK_LEFT)
        user32.RegisterHotKey(None, 4, MOD_CONTROL | MOD_ALT, VK_UP)
        user32.RegisterHotKey(None, 5, MOD_CONTROL | MOD_ALT, VK_RIGHT)
        user32.RegisterHotKey(None, 6, MOD_CONTROL | MOD_ALT, VK_DOWN)
        
        # Resize
        user32.RegisterHotKey(None, 7, MOD_CONTROL | MOD_ALT, VK_PLUS)
        user32.RegisterHotKey(None, 8, MOD_CONTROL | MOD_ALT, VK_MINUS)
        user32.RegisterHotKey(None, 9, MOD_CONTROL | MOD_ALT, VK_ADD)
        user32.RegisterHotKey(None, 10, MOD_CONTROL | MOD_ALT, VK_SUBTRACT)

        msg = wintypes.MSG()
        while True:
            rv = user32.GetMessageW(ctypes.byref(msg), 0, 0, 0)
            if rv == 0:
                break
            if msg.message == 0x0312:
                param = msg.wParam
                if param == 1: # Ctrl+Alt+S
                    def do_toggle():
                        modes = ["S", "M", "O"]
                        curr_idx = modes.index(state.get("mode", "S"))
                        next_idx = (curr_idx + 1) % len(modes)
                        state["mode"] = modes[next_idx]
                        
                        lbl_map = {"S": "S mode", "M": "M mode", "O": "O mode"}
                        show_overlay(root, lbl_map[state["mode"]], state)
                    root.after(0, do_toggle)
                elif param == 2: # F1
                    def do_pause():
                        state["paused"] = not state["paused"]
                        show_overlay(root, "Paused" if state["paused"] else "Resumed", state)
                    root.after(0, do_pause)
                elif param in [3, 4, 5, 6]: # Move
                    def do_move(p):
                        # Initialize pos if needed
                        if state["pos_x"] is None:
                            # Trigger a dummy overlay to calculate default pos first? 
                            # Or just assume bottom right. 
                            # show_overlay calculates it, but we can't easily get it back without refactoring.
                            # Simpler: default to screen center or current expected bottom-right
                            sw = root.winfo_screenwidth()
                            sh = root.winfo_screenheight()
                            state["pos_x"] = sw - 300
                            state["pos_y"] = sh - 200
                        
                        step_val = 20
                        if p == 3: state["pos_x"] -= step_val
                        elif p == 4: state["pos_y"] -= step_val
                        elif p == 5: state["pos_x"] += step_val
                        elif p == 6: state["pos_y"] += step_val
                        
                        show_overlay(root, "A", state)
                    root.after(0, lambda p=param: do_move(p))
                elif param in [7, 8, 9, 10]: # Resize
                    def do_resize(p):
                        if p in [7, 9]: # +
                            state["font_size"] += 2
                        else: # -
                            state["font_size"] = max(8, state["font_size"] - 2)
                        show_overlay(root, "A", state)
                    root.after(0, lambda p=param: do_resize(p))
    t = threading.Thread(target=start_hotkey_listener, daemon=True)
    t.start()
    def step():
        if not state["paused"]:
            cur = None
            cur_hash = None
            
            # 1. Try Image first
            try:
                img = ImageGrab.grabclipboard()
                if img:
                    buffered = io.BytesIO()
                    img.save(buffered, format="PNG")
                    img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
                    cur = {"type": "image", "data": img_str}
                    cur_hash = hash(img_str)
            except Exception:
                pass

            # 2. If no image, try text
            if cur is None:
                try:
                    txt = root.clipboard_get()
                    if txt:
                        cur = txt
                        cur_hash = hash(txt)
                except Exception:
                    pass

            if cur and cur_hash != state["last"]:
                state["last"] = cur_hash
                n = grade_text(cur, state["mode"])
                
                if state["mode"] == "O":
                    if n and n != "?":
                        root.clipboard_clear()
                        root.clipboard_append(n)
                        root.update()
                        state["last"] = hash(n)  # Prevent loop
                        show_overlay(root, "Copied!", state)
                    else:
                        show_overlay(root, "?", state)
                else:
                    show_overlay(root, n, state)
                
                if "--print" in sys.argv:
                    try:
                        print("INDEX:", n)
                    except Exception:
                        pass
        root.after(600, step)
    step()

def main():
    root = tk.Tk()
    root.withdraw()
    poll_clipboard(root)
    root.mainloop()

if __name__ == "__main__":
    if "--demo" in sys.argv:
        r = tk.Tk()
        r.withdraw()
        show_overlay(r, 1)
        r.after(1200, r.destroy)
        r.mainloop()
    else:
        main()
