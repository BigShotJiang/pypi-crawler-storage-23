from setuptools import setup, find_packages

setup(
    name="troch-nn-hp",
    version="0.1.2",
    description="",
    author="Your Name",
    packages=find_packages(include=["troch_nn_hp*"]),
    install_requires=[
        # No heavy dependencies needed for core logic as we use urllib
        # 'Pillow', # Optional if you plan to add image support later via helper
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
