import textwrap

def to_fasta(*args: tuple[str,str,str], output:str|None = None, max_length:int = 80) -> None:
    if output is None:
        raise ValueError("Output may not be `None`. Please specify an output location")
    with open(output, 'w') as fp:
        for tup in args:
            name, desc, sequence = tup
            fp.write(f'>{name}|{desc}\n')
            for chunk in textwrap.wrap(sequence, width=max_length):
                fp.write(f"{chunk}\n")


test = "MSQIIWGAYAQRNTEDHPPAYAPGYKTSVLRSPKNALISIAETLSEVTAPHFSADKFGPKDNDLILNYAKDGLPIGERVIVHGYVRDQFGRPVKNALVEVWQANASGRYRHPNDQYIGAMDPNFGGCGRMLTDDNGYYVFRTIKPGPYPWRNRINEWRPAHIHFSLIADGWAQRLISQFYFEGDTLIDSCPILKTIPSEQQRRALIALEDKSNFIEADSRCYRFDITLRGRRATYFENDLT"
test2 = "MSQIIWGAYAQRNTEDHPPAYAPGYKTSVLRSPKNALISIAETLSEVTAPHFSADKFGPKDNDLILNYAKDGLPIGERVIVHGYVRDQFGRPVKNALVEVWQANASGRYRHPNDQYIGAMDPNFGGCGRMLTDDNGYYVFRTIKPGPYPWRNRINEWRPAHIHFSLIADGWAQRLISQFYFEGDTLIDSCPILKTIPSEQQRRALIALEDKSNFIEADSRCYRFDITLRGRRATYFENDLT"

to_fasta(('test', 'test sequence', test), ('test', 'test sequence', test2), output=r"C:\Users\mcmurran\Downloads\test.fasta")