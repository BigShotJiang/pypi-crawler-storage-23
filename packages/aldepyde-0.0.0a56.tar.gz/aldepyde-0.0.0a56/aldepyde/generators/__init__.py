# from aldepyde.generators.deprecated.RandomProtein import *
from .protein_generator import ProteinGenerator



# from aldepyde.rand_utils.ProteinClassifier import ProteinClassifier

# __all__ = ['RandomProtein', 'protein_specs.py']

import sys
sys.stderr.write("Note that the `generators` submodule is not yet fully tested and may be unstable\n")