from __future__ import annotations

import json
import inspect
import time
import uuid
from typing import Any

from oauth_codex.tooling import (
    build_strict_response_format,
    callable_to_tool_schema,
    to_responses_tools,
)
from oauth_codex.types.chat.completions import ChatCompletion

PydanticBaseModel: Any = None
try:
    from pydantic import BaseModel as PydanticBaseModel
except Exception:
    pass


def _is_pydantic_model_type(value: Any) -> bool:
    return bool(
        PydanticBaseModel is not None
        and isinstance(value, type)
        and issubclass(value, PydanticBaseModel)
    )


def _normalize_response_format(response_format: Any) -> Any:
    if _is_pydantic_model_type(response_format):
        return build_strict_response_format(response_format)
    return response_format


def _normalize_tools(tools: Any) -> Any:
    if not isinstance(tools, list):
        return tools

    normalized: list[Any] = []
    for tool in tools:
        if callable(tool):
            normalized.extend(to_responses_tools([callable_to_tool_schema(tool)]))
            continue
        normalized.append(tool)
    return normalized


def _parse_text_with_model(response_format: type[Any], text: str) -> Any:
    try:
        return response_format.model_validate_json(text)
    except Exception:
        return response_format.model_validate(json.loads(text))


def _extract_output_text(response_data: dict[str, Any]) -> str:
    output_text = response_data.get("output_text")
    if isinstance(output_text, str):
        return output_text

    chunks: list[str] = []
    output = response_data.get("output")
    if not isinstance(output, list):
        return ""

    for item in output:
        if not isinstance(item, dict):
            continue
        if isinstance(item.get("text"), str):
            chunks.append(item["text"])

        content = item.get("content")
        if not isinstance(content, list):
            continue

        for entry in content:
            if not isinstance(entry, dict):
                continue
            entry_type = entry.get("type")
            if entry_type in {"text", "output_text"} and isinstance(
                entry.get("text"), str
            ):
                chunks.append(entry["text"])

    return "".join(chunks)


def _extract_tool_calls(response_data: dict[str, Any]) -> list[dict[str, Any]]:
    tool_calls: list[dict[str, Any]] = []
    output = response_data.get("output")
    if not isinstance(output, list):
        return tool_calls

    for item in output:
        if not isinstance(item, dict):
            continue

        item_type = item.get("type")
        if item_type not in {"function_call", "tool_call"}:
            continue

        name = item.get("name")
        if not isinstance(name, str) or not name:
            continue

        arguments = item.get("arguments")
        if not isinstance(arguments, str):
            arguments = "{}"

        call_id = item.get("call_id") or item.get("id")
        if not isinstance(call_id, str) or not call_id:
            call_id = f"call_{uuid.uuid4().hex}"

        tool_calls.append(
            {
                "id": call_id,
                "type": "function",
                "function": {
                    "name": name,
                    "arguments": arguments,
                },
            }
        )

    return tool_calls


def _build_assistant_message(completion: ChatCompletion) -> dict[str, Any]:
    message = completion.choices[0].message
    out: dict[str, Any] = {"role": "assistant"}
    if message.content is not None:
        out["content"] = message.content
    if message.tool_calls:
        out["tool_calls"] = [tool_call.to_dict() for tool_call in message.tool_calls]
    return out


def _coerce_tool_output_content(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=True)
    except TypeError:
        return str(value)


def _parse_tool_arguments(arguments: str) -> Any:
    if not arguments.strip():
        return {}
    try:
        return json.loads(arguments)
    except json.JSONDecodeError:
        return {}


def _build_tool_function_map(tools: Any) -> dict[str, Any]:
    if not isinstance(tools, list):
        return {}

    functions: dict[str, Any] = {}
    for tool in tools:
        if callable(tool):
            name = getattr(tool, "__name__", "")
            if isinstance(name, str) and name:
                functions[name] = tool
    return functions


def _run_tool_function(*, fn: Any, arguments: Any) -> Any:
    if isinstance(arguments, dict):
        return fn(**arguments)
    return fn(arguments)


def _to_chat_completion(
    *,
    response_data: dict[str, Any],
    requested_model: str,
) -> ChatCompletion:
    tool_calls = _extract_tool_calls(response_data)
    output_text = _extract_output_text(response_data)

    content: str | None = output_text
    if not content and tool_calls:
        content = None

    finish_reason = response_data.get("finish_reason")
    if not isinstance(finish_reason, str):
        finish_reason = "tool_calls" if tool_calls else "stop"

    usage_data = response_data.get("usage")
    prompt_tokens = 0
    completion_tokens = 0

    if isinstance(usage_data, dict):
        prompt_tokens = int(
            usage_data.get("prompt_tokens") or usage_data.get("input_tokens") or 0
        )
        completion_tokens = int(
            usage_data.get("completion_tokens") or usage_data.get("output_tokens") or 0
        )
    total_tokens = prompt_tokens + completion_tokens

    return ChatCompletion.model_validate(
        {
            "id": response_data.get("id") or f"chatcmpl-{uuid.uuid4().hex}",
            "created": int(response_data.get("created") or time.time()),
            "model": response_data.get("model") or requested_model,
            "choices": [
                {
                    "index": 0,
                    "finish_reason": finish_reason,
                    "message": {
                        "role": "assistant",
                        "content": content,
                        "tool_calls": tool_calls or None,
                    },
                }
            ],
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": int(usage_data.get("total_tokens") or total_tokens)
                if isinstance(usage_data, dict)
                else total_tokens,
            },
            "system_fingerprint": response_data.get("system_fingerprint"),
            "raw_response": response_data,
        }
    )


class Completions:
    def __init__(self, client: Any) -> None:
        self._client = client

    def create(
        self, *, model: str, messages: list[dict[str, Any]], **kwargs: Any
    ) -> ChatCompletion:
        payload = dict(kwargs)
        if "response_format" in payload:
            payload["response_format"] = _normalize_response_format(
                payload["response_format"]
            )
        if "tools" in payload:
            payload["tools"] = _normalize_tools(payload["tools"])
        payload["model"] = model
        payload["input"] = messages

        response = self._client.responses.create(**payload)
        response_data = response.to_dict(exclude_unset=False, exclude_none=False)
        return _to_chat_completion(response_data=response_data, requested_model=model)

    def parse(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        response_format: type[Any],
        **kwargs: Any,
    ) -> ChatCompletion:
        if not _is_pydantic_model_type(response_format):
            raise TypeError("response_format must be a Pydantic model type")

        completion = self.create(
            model=model,
            messages=messages,
            response_format=response_format,
            **kwargs,
        )

        text = ""
        if completion.choices:
            text = completion.choices[0].message.content or ""

        parsed = _parse_text_with_model(response_format, text)
        setattr(completion, "parsed", parsed)
        for choice in completion.choices:
            setattr(choice.message, "parsed", parsed)
        return completion


class BetaCompletions(Completions):
    def run_tools(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[Any],
        max_rounds: int = 10,
        **kwargs: Any,
    ) -> ChatCompletion:
        if max_rounds < 1:
            raise ValueError("max_rounds must be >= 1")

        if kwargs.get("stream"):
            raise ValueError("run_tools does not support stream=True")

        if not isinstance(tools, list) or not tools:
            raise ValueError("tools must be a non-empty list")

        tool_functions = _build_tool_function_map(tools)
        if not tool_functions:
            raise ValueError("run_tools requires callable tools")

        conversation = [dict(message) for message in messages]

        for _ in range(max_rounds):
            completion = self.create(
                model=model,
                messages=conversation,
                tools=tools,
                **kwargs,
            )

            if not completion.choices:
                return completion

            assistant_message = completion.choices[0].message
            tool_calls = assistant_message.tool_calls or []
            if not tool_calls:
                return completion

            conversation.append(_build_assistant_message(completion))

            for tool_call in tool_calls:
                fn_name = tool_call.function.name
                fn = tool_functions.get(fn_name)
                if fn is None:
                    raise ValueError(f"No callable tool provided for '{fn_name}'")

                arguments = _parse_tool_arguments(tool_call.function.arguments)
                output = _run_tool_function(fn=fn, arguments=arguments)
                if inspect.isawaitable(output):
                    raise TypeError(
                        f"Tool '{fn_name}' returned an awaitable; use arun_tools for async tools"
                    )

                conversation.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": _coerce_tool_output_content(output),
                    }
                )

        raise RuntimeError(
            "run_tools exceeded max_rounds without reaching a final response"
        )


class AsyncCompletions:
    def __init__(self, client: Any) -> None:
        self._client = client

    async def create(
        self, *, model: str, messages: list[dict[str, Any]], **kwargs: Any
    ) -> ChatCompletion:
        payload = dict(kwargs)
        if "response_format" in payload:
            payload["response_format"] = _normalize_response_format(
                payload["response_format"]
            )
        if "tools" in payload:
            payload["tools"] = _normalize_tools(payload["tools"])
        payload["model"] = model
        payload["input"] = messages

        response = await self._client.responses.create(**payload)
        response_data = response.to_dict(exclude_unset=False, exclude_none=False)
        return _to_chat_completion(response_data=response_data, requested_model=model)

    async def aparse(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        response_format: type[Any],
        **kwargs: Any,
    ) -> ChatCompletion:
        if not _is_pydantic_model_type(response_format):
            raise TypeError("response_format must be a Pydantic model type")

        completion = await self.create(
            model=model,
            messages=messages,
            response_format=response_format,
            **kwargs,
        )

        text = ""
        if completion.choices:
            text = completion.choices[0].message.content or ""

        parsed = _parse_text_with_model(response_format, text)
        setattr(completion, "parsed", parsed)
        for choice in completion.choices:
            setattr(choice.message, "parsed", parsed)
        return completion


class AsyncBetaCompletions(AsyncCompletions):
    async def arun_tools(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[Any],
        max_rounds: int = 10,
        **kwargs: Any,
    ) -> ChatCompletion:
        if max_rounds < 1:
            raise ValueError("max_rounds must be >= 1")

        if kwargs.get("stream"):
            raise ValueError("arun_tools does not support stream=True")

        if not isinstance(tools, list) or not tools:
            raise ValueError("tools must be a non-empty list")

        tool_functions = _build_tool_function_map(tools)
        if not tool_functions:
            raise ValueError("arun_tools requires callable tools")

        conversation = [dict(message) for message in messages]

        for _ in range(max_rounds):
            completion = await self.create(
                model=model,
                messages=conversation,
                tools=tools,
                **kwargs,
            )

            if not completion.choices:
                return completion

            assistant_message = completion.choices[0].message
            tool_calls = assistant_message.tool_calls or []
            if not tool_calls:
                return completion

            conversation.append(_build_assistant_message(completion))

            for tool_call in tool_calls:
                fn_name = tool_call.function.name
                fn = tool_functions.get(fn_name)
                if fn is None:
                    raise ValueError(f"No callable tool provided for '{fn_name}'")

                arguments = _parse_tool_arguments(tool_call.function.arguments)
                output = _run_tool_function(fn=fn, arguments=arguments)
                if inspect.isawaitable(output):
                    output = await output

                conversation.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": _coerce_tool_output_content(output),
                    }
                )

        raise RuntimeError(
            "arun_tools exceeded max_rounds without reaching a final response"
        )


class Chat:
    def __init__(self, client: Any) -> None:
        self.completions = Completions(client)


class AsyncChat:
    def __init__(self, client: Any) -> None:
        self.completions = AsyncCompletions(client)


class BetaChat:
    def __init__(self, client: Any) -> None:
        self.completions = BetaCompletions(client)


class AsyncBetaChat:
    def __init__(self, client: Any) -> None:
        self.completions = AsyncBetaCompletions(client)
