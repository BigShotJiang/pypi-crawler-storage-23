from ._version import __version__ as VERSION

__all__ = ["VERSION"]
