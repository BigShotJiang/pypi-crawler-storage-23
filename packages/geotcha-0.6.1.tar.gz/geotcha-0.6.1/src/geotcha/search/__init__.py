"""GEO search functionality."""
